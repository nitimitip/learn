/* ---------------------------------------------------------------------------
   Project budget: "One total" or "By milestone".

   Shared by the create wizard and the edit form (markup comes from
   templates/project_management/_budget_fields.html). The page supplies the
   milestones through cfg.getMilestones() -> [{key, name, end}], where `end`
   is an ISO date or '' and `key` is the value posted in
   budget_line_milestones[]. The create page builds that list from the plan
   being typed, so refresh() is called whenever the plan changes; the edit
   page passes the project's saved milestones.

   Only the controls of the chosen mode are enabled, so the other mode's
   fields never post. The server re-checks everything (_save_budget_lines).
--------------------------------------------------------------------------- */
window.PMBudget = (function () {
    'use strict';
    let cfg = null, root = null, linesEl = null;

    const $ = sel => root.querySelector(sel);
    const esc = t => { const d = document.createElement('div'); d.textContent = t == null ? '' : String(t); return d.innerHTML; };
    const mark = (el, bad) => { if (el) el.style.borderColor = bad ? 'var(--stop, #b42318)' : ''; return bad; };
    const cleanNum = v => (v || '').replace(/[,\s]/g, '');
    const isNum = v => /^\d+(\.\d+)?$/.test(v);

    function fmtDate(iso) {
        if (!iso) return '';
        const d = new Date(iso + 'T00:00:00');
        if (isNaN(d)) return '';
        return d.toLocaleDateString('en-GB', {day: '2-digit', month: 'short', year: 'numeric'});
    }

    function mode() {
        const r = root.querySelector('input[name="budget_mode"]:checked');
        return r ? r.value : 'single';
    }

    function opts(list, selected) {
        return list.map(v => '<option' + (v === selected ? ' selected' : '') + '>' + esc(v) + '</option>').join('');
    }

    function milestoneOptions(selected) {
        const list = cfg.getMilestones() || [];
        let html = '<option value="">' + (list.length ? 'Choose milestone...' : 'No milestones in the plan yet') + '</option>';
        list.forEach(m => {
            html += '<option value="' + esc(m.key) + '"' + (m.key === selected ? ' selected' : '') + '>'
                  + esc(m.name || 'Unnamed milestone') + (m.gone ? ' (milestone deleted)' : '') + '</option>';
        });
        return html;
    }

    function addLine(data) {
        data = data || {};
        const row = document.createElement('div');
        row.className = 'pm-bl-row';
        row.innerHTML =
            '<div><span class="mini-label">Milestone</span>'
          + '<select class="form-select bl-ms" name="budget_line_milestones[]" aria-label="Milestone">' + milestoneOptions(data.key || '') + '</select></div>'
          + '<div><span class="mini-label" title="End date of the milestone, taken from the plan">End date</span>'
          + '<input type="text" class="form-control bl-end" readonly tabindex="-1" aria-label="Milestone end date (from the plan)" placeholder="From the milestone"></div>'
          + '<div><span class="mini-label">Amount</span>'
          + '<input type="text" inputmode="numeric" class="form-control bl-amt" name="budget_line_amounts[]" placeholder="e.g. 50000" value="' + esc(data.amount == null ? '' : data.amount) + '"></div>'
          + '<div><span class="mini-label">Currency</span>'
          + '<select class="form-select bl-cur" name="budget_line_currencies[]">' + opts(cfg.currencies, data.currency || cfg.currencyDefault) + '</select></div>'
          + '<div><span class="mini-label">Invoiced</span>'
          + '<select class="form-select bl-inv" name="budget_line_invoiced[]">' + opts(cfg.invoiceStatuses, data.invoiced || cfg.invoiceDefault) + '</select></div>'
          + '<button type="button" class="btn-icon-square danger bl-del" title="Remove this line" aria-label="Remove this line"><i class="fas fa-trash"></i></button>';
        linesEl.appendChild(row);
        if (mode() !== 'milestone') row.querySelectorAll('input, select, button').forEach(x => { x.disabled = true; });
        syncRow(row);
        return row;
    }

    function syncRow(row) {
        const key = row.querySelector('.bl-ms').value;
        const m = (cfg.getMilestones() || []).find(x => x.key === key);
        row.querySelector('.bl-end').value = m ? (fmtDate(m.end) || 'No end date yet') : '';
    }

    function lineRows() { return [...linesEl.querySelectorAll('.pm-bl-row')]; }

    function totals() {
        const sums = {};
        lineRows().forEach(r => {
            const v = cleanNum(r.querySelector('.bl-amt').value);
            if (!isNum(v)) return;
            const c = r.querySelector('.bl-cur').value;
            sums[c] = (sums[c] || 0) + Math.round(parseFloat(v));
        });
        return cfg.currencies.filter(c => c in sums).map(c => c + ' ' + sums[c].toLocaleString('en-GB'));
    }

    // Rebuild every milestone dropdown from the current plan, keeping each
    // line's choice while that milestone still exists.
    function refresh() {
        if (!root) return;
        const list = cfg.getMilestones() || [];
        lineRows().forEach(row => {
            const sel = row.querySelector('.bl-ms');
            const keep = sel.value;
            sel.innerHTML = milestoneOptions(list.some(m => m.key === keep) ? keep : '');
            syncRow(row);
        });
        const t = totals();
        $('#pmBudgetTotal').innerHTML = t.length
            ? 'Total: <strong>' + esc(t.join(' + ')) + '</strong>' + (t.length > 1 ? ' <span class="pmx-muted">(currencies are not added together)</span>' : '')
            : '';
        $('#pmBudgetNoMs').hidden = list.length > 0;
    }

    function applyMode() {
        const m = mode();
        [['single', '#pmBudgetSingle'], ['milestone', '#pmBudgetSplit']].forEach(([name, sel]) => {
            const box = $(sel);
            box.hidden = m !== name;
            box.querySelectorAll('input, select, button').forEach(x => {
                if (!x.classList.contains('bl-end')) x.disabled = m !== name;
            });
        });
        if (m === 'milestone' && !lineRows().length) addLine();
        refresh();
    }

    // '' when fine, otherwise the message to show; marks the bad fields.
    function validate() {
        if (mode() === 'single') {
            const a = $('#budgetAmount');
            const v = cleanNum(a.value);
            if (mark(a, v !== '' && !isNum(v))) return 'Budget must be a number, for example 250000.';
            return '';
        }
        const seen = new Set();
        let msg = '';
        lineRows().forEach(r => {
            const sel = r.querySelector('.bl-ms'), amt = r.querySelector('.bl-amt');
            const v = cleanNum(amt.value);
            mark(sel, false); mark(amt, false);
            if (msg || (!sel.value && !v)) return;          // a blank line is ignored
            if (mark(sel, !sel.value)) { msg = 'Choose the milestone for every budget line (or remove the line).'; return; }
            if (mark(amt, !isNum(v))) { msg = 'Enter the amount for every budget line, as a number such as 50000.'; return; }
            if (mark(sel, seen.has(sel.value))) { msg = 'Each milestone can have one budget line only.'; return; }
            seen.add(sel.value);
        });
        return msg;
    }

    // One line for the create wizard's review step.
    function summary() {
        if (mode() === 'single') {
            const v = cleanNum($('#budgetAmount').value);
            if (!v) return '';
            return $('[name="budget_currency"]').value + ' ' + Math.round(parseFloat(v) || 0).toLocaleString('en-GB')
                 + ' - one total, invoiced: ' + $('[name="budget_invoiced"]').value;
        }
        const n = lineRows().filter(r => r.querySelector('.bl-ms').value && cleanNum(r.querySelector('.bl-amt').value)).length;
        if (!n) return '';
        return 'By milestone - ' + n + ' line' + (n === 1 ? '' : 's') + ', ' + totals().join(' + ');
    }

    function inReports() { const c = $('#budgetReports'); return !!(c && c.checked); }

    function init(options) {
        cfg = options;
        root = document.getElementById('pmBudget');
        if (!root) return;
        linesEl = $('#pmBudgetLines');
        (cfg.lines || []).forEach(addLine);
        root.querySelectorAll('input[name="budget_mode"]').forEach(r => r.addEventListener('change', applyMode));
        $('#pmBudgetAdd').addEventListener('click', () => { addLine(); refresh(); });
        linesEl.addEventListener('click', ev => {
            const del = ev.target.closest('.bl-del');
            if (!del) return;
            del.closest('.pm-bl-row').remove();
            refresh();
        });
        // Editing a field clears its error mark; validate() sets it again.
        linesEl.addEventListener('change', ev => { if (ev.target.closest('.pm-bl-row')) { mark(ev.target, false); refresh(); } });
        linesEl.addEventListener('input', ev => { if (ev.target.classList.contains('bl-amt')) { mark(ev.target, false); refresh(); } });
        applyMode();
    }

    return {init, refresh, validate, summary, mode, inReports};
})();
