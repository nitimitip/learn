"""
scheduler.py - the timer behind the morning "on leave today" email.

One daily cron job, ``leave_daily_digest``, at LEAVE_DIGEST_HOUR:MINUTE
(05:00 local by default), running daily_digest.run_daily_digest(). Its own
jobstore table (``apscheduler_jobs_leave``) so it never loads or fires another
module's jobs.

CATCH-UP AT START. If the service starts after the digest time but before
LEAVE_DIGEST_CATCHUP_UNTIL_HOUR (12:00 by default) the job runs once straight
away, so a reboot at 04:55 does not cost the day's email. After that hour a
"who is on leave today" email has stopped being useful and is not sent.

Turn the whole feature off with LEAVE_DIGEST_ENABLED=false.

Deployment model (identical to the other schedulers):
  * The Windows service (health_monitor_app_sched.py) owns the schedule in
    production and calls init_leave_monitoring().
  * The web app may start it too, guarded by RUN_SCHEDULERS_IN_APP. Each
    (tower, day) is claimed through a UNIQUE row in leave_digest_log before
    sending, so a second runner cannot duplicate an email.
"""

import logging
import os
import threading
from datetime import datetime
from typing import Optional

from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from tzlocal import get_localzone

from database import engine

from .daily_digest import run_daily_digest

logger = logging.getLogger(__name__)


def _env_int(name, default, low, high):
    try:
        value = int(os.environ.get(name, default))
    except (TypeError, ValueError):
        value = default
    return min(max(value, low), high)


_ENABLED = os.environ.get('LEAVE_DIGEST_ENABLED', 'true').strip().lower() \
    not in ('0', 'false', 'no', 'off')
_HOUR = _env_int('LEAVE_DIGEST_HOUR', 5, 0, 23)
_MINUTE = _env_int('LEAVE_DIGEST_MINUTE', 0, 0, 59)
_CATCHUP_UNTIL_HOUR = _env_int('LEAVE_DIGEST_CATCHUP_UNTIL_HOUR', 12, 0, 24)
_JOBSTORE_TABLE = os.environ.get('LEAVE_APSCHEDULER_TABLE',
                                 'apscheduler_jobs_leave')
_DIGEST_JOB = 'leave_daily_digest'

_init_lock = threading.Lock()
_scheduler: Optional[BackgroundScheduler] = None


def _digest_safe():
    """Scheduler entry point - never lets an exception kill the thread."""
    try:
        run_daily_digest()
    except Exception:
        logger.exception('Leave daily digest crashed (suppressed).')


def _in_catchup_window(now):
    started = (now.hour, now.minute) >= (_HOUR, _MINUTE)
    return started and now.hour < _CATCHUP_UNTIL_HOUR


def init_leave_monitoring() -> None:
    """Start the leave digest scheduler. Idempotent."""
    global _scheduler
    if not _ENABLED:
        logger.info('Leave daily digest disabled (LEAVE_DIGEST_ENABLED).')
        return
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            logger.info('Leave daily digest already running - skipping '
                        're-init.')
            return
        _scheduler = BackgroundScheduler(
            jobstores={'default': SQLAlchemyJobStore(
                engine=engine, tablename=_JOBSTORE_TABLE)},
            job_defaults={'coalesce': True, 'max_instances': 1,
                          'misfire_grace_time': 3600},
            timezone=get_localzone(),
        )
        _scheduler.add_job(
            func=_digest_safe,
            trigger=CronTrigger(hour=_HOUR, minute=_MINUTE),
            id=_DIGEST_JOB,
            name='Leave on-leave-today digest (daily %02d:%02d)' % (
                _HOUR, _MINUTE),
            replace_existing=True,
        )
        _scheduler.start()
        logger.info('Leave daily digest scheduled daily at %02d:%02d.',
                    _HOUR, _MINUTE)
    if _in_catchup_window(datetime.now()):
        # Already claimed towers are skipped, so this is harmless if the
        # 05:00 run did happen.
        _digest_safe()


def shutdown_leave_monitoring() -> None:
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            _scheduler.shutdown(wait=False)
            logger.info('Leave daily digest stopped.')
        _scheduler = None
