"""
daily_digest.py - the morning "who is on leave today" email.

Every morning (05:00 local by default, see scheduler.py) the job looks at each
ACTIVE tower. If at least one active member has an active, non-withdrawn
leave day TODAY, every active member of that tower gets one email listing who
is out. If nobody in the tower is on leave, nothing is sent and nothing is
written.

WHO GETS IT. Every active member of the tower with an email address - leads
included, and the people on leave too (they are members of the tower, and the
requirement is "all the members"). A person in two towers is listed in both
towers' emails, and receives both towers' emails, because they are away from
both and both teams need to know.

WHAT IT CONTAINS. Only what a colleague can already see on the tower
dashboard: name, leave type, the request's dates from today on, and the
backup (flagged when the backup is also on leave today). The REASON and NOTES
are never included - they are private to the owner, the tower lead and an
administrator (service.can_see_private), and this email goes to everyone.

ONCE PER TOWER PER DAY. Each (tower, day) is claimed by inserting a
LeaveDigestLog row BEFORE sending; the UNIQUE constraint means a second runner
(the Windows service and an in-process scheduler together) skips rather than
duplicates. A failed send deletes its claim, so a later run the same morning
- a service restart, or the catch-up at start-up - can retry.

Leave is read through service._leave_days, the same query the dashboard and
the Rota use, so "on leave today" means the same thing everywhere.
"""

import logging
from datetime import date, timedelta

from sqlalchemy import true as sql_true
from sqlalchemy.exc import IntegrityError

from database import get_db_session
from models import User
from modules.application_support.models import AppSupportTower

from . import emails, service
from .models import LeaveDigestLog

logger = logging.getLogger(__name__)

# How long the claim rows are kept. They only guard "today", so a few months
# is plenty for an administrator to look back at what went out.
LOG_RETENTION_DAYS = 90


def tower_digest(db, tower_id, today):
    """What one tower's digest would say today, or None when nobody is out.

    Returns {'entries': [...], 'recipients': [email], 'team_size': n}.
    Pure read - no claim, no send.
    """
    members = service.tower_members(db, tower_id)        # active users only
    if not members:
        return None
    people = {p.id: p for p, _lead in members}
    out_today = {}
    for uid, _day, req in service._leave_days(db, list(people), today, today):
        out_today.setdefault(uid, req)
    if not out_today:
        return None

    away_ids = set(out_today)
    backup_ids = {r.backup_user_id for r in out_today.values()
                  if r.backup_user_id}
    backup_names = {}
    if backup_ids:
        for person in db.query(User).filter(User.id.in_(backup_ids)).all():
            backup_names[person.id] = service.display_name(person)
    # A backup outside this tower can still be away; ask about them directly.
    backups_away = {uid for uid, _d, _r in service._leave_days(
        db, list(backup_ids - away_ids), today, today)} | away_ids

    entries = []
    for uid, req in out_today.items():
        remaining = [d for d in req.active_dates if d >= today]
        entries.append({
            'name': service.display_name(people[uid]),
            'type': req.type_label,
            'dates': service.summarise_dates(remaining),
            'backup': backup_names.get(req.backup_user_id, ''),
            'backup_away': bool(req.backup_user_id
                                and req.backup_user_id in backups_away),
        })
    entries.sort(key=lambda e: e['name'].lower())

    recipients, seen = [], set()
    for person, _lead in members:
        address = (person.email or '').strip()
        if address and address.lower() not in seen:
            seen.add(address.lower())
            recipients.append(address)
    return {'entries': entries, 'recipients': recipients,
            'team_size': len(members)}


def _claim(db, tower_id, today, absent_count, recipient_count):
    """Insert today's claim for the tower. The row if WE won, else None."""
    row = LeaveDigestLog(tower_id=tower_id, run_date=today,
                         absent_count=absent_count,
                         recipient_count=recipient_count, sent=False)
    db.add(row)
    try:
        db.commit()
        return row
    except IntegrityError:
        db.rollback()          # already sent today - by us or the other runner
        return None


def _prune(db, today):
    cutoff = today - timedelta(days=LOG_RETENTION_DAYS)
    deleted = (db.query(LeaveDigestLog)
               .filter(LeaveDigestLog.run_date < cutoff)
               .delete(synchronize_session=False))
    db.commit()
    return deleted


def run_daily_digest(today=None):
    """The whole job. Returns a dict of what it did. Never raises.

    Safe to call from the scheduler, a test, or by hand from a shell.
    """
    today = today or date.today()
    counts = {'towers_checked': 0, 'towers_with_leave': 0, 'sent': 0,
              'failed': 0, 'already_sent': 0, 'no_recipient': 0}
    db = get_db_session()
    try:
        names = dict(
            db.query(AppSupportTower.id, AppSupportTower.tower_name)
            .filter(AppSupportTower.is_active == sql_true())
            .order_by(AppSupportTower.tower_name).all())
        for tower_id in names:
            counts['towers_checked'] += 1
            try:
                digest = tower_digest(db, tower_id, today)
            except Exception:
                logger.exception('Leave digest: could not read tower %s.',
                                 tower_id)
                db.rollback()
                continue
            if digest is None:
                continue
            counts['towers_with_leave'] += 1
            if not digest['recipients']:
                counts['no_recipient'] += 1
                logger.warning('Leave digest: tower %r has people on leave '
                               'but no member with an email address.',
                               names[tower_id])
                continue
            claim = _claim(db, tower_id, today, len(digest['entries']),
                           len(digest['recipients']))
            if claim is None:
                counts['already_sent'] += 1
                continue
            ok = emails.send_daily_digest(
                names[tower_id], today, digest['entries'],
                digest['recipients'], team_size=digest['team_size'])
            if ok:
                claim.sent = True
                db.commit()
                counts['sent'] += 1
            else:
                # Release the claim so a later run this morning can retry.
                db.delete(claim)
                db.commit()
                counts['failed'] += 1
        try:
            _prune(db, today)
        except Exception:
            db.rollback()
            logger.exception('Leave digest: log prune failed (ignored).')
    except Exception:
        db.rollback()
        logger.exception('Leave digest run failed.')
    finally:
        db.close()
    logger.info('Leave digest for %s: %s', today.isoformat(), counts)
    return counts
