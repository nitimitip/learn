"""
Reading an operating system out of the free text a server record carries.

Infrastructure (Server Details) stores one string per server - "Windows
Server 2019", "RHEL 9", "Linux Red Hat 7.9" - because that is what the
Utility > Server Search estate file gives it. Two screens need more than the
string:

  * Technical Details lists an application's operating systems as PRODUCT +
    VERSION rows, and fills them from those server records, and
  * Estate Insights groups the estate by platform FAMILY (Windows, Linux,
    AIX ...) and drills into the versions of one family.

Both go through parse() so they can never disagree about what "RHEL 9" is.

Nothing is guessed: text that names no operating system this module knows
(and no entry of the Technology Catalog either) resolves to None and is left
out, rather than being filed under whatever it happens to resemble.

Pure functions over plain values - no database, no Flask - so the rules are
unit-tested directly. Python 3.9 compatible on purpose - production runs 3.9.
"""

import re

# ---------------------------------------------------------------------------
# Families and products
# ---------------------------------------------------------------------------

FAMILY_WINDOWS = 'Windows'
FAMILY_LINUX = 'Linux'
FAMILY_AIX = 'AIX'
FAMILY_SOLARIS = 'Solaris'
FAMILY_HPUX = 'HP-UX'
FAMILY_ZOS = 'z/OS'
FAMILY_IBMI = 'IBM i'
FAMILY_ESXI = 'VMware ESXi'
FAMILY_UNIX = 'Unix'
FAMILY_OTHER = 'Other'

#: Display order of the families: the big three first, the rest after, and
#: the catch-all last however many applications it holds.
FAMILIES = (
    FAMILY_WINDOWS, FAMILY_LINUX, FAMILY_AIX, FAMILY_SOLARIS, FAMILY_HPUX,
    FAMILY_ZOS, FAMILY_IBMI, FAMILY_ESXI, FAMILY_UNIX, FAMILY_OTHER,
)

# (key, family, canonical name, aliases). An alias is matched as whole words
# anywhere in the text, and the LONGEST alias that matches wins - which is
# what makes "Oracle Linux 8" an Oracle Linux and not a plain Linux.
_PRODUCTS = (
    ('windows_server', FAMILY_WINDOWS, 'Windows Server',
     ('microsoft windows server', 'windows server', 'win server')),
    # Resolved to Windows Server when a release year or the word "server"
    # follows - see _windows_product().
    ('windows', FAMILY_WINDOWS, 'Windows',
     ('microsoft windows', 'windows')),
    ('rhel', FAMILY_LINUX, 'Red Hat Enterprise Linux',
     ('red hat enterprise linux', 'redhat enterprise linux',
      'red hat linux', 'redhat linux', 'linux red hat', 'linux redhat',
      'red hat', 'redhat', 'rhel')),
    ('oracle_linux', FAMILY_LINUX, 'Oracle Linux',
     ('oracle enterprise linux', 'oracle linux', 'linux oracle', 'oel')),
    ('ubuntu', FAMILY_LINUX, 'Ubuntu Linux',
     ('ubuntu linux', 'linux ubuntu', 'ubuntu')),
    ('suse', FAMILY_LINUX, 'SUSE Linux',
     ('suse linux enterprise server', 'suse linux enterprise',
      'suse linux', 'linux suse', 'opensuse', 'sles', 'suse')),
    ('centos', FAMILY_LINUX, 'CentOS',
     ('centos linux', 'linux centos', 'centos')),
    ('debian', FAMILY_LINUX, 'Debian',
     ('debian gnu/linux', 'debian linux', 'linux debian', 'debian')),
    ('rocky', FAMILY_LINUX, 'Rocky Linux', ('rocky linux', 'rocky')),
    ('alma', FAMILY_LINUX, 'AlmaLinux', ('almalinux', 'alma linux')),
    ('amazon_linux', FAMILY_LINUX, 'Amazon Linux', ('amazon linux',)),
    ('linux', FAMILY_LINUX, 'Linux', ('gnu/linux', 'linux')),
    ('aix', FAMILY_AIX, 'AIX', ('ibm aix', 'aix')),
    ('solaris', FAMILY_SOLARIS, 'Solaris',
     ('oracle solaris', 'sun solaris', 'solaris', 'sunos')),
    ('hpux', FAMILY_HPUX, 'HP-UX', ('hp-ux', 'hp ux', 'hpux')),
    ('zos', FAMILY_ZOS, 'z/OS', ('z/os', 'zos')),
    ('ibmi', FAMILY_IBMI, 'IBM i', ('ibm i', 'os/400', 'i5/os', 'as/400')),
    ('esxi', FAMILY_ESXI, 'VMware ESXi',
     ('vmware esxi', 'vmware esx', 'esxi', 'esx')),
    ('unix', FAMILY_UNIX, 'Unix', ('unix',)),
)

_PRODUCT_BY_KEY = dict((p[0], p) for p in _PRODUCTS)


def _alias_pattern(alias):
    return re.compile('(?<![a-z0-9])' + re.escape(alias) + '(?![a-z0-9])')


# Longest alias first; ties keep the table order.
_ALIASES = sorted(
    ((alias, _alias_pattern(alias), product[0])
     for product in _PRODUCTS for alias in product[3]),
    key=lambda item: -len(item[0]))

# Processor / word-size notes that carry digits but are not a version.
_ARCH_NOISE = re.compile(
    r'(?<![a-z0-9])(x86[ -]?64|x64|x86|amd64|ia64|ppc64le|ppc64|aarch64|'
    r'arm64|(?:64|32)[ -]?bit)(?![a-z0-9])', re.IGNORECASE)

# A version token: "2019", "7.9", "22.04.3", "V7R3", "7200-05-03-2148",
# optionally followed by the release markers that are part of the version
# people quote ("2012 R2", "15 SP3").
_VERSION = re.compile(
    r'(?<![a-z0-9])(v?\d[0-9a-z.\-]*)((?:\s+(?:r2|sp\s?\d+))*)',
    re.IGNORECASE)

_RELEASE_YEAR = re.compile(r'^(?:19|20)\d\d$')


def fold(value):
    """The text an operating system is MATCHED on: case, underscores and
    runs of whitespace are typing accidents, not different systems."""
    return ' '.join((value or '').replace('_', ' ').split()).lower()


def _tidy(value):
    return ' '.join((value or '').replace('_', ' ').split())


def extract_version(text):
    """The first version in ``text``, as written, or ''."""
    cleaned = _ARCH_NOISE.sub(' ', _tidy(text))
    match = _VERSION.search(cleaned)
    if not match:
        return ''
    token = match.group(1).rstrip('.-')
    suffix = ' '.join(match.group(2).split()).upper()
    if not token:
        return ''
    return (token + (' ' + suffix if suffix else '')).strip()


def _windows_product(key, version, folded):
    """Plain "Windows" names the server product when a release year or the
    word "server" comes with it ("Windows 2016 Standard" is how a CMDB
    writes Windows Server 2016); "Windows 10" stays a desktop Windows."""
    if key != 'windows':
        return key
    year = version.split(' ')[0] if version else ''
    if _RELEASE_YEAR.match(year) or re.search(r'(?<![a-z0-9])server(?![a-z0-9])',
                                              folded):
        return 'windows_server'
    return key


def parse(label):
    """
    {'key', 'family', 'name', 'version'} for a recognised operating system,
    or None.

    ``name`` is the canonical product name ("Red Hat Enterprise Linux" for
    "RHEL 9"); ``version`` is taken from the text that FOLLOWS the product
    name, falling back to what precedes it ("7.9 Linux Red Hat").
    """
    tidy = _tidy(label)
    folded = tidy.lower()
    if not folded:
        return None
    for _alias, pattern, key in _ALIASES:
        match = pattern.search(folded)
        if not match:
            continue
        version = (extract_version(tidy[match.end():])
                   or extract_version(tidy[:match.start()]))
        key = _windows_product(key, version, folded)
        product = _PRODUCT_BY_KEY[key]
        return {'key': key, 'family': product[1], 'name': product[2],
                'version': version}
    return None


def describe(name, version=''):
    """
    The same shape as parse() for a row that is ALREADY a product + version
    (a Technical Details stack row). A product this module does not know is
    kept under its own name in the "Other" family - it was recorded, so it
    is shown.
    """
    name = _tidy(name)
    version = _tidy(version)
    parsed = parse(name)
    if parsed:
        return {'key': parsed['key'], 'family': parsed['family'],
                'name': name, 'version': version or parsed['version']}
    return {'key': 'name:' + fold(name), 'family': FAMILY_OTHER,
            'name': name, 'version': version}


def label_of(name, version=''):
    """"AIX 7.2" - the one-line form used in filters and tables."""
    return ' '.join(part for part in (_tidy(name), _tidy(version)) if part)


# ---------------------------------------------------------------------------
# Matching against the Technology Catalog
# ---------------------------------------------------------------------------

def catalog_matcher(entries):
    """
    Prepare the catalog's operating systems for resolve().

    ``entries`` are objects carrying ``id``, ``name``, ``description`` and
    ``is_active`` (TechCatalog rows of category 'os'). An active entry beats
    a retired one for the same product, then the lowest id wins - the same
    convergence rule tech_details.catalog_index() applies.
    """
    ordered = sorted(entries, key=lambda e: (not getattr(e, 'is_active', True),
                                             e.id))
    by_key = {}
    by_name = []
    for entry in ordered:
        folded = fold(entry.name)
        if not folded:
            continue
        parsed = parse(entry.name)
        if parsed:
            by_key.setdefault(parsed['key'], entry)
        by_name.append((folded, entry))
    # Longest catalog name first, so "Oracle Linux" is tried before "Oracle".
    by_name.sort(key=lambda item: -len(item[0]))
    return {'by_key': by_key, 'by_name': by_name}


def _linked(entry, version, family, key):
    return {'catalog_id': entry.id, 'item_name': entry.name,
            'version': version,
            'description': (entry.description or '').strip(),
            'family': family, 'key': key}


def resolve(label, matcher):
    """
    One server's OS text as a Technical Details row, or None.

    Returns {'catalog_id', 'item_name', 'version', 'description', 'family',
    'key'}. The catalog entry for the same PRODUCT is used whatever the
    server record called it ("RHEL 9" lands on the catalog's "Red Hat
    Enterprise Linux"); a system only the catalog knows is matched on its
    name; a recognised system the catalog lacks is returned unlinked
    (``catalog_id`` None) under its canonical name.
    """
    parsed = parse(label)
    if parsed:
        entry = matcher['by_key'].get(parsed['key'])
        if entry is not None:
            return _linked(entry, parsed['version'], parsed['family'],
                           parsed['key'])

    folded = fold(label)
    for name, entry in matcher['by_name']:
        if folded == name or folded.startswith(name + ' '):
            rest = _tidy(label)[len(name):]
            described = describe(entry.name)
            return _linked(entry, extract_version(rest), described['family'],
                           described['key'])

    if parsed:
        return {'catalog_id': None, 'item_name': parsed['name'],
                'version': parsed['version'], 'description': '',
                'family': parsed['family'], 'key': parsed['key']}
    return None
