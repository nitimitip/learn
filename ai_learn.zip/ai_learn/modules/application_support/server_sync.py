"""
Keeps an application's Server Details in step with the Utility module's
server estate (the ``server_data`` table behind Utility > Server Search).

The estate list is the system of record for a server's Location, Operating
System and Environment; Application Support only records WHICH servers an
application runs on. So the same three values are derived from the estate in
two places, and both go through this module:

  * the type-ahead on the add / edit application forms, which auto-fills the
    row the moment a known server name is picked, and
  * the re-sync that runs after the estate is re-imported, which refreshes
    every already-saved row.

A Server Details row whose hostname is NOT in the estate is left exactly as
it is. That is how external / third-party servers - which never appear in the
estate file - keep the details somebody typed by hand.

The same chain carries on one step further, to the Technical Details tab:
the operating systems an application's servers run are its operating
systems, so sync_os_stack() lists each distinct product + version once in
the Operating System section. It runs wherever the servers can change - the
add / edit application forms and the estate re-sync above.

Python 3.9 compatible on purpose - production runs 3.9.
"""

from modules.utility.servers_models import ServerData

from . import os_platform
from .models import (
    ServerDetails, ApplicationTechStack, TechCatalog, STACK_SOURCE_INFRA,
)
from .tech_details import match_key

OS_CATEGORY = 'os'

# Environment is recorded as "<Environment> : <Application Name>" so the row
# says both WHICH tier the server is and WHAT the estate believes runs on it.
ENVIRONMENT_SEPARATOR = ' : '


def norm_hostname(name):
    """Lower-cased, trimmed, FQDN-stripped hostname - the same join rule as
    tools/export_infrastructure_report.py uses against server_data."""
    return (name or '').strip().lower().split('.')[0]


def os_label(os_name, os_version):
    """"Windows Server 2019" from the estate's two separate columns."""
    return ' '.join(part for part in ((os_name or '').strip(),
                                      (os_version or '').strip()) if part)


def environment_label(environment, application_name):
    """"PROD : SAP ECC" - either half is dropped when the estate is silent
    about it, so a half-populated row never reads as " : SAP ECC"."""
    return ENVIRONMENT_SEPARATOR.join(
        part for part in ((environment or '').strip(),
                          (application_name or '').strip()) if part)


def estate_entry(server):
    """The four values a Server Details row takes from one estate record."""
    return {
        'name': (server.server_name or '').strip(),
        'location': (server.location or '').strip(),
        'os': os_label(server.OS, server.os_version),
        'environment': environment_label(server.environment,
                                         server.application_name),
    }


def estate_index(db_session):
    """{normalised hostname: estate_entry} for the whole estate.

    The estate routinely carries the same host more than once (one row per
    installed product, say); the first row wins, which is the same rule the
    type-ahead already applies.
    """
    index = {}
    rows = (db_session.query(ServerData)
            .filter(ServerData.server_name.isnot(None))
            .order_by(ServerData.id).all())
    for server in rows:
        key = norm_hostname(server.server_name)
        if key:
            index.setdefault(key, estate_entry(server))
    return index


def sync_server_details(db_session, commit=True):
    """
    Refresh every saved Server Details row that names a server in the estate.

    Called after the estate is re-imported, and from the manual re-sync
    button next to it. Returns
    ``{'matched': n, 'updated': n, 'external': n, 'os_added': n,
    'os_removed': n}`` where ``external`` counts the rows the estate does
    not know about - left untouched on purpose, see the module docstring -
    and the two ``os_`` figures are the Technical Details operating-system
    rows that followed the servers (see sync_os_stack).
    """
    index = estate_index(db_session)
    matched = updated = external = 0

    for row in db_session.query(ServerDetails).all():
        entry = index.get(norm_hostname(row.server_name))
        if entry is None:
            external += 1
            continue
        matched += 1
        changed = False
        for attribute, key in (('location', 'location'),
                               ('operating_system', 'os'),
                               ('environment_description', 'environment')):
            value = entry[key]
            # An estate with nothing to say about a field does not blank out
            # what the application already recorded.
            if not value or (getattr(row, attribute) or '') == value:
                continue
            setattr(row, attribute, value)
            changed = True
        if changed:
            updated += 1

    # The session does not autoflush, and the operating systems are read
    # back from the rows just refreshed.
    db_session.flush()
    stack = sync_os_stack(db_session)

    if commit and (updated or stack['added'] or stack['removed']):
        db_session.commit()
    return {'matched': matched, 'updated': updated, 'external': external,
            'os_added': stack['added'], 'os_removed': stack['removed']}


# ---------------------------------------------------------------------------
# Server Details -> Technical Details (Operating System)
# ---------------------------------------------------------------------------

def _stack_key(catalog_id, item_name, version):
    """What makes two operating-system rows the same row: the catalog entry
    (or, for an unlinked row, the folded name) plus the folded version."""
    identity = (('catalog', catalog_id) if catalog_id
                else ('name', match_key(item_name)))
    return identity, match_key(version)


def derive_os_rows(os_labels, matcher):
    """The distinct operating systems in a list of Server Details OS values.

    Ordered {key: resolved row} - one entry per product + version however
    many servers run it, in the order the servers list them. A value that
    names no operating system (blank, or free text such as a database name)
    contributes nothing: see os_platform.resolve().
    """
    wanted = {}
    for label in os_labels:
        resolved = os_platform.resolve(label, matcher)
        if resolved is None:
            continue
        key = _stack_key(resolved['catalog_id'], resolved['item_name'],
                         resolved['version'])
        wanted.setdefault(key, resolved)
    return wanted


def sync_os_stack(db_session, application_id=None):
    """
    Make the Technical Details operating systems follow the servers.

    For each application (or just ``application_id``) the infrastructure-
    sourced rows of its stack are brought into line with the distinct
    operating systems of its Server Details: missing ones are added, ones no
    server runs any more are removed, the rest are left exactly as they are -
    so running it twice changes nothing.

    Rows a team recorded themselves on the Technical Details form are never
    touched, and an operating system they already recorded at the same
    version is not listed a second time.

    Does not commit - the caller owns the transaction. Returns
    ``{'added': n, 'removed': n}``.
    """
    matcher = os_platform.catalog_matcher(
        db_session.query(TechCatalog)
        .filter(TechCatalog.category == OS_CATEGORY)
        .order_by(TechCatalog.id).all())

    servers = db_session.query(ServerDetails).order_by(ServerDetails.id)
    stack = (db_session.query(ApplicationTechStack)
             .filter(ApplicationTechStack.category == OS_CATEGORY)
             .order_by(ApplicationTechStack.id))
    if application_id is not None:
        servers = servers.filter(ServerDetails.application_id == application_id)
        stack = stack.filter(
            ApplicationTechStack.application_id == application_id)

    labels_by_app = {}
    for server in servers.all():
        labels_by_app.setdefault(server.application_id, []).append(
            server.operating_system)
    recorded_by_app, derived_by_app = {}, {}
    for row in stack.all():
        bucket = (derived_by_app if row.source == STACK_SOURCE_INFRA
                  else recorded_by_app)
        bucket.setdefault(row.application_id, []).append(row)

    added = removed = 0
    for app_id in sorted(set(labels_by_app) | set(derived_by_app)):
        wanted = derive_os_rows(labels_by_app.get(app_id, []), matcher)
        for row in recorded_by_app.get(app_id, []):
            wanted.pop(_stack_key(row.catalog_id, row.item_name, row.version),
                       None)

        kept = set()
        for row in derived_by_app.get(app_id, []):
            key = _stack_key(row.catalog_id, row.item_name, row.version)
            if key in wanted and key not in kept:
                kept.add(key)
            else:
                db_session.delete(row)
                removed += 1

        for key, resolved in wanted.items():
            if key in kept:
                continue
            db_session.add(ApplicationTechStack(
                application_id=app_id, category=OS_CATEGORY,
                catalog_id=resolved['catalog_id'],
                item_name=resolved['item_name'],
                version=resolved['version'] or None,
                description=resolved['description'] or None,
                source=STACK_SOURCE_INFRA))
            added += 1

    if added or removed:
        db_session.flush()
    return {'added': added, 'removed': removed}
