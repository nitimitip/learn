"""
routes.py - Delivery Risk Register.

    /risk-register/                     the register: date range, charts,
                                        Project risks table, BAU risks table
    /risk-register/export.xlsx          the same window as an Excel workbook
    /risk-register/bau/add              POST (fetch) log a BAU risk
    /risk-register/bau/<id>/edit        POST (fetch) update a BAU risk
    /risk-register/bau/<id>/delete      POST (fetch) delete a BAU risk

Access rules live in service.py. CSRF is enforced globally (csrf_utils): the
forms carry the hidden token and fetch() writes get the header from csrf.js.
"""

import io
import logging
import os
from datetime import datetime
from functools import wraps

from flask import (Blueprint, flash, jsonify, redirect, render_template,
                   request, send_file, url_for)

from auth import get_current_user
from database import get_db_session

from . import report_excel, service
from .models import BauRiskLog

logger = logging.getLogger(__name__)

risk_register_bp = Blueprint('risk_register', __name__,
                             template_folder='../../templates/risk_register')

_STATIC_DIR = os.path.normpath(os.path.join(os.path.dirname(__file__),
                                            '..', '..', 'static'))


def _asset_version(filename):
    try:
        return int(os.path.getmtime(os.path.join(_STATIC_DIR, filename)))
    except OSError:
        return 0


@risk_register_bp.context_processor
def _asset_versions():
    return {'asset_v': _asset_version}


@risk_register_bp.after_request
def _no_store(response):
    if response.mimetype == 'text/html':
        response.headers['Cache-Control'] = 'no-store, max-age=0'
    return response


# ---------------------------------------------------------------------------
# Gates
# ---------------------------------------------------------------------------

def login_required(view):
    """Any signed-in user may read the register and download it."""
    @wraps(view)
    def wrapper(*args, **kwargs):
        user = get_current_user()
        if not user:
            flash('Please sign in to use the Risk Register.', 'error')
            return redirect(url_for('login'))
        return view(*args, user=user, **kwargs)
    return wrapper

def _json_gate():
    """(user, error response) for the fetch endpoints."""
    user = get_current_user()
    if not user:
        return None, (jsonify({'ok': False,
                               'error': 'Please sign in again.'}), 401)
    return user, None


def _ctx(user, **extra):
    extra['user'] = user
    extra['is_admin'] = service.is_admin(user)
    return extra


def _window():
    return service.resolve_window(request.args.get('from'),
                                  request.args.get('to'))


# ---------------------------------------------------------------------------
# Register
# ---------------------------------------------------------------------------

@risk_register_bp.route('/')
@login_required
def index(user=None):
    start, end, msg = _window()
    if msg:
        flash(msg, 'warning')
    db_session = get_db_session()
    try:
        p_rows, b_rows, summary = service.window_rows(db_session, start, end,
                                                      user)
        can_add = service.can_add_bau(db_session, user)
        return render_template('risk_register/index.html', **_ctx(
            user, start=start, end=end,
            default_start=service.default_window()[0],
            project_rows=p_rows, bau_rows=b_rows, summary=summary,
            can_add=can_add, vocab=service.form_vocab(),
            today=datetime.now().date()))
    finally:
        db_session.close()


@risk_register_bp.route('/export.xlsx')
@login_required
def export(user=None):
    start, end, _msg = _window()
    db_session = get_db_session()
    try:
        p_rows, b_rows, summary = service.window_rows(db_session, start, end,
                                                      user)
        data = report_excel.build_workbook(
            {'start': start, 'end': end, 'generated': datetime.now(),
             'prepared_by': service.display_name(user)},
            summary, p_rows, b_rows)
    finally:
        db_session.close()
    name = 'risk_register_%s_to_%s.xlsx' % (start.isoformat(),
                                            end.isoformat())
    return send_file(
        io.BytesIO(data), as_attachment=True, download_name=name,
        mimetype='application/vnd.openxmlformats-officedocument.'
                 'spreadsheetml.sheet')


# ---------------------------------------------------------------------------
# BAU risks (fetch -> JSON)
# ---------------------------------------------------------------------------

@risk_register_bp.route('/bau/add', methods=['POST'])
def add_bau():
    user, err = _json_gate()
    if err:
        return err
    db_session = get_db_session()
    try:
        if not service.can_add_bau(db_session, user):
            return jsonify({'ok': False, 'error':
                            'Only Application Support tower members can log '
                            'BAU risks.'}), 403
        risk = BauRiskLog()
        service.apply_bau_form(risk, request.form, user)
        db_session.add(risk)
        db_session.commit()
        return jsonify({'ok': True, 'id': risk.id})
    except service.RiskInputError as exc:
        db_session.rollback()
        return jsonify({'ok': False, 'error': str(exc)}), 400
    except Exception:
        db_session.rollback()
        logger.exception('Failed to add BAU risk')
        return jsonify({'ok': False,
                        'error': 'The risk could not be saved.'}), 500
    finally:
        db_session.close()


@risk_register_bp.route('/bau/<int:risk_id>/edit', methods=['POST'])
def edit_bau(risk_id):
    user, err = _json_gate()
    if err:
        return err
    db_session = get_db_session()
    try:
        risk = db_session.get(BauRiskLog, risk_id)
        if risk is None:
            return jsonify({'ok': False,
                            'error': 'That risk no longer exists.'}), 404
        if not service.can_change_bau(user, risk):
            return jsonify({'ok': False, 'error':
                            'Only the person who logged this risk, or an '
                            'administrator, can change it.'}), 403
        service.apply_bau_form(risk, request.form, user)
        db_session.commit()
        return jsonify({'ok': True, 'id': risk.id})
    except service.RiskInputError as exc:
        db_session.rollback()
        return jsonify({'ok': False, 'error': str(exc)}), 400
    except Exception:
        db_session.rollback()
        logger.exception('Failed to edit BAU risk %s', risk_id)
        return jsonify({'ok': False,
                        'error': 'The risk could not be saved.'}), 500
    finally:
        db_session.close()


@risk_register_bp.route('/bau/<int:risk_id>/delete', methods=['POST'])
def delete_bau(risk_id):
    user, err = _json_gate()
    if err:
        return err
    db_session = get_db_session()
    try:
        risk = db_session.get(BauRiskLog, risk_id)
        if risk is None:
            return jsonify({'ok': True})
        if not service.can_change_bau(user, risk):
            return jsonify({'ok': False, 'error':
                            'Only the person who logged this risk, or an '
                            'administrator, can delete it.'}), 403
        db_session.delete(risk)
        db_session.commit()
        return jsonify({'ok': True})
    except Exception:
        db_session.rollback()
        logger.exception('Failed to delete BAU risk %s', risk_id)
        return jsonify({'ok': False,
                        'error': 'The risk could not be deleted.'}), 500
    finally:
        db_session.close()
