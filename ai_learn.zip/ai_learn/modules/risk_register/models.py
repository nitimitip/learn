"""
models.py - Delivery Risk Register.

One table of its own:

  bau_risk_logs   one row per BAU (business-as-usual) risk. Logged by
                  Application Support tower members (tower_members, owned by
                  that module); see service.py for the access rules.

Project risks are NOT copied here. They stay in project_risk_logs (the
Project Management risk log) and are read live, so the register can never
disagree with the project page.

The ACCOUNTABLE PARTY is the field the register exists for: which party a
risk - typically a delay - is attributed to. The vocabulary lives in
project_management.models.RISK_ACCOUNTABLE_PARTIES so the project risk log and
the BAU risk log use the same words.
"""

from datetime import date

from sqlalchemy import Column, Date, DateTime, ForeignKey, Index, Integer, String, Text
from sqlalchemy.sql import func

from database import Base

# Plain strings (not DB enums) so a stray value can never break a page load.
BAU_RISK_STATUSES = ['Open', 'Mitigated', 'Closed']
BAU_RISK_SEVERITIES = ['Low', 'Medium', 'High', 'Critical']


class BauRiskLog(Base):
    """One BAU risk. Same fields as a project risk, plus the service it
    concerns and an optional change / ticket reference, because a BAU risk
    has no project to give it context."""
    __tablename__ = 'bau_risk_logs'

    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)
    summary = Column(Text, nullable=False)
    service = Column(String(200))            # application / service concerned
    reference = Column(String(100))          # change / ticket reference
    accountable_party = Column(String(40), nullable=False)
    severity = Column(String(20), nullable=False, default='Low')
    status = Column(String(20), nullable=False, default='Open')
    probability = Column(Integer)            # 1-5
    impact = Column(Integer)                 # 1-5
    owner = Column(String(200))
    mitigation = Column(Text)
    due_date = Column(Date)
    identified_on = Column(Date, nullable=False)
    resolved_on = Column(Date)
    created_by = Column(Integer, ForeignKey('users.id'))
    updated_by = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index('ix_bau_risk_logs_identified', 'identified_on'),
    )

    @property
    def score(self):
        if self.probability and self.impact:
            return self.probability * self.impact
        return None

    @property
    def is_open(self):
        return (self.status or 'Open') == 'Open'

    @property
    def identified_date(self):
        return self.identified_on

    def age_days(self):
        """Days open so far, or days it took to resolve."""
        if not self.identified_on:
            return None
        if self.is_open:
            end = date.today()
        elif self.resolved_on:
            end = self.resolved_on
        else:
            return None
        return max(0, (end - self.identified_on).days)

    def __repr__(self):
        return '<BauRiskLog %s %r>' % (self.id, self.name)
