"""
Delivery Risk Register (Delivery).

One register for the risks that hold delivery up, project and BAU side by
side, each attributed to an accountable party (Business, Third-Party Vendor,
Delivery Team, Support Team) so it is always clear where a risk sits.

    Project risks   read live from the Project Management risk log.
    BAU risks       logged here by register members whose profile team is
                    BAU or Project & BAU.

Tables (models.py), rules and figures (service.py), the Excel workbook
(report_excel.py) and one blueprint (routes.py).
"""

from .routes import risk_register_bp

__all__ = ['risk_register_bp']
