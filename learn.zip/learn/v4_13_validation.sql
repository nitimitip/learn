/******************************************************************************
  V4-13 validation: hourly BT_Message status email.
  V4-13.1 and V4-13.4 are read-only. V4-13.2 adds email addresses.
  V4-13.3 sends one email and saves one set of counts.
******************************************************************************/

-- ============================================================================
-- V4-13.1 (read-only, before deploy) Database Mail and SQL Agent.
--   Expect at least one profile, mail STARTED, and the Agent service Running.
-- ============================================================================
SELECT name FROM msdb.dbo.sysmail_profile;
EXEC msdb.dbo.sysmail_help_status_sp;
SELECT servicename, status_desc FROM sys.dm_server_services;

-- Is Message_Received_On filled in? The application writes these rows, not a procedure.
--   Expect null_dates = 0 and newest close to now. A row with no date is never reported.
SELECT Source, COUNT(*) AS rows_checked,
       SUM(CASE WHEN Message_Received_On IS NULL THEN 1 ELSE 0 END) AS null_dates,
       MIN(Message_Received_On) AS oldest, MAX(Message_Received_On) AS newest
FROM (SELECT TOP 5000 Source, Message_Received_On FROM dbo.BT_Message WITH (NOLOCK) ORDER BY ID DESC) x
GROUP BY Source
ORDER BY Source;
GO

-- ============================================================================
-- V4-13.2 (after deploy) Add email addresses, one row per address.
-- ============================================================================
INSERT INTO dbo.QPID_CRM_Status_Report_Recipient (Email) VALUES
    ('first.person@company.com'),
    ('second.person@company.com');

SELECT Email, Is_Active, Added_On FROM dbo.QPID_CRM_Status_Report_Recipient ORDER BY Email;
GO

-- To stop an address but keep it listed:
-- UPDATE dbo.QPID_CRM_Status_Report_Recipient SET Is_Active = 0 WHERE Email = 'first.person@company.com';
-- To remove an address:
-- DELETE FROM dbo.QPID_CRM_Status_Report_Recipient WHERE Email = 'first.person@company.com';

-- ============================================================================
-- V4-13.3 (after V4-13.2) Send one now. Set the profile first.
--   No email is sent if no message received today is at F or P. See V4-13.5.
--   The first email of the day shows the change from zero. A second shows the change since the first.
-- ============================================================================
EXEC dbo.usp_QPID_CRM_Status_Report @MailProfile = N'CHANGE_ME';
GO

-- ============================================================================
-- V4-13.4 (read-only) Did it go out, and is the job running each hour?
-- ============================================================================
SELECT TOP 10 mailitem_id, recipients, subject, sent_status, sent_date
FROM msdb.dbo.sysmail_allitems ORDER BY mailitem_id DESC;

SELECT TOP 10 l.event_type, l.description, l.log_date
FROM msdb.dbo.sysmail_event_log l ORDER BY l.log_id DESC;

SELECT TOP 10 h.run_date, h.run_time, h.run_status, h.message
FROM msdb.dbo.sysjobhistory h
JOIN msdb.dbo.sysjobs j ON j.job_id = h.job_id
WHERE j.name = N'QPID - CRM status report hourly' AND h.step_id = 0
ORDER BY h.instance_id DESC;

-- The counts saved each hour.
SELECT TOP 50 Run_At, Source, F_Count, P_Count, W_Count, I_Count
FROM dbo.QPID_CRM_Status_Report_Log ORDER BY Run_At DESC, Source;

-- Check the report against the table.
SELECT Source, Message_Status, COUNT(*) AS row_count
FROM dbo.BT_Message WITH (NOLOCK)
WHERE Message_Status IN ('F', 'P', 'W', 'I')
  AND Message_Received_On >= CONVERT(date, GETDATE())
  AND Message_Received_On < DATEADD(DAY, 1, CONVERT(date, GETDATE()))
GROUP BY Source, Message_Status
ORDER BY Source, Message_Status;
GO

-- ============================================================================
-- V4-13.5 (read-only) Rows the report leaves out, because they arrived before today.
--   Run this now and then. An old row at I is a stuck message.
-- ============================================================================
SELECT Source, Message_Status, COUNT(*) AS row_count, MIN(Message_Received_On) AS oldest
FROM dbo.BT_Message WITH (NOLOCK)
WHERE Message_Status IN ('F', 'W', 'I')
  AND (Message_Received_On < CONVERT(date, GETDATE()) OR Message_Received_On IS NULL)
GROUP BY Source, Message_Status
ORDER BY Source, Message_Status;
GO
