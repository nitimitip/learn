/*
 * Team Members picker filter (create + edit project).
 *
 * Group radio -> Team checkboxes (the profile sub-group of that group) ->
 * every select[name="team_member_ids[]"] inside the team list is rebuilt to
 * show only the matching people. No team ticked = every team of the group.
 *
 * Rules:
 *   - a person already chosen in a row is always kept in that row's list,
 *     so filtering never silently clears a selection;
 *   - rows added later ("Add team member") are filtered as they appear
 *     (MutationObserver on the list), so addTeam() needs no change;
 *   - it is a view filter only - the server contract is unchanged.
 *
 * PMTeamFilter.init({people: [{id, group, team}], optionsHtml: '<option>...'})
 */
(function () {
    'use strict';

    var SELECT = 'select[name="team_member_ids[]"]';

    function esc(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
            return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c];
        });
    }

    function init(opts) {
        var box = document.getElementById(opts.boxId || 'teamFilter');
        var list = document.getElementById(opts.listId || 'team');
        if (!box || !list) return;

        var people = opts.people || [];
        var byId = {};
        people.forEach(function (p) { byId[String(p.id)] = p; });

        var teamRow = box.querySelector('#tfTeamRow');
        var teamsBox = box.querySelector('.tf-teams');
        var countEl = box.querySelector('#tfCount');

        // Master option list, parsed once from the page's TEAM_OPTIONS string.
        var master = document.createElement('select');
        master.innerHTML = opts.optionsHtml || '';
        var allOpts = Array.prototype.slice.call(master.options);

        function group() {
            var r = box.querySelector('input[name="tf_group"]:checked');
            return r ? r.value : '__all';
        }
        function tickedTeams() {
            var out = {};
            teamsBox.querySelectorAll('input:checked').forEach(function (c) { out[c.value] = true; });
            return out;
        }
        function matches(p, g, teams, anyTicked) {
            if (g === '__all') return true;
            if (p.group !== g) return false;
            return !anyTicked || !!teams[p.team];
        }

        function renderTeams() {
            var g = group();
            teamsBox.innerHTML = '';
            if (g === '__all') { teamRow.hidden = true; return; }
            var counts = {};
            people.forEach(function (p) {
                if (p.group === g) counts[p.team] = (counts[p.team] || 0) + 1;
            });
            var names = Object.keys(counts).sort(function (a, b) {
                if (a === '') return 1;           // "Not set" last
                if (b === '') return -1;
                return a.localeCompare(b);
            });
            teamsBox.innerHTML = names.map(function (n) {
                return '<label class="ms-stage-opt"><input type="checkbox" value="' + esc(n) +
                       '" form="pmTeamFilterNone"> ' + esc(n || 'Not set') +
                       ' <span class="tf-n">' + counts[n] + '</span></label>';
            }).join('');
            teamRow.hidden = names.length === 0;
        }

        function applyTo(sel, g, teams, anyTicked) {
            var cur = sel.value;
            sel.innerHTML = '';
            allOpts.forEach(function (o) {
                var p = byId[o.value];
                if (!o.value || o.value === cur || !p || matches(p, g, teams, anyTicked)) {
                    sel.appendChild(o.cloneNode(true));
                }
            });
            sel.value = cur;
        }

        function state() {
            var teams = tickedTeams();
            return {g: group(), teams: teams, any: Object.keys(teams).length > 0};
        }

        function apply() {
            var s = state();
            list.querySelectorAll(SELECT).forEach(function (sel) { applyTo(sel, s.g, s.teams, s.any); });
            var n = people.filter(function (p) { return matches(p, s.g, s.teams, s.any); }).length;
            countEl.textContent = s.g === '__all'
                ? people.length + (people.length === 1 ? ' person' : ' people') + ' available'
                : 'Showing ' + n + ' of ' + people.length + ' people in the Person lists below';
        }

        box.addEventListener('change', function (ev) {
            if (ev.target.name === 'tf_group') renderTeams();
            apply();
        });

        // Rows added after load (Add team member) pick up the current filter.
        new MutationObserver(function (muts) {
            var s = state();
            muts.forEach(function (m) {
                m.addedNodes.forEach(function (n) {
                    if (!n.querySelectorAll) return;
                    var sels = n.matches && n.matches(SELECT) ? [n] : n.querySelectorAll(SELECT);
                    Array.prototype.forEach.call(sels, function (sel) { applyTo(sel, s.g, s.teams, s.any); });
                });
            });
        }).observe(list, {childList: true});

        renderTeams();
        apply();
    }

    window.PMTeamFilter = {init: init};
})();
