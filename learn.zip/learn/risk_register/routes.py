"""
routes.py - Delivery RAID Log (was the Risk Register).

    /raid-log/                          the log: date range, charts, then
                                        Project RAID / BAU RAID, each with
                                        Risks / Assumptions / Issues /
                                        Dependencies tables
    /raid-log/export.xlsx               the same window as an Excel workbook
    /raid-log/bau/add                   POST (fetch) log a BAU risk
    /raid-log/bau/<id>/edit             POST (fetch) update a BAU risk
    /raid-log/bau/<id>/delete           POST (fetch) delete a BAU risk
    /raid-log/bau/<kind>/add            POST (fetch) log a BAU assumption /
                                        issue / dependency
    /raid-log/bau/<kind>/<id>/edit      POST (fetch) update one
    /raid-log/bau/<kind>/<id>/delete    POST (fetch) delete one

    /risk-register/...                  old addresses: GETs redirect to the
                                        same page under /raid-log

Access rules live in service.py. CSRF is enforced globally (csrf_utils): the
forms carry the hidden token and fetch() writes get the header from csrf.js.
"""

import io
import logging
import os
from datetime import datetime
from functools import wraps

from flask import (Blueprint, flash, jsonify, redirect, render_template,
                   request, send_file, url_for)

from auth import get_current_user
from database import get_db_session

from . import report_excel, service
from .models import BAU_ITEM_KINDS, BauRaidItem, BauRiskLog

logger = logging.getLogger(__name__)

# The blueprint keeps its original name ('risk_register') so every
# url_for(), the module catalogue and the access report keep working; only
# the address and the wording moved to "RAID Log".
risk_register_bp = Blueprint('risk_register', __name__,
                             template_folder='../../templates/risk_register')

# The old /risk-register address: bookmarks and shared links land on the
# same page of the RAID Log, query string kept.
risk_register_legacy_bp = Blueprint('risk_register_legacy', __name__)


@risk_register_legacy_bp.route('/', defaults={'rest': ''})
@risk_register_legacy_bp.route('/<path:rest>')
def legacy_redirect(rest):
    target = '/raid-log/' + rest
    if request.query_string:
        target += '?' + request.query_string.decode('latin-1')
    return redirect(target, code=301)

_STATIC_DIR = os.path.normpath(os.path.join(os.path.dirname(__file__),
                                            '..', '..', 'static'))


def _asset_version(filename):
    try:
        return int(os.path.getmtime(os.path.join(_STATIC_DIR, filename)))
    except OSError:
        return 0


@risk_register_bp.context_processor
def _asset_versions():
    return {'asset_v': _asset_version}


@risk_register_bp.after_request
def _no_store(response):
    if response.mimetype == 'text/html':
        response.headers['Cache-Control'] = 'no-store, max-age=0'
    return response


# ---------------------------------------------------------------------------
# Gates
# ---------------------------------------------------------------------------

def login_required(view):
    """Any signed-in user may read the register and download it."""
    @wraps(view)
    def wrapper(*args, **kwargs):
        user = get_current_user()
        if not user:
            flash('Please sign in to use the RAID Log.', 'error')
            return redirect(url_for('login'))
        return view(*args, user=user, **kwargs)
    return wrapper

def _json_gate():
    """(user, error response) for the fetch endpoints."""
    user = get_current_user()
    if not user:
        return None, (jsonify({'ok': False,
                               'error': 'Please sign in again.'}), 401)
    return user, None


def _ctx(user, **extra):
    extra['user'] = user
    extra['is_admin'] = service.is_admin(user)
    return extra


def _window():
    return service.resolve_window(request.args.get('from'),
                                  request.args.get('to'))


# ---------------------------------------------------------------------------
# Register
# ---------------------------------------------------------------------------

@risk_register_bp.route('/')
@login_required
def index(user=None):
    start, end, msg = _window()
    if msg:
        flash(msg, 'warning')
    db_session = get_db_session()
    try:
        logs, summary = service.raid_window(db_session, start, end, user)
        can_add = service.can_add_bau(db_session, user)
        can_edit_any = any(r.get('can_edit') for rows in logs['bau'].values()
                           for r in rows)
        return render_template('risk_register/index.html', **_ctx(
            user, start=start, end=end,
            default_start=service.default_window()[0],
            logs=logs, summary=summary,
            dash={'entries': service.dashboard_entries(logs),
                  'start': start.isoformat(), 'end': end.isoformat(),
                  'parties': service.PARTY_ORDER,
                  'kinds': [{'key': k, 'label': service.KIND_PLURAL[k]}
                            for k in service.KIND_KEYS],
                  'prob': service.RISK_PROBABILITY_LABELS,
                  'impact': service.RISK_IMPACT_LABELS},
            # Kept for the risk tables / modal (unchanged since the Risk
            # Register): the two risk logs.
            project_rows=logs['project']['risk'], bau_rows=logs['bau']['risk'],
            can_add=can_add, can_edit_any=can_edit_any,
            vocab=service.raid_vocab(),
            today=datetime.now().date()))
    finally:
        db_session.close()


@risk_register_bp.route('/export.xlsx')
@login_required
def export(user=None):
    start, end, _msg = _window()
    db_session = get_db_session()
    try:
        logs, summary = service.raid_window(db_session, start, end, user)
        data = report_excel.build_workbook(
            {'start': start, 'end': end, 'generated': datetime.now(),
             'prepared_by': service.display_name(user)},
            summary, logs)
    finally:
        db_session.close()
    name = 'raid_log_%s_to_%s.xlsx' % (start.isoformat(), end.isoformat())
    return send_file(
        io.BytesIO(data), as_attachment=True, download_name=name,
        mimetype='application/vnd.openxmlformats-officedocument.'
                 'spreadsheetml.sheet')


# ---------------------------------------------------------------------------
# BAU risks (fetch -> JSON)
# ---------------------------------------------------------------------------

@risk_register_bp.route('/bau/add', methods=['POST'])
def add_bau():
    user, err = _json_gate()
    if err:
        return err
    db_session = get_db_session()
    try:
        if not service.can_add_bau(db_session, user):
            return jsonify({'ok': False, 'error':
                            'Only Application Support tower members can log '
                            'BAU risks.'}), 403
        risk = BauRiskLog()
        service.apply_bau_form(risk, request.form, user)
        db_session.add(risk)
        db_session.commit()
        return jsonify({'ok': True, 'id': risk.id})
    except service.RiskInputError as exc:
        db_session.rollback()
        return jsonify({'ok': False, 'error': str(exc)}), 400
    except Exception:
        db_session.rollback()
        logger.exception('Failed to add BAU risk')
        return jsonify({'ok': False,
                        'error': 'The risk could not be saved.'}), 500
    finally:
        db_session.close()


@risk_register_bp.route('/bau/<int:risk_id>/edit', methods=['POST'])
def edit_bau(risk_id):
    user, err = _json_gate()
    if err:
        return err
    db_session = get_db_session()
    try:
        risk = db_session.get(BauRiskLog, risk_id)
        if risk is None:
            return jsonify({'ok': False,
                            'error': 'That risk no longer exists.'}), 404
        if not service.can_change_bau(user, risk):
            return jsonify({'ok': False, 'error':
                            'Only the person who logged this risk, or an '
                            'administrator, can change it.'}), 403
        service.apply_bau_form(risk, request.form, user)
        db_session.commit()
        return jsonify({'ok': True, 'id': risk.id})
    except service.RiskInputError as exc:
        db_session.rollback()
        return jsonify({'ok': False, 'error': str(exc)}), 400
    except Exception:
        db_session.rollback()
        logger.exception('Failed to edit BAU risk %s', risk_id)
        return jsonify({'ok': False,
                        'error': 'The risk could not be saved.'}), 500
    finally:
        db_session.close()


@risk_register_bp.route('/bau/<int:risk_id>/delete', methods=['POST'])
def delete_bau(risk_id):
    user, err = _json_gate()
    if err:
        return err
    db_session = get_db_session()
    try:
        risk = db_session.get(BauRiskLog, risk_id)
        if risk is None:
            return jsonify({'ok': True})
        if not service.can_change_bau(user, risk):
            return jsonify({'ok': False, 'error':
                            'Only the person who logged this risk, or an '
                            'administrator, can delete it.'}), 403
        db_session.delete(risk)
        db_session.commit()
        return jsonify({'ok': True})
    except Exception:
        db_session.rollback()
        logger.exception('Failed to delete BAU risk %s', risk_id)
        return jsonify({'ok': False,
                        'error': 'The risk could not be deleted.'}), 500
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# BAU assumptions / issues / dependencies (fetch -> JSON). Same rules as BAU
# risks: tower members and admins add; the creator or an admin changes.
# ---------------------------------------------------------------------------

def _bau_item(db_session, kind, item_id):
    item = db_session.get(BauRaidItem, item_id)
    if item is None or item.kind != kind:
        return None
    return item


@risk_register_bp.route('/bau/<kind>/add', methods=['POST'])
def add_bau_item(kind):
    if kind not in BAU_ITEM_KINDS:
        return jsonify({'ok': False, 'error': 'Unknown RAID log.'}), 404
    user, err = _json_gate()
    if err:
        return err
    db_session = get_db_session()
    try:
        if not service.can_add_bau(db_session, user):
            return jsonify({'ok': False, 'error':
                            'Only Application Support tower members can log '
                            'BAU RAID entries.'}), 403
        item = BauRaidItem(kind=kind)
        service.apply_bau_item_form(item, request.form, user, kind)
        db_session.add(item)
        db_session.commit()
        return jsonify({'ok': True, 'id': item.id})
    except service.RiskInputError as exc:
        db_session.rollback()
        return jsonify({'ok': False, 'error': str(exc)}), 400
    except Exception:
        db_session.rollback()
        logger.exception('Failed to add BAU %s', kind)
        return jsonify({'ok': False,
                        'error': 'The entry could not be saved.'}), 500
    finally:
        db_session.close()


@risk_register_bp.route('/bau/<kind>/<int:item_id>/edit', methods=['POST'])
def edit_bau_item(kind, item_id):
    if kind not in BAU_ITEM_KINDS:
        return jsonify({'ok': False, 'error': 'Unknown RAID log.'}), 404
    user, err = _json_gate()
    if err:
        return err
    db_session = get_db_session()
    try:
        item = _bau_item(db_session, kind, item_id)
        if item is None:
            return jsonify({'ok': False,
                            'error': 'That entry no longer exists.'}), 404
        if not service.can_change_bau(user, item):
            return jsonify({'ok': False, 'error':
                            'Only the person who logged this entry, or an '
                            'administrator, can change it.'}), 403
        service.apply_bau_item_form(item, request.form, user, kind)
        db_session.commit()
        return jsonify({'ok': True, 'id': item.id})
    except service.RiskInputError as exc:
        db_session.rollback()
        return jsonify({'ok': False, 'error': str(exc)}), 400
    except Exception:
        db_session.rollback()
        logger.exception('Failed to edit BAU %s %s', kind, item_id)
        return jsonify({'ok': False,
                        'error': 'The entry could not be saved.'}), 500
    finally:
        db_session.close()


@risk_register_bp.route('/bau/<kind>/<int:item_id>/delete', methods=['POST'])
def delete_bau_item(kind, item_id):
    if kind not in BAU_ITEM_KINDS:
        return jsonify({'ok': False, 'error': 'Unknown RAID log.'}), 404
    user, err = _json_gate()
    if err:
        return err
    db_session = get_db_session()
    try:
        item = _bau_item(db_session, kind, item_id)
        if item is None:
            return jsonify({'ok': True})
        if not service.can_change_bau(user, item):
            return jsonify({'ok': False, 'error':
                            'Only the person who logged this entry, or an '
                            'administrator, can delete it.'}), 403
        db_session.delete(item)
        db_session.commit()
        return jsonify({'ok': True})
    except Exception:
        db_session.rollback()
        logger.exception('Failed to delete BAU %s %s', kind, item_id)
        return jsonify({'ok': False,
                        'error': 'The entry could not be deleted.'}), 500
    finally:
        db_session.close()
