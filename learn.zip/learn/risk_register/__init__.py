"""
Delivery RAID Log (Delivery) - was the Risk Register.

One log for what holds delivery up - Risks, Assumptions, Issues and
Dependencies - with a Project RAID log and a BAU RAID log, each entry
attributed to an accountable party (Business, Third-Party Vendor, Delivery
Team, Support Team) so it is always clear where it sits.

    Project RAID   read live from the Project Management RAID logs.
    BAU RAID       logged here by Application Support tower members.

Served at /raid-log; the old /risk-register addresses redirect there.

Tables (models.py), rules and figures (service.py), the Excel workbook
(report_excel.py) and the blueprints (routes.py).
"""

from .routes import risk_register_bp, risk_register_legacy_bp

__all__ = ['risk_register_bp', 'risk_register_legacy_bp']
