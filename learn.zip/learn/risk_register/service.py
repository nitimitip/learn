"""
service.py - the rules and the numbers behind the Delivery RAID Log
(Risks, Assumptions, Issues, Dependencies; Project and BAU).

ACCESS (the one place it is decided)
    view      every signed-in user (log and Excel download).
    add BAU   administrators, and members of any Application Support tower
              (tower_members, owned by the Application Support module).
    update /  administrators, and the person who logged the entry.
    delete
    Project RAID entries are read-only here; they are maintained on the
    project's own RAID Log tab by the project team.

DATA
    An entry is in the window when its identified / raised date falls
    between the From and To dates (inclusive). Project risks logged before
    the identified date existed read their created date instead
    (ProjectRiskLog.identified_date); project assumptions / issues /
    dependencies with no raised date read their created date likewise.

ROWS
    Every row - whatever its kind - carries the same keys (name, summary,
    party, severity, status, is_open, owner, due_date, identified, resolved,
    age, overdue), so one summary, one chart set and one table macro serve
    all four logs. For assumptions / issues / dependencies `severity` holds
    the PRIORITY (the same Critical / High / Medium / Low words).
"""

from datetime import date

from sqlalchemy.orm import joinedload

from models import User
from modules.project_management.models import (
    RAID_KINDS, RISK_ACCOUNTABLE_PARTIES, RISK_IMPACT_LABELS,
    RISK_PROBABILITY_LABELS, ProjectAssumption, ProjectDependencyLog,
    ProjectIssue, ProjectRiskLog, normalise_accountable_party, risk_band,
)
from modules.application_support.models import TowerMember

from .models import (
    BAU_ITEM_KINDS, BAU_ITEM_PRIORITIES, BAU_ITEM_STATUSES,
    BAU_RISK_SEVERITIES, BAU_RISK_STATUSES, BauRaidItem, BauRiskLog,
)

KIND_KEYS = [k for k, _s, _p in RAID_KINDS]          # risk, assumption, ...
KIND_LABEL = {k: s for k, s, _p in RAID_KINDS}
KIND_PLURAL = {k: p for k, _s, p in RAID_KINDS}
PROJECT_ITEM_MODELS = {
    'assumption': ProjectAssumption,
    'issue': ProjectIssue,
    'dependency': ProjectDependencyLog,
}
# What the due date means for each kind (page, detail window, workbook).
DUE_LABEL = {
    'risk': 'Mitigation due',
    'assumption': 'Validate by',
    'issue': 'Resolve by',
    'dependency': 'Needed by',
}
RESOLVED_LABEL = {
    'risk': 'Resolved',
    'assumption': 'Validated / closed',
    'issue': 'Resolved',
    'dependency': 'Delivered / closed',
}
OUTCOME_LABEL = {
    'risk': 'Mitigation plan',
    'assumption': 'Validation outcome',
    'issue': 'Resolution / action taken',
    'dependency': 'Notes / outcome',
}

NOT_ASSIGNED = 'Not assigned'
PARTY_ORDER = RISK_ACCOUNTABLE_PARTIES + [NOT_ASSIGNED]
SOURCE_PROJECT = 'Project'
SOURCE_BAU = 'BAU'
DEFAULT_WINDOW_MONTHS = 12
MAX_TREND_MONTHS = 36


class RiskInputError(ValueError):
    """A posted BAU risk that cannot be saved - the message is user-facing."""


# ---------------------------------------------------------------------------
# Access
# ---------------------------------------------------------------------------

def is_admin(user):
    return user is not None and user.role == 'admin'


def is_tower_member(db_session, user):
    """A member of ANY Application Support tower (tower_members)."""
    if user is None:
        return False
    return db_session.query(TowerMember.id).filter(
        TowerMember.user_id == user.id).first() is not None


def can_add_bau(db_session, user):
    if user is None:
        return False
    return is_admin(user) or is_tower_member(db_session, user)


def can_change_bau(user, risk):
    """Update / delete: the person who logged it, or an administrator."""
    if user is None:
        return False
    return is_admin(user) or (risk.created_by is not None
                              and risk.created_by == user.id)



# ---------------------------------------------------------------------------
# Window
# ---------------------------------------------------------------------------

def _parse_date(raw):
    try:
        return date.fromisoformat((raw or '').strip())
    except ValueError:
        return None


def _months_back(d, months):
    """First day of the month `months` back (negative = forward)."""
    y, m = divmod(d.year * 12 + (d.month - 1) - months, 12)
    return date(y, m + 1, 1)


def default_window(today=None):
    """The first day of the month eleven months back, to today: twelve whole
    months on the trend chart."""
    today = today or date.today()
    return _months_back(today, DEFAULT_WINDOW_MONTHS - 1), today


def resolve_window(raw_from, raw_to, today=None):
    """(start, end, message). Bad or reversed input falls back to the default
    window and returns a message saying so."""
    d_start, d_end = default_window(today)
    start = _parse_date(raw_from) if raw_from else None
    end = _parse_date(raw_to) if raw_to else None
    msg = None
    if (raw_from and not start) or (raw_to and not end):
        msg = 'A date could not be read, so the default range is shown.'
        return d_start, d_end, msg
    start = start or d_start
    end = end or d_end
    if start > end:
        return d_start, d_end, ('The From date was after the To date, so the '
                                'default range is shown.')
    return start, end, msg


# ---------------------------------------------------------------------------
# Rows
# ---------------------------------------------------------------------------

def display_name(u):
    if u is None:
        return ''
    name = ' '.join(p for p in (u.firstname, u.lastname) if p).strip()
    return name.title() if name else u.username


def _enum_value(v):
    return getattr(v, 'value', v)


def _row(source, risk, **extra):
    status = _enum_value(risk.status) or 'Open'
    row = {
        'source': source,
        'kind': 'risk',
        'depends_on': '',
        'resolution': '',
        'id': risk.id,
        'name': risk.name,
        'summary': risk.summary,
        'party': risk.accountable_party or NOT_ASSIGNED,
        'party_set': bool(risk.accountable_party),
        'severity': _enum_value(risk.severity) or 'Low',
        'score': risk.score,
        'probability': risk.probability,
        'impact': risk.impact,
        'status': status,
        'is_open': risk.is_open,
        'owner': risk.owner or '',
        'mitigation': risk.mitigation or '',
        'due_date': risk.due_date,
        'identified': risk.identified_date,
        'resolved': risk.resolved_on if not risk.is_open else None,
        'age': risk.age_days(),
        'overdue': bool(risk.is_open and risk.due_date
                        and risk.due_date < date.today()),
    }
    row.update(extra)
    return row


_SEVERITY_RANK = {'Critical': 0, 'High': 1, 'Medium': 2, 'Low': 3}


def _sort_key(row):
    # Open first, then most severe, then newest.
    ident = row['identified'] or date.min
    return (0 if row['is_open'] else 1,
            _SEVERITY_RANK.get(row['severity'], 9),
            -ident.toordinal())


def _in_window(d, start, end):
    return d is not None and start <= d <= end


def _pm_names(db_session, entries):
    pm_ids = {e.project.created_by for e in entries if e.project}
    if not pm_ids:
        return {}
    return {u.id: display_name(u) for u in
            db_session.query(User).filter(User.id.in_(pm_ids)).all()}


def _project_extra(entry, owners):
    p = entry.project
    return dict(
        project_id=p.id if p else None,
        project_name=p.name if p else 'Project #%s' % entry.project_id,
        project_code=(p.project_code or '') if p else '',
        project_status=_enum_value(p.status) if p else '',
        project_manager=owners.get(p.created_by, '') if p else '',
    )


def project_rows(db_session, start, end):
    risks = (db_session.query(ProjectRiskLog)
             .options(joinedload(ProjectRiskLog.project))
             .all())
    owners = _pm_names(db_session, risks)
    rows = []
    for r in risks:
        if not _in_window(r.identified_date, start, end):
            continue
        rows.append(_row(SOURCE_PROJECT, r, **_project_extra(r, owners)))
    rows.sort(key=_sort_key)
    return rows


def _raised_date(entry):
    """raised_on, falling back to the day the row was logged."""
    if entry.raised_on:
        return entry.raised_on
    created = getattr(entry, 'created_at', None)
    return created.date() if created else None


def _item_row(source, kind, e, **extra):
    """One assumption / issue / dependency in the shared row shape."""
    is_open = e.is_open
    raised = _raised_date(e)
    if is_open:
        age = (date.today() - raised).days if raised else None
    elif e.resolved_on and raised:
        age = (e.resolved_on - raised).days
    else:
        age = None
    row = {
        'source': source,
        'kind': kind,
        'id': e.id,
        'name': e.title,
        'summary': e.description or '',
        'party': e.accountable_party or NOT_ASSIGNED,
        'party_set': bool(e.accountable_party),
        'severity': e.priority or 'Medium',
        'score': None, 'probability': None, 'impact': None,
        'status': e.status or 'Open',
        'is_open': is_open,
        'owner': e.owner or '',
        'mitigation': '',
        'resolution': e.resolution or '',
        'depends_on': (getattr(e, 'depends_on', None) or ''),
        'due_date': e.due_date,
        'identified': raised,
        'resolved': e.resolved_on if not is_open else None,
        'age': max(0, age) if age is not None else None,
        'overdue': bool(is_open and e.due_date and e.due_date < date.today()),
    }
    row.update(extra)
    return row


def project_item_rows(db_session, kind, start, end):
    model = PROJECT_ITEM_MODELS[kind]
    entries = (db_session.query(model)
               .options(joinedload(model.project))
               .all())
    owners = _pm_names(db_session, entries)
    rows = [_item_row(SOURCE_PROJECT, kind, e, **_project_extra(e, owners))
            for e in entries if _in_window(_raised_date(e), start, end)]
    rows.sort(key=_sort_key)
    return rows


def bau_rows(db_session, start, end, user=None):
    risks = (db_session.query(BauRiskLog)
             .filter(BauRiskLog.identified_on >= start,
                     BauRiskLog.identified_on <= end)
             .all())
    ids = {r.created_by for r in risks if r.created_by}
    names = {}
    if ids:
        names = {u.id: display_name(u) for u in
                 db_session.query(User).filter(User.id.in_(ids)).all()}
    rows = []
    for r in risks:
        allowed = can_change_bau(user, r)
        rows.append(_row(
            SOURCE_BAU, r,
            service=r.service or '',
            reference=r.reference or '',
            logged_by=names.get(r.created_by, ''),
            can_edit=allowed,
            can_delete=allowed,
        ))
    rows.sort(key=_sort_key)
    return rows


def _logged_by_names(db_session, entries):
    ids = {e.created_by for e in entries if e.created_by}
    if not ids:
        return {}
    return {u.id: display_name(u) for u in
            db_session.query(User).filter(User.id.in_(ids)).all()}


def bau_item_rows(db_session, kind, start, end, user=None):
    entries = (db_session.query(BauRaidItem)
               .filter(BauRaidItem.kind == kind,
                       BauRaidItem.raised_on >= start,
                       BauRaidItem.raised_on <= end)
               .all())
    names = _logged_by_names(db_session, entries)
    rows = []
    for e in entries:
        allowed = can_change_bau(user, e)
        rows.append(_item_row(
            SOURCE_BAU, kind, e,
            service=e.service or '',
            reference=e.reference or '',
            logged_by=names.get(e.created_by, ''),
            can_edit=allowed,
            can_delete=allowed,
        ))
    rows.sort(key=_sort_key)
    return rows


# ---------------------------------------------------------------------------
# Figures and charts
# ---------------------------------------------------------------------------

def _avg(values):
    values = [v for v in values if v is not None]
    return round(sum(values) / float(len(values)), 1) if values else None


def summarise(p_rows, b_rows, start, end):
    every = p_rows + b_rows
    resolved_ages = [r['age'] for r in every if not r['is_open']]

    # Risks per accountable party, Project vs BAU.
    by_party = []
    for party in PARTY_ORDER:
        p = [r for r in p_rows if r['party'] == party]
        b = [r for r in b_rows if r['party'] == party]
        both = p + b
        by_party.append({
            'party': party,
            'project': len(p),
            'bau': len(b),
            'total': len(both),
            'open': sum(1 for r in both if r['is_open']),
            'high': sum(1 for r in both
                        if r['severity'] in ('High', 'Critical')),
            'avg_open': _avg([r['age'] for r in both if r['is_open']]),
            'avg_resolve': _avg([r['age'] for r in both if not r['is_open']]),
            # Days open so far (open) or days taken to resolve (closed).
            'avg_age': _avg([r['age'] for r in both]),
        })
    # 'Not assigned' only earns a row when something is in it.
    by_party = [x for x in by_party
                if x['party'] != NOT_ASSIGNED or x['total']]
    party_max = max([max(x['project'], x['bau']) for x in by_party] + [0])
    days_max = max([x['avg_age'] or 0 for x in by_party] + [0])

    # Identified per month, Project vs BAU.
    months = []
    cursor = date(start.year, start.month, 1)
    last = date(end.year, end.month, 1)
    while cursor <= last:
        months.append(cursor)
        cursor = _months_back(cursor, -1)
    if len(months) > MAX_TREND_MONTHS:
        months = months[-MAX_TREND_MONTHS:]
    first_month = months[0] if months else start
    trend = []
    for m in months:
        def _in(r, m=m):
            d = r['identified']
            return d is not None and d.year == m.year and d.month == m.month
        trend.append({
            'label': m.strftime('%b %y'),
            'long': m.strftime('%B %Y'),
            'project': sum(1 for r in p_rows if _in(r)),
            'bau': sum(1 for r in b_rows if _in(r)),
        })
    trend_max = max([t['project'] + t['bau'] for t in trend] + [0])

    # Severity mix of what is still open.
    severity = []
    for sev in ('Critical', 'High', 'Medium', 'Low'):
        severity.append({
            'severity': sev,
            'project': sum(1 for r in p_rows
                           if r['is_open'] and r['severity'] == sev),
            'bau': sum(1 for r in b_rows
                       if r['is_open'] and r['severity'] == sev),
        })

    severity_max = max([s['project'] + s['bau'] for s in severity] + [0])

    return {
        'severity_max': severity_max,
        'total': len(every),
        'project': len(p_rows),
        'bau': len(b_rows),
        'open': sum(1 for r in every if r['is_open']),
        'overdue': sum(1 for r in every if r['overdue']),
        'unassigned': sum(1 for r in every if not r['party_set']),
        'avg_resolve': _avg(resolved_ages),
        'by_party': by_party,
        'party_max': party_max,
        'days_max': days_max,
        'trend': trend,
        'trend_max': trend_max,
        'trend_clipped': first_month > date(start.year, start.month, 1),
        'severity': severity,
    }


# ---------------------------------------------------------------------------
# BAU risk save
# ---------------------------------------------------------------------------

def _scale(raw):
    try:
        v = int(raw)
    except (TypeError, ValueError):
        return None
    return v if 1 <= v <= 5 else None


def _text(form, key, limit=None):
    value = (form.get(key) or '').strip()
    if limit:
        value = value[:limit]
    return value or None


def apply_bau_form(risk, form, user, today=None):
    """Validate the posted fields onto `risk`. Raises RiskInputError."""
    today = today or date.today()
    was_open = risk.id is None or risk.is_open

    name = _text(form, 'name', 200)
    summary = _text(form, 'summary')
    if not name or not summary:
        raise RiskInputError('Risk name and summary are required.')
    party = normalise_accountable_party(form.get('accountable_party'))
    if not party:
        raise RiskInputError('Choose the accountable party.')
    status = (form.get('status') or 'Open').strip()
    if status not in BAU_RISK_STATUSES:
        raise RiskInputError('Unknown status.')
    severity = (form.get('severity') or 'Low').strip()
    if severity not in BAU_RISK_SEVERITIES:
        raise RiskInputError('Unknown severity.')

    identified = _parse_date(form.get('identified_on')) or \
        risk.identified_on or today
    if identified > today:
        raise RiskInputError('The identified date cannot be in the future.')
    if form.get('due_date') and not _parse_date(form.get('due_date')):
        raise RiskInputError('The mitigation due date could not be read.')

    risk.name = name
    risk.summary = summary
    risk.service = _text(form, 'service', 200)
    risk.reference = _text(form, 'reference', 100)
    risk.accountable_party = party
    risk.status = status
    risk.probability = _scale(form.get('probability'))
    risk.impact = _scale(form.get('impact'))
    # Scored risks take their severity from the score band, exactly as the
    # project risk log does, so the two logs can never disagree.
    risk.severity = (risk_band(risk.probability * risk.impact)
                     if risk.probability and risk.impact else severity)
    risk.owner = _text(form, 'owner', 200)
    risk.mitigation = _text(form, 'mitigation')
    risk.due_date = _parse_date(form.get('due_date'))
    risk.identified_on = identified

    if status == 'Open':
        risk.resolved_on = None
    else:
        resolved = _parse_date(form.get('resolved_on')) or risk.resolved_on
        if not resolved and was_open:
            resolved = today
        if resolved and resolved < identified:
            raise RiskInputError(
                'The resolved date cannot be before the date it was '
                'identified (%s).' % identified.strftime('%d %b %Y'))
        if resolved and resolved > today:
            raise RiskInputError('The resolved date cannot be in the future.')
        risk.resolved_on = resolved

    if risk.id is None:
        risk.created_by = user.id
    risk.updated_by = user.id
    return risk


def form_vocab():
    return {
        'parties': RISK_ACCOUNTABLE_PARTIES,
        'statuses': BAU_RISK_STATUSES,
        'severities': BAU_RISK_SEVERITIES,
        'prob_labels': RISK_PROBABILITY_LABELS,
        'impact_labels': RISK_IMPACT_LABELS,
    }


def window_rows(db_session, start, end, user=None):
    """Risks only, for one window: (project rows, BAU rows, summary)."""
    p = project_rows(db_session, start, end)
    b = bau_rows(db_session, start, end, user)
    return p, b, summarise(p, b, start, end)


# ---------------------------------------------------------------------------
# The whole RAID log
# ---------------------------------------------------------------------------

def raid_window(db_session, start, end, user=None):
    """Everything the page and the workbook need for one window.

    Returns (logs, summary):
        logs     {'project': {kind: rows}, 'bau': {kind: rows}} for every
                 kind in KIND_KEYS (risk, assumption, issue, dependency)
        summary  summarise() over every entry of every kind, plus
                 `by_kind` - one row per kind with Project / BAU / open /
                 overdue counts.
    """
    logs = {'project': {}, 'bau': {}}
    logs['project']['risk'] = project_rows(db_session, start, end)
    logs['bau']['risk'] = bau_rows(db_session, start, end, user)
    for kind in BAU_ITEM_KINDS:
        logs['project'][kind] = project_item_rows(db_session, kind, start, end)
        logs['bau'][kind] = bau_item_rows(db_session, kind, start, end, user)
    p_all = [r for k in KIND_KEYS for r in logs['project'][k]]
    b_all = [r for k in KIND_KEYS for r in logs['bau'][k]]
    summary = summarise(p_all, b_all, start, end)
    by_kind = []
    for kind in KIND_KEYS:
        p, b = logs['project'][kind], logs['bau'][kind]
        both = p + b
        by_kind.append({
            'kind': kind, 'label': KIND_PLURAL[kind],
            'project': len(p), 'bau': len(b),
            'project_open': sum(1 for r in p if r['is_open']),
            'bau_open': sum(1 for r in b if r['is_open']),
            'open': sum(1 for r in both if r['is_open']),
            'overdue': sum(1 for r in both if r['overdue']),
            'total': len(both),
        })
    summary['by_kind'] = by_kind
    summary['kind_max'] = max([max(k['project_open'], k['bau_open'])
                               for k in by_kind] + [0])
    summary['project_open'] = sum(1 for r in p_all if r['is_open'])
    summary['bau_open'] = sum(1 for r in b_all if r['is_open'])
    return logs, summary


# ---------------------------------------------------------------------------
# Dashboard feed
# ---------------------------------------------------------------------------

def rag_of(severity):
    """RAG for one entry: Critical / High red, Medium amber, Low green.
    Risks use their severity (score band when scored); assumptions, issues
    and dependencies their priority - the same four words."""
    if severity in ('Critical', 'High'):
        return 'Red'
    if severity == 'Medium':
        return 'Amber'
    return 'Green'


def dashboard_entries(logs):
    """Every entry in the window as a flat, JSON-safe list for the dashboard
    script (filtering, KPIs, heatmap, charts all run in the browser).
    `key` matches the table row's data-key so a click can open its detail."""
    out = []
    for scope in ('project', 'bau'):
        for kind in KIND_KEYS:
            for r in logs[scope][kind]:
                out.append({
                    'key': '%s-%s-%s' % (scope, kind, r['id']),
                    'scope': scope,
                    'kind': kind,
                    'title': r['name'],
                    'context': (r.get('service') if scope == 'bau'
                                else r.get('project_name')) or '',
                    'sev': r['severity'],
                    'rag': rag_of(r['severity']),
                    'p': r['probability'] or None,
                    'i': r['impact'] or None,
                    'status': r['status'],
                    'open': bool(r['is_open']),
                    'overdue': bool(r['overdue']),
                    'party': r['party'],
                    'owner': r['owner'] or '',
                    'identified': r['identified'].isoformat() if r['identified'] else None,
                    'resolved': r['resolved'].isoformat() if r['resolved'] else None,
                    'age': r['age'],
                })
    return out


# ---------------------------------------------------------------------------
# BAU assumption / issue / dependency save
# ---------------------------------------------------------------------------

def apply_bau_item_form(item, form, user, kind, today=None):
    """Validate the posted fields onto a BauRaidItem. Raises RiskInputError."""
    if kind not in BAU_ITEM_KINDS:
        raise RiskInputError('Unknown RAID log.')
    today = today or date.today()
    label = KIND_LABEL[kind]
    was_open = item.id is None or item.is_open
    item.kind = kind

    title = _text(form, 'title', 200)
    if not title:
        raise RiskInputError('%s title is required.' % label)
    party = normalise_accountable_party(form.get('accountable_party'))
    if not party:
        raise RiskInputError('Choose the accountable party.')
    status = (form.get('status') or 'Open').strip()
    if status not in BAU_ITEM_STATUSES[kind]:
        raise RiskInputError('Unknown status.')
    priority = (form.get('priority') or 'Medium').strip()
    if priority not in BAU_ITEM_PRIORITIES:
        raise RiskInputError('Unknown priority.')

    raised = _parse_date(form.get('raised_on')) or item.raised_on or today
    if raised > today:
        raise RiskInputError('The logged date cannot be in the future.')
    if form.get('due_date') and not _parse_date(form.get('due_date')):
        raise RiskInputError('The due date could not be read.')

    item.title = title
    item.description = _text(form, 'description')
    item.service = _text(form, 'service', 200)
    item.reference = _text(form, 'reference', 100)
    item.depends_on = _text(form, 'depends_on', 200) if kind == 'dependency' else None
    item.accountable_party = party
    item.priority = priority
    item.owner = _text(form, 'owner', 200)
    item.due_date = _parse_date(form.get('due_date'))
    item.resolution = _text(form, 'resolution')
    item.raised_on = raised
    item.status = status

    if item.is_open:
        item.resolved_on = None
    else:
        resolved = _parse_date(form.get('resolved_on')) or item.resolved_on
        if not resolved and was_open:
            resolved = today
        if resolved and resolved < raised:
            raise RiskInputError(
                'The closed date cannot be before the date it was logged '
                '(%s).' % raised.strftime('%d %b %Y'))
        if resolved and resolved > today:
            raise RiskInputError('The closed date cannot be in the future.')
        item.resolved_on = resolved

    if item.id is None:
        item.created_by = user.id
    item.updated_by = user.id
    return item


def raid_vocab():
    """form_vocab() plus the per-kind status lists and wording."""
    vocab = form_vocab()
    vocab.update({
        'priorities': BAU_ITEM_PRIORITIES,
        'item_statuses': BAU_ITEM_STATUSES,
        'kinds': [{'key': k, 'label': KIND_LABEL[k], 'plural': KIND_PLURAL[k],
                   'due': DUE_LABEL[k], 'resolved': RESOLVED_LABEL[k],
                   'outcome': OUTCOME_LABEL[k]} for k in KIND_KEYS],
    })
    return vocab
