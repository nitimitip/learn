"""
report_excel.py - the Delivery RAID Log as an Excel workbook.

Pure: the rows the page shows in, bytes out. Exactly the filtered window the
person was looking at. Same visual language as the other appassist workbooks
(survey/report_excel.py, application_support/export_docs.py): NPG red title
band, dark-red subtitle and column-header rows, banded body rows, Calibri,
thin slate borders, frozen headers and filters.

SHEETS
    Summary              the window, prepared-by, headline figures, one row
                         per RAID log (Project / BAU, open, overdue) and one
                         row per accountable party.
    Project Risks        \
    Project Assumptions   |  every Project entry of that kind identified /
    Project Issues        |  raised in the window
    Project Dependencies /
    BAU Risks            \
    BAU Assumptions       |  the same for BAU
    BAU Issues            |
    BAU Dependencies     /

Free text came from users, so every string is formula-guarded (_safe).
"""

import io

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

BRAND = 'AB1236'
BRAND_DK = '7E0D27'
BAND = 'F1F5F9'
BORDER = 'D7DEE7'
TEXT = '1D293D'
MUTED = '6B7280'

SEVERITY_META = {
    'Critical': ('FEE2E2', '991B1B'),
    'High': ('FFEDD5', '9A3412'),
    'Medium': ('DBEAFE', '1E40AF'),
    'Low': ('F1F5F9', '475569'),
}
STATUS_META = {
    'Open': ('FEF3C7', '92400E'),
    'Mitigated': ('DBEAFE', '1E40AF'),
    'Closed': ('DCFCE7', '166534'),
    'In Progress': ('DBEAFE', '1E40AF'),
    'Resolved': ('DCFCE7', '166534'),
    'Validated': ('DCFCE7', '166534'),
    'Invalid': ('FFEDD5', '9A3412'),
    'At Risk': ('FEE2E2', '991B1B'),
    'Delivered': ('DCFCE7', '166534'),
}

_thin = Side(style='thin', color=BORDER)
_BORDER = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)
CENTER = Alignment(horizontal='center', vertical='center', wrap_text=True)
LEFT_TOP = Alignment(horizontal='left', vertical='top', wrap_text=True)
_FORMULA_LEADS = ('=', '+', '-', '@', '\t', '\r')


def _safe(value):
    if value is None:
        return ''
    if not isinstance(value, str):
        return value
    value = value[:32000]
    if value.startswith(_FORMULA_LEADS):
        return "'" + value
    return value


def _d(value):
    return value.strftime('%d %b %Y') if value else ''


def _widths(ws, widths):
    for idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width


def _title_band(ws, title, subtitle, ncols):
    ncols = max(ncols, 2)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    c = ws.cell(row=1, column=1, value=_safe(title))
    c.font = Font(name='Calibri', size=15, bold=True, color='FFFFFF')
    c.fill = PatternFill('solid', fgColor=BRAND)
    c.alignment = Alignment(horizontal='left', vertical='center', indent=1)
    ws.row_dimensions[1].height = 30
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
    s = ws.cell(row=2, column=1, value=_safe(subtitle))
    s.font = Font(name='Calibri', size=10, italic=True, color='FFFFFF')
    s.fill = PatternFill('solid', fgColor=BRAND_DK)
    s.alignment = Alignment(horizontal='left', vertical='center', indent=1)
    ws.row_dimensions[2].height = 20
    return 4


def _section(ws, row, label, ncols):
    ws.merge_cells(start_row=row, start_column=1, end_row=row,
                   end_column=max(ncols, 2))
    h = ws.cell(row=row, column=1, value=_safe(label))
    h.font = Font(name='Calibri', size=11, bold=True, color='FFFFFF')
    h.fill = PatternFill('solid', fgColor=BRAND)
    h.alignment = Alignment(horizontal='left', vertical='center', indent=1)
    ws.row_dimensions[row].height = 22
    return row + 1


def _header(ws, row, headers):
    for col, label in enumerate(headers, start=1):
        cell = ws.cell(row=row, column=col, value=_safe(label))
        cell.font = Font(name='Calibri', size=10, bold=True, color='FFFFFF')
        cell.fill = PatternFill('solid', fgColor=BRAND_DK)
        cell.alignment = CENTER
        cell.border = _BORDER
    ws.row_dimensions[row].height = 30


def _cell(ws, row, col, value, banded=False, center=False):
    cell = ws.cell(row=row, column=col, value=_safe(value))
    cell.font = Font(name='Calibri', size=10, color=TEXT)
    cell.alignment = CENTER if center else LEFT_TOP
    cell.border = _BORDER
    if banded:
        cell.fill = PatternFill('solid', fgColor=BAND)
    return cell


def _chip(cell, meta):
    if not meta:
        return
    fill, font = meta
    cell.fill = PatternFill('solid', fgColor=fill)
    cell.font = Font(name='Calibri', size=10, bold=True, color=font)
    cell.alignment = CENTER


def _field(ws, row, label, value, ncols):
    lc = ws.cell(row=row, column=1, value=label)
    lc.font = Font(name='Calibri', size=10, bold=True, color='FFFFFF')
    lc.fill = PatternFill('solid', fgColor=BRAND_DK)
    lc.alignment = LEFT_TOP
    lc.border = _BORDER
    ws.merge_cells(start_row=row, start_column=2, end_row=row,
                   end_column=max(ncols, 2))
    vc = ws.cell(row=row, column=2, value=_safe(value))
    vc.font = Font(name='Calibri', size=10, color=TEXT)
    vc.alignment = LEFT_TOP
    vc.border = _BORDER
    return row + 1


def _print_setup(ws, header_row):
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_title_rows = '%d:%d' % (header_row, header_row)
    ws.oddFooter.center.text = 'Page &P of &N'


def _summary_sheet(ws, meta, summary):
    ncols = 9
    row = _title_band(ws, 'Delivery RAID Log',
                      'Risks, Assumptions, Issues and Dependencies identified '
                      '%s to %s' % (_d(meta['start']), _d(meta['end'])), ncols)
    row = _field(ws, row, 'Prepared by', meta.get('prepared_by', ''), ncols)
    row = _field(ws, row, 'Generated', meta['generated'].strftime(
        '%d %b %Y %H:%M'), ncols)
    row += 1
    row = _section(ws, row, 'Headline figures', ncols)
    figures = [
        ('RAID entries in range', summary['total']),
        ('Project RAID entries', summary['project']),
        ('BAU RAID entries', summary['bau']),
        ('Open', summary['open']),
        ('Open past due date', summary['overdue']),
        ('Average days to close',
         summary['avg_resolve'] if summary['avg_resolve'] is not None
         else '-'),
        ('No accountable party recorded', summary['unassigned']),
    ]
    for label, value in figures:
        row = _field(ws, row, label, value, ncols)
    row += 1
    if summary.get('by_kind'):
        row = _section(ws, row, 'By RAID log', ncols)
        _header(ws, row, ['RAID log', 'Project', 'Project open', 'BAU',
                          'BAU open', 'Total', 'Open', 'Open past due'])
        row += 1
        for i, k in enumerate(summary['by_kind']):
            banded = i % 2 == 1
            _cell(ws, row, 1, k['label'], banded)
            for col, key in ((2, 'project'), (3, 'project_open'), (4, 'bau'),
                             (5, 'bau_open'), (6, 'total'), (7, 'open'),
                             (8, 'overdue')):
                _cell(ws, row, col, k[key], banded, center=True)
            row += 1
        row += 1
    row = _section(ws, row, 'By accountable party', ncols)
    headers = ['Accountable party', 'Project', 'BAU', 'Total', 'Open',
               'High / Critical', 'Avg days open', 'Avg days to resolve', '']
    _header(ws, row, headers[:8])
    head_row = row
    row += 1
    for i, p in enumerate(summary['by_party']):
        banded = i % 2 == 1
        _cell(ws, row, 1, p['party'], banded)
        for col, key in ((2, 'project'), (3, 'bau'), (4, 'total'),
                         (5, 'open'), (6, 'high')):
            _cell(ws, row, col, p[key], banded, center=True)
        _cell(ws, row, 7, p['avg_open'] if p['avg_open'] is not None
              else '-', banded, center=True)
        _cell(ws, row, 8, p['avg_resolve'] if p['avg_resolve'] is not None
              else '-', banded, center=True)
        row += 1
    _widths(ws, [32, 12, 12, 12, 12, 15, 15, 18, 4])
    _print_setup(ws, head_row)


PROJECT_HEADERS = [
    'Project', 'Code', 'Project Manager', 'Risk', 'Summary',
    'Accountable Party', 'Severity', 'Score', 'Status', 'Owner',
    'Mitigation Plan', 'Mitigation Due', 'Identified', 'Resolved',
    'Days Open / To Resolve',
]
PROJECT_WIDTHS = [26, 12, 20, 28, 40, 20, 11, 8, 11, 18, 36, 13, 13, 13, 13]

BAU_HEADERS = [
    'Application / Service', 'Reference', 'Risk', 'Summary',
    'Accountable Party', 'Severity', 'Score', 'Status', 'Owner',
    'Mitigation Plan', 'Mitigation Due', 'Identified', 'Resolved',
    'Days Open / To Resolve', 'Logged By',
]
BAU_WIDTHS = [24, 14, 28, 40, 20, 11, 8, 11, 18, 36, 13, 13, 13, 13, 18]


def _risk_sheet(ws, title, meta, headers, widths, rows, values_for,
                noun='risk', noun_plural='risks'):
    ncols = len(headers)
    row = _title_band(ws, title, 'Identified %s to %s  -  %d %s' % (
        _d(meta['start']), _d(meta['end']), len(rows),
        noun if len(rows) == 1 else noun_plural), ncols)
    _header(ws, row, headers)
    head_row = row
    row += 1
    if not rows:
        ws.merge_cells(start_row=row, start_column=1, end_row=row,
                       end_column=ncols)
        c = ws.cell(row=row, column=1,
                    value='No %s identified in this range.' % noun_plural)
        c.font = Font(name='Calibri', size=10, italic=True, color=MUTED)
    sev_col = (headers.index('Severity') if 'Severity' in headers
               else headers.index('Priority')) + 1
    status_col = headers.index('Status') + 1
    for i, r in enumerate(rows):
        banded = i % 2 == 1
        for col, value in enumerate(values_for(r), start=1):
            center = col in (sev_col, status_col) or isinstance(value, int)
            cell = _cell(ws, row, col, value, banded, center=center)
            if col == sev_col:
                _chip(cell, SEVERITY_META.get(r['severity']))
            elif col == status_col:
                _chip(cell, STATUS_META.get(r['status']))
        row += 1
    _widths(ws, widths)
    ws.freeze_panes = ws.cell(row=head_row + 1, column=1)
    if rows:
        ws.auto_filter.ref = '%s%d:%s%d' % ('A', head_row,
                                            get_column_letter(ncols), row - 1)
    _print_setup(ws, head_row)


def _common(r):
    return [r['name'], r['summary'], r['party'], r['severity'],
            r['score'] if r['score'] is not None else '', r['status'],
            r['owner'], r['mitigation'], _d(r['due_date']),
            _d(r['identified']), _d(r['resolved']),
            r['age'] if r['age'] is not None else '']


ITEM_KINDS = (
    # kind, singular, plural, sheet suffix, due header, closed header,
    # outcome header
    ('assumption', 'assumption', 'assumptions', 'Assumptions',
     'Validate By', 'Validated / Closed', 'Validation Outcome'),
    ('issue', 'issue', 'issues', 'Issues',
     'Resolve By', 'Resolved', 'Resolution'),
    ('dependency', 'dependency', 'dependencies', 'Dependencies',
     'Needed By', 'Delivered / Closed', 'Notes / Outcome'),
)


_NOUN = {'assumption': 'Assumption', 'issue': 'Issue',
         'dependency': 'Dependency'}


def _item_widths(kind):
    return ([28, 40] + ([22] if kind == 'dependency' else [])
            + [20, 11, 12, 18, 13, 13, 13, 13, 36])


def _item_headers(kind, due, closed, outcome, noun):
    return ([noun, 'Description']
            + (['Depends On'] if kind == 'dependency' else [])
            + ['Accountable Party', 'Priority', 'Status', 'Owner', due,
               'Logged', closed, 'Days Open / To Close', outcome])


def _item_values(kind, r):
    return ([r['name'], r['summary']]
            + ([r['depends_on']] if kind == 'dependency' else [])
            + [r['party'], r['severity'], r['status'], r['owner'],
               _d(r['due_date']), _d(r['identified']), _d(r['resolved']),
               r['age'] if r['age'] is not None else '', r['resolution']])


def build_workbook(meta, summary, logs):
    """meta = {start, end, generated, prepared_by}; logs = the `logs` dict
    from service.raid_window(). Returns xlsx bytes."""
    wb = Workbook()
    ws = wb.active
    ws.title = 'Summary'
    _summary_sheet(ws, meta, summary)
    _risk_sheet(
        wb.create_sheet('Project Risks'), 'Project Risks', meta,
        PROJECT_HEADERS, PROJECT_WIDTHS, logs['project']['risk'],
        lambda r: [r['project_name'], r['project_code'],
                   r['project_manager']] + _common(r))
    for kind, one, many, suffix, due, closed, outcome in ITEM_KINDS:
        heads = _item_headers(kind, due, closed, outcome, _NOUN[kind])
        widths = _item_widths(kind)
        _risk_sheet(
            wb.create_sheet('Project ' + suffix), 'Project ' + suffix, meta,
            ['Project', 'Code', 'Project Manager'] + heads,
            [26, 12, 20] + widths, logs['project'][kind],
            lambda r, kind=kind: [r['project_name'], r['project_code'],
                                  r['project_manager']] + _item_values(kind, r),
            noun=one, noun_plural=many)
    _risk_sheet(
        wb.create_sheet('BAU Risks'), 'BAU Risks', meta,
        BAU_HEADERS, BAU_WIDTHS, logs['bau']['risk'],
        lambda r: [r['service'], r['reference']] + _common(r)
        + [r['logged_by']])
    for kind, one, many, suffix, due, closed, outcome in ITEM_KINDS:
        heads = _item_headers(kind, due, closed, outcome, _NOUN[kind])
        widths = _item_widths(kind)
        _risk_sheet(
            wb.create_sheet('BAU ' + suffix), 'BAU ' + suffix, meta,
            ['Application / Service', 'Reference'] + heads + ['Logged By'],
            [24, 14] + widths + [18], logs['bau'][kind],
            lambda r, kind=kind: [r['service'], r['reference']]
            + _item_values(kind, r) + [r['logged_by']],
            noun=one, noun_plural=many)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
