USE [QPID_PROD]
GO
/******************************************************************************
  V4-05 - OPTIMIZED PROCEDURE - NOT EXECUTED - TEST ON UAT BEFORE DEPLOYMENT
  Procedure : [dbo].[usp_GetActivityBasedOnTypeAndName]
  Original  : QPID_SP/usp_GetActivityBasedOnTypeAndName.sql
  Generated : optimization_v4/tools/gen_v4_05.py
  Change    : UPPER() removed from the AE_internalRef column side (6 statements);
              OPTION (RECOMPILE) on the STK, CTK and PROGRESSH statements.
  Guards    : refuses a case-sensitive collation, or an unexpected live version.
******************************************************************************/
SET NOEXEC OFF;
GO
IF EXISTS (SELECT 1 FROM sys.columns c
           WHERE c.object_id IN (OBJECT_ID('dbo.BT_PROJ_U_HEADER'), OBJECT_ID('dbo.BT_STK_HEADER'),
                                 OBJECT_ID('dbo.BT_CTK_HEADER'), OBJECT_ID('dbo.BT_PROJ_HEADER'))
             AND c.name = 'AE_internalRef'
             AND (c.collation_name IS NULL OR c.collation_name NOT LIKE '%[_]CI[_]%'))
BEGIN
    RAISERROR('REFUSED: a ref column is not case-insensitive, so removing UPPER() is not equivalent. Nothing changed.', 16, 1);
    SET NOEXEC ON;
END
GO
DECLARE @def nvarchar(max) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.usp_GetActivityBasedOnTypeAndName'));
IF @def IS NULL OR (LEN(@def) <> 9827 AND @def NOT LIKE N'%QPID_OPT V4-05%')
BEGIN
    RAISERROR('REFUSED: production usp_GetActivityBasedOnTypeAndName differs from the expected original. Nothing changed.', 16, 1);
    SET NOEXEC ON;
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		TCS: Sumanta Dhara
-- Create date: 22-Nov-2019
-- Description:	It returns the Activity like Project, STK and CTK based on Activity Type.
-- Modifyed by TCS:Sandeep Singh
-- Modifyed date: 03-Apr-2020


-- =============================================
/*

[usp_GetActivityBasedOnTypeAndName] 'Project','U1039775',null,null,null,null,1,10
GO
[usp_GetActivityBasedOnTypeAndName] 'Project','U7078876',null,null,null,null,1,10
GO
[usp_GetActivityBasedOnTypeAndName] 'CTK','CTK5462817',null,null,null,null,1,10

[usp_GetActivityBasedOnTypeAndName] 'CTK',null,null,21252910,null,null,1,10

[usp_GetActivityBasedOnTypeAndName] 'STK','STK21005520',null,21005520,null,'STK21005520',1,10


*/
ALTER PROCEDURE [dbo].[usp_GetActivityBasedOnTypeAndName] --'STK',NULL,NULL,NULL,'U4517',
(	@ActivityType VARCHAR(20), 
	@CDMSRef VARCHAR(30) = null,
	@ProjectID int = null,
	@SimpleTaskID int = null,
	@CDMSProjectRef VARCHAR(30) = NULL,
	@CDMSSimpleTaskRef VARCHAR(30) = NULL,
	@PageNumber INT  = 1 ,
	@PageSize INT = 100
)
AS
BEGIN
--SELECT 1,GETDATE()
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @FirstRec INT, @LastRec INT 
	Declare @ProjName varchar(50)= ''
	Declare @UKD_PROJ_REF Varchar(50)=''
	Declare @CEES_PROJ_REF Varchar(50)=''
	SELECT @FirstRec = (@PageNumber - 1) * @PageSize
	SELECT @LastRec = (@PageNumber * @PageSize + 1);
	IF @ProjectID=0
	BEGIN
	SET @ProjectID=NULL
	END
	--IF @CDMSRef=''
	--BEGIN
	--SET @CDMSRef=NULL
	--END
    -- Insert statements for procedure here
	IF(UPPER(@ActivityType) = 'PROJECT')
	BEGIN 
Declare @tblProject As Table
(
	Id int primary key identity(1,1),
	RecordCount int,
	CDMSRef Varchar(50),
	ActivityName Varchar(50),
	CreateDate smalldatetime,
	AE_AEID int,
	ActivityType varchar(50),
	CustomerID int,
	ProjectID int,
	SiteAddress Varchar(250),
	ProjName Varchar(50),
	UKD_PROJ_REF Varchar(50),
	CEES_PROJ_REF Varchar(50)
)

				--if exists (Select * from [MT_PROJ_MAPPING] WITH (NOLOCK)  where [CEES_PROJ_REF] in (@CDMSRef))
				if exists (Select 1 from [MT_PROJ_MAPPING] WITH (NOLOCK)  where [CEES_PROJ_REF] = @CDMSRef)
					Begin
						Set @ProjName='CEES PROJECT'
						Select @UKD_PROJ_REF=UKD_PROJ_REF From [MT_PROJ_MAPPING] WITH (NOLOCK)  where [CEES_PROJ_REF] =@CDMSRef
						Set @CEES_PROJ_REF=@CDMSRef
						--   Select * from [MT_PROJ_MAPPING] where [CEES_PROJ_REF] ='U7080331'
					End
				Else
					Begin
						Set @ProjName='UKD PROJECT'
						Select @CEES_PROJ_REF=CEES_PROJ_REF From [MT_PROJ_MAPPING] WITH (NOLOCK)  where UKD_PROJ_REF =@CDMSRef
						Set @UKD_PROJ_REF=@CDMSRef
						--   --   Select * from [MT_PROJ_MAPPING] where [UKD_PROJ_REF] ='U7080331'
					End 

					Insert into @tblProject(RecordCount,CDMSRef,ActivityName,
					CreateDate,AE_AEID,ActivityType,
					CustomerID,ProjectID,
					SiteAddress,
					ProjName,
					UKD_PROJ_REF,CEES_PROJ_REF )
				SELECT	
						Count(1) OVER() AS RecordCount,AE_internalRef AS CDMSRef, AE_relativeName AS ActivityName, 
						AE_dateCreated AS CreateDate,AE_AEID,@ActivityType AS ActivityType,
						AE_customer AS CustomerID,coalesce(AE_parentProjID,ae_aeid) AS ProjectID,
						Isnull(dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(ae_address),'') As SiteAddress,--fn_GetReformatReturnAddress
						--@ProjName As ProjName
						case when source_SYS='CDA' Then 'CEES PROJECT' Else 'UKD PROJECT' End As ProjName,
						@UKD_PROJ_REF UKD_PROJ_REF,@CEES_PROJ_REF CEES_PROJ_REF
				FROM [dbo].[BT_PROJ_U_HEADER] A WITH (NOLOCK) 
				WHERE A.AE_deleted = 'N' and A.AE_internalRef in (@CEES_PROJ_REF,@UKD_PROJ_REF)
			--	AND (@CDMSRef IS NULL OR UPPER(A.AE_internalRef) = UPPER(@CDMSRef))
				ORDER BY AE_AEID
		--if (Select count(*) from @tblProject)=1
		if (Select count(1) from @tblProject)=1
		Begin
			insert into @tblProject
			Select RecordCount,CDMSRef,ActivityName,CreateDate,AE_AEID,ActivityType,
					CustomerID,ProjectID,SiteAddress,case when ProjName='UKD PROJECT' Then 
					'CEES PROJECT' Else 'UKD PROJECT' End,case when ProjName='UKD PROJECT' Then 
					CEES_PROJ_REF  Else UKD_PROJ_REF End ,case when ProjName='UKD PROJECT' Then 
					UKD_PROJ_REF Else CEES_PROJ_REF End   
			From @tblProject
		End
		--if (Select count(*) from @tblProject)=2
		if (Select count(1) from @tblProject)=2
		Begin
			Update @tblProject Set UKD_PROJ_REF= @CEES_PROJ_REF WHERE ProjName='CEES PROJECT'
			Update @tblProject Set CEES_PROJ_REF=@UKD_PROJ_REF WHERE ProjName='UKD PROJECT'
		End
			Delete from @tblProject where ISNULL(UKD_PROJ_REF,'')='' and ProjName='CEES PROJECT'
			Select * from @tblProject
			Select @UKD_PROJ_REF UKD_PROJ_REF,@CEES_PROJ_REF CEES_PROJ_REF
	END
	ELSE IF(UPPER(@ActivityType) = 'STK')
	BEGIN 
		--SELECT * FROM 
			--(
				SELECT  --ROW_NUMBER() OVER ( ORDER BY AE_AEID) AS RowNum,
						Count(1) OVER() AS RecordCount,
						A.AE_internalRef AS CDMSRef, 
						A.AE_relativeName AS ActivityName, 
						A.AE_dateCreated AS CreateDate, 
						A.AE_AEID, 
						@ActivityType AS ActivityType,
						A.AE_customer AS CustomerID,
						A.AE_parentProjID AS ProjectID,
						Isnull(dbo.fn_GetReformatReturnAddress(A.ae_address),'') As SiteAddress,
						@ProjName As ProjName,
						A.AE_internalRef UKD_PROJ_REF
						,A.AE_internalRef CEES_PROJ_REF
				FROM [dbo].[BT_STK_HEADER]  A  WITH (NOLOCK) 
				INNER JOIN [BT_PROJ_U_HEADER] B WITH (NOLOCK)  ON A.AE_ParentID=B.AE_AEID
				WHERE A.AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR A.AE_internalRef = UPPER(@CDMSRef))
				AND (@ProjectID IS NULL OR A.AE_ParentID = @ProjectID)
				--AND (@CDMSProjectRef IS NULL OR AE_ParentID = (SELECT AE_AEID FROM [dbo].[BT_PROJ_U_HEADER] WHERE UPPER(AE_internalRef) = UPPER(@CDMSProjectRef)))
				AND @CDMSProjectRef IS NULL OR A.AE_ParentID =@CDMSProjectRef
				ORDER BY AE_AEID OPTION (RECOMPILE) -- QPID_OPT V4-05
				--OFFSET ((@PageNumber - 1) * @PageSize) ROWS
				--FETCH NEXT @PageSize ROWS ONLY
			--) RowResults
		--WHERE 
			--RowNum >= @FirstRec
			--AND RowNum < @LastRec
			--ORDER BY RowNum
	END
	ELSE IF(UPPER(@ActivityType) = 'CTK')
	BEGIN 
	--SELECT 2,GETDATE()
DECLARE @AE_parentProjID INT=(SELECT top 1 AE_AEID FROM [dbo].[BT_PROJ_U_HEADER]   WHERE AE_internalRef = UPPER(@CDMSProjectRef))
DECLARE @AE_ParentID INT=(SELECT top 1 AE_AEID FROM [dbo].[BT_STK_HEADER]   WHERE AE_internalRef = UPPER(@CDMSSimpleTaskRef))
		--SELECT * FROM 
			---(
				SELECT  --ROW_NUMBER() OVER ( ORDER BY AE_AEID) AS RowNum,
						Count(1) OVER() AS RecordCount,
						A.AE_internalRef AS CDMSRef, 
						A.AE_relativeName AS ActivityName, 
						A.AE_dateCreated AS CreateDate, 
						A.AE_AEID, 
						@ActivityType AS ActivityType,
						A.AE_customer AS CustomerID,
						A.AE_parentProjID AS ProjectID,
						Isnull(dbo.fn_GetReformatReturnAddress(A.ae_address),'') As SiteAddress,
						@ProjName As ProjName,
						A.AE_internalRef UKD_PROJ_REF
						,A.AE_internalRef CEES_PROJ_REF
				FROM [dbo].[BT_CTK_HEADER]  A WITH (NOLOCK) 
				LEFT JOIN BT_STK_HEADER C WITH (NOLOCK)  ON  A.AE_ParentID=C.AE_AEID
				LEFT JOIN [BT_PROJ_U_HEADER] B WITH (NOLOCK)  on A.AE_parentProjID=B.AE_AEID	
				WHERE A.AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR A.AE_internalRef = UPPER(@CDMSRef))
				AND (@SimpleTaskID IS NULL OR A.AE_ParentID = @SimpleTaskID)
				AND (@ProjectID IS NULL OR A.AE_parentProjID = @ProjectID)
				--AND (@CDMSProjectRef IS NULL OR A.AE_parentProjID = (SELECT top 1 AE_AEID FROM [dbo].[BT_PROJ_U_HEADER]   WHERE UPPER(AE_internalRef) = UPPER(@CDMSProjectRef)))
				--AND (@CDMSSimpleTaskRef IS NULL OR A.AE_ParentID = (SELECT top 1 AE_AEID FROM [dbo].[BT_STK_HEADER]   WHERE UPPER(AE_internalRef) = UPPER(@CDMSSimpleTaskRef)))
				AND (@CDMSProjectRef IS NULL OR A.AE_parentProjID =@AE_parentProjID)
				AND (@CDMSSimpleTaskRef IS NULL OR A.AE_ParentID =@AE_ParentID)
				--AND UPPER(B.AE_internalRef) = Case When @CDMSProjectRef=null  Then B.AE_internalRef ELSE UPPER(@CDMSProjectRef) END
				--AND UPPER(C.AE_internalRef) =Case When @CDMSSimpleTaskRef=null Then C.AE_internalRef ELSE UPPER(@CDMSSimpleTaskRef) End
				ORDER BY AE_AEID OPTION (RECOMPILE) -- QPID_OPT V4-05
				--OFFSET ((@PageNumber - 1) * @PageSize) ROWS
				--FETCH NEXT @PageSize ROWS ONLY
			--) RowResults
		--WHERE 
			--RowNum >= @FirstRec
			--AND RowNum < @LastRec
	--ORDER BY RowNum
		--SELECT 3,GETDATE()	
	
	END
	ELSE IF(UPPER(@ActivityType) = 'PROGRESSH')
	BEGIN 
		--SELECT * FROM 
			--(
				SELECT  --ROW_NUMBER() OVER ( ORDER BY AE_AEID) AS RowNum,
						Count(1) OVER() AS RecordCount,
						AE_internalRef AS CDMSRef, 
						AE_relativeName AS ActivityName, 
						AE_dateCreated AS CreateDate, 
						AE_AEID, 
						@ActivityType AS ActivityType,
						AE_customer AS CustomerID,
						AE_parentProjID AS ProjectID,
						Isnull(dbo.fn_GetReformatReturnAddress(ae_address),'') As SiteAddress,
						@ProjName As ProjName,
						AE_internalRef UKD_PROJ_REF
						,AE_internalRef CEES_PROJ_REF
				FROM [dbo].[BT_PROJ_HEADER]  WITH (NOLOCK) 
				WHERE AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR AE_internalRef = UPPER(@CDMSRef))
				AND (@ProjectID IS NULL OR AE_parentProjID = @ProjectID)
				--AND (@CDMSProjectRef IS NULL OR AE_parentProjID = (SELECT AE_AEID FROM [dbo].[BT_PROJ_U_HEADER] WITH (NOLOCK)  WHERE UPPER(AE_internalRef) = UPPER(@CDMSProjectRef)))
				AND (@CDMSProjectRef IS NULL OR AE_parentProjID =@AE_parentProjID) 
				ORDER BY AE_AEID
				OFFSET ((@PageNumber - 1) * @PageSize) ROWS
				FETCH NEXT @PageSize ROWS ONLY OPTION (RECOMPILE) -- QPID_OPT V4-05
			--) RowResults
		--WHERE 
			--RowNum >= @FirstRec
			--AND RowNum < @LastRec
			--ORDER BY RowNum
	END
END
GO
SET NOEXEC OFF;
GO
IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.usp_GetActivityBasedOnTypeAndName')) LIKE N'%QPID_OPT V4-05%'
    PRINT 'DEPLOYED: V4-05 is live on usp_GetActivityBasedOnTypeAndName.';
ELSE
    RAISERROR('NOT DEPLOYED: V4-05 is not live on usp_GetActivityBasedOnTypeAndName (see the REFUSED message above).', 16, 1);
GO
