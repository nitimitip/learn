USE [QPID_PROD]
GO
/******************************************************************************
  V4-06 - OPTIMIZED PROCEDURE - NOT EXECUTED - TEST ON UAT BEFORE DEPLOYMENT
  Procedure : [dbo].[usp_QPIDConnectivitySearch]
  Original  : QPID_SP/usp_QPIDConnectivitySearch.sql
  Generated : optimization_v4/tools/gen_v4_06.py
  Change    : matching keys first; per-row lookups only for the requested page.
  Before    : run V4-06.2 in validation/v4_06_validation.sql.
  Guard     : refuses a live version that differs from the supplied original.
******************************************************************************/
SET NOEXEC OFF;
GO
DECLARE @def nvarchar(max) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.usp_QPIDConnectivitySearch'));
IF @def IS NULL OR (LEN(@def) <> 3091 AND @def NOT LIKE N'%QPID_OPT V4-06%')
BEGIN
    RAISERROR('REFUSED: production usp_QPIDConnectivitySearch differs from the supplied original. Nothing changed.', 16, 1);
    SET NOEXEC ON;
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROC [dbo].[usp_QPIDConnectivitySearch]
(
	@PrimarySubstation int=0,
	@DistributionSubstation varchar(max)= NULL,
	@GridSupply int=0,
	@BulkSupply int=0,
	@PageIndex INT = 1,  
    @PageSize INT = 10,
	@RecordCount INT OUTPUT 

)
AS
		
		  BEGIN
		  SET NOCOUNT ON;  
		  declare @disSite int = 0
		  select @disSite = INT_LOV_ID from MT_SYS_LOV where LOV_DESC=@DistributionSubstation and LOV_NAME='sysQuoteDistributionSite'	  
		  
		  -- QPID_OPT V4-06: find the matching rows first; the lookups below run only for the requested page.
Select ROW_NUMBER() OVER (ORDER BY ENQ.AE_internalRef ASC, QUO.AE_AEID ASC, EXT.EX_ID ASC) AS RowNumber,
       EXT.EX_ID, EXT.EX_AEID INTO #filterKeys
 from BT_QUOTE_AE_EXTRA EXT 
 INNER JOIN BT_QUOTE_MASTER QUO ON EXT.EX_AEID = QUO.AE_AEID AND EXT.EX_deleted <> 'Y' AND QUO.AE_deleted <> 'Y'
 INNER JOIN BT_ENQUIRY_MASTER ENQ ON ENQ.AE_AEID = QUO.AE_ParentID AND ENQ.AE_deleted <> 'Y'
		  where (primarySubSite = @PrimarySubstation OR @PrimarySubstation = 0) AND 
		  (distributionSubSite = @disSite  OR @disSite = '') AND 
		  (gridSupplyPoint = @GridSupply OR @GridSupply = 0) AND 
		  (bulkSupplyPoint = @BulkSupply OR  @BulkSupply = 0) AND 
		  EXT.EX_deleted <> 'Y' AND 
		  QUO.AE_status <> 8000 AND 
		  QUO.AE_status <> 7000
OPTION (RECOMPILE);

Select K.RowNumber , ENQ.AE_internalRef,
  (SELECT top 1 PEOPORG_NAME from MT_ACT_PEOPORG where ENQ.AE_assignedToPerson = PEOPORG_PEOPORGID) AS AE_assignedToPerson ,
  (SELECT top 1 PEOPORG_NAME from MT_ACT_PEOPORG where ENQ.AE_quoteDesigner = PEOPORG_PEOPORGID) AS AE_quoteDesigner,
  ADR.siteName,
  Convert(varchar,QUO.AE_plannedStartDate,103) AS AE_plannedStartDate , 
  (SELECT top 1 LOV_DESC from MT_SYS_LOV where QUO.AE_status = LOV_VALUE AND  rtrim(ltrim(coalesce(LOV_Name,'')))='sysStatusQuote'
				AND LOV_DELETED=0   and (ISNULL(LOV_OBSOLETE,'N') <> 'Y')) AS AE_status ,
  Convert(varchar,QUO.AE_plannedEndDate,103) AS AE_plannedEndDate ,QUO.AE_supplyCapacity,
(SELECT top 1 LOV_DESC from MT_SYS_LOV WHERE QUO.AE_NGESO = INT_LOV_ID AND rtrim(ltrim(coalesce(LOV_NAME,'')))='sysNGESO' 
		AND LOV_DELETED <> 1and ISNULL(LOV_OBSOLETE,'N') <> 'Y') AS AE_NGESO , 
QUO.AE_InteractiveEnqInfo ,EXT.EX_totalExportCapacity ,
(SELECT LOV_DESC FROM MT_SYS_LOV WHERE INT_LOV_ID = EXT.primarySubSite ) AS PrimarySubName ,
(SELECT LOV_DESC FROM MT_SYS_LOV WHERE INT_LOV_ID = EXT.distributionSubSite ) AS DistributionSubName ,
(SELECT LOV_DESC FROM MT_SYS_LOV WHERE INT_LOV_ID = EXT.FeederName ) AS FeederName ,
EXT.EX_bspGspPrimaryName ,
(SELECT LOV_DESC FROM MT_SYS_LOV WHERE INT_LOV_ID = EXT.gridSupplyPoint ) AS gridSupplyPoint ,
(SELECT LOV_DESC FROM MT_SYS_LOV WHERE INT_LOV_ID = EXT.bulkSupplyPoint ) AS bulkSupplyPoint ,
EXT.HvFeederName,Ext.EhvFeederName , 
Convert(varchar,DATEADD(DAY,90,QUO.AE_plannedStartDate),103) AS AE_quoteValidPeriod INTO #filterResults
 from #filterKeys K
 INNER JOIN BT_QUOTE_AE_EXTRA EXT ON EXT.EX_ID = K.EX_ID AND EXT.EX_AEID = K.EX_AEID
 INNER JOIN BT_QUOTE_MASTER QUO ON EXT.EX_AEID = QUO.AE_AEID
 INNER JOIN BT_ENQUIRY_MASTER ENQ ON ENQ.AE_AEID = QUO.AE_ParentID
 LEFT JOIN BT_ADDRESS_MASTER ADR ON ADR.ADDRESS_ID = ENQ.AE_address
 WHERE K.RowNumber BETWEEN(@PageIndex -1) * @PageSize + 1 AND(((@PageIndex -1) * @PageSize + 1) + @PageSize) - 1;

		SELECT * FROM #filterResults ORDER BY RowNumber

	  SELECT @RecordCount = COUNT(*) FROM #filterKeys
	  PRINT @RecordCount
        
      DROP TABLE #filterResults
      DROP TABLE #filterKeys
		  END
		
GO
SET NOEXEC OFF;
GO
IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.usp_QPIDConnectivitySearch')) LIKE N'%QPID_OPT V4-06%'
    PRINT 'DEPLOYED: V4-06 is live on usp_QPIDConnectivitySearch.';
ELSE
    RAISERROR('NOT DEPLOYED: V4-06 is not live on usp_QPIDConnectivitySearch (see the REFUSED message above).', 16, 1);
GO
