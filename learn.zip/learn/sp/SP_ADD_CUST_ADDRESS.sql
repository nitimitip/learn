USE [QPID_PROD]
GO
/******************************************************************************
  V4-03 - OPTIMIZED PROCEDURE - NOT EXECUTED - TEST ON UAT BEFORE DEPLOYMENT
  Procedure : [dbo].[SP_ADD_CUST_ADDRESS] (adds a customer address)
  Original  : QPID_SP/SP_ADD_CUST_ADDRESS.sql
  Generated : optimization_v4/tools/gen_v4_03.py
  Change    : WITH (READUNCOMMITTED) on the MAX(id)+1 read, 1 line(s). Nothing else.
  Guard     : refuses if production is not the expected original version.
  Rollback  : optimization_v4/rollback/SP_ADD_CUST_ADDRESS_ORIGINAL.sql
******************************************************************************/
SET NOEXEC OFF;
GO
DECLARE @def nvarchar(max) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.SP_ADD_CUST_ADDRESS'));
IF @def IS NULL OR (LEN(@def) <> 1744 AND @def NOT LIKE N'%QPID_OPT V4-03%')
BEGIN
    RAISERROR('REFUSED: production SP_ADD_CUST_ADDRESS differs from the expected original. Nothing changed.', 16, 1);
    SET NOEXEC ON;
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


ALTER PROCEDURE [dbo].[SP_ADD_CUST_ADDRESS]
	@ploggedonUser				VARCHAR(25),
	@pCustRef					VARCHAR(50),
	@pAddrUSage 				VARCHAR(10),
	@pFreeText					VARCHAR(50) = NULL,
	@pSubBuilding				VARCHAR(50) = NULL,
	@pBuilding					VARCHAR(50) = NULL,
	@pSubStreet					VARCHAR(50) = NULL,
	@pStreet					VARCHAR(50),
	@pDDLocality				VARCHAR(50) = NULL,
	@pDLocality					VARCHAR(50) = NULL,
	@pTown						VARCHAR(50),
	@pPostCode					VARCHAR(50) = NULL,
	@pEasting					VARCHAR(10) = NULL,
	@pNorthing					VARCHAR(10) = NULL,
	@pCFSID						int = NULL,
	@pErrorMessage				VARCHAR(5000) OUTPUT 
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @vAddId int;
	DECLARE @vConId int;
	DECLARE @vCustId int;

BEGIN TRY
		SET @pErrorMessage = ''
		
		SELECT @vAddId = MAX(ADDRESS_ID)+1 FROM BT_ADDRESS_MASTER WITH (READUNCOMMITTED); -- QPID_OPT V4-03 
		SELECT @vCustId = CUST_ID  FROM BT_CUSTOMER_MASTER where CUST_REFERENCE = @pCustRef
														
		INSERT INTO BT_ADDRESS_MASTER
				   ([ADDRESS_ID],[parentID],[addressLine1] ,[addressLine2] ,[addressLine3]
				   ,[addressLine4],[addressLine5] ,[addressLine6],[addressLine7] ,[addressLine8]
				   ,[postCode],[easting] ,[Northing] ,[addressUsage]
				   ,[dateCreated] ,[createdBy],[lastUpdated],[lastUpdatedBy] ,[CFSID],deleted
				   )
					 SELECT
					@vAddId,@vCustId,@pFreeText,@pSubBuilding,@pBuilding,
					@pSubStreet,@pStreet,@pDDLocality,@pDLocality,@pTown,
					@pPostCode,@pEasting,@pNorthing,@pAddrUSage,
					GETDATE(),@ploggedonUser,GETDATE(),@ploggedonUser,@pCFSID,'N'

	  SELECT @vAddId;



			

		RETURN 0
END TRY

BEGIN CATCH
		SELECT @pErrorMessage='Error Code: ' + CAST (ERROR_NUMBER() AS VARCHAR(10)) + ', Error: ' + ERROR_MESSAGE()
		RETURN 1
END CATCH	
END 







GO
SET NOEXEC OFF;
GO
IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.SP_ADD_CUST_ADDRESS')) LIKE N'%QPID_OPT V4-03%'
    PRINT 'DEPLOYED: V4-03 is live on SP_ADD_CUST_ADDRESS.';
ELSE
    RAISERROR('NOT DEPLOYED: V4-03 is not live on SP_ADD_CUST_ADDRESS (see the REFUSED message above).', 16, 1);
GO
