USE [QPID_PROD]
GO
/******************************************************************************
  V4-07 - OPTIMIZED PROCEDURE - NOT EXECUTED - TEST ON UAT BEFORE DEPLOYMENT
  Procedure : [dbo].[SP_LIST_NOTE_USAGE]
  Original  : QPID_SP/SP_LIST_NOTE_USAGE.sql
  Generated : optimization_v4/tools/gen_v4_07.py
  Change    : the name LIKE runs once per distinct LOV_NAME, not once per row.
  Guards    : refuses non-ASCII list names, any difference between the old and new
              filter on the live data, or an unexpected live version.
******************************************************************************/
SET NOEXEC OFF;
GO
IF EXISTS (SELECT 1 FROM dbo.MT_SYS_LOV WITH (NOLOCK)
           WHERE LOV_NAME COLLATE Latin1_General_BIN LIKE '%[^ -~]%')
BEGIN
    RAISERROR('REFUSED: MT_SYS_LOV has a non-ASCII LOV_NAME, so the rewrite is not proven equivalent. Nothing changed.', 16, 1);
    SET NOEXEC ON;
END
GO
IF EXISTS (SELECT INT_LOV_ID FROM dbo.MT_SYS_LOV WHERE LOV_NAME LIKE '%sysNoteUsage%'
           EXCEPT
           SELECT INT_LOV_ID FROM dbo.MT_SYS_LOV WHERE LOV_NAME IN (SELECT d.LOV_NAME FROM (SELECT DISTINCT TOP (2147483647) LOV_NAME FROM MT_SYS_LOV) d WHERE d.LOV_NAME LIKE '%sysNoteUsage%'))
   OR EXISTS (SELECT INT_LOV_ID FROM dbo.MT_SYS_LOV WHERE LOV_NAME IN (SELECT d.LOV_NAME FROM (SELECT DISTINCT TOP (2147483647) LOV_NAME FROM MT_SYS_LOV) d WHERE d.LOV_NAME LIKE '%sysNoteUsage%')
              EXCEPT
              SELECT INT_LOV_ID FROM dbo.MT_SYS_LOV WHERE LOV_NAME LIKE '%sysNoteUsage%')
BEGIN
    RAISERROR('REFUSED: the old and new filters select different rows. Nothing changed.', 16, 1);
    SET NOEXEC ON;
END
GO
DECLARE @def nvarchar(max) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.SP_LIST_NOTE_USAGE'));
IF @def IS NULL OR (LEN(@def) <> 162 AND @def NOT LIKE N'%QPID_OPT V4-07%')
BEGIN
    RAISERROR('REFUSED: production SP_LIST_NOTE_USAGE differs from the supplied original. Nothing changed.', 16, 1);
    SET NOEXEC ON;
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER Procedure [dbo].[SP_LIST_NOTE_USAGE]
AS
BEGIN
	-- QPID_OPT V4-07: the LIKE runs once per distinct name, not once per row.
	SELECT * FROM MT_SYS_LOV WHERE LOV_NAME IN (SELECT d.LOV_NAME FROM (SELECT DISTINCT TOP (2147483647) LOV_NAME FROM MT_SYS_LOV) d WHERE d.LOV_NAME LIKE '%sysNoteUsage%') AND LOV_DELETED<>1 ORDER BY LOV_DESC
END
GO
SET NOEXEC OFF;
GO
IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.SP_LIST_NOTE_USAGE')) LIKE N'%QPID_OPT V4-07%'
    PRINT 'DEPLOYED: V4-07 is live on SP_LIST_NOTE_USAGE.';
ELSE
    RAISERROR('NOT DEPLOYED: V4-07 is not live on SP_LIST_NOTE_USAGE (see the REFUSED message above).', 16, 1);
GO
