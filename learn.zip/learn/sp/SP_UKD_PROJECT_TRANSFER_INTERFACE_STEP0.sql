USE [QPID_PROD]
GO
/******************************************************************************
  V4-04 - OPTIMIZED PROCEDURE - NOT EXECUTED - REVIEW V4-04_NOTES.md FIRST
  Procedure : [dbo].[SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP0] (CFS project transfer job)
  Original  : QPID_SP/SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP0.sql
  Generated : optimization_v4/tools/gen_v4_04.py
  Change    : TRUNCATE instead of DELETE on XT_XFACE_CFS_CONTACTS, DELETE kept
              as the fallback. Nothing else.
  Guard     : refuses if production is not the expected original version.
  Rollback  : optimization_v4/rollback/SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP0_ORIGINAL.sql
  WARNING   : do not run this procedure by hand to test it: it sends to CFS.
******************************************************************************/
SET NOEXEC OFF;
GO
DECLARE @def nvarchar(max) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP0'));
IF @def IS NULL OR (LEN(@def) <> 2530 AND @def NOT LIKE N'%QPID_OPT V4-04%')
BEGIN
    RAISERROR('REFUSED: production SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP0 differs from the expected original. Nothing changed.', 16, 1);
    SET NOEXEC ON;
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- EXEC [SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP0]
ALTER PROCEDURE [dbo].[SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP0]  
AS  
declare @G_ERROR_PLACE     varchar(60)  
declare @G_ERROR_MSG       varchar(200)  
declare @G_ERROR_CODE      int  
declare @l_exit_flag       int   
declare @l_bud_id          int  
declare @l_task            int  
declare @l_proj            int  
declare @l_version         int  
declare @l_costType        varchar(30)  
declare @l_ExpenType       varchar(30)  
declare @l_budCost         numeric  
declare @l_bud_delete_flag varchar(1)  
declare @canConnect  varchar(1) 
declare @maximumNumberOfProjectsPerCFSBatch int 
begin   
   
declare @l_MainBatchID  varchar(30), @l_StatusBatchID varchar(30)  
declare @agentCDMS_CFSID VARCHAR(50)   


-- QPID_OPT V4-04: TRUNCATE first; the original DELETE is the fallback
BEGIN TRY
    TRUNCATE TABLE XT_XFACE_CFS_CONTACTS;
END TRY
BEGIN CATCH
    delete from XT_XFACE_CFS_CONTACTS;
END CATCH;

INSERT INTO XT_XFACE_CFS_CONTACTS
SELECT CONTACT_ID,CONTACT_FIRST_NAME,CONTACT_LAST_NAME,null
FROM OPENQUERY(CFSPROD, 'SELECT DISTINCT CONTACT_ID,CONTACT_FIRST_NAME,CONTACT_LAST_NAME
FROM CDALINK.CDA_CONTACTS_V WHERE CONTACT_ROLE=''BILL_TO'' AND CONTACT_ROLE_PRIMARY_FLAG=''Y''');



DECLARE @CFS_GOLIVE_DATE datetime

SET @CFS_GOLIVE_DATE ='2007-06-06'; 
SET @maximumNumberOfProjectsPerCFSBatch=6000;
 SET @agentCDMS_CFSID = 'CECDMS';
 
/*  
 ** Create the new Batch Record  
 */  
 insert into XT_CDMS_INTERFACEBATCHES  
 (bat_BatchID,bat_BatchType, bat_BatchDate, bat_BatchComments, bat_BatchStatus)  
 values ((SELECT MAX(bat_batchid) +1 FROM XT_CDMS_INTERFACEBATCHES),'CFSInterface',getdate(),
 'Main Batch', 'STARTED') ; 
 select @l_MainBatchID = 'CDMS'+'0'+replace(str(convert(varchar,max(bat_BatchID)),7),' ','0'),  
        @l_StatusBatchID = 'CDMS'+'1'+replace(str(convert(varchar,max(bat_BatchID)),7),' ','0')  
 from XT_CDMS_INTERFACEBATCHES;  
  
 /*  
 ** first truncate the old interface data  
 */  
 truncate table XT_XFACE_PROJECTS_TASK;  
   
--  begin tran NewProjs --GM commented out 17-10-03  
 /*  
 ** now insert all the projects   
 */  
exec SP_UKD_PROJECT_TRANSFER_runCFSIDMapping --THIS WILL UPDATE THE PROJECT WITH IT'S CFS ID'S EITHER MAPPED OR USING THE PROJECT DEFINED CUST, ADDR, CONT  
  
PRINT @l_StatusBatchID
PRINT @l_MainBatchID

exec SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP01

exec SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP02

exec SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP03
exec SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP04
exec SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP05

exec SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP2

end;
GO
SET NOEXEC OFF;
GO
IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP0')) LIKE N'%QPID_OPT V4-04%'
    PRINT 'DEPLOYED: V4-04 is live on SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP0.';
ELSE
    RAISERROR('NOT DEPLOYED: V4-04 is not live on SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP0 (see the REFUSED message above).', 16, 1);
GO
