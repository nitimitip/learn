USE [QPID_PROD]
GO
/******************************************************************************
  V4-09 - BUG FIX - NOT EXECUTED - TEST ON UAT BEFORE DEPLOYMENT
  Procedure : [dbo].[usp_QMS_InitialDataLoad_CRM]
  Original  : QPID_SP/usp_QMS_InitialDataLoad_CRM.sql
  Generated : optimization_v4/tools/gen_v4_09.py
  Change    : one line in CATCH rolls back a doomed transaction before the log
              write, so 3930 no longer hides the real error.
  Not in it : BF04 own transaction, savepoint and UPDLOCK, HOLDLOCK hints.
  Guards    : refuses if the live definition differs in length from the original,
              which includes BF04. Re-running after deployment is safe.
******************************************************************************/
SET NOEXEC OFF;
GO
DECLARE @def nvarchar(max) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.usp_QMS_InitialDataLoad_CRM'));
IF @def IS NULL OR (LEN(@def) <> 6997 AND @def NOT LIKE N'%QPID_OPT V4-09%')
BEGIN
    RAISERROR('REFUSED: live usp_QMS_InitialDataLoad_CRM differs from the supplied original. Send its definition. Nothing changed.', 16, 1);
    SET NOEXEC ON;
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[usp_QMS_InitialDataLoad_CRM]  
(  
	@pCRMRef VARCHAR(50)  
)  
AS   
 BEGIN  
   DECLARE @mResult VARCHAR(500)=NULL;  
   DECLARE @AE_AEID INT;  
   DECLARE @internal_referance varchar(20);  
   DECLARE @vCustId int;  
   DECLARE @ploggedonUser INT;  
   Declare @NewCustRef Varchar(50);  
   DECLARE @vAddId int;  
   DECLARE @vConId int;  
   DECLARE @msgTxt varchar(500);

   SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

   BEGIN TRY  
		--WAITFOR DELAY '00:00:02';
		SET @msgTxt = 'BEGIN INIT LOAD'+CONVERT( VARCHAR(24), GETDATE(), 121)+', '
		SELECT @vCustId=MAX(cust_id) +1 
		FROM BT_CUSTOMER_MASTER;
		
		SET @NewCustRef='CUST'+CONVERT(VARCHAR(MAX),@vCustId)   
   
		SELECT @ploggedonUser= INT_USR_ID 
		FROM MT_USERS 
		WITH (NOLOCK)
		WHERE [USER_NAME]='AD03\CRM.User'  
    
		INSERT INTO BT_CUSTOMER_MASTER  
					(CUST_ID,  
					 CUST_REFERENCE,  
					 CUST_ORG_Name,  
					 CUST_TELEPHONE,  
					 CFSID,  
					 CREATED_ON,  
					 CREATED_BY,  
					 UPDATED_ON,  
					 UPDATED_BY,  
					 CUST_TYPE,  
					 CUST_DELETED,SOURCE_SYS)  
		SELECT  
					@vCustId,  
					@NewCustRef,  
					'',  
					'',  
					'',  
					GETDATE(),  
					@ploggedonUser,  
					GETDATE(),  
					@ploggedonUser,  
					'',  
					'N',  
					'CRM';  
  
		SELECT @vAddId = MAX(ADDRESS_ID)+1 
		FROM BT_ADDRESS_MASTER;   
    
                
		INSERT INTO BT_ADDRESS_MASTER  
				   ([ADDRESS_ID],
				   [parentID],
				   [addressLine1],
				   [addressLine2],
				   [addressLine3]  
				   ,[addressLine4],
				   [addressLine5] 
				   ,[addressLine6],
				   [addressLine7] 
				   ,[addressLine8]  
				   ,[postCode]
				   ,[easting] 
				   ,[Northing] 
				   ,[addressUsage]  
				   ,[dateCreated] 
				   ,[createdBy]
				   ,[lastUpdated]
				   ,[lastUpdatedBy]
				   ,[CFSID]
				   ,[deleted] 
				   ,[SOURCE_SYS]
                   )  
        SELECT  
					@vAddId
					,@vCustId
					,''
					,''
					,''
					,''
					,''
					,''
					,''
					,''
					,''
					,''
					,''
					,''
					,GETDATE()
					,@ploggedonUser
					,GETDATE()
					,@ploggedonUser
					,''
					,'N'
					,'CRM'
       
		SELECT @vConId = MAX(con_contactID)+1 
		FROM BT_CONTACTS_MASTER;  
     
    
                
		INSERT INTO BT_CONTACTS_MASTER  
				   ([con_contactID],[con_parentID], [con_parentType],[con_surname] ,[con_forename]  
				   ,[con_personalTitle],[con_jobTitle] ,[con_telephone]  
				   ,[con_email] ,[con_mobile] ,[con_dateCreated],[con_createdBy],[con_lastUpdated],  
				   [con_lastUpdatedBy],[con_deleted],[con_CFSID],con_contactName ,SOURCE_SYS 
				   )  
      SELECT  
				 @vConId,@vCustId,1,'','','','',''  
				 ,'','',GETDATE(),@ploggedonUser,GETDATE(),@ploggedonUser,'N','',  
				 ''   ,'CRM'  
				 
		UPDATE 	BT_CUSTOMER_MASTER SET CUST_PRIM_ADDRID = @vAddId, CUST_PRIM_CONTACTID = @vConId
		WHERE 	CUST_ID = @vCustId AND CUST_REFERENCE = @NewCustRef           
      
	  SELECT @AE_AEID=(max(AE_AEID)+1)   
	  FROM BT_ENQUIRY_MASTER;  
  
   
	  SET @internal_referance=CONCAT('ENQ',@AE_AEID) ;  
  
	  INSERT INTO BT_ENQUIRY_MASTER   
				  ( AE_AEID,ae_address,AE_internalRef,AE_externalRef,AE_dateOrigin,AE_orderReceivedDate,AE_summaryDescription,AE_assignedToDept,AE_assignedToPerson,  
					AE_status,AE_type,AE_plotUnit,AE_networkDistributor,AE_metaModelType,AE_metaModelType2,AE_MPANRequested,AE_isTemplate,AE_sendToCFS,AE_customer,AE_createdBy,  
					AE_dateCreated,AE_lastUpdatedBy,AE_lastUpdated,AE_contact,AE_CustomerAddress,AE_companyID,AE_deleted,AE_taskInstruction,AE_useUplift,AE_Category,AE_stdCode,  
					AE_externalRef2  
					,AE_CustType,AE_externalRef3,AE_QuoteProjectDiscuss,AE_QuoteProvision  
					)  
	   VALUES  
			  (@AE_AEID,0,@internal_referance,null,getdate(),getdate(),REPLACE(REPLACE(REPLACE('', CHAR(13),' '), CHAR(10),' '),'&',' '),0,0,  
			   0,0,'',0,'T',1,'N','N','N',@vCustId,@ploggedonuser,  
			   GETDATE(),@ploggedonuser,getdate(),@vConId,@vAddId,1000,'N','Y','Y',-1,'NONE',@pCRMRef  
			   ,0,0,0,0);  
  
		 INSERT INTO MT_ENQUIRY_QUESTIONS    
		  (aeq_ae_aeid,aeq_POC_Voltage_LOV,aeq_HA_Voltage_LOV,aeq_GENERATION_LOV,aeq_TOW_REQUIRED_LOV,aeq_NUM_End_Connection_LOV,aeq_create_date,aeq_created_by,aeq_updated_by,aeq_updated_date)   
		 VALUES  
		  (@AE_AEID,0,0,0,0,0,GETDATE(),@ploggedonuser,@ploggedonuser,GETDATE());
		  
		  EXEC sp_ACT_addHIST_addEnquiry @AE_AEID, @ploggedonuser, 0, 0, 0, ''
		 
		  --Create default standards
		  declare @sourceType varchar(50)
		  SELECT
			@sourceType=source
		  FROM
			BT_Message
		  WITH (NOLOCK)
		  WHERE
			QMS_Reference_Number=@pCRMRef
		  IF @sourceType = 'CRM_SmallWork'
		  BEGIN
			IF NOT EXISTS (SELECT * FROM BT_ACT_STANDARDS_CRM_STG WHERE QMS_REF= @pCRMRef)
			BEGIN
				declare @currentDt varchar(50)
				set @currentDt = convert(varchar,getdate(),121)
				EXEC SP_ADD_STANDARDS  @ploggedonuser,@internal_referance, 294, @currentDt, 5000,1
			END

			--Update task category items
			update BT_ACT_TASKCATEGORYITEMS_CRM_STG set TCI_nonContestValQty=TCI_contestValQty where qms_ref=@pCRMRef

		  END

		  --UPDATE BT_Message SET Message_Status='W', QPID_Reference_Number=@internal_referance
		  --Where QMS_Reference_Number=@pCRMRef and Message_Status!='P'
		
		IF exists(select parent_techType_name,child_techType_name,ed.device_type,ed.QMS_REF
					from BT_EquipmentDetails_CRM_STG ed
					LEFT JOIN BT_Equipment_Techtype_Mapping_CRM_STG edm 
					on REPLACE(UPPER(edm.equipment_name),' ','') = REPLACE(UPPER(ed.device_type),' ','') 
					and edm.lov_type='sysTechnologyType'
					where ed.QMS_REF=@pCRMRef
					AND (edm.parent_techType_name IS NULL or edm.child_techType_name IS NULL))
			BEGIN
				UPDATE BT_Message 
				SET Message_Status='F',
					QPID_Reference_Number=@internal_referance, 
					Error_Description='Invalid Equipment, Technology type does not exists in QPID'
				Where QMS_Reference_Number=@pCRMRef 
					  and Message_Status!='P'
			END
		ELSE
			BEGIN
				UPDATE BT_Message 
				SET Message_Status='W', 
					QPID_Reference_Number=@internal_referance
				Where QMS_Reference_Number=@pCRMRef 
					  and Message_Status!='P'
			END
		
		SET @mResult=@internal_referance;  
		SET @msgTxt = @msgTxt + @mResult + ' END INIT LOAD '+CONVERT( VARCHAR(24), GETDATE(), 121)
		exec usp_CreateEntryForExecutionTime @pCRMRef,@msgTxt;
		
		/*IF @sourceType = 'CRM_MajorWork'
		BEGIN
			exec usp_QMS_FinalDataLoad_CRM_MajorWork
		END
		ELSE
		BEGIN
			exec usp_QMS_FinalDataLoad_CRM_SmallWork
		END*/
   END TRY  
   BEGIN CATCH  
    
		SET @mResult=dbo.GetError();  
		IF XACT_STATE() = -1 ROLLBACK TRANSACTION; -- QPID_OPT V4-09: a log write in a doomed transaction raises 3930 and hides the real error.
		SET @msgTxt = @msgTxt + @mResult + ' END INIT LOAD '+CONVERT( VARCHAR(24), GETDATE(), 121)
		exec usp_CreateEntryForExecutionTime @pCRMRef,@msgTxt;
   END CATCH  
   SELECT @mResult AS RESULT;  
   
 END
GO
SET NOEXEC OFF;
GO
IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.usp_QMS_InitialDataLoad_CRM')) LIKE N'%QPID_OPT V4-09%'
    PRINT 'DEPLOYED: V4-09 is live on usp_QMS_InitialDataLoad_CRM.';
ELSE
    RAISERROR('NOT DEPLOYED: V4-09 is not live on usp_QMS_InitialDataLoad_CRM (see the REFUSED message above).', 16, 1);
GO
