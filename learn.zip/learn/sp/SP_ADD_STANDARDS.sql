USE [QPID_PROD]
GO
/******************************************************************************
  V4-03 - OPTIMIZED PROCEDURE - NOT EXECUTED - TEST ON UAT BEFORE DEPLOYMENT
  Procedure : [dbo].[SP_ADD_STANDARDS] (adds standards to an ENQ or CTK activity)
  Original  : QPID_SP/SP_ADD_STANDARDS.sql
  Generated : optimization_v4/tools/gen_v4_03.py
  Change    : WITH (READUNCOMMITTED) on the MAX(id)+1 read, 2 line(s). Nothing else.
  Guard     : refuses if production is not the expected original version.
  Rollback  : optimization_v4/rollback/SP_ADD_STANDARDS_ORIGINAL.sql
******************************************************************************/
SET NOEXEC OFF;
GO
DECLARE @def nvarchar(max) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.SP_ADD_STANDARDS'));
IF @def IS NULL OR (LEN(@def) <> 11149 AND @def NOT LIKE N'%QPID_OPT V4-03%')
BEGIN
    RAISERROR('REFUSED: production SP_ADD_STANDARDS differs from the expected original. Nothing changed.', 16, 1);
    SET NOEXEC ON;
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[SP_ADD_STANDARDS] --23729,'ENQ23000374','593,310','2026-03-03 09:51:00','',''
	@ploggedonUser				INT,
	@pEnqRef					VARCHAR(50),
	@pStdCode					varchar(MAX),
	@pSLAStartDate				VARCHAR(50)=NULL,
	@pGS_adjust_target_date		CHAR(1) OUTPUT,
	@pErrorMessage				VARCHAR(5000) OUTPUT 

AS
BEGIN
	DECLARE @vStdId int;
	DECLARE @vEnqId int;
	DECLARE @vMaxStdId int;
	DECLARE @vNoofWorkingDays int;
	DECLARE @vTragetDate Datetime;
	DECLARE @vGS_adjust_target_date CHAR(1);
	DECLARE @currentTime char(8)
	DECLARE @dateEnd DATETIME
	DECLARE @remainingDays int
	DECLARE @slaDate DATETIME
	DECLARE @iHIST_createdByDescr VARCHAR(200)
	DECLARE @category VARCHAR(50)
	DECLARE @assigned_to_dept VARCHAR(50)
	DECLARE @status VARCHAR(50)
	DECLARE @assigned_to_person VARCHAR(50)
	DECLARE @vNoofUserWorkingDays int;
	DECLARE @vUserTragetDate Datetime;
	DECLARE @userdateEnd DATETIME
	DECLARE @Temp TABLE(std_code int)
	SELECT @iHIST_createdByDescr = dbo.fn_rpt_translateUSER(@ploggedonUser)
	IF @pSLAStartDate is NULL
	
	BEGIN
	  SET @slaDate =GETDATE();
	  SET @pSLAStartDate =GETDATE();
	END
	  ELSE
	BEGIN
	  SET @slaDate =@pSLAStartDate;
	END
	  SET @dateEnd=@slaDate
	  SET @userdateEnd=@slaDate
BEGIN TRY
		SET @pErrorMessage = ''
		IF @pEnqRef LIKE 'ENQ%'
		BEGIN
INSERT INTO @Temp(std_code)
SELECT LTRIM(RTRIM(VALUE)) AS StdCode  FROM string_split(@pStdCode,',')
select * from @TEMP
Print @pStdCode
WHILE (SELECT COUNT(1)FROM @TEMP)>0 BEGIN
SET @pStdCode=(SELECT TOP 1 std_code FROM @TEMP) 
		SELECT @VEnqId =AE_AEID,@status =AE_status,@assigned_to_dept =AE_assignedToDept,@assigned_to_person =AE_assignedToPerson
		FROM BT_ENQUIRY_MASTER  WHERE AE_internalRef = @pEnqRef;
        SELECT @vNoofWorkingDays = GS_noworkingdays,@category=GS_category,@vNoofUserWorkingDays = ISNULL(NULLIF(GS_noUserWorkingDays,0),GS_noworkingdays),
		@vGS_adjust_target_date = GS_adjust_target_date
       FROM MT_GUARANTEEDSTANDARD WHERE GS_ID = @pStdCode;		
        --select @category=GS_category FROM MT_GUARANTEEDSTANDARD WHERE GS_ID = @pStdCode;	
		--SELECT @status =AE_status  FROM BT_ENQUIRY_MASTER  WHERE AE_internalRef = @pEnqRef;
		--SELECT @assigned_to_dept =AE_assignedToDept  FROM BT_ENQUIRY_MASTER  WHERE AE_internalRef = @pEnqRef;
		--SELECT @assigned_to_person =AE_assignedToPerson  FROM BT_ENQUIRY_MASTER  WHERE AE_internalRef = @pEnqRef;
		--SELECT @vNoofUserWorkingDays = ISNULL(NULLIF(GS_noUserWorkingDays,0),GS_noworkingdays) FROM MT_GUARANTEEDSTANDARD WHERE GS_ID = @pStdCode;	

		SET @vTragetDate = @slaDate+@vNoofWorkingDays--GETDATE replced with prameter
		--SELECT @vGS_adjust_target_date = GS_adjust_target_date FROM MT_GUARANTEEDSTANDARD WHERE GS_ID = @pStdCode
		SET @vUserTragetDate = @slaDate+@vNoofUserWorkingDays--GETDATE replced with prameter

		SET @dateEnd = @slaDate;
		SET @currentTime = RIGHT('0' + CAST(DATEPART(hour, @slaDate) as varchar), 2) + ':' + RIGHT('0' + CAST(DATEPART(minute,@slaDate) as varchar), 2) + ':' 
						+ RIGHT('0' + CAST(DATEPART(second, @slaDate) as varchar), 2); -- getdate to sladtae
		SET @userdateEnd = @slaDate;
			
	IF @currentTime > '17:00:00'
	begin
		SET @vNoofWorkingDays=@vNoofWorkingDays+1;
		SET @vNoofUserWorkingDays=@vNoofUserWorkingDays+1;
	end
	IF datepart(dw,@pSLAStartDate ) = 1 
		BEGIN
		SET	@vNoofWorkingDays=@vNoofWorkingDays+1-- if sunday then start date shifted to monday
		SET	@vNoofUserWorkingDays=@vNoofUserWorkingDays+1-- if sunday then start date shifted to monday
		END
	ELSE IF datepart(dw,@pSLAStartDate ) = 7
		BEGIN
			SET	@vNoofWorkingDays=@vNoofWorkingDays+1 -- if saturday then start date shifted to monday
			SET	@vNoofUserWorkingDays=@vNoofUserWorkingDays+1 -- if saturday then start date shifted to monday
		END
	ELSE IF EXISTS (SELECT ExcludedDate FROM MT_HOLIDAY_CALENDER WHERE datediff(d, ExcludedDate, @pSLAStartDate)= 0)
		BEGIN
			SET	@vNoofWorkingDays=@vNoofWorkingDays+1 -- if bank holidy then start date shifted to next day
			SET	@vNoofUserWorkingDays=@vNoofUserWorkingDays+1 -- if bank holidy then start date shifted to next day
		END

	WHILE @vNoofWorkingDays>0
	BEGIN
		SET @dateEnd = DATEADD(d, 1, @dateEnd)
		IF datepart(dw,@dateEnd ) = 1 or datepart(dw,@dateEnd ) = 7
		BEGIN
			print 'weekend'
		END
		ELSE IF EXISTS (SELECT ExcludedDate FROM MT_HOLIDAY_CALENDER WHERE datediff(d, ExcludedDate, @dateEnd)= 0)
		BEGIN
			print 'weekend'
		END
		ELSE
		BEGIN
			SET @vNoofWorkingDays=@vNoofWorkingDays-1;
		END 
	END

	WHILE @vNoofUserWorkingDays>0
	BEGIN
		SET @userdateEnd = DATEADD(d, 1, @userdateEnd)
		IF datepart(dw,@userdateEnd ) = 1 or datepart(dw,@userdateEnd ) = 7
		BEGIN
			print 'weekend'
		END
		ELSE IF EXISTS (SELECT ExcludedDate FROM MT_HOLIDAY_CALENDER WHERE datediff(d, ExcludedDate, @userdateEnd)= 0)
		BEGIN
			print 'weekend'
		END
		ELSE
		BEGIN
			SET @vNoofUserWorkingDays=@vNoofUserWorkingDays-1;
		END 
	END
		
     SELECT @vMaxStdId =  MAX(STA_ID)+1 FROM [BT_ACT_STANDARDS] WITH (READUNCOMMITTED); -- QPID_OPT V4-03
	 SET  @pErrorMessage=CONVERT(varchar(20),@vMaxStdId) 
Print @pStdCode
		IF @vGS_adjust_target_date='N'
		BEGIN
		INSERT INTO [dbo].[BT_ACT_STANDARDS]
           ([STA_ID],[STA_AEID],[STA_STD_ID],[sta_sla_date] ,[sta_target_date]
           ,[sta_created_by],[sta_created_date],[sta_updated_by],[sta_updated_date],sta_created_from,sta_updated_from,
		   [sta_user_target_date])
		SELECT @vMaxStdId,@VEnqId,@pStdCode,@pSLAStartDate,@dateEnd,@ploggedonUser,GETDATE(), --GETDATE replced with prameter
		@ploggedonUser,GETDATE(),2,2,@userdateEnd;

		SET @pGS_adjust_target_date = @vGS_adjust_target_date
            EXEC [sp_ACT_addHistory]  @VEnqId,@pEnqRef,1,'datetime','SLA Date','BT_ACT_STANDARDS','sta_sla_date',0,'','Standard Added',@pSLAStartDate,@ploggedonUser,@iHIST_createdByDescr,@vMaxStdId
			EXEC [sp_ACT_addHistory]  @VEnqId,@pEnqRef,1,'datetime','Target Date','BT_ACT_STANDARDS','sta_target_date',0,'','Standard Added',@dateEnd,@ploggedonUser,@iHIST_createdByDescr,@vMaxStdId
		END

		ELSE
		BEGIN
		INSERT INTO [dbo].[BT_ACT_STANDARDS]
           ([STA_ID],[STA_AEID],[STA_STD_ID],[sta_sla_date] ,[sta_target_date]
           ,[sta_created_by],[sta_created_date],[sta_updated_by],[sta_updated_date],sta_created_from,sta_updated_from,
		   [sta_user_target_date])
		SELECT @vMaxStdId,@VEnqId,@pStdCode,@pSLAStartDate,NULL,@ploggedonUser,GETDATE(), --GETDATE replced with prameter
		@ploggedonUser,GETDATE(),2,2,NULL;

		SET @pGS_adjust_target_date = @vGS_adjust_target_date
     EXEC [sp_ACT_addHistory]  @VEnqId,@pEnqRef,1,'datetime','SLA Date','BT_ACT_STANDARDS','sta_sla_date',0,'','Standard Added',@pSLAStartDate,@ploggedonUser,@iHIST_createdByDescr,@vMaxStdId
			
		END
		UPDATE BT_ENQUIRY_MASTER  set AE_category=@category,AE_lastUpdatedBy=@ploggedonUser,AE_lastUpdated=GETDATE() WHERE AE_internalRef = @pEnqRef;
		EXEC sp_ACT_addHIST_editEnquiry @VEnqId, @ploggedonuser, @assigned_to_dept, @assigned_to_person, @status, @category
		DELETE FROM @Temp where std_code=@pStdCode
		END
		END



		IF @pEnqRef LIKE 'CTK%'
		BEGIN
		--SELECT @VEnqId =AE_AEID FROM BT_CTK_HEADER WHERE AE_internalRef = @pEnqRef;
		SELECT @VEnqId =AE_AEID,@pEnqRef=AE_internalRef FROM  BT_PROJ_U_HEADER
		--BT_CTK_HEADER 
		WHERE AE_AEID =Substring(@pEnqRef,4,len(@pEnqRef)) ;--Changed on 18/12/2020;
		SELECT @vNoofWorkingDays = GS_noworkingdays FROM MT_GUARANTEEDSTANDARD WHERE GS_ID = @pStdCode;		
        SELECT @category=GS_category FROM MT_GUARANTEEDSTANDARD WHERE GS_ID = @pStdCode;
		
		SET @vTragetDate = @slaDate+@vNoofWorkingDays--GETDATE replced with prameter
		SELECT @vGS_adjust_target_date = GS_adjust_target_date FROM MT_GUARANTEEDSTANDARD WHERE GS_ID = @pStdCode
		

		SET @dateEnd = @slaDate;
			
	SET @currentTime = RIGHT('0' + CAST(DATEPART(hour, @slaDate) as varchar), 2) + ':' + RIGHT('0' + CAST(DATEPART(minute,@slaDate) as varchar), 2) + ':' 
						+ RIGHT('0' + CAST(DATEPART(second, @slaDate) as varchar), 2); -- getdate to sladtae
							
	IF @currentTime > '17:00:00'
	begin
		SET @vNoofWorkingDays=@vNoofWorkingDays+1;
	end
	IF datepart(dw,@pSLAStartDate ) = 1 
		BEGIN
		SET	@vNoofWorkingDays=@vNoofWorkingDays+1-- if sunday then start date shifted to monday
		END
	ELSE IF datepart(dw,@pSLAStartDate ) = 7
		BEGIN
			SET	@vNoofWorkingDays=@vNoofWorkingDays+1 -- if saturday then start date shifted to monday
		END
	ELSE IF EXISTS (SELECT ExcludedDate FROM MT_HOLIDAY_CALENDER WHERE datediff(d, ExcludedDate, @pSLAStartDate)= 0)
		BEGIN
			SET	@vNoofWorkingDays=@vNoofWorkingDays+1 -- if bank holidy then start date shifted to next day
		END

	WHILE @vNoofWorkingDays>0
	BEGIN
		SET @dateEnd = DATEADD(d, 1, @dateEnd)
		IF datepart(dw,@dateEnd ) = 1 or datepart(dw,@dateEnd ) = 7
		BEGIN
			print 'weekend'
		END
		ELSE IF EXISTS (SELECT ExcludedDate FROM MT_HOLIDAY_CALENDER WHERE datediff(d, ExcludedDate, @dateEnd)= 0)
		BEGIN
			print 'weekend'
		END
		ELSE
		BEGIN
			SET @vNoofWorkingDays=@vNoofWorkingDays-1;
		END 
	END
		

		SELECT @vMaxStdId =  MAX(STA_ID)+1 FROM [BT_ACT_STANDARDS] WITH (READUNCOMMITTED); -- QPID_OPT V4-03
	 SET  @pErrorMessage=CONVERT(varchar(20),@vMaxStdId) 

		IF @vGS_adjust_target_date='N'
		BEGIN
		INSERT INTO [dbo].[BT_ACT_STANDARDS]
           ([STA_ID],[STA_AEID],[STA_STD_ID],[sta_sla_date] ,[sta_target_date]
           ,[sta_created_by],[sta_created_date],[sta_updated_by],[sta_updated_date],sta_created_from,sta_updated_from)
		SELECT @vMaxStdId,@VEnqId,@pStdCode,@pSLAStartDate,@dateEnd,@ploggedonUser,GETDATE(), --GETDATE replced with prameter
		@ploggedonUser,GETDATE(),2,2;

		SET @pGS_adjust_target_date = @vGS_adjust_target_date

		
			EXEC [sp_ACT_addHistory]  @VEnqId,@pEnqRef,1,'datetime','SLA Date','BT_ACT_STANDARDS','sta_sla_date',0,'','Standard Added',@pSLAStartDate,@ploggedonUser,@iHIST_createdByDescr,@vMaxStdId
			EXEC [sp_ACT_addHistory]  @VEnqId,@pEnqRef,1,'datetime','Target Date','BT_ACT_STANDARDS','sta_target_date',0,'','Standard Added',@dateEnd,@ploggedonUser,@iHIST_createdByDescr,@vMaxStdId
		END
		ELSE
		BEGIN
		INSERT INTO [dbo].[BT_ACT_STANDARDS]
           ([STA_ID],[STA_AEID],[STA_STD_ID],[sta_sla_date] ,[sta_target_date]
           ,[sta_created_by],[sta_created_date],[sta_updated_by],[sta_updated_date],sta_created_from,sta_updated_from)
		SELECT @vMaxStdId,@VEnqId,@pStdCode,@pSLAStartDate,NULL,@ploggedonUser,GETDATE(), --GETDATE replced with prameter
		@ploggedonUser,GETDATE(),2,2;

		SET @pGS_adjust_target_date = @vGS_adjust_target_date

		
			EXEC [sp_ACT_addHistory]  @VEnqId,@pEnqRef,1,'datetime','SLA Date','BT_ACT_STANDARDS','sta_sla_date',0,'','Standard Added',@pSLAStartDate,@ploggedonUser,@iHIST_createdByDescr,@vMaxStdId
			
		END
		print 'Test update CTK'
		print @category
		-- UPDATE BT_PROJ_U_HEADER  set AE_category=@category,AE_lastUpdatedBy=@ploggedonUser,AE_lastUpdated=GETDATE() WHERE AE_internalRef = @pEnqRef;
		END
		RETURN 0
END TRY

BEGIN CATCH
		SELECT @pErrorMessage='Error Code: ' + CAST (ERROR_NUMBER() AS VARCHAR(10)) + ', Error: ' + ERROR_MESSAGE()
		RETURN 1
END CATCH	
END 

GO
SET NOEXEC OFF;
GO
IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.SP_ADD_STANDARDS')) LIKE N'%QPID_OPT V4-03%'
    PRINT 'DEPLOYED: V4-03 is live on SP_ADD_STANDARDS.';
ELSE
    RAISERROR('NOT DEPLOYED: V4-03 is not live on SP_ADD_STANDARDS (see the REFUSED message above).', 16, 1);
GO
