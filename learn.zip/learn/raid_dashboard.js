/*
  raid_dashboard.js - the executive dashboard at the top of the Delivery
  RAID Log (templates/risk_register/index.html).

  Reads one JSON feed (#rdData, built by service.dashboard_entries) and draws:
    * KPI deck            open / red / overdue / open issues / avg days to close
    * risk heatmap        open scored risks on a 5 x 5 probability x impact
                          grid; a cell lists its risks, a risk opens its detail
    * RAID log by RAG     stacked bars; a bar opens that log's table
    * open vs closed      per period: logged (bars), open at period end and
                          cumulative closed (lines)
    * accountable party   open entries per party, stacked by RAG
  The All / Project / BAU switch re-cuts all of it in the browser.

  Colour means RAG everywhere (Critical / High red, Medium amber, Low green).
  Charts use the locally served Plotly (static/js/plotly-3.3.0.min.js) - the
  production server has no internet, so no CDN.

  Plotly traps carried over from other modules:
    * never clear a node and then Plotly.react into it - react on a live plot,
      otherwise empty it and newPlot (plotInto below)
    * horizontal-bar category labels clip under automargin - the party chart
      sets its own left margin
*/
(function () {
  'use strict';

  var feedEl = document.getElementById('rdData');
  if (!feedEl || !window.Plotly) { return; }
  var DATA = JSON.parse(feedEl.textContent);
  var ENTRIES = DATA.entries || [];

  var C = {
    red: '#d64545', amber: '#e3a21a', green: '#2f9e6b',
    open: '#3157c8', closed: '#2f9e6b', fresh: '#cdd5e1',
    ink: '#1d293d', muted: '#5b6478', grid: '#eceff4', line: '#d7dee7'
  };
  var RAGS = ['Red', 'Amber', 'Green'];
  var RAG_COLOUR = { Red: C.red, Amber: C.amber, Green: C.green };
  var KIND_LABEL = {};
  (DATA.kinds || []).forEach(function (k) { KIND_LABEL[k.key] = k.label; });
  var FONT = (getComputedStyle(document.body).fontFamily || 'sans-serif');
  var STORE = 'appassist.raidDashboard.ws';

  var state = { ws: 'all', cell: null };
  try { var saved = window.localStorage.getItem(STORE); if (saved) { state.ws = saved; } } catch (e) { /* storage blocked */ }

  // ------------------------------------------------------------- helpers
  function $(id) { return document.getElementById(id); }
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) { n.className = cls; }
    if (text !== undefined && text !== null) { n.textContent = String(text); }
    return n;
  }
  function filtered() {
    if (state.ws === 'all') { return ENTRIES; }
    return ENTRIES.filter(function (e) { return e.scope === state.ws; });
  }
  function plural(n, one, many) { return n + ' ' + (n === 1 ? one : (many || one + 's')); }
  function avg(list) {
    if (!list.length) { return null; }
    var s = 0; list.forEach(function (v) { s += v; });
    return Math.round((s / list.length) * 10) / 10;
  }
  function baseLayout(extra) {
    var layout = {
      height: 270,
      margin: { l: 40, r: 14, t: 8, b: 34 },
      paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
      font: { family: FONT, size: 12, color: C.muted },
      showlegend: false,
      hoverlabel: { bgcolor: '#ffffff', bordercolor: C.line, font: { family: FONT, size: 12, color: C.ink } },
      xaxis: { showgrid: false, zeroline: false, linecolor: C.line, ticks: '', fixedrange: true },
      yaxis: { gridcolor: C.grid, zeroline: false, rangemode: 'tozero', tickformat: 'd', fixedrange: true }
    };
    Object.keys(extra || {}).forEach(function (k) { layout[k] = extra[k]; });
    return layout;
  }
  var CONFIG = { displayModeBar: false, responsive: true };
  function plotInto(node, traces, layout) {
    if (node.classList.contains('js-plotly-plot')) {
      return Plotly.react(node, traces, layout, CONFIG);
    }
    node.innerHTML = '';
    return Plotly.newPlot(node, traces, layout, CONFIG);
  }
  function empty(node, message) {
    if (node.classList.contains('js-plotly-plot')) { Plotly.purge(node); }
    node.innerHTML = '';
    var box = el('div', 'rd-empty');
    box.appendChild(el('i', 'fas fa-circle-check'));
    box.appendChild(el('span', null, message));
    node.appendChild(box);
  }
  function countTicks(max) { return max <= 6 ? 1 : null; }
  // Phone-width panels get short category labels and fewer date ticks.
  function narrow() { return window.innerWidth < 600; }

  // Open the table row behind an entry (switches scope + log tab first).
  function openEntry(key) {
    var parts = key.split('-');
    if (window.rrShow) { window.rrShow(parts[0], parts[1]); }
    var row = document.querySelector('tr.rr-row[data-key="' + key + '"]');
    if (row) { row.click(); }
  }

  // ---------------------------------------------------------------- KPIs
  function renderKpis(items) {
    var open = items.filter(function (e) { return e.open; });
    var red = open.filter(function (e) { return e.rag === 'Red'; });
    var issues = open.filter(function (e) { return e.kind === 'issue'; });
    var closedAges = items.filter(function (e) { return !e.open && e.resolved && e.age !== null; })
                          .map(function (e) { return e.age; });
    $('rdKpiOpen').textContent = open.length;
    $('rdKpiOpenSub').textContent = 'of ' + plural(items.length, 'entry', 'entries') + ' logged';
    $('rdKpiRed').textContent = red.length;
    $('rdKpiRedSub').textContent = open.length ? Math.round(red.length / open.length * 100) + '% of open' : 'nothing open';
    $('rdKpiOverdue').textContent = open.filter(function (e) { return e.overdue; }).length;
    $('rdKpiIssues').textContent = issues.length;
    var odIssues = issues.filter(function (e) { return e.overdue; }).length;
    $('rdKpiIssuesSub').textContent = odIssues ? odIssues + ' overdue' : 'none overdue';
    var a = avg(closedAges);
    $('rdKpiClose').textContent = a === null ? '-' : a;
    $('rdKpiCloseSub').textContent = closedAges.length ? 'across ' + plural(closedAges.length, 'closed entry', 'closed entries') : 'nothing closed yet';
  }

  // ------------------------------------------------------------- heatmap
  function band(score) {
    if (score >= 15) { return 'crit'; }
    if (score >= 10) { return 'red'; }
    if (score >= 5) { return 'amber'; }
    return 'green';
  }
  function buildHeatmapAxes() {
    var y = $('rdHmY'), x = $('rdHmX');
    y.innerHTML = ''; x.innerHTML = '';
    [5, 4, 3, 2, 1].forEach(function (i) {
      var s = el('span', 'rd-hm-axlbl');
      s.appendChild(el('b', null, i)); s.appendChild(document.createTextNode(' ' + (DATA.impact[i] || '')));
      y.appendChild(s);
    });
    [1, 2, 3, 4, 5].forEach(function (p) {
      var s = el('span', 'rd-hm-axlbl');
      s.appendChild(el('b', null, p)); s.appendChild(document.createTextNode(' ' + (DATA.prob[p] || '')));
      x.appendChild(s);
    });
  }
  function renderHeatmap(items) {
    var risks = items.filter(function (e) { return e.kind === 'risk' && e.open; });
    var scored = risks.filter(function (e) { return e.p && e.i; });
    var map = {};
    scored.forEach(function (e) { var k = e.i + '-' + e.p; (map[k] = map[k] || []).push(e); });
    if (state.cell && !map[state.cell]) { state.cell = null; }

    var grid = $('rdHmGrid');
    grid.innerHTML = '';
    [5, 4, 3, 2, 1].forEach(function (i) {
      [1, 2, 3, 4, 5].forEach(function (p) {
        var key = i + '-' + p, list = map[key] || [];
        var cell = el('button', 'rd-hm-cell b-' + band(i * p));
        cell.type = 'button';
        cell.setAttribute('role', 'gridcell');
        cell.setAttribute('aria-label', 'Impact ' + i + ', probability ' + p + ' (score ' + (i * p) + '): ' + plural(list.length, 'open risk'));
        cell.title = 'Score ' + (i * p) + ' - ' + plural(list.length, 'open risk');
        if (list.length) {
          cell.classList.add('has-items');
          cell.appendChild(el('span', 'rd-hm-badge', list.length));
          cell.addEventListener('click', function () {
            state.cell = state.cell === key ? null : key;
            renderHeatmap(filtered());
          });
        } else {
          cell.disabled = true;
          cell.appendChild(el('span', 'rd-hm-dot'));
        }
        if (state.cell === key) { cell.classList.add('is-selected'); }
        grid.appendChild(cell);
      });
    });

    var unscored = risks.length - scored.length;
    $('rdHmNote').textContent = !risks.length ? 'No open risks in this view.'
      : plural(scored.length, 'open risk') + ' plotted' + (unscored ? '; ' + unscored + ' not yet scored (no probability x impact).' : '.');

    var box = $('rdInspect'), list = $('rdInspectList');
    if (!state.cell) { box.hidden = true; list.innerHTML = ''; return; }
    var items2 = map[state.cell], ip = state.cell.split('-');
    $('rdInspectTitle').textContent = 'Impact ' + ip[0] + ' x probability ' + ip[1] + ' - ' + plural(items2.length, 'risk');
    list.innerHTML = '';
    items2.forEach(function (e) {
      var li = el('li');
      var btn = el('button', 'rd-inspect-row');
      btn.type = 'button';
      var main = el('span', 'rd-inspect-main');
      main.appendChild(el('span', 'rd-inspect-title', e.title));
      main.appendChild(el('span', 'rd-inspect-ctx', (e.scope === 'bau' ? 'BAU' : 'Project') + (e.context ? ' - ' + e.context : '')));
      var meta = el('span', 'rd-inspect-meta');
      meta.appendChild(el('span', 'rd-tag t-' + e.rag.toLowerCase(), e.sev));
      if (e.overdue) { meta.appendChild(el('span', 'rd-tag t-overdue', 'Overdue')); }
      if (e.owner) { meta.appendChild(el('span', 'rd-inspect-owner', e.owner)); }
      btn.appendChild(main); btn.appendChild(meta);
      btn.addEventListener('click', function () { openEntry(e.key); });
      li.appendChild(btn);
      list.appendChild(li);
    });
    box.hidden = false;
  }
  $('rdInspectClear').addEventListener('click', function () { state.cell = null; renderHeatmap(filtered()); });

  // --------------------------------------------------- RAID log by RAG
  function renderKind(items) {
    var node = $('rdChartKind');
    var open = items.filter(function (e) { return e.open; });
    if (!open.length) { empty(node, 'No open entries in this view.'); return; }
    var kinds = DATA.kinds.map(function (k) { return k.key; });
    var SHORT = { risk: 'Risks', assumption: 'Assump.', issue: 'Issues', dependency: 'Depend.' };
    var labels = kinds.map(function (k) { return narrow() ? SHORT[k] : KIND_LABEL[k]; });
    var max = 0;
    var totals = kinds.map(function (k) {
      var n = open.filter(function (e) { return e.kind === k; }).length;
      max = Math.max(max, n); return n;
    });
    var traces = RAGS.map(function (rag) {
      return {
        type: 'bar', name: rag, x: labels,
        y: kinds.map(function (k) { return open.filter(function (e) { return e.kind === k && e.rag === rag; }).length; }),
        marker: { color: RAG_COLOUR[rag], line: { color: '#ffffff', width: 1.5 } },
        hovertemplate: '<b>%{x}</b><br>' + rag + ': %{y}<extra></extra>'
      };
    });
    var layout = baseLayout({
      barmode: 'stack', bargap: 0.45, barcornerradius: 6,
      annotations: labels.map(function (l, ix) {
        return { x: l, y: totals[ix], text: '<b>' + totals[ix] + '</b>', showarrow: false, yanchor: 'bottom', yshift: 4,
                 font: { family: FONT, size: 12, color: C.ink } };
      })
    });
    layout.yaxis.dtick = countTicks(max);
    layout.yaxis.range = [0, Math.max(1, max) * 1.18];
    layout.xaxis.tickfont = { size: narrow() ? 11.5 : 12.5, color: C.ink };
    layout.xaxis.tickangle = 0;
    plotInto(node, traces, layout).then(function () {
      if (node.dataset.bound) { return; }
      node.dataset.bound = '1';
      node.on('plotly_click', function (ev) {
        var label = ev.points && ev.points[0] && ev.points[0].x;
        var kind = kinds[labels.indexOf(label)];
        if (!kind) { return; }
        var scope = state.ws === 'all'
          ? (ENTRIES.filter(function (e) { return e.open && e.kind === kind && e.scope === 'bau'; }).length >
             ENTRIES.filter(function (e) { return e.open && e.kind === kind && e.scope === 'project'; }).length ? 'bau' : 'project')
          : state.ws;
        if (window.rrShow) { window.rrShow(scope, kind); }
        var t = $('rrTables'); if (t) { t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
      });
    });
    node.style.cursor = 'pointer';
  }

  // --------------------------------------------------------------- trend
  function iso(d) {
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function parseIso(s) { var p = s.split('-'); return new Date(+p[0], +p[1] - 1, +p[2]); }
  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function buckets() {
    var start = parseIso(DATA.start), end = parseIso(DATA.end), out = [];
    var days = Math.round((end - start) / 86400000);
    if (days <= 120) {
      var s = new Date(start);
      while (s <= end) {
        var e = new Date(s); e.setDate(e.getDate() + 6);
        if (e > end) { e = new Date(end); }
        out.push({ from: iso(s), to: iso(e), label: s.getDate() + ' ' + MONTHS[s.getMonth()] });
        s = new Date(e); s.setDate(s.getDate() + 1);
      }
      return { list: out, unit: 'week' };
    }
    var m = new Date(start.getFullYear(), start.getMonth(), 1);
    while (m <= end) {
      var last = new Date(m.getFullYear(), m.getMonth() + 1, 0);
      var from = m < start ? start : m;
      out.push({ from: iso(from), to: iso(last > end ? end : last),
                 label: MONTHS[m.getMonth()] + ' ' + String(m.getFullYear()).slice(2) });
      m = new Date(m.getFullYear(), m.getMonth() + 1, 1);
    }
    return { list: out, unit: 'month' };
  }
  function renderTrend(items) {
    var node = $('rdChartTrend');
    var dated = items.filter(function (e) { return e.identified && (e.open || e.resolved); });
    if (!dated.length) { empty(node, 'Nothing logged in this view.'); return; }
    var b = buckets(), labels = [], fresh = [], open = [], closed = [], max = 0;
    b.list.forEach(function (k) {
      labels.push(k.label);
      fresh.push(dated.filter(function (e) { return e.identified >= k.from && e.identified <= k.to; }).length);
      var o = dated.filter(function (e) { return e.identified <= k.to && (!e.resolved || e.resolved > k.to); }).length;
      var c = dated.filter(function (e) { return e.resolved && e.resolved <= k.to; }).length;
      open.push(o); closed.push(c);
      max = Math.max(max, o, c, fresh[fresh.length - 1]);
    });
    $('rdTrendSub').textContent = 'Per ' + b.unit + ': entries still open at the end of it, the running total closed, and how many were logged.';
    var line = function (name, ys, colour) {
      return { type: 'scatter', mode: 'lines+markers', name: name, x: labels, y: ys,
               line: { color: colour, width: 2.5, shape: 'spline', smoothing: 0.6 },
               marker: { size: 7, color: '#ffffff', line: { color: colour, width: 2.2 } },
               hovertemplate: name + ': %{y}<extra></extra>' };
    };
    var traces = [
      { type: 'bar', name: 'Logged', x: labels, y: fresh, marker: { color: C.fresh },
        hovertemplate: 'Logged: %{y}<extra></extra>' },
      line('Open', open, C.open),
      line('Closed (cumulative)', closed, C.closed)
    ];
    var layout = baseLayout({ bargap: 0.55, barcornerradius: 4, hovermode: 'x unified' });
    layout.yaxis.dtick = countTicks(max);
    layout.yaxis.range = [0, Math.max(1, max) * 1.15];
    layout.xaxis.tickangle = 0;
    var maxTicks = narrow() ? 4 : 8;
    if (labels.length > maxTicks) { layout.xaxis.nticks = maxTicks; }
    plotInto(node, traces, layout);
  }

  // ---------------------------------------------------- accountable party
  function renderParty(items) {
    var node = $('rdChartParty');
    var open = items.filter(function (e) { return e.open; });
    if (!open.length) { empty(node, 'No open entries in this view.'); return; }
    var parties = DATA.parties.filter(function (p) { return open.some(function (e) { return e.party === p; }); });
    var totals = parties.map(function (p) { return open.filter(function (e) { return e.party === p; }).length; });
    var ages = parties.map(function (p) {
      var a = avg(open.filter(function (e) { return e.party === p && e.age !== null; }).map(function (e) { return e.age; }));
      return a === null ? '-' : a + ' days';
    });
    var max = Math.max.apply(null, totals.concat([1]));
    var traces = RAGS.map(function (rag) {
      return {
        type: 'bar', orientation: 'h', name: rag, y: parties,
        x: parties.map(function (p) { return open.filter(function (e) { return e.party === p && e.rag === rag; }).length; }),
        customdata: ages,
        marker: { color: RAG_COLOUR[rag], line: { color: '#ffffff', width: 1.5 } },
        hovertemplate: '<b>%{y}</b><br>' + rag + ': %{x}<br>Avg age open: %{customdata}<extra></extra>'
      };
    });
    var layout = baseLayout({
      barmode: 'stack', bargap: 0.42, barcornerradius: 6,
      height: Math.max(220, 64 + parties.length * 44),
      margin: { l: 132, r: 34, t: 6, b: 30 },
      annotations: parties.map(function (p, ix) {
        return { x: totals[ix], y: p, text: '<b>' + totals[ix] + '</b>', showarrow: false, xanchor: 'left', xshift: 6,
                 font: { family: FONT, size: 12, color: C.ink } };
      })
    });
    layout.xaxis = { showgrid: true, gridcolor: C.grid, zeroline: false, tickformat: 'd', fixedrange: true,
                     dtick: countTicks(max), range: [0, max * 1.15] };
    layout.yaxis = { autorange: 'reversed', showgrid: false, zeroline: false, fixedrange: true,
                     ticks: '', ticksuffix: '  ', tickfont: { size: 12.5, color: C.ink } };
    plotInto(node, traces, layout);
  }

  // --------------------------------------------------------------- render
  function render() {
    var items = filtered();
    document.querySelectorAll('.rd-seg button').forEach(function (b) {
      var on = b.getAttribute('data-ws') === state.ws;
      b.classList.toggle('is-on', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    renderKpis(items);
    renderHeatmap(items);
    renderKind(items);
    renderTrend(items);
    renderParty(items);
  }
  document.querySelectorAll('.rd-seg button').forEach(function (b) {
    b.addEventListener('click', function () {
      state.ws = b.getAttribute('data-ws');
      state.cell = null;
      try { window.localStorage.setItem(STORE, state.ws); } catch (e) { /* storage blocked */ }
      render();
    });
  });
  if (['all', 'project', 'bau'].indexOf(state.ws) < 0) { state.ws = 'all'; }
  buildHeatmapAxes();
  render();
  // Redraw only when the width crosses the phone threshold (labels change);
  // Plotly's own `responsive` handles every other resize.
  var wasNarrow = narrow(), resizeTimer = null;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () {
      if (narrow() !== wasNarrow) { wasNarrow = narrow(); render(); }
    }, 150);
  });
})();
