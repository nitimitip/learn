USE [QPID_PROD]
GO
/******************************************************************************
  RECOMMENDED INDEX - NOT EXECUTED - TEST ON UAT BEFORE DEPLOYMENT
  Table : dbo.BT_Message (heap; 72,381 rows in the October table-size.xlsx;
          one full scan = about 2,078 reads in the November stats)
  Index : IX_BT_Message_ID, UNIQUE ON (ID)

  WHY   : usp_QMS_FinalDataLoad_CRM_SmallWork updates BT_Message by ID:
          - Message_Status = 'I', before the transaction starts
          - Message_Status = 'P', inside the long transaction, just before COMMIT
          - Message_Status = 'F', in the CATCH block, after the rollback
          With no index on ID these likely scan the heap. If the 'P' update waits
          on another session's locked row, SmallWork keeps all of its locks while
          it waits. Inferred from the code, not caught live. Phase-1 file 25
          called this scan small, judging by reads only.

  DESIGN: - Nonclustered, so the heap itself is not rebuilt. Converting the heap
            to a clustered table is a separate decision.
          - @btMsgID is INT, the same type as ID.
          - UNIQUE: ID is an IDENTITY column with no constraint, so duplicates are
            very unlikely but not impossible. The script checks first and skips
            if it finds any.

  RESULTS: no change. Only single-row updates by ID use this index.

  COST  : about 1-2 MB (estimate). ID never changes, so only inserts maintain it.

  NUMBER: 64 stays held for the SmallWork candidate noted in V4-02. Next free
          number after this file: 67.

  UNDO  : DROP INDEX IX_BT_Message_ID ON dbo.BT_Message;
******************************************************************************/
IF EXISTS (SELECT 1
           FROM sys.indexes i
           JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
           JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
           WHERE i.object_id = OBJECT_ID('dbo.BT_Message')
             AND ic.key_ordinal = 1 AND c.name = 'ID')
    PRINT 'SKIPPED: an index leading on ID already exists.';
ELSE IF EXISTS (SELECT ID FROM dbo.BT_Message WITH (NOLOCK)
                GROUP BY ID HAVING COUNT(*) > 1)
    PRINT 'SKIPPED: duplicate ID values found. Send them for review.';
ELSE
BEGIN
    -- ONLINE = ON requires Enterprise/Developer/Azure; remove on Standard.
    CREATE UNIQUE NONCLUSTERED INDEX IX_BT_Message_ID
        ON dbo.BT_Message (ID)
        WITH (ONLINE = ON, SORT_IN_TEMPDB = ON, FILLFACTOR = 90);
    PRINT 'CREATED: IX_BT_Message_ID.';
END
GO
