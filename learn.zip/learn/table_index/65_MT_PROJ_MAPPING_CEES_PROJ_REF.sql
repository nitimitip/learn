USE [QPID_PROD]
GO
/******************************************************************************
  V4-05 - RECOMMENDED INDEX - NOT EXECUTED - TEST ON UAT BEFORE DEPLOYMENT
  Table : dbo.MT_PROJ_MAPPING (335,981 rows; clustered index about 2.2k pages)
  Index : IX_MT_PROJ_MAPPING_CEES_PROJ_REF ON (CEES_PROJ_REF) INCLUDE (UKD_PROJ_REF)
  WHY   : usp_GetActivityBasedOnTypeAndName (Project branch) filters this table
          on CEES_PROJ_REF on every call. Index 09 covers only UKD_PROJ_REF, so
          this filter scans the table. SP_HAS_CEES_PROJECT and
          usp_FetchActualCFSCostForCEES filter on the same column.
  ORDER : within one key value the seek returns rows in MAP_ID order, the same
          order as a serial clustered scan, so "SELECT @v = col" keeps the same
          last row if a ref has duplicates (V4-05.2 lists any).
  WRITES: about 1,159 inserts in the baseline window: negligible.
  NUMBER: 64 stays held for the SmallWork candidate noted in V4-02.
******************************************************************************/
IF EXISTS (SELECT 1
           FROM sys.indexes i
           JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
           JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
           WHERE i.object_id = OBJECT_ID('dbo.MT_PROJ_MAPPING')
             AND ic.key_ordinal = 1 AND c.name = 'CEES_PROJ_REF')
    PRINT 'SKIPPED: an index leading on CEES_PROJ_REF already exists.';
ELSE
BEGIN
    -- ONLINE = ON requires Enterprise/Developer/Azure; remove on Standard.
    CREATE NONCLUSTERED INDEX IX_MT_PROJ_MAPPING_CEES_PROJ_REF
        ON dbo.MT_PROJ_MAPPING (CEES_PROJ_REF)
        INCLUDE (UKD_PROJ_REF)
        WITH (ONLINE = ON, SORT_IN_TEMPDB = ON, FILLFACTOR = 95);
    PRINT 'CREATED: IX_MT_PROJ_MAPPING_CEES_PROJ_REF.';
END
GO
