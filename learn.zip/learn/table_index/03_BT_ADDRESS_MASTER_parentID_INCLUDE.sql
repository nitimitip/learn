USE [QPID_PROD]
GO
/******************************************************************************
  V4-07 - RECOMMENDED INDEX CHANGE - NOT EXECUTED - TEST ON UAT BEFORE DEPLOYMENT
  Table : dbo.BT_ADDRESS_MASTER (6,279,178 rows at the October review)
  Index : IX_BT_ADDRESS_MASTER_parentID (parentID) INCLUDE (addressUsage, deleted)
  WHY   : usp_GetDropDownAddressByID filters on parentID, deleted and addressUsage.
          The index has only parentID, so each address of the customer needs a key
          lookup. Production max is 9.1M reads per call, 127 x a full table scan,
          so it must be per-row work. V4-07.1 checks this before deployment.
  ORDER : the key stays (parentID), so rows still come back in ADDRESS_ID order
          within a parent. The same 500 rows are returned by TOP 500 on this path.
  SIZE  : about 40-50 MB on top of 130.74 MB (estimate).
  WRITES: updates of addressUsage or deleted now also touch this index.
  RUN   : outside peak hours. This is a busy table. ONLINE = ON needs Enterprise,
          Developer or Azure. WITHOUT it the rebuild blocks the table: on Standard,
          do it in a maintenance window only.
  NUMBER: this is the optional change noted in phase-1 file 03. It takes no new number.
  UNDO  : the same CREATE without the INCLUDE clause, with DROP_EXISTING = ON.
******************************************************************************/
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID('dbo.BT_ADDRESS_MASTER')
                 AND name = 'IX_BT_ADDRESS_MASTER_parentID')
    RAISERROR('REFUSED: IX_BT_ADDRESS_MASTER_parentID does not exist. Nothing changed.', 16, 1);
ELSE IF EXISTS (SELECT 1
                FROM sys.indexes i
                JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
                JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
                WHERE i.object_id = OBJECT_ID('dbo.BT_ADDRESS_MASTER')
                  AND i.name = 'IX_BT_ADDRESS_MASTER_parentID'
                  AND c.name <> 'parentID'
                  AND NOT (ic.is_included_column = 1 AND c.name IN ('addressUsage', 'deleted')))
    RAISERROR('REFUSED: IX_BT_ADDRESS_MASTER_parentID has other columns. Send its definition. Nothing changed.', 16, 1);
ELSE IF (SELECT COUNT(*)
         FROM sys.indexes i
         JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
         WHERE i.object_id = OBJECT_ID('dbo.BT_ADDRESS_MASTER')
           AND i.name = 'IX_BT_ADDRESS_MASTER_parentID'
           AND ic.is_included_column = 1) = 2
    PRINT 'SKIPPED: IX_BT_ADDRESS_MASTER_parentID already includes both columns.';
ELSE
BEGIN
    CREATE NONCLUSTERED INDEX IX_BT_ADDRESS_MASTER_parentID
        ON dbo.BT_ADDRESS_MASTER (parentID)
        INCLUDE (addressUsage, deleted)
        WITH (DROP_EXISTING = ON, ONLINE = ON, SORT_IN_TEMPDB = ON);
    PRINT 'CHANGED: IX_BT_ADDRESS_MASTER_parentID now includes addressUsage and deleted.';
END
GO
