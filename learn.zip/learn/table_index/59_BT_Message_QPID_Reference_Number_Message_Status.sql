USE [QPID_PROD]
GO
/******************************************************************************
  RECOMMENDED INDEX - NOT EXECUTED - TEST ON UAT BEFORE DEPLOYMENT
  Table : dbo.BT_Message (heap; 72,381 rows in the October table-size.xlsx;
          one full scan = about 2,078 reads in the November stats)
  Index : IX_BT_Message_QPID_Ref_Status
          ON (QPID_Reference_Number, Message_Status)
          INCLUDE (oldEnquiryNumber, QMS_Reference_Number)
  NOTE  : the first file with this number was lost from optimization_v4. This
          definition was rebuilt from the evidence and may differ from it.

  WHY   : SP_GetOldEnquiryNumber runs:
              SELECT oldEnquiryNumber FROM BT_Message
              WHERE Message_Status = 'P' AND QPID_Reference_Number = @EnquiryNo
          - 34,017 calls, 2,078 reads per call, 1,074 ms avg, 20.8 ms CPU,
            120 s max, 608.8 min in total: the largest item in the stats.
          - IX_BT_Message_Message_Status_Source does not narrow this search,
            so the reads equal a full scan.
          - At READ COMMITTED a scan can wait on any locked row in the table.
            A seek on this index should wait only when this enquiry's own row
            is locked. The blocking cause is inferred, not caught live.
          Also filtering on QPID_Reference_Number: SP_LCT_GetEquipmentDataByEnquiry,
          SP_LCT_MapEquipmentDataToTechType and usp_get_PaymentAmountByEnquiry.

  DESIGN: - The index fully covers SP_GetOldEnquiryNumber, so it needs no heap
            lookup. Estimated 3-4 reads per call.
          - @EnquiryNo is varchar(100) against a varchar(50) column: no implicit
            conversion to a different type family, so a seek is possible.
          - Not unique: the data is not known to be unique on this key.

  ORDER : rows with the same key should come back in physical row order, which
          is close to the current scan order but not guaranteed to match. This
          matters only if one enquiry has several 'P' rows. Check P1 below.

  COST  : about 2-5 MB (estimate). A Message_Status change now also updates this
          index; each message changes status only a few times.

  UNDO  : DROP INDEX IX_BT_Message_QPID_Ref_Status ON dbo.BT_Message;
******************************************************************************/

-- P1. Read-only check: enquiries with more than one 'P' row. Row order could
--     change for these only. Review any rows before deploying.
-- SELECT QPID_Reference_Number, COUNT(*) AS n
-- FROM dbo.BT_Message WITH (NOLOCK)
-- WHERE Message_Status = 'P'
-- GROUP BY QPID_Reference_Number
-- HAVING COUNT(*) > 1
-- ORDER BY n DESC;

IF EXISTS (SELECT 1
           FROM sys.indexes i
           JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
           JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
           WHERE i.object_id = OBJECT_ID('dbo.BT_Message')
             AND ic.key_ordinal = 1 AND c.name = 'QPID_Reference_Number')
    PRINT 'SKIPPED: an index leading on QPID_Reference_Number already exists.';
ELSE
BEGIN
    -- ONLINE = ON requires Enterprise/Developer/Azure; remove on Standard.
    CREATE NONCLUSTERED INDEX IX_BT_Message_QPID_Ref_Status
        ON dbo.BT_Message (QPID_Reference_Number, Message_Status)
        INCLUDE (oldEnquiryNumber, QMS_Reference_Number)
        WITH (ONLINE = ON, SORT_IN_TEMPDB = ON, FILLFACTOR = 90);
    PRINT 'CREATED: IX_BT_Message_QPID_Ref_Status.';
END
GO
