USE [QPID_PROD]
GO
/******************************************************************************
  RECOMMENDED INDEX - NOT EXECUTED - TEST ON UAT BEFORE DEPLOYMENT
  Table : dbo.BT_ACT_TASKCATEGORYITEMS_CRM_STG (no primary key or index in the
          QPID_Table script; 26,257 rows and 7.5 MB in the October table-size.xlsx)
  Index : IX_BT_ACT_TCI_CRM_STG_ID, UNIQUE ON (ID)
  NOTE  : V4-00.2c did not list this table, so production's indexes on it are not
          known. The script skips if one already leads on ID.

  WHY   : usp_QMS_FinalDataLoad_CRM_SmallWork runs, once per item, inside its long
          transaction:
              UPDATE BT_ACT_TASKCATEGORYITEMS_CRM_STG
              SET ItemInserted = 'Y' WHERE ID = @vItem_ID
          - With no index on ID this likely scans the table with U locks.
          - usp_QMS_InitialDataLoad_CRM writes rows of this table, and any X lock
            lasts until its caller commits. If the scan reaches such a row,
            SmallWork waits while keeping all of its own locks.
          The chain is inferred from the code, not caught live.
          Index 62 does not fix this: it helps the InitialDataLoad_CRM UPDATE, not
          this one.

  DESIGN: - Nonclustered, so the heap itself is not rebuilt.
          - @vItem_ID is INT, the same type as ID.
          - UNIQUE: ID is an IDENTITY column with no constraint, so duplicates are
            very unlikely but not impossible. The script checks first and skips
            if it finds any.

  RESULTS: no change. Only single-row updates by ID use this index.

  COST  : under 1 MB (estimate). ID never changes, so only inserts maintain it.

  UNDO  : DROP INDEX IX_BT_ACT_TCI_CRM_STG_ID
              ON dbo.BT_ACT_TASKCATEGORYITEMS_CRM_STG;
******************************************************************************/
IF EXISTS (SELECT 1
           FROM sys.indexes i
           JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
           JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
           WHERE i.object_id = OBJECT_ID('dbo.BT_ACT_TASKCATEGORYITEMS_CRM_STG')
             AND ic.key_ordinal = 1 AND c.name = 'ID')
    PRINT 'SKIPPED: an index leading on ID already exists.';
ELSE IF EXISTS (SELECT ID FROM dbo.BT_ACT_TASKCATEGORYITEMS_CRM_STG WITH (NOLOCK)
                GROUP BY ID HAVING COUNT(*) > 1)
    PRINT 'SKIPPED: duplicate ID values found. Send them for review.';
ELSE
BEGIN
    -- ONLINE = ON requires Enterprise/Developer/Azure; remove on Standard.
    CREATE UNIQUE NONCLUSTERED INDEX IX_BT_ACT_TCI_CRM_STG_ID
        ON dbo.BT_ACT_TASKCATEGORYITEMS_CRM_STG (ID)
        WITH (ONLINE = ON, SORT_IN_TEMPDB = ON, FILLFACTOR = 90);
    PRINT 'CREATED: IX_BT_ACT_TCI_CRM_STG_ID.';
END
GO
