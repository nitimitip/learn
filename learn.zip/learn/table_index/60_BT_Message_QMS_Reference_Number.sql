USE [QPID_PROD]
GO
/******************************************************************************
  RECOMMENDED INDEX - NOT EXECUTED - TEST ON UAT BEFORE DEPLOYMENT
  Table : dbo.BT_Message (heap; 72,381 rows in the October table-size.xlsx;
          one full scan = about 2,078 reads in the November stats)
  Index : IX_BT_Message_QMS_Ref ON (QMS_Reference_Number)
          INCLUDE (Source, QPID_Reference_Number)
  NOTE  : the first file with this number was lost from optimization_v4. This
          definition was rebuilt from the evidence and may differ from it.

  WHY   : no index leads on QMS_Reference_Number.
          - usp_QMS_InitialDataLoad_CRM: SELECT @sourceType = source reads 2,078
            pages on 759 runs (V4-00.4b). Its UPDATE reads 285 pages on 747 runs,
            likely through the status index (inferred).
          - usp_QMS_FinalDataLoad_CRM_MajorWork: UPDATE BT_Message SET
            Message_Status = 'P' ... WHERE QMS_Reference_Number = @pQMSRefNo runs
            inside the long transaction and has no status filter, so it likely
            scans the heap. If that scan waits on a locked row, MajorWork keeps
            all of its locks while it waits. Inferred from the code, not caught
            live.
          Also filtering on it: MajorWork's 'I' and 'F' updates,
          SP_CRM_QUOTE_STATUS_UPDATE, SP_LCT_MapEquipmentDataToTechType.

  DESIGN: - The INCLUDE columns cover SELECT @sourceType and the reference lookup.
          - The refs are varchar(50) or varchar(100) on both sides, so a seek is
            possible.
          - Not unique: the legacy loader reads this ref with TOP 1 ... ORDER BY
            ID DESC, which suggests one ref can have several rows.

  ORDER : "SELECT @sourceType = source" keeps the last row it reads. Rows with
          the same key should come back in physical row order, which is close to
          the current scan order but not guaranteed to match. This matters only
          if one ref has several rows with different Source values. Check P1.

  COST  : about 2-5 MB (estimate). Set QPID_Reference_Number once per message in
          the load step, so write cost is negligible.

  UNDO  : DROP INDEX IX_BT_Message_QMS_Ref ON dbo.BT_Message;
******************************************************************************/

-- P1. Read-only check: refs with more than one Source value. The value assigned
--     to @sourceType could change for these only. Review any rows first.
-- SELECT QMS_Reference_Number, COUNT(*) AS n, COUNT(DISTINCT Source) AS sources
-- FROM dbo.BT_Message WITH (NOLOCK)
-- GROUP BY QMS_Reference_Number
-- HAVING COUNT(DISTINCT Source) > 1
-- ORDER BY n DESC;

IF EXISTS (SELECT 1
           FROM sys.indexes i
           JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
           JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
           WHERE i.object_id = OBJECT_ID('dbo.BT_Message')
             AND ic.key_ordinal = 1 AND c.name = 'QMS_Reference_Number')
    PRINT 'SKIPPED: an index leading on QMS_Reference_Number already exists.';
ELSE
BEGIN
    -- ONLINE = ON requires Enterprise/Developer/Azure; remove on Standard.
    CREATE NONCLUSTERED INDEX IX_BT_Message_QMS_Ref
        ON dbo.BT_Message (QMS_Reference_Number)
        INCLUDE (Source, QPID_Reference_Number)
        WITH (ONLINE = ON, SORT_IN_TEMPDB = ON, FILLFACTOR = 90);
    PRINT 'CREATED: IX_BT_Message_QMS_Ref.';
END
GO
