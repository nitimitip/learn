USE [QPID_PROD]
GO
/******************************************************************************
  RECOMMENDED INDEX - NOT EXECUTED - TEST ON UAT BEFORE DEPLOYMENT
  Table : dbo.BT_ACT_TASKCATEGORYITEMS_CRM_STG (no primary key or index in the
          QPID_Table script; 26,257 rows and 7.5 MB in the October table-size.xlsx)
  Index : IX_BT_ACT_TCI_CRM_STG_QMS_REF ON (QMS_REF)
  NOTE  : the first file with this number was lost from optimization_v4. This
          definition was rebuilt from the evidence and may differ from it.
          V4-00.2c did not list this table, so production's indexes on it are
          not known. The script skips if one already leads on QMS_REF.

  WHY   : usp_QMS_InitialDataLoad_CRM, SmallWork path (531 of 760 runs):
              UPDATE BT_ACT_TASKCATEGORYITEMS_CRM_STG
              SET TCI_nonContestValQty = TCI_contestValQty
              WHERE qms_ref = @pCRMRef
          - 1,217 reads per run (V4-00.4b), which matches a full scan.
          - READ UNCOMMITTED does not stop an UPDATE taking U locks, so the scan
            can wait on rows of other messages. A seek touches only this
            message's rows (16 at most in the stats). The wait itself is
            inferred; V4-00.4b has no elapsed time per statement.
          SmallWork also reads this table by QMS_REF under NOLOCK, in a loop.

  DESIGN: - Key only. Rate_Card_Top_ID and ItemInserted are not included, because
            SmallWork updates ItemInserted once per item and each message has
            few rows.
          - @pCRMRef and @pQMSRefNo are varchar(50), the same type as QMS_REF.

  RESULTS: the InitialDataLoad_CRM UPDATE is unaffected: it sets the same rows, each
           from its own row.
  ORDER : SmallWork picks items one at a time with TOP 1 and no ORDER BY (two reads
          that select ID, about 1,987 and 2,056 in the SP). The loop still handles
          all of a message's rows, but a new plan could process them in a different
          order, so rows created from them could get ids in a different order. Rows
          with the same key should come back in physical row order, which is close
          to the current scan order but not guaranteed to match. Compare one
          multi-item SmallWork message on UAT if downstream output depends on the
          order.

  COST  : under 1 MB (estimate). Only inserts maintain the key.

  UNDO  : DROP INDEX IX_BT_ACT_TCI_CRM_STG_QMS_REF
              ON dbo.BT_ACT_TASKCATEGORYITEMS_CRM_STG;
******************************************************************************/
IF EXISTS (SELECT 1
           FROM sys.indexes i
           JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
           JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
           WHERE i.object_id = OBJECT_ID('dbo.BT_ACT_TASKCATEGORYITEMS_CRM_STG')
             AND ic.key_ordinal = 1 AND c.name = 'QMS_REF')
    PRINT 'SKIPPED: an index leading on QMS_REF already exists.';
ELSE
BEGIN
    -- ONLINE = ON requires Enterprise/Developer/Azure; remove on Standard.
    CREATE NONCLUSTERED INDEX IX_BT_ACT_TCI_CRM_STG_QMS_REF
        ON dbo.BT_ACT_TASKCATEGORYITEMS_CRM_STG (QMS_REF)
        WITH (ONLINE = ON, SORT_IN_TEMPDB = ON, FILLFACTOR = 90);
    PRINT 'CREATED: IX_BT_ACT_TCI_CRM_STG_QMS_REF.';
END
GO
