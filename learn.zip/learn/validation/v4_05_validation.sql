/* V4-05 validation. Not executed by the author. Every query here is read-only.
   Do NOT run SP_CEES_PROJECT_TRANSFER_INTERFACE_STEP2 by hand: it sends to CFS. */

/* ===== usp_GetActivityBasedOnTypeAndName ===== */

/* V4-05.1 UAT, BEFORE and AFTER deployment: compare results and reads.
   Replace the sample values with real UAT refs, cover every branch the screen uses,
   and save each result. The rows must match exactly; only logical reads should fall. */
SET STATISTICS IO ON;
EXEC dbo.usp_GetActivityBasedOnTypeAndName 'Project', 'U1039775', NULL, NULL, NULL, NULL, 1, 10;
EXEC dbo.usp_GetActivityBasedOnTypeAndName 'project', 'u1039775', NULL, NULL, NULL, NULL, 1, 10;  -- lower case must return the same rows
EXEC dbo.usp_GetActivityBasedOnTypeAndName 'STK', 'STK21005520', NULL, 21005520, NULL, 'STK21005520', 1, 10;
EXEC dbo.usp_GetActivityBasedOnTypeAndName 'CTK', 'CTK5462817', NULL, NULL, NULL, NULL, 1, 10;
EXEC dbo.usp_GetActivityBasedOnTypeAndName 'CTK', NULL, NULL, 21252910, NULL, NULL, 1, 10;
SET STATISTICS IO OFF;
GO

/* V4-05.2 Refs with more than one mapping row. Not a blocker: the index keeps the same
   row order. Send any rows so they can be recorded. */
SELECT CEES_PROJ_REF, COUNT(*) AS mapping_rows, COUNT(DISTINCT UKD_PROJ_REF) AS distinct_ukd_refs
FROM dbo.MT_PROJ_MAPPING WITH (READUNCOMMITTED)
WHERE CEES_PROJ_REF IS NOT NULL
GROUP BY CEES_PROJ_REF
HAVING COUNT(*) > 1
ORDER BY mapping_rows DESC;
GO

/* V4-05.3 Production, after a few days. Baseline from sp_execuation_stat.xlsx:
   538 ms avg, 514 ms CPU, 95,145 reads per call, 15.9 s max.
   Watch CPU as well as reads: OPTION (RECOMPILE) adds a small compile cost per call. */
SELECT s.cached_time, s.execution_count,
       s.total_elapsed_time / s.execution_count / 1000 AS avg_ms,
       s.total_worker_time / s.execution_count / 1000 AS avg_cpu_ms,
       s.total_logical_reads / s.execution_count AS avg_reads,
       s.max_elapsed_time / 1000 AS max_ms
FROM sys.dm_exec_procedure_stats AS s
WHERE s.database_id = DB_ID()
  AND s.object_id = OBJECT_ID(N'dbo.usp_GetActivityBasedOnTypeAndName');
GO

/* ===== SP_CEES_PROJECT_TRANSFER_INTERFACE_STEP2 (needed before any change) ===== */

/* V4-05.4 Which statements hold the 22M reads and 85 s of CPU? Run on production while
   the procedure is cached. Reads made inside scalar functions count in these figures. */
SELECT TOP (25)
       SUBSTRING(t.text, s.statement_start_offset / 2 + 1, 90) AS stmt_head,
       s.execution_count,
       s.total_elapsed_time / s.execution_count / 1000 AS avg_ms,
       s.total_worker_time / s.execution_count / 1000 AS avg_cpu_ms,
       s.total_logical_reads / s.execution_count AS avg_reads,
       s.total_rows / s.execution_count AS avg_rows
FROM sys.dm_exec_query_stats AS s
CROSS APPLY sys.dm_exec_sql_text(s.sql_handle) AS t
WHERE t.objectid = OBJECT_ID(N'dbo.SP_CEES_PROJECT_TRANSFER_INTERFACE_STEP2')
  AND t.dbid = DB_ID()
ORDER BY s.total_logical_reads DESC;
GO

/* V4-05.5 Cost of the scalar functions the procedure calls. */
SELECT OBJECT_NAME(f.object_id) AS function_name, f.execution_count,
       f.total_worker_time / f.execution_count AS avg_cpu_us,
       f.total_logical_reads / f.execution_count AS avg_reads,
       f.total_logical_reads AS total_reads
FROM sys.dm_exec_function_stats AS f
WHERE f.database_id = DB_ID()
  AND OBJECT_NAME(f.object_id) IN (N'f_get_TaskNumber_stk', N'f_get_TaskNumber_ctk', N'f_get_parent_task',
                                   N'f_getDefaultTopTaskCustFlag', N'getCFSOrgIDByCust', N'f_get_CustType_CDA',
                                   N'getTopProjectVersion')
ORDER BY f.total_logical_reads DESC;
