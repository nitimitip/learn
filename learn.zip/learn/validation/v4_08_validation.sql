/* V4-08 validation: usp_QMS_FinalDataLoad_CRM_MajorWork. Not executed by the author.
   Every query here is read-only. Do NOT run the procedure by hand on production: it
   processes the next waiting message. */

/* V4-08.1 Pre-check, on UAT and production. Expected: key_column = 1, index_id not NULL,
   definition_len = 70232 on the original (a different length means the deploy script
   will refuse; send the live definition). */
SELECT COLUMNPROPERTY(OBJECT_ID('dbo.BT_ENQUIRY_MASTER'), 'AE_externalRef2_Key', 'IsComputed') AS key_column,
       INDEXPROPERTY(OBJECT_ID('dbo.BT_ENQUIRY_MASTER'), 'IX_BT_ENQUIRY_MASTER_AE_externalRef2_Key', 'IndexID') AS index_id,
       LEN(OBJECT_DEFINITION(OBJECT_ID('dbo.usp_QMS_FinalDataLoad_CRM_MajorWork'))) AS definition_len,
       (SELECT modify_date FROM sys.procedures
        WHERE object_id = OBJECT_ID('dbo.usp_QMS_FinalDataLoad_CRM_MajorWork')) AS modify_date;
GO

/* V4-08.2 The new filter seeks. Safe on production: it should read fewer than about 20
   pages of BT_ENQUIRY_MASTER. If it reads about 150k pages the index is not being used:
   do not deploy, and send the actual plan. */
DECLARE @p varchar(50) = (SELECT TOP (1) QMS_Reference_Number
                          FROM dbo.BT_Message WITH (READUNCOMMITTED)
                          WHERE [Source] = 'CRM_MajorWork' AND QMS_Reference_Number IS NOT NULL
                          ORDER BY ID DESC);
SET STATISTICS IO ON;
SELECT AE_AEID, AE_internalRef
FROM dbo.BT_ENQUIRY_MASTER WITH (READUNCOMMITTED)
WHERE AE_externalRef2_Key = @p AND AE_externalRef2 = @p;
SET STATISTICS IO OFF;
GO

/* V4-08.3 UAT ONLY: old and new filters find the same rows, for the 3 latest MajorWork
   refs. The old filter scans about 150k pages per ref, so do not run this on production.
   Expected: no rows returned. */
SET NOCOUNT ON;
DECLARE @ref varchar(50);
DECLARE @diff TABLE (ref varchar(50), AE_AEID int, only_in varchar(3));
DECLARE c CURSOR LOCAL FAST_FORWARD FOR
    SELECT TOP (3) QMS_Reference_Number
    FROM dbo.BT_Message WITH (READUNCOMMITTED)
    WHERE [Source] = 'CRM_MajorWork' AND QMS_Reference_Number IS NOT NULL
    ORDER BY ID DESC;
OPEN c;
FETCH NEXT FROM c INTO @ref;
WHILE @@FETCH_STATUS = 0
BEGIN
    INSERT @diff
    SELECT @ref, x.AE_AEID, 'old'
    FROM (SELECT AE_AEID FROM dbo.BT_ENQUIRY_MASTER WITH (READUNCOMMITTED)
          WHERE AE_externalRef2 = @ref
          EXCEPT
          SELECT AE_AEID FROM dbo.BT_ENQUIRY_MASTER WITH (READUNCOMMITTED)
          WHERE AE_externalRef2_Key = @ref AND AE_externalRef2 = @ref) AS x;
    INSERT @diff
    SELECT @ref, x.AE_AEID, 'new'
    FROM (SELECT AE_AEID FROM dbo.BT_ENQUIRY_MASTER WITH (READUNCOMMITTED)
          WHERE AE_externalRef2_Key = @ref AND AE_externalRef2 = @ref
          EXCEPT
          SELECT AE_AEID FROM dbo.BT_ENQUIRY_MASTER WITH (READUNCOMMITTED)
          WHERE AE_externalRef2 = @ref) AS x;
    FETCH NEXT FROM c INTO @ref;
END
CLOSE c;
DEALLOCATE c;
SELECT * FROM @diff;
GO

/* V4-08.4 Time per processed MajorWork message, from the procedure's own log. Run BEFORE
   deployment on production and save the output, then again after a few days. The log has
   no date column, so the times are read from its text. Runs that failed are left out. */
SELECT TOP (200)
       l.QMSRefNo,
       TRY_CONVERT(datetime, SUBSTRING(l.ExecutionTime, 7, 23), 121) AS started,
       DATEDIFF(MILLISECOND,
                TRY_CONVERT(datetime, SUBSTRING(l.ExecutionTime, 7, 23), 121),
                TRY_CONVERT(datetime, RIGHT(l.ExecutionTime, 23), 121)) AS duration_ms
FROM dbo.QMSRecordProcessTime AS l WITH (READUNCOMMITTED)
WHERE l.ExecutionTime LIKE 'START %'
  AND l.ExecutionTime LIKE '%END 20%'
  AND l.ExecutionTime NOT LIKE '%END WITH ERROR%'
  AND EXISTS (SELECT 1 FROM dbo.BT_Message AS m WITH (READUNCOMMITTED)
              WHERE m.QMS_Reference_Number = l.QMSRefNo AND m.[Source] = 'CRM_MajorWork')
ORDER BY started DESC;
GO

/* V4-08.5 Production, after a few days. Baseline from sp_execuation_stat.xlsx:
   MajorWork 1,152 calls, 183 ms avg, 286 ms CPU, 35,344 reads per call.
   SP_LCT_MapEquipmentDataToTechType 3,115 calls, 35 ms avg, 3,333 reads.
   Compare MajorWork's cached_time with the deployment time: stats restart at ALTER.
   SP_LCT's call count should now track processed messages, not every loader run, so it
   should rise far more slowly than usp_QMS_FinalDataLoad_CRM_Main's count. */
SELECT OBJECT_NAME(s.object_id) AS procedure_name, s.cached_time, s.execution_count,
       s.total_elapsed_time / s.execution_count / 1000 AS avg_ms,
       s.total_worker_time / s.execution_count / 1000 AS avg_cpu_ms,
       s.total_logical_reads / s.execution_count AS avg_reads,
       s.max_elapsed_time / 1000 AS max_ms
FROM sys.dm_exec_procedure_stats AS s
WHERE s.database_id = DB_ID()
  AND s.object_id IN (OBJECT_ID(N'dbo.usp_QMS_FinalDataLoad_CRM_MajorWork'),
                      OBJECT_ID(N'dbo.usp_QMS_FinalDataLoad_CRM_Main'),
                      OBJECT_ID(N'dbo.SP_LCT_MapEquipmentDataToTechType'));
GO
