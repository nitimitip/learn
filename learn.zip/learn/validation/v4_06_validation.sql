/* V4-06 validation. Not executed by the author.
   Everything here only reads real tables. V4-06.1 writes only to a ## temp table,
   and usp_QPIDConnectivitySearch itself writes only to # temp tables. */

/* ===== usp_QPIDConnectivitySearch ===== */

/* V4-06.1 UAT compare. Keep THIS query window open throughout, because the ## table
   lives with it.
   Step 1: run the capture batch below with @phase = 'before'.
   Step 2: in another window, deploy sp/usp_QPIDConnectivitySearch.sql on UAT.
   Step 3: run the capture batch again with @phase = 'after'.
   Step 4: run the compare batch. The test values are the commonest ones in the data. */
IF OBJECT_ID('tempdb..##v406') IS NULL
    CREATE TABLE ##v406 (
        phase varchar(6) NULL, case_no int NULL, record_count int NULL,
        RowNumber bigint, AE_internalRef varchar(50), AE_assignedToPerson varchar(50),
        AE_quoteDesigner varchar(50), siteName varchar(250), AE_plannedStartDate varchar(30),
        AE_status varchar(100), AE_plannedEndDate varchar(30), AE_supplyCapacity varchar(50),
        AE_NGESO varchar(100), AE_InteractiveEnqInfo varchar(250), EX_totalExportCapacity money,
        PrimarySubName varchar(100), DistributionSubName varchar(100), FeederName varchar(100),
        EX_bspGspPrimaryName varchar(50), gridSupplyPoint varchar(100), bulkSupplyPoint varchar(100),
        HvFeederName varchar(max), EhvFeederName varchar(50), AE_quoteValidPeriod varchar(30));
GO
/* Capture batch: set @phase, then run. */
DECLARE @phase varchar(6) = 'before';   -- then 'after'
DECLARE @rc int, @big int = 2000000;
DECLARE @p int, @g int, @b int, @d varchar(100);

SELECT TOP (1) @p = primarySubSite FROM dbo.BT_QUOTE_AE_EXTRA WITH (READUNCOMMITTED)
WHERE primarySubSite <> 0 GROUP BY primarySubSite ORDER BY COUNT(*) DESC, primarySubSite;
SELECT TOP (1) @g = gridSupplyPoint FROM dbo.BT_QUOTE_AE_EXTRA WITH (READUNCOMMITTED)
WHERE gridSupplyPoint <> 0 GROUP BY gridSupplyPoint ORDER BY COUNT(*) DESC, gridSupplyPoint;
SELECT TOP (1) @b = bulkSupplyPoint FROM dbo.BT_QUOTE_AE_EXTRA WITH (READUNCOMMITTED)
WHERE bulkSupplyPoint <> 0 GROUP BY bulkSupplyPoint ORDER BY COUNT(*) DESC, bulkSupplyPoint;
SELECT TOP (1) @d = L.LOV_DESC
FROM dbo.BT_QUOTE_AE_EXTRA E WITH (READUNCOMMITTED)
JOIN dbo.MT_SYS_LOV L WITH (READUNCOMMITTED)
  ON L.INT_LOV_ID = E.distributionSubSite AND L.LOV_NAME = 'sysQuoteDistributionSite'
GROUP BY L.LOV_DESC ORDER BY COUNT(*) DESC, L.LOV_DESC;

INSERT ##v406 (RowNumber, AE_internalRef, AE_assignedToPerson, AE_quoteDesigner, siteName, AE_plannedStartDate,
    AE_status, AE_plannedEndDate, AE_supplyCapacity, AE_NGESO, AE_InteractiveEnqInfo, EX_totalExportCapacity,
    PrimarySubName, DistributionSubName, FeederName, EX_bspGspPrimaryName, gridSupplyPoint, bulkSupplyPoint,
    HvFeederName, EhvFeederName, AE_quoteValidPeriod)
EXEC dbo.usp_QPIDConnectivitySearch @PrimarySubstation = @p, @PageIndex = 1, @PageSize = @big, @RecordCount = @rc OUTPUT;
UPDATE ##v406 SET phase = @phase, case_no = 1, record_count = @rc WHERE phase IS NULL;

INSERT ##v406 (RowNumber, AE_internalRef, AE_assignedToPerson, AE_quoteDesigner, siteName, AE_plannedStartDate,
    AE_status, AE_plannedEndDate, AE_supplyCapacity, AE_NGESO, AE_InteractiveEnqInfo, EX_totalExportCapacity,
    PrimarySubName, DistributionSubName, FeederName, EX_bspGspPrimaryName, gridSupplyPoint, bulkSupplyPoint,
    HvFeederName, EhvFeederName, AE_quoteValidPeriod)
EXEC dbo.usp_QPIDConnectivitySearch @GridSupply = @g, @PageIndex = 1, @PageSize = @big, @RecordCount = @rc OUTPUT;
UPDATE ##v406 SET phase = @phase, case_no = 2, record_count = @rc WHERE phase IS NULL;

INSERT ##v406 (RowNumber, AE_internalRef, AE_assignedToPerson, AE_quoteDesigner, siteName, AE_plannedStartDate,
    AE_status, AE_plannedEndDate, AE_supplyCapacity, AE_NGESO, AE_InteractiveEnqInfo, EX_totalExportCapacity,
    PrimarySubName, DistributionSubName, FeederName, EX_bspGspPrimaryName, gridSupplyPoint, bulkSupplyPoint,
    HvFeederName, EhvFeederName, AE_quoteValidPeriod)
EXEC dbo.usp_QPIDConnectivitySearch @BulkSupply = @b, @PageIndex = 1, @PageSize = @big, @RecordCount = @rc OUTPUT;
UPDATE ##v406 SET phase = @phase, case_no = 3, record_count = @rc WHERE phase IS NULL;

INSERT ##v406 (RowNumber, AE_internalRef, AE_assignedToPerson, AE_quoteDesigner, siteName, AE_plannedStartDate,
    AE_status, AE_plannedEndDate, AE_supplyCapacity, AE_NGESO, AE_InteractiveEnqInfo, EX_totalExportCapacity,
    PrimarySubName, DistributionSubName, FeederName, EX_bspGspPrimaryName, gridSupplyPoint, bulkSupplyPoint,
    HvFeederName, EhvFeederName, AE_quoteValidPeriod)
EXEC dbo.usp_QPIDConnectivitySearch @DistributionSubstation = @d, @PageIndex = 1, @PageSize = @big, @RecordCount = @rc OUTPUT;
UPDATE ##v406 SET phase = @phase, case_no = 4, record_count = @rc WHERE phase IS NULL;

/* Case 5: a real page, to check the page boundaries. */
INSERT ##v406 (RowNumber, AE_internalRef, AE_assignedToPerson, AE_quoteDesigner, siteName, AE_plannedStartDate,
    AE_status, AE_plannedEndDate, AE_supplyCapacity, AE_NGESO, AE_InteractiveEnqInfo, EX_totalExportCapacity,
    PrimarySubName, DistributionSubName, FeederName, EX_bspGspPrimaryName, gridSupplyPoint, bulkSupplyPoint,
    HvFeederName, EhvFeederName, AE_quoteValidPeriod)
EXEC dbo.usp_QPIDConnectivitySearch @PrimarySubstation = @p, @PageIndex = 2, @PageSize = 10, @RecordCount = @rc OUTPUT;
UPDATE ##v406 SET phase = @phase, case_no = 5, record_count = @rc WHERE phase IS NULL;

SELECT phase, case_no, COUNT(*) AS rows_returned, MAX(record_count) AS record_count, MIN(RowNumber) AS min_rn, MAX(RowNumber) AS max_rn
FROM ##v406 GROUP BY phase, case_no ORDER BY phase, case_no;
GO
/* Compare batch. Pass = every *_diff column is 0 for cases 1 to 4.
   position_diff compares (RowNumber, ref) and must be 0 for all 5 cases.
   content_diff ignores RowNumber, because rows with the same ref had no fixed order
   in the original. It can be above 0 for case 5 only, because tied rows may sit on a
   different page. */
SELECT c.case_no,
    (SELECT COUNT(*) FROM (SELECT RowNumber, AE_internalRef FROM ##v406 WHERE phase = 'before' AND case_no = c.case_no
                           EXCEPT SELECT RowNumber, AE_internalRef FROM ##v406 WHERE phase = 'after' AND case_no = c.case_no) x)
  + (SELECT COUNT(*) FROM (SELECT RowNumber, AE_internalRef FROM ##v406 WHERE phase = 'after' AND case_no = c.case_no
                           EXCEPT SELECT RowNumber, AE_internalRef FROM ##v406 WHERE phase = 'before' AND case_no = c.case_no) x) AS position_diff,
    (SELECT COUNT(*) FROM (SELECT AE_internalRef, AE_assignedToPerson, AE_quoteDesigner, siteName, AE_plannedStartDate, AE_status, AE_plannedEndDate, AE_supplyCapacity, AE_NGESO, AE_InteractiveEnqInfo, EX_totalExportCapacity, PrimarySubName, DistributionSubName, FeederName, EX_bspGspPrimaryName, gridSupplyPoint, bulkSupplyPoint, HvFeederName, EhvFeederName, AE_quoteValidPeriod FROM ##v406 WHERE phase = 'before' AND case_no = c.case_no
                           EXCEPT SELECT AE_internalRef, AE_assignedToPerson, AE_quoteDesigner, siteName, AE_plannedStartDate, AE_status, AE_plannedEndDate, AE_supplyCapacity, AE_NGESO, AE_InteractiveEnqInfo, EX_totalExportCapacity, PrimarySubName, DistributionSubName, FeederName, EX_bspGspPrimaryName, gridSupplyPoint, bulkSupplyPoint, HvFeederName, EhvFeederName, AE_quoteValidPeriod FROM ##v406 WHERE phase = 'after' AND case_no = c.case_no) x)
  + (SELECT COUNT(*) FROM (SELECT AE_internalRef, AE_assignedToPerson, AE_quoteDesigner, siteName, AE_plannedStartDate, AE_status, AE_plannedEndDate, AE_supplyCapacity, AE_NGESO, AE_InteractiveEnqInfo, EX_totalExportCapacity, PrimarySubName, DistributionSubName, FeederName, EX_bspGspPrimaryName, gridSupplyPoint, bulkSupplyPoint, HvFeederName, EhvFeederName, AE_quoteValidPeriod FROM ##v406 WHERE phase = 'after' AND case_no = c.case_no
                           EXCEPT SELECT AE_internalRef, AE_assignedToPerson, AE_quoteDesigner, siteName, AE_plannedStartDate, AE_status, AE_plannedEndDate, AE_supplyCapacity, AE_NGESO, AE_InteractiveEnqInfo, EX_totalExportCapacity, PrimarySubName, DistributionSubName, FeederName, EX_bspGspPrimaryName, gridSupplyPoint, bulkSupplyPoint, HvFeederName, EhvFeederName, AE_quoteValidPeriod FROM ##v406 WHERE phase = 'before' AND case_no = c.case_no) x) AS content_diff,
    (SELECT MAX(record_count) FROM ##v406 WHERE phase = 'before' AND case_no = c.case_no)
  - (SELECT MAX(record_count) FROM ##v406 WHERE phase = 'after' AND case_no = c.case_no) AS record_count_diff
FROM (VALUES (1), (2), (3), (4), (5)) c(case_no)
ORDER BY c.case_no;
GO

/* V4-06.2 Production, BEFORE deployment. Both answers should be 0.
   bad_status above 0: "QUO.AE_status <> 8000" converts the column to int, so a text status
   raises error 245 if a new plan reads that row first. Do not deploy; send the values.
   ambiguous_people above 0: a person id with two names. The TOP 1 lookup may show a
   different name than before. Not a blocker; send the ids.
   Both queries use READUNCOMMITTED, and the first scans BT_QUOTE_MASTER (about 145k pages),
   so run it outside peak hours. */
SELECT COUNT(*) AS bad_status
FROM dbo.BT_QUOTE_MASTER WITH (READUNCOMMITTED)
WHERE AE_status IS NOT NULL AND TRY_CONVERT(int, AE_status) IS NULL;

SELECT COUNT(*) AS ambiguous_people
FROM (SELECT peoporg_peoporgID
      FROM dbo.MT_ACT_PEOPORG WITH (READUNCOMMITTED)
      GROUP BY peoporg_peoporgID
      HAVING COUNT(DISTINCT peoporg_name) > 1) x;
GO

/* V4-06.3 Production, after a few days. Baseline from sp_execuation_stat.xlsx:
   111 calls, 11,894 ms avg, 20,623 ms CPU, 1,918,790 reads per call, 30.6 s max. */
SELECT s.cached_time, s.execution_count,
       s.total_elapsed_time / s.execution_count / 1000 AS avg_ms,
       s.total_worker_time / s.execution_count / 1000 AS avg_cpu_ms,
       s.total_logical_reads / s.execution_count AS avg_reads,
       s.max_elapsed_time / 1000 AS max_ms
FROM sys.dm_exec_procedure_stats AS s
WHERE s.database_id = DB_ID()
  AND s.object_id = OBJECT_ID(N'dbo.usp_QPIDConnectivitySearch');
GO

/* ===== PRC_ACT_uspActActQuery_v4 (no change in this batch) ===== */

/* V4-06.4 Production. The search runs through EXEC(@SqlString), so it has no object id
   and is found by its text. Shows whether the reads follow the search type. */
SELECT TOP (20)
       s.execution_count,
       s.total_elapsed_time / s.execution_count / 1000 AS avg_ms,
       s.total_worker_time / s.execution_count / 1000 AS avg_cpu_ms,
       s.total_logical_reads / s.execution_count AS avg_reads,
       s.total_rows / s.execution_count AS avg_rows,
       s.max_dop,
       RIGHT(t.text, 400) AS search_filters
FROM sys.dm_exec_query_stats AS s
CROSS APPLY sys.dm_exec_sql_text(s.sql_handle) AS t
WHERE t.text LIKE N'%Cutomer Name%BT_PROJ_HEADER A WITH (NOLOCK)%'
  AND t.text NOT LIKE N'%dm_exec_query_stats%'
ORDER BY s.total_logical_reads DESC;
GO

/* ===== SP_GET_ALL_DDL_BY_ACTTYPE_DOCID (155 min, largest SP not yet explained) ===== */

/* V4-06.5 Production. Which statements hold the 12,747 reads and 112 ms of CPU per call? */
SELECT TOP (15)
       SUBSTRING(t.text, s.statement_start_offset / 2 + 1, 120) AS stmt_head,
       s.execution_count,
       s.total_worker_time / 1000 AS total_cpu_ms,
       s.total_logical_reads AS total_reads,
       s.total_logical_reads / s.execution_count AS avg_reads,
       s.total_worker_time / s.execution_count AS avg_cpu_us
FROM sys.dm_exec_query_stats AS s
CROSS APPLY sys.dm_exec_sql_text(s.sql_handle) AS t
WHERE t.objectid = OBJECT_ID(N'dbo.SP_GET_ALL_DDL_BY_ACTTYPE_DOCID')
  AND t.dbid = DB_ID()
ORDER BY s.total_worker_time DESC;
GO
