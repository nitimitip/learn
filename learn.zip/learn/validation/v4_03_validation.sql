/* V4-03 validation. Not executed by the author.
   Part 1 is read-only and safe on production.
   Part 2 is for UAT ONLY: it runs the procedure inside transactions and rolls back. */

/* ===== PART 1: production, read-only ===== */

/* V4-03.1 Which version is live? Expect has_v4_03 = 1 after deployment. */
SELECT o.name, o.modify_date, LEN(OBJECT_DEFINITION(o.object_id)) AS definition_len,
       CASE WHEN OBJECT_DEFINITION(o.object_id) LIKE N'%QPID_OPT V4-03%' THEN 1 ELSE 0 END AS has_v4_03
FROM sys.procedures AS o
WHERE o.name IN (N'SP_ADD_STANDARDS', N'SP_ADD_CUST_ADDRESS');

/* V4-03.2 Duration after deployment. Baseline from sp_execuation_stat.xlsx:
   SP_ADD_STANDARDS 290 ms avg, 30.1 s max; SP_ADD_CUST_ADDRESS 3,536 ms avg, 30.0 s max.
   ALTER resets these counters, so they cover only the period since deployment. */
SELECT OBJECT_NAME(s.object_id) AS proc_name, s.cached_time, s.execution_count,
       s.total_elapsed_time / s.execution_count / 1000 AS avg_ms,
       s.max_elapsed_time / 1000 AS max_ms,
       s.total_worker_time / s.execution_count / 1000 AS avg_cpu_ms,
       s.total_logical_reads / s.execution_count AS avg_reads
FROM sys.dm_exec_procedure_stats AS s
WHERE s.database_id = DB_ID()
  AND s.object_id IN (OBJECT_ID(N'dbo.SP_ADD_STANDARDS'), OBJECT_ID(N'dbo.SP_ADD_CUST_ADDRESS'));

/* V4-03.3 Duplicate STA_ID check. The primary key is (STA_ID, STA_STD_ID), so it does
   not stop two rows sharing one STA_ID. Run BEFORE deployment and keep the result as
   the baseline, then again one week after. Expect no new rows after deployment. */
SELECT STA_ID, COUNT(*) AS rows_with_id, MIN(sta_created_date) AS first_created, MAX(sta_created_date) AS last_created
FROM dbo.BT_ACT_STANDARDS WITH (READUNCOMMITTED)
GROUP BY STA_ID
HAVING COUNT(*) > 1
ORDER BY last_created DESC;
GO

/* ===== PART 2: UAT ONLY, two query windows, nothing is committed =====

   WINDOW 1 - hold an uncommitted newest address row, as a long transaction would:

       BEGIN TRAN;
       DECLARE @e varchar(5000);
       EXEC dbo.SP_ADD_CUST_ADDRESS @ploggedonUser='1', @pCustRef='<real UAT CUST_REFERENCE>',
            @pAddrUSage='TEST', @pStreet='V4-03 TEST', @pTown='V4-03 TEST', @pErrorMessage=@e OUTPUT;
       -- note the id returned (N); leave this transaction open

   WINDOW 2 - run the same thing:

       SET LOCK_TIMEOUT 5000;
       BEGIN TRAN;
       DECLARE @e varchar(5000);
       EXEC dbo.SP_ADD_CUST_ADDRESS @ploggedonUser='1', @pCustRef='<real UAT CUST_REFERENCE>',
            @pAddrUSage='TEST', @pStreet='V4-03 TEST', @pTown='V4-03 TEST', @pErrorMessage=@e OUTPUT;
       SELECT @e AS error_message;
       ROLLBACK;

   THEN in WINDOW 1:  ROLLBACK;

   Original procedure : window 2 waits 5 s, then error_message shows error 1222.
   V4-03 procedure    : window 2 returns at once with id N+1 and an empty error_message.

   If window 2 still waits with V4-03 live, the MAX read is not the only wait.
   Report that result: the change is still safe but its gain is smaller.
*/
