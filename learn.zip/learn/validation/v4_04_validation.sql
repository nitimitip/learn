/* V4-04 validation. Not executed by the author. Every query here is read-only.
   Do NOT run SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP0 by hand to test it: it sends to CFS. */

/* V4-04.1 BEFORE deployment: how much of the job is the DELETE?
   Run while the procedure is still in the plan cache, and send the result.
   If the DELETE row is small and the INSERT row dominates, the change gains little. */
SELECT SUBSTRING(t.text, s.statement_start_offset / 2 + 1, 70) AS stmt_head,
       s.execution_count,
       s.total_elapsed_time / s.execution_count / 1000 AS avg_ms,
       s.total_worker_time / s.execution_count / 1000 AS avg_cpu_ms,
       s.total_logical_reads / s.execution_count AS avg_reads,
       s.total_rows / s.execution_count AS avg_rows
FROM sys.dm_exec_query_stats AS s
CROSS APPLY sys.dm_exec_sql_text(s.sql_handle) AS t
WHERE t.objectid = OBJECT_ID(N'dbo.SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP0')
  AND t.dbid = DB_ID()
ORDER BY s.total_elapsed_time DESC;

/* V4-04.2 Table size and recovery model. Run before deployment and after one job run.
   Before: many more pages than the rows need means empty heap pages are being kept.
   rows_now should stay about the same; used_pages should not grow from run to run. */
SELECT SUM(p.row_count) AS rows_now, SUM(p.used_page_count) AS used_pages,
       (SELECT recovery_model_desc FROM sys.databases WHERE database_id = DB_ID()) AS recovery_model
FROM sys.dm_db_partition_stats AS p
WHERE p.object_id = OBJECT_ID(N'dbo.XT_XFACE_CFS_CONTACTS');

/* V4-04.3 AFTER one job run: the reload is complete and has no duplicates.
   Expect rows > 0, duplicate_rows = 0 and max_xface_id = rows (the id restarted at 1). */
SELECT COUNT(*) AS rows_loaded,
       COUNT(*) - (SELECT COUNT(*) FROM (SELECT DISTINCT XFACE_CONTACT_ID, XFACE_CONTACT_FIRST_NAME, XFACE_CONTACT_LAST_NAME
                                         FROM dbo.XT_XFACE_CFS_CONTACTS) AS d) AS duplicate_rows,
       MAX(XFACE_ID) AS max_xface_id
FROM dbo.XT_XFACE_CFS_CONTACTS;

/* V4-04.4 AFTER a few days. Baseline from sp_execuation_stat.xlsx:
   52,297 ms avg, 49,964 ms CPU, 7,527,863 reads per run, 92.1 s max. */
SELECT s.cached_time, s.execution_count,
       s.total_elapsed_time / s.execution_count / 1000 AS avg_ms,
       s.total_worker_time / s.execution_count / 1000 AS avg_cpu_ms,
       s.total_logical_reads / s.execution_count AS avg_reads,
       s.max_elapsed_time / 1000 AS max_ms
FROM sys.dm_exec_procedure_stats AS s
WHERE s.database_id = DB_ID()
  AND s.object_id = OBJECT_ID(N'dbo.SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP0');

/* V4-04.6 How many recent job runs had any project to send?
   Sizes the optional "skip the reload when nothing is waiting" idea in V4-04_NOTES.md. */
SELECT (SELECT COUNT(*) FROM dbo.XT_CDMS_INTERFACEBATCHES WITH (READUNCOMMITTED)
        WHERE bat_BatchType = 'CFSInterface' AND bat_BatchDate >= DATEADD(day, -30, GETDATE())) AS job_runs_30d,
       (SELECT COUNT(DISTINCT batch_id) FROM dbo.XT_XFACE_PROJECTS_TASK_ARC WITH (READUNCOMMITTED)
        WHERE SENT_DATE >= DATEADD(day, -30, GETDATE())) AS runs_with_projects_30d;

/* V4-04.5 usp_GetEnquiries_afp: needed before any change can be designed.
   Also script fn_GetCRMEnquiryAuditData in SSMS (right-click, Script Function as, CREATE To)
   and send the file: a grid result can cut off a long definition. */
SELECT o.name, o.type_desc, o.modify_date
FROM sys.objects AS o
WHERE o.object_id = OBJECT_ID(N'dbo.fn_GetCRMEnquiryAuditData');

/* Objects the function uses, including other functions. */
SELECT d.referenced_entity_name, o.type_desc
FROM sys.sql_expression_dependencies AS d
LEFT JOIN sys.objects AS o ON o.object_id = d.referenced_id
WHERE d.referencing_id = OBJECT_ID(N'dbo.fn_GetCRMEnquiryAuditData')
ORDER BY o.type_desc, d.referenced_entity_name;

/* Statement costs inside the function, if it is multi-statement and still cached. */
SELECT SUBSTRING(t.text, s.statement_start_offset / 2 + 1, 70) AS stmt_head,
       s.execution_count,
       s.total_elapsed_time / s.execution_count / 1000 AS avg_ms,
       s.total_worker_time / s.execution_count / 1000 AS avg_cpu_ms,
       s.total_logical_reads / s.execution_count AS avg_reads,
       s.total_rows / s.execution_count AS avg_rows
FROM sys.dm_exec_query_stats AS s
CROSS APPLY sys.dm_exec_sql_text(s.sql_handle) AS t
WHERE t.objectid = OBJECT_ID(N'dbo.fn_GetCRMEnquiryAuditData')
  AND t.dbid = DB_ID()
ORDER BY s.total_elapsed_time DESC;
