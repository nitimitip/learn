/* V4-09 validation: usp_QMS_InitialDataLoad_CRM. Not executed by the author.
   V4-09.1, .2 and .6 are read-only. V4-09.3 to .5 create customer and enquiry rows and
   change a permission: UAT or SIT ONLY, never production. */

/* V4-09.1 Pre-check, on UAT and production. Expected: definition_len = 6997 before
   deployment. Any other length means the deploy script will refuse (BF04 is one such
   version): send the live definition. */
SELECT LEN(OBJECT_DEFINITION(OBJECT_ID('dbo.usp_QMS_InitialDataLoad_CRM'))) AS definition_len,
       (SELECT modify_date FROM sys.procedures
        WHERE object_id = OBJECT_ID('dbo.usp_QMS_InitialDataLoad_CRM')) AS modify_date;
GO

/* V4-09.2 Production, BEFORE deployment: failed runs the log already shows. A run whose
   transaction was doomed writes nothing here today, so this list misses the 3930 cases.
   Save it for comparison. Ordered by text, which starts with the run's timestamp. */
SELECT TOP (200) QMSRefNo, ExecutionTime
FROM dbo.QMSRecordProcessTime WITH (READUNCOMMITTED)
WHERE ExecutionTime LIKE 'BEGIN INIT LOAD%'
  AND ExecutionTime NOT LIKE '%ENQ%END INIT LOAD%'
ORDER BY ExecutionTime DESC;
GO

/* V4-09.3 UAT, ORIGINAL procedure: reproduce 3930. Use a test login and a test ref that
   exists in BT_Message. As DBA first:
       DENY INSERT ON dbo.MT_ENQUIRY_QUESTIONS TO [<<test login>>];
   Then, connected as the test login, run the three cases below one at a time:

   Case A, explicit transaction with XACT_ABORT ON:
       SET XACT_ABORT ON; BEGIN TRAN;
       EXEC dbo.usp_QMS_InitialDataLoad_CRM @pCRMRef = '<<test ref>>';
       IF @@TRANCOUNT > 0 ROLLBACK;
       SET XACT_ABORT OFF;

   Case B, the likely JDBC autoCommit = false mode:
       SET XACT_ABORT ON; SET IMPLICIT_TRANSACTIONS ON;
       EXEC dbo.usp_QMS_InitialDataLoad_CRM @pCRMRef = '<<test ref>>';
       IF @@TRANCOUNT > 0 ROLLBACK;
       SET IMPLICIT_TRANSACTIONS OFF; SET XACT_ABORT OFF;

   Case C, no caller transaction and XACT_ABORT OFF:
       EXEC dbo.usp_QMS_InitialDataLoad_CRM @pCRMRef = '<<test ref>>';

   Expected on the original: 3930 in A and B. Record the actual messages for all three,
   and repeat B with XACT_ABORT OFF if the real caller's setting is not known. */

/* V4-09.4 UAT, after deploying sp/usp_QMS_InitialDataLoad_CRM.sql: same three cases.

   Expected in A and B:
     - No 3930.
     - RESULT shows the real error (229, permission denied).
     - A may also raise 266 (transaction count mismatch) after the result. Record it.
     - The caller's work is gone: the doomed transaction was rolled back.
     - In A the new log row below is kept. In B it is kept only if the caller commits,
       so the rollback in the case B script removes it. That is expected, and it matters
       for the real API: see the notes.
   Expected in C: exactly the same as the original (partly created rows remain). */
SELECT TOP (5) QMSRefNo, ExecutionTime
FROM dbo.QMSRecordProcessTime WITH (READUNCOMMITTED)
WHERE QMSRefNo = '<<test ref>>';
GO

/* Rows left for the test ref. Case A and B should add none; compare with the count before
   the test. Note: this scans BT_ENQUIRY_MASTER, which is acceptable on UAT. */
SELECT COUNT(*) AS enquiries_for_ref
FROM dbo.BT_ENQUIRY_MASTER WITH (READUNCOMMITTED)
WHERE AE_externalRef2 = '<<test ref>>';
GO

/* Clean up, as DBA:
       REVOKE INSERT ON dbo.MT_ENQUIRY_QUESTIONS FROM [<<test login>>]; */

/* V4-09.5 UAT, through the REAL API, after the permission is restored:
     1. Send one normal Small Works and one normal Major Works message. Each must succeed
        and return an ENQ reference, as it does today.
     2. If possible, force one failure with the DENY above on the API's own UAT login.
        Record what the API returns and whether it commits or rolls back. This is the only
        way to see how it handles the changed outcome and any 266. */

/* V4-09.6 Production, after a few days. No speed change is expected: baseline from
   sp_execuation_stat.xlsx is 760 calls, 9,868 ms avg, 63 ms CPU, 6,736 reads.
   Also rerun V4-09.2: failed runs should now show the real error text. */
SELECT s.cached_time, s.execution_count,
       s.total_elapsed_time / s.execution_count / 1000 AS avg_ms,
       s.total_worker_time / s.execution_count / 1000 AS avg_cpu_ms,
       s.total_logical_reads / s.execution_count AS avg_reads,
       s.max_elapsed_time / 1000 AS max_ms
FROM sys.dm_exec_procedure_stats AS s
WHERE s.database_id = DB_ID()
  AND s.object_id = OBJECT_ID(N'dbo.usp_QMS_InitialDataLoad_CRM');
GO
