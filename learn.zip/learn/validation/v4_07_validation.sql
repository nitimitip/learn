/* V4-07 validation. Not executed by the author.
   Everything here only reads real tables. V4-07.2 writes only to a ## temp table. */

/* ===== usp_GetDropDownAddressByID + index 03 ===== */

/* V4-07.1 Production, BEFORE the index change. Are there customers with millions of addresses?
   Reads the parentID index only (about 17k pages) under READUNCOMMITTED.
   Decision: 9.1M reads at about 3-4 per key lookup needs a parent of about 2-3M addresses.
   - Largest parent above about 1M: the explanation holds. Deploy.
   - Largest parent below that: the explanation is wrong. Do NOT deploy; send the result. */
SELECT TOP (10) parentID, COUNT(*) AS address_rows
FROM dbo.BT_ADDRESS_MASTER WITH (READUNCOMMITTED, INDEX (IX_BT_ADDRESS_MASTER_parentID))
GROUP BY parentID
ORDER BY COUNT(*) DESC;
GO

/* V4-07.2 UAT compare. Keep THIS query window open throughout, because the ## table lives
   with it. Run the capture batch with @phase = 'before', apply the index in another window,
   run it again with @phase = 'after', then run the compare. Rows AND their order must match:
   the dropdown has no ORDER BY, so this is the check that the index keeps the order.
   The Messages tab shows logical reads; BT_ADDRESS_MASTER reads should fall. */
IF OBJECT_ID('tempdb..##v407') IS NULL
    CREATE TABLE ##v407 (
        seq int IDENTITY(1,1), phase varchar(6) NULL, case_no int NULL,
        selectValue int, selectDescription varchar(max), addressUsage int);
GO
DECLARE @phase varchar(6) = 'before';   -- then 'after'
DECLARE @big int, @small int;
SELECT TOP (1) @big = parentID FROM dbo.BT_ADDRESS_MASTER WITH (READUNCOMMITTED, INDEX (IX_BT_ADDRESS_MASTER_parentID))
GROUP BY parentID ORDER BY COUNT(*) DESC, parentID;
SELECT TOP (1) @small = parentID FROM dbo.BT_ADDRESS_MASTER WITH (READUNCOMMITTED, INDEX (IX_BT_ADDRESS_MASTER_parentID))
WHERE parentID > 0 GROUP BY parentID HAVING COUNT(*) BETWEEN 5 AND 50 ORDER BY parentID;

SET STATISTICS IO ON;
INSERT ##v407 (selectValue, selectDescription, addressUsage) EXEC dbo.usp_GetDropDownAddressByID @big, 'Customer', 0;
UPDATE ##v407 SET phase = @phase, case_no = 1 WHERE phase IS NULL;
INSERT ##v407 (selectValue, selectDescription, addressUsage) EXEC dbo.usp_GetDropDownAddressByID @small, 'Customer', 0;
UPDATE ##v407 SET phase = @phase, case_no = 2 WHERE phase IS NULL;
SET STATISTICS IO OFF;
GO
/* Compare: all four columns must be 0, and rows_before must equal rows_after. */
WITH b AS (SELECT case_no, ROW_NUMBER() OVER (PARTITION BY case_no ORDER BY seq) AS pos, selectValue, selectDescription, addressUsage FROM ##v407 WHERE phase = 'before'),
     a AS (SELECT case_no, ROW_NUMBER() OVER (PARTITION BY case_no ORDER BY seq) AS pos, selectValue, selectDescription, addressUsage FROM ##v407 WHERE phase = 'after')
SELECT ISNULL(b.case_no, a.case_no) AS case_no,
       COUNT(b.pos) AS rows_before,
       COUNT(a.pos) AS rows_after,
       SUM(CASE WHEN b.pos IS NULL OR a.pos IS NULL THEN 1 ELSE 0 END) AS missing_rows,
       SUM(CASE WHEN b.selectValue <> a.selectValue THEN 1 ELSE 0 END) AS different_address_or_order,
       SUM(CASE WHEN b.selectDescription <> a.selectDescription THEN 1 ELSE 0 END) AS different_description,
       SUM(CASE WHEN b.addressUsage <> a.addressUsage THEN 1 ELSE 0 END) AS different_usage
FROM b FULL JOIN a ON a.case_no = b.case_no AND a.pos = b.pos
GROUP BY ISNULL(b.case_no, a.case_no)
ORDER BY 1;
GO

/* V4-07.3 Production, after a few days. Baseline from sp_execuation_stat.xlsx:
   15,967 calls, 33.2 ms avg, 32.4 ms CPU, 31,110 reads per call, max 9,097,239 reads, 12.3 s max. */
SELECT s.cached_time, s.execution_count,
       s.total_elapsed_time / s.execution_count / 1000 AS avg_ms,
       s.total_worker_time / s.execution_count / 1000 AS avg_cpu_ms,
       s.total_logical_reads / s.execution_count AS avg_reads,
       s.max_logical_reads, s.max_elapsed_time / 1000 AS max_ms
FROM sys.dm_exec_procedure_stats AS s
WHERE s.database_id = DB_ID()
  AND s.object_id = OBJECT_ID(N'dbo.usp_GetDropDownAddressByID');
GO

/* ===== SP_LIST_NOTE_USAGE ===== */

/* V4-07.4 Run on UAT or production, BEFORE deployment. Rows with the same LOV_DESC have no
   fixed order, so a new plan may show them in a different order in the list.
   Any row here is not a blocker. It tells you what to look at on the screen. */
SELECT LOV_DESC, COUNT(*) AS same_description
FROM dbo.MT_SYS_LOV WITH (READUNCOMMITTED)
WHERE LOV_NAME LIKE '%sysNoteUsage%' AND LOV_DELETED <> 1
GROUP BY LOV_DESC
HAVING COUNT(*) > 1;
GO

/* V4-07.5 UAT, before and after deployment. Save both results: same rows, same LOV_DESC order. */
SET STATISTICS TIME ON;
EXEC dbo.SP_LIST_NOTE_USAGE;
SET STATISTICS TIME OFF;
GO

/* V4-07.6 Production, after a few days. Baseline from sp_execuation_stat.xlsx:
   2,671 calls, 146 ms avg, 142 ms CPU, 587 reads per call. Reads are expected to stay about the same. */
SELECT s.cached_time, s.execution_count,
       s.total_elapsed_time / s.execution_count / 1000 AS avg_ms,
       s.total_worker_time / s.execution_count / 1000 AS avg_cpu_ms,
       s.total_logical_reads / s.execution_count AS avg_reads
FROM sys.dm_exec_procedure_stats AS s
WHERE s.database_id = DB_ID()
  AND s.object_id = OBJECT_ID(N'dbo.SP_LIST_NOTE_USAGE');
GO

/* ===== SP_GET_ALL_ENQ_DATA (56.1 min, not yet explained, no change in this batch) ===== */

/* V4-07.7 Production. Which statements hold the 2,470 reads and 90 ms of CPU per call?
   Same query as V4-06.5, for this SP. */
SELECT TOP (15)
       SUBSTRING(t.text, s.statement_start_offset / 2 + 1, 120) AS stmt_head,
       s.execution_count,
       s.total_worker_time / 1000 AS total_cpu_ms,
       s.total_logical_reads AS total_reads,
       s.total_logical_reads / s.execution_count AS avg_reads,
       s.total_worker_time / s.execution_count AS avg_cpu_us
FROM sys.dm_exec_query_stats AS s
CROSS APPLY sys.dm_exec_sql_text(s.sql_handle) AS t
WHERE t.objectid = OBJECT_ID(N'dbo.SP_GET_ALL_ENQ_DATA')
  AND t.dbid = DB_ID()
ORDER BY s.total_worker_time DESC;
GO
