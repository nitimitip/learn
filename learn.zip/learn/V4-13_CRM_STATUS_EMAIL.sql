USE [QPID_PROD]
GO
/******************************************************************************
  V4-13 - HOURLY BT_MESSAGE STATUS EMAIL - NOT EXECUTED - TEST ON UAT FIRST
  Creates : table dbo.QPID_CRM_Status_Report_Recipient (email addresses)
            table dbo.QPID_CRM_Status_Report_Log (saved counts)
            procedure dbo.usp_QPID_CRM_Status_Report
            SQL Agent job 'QPID - CRM status report hourly'
  Change  : adds these objects only. No existing table or procedure is changed.
  Report  : messages with Message_Received_On today. No email if none of them is at F or P.
  Needs   : Database Mail with a working profile, and SQL Server Agent running.
  Before  : SET THE MAIL PROFILE BELOW. The script refuses until it is set.
  After   : add email addresses to dbo.QPID_CRM_Status_Report_Recipient.
  Run as  : a login in sysadmin. Re-running replaces the procedure and the job and
            keeps the email addresses and the saved counts.
******************************************************************************/
SET NOEXEC OFF;
SET NOCOUNT ON;
GO
IF OBJECT_ID('tempdb..#v413_config') IS NOT NULL DROP TABLE #v413_config;
CREATE TABLE #v413_config (MailProfile sysname NOT NULL);

INSERT INTO #v413_config (MailProfile) VALUES (
    N'CHANGE_ME'     -- Database Mail profile: SELECT name FROM msdb.dbo.sysmail_profile;
);

IF NOT EXISTS (SELECT 1 FROM msdb.dbo.sysmail_profile p JOIN #v413_config c ON c.MailProfile = p.name)
BEGIN
    RAISERROR('REFUSED: set a Database Mail profile that exists at the top of this script. Nothing changed.', 16, 1);
    SET NOEXEC ON;
END
GO
IF OBJECT_ID('dbo.QPID_CRM_Status_Report_Recipient', 'U') IS NULL
    CREATE TABLE dbo.QPID_CRM_Status_Report_Recipient (
        Email      varchar(320) NOT NULL,
        Is_Active  bit          NOT NULL
            CONSTRAINT DF_QPID_CRM_Status_Report_Recipient_Active DEFAULT (1),
        Added_On   datetime     NOT NULL
            CONSTRAINT DF_QPID_CRM_Status_Report_Recipient_Added DEFAULT (GETDATE()),
        CONSTRAINT PK_QPID_CRM_Status_Report_Recipient PRIMARY KEY CLUSTERED (Email),
        CONSTRAINT CK_QPID_CRM_Status_Report_Recipient_Email
            CHECK (Email LIKE '%_@_%._%' AND Email NOT LIKE '%[; ,]%')
    );
GO
IF OBJECT_ID('dbo.QPID_CRM_Status_Report_Log', 'U') IS NULL
    CREATE TABLE dbo.QPID_CRM_Status_Report_Log (
        Run_At   datetime      NOT NULL,
        Source   varchar(100)  NOT NULL,
        F_Count  int           NOT NULL,
        P_Count  int           NOT NULL,
        W_Count  int           NOT NULL,
        I_Count  int           NOT NULL,
        CONSTRAINT PK_QPID_CRM_Status_Report_Log PRIMARY KEY CLUSTERED (Run_At, Source)
    );
GO
IF OBJECT_ID('dbo.usp_QPID_CRM_Status_Report', 'P') IS NULL
    EXEC ('CREATE PROCEDURE dbo.usp_QPID_CRM_Status_Report AS RETURN 0;');
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE dbo.usp_QPID_CRM_Status_Report
    @MailProfile sysname,
    @KeepDays    int = 90
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @recipients varchar(max) = STUFF((
        SELECT ';' + Email
        FROM dbo.QPID_CRM_Status_Report_Recipient
        WHERE Is_Active = 1
        ORDER BY Email
        FOR XML PATH(''), TYPE).value('.', 'varchar(max)'), 1, 1, '');

    -- Fails the job step, so the job history shows why no email went out.
    IF @recipients IS NULL
    BEGIN
        RAISERROR('No active email address in dbo.QPID_CRM_Status_Report_Recipient. No email sent.', 16, 1);
        RETURN;
    END

    DECLARE @now datetime = GETDATE();
    DECLARE @today datetime = CONVERT(date, @now);
    DECLARE @tomorrow datetime = DATEADD(DAY, 1, @today);
    -- The previous report of today only. The first report of the day compares with zero.
    DECLARE @prev datetime = (SELECT MAX(Run_At) FROM dbo.QPID_CRM_Status_Report_Log WHERE Run_At >= @today);

    -- NOLOCK so this report never waits on or blocks the loaders. Counts are approximate
    -- while a loader is running.
    SELECT ISNULL(NULLIF(Source COLLATE DATABASE_DEFAULT, ''), '(none)') AS Source,
           SUM(CASE WHEN Message_Status = 'F' THEN 1 ELSE 0 END) AS F_Count,
           SUM(CASE WHEN Message_Status = 'P' THEN 1 ELSE 0 END) AS P_Count,
           SUM(CASE WHEN Message_Status = 'W' THEN 1 ELSE 0 END) AS W_Count,
           SUM(CASE WHEN Message_Status = 'I' THEN 1 ELSE 0 END) AS I_Count
    INTO #now
    FROM dbo.BT_Message WITH (NOLOCK)
    WHERE Message_Status IN ('F', 'P', 'W', 'I')
      AND Message_Received_On >= @today
      AND Message_Received_On < @tomorrow
    GROUP BY ISNULL(NULLIF(Source COLLATE DATABASE_DEFAULT, ''), '(none)');

    -- Nothing at F or P for today: no email, and the job step still succeeds.
    IF NOT EXISTS (SELECT 1 FROM #now WHERE F_Count + P_Count > 0)
        RETURN;

    -- FULL JOIN: a source whose count has fallen to zero still shows its change.
    SELECT COALESCE(n.Source, p.Source) AS Source,
           ISNULL(n.F_Count, 0) AS F_Count,
           ISNULL(n.P_Count, 0) AS P_Count,
           ISNULL(n.W_Count, 0) AS W_Count,
           ISNULL(n.I_Count, 0) AS I_Count,
           ISNULL(n.F_Count, 0) - ISNULL(p.F_Count, 0) AS F_Change,
           ISNULL(n.P_Count, 0) - ISNULL(p.P_Count, 0) AS P_Change
    INTO #report
    FROM #now n
    FULL JOIN (SELECT Source, F_Count, P_Count
               FROM dbo.QPID_CRM_Status_Report_Log
               WHERE Run_At = @prev) p ON p.Source = n.Source;

    DECLARE @fTotal int, @pTotal int, @wTotal int, @iTotal int, @fChange int, @pChange int;
    SELECT @fTotal = ISNULL(SUM(F_Count), 0), @pTotal = ISNULL(SUM(P_Count), 0),
           @wTotal = ISNULL(SUM(W_Count), 0), @iTotal = ISNULL(SUM(I_Count), 0),
           @fChange = ISNULL(SUM(F_Change), 0), @pChange = ISNULL(SUM(P_Change), 0)
    FROM #report;

    DECLARE @fText varchar(30) = CASE WHEN @fChange > 0 THEN '+' + CONVERT(varchar(20), @fChange)
                                      ELSE CONVERT(varchar(20), @fChange) END;
    DECLARE @pText varchar(30) = CASE WHEN @pChange > 0 THEN '+' + CONVERT(varchar(20), @pChange)
                                      ELSE CONVERT(varchar(20), @pChange) END;

    DECLARE @rows nvarchar(max) = CONVERT(nvarchar(max), (
        SELECT td = x.Source, '',
               td = CONVERT(varchar(20), x.F_Count), '',
               td = CASE WHEN x.F_Change > 0 THEN '+' + CONVERT(varchar(20), x.F_Change)
                         ELSE CONVERT(varchar(20), x.F_Change) END, '',
               td = CONVERT(varchar(20), x.P_Count), '',
               td = CASE WHEN x.P_Change > 0 THEN '+' + CONVERT(varchar(20), x.P_Change)
                         ELSE CONVERT(varchar(20), x.P_Change) END, '',
               td = CONVERT(varchar(20), x.W_Count), '',
               td = CONVERT(varchar(20), x.I_Count), ''
        FROM (SELECT 0 AS Sort, Source, F_Count, F_Change, P_Count, P_Change, W_Count, I_Count FROM #report
              UNION ALL
              SELECT 1, 'TOTAL', @fTotal, @fChange, @pTotal, @pChange, @wTotal, @iTotal) x
        ORDER BY x.Sort, x.Source
        FOR XML PATH('tr'), TYPE));

    DECLARE @subject nvarchar(255) = N'QPID message status - ' + CONVERT(nvarchar(128), @@SERVERNAME)
        + N' - ' + CONVERT(nvarchar(16), @now, 120)
        + N' - F: ' + CONVERT(nvarchar(20), @fTotal) + N' (' + @fText + N')'
        + N', P: ' + CONVERT(nvarchar(20), @pTotal) + N' (' + @pText + N')'
        + N', W: ' + CONVERT(nvarchar(20), @wTotal)
        + N', I: ' + CONVERT(nvarchar(20), @iTotal);

    DECLARE @body nvarchar(max) =
          N'<p style="font-family:Arial;font-size:13px">BT_Message status on <b>'
        + CONVERT(nvarchar(128), @@SERVERNAME) + N'</b> at ' + CONVERT(nvarchar(16), @now, 120)
        + N', for messages received on ' + CONVERT(nvarchar(10), @today, 120) + N'.</p>'
        + N'<table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse;font-family:Arial;font-size:13px">'
        + N'<tr><th>Source</th><th>F (failed)</th><th>F change</th><th>P (processed)</th><th>P change</th>'
        + N'<th>W (waiting)</th><th>I (in progress)</th></tr>'
        + @rows
        + N'</table>'
        + N'<p style="font-family:Arial;font-size:12px">Counts are today''s messages at that status now. '
        + N'Messages received on earlier days are not included. Change is the net change since '
        + CASE WHEN @prev IS NULL THEN N'the start of the day' ELSE CONVERT(nvarchar(16), @prev, 120) END
        + N'. I can be a message being processed now: it is a concern if it stays above 0 across several reports. '
        + N'Counts are approximate while a loader is running.</p>';

    EXEC msdb.dbo.sp_send_dbmail
         @profile_name = @MailProfile,
         @recipients   = @recipients,
         @subject      = @subject,
         @body         = @body,
         @body_format  = 'HTML';

    -- Saved only after the mail is queued, so a failed or skipped run does not lose a period:
    -- the next report's change then covers it.
    INSERT INTO dbo.QPID_CRM_Status_Report_Log (Run_At, Source, F_Count, P_Count, W_Count, I_Count)
    SELECT @now, Source, F_Count, P_Count, W_Count, I_Count FROM #now;

    DELETE FROM dbo.QPID_CRM_Status_Report_Log WHERE Run_At < DATEADD(DAY, -@KeepDays, @now);
END
GO
DECLARE @jobName sysname = N'QPID - CRM status report hourly';
DECLARE @profile sysname, @command nvarchar(max), @db sysname = DB_NAME();
SELECT @profile = MailProfile FROM #v413_config;
SET @command = N'EXEC dbo.usp_QPID_CRM_Status_Report @MailProfile = N''' + REPLACE(@profile, N'''', N'''''') + N''';';

BEGIN TRY
    BEGIN TRANSACTION;
    IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE name = @jobName)
        EXEC msdb.dbo.sp_delete_job @job_name = @jobName;
    EXEC msdb.dbo.sp_add_job
         @job_name = @jobName,
         @enabled = 1,
         @description = N'Emails the BT_Message status counts every hour. Addresses are in dbo.QPID_CRM_Status_Report_Recipient. See optimization_v4/V4-13_NOTES.md.';
    EXEC msdb.dbo.sp_add_jobstep
         @job_name = @jobName,
         @step_name = N'Send report',
         @subsystem = N'TSQL',
         @database_name = @db,
         @command = @command,
         @on_success_action = 1,
         @on_fail_action = 2;
    EXEC msdb.dbo.sp_add_jobschedule
         @job_name = @jobName,
         @name = N'Every hour',
         @enabled = 1,
         @freq_type = 4,              -- daily
         @freq_interval = 1,
         @freq_subday_type = 8,       -- hours
         @freq_subday_interval = 1,
         @active_start_time = 0;      -- on the hour
    EXEC msdb.dbo.sp_add_jobserver @job_name = @jobName, @server_name = N'(local)';
    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    DECLARE @msg nvarchar(2048) = N'REFUSED: the job was not created. ' + ERROR_MESSAGE();
    RAISERROR(@msg, 16, 1);
END CATCH
GO
SET NOEXEC OFF;
GO
IF OBJECT_ID('dbo.usp_QPID_CRM_Status_Report', 'P') IS NOT NULL
   AND OBJECT_ID('dbo.QPID_CRM_Status_Report_Recipient', 'U') IS NOT NULL
   AND OBJECT_ID('dbo.QPID_CRM_Status_Report_Log', 'U') IS NOT NULL
   AND EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE name = N'QPID - CRM status report hourly')
   AND EXISTS (SELECT 1 FROM msdb.dbo.sysmail_profile p JOIN #v413_config c ON c.MailProfile = p.name)
BEGIN
    PRINT 'DEPLOYED: V4-13 hourly status report.';
    IF NOT EXISTS (SELECT 1 FROM dbo.QPID_CRM_Status_Report_Recipient WHERE Is_Active = 1)
        PRINT 'NEXT: add email addresses to dbo.QPID_CRM_Status_Report_Recipient. The job fails until you do.';
END
ELSE
    RAISERROR('NOT DEPLOYED: see the messages above.', 16, 1);
GO
IF OBJECT_ID('tempdb..#v413_config') IS NOT NULL DROP TABLE #v413_config;
GO
