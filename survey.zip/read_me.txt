Below is the complete, ready-to-use solution for Option 1, including the C# files for your .NET application and the complete, updated url_journey_recorder.py script that handles both popups/new tabs and the new .NET Methods Excel sheet.

Part 1: C# (.NET Application) Setup
This setup uses MethodTimer.Fody (to automatically time every method and sub-method at compile time without cluttering your code) and an IHttpModule (to automatically attach the captured method timings to the HTTP response headers on every request).

Step 1: Install the NuGet Package
In Visual Studio, open the Package Manager Console for your web project and run:

Install-Package MethodTimer.Fody



(Note: Ensure a file named FodyWeavers.xml is created in your project root containing <Weavers><MethodTimer/></Weavers>—the NuGet installer does this automatically).

Step 2: Add MethodTimingTracker.cs to your Project
Create a new class file in your .NET project (for example, MethodTimingTracker.cs) and paste the following complete code:


using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using MethodTimer;

// This single line tells Fody to automatically time EVERY method and sub-method in your project!
// (If you only want to time specific classes like LetterEditor, remove this line and put [Time] above the class instead).
[assembly: Time]

namespace NPg_CDACDMS
{
    /// <summary>
    /// 1. MethodTimeLogger is automatically called by MethodTimer.Fody whenever any method finishes.
    /// Must remain a public static class named MethodTimeLogger in the root or global namespace.
    /// </summary>
    public static class MethodTimeLogger
    {
        public static void Log(MethodBase methodBase, TimeSpan elapsed, string message)
        {
            try
            {
                string className = methodBase.DeclaringType != null ? methodBase.DeclaringType.Name : "Global";
                string methodName = $"{className}.{methodBase.Name}";
                RequestMethodProfiler.Record(methodName, (long)elapsed.TotalMilliseconds);
            }
            catch
            {
                // Never interfere with application execution
            }
        }
    }

    /// <summary>
    /// 2. Stores method timings per HTTP request and writes them to the X-Net-Methods response header.
    /// </summary>
    public static class RequestMethodProfiler
    {
        private const string ContextKey = "__NetMethodTimings";

        public static void Record(string methodName, long elapsedMs)
        {
            var ctx = HttpContext.Current;
            if (ctx?.Items == null) return;

            var list = ctx.Items[ContextKey] as List<string>;
            if (list == null)
            {
                list = new List<string>();
                ctx.Items[ContextKey] = list;
            }

            // Cap at 60 entries per request so we never exceed IIS HTTP response header size limits
            if (list.Count < 60)
            {
                list.Add($"{methodName}:{elapsedMs}");
            }
        }

        public static void FlushToResponseHeaders()
        {
            var ctx = HttpContext.Current;
            if (ctx?.Items == null || ctx.Response == null) return;

            if (ctx.Items[ContextKey] is List<string> list && list.Count > 0)
            {
                try
                {
                    // Writes header: X-Net-Methods: LetterEditor.Page_Load:15,LetterEditor.ASPxRichEditFormatPainter:42
                    ctx.Response.Headers["X-Net-Methods"] = string.Join(",", list);
                }
                catch
                {
                    // Ignore if headers were already flushed to client
                }
            }
        }
    }

    /// <summary>
    /// 3. HTTP Module that automatically flushes the collected method timings on every WebForms/AJAX request.
    /// </summary>
    public class MethodTimingHttpModule : IHttpModule
    {
        public void Init(HttpApplication context)
        {
            context.PreSendRequestHeaders += (sender, e) =>
            {
                RequestMethodProfiler.FlushToResponseHeaders();
            };
        }

        public void Dispose() { }
    }
}




Step 3: Register the Module in Web.config
In your application's Web.config, add MethodTimingHttpModule inside <system.webServer><modules>:

<configuration>
  <system.webServer>
    <modules>
      <add name="MethodTimingHttpModule" type="NPg_CDACDMS.MethodTimingHttpModule" />
    </modules>
  </system.webServer>
</configuration>



That's it for C#. You do not need to modify LetterEditor.cs or any of its methods (Page_Load, btnSaveDocument_Click, ASPxRichEditFormatPainter, etc.)—they will all be timed and sent to the browser automatically when compiled.

What happens when you run this now:
Popups & New Tabs: Whenever a button opens a popup or new tab, the console prints NOTE: New tab/popup detected (...) - attaching recorder to Tab 2 and records all clicks, form submissions, and network requests in that popup prefixed with [Tab 2] (and continues recording Tab 1 when you close the popup or switch back).

.NET Method & Sub-Method Timings: Every HTTP response coming back from your .NET application carries the X-Net-Methods header. The Excel report now includes:

Two new columns on the Journey sheet (.NET Methods count and Slowest .NET Method).

A dedicated .NET Methods sheet listing the Step #, User Action, Page, Request URL, C# Class.Method (including sub-methods like LetterEditor.ASPxRichEditFormatPainter), and Execution Time (ms).








