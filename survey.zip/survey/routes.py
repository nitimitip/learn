"""
routes.py - every screen and action in the Survey module.

    /survey/                       My surveys    list, templates, hero
    /survey/new                    Builder       new survey (?template=key)
    /survey/<id>                   Dashboard     link, figures, every
                                                 response (opens in full)
    /survey/<id>/edit              Builder       edit (questions frozen once
                                                 anybody has answered)
    /survey/<id>/responses         -> /survey/<id> (kept for old links)
    /survey/<id>/preview           Preview       the public form, no submit
    /survey/<id>/export.xlsx       Excel report
    /survey/<id>/status            POST open / close
    /survey/<id>/duplicate         POST copy into a new draft
    /survey/<id>/delete            POST delete now
    /survey/members                Members       admin only

    /f/<token>                     PUBLIC        answer the survey
    /f/<token>/thanks              PUBLIC        confirmation
    /survey/s/<token>[/thanks]     PUBLIC        the same, at the original
                                                 address (old links keep
                                                 working; the public-only
                                                 site does NOT answer it)

ACCESS is decided by service.py - see its docstring. Everything except the
two public routes needs a signed-in survey member (or admin); a survey that is
not yours, or has expired, is a 404 so the route does not confirm it exists.

The public routes need no sign-in: the link is the credential, so its token is
24 random URL-safe characters rather than the row id. CSRF still applies - the
global gate issues an anonymous session its own token, which the form carries.
"""

import io
import json
import logging
from datetime import datetime
from functools import wraps

from flask import (Blueprint, abort, flash, redirect, render_template,
                   request, send_file, url_for)

from auth import get_current_user
from database import get_db_session
from models import User

from . import public_gate, report_excel, schema as S, service, templates_lib
from .models import (RETENTION_DAYS, STATUS_CLOSED, STATUS_OPEN,
                     SurveyMember)

logger = logging.getLogger(__name__)

survey_bp = Blueprint('survey', __name__,
                      template_folder='../../templates/survey')

# The participant's link, at a neutral top-level address (/f/<token>) that
# names neither the application nor the module. Registered with no prefix.
# It is the only blueprint a public-only deployment answers - see
# public_gate.py.
survey_public_bp = Blueprint('survey_public', __name__,
                             template_folder='../../templates/survey')


@survey_bp.after_request
def _no_store(response):
    """Never reuse a survey page from the browser cache.

    Results change with every response, and a cached public form could be
    resubmitted after the survey closed or was deleted.
    """
    if response.mimetype == 'text/html':
        response.headers['Cache-Control'] = 'no-store, max-age=0'
    return response


# The participant pages: never cached either, and never indexed.
@survey_public_bp.after_request
def _public_headers(response):
    response = _no_store(response)
    response.headers['X-Robots-Tag'] = 'noindex, nofollow'
    return response


# ---------------------------------------------------------------------------
# Auth gates
# ---------------------------------------------------------------------------

def member_required(view):
    """Signed in AND a survey member (admins are members implicitly)."""
    @wraps(view)
    def wrapper(*args, **kwargs):
        user = get_current_user()
        if not user:
            flash('Please sign in to use Surveys.', 'error')
            return redirect(url_for('login'))
        db_session = get_db_session()
        try:
            allowed = service.is_member(db_session, user)
        finally:
            db_session.close()
        if not allowed:
            flash('Surveys are limited to survey members. Ask an '
                  'administrator to add you.', 'error')
            return redirect(url_for('index'))
        return view(*args, user=user, **kwargs)
    return wrapper


def admin_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        user = get_current_user()
        if not user:
            flash('Please sign in to use Surveys.', 'error')
            return redirect(url_for('login'))
        if user.role != 'admin':
            flash('Administrator access is required to manage survey '
                  'members.', 'error')
            return redirect(url_for('survey.index'))
        return view(*args, user=user, **kwargs)
    return wrapper


def _public_url(survey):
    """The link participants get. On the public-only site when one is
    configured (SURVEY_PUBLIC_BASE_URL), otherwise on this site - either way
    at the neutral /f/<token> address."""
    path = url_for('survey_public.respond', token=survey.token)
    if public_gate.PUBLIC_BASE_URL:
        return public_gate.PUBLIC_BASE_URL + path
    return url_for('survey_public.respond', token=survey.token,
                   _external=True)


def _owner_names(db_session, surveys):
    ids = {s.owner_id for s in surveys}
    if not ids:
        return {}
    return {u.id: _display(u) for u in
            db_session.query(User).filter(User.id.in_(ids)).all()}


def _display(u):
    if u is None:
        return 'Unknown'
    name = ' '.join(p for p in (u.firstname, u.lastname) if p).strip()
    return name.title() if name else u.username


def _ctx(user, **extra):
    extra.setdefault('is_admin', user is not None and user.role == 'admin')
    extra['user'] = user
    extra['retention_days'] = RETENTION_DAYS
    return extra


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------

@survey_bp.route('/')
@member_required
def index(user=None):
    service.maybe_purge()
    db_session = get_db_session()
    try:
        surveys = service.visible_surveys(db_session, user)
        counts = service.response_counts(db_session, [s.id for s in surveys])
        owners = _owner_names(db_session, surveys)
        now = datetime.now()
        rows = [{
            'survey': s,
            'responses': counts.get(s.id, 0),
            'owner': owners.get(s.owner_id, 'Unknown'),
            'mine': s.owner_id == user.id,
            'days_left': s.days_left(now),
            'url': _public_url(s),
        } for s in surveys]
        stats = {
            'total': len(rows),
            'open': sum(1 for r in rows if r['survey'].status == STATUS_OPEN),
            'responses': sum(r['responses'] for r in rows),
            'expiring': sum(1 for r in rows if r['days_left'] <= 7),
        }
        return render_template('survey/index.html', **_ctx(
            user, rows=rows, stats=stats,
            templates=templates_lib.TEMPLATES))
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Builder
# ---------------------------------------------------------------------------

def _builder(user, survey=None, title='', description='', form_schema=None,
             locked=False, response_total=0):
    return render_template('survey/builder.html', **_ctx(
        user, survey=survey, title=title, description=description,
        schema_data=form_schema or {'questions': []},
        locked=locked, response_total=response_total,
        type_labels=S.TYPE_LABELS, ack_default=S.default_ack(),
        reason_default=S.REASON_DEFAULT_LABEL,
        limits={'questions': S.MAX_QUESTIONS, 'options': S.MAX_OPTIONS,
                'rows': S.MAX_ROWS, 'columns': S.MAX_COLUMNS}))


def _posted():
    return (request.form.get('title', ''),
            request.form.get('description', ''),
            request.form.get('schema', ''))


@survey_bp.route('/new', methods=['GET', 'POST'])
@member_required
def create(user=None):
    if request.method == 'GET':
        tpl = templates_lib.BY_KEY.get(request.args.get('template') or '')
        if tpl:
            return _builder(user, title=tpl['title'],
                            description=tpl['description'],
                            form_schema=S.normalise(tpl['schema']))
        return _builder(user)

    title, description, raw = _posted()
    publish = request.form.get('action') == 'publish'
    db_session = get_db_session()
    try:
        survey = service.create_survey(db_session, user, title, description,
                                       raw)
        if publish:
            service.set_status(survey, STATUS_OPEN)
        db_session.commit()
        flash('Survey %s. It will be deleted automatically on %s.' % (
            'published - share the link below' if publish else
            'saved as a draft', survey.expires_at.strftime('%d %b %Y')),
            'success')
        return redirect(url_for('survey.detail', survey_id=survey.id))
    except S.SchemaError as exc:
        db_session.rollback()
        flash(str(exc), 'error')
        return _builder(user, title=title, description=description,
                        form_schema=_loose(raw))
    except Exception:
        db_session.rollback()
        logger.exception('Survey create failed')
        flash('The survey could not be saved.', 'error')
        return _builder(user, title=title, description=description,
                        form_schema=_loose(raw))
    finally:
        db_session.close()


def _loose(raw):
    """Best-effort reload of a rejected form, so the builder keeps the work."""
    try:
        data = json.loads(raw or '{}')
        if isinstance(data, dict) and isinstance(data.get('questions'), list):
            return data
    except ValueError:
        pass
    return {'questions': []}


@survey_bp.route('/<int:survey_id>/edit', methods=['GET', 'POST'])
@member_required
def edit(survey_id, user=None):
    db_session = get_db_session()
    try:
        survey = service.get_managed(db_session, user, survey_id)
        if survey is None:
            abort(404)
        total = service.response_count(db_session, survey)
        if request.method == 'GET':
            return _builder(user, survey=survey, title=survey.title,
                            description=survey.description or '',
                            form_schema=S.load(survey.schema_json),
                            locked=total > 0, response_total=total)

        title, description, raw = _posted()
        try:
            saved = service.update_survey(db_session, survey, title,
                                          description, raw)
            if request.form.get('action') == 'publish':
                service.set_status(survey, STATUS_OPEN)
            db_session.commit()
        except S.SchemaError as exc:
            db_session.rollback()
            flash(str(exc), 'error')
            return _builder(user, survey=survey, title=title,
                            description=description, form_schema=_loose(raw),
                            locked=total > 0, response_total=total)
        flash('Survey saved.' if saved else
              'Title and description saved. The questions are locked '
              'because people have already answered - duplicate the survey '
              'to change them.', 'success' if saved else 'warning')
        return redirect(url_for('survey.detail', survey_id=survey.id))
    except Exception as exc:
        if getattr(exc, 'code', None) == 404:
            raise
        db_session.rollback()
        logger.exception('Survey edit failed for %s', survey_id)
        flash('The survey could not be saved.', 'error')
        return redirect(url_for('survey.index'))
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------

def _load_results(db_session, user, survey_id):
    survey = service.get_managed(db_session, user, survey_id)
    if survey is None:
        abort(404)
    form_schema = S.load(survey.schema_json)
    responses = list(survey.responses)
    return survey, form_schema, responses


@survey_bp.route('/<int:survey_id>')
@member_required
def detail(survey_id, user=None):
    """The survey's dashboard: its link and headline figures, then every
    response in a table - each one opens in full. There is no separate
    summary screen; the Excel download carries the summary sheet."""
    db_session = get_db_session()
    try:
        survey, form_schema, items = _load_results(db_session, user,
                                                   survey_id)
        names = service.respondent_names(db_session, items)
        questions = S.answerable(form_schema)
        rows = []
        numbers = S.question_numbers(form_schema)
        rules = dict((q['id'], S.rule_text(form_schema, q, numbers))
                     for q in questions if q.get('show_if'))
        for i, r in enumerate(items, start=1):
            answers = service.load_answers(r)
            signed = answers.get(S.ACK_KEY) or {}
            # Questions skipped by a show_if rule were never asked of this
            # person, so they count neither as answered nor as missed.
            shown = S.shown_ids(form_schema, answers)
            rows.append({
                'number': i,
                'submitted_at': r.submitted_at,
                'respondent': service.respondent_label(
                    answers, names.get(r.respondent_user_id)),
                'account': names.get(r.respondent_user_id),
                'answers': answers,
                'answered': sum(1 for q in questions
                                if q['id'] in shown and
                                answers.get(q['id']) not in
                                (None, '', [], {})),
                'asked': len(shown),
                'shown': shown,
                'ack': signed if signed.get('confirmed') else None,
            })
        rows.reverse()                  # newest first on screen
        ack = S.ack_of(form_schema)
        owner = db_session.get(User, survey.owner_id)
        return render_template('survey/detail.html', **_ctx(
            user, survey=survey, form_schema=form_schema, rows=rows,
            questions=questions, ack=ack, answer_text=S.answer_text,
            reason_key=S.reason_key, rules=rules,
            owner_name=_display(owner), url=_public_url(survey),
            days_left=survey.days_left(),
            latest=items[-1].submitted_at if items else None,
            acked=(sum(1 for r in rows if r['ack']) if ack else None),
            type_labels=S.TYPE_LABELS))
    finally:
        db_session.close()


@survey_bp.route('/<int:survey_id>/responses')
@member_required
def responses(survey_id, user=None):
    """Old address of the responses list - it IS the survey page now."""
    return redirect(url_for('survey.detail', survey_id=survey_id))


@survey_bp.route('/<int:survey_id>/export.xlsx')
@member_required
def export(survey_id, user=None):
    db_session = get_db_session()
    try:
        survey, form_schema, items = _load_results(db_session, user,
                                                   survey_id)
        names = service.respondent_names(db_session, items)
        owner = db_session.get(User, survey.owner_id)
        rows = [{
            'id': r.id,
            'submitted_at': r.submitted_at,
            'respondent': service.respondent_label(
                service.load_answers(r), names.get(r.respondent_user_id)),
            'answers': service.load_answers(r),
        } for r in items]
        meta = {
            'title': survey.title,
            'description': survey.description,
            'status': survey.status,
            'url': _public_url(survey),
            'owner': _display(owner),
            'created_at': survey.created_at,
            'published_at': survey.published_at,
            'expires_at': survey.expires_at,
            'generated_at': datetime.now(),
            'generated_by': _display(user),
        }
        data = report_excel.build_workbook(
            meta, form_schema, rows, service.summarise(form_schema, items))
    finally:
        db_session.close()

    safe = ''.join(ch if ch.isalnum() or ch in ' -_' else ' '
                   for ch in survey.title).strip()
    safe = '_'.join(safe.split())[:60] or 'survey'
    filename = 'Survey_%s_%s.xlsx' % (safe, datetime.now().strftime('%Y%m%d'))
    return send_file(
        io.BytesIO(data), as_attachment=True, download_name=filename,
        mimetype='application/vnd.openxmlformats-officedocument.'
                 'spreadsheetml.sheet')


@survey_bp.route('/<int:survey_id>/preview')
@member_required
def preview(survey_id, user=None):
    db_session = get_db_session()
    try:
        survey = service.get_managed(db_session, user, survey_id)
        if survey is None:
            abort(404)
        return render_template('survey/public.html', survey=survey,
                               form_schema=S.load(survey.schema_json),
                               preview=True, values=None, errors={},
                               field_name=S.field_name, viewer=user,
                               **_public_extra(S.load(survey.schema_json),
                                               user))
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Status, duplicate, delete
# ---------------------------------------------------------------------------

@survey_bp.route('/<int:survey_id>/status', methods=['POST'])
@member_required
def set_status(survey_id, user=None):
    wanted = request.form.get('status')
    if wanted not in (STATUS_OPEN, STATUS_CLOSED):
        abort(400)
    db_session = get_db_session()
    try:
        survey = service.get_managed(db_session, user, survey_id)
        if survey is None:
            abort(404)
        service.set_status(survey, wanted)
        db_session.commit()
        flash('Survey is now open - anyone with the link can answer it.'
              if wanted == STATUS_OPEN else
              'Survey closed - the link now shows that it is no longer '
              'accepting responses.', 'success')
    finally:
        db_session.close()
    return redirect(url_for('survey.detail', survey_id=survey_id))


@survey_bp.route('/<int:survey_id>/duplicate', methods=['POST'])
@member_required
def duplicate(survey_id, user=None):
    db_session = get_db_session()
    try:
        survey = service.get_managed(db_session, user, survey_id)
        if survey is None:
            abort(404)
        copy = service.duplicate_survey(db_session, user, survey)
        db_session.commit()
        flash('Copied into a new draft with its own link and its own %d '
              'days.' % RETENTION_DAYS, 'success')
        return redirect(url_for('survey.edit', survey_id=copy.id))
    finally:
        db_session.close()


@survey_bp.route('/<int:survey_id>/delete', methods=['POST'])
@member_required
def delete(survey_id, user=None):
    db_session = get_db_session()
    try:
        survey = service.get_managed(db_session, user, survey_id)
        if survey is None:
            abort(404)
        title = survey.title
        service.delete_survey(db_session, survey)
        db_session.commit()
        flash('"%s" and all its responses were deleted.' % title, 'success')
    except Exception as exc:
        if getattr(exc, 'code', None) == 404:
            raise
        db_session.rollback()
        logger.exception('Survey delete failed for %s', survey_id)
        flash('The survey could not be deleted.', 'error')
    finally:
        db_session.close()
    return redirect(url_for('survey.index'))


# ---------------------------------------------------------------------------
# Members (admin only)
# ---------------------------------------------------------------------------

@survey_bp.route('/members')
@admin_required
def members(user=None):
    db_session = get_db_session()
    try:
        rows = service.member_rows(db_session)
        member_ids = {r['user'].id for r in rows}
        available = db_session.query(User).filter(User.is_active == True)  # noqa: E712
        if member_ids:
            available = available.filter(~User.id.in_(member_ids))
        available = [u for u in available.order_by(User.username).all()
                     if u.role != 'admin']
        admin_count = (db_session.query(User)
                       .filter(User.role == 'admin',
                               User.is_active == True)   # noqa: E712
                       .count())
        return render_template('survey/members.html', **_ctx(
            user, member_rows=rows, available_users=available,
            admin_count=admin_count))
    finally:
        db_session.close()


@survey_bp.route('/members/add', methods=['POST'])
@admin_required
def add_member(user=None):
    target_id = (request.form.get('user_id') or '').strip()
    if not target_id.isdigit():
        flash('Please choose a person to add.', 'error')
        return redirect(url_for('survey.members'))
    db_session = get_db_session()
    try:
        target = db_session.query(User).filter(
            User.id == int(target_id), User.is_active == True).first()  # noqa: E712
        if not target:
            flash('That account could not be found, or is disabled.', 'error')
        elif db_session.query(SurveyMember).filter_by(
                user_id=target.id).first():
            flash('%s is already a survey member.' % target.username,
                  'warning')
        else:
            db_session.add(SurveyMember(user_id=target.id, added_by=user.id))
            db_session.commit()
            flash('%s can now create surveys.' % target.username, 'success')
    except Exception:
        db_session.rollback()
        logger.exception('Failed to add survey member %s', target_id)
        flash('That person could not be added.', 'error')
    finally:
        db_session.close()
    return redirect(url_for('survey.members'))


@survey_bp.route('/members/<int:member_id>/remove', methods=['POST'])
@admin_required
def remove_member(member_id, user=None):
    """Revoke access. Their surveys stay (admins can still see them) and are
    deleted on their normal 30-day date."""
    db_session = get_db_session()
    try:
        member = db_session.query(SurveyMember).filter_by(
            id=member_id).first()
        if not member:
            flash('That member is no longer on the list.', 'warning')
        else:
            target = db_session.get(User, member.user_id)
            db_session.delete(member)
            db_session.commit()
            flash('%s can no longer use Surveys.' % (
                target.username if target else 'That person'), 'success')
    except Exception:
        db_session.rollback()
        logger.exception('Failed to remove survey member %s', member_id)
        flash('That member could not be removed.', 'error')
    finally:
        db_session.close()
    return redirect(url_for('survey.members'))


# ---------------------------------------------------------------------------
# Public
# ---------------------------------------------------------------------------

def _public_extra(form_schema, viewer, values=None):
    """What the participant form needs beyond the questions: the
    acknowledgement block, today's date for its Date field, the signed-in
    person's name to pre-fill its Name field, and how many rows each
    text-entry table should show (one, or as many as were posted when the
    form is re-shown after an error)."""
    return {
        'max_rows': S.MAX_ROWS,
        'row_count': (lambda q: S.posted_row_count(values, q)) if values
        else (lambda q: 1),
        'other_value': S.OTHER_VALUE,
        'ack': S.ack_of(form_schema),
        'ack_fields': {'confirm': S.ACK_FIELD_CONFIRM,
                       'name': S.ACK_FIELD_NAME,
                       'email': S.ACK_FIELD_EMAIL,
                       'date': S.ACK_FIELD_DATE,
                       'comments': S.ACK_FIELD_COMMENTS},
        'ack_key': S.ACK_KEY,
        'today': datetime.now().strftime('%Y-%m-%d'),
        'default_name': _display(viewer) if viewer else '',
        'default_email': (viewer.email or '') if viewer else '',
    }


@survey_public_bp.route('/f/<token>', methods=['GET', 'POST'])
@survey_bp.route('/s/<token>', methods=['GET', 'POST'])
def respond(token):
    """The participant's page. No sign-in; the link is the credential."""
    viewer = get_current_user()
    db_session = get_db_session()
    try:
        survey = service.get_public(db_session, token)
        if survey is None:
            return render_template('survey/public_gone.html',
                                   reason='missing'), 404
        if survey.status != STATUS_OPEN:
            return render_template('survey/public_gone.html', survey=survey,
                                   reason=survey.status)
        form_schema = S.load(survey.schema_json)
        values, errors = None, {}
        if request.method == 'POST':
            answers, errors = S.read_answers(form_schema, request.form)
            if not errors:
                _, problem = service.submit_response(db_session, survey,
                                                     answers, user=viewer)
                if problem == service.DUPLICATE_EMAIL:
                    # Shown on the acknowledgement block, with everything
                    # they typed still in place.
                    db_session.rollback()
                    errors = {S.ACK_KEY: problem}
                elif problem:
                    db_session.rollback()
                    return render_template('survey/public_gone.html',
                                           survey=survey, reason='full')
                else:
                    db_session.commit()
                    return redirect(url_for('survey_public.thanks',
                                            token=token))
            values = request.form
        return render_template('survey/public.html', survey=survey,
                               form_schema=form_schema, preview=False,
                               values=values, errors=errors,
                               field_name=S.field_name, viewer=viewer,
                               **_public_extra(form_schema, viewer, values))
    finally:
        db_session.close()


@survey_public_bp.route('/f/<token>/thanks')
@survey_bp.route('/s/<token>/thanks')
def thanks(token):
    db_session = get_db_session()
    try:
        survey = service.get_public(db_session, token)
        if survey is None:
            return render_template('survey/public_gone.html',
                                   reason='missing'), 404
        return render_template('survey/public_thanks.html', survey=survey)
    finally:
        db_session.close()
