"""
scheduler.py - Survey retention purge.

One daily cron job, ``survey_retention_purge`` (SURVEY_PURGE_HOUR:MINUTE,
02:45 local by default), deleting every survey whose 30 days are up together
with all its responses (service.purge_expired). Its own jobstore table
(``apscheduler_jobs_survey``) so it never loads or fires another module's jobs.

Deployment model (identical to the other schedulers):
  * The Windows service (health_monitor_app_sched.py) owns the schedule in
    production and calls init_survey_monitoring().
  * The web app may start it too, guarded by RUN_SCHEDULERS_IN_APP. The purge
    is idempotent (a second run finds nothing to delete), so a second runner
    is harmless.

The scheduler is not the only guard: every page hides an expired survey the
instant it expires, and the module's own pages also run the purge
(service.maybe_purge) - see service.py.
"""

import logging
import os
import threading
from typing import Optional

from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from tzlocal import get_localzone

from database import engine
from .service import run_purge

logger = logging.getLogger(__name__)

_PURGE_HOUR = int(os.environ.get('SURVEY_PURGE_HOUR', '2'))
_PURGE_MINUTE = int(os.environ.get('SURVEY_PURGE_MINUTE', '45'))
_JOBSTORE_TABLE = os.environ.get('SURVEY_APSCHEDULER_TABLE',
                                 'apscheduler_jobs_survey')
_PURGE_JOB = 'survey_retention_purge'

_init_lock = threading.Lock()
_scheduler: Optional[BackgroundScheduler] = None


def _purge_safe():
    try:
        run_purge()
    except Exception:
        logger.exception('Survey retention purge crashed (suppressed).')


def init_survey_monitoring() -> None:
    """Start the survey retention scheduler. Idempotent."""
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            logger.info('Survey retention already running - skipping re-init.')
            return
        _scheduler = BackgroundScheduler(
            jobstores={'default': SQLAlchemyJobStore(
                engine=engine, tablename=_JOBSTORE_TABLE)},
            job_defaults={'coalesce': True, 'max_instances': 1,
                          'misfire_grace_time': 3600},
            timezone=get_localzone(),
        )
        _scheduler.add_job(
            func=_purge_safe,
            trigger=CronTrigger(hour=_PURGE_HOUR, minute=_PURGE_MINUTE),
            id=_PURGE_JOB,
            name='Survey retention purge (daily %02d:%02d)' % (
                _PURGE_HOUR, _PURGE_MINUTE),
            replace_existing=True,
        )
        _scheduler.start()
        logger.info('Survey retention purge scheduled daily at %02d:%02d.',
                    _PURGE_HOUR, _PURGE_MINUTE)
    # Catch up straight away: a service that was down for a week should not
    # leave expired surveys in the database until tomorrow night.
    _purge_safe()


def shutdown_survey_monitoring() -> None:
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            _scheduler.shutdown(wait=False)
            logger.info('Survey retention purge stopped.')
        _scheduler = None
