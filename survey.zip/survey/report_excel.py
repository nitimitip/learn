"""
report_excel.py - a survey's responses as an Excel workbook.

Pure: plain data in, bytes out, so it is testable without a database. Same
visual language as the other appassist workbooks (application_support/
export_docs.py, project_management/project_excel.py): NPG red title band,
dark-red subtitle and column-header rows, banded body rows, Calibri, thin
slate borders, frozen headers and filters.

SHEETS
    Overview    the survey's facts (owner, status, link, created, deletion
                date) and its headline figures (responses, first and last
                response, completion).
    Summary     one section band per question: a choice question gets Count /
                % / a data bar per choice and the "Other" texts; a choice table
                gets a row x column count matrix; free text is pointed at the
                Responses sheet.
    Responses   one row per response, one column per question. A choice
                table gets one column PER TABLE ROW so each can be filtered on
                its own; a text-entry table gets one column summarising the
                rows that participant added.
    <table>     one extra sheet per text-entry table question (e.g. the VPN
                form's "Application testing results") in long format: one row
                per row a participant added, one column per table column - the
                shape somebody actually pivots.
    Acknowledgements  (forms with the acceptance block) who confirmed, the
                name and date they signed with, and their comments / issues.
    Questions   the form itself, question by question.

FORMULA INJECTION. Every answer came from the public link, so any of them can
start with "=", "+", "-" or "@". openpyxl writes a string that starts with "="
as a live formula, and Excel evaluates the others; ``_safe`` neutralises all of
them with a leading apostrophe before they reach a cell.
"""

import io
import re

from openpyxl import Workbook
from openpyxl.formatting.rule import DataBarRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from . import schema as S

# Brand palette - NPG red (mirrors application_support/export_docs.py).
BRAND = 'AB1236'      # title bands & section headers
BRAND_DK = '7E0D27'   # subtitles & column-header rows
BAND = 'F1F5F9'
BORDER = 'D7DEE7'
TEXT = '1D293D'
MUTED = '6B7280'

# Status -> (fill, font) chip colours, as the screen badges show them.
STATUS_META = {
    'open': ('DCFCE7', '166534'),
    'draft': ('F1F5F9', '475569'),
    'closed': ('FEF3C7', '92400E'),
}
YES_NO_META = {
    'Yes': ('DCFCE7', '166534'),
    'No': ('FEE2E2', '991B1B'),
}

_thin = Side(style='thin', color=BORDER)
_BORDER = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)
CENTER = Alignment(horizontal='center', vertical='center', wrap_text=True)
LEFT_TOP = Alignment(horizontal='left', vertical='top', wrap_text=True)

_FORMULA_LEADS = ('=', '+', '-', '@', '\t', '\r')
_CELL_MAX = 32000                 # Excel's hard limit is 32,767 characters
_SHEET_BAD = re.compile(r'[\[\]\*\?/\\:]')


def _safe(value):
    if value is None:
        return ''
    if not isinstance(value, str):
        return value
    value = value[:_CELL_MAX]
    if value.startswith(_FORMULA_LEADS):
        return "'" + value
    return value


# ---------------------------------------------------------------------------
# Excel helpers (same visual language as the Application Support workbook)
# ---------------------------------------------------------------------------

def _autosize(ws, widths):
    for idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width


def _title_band(ws, title, subtitle, ncols):
    ncols = max(ncols, 2)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    c = ws.cell(row=1, column=1, value=_safe(title))
    c.font = Font(name='Calibri', size=15, bold=True, color='FFFFFF')
    c.fill = PatternFill('solid', fgColor=BRAND)
    c.alignment = Alignment(horizontal='left', vertical='center', indent=1)
    ws.row_dimensions[1].height = 30
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
    s = ws.cell(row=2, column=1, value=_safe(subtitle))
    s.font = Font(name='Calibri', size=10, italic=True, color='FFFFFF')
    s.fill = PatternFill('solid', fgColor=BRAND_DK)
    s.alignment = Alignment(horizontal='left', vertical='center', indent=1)
    ws.row_dimensions[2].height = 20
    return 4


def _section_band(ws, row, label, ncols):
    ncols = max(ncols, 2)
    ws.merge_cells(start_row=row, start_column=1, end_row=row,
                   end_column=ncols)
    h = ws.cell(row=row, column=1, value=_safe(label))
    h.font = Font(name='Calibri', size=11, bold=True, color='FFFFFF')
    h.fill = PatternFill('solid', fgColor=BRAND)
    h.alignment = Alignment(horizontal='left', vertical='center', indent=1,
                            wrap_text=True)
    ws.row_dimensions[row].height = 22 if len(label) < 110 else 36
    return row + 1


def _header_row(ws, row, headers):
    for col, label in enumerate(headers, start=1):
        cell = ws.cell(row=row, column=col, value=_safe(label))
        cell.font = Font(name='Calibri', size=10, bold=True, color='FFFFFF')
        cell.fill = PatternFill('solid', fgColor=BRAND_DK)
        cell.alignment = CENTER
        cell.border = _BORDER
    ws.row_dimensions[row].height = 30


def _cell(ws, row, col, value, banded=False, center=False):
    cell = ws.cell(row=row, column=col, value=_safe(value))
    cell.font = Font(name='Calibri', size=10, color=TEXT)
    cell.alignment = CENTER if center else LEFT_TOP
    cell.border = _BORDER
    if banded:
        cell.fill = PatternFill('solid', fgColor=BAND)
    return cell


def _chip(cell, fill, font_clr):
    cell.fill = PatternFill('solid', fgColor=fill)
    cell.font = Font(name='Calibri', size=10, bold=True, color=font_clr)
    cell.alignment = CENTER
    cell.border = _BORDER


def _note(ws, row, message, ncols):
    ncols = max(ncols, 2)
    ws.merge_cells(start_row=row, start_column=1, end_row=row,
                   end_column=ncols)
    c = ws.cell(row=row, column=1, value=_safe(message))
    c.font = Font(name='Calibri', size=10, italic=True, color=MUTED)
    c.alignment = Alignment(horizontal='left', vertical='center', indent=1,
                            wrap_text=True)
    return row + 1


def _field(ws, row, label, value, ncols=4):
    lc = ws.cell(row=row, column=1, value=label)
    lc.font = Font(name='Calibri', size=10, bold=True, color='FFFFFF')
    lc.fill = PatternFill('solid', fgColor=BRAND_DK)
    lc.alignment = LEFT_TOP
    lc.border = _BORDER
    ws.merge_cells(start_row=row, start_column=2, end_row=row,
                   end_column=ncols)
    vc = ws.cell(row=row, column=2,
                 value=_safe(value) if value not in (None, '') else '-')
    vc.font = Font(name='Calibri', size=10, color=TEXT)
    vc.alignment = LEFT_TOP
    vc.border = _BORDER
    for col in range(3, ncols + 1):
        ws.cell(row=row, column=col).border = _BORDER
    ws.row_dimensions[row].height = max(
        20, 14 * (1 + len(str(value or '')) // 90))
    return vc, row + 1


def _print_setup(ws, landscape=True, header_row=None):
    ws.page_setup.orientation = 'landscape' if landscape else 'portrait'
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    if header_row:
        ws.print_title_rows = '%d:%d' % (header_row, header_row)
    ws.oddFooter.center.text = 'Page &P of &N'


def _sheet_name(wb, label):
    base = _SHEET_BAD.sub(' ', label).strip()[:28] or 'Table'
    name, n = base, 2
    while name in wb.sheetnames:
        name = '%s %d' % (base[:26], n)
        n += 1
    return name


def _fmt(dt):
    return dt.strftime('%d %b %Y %H:%M') if dt else '-'


# ---------------------------------------------------------------------------
# Answer -> cell
# ---------------------------------------------------------------------------

# The Responses sheet column that holds a choice question's reason box,
# rather than a grid row.
REASON_COLUMN = object()
NOT_ASKED = 'Not asked'


def _columns(form_schema):
    """[(header, question, table_row_or_None)] for the Responses sheet.
    table_row is REASON_COLUMN for a choice question's reason column."""
    cols = []
    for q in S.answerable(form_schema):
        if q['type'] in ('grid', 'grid_multi'):
            for row in q['rows']:
                cols.append(('%s - %s' % (q['label'], row), q, row))
        else:
            cols.append((q['label'], q, None))
            if q.get('reason_on'):
                cols.append(('%s - %s' % (q['label'], q['reason_label']),
                             q, REASON_COLUMN))
    return cols


def _cell_value(q, table_row, value):
    if value in (None, '', [], {}):
        return ''
    if table_row is None:
        if q['type'] == 'number':
            try:
                number = float(value)
                return int(number) if number.is_integer() else number
            except (TypeError, ValueError):
                return str(value)
        return S.answer_text(q, value)
    if not isinstance(value, dict):
        return ''
    picked = value.get(table_row)
    if picked in (None, '', [], {}):
        return ''
    if q['type'] == 'grid':
        return str(picked)
    if q['type'] == 'grid_multi':
        return '; '.join(picked) if isinstance(picked, list) else str(picked)
    if isinstance(picked, dict):
        return '; '.join('%s: %s' % (c, picked[c])
                         for c in q['columns'] if c in picked)
    return str(picked)


# ---------------------------------------------------------------------------
# The workbook
# ---------------------------------------------------------------------------

def build_workbook(meta, form_schema, rows, summary):
    """Bytes of the .xlsx.

    meta     {'title', 'description', 'status', 'url', 'owner', 'created_at',
              'published_at', 'expires_at', 'generated_at', 'generated_by'}
    rows     [{'id', 'submitted_at', 'respondent', 'answers'}] oldest first
    summary  service.summarise()
    """
    wb = Workbook()
    generated = 'Generated %s by %s' % (_fmt(meta['generated_at']),
                                        meta['generated_by'])
    _overview(wb.active, meta, form_schema, rows, generated)
    _summary(wb.create_sheet('Summary'), meta, summary, len(rows), generated)
    _responses(wb.create_sheet('Responses'), meta, form_schema, rows,
               generated)
    for q in S.answerable(form_schema):
        if q['type'] == 'table':
            _table_sheet(wb, q, rows, generated)
    ack = S.ack_of(form_schema)
    if ack:
        _ack_sheet(wb.create_sheet('Acknowledgements'), meta, ack, rows,
                   generated)
    _questions(wb.create_sheet('Questions'), meta, form_schema, generated)

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _overview(ws, meta, form_schema, rows, generated):
    ws.title = 'Overview'
    ncols = 4
    row = _title_band(ws, meta['title'], 'Survey report - ' + generated,
                      ncols)
    row = _section_band(ws, row, 'Survey details', ncols)
    _, row = _field(ws, row, 'Title', meta['title'], ncols)
    if meta.get('description'):
        _, row = _field(ws, row, 'Description', meta['description'], ncols)
    vc, row = _field(ws, row, 'Status', meta['status'].title(), ncols)
    _chip(vc, *STATUS_META.get(meta['status'], STATUS_META['draft']))
    vc.alignment = Alignment(horizontal='left', vertical='center', indent=1)
    _, row = _field(ws, row, 'Owner', meta['owner'], ncols)
    _, row = _field(ws, row, 'Public link', meta['url'], ncols)
    _, row = _field(ws, row, 'Created', _fmt(meta['created_at']), ncols)
    _, row = _field(ws, row, 'Published', _fmt(meta.get('published_at')),
                    ncols)
    vc, row = _field(ws, row, 'Deleted on',
                     '%s - the survey and every response are deleted '
                     'automatically 30 days after creation.'
                     % _fmt(meta['expires_at']), ncols)
    vc.font = Font(name='Calibri', size=10, bold=True, color='991B1B')
    if S.ack_of(form_schema):
        signed = sum(1 for r in rows
                     if (r['answers'].get(S.ACK_KEY) or {}).get('confirmed'))
        _, row = _field(ws, row, 'Acknowledged',
                        '%d of %d response(s) confirmed the statement - see '
                        'the Acknowledgements sheet.' % (signed, len(rows)),
                        ncols)

    row += 1
    row = _section_band(ws, row, 'At a glance', ncols)
    _header_row(ws, row, ['Responses', 'First response', 'Latest response',
                          'Questions'])
    row += 1
    questions = S.answerable(form_schema)
    _cell(ws, row, 1, len(rows), center=True).font = Font(
        name='Calibri', size=14, bold=True, color=BRAND)
    _cell(ws, row, 2, _fmt(rows[0]['submitted_at']) if rows else '-',
          center=True)
    _cell(ws, row, 3, _fmt(rows[-1]['submitted_at']) if rows else '-',
          center=True)
    _cell(ws, row, 4, len(questions), center=True)
    ws.row_dimensions[row].height = 26

    _autosize(ws, [20, 26, 26, 26])
    _print_setup(ws, landscape=False)


def _summary(ws, meta, summary, total, generated):
    ncols = 4
    widest = max([len(e['q'].get('columns', [])) for e in summary
                  if e['kind'] in ('grid', 'table')] or [0])
    ncols = max(ncols, widest + 1)
    row = _title_band(ws, 'Summary - ' + meta['title'],
                      '%d response(s). %s' % (total, generated), ncols)
    if not summary:
        _note(ws, row, 'This survey has no questions.', ncols)
    for entry in summary:
        q = entry['q']
        if entry['kind'] == 'section':
            if q.get('label'):
                cell = ws.cell(row=row, column=1,
                               value=_safe(q['label'].upper()))
                cell.font = Font(name='Calibri', size=12, bold=True,
                                 color=BRAND_DK)
                ws.row_dimensions[row].height = 22
                row += 1
            continue
        number = entry['number']
        row = _section_band(ws, row, '%d. %s' % (number, q['label']), ncols)
        text = '%s - answered by %d of %d response(s)' % (
            S.TYPE_LABELS.get(q['type'], q['type']), entry['answered'],
            entry['total'])
        if entry.get('rule'):
            text += ' asked. Shown only when %s - not asked in %d.' % (
                entry['rule'], entry.get('not_asked', 0))
        row = _note(ws, row, text, ncols)

        if entry['kind'] == 'choice':
            _header_row(ws, row, ['Choice', 'Count', '% of answers',
                                  'Share'])
            row += 1
            first = row
            for i, (label, n, pct) in enumerate(entry['counts']):
                band = i % 2 == 1
                _cell(ws, row, 1, label, band)
                _cell(ws, row, 2, n, band, center=True)
                _cell(ws, row, 3, pct / 100.0, band,
                      center=True).number_format = '0%'
                _cell(ws, row, 4, n, band)
                row += 1
            if row > first:
                ws.conditional_formatting.add(
                    'D%d:D%d' % (first, row - 1),
                    DataBarRule(start_type='num', start_value=0,
                                end_type='max', color=BRAND,
                                showValue=False))
            if entry.get('others'):
                row = _note(ws, row, 'Other: ' + '; '.join(entry['others']),
                            ncols)
            if entry.get('reasons'):
                row = _note(ws, row, '%s: %s' % (
                    q.get('reason_label') or 'Reasons',
                    '; '.join(entry['reasons'])), ncols)

        elif entry['kind'] == 'grid':
            header = [q.get('row_header') or 'Row'] + list(q['columns'])
            _header_row(ws, row, header)
            row += 1
            for i, (label, counts, _) in enumerate(entry['matrix']):
                band = i % 2 == 1
                _cell(ws, row, 1, label, band)
                for c, n in enumerate(counts, start=2):
                    _cell(ws, row, c, n, band, center=True)
                row += 1

        elif entry['kind'] == 'table':
            _header_row(ws, row, ['Rows entered'] + list(q['columns']))
            row += 1
            _cell(ws, row, 1, entry.get('rows_total', 0), center=True)
            for c, cell in enumerate(entry.get('totals', []), start=2):
                if 'filled' in cell:
                    text = '%d filled' % cell['filled']
                elif 'counts' in cell:
                    text = ' / '.join('%s %d' % (o, n)
                                      for o, n in cell['counts'])
                else:
                    text = 'Yes %d / No %d' % (cell['yes'], cell['no'])
                _cell(ws, row, c, text, center=True)
            row += 1
            row = _note(ws, row, 'Typed entries - see the "%s" sheet.'
                        % q['label'][:28], ncols)
        else:
            row = _note(ws, row, 'Free-text answers - see the Responses '
                        'sheet.', ncols)
        row += 1
    _autosize(ws, [48] + [16] * (ncols - 1))
    _print_setup(ws, landscape=False)


def _responses(ws, meta, form_schema, rows, generated):
    cols = _columns(form_schema)
    ack = S.ack_of(form_schema)
    ack_heads = (['Confirmed', 'Signed name', 'Signed email', 'Signed date',
                  ack.get('comments_label') or 'Comments']
                 if ack else [])
    headers = (['#', 'Submitted', 'Respondent'] + [c[0] for c in cols] +
               ack_heads)
    row = _title_band(ws, 'Responses - ' + meta['title'],
                      '%d response(s). %s' % (len(rows), generated),
                      min(len(headers), 12))
    _header_row(ws, row, headers)
    head = row
    row += 1
    if not rows:
        _note(ws, row, 'No responses yet.', min(len(headers), 12))
    for i, r in enumerate(rows, start=1):
        band = i % 2 == 0
        _cell(ws, row, 1, i, band, center=True)
        _cell(ws, row, 2, r['submitted_at'], band,
              center=True).number_format = 'dd mmm yyyy hh:mm'
        _cell(ws, row, 3, r['respondent'] or 'Anonymous', band)
        shown = S.shown_ids(form_schema, r['answers'])
        for c, (_, q, table_row) in enumerate(cols, start=4):
            if q['id'] not in shown:
                # Skipped by its show_if rule - say so, so it does not read
                # as a question this person left blank.
                _cell(ws, row, c, NOT_ASKED, band).font = Font(
                    name='Calibri', size=10, italic=True, color=MUTED)
                continue
            if table_row is REASON_COLUMN:
                value = r['answers'].get(S.reason_key(q['id'])) or ''
            else:
                value = _cell_value(q, table_row,
                                    r['answers'].get(q['id']))
            cell = _cell(ws, row, c, value, band,
                         center=q['type'] in ('number', 'date', 'grid'))
            if value in YES_NO_META:
                _chip(cell, *YES_NO_META[value])
        if ack:
            signed = r['answers'].get(S.ACK_KEY) or {}
            ok = 'Yes' if signed.get('confirmed') else 'No'
            c = 4 + len(cols)
            _chip(_cell(ws, row, c, ok, band), *YES_NO_META[ok])
            _cell(ws, row, c + 1, signed.get('name', ''), band)
            _cell(ws, row, c + 2, signed.get('email', ''), band)
            _cell(ws, row, c + 3, signed.get('date', ''), band, center=True)
            _cell(ws, row, c + 4, signed.get('comments', ''), band)
        row += 1
    _autosize(ws, [6, 18, 24] + [30] * len(cols) +
              ([12, 24, 30, 14, 40] if ack else []))
    ws.freeze_panes = ws.cell(row=head + 1, column=4).coordinate
    if rows:
        ws.auto_filter.ref = 'A%d:%s%d' % (
            head, get_column_letter(len(headers)), row - 1)
    _print_setup(ws, header_row=head)


def _table_sheet(wb, q, rows, generated):
    ws = wb.create_sheet(_sheet_name(wb, q['label']))
    headers = ['Response #', 'Submitted', 'Respondent',
               'Row'] + list(q['columns'])
    row = _title_band(ws, q['label'], 'One row per table row a participant '
                      'added. ' + generated, len(headers))
    _header_row(ws, row, headers)
    head = row
    row += 1
    written = 0
    for i, r in enumerate(rows, start=1):
        for number, cells in enumerate(
                S.table_rows(r['answers'].get(q['id'])), start=1):
            label = 'Row %d' % number
            band = written % 2 == 1
            _cell(ws, row, 1, i, band, center=True)
            _cell(ws, row, 2, r['submitted_at'], band,
                  center=True).number_format = 'dd mmm yyyy hh:mm'
            _cell(ws, row, 3, r['respondent'] or 'Anonymous', band)
            _cell(ws, row, 4, label, band).font = Font(
                name='Calibri', size=10, bold=True, color=TEXT)
            for c, col in enumerate(q['columns'], start=5):
                text = cells.get(col, '')
                cell = _cell(ws, row, c, text, band,
                             center=text in YES_NO_META)
                if text in YES_NO_META:
                    _chip(cell, *YES_NO_META[text])
            row += 1
            written += 1
    if not written:
        _note(ws, row, 'Nobody has filled in this table yet.', len(headers))
    _autosize(ws, [11, 18, 24, 9] + [26] * len(q['columns']))
    ws.freeze_panes = ws.cell(row=head + 1, column=5).coordinate
    if written:
        ws.auto_filter.ref = 'A%d:%s%d' % (
            head, get_column_letter(len(headers)), row - 1)
    _print_setup(ws, header_row=head)


def _ack_sheet(ws, meta, ack, rows, generated):
    headers = ['Response #', 'Submitted', 'Confirmed', 'Name', 'Email',
               'Date', ack.get('comments_label') or 'Comments']
    row = _title_band(ws, ack.get('heading') or 'Acknowledgements',
                      generated, len(headers))
    row = _note(ws, row, 'Statement: ' + (ack.get('statement') or ''),
                len(headers))
    ws.row_dimensions[row - 1].height = 32
    row += 1
    _header_row(ws, row, headers)
    head = row
    row += 1
    for i, r in enumerate(rows, start=1):
        signed = r['answers'].get(S.ACK_KEY) or {}
        band = i % 2 == 0
        _cell(ws, row, 1, i, band, center=True)
        _cell(ws, row, 2, r['submitted_at'], band,
              center=True).number_format = 'dd mmm yyyy hh:mm'
        ok = 'Yes' if signed.get('confirmed') else 'No'
        _chip(_cell(ws, row, 3, ok, band), *YES_NO_META[ok])
        _cell(ws, row, 4, signed.get('name', ''), band)
        _cell(ws, row, 5, signed.get('email', ''), band)
        _cell(ws, row, 6, signed.get('date', ''), band, center=True)
        _cell(ws, row, 7, signed.get('comments', ''), band)
        row += 1
    if not rows:
        _note(ws, row, 'No responses yet.', len(headers))
    _autosize(ws, [11, 18, 12, 28, 32, 14, 60])
    ws.freeze_panes = ws.cell(row=head + 1, column=1).coordinate
    if rows:
        ws.auto_filter.ref = 'A%d:G%d' % (head, row - 1)
    _print_setup(ws, header_row=head)


def _questions(ws, meta, form_schema, generated):
    ncols = 4
    row = _title_band(ws, 'Questions - ' + meta['title'], generated, ncols)
    _header_row(ws, row, ['#', 'Question', 'Type', 'Required / choices'])
    head = row
    row += 1
    number = 0
    for q in form_schema.get('questions', []):
        if q['type'] == 'section':
            row = _section_band(ws, row, q.get('label') or 'Section', ncols)
            if q.get('help'):
                row = _note(ws, row, q['help'], ncols)
            continue
        number += 1
        detail = 'Required' if q.get('required') else 'Optional'
        if q['type'] in S.CHOICE_TYPES:
            detail += ' - ' + '; '.join(q['options'])
            if q.get('allow_other'):
                detail += '; Other (please specify)'
            if q.get('reason_on'):
                detail += ' | "%s" asked when: %s' % (
                    q['reason_label'], '; '.join(q['reason_on']))
        elif q['type'] == 'table':
            opts = q.get('column_options') or []
            detail += ' - columns: %s | rows added by the participant' % (
                '; '.join(
                    '%s (%s)' % (col, ' / '.join(opts[i]))
                    if i < len(opts) and opts[i] else col
                    for i, col in enumerate(q['columns'])))
        elif q['type'] in S.TABLE_TYPES:
            detail += ' - rows: %s | columns: %s' % (
                '; '.join(q['rows']), '; '.join(q['columns']))
        if q.get('show_if'):
            detail += ' | Shown only when ' + S.rule_text(form_schema, q)
        band = number % 2 == 0
        _cell(ws, row, 1, number, band, center=True)
        _cell(ws, row, 2, q['label'], band)
        _cell(ws, row, 3, S.TYPE_LABELS.get(q['type'], q['type']), band)
        _cell(ws, row, 4, detail, band)
        row += 1
    ack = S.ack_of(form_schema)
    if ack:
        row = _section_band(ws, row, ack.get('heading') or
                            'Acknowledgement', ncols)
        row = _note(ws, row, ack.get('statement') or '', ncols)
        _cell(ws, row, 2, 'Confirm tick box, Name, Email (one response '
              'per address), Date' +
              (', ' + ack.get('comments_label') if ack.get('comments')
               else ''))
        _cell(ws, row, 3, 'Acknowledgement')
        _cell(ws, row, 4, 'Required (comments optional)')
        row += 1
    _autosize(ws, [6, 56, 26, 64])
    _print_setup(ws, landscape=False, header_row=head)
