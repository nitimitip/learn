APPASSIST TEST CASE AGENT - README
========================================================================
A Microsoft 365 Copilot agent (Agent Builder, used from Microsoft Teams
or the Copilot app) that acts as a senior test lead. It reads the user's
requirement documents and writes professional positive, negative and
boundary test cases into an Excel workbook in the AppAssist theme.

It is not tied to an AppAssist module or database: there is no JSON
draft, no database ID and nothing to import into AppAssist. The output
is the Excel file only.

FILES
------------------------------------------------------------------------
  TestCase_agent_config.txt          the agent WITHOUT a skill: setup,
                                     instructions (Part 2), rules and the
                                     workbook code (Part 6), all in one
                                     knowledge file
  skills/appassist-testcase.zip      the skill (upload package)
  skills/appassist-testcase/         the same skill unpacked, for reading
                                     and maintenance
  Sample_TestCase_input_Requirements.txt
                                     fictional combined BRD + FRS + HLD
                                     document with deliberate gaps
  Sample_Test_Cases.xlsx             the workbook the agent should produce
                                     from that sample input
  Sample_TestCase_spec.py            that sample as a Python dict, for
                                     maintenance and testing only (NOT in
                                     the skill: Copilot accepts only .md
                                     files in references/)
  TestCase_README.txt                this file

WHAT THE AGENT DOES
------------------------------------------------------------------------
  Users do not need to know how to prompt: uploading a BRD with "create
  test case document" is enough. The agent reads the document first and
  asks only what it cannot find there - every doubt, in plain English.

  1. Takes the attached documents (or asks for one if none is attached):
       BRD        -> "UAT (BRD)" sheet          business scenarios
       FRS / SRS  -> "System Test (FRS)" sheet  field rules, messages,
                                                roles, status flows
       HLD        -> "SIT-API (HLD)" sheet      handoffs, APIs, timeouts,
                                                retries, error responses
     Any one document is enough to start.
  2. Reads every document in full and analyses each requirement
     (actors, screens, fields, rules, states, messages, gaps) silently.
  3. Shows the document -> sheet map and the requirement list and asks
     its questions in one batch (follow-up batch if an answer opens a
     new gap).
  4. When everything is clear, confirms the scope and asks "Shall I
     prepare the Excel file?".
  5. Writes the test cases straight into the workbook - never in chat:
     a Positive case for every requirement, Negative cases for every
     rule, role and interface, Boundary cases for every stated limit.
  6. Gives the Excel file with a short summary, assumptions and open
     questions.

  The chat is only for questions, clarifications and confirmation; the
  end result is always the Excel file.

  It never makes up data. A missing fact is written "To be confirmed -
  Q-nn" and question Q-nn goes on the Clarifications sheet.

  It never writes generic cases. Every title, precondition, step, test
  data and expected result is specific to that one case (real screen,
  field, role, value, state, message). With the skill, the checker
  REFUSES to build the workbook when it finds placeholder wording
  ("Verify requirement for FR-01", "User logged in with valid role",
  "Open related screen", "Perform action with test data", "Requirement
  based data", "System behaves as per specification", ...) or a title,
  steps or expected result copied between cases.

THE WORKBOOK
------------------------------------------------------------------------
  Dashboard          project details, 18 KPI tiles (total, executed,
                     pass, fail, blocked, not run, pass rate, progress,
                     positive / negative / boundary, defects, requirement
                     coverage, critical failures, open questions), status
                     by level, priority and category tables, two charts
  UAT / System Test / SIT-API sheets
                     TC ID, Req ID, Module, Title, Test Type, Category,
                     Priority, Preconditions, Test Steps, Test Data,
                     Expected Result, Actual Result, Status, Defect ID,
                     Executed By, Execution Date, Remarks
  RTM                requirement -> test cases, with coverage status
  Clarifications     open questions for the document authors

  Every Dashboard and RTM figure is a formula. Testers fill in Status,
  Actual Result and Defect ID (or add rows, up to row 1004) and the
  figures update by themselves. Status, Type, Category and Priority are
  drop-down lists.

SETUP OPTION A - WITH THE SKILL  (recommended)
------------------------------------------------------------------------
  The skill carries the workbook code as a real script plus a checker,
  so the workbook is always built exactly as designed.

  1. Agent Builder > create agent > Configure > Skills > Add.
  2. Upload skills/appassist-testcase.zip (the zip, not SKILL.md alone).
  3. Code interpreter: ON.  Web search: OFF.  No knowledge file needed.
  4. Name:  AppAssist Test Case Agent
     Description and conversation starters: copy from Part 1 of
     TestCase_agent_config.txt.
  5. Instructions (paste):
  ----------------------------------------------------------------------
  You are the AppAssist Test Case Agent: a principal test lead with 30
  years of experience. Whenever the user asks for test cases, test
  scenarios, UAT or SIT scripts or an RTM, use the appassist-testcase
  skill and follow it exactly. Ask for the BRD, FRS / SRS and HLD (any
  one is enough) and the project details for the dashboard. Most users
  just upload a BRD and type "create test case document": that is a
  complete request - read the document first, then reply in one short
  plain-English message as the skill's conversation guide shows. Any
  doubt, however small, is a question to the user; never assume. Read
  every document in full and analyse each requirement before writing. Use the
  chat ONLY to ask questions, clarify and confirm; never write test cases
  in chat. When all questions are answered, confirm the scope, then build
  the Excel file with the skill's script - the Excel file is always the
  end result. Every test case must be specific (real screen, field, role,
  value, state and message); never generic wording such as "verify
  requirement", "open related screen" or "system behaves as per
  specification". Never make up data: requirements, limits, messages,
  roles, interfaces and project details come only from the user's
  documents or answers; log anything still open as a clarification. You
  only write test cases; send other requests to the matching AppAssist
  agent.
  ----------------------------------------------------------------------

  Skills in Agent Builder may still be a preview feature in your tenant.
  If Configure shows no Skills section, use option B.

SETUP OPTION B - WITHOUT A SKILL
------------------------------------------------------------------------
  1. Instructions: paste Part 2 of TestCase_agent_config.txt (between
     BEGIN INSTRUCTIONS and END INSTRUCTIONS).
  2. Knowledge: upload TestCase_agent_config.txt.
  3. Code interpreter: ON.  Web search: OFF.
  Limitation: Copilot reads a knowledge file in chunks. If it does not
  pick up all of Part 6, the agent may build a workbook that differs
  from the AppAssist design. Option A does not have this risk.

  Do not use both options on one agent.

INSIDE THE SKILL
------------------------------------------------------------------------
  SKILL.md                         workflow and rules
  references/conversation-guide.md talking to non-expert users: bare
                                   "create test cases" uploads, every
                                   doubt asked, loose replies, no / wrong
                                   / unreadable document, "make it Word"
  references/quality-standard.md   expert document analysis, what every
                                   column must carry, wording the checker
                                   refuses, bad -> good, self-review
  references/document-guide.md     BRD / FRS / HLD -> test level, combined
                                   documents, missing documents
  references/test-design.md        techniques, test types, how each column
                                   is written, priority, examples
  references/worked-example.md     one requirement from document to
                                   analysis note to cases (fictional)
  references/workbook-layout.md    sheets, lists, KPI definitions, theme
  references/checklist.md          checks before the file is given
  scripts/appassist_testcase.py    checks the test cases and builds the
                                   workbook; refuses on any ERROR (wrong
                                   list value, bad TC ID, more than one
                                   Req ID, unknown requirement, empty
                                   column, unknown Q-nn, generic wording,
                                   Req ID in a title, title / steps /
                                   expected result copied between cases,
                                   one precondition or test data text for
                                   a whole sheet)

  references/ holds only .md files (Copilot rejects other file types
  there); Python lives in scripts/ only.
  scripts/tc_builder.py            draws the workbook

  The agent passes the test cases to the helper as a Python dict inside
  its own script. No JSON or other intermediate file is used.

REQUIREMENTS IN THE COPILOT SANDBOX
------------------------------------------------------------------------
  Python with the openpyxl package (standard in the Copilot code
  interpreter). If the agent cannot run Python it says the code
  interpreter must be turned on and stops; it does not put the test
  cases in chat.

MAINTENANCE
------------------------------------------------------------------------
  * The workbook code exists twice: skills/appassist-testcase/scripts/
    tc_builder.py and Part 6 of TestCase_agent_config.txt. Change both
    together.
  * The skill's references are Parts 3, 4, 5 and 7 of the config file
    (Part 4 = test-design.md + quality-standard.md as sections 7-11;
    Part 8 = conversation-guide.md).
    Change both together.
  * The generic-wording list is in GENERIC at the top of
    scripts/appassist_testcase.py; keep quality-standard.md section 3
    in step with it.
  * After changing the skill folder, zip it again with SKILL.md at the
    top level of the zip and only one folder level below it
    (references/, scripts/) - Agent Builder rejects deeper nesting.
  * Theme colours come from AppAssist email_theme.py; if the AppAssist
    palette changes, update the colour constants at the top of
    tc_builder.py.

TESTED
------------------------------------------------------------------------
  2026-11-24, locally (not yet inside Copilot): the sample built from
  the unzipped skill opens in Excel with all six sheets, 33 test cases,
  100% requirement coverage and no formula errors; changing Status
  values updates the dashboard and RTM; a spec with deliberate mistakes
  is refused with one ERROR per mistake.
