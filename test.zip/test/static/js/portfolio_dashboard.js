/* Portfolio dashboard - Application Support.

   One JSON document (portfolio.build_portfolio) holds every active
   application as a row plus the master lists. Everything on the page -
   KPIs, the charts, the heatmap and the inventory table - is derived
   in here from the rows that pass the current filters, so a filter change
   re-draws all of it at once without a round trip.

   Nothing is hardcoded: towers, capabilities, technologies and languages
   all come from the data, so adding a tower or a technology in
   the master data shows up here on the next load.

   ASCII only (house convention); non-ASCII glyphs are written as escapes. */
(function () {
  'use strict';

  var CFG = window.PORTFOLIO_CONFIG || {};

  /* ---- colour: identity slots in fixed order, never cycled ----------- */
  var C = {
    blue: '#2a78d6', orange: '#eb6834', aqua: '#1baf7a',
    gray: '#a3aab8', ink: '#0f1626', ink2: '#333e52', ink3: '#5a6478',
    line: '#e3e8f0'
  };
  var OWN_COLOR = {'Base COTS': C.blue, 'In-house / Bespoke': C.orange,
                   'Not recorded': C.gray};
  var IF_COLOR = {'Inbound': C.blue, 'Outbound': C.orange, 'Both': C.aqua,
                  'None': C.gray};
  /* Sequential (magnitude) - one hue, light to dark. */
  var SEQ = ['#cde2fb', '#9ec5f4', '#6da7ec', '#3987e5', '#256abf', '#184f95', '#0d366b'];

  var FONT = {family: getComputedStyle(document.body).fontFamily, size: 12, color: C.ink2};
  var PLOT_CFG = {displayModeBar: false, responsive: true};
  var ELLIPSIS = '\u2026';
  var DASH = '\u2014';

  /* ---- filters --------------------------------------------------------
     key -> how a row is tested. `multi` fields hold a list and match when
     the list contains the chosen value. */
  var FILTERS = [
    {key: 'tower', label: 'Tower', field: 'tower'},
    {key: 'capability', label: 'Business capability', field: 'capability'},
    {key: 'ownership', label: 'Ownership type', field: 'ownership'},
    {key: 'tech', label: 'Technology / tool', field: 'technologies', multi: true},
    {key: 'lang', label: 'Programming language', field: 'languages', multi: true},
    {key: 'iface', label: 'Recorded interfaces', field: 'iface_yn'},
    {key: 'itype', label: 'Interface type', field: 'interface_type'}
  ];
  FILTERS.push({key: 'bc', label: 'Criticality', field: 'bc'},
    {key: 'vendor', label: 'Vendor', field: 'vendors', multi: true},
    {key: 'evidence', label: 'Evidence / action', field: 'signals', multi: true});
  var SIGNALS = ['Overdue remediation', 'No capability recorded',
    'No technology recorded', 'No primary owner recorded', 'Unanswered controls',
    'Non Compliant', 'Compliant', 'Vendor Product Compliant', 'Not Started', 'In Progress'];
  var view = 'overview';
  var neighbours = {};
  var state = {filters: {}, search: '', tableSearch: '', sortKey: 'tower',
               sortDir: 1, page: 1, pageSize: 25, hidden: {}};
  var DATA = null;
  var ROWS = [];

  /* ---- table columns -------------------------------------------------- */
  function join(list) { return (list || []).join(', '); }
  var COLUMNS = [
    {key: 'sno', label: 'S.No', fixed: true, sort: false},
    {key: 'name', label: 'Application Name', fixed: true, get: function (r) { return r.name; }},
    {key: 'tower', label: 'Tower', get: function (r) { return r.tower; }},
    {key: 'capability', label: 'Business Capability', get: function (r) { return r.capability; }},
    {key: 'bc', label: 'Criticality', get: function (r) { return r.bc; }},
    {key: 'ownership', label: 'Ownership Type', get: function (r) { return r.ownership; }},
    {key: 'technologies', label: 'Technology / Tools', get: function (r) { return join(r.technologies); }},
    {key: 'languages', label: 'Programming Language', get: function (r) { return join(r.languages); }},
    {key: 'iface', label: 'Recorded Interfaces', get: function (r) { return r.has_interface ? 'Yes' : 'No'; }},
    {key: 'itype', label: 'Interface Type', get: function (r) { return r.interface_type; }, hide: true},
    {key: 'inbound', label: 'Inbound Systems', get: function (r) { return join(r.inbound); }},
    {key: 'outbound', label: 'Outbound Systems', get: function (r) { return join(r.outbound); }},
    {key: 'owners', label: 'Owner Team', get: function (r) { return join(r.owners); }},
    {key: 'vendors', label: 'Vendor Name', get: function (r) { return join(r.vendors); }},
    {key: 'remarks', label: 'Remarks', get: function (r) { return r.remarks; }, hide: true},
    {key: 'created', label: 'Created', get: function (r) { return r.created; }, hide: true},
    {key: 'updated', label: 'Last Updated', get: function (r) { return r.updated; }}
  ];
  var COL_STORE = 'pf.hiddenColumns.v1';

  /* ---- small helpers -------------------------------------------------- */
  function $(id) { return document.getElementById(id); }
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) { n.className = cls; }
    if (text !== undefined && text !== null) { n.textContent = text; }
    return n;
  }
  function clear(n) { while (n.firstChild) { n.removeChild(n.firstChild); } }
  function plural(n, one, many) { return n + ' ' + (n === 1 ? one : (many || one + 's')); }
  function norm(s) { return String(s || '').toLowerCase(); }
  function countBy(rows, fn) {
    var out = {};
    rows.forEach(function (r) {
      var keys = fn(r);
      if (!Array.isArray(keys)) { keys = [keys]; }
      keys.forEach(function (k) { if (k !== '' && k != null) { out[k] = (out[k] || 0) + 1; } });
    });
    return out;
  }
  function url(tpl, id) { return String(tpl).replace(CFG.idToken, String(id)); }
  function storeGet(key) { try { return window.localStorage.getItem(key); } catch (e) { return null; } }
  function storeSet(key, v) { try { window.localStorage.setItem(key, v); } catch (e) { /* private mode */ } }

  /* ---- filtering ------------------------------------------------------ */
  function passes(row, skipKey) {
    for (var i = 0; i < FILTERS.length; i++) {
      var f = FILTERS[i];
      if (f.key === skipKey) { continue; }
      var want = state.filters[f.key];
      if (!want) { continue; }
      var have = row[f.field];
      if (f.multi) {
        if (!have || have.indexOf(want) === -1) { return false; }
      } else if (have !== want) {
        return false;
      }
    }
    if (state.search && norm(row.name).indexOf(norm(state.search)) === -1) { return false; }
    return true;
  }
  function filtered() { return ROWS.filter(function (r) { return passes(r); }); }
  function anyFilter() {
    return !!state.search || FILTERS.some(function (f) { return !!state.filters[f.key]; });
  }
  function setFilter(key, value) {
    state.filters[key] = state.filters[key] === value ? '' : value;
    state.page = 1;
    render();
  }

  /* Options per filter: the master list, each with the count it would give
     under every OTHER active filter - so a choice that empties the page is
     visible before it is made. The current value always stays offered. */
  function optionValues(f) {
    var m = DATA.masters;
    switch (f.key) {
      case 'tower': return m.towers.map(function (t) { return t.name; });
      case 'capability': return m.capabilities;
      case 'ownership': return m.ownership;
      case 'tech': return m.technologies;
      case 'lang': return m.languages;
      case 'iface': return ['Yes', 'No'];
      case 'itype': return m.interface_types;
      case 'bc': return ['BC1', 'BC2', 'BC3'];
      case 'vendor': return Object.keys(countBy(ROWS, function (r) { return r.vendors; })).sort();
      case 'evidence': return SIGNALS;
    }
    return [];
  }

  function buildFilterControls() {
    var grid = $('pfFilters');
    clear(grid);
    FILTERS.forEach(function (f) {
      var wrap = el('label', 'pf-field');
      wrap.appendChild(el('span', 'pf-field-lab', f.label));
      var sel = el('select');
      sel.id = 'pfF_' + f.key;
      sel.addEventListener('change', function () {
        state.filters[f.key] = sel.value;
        state.page = 1;
        buildNeighbours();
        render();
      });
      wrap.appendChild(sel);
      grid.appendChild(wrap);
    });
  }

  function refreshFilterOptions() {
    FILTERS.forEach(function (f) {
      var sel = $('pfF_' + f.key);
      var pool = ROWS.filter(function (r) { return passes(r, f.key); });
      var counts = countBy(pool, function (r) { return r[f.field]; });
      var current = state.filters[f.key] || '';
      clear(sel);
      var all = el('option', null, 'All (' + pool.length + ')');
      all.value = '';
      sel.appendChild(all);
      var seen = {};
      optionValues(f).forEach(function (v) {
        if (seen[v]) { return; }
        seen[v] = true;
        var n = counts[v] || 0;
        var o = el('option', null, v + ' (' + n + ')');
        o.value = v;
        if (!n && v !== current) { o.className = 'pf-opt-zero'; }
        sel.appendChild(o);
      });
      if (current && !seen[current]) {
        var extra = el('option', null, current + ' (0)');
        extra.value = current;
        sel.appendChild(extra);
      }
      sel.value = current;
      sel.classList.toggle('is-set', !!current);
    });
  }

  function renderChips() {
    var box = $('pfChips');
    clear(box);
    var any = false;
    FILTERS.forEach(function (f) {
      var v = state.filters[f.key];
      if (!v) { return; }
      any = true;
      var chip = el('button', 'pf-chip');
      chip.type = 'button';
      chip.title = 'Remove this filter';
      chip.appendChild(el('span', 'pf-chip-k', f.label));
      chip.appendChild(document.createTextNode(v));
      chip.appendChild(el('i', 'fas fa-xmark'));
      chip.addEventListener('click', function () { setFilter(f.key, v); });
      box.appendChild(chip);
    });
    if (state.search) {
      any = true;
      var s = el('button', 'pf-chip');
      s.type = 'button';
      s.appendChild(el('span', 'pf-chip-k', 'Name contains'));
      s.appendChild(document.createTextNode('"' + state.search + '"'));
      s.appendChild(el('i', 'fas fa-xmark'));
      s.addEventListener('click', function () {
        state.search = '';
        $('pfSearch').value = '';
        buildNeighbours();
        render();
      });
      box.appendChild(s);
    }
    box.hidden = !any;
    $('pfReset').disabled = !any;
  }

  function scopeText() {
    var parts = FILTERS.filter(function (f) { return state.filters[f.key]; })
      .map(function (f) { return f.label + ': ' + state.filters[f.key]; });
    if (state.search) { parts.push('name contains "' + state.search + '"'); }
    if (state.tableSearch) { parts.push('table search "' + state.tableSearch + '"'); }
    return parts.join('; ');
  }

  /* ---- KPIs ----------------------------------------------------------- */
  function renderKpis(rows) {
    var box = $('pfKpis');
    clear(box);
    var withIf = rows.filter(function (r) { return r.has_interface; }).length;
    var pct = function (n) { return rows.length ? Math.round(n * 100 / rows.length) + '%' : DASH; };
    var assessed = 0, applicable = 0;
    rows.forEach(function (r) { assessed += r.standards.answered; applicable += r.standards.total; });
    var tiles = [
      ['Applications in scope', rows.length, 'fa-cubes', 'of ' + ROWS.length + ' active records', null],
      ['BC1 applications', rows.filter(function (r) { return r.bc === 'BC1'; }).length,
       'fa-shield-halved', 'highest recorded criticality', ['bc', 'BC1']],
      ['With recorded interfaces', withIf, 'fa-plug', pct(withIf) + ' of applications', ['iface', 'Yes']],
      ['Overdue remediation', rows.filter(function (r) { return r.standards.overdue > 0; }).length,
       'fa-clock', 'applications with past-due controls', ['evidence', 'Overdue remediation']],
      ['Assessment coverage', applicable ? Math.round(100 * assessed / applicable) + '%' : DASH,
       'fa-list-check', assessed + ' / ' + applicable + ' applicable controls answered', null]
    ];
    tiles.forEach(function (t, i) {
      var clickable = Array.isArray(t[4]);
      var card = el(clickable ? 'button' : 'div', 'pf-kpi pf-kpi-' + (i % 4));
      if (clickable) {
        card.type = 'button';
        card.title = 'Filter to ' + t[4][1];
        if (state.filters[t[4][0]] === t[4][1]) { card.classList.add('is-on'); }
        card.addEventListener('click', function () { setFilter(t[4][0], t[4][1]); });
      }
      var lab = el('div', 'pf-kpi-lab');
      lab.appendChild(el('span', null, t[0]));
      lab.appendChild(el('i', 'fas ' + t[2]));
      card.appendChild(lab);
      card.appendChild(el('div', 'pf-kpi-val', String(t[1])));
      card.appendChild(el('div', 'pf-kpi-sub', t[3]));
      box.appendChild(card);
    });
  }

  /* ---- charts --------------------------------------------------------- */
  function empty(node, msg) {
    if (window.Plotly) { try { Plotly.purge(node); } catch (e) { /* not a plot */ } }
    node.classList.remove('js-plotly-plot', 'is-clickable');
    clear(node);
    node.style.height = '';
    node.appendChild(el('div', 'pf-empty', msg || 'No applications match the filters.'));
  }

  /* Label room measured in the page font rather than left to automargin,
     which under-reserves and clips the longest name. */
  var measureCtx = null;
  function textWidth(s) {
    if (!measureCtx) {
      measureCtx = document.createElement('canvas').getContext('2d');
      measureCtx.font = '12px ' + FONT.family;
    }
    return measureCtx.measureText(s).width;
  }
  function fitLabels(labels, maxPx) {
    return labels.map(function (l) {
      if (textWidth(l) <= maxPx) { return l; }
      var s = l;
      while (s.length > 1 && textWidth(s + ELLIPSIS) > maxPx) { s = s.slice(0, -1); }
      return s + ELLIPSIS;
    });
  }

  function hbar(node, entries, opts) {
    opts = opts || {};
    if (!entries.length) { empty(node, opts.emptyText); return; }
    var width = node.clientWidth || 520;
    var cap = Math.round(width * 0.42);
    var widest = 0;
    entries.forEach(function (e) { widest = Math.max(widest, textWidth(e[0])); });
    var left = Math.min(cap, Math.ceil(widest) + 26);
    var labels = fitLabels(entries.map(function (e) { return e[0]; }), left - 26);
    var height = Math.max(96, entries.length * 30 + 24);
    node.style.height = height + 'px';
    var active = opts.activeValue;
    plotInto(node, [{
      type: 'bar', orientation: 'h',
      x: entries.map(function (e) { return e[1]; }),
      y: labels,
      customdata: entries.map(function (e) { return e[0]; }),
      marker: {
        color: entries.map(function (e) {
          return active && e[0] !== active ? '#b7d3f6' : (opts.color || C.blue);
        }),
        cornerradius: 4
      },
      text: entries.map(function (e) { return String(e[1]); }),
      textposition: 'outside', textangle: 0, cliponaxis: false,
      textfont: {color: C.ink2, size: 12},
      hovertemplate: '%{customdata}: %{x} ' + (opts.unit || 'applications') + '<extra></extra>'
    }], {
      font: FONT, autosize: true, height: height,
      margin: {t: 4, r: 40, b: 4, l: left, pad: 8},
      paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
      bargap: 0.38,
      xaxis: {visible: false, fixedrange: true, rangemode: 'tozero'},
      yaxis: {autorange: 'reversed', automargin: false, fixedrange: true,
              tickfont: {size: 12, color: C.ink2}},
      showlegend: false,
      hoverlabel: {bgcolor: '#fff', bordercolor: C.line, font: {color: C.ink}}
    }, PLOT_CFG);
    bindClick(node, opts.onClick, function (pt) { return pt.customdata; });
  }

  function donut(node, entries, colors, opts) {
    opts = opts || {};
    var total = entries.reduce(function (s, e) { return s + e[1]; }, 0);
    if (!total) { empty(node); return; }
    node.style.height = '260px';
    var active = opts.activeValue;
    plotInto(node, [{
      type: 'pie', hole: 0.64, sort: false, direction: 'clockwise',
      labels: entries.map(function (e) { return e[0] + '  ' + e[1]; }),
      values: entries.map(function (e) { return e[1]; }),
      customdata: entries.map(function (e) { return e[0]; }),
      marker: {colors: entries.map(function (e) {
        return active && e[0] !== active ? '#dfe6f0' : colors[e[0]] || C.gray;
      }), line: {color: '#ffffff', width: 2}},
      textinfo: 'none',
      hovertemplate: '%{customdata}: %{value} (%{percent})<extra></extra>'
    }], {
      font: FONT, autosize: true, height: 260,
      margin: {t: 8, r: 8, b: 8, l: 8},
      paper_bgcolor: 'rgba(0,0,0,0)',
      showlegend: true,
      legend: {orientation: 'v', x: 1.02, xanchor: 'left', y: 0.5, yanchor: 'middle',
               font: {size: 12, color: C.ink2}, itemclick: false, itemdoubleclick: false},
      annotations: [{text: '<b>' + total + '</b><br><span style="font-size:11px;color:' + C.ink3 + '">applications</span>',
                     showarrow: false, font: {size: 22, color: C.ink}, x: 0.5, y: 0.5,
                     xref: 'paper', yref: 'paper'}],
      hoverlabel: {bgcolor: '#fff', bordercolor: C.line, font: {color: C.ink}}
    }, PLOT_CFG);
    bindClick(node, opts.onClick, function (pt) { return pt.customdata; });
  }

  /* A node that already holds a plot is updated in place; anything else
     (first draw, or the empty-state message) is cleared and drawn fresh.
     Wiping a live plot's DOM and then calling react() on it is what left a
     chart blank after a resize or a filter change. */
  function plotInto(node, data, layout, cfg) {
    if (node.classList.contains('js-plotly-plot') && node.querySelector('.main-svg')) {
      return Plotly.react(node, data, layout, cfg);
    }
    clear(node);
    return Plotly.newPlot(node, data, layout, cfg);
  }

  function bindClick(node, handler, pick) {
    if (!handler || !node.on) { return; }
    node.removeAllListeners && node.removeAllListeners('plotly_click');
    node.on('plotly_click', function (ev) {
      var pt = ev && ev.points && ev.points[0];
      if (pt) { handler(pick(pt)); }
    });
    node.classList.add('is-clickable');
  }

  function sortedEntries(counts, limit) {
    var list = Object.keys(counts).map(function (k) { return [k, counts[k]]; });
    list.sort(function (a, b) { return b[1] - a[1] || a[0].localeCompare(b[0]); });
    return limit ? list.slice(0, limit) : list;
  }

  function renderCharts(rows) {
    renderArchitecture(rows);
    // A. by tower - every tower, zeros included, so an empty tower is visible
    var byTower = countBy(rows, function (r) { return r.tower; });
    var towers = DATA.masters.towers.map(function (t) { return t.name; })
      .filter(function (name) { return !state.filters.tower || name === state.filters.tower; });
    var towerEntries = towers.map(function (name) { return [name, byTower[name] || 0]; })
      .sort(function (a, b) { return b[1] - a[1] || a[0].localeCompare(b[0]); });
    if (!rows.length) { towerEntries = []; }
    if (view === 'sourcing') { hbar($('cTower'), towerEntries, {
      activeValue: state.filters.tower,
      onClick: function (v) { setFilter('tower', v); }
    });

    // B. ownership
    var own = countBy(rows, function (r) { return r.ownership; });
    donut($('cOwn'), DATA.masters.ownership.map(function (k) { return [k, own[k] || 0]; })
      .filter(function (e) { return e[1]; }), OWN_COLOR,
      {activeValue: state.filters.ownership, onClick: function (v) { setFilter('ownership', v); }});

    }
    if (view === 'technology') {
    // C. top technologies
    hbar($('cTech'), sortedEntries(countBy(rows, function (r) { return r.technologies; }), 12), {
      activeValue: state.filters.tech,
      emptyText: rows.length ? 'No technologies recorded for these applications.' : null,
      onClick: function (v) { setFilter('tech', v); }
    });

    // D. languages
    hbar($('cLang'), sortedEntries(countBy(rows, function (r) { return r.languages; })), {
      activeValue: state.filters.lang,
      emptyText: rows.length ? 'No programming languages recorded for these applications.' : null,
      onClick: function (v) { setFilter('lang', v); }
    });

    }
    if (view === 'dependencies') {
    // E. with / without interfaces
    var withIf = rows.filter(function (r) { return r.has_interface; }).length;
    donut($('cIf'), [['With interfaces', withIf], ['No interfaces recorded', rows.length - withIf]]
      .filter(function (e) { return e[1]; }),
      {'With interfaces': C.aqua, 'No interfaces recorded': C.gray},
      {activeValue: state.filters.iface === 'Yes' ? 'With interfaces'
                  : state.filters.iface === 'No' ? 'No interfaces recorded' : '',
       onClick: function (v) { setFilter('iface', v === 'With interfaces' ? 'Yes' : 'No'); }});

    // G. interface direction
    renderDirection(rows);

    }
    // F. tower x ownership (stacked)
    if (view === 'sourcing') { renderStacked(rows, towers); }

    // H. heatmap
    if (view === 'technology') { renderHeat(rows, towers); }

    // I. inter-tower connections
    if (view === 'dependencies') { renderTowerLinks(rows, towers); }
  }

  function prepareRow(r) {
    r.standards = r.standards || {total: 0, answered: 0, unanswered: 0, overdue: 0, counts: {}, findings: []};
    r.stack = r.stack || [];
    r.signals = [];
    if (r.standards.overdue) { r.signals.push('Overdue remediation'); }
    if (r.capability === 'Uncategorised') { r.signals.push('No capability recorded'); }
    if (!r.stack.length) { r.signals.push('No technology recorded'); }
    if (!r.owners.length) { r.signals.push('No primary owner recorded'); }
    if (r.standards.unanswered) { r.signals.push('Unanswered controls'); }
    Object.keys(r.standards.counts).forEach(function (key) {
      if (r.standards.counts[key]) { r.signals.push(key); }
    });
  }

  function buildNeighbours() {
    neighbours = {};
    ROWS.forEach(function (r) { neighbours[r.id] = {inbound: new Set(), outbound: new Set()}; });
    (DATA.links || []).forEach(function (link) {
      var a = neighbours[link.src], b = neighbours[link.dst];
      if (!a || !b || link.src === link.dst) { return; }
      a.outbound.add(link.dst); b.inbound.add(link.src);
      if (link.bidir) { a.inbound.add(link.dst); b.outbound.add(link.src); }
    });
  }
  function degree(id) {
    var n = neighbours[id];
    return n ? new Set(Array.from(n.inbound).concat(Array.from(n.outbound))).size : 0;
  }
  function selectBoth(first, value, second, other) {
    state.filters[first] = value; state.filters[second] = other;
    state.page = 1; render();
  }
  function appButton(r, label) {
    var button = el('button', 'pf-text-button', label || r.name);
    button.type = 'button';
    button.addEventListener('click', function () { openDrawer(r); });
    return button;
  }
  function makeTable(node, labels) {
    clear(node);
    var wrap = el('div', 'pf-table-wrap');
    var table = el('table', 'pf-insight-table');
    var head = el('thead'), tr = el('tr');
    labels.forEach(function (label) { var th = el('th', null, label); th.scope = 'col'; tr.appendChild(th); });
    head.appendChild(tr); table.appendChild(head);
    var body = el('tbody'); table.appendChild(body); wrap.appendChild(table); node.appendChild(wrap);
    return body;
  }
  function renderCapability(rows) {
    var node = $('cCapability');
    if (!rows.length) { empty(node); return; }
    var towers = Object.keys(countBy(rows, function (r) { return r.tower; })).sort();
    var caps = sortedEntries(countBy(rows, function (r) { return r.capability; })).map(function (v) { return v[0]; });
    var counts = Object.create(null), max = 1;
    rows.forEach(function (r) { var key = JSON.stringify([r.tower, r.capability]); counts[key] = (counts[key] || 0) + 1; max = Math.max(max, counts[key]); });
    var body = makeTable(node, ['Tower / capability'].concat(caps));
    towers.forEach(function (tower) {
      var tr = el('tr'), th = el('th', null, tower); th.scope = 'row'; tr.appendChild(th);
      caps.forEach(function (cap) {
        var n = counts[JSON.stringify([tower, cap])] || 0, td = el('td');
        if (n) {
          var button = el('button', 'pf-heat-button', String(n)); button.type = 'button';
          var step = heatStep(n, max); button.style.background = SEQ[step]; button.style.color = step >= 3 ? '#fff' : C.ink;
          button.setAttribute('aria-label', tower + ', ' + cap + ': ' + n + ' applications. Filter');
          button.addEventListener('click', function () { selectBoth('tower', tower, 'capability', cap); });
          td.appendChild(button);
        } else { td.textContent = '0'; td.className = 'pf-mute'; }
        tr.appendChild(td);
      });
      body.appendChild(tr);
    });
    node.appendChild(el('p', 'pf-context', 'Darker = more applications. One recorded category per application; overlap is not proof of duplication.'));
  }
  function renderHotspots(rows) {
    var node = $('cHotspots');
    var ranked = rows.filter(function (r) { return degree(r.id) > 0; }).sort(function (a, b) { return degree(b.id) - degree(a.id) || a.name.localeCompare(b.name); }).slice(0, 12);
    if (!ranked.length) { empty(node, 'No registered application connections recorded in this selection.'); return; }
    var body = makeTable(node, ['Application', 'Unique neighbours', 'Inbound', 'Outbound', 'Outbound BC1 neighbours']);
    var max = degree(ranked[0].id);
    ranked.forEach(function (r) {
      var n = neighbours[r.id], tr = el('tr'), td = el('td'); td.appendChild(appButton(r, r.name + ' / ' + r.tower)); tr.appendChild(td);
      td = el('td'); var bar = el('div', 'pf-rank'); var fill = el('span', 'pf-rank-fill'); fill.style.width = (degree(r.id) * 100 / max) + '%'; bar.appendChild(fill); bar.appendChild(el('strong', null, String(degree(r.id)))); td.appendChild(bar); tr.appendChild(td);
      [n.inbound.size, n.outbound.size, ROWS.filter(function (a) { return a.bc === 'BC1' && n.outbound.has(a.id); }).length].forEach(function (value) { tr.appendChild(el('td', null, String(value))); });
      body.appendChild(tr);
    });
  }
  var STANDARD_COLORS = {'Compliant': '#25856a', 'Vendor Product Compliant': '#3987e5',
    'Non Compliant': '#bd384c', 'Not Started': '#d08b22', 'In Progress': '#8a6bc1', 'Unanswered': '#a3aab8'};
  function renderStandards(rows) {
    var node = $('cStandards'); clear(node);
    if (!rows.length) { empty(node); return; }
    var legend = el('div', 'pf-standard-legend');
    Object.keys(STANDARD_COLORS).forEach(function (key) { var label = el('span', null, key); label.style.borderLeftColor = STANDARD_COLORS[key]; legend.appendChild(label); });
    node.appendChild(legend);
    var total = 0;
    Object.keys(countBy(rows, function (r) { return r.tower; })).sort().forEach(function (tower) {
      var apps = rows.filter(function (r) { return r.tower === tower; }), counts = {}, sum = 0;
      Object.keys(STANDARD_COLORS).forEach(function (key) {
        counts[key] = apps.reduce(function (n, r) { return n + (key === 'Unanswered' ? r.standards.unanswered : r.standards.counts[key] || 0); }, 0); sum += counts[key];
      });
      total += sum;
      var lane = el('div', 'pf-standard-row'); lane.appendChild(el('strong', null, tower));
      var bar = el('div', 'pf-standard-bar');
      if (!sum) { bar.appendChild(el('span', 'pf-mute', 'No applicable controls')); }
      Object.keys(counts).forEach(function (key) {
        if (!counts[key]) { return; }
        var b = el('button', null, String(counts[key])); b.type = 'button'; b.style.flexGrow = counts[key]; b.style.background = STANDARD_COLORS[key];
        if (key === 'Unanswered' || key === 'Not Started') { b.style.color = '#172235'; b.style.textShadow = 'none'; }
        b.title = key + ': ' + counts[key] + ' controls'; b.setAttribute('aria-label', tower + ', ' + b.title + '. Show applications');
        b.addEventListener('click', function () { selectBoth('tower', tower, 'evidence', key === 'Unanswered' ? 'Unanswered controls' : key); }); bar.appendChild(b);
      });
      lane.appendChild(bar); lane.appendChild(el('span', 'pf-mute', sum + ' controls')); node.appendChild(lane);
    });
    if (!total) { node.appendChild(el('p', 'pf-context', 'Assessment coverage is unavailable until applicable checklist items are configured.')); }
  }
  function renderArchitecture(rows) {
    if (view === 'overview') {
      renderCapability(rows);
      hbar($('cCriticality'), sortedEntries(countBy(rows, function (r) { return r.bc; })), {onClick: function (v) { setFilter('bc', v); }});
    }
    if (view === 'dependencies') { renderHotspots(rows); }
    if (view === 'sourcing') {
      hbar($('cVendor'), sortedEntries(countBy(rows, function (r) { return r.vendors; })), {emptyText: 'No vendors recorded in this selection.', onClick: function (v) { setFilter('vendor', v); }});
    }
    if (view === 'standards') {
      renderStandards(rows);
      hbar($('cRemediation'), sortedEntries(countBy(rows.filter(function (r) { return r.standards.overdue > 0; }), function (r) { return r.tower; })),
        {color: '#bd384c', emptyText: rows.length ? 'No overdue remediation recorded in this selection.' : null, onClick: function (v) { selectBoth('tower', v, 'evidence', 'Overdue remediation'); }});
      hbar($('cGaps'), SIGNALS.slice(1, 6).map(function (key) { return [key, rows.filter(function (r) { return r.signals.indexOf(key) !== -1; }).length]; }).filter(function (e) { return e[1]; }),
        {emptyText: rows.length ? 'No gaps in the five tracked evidence fields.' : null, onClick: function (v) { setFilter('evidence', v); }});
    }
  }

  function renderDirection(rows) {
    var node = $('cIfType');
    var kinds = [['Inbound', 'Inbound only'], ['Outbound', 'Outbound only'], ['Both', 'Both directions']];
    var counts = countBy(rows, function (r) { return r.interface_type; });
    var total = kinds.reduce(function (s, k) { return s + (counts[k[0]] || 0); }, 0);
    if (!total) {
      empty(node, rows.length ? 'None of these applications has a recorded interface.' : null);
      return;
    }
    node.style.height = '260px';
    var active = state.filters.itype;
    plotInto(node, [{
      type: 'bar',
      x: kinds.map(function (k) { return k[1]; }),
      y: kinds.map(function (k) { return counts[k[0]] || 0; }),
      customdata: kinds.map(function (k) { return k[0]; }),
      marker: {color: kinds.map(function (k) {
        return active && active !== k[0] ? '#dfe6f0' : IF_COLOR[k[0]];
      }), cornerradius: 4},
      text: kinds.map(function (k) { return String(counts[k[0]] || 0); }),
      textposition: 'outside', cliponaxis: false,
      textfont: {color: C.ink2, size: 12},
      hovertemplate: '%{x}: %{y} applications<extra></extra>'
    }], {
      font: FONT, autosize: true, height: 260,
      margin: {t: 24, r: 8, b: 34, l: 8},
      paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
      bargap: 0.62,
      xaxis: {fixedrange: true, tickfont: {size: 12, color: C.ink2}},
      yaxis: {visible: false, fixedrange: true, rangemode: 'tozero'},
      showlegend: false,
      hoverlabel: {bgcolor: '#fff', bordercolor: C.line, font: {color: C.ink}}
    }, PLOT_CFG);
    bindClick(node, function (v) { setFilter('itype', v); }, function (pt) { return pt.customdata; });
  }

  function renderStacked(rows, towers) {
    var node = $('cTowerOwn');
    if (!rows.length) { empty(node); return; }
    var byTower = {};
    rows.forEach(function (r) {
      var t = byTower[r.tower] || (byTower[r.tower] = {total: 0});
      t[r.ownership] = (t[r.ownership] || 0) + 1;
      t.total += 1;
    });
    var names = towers.filter(function (n) { return byTower[n]; })
      .sort(function (a, b) { return byTower[b].total - byTower[a].total || a.localeCompare(b); });
    var width = node.clientWidth || 900;
    var widest = 0;
    names.forEach(function (n) { widest = Math.max(widest, textWidth(n)); });
    var left = Math.min(Math.round(width * 0.3), Math.ceil(widest) + 26);
    var labels = fitLabels(names, left - 26);
    var height = Math.max(160, names.length * 32 + 60);
    node.style.height = height + 'px';
    var traces = DATA.masters.ownership.map(function (kind) {
      return {
        type: 'bar', orientation: 'h', name: kind,
        y: labels, x: names.map(function (n) { return byTower[n][kind] || 0; }),
        customdata: names,
        marker: {color: OWN_COLOR[kind], line: {color: '#ffffff', width: 2}},
        hovertemplate: '%{customdata} \u00b7 ' + kind + ': %{x}<extra></extra>'
      };
    }).filter(function (t) { return t.x.some(function (v) { return v > 0; }); });
    plotInto(node, traces, {
      font: FONT, autosize: true, height: height, barmode: 'stack',
      margin: {t: 36, r: 16, b: 24, l: left, pad: 8},
      paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
      bargap: 0.36,
      xaxis: {fixedrange: true, gridcolor: C.line, zeroline: false, dtick: niceTick(names, byTower),
              tickfont: {size: 11, color: C.ink3}},
      yaxis: {autorange: 'reversed', automargin: false, fixedrange: true,
              tickfont: {size: 12, color: C.ink2}},
      legend: {orientation: 'h', x: 0, y: 1.02, yanchor: 'bottom', traceorder: 'normal',
               font: {size: 12, color: C.ink2},
               itemclick: false, itemdoubleclick: false},
      hoverlabel: {bgcolor: '#fff', bordercolor: C.line, font: {color: C.ink}}
    }, PLOT_CFG);
    bindClick(node, function (v) { setFilter('tower', v); }, function (pt) { return pt.customdata; });
  }
  function niceTick(names, byTower) {
    var max = 0;
    names.forEach(function (n) { max = Math.max(max, byTower[n].total); });
    return max <= 10 ? 1 : null;
  }

  function renderHeat(rows, towers) {
    var node = $('cHeat');
    clear(node);
    var techCounts = countBy(rows, function (r) { return r.technologies; });
    var techs = sortedEntries(techCounts, 14).map(function (e) { return e[0]; });
    var towerNames = towers.filter(function (n) {
      return rows.some(function (r) { return r.tower === n; });
    });
    if (!techs.length || !towerNames.length) {
      node.appendChild(el('div', 'pf-empty', rows.length
        ? 'No technologies recorded for these applications.'
        : 'No applications match the filters.'));
      return;
    }
    var cell = {};
    var max = 0;
    rows.forEach(function (r) {
      r.technologies.forEach(function (t) {
        var k = r.tower + '\u0000' + t;
        cell[k] = (cell[k] || 0) + 1;
        max = Math.max(max, cell[k]);
      });
    });
    var table = el('table', 'pf-heat');
    var thead = el('thead');
    var hr = el('tr');
    hr.appendChild(el('th', 'pf-heat-corner', 'Tower / technology'));
    techs.forEach(function (t) {
      var th = el('th', null);
      th.scope = 'col';
      th.appendChild(el('span', null, t));
      th.title = t + ' \u00b7 ' + techCounts[t] + ' applications';
      hr.appendChild(th);
    });
    hr.appendChild(el('th', 'pf-heat-total', 'Apps'));
    thead.appendChild(hr);
    table.appendChild(thead);
    var tbody = el('tbody');
    towerNames.forEach(function (tower) {
      var tr = el('tr');
      var th = el('th', null, tower);
      th.scope = 'row';
      tr.appendChild(th);
      techs.forEach(function (t) {
        var n = cell[tower + '\u0000' + t] || 0;
        var td = el('td', n ? 'is-hit' : 'is-zero', n ? String(n) : '');
        if (n) {
          /* Steps 1..6 of the ramp (step 0 is too close to the surface to
             read as a mark); a lone maximum of 1 sits mid-ramp. */
          var step = heatStep(n, max);
          td.style.background = SEQ[step];
          td.style.color = step >= 3 ? '#ffffff' : C.ink;
          td.title = tower + ' \u00b7 ' + t + ': ' + n + ' application' + (n === 1 ? '' : 's') + ' (click to filter)';
          td.tabIndex = 0;
          td.addEventListener('click', function () { heatFilter(tower, t); });
          td.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); heatFilter(tower, t); }
          });
        }
        tr.appendChild(td);
      });
      tr.appendChild(el('td', 'pf-heat-total',
        String(rows.filter(function (r) { return r.tower === tower; }).length)));
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    node.appendChild(table);
    var legend = el('div', 'pf-heat-legend');
    legend.appendChild(el('span', null, 'Fewer'));
    SEQ.slice(1).forEach(function (c) {
      var sw = el('i');
      sw.style.background = c;
      legend.appendChild(sw);
    });
    legend.appendChild(el('span', null, 'More (max ' + max + ')'));
    if (Object.keys(techCounts).length > techs.length) {
      legend.appendChild(el('span', 'pf-heat-note',
        'Showing the ' + techs.length + ' most-used of ' + Object.keys(techCounts).length + ' technologies.'));
    }
    node.appendChild(legend);
  }
  /* The ramp step for n of max: steps 1..6 (step 0 is too close to the
     surface to read as a mark); a lone maximum of 1 sits mid-ramp. */
  function heatStep(n, max) {
    return max === 1 ? 3 : 1 + Math.round(((n - 1) / (max - 1)) * (SEQ.length - 2));
  }

  /* Inter-tower connections: a directional tower x tower matrix over the
     resolved links. A link is in scope when EITHER of its applications
     passes the filters, so filtering to one tower shows everything it
     talks to, not only its internal traffic. */
  var linkSel = null;
  function renderTowerLinks(rows, towers) {
    var node = $('cLinks');
    var list = $('cLinksList');
    clear(node);
    var inScope = {};
    rows.forEach(function (r) { inScope[r.id] = true; });
    var byId = {};
    ROWS.forEach(function (r) { byId[r.id] = r; });
    var cell = {}, pairs = {}, max = 0, sends = {}, gets = {}, used = {};
    function add(a, b, link) {
      var k = a.tower + '\u0000' + b.tower;
      cell[k] = (cell[k] || 0) + 1;
      (pairs[k] || (pairs[k] = [])).push({from: a, to: b, via: link.via, bidir: link.bidir});
      max = Math.max(max, cell[k]);
      sends[a.tower] = (sends[a.tower] || 0) + 1;
      gets[b.tower] = (gets[b.tower] || 0) + 1;
      used[a.tower] = used[b.tower] = true;
    }
    var total = 0, cross = 0;
    (DATA.links || []).forEach(function (link) {
      var a = byId[link.src], b = byId[link.dst];
      if (!a || !b || !(inScope[a.id] || inScope[b.id])) { return; }
      total += 1;
      if (a.tower !== b.tower) { cross += 1; }
      add(a, b, link);
      if (link.bidir) { add(b, a, link); }
    });
    var names = DATA.masters.towers.map(function (t) { return t.name; })
      .filter(function (n) { return used[n]; });
    if (!names.length) {
      node.appendChild(el('div', 'pf-empty', rows.length
        ? 'No connections between applications are recorded for these applications.'
        : 'No applications match the filters.'));
      list.hidden = true;
      return;
    }
    var table = el('table', 'pf-heat pf-links');
    var thead = el('thead');
    var hr = el('tr');
    hr.appendChild(el('th', 'pf-heat-corner', 'From \u2193  to \u2192'));
    names.forEach(function (n) {
      var th = el('th');
      th.scope = 'col';
      th.appendChild(el('span', null, n));
      th.title = n + ' receives ' + (gets[n] || 0);
      hr.appendChild(th);
    });
    hr.appendChild(el('th', 'pf-heat-total', 'Sends'));
    thead.appendChild(hr);
    table.appendChild(thead);
    var tbody = el('tbody');
    names.forEach(function (from) {
      var tr = el('tr');
      var th = el('th', null, from);
      th.scope = 'row';
      tr.appendChild(th);
      names.forEach(function (to) {
        var k = from + '\u0000' + to;
        var n = cell[k] || 0;
        var td = el('td', (n ? 'is-hit' : 'is-zero') + (from === to ? ' is-self' : ''),
                    n ? String(n) : '');
        if (n) {
          var step = heatStep(n, max);
          td.style.background = SEQ[step];
          td.style.color = step >= 3 ? '#ffffff' : C.ink;
          td.title = (from === to ? 'Within ' + from : from + ' \u2192 ' + to) + ': '
            + n + ' connection' + (n === 1 ? '' : 's') + ' (click to list)';
          td.tabIndex = 0;
          if (linkSel === k) { td.classList.add('is-picked'); }
          var open = function () { linkSel = linkSel === k ? null : k; renderTowerLinks(rows, towers); };
          td.addEventListener('click', open);
          td.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); }
          });
        }
        tr.appendChild(td);
      });
      tr.appendChild(el('td', 'pf-heat-total', String(sends[from] || 0)));
      tbody.appendChild(tr);
    });
    var fr = el('tr', 'pf-links-foot');
    fr.appendChild(el('th', null, 'Receives'));
    names.forEach(function (n) { fr.appendChild(el('td', 'pf-heat-total', String(gets[n] || 0))); });
    fr.appendChild(el('td', 'pf-heat-total', ''));
    tbody.appendChild(fr);
    table.appendChild(tbody);
    node.appendChild(table);

    var legend = el('div', 'pf-heat-legend');
    legend.appendChild(el('span', null, 'Fewer'));
    SEQ.slice(1).forEach(function (c) {
      var sw = el('i');
      sw.style.background = c;
      legend.appendChild(sw);
    });
    legend.appendChild(el('span', null, 'More (max ' + max + ')'));
    legend.appendChild(el('span', 'pf-heat-note',
      plural(total, 'connection') + ' \u00b7 ' + cross + ' cross tower \u00b7 '
      + (total - cross) + ' within a tower'));
    node.appendChild(legend);

    // The list for the picked cell (kept while it still exists).
    clear(list);
    if (!linkSel || !pairs[linkSel]) { linkSel = null; list.hidden = true; return; }
    var parts = linkSel.split('\u0000');
    var head = el('div', 'pf-linklist-head');
    head.appendChild(el('b', null, parts[0] === parts[1] ? 'Within ' + parts[0]
      : parts[0] + ' \u2192 ' + parts[1]));
    head.appendChild(el('span', null, plural(pairs[linkSel].length, 'connection')));
    var x = el('button', 'pf-x', '');
    x.type = 'button';
    x.setAttribute('aria-label', 'Close the list');
    x.appendChild(el('i', 'fas fa-xmark'));
    x.addEventListener('click', function () { linkSel = null; renderTowerLinks(rows, towers); });
    head.appendChild(x);
    list.appendChild(head);
    var ul = el('ul');
    pairs[linkSel].slice().sort(function (p, q) {
      return p.from.name.localeCompare(q.from.name) || p.to.name.localeCompare(q.to.name);
    }).forEach(function (p) {
      var li = el('li');
      li.appendChild(appLink(p.from));
      li.appendChild(el('span', 'pf-arrow', p.bidir ? ' \u2194 ' : ' \u2192 '));
      li.appendChild(appLink(p.to));
      if (p.via) { li.appendChild(el('span', 'pf-via', p.via)); }
      ul.appendChild(li);
    });
    list.appendChild(ul);
    list.hidden = false;
  }
  function appLink(r) {
    var b = el('button', 'pf-applink', r.name);
    b.type = 'button';
    b.title = 'Open details for ' + r.name;
    b.addEventListener('click', function () { openDrawer(r); });
    return b;
  }

  function heatFilter(tower, tech) {
    state.filters.tower = tower;
    state.filters.tech = tech;
    state.page = 1;
    render();
  }

  /* ---- table ---------------------------------------------------------- */
  function visibleColumns() {
    return COLUMNS.filter(function (c) { return c.fixed || !state.hidden[c.key]; });
  }

  function tableRows(rows) {
    var q = norm(state.tableSearch);
    var list = rows;
    if (q) {
      list = rows.filter(function (r) {
        return COLUMNS.some(function (c) { return c.get && norm(c.get(r)).indexOf(q) !== -1; });
      });
    }
    var col = null;
    COLUMNS.forEach(function (c) { if (c.key === state.sortKey) { col = c; } });
    if (col && col.get) {
      var dir = state.sortDir;
      list = list.slice().sort(function (a, b) {
        var x = col.get(a) || '', y = col.get(b) || '';
        if (!x && y) { return 1; }
        if (x && !y) { return -1; }
        return dir * String(x).localeCompare(String(y), undefined, {numeric: true, sensitivity: 'base'})
          || a.name.localeCompare(b.name);
      });
    }
    return list;
  }

  function buildColumnMenu() {
    var menu = $('pfColMenu');
    clear(menu);
    menu.appendChild(el('div', 'pf-menu-cap', 'Show columns'));
    COLUMNS.forEach(function (c) {
      if (c.fixed) { return; }
      var lab = el('label', 'pf-colopt');
      var cb = el('input');
      cb.type = 'checkbox';
      cb.checked = !state.hidden[c.key];
      cb.addEventListener('change', function () {
        state.hidden[c.key] = !cb.checked;
        storeSet(COL_STORE, JSON.stringify(state.hidden));
        renderTable(filtered());
      });
      lab.appendChild(cb);
      lab.appendChild(document.createTextNode(' ' + c.label));
      menu.appendChild(lab);
    });
  }

  var tableCache = [];
  function renderTable(rows) {
    var cols = visibleColumns();
    var list = tableRows(rows);
    tableCache = list;
    var thead = $('pfThead');
    clear(thead);
    cols.forEach(function (c) {
      var th = el('th');
      th.scope = 'col';
      if (c.sort === false) {
        th.textContent = c.label;
      } else {
        var b = el('button', 'pf-sort', c.label);
        b.type = 'button';
        var on = state.sortKey === c.key;
        th.setAttribute('aria-sort', on ? (state.sortDir > 0 ? 'ascending' : 'descending') : 'none');
        b.appendChild(el('i', 'fas ' + (on ? (state.sortDir > 0 ? 'fa-arrow-up' : 'fa-arrow-down') : 'fa-sort')));
        if (on) { b.classList.add('is-on'); }
        b.addEventListener('click', function () {
          if (state.sortKey === c.key) { state.sortDir = -state.sortDir; }
          else { state.sortKey = c.key; state.sortDir = 1; }
          renderTable(filtered());
        });
        th.appendChild(b);
      }
      thead.appendChild(th);
    });

    var pages = Math.max(1, Math.ceil(list.length / state.pageSize));
    if (state.page > pages) { state.page = pages; }
    var start = (state.page - 1) * state.pageSize;
    var slice = list.slice(start, start + state.pageSize);
    var tbody = $('pfTbody');
    clear(tbody);
    if (!slice.length) {
      var tr0 = el('tr');
      var td0 = el('td', 'pf-table-empty', ROWS.length
        ? 'No applications match the current filters.'
        : 'No applications recorded yet.');
      td0.colSpan = cols.length;
      tr0.appendChild(td0);
      tbody.appendChild(tr0);
    }
    slice.forEach(function (r, i) {
      var tr = el('tr');
      tr.tabIndex = 0;
      tr.setAttribute('role', 'button');
      tr.setAttribute('aria-label', 'Open details for ' + r.name);
      tr.addEventListener('click', function () { openDrawer(r); });
      tr.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openDrawer(r); }
      });
      cols.forEach(function (c) {
        var td = el('td', 'pf-c-' + c.key);
        if (c.key === 'sno') {
          td.textContent = String(start + i + 1);
        } else if (c.key === 'ownership') {
          td.appendChild(ownBadge(r.ownership));
        } else if (c.key === 'name') {
          td.appendChild(el('span', 'pf-name', r.name));
          if (r.bc) { td.appendChild(el('span', 'bc-pill ' + r.bc.toLowerCase(), r.bc)); }
        } else {
          var v = c.get(r);
          if (v) {
            /* Clamped to two lines so one long interface list cannot make
               a row five lines tall; the full text is the tooltip and the
               drawer. */
            var sp = el('span', 'pf-clamp', v);
            sp.title = v;
            td.appendChild(sp);
          } else {
            td.appendChild(el('span', 'pf-mute', DASH));
          }
        }
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });

    $('pfPageInfo').textContent = list.length
      ? 'Showing ' + (start + 1) + '\u2013' + (start + slice.length) + ' of ' + plural(list.length, 'application')
      : '0 applications';
    $('pfPageNo').textContent = 'Page ' + state.page + ' of ' + pages;
    $('pfPrev').disabled = state.page <= 1;
    $('pfNext').disabled = state.page >= pages;
    $('pfInvSub').textContent = (state.tableSearch
      ? plural(list.length, 'application') + ' match "' + state.tableSearch + '" \u00b7 '
      : '') + 'Click a row for the full record.';
  }

  function ownBadge(own) {
    var span = el('span', 'pf-own');
    var dot = el('i', 'pf-dot');
    dot.style.background = OWN_COLOR[own] || C.gray;
    span.appendChild(dot);
    span.appendChild(document.createTextNode(own));
    return span;
  }

  /* ---- drawer --------------------------------------------------------- */
  var lastFocus = null;
  function openDrawer(r) {
    if ($('pfDrawer').getAttribute('aria-hidden') === 'true') { lastFocus = document.activeElement; }
    $('pfDrawerEyebrow').textContent = r.tower + (r.bc ? ' \u00b7 ' + r.bc : '');
    $('pfDrawerTitle').textContent = r.name;
    var body = $('pfDrawerBody');
    clear(body);
    var top = el('div', 'pf-drawer-badges');
    top.appendChild(ownBadge(r.ownership));
    body.appendChild(top);
    if (r.summary) { body.appendChild(el('p', 'pf-drawer-sum', r.summary)); }
    var dl = el('dl', 'pf-dl');
    function row(label, value, isList) {
      dl.appendChild(el('dt', null, label));
      var dd = el('dd');
      if (isList) {
        if (value && value.length) {
          var ul = el('div', 'pf-taglist');
          value.forEach(function (v) { ul.appendChild(el('span', 'pf-tag', v)); });
          dd.appendChild(ul);
        } else {
          dd.appendChild(el('span', 'pf-mute', 'Not recorded'));
        }
      } else if (value) {
        dd.textContent = value;
      } else {
        dd.appendChild(el('span', 'pf-mute', 'Not recorded'));
      }
      dl.appendChild(dd);
    }
    row('Application ID', String(r.id));
    row('Tower', r.tower);
    row('Business capability', r.capability);
    row('Business criticality', r.bc);
    row('Ownership type', r.ownership);
    row('Vendor', r.vendors, true);
    row('Technology / tools', r.technologies, true);
    row('Programming languages', r.languages, true);
    row('Recorded interfaces', r.has_interface ? 'Yes \u00b7 ' + r.interface_type : 'No');
    row('Inbound systems', r.inbound, true);
    row('Outbound systems', r.outbound, true);
    row('Owner team', r.owners, true);
    row('Remarks', r.remarks);
    row('Created', r.created);
    row('Last updated', r.updated);
    body.appendChild(dl);

    var techSection = el('section', 'pf-drawer-section');
    techSection.appendChild(el('h3', null, 'Technology & versions'));
    r.stack.forEach(function (t) { techSection.appendChild(el('p', null, t.category + ' / ' + t.name + ' / ' + (t.version || 'Version not recorded'))); });
    if (!r.stack.length) { techSection.appendChild(el('p', 'pf-mute', 'No technology recorded')); }
    body.appendChild(techSection);
    var connections = el('section', 'pf-drawer-section');
    connections.appendChild(el('h3', null, 'Registered application connections'));
    var known = 0;
    (DATA.links || []).forEach(function (link) {
      if (link.src !== r.id && link.dst !== r.id) { return; }
      var otherId = link.src === r.id ? link.dst : link.src;
      var other = ROWS.find(function (a) { return a.id === otherId; });
      if (!other) { return; }
      known += 1;
      var line = el('div', 'pf-version-row');
      line.appendChild(el('span', null, link.bidir ? 'Both directions' : link.src === r.id ? 'Outbound to' : 'Inbound from'));
      line.appendChild(appButton(other));
      line.appendChild(el('span', 'pf-mute', other.tower + ' / ' + other.bc + ' / ' + (link.via || 'Connectivity not recorded')));
      connections.appendChild(line);
    });
    if (!known) { connections.appendChild(el('p', 'pf-mute', 'No registered application connections recorded.')); }
    body.appendChild(connections);
    var declarations = el('section', 'pf-drawer-section');
    declarations.appendChild(el('h3', null, 'Interface records declared by this application'));
    (r.interfaces || []).forEach(function (entry) {
      var detail = el('details', 'pf-version'); detail.appendChild(el('summary', null, entry.name));
      detail.appendChild(el('p', null, (entry.direction || 'Direction not recorded') + ' / ' + (entry.connectivity || 'Connectivity not recorded')));
      detail.appendChild(el('p', 'pf-mute', entry.resolved_app_id != null ? 'Matched to a registered application' : 'External or unresolved system'));
      if (entry.host) { detail.appendChild(el('p', null, 'Host: ' + entry.host)); }
      declarations.appendChild(detail);
    });
    if (!(r.interfaces || []).length) { declarations.appendChild(el('p', 'pf-mute', 'No interface records declared here. Connections can also be recorded by other applications.')); }
    body.appendChild(declarations);
    var standards = el('section', 'pf-drawer-section');
    standards.appendChild(el('h3', null, 'Standards evidence'));
    standards.appendChild(el('p', 'pf-mute', r.standards.answered + ' / ' + r.standards.total + ' controls answered; ' + r.standards.overdue + ' overdue.'));
    r.standards.findings.forEach(function (finding) {
      var item = el('details', 'pf-version');
      item.appendChild(el('summary', null, finding.name));
      item.appendChild(el('p', finding.overdue ? 'pf-overdue' : null, finding.status + (finding.due ? ' / Due ' + finding.due : '') + (finding.overdue ? ' / Overdue' : '')));
      standards.appendChild(item);
    });
    body.appendChild(standards);

    var foot = $('pfDrawerFoot');
    clear(foot);
    var open = el('a', 'btn btn-primary');
    open.href = url(CFG.appUrl, r.id);
    open.appendChild(el('i', 'fas fa-arrow-up-right-from-square'));
    open.appendChild(document.createTextNode(' Open record'));
    foot.appendChild(open);
    if ((CFG.editableTowers || []).indexOf(r.tower_id) !== -1) {
      var edit = el('a', 'btn');
      edit.href = url(CFG.editUrl, r.id);
      edit.appendChild(el('i', 'fas fa-pen'));
      edit.appendChild(document.createTextNode(' Edit'));
      foot.appendChild(edit);
      var tech = el('a', 'btn');
      tech.href = url(CFG.technicalUrl, r.id);
      tech.appendChild(el('i', 'fas fa-microchip'));
      tech.appendChild(document.createTextNode(' Technology'));
      foot.appendChild(tech);
    }
    $('pfScrim').hidden = false;
    var d = $('pfDrawer');
    d.classList.add('is-open');
    d.setAttribute('aria-hidden', 'false');
    d.focus();
  }
  function closeDrawer() {
    var d = $('pfDrawer');
    if (!d.classList.contains('is-open')) { return; }
    d.classList.remove('is-open');
    d.setAttribute('aria-hidden', 'true');
    $('pfScrim').hidden = true;
    if (lastFocus && lastFocus.focus) { lastFocus.focus(); }
  }

  /* ---- exports -------------------------------------------------------- */
  var CSV_COLUMNS = [
    ['S.No', null], ['Application ID', function (r) { return r.id; }],
    ['Application Name', function (r) { return r.name; }],
    ['Tower', function (r) { return r.tower; }],
    ['Business Capability', function (r) { return r.capability; }],
    ['Criticality', function (r) { return r.bc; }],
    ['Ownership Type', function (r) { return r.ownership; }],
    ['Vendor Name', function (r) { return r.vendors.join('; '); }],
    ['Technology / Tools', function (r) { return r.technologies.join('; '); }],
    ['Programming Languages', function (r) { return r.languages.join('; '); }],
    ['Recorded Interfaces', function (r) { return r.has_interface ? 'Yes' : 'No'; }],
    ['Interface Type', function (r) { return r.interface_type; }],
    ['Inbound Systems', function (r) { return r.inbound.join('; '); }],
    ['Outbound Systems', function (r) { return r.outbound.join('; '); }],
    ['Owner Team', function (r) { return r.owners.join('; '); }],
    ['Remarks', function (r) { return r.remarks; }],
    ['Created', function (r) { return r.created; }],
    ['Last Updated', function (r) { return r.updated; }]
  ];
  function csvCell(v) {
    var s = v === null || v === undefined ? '' : String(v);
    /* A leading = + - @ would run as a formula when the file is opened. */
    if (/^[=+\-@\t\r]/.test(s)) { s = "'" + s; }
    if (/[",\r\n]/.test(s)) { s = '"' + s.replace(/"/g, '""') + '"'; }
    return s;
  }
  function exportCsv() {
    var lines = [CSV_COLUMNS.map(function (c) { return csvCell(c[0]); }).join(',')];
    tableCache.forEach(function (r, i) {
      lines.push(CSV_COLUMNS.map(function (c) {
        return csvCell(c[1] ? c[1](r) : i + 1);
      }).join(','));
    });
    var blob = new Blob(['\ufeff' + lines.join('\r\n')], {type: 'text/csv;charset=utf-8'});
    var a = document.createElement('a');
    var stamp = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    a.href = URL.createObjectURL(blob);
    a.download = 'Application_Portfolio_' + stamp + '.csv';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 0);
  }
  function exportXlsx() {
    $('pfExportIds').value = tableCache.map(function (r) { return r.id; }).join(',');
    $('pfExportScope').value = scopeText();
    $('pfExportForm').submit();
  }

  /* ---- render --------------------------------------------------------- */
  function render() {
    var rows = filtered();
    document.querySelectorAll('[data-panel]').forEach(function (panel) { panel.hidden = panel.dataset.panel !== view; });
    $('pfContext').textContent = {overview: 'Live records by business coverage and criticality.', technology: 'Recorded technology and language adoption across the estate.', dependencies: 'Connection counts describe recorded data flows, not proven failure impact.', sourcing: 'Vendor-record inference; application counts do not measure spend or contractual exposure.', standards: 'Applicable controls, evidence coverage and dated remediation. Unknown is not compliant.'}[view];
    refreshFilterOptions();
    renderChips();
    $('pfCount').textContent = anyFilter()
      ? plural(rows.length, 'application') + ' of ' + ROWS.length
      : plural(ROWS.length, 'application') + ' \u00b7 ' + plural(DATA.masters.towers.length, 'tower');
    renderKpis(rows);
    renderCharts(rows);
    renderTable(rows);
  }

  function wire() {
    document.querySelectorAll('[data-view]').forEach(function (button) {
      button.addEventListener('click', function () {
        view = button.dataset.view;
        document.querySelectorAll('[data-view]').forEach(function (b) {
          b.classList.toggle('is-active', b === button); b.setAttribute('aria-pressed', String(b === button));
        });
        if (DATA) { render(); }
      });
    });
    var t = null;
    $('pfSearch').addEventListener('input', function (e) {
      clearTimeout(t);
      var v = e.target.value.trim();
      t = setTimeout(function () { state.search = v; state.page = 1; render(); }, 160);
    });
    var t2 = null;
    $('pfTableSearch').addEventListener('input', function (e) {
      clearTimeout(t2);
      var v = e.target.value.trim();
      t2 = setTimeout(function () { state.tableSearch = v; state.page = 1; renderTable(filtered()); }, 160);
    });
    $('pfReset').addEventListener('click', function () {
      state.filters = {};
      state.search = '';
      state.page = 1;
      $('pfSearch').value = '';
      render();
    });
    $('pfPageSize').addEventListener('change', function (e) {
      state.pageSize = parseInt(e.target.value, 10) || 25;
      state.page = 1;
      renderTable(filtered());
    });
    $('pfPrev').addEventListener('click', function () { state.page -= 1; renderTable(filtered()); });
    $('pfNext').addEventListener('click', function () { state.page += 1; renderTable(filtered()); });
    $('pfCsv').addEventListener('click', exportCsv);
    $('pfXlsx').addEventListener('click', exportXlsx);
    $('pfDrawerClose').addEventListener('click', closeDrawer);
    $('pfScrim').addEventListener('click', closeDrawer);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { closeDrawer(); } });
    /* Menus built on <details>: close on outside click / after choosing. */
    document.addEventListener('click', function (e) {
      document.querySelectorAll('.pf-menu[open]').forEach(function (m) {
        if (!m.contains(e.target)) { m.removeAttribute('open'); }
      });
    });
    var resizeT = null;
    window.addEventListener('resize', function () {
      clearTimeout(resizeT);
      resizeT = setTimeout(function () { if (DATA) { renderCharts(filtered()); } }, 200);
    });
  }

  function boot() {
    try {
      var saved = JSON.parse(storeGet(COL_STORE) || 'null');
      if (saved && typeof saved === 'object') { state.hidden = saved; }
      else { COLUMNS.forEach(function (c) { if (c.hide) { state.hidden[c.key] = true; } }); }
    } catch (e) {
      COLUMNS.forEach(function (c) { if (c.hide) { state.hidden[c.key] = true; } });
    }
    /* The drawer lives at <body> level inside its own .pf wrapper: an
       ancestor with a transform turns position:fixed into position:absolute
       and the site header then covers the drawer's title. */
    var portal = el('div', 'pf pf-portal');
    portal.appendChild($('pfScrim'));
    portal.appendChild($('pfDrawer'));
    document.body.appendChild(portal);
    buildFilterControls();
    buildColumnMenu();
    wire();
    fetch(CFG.dataUrl, {credentials: 'same-origin', cache: 'no-store'})
      .then(function (r) {
        if (!r.ok) { throw new Error('Request failed (' + r.status + ')'); }
        return r.json();
      })
      .then(function (data) {
        DATA = data;
        ROWS = (data.apps || []).map(function (r) {
          prepareRow(r);
          r.iface_yn = r.has_interface ? 'Yes' : 'No';
          return r;
        });
        buildNeighbours();
        render();
      })
      .catch(function (err) {
        $('pfCount').textContent = 'Could not load the portfolio: ' + err.message + '. Refresh to try again.';
        ['cTower', 'cOwn', 'cTech', 'cLang', 'cIf', 'cIfType', 'cTowerOwn', 'cHeat'].forEach(function (id) {
          empty($(id), 'The portfolio could not be loaded.');
        });
      });
  }

  boot();
}());
