"""
portfolio.py - the Portfolio dashboard's view of the application estate.

One row per active application, carrying everything the dashboard filters,
charts and tables on: tower, business capability, ownership type, technology
and languages, inbound / outbound systems, owner, remarks.

Deliberately NOT a second inventory. Every figure is read from the records
the rest of the module already keeps, so the dashboard can never disagree
with the application pages or the two architecture diagrams:

  Tower                 AppSupportTower
  Business capability   ApplicationCategory (the business area)
  Ownership type        VendorDetails - a non-bespoke vendor row makes an
                        application Base COTS, a bespoke-only one In-house
  Technology / tools    ApplicationTechStack rows in 'tool' and 'database'
  Languages             ApplicationTechStack rows in 'language'
  Inbound / outbound    the RESOLVED connections from
                        architecture.build_estate_graph, so an interface the
                        OTHER application recorded counts too, and one
                        connection recorded twice counts once
  Owner team            SupportTeam rows with the Primary Owner role
  Remarks               ApplicationDetails.remarks

Nothing is guessed: a field with no record reads "Not recorded" and is
counted as such, so a gap in the data shows up as a gap on the chart.

The aggregation (KPIs, charts, the heatmap) is done in the browser over these
rows, because every filter has to re-drive all of it instantly; this module
only has to get the rows right. It also builds the Excel export and holds the
value lists the application form validates against.
"""

import io
from datetime import datetime, timezone

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from sqlalchemy import true as sql_true

from . import categories, tech_details
from .architecture import build_estate_graph
from .models import (
    AppSupportTower, ApplicationDetails, FlowDirection, InterfaceSystem,
    TechCatalog, ApplicationTechStack, ApplicationStandardCompliance,
    StandardChecklistItem,
)

# ---------------------------------------------------------------------------
# Value lists
# ---------------------------------------------------------------------------

OWNERSHIP_COTS = 'Base COTS'
OWNERSHIP_BESPOKE = 'In-house / Bespoke'
OWNERSHIP_UNKNOWN = 'Not recorded'
OWNERSHIP_TYPES = (OWNERSHIP_COTS, OWNERSHIP_BESPOKE, OWNERSHIP_UNKNOWN)

IFACE_INBOUND = 'Inbound'
IFACE_OUTBOUND = 'Outbound'
IFACE_BOTH = 'Both'
IFACE_NONE = 'None'
INTERFACE_TYPES = (IFACE_INBOUND, IFACE_OUTBOUND, IFACE_BOTH, IFACE_NONE)

#: Tech-stack categories the dashboard calls "Technology / Tools". Operating
#: systems are a platform, not a tool, and stay on the Technical Details tab.
TOOL_CATEGORIES = ('tool', 'database')
LANGUAGE_CATEGORY = 'language'

CAPABILITY_UNSET = 'Uncategorised'
REMARKS_MAX = 4000


def clean_remarks(value):
    text = (value or '').strip()
    return text[:REMARKS_MAX]


def ownership_of(vendors):
    """Ownership type from an application's vendor rows (graph payload shape:
    [{'name', 'bespoke'}]). Any non-bespoke vendor makes it a vendor product;
    a record that only says "bespoke" is in-house; no rows is unknown."""
    named = [v for v in (vendors or []) if (v.get('name') or '').strip()]
    if any(not v.get('bespoke') for v in named):
        return OWNERSHIP_COTS
    if named:
        return OWNERSHIP_BESPOKE
    return OWNERSHIP_UNKNOWN


def interface_type(inbound, outbound):
    if inbound and outbound:
        return IFACE_BOTH
    if inbound:
        return IFACE_INBOUND
    if outbound:
        return IFACE_OUTBOUND
    return IFACE_NONE


def interface_systems_by_app(graph):
    """{app_id: {'inbound': set(names), 'outbound': set(names)}}.

    Read off the resolved graph rather than the raw interface rows: a link
    between two applications is recorded once however many rows declare it,
    and it appears on BOTH ends - Billing feeds Ledger shows as outbound on
    Billing and inbound on Ledger even if only Billing's owner recorded it.
    """
    names = dict((a['id'], a['name']) for a in graph.get('apps') or [])
    out = dict((app_id, {'inbound': set(), 'outbound': set()})
               for app_id in names)

    def add(app_id, side, name):
        if app_id in out and name:
            out[app_id][side].add(name)

    for link in graph.get('links') or []:
        src, dst = link.get('src_app'), link.get('dst_app')
        add(src, 'outbound', names.get(dst))
        add(dst, 'inbound', names.get(src))
        if link.get('bidir'):
            add(src, 'inbound', names.get(dst))
            add(dst, 'outbound', names.get(src))

    for ext in graph.get('externals') or []:
        label = (ext.get('name') or '').strip()
        for edge in ext.get('links') or []:
            direction = edge.get('direction')
            if direction in (FlowDirection.INBOUND.value,
                             FlowDirection.BIDIRECTIONAL.value):
                add(edge.get('app'), 'inbound', label)
            if direction in (FlowDirection.OUTBOUND.value,
                             FlowDirection.BIDIRECTIONAL.value):
                add(edge.get('app'), 'outbound', label)
    return out


def _sorted_unique(values):
    seen, out = set(), []
    for value in values:
        key = tech_details.match_key(value)
        if value and key not in seen:
            seen.add(key)
            out.append(value)
    return sorted(out, key=lambda v: v.lower())


def _iso(value):
    return value.strftime('%Y-%m-%d') if value else ''


# ---------------------------------------------------------------------------
# The rows
# ---------------------------------------------------------------------------

def build_rows(graph, extras):
    """The dashboard rows from a graph document plus the per-application
    fields the graph does not carry (``extras``: {app_id: {remarks,
    created, updated}}). Pure - tested without a database."""
    tower_names = dict((t['id'], t['name']) for t in graph.get('towers') or [])
    systems = interface_systems_by_app(graph)
    rows = []
    for app in graph.get('apps') or []:
        tech = app.get('tech') or []
        tools = _sorted_unique(t['name'] for t in tech
                               if t.get('category') in TOOL_CATEGORIES)
        langs = _sorted_unique(t['name'] for t in tech
                               if t.get('category') == LANGUAGE_CATEGORY)
        side = systems.get(app['id'], {'inbound': set(), 'outbound': set()})
        inbound = sorted(side['inbound'], key=str.lower)
        outbound = sorted(side['outbound'], key=str.lower)
        owners = _sorted_unique(
            (m.get('name') or '').strip() for m in app.get('support') or []
            if m.get('role') == 'Primary Owner')
        vendors = _sorted_unique(
            (v.get('name') or '').strip() for v in app.get('vendors') or []
            if not v.get('bespoke'))
        extra = extras.get(app['id'], {})
        itype = interface_type(inbound, outbound)
        rows.append({
            'id': app['id'],
            'name': app['name'],
            'tower_id': app.get('tower_id'),
            'tower': tower_names.get(app.get('tower_id'), ''),
            'capability': (app.get('category') or '').strip() or CAPABILITY_UNSET,
            'bc': app.get('bc') or '',
            'ownership': ownership_of(app.get('vendors')),
            'vendors': vendors,
            'technologies': tools,
            'languages': langs,
            'has_interface': itype != IFACE_NONE,
            'interface_type': itype,
            'inbound': inbound,
            'outbound': outbound,
            'owners': owners,
            'remarks': extra.get('remarks') or '',
            'summary': app.get('summary') or '',
            'created': extra.get('created') or '',
            'updated': extra.get('updated') or '',
            'stack': tech,
            'interfaces': app.get('interfaces') or [],
        })
    rows.sort(key=lambda r: (r['tower'].lower(), r['name'].lower()))
    return rows


def build_links(graph):
    """Application-to-application connections for the inter-tower matrix.

    One entry per RESOLVED link in the graph - the same lines the diagrams
    draw, so a connection recorded by both owners counts once. ``bidir``
    links carry data both ways and are counted in both directions by the
    page. External systems are not here: they belong to no tower.
    """
    names = dict((a['id'], a['name']) for a in graph.get('apps') or [])
    out = []
    for link in graph.get('links') or []:
        src, dst = link.get('src_app'), link.get('dst_app')
        if src not in names or dst not in names:
            continue
        out.append({'src': src, 'dst': dst, 'bidir': bool(link.get('bidir')),
                    'via': (link.get('connectivity') or '').strip()})
    return out


def _load_extras(db_session):
    extras = {}
    for app in (db_session.query(ApplicationDetails)
                .filter(ApplicationDetails.is_active == sql_true()).all()):
        extras[app.id] = {
            'remarks': app.remarks or '',
            'created': _iso(app.created_at),
            'updated': _iso(app.updated_at or app.created_at),
        }
    return extras


def _catalog_names(db_session, cats):
    rows = (db_session.query(TechCatalog)
            .filter(TechCatalog.category.in_(cats),
                    TechCatalog.is_active == sql_true())
            .all())
    return [r.name for r in rows]


def interface_system_names(db_session, include_inactive=False):
    query = db_session.query(InterfaceSystem)
    if not include_inactive:
        query = query.filter(InterfaceSystem.is_active == sql_true())
    return sorted((r.name for r in query.all()), key=lambda n: n.lower())


def standards_for_app(stack, items, answers, today):
    """Only applicable, active controls count; missing answers remain visible."""
    scopes = tech_details.active_scope_keys(stack)
    applicable = [item for item in items if item.is_active and
                  tech_details.scope_key(item.scope, item.catalog_id) in scopes]
    counts = dict((status, 0) for status in tech_details.STATUSES)
    overdue = 0
    findings = []
    for item in applicable:
        answer = answers.get(item.id)
        status = (answer.status if answer and answer.status in counts
                  else 'Unanswered')
        if status in counts:
            counts[status] += 1
        late = bool(answer and status in tech_details.DATE_STATUSES and
                    answer.end_date and answer.end_date < today)
        overdue += int(late)
        findings.append({'name': item.name, 'status': status,
                         'due': _iso(answer.end_date) if answer else '',
                         'overdue': late})
    answered = sum(counts.values())
    return {'total': len(applicable), 'answered': answered,
            'unanswered': len(applicable) - answered, 'counts': counts,
            'overdue': overdue, 'findings': findings}


def load_standards(db_session, rows):
    """Batch load the same checklist scope rules used by Technical Details."""
    stacks, answers = {}, {}
    ids = set(row['id'] for row in rows)
    for entry in db_session.query(ApplicationTechStack).all():
        if entry.application_id in ids:
            stacks.setdefault(entry.application_id, []).append(entry)
    for entry in db_session.query(ApplicationStandardCompliance).all():
        if entry.application_id in ids:
            answers.setdefault(entry.application_id, {})[entry.checklist_id] = entry
    items = (db_session.query(StandardChecklistItem)
             .filter(StandardChecklistItem.is_active == sql_true())
             .order_by(StandardChecklistItem.sort_order, StandardChecklistItem.id).all())
    today = datetime.now(timezone.utc).date()
    for row in rows:
        row['standards'] = standards_for_app(
            stacks.get(row['id'], []), items, answers.get(row['id'], {}), today)


def build_portfolio(db_session):
    """The whole JSON document the dashboard page loads.

    ``masters`` are the filter option lists. Each is the admin-maintained
    list UNIONED with whatever the estate actually records, so a tower with
    no applications still appears as a filter value (and as a zero on the
    tower chart), and a retired catalog entry an application still records
    is still filterable.
    """
    graph = build_estate_graph(db_session)
    rows = build_rows(graph, _load_extras(db_session))
    load_standards(db_session, rows)

    towers = [{'id': t.id, 'name': t.tower_name} for t in
              (db_session.query(AppSupportTower)
               .filter(AppSupportTower.is_active == sql_true())
               .order_by(AppSupportTower.tower_name).all())]

    categories.ensure_seeded(db_session)
    capabilities = _sorted_unique(
        [c.name for c in categories.list_categories(db_session)]
        + [r['capability'] for r in rows if r['capability'] != CAPABILITY_UNSET])
    if any(r['capability'] == CAPABILITY_UNSET for r in rows):
        capabilities.append(CAPABILITY_UNSET)

    technologies = _sorted_unique(
        _catalog_names(db_session, TOOL_CATEGORIES)
        + [t for r in rows for t in r['technologies']])
    languages = _sorted_unique(
        _catalog_names(db_session, (LANGUAGE_CATEGORY,))
        + [t for r in rows for t in r['languages']])
    systems = _sorted_unique(
        interface_system_names(db_session)
        + [s for r in rows for s in r['inbound'] + r['outbound']])

    return {
        'generated_at': datetime.now(timezone.utc).strftime(
            '%Y-%m-%dT%H:%M:%SZ'),
        'apps': rows,
        'links': build_links(graph),
        'masters': {
            'towers': towers,
            'capabilities': capabilities,
            'ownership': list(OWNERSHIP_TYPES),
            'technologies': technologies,
            'languages': languages,
            'interface_types': list(INTERFACE_TYPES),
            'systems': systems,
        },
    }


# ---------------------------------------------------------------------------
# Excel export
# ---------------------------------------------------------------------------

EXPORT_COLUMNS = (
    ('S.No', 6), ('Application ID', 12), ('Application Name', 30),
    ('Tower', 18), ('Business Capability', 22), ('Criticality', 11),
    ('Ownership Type', 18), ('Vendor Name', 22), ('Technology / Tools', 34),
    ('Programming Languages', 24), ('Recorded Interfaces', 12),
    ('Interface Type', 13), ('Inbound Systems', 30), ('Outbound Systems', 30),
    ('Owner Team', 24), ('Remarks', 40),
    ('Created', 12), ('Last Updated', 12),
)

_BRAND = 'AB1236'
_BRAND_DK = '7E0D27'
_THIN = Side(style='thin', color='D3DBE7')
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)
_FORMULA_LEADS = ('=', '+', '-', '@', chr(9), chr(13))


def safe_cell(value):
    """A value made safe to put in a spreadsheet cell.

    Record text is typed by users, and a cell that starts with '=' (or +, -,
    @) is executed as a formula when the workbook is opened - a leading
    apostrophe keeps it text. Numbers are passed through untouched.
    """
    if isinstance(value, (int, float)):
        return value
    text = '' if value is None else str(value)
    if text[:1] in _FORMULA_LEADS:
        return "'" + text
    return text


def export_values(row, index):
    join = '; '.join
    return [
        index, row['id'], row['name'], row['tower'], row['capability'],
        row['bc'], row['ownership'], join(row['vendors']),
        join(row['technologies']), join(row['languages']),
        'Yes' if row['has_interface'] else 'No', row['interface_type'],
        join(row['inbound']), join(row['outbound']), join(row['owners']),
        row['remarks'], row['created'], row['updated'],
    ]


def build_workbook(rows, generated_by, scope_note=''):
    """The inventory table as an .xlsx, one row per application, in the
    order given (the page sends its current sort)."""
    wb = Workbook()
    ws = wb.active
    ws.title = 'Application Portfolio'
    ws.sheet_view.showGridLines = False
    ncols = len(EXPORT_COLUMNS)
    for idx, (_, width) in enumerate(EXPORT_COLUMNS, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width

    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    title = ws.cell(row=1, column=1, value='Application Portfolio')
    title.font = Font(name='Calibri', size=15, bold=True, color='FFFFFF')
    title.fill = PatternFill('solid', fgColor=_BRAND)
    title.alignment = Alignment(vertical='center', indent=1)
    ws.row_dimensions[1].height = 28

    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
    note = '{0} application(s){1} - generated {2} by {3}'.format(
        len(rows), (' - ' + scope_note) if scope_note else '',
        datetime.now().strftime('%d %b %Y %H:%M'), generated_by or '-')
    sub = ws.cell(row=2, column=1, value=safe_cell(note))
    sub.font = Font(name='Calibri', size=10, italic=True, color='FFFFFF')
    sub.fill = PatternFill('solid', fgColor=_BRAND_DK)
    sub.alignment = Alignment(vertical='center', indent=1)

    header_row = 4
    for col, (label, _) in enumerate(EXPORT_COLUMNS, start=1):
        cell = ws.cell(row=header_row, column=col, value=label)
        cell.font = Font(name='Calibri', size=10, bold=True, color='FFFFFF')
        cell.fill = PatternFill('solid', fgColor=_BRAND_DK)
        cell.alignment = Alignment(horizontal='center', vertical='center',
                                   wrap_text=True)
        cell.border = _BORDER
    ws.row_dimensions[header_row].height = 30

    band = PatternFill('solid', fgColor='F4F7FB')
    for i, row in enumerate(rows, start=1):
        r = header_row + i
        for col, value in enumerate(export_values(row, i), start=1):
            cell = ws.cell(row=r, column=col, value=safe_cell(value))
            cell.font = Font(name='Calibri', size=10, color='0F1626')
            cell.alignment = Alignment(vertical='top', wrap_text=True)
            cell.border = _BORDER
            if i % 2 == 0:
                cell.fill = band
    ws.freeze_panes = ws.cell(row=header_row + 1, column=4)
    if rows:
        ws.auto_filter.ref = 'A{0}:{1}{2}'.format(
            header_row, get_column_letter(ncols), header_row + len(rows))

    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()
