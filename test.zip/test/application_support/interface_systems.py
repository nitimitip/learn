"""
interface_systems.py - the admin-maintained list of interface system names.

The External Interfaces section of an application record names the system at
the other end of each interface in a free-text field. Free text drifts
("ServiceNow", "Service Now", "SNOW"), and every drifted spelling becomes a
separate system on the Portfolio dashboard and the architecture diagrams.
This list is what the field SUGGESTS, so people pick the agreed spelling.

It is a suggestion list, not a foreign key: interface rows keep storing the
name as text (older rows, and systems nobody has listed yet, must keep
working). So deleting or retiring an entry never changes a record - it only
stops the name being offered. "In use" is counted by name, ignoring capitals
and spacing, the same way the rest of the module matches names.
"""

from sqlalchemy import true as sql_true

from . import tech_details
from .models import ApplicationDetails, ExternalInterfaces, InterfaceSystem

NAME_MAX = 150


def clean_name(value):
    return ' '.join((value or '').split())


def clean_description(value):
    return (value or '').strip() or None


def validate_name(value):
    """(name, error)."""
    name = clean_name(value)
    if not name:
        return None, 'Enter a system name.'
    if len(name) > NAME_MAX:
        return None, 'System names are limited to {0} characters.'.format(
            NAME_MAX)
    return name, None


def list_systems(db_session, include_inactive=False):
    query = db_session.query(InterfaceSystem)
    if not include_inactive:
        query = query.filter(InterfaceSystem.is_active == sql_true())
    return sorted(query.all(), key=lambda r: (not r.is_active, r.name.lower()))


def get_system(db_session, system_id):
    return db_session.query(InterfaceSystem).filter_by(id=system_id).first()


def find_by_name(db_session, name, exclude_id=None):
    key = tech_details.match_key(name)
    for row in db_session.query(InterfaceSystem).all():
        if row.id != exclude_id and tech_details.match_key(row.name) == key:
            return row
    return None


def usage_counts(db_session):
    """{match_key(name): number of interface rows naming it} over the
    interface rows of active applications."""
    counts = {}
    rows = (db_session.query(ExternalInterfaces.interface_name)
            .join(ApplicationDetails,
                  ApplicationDetails.id == ExternalInterfaces.application_id)
            .filter(ApplicationDetails.is_active == sql_true())
            .all())
    for (name,) in rows:
        key = tech_details.match_key(name)
        if key:
            counts[key] = counts.get(key, 0) + 1
    return counts


def unlisted_names(db_session, limit=40):
    """Interface names the estate records that the list does not hold yet,
    most used first - the admin screen offers them for one-click adding."""
    listed = set(tech_details.match_key(r.name)
                 for r in db_session.query(InterfaceSystem).all())
    seen = {}
    rows = (db_session.query(ExternalInterfaces.interface_name)
            .join(ApplicationDetails,
                  ApplicationDetails.id == ExternalInterfaces.application_id)
            .filter(ApplicationDetails.is_active == sql_true())
            .all())
    for (name,) in rows:
        clean = clean_name(name)
        key = tech_details.match_key(clean)
        if not key or key in listed:
            continue
        entry = seen.setdefault(key, [clean, 0])
        entry[1] += 1
    ranked = sorted(seen.values(), key=lambda e: (-e[1], e[0].lower()))
    return [{'name': n, 'count': c} for n, c in ranked[:limit]]


def suggestion_names(db_session):
    """What the Interface Name field offers: the active list plus every
    active application's name (an interface to another application in the
    estate is the most common kind)."""
    names = [r.name for r in list_systems(db_session)]
    names += [a.application_name for a in
              db_session.query(ApplicationDetails)
              .filter(ApplicationDetails.is_active == sql_true()).all()
              if a.application_name]
    seen, out = set(), []
    for name in names:
        key = tech_details.match_key(name)
        if key and key not in seen:
            seen.add(key)
            out.append(name)
    return sorted(out, key=lambda n: n.lower())
