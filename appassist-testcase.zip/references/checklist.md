# Checklist  (Run Before Giving The File)

```text

  CONTENT
  [ ] Every document was read in full; each requirement has an analysis
      note (actors, entry point, inputs, rules, states, outputs, gaps)
      in the working script.
  [ ] Every fact traces to a document or a user answer; nothing invented.
      Gaps say "To be confirmed - Q-nn" and have a Clarifications row.
  [ ] Each document (or section of a combined document) went to the right
      sheet per document-guide.md; the user confirmed the map.
  [ ] Every requirement is in the RTM and has at least one test case;
      no requirement shows "Not Covered" unless it is explained to the
      user.
  [ ] Every requirement with a rule has Positive AND Negative cases; every
      stated limit has Boundary cases.

  QUALITY  (quality-standard.md)
  [ ] Every title names the behaviour and the condition with the real
      field, value, role or state - no Req ID, no "verify requirement".
  [ ] Preconditions name the role and the data / state THIS case needs.
  [ ] Steps use the document's screen, field and button names and this
      case's exact value; one action per step.
  [ ] Test data gives this case's values (or data condition) and why.
  [ ] Expected results are observable and specific to the condition;
      message text quoted exactly; negative cases say what does not
      change.
  [ ] Swap test passes: no two cases share a title, steps or expected
      result; preconditions and test data are not one text for the sheet.
  [ ] No real passwords, keys, tokens or personal data in test data.

  WORKBOOK
  [ ] Every case has exactly one Req ID that exists in the RTM.
  [ ] TC IDs sequential per sheet (TC-UAT-001, TC-ST-001, TC-SIT-001), no
      duplicates, no gaps.
  [ ] Type, Category, Priority values are exactly from the workbook-layout.md lists.
  [ ] Execution columns empty; Status "Not Run".
  [ ] Builder set up per builder-code.md (found, or installed with HASH
      OK and SELFTEST OK) - no self-written workbook code, no
      "framework" / "structure" / partial workbook, no disclaimer that
      the pack is incomplete.
  [ ] Every requirement in the document has test cases (or a stated
      not_testable reason the user was told about).
  [ ] Workbook built with scripts/appassist_testcase.py: RESULT OK, no
      ERROR; project details only as given by the user; file named
      <Project_Name>_Test_Cases.xlsx.

  CHAT
  [ ] The first reply came AFTER reading the document, in the
      conversation-guide.md shape: what was found, at most 8 plain
      questions, optional project details, "or just say 'go ahead'".
  [ ] Every doubt was asked (in batches of at most 8); none was settled
      by assumption; doubts found while writing were asked before the
      build. Unanswered points are "To be confirmed" only because the
      user chose to proceed.
  [ ] Nothing was asked that the document already answers; no question
      was asked twice; no unexplained test jargon.
  [ ] No test case was written out in chat - the Excel file is the
      deliverable.
  [ ] Closing message: the file, counts per sheet, positive / negative /
      boundary split, requirements covered, open clarifications.
```
