# Quality Standard  (Write Like A Principal Tester With 30 Years' Experience)

```text

A test case is only useful if a tester who has NEVER read the document
can run it, and two testers running it get the same Pass / Fail. Generic
cases ("verify requirement", "open related screen", "system behaves as per
specification") fail that test and are refused by the checker.

1. READ THE DOCUMENT LIKE AN EXPERT  (before writing any case)
------------------------------------------------------------------------
  Read every page end to end: body text, tables (field lists, role
  matrices, status tables, message lists), numbered and bulleted lists,
  notes, assumptions, constraints, appendices, glossary, diagram
  captions and the version history. Rules for one requirement are often
  in a table or an appendix far from it - find them.
  Build the requirement inventory first: every requirement ID (or
  numbered section when there are no IDs) with a one-line summary.
  Count it; the workbook will cover every one.
  Then go requirement by requirement. For EACH write a test-analysis
  note in your working script as Python comments (never in chat):

    Actors        who does it - the role names the document uses; who
                  must NOT be able to do it
    Entry point   screen / menu / button / API / batch job, by the
                  document's own names
    Inputs        every field: type, mandatory / optional, format,
                  length, range, list values, default
    Rules         every condition, calculation and dependency; rules
                  with 2+ conditions -> decision table
    States        state before, state after, transitions not allowed
    Outputs       what is shown, saved, sent, generated, logged,
                  notified, and to whom; message text word for word
    Links         other requirements, interfaces, master data, time
                  (cut-off, schedule, today / past / future dates)
    Gaps          anything a tester needs that the document does not
                  say -> a clarification question (never an assumption)

  Then turn the note into TEST CONDITIONS: one per valid class, invalid
  class, stated limit (on / below / above), rule combination, allowed
  and blocked state change, allowed and blocked role, interface
  success / failure / timeout. Each condition becomes ONE test case.

  Look also where experienced testers find defects - but only write a
  case when the document gives the expected behaviour; otherwise ask:
    - resubmission / double click / duplicate record
    - the same action by a second user or on a stale record
    - data kept after save, refresh, sign-out and sign-in
    - a blocked role reaching the action another way (direct link,
      another menu)
    - what must NOT change in a negative case (record, status, email,
      balance)
    - dates: today, past, future, month-end, leap day - only if dates
      are in the requirement
    - empty list / first record / maximum records - only if stated

1A. WHEN A QUESTION STAYS UNANSWERED
------------------------------------------------------------------------
  A case is written only from stated facts and the user's answers.
  - If Pass / Fail of a test depends on the unanswered point, the test
    is LEFT OUT: add it to that clarification's "dropped" list (a short
    test title) and tell the user. Never write it with "To be
    confirmed", "TBC", an assumed value or a Q-nn reference.
  - If only a detail is unknown but the stated facts still give a
    clear Pass / Fail, write the case on those facts alone and leave
    the unknown detail out of it. Example: the field is mandatory but
    the message text is not given -> write "the request is not saved
    and no request reaches the manager"; list "message text for blank
    Start Date" under the question.
  - An expert chooses test data that does not depend on the open
    point. Example: weekend counting is unclear -> test the balance
    limit with Monday-Friday dates in one week (same count under any
    rule) and list "request spanning a weekend" as left out.
  - If every test of a requirement depends on unanswered points, the
    requirement carries "dropped": "Q-nn" and shows "Dropped" in the
    RTM.

2. WHAT EVERY COLUMN MUST CARRY
------------------------------------------------------------------------
  Title          the behaviour AND the condition, with the real field,
                 value, role or state:  "Verify the customer is not
                 saved when Email has no @ sign".  Never the Req ID,
                 never "verify requirement", never two conditions.
  Preconditions  the role by its document name, the data that must
                 exist and its state, the starting screen / system
                 state.  Different cases need different data - so the
                 preconditions differ too.
  Test Steps     the document's own screen, field, button and menu
                 names; the exact value typed in THIS case; one action
                 per step; the last action is the one under test; add a
                 check step when the result is somewhere else (open the
                 record, check the mailbox, read the audit log).
  Test Data      the exact values for THIS case and why:
                 "Email = anna.example.com (no @ sign)",
                 "Quantity = 101 (maximum 100 + 1)".
                 No value in the document -> the data condition for THIS
                 case: "Customer record in status Closed (test data team
                 to provide)".
  Expected       what the tester will see or find, specific to THIS
                 condition: message text in quotes and where it shows,
                 what is saved / not saved, status before -> after,
                 field values stored, who gets which email, and for a
                 negative case what does NOT change.

  The swap test: if the Expected Result (or Steps, or Data) of two cases
  could be swapped and nobody would notice, both are too generic.

3. REFUSED BY THE CHECKER  (and by build_workbook itself)
------------------------------------------------------------------------
  - "Verify / validate requirement ...", or a Req ID in the title
  - "mandatory / invalid", "valid / invalid" - two conditions in one case
  - "user logged in with valid role / appropriate access"
  - "open related / relevant screen", "perform action", "submit and
    observe", "observe result", "with test data", "enter details"
  - "requirement based data"
  - "as per specification / requirement", "as expected", "works
    correctly", "appropriate / proper / correct message"
  - "same as above", "similar to TC-...", "refer to the document"
  - TBD, TBA, N/A, etc.
  - "To be confirmed", TBC, "pending clarification", "assume / assumed"
    and any Q-nn that is not answered - leave such a test out instead
    (section 1A)
  - the same Title, Test Steps or Expected Result in two cases; the
    same Preconditions or Test Data on more than half the cases of a
    sheet
  - a title under 5 words, an expected result under 6 words, fewer than
    2 steps

4. BAD -> GOOD  (fictional requirement, style only)
------------------------------------------------------------------------
  FRS: "FR-12 Create Customer. Only a Sales Executive can create a
  customer. Email is mandatory, max 100 characters, must contain @.
  Message: 'Enter a valid email address.' On save the status is Active."

  BAD (refused):
    Title     Validate mandatory / invalid handling for FR-12
    Pre       User logged in with valid role
    Steps     1. Open related screen 2. Perform action with test data
              3. Submit and observe result
    Data      Requirement based data
    Expected  System behaves as per specification

  GOOD - one condition each:
    TC-ST-031 | FR-12 | Customer Maintenance
      Title     Verify the customer is not saved when Email has no @ sign
      Type / Category / Priority   Negative / Field Validation / High
      Pre       Signed in as a Sales Executive; Create Customer screen
                open with all other mandatory fields filled
      Steps     1. Enter Email "anna.example.com".
                2. Select Save.
                3. Search Customers for "anna.example.com".
      Data      Email = anna.example.com (no @ sign)
      Expected  The message "Enter a valid email address." is shown
                against Email; no customer is created (search returns
                no result).
    TC-ST-032 | FR-12 | Customer Maintenance
      Title     Verify a 100-character Email is accepted and stored in full
      Type / Category / Priority   Boundary / Field Validation / Medium
      Pre       Signed in as a Sales Executive; no customer exists with
                the prepared Email
      Steps     1. Open Customers > Create Customer.
                2. Fill the other mandatory fields.
                3. Enter the prepared 100-character Email.
                4. Select Save.
                5. Open the new customer record.
      Data      Email = 100 characters including one @ (stated maximum)
      Expected  The customer is saved with status Active; the record
                shows all 100 characters of Email unchanged.
    TC-ST-033 | FR-12 | Customer Maintenance
      Title     Verify a Service Agent cannot create a customer
      Type / Category / Priority   Negative / Access / Security / Critical
      Pre       Service Agent account (test data team to provide)
      Steps     1. Sign in as the Service Agent.
                2. Open the Customers menu.
                3. Look for Create Customer.
      Data      Role = Service Agent (not Sales Executive)
      Expected  Create Customer is not offered in the Customers menu;
                no customer can be created by this role.
      (Left out: "Service Agent opens the Create Customer link
      directly" - the document does not say what happens; listed
      under Q-04 until answered.)

5. SELF-REVIEW  (before calling build)
------------------------------------------------------------------------
  [ ] Read each case as a new tester: could you run it without the
      document and know, without asking anyone, whether it passed?
  [ ] Every value, name and message traces to the document or to a user
      answer; a test that would need anything else is left out and
      listed under its question.
  [ ] Every requirement in the inventory has cases, or is "dropped" /
      "not_testable" with the reason told to the user.
  [ ] Every test condition from the analysis notes has a case; no case
      tests two conditions; no two cases test the same condition.
  [ ] The swap test passes for every pair of cases on a sheet.
```
