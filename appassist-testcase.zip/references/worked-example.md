# Worked Example  (Fictional - Style Only, Never Copy Its Content)

The requirement text below is invented. It shows the path from document
to analysis note to test cases to the spec passed to `build()`.

## 1. Requirement as written in the document

```text
FR-01 Leave request form (Requirements Specification v1.0, s2.1)
  Leave Type   mandatory, list: Annual, Sick, Unpaid.
               Message: "Select a leave type."
  Start Date   mandatory, cannot be in the past.
               Message: "Start date cannot be in the past."
  End Date     mandatory, on or after Start Date.
               Message: "End date must be on or after the start date."
  Reason       optional, max 250 characters.
               Message: "Reason cannot exceed 250 characters."
  On Submit the request is saved with status Submitted.
```

## 2. Analysis note (in the working script, never in chat)

```python
# FR-01 Leave request form
# Actors     : Employee (raises). Not stated who else can open the form.
# Entry      : leave request form -> Submit
# Inputs     : Leave Type (mandatory, list of 3); Start Date (mandatory,
#              >= today); End Date (mandatory, >= Start Date); Reason
#              (optional, <= 250 chars)
# States     : none -> Submitted
# Outputs    : 4 message texts given; status Submitted
# Conditions : all valid (P) | each list value (P) | Leave Type blank (N)
#              | Start = today (B) | Start = yesterday (B) | Start blank (N)
#              | End = Start (B) | End = Start - 1 (B) | End blank (N)
#              | Reason 250 (B) | Reason 251 (B)
# Gaps       : no message text for blank Start / End Date -> Q-05
```

## 3. Cases in the spec (three of the eleven)

```python
{"id": "TC-ST-003", "req": "FR-01", "module": "Leave Request Form",
 "title": "Verify submission is rejected when Leave Type is not selected",
 "type": "Negative", "category": "Field Validation", "priority": "High",
 "pre": "Active employee account (test data team to provide); the leave "
        "request form opens with Leave Type empty.",
 "steps": ["Sign in as the employee.", "Open the leave request form.",
           "Leave Leave Type empty.", "Enter valid future Start and End Dates.",
           "Select Submit."],
 "data": "Leave Type = blank; Start / End Date = valid future dates",
 "expected": "The request is not saved; the message \"Select a leave type.\" "
             "is shown against Leave Type."},

{"id": "TC-ST-005", "req": "FR-01", "module": "Leave Request Form",
 "title": "Verify Start Date of yesterday is rejected",
 "type": "Boundary", "category": "Field Validation", "priority": "High",
 "pre": "Active employee account (test data team to provide); the system "
        "date is known so that yesterday can be entered.",
 "steps": ["Sign in as the employee.", "Open the leave request form.",
           "Select Leave Type Sick.", "Enter Start Date = yesterday.",
           "Enter End Date = today.", "Select Submit."],
 "data": "Start Date = today minus 1 day (just outside 'not in the past')",
 "expected": "The request is not saved; the message \"Start date cannot be in "
             "the past.\" is shown."},

{"id": "TC-ST-006", "req": "FR-01", "module": "Leave Request Form",
 "title": "Verify submission is rejected when Start Date is blank",
 "type": "Negative", "category": "Field Validation", "priority": "High",
 "pre": "Active employee account (test data team to provide); the leave "
        "request form opens with Start Date empty.",
 "steps": ["Sign in as the employee.", "Open the leave request form.",
           "Select Leave Type Annual.", "Leave Start Date blank.",
           "Enter a future End Date.", "Select Submit."],
 "data": "Start Date = blank",
 "expected": "The request is not saved; Start Date is reported as mandatory "
             "(message text To be confirmed - Q-05)."},
```

Notice: every title names the field and the value; preconditions,
steps, data and expected results differ because each case tests a
different condition; message text is quoted exactly; the one missing
fact is a Q-nn, not a guess.

## 4. The matching requirement and clarification rows

```python
"requirements": [{"id": "FR-01",
                  "summary": "Leave request form fields, validations and messages.",
                  "source": "Req Spec v1.0 s2.1", "level": "System Test"}],
"clarifications": [{"id": "Q-05", "document": "Req Spec v1.0", "section": "FR-01",
                    "question": "Message text when Start Date or End Date is blank "
                                "(only Leave Type has one)?",
                    "impact": "FR-01 / TC-ST-006, TC-ST-009"}],
```
