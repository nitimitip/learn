# Workbook Layout And Appassist Theme

```text

scripts/tc_builder.py produces this layout. It is described here so the
agent can explain it; the agent never builds it by hand.

1. SHEETS  (in this order; level sheets only when the documents support them)
------------------------------------------------------------------------
  Dashboard          project details, 18 KPI tiles, status by level, test
                     type coverage, priority and category breakdowns, two
                     charts. Every figure is a formula over the level
                     sheets, RTM and Clarifications, so it updates as
                     testers fill Status / Defect ID or add rows.
  UAT (BRD)          test cases from the BRD
  System Test (FRS)  test cases from the FRS / SRS
  SIT-API (HLD)      test cases from the HLD
  RTM                requirements traceability matrix: one row per
                     requirement; test case, positive, negative, boundary,
                     passed and failed counts and coverage status
                     (Not Covered / Covered - Not Run / In Progress /
                     Failing / Passed) are formulas.
  Clarifications     open questions and gaps: Q ID, document, section,
                     question, impacted Req / TC, raised on, answer, status
                     (Open / Answered / Closed).

2. TEST CASE COLUMNS  (header row 4, data from row 5)
------------------------------------------------------------------------
  A TC ID | B Req ID | C Module / Feature | D Title / Scenario | E Test Type
  | F Category | G Priority | H Preconditions | I Test Steps | J Test Data
  | K Expected Result | L Actual Result | M Status | N Defect ID
  | O Executed By | P Execution Date | Q Remarks
  Drop-down lists on Test Type, Category, Priority and Status; Status is
  colour coded; header frozen with filters; 25 formatted spare rows; the
  formulas watch rows 5 to 1004.

3. LISTS
------------------------------------------------------------------------
  Test Type  Positive, Negative, Boundary
  Priority   Critical, High, Medium, Low
  Status     Not Run, Pass, Fail, Blocked, Deferred
  Category   Business Flow, Functional, Field Validation, Business Rule,
             UI / Navigation, Access / Security, Error Handling,
             Integration, API, Data / Mapping, Performance,
             Resilience / Timeout

4. DASHBOARD PROJECT DETAILS  (ask the user; never fill them yourself)
------------------------------------------------------------------------
  Project Name, Application / System, Release / Version, Test Cycle,
  Test Environment, Prepared By, Reviewed By, Planned Start Date,
  Planned End Date, Source Documents (name + version of each document
  used - taken from the documents themselves).
  A field the user does not give shows "To be confirmed".

5. KPI DEFINITIONS
------------------------------------------------------------------------
  Total = rows with a TC ID.  Executed = Pass + Fail.
  Pass Rate = Pass / Executed.  Execution Progress = Executed / Total.
  Not Run = Total - Pass - Fail - Blocked - Deferred (blank = Not Run).
  Defects Logged = rows with a Defect ID.  Critical Failures = Critical
  priority rows with Status Fail.  Requirement Coverage = requirements
  with at least one test case / requirements in the RTM.

6. APPASSIST THEME  (from AppAssist email_theme.py / npg.css)
------------------------------------------------------------------------
  4A0E1E  burgundy band    sheet title band
  DBCFD2  band eyebrow     small caps line on the band
  7D0C27  deep red         table header fill (white bold text), tab colour
  AB1236  brand red        section label rule, Critical priority, accents
  0F1626  ink              headings and figures
  333E52  body             cell text
  5A6478  muted            notes, "To be confirmed"
  D3DBE7  hairline         all cell borders
  F2F5FA  card             KPI tiles, label cells, total rows
  F7F9FC  zebra            every second data row
  Status tones (fill / text): Pass E7F5EF / 0B5B41, Fail FDEEED / 8F1C13,
  Blocked FDF2E4 / 8A4308, Deferred ECF2FD / 13489F, Not Run F2F5FA /
  333E52.  Font: Segoe UI.  No gridlines; landscape, fit to page width.
```
