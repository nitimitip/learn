# Source Documents And Test Levels

```text

1. WHAT EACH DOCUMENT GIVES QA
------------------------------------------------------------------------
  BRD  Business Requirements Document
       Contains: business goals, ROI, stakeholders, as-is / to-be business
       processes, workflows, business rules at policy level ("why we are
       building this").
       Test level: User Acceptance Testing (UAT).
       Sheet: "UAT (BRD)"   code UAT   TC IDs TC-UAT-001 ...
       Use: high-level end-to-end business scenarios written in business
       language, one per workflow path, plus negative business scenarios
       (approval rejected, unauthorised role, mandatory business data
       missing, process exception). Too broad for field-level cases: do
       not invent field rules from a BRD.

  FRS / SRS  Functional / Software Requirements Specification
       Contains: detailed system behaviour, business rules, input fields
       and validations, error messages, screen flows, roles and
       permissions, status changes, reports ("what the system must do").
       Test level: System & Functional Testing.
       Sheet: "System Test (FRS)"   code ST   TC IDs TC-ST-001 ...
       Use: the main QA source. Each rule, field and message becomes
       positive, negative and boundary cases.

  HLD  High-Level Design
       Contains: architecture, modules, interfaces and APIs, third-party
       integrations, data flows, message formats, error handling,
       timeouts, retries, non-functional targets ("how modules connect").
       Test level: System Integration Testing (SIT) and API / performance.
       Sheet: "SIT-API (HLD)"   code SIT   TC IDs TC-SIT-001 ...
       Use: handoffs between components (e.g. Checkout -> Payment
       Gateway): success path, data mapping, invalid payload,
       authentication failure, downstream unavailable, timeout, retry,
       duplicate / repeated request, partial failure and rollback.
       Performance cases ONLY when the HLD states a measurable target
       (response time, throughput, volume); otherwise log a clarification.

2. COMBINED DOCUMENTS  (BRD + FRS in one, or FRS + design in one)
------------------------------------------------------------------------
  Many projects issue one "Requirements Specification" holding both
  business and functional content. Do not treat it as one level. Classify
  each SECTION by its content, not by the document title:
    Goes to UAT (BRD content)          Goes to System Test (FRS content)
    - business objectives, benefits    - field lists, formats, mandatory
    - stakeholder / actor overview       flags, lengths, ranges
    - end-to-end process / workflow    - validation and calculation rules
    - business policy statements       - error / warning message text
    - acceptance criteria written as   - screen flows, buttons, navigation
      business outcomes                - roles and permission matrix
                                       - status / state transitions
    Goes to SIT (HLD content): interface lists, API endpoints, payloads,
    integrations, batch / file transfers, data flow diagrams.
  A section that holds both (e.g. a use case with a business flow and
  field rules) feeds both sheets: the end-to-end flow becomes one UAT
  scenario, the rules become System Test cases, and both carry the same
  Req ID.
  Show the section map to the user and ask them to confirm judgement
  calls before writing cases.

3. WHEN DOCUMENTS ARE MISSING
------------------------------------------------------------------------
  Only BRD        UAT sheet only - the most common upload. Mention once,
                  without blocking, that field-level cases need an FRS /
                  SRS. Still write a complete professional UAT set from
                  what the BRD gives:
                    - every business process: the main path end to end,
                      by the BRD's own process, step and actor names
                    - every alternate and exception path the BRD
                      mentions (rejected, returned, cancelled, on hold,
                      escalated, expired)
                    - every business rule and policy statement: one
                      case where it is met, one where it is broken
                    - every actor: what each may do, and one actor who
                      may not (where the BRD says who may)
                    - every handoff between teams or systems the BRD
                      names, and every notification / report / output
                    - every acceptance criterion and success measure
                      that can be observed in a test
                  Never turn BRD wording into invented field rules,
                  limits or messages; a missing detail is a question.
  Only FRS        System Test sheet; add UAT scenarios only if the FRS
                  describes end-to-end business flows.
  Only HLD        SIT sheet only.
  No document     Do not write test cases. Ask for a document; pasted
                  requirement text is acceptable.
  Conflicts between documents are never resolved by you: log each one on
  the Clarifications sheet and ask.
```
