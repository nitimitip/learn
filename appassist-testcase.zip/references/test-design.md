# Test Design Standard

```text

1. DESIGN TECHNIQUES  (use the ones the requirement calls for)
------------------------------------------------------------------------
  Equivalence partitioning  one case per valid class and per invalid class
                            (e.g. valid email / missing "@" / empty).
  Boundary value analysis   for every stated limit test min, min-1, max,
                            max+1 (and min+1 / max-1 for critical fields).
                            Only limits the document states.
  Decision table            rules with several conditions: one case per
                            meaningful combination of conditions.
  State transition          status flows (Draft -> Submitted -> Approved):
                            every allowed transition (positive) and the
                            important disallowed ones (negative).
  Role / permission         each role allowed (positive) and a role not
                            allowed (negative), per protected action.
  Error guessing            interfaces: timeout, unavailable, invalid or
                            empty response, duplicate request.
  End-to-end scenario       UAT: one business flow from start to finish.

2. TEST TYPE  (column E)
------------------------------------------------------------------------
  Positive   valid input or allowed action; the system does what it should.
  Negative   invalid input, missing data, wrong role, failure of a
             dependency; the system rejects it correctly and safely.
  Boundary   the value exactly on, just inside or just outside a stated
             limit.
  Balance: a typical FRS gives more negative + boundary cases than
  positive ones; aim for at least one negative per positive where the
  requirement has a rule. Never pad: no duplicate cases to reach a ratio.

3. HOW EACH COLUMN IS WRITTEN  (quality-standard.md sets the bar; the
   checker refuses generic or copied cells)
------------------------------------------------------------------------
  TC ID            TC-UAT-001, TC-ST-001, TC-SIT-001: sequential per sheet,
                   three digits, no gaps.
  Req ID           exactly ONE requirement ID from the document (the RTM
                   counts on it). If the document has no IDs, use the
                   section: BRD-3.2, FRS-4.1.3, HLD-5.2 (confirm with the
                   user first).
  Module / Feature the module or screen name used in the document.
  Title / Scenario "Verify <behaviour> when <condition>", one line,
                   specific: "Verify login is rejected when the password
                   is blank".
  Test Type        Positive | Negative | Boundary.
  Category         one value from the list in workbook-layout.md.
  Priority         Critical - core business flow, money, security, data
                              loss, legal or safety impact
                   High     - main functions and key validations
                   Medium   - secondary functions, most messages
                   Low      - cosmetic, rarely used paths
                   Base it on the document's priority (MoSCoW: Must ->
                   Critical/High, Should -> Medium, Could -> Low) when it
                   gives one.
  Preconditions    the state before step 1 FOR THIS CASE: the role by the
                   document's name for it, the data that must exist and its
                   status, the starting screen or system state. Never "user
                   logged in with valid role". "None" only if truly none.
  Test Steps       numbered, one action per step, imperative, using the
                   document's own screen, field, button and menu names and
                   the exact value of this case: "1. Open the Login screen.
                   2. Enter a registered user ID. 3. Leave Password blank.
                   4. Select Login." Never "open related screen / perform
                   action / submit and observe". Pass steps as a list in
                   the spec; the builder numbers them.
  Test Data        the exact values of THIS case and why: "Quantity = 101
                   (maximum 100 + 1)". Concrete values only when the
                   document gives them or they follow from a stated rule;
                   otherwise the data condition of this case: "Active
                   customer account with one open order (test data team to
                   provide)". Never "requirement based data".
  Expected Result  observable outcome of THIS condition: what is shown
                   (message text in quotes exactly as in the document, and
                   where), what is saved or not saved, status before ->
                   after, values stored, who is notified; for a negative
                   case also what does NOT change. If the document has no
                   message text and the user did not give it: state only
                   the known outcome ("the order is not saved") and list
                   the message check as left out under its question
                   (quality-standard.md section 1A). Never "To be
                   confirmed", "system behaves as per specification" or
                   "as expected".
  Actual Result, Status, Defect ID, Executed By, Execution Date, Remarks
                   execution columns; left empty, Status "Not Run".

4. LEVEL-SPECIFIC GUIDANCE
------------------------------------------------------------------------
  UAT (BRD)  business language; a business user can run it; one scenario
             per workflow path; steps at task level ("Raise a purchase
             request for an approved supplier"). Categories: Business Flow,
             Access / Security, Business Rule.
  System (FRS) one condition per case; cover every field rule, message,
             calculation, role and state change.
  SIT (HLD)  name both sides of the handoff in the title ("Order Service ->
             Payment Gateway"); expected result states what each side
             does (request sent, response handled, data stored, error
             logged, user informed). Response codes, payload fields,
             timeouts and retry counts only as the HLD gives them.

5. EXAMPLES  (style only - never copy content into a real workbook)
------------------------------------------------------------------------
  FRS line: "FR-07 Quantity is mandatory, whole number 1-100. Message:
            'Enter a quantity between 1 and 100.'"
  Cases:
    TC-ST-014 | FR-07 | Verify order is accepted when Quantity is 1
              | Boundary | Field Validation | High
              | Steps: 1. Open New Order. 2. Enter Quantity 1. 3. Submit.
              | Data: Quantity = 1 (stated minimum)
              | Expected: Order is saved; no validation message.
    TC-ST-015 | FR-07 | Verify order is rejected when Quantity is 0
              | Boundary | Field Validation | High
              | Expected: Order is not saved; message "Enter a quantity
                between 1 and 100." is shown against Quantity.
    TC-ST-016 | FR-07 | ... Quantity is 101 | Boundary
    TC-ST-017 | FR-07 | ... Quantity is blank | Negative
    TC-ST-018 | FR-07 | ... Quantity is 2.5 (not a whole number) | Negative
    TC-ST-019 | FR-07 | ... Quantity is 50 | Positive

  HLD line: "INT-03 Order Service calls Payment Gateway; timeout 30 s; one
            retry; on failure the order stays Pending Payment."
  Cases: success handoff (Positive, Integration); gateway does not respond
  within 30 s -> one retry then order stays Pending Payment (Negative,
  Resilience / Timeout); gateway returns a decline (Negative, Error
  Handling); payload missing a mandatory field, only if the HLD lists the
  fields (Negative, API).

6. WHAT NEVER GOES IN
------------------------------------------------------------------------
  Requirements, limits, messages, codes, roles or targets the documents
  do not state; real credentials or personal data; duplicate cases; cases
  for features the documents do not describe; guidance text from this
  file; the word "Sample"; placeholder wording or a cell copied across
  cases (quality-standard.md section 3).
```
