import datetime
import re
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.formatting.rule import CellIsRule
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.chart import DoughnutChart, BarChart, Reference
from openpyxl.chart.series import DataPoint

# AppAssist palette (email_theme.py / npg.css)
BAND = '4A0E1E'; RED = 'AB1236'; DEEP = '7D0C27'; INK = '0F1626'
BODY = '333E52'; MUTED = '5A6478'; LINE = 'D3DBE7'; LINE2 = 'BBC6D6'
CARD = 'F2F5FA'; ZEBRA = 'F7F9FC'; EYEBROW = 'DBCFD2'; WHITE = 'FFFFFF'
FONT = 'Segoe UI'
TONE = {'Pass': ('E7F5EF', '0B5B41', '0F7050'),
        'Fail': ('FDEEED', '8F1C13', 'B42318'),
        'Blocked': ('FDF2E4', '8A4308', 'B45309'),
        'Deferred': ('ECF2FD', '13489F', '175CD3'),
        'Not Run': ('F2F5FA', '333E52', 'BBC6D6')}
STATUSES = ['Not Run', 'Pass', 'Fail', 'Blocked', 'Deferred']
TYPES = ['Positive', 'Negative', 'Boundary']
PRIORITIES = ['Critical', 'High', 'Medium', 'Low']
CATEGORIES = ['Business Flow', 'Functional', 'Field Validation',
              'Business Rule', 'UI / Navigation', 'Access / Security',
              'Error Handling', 'Integration', 'API', 'Data / Mapping',
              'Performance', 'Resilience / Timeout']
LEVELS = {'UAT': ('UAT (BRD)', 'User Acceptance Testing', 'BRD', 'UAT'),
          'ST': ('System Test (FRS)', 'System & Functional Testing', 'FRS / SRS',
                 'Functional'),
          'SIT': ('SIT-API (HLD)', 'System Integration & API Testing', 'HLD',
                  'SIT / API')}
PROJECT_FIELDS = ['Project Name', 'Application / System', 'Release / Version',
                  'Test Cycle', 'Test Environment', 'Prepared By',
                  'Reviewed By', 'Planned Start Date', 'Planned End Date',
                  'Source Documents']
COLS = [('TC ID', 'id', 14), ('Req ID', 'req', 12), ('Module / Feature', 'module', 20),
        ('Title / Scenario', 'title', 34), ('Test Type', 'type', 12),
        ('Category', 'category', 18), ('Priority', 'priority', 11),
        ('Preconditions', 'pre', 28), ('Test Steps', 'steps', 46),
        ('Test Data', 'data', 28), ('Expected Result', 'expected', 40),
        ('Actual Result', None, 28), ('Status', None, 11), ('Defect ID', None, 12),
        ('Executed By', None, 15), ('Execution Date', None, 15), ('Remarks', None, 24)]
FIRST, LAST = 5, 1004          # test-case rows the formulas watch
TBC = 'To be confirmed'
THIN = Side(style='thin', color=LINE)
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

# ---- quality gate: build_workbook() refuses generic, copied or guessed cases ----
# Placeholder wording says nothing a tester can execute or check. Rewrite the
# cell with the document's own screen, field, role, value, message and state.
GENERIC = [
    (r'\b(verify|validate|check|test)\s+(the\s+)?(req\b|requir\w*|requri\w*)', 'title names the requirement, not the behaviour'),
    (r'\bmandatory\s*/\s*invalid\b|\bvalid\s*/\s*invalid\b|\bpositive\s*/\s*negative\b', 'two conditions in one case'),
    (r'\binvalid\s+hand\w*\b|\bmandatory\s+hand\w*\b', 'condition not named'),
    (r'requirements?[\s-]*bas(e|ed)\s+(test\s+)?data', 'test data not stated'),
    (r'\bas\s+per\s+(the\s+)?(spec|specification|requirements?|document|srs|frs|brd|hld|design)\b', 'expected result not stated'),
    (r'\b(behaves?|works?|functions?|performs?|responds?)\s+(as\s+expected|correctly|properly|fine|accordingly|successfully)\b', 'expected result not stated'),
    (r'\bas\s+expected\b|\bas\s+applicable\b', 'expected result not stated'),
    (r'\b(expected|desired|appropriate|proper|correct|relevant)\s+(result|outcome|behaviou?r|message|error|response|screen|page|data|action)\b', 'vague - name it'),
    (r'\b(open|navigate\s+to|go\s+to|launch)\s+(the\s+)?(related|relevant|respective|concerned|required|corresponding|appropriate)\s+(screen|page|module|form|menu|application)', 'screen not named'),
    (r'\bperform\s+(the\s+)?(action|operation|step|transaction)\b', 'action not named'),
    (r'\b(submit|save|click)\s+and\s+(observe|check|verify)\b', 'two actions and no check'),
    (r'\bobserve\s+(the\s+)?(result|behaviou?r|output|outcome|system)\b', 'nothing observable named'),
    (r'\bwith\s+(the\s+)?(given|required|relevant|test|valid|appropriate)\s+(test\s+)?data\b', 'data not named'),
    (r'\b(valid|appropriate|required|relevant|necessary|proper)\s+(role|access|permissions?|privileges?|rights|credentials)\b', 'role not named'),
    (r'\b(enter|input|fill)\s+(all\s+)?(the\s+)?(details|data|values|fields|information)\s*\.?$', 'fields and values not named'),
    (r'\bsame\s+as\s+(above|previous|before)\b|\bsimilar\s+to\s+(above|previous|TC)', 'every case stands on its own'),
    (r'\brefer\s+(to\s+)?(the\s+)?(document|brd|frs|srs|hld|requirement|spec)', 'the tester must not need the document'),
    (r'\bTBD\b|\bTBA\b|\bN/?A\b', 'placeholder - ask the user, or leave the case out'),
    (r'\betc\.?(?=\W|$)', 'list every item instead of "etc"'),
]
GENERIC = [(re.compile(p, re.I), why) for p, why in GENERIC]
# A test case never waits on an open question and never guesses: what the
# user did not answer is left out and listed under the clarification's
# "dropped" list (or the requirement's "dropped" when nothing can be written).
OPEN = re.compile(r'\bto\s+be\s+(confirmed|clarified|decided|defined|agreed|advised)\b'
                  r'|\bTBC\b|\bpending\s+(clarification|confirmation|answer)\b'
                  r'|\bassum(e|ed|es|ing|ption)\b', re.I)
Q_REF = re.compile(r'\bQ-\d{2,3}\b')
MIN_WORDS = {'title': 5, 'expected': 6}
TEXT_KEYS = ('title', 'pre', 'steps', 'data', 'expected')


def _norm(v):
    if isinstance(v, list):
        v = ' | '.join(str(x) for x in v)
    return re.sub(r'\s+', ' ', str(v or '')).strip().lower().rstrip('.')


def quality(spec):
    """(errors, warnings) for the wording of every test case in spec."""
    errors, warnings = [], []
    E, W = errors.append, warnings.append
    req_ids = [r.get('id') for r in spec.get('requirements') or []]
    answered = set(q.get('id') for q in spec.get('clarifications') or []
                   if q.get('answer'))
    for sh in spec.get('sheets') or []:
        code = sh.get('code')
        cases = sh.get('cases') or []
        for n, c in enumerate(cases, 1):
            where = '%s case %d (%s)' % (code, n, c.get('id'))
            for k in TEXT_KEYS:
                v = c.get(k)
                for part in (v if isinstance(v, list) else [v]):
                    for rx, why in GENERIC:
                        m = rx.search(str(part or ''))
                        if m:
                            E('%s: %s has generic wording "%s" (%s)' % (where, k, m.group(0), why))
                            break
                    m = OPEN.search(str(part or ''))
                    if m:
                        E('%s: %s says "%s" - a case is written only from stated facts and '
                          'answers; if pass / fail depends on an unanswered point, leave the '
                          'case out and list it under that question\'s "dropped"'
                          % (where, k, m.group(0)))
                    for q in Q_REF.findall(str(part or '')):
                        if q not in answered:
                            E('%s: %s depends on open question %s - leave the case out and '
                              'list it under %s "dropped"' % (where, k, q, q))
            title = str(c.get('title') or '')
            for rid in req_ids:
                if rid and re.search(r'(?<![\w-])%s(?![\w-])' % re.escape(rid), title, re.I):
                    E('%s: title contains Req ID %s - describe the behaviour and the '
                      'condition instead' % (where, rid))
            for k, least in MIN_WORDS.items():
                if len(str(c.get(k) or '').split()) < least:
                    E('%s: %s is too short to be specific (fewer than %d words)'
                      % (where, k, least))
            steps = c.get('steps')
            if isinstance(steps, list) and len(steps) < 2:
                E('%s: steps need at least 2 actions (set-up and the action under test)' % where)
        # copied cells: the condition under test must show in every column
        for k, label_, hard in (('title', 'Title', True), ('steps', 'Test Steps', True),
                                ('expected', 'Expected Result', True),
                                ('data', 'Test Data', False), ('pre', 'Preconditions', False)):
            groups = {}
            for c in cases:
                groups.setdefault(_norm(c.get(k)), []).append(c.get('id'))
            for text, ids in groups.items():
                if len(ids) < 2 or not text:
                    continue
                if hard:
                    E('%s: %s is identical in %s - each case must show its own condition, '
                      'value and outcome' % (code, label_, ', '.join(ids)))
                elif len(cases) >= 4 and len(ids) * 2 > len(cases):
                    E('%s: %s is the same in %d of %d cases (%s...) - state the role, data and '
                      'state each case needs' % (code, label_, len(ids), len(cases),
                                                 ', '.join(ids[:3])))
                elif len(cases) >= 6 and len(ids) * 4 > len(cases):
                    W('%s: %s is the same in %d of %d cases (%s...) - make it specific to each '
                      'case' % (code, label_, len(ids), len(cases), ', '.join(ids[:3])))
    return errors, warnings


def fill(c):
    return PatternFill('solid', fgColor=c)


def fnt(size=10, bold=False, color=BODY, italic=False):
    return Font(name=FONT, size=size, bold=bold, color=color, italic=italic)


def rng(sheet, col, first=FIRST, last=LAST):
    return "'%s'!$%s$%d:$%s$%d" % (sheet, col, first, col, last)


def band(ws, c1, c2, eyebrow, title, sub):
    for r in (1, 2):
        for c in range(c1, c2 + 1):
            ws.cell(r, c).fill = fill(BAND)
    ws.cell(1, c1, eyebrow).font = fnt(9, True, EYEBROW)
    ws.cell(2, c1, title).font = fnt(16, True, WHITE)
    ws.cell(1, c1).alignment = Alignment(vertical='bottom', indent=1)
    ws.cell(2, c1).alignment = Alignment(vertical='center', indent=1)
    ws.row_dimensions[1].height = 22
    ws.row_dimensions[2].height = 32
    ws.cell(3, c1, sub).font = fnt(9, False, MUTED, True)
    ws.row_dimensions[3].height = 20


def header(ws, row, c1, labels):
    for i, label in enumerate(labels):
        c = ws.cell(row, c1 + i, label)
        c.fill = fill(DEEP); c.font = fnt(10, True, WHITE); c.border = BOX
        c.alignment = Alignment(vertical='center', wrap_text=True)
    ws.row_dimensions[row].height = 30


def body(c, zebra=False, fmt=None, center=False, bold=False):
    c.font = fnt(10, bold, INK if bold else BODY); c.border = BOX
    c.alignment = Alignment(vertical='top', wrap_text=True,
                            horizontal='center' if center else None)
    if zebra:
        c.fill = fill(ZEBRA)
    if fmt:
        c.number_format = fmt


def label(ws, row, c1, c2, text):
    for c in range(c1, c2 + 1):
        ws.cell(row, c).border = Border(bottom=Side(style='medium', color=RED))
    ws.cell(row, c1, text).font = fnt(10, True, DEEP)
    ws.row_dimensions[row].height = 22


def listdv(ws, values, ref):
    dv = DataValidation(type='list', formula1='"%s"' % ','.join(values),
                        allow_blank=True, showErrorMessage=True,
                        errorTitle='Invalid value', error='Pick a value from the list.')
    ws.add_data_validation(dv); dv.add(ref)


def tones(ws, ref, mapping):
    for value, (bg, fg, _) in mapping.items():
        ws.conditional_formatting.add(ref, CellIsRule(
            operator='equal', formula=['"%s"' % value], fill=fill(bg),
            font=Font(name=FONT, color=fg, bold=True)))


def finish(ws, landscape=True):
    ws.sheet_view.showGridLines = False
    ws.page_setup.orientation = 'landscape' if landscape else 'portrait'
    ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.sheet_properties.tabColor = DEEP


def test_sheet(wb, sh, project):
    name, level, doc, _ = LEVELS[sh['code']]
    ws = wb.create_sheet(name)
    band(ws, 1, len(COLS), 'APPASSIST  |  TEST CASES  |  ' + level.upper(),
         '%s  -  %s' % (project, level),
         'Source: %s.  Fill Actual Result, Status, Defect ID, Executed By and '
         'Execution Date while executing; the Dashboard and RTM update '
         'automatically.' % sh.get('source', doc))
    header(ws, 4, 1, [c[0] for c in COLS])
    for i, col in enumerate(COLS):
        ws.column_dimensions[chr(65 + i)].width = col[2]
    cases = sh.get('cases', [])
    for i in range(len(cases) + 25):        # 25 formatted spare rows
        r = FIRST + i
        case = cases[i] if i < len(cases) else None
        for j, (_, key, _) in enumerate(COLS):
            v = None
            if case is not None:
                v = case.get(key) if key else None
                if key == 'steps' and isinstance(v, list):
                    v = '\n'.join('%d. %s' % (k + 1, s) for k, s in enumerate(v))
                if j == 12:
                    v = 'Not Run'
            c = ws.cell(r, j + 1, v)
            body(c, i % 2 == 1, 'dd-mmm-yyyy' if j == 15 else None,
                 center=j in (4, 6, 12), bold=j == 0)
    listdv(ws, TYPES, 'E%d:E%d' % (FIRST, LAST))
    listdv(ws, CATEGORIES, 'F%d:F%d' % (FIRST, LAST))
    listdv(ws, PRIORITIES, 'G%d:G%d' % (FIRST, LAST))
    listdv(ws, STATUSES, 'M%d:M%d' % (FIRST, LAST))
    tones(ws, 'M%d:M%d' % (FIRST, LAST), TONE)
    ws.conditional_formatting.add('G%d:G%d' % (FIRST, LAST), CellIsRule(
        operator='equal', formula=['"Critical"'],
        font=Font(name=FONT, color=RED, bold=True)))
    ws.freeze_panes = 'C5'
    ws.auto_filter.ref = 'A4:Q%d' % (FIRST + len(cases) + 24)
    ws.print_title_rows = '4:4'
    finish(ws)
    return name


def rtm_sheet(wb, reqs, sheets):
    ws = wb.create_sheet('RTM')
    band(ws, 1, 11, 'APPASSIST  |  REQUIREMENTS TRACEABILITY MATRIX',
         'Requirements Traceability Matrix',
         'Every requirement from the source documents, traced to its test '
         'cases. Counts and coverage status are formulas.')
    header(ws, 4, 1, ['Req ID', 'Requirement Summary', 'Source (Document / Section)',
                      'Test Level', 'Test Cases', 'Positive', 'Negative',
                      'Boundary', 'Passed', 'Failed', 'Coverage Status'])
    for i, w in enumerate([12, 46, 26, 16, 10, 10, 10, 10, 10, 10, 18]):
        ws.column_dimensions[chr(65 + i)].width = w

    def total(r, extra=None):
        parts = []
        for s in sheets:
            if extra:
                parts.append('COUNTIFS(%s,$A%d,%s,"%s")' % (
                    rng(s, 'B'), r, rng(s, extra[0]), extra[1]))
            else:
                parts.append('COUNTIF(%s,$A%d)' % (rng(s, 'B'), r))
        return '=IF($A%d="","",%s)' % (r, '+'.join(parts) or '0')
    for i in range(len(reqs) + 15):
        r = FIRST + i
        q = reqs[i] if i < len(reqs) else {}
        dropped = q.get('dropped')
        if isinstance(dropped, list):
            dropped = ', '.join(dropped)
        summary = q.get('summary')
        if dropped:
            summary = '%s\n(Test cases left out until %s is answered.)' % (summary, dropped)
        vals = [q.get('id'), summary, q.get('source'), q.get('level'),
                total(r), total(r, ('E', 'Positive')), total(r, ('E', 'Negative')),
                total(r, ('E', 'Boundary')), total(r, ('M', 'Pass')),
                total(r, ('M', 'Fail')),
                '=IF($A{0}="","",IF(E{0}=0,"{1}",IF(J{0}>0,"Failing",'
                'IF(I{0}=E{0},"Passed",IF(I{0}+J{0}=0,"Covered - Not Run",'
                '"In Progress")))))'.format(r, 'Dropped' if dropped else 'Not Covered')]
        for j, v in enumerate(vals):
            body(ws.cell(r, j + 1, v), i % 2 == 1, center=j >= 4, bold=j == 0)
    tones(ws, 'K%d:K%d' % (FIRST, LAST), {
        'Passed': TONE['Pass'], 'Failing': TONE['Fail'], 'Not Covered': TONE['Fail'],
        'In Progress': TONE['Blocked'], 'Covered - Not Run': TONE['Not Run'],
        'Dropped': TONE['Deferred']})
    ws.freeze_panes = 'B5'
    ws.auto_filter.ref = 'A4:K%d' % (FIRST + len(reqs) + 14)
    finish(ws)


def clar_sheet(wb, items, today):
    ws = wb.create_sheet('Clarifications')
    band(ws, 1, 8, 'APPASSIST  |  OPEN QUESTIONS FOR THE DOCUMENT AUTHORS',
         'Clarifications & Assumptions',
         'Gaps found in the source documents. Tests that depend on an '
         'unanswered question are left out and listed against it; add them '
         'once it is answered.')
    header(ws, 4, 1, ['Q ID', 'Document', 'Section / Page', 'Question / Gap',
                      'Impacted Req / Tests Left Out', 'Raised On', 'Answer', 'Status'])
    for i, w in enumerate([9, 14, 14, 50, 36, 13, 40, 12]):
        ws.column_dimensions[chr(65 + i)].width = w
    for i in range(len(items) + 15):
        r = FIRST + i
        q = items[i] if i < len(items) else None
        impact = None
        if q:
            impact = q.get('impact') or ''
            if q.get('dropped'):
                impact = ((impact + '\n' if impact else '') + 'Left out until answered: '
                          + '; '.join(q['dropped']))
        vals = ([q.get('id'), q.get('document'), q.get('section'), q.get('question'),
                 impact, today, q.get('answer'),
                 q.get('status') or ('Answered' if q.get('answer') else 'Open')]
                if q else [None] * 8)
        for j, v in enumerate(vals):
            body(ws.cell(r, j + 1, v), i % 2 == 1,
                 'dd-mmm-yyyy' if j == 5 else None, center=j in (5, 7), bold=j == 0)
    listdv(ws, ['Open', 'Answered', 'Closed'], 'H%d:H%d' % (FIRST, LAST))
    tones(ws, 'H%d:H%d' % (FIRST, LAST), {'Open': TONE['Blocked'],
                                          'Answered': TONE['Deferred'],
                                          'Closed': TONE['Pass']})
    ws.freeze_panes = 'B5'
    finish(ws)


def tile(ws, row, col, text, formula, fmt='0', color=INK):
    for r in range(row, row + 3):
        ws.merge_cells(start_row=r, start_column=col, end_row=r, end_column=col + 1)
        for c in (col, col + 1):
            cell = ws.cell(r, c)
            cell.fill = fill(CARD)
            cell.border = Border(
                left=THIN if c == col else None, right=THIN if c == col + 1 else None,
                top=THIN if r == row else None, bottom=THIN if r == row + 2 else None)
    a = ws.cell(row, col, text.upper())
    a.font = fnt(8, True, MUTED); a.alignment = Alignment(indent=1, vertical='bottom')
    v = ws.cell(row + 1, col, formula)
    v.font = fnt(20, True, color); v.number_format = fmt
    v.alignment = Alignment(indent=1, horizontal='left', vertical='center')
    ws.row_dimensions[row + 1].height = 30


def dashboard(ws, spec, sheets, today):
    p = spec.get('project', {})
    pname = p.get('Project Name') or TBC
    ws.title = 'Dashboard'
    ws.column_dimensions['A'].width = 2
    for c in range(2, 14):
        ws.column_dimensions[chr(64 + c)].width = 20 if c == 2 else 15
    band(ws, 2, 13, 'APPASSIST  |  QUALITY ASSURANCE  |  TEST CASE DASHBOARD',
         pname, 'Prepared %s.  Every figure below is a formula: it updates as '
                'test cases are added and executed.' % today.strftime('%d %B %Y'))
    label(ws, 5, 2, 13, 'PROJECT DETAILS')
    for k, f in enumerate(PROJECT_FIELDS):
        r = 6 + k // 2; c = 2 if k % 2 == 0 else 8
        ws.merge_cells(start_row=r, start_column=c, end_row=r, end_column=c + 1)
        ws.merge_cells(start_row=r, start_column=c + 2, end_row=r, end_column=c + 5)
        for cc in range(c, c + 6):
            ws.cell(r, cc).border = BOX
            ws.cell(r, cc).fill = fill(CARD if cc < c + 2 else WHITE)
        a = ws.cell(r, c, f); a.font = fnt(9, True, INK)
        a.alignment = Alignment(vertical='center', indent=1)
        val = p.get(f) or TBC
        b = ws.cell(r, c + 2, val)
        b.font = fnt(10, False, MUTED if val == TBC else BODY, val == TBC)
        b.alignment = Alignment(vertical='center', wrap_text=True, indent=1)
        ws.row_dimensions[r].height = 30 if len(str(val)) > 45 else 20

    # status by level table (row numbers fixed first so tiles can point at it)
    n = len(sheets)
    lvl_head = 27; tot = lvl_head + n + 1
    type_head = tot + 3; type_tot = type_head + n + 1
    pri_head = type_tot + 3; cat_head = pri_head + len(PRIORITIES) + 3

    def across(fn):
        return '+'.join(fn(s) for s in sheets) or '0'
    T = lambda c: '%s%d' % (c, tot)
    label(ws, 12, 2, 13, 'KEY INDICATORS')
    req_rng = "RTM!$A$%d:$A$%d" % (FIRST, LAST)
    tiles = [
        [('Total Test Cases', '=' + T('D'), '0', INK),
         ('Executed', '=%s+%s' % (T('E'), T('F')), '0', INK),
         ('Passed', '=' + T('E'), '0', TONE['Pass'][2]),
         ('Failed', '=' + T('F'), '0', TONE['Fail'][2]),
         ('Blocked', '=' + T('G'), '0', TONE['Blocked'][2]),
         ('Not Run', '=' + T('I'), '0', MUTED)],
        [('Pass Rate', '=' + T('J'), '0.0%', TONE['Pass'][2]),
         ('Execution Progress', '=' + T('K'), '0.0%', INK),
         ('Positive Cases', '=C%d' % type_tot, '0', DEEP),
         ('Negative Cases', '=D%d' % type_tot, '0', RED),
         ('Boundary Cases', '=E%d' % type_tot, '0', MUTED),
         ('Defects Logged', '=' + across(lambda s: 'COUNTIF(%s,"?*")' % rng(s, 'N')),
          '0', TONE['Fail'][2])],
        [('Requirements', '=COUNTA(%s)' % req_rng, '0', INK),
         ('Requirements Covered', '=COUNTA(%s)-COUNTIF(RTM!$K$%d:$K$%d,"Not Covered")'
          '-COUNTIF(RTM!$K$%d:$K$%d,"Dropped")'
          % (req_rng, FIRST, LAST, FIRST, LAST), '0', TONE['Pass'][2]),
         ('Not Covered / Dropped', '=COUNTIF(RTM!$K$%d:$K$%d,"Not Covered")'
          '+COUNTIF(RTM!$K$%d:$K$%d,"Dropped")' % (FIRST, LAST, FIRST, LAST),
          '0', TONE['Fail'][2]),
         ('Requirement Coverage', '=IFERROR(D22/B22,0)', '0.0%', INK),
         ('Critical Failures', '=' + across(lambda s: 'COUNTIFS(%s,"Critical",%s,"Fail")'
                                             % (rng(s, 'G'), rng(s, 'M'))),
          '0', TONE['Fail'][2]),
         ('Open Clarifications', "=COUNTIF(Clarifications!$H$%d:$H$%d,\"Open\")"
          % (FIRST, LAST), '0', TONE['Blocked'][2])]]
    for k, row in enumerate(tiles):
        for m, (t, f, fmt, color) in enumerate(row):
            tile(ws, 13 + 4 * k, 2 + 2 * m, t, f, fmt, color)

    label(ws, lvl_head - 1, 2, 13, 'EXECUTION STATUS BY TEST LEVEL')
    header(ws, lvl_head, 2, ['Worksheet', 'Test Level', 'Total', 'Pass', 'Fail',
                             'Blocked', 'Deferred', 'Not Run', 'Pass Rate',
                             'Executed %', 'Source'])
    for k, sh in enumerate(spec['sheets']):
        r = lvl_head + 1 + k; s = sheets[k]
        cnt = lambda st: 'COUNTIF(%s,"%s")' % (rng(s, 'M'), st)
        vals = [s, LEVELS[sh['code']][3], '=COUNTA(%s)' % rng(s, 'A'),
                '=' + cnt('Pass'), '=' + cnt('Fail'), '=' + cnt('Blocked'),
                '=' + cnt('Deferred'), '=D{0}-E{0}-F{0}-G{0}-H{0}'.format(r),
                '=IFERROR(E{0}/(E{0}+F{0}),0)'.format(r),
                '=IFERROR((E{0}+F{0})/D{0},0)'.format(r), sh.get('source', '')]
        for j, v in enumerate(vals):
            body(ws.cell(r, 2 + j, v), k % 2 == 1, '0.0%' if j in (8, 9) else None,
                 center=2 <= j <= 9, bold=j == 0)
    vals = ['Total', '', ] + ['=SUM(%s%d:%s%d)' % (c, lvl_head + 1, c, tot - 1)
                              for c in 'DEFGHI'] + [
        '=IFERROR(E{0}/(E{0}+F{0}),0)'.format(tot),
        '=IFERROR((E{0}+F{0})/D{0},0)'.format(tot), '']
    for j, v in enumerate(vals):
        c = ws.cell(tot, 2 + j, v)
        body(c, False, '0.0%' if j in (8, 9) else None, center=2 <= j <= 9, bold=True)
        c.fill = fill(CARD)

    label(ws, type_head - 1, 2, 7, 'TEST DESIGN COVERAGE BY TYPE')
    header(ws, type_head, 2, ['Worksheet', 'Positive', 'Negative', 'Boundary',
                              'Total', 'Negative + Boundary %'])
    for k, s in enumerate(sheets + ['Total']):
        r = type_head + 1 + k
        if s == 'Total':
            vals = ['Total'] + ['=SUM(%s%d:%s%d)' % (c, type_head + 1, c, r - 1)
                                for c in 'CDEF']
        else:
            vals = [s] + ['=COUNTIF(%s,"%s")' % (rng(s, 'E'), t) for t in TYPES] + [
                '=SUM(C{0}:E{0})'.format(r)]
        vals.append('=IFERROR((D{0}+E{0})/F{0},0)'.format(r))
        for j, v in enumerate(vals):
            c = ws.cell(r, 2 + j, v)
            body(c, k % 2 == 1 and s != 'Total', '0.0%' if j == 5 else None,
                 center=j > 0, bold=j == 0 or s == 'Total')
            if s == 'Total':
                c.fill = fill(CARD)

    def breakdown(head, title, items, col):
        label(ws, head - 1, 2, 7, title)
        header(ws, head, 2, [title.split(' ')[0].title(), 'Total', 'Pass', 'Fail',
                             'Blocked', 'Not Run'])
        for k, it in enumerate(items):
            r = head + 1 + k
            f = lambda st: '=' + across(lambda s: 'COUNTIFS(%s,"%s",%s,"%s")' % (
                rng(s, col), it, rng(s, 'M'), st))
            vals = [it, '=' + across(lambda s: 'COUNTIF(%s,"%s")' % (rng(s, col), it)),
                    f('Pass'), f('Fail'), f('Blocked'),
                    '=C{0}-D{0}-E{0}-F{0}-('.format(r) + across(
                        lambda s: 'COUNTIFS(%s,"%s",%s,"Deferred")' % (
                            rng(s, col), it, rng(s, 'M'))) + ')']
            for j, v in enumerate(vals):
                body(ws.cell(r, 2 + j, v), k % 2 == 1, center=j > 0, bold=j == 0)
    breakdown(pri_head, 'PRIORITY BREAKDOWN', PRIORITIES, 'G')
    breakdown(cat_head, 'CATEGORY BREAKDOWN', CATEGORIES, 'F')

    # charts
    label(ws, type_head - 1, 9, 13, 'EXECUTION STATUS')
    dn = DoughnutChart(); dn.holeSize = 55
    dn.add_data(Reference(ws, min_col=5, max_col=9, min_row=tot, max_row=tot),
                from_rows=True, titles_from_data=False)
    dn.set_categories(Reference(ws, min_col=5, max_col=9, min_row=lvl_head,
                                max_row=lvl_head))
    for idx, st in enumerate(['Pass', 'Fail', 'Blocked', 'Deferred', 'Not Run']):
        pt = DataPoint(idx=idx); pt.graphicalProperties.solidFill = TONE[st][2]
        pt.graphicalProperties.line.solidFill = WHITE
        dn.series[0].dPt.append(pt)
    dn.width = 13.5; dn.height = 7.5
    ws.add_chart(dn, 'I%d' % type_head)
    bc = BarChart(); bc.type = 'col'; bc.grouping = 'stacked'; bc.overlap = 100
    bc.add_data(Reference(ws, min_col=3, max_col=5, min_row=type_head,
                          max_row=type_tot - 1), titles_from_data=True)
    bc.set_categories(Reference(ws, min_col=2, min_row=type_head + 1,
                                max_row=type_tot - 1))
    for s, color in zip(bc.series, [DEEP, RED, LINE2]):
        s.graphicalProperties.solidFill = color
        s.graphicalProperties.line.solidFill = color
    bc.x_axis.delete = False; bc.y_axis.delete = False
    bc.y_axis.majorGridlines = None; bc.legend.position = 'r'
    bc.legend.overlay = False; bc.gapWidth = 80
    bc.width = 13.5; bc.height = 7.5
    bar_row = max(cat_head, type_head + 18)
    label(ws, bar_row - 1, 9, 13, 'TEST CASES BY TYPE AND LEVEL')
    ws.add_chart(bc, 'I%d' % bar_row)
    foot = max(cat_head + len(CATEGORIES) + 2, bar_row + 16)
    ws.cell(foot, 2, 'Executed = Pass + Fail.  Pass Rate = Pass / Executed.  '
            'Not Run includes blank status.  Generated by the AppAssist Test '
            'Case Agent.').font = fnt(8, False, MUTED, True)
    finish(ws)
    ws.print_area = 'A1:M%d' % foot


def build_workbook(spec, path):
    """spec: {'project': {field: value}, 'sheets': [{'code': 'UAT'|'ST'|'SIT',
    'source': str, 'cases': [ {id, req, module, title, type, category,
    priority, pre, steps (list), data, expected} ]}], 'requirements': [{id,
    summary, source, level, dropped?}], 'clarifications': [{id, document,
    section, question, impact, dropped? (list of tests left out), answer?}]}

    Refuses (ValueError) when quality() finds generic, copied or guessed
    test case wording - rewrite those cases; never bypass this check."""
    problems = quality(spec)[0]
    if problems:
        raise ValueError('Workbook not built - %d test case problem(s):\n  %s'
                         % (len(problems), '\n  '.join(problems)))
    today = datetime.date.today()
    order = {'UAT': 0, 'ST': 1, 'SIT': 2}
    spec['sheets'] = sorted(spec['sheets'], key=lambda s: order[s['code']])
    wb = Workbook()
    pname = spec.get('project', {}).get('Project Name') or TBC
    names = [test_sheet(wb, sh, pname) for sh in spec['sheets']]
    rtm_sheet(wb, spec.get('requirements', []), names)
    clar_sheet(wb, spec.get('clarifications', []), today)
    dashboard(wb.worksheets[0], spec, names, today)
    wb.calculation.fullCalcOnLoad = True
    wb.properties.title = 'Test Cases - ' + pname
    wb.properties.creator = spec.get('project', {}).get('Prepared By') or 'AppAssist'
    wb.save(path)
    return path
