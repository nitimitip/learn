/*
   User management: client-side search and filtering over the rows already on
   the page. Progressive enhancement - with JavaScript off every account is
   still listed and every control still works, because they are plain links
   and form submissions.
*/
(function () {
  'use strict';

  var search = document.getElementById('u-search');
  var roleFilter = document.getElementById('u-role-filter');
  var statusFilter = document.getElementById('u-status-filter');
  var rows = Array.prototype.slice.call(document.querySelectorAll('#u-rows tr'));
  var noResults = document.getElementById('u-no-results');
  var count = document.getElementById('u-count');
  var results = document.getElementById('u-results');
  var reset = document.getElementById('u-reset');
  var clear = document.getElementById('u-clear');

  if (!search || !rows.length) return;

  function apply() {
    var words = search.value.toLowerCase().trim().split(/\s+/).filter(Boolean);
    var role = roleFilter.value;
    var status = statusFilter.value;
    var shown = 0;

    rows.forEach(function (row) {
      var hay = row.dataset.search.toLowerCase();
      var match = (role === 'all' || row.dataset.role === role) &&
                  (status === 'all' || row.dataset.status === status) &&
                  words.every(function (word) { return hay.indexOf(word) !== -1; });
      row.hidden = !match;
      if (match) shown++;
    });

    /* The toolbar's clear control exists only while something is filtering,
       so it never sits there as a dead button. */
    clear.hidden = !search.value && role === 'all' && status === 'all';

    noResults.hidden = shown > 0;
    count.textContent = shown === rows.length
      ? rows.length + ' shown'
      : shown + ' of ' + rows.length + ' shown';
    results.textContent = shown + (shown === 1 ? ' user' : ' users') + ' shown';
  }

  search.addEventListener('input', apply);
  roleFilter.addEventListener('change', apply);
  statusFilter.addEventListener('change', apply);

  function clearAll() {
    search.value = '';
    roleFilter.value = 'all';
    statusFilter.value = 'all';
    apply();
    search.focus();
  }
  reset.addEventListener('click', clearAll);
  clear.addEventListener('click', clearAll);

  search.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && search.value) {
      search.value = '';
      apply();
    }
  });
})();

/*
   Group / sub-group / team editor. One <dialog> serves every row; the row's
   pencil button carries the account's current values and the POST url.
   Mirrors the profile page's rules (the server enforces them regardless):
   Organization Members get the fixed org sub-group and team; Application /
   Infra need both; sub-groups come from the admin-managed list, and a value
   the account already carries stays offered even after it was retired.
*/
(function () {
  'use strict';

  var dialog = document.getElementById('u-org-dialog');
  var data = document.getElementById('u-sub-groups');
  if (!dialog || !data || typeof dialog.showModal !== 'function') return;

  var ORG_GROUP = 'guest';
  var ORG_SUB_GROUP = 'Organization';
  var ORG_TEAM = 'Organization';

  var SUB_GROUPS = JSON.parse(data.textContent || '{}');
  var form = document.getElementById('u-org-form');
  var who = document.getElementById('u-org-user');
  var group = document.getElementById('u-org-group');
  var sub = document.getElementById('u-org-sub');
  var team = document.getElementById('u-org-team');
  var help = document.getElementById('u-org-help');
  var reqMarks = dialog.querySelectorAll('.u-req');
  var current = { group: '', sub: '', team: '' };

  function option(value, label) {
    var o = document.createElement('option');
    o.value = value;
    o.textContent = label;
    return o;
  }

  function groupChanged() {
    var g = group.value;
    var isOrg = g === ORG_GROUP;
    var mandatory = g === 'application' || g === 'infra';

    sub.required = mandatory;
    team.required = mandatory;
    Array.prototype.forEach.call(reqMarks, function (m) { m.hidden = !mandatory; });
    Array.prototype.forEach.call(team.options, function (o) {
      if (o.value === ORG_TEAM) o.hidden = !isOrg;
    });

    sub.innerHTML = '';
    if (isOrg) {
      sub.appendChild(option(ORG_SUB_GROUP, ORG_SUB_GROUP));
      sub.disabled = true;
      team.value = ORG_TEAM;
      team.disabled = true;
      help.hidden = false;
      return;
    }

    team.disabled = false;
    help.hidden = true;
    if (team.value === ORG_TEAM) team.value = '';

    sub.appendChild(option('', '— Not set —'));
    var names = SUB_GROUPS[g] || [];
    names.forEach(function (name) { sub.appendChild(option(name, name)); });
    if (current.sub && g === current.group && names.indexOf(current.sub) === -1) {
      sub.appendChild(option(current.sub, current.sub + ' (retired value)'));
    }
    sub.value = g === current.group ? current.sub : '';
    if (sub.selectedIndex < 0) sub.value = '';
    sub.disabled = !g;
  }

  document.addEventListener('click', function (event) {
    var btn = event.target.closest('.u-org-edit');
    if (!btn) return;
    current = {
      group: btn.dataset.group || '',
      sub: btn.dataset.subGroup || '',
      team: btn.dataset.team || ''
    };
    form.action = btn.dataset.url;
    who.textContent = btn.dataset.username;
    group.value = current.group;
    team.value = current.team;
    groupChanged();
    dialog.showModal();
  });

  group.addEventListener('change', groupChanged);
  document.getElementById('u-org-cancel').addEventListener('click', function () {
    dialog.close();
  });

  /* Disabled selects are not posted; the server forces the org values for
     Organization Members anyway, but re-enable so the form reads honestly. */
  form.addEventListener('submit', function () {
    sub.disabled = false;
    team.disabled = false;
  });
})();
