# python3.9_v - Python 3.9 compatibility overlay

The application source targets **Python 3.12+**. Production runs **Python 3.9**.

This folder is an **overlay**, not a fork: it contains *only* the files that
actually break on 3.9, at their original paths. Deploy by copying this tree over
a checkout of the app - every file here replaces its same-named counterpart, and
everything not listed here is already 3.9-compatible and must be taken from the
root of the repo unchanged.

```
python3.9_v/
|- requirements.txt                                     (dependency pins)
|- modules/
   |- code_sentinel/engine/
   |  |- __init__.py                                    (future import)
   |  |- codesentinel/
   |     |- application.py                              (slots)
   |     |- analysis/dependencies.py                    (slots)
   |     |- analysis/languages.py                       (slots)
   |     |- analysis/scanner.py                         (slots)
   |     |- domain/models.py                            (slots x4)
   |     |- domain/scoring.py                           (slots x4)
   |     |- infrastructure/repositories.py              (slots x2)
   |     |- plugins/api.py                              (slots)
   |     |- plugins/manager.py                          (slots)
   |     |- reporting/base.py                           (slots)
   |- project_management/routes.py                      (future import)
```

12 source files out of 264. Deploy:

```powershell
robocopy python3.9_v <app-dir> /E      # overlay onto the deployed app
pip install -r python3.9_v\requirements.txt
```

---

## What breaks on 3.9, and the fix

### 1. `@dataclass(slots=True)` - 17 occurrences, 10 files

`slots=` was added to `dataclasses.dataclass` in **3.10**. On 3.9 this raises
`TypeError: dataclass() got an unexpected keyword argument 'slots'` at *import*
time, so the whole Code Sentinel engine fails to load.

Fix: drop `slots=True`, keep every other argument.

```python
@dataclass(frozen=True, slots=True)   ->   @dataclass(frozen=True)
@dataclass(slots=True)                ->   @dataclass
```

`slots=True` is a memory optimisation. Removing it changes no semantics the app
relies on: `frozen=` still enforces immutability, `__eq__`/`__hash__`/`fields()`
are unaffected. The only difference is that instances gain a `__dict__` (so
undeclared attributes could be set) - nothing in the codebase does that.

### 2. PEP 604 unions (`X | Y`) evaluated at import time - 2 files

`int | None` as a *runtime* expression requires **3.10** (`TypeError:
unsupported operand type(s) for |: 'type' and 'NoneType'` on 3.9).

Function annotations are evaluated when the `def` executes - **unless** the
module has `from __future__ import annotations`, which stores them as strings
and never evaluates them.

98 of the app's files already have that future import, so their `X | Y`
annotations are inert strings and **already run on 3.9 as-is**. Only two files
use `X | Y` *without* it:

| file | union annotation sites |
|---|---|
| `modules/code_sentinel/engine/__init__.py` | 8 (`set \| None`, `int \| None`, `dict \| None`) |
| `modules/project_management/routes.py` | 1 (`-> str \| None`) |

Fix: add `from __future__ import annotations` after the module docstring - the
same one-line convention the other 98 files already use. No annotation bodies
were rewritten.

This is safe **only because nothing in the app ever evaluates annotations at
runtime**: there is no `pydantic`, no `typing.get_type_hints()`, no
`attrs`. (`@dataclass` itself does not evaluate them - it only string-matches
`ClassVar` / `InitVar`.) **If you ever introduce pydantic or `get_type_hints()`,
this shortcut stops working** and those annotations must be rewritten to
`Optional[...]` / `Union[...]` instead.

### 3. `requirements.txt` - 10 packages cannot be used as pinned

Four scientific packages declare `Requires-Python >= 3.10`/`>= 3.11`;
`pip install` fails outright with *"No matching distribution found"*. Re-pinned
to the newest release that still ships a **cp39** wheel:

| package | root (3.12+) | this file (3.9) | why |
|---|---|---|---|
| pandas | 3.0.3 | **2.3.3** | pandas 3.x requires >= 3.11 |
| numpy | 2.4.6 | **2.0.2** | numpy 2.1+ requires >= 3.10 |
| scipy | 1.17.1 | **1.13.1** | scipy 1.14+ requires >= 3.10 |
| scikit-learn | 1.8.0 | **1.6.1** | sklearn 1.7+ requires >= 3.10 |

The tree-sitter stack has a second, sharper constraint. **0.23.2 is the newest
tree-sitter core with a cp39 wheel**, and that runtime accepts grammar Language
ABI 13-14 only. A grammar published for ABI 15 installs perfectly and then
fails at *runtime*:

```
ValueError: Incompatible Language version 15. Must be between 13 and 14
```

So each grammar below is the newest release that is **both cp39-installable and
ABI <= 14**. Every one was verified by loading it and parsing real source on
CPython 3.9.25 - do not bump them to match the root file.

| package | root (3.12+) | this file (3.9) | why |
|---|---|---|---|
| tree-sitter | 0.26.0 | **0.23.2** | 0.24+ needs >= 3.10 |
| tree-sitter-javascript | 0.25.0 | **0.23.1** | 0.25 wheel is cp310-abi3 |
| tree-sitter-typescript | 0.23.2 | 0.23.2 | cp39-abi3, unchanged |
| tree-sitter-java | 0.23.5 | 0.23.5 | cp39-abi3, unchanged |
| tree-sitter-c-sharp | 0.23.5 | **0.23.1** | 0.23.5 wheel is cp310-abi3 |
| tree-sitter-go | 0.25.0 | **0.23.4** | 0.25 ships no cp39 wheel |
| tree-sitter-rust | 0.24.2 | **0.23.2** | 0.23.3+ grammars are ABI 15 |
| tree-sitter-kotlin | 1.1.0 | 1.1.0 | cp39-abi3, ABI 14, unchanged |
| tree-sitter-swift | 0.7.3 | **0.0.1** | 0.7.x grammars are ABI 15 |

`tree-sitter-swift==0.0.1` is the official `tree-sitter/tree-sitter-swift`
package (MIT); its version number simply does not track the grammar. It parses
real Swift correctly and is the only published build at ABI 14.

Every other pin (Flask 3.1.3, Werkzeug 3.1.8, SQLAlchemy 2.0.50, lxml 6.1.1,
openpyxl 3.1.5, plotly 6.7.0, lightgbm 4.6.0, joblib 1.5.3, reportlab <5.1) is
unchanged and verified to resolve on 3.9.

> **Retrain / re-verify the ML artefacts.** Any model pickled with
> scikit-learn 1.8 / numpy 2.4 may not load under 1.6.1 / 2.0.2. Regenerate the
> `service_now_analysis` artefacts on the 3.9 stack rather than shipping the ones
> built on 3.13.

---

## Known limitations on 3.9

These are consequences of the 0.23.2 tree-sitter ceiling. They are behavioural,
not crashes, and there is no fix available inside the overlay.

**`QRY-GO001` cannot run.** Its query matches
`(for_statement (block (statement_list (defer_statement) @finding)))`.
`statement_list` is an intermediate node that exists only in the Go grammar from
0.25 onwards; under 0.23.4 the query fails to compile and the engine reports
its own reliability finding instead:

```
PARSE-QUERY (HIGH): Query rule QRY-GO001 could not compile;
                    analysis coverage is incomplete.
```

That finding appears on **every Go file scanned**. The two grammars are
mutually exclusive here - `(for_statement (block (defer_statement) @finding))`
compiles on 0.23.4 and is an "Impossible pattern" on 0.25 - so no single query
serves both. **On the 3.9 deployment, add `QRY-GO001` to the disabled rule IDs
in Code Sentinel settings** so reports are not polluted. Every other query
rule compiles and runs correctly.

**`#any-of?` predicates are not evaluated.** The 0.23 binding applies `#eq?`
(so `GO-C001`, `RS-Q001` and `QRY-SW001` behave exactly as they do on 3.12) but
silently ignores `#any-of?`, returning unfiltered captures. No shipped rule uses
`#any-of?` today. **Do not add one while production runs 3.9** - it will
over-fire rather than fail visibly.

**C# query rules, re-verified 21 September 2026.** The .NET coverage pass added
`QRY-CS003` (self-assignment), `QRY-CS004` (identical branches), `QRY-CS005`
(self-comparison) and `QRY-CS006` (lock on a string literal). Three of them use
`#eq?` and `QRY-CS005` also uses an anonymous-node alternation
(`operator: ["==" "!="]`). All six C# query rules were run on CPython 3.9.25
against tree-sitter 0.23.2 / tree-sitter-c-sharp 0.23.1 with the overlay
applied: each one compiles, matches its unsafe case and - critically - does NOT
match its safe case, so the predicates really are filtering rather than
returning unfiltered captures. Re-run that check whenever a C# query rule is
added; a predicate that silently stops filtering turns a precise rule into one
that fires on every assignment or comparison in the codebase.

---

## What was checked and found clean

Verified across all 264 `.py` files, so you don't have to re-check:

- **Syntax** - every file parses under a 3.9 grammar (`ast.parse(feature_version=(3,9))`).
  No `match` statements, no `except*`, no PEP 695 generics.
- **f-strings** - no PEP 701 (3.12) constructs: no nested same-quote f-strings,
  no backslashes inside f-string expressions.
- **stdlib** - no `tomllib`, `datetime.UTC`, `enum.StrEnum`, `itertools.pairwise`,
  `typing.Self` / `TypeAlias` / `override`, `zip(strict=)`, `int.bit_count()`.
- **`X | Y` type aliases** outside annotations (which a future import would *not*
  rescue) - none.
- **`datetime.fromisoformat`** - 3.9 cannot parse a `Z` suffix. Every call site is
  either a plain `date.fromisoformat`, a round-trip of `.isoformat()` output, or
  already normalises `Z` -> `+00:00`. No change needed.
- **`web.config`** - uses `<<PYTHON_EXE>>` placeholders, so it is version-agnostic.
  Point it at the 3.9 interpreter at deploy time; no 3.9-specific copy is needed.

Note that `artifacts/` holds review baselines and vendored test dependencies.
Those trees do contain 3.10+ syntax, they are correctly *not* overlaid, and the
guard test skips them - see `SKIP_DIRS` in `tests/test_py39_overlay.py`.

## Verification status

Last verified 2026-09-17 against a real CPython 3.9.25 interpreter:

- All 12 overlay files compile under a 3.9 interpreter.
- The overlaid `codesentinel` package imports and completes a real scan on 3.9,
  including the three behaviours a stale overlay had been dropping:
  `QualityGateConfig`'s assurance fields, `ReportContext.gate_scope` /
  `.evaluation_note`, and `Finding.__post_init__` OWASP-key canonicalisation.
- All 8 tree-sitter grammars load and parse real source on 3.9.
- `pytest tests/test_py39_overlay.py` - 6 passed.

## Keeping this overlay in sync

> **This has bitten production once.** The waiver/`triage_details` work landed
> in `modules/code_sentinel/engine/__init__.py` but not in this overlay's copy.
> Because the overlay file is what actually runs on 3.9, report downloads died
> with `TypeError: export_payload() got an unexpected keyword argument
> 'triage_details'` while every test passed on the 3.12 tree. **A stale overlay
> file is a production outage that CI cannot see** unless something compares the
> two copies - which `tests/test_py39_overlay.py` now does.

`tests/test_py39_overlay.py` enforces the rules below automatically:

- **API parity** - every overlaid file must expose the same functions,
  signatures, classes, methods and module constants as its root counterpart
  (annotations excluded, since rewriting those is the point). This is the check
  that catches a stale copy.
- **3.9 safety** - every overlaid file parses under a 3.9 grammar, passes no
  `slots=`/`kw_only=` to a dataclass, and never evaluates a PEP 604 union.
- **Coverage** - the inverse: a *root* file that needs a 3.9 edit but has no
  overlay copy fails the suite, so new 3.10+ syntax cannot land unnoticed.
- **Requirements parity** - the overlay's `requirements.txt` must name every
  package the root file names. Versions are expected to differ; a *missing*
  package is simply absent in production. Four tree-sitter grammars went missing
  exactly this way.

Both 3.9 checks read the AST, not the file text, so an `X | None` in a docstring
or a `slots=True` inside a string literal is correctly ignored.

When editing the app, this overlay only needs updating if you touch one of the
12 files above, or if you introduce:

- `@dataclass(slots=True)` or `kw_only=True`
- `X | Y` annotations in a file **without** `from __future__ import annotations`
- `match` statements, or any 3.10+ stdlib API
- a new third-party dependency (add it to both requirements files)

Prefer writing 3.9-safe code in the root tree (add the future import, skip
`slots=`) so this overlay can stay small.

**When you do update an overlay file: re-copy the root file and re-apply only
the 3.9 edit.** Overlay files must never carry their own logic. Preserve the
root file's line endings - the tree is mixed CRLF/LF, and `read_text` /
`write_text` silently normalise to LF, which makes the whole file look changed.
