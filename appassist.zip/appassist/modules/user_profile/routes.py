"""
User Profile module - routes.

* /profile/                    - my profile: edit name, surname, email, group,
                                 sub-group, team; pick technical and soft
                                 skills; change password (own account).
* /profile/update              - save the profile details form.
* /profile/skills              - save the technical / soft skill selection.
* /profile/password            - change the signed-in user's password.
* /profile/admin/users/<id>/organization
                               - admin: set another user's group, sub-group
                                 and team (posted from User management).
* /profile/admin/sub-groups    - admin page: add / rename / delete the
                                 sub-group values offered per user group.
* /profile/admin/soft-skills   - admin page: add / rename / delete the
                                 soft-skill values offered on every profile.

Only the signed-in user can edit their own profile (an admin may also change
anyone's group / sub-group / team); both reference lists are admin-only. Renaming a value also updates the users currently carrying it
(the user/skill row stores the name as text); deleting one leaves those
users' stored text untouched so nothing breaks.

Technical skills are NOT a list this module owns - they are the Application
Support Technology Catalog, read live, so people and applications describe
technology with the same words.
"""

import logging

from flask import (Blueprint, flash, redirect, render_template, request,
                   url_for)
from sqlalchemy import func

from auth import get_current_user
from csrf_utils import csrf_protect
from database import get_db_session
from models import User

from .models import (NO_CATEGORY, ORG_MEMBER_GROUP, ORG_SUB_GROUP, ORG_TEAM,
                     SKILL_SOFT, SKILL_TECHNICAL,
                     USER_GROUPS, USER_GROUP_LABELS, USER_TEAMS,
                     SoftSkill, UserSkill, UserSubGroup,
                     ensure_soft_skills_seeded, ensure_sub_groups_seeded,
                     load_user_skills, replace_user_skills, skill_key,
                     soft_skill_names, sub_groups_by_group)

logger = logging.getLogger(__name__)

user_profile_bp = Blueprint(
    'user_profile', __name__,
    template_folder='../../templates/user_profile',
)


# ---------------------------------------------------------------------------
# Group / sub-group / team rules (shared by "my profile" and the admin edit)
# ---------------------------------------------------------------------------

def validate_org_fields(db_session, group, sub_group, team,
                        current_group, current_sub_group):
    """Validate and normalise a group / sub-group / team selection.

    Returns ``(group, sub_group, team)`` ready to store ('' = not set), or
    raises ValueError with the message to flash. ``current_group`` and
    ``current_sub_group`` are what the account carries today: keeping that
    sub-group is always allowed, even after an admin retired it from the list
    (deleting a list value must never invalidate the users who carry it).
    """
    group = (group or '').strip().lower()
    sub_group = (sub_group or '').strip()
    team = (team or '').strip()

    if group and group not in USER_GROUPS:
        raise ValueError('Invalid group selection.')

    # Organization Members always carry the fixed org sub-group and team -
    # whatever the form submitted (the form's fields are locked, but the
    # server never trusts that). Applies to first-time setup and edits alike.
    if group == ORG_MEMBER_GROUP:
        sub_group = ORG_SUB_GROUP
        team = ORG_TEAM

    if team and team not in USER_TEAMS:
        raise ValueError('Invalid team selection.')
    if team == ORG_TEAM and group != ORG_MEMBER_GROUP:
        raise ValueError('The Organization team is reserved for '
                         'Organization Members.')

    # Application / Infra users must specify both a sub-group and a team
    # (Organization Members are exempt - their values are forced above).
    if group in ('application', 'infra') and (not sub_group or not team):
        raise ValueError('Please select a sub-group and a team for the '
                         'chosen group.')

    # A sub-group must belong to the chosen group's offered values. No group
    # -> no sub-group. Organization Members skip the list lookup: their
    # sub-group is the fixed value forced above.
    if group == ORG_MEMBER_GROUP:
        pass
    elif group and sub_group:
        unchanged = (group == (current_group or '')
                     and sub_group == (current_sub_group or ''))
        valid = unchanged or (db_session.query(UserSubGroup)
                              .filter_by(user_group=group, name=sub_group)
                              .first())
        if not valid:
            raise ValueError('Invalid sub-group for the chosen group.')
    else:
        sub_group = ''

    return group, sub_group, team


# ---------------------------------------------------------------------------
# My profile
# ---------------------------------------------------------------------------

@user_profile_bp.route('/')
def profile():
    user = get_current_user()
    if not user:
        flash('Please login to view your profile.', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        ensure_sub_groups_seeded(db_session)
        ensure_soft_skills_seeded(db_session)
        sub_groups = sub_groups_by_group(db_session)
        skills = build_skill_picker(db_session, user.id)
    finally:
        db_session.close()

    return render_template(
        'user_profile/profile.html',
        user=user,
        user_groups=USER_GROUPS,
        user_group_labels=USER_GROUP_LABELS,
        user_teams=USER_TEAMS,
        sub_groups=sub_groups,
        skills=skills,
    )


@user_profile_bp.route('/update', methods=['POST'])
@csrf_protect
def update_profile():
    user = get_current_user()
    if not user:
        flash('Please login to update your profile.', 'error')
        return redirect(url_for('login'))

    firstname = (request.form.get('firstname') or '').strip()
    lastname  = (request.form.get('lastname') or '').strip()
    email     = (request.form.get('email') or '').strip()
    group     = (request.form.get('user_group') or '').strip().lower()
    sub_group = (request.form.get('sub_group') or '').strip()
    team      = (request.form.get('team') or '').strip()

    if not firstname or not lastname or not email:
        flash('Name, surname and email are required.', 'error')
        return redirect(url_for('user_profile.profile'))
    if '@' not in email or '.' not in email.split('@')[-1]:
        flash('Please enter a valid email address.', 'error')
        return redirect(url_for('user_profile.profile'))

    db_session = get_db_session()
    try:
        try:
            group, sub_group, team = validate_org_fields(
                db_session, group, sub_group, team,
                user.user_group, user.sub_group)
        except ValueError as e:
            flash(str(e), 'error')
            return redirect(url_for('user_profile.profile'))

        # Email must stay unique across accounts (case-insensitive).
        clash = (db_session.query(User)
                 .filter(func.lower(User.email) == email.lower(),
                         User.id != user.id).first())
        if clash:
            flash('That email address is already used by another account.', 'error')
            return redirect(url_for('user_profile.profile'))

        db_user = db_session.query(User).filter_by(id=user.id).first()
        db_user.firstname  = firstname
        db_user.lastname   = lastname
        db_user.email      = email
        db_user.user_group = group or None
        db_user.sub_group  = sub_group or None
        db_user.team       = team or None
        db_session.commit()
        flash('Profile updated successfully.', 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error updating profile for user %s: %s', user.username, e)
        flash('An error occurred while updating your profile.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('user_profile.profile'))


@user_profile_bp.route('/password', methods=['POST'])
@csrf_protect
def change_my_password():
    """Change the signed-in user's password (same rules as /change-password)."""
    user = get_current_user()
    if not user:
        flash('Please login to change your password.', 'error')
        return redirect(url_for('login'))

    current_password = request.form.get('current_password')
    new_password = request.form.get('new_password')
    confirm_new_password = request.form.get('confirm_new_password')

    if not all([current_password, new_password, confirm_new_password]):
        flash('All password fields are required.', 'error')
    elif not user.check_password(current_password):
        flash('Incorrect current password.', 'error')
    elif new_password != confirm_new_password:
        flash('New passwords do not match.', 'error')
    elif len(new_password) < 6:
        flash('Password must be at least 6 characters long.', 'error')
    else:
        db_session = get_db_session()
        try:
            db_user = db_session.query(User).filter_by(id=user.id).first()
            db_user.set_password(new_password)
            db_session.commit()
            flash('Password changed successfully.', 'success')
        except Exception as e:
            db_session.rollback()
            logger.exception('Error changing password for user %s: %s',
                             user.username, e)
            flash('An error occurred while changing your password.', 'error')
        finally:
            db_session.close()

    return redirect(url_for('user_profile.profile'))


# ---------------------------------------------------------------------------
# Admin: change another user's group / sub-group / team
# ---------------------------------------------------------------------------

@user_profile_bp.route('/admin/users/<int:user_id>/organization',
                       methods=['POST'])
@csrf_protect
def admin_update_user_org(user_id):
    """Set a user's group, sub-group and team from User management.

    Same rules as the user's own profile form (validate_org_fields); only the
    three organization fields change - name, email and skills stay the user's.
    """
    admin = _require_admin()
    if not admin:
        return redirect(url_for('index'))

    db_session = get_db_session()
    try:
        target = db_session.query(User).filter_by(id=user_id).first()
        if not target:
            flash('User not found.', 'error')
            return redirect(url_for('admin_users'))
        try:
            group, sub_group, team = validate_org_fields(
                db_session,
                request.form.get('user_group'),
                request.form.get('sub_group'),
                request.form.get('team'),
                target.user_group, target.sub_group)
        except ValueError as e:
            flash('{0} ({1})'.format(e, target.username), 'error')
            return redirect(url_for('admin_users'))

        target.user_group = group or None
        target.sub_group = sub_group or None
        target.team = team or None
        db_session.commit()
        logger.info('Admin %s set group/sub-group/team of %s to %r/%r/%r',
                    admin.username, target.username, group, sub_group, team)
        flash('Group, sub-group and team updated for {0}.'
              .format(target.username), 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error updating organization for user_id=%s: %s',
                         user_id, e)
        flash('An error occurred while updating the user.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('admin_users'))


# ---------------------------------------------------------------------------
# Admin: manage the sub-group values offered per user group
# ---------------------------------------------------------------------------

def _require_admin():
    """Current user if admin, else None (caller redirects)."""
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required.', 'error')
        return None
    return user


@user_profile_bp.route('/admin/sub-groups')
def admin_sub_groups():
    user = _require_admin()
    if not user:
        return redirect(url_for('index'))

    db_session = get_db_session()
    try:
        ensure_sub_groups_seeded(db_session)
        rows = (db_session.query(UserSubGroup)
                .order_by(UserSubGroup.user_group, UserSubGroup.name)
                .all())
        grouped = {g: [] for g in USER_GROUPS}
        for r in rows:
            grouped.setdefault(r.user_group, []).append(r)
        # How many users currently carry each value (shown as a hint).
        usage = dict(db_session.query(User.sub_group, func.count(User.id))
                     .filter(User.sub_group.isnot(None))
                     .group_by(User.sub_group).all())
    finally:
        db_session.close()

    return render_template(
        'user_profile/sub_groups.html',
        user=user, grouped=grouped, usage=usage,
        user_groups=USER_GROUPS, user_group_labels=USER_GROUP_LABELS,
    )


@user_profile_bp.route('/admin/sub-groups/add', methods=['POST'])
@csrf_protect
def add_sub_group():
    user = _require_admin()
    if not user:
        return redirect(url_for('index'))

    group = (request.form.get('user_group') or '').strip().lower()
    name  = (request.form.get('name') or '').strip()
    if group not in USER_GROUPS or not name:
        flash('A group and a sub-group name are required.', 'error')
        return redirect(url_for('user_profile.admin_sub_groups'))

    db_session = get_db_session()
    try:
        exists = (db_session.query(UserSubGroup)
                  .filter(UserSubGroup.user_group == group,
                          func.lower(UserSubGroup.name) == name.lower())
                  .first())
        if exists:
            flash(f"'{exists.name}' already exists under "
                  f"{USER_GROUP_LABELS[group]}.", 'error')
        else:
            db_session.add(UserSubGroup(user_group=group, name=name))
            db_session.commit()
            flash(f"Sub-group '{name}' added under {USER_GROUP_LABELS[group]}.",
                  'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error adding sub-group: %s', e)
        flash('An error occurred while adding the sub-group.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('user_profile.admin_sub_groups'))


@user_profile_bp.route('/admin/sub-groups/<int:sub_id>/edit', methods=['POST'])
@csrf_protect
def edit_sub_group(sub_id):
    user = _require_admin()
    if not user:
        return redirect(url_for('index'))

    new_name = (request.form.get('name') or '').strip()
    if not new_name:
        flash('The sub-group name cannot be empty.', 'error')
        return redirect(url_for('user_profile.admin_sub_groups'))

    db_session = get_db_session()
    try:
        row = db_session.query(UserSubGroup).filter_by(id=sub_id).first()
        if not row:
            flash('Sub-group not found.', 'error')
            return redirect(url_for('user_profile.admin_sub_groups'))
        clash = (db_session.query(UserSubGroup)
                 .filter(UserSubGroup.user_group == row.user_group,
                         func.lower(UserSubGroup.name) == new_name.lower(),
                         UserSubGroup.id != row.id)
                 .first())
        if clash:
            flash(f"'{clash.name}' already exists under "
                  f"{USER_GROUP_LABELS[row.user_group]}.", 'error')
            return redirect(url_for('user_profile.admin_sub_groups'))

        old_name = row.name
        row.name = new_name
        # Keep the users carrying the old value in step with the rename.
        moved = (db_session.query(User)
                 .filter(User.user_group == row.user_group,
                         User.sub_group == old_name)
                 .update({User.sub_group: new_name},
                         synchronize_session=False))
        db_session.commit()
        msg = f"Sub-group renamed to '{new_name}'."
        if moved:
            msg += f' {moved} user(s) updated.'
        flash(msg, 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error renaming sub-group %s: %s', sub_id, e)
        flash('An error occurred while renaming the sub-group.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('user_profile.admin_sub_groups'))


@user_profile_bp.route('/admin/sub-groups/<int:sub_id>/delete', methods=['POST'])
@csrf_protect
def delete_sub_group(sub_id):
    user = _require_admin()
    if not user:
        return redirect(url_for('index'))

    db_session = get_db_session()
    try:
        row = db_session.query(UserSubGroup).filter_by(id=sub_id).first()
        if not row:
            flash('Sub-group not found.', 'error')
        else:
            name, group = row.name, row.user_group
            db_session.delete(row)
            db_session.commit()
            # Users keep their stored text; it is simply no longer offered.
            flash(f"Sub-group '{name}' removed from "
                  f"{USER_GROUP_LABELS[group]}. Users who had it keep the "
                  f"value on their profile until they change it.", 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error deleting sub-group %s: %s', sub_id, e)
        flash('An error occurred while deleting the sub-group.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('user_profile.admin_sub_groups'))


# ---------------------------------------------------------------------------
# Skills - technical (from the Application Support Technology Catalog) and
# soft (from the admin-managed list in this module)
# ---------------------------------------------------------------------------

# A technical skill the user holds whose catalog value is no longer offered
# is still rendered, pre-ticked, under this token so saving the form never
# silently strips it. 'x:' marks "carried value", then the category, then the
# stored name (categories never contain a colon).
CARRIED_PREFIX = 'x:'


def _tech_catalog():
    """
    The Application Support Technology Catalog helpers.

    Imported at CALL time, not module import time: the profile module is
    registered before Application Support in main_app, and a top-level import
    would tie the two blueprints' import order together for no benefit.
    """
    from modules.application_support import tech_details
    return tech_details


def _carried_token(category, name):
    return '{0}{1}:{2}'.format(CARRIED_PREFIX, category or '', name)


def _parse_carried_token(token):
    """('category', 'name') from a carried-value token, or (None, None)."""
    if not token.startswith(CARRIED_PREFIX):
        return None, None
    rest = token[len(CARRIED_PREFIX):]
    category, _, name = rest.partition(':')
    if not name.strip():
        return None, None
    return category.strip(), name.strip()


def build_skill_picker(db_session, user_id):
    """
    Everything the profile form needs to render both skill pickers.

    Technical options are the ACTIVE catalog entries grouped by category.
    Anything the user already holds that is no longer on offer - a retired
    catalog entry, or one deleted outright - is returned separately as a
    "carried" option so it stays visible and stays ticked.
    """
    tech_details = _tech_catalog()
    held = load_user_skills(db_session, user_id)

    held_technical = {}
    for row in held[SKILL_TECHNICAL]:
        held_technical[(row.category or NO_CATEGORY,
                        skill_key(row.item_name))] = row
    held_soft = dict((skill_key(row.item_name), row)
                     for row in held[SKILL_SOFT])

    offered_technical = set()
    categories = []
    for key in tech_details.TECH_CATEGORIES:
        label, plural, icon = tech_details.CATEGORY_META[key]
        options = []
        for entry in tech_details.catalog_options(db_session).get(key, []):
            fold = skill_key(entry.name)
            offered_technical.add((key, fold))
            options.append({
                'value': str(entry.id),
                'name': entry.name,
                'checked': (key, fold) in held_technical,
            })
        categories.append({
            'key': key, 'label': label, 'plural': plural, 'icon': icon,
            'options': options,
        })

    carried_technical = []
    for (category, fold), row in sorted(held_technical.items()):
        if (category, fold) in offered_technical:
            continue
        meta = tech_details.CATEGORY_META.get(category)
        carried_technical.append({
            'value': _carried_token(category, row.item_name),
            'name': row.item_name,
            'category': category,
            'category_label': meta[0] if meta else 'Other',
            'checked': True,
        })

    offered_soft = soft_skill_names(db_session)
    offered_soft_keys = set(skill_key(name) for name in offered_soft)
    soft_options = [{'value': name, 'name': name,
                     'checked': skill_key(name) in held_soft}
                    for name in offered_soft]
    carried_soft = [{'value': row.item_name, 'name': row.item_name,
                     'checked': True}
                    for fold, row in sorted(held_soft.items())
                    if fold not in offered_soft_keys]

    return {
        'categories': categories,
        'carried_technical': carried_technical,
        'soft_options': soft_options,
        'carried_soft': carried_soft,
        'technical_count': len(held[SKILL_TECHNICAL]),
        'soft_count': len(held[SKILL_SOFT]),
        'catalog_empty': not offered_technical,
        'soft_empty': not offered_soft,
    }


def resolve_submitted_skills(db_session, user_id, tech_values, soft_values):
    """
    Turn the posted checkbox values into storable skill entries.

    Every value is resolved against the server's own data - a catalog id is
    looked up, and a carried value is accepted ONLY when the user already
    holds it. Nothing the browser posts becomes a skill name on its own, so
    a hand-crafted POST cannot write free text into the skill list.
    """
    from modules.application_support.models import TechCatalog

    held = load_user_skills(db_session, user_id)
    held_technical = set((row.category or NO_CATEGORY, skill_key(row.item_name))
                         for row in held[SKILL_TECHNICAL])
    held_soft = set(skill_key(row.item_name) for row in held[SKILL_SOFT])

    catalog_ids = []
    carried = []
    for raw in tech_values:
        value = (raw or '').strip()
        if not value:
            continue
        if value.startswith(CARRIED_PREFIX):
            category, name = _parse_carried_token(value)
            if name and (category or NO_CATEGORY, skill_key(name)) in held_technical:
                carried.append({'category': category, 'name': name,
                                'catalog_id': None})
            continue
        if value.isdigit():
            catalog_ids.append(int(value))

    technical = []
    if catalog_ids:
        rows = (db_session.query(TechCatalog)
                .filter(TechCatalog.id.in_(catalog_ids)).all())
        for row in rows:
            technical.append({'category': row.category, 'name': row.name,
                              'catalog_id': row.id})
    technical.extend(carried)

    offered_soft = set(skill_key(name) for name in soft_skill_names(db_session))
    soft = []
    for raw in soft_values:
        name = (raw or '').strip()
        fold = skill_key(name)
        if fold and (fold in offered_soft or fold in held_soft):
            soft.append(name)

    return technical, soft


@user_profile_bp.route('/skills', methods=['POST'])
@csrf_protect
def update_skills():
    """Save the signed-in user's technical and soft skill selection."""
    user = get_current_user()
    if not user:
        flash('Please login to update your skills.', 'error')
        return redirect(url_for('login'))

    tech_values = request.form.getlist('tech_skill')
    soft_values = request.form.getlist('soft_skill')

    db_session = get_db_session()
    try:
        technical, soft = resolve_submitted_skills(
            db_session, user.id, tech_values, soft_values)
        result = replace_user_skills(db_session, user.id, technical, soft)
        db_session.commit()
        total = len(technical) + len(soft)
        if result['added'] or result['removed']:
            flash('Skills updated - {0} recorded ({1} added, {2} removed).'
                  .format(total, result['added'], result['removed']), 'success')
        else:
            flash('Skills saved - no changes.', 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error updating skills for user %s: %s',
                         user.username, e)
        flash('An error occurred while updating your skills.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('user_profile.profile') + '#skills')


# ---------------------------------------------------------------------------
# Admin: manage the soft-skill values offered on every profile
#
# Same shape and the same rules as the sub-group list above: renaming a value
# carries the users holding it along with it, and deleting one only takes it
# off the list - the people who recorded it keep it.
# ---------------------------------------------------------------------------

@user_profile_bp.route('/admin/soft-skills')
def admin_soft_skills():
    user = _require_admin()
    if not user:
        return redirect(url_for('index'))

    db_session = get_db_session()
    try:
        ensure_soft_skills_seeded(db_session)
        rows = (db_session.query(SoftSkill)
                .order_by(SoftSkill.sort_order, SoftSkill.name).all())
        # How many people currently hold each value (shown as a hint).
        counts = dict(db_session.query(UserSkill.item_name,
                                       func.count(UserSkill.id))
                      .filter(UserSkill.skill_type == SKILL_SOFT)
                      .group_by(UserSkill.item_name).all())
        # Keyed by row id so the template never has to re-fold a name.
        # Folded matching, so a value people recorded under a different
        # casing still counts against the row it belongs to.
        folded = {}
        for name, total in counts.items():
            folded[skill_key(name)] = folded.get(skill_key(name), 0) + total
        usage = dict((row.id, folded.get(skill_key(row.name), 0))
                     for row in rows)
        # Values people hold that are no longer offered - shown so an admin
        # can see what a past deletion left behind and re-add it if wanted.
        offered = set(skill_key(row.name) for row in rows)
        orphans = sorted((name, total) for name, total in counts.items()
                         if skill_key(name) not in offered)
    finally:
        db_session.close()

    return render_template(
        'user_profile/soft_skills.html',
        user=user, rows=rows, usage=usage, orphans=orphans,
    )


@user_profile_bp.route('/admin/soft-skills/add', methods=['POST'])
@csrf_protect
def add_soft_skill():
    user = _require_admin()
    if not user:
        return redirect(url_for('index'))

    name = (request.form.get('name') or '').strip()
    if not name:
        flash('A soft-skill name is required.', 'error')
        return redirect(url_for('user_profile.admin_soft_skills'))

    db_session = get_db_session()
    try:
        exists = (db_session.query(SoftSkill)
                  .filter(func.lower(SoftSkill.name) == name.lower()).first())
        if exists:
            flash("'{0}' is already on the list.".format(exists.name), 'error')
        else:
            last = (db_session.query(func.max(SoftSkill.sort_order)).scalar()
                    or 0)
            db_session.add(SoftSkill(name=name, sort_order=last + 10))
            db_session.commit()
            flash("Soft skill '{0}' added.".format(name), 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error adding soft skill: %s', e)
        flash('An error occurred while adding the soft skill.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('user_profile.admin_soft_skills'))


@user_profile_bp.route('/admin/soft-skills/<int:skill_id>/edit',
                       methods=['POST'])
@csrf_protect
def edit_soft_skill(skill_id):
    user = _require_admin()
    if not user:
        return redirect(url_for('index'))

    new_name = (request.form.get('name') or '').strip()
    if not new_name:
        flash('The soft-skill name cannot be empty.', 'error')
        return redirect(url_for('user_profile.admin_soft_skills'))

    db_session = get_db_session()
    try:
        row = db_session.query(SoftSkill).filter_by(id=skill_id).first()
        if not row:
            flash('Soft skill not found.', 'error')
            return redirect(url_for('user_profile.admin_soft_skills'))
        clash = (db_session.query(SoftSkill)
                 .filter(func.lower(SoftSkill.name) == new_name.lower(),
                         SoftSkill.id != row.id).first())
        if clash:
            flash("'{0}' is already on the list.".format(clash.name), 'error')
            return redirect(url_for('user_profile.admin_soft_skills'))

        old_name = row.name
        row.name = new_name
        # Keep the people holding the old value in step with the rename.
        moved = (db_session.query(UserSkill)
                 .filter(UserSkill.skill_type == SKILL_SOFT,
                         UserSkill.item_name == old_name)
                 .update({UserSkill.item_name: new_name},
                         synchronize_session=False))
        db_session.commit()
        msg = "Soft skill renamed to '{0}'.".format(new_name)
        if moved:
            msg += ' {0} profile(s) updated.'.format(moved)
        flash(msg, 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error renaming soft skill %s: %s', skill_id, e)
        flash('An error occurred while renaming the soft skill.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('user_profile.admin_soft_skills'))


@user_profile_bp.route('/admin/soft-skills/<int:skill_id>/delete',
                       methods=['POST'])
@csrf_protect
def delete_soft_skill(skill_id):
    user = _require_admin()
    if not user:
        return redirect(url_for('index'))

    db_session = get_db_session()
    try:
        row = db_session.query(SoftSkill).filter_by(id=skill_id).first()
        if not row:
            flash('Soft skill not found.', 'error')
        else:
            name = row.name
            db_session.delete(row)
            db_session.commit()
            # People keep their recorded skill; it is simply no longer
            # offered to anyone who does not already have it.
            flash("Soft skill '{0}' removed from the list. People who "
                  "recorded it keep it on their profile until they change "
                  "it.".format(name), 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error deleting soft skill %s: %s', skill_id, e)
        flash('An error occurred while deleting the soft skill.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('user_profile.admin_soft_skills'))
