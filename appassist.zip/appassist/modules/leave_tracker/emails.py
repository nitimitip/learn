"""
emails.py - the one message the Leave Tracker sends, in three variants.

    send_leave_notice(kind='created')     a new request was saved
    send_leave_notice(kind='updated')     the owner edited it
    send_leave_notice(kind='cancelled')   the owner cancelled it, or withdrew
                                          the days still to come

WHO GETS IT. TO: the leads of every tower the requester belongs to (a person
in two towers is away from both). CC: the requester, as their receipt, and
the named backup, who is the other person who needs to know. A requester who
is themselves a lead is never sent their own notice as a lead. When nobody
leads the requester's towers there is nobody to tell; that is reported back
to the screen rather than guessed around.

The requirement only asks for the email on create. Edits and cancellations
send it too, because a lead who was told "off on the 14th" and never told
"not any more" is holding wrong information.

DESIGN follows the application's email rules (see modules/rota/emails.py and
email_theme.py): nested tables only, solid colours with a bgcolor twin,
labels pre-uppercased, and a plain-text alternative always attached. Every
piece of user text is escaped.
"""

import logging
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from email_theme import (CHIP_BG, CHIP_BORDER, CHIP_FG, FONT, NPG_BORDER,
                         NPG_DARK, NPG_INK, NPG_LIGHT, NPG_RED,
                         NPG_TEXT_MUTED, badge, button, callout, footer_rows,
                         hero_rows, section_label)

logger = logging.getLogger(__name__)

_SMTP_SERVER = os.environ.get('SMTP_SERVER', 'mail1.northernpowergrid.com')
_SMTP_PORT = int(os.environ.get('SMTP_PORT', '25'))
_EMAIL_FROM = os.environ.get('EMAIL_FROM',
                             'NPgAppAssist@northernpowergrid.com')

# Optional deep link, same convention as the rota's ROTA_APP_BASE_URL.
_BASE_URL = (os.environ.get('LEAVE_APP_BASE_URL') or '').strip().rstrip('/')

_FOOTER_LINE = 'Workforce &middot; Leave Tracker'

_COPY = {
    # (eyebrow, subject verb, opening line)
    'created': ('LEAVE REQUESTED', 'Leave request',
                '{who} has booked leave. The details are below.'),
    'updated': ('LEAVE UPDATED', 'Leave updated',
                '{who} has changed a leave request. The details below are '
                'the current ones.'),
    'cancelled': ('LEAVE CANCELLED', 'Leave cancelled',
                  '{who} has cancelled this leave. They are no longer away '
                  'on the dates shown.'),
    'withdrawn': ('LEAVE SHORTENED', 'Leave shortened',
                  '{who} has withdrawn the remaining days of this leave. The '
                  'days already taken stay on the record.'),
}


def _esc(value):
    if value is None:
        return ''
    return (str(value).replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;').replace('"', '&quot;'))


def _link(request_id=None):
    if not _BASE_URL:
        return ''
    if request_id:
        return '{0}/leave/{1}'.format(_BASE_URL, request_id)
    return '{0}/leave/'.format(_BASE_URL)


def _band(inner_html, top=24, bottom=0):
    return ('<tr><td class="px-32" style="padding:{0}px 32px {1}px 32px;">{2}'
            '</td></tr>').format(top, bottom, inner_html)


def _paragraph(text_html, size=14):
    return ('<p style="margin:0 0 12px 0;font-family:{0};font-size:{1}px;'
            'color:{2};mso-line-height-rule:exactly;line-height:22px;">{3}'
            '</p>').format(FONT, size, NPG_INK, text_html)


def _multiline_html(value):
    lines = [_esc(line.strip()) for line in str(value or '').splitlines()]
    return '<br />'.join(line for line in lines if line) or '&mdash;'


def _chip(label):
    return badge(CHIP_BG, CHIP_FG, _esc(label).upper(), CHIP_BORDER)


def _detail_table(rows):
    """Label / value rows in a bordered table - the centrepiece."""
    out = []
    for index, (label, value_html) in enumerate(rows):
        last = index == len(rows) - 1
        rule = '' if last else 'border-bottom:1px solid {0};'.format(
            NPG_BORDER)
        out.append(
            '<tr>'
            '<td width="150" valign="top" bgcolor="#F7F9FC" '
            'style="background-color:#F7F9FC;width:150px;padding:11px 14px;'
            'font-family:{font};font-size:10px;font-weight:bold;'
            'color:{muted};letter-spacing:1.1px;{rule}">{label}</td>'
            '<td valign="top" style="padding:11px 14px;font-family:{font};'
            'font-size:13px;color:{ink};{rule}mso-line-height-rule:exactly;'
            'line-height:19px;">{value}</td></tr>'.format(
                font=FONT, muted=NPG_TEXT_MUTED, ink=NPG_DARK, rule=rule,
                label=_esc(label.upper()), value=value_html))
    return ('<table role="presentation" cellpadding="0" cellspacing="0" '
            'border="0" width="100%" style="width:100%;border:1px solid {0};'
            'border-collapse:separate;border-spacing:0;border-radius:10px;'
            'overflow:hidden;">{1}</table>').format(NPG_BORDER, ''.join(out))


def _envelope(preheader, hero_html, body_html, title):
    footer = footer_rows(_FOOTER_LINE)
    return """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>NPG App Assist &mdash; {title}</title>
  <!--[if mso]>
  <xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch><o:AllowPNG/></o:OfficeDocumentSettings></xml>
  <style type="text/css">table {{border-collapse:collapse;}} td {{mso-line-height-rule:exactly;}}</style>
  <![endif]-->
  <style type="text/css">
    body, table, td {{ -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }}
    table {{ border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }}
    a {{ color:{red}; text-decoration:none; }}
    @media only screen and (max-width:620px) {{
      .container {{ width:100% !important; }}
      .px-32 {{ padding-left:18px !important; padding-right:18px !important; }}
    }}
  </style>
</head>
<body style="margin:0;padding:0;background-color:{light};font-family:{font};">
<div style="display:none;font-size:1px;color:{light};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
{preheader}
</div>
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="{light}" style="background-color:{light};">
  <tr><td align="center" style="padding:34px 16px 40px 16px;">
    <!--[if mso]><table role="presentation" align="center" cellpadding="0" cellspacing="0" border="0" width="600"><tr><td><![endif]-->
    <table role="presentation" class="container" cellpadding="0" cellspacing="0" border="0" width="600"
           style="width:600px;max-width:600px;background-color:#FFFFFF;border:1px solid {border};border-bottom-color:#C6D0DE;border-collapse:separate;border-spacing:0;border-radius:14px;">
      {hero}
      {body}
      {footer}
    </table>
    <!--[if mso]></td></tr></table><![endif]-->
  </td></tr>
</table>
</body>
</html>""".format(title=_esc(title), red=NPG_RED, light=NPG_LIGHT, font=FONT,
                  border=NPG_BORDER, preheader=_esc(preheader),
                  hero=hero_html, body=body_html, footer=footer)


def _send(to_addresses, cc_addresses, subject, html, text):
    """Send one message. Never raises."""
    to_addresses = [a for a in (to_addresses or []) if a]
    cc_addresses = [a for a in (cc_addresses or [])
                    if a and a not in to_addresses]
    if not to_addresses:
        logger.warning('Leave email %r has no recipient - skipped.', subject)
        return False
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = _EMAIL_FROM
        msg['To'] = ', '.join(to_addresses)
        if cc_addresses:
            msg['Cc'] = ', '.join(cc_addresses)
        msg.attach(MIMEText(text, 'plain', 'utf-8'))
        msg.attach(MIMEText(html, 'html', 'utf-8'))
        with smtplib.SMTP(_SMTP_SERVER, _SMTP_PORT, timeout=30) as server:
            server.send_message(msg, to_addrs=to_addresses + cc_addresses)
        logger.info('Leave email sent: %r -> %s', subject,
                    ', '.join(to_addresses))
        return True
    except smtplib.SMTPException as exc:
        logger.error('SMTP error sending leave email %r to %s: %s',
                     subject, ', '.join(to_addresses), exc)
        return False
    except Exception:
        logger.exception('Unexpected error sending leave email %r.', subject)
        return False


def build_leave_notice(kind, details):
    """(subject, html, text) for one notice. Pure - no I/O.

    `details` keys: name, type, dates (summary text), day_count, reason,
    backup, notes, towers (list), changes (list, optional), withdrawn
    (summary text, optional), request_id, backup_clash (summary, optional),
    rota_shifts (list of 'Rota: day time' lines, optional).
    """
    eyebrow, verb, opening = _COPY[kind]
    name = details.get('name') or 'A colleague'
    subject = '{0}: {1} - {2} ({3})'.format(
        verb, name, details.get('type', ''), details.get('dates', ''))
    count = details.get('day_count') or 0

    chips = [_chip(details.get('type', ''))]
    if count:
        chips.append(_chip('{0} day{1}'.format(count,
                                               '' if count == 1 else 's')))
    for tower in details.get('towers') or []:
        chips.append(_chip(tower))
    hero = hero_rows(eyebrow=eyebrow, title=_esc(name), chips=chips,
                     subtitle=_esc(details.get('dates', '')))

    rows = [
        ('Name', '<strong>{0}</strong>'.format(_esc(name))),
        ('Leave type', _esc(details.get('type', ''))),
        ('Leave date(s)', _esc(details.get('dates', ''))
         + ('<br /><span style="color:{0};font-size:12px;">{1} day{2}</span>'
            .format(NPG_TEXT_MUTED, count, '' if count == 1 else 's')
            if count else '')),
        ('Reason', _multiline_html(details.get('reason'))),
        ('Backup', _esc(details.get('backup') or 'Not named')),
        ('Notes', _multiline_html(details.get('notes'))),
    ]
    if details.get('withdrawn'):
        rows.insert(3, ('Withdrawn', _esc(details['withdrawn'])))

    body = [
        _band(_paragraph(_esc(opening.format(who=name)))),
        _band(_detail_table(rows), top=6),
    ]
    if details.get('changes'):
        items = ''.join(_paragraph('&bull; ' + _esc(c), size=13)
                        for c in details['changes'])
        body.append(_band(section_label('WHAT CHANGED') + items, top=20))
    if details.get('rota_shifts'):
        items = ''.join(_paragraph('&bull; ' + _esc(line), size=13)
                        for line in details['rota_shifts'])
        body.append(_band(callout(
            'warn', 'On the rota during this leave',
            'These shifts need a swap or re-staffing. The rota leads are '
            'copied on this email.'), top=20))
        body.append(_band(items, top=12))
    if details.get('backup_clash') and kind != 'cancelled':
        body.append(_band(callout(
            'warn', 'Backup is also away',
            _esc('{0} is on leave themselves on {1}. Cover for those days '
                 'may need arranging.'.format(details.get('backup'),
                                              details['backup_clash']))),
            top=20))

    action = ''
    link = _link(details.get('request_id'))
    if link:
        action = ('<table role="presentation" cellpadding="0" '
                  'cellspacing="0" border="0"><tr><td style="padding-bottom:'
                  '14px;">{0}</td></tr></table>').format(
                      button(link, 'Open the Leave Tracker'))
    note = ('You are receiving this as a tower lead for {0}, or because you '
            'are the requester, the named backup or a lead of an affected '
            'rota.'.format(
                ', '.join(details.get('towers') or []) or 'this person'))
    body.append(_band(
        '{0}<table role="presentation" cellpadding="0" cellspacing="0" '
        'border="0" width="100%" style="border-top:1px solid {1};">'
        '<tr><td style="padding-top:14px;font-family:{2};font-size:12px;'
        'color:{3};mso-line-height-rule:exactly;line-height:18px;">{4}</td>'
        '</tr></table>'.format(action, NPG_LIGHT, FONT, NPG_TEXT_MUTED,
                               _esc(note)), top=20, bottom=26))

    html = _envelope(subject, hero, ''.join(body), subject)

    lines = [opening.format(who=name), '',
             'Name:          {0}'.format(name),
             'Leave type:    {0}'.format(details.get('type', '')),
             'Leave date(s): {0} ({1} day{2})'.format(
                 details.get('dates', ''), count, '' if count == 1 else 's')]
    if details.get('withdrawn'):
        lines.append('Withdrawn:     {0}'.format(details['withdrawn']))
    lines += ['Reason:        {0}'.format(details.get('reason') or '-'),
              'Backup:        {0}'.format(details.get('backup') or
                                          'Not named'),
              'Notes:         {0}'.format(details.get('notes') or '-')]
    if details.get('changes'):
        lines += ['', 'What changed:'] + ['  - ' + c
                                          for c in details['changes']]
    if details.get('rota_shifts'):
        lines += ['', 'On the rota during this leave (needs a swap or '
                  're-staffing):'] + ['  - ' + r
                                     for r in details['rota_shifts']]
    if details.get('backup_clash') and kind != 'cancelled':
        lines += ['', 'Note: the backup is also on leave on {0}.'.format(
            details['backup_clash'])]
    lines += ['', 'Open the Leave Tracker: {0}'.format(link) if link
              else 'Open App Assist to reach the Leave Tracker.',
              '', 'NPG App Assist - Workforce / Leave Tracker']
    return subject, html, '\n'.join(lines)


def send_leave_notice(kind, details, lead_emails, cc_emails):
    """Build and send. Returns True when the message was handed to SMTP."""
    subject, html, text = build_leave_notice(kind, details)
    return _send(lead_emails, cc_emails, subject, html, text)
