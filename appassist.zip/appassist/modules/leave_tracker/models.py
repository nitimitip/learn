"""
models.py - the Leave Tracker's three tables.

    leave_requests        one request: who, what type, why, who covers
    leave_request_dates   the dates it covers, one row per day
    leave_settings        the single business-rule row

WHY THE DATES ARE ROWS. A request may cover one day, a range, or a scattered
handful ("the 3rd, the 7th and the 12th"), and every question the dashboard
asks - who is out today, how many are out on the 14th, is the backup also away
- is a question about a DAY. One row per day answers all of them with a plain
indexed query instead of range arithmetic in Python.

CANCELLED DAYS ARE KEPT, not deleted. A request that has started cannot be
cancelled as a whole - the days already taken were taken - so cancelling it
withdraws only the days still to come. Flagging those rows rather than
deleting them keeps the record honest: the request still reads "5 days
requested, 2 taken, 3 withdrawn" instead of silently shrinking.

TOWER MEMBERSHIP IS NOT COPIED ONTO A REQUEST. Leave belongs to a person, and
a person who sits in two towers is away from both of them. Who can see a
request, and which leads are told about it, is therefore always read from
Application Support's tower_members at the moment it is needed, so a change
of tower takes effect at once.
"""

from sqlalchemy import (Boolean, Column, Date, DateTime, ForeignKey, Integer,
                        String, Text, UniqueConstraint)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from database import Base

# ---------------------------------------------------------------------------
# Leave types, in the order the business listed them. The order is also the
# order of the categorical colour slots in leave.css, so a type keeps its
# colour on every screen.
# ---------------------------------------------------------------------------
LEAVE_TYPES = (
    ('festival', 'Festival'),
    ('sick', 'Sick'),
    ('unplanned', 'Unplanned'),
    ('comp_off', 'Comp Off'),
    ('casual', 'Casual'),
    ('annual', 'Annual'),
)
LEAVE_TYPE_KEYS = tuple(k for k, _ in LEAVE_TYPES)
LEAVE_TYPE_LABELS = dict(LEAVE_TYPES)
# One-letter code printed inside a calendar cell, so the grid never relies on
# colour alone.
LEAVE_TYPE_CODES = {
    'festival': 'F', 'sick': 'S', 'unplanned': 'U',
    'comp_off': 'C', 'casual': 'L', 'annual': 'A',
}

STATUS_ACTIVE = 'active'
STATUS_CANCELLED = 'cancelled'

# What happened when the tower leads were emailed.
NOTIFY_SENT = 'sent'
NOTIFY_FAILED = 'failed'
NOTIFY_NO_LEAD = 'no_lead'

# Field limits, enforced by the form handler.
REASON_MAX = 1000
NOTES_MAX = 2000


class LeaveRequest(Base):
    __tablename__ = 'leave_requests'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False,
                     index=True)
    leave_type = Column(String(20), nullable=False)
    reason = Column(Text, nullable=False)
    backup_user_id = Column(Integer, ForeignKey('users.id'))
    notes = Column(Text)
    status = Column(String(20), nullable=False, default=STATUS_ACTIVE)

    # Denormalised span of the ACTIVE dates, kept in step by
    # service.refresh_span(). Lets the lists sort and filter without a join.
    first_date = Column(Date, index=True)
    last_date = Column(Date)
    day_count = Column(Integer, default=0)

    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    cancelled_at = Column(DateTime)

    # The last lead notification: when, how it went, and who it went to.
    notified_at = Column(DateTime)
    notify_status = Column(String(20))
    notified_to = Column(Text)

    dates = relationship('LeaveRequestDate', back_populates='request',
                         cascade='all, delete-orphan',
                         order_by='LeaveRequestDate.leave_date')

    @property
    def type_label(self):
        return LEAVE_TYPE_LABELS.get(self.leave_type, self.leave_type or '')

    @property
    def type_code(self):
        return LEAVE_TYPE_CODES.get(self.leave_type, '?')

    @property
    def active_dates(self):
        return [d.leave_date for d in self.dates if not d.is_cancelled]

    @property
    def withdrawn_dates(self):
        return [d.leave_date for d in self.dates if d.is_cancelled]

    @property
    def is_cancelled(self):
        return self.status == STATUS_CANCELLED

    def __repr__(self):
        return '<LeaveRequest {0} user={1} {2}>'.format(
            self.id, self.user_id, self.leave_type)


class LeaveRequestDate(Base):
    __tablename__ = 'leave_request_dates'
    __table_args__ = (
        UniqueConstraint('request_id', 'leave_date',
                         name='uq_leave_request_date'),
    )

    id = Column(Integer, primary_key=True)
    request_id = Column(Integer, ForeignKey('leave_requests.id'),
                        nullable=False, index=True)
    leave_date = Column(Date, nullable=False, index=True)
    # A withdrawn day - see the module docstring.
    is_cancelled = Column(Boolean, nullable=False, default=False)

    request = relationship('LeaveRequest', back_populates='dates')


class LeaveSettings(Base):
    """The single business-rule row, created on the first admin save.

    ``allow_same_day_changes`` answers the requirement's open question: may a
    request still be edited or cancelled ON its leave date? Off by default -
    the day is locked once it arrives - and an administrator can turn it on
    if the business decides otherwise. Past dates are locked either way.
    """
    __tablename__ = 'leave_settings'

    id = Column(Integer, primary_key=True)
    allow_same_day_changes = Column(Boolean, nullable=False, default=False)
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    updated_by = Column(Integer, ForeignKey('users.id'))
