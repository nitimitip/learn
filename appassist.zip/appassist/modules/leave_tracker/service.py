"""
service.py - the rules the Leave Tracker runs under.

Every decision the screens make is taken here, so the routes stay a thin
layer of parsing and rendering and the rules can be tested without HTTP.

ACCESS
------
Leave belongs to a person; visibility follows the person's TOWERS, read live
from Application Support's tower_members:

  * a member sees the dashboard of each tower they belong to, and nothing else
  * an administrator sees every active tower (read-only oversight)
  * a request is visible to its owner, to anybody who shares a tower with the
    owner, and to an administrator
  * the REASON and NOTES are personal (a sick note is nobody else's business):
    only the owner, a lead of one of the owner's towers, and an administrator
    read them. Colleagues see who is out, when, the type and the backup.
  * ONLY THE OWNER creates, edits or cancels their own leave. There is no
    on-behalf path - not for a lead, not for an administrator.

THE LOCK
--------
A leave day is LOCKED once it has arrived: a past date always, today unless
the business rule (LeaveSettings.allow_same_day_changes) says otherwise.

  * Edit and Cancel stay available while the request still has at least one
    unlocked day.
  * Editing never touches a locked day - it is kept as taken - and cannot add
    a day that is already locked.
  * Cancelling a request that has NOT started cancels it outright. Cancelling
    one that HAS started withdraws only the days still to come; the days
    already taken stay on the record.
  * When every day is locked, both actions are gone for good.

DATES
-----
A request is one day, a range, or a hand-picked set, capped at MAX_DAYS. A
range skips weekends and the Workforce public-holiday calendar by default.
A new request may be back-dated by up to BACKDATE_DAYS - sick and unplanned
leave is often recorded after the fact - and reaches at most FORWARD_DAYS
ahead. A person cannot book the same day twice across their active requests.
"""

from datetime import date, datetime, timedelta

from sqlalchemy import func as sa_func
# `col == sql_true()` rather than `col.is_(True)`: T-SQL rejects `IS 1`.
from sqlalchemy import false as sql_false
from sqlalchemy import true as sql_true

from models import User
from modules.application_support.models import AppSupportTower, TowerMember

from .models import (LEAVE_TYPE_KEYS, LEAVE_TYPE_LABELS, LEAVE_TYPES,
                     NOTES_MAX, REASON_MAX, STATUS_ACTIVE, STATUS_CANCELLED,
                     LeaveRequest, LeaveRequestDate, LeaveSettings)

MAX_DAYS = 60
BACKDATE_DAYS = 30
FORWARD_DAYS = 366
UPCOMING_WINDOW = 30

MODE_SINGLE = 'single'
MODE_RANGE = 'range'
MODE_MULTI = 'multi'
DATE_MODES = (MODE_SINGLE, MODE_RANGE, MODE_MULTI)


# ===========================================================================
# Small helpers
# ===========================================================================

def display_name(user):
    if user is None:
        return ''
    full = '{0} {1}'.format(user.firstname or '', user.lastname or '').strip()
    return full or (user.username or '')


def is_admin(user):
    return bool(user) and getattr(user, 'role', None) == 'admin'


def parse_iso(value):
    """'2026-10-06' -> date, anything else -> None."""
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    try:
        return datetime.strptime((value or '').strip(), '%Y-%m-%d').date()
    except (TypeError, ValueError, AttributeError):
        return None


def summarise_dates(dates):
    """Consecutive days collapsed into ranges.

    [6, 7, 8, 10 Oct] -> 'Mon 06 Oct - Wed 08 Oct, Fri 10 Oct'. A span that
    crosses a year states the year on both ends.
    """
    days = sorted(set(dates))
    if not days:
        return ''
    runs, start, prev = [], days[0], days[0]
    for day in days[1:]:
        if day == prev + timedelta(days=1):
            prev = day
            continue
        runs.append((start, prev))
        start = prev = day
    runs.append((start, prev))

    today_year = date.today().year

    def fmt(d):
        return d.strftime('%a %d %b') + (
            d.strftime(' %Y') if d.year != today_year else '')

    return ', '.join(fmt(a) if a == b else '{0} - {1}'.format(fmt(a), fmt(b))
                     for a, b in runs)


def holidays_between(db, start, end):
    """{date: name} from the Workforce public-holiday calendar."""
    try:
        from modules.resource_utilization.models import WorkforceHoliday
        rows = (db.query(WorkforceHoliday)
                .filter(WorkforceHoliday.holiday_date >= start,
                        WorkforceHoliday.holiday_date <= end).all())
        return {r.holiday_date: r.name for r in rows}
    except Exception:
        # The calendar is a nicety; a missing table must not stop a booking.
        return {}


# ===========================================================================
# Settings and the lock
# ===========================================================================

def load_settings(db):
    row = db.query(LeaveSettings).order_by(LeaveSettings.id).first()
    return {'allow_same_day_changes': bool(row and row.allow_same_day_changes)}


def save_settings(db, allow_same_day_changes, actor):
    row = db.query(LeaveSettings).order_by(LeaveSettings.id).first()
    if row is None:
        row = LeaveSettings()
        db.add(row)
    row.allow_same_day_changes = bool(allow_same_day_changes)
    row.updated_by = getattr(actor, 'id', None)
    db.commit()


def is_locked(day, today, allow_same_day=False):
    """True once a leave day can no longer be changed."""
    if day < today:
        return True
    if day == today:
        return not allow_same_day
    return False


def request_state(req, today, allow_same_day=False):
    """What the owner may still do with a request, and how to describe it."""
    active = req.active_dates
    locked = [d for d in active if is_locked(d, today, allow_same_day)]
    open_days = [d for d in active if not is_locked(d, today, allow_same_day)]
    started = bool(active) and min(active) <= today
    finished = bool(active) and max(active) < today

    if req.status == STATUS_CANCELLED:
        label, tone = 'Cancelled', 'quiet'
    elif not active:
        label, tone = 'Withdrawn', 'quiet'
    elif finished:
        label, tone = 'Taken', 'done'
    elif started:
        label, tone = 'On leave', 'live'
    else:
        label, tone = 'Upcoming', 'go'
    if req.status != STATUS_CANCELLED and req.withdrawn_dates and active:
        label += ' (part withdrawn)'

    can_change = req.status == STATUS_ACTIVE and bool(open_days)
    return {
        'label': label,
        'tone': tone,
        'can_edit': can_change,
        'can_cancel': can_change,
        # Cancelling a started request withdraws only what is left.
        'partial_cancel': can_change and bool(locked),
        'locked_dates': sorted(locked),
        'open_dates': sorted(open_days),
        'started': started,
        'finished': finished,
    }


# ===========================================================================
# Towers and people
# ===========================================================================

def _active_tower_filter(query):
    return query.filter(AppSupportTower.is_active == sql_true())


def user_tower_ids(db, user_id):
    """Ids of the ACTIVE towers the person is a member of."""
    rows = (_active_tower_filter(
        db.query(TowerMember.tower_id)
        .join(AppSupportTower, AppSupportTower.id == TowerMember.tower_id)
        .filter(TowerMember.user_id == user_id)).all())
    return sorted({r[0] for r in rows})


def visible_towers(db, user):
    """[(id, name)] of the dashboards this person may open."""
    query = db.query(AppSupportTower.id, AppSupportTower.tower_name)
    query = _active_tower_filter(query)
    if not is_admin(user):
        ids = user_tower_ids(db, user.id)
        if not ids:
            return []
        query = query.filter(AppSupportTower.id.in_(ids))
    return [(r[0], r[1]) for r in
            query.order_by(AppSupportTower.tower_name).all()]


def tower_members(db, tower_id):
    """Active users in the tower, ordered by name, each with an is_lead flag.

    Returns [(User, is_lead)].
    """
    rows = (db.query(User, TowerMember.is_lead)
            .join(TowerMember, TowerMember.user_id == User.id)
            .filter(TowerMember.tower_id == tower_id,
                    User.is_active == sql_true())
            .order_by(User.firstname, User.lastname, User.username).all())
    seen, out = set(), []
    for person, lead in rows:
        if person.id in seen:
            continue
        seen.add(person.id)
        out.append((person, bool(lead)))
    return out


def colleague_ids(db, user_id):
    """Everyone who shares at least one active tower with the person."""
    towers = user_tower_ids(db, user_id)
    if not towers:
        return set()
    rows = (db.query(TowerMember.user_id)
            .filter(TowerMember.tower_id.in_(towers)).all())
    return {r[0] for r in rows}


def leads_for_user(db, user_id):
    """The leads of every active tower the person belongs to, minus the
    person themselves. [(User, [tower names])]."""
    towers = user_tower_ids(db, user_id)
    if not towers:
        return []
    rows = (db.query(User, AppSupportTower.tower_name)
            .join(TowerMember, TowerMember.user_id == User.id)
            .join(AppSupportTower, AppSupportTower.id == TowerMember.tower_id)
            .filter(TowerMember.tower_id.in_(towers),
                    TowerMember.is_lead == sql_true(),
                    User.is_active == sql_true(),
                    User.id != user_id)
            .order_by(User.firstname, User.lastname).all())
    by_id, order = {}, []
    for person, tower_name in rows:
        if person.id not in by_id:
            by_id[person.id] = (person, [])
            order.append(person.id)
        if tower_name not in by_id[person.id][1]:
            by_id[person.id][1].append(tower_name)
    return [by_id[i] for i in order]


def is_lead_of_user(db, viewer_id, owner_id):
    """True when the viewer leads a tower the owner belongs to."""
    towers = user_tower_ids(db, owner_id)
    if not towers:
        return False
    return db.query(TowerMember.id).filter(
        TowerMember.user_id == viewer_id,
        TowerMember.tower_id.in_(towers),
        TowerMember.is_lead == sql_true()).first() is not None


def backup_choices(db, user):
    """Who may be named as backup: active colleagues from the person's own
    towers, never the person themselves. [User]."""
    ids = colleague_ids(db, user.id) - {user.id}
    if not ids:
        return []
    return (db.query(User)
            .filter(User.id.in_(ids), User.is_active == sql_true())
            .order_by(User.firstname, User.lastname, User.username).all())


def can_view_request(db, viewer, req):
    if viewer is None or req is None:
        return False
    if req.user_id == viewer.id or is_admin(viewer):
        return True
    return viewer.id in colleague_ids(db, req.user_id)


def can_see_private(db, viewer, req):
    """Reason and notes: owner, a lead of the owner's tower, an admin."""
    if viewer is None or req is None:
        return False
    if req.user_id == viewer.id or is_admin(viewer):
        return True
    return is_lead_of_user(db, viewer.id, req.user_id)


# ===========================================================================
# Dates from the form
# ===========================================================================

def expand_dates(db, mode, single=None, date_from=None, date_to=None,
                 skip_non_working=True, multi=None):
    """Turn the date part of the form into a sorted list of days.

    Returns (dates, errors). `multi` is a list or a comma-separated string of
    ISO dates. A range skips weekends and public holidays when asked to.
    """
    errors = []
    days = set()
    if mode == MODE_SINGLE:
        day = parse_iso(single)
        if day is None:
            errors.append('Choose the leave date.')
        else:
            days.add(day)
    elif mode == MODE_RANGE:
        start, end = parse_iso(date_from), parse_iso(date_to)
        if start is None or end is None:
            errors.append('Choose both the first and the last day of the '
                          'range.')
        elif end < start:
            errors.append('The last day of the range is before the first.')
        elif (end - start).days + 1 > MAX_DAYS * 2:
            errors.append('That range is too long - a single request covers '
                          'at most {0} days.'.format(MAX_DAYS))
        else:
            holidays = (holidays_between(db, start, end)
                        if skip_non_working else {})
            day = start
            while day <= end:
                if not (skip_non_working and (day.weekday() >= 5
                                              or day in holidays)):
                    days.add(day)
                day += timedelta(days=1)
            if not days:
                errors.append('Every day in that range is a weekend or a '
                              'public holiday - there is nothing to book.')
    elif mode == MODE_MULTI:
        raw = multi if isinstance(multi, (list, tuple)) else \
            (multi or '').split(',')
        bad = 0
        for item in raw:
            item = (item or '').strip()
            if not item:
                continue
            day = parse_iso(item)
            if day is None:
                bad += 1
            else:
                days.add(day)
        if bad:
            errors.append('{0} of the picked dates could not be read.'
                          .format(bad))
        if not days and not bad:
            errors.append('Pick at least one date.')
    else:
        errors.append('Choose how you want to enter the dates.')

    if len(days) > MAX_DAYS:
        errors.append('A single request covers at most {0} days - split it '
                      'into two.'.format(MAX_DAYS))
    return sorted(days), errors


def _own_clashes(db, user_id, days, exclude_request_id=None):
    """Days already booked on the person's other active requests."""
    if not days:
        return []
    query = (db.query(LeaveRequestDate.leave_date)
             .join(LeaveRequest,
                   LeaveRequest.id == LeaveRequestDate.request_id)
             .filter(LeaveRequest.user_id == user_id,
                     LeaveRequest.status == STATUS_ACTIVE,
                     LeaveRequestDate.is_cancelled == sql_false(),
                     LeaveRequestDate.leave_date.in_(list(days))))
    if exclude_request_id is not None:
        query = query.filter(LeaveRequest.id != exclude_request_id)
    return sorted({r[0] for r in query.all()})


def backup_clashes(db, backup_user_id, days):
    """Days on which the named backup is on leave themselves."""
    if not backup_user_id or not days:
        return []
    return _own_clashes(db, backup_user_id, days)


# ===========================================================================
# Create, edit, cancel
# ===========================================================================

def _validate_fields(db, user, leave_type, reason, backup_user_id, notes):
    errors = []
    if leave_type not in LEAVE_TYPE_KEYS:
        errors.append('Choose a leave type.')
    if not reason:
        errors.append('Give a reason for the leave.')
    elif len(reason) > REASON_MAX:
        errors.append('The reason is limited to {0} characters.'
                      .format(REASON_MAX))
    if notes and len(notes) > NOTES_MAX:
        errors.append('Notes are limited to {0} characters.'
                      .format(NOTES_MAX))
    if not backup_user_id:
        errors.append('Name the person who will back you up.')
    elif backup_user_id == user.id:
        errors.append('You cannot be your own backup.')
    elif backup_user_id not in {u.id for u in backup_choices(db, user)}:
        errors.append('The backup must be an active member of one of your '
                      'towers.')
    return errors


def _check_window(days, today, allow_backdate=True):
    errors = []
    earliest = today - timedelta(days=BACKDATE_DAYS)
    latest = today + timedelta(days=FORWARD_DAYS)
    if allow_backdate and any(d < earliest for d in days):
        errors.append('Leave can be recorded at most {0} days after the '
                      'event.'.format(BACKDATE_DAYS))
    if any(d > latest for d in days):
        errors.append('Leave can be booked at most a year ahead.')
    return errors


def refresh_span(req):
    active = req.active_dates
    req.first_date = min(active) if active else None
    req.last_date = max(active) if active else None
    req.day_count = len(active)


def create_request(db, user, leave_type, days, reason, backup_user_id,
                   notes, today=None):
    """Validate and save a new request. Returns (request or None, errors)."""
    today = today or date.today()
    if not user_tower_ids(db, user.id):
        return None, ['You are not a member of any support tower, so there '
                      'is no tower lead to notify. Ask an administrator to '
                      'add you to your tower first.']
    errors = _validate_fields(db, user, leave_type, reason, backup_user_id,
                              notes)
    if not days:
        errors.append('Pick at least one date.')
    errors += _check_window(days, today)
    clash = _own_clashes(db, user.id, days)
    if clash:
        errors.append('You already have leave booked on {0}.'
                      .format(summarise_dates(clash)))
    if errors:
        return None, errors

    req = LeaveRequest(user_id=user.id, leave_type=leave_type,
                       reason=reason, backup_user_id=backup_user_id,
                       notes=notes or None, status=STATUS_ACTIVE)
    for day in days:
        req.dates.append(LeaveRequestDate(leave_date=day, is_cancelled=False))
    refresh_span(req)
    db.add(req)
    db.commit()
    return req, []


def update_request(db, user, req, leave_type, submitted_days, reason,
                   backup_user_id, notes, today=None, allow_same_day=False):
    """Apply an edit by the owner. Returns (changed_summary, errors).

    Locked days are kept whatever was submitted; see the module docstring.
    """
    today = today or date.today()
    if req.user_id != user.id:
        return None, ['Only the person who booked this leave can change it.']
    state = request_state(req, today, allow_same_day)
    if not state['can_edit']:
        return None, ['This leave can no longer be changed - its dates have '
                      'arrived.']

    errors = _validate_fields(db, user, leave_type, reason, backup_user_id,
                              notes)
    locked = set(state['locked_dates'])
    submitted = set(submitted_days)
    newly_locked = sorted(d for d in submitted
                          if is_locked(d, today, allow_same_day)
                          and d not in locked)
    if newly_locked:
        errors.append('{0} cannot be added - the date has already arrived.'
                      .format(summarise_dates(newly_locked)))
    open_part = {d for d in submitted
                 if not is_locked(d, today, allow_same_day)}
    if not open_part:
        errors.append('Keep at least one upcoming day. To withdraw every '
                      'remaining day, use Cancel instead.')
    final = locked | open_part
    if len(final) > MAX_DAYS:
        errors.append('A single request covers at most {0} days.'
                      .format(MAX_DAYS))
    errors += _check_window(sorted(open_part), today)
    clash = _own_clashes(db, user.id, sorted(open_part),
                         exclude_request_id=req.id)
    if clash:
        errors.append('You already have leave booked on {0}.'
                      .format(summarise_dates(clash)))
    if errors:
        return None, errors

    before = {
        'type': req.type_label,
        'dates': summarise_dates(req.active_dates),
        'backup': req.backup_user_id,
    }

    existing = {row.leave_date: row for row in req.dates}
    for day, row in list(existing.items()):
        if day in locked:
            continue
        if day in open_part:
            row.is_cancelled = False
        elif not row.is_cancelled:
            req.dates.remove(row)
    for day in sorted(open_part):
        if day not in existing:
            req.dates.append(LeaveRequestDate(leave_date=day,
                                              is_cancelled=False))

    req.leave_type = leave_type
    req.reason = reason
    req.backup_user_id = backup_user_id
    req.notes = notes or None
    refresh_span(req)
    db.commit()

    changes = []
    if before['type'] != req.type_label:
        changes.append('Leave type {0} -> {1}'.format(before['type'],
                                                      req.type_label))
    after_dates = summarise_dates(req.active_dates)
    if before['dates'] != after_dates:
        changes.append('Dates {0} -> {1}'.format(before['dates'],
                                                 after_dates))
    if before['backup'] != req.backup_user_id:
        changes.append('Backup changed')
    return changes, []


def cancel_request(db, user, req, today=None, allow_same_day=False):
    """Cancel, or withdraw the remaining days. Returns (outcome, errors).

    outcome is 'cancelled' (the whole request) or 'withdrawn' (the days still
    to come; the days already taken stay) together with the withdrawn dates.
    """
    today = today or date.today()
    if req.user_id != user.id:
        return None, ['Only the person who booked this leave can cancel it.']
    state = request_state(req, today, allow_same_day)
    if not state['can_cancel']:
        return None, ['This leave can no longer be cancelled - its dates '
                      'have arrived.']
    withdrawn = list(state['open_dates'])
    for row in req.dates:
        if row.leave_date in withdrawn:
            row.is_cancelled = True
    now = datetime.now()
    if state['partial_cancel']:
        outcome = 'withdrawn'
    else:
        outcome = 'cancelled'
        req.status = STATUS_CANCELLED
        req.cancelled_at = now
    refresh_span(req)
    if outcome == 'cancelled':
        # Keep the span of what was booked so the record still reads.
        req.first_date = min(withdrawn)
        req.last_date = max(withdrawn)
        req.day_count = 0
    db.commit()
    return (outcome, withdrawn), []


# ===========================================================================
# Reading
# ===========================================================================

def my_requests(db, user_id):
    return (db.query(LeaveRequest)
            .filter(LeaveRequest.user_id == user_id)
            .order_by(LeaveRequest.first_date.desc(),
                      LeaveRequest.id.desc()).all())


def _leave_days(db, user_ids, start, end):
    """[(user_id, date, LeaveRequest)] for active days in [start, end]."""
    if not user_ids:
        return []
    rows = (db.query(LeaveRequestDate.leave_date, LeaveRequest)
            .join(LeaveRequest,
                  LeaveRequest.id == LeaveRequestDate.request_id)
            .filter(LeaveRequest.user_id.in_(list(user_ids)),
                    LeaveRequest.status == STATUS_ACTIVE,
                    LeaveRequestDate.is_cancelled == sql_false(),
                    LeaveRequestDate.leave_date >= start,
                    LeaveRequestDate.leave_date <= end).all())
    return [(req.user_id, day, req) for day, req in rows]


def month_bounds(month_start):
    first = month_start.replace(day=1)
    nxt = (first.replace(day=28) + timedelta(days=4)).replace(day=1)
    return first, nxt - timedelta(days=1)


def dashboard(db, tower_id, month_start, today=None):
    """Everything the tower dashboard shows, for one tower and one month."""
    today = today or date.today()
    first, last = month_bounds(month_start)
    members = tower_members(db, tower_id)
    people = [p for p, _ in members]
    ids = [p.id for p in people]
    names = {p.id: display_name(p) for p in people}
    team_size = len(people)

    # ---- the month grid
    days = [first + timedelta(days=i) for i in range((last - first).days + 1)]
    holidays = holidays_between(db, first, last)
    cells = {}
    for uid, day, req in _leave_days(db, ids, first, last):
        cells[(uid, day)] = req
    per_day = {day: 0 for day in days}
    per_person_month = {uid: 0 for uid in ids}
    for (uid, day) in cells:
        per_day[day] += 1
        per_person_month[uid] += 1
    peak = max(per_day.values()) if per_day else 0

    # ---- year to date (the displayed month's year)
    y_first, y_last = date(first.year, 1, 1), date(first.year, 12, 31)
    year_rows = _leave_days(db, ids, y_first, y_last)
    by_type = {key: 0 for key, _ in LEAVE_TYPES}
    per_person_year = {uid: 0 for uid in ids}
    for uid, _day, req in year_rows:
        by_type[req.leave_type] = by_type.get(req.leave_type, 0) + 1
        per_person_year[uid] += 1
    year_total = sum(by_type.values())

    # ---- today and this week (always about the real today)
    week_start = today - timedelta(days=today.weekday())
    week_end = week_start + timedelta(days=6)
    window_end = today + timedelta(days=UPCOMING_WINDOW)
    near_rows = _leave_days(db, ids, min(week_start, today),
                            max(week_end, window_end))
    out_today = []
    week_people = set()
    upcoming = {}
    for uid, day, req in near_rows:
        if day == today:
            out_today.append(req)
        if week_start <= day <= week_end:
            week_people.add(uid)
        if today <= day <= window_end:
            upcoming.setdefault(req.id, (req, []))[1].append(day)

    upcoming_list = []
    clash_count = 0
    for req, req_days in sorted(upcoming.values(),
                                key=lambda item: (min(item[1]),
                                                  names.get(item[0].user_id,
                                                            ''))):
        req_days.sort()
        clashes = backup_clashes(db, req.backup_user_id, req_days)
        if clashes:
            clash_count += 1
        upcoming_list.append({'req': req, 'days': req_days,
                              'summary': summarise_dates(req_days),
                              'next': req_days[0],
                              'backup_clashes': clashes})

    backups = {}
    backup_ids = {r.backup_user_id for r in out_today if r.backup_user_id}
    backup_ids |= {u['req'].backup_user_id for u in upcoming_list
                   if u['req'].backup_user_id}
    if backup_ids:
        for person in db.query(User).filter(User.id.in_(backup_ids)).all():
            backups[person.id] = display_name(person)

    grid_rows = []
    for person, lead in members:
        grid_rows.append({
            'user': person,
            'name': names[person.id],
            'is_lead': lead,
            'cells': [cells.get((person.id, day)) for day in days],
            'month_days': per_person_month[person.id],
            'year_days': per_person_year[person.id],
        })

    return {
        'first': first,
        'last': last,
        'days': days,
        'holidays': holidays,
        'per_day': [per_day[d] for d in days],
        'peak': peak,
        'rows': grid_rows,
        'team_size': team_size,
        'lead_names': [names[p.id] for p, lead in members if lead],
        'out_today': sorted(out_today,
                            key=lambda r: names.get(r.user_id, '')),
        'out_today_pct': (round(100.0 * len(out_today) / team_size)
                          if team_size else 0),
        'week_people': len(week_people),
        'upcoming': upcoming_list,
        'upcoming_people': len({u['req'].user_id for u in upcoming_list}),
        'month_total': sum(per_person_month.values()),
        'year_total': year_total,
        'by_type': [(key, LEAVE_TYPE_LABELS[key], by_type.get(key, 0))
                    for key, _ in LEAVE_TYPES],
        'by_type_max': max(by_type.values()) if by_type else 0,
        'backup_clash_count': clash_count,
        'names': names,
        'backups': backups,
    }


def count_open_leave(db, user_id, today=None):
    """Active days still to come, for the owner's banner."""
    today = today or date.today()
    return (db.query(sa_func.count(LeaveRequestDate.id))
            .join(LeaveRequest,
                  LeaveRequest.id == LeaveRequestDate.request_id)
            .filter(LeaveRequest.user_id == user_id,
                    LeaveRequest.status == STATUS_ACTIVE,
                    LeaveRequestDate.is_cancelled == sql_false(),
                    LeaveRequestDate.leave_date >= today).scalar() or 0)


# ===========================================================================
# For other modules (Rota)
#
# The Leave Tracker owns leave; other modules READ it through these three
# functions and nothing else, so the day a rule changes here it changes for
# them too. All three answer about ACTIVE, non-withdrawn days only.
# ===========================================================================

def dates_touched(starts_at, ends_at):
    """Every calendar day a [starts_at, ends_at) window touches.

    A 22:00-06:00 night shift touches two days; a leave day on either of
    them means the person cannot work it.
    """
    first = starts_at.date()
    last = (ends_at - timedelta(seconds=1)).date() if ends_at > starts_at \
        else first
    out, day = [], first
    while day <= last:
        out.append(day)
        day += timedelta(days=1)
    return out


def leave_map(db, user_ids, start, end):
    """{(user_id, date): LeaveRequest} for active leave in [start, end]."""
    return {(uid, day): req
            for uid, day, req in _leave_days(db, set(user_ids), start, end)}


def on_leave_during(db, user_id, starts_at, ends_at):
    """The leave request that makes this person unavailable for the window,
    or None."""
    days = dates_touched(starts_at, ends_at)
    found = leave_map(db, [user_id], days[0], days[-1])
    for day in days:
        if (user_id, day) in found:
            return found[(user_id, day)]
    return None


def rota_shifts_during(db, user_id, days, today=None):
    """Upcoming rota assignments the person holds on any of these days.

    Returns [RotaAssignment] - active, not yet clocked in, on a rota that is
    not closed, sorted by start. Empty (never an error) if the Rota module is
    unavailable, because booking leave must not depend on it.
    """
    days = sorted(set(days))
    if not days:
        return []
    today = today or date.today()
    try:
        from modules.rota.models import (STATE_ACTIVE, STATUS_CLOSED, Rota,
                                         RotaAssignment, RotaShift)
        start = datetime.combine(days[0] - timedelta(days=1), datetime.min.time())
        end = datetime.combine(days[-1] + timedelta(days=1), datetime.max.time())
        rows = (db.query(RotaAssignment)
                .join(RotaShift, RotaShift.id == RotaAssignment.shift_id)
                .join(Rota, Rota.id == RotaAssignment.rota_id)
                .filter(RotaAssignment.user_id == user_id,
                        RotaAssignment.state == STATE_ACTIVE,
                        RotaAssignment.signed_in_at.is_(None),
                        Rota.status != STATUS_CLOSED,
                        RotaShift.starts_at >= start,
                        RotaShift.starts_at <= end)
                .order_by(RotaShift.starts_at).all())
    except Exception:
        return []
    wanted = set(days)
    return [a for a in rows
            if a.shift is not None and a.shift.shift_date >= today
            and wanted.intersection(dates_touched(a.shift.starts_at,
                                                  a.shift.ends_at))]


def is_lead_of_tower(db, user_id, tower_id):
    return db.query(TowerMember.id).filter(
        TowerMember.user_id == user_id, TowerMember.tower_id == tower_id,
        TowerMember.is_lead == sql_true()).first() is not None
