"""
routes.py - every screen and action in the Leave Tracker.

    /leave/                    Dashboard   the tower's leave, month by month
    /leave/mine                My leave    my requests; edit and cancel
    /leave/new                 Request     book leave
    /leave/<id>                Detail      one request
    /leave/<id>/edit           Edit        owner only, before the dates arrive
    /leave/<id>/cancel         Cancel      owner only, POST
    /leave/export.xlsx         Excel       the tower calendar for one month
    /leave/settings            Settings    admin only: the same-day rule

ACCESS is decided by service.py - see its docstring. In short: a member sees
their own towers' dashboards, an admin sees every tower, and only the owner
ever creates, edits or cancels leave. Somebody acting on another person's
request gets a 404, not a 403, so the route does not confirm the id exists.

CSRF is enforced application-wide by csrf_utils.enforce_csrf; the forms
carry the hidden csrf_token field.
"""

import io
import logging
from datetime import date, datetime, timedelta

import re

from flask import (Blueprint, abort, flash, redirect, render_template,
                   request, send_file, url_for)

from auth import get_current_user
from csrf_utils import csrf_protect
from database import get_db_session
from models import User

from . import emails, report_excel, service
from .models import (LEAVE_TYPE_CODES, LEAVE_TYPE_LABELS, LEAVE_TYPES,
                     NOTES_MAX, NOTIFY_FAILED, NOTIFY_NO_LEAD, NOTIFY_SENT,
                     REASON_MAX, LeaveRequest)

logger = logging.getLogger(__name__)

leave_tracker_bp = Blueprint('leave_tracker', __name__,
                             template_folder='../../templates/leave_tracker')


# ===========================================================================
# Helpers
# ===========================================================================

def _clean(value, limit=None):
    text = ' '.join((value or '').split())
    return text[:limit] if limit else text


def _clean_multiline(value, limit=None):
    text = (value or '').replace('\r\n', '\n').strip()
    return text[:limit] if limit else text


def _parse_int(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def _require_login():
    user = get_current_user()
    if not user:
        return None, redirect(url_for('login'))
    return user, None


def _today():
    """One seam for 'today', so the lock rules can be tested."""
    return date.today()


def _base_context(user, db):
    settings = service.load_settings(db)
    return {
        'user': user,
        'is_admin': service.is_admin(user),
        'leave_types': LEAVE_TYPES,
        'type_labels': LEAVE_TYPE_LABELS,
        'type_codes': LEAVE_TYPE_CODES,
        'settings': settings,
        'today': _today(),
        'summarise_dates': service.summarise_dates,
        'display_name': service.display_name,
    }


def _form_values(form):
    """The submitted form, cleaned - also used to re-fill it on error."""
    return {
        'leave_type': _clean(form.get('leave_type')),
        'mode': _clean(form.get('date_mode')) or service.MODE_SINGLE,
        'single': _clean(form.get('date_single')),
        'date_from': _clean(form.get('date_from')),
        'date_to': _clean(form.get('date_to')),
        'skip_non_working': form.get('skip_non_working') == '1',
        'multi': _clean(form.get('date_multi')),
        'reason': _clean_multiline(form.get('reason'), REASON_MAX + 1),
        'backup_user_id': _parse_int(form.get('backup_user_id')),
        'notes': _clean_multiline(form.get('notes'), NOTES_MAX + 1),
    }


def _rota_impact(db, req, owner):
    """The owner's upcoming rota shifts that fall on this leave.

    Returns (lines, emails): one readable line per shift for the screen and
    the email, and the addresses of whoever re-staffs those rotas - each
    rota's leads and the Rota Admins, the same people the rota itself tells
    when a shift goes wrong. Both empty when nothing clashes or the Rota
    module is unavailable.
    """
    upcoming = [d for d in req.active_dates if d >= _today()]
    shifts = service.rota_shifts_during(db, owner.id, upcoming, _today())
    if not shifts:
        return [], []
    lines, emails_out, rotas = [], [], {}
    for a in shifts:
        name = a.rota.name if a.rota is not None else 'Rota'
        lines.append('{0}: {1} {2}'.format(name, a.shift.day_label,
                                           a.shift.time_label))
        if a.rota is not None:
            rotas[a.rota.id] = a.rota
    try:
        from modules.rota.service import rota_recipients
        for rota in rotas.values():
            for person in rota_recipients(db, rota):
                if (person.email and person.id != owner.id
                        and person.email not in emails_out):
                    emails_out.append(person.email)
    except Exception:
        logger.exception('Could not resolve the rota recipients for leave '
                         'request %s.', req.id)
    return lines, emails_out


def _notify(db, kind, req, owner, changes=None, withdrawn=None):
    """Email the owner's tower leads; record the outcome on the request.

    Returns the NOTIFY_* outcome. A failure never undoes the save - the leave
    is booked either way, and the screen says whether the leads were told.
    """
    leads = service.leads_for_user(db, owner.id)
    towers = []
    for _person, names in leads:
        for name in names:
            if name not in towers:
                towers.append(name)
    if not towers:
        tower_ids = service.user_tower_ids(db, owner.id)
        towers = [name for tid, name in service.visible_towers(db, owner)
                  if tid in tower_ids]

    backup = (db.query(User).filter_by(id=req.backup_user_id).first()
              if req.backup_user_id else None)
    clash = []
    if backup is not None and kind != 'cancelled':
        clash = service.backup_clashes(db, backup.id, [
            d for d in req.active_dates if d >= _today()])

    rota_lines, rota_emails = ([], []) if kind in ('cancelled', 'withdrawn')         else _rota_impact(db, req, owner)

    details = {
        'rota_shifts': rota_lines,
        'name': service.display_name(owner),
        'type': req.type_label,
        'dates': service.summarise_dates(
            withdrawn if kind == 'cancelled' and withdrawn
            else req.active_dates),
        'day_count': (len(withdrawn) if kind == 'cancelled' and withdrawn
                      else req.day_count),
        'reason': req.reason,
        'backup': service.display_name(backup) if backup else '',
        'notes': req.notes,
        'towers': towers,
        'changes': changes or [],
        'withdrawn': (service.summarise_dates(withdrawn)
                      if kind == 'withdrawn' and withdrawn else ''),
        'request_id': req.id,
        'backup_clash': service.summarise_dates(clash) if clash else '',
    }

    lead_emails = [p.email for p, _ in leads if p.email]
    cc = [owner.email] + ([backup.email] if backup is not None else [])
    cc += [e for e in rota_emails if e not in cc]
    req.notified_at = datetime.now()
    if not lead_emails:
        req.notify_status = NOTIFY_NO_LEAD
        req.notified_to = ''
        db.commit()
        return NOTIFY_NO_LEAD
    try:
        ok = emails.send_leave_notice(kind, details, lead_emails, cc)
    except Exception:
        logger.exception('Leave notice %s for request %s failed.', kind,
                         req.id)
        ok = False
    req.notify_status = NOTIFY_SENT if ok else NOTIFY_FAILED
    req.notified_to = ', '.join(lead_emails)
    db.commit()
    return req.notify_status


def _flash_notify(outcome, action_word):
    if outcome == NOTIFY_SENT:
        flash('Leave {0}. Your tower lead has been emailed.'
              .format(action_word), 'success')
    elif outcome == NOTIFY_NO_LEAD:
        flash('Leave {0}, but no other tower lead is named for your '
              'tower(s), so no lead was emailed. Ask an administrator to name '
              'a tower lead.'
              .format(action_word), 'warning')
    else:
        flash('Leave {0}, but the email to your tower lead could not be '
              'sent. Please let them know directly.'.format(action_word),
              'warning')


def _flash_rota(db, req, owner):
    lines, _emails = _rota_impact(db, req, owner)
    if lines:
        flash('You are on {0} rota shift{1} during this leave ({2}). The '
              'rota leads have been copied - raise a swap or give-up on '
              'Rota > My shifts.'.format(len(lines),
                                         '' if len(lines) == 1 else 's',
                                         '; '.join(lines)), 'warning')


def _load_request(db, request_id):
    req = db.query(LeaveRequest).filter_by(id=request_id).first()
    if req is None:
        abort(404)
    return req


# ===========================================================================
# Dashboard
# ===========================================================================

@leave_tracker_bp.route('/')
def index():
    user, bounce = _require_login()
    if bounce:
        return bounce
    db = get_db_session()
    try:
        ctx = _base_context(user, db)
        towers, tower_id, month = _resolve_tower_month(db, user, ctx)
        today = ctx['today']
        first, _last = service.month_bounds(month)
        prev_month = (first - timedelta(days=1)).replace(day=1)
        next_month = (first.replace(day=28) + timedelta(days=4)).replace(day=1)

        data = service.dashboard(db, tower_id, first, today) \
            if tower_id else None
        tower_name = dict(towers).get(tower_id, '')
        my_open_days = service.count_open_leave(db, user.id, today)
        can_request = bool(service.user_tower_ids(db, user.id))
        return render_template(
            'leave_tracker/dashboard.html', towers=towers,
            tower_id=tower_id, tower_name=tower_name, d=data,
            month=first, prev_month=prev_month, next_month=next_month,
            my_open_days=my_open_days, can_request=can_request, **ctx)
    finally:
        db.close()


def _resolve_tower_month(db, user, ctx):
    """The tower (one the viewer may see) and month a request asks for."""
    towers = service.visible_towers(db, user)
    tower_ids = [t[0] for t in towers]
    tower_id = _parse_int(request.args.get('tower'))
    if tower_id not in tower_ids:
        own = service.user_tower_ids(db, user.id)
        tower_id = next((t for t in tower_ids if t in own),
                        tower_ids[0] if tower_ids else None)
    month = service.parse_iso((request.args.get('month') or '') + '-01')
    month = month or ctx['today'].replace(day=1)
    return towers, tower_id, month


@leave_tracker_bp.route('/export.xlsx')
def export_calendar():
    """The tower calendar for one month, as Excel.

    Same access as the dashboard: a tower the viewer cannot open is never
    exported - an id for one is replaced by the viewer's own tower, exactly
    as the dashboard does. Reason and notes are included only for a lead of
    this tower or an administrator.
    """
    user, bounce = _require_login()
    if bounce:
        return bounce
    db = get_db_session()
    try:
        ctx = _base_context(user, db)
        towers, tower_id, month = _resolve_tower_month(db, user, ctx)
        if tower_id is None:
            abort(404)
        first, _last = service.month_bounds(month)
        data = service.dashboard(db, tower_id, first, ctx['today'])
        tower_name = dict(towers).get(tower_id, 'Tower')

        # Backups can sit in another of the owner's towers, so name them
        # all, and find the days each backup is away too.
        items = report_excel.month_requests(data)
        backup_ids = {r.backup_user_id for r, _d in items if r.backup_user_id}
        backup_names = {}
        if backup_ids:
            for p in db.query(User).filter(User.id.in_(backup_ids)).all():
                backup_names[p.id] = service.display_name(p)
        clashes = {}
        for req, days in items:
            hit = service.backup_clashes(db, req.backup_user_id, days)
            if hit:
                clashes[req.id] = hit

        include_private = (service.is_admin(user) or
                           service.is_lead_of_tower(db, user.id, tower_id))
        payload = report_excel.build_calendar_workbook(
            data, tower_name, first, include_private=include_private,
            viewer_name=service.display_name(user), today=ctx['today'],
            summarise_dates=service.summarise_dates,
            backup_names=backup_names, backup_clashes=clashes)
    finally:
        db.close()

    safe = re.sub(r'[^A-Za-z0-9]+', '_', tower_name).strip('_') or 'tower'
    return send_file(
        io.BytesIO(payload),
        mimetype='application/vnd.openxmlformats-officedocument.'
                 'spreadsheetml.sheet',
        as_attachment=True,
        download_name='leave_{0}_{1}.xlsx'.format(safe,
                                                 first.strftime('%Y-%m')))


# ===========================================================================
# My leave
# ===========================================================================

@leave_tracker_bp.route('/mine')
def mine():
    user, bounce = _require_login()
    if bounce:
        return bounce
    db = get_db_session()
    try:
        ctx = _base_context(user, db)
        allow = ctx['settings']['allow_same_day_changes']
        rows = []
        backup_ids = set()
        for req in service.my_requests(db, user.id):
            rows.append((req, service.request_state(req, ctx['today'],
                                                    allow)))
            if req.backup_user_id:
                backup_ids.add(req.backup_user_id)
        backups = {}
        if backup_ids:
            for p in db.query(User).filter(User.id.in_(backup_ids)).all():
                backups[p.id] = service.display_name(p)
        upcoming = [r for r in rows if r[1]['tone'] in ('go', 'live')]
        history = [r for r in rows if r[1]['tone'] not in ('go', 'live')]
        year_days = sum(len([d for d in req.active_dates
                             if d.year == ctx['today'].year])
                        for req, _s in rows if not req.is_cancelled)
        return render_template(
            'leave_tracker/mine.html', upcoming=upcoming, history=history,
            backups=backups, year_days=year_days,
            can_request=bool(service.user_tower_ids(db, user.id)), **ctx)
    finally:
        db.close()


# ===========================================================================
# Create and edit
# ===========================================================================

def _render_form(db, user, ctx, values, req=None, state=None, errors=None,
                 status=200):
    backups = service.backup_choices(db, user)
    leads = service.leads_for_user(db, user.id)
    return render_template(
        'leave_tracker/form.html', values=values, req=req, state=state,
        errors=errors or [], backups=backups,
        lead_names=[service.display_name(p) for p, _ in leads],
        date_modes=service.DATE_MODES, max_days=service.MAX_DAYS,
        backdate_days=service.BACKDATE_DAYS, reason_max=REASON_MAX,
        notes_max=NOTES_MAX, **ctx), status


@leave_tracker_bp.route('/new', methods=['GET', 'POST'])
def create():
    user, bounce = _require_login()
    if bounce:
        return bounce
    db = get_db_session()
    try:
        ctx = _base_context(user, db)
        if not service.user_tower_ids(db, user.id):
            flash('You are not a member of any support tower yet, so there is '
                  'no tower lead to notify. Ask an administrator to add you '
                  'to your tower.', 'warning')
            return redirect(url_for('leave_tracker.index'))

        if request.method == 'GET':
            values = {'leave_type': '', 'mode': service.MODE_SINGLE,
                      'single': '', 'date_from': '', 'date_to': '',
                      'skip_non_working': True, 'multi': '', 'reason': '',
                      'backup_user_id': None, 'notes': ''}
            return _render_form(db, user, ctx, values)

        values = _form_values(request.form)
        days, errors = service.expand_dates(
            db, values['mode'], values['single'], values['date_from'],
            values['date_to'], values['skip_non_working'], values['multi'])
        if not errors:
            req, errors = service.create_request(
                db, user, values['leave_type'], days, values['reason'],
                values['backup_user_id'], values['notes'], ctx['today'])
        if errors:
            return _render_form(db, user, ctx, values, errors=errors,
                                status=400)

        outcome = _notify(db, 'created', req, user)
        _flash_notify(outcome, 'booked')
        _flash_rota(db, req, user)
        clash = service.backup_clashes(db, req.backup_user_id,
                                       req.active_dates)
        if clash:
            flash('Heads up: your backup is also on leave on {0}.'
                  .format(service.summarise_dates(clash)), 'warning')
        return redirect(url_for('leave_tracker.detail', request_id=req.id))
    finally:
        db.close()


@leave_tracker_bp.route('/<int:request_id>/edit', methods=['GET', 'POST'])
def edit(request_id):
    user, bounce = _require_login()
    if bounce:
        return bounce
    db = get_db_session()
    try:
        ctx = _base_context(user, db)
        req = _load_request(db, request_id)
        # Only the owner. Anybody else - an admin included - gets a 404.
        if req.user_id != user.id:
            abort(404)
        allow = ctx['settings']['allow_same_day_changes']
        state = service.request_state(req, ctx['today'], allow)
        if not state['can_edit']:
            flash('This leave can no longer be edited - its dates have '
                  'arrived.', 'warning')
            return redirect(url_for('leave_tracker.detail',
                                    request_id=req.id))

        if request.method == 'GET':
            values = {
                'leave_type': req.leave_type, 'mode': service.MODE_MULTI,
                'single': '', 'date_from': '', 'date_to': '',
                'skip_non_working': True,
                'multi': ','.join(d.isoformat()
                                  for d in state['open_dates']),
                'reason': req.reason or '',
                'backup_user_id': req.backup_user_id,
                'notes': req.notes or '',
            }
            return _render_form(db, user, ctx, values, req=req, state=state)

        values = _form_values(request.form)
        days, errors = service.expand_dates(
            db, values['mode'], values['single'], values['date_from'],
            values['date_to'], values['skip_non_working'], values['multi'])
        changes = None
        if not errors:
            changes, errors = service.update_request(
                db, user, req, values['leave_type'], days, values['reason'],
                values['backup_user_id'], values['notes'], ctx['today'],
                allow)
        if errors:
            return _render_form(db, user, ctx, values, req=req, state=state,
                                errors=errors, status=400)

        outcome = _notify(db, 'updated', req, user, changes=changes)
        _flash_notify(outcome, 'updated')
        _flash_rota(db, req, user)
        return redirect(url_for('leave_tracker.detail', request_id=req.id))
    finally:
        db.close()


@leave_tracker_bp.route('/<int:request_id>/cancel', methods=['POST'])
@csrf_protect
def cancel(request_id):
    user, bounce = _require_login()
    if bounce:
        return bounce
    db = get_db_session()
    try:
        ctx = _base_context(user, db)
        req = _load_request(db, request_id)
        if req.user_id != user.id:
            abort(404)
        allow = ctx['settings']['allow_same_day_changes']
        result, errors = service.cancel_request(db, user, req, ctx['today'],
                                                allow)
        if errors:
            for message in errors:
                flash(message, 'error')
            return redirect(url_for('leave_tracker.detail',
                                    request_id=req.id))
        outcome_kind, withdrawn = result
        outcome = _notify(db, outcome_kind, req, user, withdrawn=withdrawn)
        _flash_notify(outcome, 'cancelled' if outcome_kind == 'cancelled'
                      else 'shortened - the remaining days are withdrawn')
        return redirect(url_for('leave_tracker.mine'))
    finally:
        db.close()


# ===========================================================================
# Detail
# ===========================================================================

@leave_tracker_bp.route('/<int:request_id>')
def detail(request_id):
    user, bounce = _require_login()
    if bounce:
        return bounce
    db = get_db_session()
    try:
        ctx = _base_context(user, db)
        req = _load_request(db, request_id)
        if not service.can_view_request(db, user, req):
            abort(404)
        allow = ctx['settings']['allow_same_day_changes']
        state = service.request_state(req, ctx['today'], allow)
        owner = db.query(User).filter_by(id=req.user_id).first()
        backup = (db.query(User).filter_by(id=req.backup_user_id).first()
                  if req.backup_user_id else None)
        clash = []
        if backup is not None and not req.is_cancelled:
            clash = service.backup_clashes(
                db, backup.id, [d for d in req.active_dates
                                if d >= ctx['today']])
        return render_template(
            'leave_tracker/detail.html', req=req, state=state, owner=owner,
            backup=backup, is_owner=req.user_id == user.id,
            show_private=service.can_see_private(db, user, req),
            backup_clash=clash, **ctx)
    finally:
        db.close()


# ===========================================================================
# Settings
# ===========================================================================

@leave_tracker_bp.route('/settings', methods=['GET', 'POST'])
def settings():
    user, bounce = _require_login()
    if bounce:
        return bounce
    if not service.is_admin(user):
        abort(403)
    db = get_db_session()
    try:
        if request.method == 'POST':
            service.save_settings(
                db, request.form.get('allow_same_day_changes') == '1', user)
            flash('Leave Tracker settings saved.', 'success')
            return redirect(url_for('leave_tracker.settings'))
        ctx = _base_context(user, db)
        return render_template('leave_tracker/settings.html', **ctx)
    finally:
        db.close()
