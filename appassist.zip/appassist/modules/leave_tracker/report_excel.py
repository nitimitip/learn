"""
report_excel.py - the tower leave calendar as an Excel workbook.

Pure: plain data in (the dict service.dashboard() already builds for the
screen), bytes out. Building from the SAME dict the dashboard renders means
the download can never disagree with the page it was downloaded from.

THREE SHEETS
    Calendar    the month grid: one row per person, one column per day, each
                leave day filled in its type colour AND carrying its letter
                (colour is never the only carrier), a people-out row, month
                and year totals, weekends and public holidays shaded
    Leave list  one row per request touching the month, filterable
    Summary     days by type (month and year) and days per person

PRIVACY. The reason and notes columns are written only when the caller says
the viewer may read them (a lead of this tower, or an administrator) - the
same rule the detail screen applies. Everyone else gets the sheet without
them, not with them blanked, so nothing suggests they were withheld per row.
"""

import io
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .models import LEAVE_TYPE_CODES, LEAVE_TYPES

# NPg brand, as the other workbooks use it (see user_profile/access_report).
BRAND = 'AB1236'
BRAND_DK = '7E0D27'
BAND = 'F1F5F9'
BORDER = 'D7DEE7'
TEXT = '1D293D'
MUTED = '6B7280'
WEEKEND = 'EEF1F6'
HOLIDAY = 'FBF1DC'
TODAY = 'E4EFD8'

# The categorical slots leave.css uses, in the same order, and the ink that
# reads on each (dark on the light fills, white on the deep ones).
TYPE_FILL = {
    'festival': '2A78D6', 'sick': 'EB6834', 'unplanned': '1BAF7A',
    'comp_off': 'EDA100', 'casual': 'E87BA4', 'annual': '008300',
}
TYPE_INK = {
    'festival': 'FFFFFF', 'sick': '1A1F2B', 'unplanned': '1A1F2B',
    'comp_off': '1A1F2B', 'casual': '1A1F2B', 'annual': 'FFFFFF',
}

_thin = Side(style='thin', color=BORDER)
_BOX = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)
_CENTER = Alignment(horizontal='center', vertical='center')
_WRAP = Alignment(vertical='top', wrap_text=True)


def _fill(hex_colour):
    return PatternFill('solid', start_color=hex_colour, end_color=hex_colour)


def _title(ws, text, sub, width_cols):
    ws.cell(row=1, column=1, value=text).font = Font(
        bold=True, size=14, color='FFFFFF')
    ws.cell(row=2, column=1, value=sub).font = Font(size=10, color='FFFFFF')
    for row, colour in ((1, BRAND), (2, BRAND_DK)):
        for col in range(1, width_cols + 1):
            ws.cell(row=row, column=col).fill = _fill(colour)
    ws.row_dimensions[1].height = 24


def _header_row(ws, row, labels):
    for col, label in enumerate(labels, start=1):
        cell = ws.cell(row=row, column=col, value=label)
        cell.font = Font(bold=True, color='FFFFFF', size=10)
        cell.fill = _fill(BRAND_DK)
        cell.alignment = Alignment(horizontal='left', vertical='center',
                                   wrap_text=True)
        cell.border = _BOX


def _print_setup(ws, landscape=True, header_rows=None):
    ws.page_setup.orientation = 'landscape' if landscape else 'portrait'
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    if header_rows:
        ws.print_title_rows = header_rows
    ws.oddFooter.center.text = 'Page &P of &N'


def month_requests(data):
    """[(request, [days in this month])] for every request on the grid,
    ordered by the person then the first day."""
    by_id = {}
    for row in data['rows']:
        for day, req in zip(data['days'], row['cells']):
            if req is None:
                continue
            by_id.setdefault(req.id, (req, []))[1].append(day)
    out = list(by_id.values())
    out.sort(key=lambda item: (data['names'].get(item[0].user_id, ''),
                               min(item[1])))
    return out


def build_calendar_workbook(data, tower_name, month, *, include_private,
                            viewer_name, today, summarise_dates,
                            backup_names=None, backup_clashes=None):
    """Bytes of the .xlsx for one tower and one month.

    `data` is service.dashboard(); `backup_names` maps user id -> name for
    backups outside the tower; `backup_clashes` maps request id -> the days in
    the month its backup is away too.
    """
    backup_names = backup_names or {}
    backup_clashes = backup_clashes or {}
    names = dict(data['names'])
    names.update(backup_names)
    days = data['days']
    stamp = 'Generated {0} by {1}'.format(
        datetime.now().strftime('%d %b %Y %H:%M'), viewer_name)

    wb = Workbook()

    # ------------------------------------------------------------ Calendar
    ws = wb.active
    ws.title = 'Calendar'
    first_day_col = 3
    total_cols = first_day_col + len(days) + 1
    _title(ws, 'Leave calendar - {0} - {1}'.format(
        tower_name, month.strftime('%B %Y')), stamp, total_cols)

    ws.cell(row=4, column=1, value='Team member')
    ws.cell(row=4, column=2, value='Role')
    for i, day in enumerate(days):
        col = first_day_col + i
        ws.cell(row=4, column=col, value=day.strftime('%a')[:2])
        ws.cell(row=5, column=col, value=day.day)
    ws.cell(row=4, column=first_day_col + len(days), value='Month')
    ws.cell(row=4, column=first_day_col + len(days) + 1,
            value=str(month.year))
    for row in (4, 5):
        for col in range(1, total_cols + 1):
            cell = ws.cell(row=row, column=col)
            cell.font = Font(bold=True, color='FFFFFF', size=9)
            cell.fill = _fill(BRAND_DK)
            cell.alignment = _CENTER
            cell.border = _BOX
    ws.merge_cells(start_row=4, start_column=1, end_row=5, end_column=1)
    ws.merge_cells(start_row=4, start_column=2, end_row=5, end_column=2)

    # People-out row.
    load_row = 6
    ws.cell(row=load_row, column=1, value='People out').font = Font(
        bold=True, color=MUTED, size=9)
    for i, count in enumerate(data['per_day']):
        cell = ws.cell(row=load_row, column=first_day_col + i,
                       value=count or None)
        cell.alignment = _CENTER
        cell.font = Font(bold=count == data['peak'] and count > 0,
                         color=TEXT, size=9)
        cell.border = _BOX
        cell.fill = _fill(BAND)
    for col in (1, 2, first_day_col + len(days), total_cols):
        ws.cell(row=load_row, column=col).fill = _fill(BAND)
        ws.cell(row=load_row, column=col).border = _BOX

    row_no = load_row + 1
    for person in data['rows']:
        ws.cell(row=row_no, column=1, value=person['name']).font = Font(
            bold=True, color=TEXT, size=10)
        ws.cell(row=row_no, column=2,
                value='Lead' if person['is_lead'] else 'Member').font = Font(
                    color=MUTED, size=9)
        for i, req in enumerate(person['cells']):
            day = days[i]
            cell = ws.cell(row=row_no, column=first_day_col + i)
            cell.alignment = _CENTER
            cell.border = _BOX
            if req is not None:
                cell.value = LEAVE_TYPE_CODES.get(req.leave_type, '?')
                cell.fill = _fill(TYPE_FILL.get(req.leave_type, '999999'))
                cell.font = Font(bold=True, size=9,
                                 color=TYPE_INK.get(req.leave_type, 'FFFFFF'))
            elif day in data['holidays']:
                cell.fill = _fill(HOLIDAY)
            elif day.weekday() >= 5:
                cell.fill = _fill(WEEKEND)
            elif day == today:
                cell.fill = _fill(TODAY)
        month_cell = ws.cell(row=row_no, column=first_day_col + len(days),
                             value=person['month_days'])
        year_cell = ws.cell(row=row_no, column=total_cols,
                            value=person['year_days'])
        for cell in (month_cell, year_cell):
            cell.alignment = _CENTER
            cell.border = _BOX
        month_cell.font = Font(bold=True, color=TEXT)
        for col in (1, 2):
            ws.cell(row=row_no, column=col).border = _BOX
        row_no += 1

    # Legend, under the grid.
    row_no += 1
    ws.cell(row=row_no, column=1, value='Key').font = Font(bold=True,
                                                           color=TEXT)
    row_no += 1
    for key, label in LEAVE_TYPES:
        code = ws.cell(row=row_no, column=2, value=LEAVE_TYPE_CODES[key])
        code.fill = _fill(TYPE_FILL[key])
        code.font = Font(bold=True, color=TYPE_INK[key])
        code.alignment = _CENTER
        ws.cell(row=row_no, column=1, value=label)
        row_no += 1
    for fill, label in ((WEEKEND, 'Weekend'), (HOLIDAY, 'Public holiday'),
                        (TODAY, 'Today')):
        ws.cell(row=row_no, column=2).fill = _fill(fill)
        ws.cell(row=row_no, column=1, value=label)
        row_no += 1
    if data['holidays']:
        row_no += 1
        ws.cell(row=row_no, column=1, value='Public holidays').font = Font(
            bold=True, color=TEXT)
        for day, name in sorted(data['holidays'].items()):
            row_no += 1
            ws.cell(row=row_no, column=1, value=day.strftime('%a %d %b'))
            ws.cell(row=row_no, column=2, value=name)

    ws.column_dimensions['A'].width = 26
    ws.column_dimensions['B'].width = 9
    for i in range(len(days)):
        ws.column_dimensions[get_column_letter(first_day_col + i)].width = 4.2
    ws.column_dimensions[get_column_letter(first_day_col + len(days))].width = 8
    ws.column_dimensions[get_column_letter(total_cols)].width = 8
    ws.freeze_panes = ws.cell(row=load_row + 1, column=first_day_col)
    _print_setup(ws, landscape=True, header_rows='4:6')

    # ---------------------------------------------------------- Leave list
    ws = wb.create_sheet('Leave list')
    headers = ['Name', 'Leave type', 'Dates this month', 'Days this month',
               'All dates on the request', 'Total days', 'Backup',
               'Backup also away', 'Status', 'Booked on']
    if include_private:
        headers += ['Reason', 'Notes']
    _title(ws, 'Leave list - {0} - {1}'.format(
        tower_name, month.strftime('%B %Y')),
        stamp + ('' if include_private else
                 ' - reason and notes are visible to tower leads and '
                 'administrators only'), len(headers))
    _header_row(ws, 4, headers)
    row_no = 5
    items = month_requests(data)
    for req, in_month in items:
        clash = backup_clashes.get(req.id) or []
        values = [
            names.get(req.user_id, ''),
            req.type_label,
            summarise_dates(in_month),
            len(in_month),
            summarise_dates(req.active_dates),
            len(req.active_dates),
            names.get(req.backup_user_id, '') if req.backup_user_id else '',
            summarise_dates(clash) if clash else '',
            'Part withdrawn' if req.withdrawn_dates else 'Booked',
            req.created_at,
        ]
        if include_private:
            values += [req.reason or '', req.notes or '']
        for col, value in enumerate(values, start=1):
            cell = ws.cell(row=row_no, column=col, value=value)
            cell.border = _BOX
            cell.alignment = _WRAP
            if row_no % 2 == 0:
                cell.fill = _fill('F8FAFC')
        ws.cell(row=row_no, column=10).number_format = 'dd mmm yyyy hh:mm'
        type_cell = ws.cell(row=row_no, column=2)
        type_cell.fill = _fill(TYPE_FILL.get(req.leave_type, 'FFFFFF'))
        type_cell.font = Font(bold=True,
                              color=TYPE_INK.get(req.leave_type, TEXT))
        if clash:
            ws.cell(row=row_no, column=8).font = Font(bold=True,
                                                      color='8A4308')
        row_no += 1
    if not items:
        ws.cell(row=5, column=1, value='No leave booked in this month.')
    widths = [24, 13, 30, 10, 34, 9, 22, 22, 14, 17, 40, 40]
    for col, width in enumerate(widths[:len(headers)], start=1):
        ws.column_dimensions[get_column_letter(col)].width = width
    ws.freeze_panes = 'B5'
    if items:
        ws.auto_filter.ref = 'A4:{0}{1}'.format(
            get_column_letter(len(headers)), row_no - 1)
    _print_setup(ws, landscape=True, header_rows='4:4')

    # ------------------------------------------------------------- Summary
    ws = wb.create_sheet('Summary')
    _title(ws, 'Summary - {0} - {1}'.format(
        tower_name, month.strftime('%B %Y')), stamp, 4)
    month_by_type = {key: 0 for key, _ in LEAVE_TYPES}
    for _req, in_month in items:
        month_by_type[_req.leave_type] = \
            month_by_type.get(_req.leave_type, 0) + len(in_month)

    facts = [
        ('Team members', data['team_size']),
        ('Tower lead(s)', ', '.join(data['lead_names']) or 'None named'),
        ('Leave days this month', data['month_total']),
        ('Busiest day (people out)', data['peak']),
        ('Leave days in {0}'.format(month.year), data['year_total']),
    ]
    row_no = 4
    for label, value in facts:
        ws.cell(row=row_no, column=1, value=label).font = Font(bold=True,
                                                               color=TEXT)
        ws.cell(row=row_no, column=2, value=value)
        row_no += 1

    row_no += 1
    _header_row(ws, row_no, ['Leave type', 'Days this month',
                                'Days in {0}'.format(month.year)])
    row_no += 1
    for key, label, year_count in data['by_type']:
        ws.cell(row=row_no, column=1, value=label).fill = _fill(TYPE_FILL[key])
        ws.cell(row=row_no, column=1).font = Font(bold=True,
                                                  color=TYPE_INK[key])
        ws.cell(row=row_no, column=2, value=month_by_type.get(key, 0))
        ws.cell(row=row_no, column=3, value=year_count)
        for col in (1, 2, 3):
            ws.cell(row=row_no, column=col).border = _BOX
        row_no += 1

    row_no += 1
    _header_row(ws, row_no, ['Team member', 'Days this month',
                                'Days in {0}'.format(month.year), 'Role'])
    row_no += 1
    for person in data['rows']:
        values = [person['name'], person['month_days'], person['year_days'],
                  'Lead' if person['is_lead'] else 'Member']
        for col, value in enumerate(values, start=1):
            ws.cell(row=row_no, column=col, value=value).border = _BOX
        row_no += 1
    for col, width in zip('ABCD', (30, 22, 16, 12)):
        ws.column_dimensions[col].width = width
    _print_setup(ws, landscape=False)

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()

