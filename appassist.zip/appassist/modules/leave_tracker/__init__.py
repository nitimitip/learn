"""
Leave Tracker module (Workforce).

    A person books leave -> their tower leads are emailed -> the tower sees
    who is out, when, and who is covering.

Three tables (models.py), one blueprint (routes.py), and the rules in
service.py. Tower membership and tower leads are not stored here - they are
read live from Application Support's tower_members.
"""

from .routes import leave_tracker_bp

__all__ = ['leave_tracker_bp']
