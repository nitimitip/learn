"""
Project milestones & tasks -> professional multi-sheet Excel workbook.

Replaces the old flat CSV task dump. Produces:
    1. Project Overview   - project metadata + roll-up KPIs
    2. Milestone Summary  - one row per milestone (window, status, progress)
    3. Task Detail        - tasks grouped under collapsible milestone headers
                            (Excel row outline), colour-coded status chips.

Styling uses the NPG (Northern Powergrid) red brand palette so the file reads
as a deliverable from the same system rather than a raw export.
"""

from __future__ import annotations

import io
from datetime import date, datetime, timedelta

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.formatting.rule import DataBarRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.page import PageMargins
from openpyxl.worksheet.properties import PageSetupProperties

from .models import RISK_PROBABILITY_LABELS, RISK_IMPACT_LABELS

# Brand palette - NPG (Northern Powergrid) red
BRAND     = "AB1236"   # NPG red - title bands & section headers
BRAND_DK  = "7E0D27"   # darker NPG red - subtitles & column-header rows
BAND      = "F1F5F9"
BORDER    = "D7DEE7"
TEXT      = "1D293D"
MUTED     = "6B7280"
MS_BG     = "E8EDF3"   # milestone group-header fill

# Task status -> (fill, font) chip colours.
STATUS_FILL = {
    "Not Started": ("E2E8F0", "1D293D"),
    "In Progress": ("DBEAFE", "1E40AF"),
    "Hold":        ("FEF3C7", "92400E"),
    "Completed":   ("DCFCE7", "166534"),
    "Overdue":     ("FEE2E2", "991B1B"),
}

# RAG health (derived from the target end date) -> (fill, font, label).
RAG = {
    "green":   ("D1FADF", "166534", "On track"),
    "amber":   ("FEF0C7", "92400E", "At risk"),
    "red":     ("FEE2E2", "991B1B", "Off track"),
    "neutral": ("E2E8F0", "1D293D", "-"),
}

# Risk status -> (fill, font) chip colours (register sheet).
RISK_STATUS_FILL = {
    "Open":      ("FEE2E2", "991B1B"),
    "Mitigated": ("DBEAFE", "1E40AF"),
    "Closed":    ("DCFCE7", "166534"),
}

# Issue status -> (fill, font) chip colours (issue log sheet).
ISSUE_STATUS_FILL = {
    "Open":        ("FEE2E2", "991B1B"),
    "In Progress": ("DBEAFE", "1E40AF"),
    "Resolved":    ("DCFCE7", "166534"),
    "Closed":      ("E2E8F0", "1D293D"),
}

# SDLC gate-state label -> (fill, font) chip colours.
SDLC_STATE_FILL = {
    "Gate passed":        ("DCFCE7", "166534"),
    "Ready for sign-off": ("DBEAFE", "1E40AF"),
    "In progress":        ("FEF3C7", "92400E"),
    "Not started":        ("E2E8F0", "1D293D"),
    "Not assigned":       ("FEE2E2", "991B1B"),
}

_THIN = Side(style="thin", color=BORDER)
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

CENTER   = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT     = Alignment(horizontal="left", vertical="center", wrap_text=True)
LEFT_TOP = Alignment(horizontal="left", vertical="top", wrap_text=True)


def _fmt_date(value) -> str:
    if not value:
        return ""
    if isinstance(value, (date, datetime)):
        return value.strftime("%d %b %Y")
    return str(value)


def _title_band(ws, title, subtitle, ncols):
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    c = ws.cell(row=1, column=1, value=title)
    c.font = Font(name="Calibri", size=15, bold=True, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=BRAND)
    c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[1].height = 30

    if subtitle:
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
        s = ws.cell(row=2, column=1, value=subtitle)
        s.font = Font(name="Calibri", size=10, italic=True, color="FFFFFF")
        s.fill = PatternFill("solid", fgColor=BRAND_DK)
        s.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        ws.row_dimensions[2].height = 20
        return 4
    return 3


def _header_row(ws, row, headers):
    for col, label in enumerate(headers, start=1):
        cell = ws.cell(row=row, column=col, value=label)
        cell.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=BRAND_DK)
        cell.alignment = CENTER
        cell.border = _BORDER
    ws.row_dimensions[row].height = 26


def _autosize(ws, widths):
    for idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width


def _print_setup(ws, orientation="landscape", repeat_rows=None):
    """Print-ready page setup: fit to one page wide, repeated header rows and
    a page-number footer, so the sheet prints as a deliverable without the
    recipient having to fight Excel's defaults."""
    ws.page_setup.orientation = orientation
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    ws.page_margins = PageMargins(left=0.4, right=0.4, top=0.5, bottom=0.55,
                                  header=0.2, footer=0.25)
    if repeat_rows:
        ws.print_title_rows = repeat_rows
    ws.oddFooter.left.text = "NPg AppAssist - Project Management"
    ws.oddFooter.left.size = 8
    ws.oddFooter.left.color = MUTED
    ws.oddFooter.right.text = "Page &P of &N"
    ws.oddFooter.right.size = 8
    ws.oddFooter.right.color = MUTED


def _chip(cell, fill, font_clr, bold=True):
    """Apply a coloured chip style to a cell in place."""
    cell.fill = PatternFill("solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=10, bold=bold, color=font_clr)
    cell.alignment = CENTER
    cell.border = _BORDER


def _empty_row(ws, row, ncols, message, indent=0):
    """Merged, muted 'nothing to show' row used by every list sheet."""
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=message)
    c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
    c.alignment = (Alignment(horizontal="left", vertical="center", indent=indent)
                   if indent else CENTER)


def _style_cell(cell, banded=False, center=False):
    cell.font = Font(name="Calibri", size=10, color=TEXT)
    cell.alignment = CENTER if center else LEFT_TOP
    cell.border = _BORDER
    if banded:
        cell.fill = PatternFill("solid", fgColor=BAND)


def _status_chip(cell, status):
    fill, font_clr = STATUS_FILL.get(status, ("E2E8F0", TEXT))
    cell.fill = PatternFill("solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=10, bold=True, color=font_clr)
    cell.alignment = CENTER
    cell.border = _BORDER


def _sorted_milestones(project):
    return sorted(project.milestones,
                  key=lambda m: (m.start_date or m.end_date, m.end_date, m.id))


# Sheet 1: Overview
def _build_overview(ws, project):
    _autosize(ws, [26, 88])
    row = _title_band(ws, f"Project Plan - {project.name}", "Project Overview", 2)

    all_tasks = project.get_all_tasks()
    completed = [t for t in all_tasks if t.status.value == "Completed"]
    overdue   = [t for t in all_tasks if t.is_overdue()]

    def field(label, value, kpi=False):
        nonlocal row
        lc = ws.cell(row=row, column=1, value=label)
        lc.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        lc.fill = PatternFill("solid", fgColor=BRAND_DK)
        lc.alignment = LEFT_TOP
        lc.border = _BORDER
        vc = ws.cell(row=row, column=2, value=value if value not in (None, "") else "-")
        vc.font = Font(name="Calibri", size=11 if kpi else 10,
                       bold=kpi, color=TEXT)
        vc.alignment = LEFT_TOP
        vc.border = _BORDER
        ws.row_dimensions[row].height = 22
        row += 1

    field("Project Name", project.name)
    field("Status", project.status.value if project.status else "")
    field("Goal / Objective", project.goal_objective or "")
    field("Description", project.description or "")
    field("Start Date", _fmt_date(project.start_date))
    field("Target End Date", _fmt_date(project.target_end_date))
    row += 1  # spacer

    # KPI block header
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=2)
    h = ws.cell(row=row, column=1, value="Summary")
    h.font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    h.fill = PatternFill("solid", fgColor=BRAND)
    h.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row].height = 22
    row += 1

    field("Total Milestones", len(project.milestones), kpi=True)
    field("Total Tasks", len(all_tasks), kpi=True)
    field("Completed Tasks", len(completed), kpi=True)
    field("Completion", f"{project.get_completion_percentage()}%", kpi=True)
    field("Overdue Tasks", len(overdue), kpi=True)
    open_risks = [r for r in project.risk_logs if r.status.value == "Open"]
    open_issues = project.get_open_issues()
    field("Open Risks", f"{len(open_risks)} ({len(project.get_open_high_risks())} high / critical)", kpi=True)
    field("Open Issues", f"{len(open_issues)} ({sum(1 for i in open_issues if i.is_overdue())} overdue)", kpi=True)
    field("Generated", datetime.now().strftime("%d %b %Y %H:%M"))


# Sheet 2: Milestone Summary
def _build_milestone_summary(ws, project):
    headers = ["#", "Milestone", "Start", "Deadline", "Status",
               "Tasks", "Completed", "Progress"]
    _autosize(ws, [5, 34, 16, 16, 16, 9, 11, 12])
    row = _title_band(ws, "Milestone Summary",
                      "One row per milestone", len(headers))
    _header_row(ws, row, headers)
    ws.freeze_panes = ws.cell(row=row + 1, column=1)
    row += 1

    milestones = _sorted_milestones(project)
    if not milestones:
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=len(headers))
        c = ws.cell(row=row, column=1, value="No milestones defined.")
        c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
        c.alignment = CENTER
        return

    for i, ms in enumerate(milestones, start=1):
        banded = (i % 2 == 0)
        done = sum(1 for t in ms.tasks if t.status.value == "Completed")
        values = [
            i, ms.name, _fmt_date(ms.start_date), _fmt_date(ms.end_date),
            ms.status.value, len(ms.tasks), done,
            f"{ms.completion_percentage}%",
        ]
        for col, val in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=val)
            _style_cell(cell, banded, center=(col in (1, 3, 4, 6, 7, 8)))
        # Status chip on the Status column (col 5)
        st = values[4]
        _status_chip(ws.cell(row=row, column=5), st)
        row += 1


# Priority -> (fill, font) chip colours.
PRIORITY_FILL = {
    "Critical": ("FEE2E2", "991B1B"),
    "High":     ("FFEDD5", "9A3412"),
    "Medium":   ("DBEAFE", "1E40AF"),
    "Low":      ("E2E8F0", "475569"),
}


# Sheet 3: Task Detail (grouped under milestones)
def _build_task_detail(ws, project, name_map, task_extras=None):
    """task_extras: {task_id: {'priority','percent','predecessors','critical',
    'baseline_end','slip'}} - Phase-4 columns; omitted values render blank."""
    task_extras = task_extras or {}
    headers = ["Task", "Category", "Priority", "% Done", "Assigned To",
               "Start", "End", "Status", "Overdue",
               "Predecessors", "Critical Path", "Baseline End", "Slip (d)"]
    _autosize(ws, [30, 20, 11, 9, 20, 13, 13, 13, 9, 26, 12, 14, 9])
    row = _title_band(ws, "Task Detail",
                      "Tasks grouped by milestone (use the +/- outline to collapse)",
                      len(headers))
    _header_row(ws, row, headers)
    ws.freeze_panes = ws.cell(row=row + 1, column=1)
    # Milestone header rows are the group summary; keep them ABOVE their tasks.
    ws.sheet_properties.outlinePr.summaryBelow = False
    ws.auto_filter.ref = f"A{row}:{get_column_letter(len(headers))}{row}"
    row += 1

    milestones = _sorted_milestones(project)
    if not milestones:
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=len(headers))
        c = ws.cell(row=row, column=1, value="No milestones or tasks to display.")
        c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
        c.alignment = CENTER
        return

    for ms in milestones:
        # Milestone group header (merged band)
        done = sum(1 for t in ms.tasks if t.status.value == "Completed")
        win = ""
        if ms.start_date:
            win = f"{_fmt_date(ms.start_date)} -> "
        win += _fmt_date(ms.end_date)
        label = (f">  {ms.name}    "
                 f"[{ms.status.value} - {ms.completion_percentage}% - "
                 f"{done}/{len(ms.tasks)} tasks - {win}]")
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=len(headers))
        hc = ws.cell(row=row, column=1, value=label)
        hc.font = Font(name="Calibri", size=11, bold=True, color=BRAND)
        hc.fill = PatternFill("solid", fgColor=MS_BG)
        hc.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        for col in range(1, len(headers) + 1):
            ws.cell(row=row, column=col).border = _BORDER
        ws.row_dimensions[row].height = 24
        row += 1

        tasks = sorted(ms.tasks, key=lambda t: (t.start_date or date.max, t.id))
        if not tasks:
            ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=len(headers))
            c = ws.cell(row=row, column=1, value="No tasks in this milestone.")
            c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
            c.alignment = Alignment(horizontal="left", vertical="center", indent=2)
            ws.row_dimensions[row].outline_level = 1
            for col in range(1, len(headers) + 1):
                ws.cell(row=row, column=col).border = _BORDER
            row += 1
            continue

        for i, t in enumerate(tasks):
            banded = (i % 2 == 1)
            overdue = t.is_overdue()
            assigned = (name_map.get(t.assigned_to, "") if t.assigned_to else "Unassigned")
            extra = task_extras.get(t.id, {})
            category = t.category or ""
            if t.sub_category:
                category = f"{category} > {t.sub_category}" if category else t.sub_category
            slip = extra.get("slip")
            values = [
                t.name, category,
                extra.get("priority", ""),
                f"{extra.get('percent')}%" if extra.get("percent") is not None else "",
                assigned,
                _fmt_date(t.start_date), _fmt_date(t.end_date),
                t.status.value, "Yes" if overdue else "No",
                extra.get("predecessors", ""),
                "Yes" if extra.get("critical") else "",
                _fmt_date(extra.get("baseline_end")),
                (f"+{slip}" if slip and slip > 0 else str(slip)) if slip is not None else "",
            ]
            for col, val in enumerate(values, start=1):
                cell = ws.cell(row=row, column=col, value=val)
                _style_cell(cell, banded, center=(col in (3, 4, 6, 7, 9, 11, 12, 13)))
            # Priority chip (col 3) and status chip (col 8, Overdue colour wins).
            prio = extra.get("priority")
            if prio in PRIORITY_FILL:
                p_fill, p_font = PRIORITY_FILL[prio]
                pc = ws.cell(row=row, column=3)
                pc.fill = PatternFill("solid", fgColor=p_fill)
                pc.font = Font(name="Calibri", size=10, bold=True, color=p_font)
                pc.alignment = CENTER
                pc.border = _BORDER
            _status_chip(ws.cell(row=row, column=8), "Overdue" if overdue else t.status.value)
            if overdue:
                oc = ws.cell(row=row, column=9)
                oc.font = Font(name="Calibri", size=10, bold=True, color="991B1B")
            if extra.get("critical"):
                cc = ws.cell(row=row, column=11)
                cc.font = Font(name="Calibri", size=10, bold=True, color=BRAND)
            if slip is not None and slip > 0:
                sc = ws.cell(row=row, column=13)
                sc.font = Font(name="Calibri", size=10, bold=True, color="991B1B")
            ws.row_dimensions[row].outline_level = 1  # collapsible under milestone
            row += 1


# ---------------------------------------------------------------------------
# Portfolio report (dashboard-filtered export)
# ---------------------------------------------------------------------------

MS_DUE_SOON_DAYS = 14      # exec-summary "milestones due soon" window
MS_UPCOMING_DAYS = 30      # horizon of the Upcoming Milestones sheet


def _portfolio_stats(projects):
    """Roll-up numbers shared by the executive summary sheet."""
    today = date.today()
    status_counts, health_counts = {}, {"green": 0, "amber": 0, "red": 0, "neutral": 0}
    overdue_tasks = high_risks = due_soon = 0
    completion_sum = 0
    for p in projects:
        st = p.status.value if p.status else "-"
        status_counts[st] = status_counts.get(st, 0) + 1
        health_counts[p.get_health_state()] += 1
        overdue_tasks += len(p.get_overdue_tasks())
        high_risks += len(p.get_open_high_risks())
        completion_sum += p.get_completion_percentage()
        if not getattr(p, "is_closed", False):
            for ms in p.milestones:
                if (ms.status.value != "Completed" and ms.end_date
                        and today <= ms.end_date <= today + timedelta(days=MS_DUE_SOON_DAYS)):
                    due_soon += 1
    return {
        "total": len(projects),
        "status_counts": status_counts,
        "health_counts": health_counts,
        "overdue_tasks": overdue_tasks,
        "high_risks": high_risks,
        "due_soon": due_soon,
        "avg_completion": round(completion_sum / len(projects), 1) if projects else 0,
    }


def _build_exec_summary(ws, projects, meta):
    """Sheet 1: KPI block, RAG counts and a status-distribution chart."""
    _autosize(ws, [30, 16, 3, 14, 10])
    stats = _portfolio_stats(projects)
    rng = meta.get("range_label") or "all dates"
    row = _title_band(ws, "Portfolio Report - Executive Summary",
                      f"Filters: {rng}", 5)

    def section(label):
        nonlocal row
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=5)
        h = ws.cell(row=row, column=1, value=label)
        h.font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
        h.fill = PatternFill("solid", fgColor=BRAND)
        h.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        ws.row_dimensions[row].height = 22
        row += 1

    def kpi(label, value, chip=None):
        nonlocal row
        lc = ws.cell(row=row, column=1, value=label)
        lc.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        lc.fill = PatternFill("solid", fgColor=BRAND_DK)
        lc.alignment = LEFT
        lc.border = _BORDER
        vc = ws.cell(row=row, column=2, value=value)
        if chip:
            _chip(vc, chip[0], chip[1])
        else:
            vc.font = Font(name="Calibri", size=11, bold=True, color=TEXT)
            vc.alignment = CENTER
            vc.border = _BORDER
        ws.row_dimensions[row].height = 22
        row += 1

    section("Portfolio at a glance")
    kpi("Total projects", stats["total"])
    kpi("In progress", stats["status_counts"].get("In Progress", 0))
    kpi("Delivered (Completed + Closed)",
        stats["status_counts"].get("Completed", 0) + stats["status_counts"].get("Closed", 0))
    kpi("Average completion", f"{stats['avg_completion']}%")
    kpi("Overdue tasks (portfolio total)", stats["overdue_tasks"],
        chip=("FEE2E2", "991B1B") if stats["overdue_tasks"] else None)
    kpi("Open High / Critical risks", stats["high_risks"],
        chip=("FEE2E2", "991B1B") if stats["high_risks"] else None)
    kpi(f"Milestones due in next {MS_DUE_SOON_DAYS} days", stats["due_soon"],
        chip=("FEF3C7", "92400E") if stats["due_soon"] else None)
    row += 1

    section("Delivery health (RAG)")
    for key, label in (("red", "Off track"), ("amber", "At risk"),
                       ("green", "On track / delivered"), ("neutral", "No signal")):
        fill, font_clr, _ = RAG[key]
        kpi(label, stats["health_counts"].get(key, 0), chip=(fill, font_clr))
    row += 1

    section("Status breakdown")
    chart_first = row
    for st in ("Planning", "In Progress", "On Hold", "Completed", "Failed", "Closed"):
        kpi(st, stats["status_counts"].get(st, 0))
    chart_last = row - 1

    # Native bar chart of the status breakdown, anchored beside the KPIs.
    if stats["total"]:
        chart = BarChart()
        chart.type = "bar"
        chart.style = 10
        chart.title = "Projects by status"
        chart.legend = None
        chart.y_axis.delete = False
        chart.x_axis.delete = False
        data = Reference(ws, min_col=2, min_row=chart_first, max_row=chart_last)
        cats = Reference(ws, min_col=1, min_row=chart_first, max_row=chart_last)
        chart.add_data(data, titles_from_data=False)
        chart.set_categories(cats)
        chart.height, chart.width = 8.5, 13
        ws.add_chart(chart, "D6")

    row += 1
    gen = meta.get("generated") or datetime.now()
    for label, value in (("Prepared by", meta.get("prepared_by") or "-"),
                         ("Generated", gen.strftime("%d %b %Y %H:%M"))):
        lc = ws.cell(row=row, column=1, value=label)
        lc.font = Font(name="Calibri", size=9, bold=True, color=MUTED)
        vc = ws.cell(row=row, column=2, value=value)
        vc.font = Font(name="Calibri", size=9, color=MUTED)
        vc.alignment = CENTER
        row += 1


def _build_portfolio(ws, projects, meta):
    headers = ["#", "Project", "Type", "Status", "Project Manager",
               "Start", "Target End", "Days Left", "Progress %",
               "Tasks (done/total)", "Overdue", "High Risks", "Team", "Health"]
    _autosize(ws, [5, 36, 12, 13, 20, 13, 13, 10, 11, 15, 9, 10, 7, 12])
    owner_names = meta.get("owner_names") or {}
    today = date.today()

    rng = meta.get("range_label") or "all dates"
    row = _title_band(ws, "Portfolio", f"Filters: {rng}", len(headers))

    # Legend strip: real coloured cells, so the key shows the actual RAG fills.
    leg = ws.cell(row=row, column=1, value="Health key:")
    leg.font = Font(name="Calibri", size=9, italic=True, color=MUTED)
    leg.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    for offset, key in enumerate(("green", "amber", "red")):
        fill, font_clr, label = RAG[key]
        _chip(ws.cell(row=row, column=2 + offset * 2), fill, font_clr, bold=False)
        ws.merge_cells(start_row=row, start_column=2 + offset * 2,
                       end_row=row, end_column=3 + offset * 2)
        ws.cell(row=row, column=2 + offset * 2, value=label)
    ws.row_dimensions[row].height = 18
    row += 1

    _header_row(ws, row, headers)
    ws.freeze_panes = ws.cell(row=row + 1, column=1)
    ws.auto_filter.ref = f"A{row}:{get_column_letter(len(headers))}{row}"
    header_row = row
    row += 1

    if not projects:
        _empty_row(ws, row, len(headers), "No projects match the selected filters.")
        return

    for i, p in enumerate(projects, start=1):
        banded = (i % 2 == 0)
        health = p.get_health_state()
        fill, font_clr, label = RAG.get(health, RAG["neutral"])
        all_tasks = p.get_all_tasks()
        done = sum(1 for t in all_tasks if t.status.value == "Completed")
        overdue = len(p.get_overdue_tasks())
        high_risks = len(p.get_open_high_risks())
        finished = p.status and p.status.value in ("Completed", "Closed")
        if p.target_end_date and not finished:
            days_left = (p.target_end_date - today).days
        else:
            days_left = None
        if getattr(p, "project_type", None) == "simple":
            ptype = "Simple"
        else:
            ptype = (p.methodology or "").title() or "-"
        values = [
            i, p.name, ptype, p.status.value if p.status else "",
            owner_names.get(p.created_by, "-"),
            _fmt_date(p.start_date), _fmt_date(p.target_end_date),
            days_left if days_left is not None else "-",
            p.get_completion_percentage(),
            f"{done}/{len(all_tasks)}", overdue or "-", high_risks or "-",
            len(p.team_members), label,
        ]
        for col, val in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=val)
            _style_cell(cell, banded, center=(col not in (2, 5)))
        ws.cell(row=row, column=9).number_format = '0"%"'
        _status_chip(ws.cell(row=row, column=4), p.status.value if p.status else "")
        if days_left is not None and days_left < 0:
            dc = ws.cell(row=row, column=8)
            dc.font = Font(name="Calibri", size=10, bold=True, color="991B1B")
        if overdue:
            oc = ws.cell(row=row, column=11)
            oc.font = Font(name="Calibri", size=10, bold=True, color="991B1B")
        if high_risks:
            rc = ws.cell(row=row, column=12)
            rc.font = Font(name="Calibri", size=10, bold=True, color="991B1B")
        _chip(ws.cell(row=row, column=14), fill, font_clr)
        row += 1

    # In-cell data bars on the Progress column.
    ws.conditional_formatting.add(
        f"I{header_row + 1}:I{row - 1}",
        DataBarRule(start_type="num", start_value=0, end_type="num",
                    end_value=100, color=BRAND, showValue=True))


def _build_upcoming_milestones(ws, projects, meta):
    """Sheet 3: every open milestone due inside the horizon, plus any already
    overdue - the steering-committee 'what needs attention next' page."""
    headers = ["#", "Project", "Milestone", "Start", "Deadline", "Days Left",
               "Status", "Progress %", "Tasks (done/total)"]
    _autosize(ws, [5, 32, 34, 13, 13, 11, 14, 11, 15])
    today = date.today()
    horizon = today + timedelta(days=MS_UPCOMING_DAYS)

    row = _title_band(ws, "Upcoming Milestones",
                      f"Open milestones due by {horizon.strftime('%d %b %Y')} "
                      f"(next {MS_UPCOMING_DAYS} days), plus any overdue",
                      len(headers))
    _header_row(ws, row, headers)
    ws.freeze_panes = ws.cell(row=row + 1, column=1)
    ws.auto_filter.ref = f"A{row}:{get_column_letter(len(headers))}{row}"
    row += 1

    entries = []
    for p in projects:
        if getattr(p, "is_closed", False):
            continue
        for ms in p.milestones:
            if ms.status.value == "Completed" or not ms.end_date:
                continue
            if ms.end_date <= horizon:
                entries.append((p, ms))
    entries.sort(key=lambda e: (e[1].end_date, e[0].name))

    if not entries:
        _empty_row(ws, row, len(headers),
                   "No open milestones due inside the horizon. Nothing overdue.")
        return

    for i, (p, ms) in enumerate(entries, start=1):
        banded = (i % 2 == 0)
        days_left = (ms.end_date - today).days
        done = sum(1 for t in ms.tasks if t.status.value == "Completed")
        values = [
            i, p.name, ms.name, _fmt_date(ms.start_date), _fmt_date(ms.end_date),
            days_left if days_left >= 0 else f"Overdue {-days_left}d",
            ms.status.value, ms.completion_percentage, f"{done}/{len(ms.tasks)}",
        ]
        for col, val in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=val)
            _style_cell(cell, banded, center=(col not in (2, 3)))
        ws.cell(row=row, column=8).number_format = '0"%"'
        if days_left < 0:
            dc = ws.cell(row=row, column=6)
            dc.font = Font(name="Calibri", size=10, bold=True, color="991B1B")
            dc.fill = PatternFill("solid", fgColor="FEE2E2")
        _status_chip(ws.cell(row=row, column=7), ms.status.value)
        row += 1


def build_portfolio_workbook(projects, meta) -> bytes:
    """Return the .xlsx bytes for a dashboard-filtered portfolio report.

    `projects` is the filtered, ordered list of Project rows. `meta` carries:
        range_label  - human description of the active filters (subtitle)
        owner_names  - {user_id: display name} for the PM column
        prepared_by  - requesting user's display name (exec-summary footer)
        generated    - report timestamp (datetime)
    """
    wb = Workbook()

    summary = wb.active
    summary.title = "Executive Summary"
    summary.sheet_view.showGridLines = False
    _build_exec_summary(summary, projects, meta)
    _print_setup(summary, orientation="portrait")

    portfolio = wb.create_sheet("Portfolio")
    portfolio.sheet_view.showGridLines = False
    _build_portfolio(portfolio, projects, meta)
    _print_setup(portfolio, repeat_rows="1:5")

    upcoming = wb.create_sheet("Upcoming Milestones")
    upcoming.sheet_view.showGridLines = False
    _build_upcoming_milestones(upcoming, projects, meta)
    _print_setup(upcoming, repeat_rows="1:4")

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()


def _build_sdlc_sheet(ws, sdlc_rows):
    """One row per SDLC stage: gate state, milestone grouping, docs, sign-off.
    Styled like the other sheets: brand title band, banded rows, gate chips."""
    headers = ['#', 'Stage', 'Gate State', 'Milestones', 'Tasks Done',
               'Required Documents', 'Missing Documents', 'Signed Off By',
               'Signed Off On', 'Flags']
    _autosize(ws, [4, 26, 18, 28, 11, 28, 28, 20, 14, 56])
    row = _title_band(ws, "SDLC Process",
                      "Gate state per stage - flags mark where the defined "
                      "process is not being followed", len(headers))
    _header_row(ws, row, headers)
    ws.freeze_panes = ws.cell(row=row + 1, column=1)
    row += 1

    if not sdlc_rows:
        _empty_row(ws, row, len(headers), "No SDLC process attached.")
        return

    for i, sr in enumerate(sdlc_rows, start=1):
        banded = (i % 2 == 0)
        values = [i, sr['name'], sr['state'], sr['milestones'], sr['tasks'],
                  sr['docs'], sr['missing'], sr['signed_by'], sr['signed_on'],
                  sr['flags']]
        for c, v in enumerate(values, start=1):
            cell = ws.cell(row=row, column=c, value=v if v != '' else '-')
            _style_cell(cell, banded, center=(c in (1, 5, 9)))
        if sr['state'] in SDLC_STATE_FILL:
            fill, font_clr = SDLC_STATE_FILL[sr['state']]
            _chip(ws.cell(row=row, column=3), fill, font_clr)
        if sr['missing']:
            mc = ws.cell(row=row, column=7)
            mc.font = Font(name="Calibri", size=10, color="92400E")
        if sr['flags']:
            fc = ws.cell(row=row, column=10)
            fc.font = Font(name="Calibri", size=10, bold=True, color="991B1B")
        row += 1


# Sheet: Risk Register
def _build_risk_sheet(ws, project):
    """PMBOK-style risk register: PxI matrix fields, severity/status chips,
    open risks first (highest score at the top)."""
    headers = ["#", "Risk", "Summary", "Probability", "Impact", "Score",
               "Severity", "Status", "Owner", "Mitigation", "Due", "Raised"]
    _autosize(ws, [5, 26, 36, 15, 15, 8, 12, 12, 18, 36, 13, 13])
    row = _title_band(ws, "Risk Register",
                      "Open risks first, highest exposure at the top",
                      len(headers))
    _header_row(ws, row, headers)
    ws.freeze_panes = ws.cell(row=row + 1, column=1)
    ws.auto_filter.ref = f"A{row}:{get_column_letter(len(headers))}{row}"
    row += 1

    risks = list(project.risk_logs)
    if not risks:
        _empty_row(ws, row, len(headers), "No risks recorded for this project.")
        return

    sev_rank = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}
    status_rank = {"Open": 0, "Mitigated": 1, "Closed": 2}
    risks.sort(key=lambda r: (status_rank.get(r.status.value, 9),
                              -(r.score or 0),
                              sev_rank.get(r.severity.value, 9),
                              r.id or 0))

    for i, r in enumerate(risks, start=1):
        banded = (i % 2 == 0)
        prob = (f"{r.probability} - {RISK_PROBABILITY_LABELS.get(r.probability, '')}"
                if r.probability else "-")
        impact = (f"{r.impact} - {RISK_IMPACT_LABELS.get(r.impact, '')}"
                  if r.impact else "-")
        values = [
            i, r.name, r.summary or "", prob, impact, r.score or "-",
            r.severity.value, r.status.value, r.owner or "-",
            r.mitigation or "-", _fmt_date(r.due_date), _fmt_date(r.created_at),
        ]
        for col, val in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=val)
            _style_cell(cell, banded, center=(col in (1, 4, 5, 6, 11, 12)))
        if r.severity.value in PRIORITY_FILL:
            _chip(ws.cell(row=row, column=7), *PRIORITY_FILL[r.severity.value])
        if r.status.value in RISK_STATUS_FILL:
            _chip(ws.cell(row=row, column=8), *RISK_STATUS_FILL[r.status.value])
        if r.score and r.score >= 10:
            sc = ws.cell(row=row, column=6)
            sc.font = Font(name="Calibri", size=10, bold=True, color="991B1B")
        row += 1


# Sheet: Issue Log
def _build_issue_sheet(ws, project):
    """The issue log: open issues first (overdue, then by priority, then due
    date), then the resolved / closed history, most recently resolved first.
    Same order as the Risks & Issues tab."""
    headers = ["#", "Issue", "Description / Impact", "Priority", "Status",
               "Owner", "Raised", "Due", "Days Open", "Resolved", "Resolution"]
    _autosize(ws, [5, 30, 40, 11, 13, 18, 13, 13, 10, 13, 40])
    row = _title_band(ws, "Issue Log",
                      "Open issues first - overdue, then by priority",
                      len(headers))
    _header_row(ws, row, headers)
    ws.freeze_panes = ws.cell(row=row + 1, column=1)
    ws.auto_filter.ref = f"A{row}:{get_column_letter(len(headers))}{row}"
    row += 1

    issues = list(project.issues)
    if not issues:
        _empty_row(ws, row, len(headers), "No issues raised for this project.")
        return

    prio_rank = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}
    open_rows = sorted((i for i in issues if i.is_open),
                       key=lambda i: (not i.is_overdue(), prio_rank.get(i.priority, 9),
                                      i.due_date or date.max, i.id or 0))
    closed_rows = sorted((i for i in issues if not i.is_open),
                         key=lambda i: (i.resolved_on or date.min, i.id or 0),
                         reverse=True)

    for n, iss in enumerate(open_rows + closed_rows, start=1):
        banded = (n % 2 == 0)
        age = iss.age_days()
        values = [
            n, iss.title, iss.description or "-", iss.priority or "Medium",
            iss.status or "Open", iss.owner or "Unassigned",
            _fmt_date(iss.raised_on) or "-", _fmt_date(iss.due_date) or "-",
            age if age is not None else "-", _fmt_date(iss.resolved_on) or "-",
            iss.resolution or "-",
        ]
        for col, val in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=val)
            _style_cell(cell, banded, center=(col in (1, 4, 5, 7, 8, 9, 10)))
        if (iss.priority or "Medium") in PRIORITY_FILL:
            _chip(ws.cell(row=row, column=4), *PRIORITY_FILL[iss.priority or "Medium"])
        if iss.status in ISSUE_STATUS_FILL:
            _chip(ws.cell(row=row, column=5), *ISSUE_STATUS_FILL[iss.status])
        if iss.is_overdue():
            dc = ws.cell(row=row, column=8)
            dc.font = Font(name="Calibri", size=10, bold=True, color="991B1B")
        if not iss.owner:
            oc = ws.cell(row=row, column=6)
            oc.font = Font(name="Calibri", size=10, italic=True, color="92400E")
        row += 1


# Sheet: Task Notes
def _build_notes_sheet(ws, project, name_map):
    """Every task note across the project, newest first - the working log
    that previously never made it into the export."""
    headers = ["#", "Milestone", "Task", "Note", "Author", "Date"]
    _autosize(ws, [5, 26, 28, 64, 20, 16])
    row = _title_band(ws, "Task Notes", "All task notes, newest first",
                      len(headers))
    _header_row(ws, row, headers)
    ws.freeze_panes = ws.cell(row=row + 1, column=1)
    ws.auto_filter.ref = f"A{row}:{get_column_letter(len(headers))}{row}"
    row += 1

    entries = [(ms, t, n)
               for ms in _sorted_milestones(project)
               for t in ms.tasks for n in t.notes]
    if not entries:
        _empty_row(ws, row, len(headers), "No task notes recorded.")
        return

    entries.sort(key=lambda e: e[2].created_at or datetime.min, reverse=True)
    for i, (ms, t, n) in enumerate(entries, start=1):
        banded = (i % 2 == 0)
        created = (n.created_at.strftime("%d %b %Y %H:%M")
                   if n.created_at else "")
        values = [i, ms.name, t.name, n.note,
                  name_map.get(n.user_id, "-"), created]
        for col, val in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=val)
            _style_cell(cell, banded, center=(col in (1, 6)))
        row += 1


def build_project_workbook(project, name_map, task_extras=None,
                           sdlc_rows=None) -> bytes:
    """Return the .xlsx bytes for a project's milestones & tasks.

    task_extras (optional) carries the per-task CPM/baseline/priority columns
    for the Task Detail sheet - see _build_task_detail.
    """
    wb = Workbook()

    overview = wb.active
    overview.title = "Project Overview"
    overview.sheet_view.showGridLines = False
    _build_overview(overview, project)
    _print_setup(overview, orientation="portrait")

    summary = wb.create_sheet("Milestone Summary")
    summary.sheet_view.showGridLines = False
    _build_milestone_summary(summary, project)
    _print_setup(summary, repeat_rows="1:4")

    if sdlc_rows:
        sdlc_ws = wb.create_sheet("SDLC Process")
        sdlc_ws.sheet_view.showGridLines = False
        _build_sdlc_sheet(sdlc_ws, sdlc_rows)
        _print_setup(sdlc_ws, repeat_rows="1:4")

    detail = wb.create_sheet("Task Detail")
    detail.sheet_view.showGridLines = False
    _build_task_detail(detail, project, name_map, task_extras)
    _print_setup(detail, repeat_rows="1:4")

    risks = wb.create_sheet("Risk Register")
    risks.sheet_view.showGridLines = False
    _build_risk_sheet(risks, project)
    _print_setup(risks, repeat_rows="1:4")

    issues = wb.create_sheet("Issue Log")
    issues.sheet_view.showGridLines = False
    _build_issue_sheet(issues, project)
    _print_setup(issues, repeat_rows="1:4")

    notes = wb.create_sheet("Task Notes")
    notes.sheet_view.showGridLines = False
    _build_notes_sheet(notes, project, name_map)
    _print_setup(notes, repeat_rows="1:4")

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()
