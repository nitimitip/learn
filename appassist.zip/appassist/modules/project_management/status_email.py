"""
status_email.py - Project status-report email.

Builds and sends a professional, narrative status update for a project to its
configured recipient list (see ProjectStatusRecipient). It is used in two ways:

  * Manually - the project manager presses "Send status report now".
  * Automatically - whenever a milestone turns Completed (per-project toggle).

The email deliberately reads like a status note, NOT a spreadsheet: an overview
header, a KPI strip, milestone progress (with RAG colour + % bars), open
High/Critical risks, and a "needs attention" block of overdue / due-soon tasks.

Design language and Outlook-safety rules are intentionally the same as the
To-Do / MIMP / health-check emails so it looks like a sibling product:
  * 100% nested <table> layout - no <div>s for structure.
  * State is a tint fill plus a hairline on ALL FOUR sides - never a
    coloured stripe down one edge (matches the web theme).
  * Pills/badges are tiny <table>s, not inline-block spans.
  * Labels are PRE-UPPERCASED in Python (Word ignores text-transform).
  * Solid colours only; bgcolor attributes accompany every background-color.
  * A multipart/alternative plain-text part is included for deliverability.

The HTML/text renderers take a plain dict (`gather_status_context` flattens the
ORM into it), so the render is pure and easy to preview. A static dummy-data
preview lives at ``email_samples/project_status_sample.html``.
"""

from __future__ import annotations

import logging
import os
import smtplib
from datetime import date
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

logger = logging.getLogger(__name__)


# SMTP (shared convention with the rest of the app)
_SMTP_SERVER = os.environ.get('SMTP_SERVER', 'mail1.northernpowergrid.com')
_SMTP_PORT = int(os.environ.get('SMTP_PORT', '25'))
_EMAIL_FROM = os.environ.get('EMAIL_FROM', 'NPgAppAssist@northernpowergrid.com')


# NPG palette - imported from the shared email theme so a colour is
# defined ONCE for the whole application (email_theme.py). The private
# aliases keep this module's f-strings unchanged.
from email_theme import (                             # noqa: E402
    NPG_RED as _NPG_RED, NPG_DARK as _NPG_DARK, NPG_LIGHT as _NPG_LIGHT,
    NPG_BORDER as _NPG_BORDER, NPG_TEXT as _NPG_TEXT,
    NPG_TEXT_MUTED as _NPG_TEXT_MUTED, CHIP_BG as _CHIP_BG,
    FONT as _FONT,
)

# Masthead and footer come from the shared NPG theme (email_theme.py): a flat
# maroon banner closed by a graphite rule, and a graphite footer band. Flat, not
# a gradient - the Word engine behind desktop Outlook cannot render one.
from email_theme import hero_rows, footer_rows

# RAG palettes keyed by health state.
_RAG = {
    'green':   {'bar': '#16A34A', 'pill_bg': '#DCFCE7', 'pill_fg': '#166534',
                'tint': '#F0FDF4', 'tint_border': '#BBF7D0'},
    'amber':   {'bar': '#F59E0B', 'pill_bg': '#FEF3C7', 'pill_fg': '#92400E',
                'tint': '#FFFBEB', 'tint_border': '#FDE68A'},
    'red':     {'bar': '#DC2626', 'pill_bg': '#FEE2E2', 'pill_fg': '#991B1B',
                'tint': '#FEF2F2', 'tint_border': '#FECACA'},
    'neutral': {'bar': '#94A3B8', 'pill_bg': '#E2E8F0', 'pill_fg': '#475569',
                'tint': '#F8FAFC', 'tint_border': _NPG_BORDER},
}

_SEVERITY = {
    'Critical': {'pill_bg': '#FEE2E2', 'pill_fg': '#991B1B', 'bar': '#DC2626'},
    'High':     {'pill_bg': '#FEF3C7', 'pill_fg': '#92400E', 'bar': '#F59E0B'},
    # Issues use all four priorities; risks only ever reach the email at
    # High / Critical, so these two are issue-only.
    'Medium':   {'pill_bg': '#DBEAFE', 'pill_fg': '#1E40AF', 'bar': '#2563EB'},
    'Low':      {'pill_bg': '#E2E8F0', 'pill_fg': '#1D293D', 'bar': '#64748B'},
}


# Public entry points
def send_status_report(project, db_session, trigger: str = 'manual',
                       milestone_name: str | None = None) -> tuple[bool, str]:
    """Email the project's status report to its configured recipients.

    Returns (ok, message). All SMTP/connection errors are caught and turned into
    a friendly message so a failure never propagates into the calling request.
    `trigger` is 'manual' or 'milestone' and only affects the subject / log line.
    """
    recipients = [r.email.strip() for r in project.status_recipients
                  if (r.email or '').strip()]
    if not recipients:
        return (False, 'No recipients are configured yet - add at least one '
                       'email address to the status-report list first.')

    ctx = gather_status_context(project, db_session)

    if trigger == 'milestone':
        ms = milestone_name or 'A milestone'
        subject = (f"[App Assist] Milestone completed - {ctx['project_name']} "
                   f"status report ({ctx['completion']}% complete)")
        ctx['trigger_note'] = (f"This report was sent automatically because "
                               f"the milestone '{ms}' was marked Completed.")
    else:
        subject = (f"[App Assist] Project status - {ctx['project_name']} "
                   f"({ctx['completion']}% complete)")
        ctx['trigger_note'] = None

    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = _EMAIL_FROM
        msg['To'] = ', '.join(recipients)
        msg.attach(MIMEText(render_status_text(ctx), 'plain', 'utf-8'))
        msg.attach(MIMEText(render_status_html(ctx), 'html', 'utf-8'))

        with smtplib.SMTP(_SMTP_SERVER, _SMTP_PORT, timeout=30) as server:
            server.send_message(msg)

        logger.info("Project status report sent for '%s' to %d recipient(s) [%s].",
                    ctx['project_name'], len(recipients), trigger)
        return (True, f"Status report sent to {len(recipients)} "
                      f"recipient{'s' if len(recipients) != 1 else ''}.")

    except (smtplib.SMTPException, OSError) as exc:
        logger.error("Could not send project status report for '%s': %s",
                     ctx['project_name'], exc)
        return (False, 'The email service is unavailable right now (could not '
                       'reach the mail server). Please try again later.')
    except Exception:
        logger.exception("Unexpected error sending project status report.")
        return (False, 'Something went wrong while sending the status report.')


def gather_status_context(project, db_session) -> dict:
    """Flatten a Project (and its children) into a plain, render-ready dict."""
    from models import User
    from .models import TaskStatus, RiskSeverity, RiskStatus

    # Resolve assignee names in one pass.
    assignee_ids = {t.assigned_to for t in project.get_all_tasks() if t.assigned_to}
    name_by_id = {}
    if assignee_ids:
        for u in db_session.query(User).filter(User.id.in_(assignee_ids)).all():
            name_by_id[u.id] = (f"{u.firstname} {u.lastname}".strip()
                                or u.username)

    def _task_row(t):
        return {
            'name': t.name,
            'milestone': t.milestone.name if t.milestone else '',
            'end_date': _fmt_date(t.end_date),
            'assignee': name_by_id.get(t.assigned_to, 'Unassigned'),
        }

    milestones = []
    counts = {'completed': 0, 'in_progress': 0, 'not_started': 0, 'total': 0}
    for m in project.milestones:
        status = m.status.value if m.status else 'Not Started'
        counts['total'] += 1
        if status == 'Completed':
            counts['completed'] += 1
        elif status == 'In Progress':
            counts['in_progress'] += 1
        else:
            counts['not_started'] += 1
        milestones.append({
            'name': m.name,
            'status': status,
            'pct': m.completion_percentage,
            'deadline': _fmt_date(m.end_date),
            'health': m.get_health_state(),
        })

    overdue = [_task_row(t) for t in project.get_overdue_tasks()]
    due_soon = [_task_row(t) for t in project.get_all_tasks()
                if t.is_nearing_deadline() and not t.is_overdue()]

    risks = []
    for r in project.get_open_high_risks():
        risks.append({
            'name': r.name,
            'severity': r.severity.value if r.severity else 'High',
            'summary': r.summary or '',
        })

    # Open issues (Open / In Progress) - overdue first, then by priority,
    # then due date; the same order as the Risks & Issues tab.
    prio_rank = {'Critical': 0, 'High': 1, 'Medium': 2, 'Low': 3}
    open_issues = sorted(
        project.get_open_issues(),
        key=lambda i: (not i.is_overdue(), prio_rank.get(i.priority, 9),
                       i.due_date or date.max, i.id or 0))
    issues = [{
        'title': i.title,
        'priority': i.priority or 'Medium',
        'status': i.status or 'Open',
        'owner': i.owner or 'Unassigned',
        'due': _fmt_date(i.due_date),
        'overdue': i.is_overdue(),
        'description': i.description or '',
    } for i in open_issues]

    # SDLC governance summary (None for legacy ungoverned projects). The
    # import is function-level because routes imports this module.
    process = None
    try:
        from .routes import _sdlc_context
        sctx = _sdlc_context(project)
        if sctx:
            process = {'label': sctx['methodology_label'],
                       'passed': sctx['passed'], 'total': sctx['total'],
                       'flags': len(sctx['flags'])}
    except Exception:
        process = None

    return {
        'project_name': project.name,
        'process': process,
        'status': project.status.value if project.status else 'Planning',
        'health': project.get_health_state(),
        'completion': project.get_completion_percentage(),
        'start_date': _fmt_date(project.start_date),
        'target_end_date': _fmt_date(project.target_end_date),
        'generated_on': date.today().strftime('%A, %d %b %Y'),
        'milestones': milestones,
        'milestone_counts': counts,
        'risks': risks,
        'open_risk_count': len(risks),
        'issues': issues,
        'open_issue_count': len(issues),
        'overdue_issue_count': sum(1 for i in issues if i['overdue']),
        'overdue': overdue,
        'overdue_count': len(overdue),
        'due_soon': due_soon,
        'due_soon_count': len(due_soon),
        'trigger_note': None,
    }


# Outlook-safe building blocks
def _badge(bg: str, fg: str, label: str) -> str:
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
        f'style="display:inline-table;"><tr>'
        f'<td bgcolor="{bg}" style="background-color:{bg};padding:5px 12px;'
        f'font-family:{_FONT};font-size:11px;font-weight:bold;color:{fg};'
        f'mso-line-height-rule:exactly;line-height:14px;letter-spacing:1px;'
        f'border-collapse:separate;border-spacing:0;border-radius:20px;">{label}</td></tr></table>'
    )


def _stat_card(bg: str, big_fg: str, label_fg: str, value, label: str,
               border: str = _NPG_BORDER) -> str:
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
        f'width="100%" bgcolor="{bg}" style="background-color:{bg};'
        f'border:1px solid {border};border-collapse:separate;border-spacing:0;border-radius:10px;">'
        f'<tr><td align="center" style="padding:16px 12px;font-family:{_FONT};">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0">'
        f'<tr><td align="center" style="font-size:28px;font-weight:bold;color:{big_fg};'
        f'letter-spacing:-0.4px;mso-line-height-rule:exactly;line-height:32px;">{value}</td></tr>'
        f'<tr><td align="center" style="font-size:10px;font-weight:bold;color:{label_fg};'
        f'mso-line-height-rule:exactly;line-height:14px;letter-spacing:1px;padding-top:6px;">'
        f'{label}</td></tr></table>'
        f'</td></tr></table>'
    )


def _progress_bar(pct: int, colour: str) -> str:
    """An Outlook-safe % bar: a full-width track with a coloured fill cell.

    The ends are rounded where a client can draw them (Word keeps them
    square, like every other radius here) - a 6px bar with hard ends is the
    one element that still looked like a table cell rather than a meter."""
    pct = max(0, min(100, int(pct)))
    full = 'border-radius:4px;' if pct >= 100 else 'border-radius:4px 0 0 4px;'
    fill = (
        f'<td width="{pct}%" bgcolor="{colour}" style="background-color:{colour};'
        f'font-size:0;line-height:0;height:7px;{full}">&nbsp;</td>' if pct > 0 else ''
    )
    rest = 100 - pct
    end = 'border-radius:4px;' if pct <= 0 else 'border-radius:0 4px 4px 0;'
    track = (
        f'<td width="{rest}%" bgcolor="#DFE6F0" style="background-color:#DFE6F0;'
        f'font-size:0;line-height:0;height:7px;{end}">&nbsp;</td>' if rest > 0 else ''
    )
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
        f'width="100%" style="table-layout:fixed;border-collapse:separate;'
        f'border-spacing:0;"><tr>{fill}{track}</tr></table>'
    )


def _milestone_row(m: dict) -> str:
    pal = _RAG.get(m['health'], _RAG['neutral'])
    name = _esc(m['name'])
    status = _esc(m['status'].upper())
    deadline = _esc(m['deadline'])
    pct = m['pct']
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
        f'bgcolor="{pal["tint"]}" style="background-color:{pal["tint"]};'
        f'border:1px solid {pal["tint_border"]};border-collapse:separate;border-spacing:0;border-radius:10px;margin-bottom:8px;"><tr>'
        f'<td style="padding:11px 14px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr>'
        f'<td style="font-family:{_FONT};font-size:14px;font-weight:bold;color:{_NPG_TEXT};'
        f'mso-line-height-rule:exactly;line-height:18px;">{name}</td>'
        f'<td align="right" valign="top">{_badge(pal["pill_bg"], pal["pill_fg"], status)}</td>'
        f'</tr>'
        f'<tr><td colspan="2" style="padding:8px 0 5px;">{_progress_bar(pct, pal["bar"])}</td></tr>'
        f'<tr><td style="font-family:{_FONT};font-size:12px;font-weight:bold;'
        f'color:{pal["pill_fg"]};mso-line-height-rule:exactly;line-height:16px;">{pct}% complete</td>'
        f'<td align="right" style="font-family:{_FONT};font-size:12px;color:{_NPG_TEXT_MUTED};'
        f'mso-line-height-rule:exactly;line-height:16px;">Due {deadline}</td></tr>'
        f'</table></td></tr></table>'
    )


def _risk_row(r: dict) -> str:
    pal = _SEVERITY.get(r['severity'], _SEVERITY['High'])
    name = _esc(r['name'])
    sev = _esc(r['severity'].upper())
    summary = _esc(r['summary'])
    summary_html = (
        f'<tr><td colspan="2" style="padding-top:4px;font-family:{_FONT};font-size:12px;'
        f'color:{_NPG_TEXT_MUTED};mso-line-height-rule:exactly;line-height:16px;">{summary}</td></tr>'
        if summary else ''
    )
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
        f'bgcolor="#FDEEED" style="background-color:#FDEEED;border:1px solid #F3C9C6;border-collapse:separate;border-spacing:0;border-radius:10px;'
        f'margin-bottom:8px;">'
        f'<tr>'
        f'<td style="padding:11px 14px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr>'
        f'<td style="font-family:{_FONT};font-size:14px;font-weight:bold;color:{_NPG_TEXT};'
        f'mso-line-height-rule:exactly;line-height:18px;">{name}</td>'
        f'<td align="right" valign="top">{_badge(pal["pill_bg"], pal["pill_fg"], sev)}</td>'
        f'</tr>{summary_html}</table></td></tr></table>'
    )


def _issue_row(i: dict) -> str:
    """One open issue: title + priority pill, then owner / status / due, then
    the description. Overdue issues sit on the red tint, others on amber."""
    pal = _SEVERITY.get(i['priority'], _SEVERITY['Medium'])
    tint, edge = (('#FDEEED', '#F3C9C6') if i['overdue'] else ('#FFFBEB', '#FDE68A'))
    due = f"due {i['due']}" if i['due'] else 'no due date'
    if i['overdue']:
        due = 'OVERDUE - ' + due
    meta = _esc(f"{i['owner']} - {i['status']} - {due}")
    meta_fg = '#991B1B' if i['overdue'] else _NPG_TEXT_MUTED
    desc = _esc(i['description'])
    desc_html = (
        f'<tr><td colspan="2" style="padding-top:4px;font-family:{_FONT};font-size:12px;'
        f'color:{_NPG_TEXT_MUTED};mso-line-height-rule:exactly;line-height:16px;">{desc}</td></tr>'
        if desc else ''
    )
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
        f'bgcolor="{tint}" style="background-color:{tint};border:1px solid {edge};'
        f'border-collapse:separate;border-spacing:0;border-radius:10px;margin-bottom:8px;">'
        f'<tr><td style="padding:11px 14px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr>'
        f'<td style="font-family:{_FONT};font-size:14px;font-weight:bold;color:{_NPG_TEXT};'
        f'mso-line-height-rule:exactly;line-height:18px;">{_esc(i["title"])}</td>'
        f'<td align="right" valign="top">{_badge(pal["pill_bg"], pal["pill_fg"], _esc(i["priority"].upper()))}</td>'
        f'</tr>'
        f'<tr><td colspan="2" style="padding-top:3px;font-family:{_FONT};font-size:12px;'
        f'font-weight:bold;color:{meta_fg};mso-line-height-rule:exactly;line-height:16px;">{meta}</td></tr>'
        f'{desc_html}</table></td></tr></table>'
    )


def _task_line(t: dict, accent: str, detail_fg: str,
               tint: str = '#FFFFFF', edge: str = '') -> str:
    """One task line. State is the tint plus the hairline that goes all
    the way round; `accent` is kept for the edge when no softer one is
    given, so a caller can still point at a RAG colour."""
    name = _esc(t['name'])
    meta = _esc(f"{t['milestone']} - {t['assignee']} - due {t['end_date']}")
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
        f'bgcolor="{tint}" style="background-color:{tint};'
        f'border:1px solid {edge or accent};border-collapse:separate;border-spacing:0;border-radius:10px;margin-bottom:6px;">'
        f'<tr>'
        f'<td style="padding:9px 14px;font-family:{_FONT};">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr><td style="font-size:13px;font-weight:bold;color:{_NPG_TEXT};'
        f'mso-line-height-rule:exactly;line-height:17px;">{name}</td></tr>'
        f'<tr><td style="padding-top:2px;font-size:12px;color:{detail_fg};'
        f'mso-line-height-rule:exactly;line-height:16px;">{meta}</td></tr>'
        f'</table></td></tr></table>'
    )


def _section_header(label: str, count_text: str, colour: str, detail_fg: str) -> str:
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr><td style="border-bottom:1px solid {colour};padding-bottom:8px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"><tr>'
        f'<td style="font-family:{_FONT};font-size:13px;font-weight:bold;color:{detail_fg};'
        f'letter-spacing:0.4px;mso-line-height-rule:exactly;line-height:17px;">{label}</td>'
        f'<td align="right" style="font-family:{_FONT};font-size:11px;color:{_NPG_TEXT_MUTED};'
        f'font-weight:bold;mso-line-height-rule:exactly;line-height:15px;">{count_text}</td>'
        f'</tr></table></td></tr></table>'
    )


# HTML composition
def render_status_html(ctx: dict) -> str:
    pal = _RAG.get(ctx['health'], _RAG['neutral'])
    name = _esc(ctx['project_name'])
    completion = ctx['completion']
    counts = ctx['milestone_counts']

    # Overview ribbon - a short narrative tuned to the project's shape.
    if ctx['health'] == 'red':
        rib = _RAG['red']
        ribbon_title = 'Attention needed'
        ribbon_body = ("The project is behind where it should be - see the overdue items and open "
                       "risks below. Early action keeps the delivery date in reach.")
    elif ctx['health'] == 'amber':
        rib = _RAG['amber']
        ribbon_title = 'On track, watch the dates'
        ribbon_body = ("Delivery is close to the target date. Progress is steady; keep an eye on "
                       "the items flagged below.")
    elif ctx['health'] == 'green':
        rib = _RAG['green']
        ribbon_title = 'In good shape'
        ribbon_body = ("The project is on track - milestones are progressing and nothing is overdue. "
                       "Here's where things stand.")
    else:
        rib = _RAG['neutral']
        ribbon_title = "Here's where things stand"
        ribbon_body = ("A snapshot of the project's progress, milestones and anything that needs "
                       "attention.")

    trigger_html = ''
    if ctx.get('trigger_note'):
        trigger_html = (
            f'<tr><td class="px-32" style="padding:0 32px 4px;">'
            f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
            f'bgcolor="#F0FDF4" style="background-color:#F0FDF4;border:1px solid #BBF7D0;border-collapse:separate;border-spacing:0;border-radius:10px;"><tr>'
            f'<td style="padding:10px 14px;font-family:{_FONT};font-size:12px;'
            f'color:#166534;mso-line-height-rule:exactly;line-height:17px;">'
            f'<strong>OK Milestone completed.</strong> {_esc(ctx["trigger_note"])}</td>'
            f'</tr></table></td></tr>'
        )

    # Sections
    blocks = []

    if ctx.get('process'):
        pr = ctx['process']
        flag_txt = (f" - {pr['flags']} process flag{'s' if pr['flags'] != 1 else ''}"
                    if pr['flags'] else '')
        blocks.append(_section_header(
            'SDLC PROCESS',
            f"{pr['label']} - {pr['passed']}/{pr['total']} gates passed{flag_txt}",
            _NPG_DARK, _NPG_DARK))

    ms_rows = ''.join(_milestone_row(m) for m in ctx['milestones'])
    if ms_rows:
        count_text = (f"{counts['completed']}/{counts['total']} complete")
        blocks.append(
            _section_header('MILESTONE PROGRESS', count_text, _NPG_DARK, _NPG_DARK)
            + f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
              f'<tr><td style="padding-top:12px;">{ms_rows}</td></tr></table>'
        )

    if ctx['risks']:
        risk_rows = ''.join(_risk_row(r) for r in ctx['risks'])
        blocks.append(
            _section_header('OPEN RISKS', f"{ctx['open_risk_count']} open", '#DC2626', '#991B1B')
            + f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
              f'<tr><td style="padding-top:12px;">{risk_rows}</td></tr></table>'
        )

    if ctx.get('issues'):
        issue_rows = ''.join(_issue_row(i) for i in ctx['issues'])
        count_text = f"{ctx['open_issue_count']} open"
        if ctx['overdue_issue_count']:
            count_text += f" - {ctx['overdue_issue_count']} overdue"
        blocks.append(
            _section_header('OPEN ISSUES', count_text, '#F59E0B', '#92400E')
            + f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
              f'<tr><td style="padding-top:12px;">{issue_rows}</td></tr></table>'
        )

    if ctx['overdue'] or ctx['due_soon']:
        att = ''
        if ctx['overdue']:
            att += ''.join(_task_line(t, '#DC2626', '#991B1B',
                                      _RAG['red']['tint'], _RAG['red']['tint_border'])
                           for t in ctx['overdue'])
        if ctx['due_soon']:
            att += ''.join(_task_line(t, '#F59E0B', '#92400E',
                                      _RAG['amber']['tint'], _RAG['amber']['tint_border'])
                           for t in ctx['due_soon'])
        bits = []
        if ctx['overdue_count']:
            bits.append(f"{ctx['overdue_count']} overdue")
        if ctx['due_soon_count']:
            bits.append(f"{ctx['due_soon_count']} due soon")
        blocks.append(
            _section_header('NEEDS ATTENTION', ' - '.join(bits), '#F59E0B', '#92400E')
            + f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
              f'<tr><td style="padding-top:12px;">{att}</td></tr></table>'
        )

    sections = ''.join(
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
        f'style="margin-bottom:20px;"><tr><td>{b}</td></tr></table>'
        for b in blocks
    )
    if not sections:
        sections = (
            f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
            f'<tr><td style="font-family:{_FONT};font-size:13px;color:{_NPG_TEXT_MUTED};'
            f'mso-line-height-rule:exactly;line-height:19px;">No milestones, risks, issues or outstanding '
            f'tasks to report yet.</td></tr></table>'
        )

    dates_line = ''
    if ctx['start_date'] or ctx['target_end_date']:
        dates_line = _esc(
            f"Window: {ctx['start_date'] or '-'} -> {ctx['target_end_date'] or '-'}"
        )

    badge_status = _badge(_CHIP_BG, '#FFFFFF', ctx['status'].upper())
    badge_when = _badge(_CHIP_BG, '#FFFFFF', ctx['generated_on'].upper())

    hero = hero_rows('NPG APP ASSIST &middot; PROJECT STATUS REPORT', name,
                     [badge_status, badge_when])
    footer = footer_rows('Project Management')

    return f"""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>NPG App Assist &mdash; Project Status Report</title>
  <!--[if mso]>
  <xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch><o:AllowPNG/></o:OfficeDocumentSettings></xml>
  <style type="text/css">table {{border-collapse:collapse;}} td {{mso-line-height-rule:exactly;}}</style>
  <![endif]-->
  <style type="text/css">
    body, table, td {{ -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }}
    table {{ border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }}
    a {{ color:{_NPG_RED}; text-decoration:none; }}
    @media only screen and (max-width:620px) {{
      .container {{ width:100% !important; }}
      .px-32 {{ padding-left:18px !important; padding-right:18px !important; }}
      .stat-cell {{ display:block !important; width:100% !important; padding:0 0 6px 0 !important; }}
    }}
  </style>
</head>
<body style="margin:0;padding:0;background-color:{_NPG_LIGHT};font-family:{_FONT};">
<div style="display:none;font-size:1px;color:{_NPG_LIGHT};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
{name} &mdash; {ctx['status']} &middot; {completion}% complete
</div>

<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="{_NPG_LIGHT}" style="background-color:{_NPG_LIGHT};">
  <tr><td align="center" style="padding:34px 16px 40px 16px;">
    <!--[if mso]><table role="presentation" align="center" cellpadding="0" cellspacing="0" border="0" width="600"><tr><td><![endif]-->
    <table role="presentation" class="container" cellpadding="0" cellspacing="0" border="0" width="600"
           style="width:600px;max-width:600px;background-color:#FFFFFF;border:1px solid {_NPG_BORDER};border-bottom-color:#C6D0DE;border-collapse:separate;border-spacing:0;border-radius:14px;">

      <!-- Header (shared NPG theme: flat maroon masthead) -->
      {hero}

      <!-- Ribbon -->
      <tr><td class="px-32" style="padding:24px 32px 12px;">
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"
               bgcolor="{rib['tint']}" style="background-color:{rib['tint']};border:1px solid {rib['tint_border']};border-collapse:separate;border-spacing:0;border-radius:10px;">
          <tr>
            <td style="padding:14px 16px;font-family:{_FONT};color:{rib['pill_fg']};">
              <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                <tr><td style="font-size:13px;font-weight:bold;mso-line-height-rule:exactly;line-height:18px;
                           padding-bottom:4px;color:{rib['pill_fg']};">{ribbon_title}</td></tr>
                <tr><td style="font-size:13px;mso-line-height-rule:exactly;line-height:20px;
                           color:{rib['pill_fg']};">{ribbon_body}</td></tr>
                {f'<tr><td style="padding-top:8px;font-size:12px;font-weight:bold;color:{_NPG_TEXT_MUTED};mso-line-height-rule:exactly;line-height:16px;">{dates_line}</td></tr>' if dates_line else ''}
              </table>
            </td>
          </tr>
        </table>
      </td></tr>

      {trigger_html}

      <!-- Stat strip -->
      <tr><td class="px-32" style="padding:12px 32px 20px;">
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
          <td class="stat-cell" width="25%" valign="top" style="padding-right:5px;">
            {_stat_card('#EFF6FF', '#1D4ED8', '#1E3A8A', f"{completion}%", 'COMPLETE')}</td>
          <td class="stat-cell" width="25%" valign="top" style="padding:0 3px;">
            {_stat_card('#FEF2F2', _NPG_RED, '#991B1B', ctx['overdue_count'], 'OVERDUE TASKS')}</td>
          <td class="stat-cell" width="25%" valign="top" style="padding:0 3px;">
            {_stat_card('#FFFBEB', '#B45309', '#92400E', ctx['open_risk_count'], 'HIGH RISKS')}</td>
          <td class="stat-cell" width="25%" valign="top" style="padding-left:5px;">
            {_stat_card('#FFFBEB', '#B45309', '#92400E', ctx.get('open_issue_count', 0), 'OPEN ISSUES')}</td>
        </tr></table>
      </td></tr>

      <!-- Sections -->
      <tr><td class="px-32" style="padding:24px 32px;">
        {sections}
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-top:1px solid {_NPG_LIGHT};">
          <tr><td style="padding-top:14px;font-family:{_FONT};font-size:12px;color:{_NPG_TEXT_MUTED};
                     mso-line-height-rule:exactly;line-height:18px;">
            You are receiving this because you are on the status-report list for this project.
            Sign in to App Assist for the full project workspace.
          </td></tr>
        </table>
      </td></tr>

      <!-- Footer (shared NPG theme) -->
      {footer}

    </table>
    <!--[if mso]></td></tr></table><![endif]-->
  </td></tr>
</table>
</body>
</html>"""


# Plain-text alternative
def render_status_text(ctx: dict) -> str:
    counts = ctx['milestone_counts']
    lines = [
        'NPG APP ASSIST - PROJECT STATUS REPORT',
        '=' * 52,
        ctx['project_name'],
        f"Status: {ctx['status']}   |   {ctx['completion']}% complete",
        ctx['generated_on'],
    ]
    if ctx['start_date'] or ctx['target_end_date']:
        lines.append(f"Window: {ctx['start_date'] or '-'} -> {ctx['target_end_date'] or '-'}")
    if ctx.get('trigger_note'):
        lines += ['', ctx['trigger_note']]
    lines += ['',
              f"Milestones: {counts['completed']}/{counts['total']} complete   "
              f"Overdue tasks: {ctx['overdue_count']}   High risks: {ctx['open_risk_count']}   "
              f"Open issues: {ctx.get('open_issue_count', 0)}",
              '']

    if ctx['milestones']:
        lines.append('MILESTONE PROGRESS')
        lines.append('-' * 52)
        for m in ctx['milestones']:
            lines.append(f"  [{m['status']}] {m['name']} - {m['pct']}% (due {m['deadline']})")
        lines.append('')

    if ctx['risks']:
        lines.append('OPEN RISKS')
        lines.append('-' * 52)
        for r in ctx['risks']:
            lines.append(f"  [{r['severity'].upper()}] {r['name']}")
            if r['summary']:
                lines.append(f"        {r['summary']}")
        lines.append('')

    if ctx.get('issues'):
        lines.append('OPEN ISSUES')
        lines.append('-' * 52)
        for i in ctx['issues']:
            due = f"due {i['due']}" if i['due'] else 'no due date'
            flag = ' [OVERDUE]' if i['overdue'] else ''
            lines.append(f"  [{i['priority'].upper()}]{flag} {i['title']} - {i['owner']} - {i['status']} - {due}")
            if i['description']:
                lines.append(f"        {i['description']}")
        lines.append('')

    if ctx['overdue'] or ctx['due_soon']:
        lines.append('NEEDS ATTENTION')
        lines.append('-' * 52)
        for t in ctx['overdue']:
            lines.append(f"  [OVERDUE] {t['name']} - {t['milestone']} - {t['assignee']} - due {t['end_date']}")
        for t in ctx['due_soon']:
            lines.append(f"  [DUE SOON] {t['name']} - {t['milestone']} - {t['assignee']} - due {t['end_date']}")
        lines.append('')

    lines.append('You are on the status-report list for this project.')
    lines.append('NPG App Assist - Project Management - Generated automatically - Do not reply')
    return '\n'.join(lines)


# Helpers
def _fmt_date(value) -> str:
    if not value:
        return ''
    try:
        return value.strftime('%d %b %Y')
    except (AttributeError, ValueError):
        return str(value)


def _esc(text) -> str:
    if text is None:
        return ''
    return (str(text)
            .replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;'))
