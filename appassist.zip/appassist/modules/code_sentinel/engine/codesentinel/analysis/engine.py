"""
The analysis engine: orchestrates per-file analysis across a scan.

Design goals:
  * UI-agnostic - progress flows through injected callbacks only.
  * Parallel - ProcessPoolExecutor for large scans, serial for small ones
    (a Windows process pool costs ~1s to spin up; don't pay it for 5 files).
  * Incremental - unchanged files (same content hash + same rule set) are
    served from the cache without re-analysis.
  * Fault-isolated - one unreadable/pathological file never aborts a scan.
"""

from __future__ import annotations

import hashlib
import copy
import logging
import threading
import time
from dataclasses import replace
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Callable, Protocol, Sequence

from ..domain.models import FileAnalysis, Finding, ScanResult
from ..rules.engine import RuleEngine
from ..rules.loader import load_rule_set
from ..rules.model import RuleSet
from .ast_checks import (
    JinjaTemplateChecker, PlsqlDynamicSqlChecker, PowerShellSecurityChecker,
    PythonAstChecker, RazorTemplateChecker, ShellFileChecker,
    SqlStatementChecker,
)
from .duplication import DuplicationDetector
from .languages import LanguageRegistry, registry as default_registry
from .metrics import MetricsCalculator
from .taint import PythonTaintScanner
from . import tree_sitter_analysis

logger = logging.getLogger(__name__)

ProgressCallback = Callable[[int, int, str], None]

#: Below this many files a process pool costs more than it saves.
PARALLEL_THRESHOLD = 24


class AnalysisCache(Protocol):
    """Incremental-scan cache contract (implemented in infrastructure)."""

    def get(self, path: str, content_hash: str, engine_key: str) -> FileAnalysis | None: ...

    def put(self, path: str, content_hash: str, engine_key: str,
            analysis: FileAnalysis) -> None: ...


#: Retry schedule for transient read failures. On Windows, antivirus
#: real-time scanning briefly locks freshly written files (PermissionError,
#: WinError 5/13) - and scan sources are typically extracted from a zip
#: seconds before being read, which is exactly when the AV inspects them.
_READ_RETRY_DELAYS = (0.2, 0.5, 1.0)


def _read_with_retry(reader: Callable[[], object]):
    """Run `reader`, retrying transient permission errors with backoff."""
    for delay in _READ_RETRY_DELAYS:
        try:
            return reader()
        except PermissionError:
            time.sleep(delay)
    return reader()


def analyze_file(
    path: Path,
    rule_engine: RuleEngine,
    registry: LanguageRegistry,
    text: str | None = None,
) -> FileAnalysis:
    """
    Run every applicable analyzer against one file.

    Pure function of (file content, rule set) - safe to run in any process.
    """
    spec = registry.detect(path)
    if spec is None:
        return FileAnalysis(path=path, language_id="unknown",
                            tool_errors=["Unrecognised file type."])

    analysis = FileAnalysis(path=path, language_id=spec.id)
    analysis.tool_errors.extend('Rule pack unavailable: ' + error
                                for error in rule_engine.rule_set.load_errors)
    try:
        if text is None:
            text = _read_with_retry(
                lambda: path.read_text(encoding="utf-8", errors="replace"))
    except OSError as exc:
        analysis.tool_errors.append(f"Could not read file: {exc}")
        return analysis

    analysis.metrics = MetricsCalculator().measure(text, spec)

    findings = rule_engine.scan(text, spec.id, spec.comment_prefixes,
                                spec.block_comments, spec.string_spans)
    analysis.tools_run.append("sentinel-rules")

    if spec.id == "python":
        # AST checks own these semantics; preserve the IDs of their fallbacks.
        findings = [f for f in findings if f.rule_id != 'PY-Q001']
        findings.extend(PythonAstChecker().scan(text))
        findings.extend(PythonTaintScanner().scan_text(text))
        analysis.tools_run.extend(["sentinel-ast", "sentinel-taint"])
    elif spec.id == "shell":
        findings.extend(ShellFileChecker().scan(text.splitlines()))
        analysis.tools_run.append("sentinel-ast")
    elif spec.id == "powershell":
        findings.extend(PowerShellSecurityChecker().scan(text))
        analysis.tools_run.append("sentinel-ast")
    elif spec.id in ("html", "jinja"):
        # Flask/Jinja templates are usually .html; run the Jinja XSS checks on
        # both. Non-Jinja HTML simply has none of the {{ }}/{% %} patterns.
        findings.extend(JinjaTemplateChecker().scan(text))
        analysis.tools_run.append("sentinel-ast")
    elif spec.id == "razor":
        findings.extend(RazorTemplateChecker().scan(text))
        analysis.tools_run.append("sentinel-ast")
    elif spec.id in ("sql", "plsql"):
        findings = [f for f in findings if f.rule_id not in {'SQL-D004', 'SQL-D005'}]
        findings.extend(SqlStatementChecker().scan(text))
        analysis.tools_run.append("sentinel-ast")
        if spec.id == "plsql":
            findings.extend(PlsqlDynamicSqlChecker().scan(text))
    elif spec.id in tree_sitter_analysis.SUPPORTED_LANGUAGES:
        # Parse-tree analysis (structural + taint) when the optional
        # tree-sitter grammars are installed; None means "not available",
        # and the file keeps its regex-rule coverage either way.
        ts_findings = tree_sitter_analysis.scan(
            text, spec.id, path.suffix,
            rule_engine.rule_set.queries_for_language(spec.id))
        if ts_findings is not None:
            # The parse-tree analyzer's exit-aware loop check supersedes the
            # regex *-L001 rules; the regex remains the no-grammar fallback.
            if not any(f.rule_id in {'PARSE-001', 'PARSE-QUERY'} for f in ts_findings):
                superseded = tree_sitter_analysis.SUPERSEDED_RULE_IDS | {
                    r.id for r in rule_engine.rule_set.queries_for_language(spec.id)}
                findings = [f for f in findings if f.rule_id not in superseded]
            findings.extend(ts_findings)
            analysis.tools_run.append(tree_sitter_analysis.TOOL_NAME)

    if any(f.rule_id in ('PY-Q000', 'PARSE-001', 'PARSE-QUERY') for f in findings):
        analysis.tool_errors.append('Syntax analysis incomplete; fix parser diagnostics and re-scan.')
    analysis.findings.extend(_backfill_snippets(rule_engine.apply_policy(findings, text, spec), text))
    return analysis


def _backfill_snippets(findings: list[Finding], text: str) -> list[Finding]:
    """
    Give every finding an offending-code snippet.

    The rule engine already records one, but the AST/taint/SQL/shell analyzers
    emit findings with no snippet. An empty snippet is not just a cosmetic gap
    in reports: it is what a finding's stable identity (fingerprint) is anchored
    on, so leaving it empty makes distinct findings on distinct lines share an
    identity. Filling it from the source line keeps every finding uniquely and
    stably identifiable - and shows reviewers the exact line in reports.
    """
    lines = text.splitlines()
    out = []
    for finding in findings:
        if not finding.snippet and 1 <= finding.line <= len(lines):
            out.append(replace(finding, snippet=lines[finding.line - 1].strip()[:200]))
        else:
            out.append(finding)
    return out


# ---- Process-pool worker plumbing ------------------------------------------
#
# Workers rebuild the rule engine once (initializer) instead of pickling
# compiled regexes into every task submission.

_WORKER_ENGINE: RuleEngine | None = None
_WORKER_REGISTRY: LanguageRegistry | None = None


def _init_worker(rule_set: RuleSet, registry: LanguageRegistry) -> None:
    global _WORKER_ENGINE, _WORKER_REGISTRY
    _WORKER_ENGINE = RuleEngine(rule_set)
    _WORKER_REGISTRY = registry


def _analyze_in_worker(path_str: str) -> FileAnalysis:
    assert _WORKER_ENGINE is not None and _WORKER_REGISTRY is not None
    return analyze_file(Path(path_str), _WORKER_ENGINE, _WORKER_REGISTRY)


class AnalysisEngine:
    """Runs a full scan: cache lookup, per-file analysis, duplication pass."""

    ENGINE_VERSION = "16"  # .NET SSRF/LDAP/XPath/reflection sinks, property sinks, per-ctor args

    def __init__(
        self,
        rule_set: RuleSet | None = None,
        registry: LanguageRegistry | None = None,
        cache: AnalysisCache | None = None,
        max_workers: int = 0,
        extra_rule_dirs: Sequence[Path] = (),
        disabled_rule_ids: Sequence[str] = (),
        enable_sca: bool = True,
        enable_cross_file: bool = True,
    ) -> None:
        self._extra_rule_dirs = [str(p) for p in extra_rule_dirs]
        self._disabled_rule_ids = list(disabled_rule_ids)
        self._rule_set = rule_set or load_rule_set(extra_rule_dirs, disabled_rule_ids)
        if disabled_rule_ids:
            self._rule_set.disabled_ids = self._rule_set.disabled_ids | frozenset(disabled_rule_ids)
        self._registry = registry or default_registry
        self._cache = cache
        self._max_workers = max_workers  # 0 == auto
        self._enable_sca = enable_sca
        self._enable_cross_file = enable_cross_file
        self._cancel = threading.Event()

    @property
    def rule_set(self) -> RuleSet:
        return self._rule_set

    def cancel(self) -> None:
        """Request cooperative cancellation; the scan stops between files."""
        self._cancel.set()

    def run(
        self,
        files: Sequence[Path],
        root: Path,
        progress: ProgressCallback | None = None,
    ) -> ScanResult:
        """Analyse every file and return the aggregated scan result."""
        self._cancel.clear()
        result = ScanResult(root=root, started_at=datetime.now())
        # The tree-sitter availability is part of the key: installing (or
        # removing) the optional grammars changes what a scan can find, so
        # results cached under a different availability must not be served.
        engine_key = (f"{self.ENGINE_VERSION}:"
                      f"{tree_sitter_analysis.availability_fingerprint()}:"
                      f"{self._rule_set.content_hash()}")
        rule_engine = RuleEngine(self._rule_set)

        pending: list[Path] = []
        hashes: dict[Path, str] = {}
        unreadable: list[FileAnalysis] = []

        # Phase 1 - serve unchanged files from the incremental cache.
        # Files that cannot be read (after the transient-lock retries) are
        # recorded as failed analyses, never silently dropped: a security
        # scan must account for every file it discovered.
        for path in files:
            digest = self._content_hash(path)
            if digest is None:
                unreadable.append(FileAnalysis(
                    path=path, language_id="unknown",
                    tool_errors=["Could not read file (locked or unreadable) "
                                 "- it was NOT analysed."],
                ))
                continue
            hashes[path] = digest
            cached = self._cache.get(str(path), digest, engine_key) if self._cache else None
            if cached is not None:
                cached = copy.deepcopy(cached)
                cached.from_cache = True
                result.analyses.append(cached)
            else:
                pending.append(path)
        result.files_from_cache = len(result.analyses)
        result.analyses.extend(unreadable)

        # Phase 2 - analyse the remainder, in parallel when it pays off.
        total = len(files)
        done = len(result.analyses)
        use_pool = len(pending) >= PARALLEL_THRESHOLD

        if use_pool:
            done = self._run_parallel(pending, result, progress, done, total)
        else:
            for path in pending:
                if self._cancel.is_set():
                    break
                result.analyses.append(self._safe_analyze(path, rule_engine))
                done += 1
                if progress:
                    progress(done, total, path.name)

        # Cache only per-file evidence. Duplication and advisories depend on
        # project state and must be recomputed even when this file is unchanged.
        if self._cache:
            for analysis in result.analyses:
                if not analysis.from_cache and analysis.path in hashes:
                    self._cache.put(str(analysis.path), hashes[analysis.path],
                                    engine_key, copy.deepcopy(analysis))

        DuplicationDetector(self._registry).annotate(result.analyses)
        if self._enable_sca:
            self._run_sca(result, root)

        # Phase 5 - cross-file taint. Deliberately AFTER the cache
        # write-back: these findings depend on OTHER files, so they are
        # recomputed fresh every run and must never be replayed from cache.
        if self._enable_cross_file:
            self._run_cross_file(result)

        for analysis in result.analyses:
            spec = self._registry.get(analysis.language_id)
            if spec is not None:
                try:
                    source = analysis.path.read_text(encoding='utf-8', errors='replace')
                    analysis.findings = rule_engine.apply_policy(analysis.findings, source, spec)
                except OSError:
                    analysis.tool_errors.append('Could not re-read source for final policy application.')

        result.analyses.sort(key=lambda a: str(a.path).lower())
        result.finished_at = datetime.now()
        return result

    # ---- Internals ----------------------------------------------------------

    def _run_parallel(
        self,
        pending: list[Path],
        result: ScanResult,
        progress: ProgressCallback | None,
        done: int,
        total: int,
    ) -> int:
        workers = self._max_workers or None  # None == os.cpu_count()
        try:
            with ProcessPoolExecutor(
                max_workers=workers,
                initializer=_init_worker,
                initargs=(self._rule_set, self._registry),
            ) as pool:
                futures = {pool.submit(_analyze_in_worker, str(p)): p for p in pending}
                for future in as_completed(futures):
                    if self._cancel.is_set():
                        pool.shutdown(cancel_futures=True)
                        break
                    path = futures[future]
                    try:
                        result.analyses.append(future.result())
                    except Exception as exc:  # noqa: BLE001 - isolate per-file faults
                        logger.exception("Worker failed on %s", path)
                        result.analyses.append(FileAnalysis(
                            path=path, language_id="unknown",
                            tool_errors=[f"Analysis failed: {exc}"],
                        ))
                    done += 1
                    if progress:
                        progress(done, total, path.name)
        except (OSError, RuntimeError) as exc:
            # Pool could not start (sandboxed/embedded interpreter) -
            # degrade gracefully to serial analysis.
            logger.warning("Process pool unavailable (%s); running serially.", exc)
            rule_engine = RuleEngine(self._rule_set)
            analysed = {a.path for a in result.analyses}
            for path in pending:
                if self._cancel.is_set() or path in analysed:
                    continue
                result.analyses.append(self._safe_analyze(path, rule_engine))
                done += 1
                if progress:
                    progress(done, total, path.name)
        return done

    def _safe_analyze(self, path: Path, rule_engine: RuleEngine) -> FileAnalysis:
        try:
            return analyze_file(path, rule_engine, self._registry)
        except Exception as exc:
            logger.exception('Analysis failed on %s', path)
            return FileAnalysis(path=path, language_id='unknown',
                                tool_errors=[f'Analysis failed: {exc}'])

    def _run_sca(self, result: ScanResult, root: Path) -> None:
        """Attach vulnerable-dependency findings to their manifest analyses."""
        try:
            from . import advisories
            scanner = advisories.open_default()
        except Exception:  # noqa: BLE001 - optional feature, never fatal
            logger.debug("SCA unavailable", exc_info=True)
            return
        if scanner is None:
            return
        try:
            by_manifest = scanner.scan(root)
        except Exception:  # noqa: BLE001
            logger.warning("Software-composition analysis failed", exc_info=True)
            return
        finally:
            scanner.close()

        if not by_manifest:
            return
        index = {a.path.name: a for a in result.analyses}
        for manifest_name, findings in by_manifest.items():
            analysis = index.get(manifest_name)
            if analysis is None:
                analysis = FileAnalysis(path=root / manifest_name,
                                        language_id="manifest")
                result.analyses.append(analysis)
                index[manifest_name] = analysis
            analysis.findings.extend(findings)
            if advisories.TOOL_NAME not in analysis.tools_run:
                analysis.tools_run.append(advisories.TOOL_NAME)

    @staticmethod
    def _run_cross_file(result: ScanResult) -> None:
        """Attach cross-file taint findings; never fatal to a scan."""
        try:
            from .crossfile import CrossFileTaintAnalyzer
            CrossFileTaintAnalyzer().annotate(result.analyses)
        except Exception:  # noqa: BLE001 - analysis add-on, fault-isolated
            logger.warning("Cross-file taint analysis failed", exc_info=True)

    @staticmethod
    def _content_hash(path: Path) -> str | None:
        try:
            return hashlib.sha256(_read_with_retry(path.read_bytes)).hexdigest()
        except OSError:
            return None
