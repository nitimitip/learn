"""
Tree-sitter analysis: real parse trees for JavaScript, TypeScript and Java.

This closes the biggest gap between CodeSentinel and parser-based tools:
until now only Python had AST-level checks and taint tracking - every other
language was regex-per-line. This module brings the same two analyzers to
the JS family and Java, driven by tree-sitter grammars:

  * structural checks - long functions, parameter overload, deep loop
    nesting, the N+1 query pattern, and swallowed exceptions (empty catch),
    mirroring `ast_checks.PythonAstChecker`;
  * taint tracking - forward source->sink data-flow over the parse tree with
    sanitiser kills and one level of interprocedural awareness for local
    wrapper functions, mirroring `taint.PythonTaintScanner`.

Go, Rust, Kotlin and Swift are supported at the DECLARATIVE-query level only
(QUERY_ONLY_LANGUAGES): they have no bespoke structural/taint analyzer yet,
but their grammars are loaded so the parse-tree query rules in the
`tree_queries` pack run against a real syntax tree (no lexical guessing,
never firing inside strings or comments).

The dependency is OPTIONAL. tree-sitter wheels (`tree_sitter` plus the
per-language grammar packages) may be absent in an air-gapped install; in
that case `scan()` returns None and files fall back to the regex rules
exactly as before - no error, no degraded scan, just fewer analyzers.
Availability is folded into the incremental-cache key (see
`availability_fingerprint`), so installing the wheels later invalidates
stale cached results automatically.

Everything here is 3.9-compatible and process-pool safe: parsers are built
lazily once per process and never pickled.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from ..domain.models import Finding, RiskCategory, Severity
from . import frameworks

logger = logging.getLogger(__name__)

TOOL_NAME = "sentinel-tree-sitter"

#: Languages with a full parse-tree analyzer (structural checks + taint).
STRUCTURAL_LANGUAGES = ("javascript", "typescript", "java", "csharp")
#: Languages that get parse-tree DECLARATIVE query rules only (no bespoke
#: structural/taint analyzer yet). A grammar is still required; without the
#: wheel these files stay on their regex packs exactly as before.
QUERY_ONLY_LANGUAGES = ("go", "rust", "kotlin", "swift")
#: Language ids (languages.LanguageSpec.id) this module can analyse.
SUPPORTED_LANGUAGES = STRUCTURAL_LANGUAGES + QUERY_ONLY_LANGUAGES

#: grammar key -> (pip module, factory function). TSX needs its own grammar
#: to parse JSX syntax; plain .ts must NOT use it (ambiguous `<T>` casts).
_GRAMMARS = {
    "javascript": ("tree_sitter_javascript", "language"),
    "typescript": ("tree_sitter_typescript", "language_typescript"),
    "tsx": ("tree_sitter_typescript", "language_tsx"),
    "java": ("tree_sitter_java", "language"),
    "csharp": ("tree_sitter_c_sharp", "language"),
    "go": ("tree_sitter_go", "language"),
    "rust": ("tree_sitter_rust", "language"),
    "kotlin": ("tree_sitter_kotlin", "language"),
    "swift": ("tree_sitter_swift", "language"),
}

#: Per-process parser cache: grammar key -> Parser, or None == unavailable.
_parsers: dict = {}
#: Per-process Language cache (needed to compile queries against).
_languages: dict = {}
#: Per-process compiled-query cache: (grammar key, query text) -> Query,
#: or None == the query failed to compile (logged once, then skipped).
_compiled_queries: dict = {}

# Shared structural thresholds - same numbers as the Python AST checker.
MAX_FUNCTION_LINES = 60
MAX_PARAMETERS = 7
MAX_LOOP_DEPTH = 3
#: SonarSource's default cognitive-complexity gate for one function.
MAX_COGNITIVE_COMPLEXITY = 15

#: Node types that break linear flow and charge a nesting penalty.
_COGNITIVE_BRANCH_TYPES = frozenset({
    "catch_clause", "switch_statement", "switch_expression",
    "ternary_expression", "conditional_expression",
})

#: Regex pack rules superseded by the exit-aware parse-tree loop check.
#: The engine drops these from the regex findings whenever this analyzer
#: actually ran on the file (regex stays as the no-grammar fallback).
SUPERSEDED_RULE_IDS = frozenset({"JS-L001", "JV-L001", "CS-L001"})

#: profile language id -> rule id for the unconditional-no-exit loop finding
#: (same ids as the superseded regex rules, so SARIF/triage identity holds).
_LOOP_RULE_IDS = {"javascript": "JS-L001", "java": "JV-L001",
                  "csharp": "CS-L001"}
#: Statements that can transfer control out of a loop (yield counts: the
#: consumer of an infinite generator decides when iteration stops).
_LOOP_EXIT_TYPES = frozenset({
    "return_statement", "throw_statement", "throw_expression",
    "yield_expression", "yield_statement", "goto_statement",
})
#: `break` binds to the innermost loop OR switch - a break inside these
#: does not exit the loop under test.
_BREAK_OWNER_TYPES = frozenset({"switch_statement", "switch_expression"})
#: Nested executable scopes whose returns/throws do not leave the loop.
_NESTED_SCOPE_TYPES = frozenset({
    "lambda_expression", "anonymous_method_expression",
    "local_function_statement", "class_declaration", "class_body",
})

#: Statement types after which the rest of a block can never execute.
_FLOW_TERMINATORS = frozenset({
    "return_statement", "throw_statement", "break_statement",
    "continue_statement",
})
#: Block node types whose named children form a straight-line statement list.
_BLOCK_TYPES = frozenset({"statement_block", "block"})
#: Statements that are HOISTED in JS - reachable even after a return.
_HOISTED_TYPES = frozenset({"function_declaration",
                            "generator_function_declaration"})


def _parser(grammar_key: str):
    """Build (once per process) the parser for a grammar; None if absent."""
    if grammar_key in _parsers:
        return _parsers[grammar_key]
    parser = None
    try:
        import importlib

        from tree_sitter import Language, Parser

        module_name, factory = _GRAMMARS[grammar_key]
        module = importlib.import_module(module_name)
        language = Language(getattr(module, factory)())
        try:
            parser = Parser(language)          # tree_sitter >= 0.22
        except TypeError:
            parser = Parser()                  # tree_sitter <= 0.21
            parser.set_language(language)
        _languages[grammar_key] = language
    except Exception:                          # noqa: BLE001 - optional dep
        logger.debug("tree-sitter grammar %r unavailable", grammar_key,
                     exc_info=True)
        parser = None
    _parsers[grammar_key] = parser
    return parser


def _grammar_key(language_id: str, suffix: str) -> str:
    if language_id == "typescript" and suffix == ".tsx":
        return "tsx"
    return language_id


def availability_fingerprint() -> str:
    """
    Which grammars this process can load - part of the incremental-cache
    key, so results analysed without tree-sitter are re-analysed once the
    wheels are installed (and vice versa).
    """
    available = [key for key in sorted(_GRAMMARS) if _parser(key) is not None]
    return "+".join(available) if available else "none"


def scan(
    text: str,
    language_id: str,
    suffix: str = "",
    query_rules: "tuple | list" = (),
) -> "list[Finding] | None":
    """
    Analyse one file; returns None when the grammar is unavailable so the
    caller can keep `tools_run` honest (an empty list means "ran, clean").

    `query_rules` are declarative parse-tree rules (rules.model.QueryRule)
    executed against the same tree as the structural and taint analyzers.
    """
    if language_id not in SUPPORTED_LANGUAGES:
        return None
    grammar_key = _grammar_key(language_id, suffix.lower())
    parser = _parser(grammar_key)
    if parser is None:
        return None
    try:
        tree = parser.parse(text.encode("utf-8", "replace"))
    except Exception:                          # noqa: BLE001 - never abort a scan
        logger.warning("tree-sitter failed to parse a %s file", language_id,
                       exc_info=True)
        return None

    root = tree.root_node
    if root.has_error:
        return [Finding(
            tool=TOOL_NAME, rule_id='PARSE-001', severity=Severity.HIGH,
            category=RiskCategory.RELIABILITY, line=1, cwe='CWE-1078',
            message='The language parser reported invalid or unsupported syntax; structural analysis is incomplete.',
            remediation='Fix syntax errors or use a compatible language grammar, then run a fresh scan.',
            confidence='HIGH',
        )]
    # STRUCTURAL_LANGUAGES have a bespoke analyzer; QUERY_ONLY_LANGUAGES
    # (go/rust/kotlin/swift) have no profile and rely on the declarative
    # query rules alone.
    profile = _PROFILES.get(language_id)
    findings: list = []
    if profile is not None:
        findings.extend(_StructuralChecker(profile).scan(root))
        findings.extend(_TaintScanner(profile).scan(root))
    if query_rules:
        findings.extend(_run_query_rules(grammar_key, root, query_rules))
    return findings


# ---------------------------------------------------------------------------
# Declarative parse-tree query rules (rules.model.QueryRule)
# ---------------------------------------------------------------------------

def _compiled_query(grammar_key: str, query_text: str):
    """Compile (once per process) a query for a grammar; None on failure."""
    cache_key = (grammar_key, query_text)
    if cache_key in _compiled_queries:
        return _compiled_queries[cache_key]
    compiled = None
    language = _languages.get(grammar_key)
    if language is not None:
        try:
            try:
                from tree_sitter import Query
                compiled = Query(language, query_text)   # tree_sitter >= 0.22
            except (ImportError, TypeError):
                compiled = language.query(query_text)    # tree_sitter <= 0.21
        except Exception:                  # noqa: BLE001 - bad query, skip rule
            logger.error("Query rule failed to compile for grammar %r: %r",
                         grammar_key, query_text, exc_info=True)
    _compiled_queries[cache_key] = compiled
    return compiled


def _query_captures(compiled, root) -> "list[tuple]":
    """(node, capture_name) pairs across the py-tree-sitter API versions."""
    try:
        from tree_sitter import QueryCursor                # >= 0.25
        captures = QueryCursor(compiled).captures(root)
    except Exception:                          # noqa: BLE001 - older bindings
        captures = compiled.captures(root)
    if isinstance(captures, dict):                         # >= 0.24
        return [(node, name) for name, nodes in captures.items()
                for node in nodes]
    return [(node, name) for node, name in captures]       # <= 0.23


def _run_query_rules(grammar_key: str, root, query_rules) -> "list[Finding]":
    findings: list = []
    for rule in query_rules:
        compiled = _compiled_query(grammar_key, rule.query)
        if compiled is None:
            findings.append(Finding(tool=TOOL_NAME, rule_id='PARSE-QUERY',
                severity=Severity.HIGH, category=RiskCategory.RELIABILITY, line=1,
                message=f'Query rule {rule.id} could not compile; analysis coverage is incomplete.',
                remediation='Correct the query or install its compatible grammar and re-scan.'))
            continue
        try:
            captures = _query_captures(compiled, root)
        except Exception:                      # noqa: BLE001 - never abort a scan
            logger.warning("Query rule %s failed to execute", rule.id,
                           exc_info=True)
            findings.append(Finding(tool=TOOL_NAME, rule_id='PARSE-QUERY',
                severity=Severity.HIGH, category=RiskCategory.RELIABILITY, line=1,
                message=f'Query rule {rule.id} failed during execution; analysis coverage is incomplete.',
                remediation='Review analyzer logs, correct the query/runtime and re-scan.'))
            continue
        seen: set = set()
        for node, name in captures:
            if name != rule.capture:
                continue
            line = _line(node)
            if line in seen:
                continue
            seen.add(line)
            findings.append(Finding(
                tool=TOOL_NAME, rule_id=rule.id, severity=rule.severity,
                line=line, category=rule.category, cwe=rule.cwe,
                owasp=rule.owasp, confidence=rule.confidence,
                message=rule.message, remediation=rule.remediation,
                snippet=_text(node).splitlines()[0][:200] if _text(node) else "",
            ))
    return findings


# ---------------------------------------------------------------------------
# Node helpers
# ---------------------------------------------------------------------------

def _text(node) -> str:
    raw = node.text
    return raw.decode("utf-8", "replace") if raw else ""


def _line(node) -> int:
    return node.start_point[0] + 1


def _preorder(node):
    """Document-order traversal (named nodes only)."""
    stack = [node]
    while stack:
        current = stack.pop()
        yield current
        stack.extend(reversed(current.named_children))


def _field(node, name: str):
    return node.child_by_field_name(name)


# ---------------------------------------------------------------------------
# Language profiles: node vocabulary + taint dictionaries
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class _Profile:
    """Grammar node names and taint vocabulary for one language family."""

    language_id: str
    function_defs: frozenset
    loop_types: frozenset
    call_type: str
    member_types: frozenset
    new_type: str
    #: sink method/function name -> (rule id, severity, label, CWE)
    sink_calls: dict
    #: constructor type name -> (rule id, severity, label, CWE)
    new_sinks: dict
    source_calls: frozenset
    #: Dotted-expression prefixes that denote external input.
    source_prefixes: tuple
    sanitizers: frozenset
    #: Assigned properties that are sinks: property name -> (rule id,
    #: severity, label, CWE). `el.innerHTML = tainted` (XSS),
    #: `searcher.Filter = tainted` (LDAP), `psi.Arguments = tainted` (CMD).
    #: Gated by `sink_receiver_types` under the same property name.
    sink_assign_props: dict = field(default_factory=dict)
    #: Which constructor arguments actually carry the dangerous value:
    #: type name -> (positions tuple, accepted parameter names). Only these
    #: are taint-checked, so a tainted connection/encoding/search-root
    #: argument is not reported as SQL/LDAP injection. Constructor sinks
    #: absent from this map use `new_sink_default_args`.
    new_sink_args: dict = field(default_factory=dict)
    #: Fallback (positions, parameter names) for unlisted constructor sinks.
    new_sink_default_args: tuple = ((0,), frozenset())
    #: Method names indicating a database round-trip (N+1 detection).
    db_call_names: frozenset = frozenset()

    # ---- Grammar-specific node access (defaults suit the JS family) --------
    #: How the invoked name is found: "function" (JS/C#: a `function` field
    #: that is an identifier or member access) or "method" (Java: a `name`
    #: field directly on the call, receiver in an `object` field).
    call_name_style: str = "function"
    #: Field on a member/access node holding the receiver object.
    member_object_field: str = "object"
    #: Field on a member/access node holding the accessed name.
    member_property_field: str = "property"
    #: When set, call arguments are wrapped one level (C# `argument` nodes);
    #: unwrap to the inner expression before taint analysis.
    arg_wrapper: str = ""
    #: Field holding a variable declarator's initializer, or "" when the
    #: initializer is simply the declarator's last named child (C#).
    declarator_value_field: str = "value"
    #: Node types that hold an embedded expression inside a string template.
    interpolation_types: frozenset = frozenset({"template_substitution"})
    #: Receiver-gated call sinks: method name -> (receiver last-segment,
    #: (rule, severity, label, CWE)). Fires only when the call's receiver
    #: matches - keeps generic names like write()/Start() precise
    #: (document.write XSS, Response.Write XSS, Process.Start command exec).
    receiver_gated_calls: dict = None  # type: ignore[assignment]
    #: Stage 4 type approximation: sink method name -> plausible receiver
    #: TYPE substrings (case-insensitive). When the receiver's declared/
    #: inferred type is KNOWN and matches none of them, the sink is
    #: suppressed (a false-positive kill); an unknown type always fires -
    #: typing only ever removes findings, never recall.
    sink_receiver_types: dict = None  # type: ignore[assignment]

    # ---- Framework-model hooks (populated by frameworks.merge_into) --------
    #: Parameter annotations/attributes that mark a parameter as an input
    #: source (ASP.NET [FromQuery], Spring @RequestParam).
    param_source_annotations: frozenset = frozenset()
    #: Grammar node types that represent a parameter annotation/attribute
    #: (C#: "attribute"; Java: "marker_annotation"/"annotation").
    annotation_node_types: frozenset = frozenset()
    #: JSX attribute names that are XSS sinks (React dangerouslySetInnerHTML).
    jsx_sink_attrs: frozenset = frozenset()

    def __post_init__(self) -> None:
        if self.receiver_gated_calls is None:
            object.__setattr__(self, "receiver_gated_calls", {})
        if self.sink_receiver_types is None:
            object.__setattr__(self, "sink_receiver_types", {})


_SQL = ("TAINT-SQL", Severity.CRITICAL, "SQL execution", "CWE-89")
_CMD = ("TAINT-CMD", Severity.CRITICAL, "OS command execution", "CWE-78")
_EVAL = ("TAINT-EVAL", Severity.CRITICAL, "code evaluation", "CWE-95")
_PATH = ("TAINT-PATH", Severity.MEDIUM, "file access", "CWE-22")
_XSS = ("TAINT-XSS", Severity.HIGH, "HTML injection (XSS)", "CWE-79")
_SSRF = ("TAINT-SSRF", Severity.HIGH, "an outbound HTTP request", "CWE-918")
_LDAP = ("TAINT-LDAP", Severity.HIGH, "an LDAP directory query", "CWE-90")
_XPATH = ("TAINT-XPATH", Severity.HIGH, "an XPath query", "CWE-643")
_REFLECT = ("TAINT-REFLECT", Severity.HIGH, "type/assembly loading", "CWE-470")

#: Sink rule id -> OWASP Top 10 2021 category. Most taint sinks are injection
#: (A03); SSRF and path traversal belong to different categories, so the
#: finding must not be stamped A03 for them.
_SINK_OWASP = {
    "TAINT-SSRF": "A10:2021-Server-Side Request Forgery",
    "TAINT-PATH": "A01:2021-Broken Access Control",
    "TAINT-REFLECT": "A08:2021-Software and Data Integrity Failures",
}
_DEFAULT_SINK_OWASP = "A03:2021-Injection"

_JS_PROFILE = _Profile(
    language_id="javascript",
    function_defs=frozenset({
        "function_declaration", "function_expression", "arrow_function",
        "method_definition", "generator_function_declaration",
    }),
    loop_types=frozenset({
        "for_statement", "for_in_statement", "while_statement", "do_statement",
    }),
    call_type="call_expression",
    member_types=frozenset({"member_expression", "subscript_expression"}),
    new_type="new_expression",
    sink_calls={
        "eval": _EVAL,
        "Function": _EVAL,
        "exec": _CMD,
        "execSync": _CMD,
        "query": _SQL,
        "execute": _SQL,
    },
    new_sinks={"Function": _EVAL},
    source_calls=frozenset({"prompt"}),
    source_prefixes=(
        "req.query", "req.body", "req.params", "req.headers", "req.cookies",
        "request.query", "request.body", "request.params",
        "ctx.query", "ctx.request",
        "location.search", "location.hash", "location.href",
        "window.location", "document.location", "document.cookie",
        "process.argv",
    ),
    sanitizers=frozenset({
        "parseInt", "parseFloat", "Number", "Boolean",
    }),
    sink_assign_props={"innerHTML": _XSS, "outerHTML": _XSS},
    db_call_names=frozenset({"query", "execute"}),
    receiver_gated_calls={
        "write": ("document", _XSS),
        "writeln": ("document", _XSS),
    },
    sink_receiver_types={
        # node-postgres Pool/Client, mysql/mysql2 Connection/Pool, knex,
        # sequelize, generic db/database handles.
        "query": ("pool", "client", "connection", "database", "db",
                  "knex", "sequelize"),
        "execute": ("pool", "client", "connection", "database", "db"),
    },
)

_JAVA_PROFILE = _Profile(
    language_id="java",
    function_defs=frozenset({"method_declaration", "constructor_declaration"}),
    loop_types=frozenset({
        "for_statement", "enhanced_for_statement", "while_statement",
        "do_statement",
    }),
    call_type="method_invocation",
    call_name_style="method",
    member_types=frozenset({"field_access"}),
    new_type="object_creation_expression",
    annotation_node_types=frozenset({"marker_annotation", "annotation"}),
    sink_calls={
        "executeQuery": _SQL,
        "executeUpdate": _SQL,
        "execute": _SQL,
        "addBatch": _SQL,
        "exec": _CMD,
        "eval": _EVAL,               # javax.script.ScriptEngine
    },
    new_sinks={
        "ProcessBuilder": _CMD,
        "File": _PATH,
        "FileInputStream": _PATH,
        "FileReader": _PATH,
        "FileWriter": _PATH,
    },
    source_calls=frozenset({
        "getParameter", "getParameterValues", "getHeader", "getQueryString",
        "getCookies", "nextLine", "next", "readLine",
    }),
    source_prefixes=(),
    sanitizers=frozenset({
        "parseInt", "parseLong", "parseDouble", "parseFloat", "parseBoolean",
    }),
    db_call_names=frozenset({
        "executeQuery", "executeUpdate", "execute", "executeBatch", "commit",
    }),
    sink_receiver_types={
        # JDBC statement family, Spring JdbcTemplate, JPA EntityManager.
        "executeQuery": ("statement", "jdbctemplate", "entitymanager"),
        "executeUpdate": ("statement", "jdbctemplate", "entitymanager"),
        "execute": ("statement", "jdbctemplate", "entitymanager"),
        "addBatch": ("statement",),
    },
)

_CSHARP_PROFILE = _Profile(
    language_id="csharp",
    function_defs=frozenset({
        "method_declaration", "constructor_declaration",
        "local_function_statement",
    }),
    loop_types=frozenset({
        "for_statement", "foreach_statement", "while_statement", "do_statement",
    }),
    call_type="invocation_expression",
    member_types=frozenset({
        "member_access_expression", "element_access_expression",
    }),
    new_type="object_creation_expression",
    sink_calls={
        "ExecuteReader": _SQL,
        "ExecuteNonQuery": _SQL,
        "ExecuteScalar": _SQL,
        "ExecuteQuery": _SQL,
        "Query": _SQL,               # Dapper: conn.Query(sql, ...)
        "Execute": _SQL,             # Dapper: conn.Execute(sql, ...)
        # System.Xml / System.Xml.XPath - the argument is an XPath expression.
        "SelectSingleNode": _XPATH,
        "SelectNodes": _XPATH,
        "XPathSelectElement": _XPATH,
        "XPathSelectElements": _XPATH,
        "XPathEvaluate": _XPATH,
        # System.Reflection - loading a type or assembly chosen by the caller.
        "GetType": _REFLECT,
        "LoadFrom": _REFLECT,
        "LoadFile": _REFLECT,
        "UnsafeLoadFrom": _REFLECT,
        "CreateInstanceFrom": _REFLECT,
    },
    new_sinks={
        # Tainted SQL concatenated into a command object at construction.
        "SqlCommand": _SQL,
        "OleDbCommand": _SQL,
        "MySqlCommand": _SQL,
        "OracleCommand": _SQL,
        "NpgsqlCommand": _SQL,
        # File access with an attacker-influenced path.
        "StreamReader": _PATH,
        "StreamWriter": _PATH,
        "FileStream": _PATH,
        # System.DirectoryServices - the filter argument is an LDAP query.
        "DirectorySearcher": _LDAP,
    },
    new_sink_args={
        # `new SqlCommand(cmdText, connection)` - argument 0 only.
        "SqlCommand": ((0,), frozenset({"cmdText", "commandText"})),
        "OleDbCommand": ((0,), frozenset({"cmdText", "commandText"})),
        "MySqlCommand": ((0,), frozenset({"cmdText", "commandText"})),
        "OracleCommand": ((0,), frozenset({"cmdText", "commandText"})),
        "NpgsqlCommand": ((0,), frozenset({"cmdText", "commandText"})),
        "StreamReader": ((0,), frozenset({"path"})),
        "StreamWriter": ((0,), frozenset({"path"})),
        "FileStream": ((0,), frozenset({"path"})),
        # DirectorySearcher has both `(filter)` and `(searchRoot, filter)`
        # overloads; a tainted search root is DN injection, also CWE-90.
        "DirectorySearcher": ((0, 1), frozenset({"filter"})),
    },
    new_sink_default_args=((0,), frozenset({"cmdText", "commandText",
                                            "selectCommandText", "path"})),
    source_calls=frozenset({"ReadLine"}),
    source_prefixes=(
        # ASP.NET (classic PascalCase and Core lower-case parameter forms).
        "Request.Query", "Request.Form", "Request.QueryString",
        "Request.Params", "Request.Cookies", "Request.Headers",
        "request.Query", "request.Form", "request.QueryString",
        "request.Params", "request.Cookies", "request.Headers",
        "HttpContext.Current.Request", "Request.RawUrl", "Request.Url",
    ),
    sanitizers=frozenset({
        "ToInt32", "ToInt64", "ToDouble", "ToDecimal", "ToBoolean",
    }),
    db_call_names=frozenset({
        "ExecuteReader", "ExecuteNonQuery", "ExecuteScalar", "ExecuteQuery",
        "Query", "Execute",
    }),
    receiver_gated_calls={
        "Write": ("Response", _XSS),
        "WriteLine": ("Response", _XSS),
        "Start": ("Process", _CMD),      # Process.Start(tainted)
    },
    sink_assign_props={
        # System.DirectoryServices.DirectorySearcher.Filter
        "Filter": _LDAP,
        # System.Diagnostics.ProcessStartInfo.Arguments / .FileName
        "Arguments": _CMD,
        # ADO.NET IDbCommand.CommandText assigned after construction.
        "CommandText": _SQL,
        # System.Web.UI.HtmlControls InnerHtml (raw markup).
        "InnerHtml": _XSS,
    },
    sink_receiver_types={
        # ADO.NET command objects; Dapper extends IDbConnection.
        "ExecuteReader": ("command",),
        "ExecuteNonQuery": ("command",),
        "ExecuteScalar": ("command",),
        "ExecuteQuery": ("command", "connection", "context", "database"),
        "Query": ("connection", "context", "database"),
        "Execute": ("connection", "context", "database"),
        # Reflection: only System.Type.GetType(string) loads a chosen type;
        # the parameterless object.GetType() has no argument to taint.
        "GetType": ("type",),
        "LoadFrom": ("assembly",),
        "LoadFile": ("assembly",),
        "UnsafeLoadFrom": ("assembly",),
        "CreateInstanceFrom": ("activator", "appdomain"),
        # XPath receivers are XML documents/nodes, never a DB command.
        "SelectSingleNode": ("xml", "node", "document", "element"),
        "SelectNodes": ("xml", "node", "document", "element"),
        # SSRF: generic verb names are only outbound requests on an HTTP
        # client. A typed receiver of any other kind suppresses them.
        "GetAsync": ("httpclient", "client"),
        "PostAsync": ("httpclient", "client"),
        "PutAsync": ("httpclient", "client"),
        "PatchAsync": ("httpclient", "client"),
        "DeleteAsync": ("httpclient", "client"),
        "SendAsync": ("httpclient", "client"),
        "OpenRead": ("webclient", "client"),
        "UploadString": ("webclient", "client"),
        # Property sinks (see sink_assign_props) share this gate by name.
        "Filter": ("directorysearcher", "searcher"),
        "Arguments": ("processstartinfo", "startinfo"),
        "CommandText": ("command",),
    },
    # Grammar-specific node access for the C# tree-sitter grammar.
    call_name_style="function",
    member_object_field="expression",
    member_property_field="name",
    arg_wrapper="argument",
    declarator_value_field="",            # initializer is the last child
    interpolation_types=frozenset({"interpolation"}),
    annotation_node_types=frozenset({"attribute"}),
)

#: Base profiles enriched with framework models (Express/React, ASP.NET Core/
#: EF Core/Dapper, Spring). Merging is unconditional and FP-safe because every
#: framework addition is a specific construct (see frameworks.py).
_PROFILES = {
    "javascript": frameworks.merge_into(_JS_PROFILE),
    "typescript": frameworks.merge_into(_JS_PROFILE),
    "java": frameworks.merge_into(_JAVA_PROFILE),
    "csharp": frameworks.merge_into(_CSHARP_PROFILE),
}


# ---------------------------------------------------------------------------
# Structural checks (mirrors ast_checks.PythonAstChecker)
# ---------------------------------------------------------------------------

class _StructuralChecker:
    """Function size/params, empty catch, loop nesting, N+1 queries."""

    def __init__(self, profile: _Profile) -> None:
        self._profile = profile

    def scan(self, root) -> "list[Finding]":
        findings: list = []
        for node in _preorder(root):
            if node.type in self._profile.function_defs:
                findings.extend(self._check_function(node))
            elif node.type == "catch_clause":
                findings.extend(self._check_catch(node))
            elif node.type in self._profile.loop_types:
                findings.extend(self._check_infinite_loop(node))
            elif node.type in _BLOCK_TYPES:
                findings.extend(self._check_unreachable(node))
        findings.extend(self._loop_checks(root))
        return findings

    # ---- Unreachable code (roadmap Stage 3) --------------------------------

    @staticmethod
    def _check_unreachable(block) -> "list[Finding]":
        statements = [c for c in block.named_children if c.type != "comment"]
        for index, stmt in enumerate(statements[:-1]):
            if stmt.type not in _FLOW_TERMINATORS:
                continue
            follower = statements[index + 1]
            # JS hoists function declarations - they ARE reachable.
            if follower.type in _HOISTED_TYPES:
                continue
            return [Finding(
                tool=TOOL_NAME, rule_id="AST-U001", severity=Severity.MEDIUM,
                line=_line(follower), category=RiskCategory.RELIABILITY,
                cwe="CWE-561",
                message=f"Unreachable code: this statement follows a "
                        f"{stmt.type.replace('_statement', '')} on line "
                        f"{_line(stmt)} in the same block and can never "
                        f"execute.",
                remediation="Delete the dead statements, or move them before "
                            "the terminating statement if they were meant "
                            "to run.",
            )]
        return []

    # ---- Infinite loops (exit-aware, supersedes the *-L001 regex rules) ----

    def _check_infinite_loop(self, node) -> "list[Finding]":
        """`while(true)` / `for(;;)` / `do...while(true)` with no way out."""
        rule_id = _LOOP_RULE_IDS.get(self._profile.language_id)
        if rule_id is None or not self._is_unconditional(node):
            return []
        body = _field(node, "body")
        if body is None or self._loop_body_has_exit(body):
            return []
        return [Finding(
            tool=TOOL_NAME, rule_id=rule_id, severity=Severity.MEDIUM,
            line=_line(node), category=RiskCategory.RELIABILITY,
            cwe="CWE-835",
            message="Unconditional loop with no reachable exit - the body "
                    "contains no break, return, throw, yield, or goto, so "
                    "the loop can never terminate.",
            remediation="Add a reachable exit (break on a condition, return, "
                        "or a real loop condition). If this is an intentional "
                        "daemon loop, suppress with 'nosast'.",
        )]

    @staticmethod
    def _is_unconditional(node) -> bool:
        if node.type == "for_statement":
            cond = _field(node, "condition")
            if cond is None:
                return True                       # for(;;)
            text = _text(cond).strip().rstrip(";").strip()
            return text in ("", "true", "1")
        if node.type in ("while_statement", "do_statement"):
            cond = _field(node, "condition")
            if cond is None:
                return False
            text = _text(cond).strip()
            while text.startswith("(") and text.endswith(")"):
                text = text[1:-1].strip()
            return text in ("true", "1")
        return False

    def _loop_body_has_exit(self, body) -> bool:
        nested = set(self._profile.function_defs) | _NESTED_SCOPE_TYPES
        # break counts only at this loop's own level.
        break_skip = nested | set(self._profile.loop_types) | _BREAK_OWNER_TYPES
        if self._contains(body, frozenset({"break_statement"}), break_skip):
            return True
        return self._contains(body, _LOOP_EXIT_TYPES, nested)

    @staticmethod
    def _contains(root, target_types, skip_types) -> bool:
        stack = [root]
        while stack:
            node = stack.pop()
            if node.type in target_types:
                return True
            if node is not root and node.type in skip_types:
                continue
            stack.extend(node.named_children)
        return False

    def _function_name(self, node) -> str:
        name_node = _field(node, "name")
        if name_node is not None:
            return _text(name_node)
        # `const handler = (req) => {...}` - take the declarator's name.
        parent = node.parent
        if parent is not None and parent.type == "variable_declarator":
            declared = _field(parent, "name")
            if declared is not None:
                return _text(declared)
        return "<anonymous>"

    @staticmethod
    def _parameter_count(node) -> int:
        params = _field(node, "parameters")
        if params is not None:
            return len([c for c in params.named_children if c.type != "comment"])
        # Arrow function with a single bare parameter: `x => ...`
        return 1 if _field(node, "parameter") is not None else 0

    def _check_function(self, node) -> "list[Finding]":
        findings: list = []
        name = self._function_name(node)
        length = node.end_point[0] - node.start_point[0] + 1
        if length > MAX_FUNCTION_LINES:
            findings.append(Finding(
                tool=TOOL_NAME, rule_id="MET-FN1", severity=Severity.LOW,
                line=_line(node), category=RiskCategory.MAINTAINABILITY,
                cwe="CWE-1120",
                message=f"Function '{name}' is {length} lines long - "
                        f"hard to review, test, and modify safely.",
                remediation="Decompose into smaller single-purpose functions; "
                            "each extracted step becomes individually testable.",
            ))
        cognitive = self._cognitive_complexity(node)
        if cognitive > MAX_COGNITIVE_COMPLEXITY:
            findings.append(Finding(
                tool=TOOL_NAME, rule_id="MET-FN3", severity=Severity.MEDIUM,
                line=_line(node), category=RiskCategory.MAINTAINABILITY,
                cwe="CWE-1120",
                message=f"Function '{name}' has cognitive complexity "
                        f"{cognitive} (limit {MAX_COGNITIVE_COMPLEXITY}) - "
                        f"the nesting and branching exceed what a reader can "
                        f"hold in working memory.",
                remediation="Flatten the structure: extract nested blocks "
                            "into named helpers, use early returns instead "
                            "of deep if-chains, and simplify compound "
                            "boolean conditions.",
            ))
        params = self._parameter_count(node)
        if params > MAX_PARAMETERS:
            findings.append(Finding(
                tool=TOOL_NAME, rule_id="MET-FN2", severity=Severity.LOW,
                line=_line(node), category=RiskCategory.MAINTAINABILITY,
                cwe="CWE-1064",
                message=f"Function '{name}' takes {params} parameters - "
                        f"callers will pass them in the wrong order eventually.",
                remediation="Group related parameters into an options object / "
                            "parameter class, or split the function by "
                            "responsibility.",
            ))
        return findings

    def _cognitive_complexity(self, func) -> int:
        """
        SonarSource cognitive complexity over the parse tree: +1 (+nesting)
        for if/loops/catch/switch/ternary, +1 flat for else and else-if,
        +1 per sequence of like boolean operators (only the head of an
        `a && b && c` chain counts), nested functions at one deeper level.
        """
        profile = self._profile
        nest_types = _COGNITIVE_BRANCH_TYPES | set(profile.loop_types)

        def is_else_if(node) -> bool:
            parent = node.parent
            if parent is None:
                return False
            if parent.type == "else_clause":                   # JS family
                return True
            if parent.type == "if_statement":                  # Java / C#
                alternative = _field(parent, "alternative")
                return alternative is not None and alternative == node
            return False

        def bool_sequence_head(node) -> bool:
            operator = _field(node, "operator")
            op_text = _text(operator) if operator is not None else ""
            if op_text not in ("&&", "||"):
                return False
            parent = node.parent
            if parent is not None and parent.type == "binary_expression":
                parent_op = _field(parent, "operator")
                if parent_op is not None and _text(parent_op) == op_text:
                    return False               # interior of the same chain
            return True

        def score(node, nesting: int) -> int:
            total = 0
            for child in node.named_children:
                child_nesting = nesting
                kind = child.type
                if kind in profile.function_defs:
                    child_nesting = nesting + 1
                elif kind == "if_statement":
                    total += 1 if is_else_if(child) else 1 + nesting
                    alternative = _field(child, "alternative")
                    if alternative is not None:
                        inner = alternative
                        if inner.type == "else_clause" and inner.named_children:
                            inner = inner.named_children[0]
                        if inner.type != "if_statement":
                            total += 1                         # a plain else
                    child_nesting = nesting + 1
                elif kind in nest_types:
                    total += 1 + nesting
                    child_nesting = nesting + 1
                elif kind == "binary_expression" and bool_sequence_head(child):
                    total += 1
                total += score(child, child_nesting)
            return total

        return score(func, 0)

    @staticmethod
    def _check_catch(node) -> "list[Finding]":
        body = _field(node, "body")
        if body is None:
            return []
        statements = [c for c in body.named_children if c.type != "comment"]
        if statements:
            return []
        return [Finding(
            tool=TOOL_NAME, rule_id="AST-Q001", severity=Severity.MEDIUM,
            line=_line(node), category=RiskCategory.RELIABILITY,
            cwe="CWE-390",
            message="Exception caught and silently discarded (empty catch "
                    "block) - failures vanish without logging or context.",
            remediation="Log the exception with context and handle or rethrow "
                        "it; never discard it.",
        )]

    def _loop_checks(self, root) -> "list[Finding]":
        """Deep loop nesting and DB calls inside loops (the N+1 pattern)."""
        profile = self._profile
        findings: list = []
        flagged_nesting: set = set()
        flagged_n_plus_1: set = set()

        def visit(node, loop_depth: int) -> None:
            if node.type in profile.loop_types:
                loop_depth += 1
                line = _line(node)
                if loop_depth >= MAX_LOOP_DEPTH and line not in flagged_nesting:
                    flagged_nesting.add(line)
                    findings.append(Finding(
                        tool=TOOL_NAME, rule_id="PERF-L1",
                        severity=Severity.MEDIUM, line=line,
                        category=RiskCategory.PERFORMANCE, cwe="CWE-1050",
                        message=f"Loops nested {loop_depth} levels deep - "
                                f"runtime grows as O(n^{loop_depth}) and will "
                                f"stall as data volume scales.",
                        remediation="Restructure with lookup maps/sets or a "
                                    "single pre-computed join instead of "
                                    "nested iteration.",
                    ))

            if loop_depth >= 1 and node.type == profile.call_type:
                name = _call_name(node, profile)
                line = _line(node)
                if name in profile.db_call_names and line not in flagged_n_plus_1:
                    flagged_n_plus_1.add(line)
                    findings.append(Finding(
                        tool=TOOL_NAME, rule_id="PERF-N1",
                        severity=Severity.MEDIUM, line=line,
                        category=RiskCategory.PERFORMANCE, cwe="CWE-1073",
                        message=f"Database call '{name}()' inside a loop - the "
                                f"N+1 query pattern: one round-trip per item "
                                f"instead of one per batch.",
                        remediation="Move the query outside the loop: fetch "
                                    "with a single IN (...) / JOIN, or use a "
                                    "batched statement for writes.",
                    ))

            for child in node.named_children:
                visit(child, loop_depth)

        visit(root, 0)
        return findings


def _call_name(call, profile: _Profile) -> str:
    """The invoked name: `f(x)` -> f, `db.query(x)` -> query."""
    if profile.call_name_style == "method":                # Java
        name = _field(call, "name")
        return _text(name) if name is not None else ""
    callee = _field(call, "function")                      # JS family, C#
    if callee is None:
        return ""
    if callee.type == "identifier":
        return _text(callee)
    if profile.language_id == 'csharp' and callee.type == 'generic_name':
        return _text(callee.named_children[0])
    if callee.type in profile.member_types:
        prop = _field(callee, profile.member_property_field)
        if prop is not None and profile.language_id == 'csharp' and prop.type == 'generic_name':
            return _text(prop.named_children[0])
        return _text(prop) if prop is not None else ""
    return ""


def _call_receiver(call, profile: _Profile):
    """The object a method is invoked on, or None for bare calls."""
    if profile.call_name_style == "method":                # Java
        return _field(call, "object")
    callee = _field(call, "function")
    if callee is not None and callee.type in profile.member_types:
        return _field(callee, profile.member_object_field)
    return None


def _call_args(call, profile: _Profile) -> list:
    args = _field(call, "arguments")
    if args is None:
        return []
    children = [c for c in args.named_children if c.type != "comment"]
    if not profile.arg_wrapper:                            # JS family, Java
        return children
    # C#: each argument is wrapped in an `argument` node; take its expression.
    unwrapped: list = []
    for child in children:
        if child.type == profile.arg_wrapper and child.named_children:
            unwrapped.append(child.named_children[-1])
        else:
            unwrapped.append(child)
    return unwrapped


def _parameter_arg(call, profile, position, names):
    """Select a modeled parameter, preserving C# named-argument binding."""
    if profile.language_id != 'csharp':
        args = _call_args(call, profile)
        return args[position] if position < len(args) else None
    arguments = _field(call, 'arguments')
    if arguments is None:
        return None
    children = [c for c in arguments.named_children if c.type != 'comment']
    for child in children:
        name = _field(child, 'name')
        if name is not None and _text(name) in names:
            return child.named_children[-1]
    if position < len(children) and _field(children[position], 'name') is None:
        return children[position].named_children[-1]
    return None


# ---------------------------------------------------------------------------
# Taint tracking (mirrors taint.PythonTaintScanner)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Stage 4 - per-file symbol table (declared / inferred receiver types)
# ---------------------------------------------------------------------------

#: Declared type spellings that carry no information.
_UNTYPED = frozenset({"var", "any", "object", "dynamic", "auto", "unknown"})


def _collect_declared_types(root) -> dict:
    """
    name -> type text for every variable whose type is syntactically visible:
    typed declarations and parameters (Java/C#), TS type annotations, and
    `new X()` initializers (all languages). A name declared with conflicting
    types collapses to None (= unknown), and unknown NEVER suppresses a
    finding - the table is only ever used to kill false positives.
    """
    types: dict = {}

    def put(name: str, type_text: str) -> None:
        if not name or not type_text:
            return
        cleaned = type_text.lstrip(":").strip()
        if not cleaned or cleaned.lower() in _UNTYPED:
            return
        if name in types:
            if types[name] != cleaned:
                types[name] = None          # conflicting declarations
        else:
            types[name] = cleaned

    def declarator_name(declarator):
        name_node = _field(declarator, "name")
        if name_node is None:
            name_node = next((c for c in declarator.named_children
                              if c.type == "identifier"), None)
        return name_node

    def constructed_type(value) -> str:
        node = value
        while node is not None and node.type in (
                "parenthesized_expression", "await_expression"):
            node = node.named_children[0] if node.named_children else None
        if node is not None and node.type in (
                "new_expression", "object_creation_expression"):
            ctor = _field(node, "constructor") or _field(node, "type")
            if ctor is not None:
                return _text(ctor)
        return ""

    for node in _preorder(root):
        kind = node.type
        if kind in ("local_variable_declaration", "field_declaration",
                    "variable_declaration"):               # Java / C#
            type_node = _field(node, "type")
            if type_node is None:
                continue
            type_text = _text(type_node)
            if type_text.strip().lower() in _UNTYPED:
                continue                    # `var` - the declarator infers
            for child in node.named_children:
                if child.type == "variable_declarator":
                    name_node = declarator_name(child)
                    if name_node is not None:
                        put(_text(name_node), type_text)
        elif kind == "variable_declarator":                # JS/TS + var-infer
            name_node = declarator_name(node)
            if name_node is None or name_node.type != "identifier":
                continue
            name = _text(name_node)
            annotated = _field(node, "type")               # TS annotation
            if annotated is not None:
                put(name, _text(annotated))
                continue
            if name in types:
                continue    # a declared type from the parent already won
            value = _field(node, "value")
            if value is None and node.named_children:
                # C#: no value field - the initializer is the last child.
                last = node.named_children[-1]
                if last is not name_node:
                    value = last
            if value is not None:
                put(name, constructed_type(value))
        elif kind in ("formal_parameter", "parameter"):    # Java / C#
            type_node = _field(node, "type")
            name_node = _field(node, "name")
            if type_node is not None and name_node is not None:
                put(_text(name_node), _text(type_node))
    return types


class _TaintScanner:
    """Forward taint propagation over a tree-sitter parse tree."""

    #: Expression wrappers whose taint is simply their children's taint.
    _TRANSPARENT = frozenset({
        "parenthesized_expression", "ternary_expression",
        "conditional_expression", "await_expression", "cast_expression",
        "binary_expression", "template_string", "array",
        "array_initializer", "sequence_expression", "spread_element",
        "unary_expression", "non_null_expression", "as_expression",
        "interpolated_string_expression",              # C# $"...{x}..."
    })

    def __init__(self, profile: _Profile) -> None:
        self._profile = profile
        self._wrappers: dict = {}
        self._symbols: dict = {}

    def scan(self, root) -> "list[Finding]":
        findings: list = []

        # Stage 4 - declared/inferred receiver types for this file. Built
        # before every pass so the wrapper pre-pass is type-gated too.
        self._symbols = _collect_declared_types(root)

        # Pass 1 - which locally-defined functions forward a parameter into
        # a sink? (one level of interprocedural analysis)
        for node in _preorder(root):
            if node.type in self._profile.function_defs:
                name = _StructuralChecker(self._profile)._function_name(node)
                if name == "<anonymous>":
                    continue
                params = self._parameter_names(node)
                if not params:
                    continue
                bindings = []
                for position, (param, line) in enumerate(params.items()):
                    hits = self._scan_scope(node, {param: line}, collect=None)
                    if hits:
                        bindings.append((position, param, hits[0][0], hits[0][1]))
                if bindings:
                    self._wrappers.setdefault(name, []).extend(bindings)

        # Pass 2a - real taint from real sources, whole file.
        self._scan_scope(root, {}, collect=findings)

        # Pass 2b - framework parameter sources (ASP.NET [FromQuery], Spring
        # @RequestParam ...): each such function is re-scanned in its OWN scope
        # with the annotated parameters pre-tainted, so the value bound to the
        # parameter is tracked to its sink. Per-function scoping avoids a
        # tainted param name bleeding across unrelated functions.
        for node in _preorder(root):
            if node.type in self._profile.function_defs:
                seed = self._annotated_params(node) if self._profile.param_source_annotations else {}
                body = _field(node, "body") or node
                self._scan_scope(body, dict(seed), collect=findings)

        # De-duplicate by (rule, line) - the two-pass fixpoint revisits nodes.
        seen: set = set()
        unique: list = []
        for finding in findings:
            key = (finding.rule_id, finding.line)
            if key not in seen:
                seen.add(key)
                unique.append(finding)
        return unique

    @staticmethod
    def _parameter_names(func_node) -> dict:
        """param name -> definition line, pre-tainted for the wrapper pass."""
        params = _field(func_node, "parameters")
        names: dict = {}
        if params is not None:
            for child in params.named_children:
                if child.type == "identifier":              # JS bare param
                    names[_text(child)] = _line(child)
                    continue
                named = _field(child, "name")               # Java/C# parameter
                if named is not None and named.type == "identifier":
                    names[_text(named)] = _line(named)
                else:                                        # patterns/destructuring
                    for sub in _preorder(child):
                        if sub.type == "identifier":
                            names[_text(sub)] = _line(sub)
                            break
        single = _field(func_node, "parameter")
        if single is not None and single.type == "identifier":
            names[_text(single)] = _line(single)
        return names

    def _annotated_params(self, func_node) -> dict:
        """
        Parameters bound to untrusted input by a framework annotation -
        ``{name: line}`` - e.g. ASP.NET ``[FromQuery] string id`` or Spring
        ``@RequestParam String id``. The bound value is a taint source.
        """
        params = _field(func_node, "parameters")
        out: dict = {}
        if params is None:
            return out
        wanted = self._profile.param_source_annotations
        for child in params.named_children:
            if self._param_annotations(child) & wanted:
                name = _field(child, "name")
                if name is not None and name.type == "identifier":
                    out[_text(name)] = _line(name)
        return out

    def _param_annotations(self, param_node) -> set:
        """Annotation/attribute names declared on one parameter node."""
        types = self._profile.annotation_node_types
        found: set = set()
        if not types:
            return found
        for sub in _preorder(param_node):
            if sub.type in types:
                name = _field(sub, "name")
                if name is not None:
                    found.add(_text(name))
        return found

    # ---- Scope walker ------------------------------------------------------

    def _scan_scope(self, scope, tainted: dict, collect) -> list:
        """
        Forward pass tracking `tainted: name -> origin line`. Branch states
        are joined; actual loops use a bounded fixed point. When `collect` is a list, findings
        are appended; when None, raw sink hits are returned (wrapper pre-pass).
        """
        profile = self._profile
        hits: list = []

        def walk(node):
            # Function bodies are analysed separately, never in their
            # caller's environment. Evaluate expressions before stores.
            if node is not scope and node.type in profile.function_defs:
                return
            if node.type == 'if_statement':
                condition = _field(node, 'condition')
                if condition is not None:
                    walk(condition)
                left, right = dict(tainted), dict(tainted)
                yes = _field(node, 'consequence') or _field(node, 'body')
                no = _field(node, 'alternative')
                if yes is not None:
                    hits.extend(self._scan_scope(yes, left, collect))
                if no is not None:
                    hits.extend(self._scan_scope(no, right, collect))
                tainted.clear()
                tainted.update(right)
                tainted.update(left)
                return
            if node.type in profile.loop_types:
                entry = dict(tainted)
                for _ in range(8):
                    before = dict(tainted)
                    for child in node.named_children:
                        walk(child)
                    tainted.update(entry)
                    if before == tainted:
                        break
                return
            for child in node.named_children:
                walk(child)
                if child.type in _FLOW_TERMINATORS:
                    break
            node_type = node.type
            if node_type == "variable_declarator":
                name_node = _field(node, "name")
                value = self._declarator_value(node, name_node)
                if (name_node is not None and value is not None
                        and name_node.type == "identifier"):
                    origin = self._expr_taint(value, tainted)
                    if origin is not None:
                        tainted[_text(name_node)] = origin
                    else:
                        tainted.pop(_text(name_node), None)
            elif node_type == "assignment_expression":
                hit = self._handle_assignment(node, tainted, collect)
                if hit:
                    hits.append(hit)
            elif node_type == "augmented_assignment_expression":
                left = _field(node, "left")
                right = _field(node, "right")
                if left is not None and left.type == "identifier" and right is not None:
                    origin = self._expr_taint(right, tainted)
                    if origin is not None:      # += only ever ADDS taint
                        tainted[_text(left)] = origin
            elif node_type == profile.call_type:
                hit = self._check_sink(node, tainted, collect)
                if hit:
                    hits.append(hit)
            elif node_type == profile.new_type:
                hit = self._check_new_sink(node, tainted, collect)
                if hit:
                    hits.append(hit)
            elif node_type == "jsx_attribute" and profile.jsx_sink_attrs:
                hit = self._check_jsx_sink(node, tainted, collect)
                if hit:
                    hits.append(hit)
        walk(scope)
        return hits

    def _check_jsx_sink(self, attr, tainted: dict, collect):
        """React dangerouslySetInnerHTML={{__html: tainted}} - XSS sink."""
        kids = attr.named_children
        if not kids or kids[0].type != "property_identifier":
            return None
        if _text(kids[0]) not in self._profile.jsx_sink_attrs:
            return None
        # Any tainted value anywhere in the attribute's expression is unsafe.
        for sub in _preorder(attr):
            if sub.type == "identifier" or sub.type in self._profile.member_types:
                origin = self._expr_taint(sub, tainted)
                if origin is not None:
                    rule, severity, label, cwe = _XSS
                    if collect is not None:
                        collect.append(self._finding(
                            rule, severity, label, cwe, _line(attr), origin,
                            f"{_text(kids[0])}"))
                    return (_line(attr), label)
        return None

    def _declarator_value(self, node, name_node):
        """A declarator's initializer expression, or None."""
        field = self._profile.declarator_value_field
        if field:
            return _field(node, field)                     # JS / Java `value`
        # C#: the initializer is the last named child after the name.
        kids = node.named_children
        if kids and kids[-1] is not name_node:
            return kids[-1]
        return None

    def _handle_assignment(self, node, tainted: dict, collect):
        left = _field(node, "left")
        right = _field(node, "right")
        if left is None or right is None:
            return None
        origin = self._expr_taint(right, tainted)

        if left.type == "identifier":
            if origin is not None:
                tainted[_text(left)] = origin
            else:
                tainted.pop(_text(left), None)
            return None

        # Property sink: `el.innerHTML = tainted` (XSS), `searcher.Filter =
        # tainted` (LDAP), `psi.Arguments = tainted` (command injection).
        if (origin is not None and left.type in self._profile.member_types
                and self._profile.sink_assign_props):
            prop = _field(left, self._profile.member_property_field)
            sink = (self._profile.sink_assign_props.get(_text(prop))
                    if prop is not None else None)
            if sink is not None and not self._assign_receiver_implausible(
                    left, _text(prop)):
                rule, severity, label, cwe = sink
                if collect is not None:
                    collect.append(self._finding(
                        rule, severity, label, cwe, _line(node), origin,
                        f"{_text(prop)} assignment"))
                return (_line(node), label)
        return None

    def _assign_receiver_implausible(self, member, prop: str) -> bool:
        """
        Property-sink twin of `_receiver_type_implausible`: suppress only when
        the assigned-to object's declared type is KNOWN and matches none of the
        plausible types for that property. Keeps generic names like `Filter`
        (DirectorySearcher vs OpenFileDialog) from firing on the wrong type.
        """
        plausible = self._profile.sink_receiver_types.get(prop)
        if not plausible:
            return False
        receiver = _field(member, self._profile.member_object_field)
        if receiver is None or receiver.type != "identifier":
            return False
        declared = self._symbols.get(_text(receiver))
        if not declared:
            return False
        lowered = declared.lower()
        return not any(token in lowered for token in plausible)

    # ---- Expression taint ----------------------------------------------------

    def _expr_taint(self, node, tainted: dict):
        """Return the source line this expression's taint originates from."""
        profile = self._profile
        node_type = node.type

        if node_type == "identifier":
            return tainted.get(_text(node))

        if node_type in profile.member_types:
            dotted = _text(node)
            for prefix in profile.source_prefixes:
                if dotted == prefix or dotted.startswith(prefix + ".") \
                        or dotted.startswith(prefix + "["):
                    return _line(node)
            inner = _field(node, profile.member_object_field)
            if inner is None and node.named_children:
                inner = node.named_children[0]
            return self._expr_taint(inner, tainted) if inner is not None else None

        if node_type == profile.call_type:
            name = _call_name(node, profile)
            if name in profile.sanitizers:
                return None
            if name in profile.source_calls:
                return _line(node)
            # format()/concat()/join() etc. propagate their inputs' taint.
            for arg in _call_args(node, profile):
                origin = self._expr_taint(arg, tainted)
                if origin is not None:
                    return origin
            receiver = _call_receiver(node, profile)
            if receiver is not None:
                return self._expr_taint(receiver, tainted)
            return None

        if node_type in profile.interpolation_types:
            for child in node.named_children:
                origin = self._expr_taint(child, tainted)
                if origin is not None:
                    return origin
            return None

        if node_type in self._TRANSPARENT:
            for child in node.named_children:
                origin = self._expr_taint(child, tainted)
                if origin is not None:
                    return origin
        return None

    # ---- Sink detection --------------------------------------------------------

    def _check_sink(self, call, tainted: dict, collect):
        profile = self._profile
        name = _call_name(call, profile)
        args = _call_args(call, profile)
        if profile.language_id == 'csharp' and name in profile.sink_calls:
            first = _parameter_arg(call, profile, 0, {'sql'})
        else:
            first = args[0] if args else None
        first_taint = self._expr_taint(first, tainted) if first is not None else None

        # Receiver-gated sinks - generic method names (write/Write/Start) that
        # are only dangerous on a specific receiver (document.write XSS,
        # Response.Write XSS, Process.Start command exec). Gating keeps them
        # precise instead of firing on every write()/Start().
        if name in profile.receiver_gated_calls and first_taint is not None:
            want_receiver, (rule, severity, label, cwe) = \
                profile.receiver_gated_calls[name]
            receiver = _call_receiver(call, profile)
            if (receiver is not None
                    and _text(receiver).split(".")[-1] == want_receiver):
                if collect is not None:
                    collect.append(self._finding(
                        rule, severity, label, cwe, _line(call), first_taint,
                        f"{want_receiver}.{name}()"))
                return (_line(call), label)

        if name in profile.sink_calls and first_taint is not None:
            if self._receiver_type_implausible(call, name):
                return None     # typed receiver that cannot be this sink
            rule, severity, label, cwe = profile.sink_calls[name]
            if collect is not None:
                collect.append(self._finding(
                    rule, severity, label, cwe, _line(call), first_taint,
                    f"{name}()"))
            return (_line(call), label)

        return self._check_wrapper_call(call, name, tainted, collect)

    def _receiver_type_implausible(self, call, name: str) -> bool:
        """
        True only when the receiver's declared/inferred type is KNOWN and
        matches none of the sink's plausible type substrings - the pure
        false-positive kill. No receiver, an unknown name, or a conflicted
        declaration all return False (the sink fires as before).
        """
        plausible = self._profile.sink_receiver_types.get(name)
        if not plausible:
            return False
        receiver = _call_receiver(call, self._profile)
        if receiver is None or receiver.type != "identifier":
            return False
        declared = self._symbols.get(_text(receiver))
        if not declared:
            return False
        lowered = declared.lower()
        return not any(token in lowered for token in plausible)

    def _check_wrapper_call(self, call, name, tainted: dict, collect):
        # One-level interprocedural: call into a local sink-wrapper function.
        if collect is not None and name in self._wrappers:
            for position, param, sink_line, sink_label in self._wrappers[name]:
                arg = _parameter_arg(call, self._profile, position, {param})
                if arg is None:
                    continue
                origin = self._expr_taint(arg, tainted)
                if origin is not None:
                    collect.append(Finding(
                        tool=TOOL_NAME, rule_id="TAINT-CALL",
                        severity=Severity.HIGH, line=_line(call),
                        category=RiskCategory.INJECTION, cwe="CWE-20",
                        owasp="A03:2021-Injection",
                        message=(
                            f"Tainted data (from line {origin}) is passed to "
                            f"local function '{name}()', which forwards its "
                            f"parameter into a {sink_label} sink "
                            f"(line {sink_line})."
                        ),
                        remediation="Sanitise/validate before the call, or "
                                    "parameterise the sink inside the function "
                                    "so no caller can inject.",
                    ))
                    return (_line(call), "call")
        return None

    def _check_new_sink(self, node, tainted: dict, collect):
        profile = self._profile
        if profile.new_type == "object_creation_expression":   # Java, C#
            type_node = _field(node, "type")
        else:                                                  # JS new X()
            type_node = _field(node, "constructor")
        if type_node is None:
            return None
        type_name = _text(type_node)
        # Match the full type or its last dotted segment
        # (C#: `new System.Diagnostics.Process()` -> "Process").
        match = None
        for candidate in (type_name, type_name.split(".")[-1]):
            if candidate in profile.new_sinks:
                match = candidate
                break
        if match is None:
            return None
        args = _call_args(node, profile)
        # C# constructors take the dangerous value in a specific argument; a
        # tainted connection, encoding, option or LDAP search root is not
        # itself SQL/path/LDAP injection.
        if profile.language_id == 'csharp':
            positions, names = profile.new_sink_args.get(
                match, profile.new_sink_default_args)
            candidates = (_parameter_arg(node, profile, position, names)
                          for position in positions)
            args = [arg for arg in candidates if arg is not None]
        for arg in args:
            origin = self._expr_taint(arg, tainted)
            if origin is not None:
                rule, severity, label, cwe = profile.new_sinks[match]
                if collect is not None:
                    collect.append(self._finding(
                        rule, severity, label, cwe, _line(node), origin,
                        f"new {match}()"))
                return (_line(node), label)
        return None

    def _finding(self, rule: str, severity: Severity, label: str, cwe: str,
                 line: int, origin: int, sink_display: str) -> Finding:
        return Finding(
            tool=TOOL_NAME, rule_id=rule, severity=severity, line=line,
            category=RiskCategory.INJECTION, cwe=cwe,
            owasp=_SINK_OWASP.get(rule, _DEFAULT_SINK_OWASP),
            message=(
                f"User-controlled data (entering at line {origin}) flows "
                f"into {label} via {sink_display} without sanitisation - "
                f"identified by bounded static data-flow analysis; review reachability and validation."
            ),
            remediation=(
                "Break the flow: validate/convert the input at the boundary "
                "(allow-list, numeric parse), and parameterise the sink "
                "(bound SQL parameters, argument arrays, no dynamic code, "
                "textContent instead of innerHTML)."
            ),
        )
