"""
The rule-matching engine.

Applies every applicable rule to a file line-by-line, with:
  * comment awareness - line comments, block comments (`/* ... */`), trailing
    comments, and docstrings are MASKED out of the text that non-secret
    rules see, string-literal aware so a delimiter inside a string never
    opens a phantom comment (secret rules still scan the raw line),
  * inline suppressions (`nosast` / `nosast: RULE-ID, ...`),
  * Shannon-entropy screening for high-entropy embedded secrets.

Pure computation - no I/O beyond the text it is handed - so it can run in
worker processes during parallel scans.
"""

from __future__ import annotations

import math
import re
from bisect import bisect_right

from ..domain.models import Finding, RiskCategory, Severity
from .model import Rule, RuleSet

TOOL_NAME = "sentinel-rules"

#: `# nosast` silences every rule on that line;
#: `# nosast: PY-D002, PERF-L1` silences only the listed rules.
_SUPPRESS_RE = re.compile(r"\bnosast\b(?:[ \t]*:[ \t]*([A-Z0-9]+-[A-Z0-9]+(?:[ \t]*,[ \t]*[A-Z0-9]+-[A-Z0-9]+)*))?", re.IGNORECASE)

#: String literals considered for entropy analysis.
_LITERAL_RE = re.compile(r"""["']([A-Za-z0-9+/_=\-.]{24,})["']""")
_ENTROPY_THRESHOLD = 4.2

#: Quote characters that open a single-line string literal.
_QUOTE_CHARS = "\"'"
_CSHARP_RAW_RE = re.compile(r'\$*("{3,})')


class LineMasker:
    """
    Blanks comment content out of source lines, string-literal aware.

    Per line, a character scan tracks three contexts:

      * **code** - line-comment prefixes and block-comment openers take
        effect; quote characters open a single-line string;
      * **string** - nothing takes effect until the closing quote (with
        backslash escapes), so ``url = "http://x/*"`` never opens a block;
      * **multi-line region** - an open block comment or string span carries
        across lines. Block-comment content is masked (replaced by spaces,
        preserving column positions); string-span content is data and stays
        visible. A string span that OPENS at line start is documentation
        (a Python docstring) and is masked like a comment; one opening
        mid-line (``x = \"\"\"...\"\"\"``) is a value and is left alone.

    Known, accepted imprecision: single-line string state does not carry
    across lines (an unterminated plain string leaves the rest of ITS line
    unmasked-as-string, then resets), and here-string closers are matched
    anywhere on a line rather than only at column 0.
    """

    def __init__(
        self,
        comment_prefixes: tuple = (),
        block_comments: tuple = (),
        string_spans: tuple = (),
        language_id: str = "",
        mask_strings: bool = False,
    ) -> None:
        self._prefixes = tuple(comment_prefixes)
        self._language = language_id
        self._mask_strings = mask_strings
        # Longest delimiter first so `"""` wins over `"`, `@"` over `"`.
        self._openers = sorted(
            [(o, c, True) for o, c in block_comments]
            + [(o, c, False) for o, c in string_spans],
            key=lambda item: -len(item[0]),
        )

    def mask_lines(self, lines: list) -> list:
        """Return a same-length list of lines with comment content blanked."""
        masked = []
        region = None  # (closer, blank_content, verbatim) of an open region
        for raw in lines:
            out, region = self._mask_line(raw, region)
            masked.append(out)
        return masked

    # ---- Internals ----------------------------------------------------------

    def _mask_line(self, raw: str, region) -> tuple:
        chars = list(raw)
        i = 0
        length = len(raw)

        while i < length:
            if region is not None:
                closer, is_comment, verbatim = region
                end = self._region_end(raw, i, closer, verbatim)
                if end < 0:
                    if is_comment:
                        self._blank(chars, i, length)
                    return "".join(chars), region
                stop = end + len(closer)
                if is_comment:
                    self._blank(chars, i, stop)
                region = None
                i = stop
                continue

            opened = self._match_opener(raw, i)
            if opened is not None:
                opener, closer, is_comment = opened
                verbatim = self._language == 'csharp' and opener in ('@"', '$@"', '@$"')
                if not is_comment and self._language == 'python' and raw[:i].strip() == "":
                    is_comment = True        # docstring-style documentation
                is_comment = is_comment or self._mask_strings
                start = i
                end = self._region_end(raw, i + len(opener), closer, verbatim)
                if end < 0:
                    if is_comment:
                        self._blank(chars, start, length)
                    return "".join(chars), (closer, is_comment, verbatim)
                stop = end + len(closer)
                if is_comment:
                    self._blank(chars, start, stop)
                i = stop
                continue

            # A line comment starts at column 0 or after whitespace - a
            # prefix glued to code (";Password=x" in a connection string,
            # "a//b") is data, not a trailing comment.
            if any(raw.startswith(p, i) and self._comment_boundary(raw, i, p)
                   for p in self._prefixes):
                self._blank(chars, i, length)
                break

            if raw[i] in _QUOTE_CHARS:
                stop = self._skip_string(raw, i)
                if self._mask_strings:
                    self._blank(chars, i, stop)
                i = stop
                continue

            i += 1

        return "".join(chars), None

    def _comment_boundary(self, raw: str, i: int, prefix: str) -> bool:
        if self._language in {'shell', 'yaml', 'config', 'dockerfile', 'batch'}:
            return i == 0 or raw[i - 1].isspace()
        return True

    def _match_opener(self, raw: str, i: int):
        if self._language == 'csharp':
            # Raw delimiters can contain any number of quotes >= 3. Dollar
            # prefixes belong to the literal, not to executable source.
            raw_string = _CSHARP_RAW_RE.match(raw, i) if raw[i] in '$"' else None
            if raw_string:
                return raw_string.group(), raw_string.group(1), False
            for opener in ('$@"', '@$"', '@"'):
                if raw.startswith(opener, i):
                    return opener, '"', False
        for opener, closer, is_comment in self._openers:
            if raw.startswith(opener, i):
                return opener, closer, is_comment
        return None

    @staticmethod
    def _region_end(raw: str, start: int, closer: str, verbatim: bool) -> int:
        end = raw.find(closer, start)
        # In C# verbatim strings a doubled quote is data, including across
        # lines. Backslashes never escape the closing quote.
        while verbatim and end >= 0 and raw.startswith('""', end):
            end = raw.find(closer, end + 2)
        return end

    @staticmethod
    def _skip_string(raw: str, i: int) -> int:
        """Return the index just past a single-line string literal."""
        quote = raw[i]
        i += 1
        while i < len(raw):
            if raw[i] == "\\":
                i += 2
                continue
            if raw[i] == quote:
                return i + 1
            i += 1
        return i                     # unterminated: rest of line is string

    @staticmethod
    def _blank(chars: list, start: int, stop: int) -> None:
        for index in range(start, min(stop, len(chars))):
            chars[index] = " "


class RuleEngine:
    """Matches a `RuleSet` against source text for one language."""

    def __init__(self, rule_set: RuleSet) -> None:
        self._rule_set = rule_set

    @property
    def rule_set(self) -> RuleSet:
        return self._rule_set

    def scan(
        self,
        text: str,
        language_id: str,
        comment_prefixes: tuple[str, ...] = (),
        block_comments: tuple[tuple[str, str], ...] = (),
        string_spans: tuple[tuple[str, str], ...] = (),
    ) -> list[Finding]:
        """Return every (unsuppressed, deduplicated) finding for the text."""
        rules = self._rule_set.for_language(language_id)
        lines = text.splitlines()
        visible_lines = LineMasker(
            comment_prefixes, block_comments, string_spans, language_id).mask_lines(lines)
        code_lines = LineMasker(
            comment_prefixes, block_comments, string_spans, language_id, True).mask_lines(lines)
        comment_lines = [''.join(c if c != v else ' ' for c, v in zip(raw, visible))
                         for raw, visible in zip(lines, visible_lines)]
        findings: list[Finding] = []

        starts = []
        offset = 0
        for raw in lines:
            starts.append(offset)
            offset += len(raw) + 1
        for rule in rules:
            targets = (comment_lines if rule.match_scope == 'comments' else
                       lines if rule.check_comments else visible_lines)
            if rule.multiline:
                subjects = [(0, '\n'.join(targets))]
            else:
                subjects = enumerate(targets)
            for index, target in subjects:
                for match in rule.pattern.finditer(target):
                    anchor = match.start() + len(match.group()) - len(match.group().lstrip())
                    row = bisect_right(starts, anchor) - 1 if rule.multiline else index
                    column = anchor - starts[row] if rule.multiline else anchor
                    if row < 0 or row >= len(lines):
                        continue
                    if rule.match_scope == 'code' and (column >= len(code_lines[row]) or
                            code_lines[row][column].isspace()):
                        continue
                    findings.append(self._finding(rule, row + 1, lines[row]))

        for line_no, raw in enumerate(lines, start=1):
            entropy = (self._entropy_secret(raw)
                       if 'SEC-ENTROPY' not in self._rule_set.disabled_ids else None)
            if entropy is not None:
                findings.append(Finding(
                    tool=TOOL_NAME,
                    rule_id="SEC-ENTROPY",
                    severity=Severity.MEDIUM,
                    line=line_no,
                    category=RiskCategory.SECRETS,
                    cwe="CWE-798",
                    owasp="A07:2021",
                    confidence="MEDIUM",
                    snippet=raw.strip()[:200],
                    message=(
                        f"High-entropy string literal ({entropy:.1f} bits/char) - "
                        f"statistically resembles a random secret, token, or key "
                        f"rather than human-written text."
                    ),
                    remediation=(
                        "If this is a credential/token, revoke and rotate it, then "
                        "load it from a secrets store at runtime. If it is inert "
                        "data (e.g. a test fixture hash), document that in a "
                        "nearby comment or suppress with 'nosast: SEC-ENTROPY'."
                    ),
                ))

        findings = self._apply_suppressions(findings, comment_lines)
        return self._dedupe(findings)

    # ---- Internals ---------------------------------------------------------

    @staticmethod
    def _finding(rule: Rule, line_no: int, raw: str) -> Finding:
        return Finding(
            tool=TOOL_NAME,
            rule_id=rule.id,
            severity=rule.severity,
            line=line_no,
            message=rule.message,
            category=rule.category,
            cwe=rule.cwe,
            owasp=rule.owasp,
            remediation=rule.remediation,
            confidence=rule.confidence,
            snippet=raw.strip()[:200],
        )

    @staticmethod
    def _apply_suppressions(findings: list[Finding], lines: list[str]) -> list[Finding]:
        kept: list[Finding] = []
        for finding in findings:
            line_text = lines[finding.line - 1] if 0 < finding.line <= len(lines) else ""
            match = _SUPPRESS_RE.search(line_text)
            if match:
                listed = match.group(1)
                if not listed and line_text[match.end():].lstrip().startswith(':'):
                    kept.append(finding)
                    continue
                if not listed or finding.rule_id.upper() in {
                    item.strip().upper() for item in listed.split(",")
                }:
                    continue  # explicitly waived by the developer
            kept.append(finding)
        return kept

    def apply_policy(self, findings: list[Finding], text: str, spec) -> list[Finding]:
        """Apply the same profile and comment-only waivers to every analyzer."""
        lines = text.splitlines()
        visible = LineMasker(spec.comment_prefixes, spec.block_comments,
                             spec.string_spans, spec.id).mask_lines(lines)
        comments = [''.join(c if c != v else ' ' for c, v in zip(raw, masked))
                    for raw, masked in zip(lines, visible)]
        disabled = self._rule_set.disabled_ids | {
            r.id for r in [*self._rule_set.rules, *self._rule_set.query_rules] if not r.enabled}
        return self._dedupe(self._apply_suppressions(
            [f for f in findings if f.rule_id not in disabled], comments))

    @staticmethod
    def _dedupe(findings: list[Finding]) -> list[Finding]:
        """Collapse identical (rule, line) hits from overlapping patterns."""
        seen: set[tuple[str, int]] = set()
        unique: list[Finding] = []
        for finding in findings:
            key = (finding.rule_id, finding.line)
            if key not in seen:
                seen.add(key)
                unique.append(finding)
        return unique

    @staticmethod
    def _entropy_secret(line: str) -> float | None:
        """
        Shannon-entropy screen for embedded secrets (the trufflehog
        technique): random keys/tokens carry far more information per
        character than identifiers, paths, or prose.
        """
        # Entropy alone also describes hashes, asset IDs and test data.
        # Require a credential-bearing key; provider-format rules remain
        # responsible for recognizable credentials anywhere in the source.
        if not re.search(r'\b[\w-]*(?:password|passwd|secret|token|api[_-]?key|access[_-]?key)[\w-]*[\"\']?\s*[:=]', line, re.I):
            return None
        for match in _LITERAL_RE.finditer(line):
            candidate = match.group(1)
            # Structured text (paths, URLs, dotted names) is not a secret.
            if candidate.count(".") > 2 or candidate.count("/") > 2:
                continue
            classes = sum((
                any(c.islower() for c in candidate),
                any(c.isupper() for c in candidate),
                any(c.isdigit() for c in candidate),
            ))
            if classes < 3:
                continue
            counts: dict[str, int] = {}
            for char in candidate:
                counts[char] = counts.get(char, 0) + 1
            entropy = -sum(
                (n / len(candidate)) * math.log2(n / len(candidate))
                for n in counts.values()
            )
            if entropy >= _ENTROPY_THRESHOLD:
                return entropy
        return None
