"""Rule definitions: the unit of knowledge in the platform."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field

from ..domain.models import RiskCategory, Severity


@dataclass(frozen=True)
class Rule:
    """
    One detection rule, loaded from a JSON rule pack.

    Rules are language-scoped ("python") or universal ("*"). The compiled
    pattern is matched per line unless explicitly marked multiline. Semantic
    and data-flow checks live in dedicated analyzers.
    """

    id: str
    title: str
    severity: Severity
    category: str
    pattern: re.Pattern[str]
    message: str
    remediation: str = ""
    #: Language ids this rule applies to; ("*",) means every language.
    languages: tuple[str, ...] = ("*",)
    cwe: str = ""
    owasp: str = ""
    confidence: str = "HIGH"
    #: Secrets are worth flagging even inside comments; most rules are not.
    check_comments: bool = False
    enabled: bool = True
    tags: tuple[str, ...] = ()
    references: tuple[str, ...] = ()
    #: Match across line breaks only for explicitly reviewed bounded patterns.
    multiline: bool = False
    #: code requires the first matched token to occur outside a string literal.
    match_scope: str = "source"

    @classmethod
    def from_dict(cls, data: dict, languages: tuple[str, ...]) -> "Rule":
        """Build a rule from one JSON pack entry, validating required keys."""
        missing = [key for key in ("id", "severity", "pattern", "message") if key not in data]
        if missing:
            raise ValueError(
                f"Rule entry {data.get('id', '<no id>')!r} is missing "
                f"required key(s): {', '.join(missing)}"
            )
        _validate_metadata(data)
        flags = re.IGNORECASE if data.get("ignore_case", True) else 0
        if data.get("multiline", False):
            flags |= re.MULTILINE
        try:
            pattern = re.compile(data["pattern"], flags)
        except re.error as exc:
            raise ValueError(f"Rule {data['id']!r} has an invalid pattern: {exc}") from exc

        return cls(
            id=str(data["id"]),
            title=str(data.get("title", data["id"])),
            severity=Severity(str(data["severity"]).upper()),
            category=str(data.get("category", RiskCategory.GENERAL)),
            pattern=pattern,
            message=str(data["message"]),
            remediation=str(data.get("remediation", "")),
            languages=_rule_languages(data, languages),
            cwe=str(data.get("cwe", "")),
            owasp=str(data.get("owasp", "")),
            confidence=str(data.get("confidence", "HIGH")).upper(),
            check_comments=bool(data.get("check_comments", False)),
            enabled=bool(data.get("enabled", True)),
            tags=tuple(data.get("tags", ())),
            references=tuple(data.get("references", ())),
            multiline=bool(data.get("multiline", False)),
            match_scope=data.get("match_scope", "source"),
        )


@dataclass(frozen=True)
class QueryRule:
    """
    A parse-tree rule: a tree-sitter S-expression query matched against the
    file's real syntax tree instead of a line regex. Runs only for languages
    with an installed grammar; a file without one keeps its regex coverage.

    The finding anchors on the node bound to `capture` (default "finding").
    Query text is validated lazily at compile time - a malformed query is
    reported as incomplete analysis while other rules continue.
    """

    id: str
    title: str
    severity: Severity
    category: str
    query: str
    message: str
    remediation: str = ""
    languages: tuple[str, ...] = ()
    capture: str = "finding"
    cwe: str = ""
    owasp: str = ""
    confidence: str = "HIGH"
    enabled: bool = True
    tags: tuple[str, ...] = ()
    references: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, data: dict, languages: tuple[str, ...]) -> "QueryRule":
        missing = [key for key in ("id", "severity", "query", "message") if key not in data]
        if missing:
            raise ValueError(
                f"Query rule {data.get('id', '<no id>')!r} is missing "
                f"required key(s): {', '.join(missing)}"
            )
        _validate_metadata(data)
        rule_languages = _rule_languages(data, languages)
        return cls(
            id=str(data["id"]),
            title=str(data.get("title", data["id"])),
            severity=Severity(str(data["severity"]).upper()),
            category=str(data.get("category", RiskCategory.GENERAL)),
            query=str(data["query"]),
            message=str(data["message"]),
            remediation=str(data.get("remediation", "")),
            languages=rule_languages,
            capture=str(data.get("capture", "finding")),
            cwe=str(data.get("cwe", "")),
            owasp=str(data.get("owasp", "")),
            confidence=str(data.get("confidence", "HIGH")).upper(),
            enabled=bool(data.get("enabled", True)),
            tags=tuple(data.get("tags", ())),
            references=tuple(data.get("references", ())),
        )


@dataclass
class RuleSet:
    """Every loaded rule, indexed by language, with profile overrides applied."""

    rules: list[Rule] = field(default_factory=list)
    query_rules: list[QueryRule] = field(default_factory=list)
    disabled_ids: frozenset[str] = frozenset()
    load_errors: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        self._by_language: dict[str, list[Rule]] = {}
        self._universal: list[Rule] = []
        for rule in self.rules:
            if "*" in rule.languages:
                self._universal.append(rule)
                continue
            for language_id in rule.languages:
                self._by_language.setdefault(language_id, []).append(rule)
        self._queries_by_language: dict[str, list[QueryRule]] = {}
        for query_rule in self.query_rules:
            for language_id in query_rule.languages:
                self._queries_by_language.setdefault(
                    language_id, []).append(query_rule)

    def for_language(self, language_id: str) -> list[Rule]:
        """Enabled rules that apply to one language (universal rules included)."""
        candidates = self._by_language.get(language_id, []) + self._universal
        return [rule for rule in candidates if rule.enabled]

    def queries_for_language(self, language_id: str) -> list[QueryRule]:
        """Enabled parse-tree query rules for one language."""
        return [rule for rule in self._queries_by_language.get(language_id, [])
                if rule.enabled]

    def all_rules(self) -> list[Rule]:
        return list(self.rules)

    def all_query_rules(self) -> list[QueryRule]:
        return list(self.query_rules)

    def get(self, rule_id: str) -> Rule | None:
        for rule in self.rules:
            if rule.id == rule_id:
                return rule
        return None

    def content_hash(self) -> str:
        """
        Stable digest of every enabled rule - part of the incremental-cache
        key so editing/toggling rules invalidates cached results.
        """
        from dataclasses import fields
        entries = []
        for rule in sorted([*self.rules, *self.query_rules], key=lambda r: r.id):
            entry = {f.name: getattr(rule, f.name) for f in fields(rule)}
            if isinstance(rule, Rule):
                entry['pattern'] = (rule.pattern.pattern, rule.pattern.flags)
            entries.append(entry)
        payload = json.dumps([entries, sorted(self.disabled_ids), self.load_errors], sort_keys=True)
        return hashlib.sha256(payload.encode('utf-8')).hexdigest()[:16]


def _rule_languages(data: dict, defaults: tuple[str, ...]) -> tuple[str, ...]:
    declared = data.get('languages', defaults)
    if not isinstance(declared, (list, tuple)) or not declared or any(
            not isinstance(item, str) or not item.strip() for item in declared):
        raise ValueError('languages must be a non-empty array of language IDs')
    return tuple(declared)


def _validate_metadata(data: dict) -> None:
    for key in ('message', 'pattern' if 'pattern' in data else 'query'):
        if not isinstance(data.get(key), str) or not data[key].strip():
            raise ValueError(f'{key} must be a non-empty string')
    if 'pattern' in data and 'query' in data:
        raise ValueError('a rule must declare either pattern or query, not both')
    for key in ('tags', 'references'):
        if key in data and (not isinstance(data[key], (list, tuple)) or any(
                not isinstance(item, str) or not item.strip() for item in data[key])):
            raise ValueError(f'{key} must be an array of non-empty strings')
    if 'capture' in data and (not isinstance(data['capture'], str) or not data['capture'].strip()):
        raise ValueError('capture must be a non-empty string')
    if not re.fullmatch(r'[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+', str(data.get('id', ''))):
        raise ValueError('id must be an uppercase, hyphen-separated rule ID')
    if str(data.get('severity', '')).upper() not in Severity._value2member_map_:
        raise ValueError('unknown severity; expected BLOCKER/CRITICAL/HIGH/MEDIUM/LOW/INFO')
    if str(data.get('confidence', 'HIGH')).upper() not in {'HIGH', 'MEDIUM', 'LOW'}:
        raise ValueError('unknown confidence; expected HIGH/MEDIUM/LOW')
    categories = {v for k, v in vars(RiskCategory).items() if k.isupper() and isinstance(v, str)}
    if data.get('category', RiskCategory.GENERAL) not in categories:
        raise ValueError('unknown category')
    if data.get('match_scope', 'source') not in {'source', 'code', 'comments'}:
        raise ValueError('match_scope must be source, code, or comments')
    for key in ('enabled', 'check_comments', 'ignore_case', 'multiline'):
        if key in data and not isinstance(data[key], bool):
            raise ValueError(f'{key} must be a boolean')
