"""
Rule pack loader.

Rule packs are JSON documents: `{"language": "<id>|*", "rules": [...]}`.
Built-in packs ship in `codesentinel/rules/packs/`; administrators can add
or override rules by dropping packs into the user rules directory, and
individual rules can be disabled persistently via the settings store.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Iterable

from .model import QueryRule, Rule, RuleSet

logger = logging.getLogger(__name__)

BUILTIN_PACK_DIR = Path(__file__).resolve().parent / "packs"


class RulePackError(ValueError):
    """A rule pack file could not be parsed or validated."""


def load_pack(path: Path) -> tuple[list[Rule], list[QueryRule]]:
    """
    Load one JSON rule pack, raising `RulePackError` on any defect.

    An entry with a `"query"` key is a parse-tree query rule; one with a
    `"pattern"` key is a line-regex rule. Returns both lists.
    """
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RulePackError(f"Cannot read rule pack {path.name}: {exc}") from exc

    if not isinstance(payload, dict) or not isinstance(payload.get("rules"), list):
        raise RulePackError(
            f"Rule pack {path.name} must be an object with a 'rules' array."
        )

    declared = payload.get("languages", payload.get("language", "*"))
    if isinstance(declared, str):
        declared = [declared]
    if not isinstance(declared, list) or not declared or any(
            not isinstance(item, str) or not item.strip() for item in declared):
        raise RulePackError(f'{path.name}: languages must contain non-empty language IDs')
    languages = tuple(declared)
    rules: list[Rule] = []
    query_rules: list[QueryRule] = []
    seen_ids = set()
    for index, entry in enumerate(payload["rules"]):
        try:
            if not isinstance(entry, dict):
                raise ValueError('rule entry must be an object')
            if str(entry.get('id')) in seen_ids:
                raise ValueError(f"duplicate rule ID: {entry.get('id')}")
            seen_ids.add(str(entry.get('id')))
            if isinstance(entry, dict) and "query" in entry:
                query_rules.append(QueryRule.from_dict(entry, languages))
            else:
                rules.append(Rule.from_dict(entry, languages))
        except (ValueError, TypeError, KeyError) as exc:
            raise RulePackError(f"{path.name} rule #{index + 1}: {exc}") from exc
    return rules, query_rules


def load_rule_set(
    extra_dirs: Iterable[Path] = (),
    disabled_rule_ids: Iterable[str] = (),
) -> RuleSet:
    """
    Load built-in packs plus any packs found in `extra_dirs`.

    Later packs override earlier rules with the same id, so a user pack can
    re-tune a built-in rule. `disabled_rule_ids` applies the persisted
    enable/disable profile on top.
    """
    by_id: dict[str, Rule] = {}
    queries_by_id: dict[str, QueryRule] = {}
    directories = [BUILTIN_PACK_DIR, *extra_dirs]
    errors = []

    for directory in directories:
        if not directory.is_dir():
            continue
        for pack_path in sorted(directory.glob("*.json")):
            try:
                rules, query_rules = load_pack(pack_path)
                for rule in rules:
                    by_id[rule.id] = rule
                for query_rule in query_rules:
                    queries_by_id[query_rule.id] = query_rule
            except RulePackError as exc:
                # A malformed user pack must never take the scanner down.
                logger.error("Skipping rule pack: %s", exc)
                errors.append(str(exc))

    disabled = {rule_id.strip() for rule_id in disabled_rule_ids}
    rules = [
        _with_enabled(rule, False) if rule.id in disabled else rule
        for rule in by_id.values()
    ]
    query_rules = [
        _with_enabled(rule, False) if rule.id in disabled else rule
        for rule in queries_by_id.values()
    ]
    return RuleSet(rules=sorted(rules, key=lambda r: r.id),
                   query_rules=sorted(query_rules, key=lambda r: r.id),
                   disabled_ids=frozenset(disabled), load_errors=tuple(errors))


def _with_enabled(rule: Rule, enabled: bool) -> Rule:
    """Return a copy of a frozen rule with `enabled` replaced."""
    from dataclasses import replace

    return replace(rule, enabled=enabled)
