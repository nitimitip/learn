# Code Sentinel rule policy — version 3.1

Reviewed 12–13 September 2026; .NET coverage pass 21 September 2026. This is the built-in pack directory.
Administrator overrides belong in CODESENTINEL_HOME/rules. Later packs
can override matching IDs. The earlier policy is preserved in the review baseline.

## Scope and evidence

Recognizing a language does not imply equivalent analysis depth. Python has
native AST and bounded taint analysis; JavaScript, TypeScript, Java and C# have
optional syntax and bounded in-file taint analysis. Go, Rust, Kotlin and Swift
have optional syntax-query checks. Other profiles use patterns and, where
implemented, specialist statement/template checks. See
artifacts/code-sentinel-review/REVIEW.md in the project root for the assessment.

No rule count, quality score, CWE reference or regression pass rate establishes
SonarQube/Veracode parity or OWASP/CERT/ASVS compliance.

## Authoring

- One stable uppercase, hyphen-separated ID must have one meaning across
  pattern and parser implementations. Match their taxonomy and remediation.
- Declare rule-level languages when narrower than the pack. Reserve universal
  rules for shared evidence such as recognizable credential formats.
- Required fields: id, severity, pattern (or query), message. Built-ins must
  also have useful titles, categories, confidence and remediation.
- Severities: BLOCKER, CRITICAL, HIGH, MEDIUM, LOW, INFO. Confidence: HIGH,
  MEDIUM, LOW. Severity describes potential impact; confidence describes the
  evidence. Neither proves exploitation. Categories use RiskCategory constants.
- match_scope=code requires the first matched token outside a string/comment.
  source retains literal evidence but normally masks comments. comments targets
  documentation markers and compiler-suppression comments. This is lexical
  filtering, not a complete language lexer.
- check_comments=true is appropriate for credential evidence, not executable
  API checks. Set ignore_case according to the language and API.
- multiline=true explicitly permits cross-line matching and multiline anchors;
  it does not enable DOTALL. Prefer syntax queries to complex regexes. Review
  worst-case runtime and add safe, unsafe, multiline, comment and string cases.
- Parser/query failures and invalid packs must surface as incomplete analysis.
  Missing optional grammars remain visible as reduced analysis depth.

## Findings and waivers

A variable URL, unsafe block, pseudorandom API, inline template or initialized
empty password is review evidence, not automatically a vulnerability. Do not
label public key identifiers as leaked authentication secrets. Give conditional
remediation when a finding depends on context.

Use an actual language comment containing nosast: RULE-ID for a same-line
waiver. A bare nosast waives every finding on that line; use it sparingly.
Text inside a string is not a waiver. Profiles and waivers apply to pattern,
AST, query and taint findings. Waiving a parser finding does not remove its
analysis-error evidence. Persisted reviewer triage is a separate mechanism.

## Compatibility

Go defer uses QRY-GO001, avoiding the URL review rule GO-P001. Kotlin query IDs
now agree with pattern IDs. Swift forced-cast syntax uses QRY-SW001. Rust
unsafe syntax uses RS-U001. Python swallowed exceptions use PY-Q001, bare
except uses PY-Q006, and credential logging retains PY-Q002.

Old ambiguous triage cannot be migrated reliably by ID alone. Review affected
waivers and run a fresh scan. The engine cache version is bumped; every rule
field and regex flag participates in invalidation. Project-wide findings are
recomputed outside the per-file cache.

## .NET coverage pass (21 September 2026)

Rules tagged `dotnet-coverage-2026-09` extend the C#/.NET profile. Each has a
safe/unsafe fixture pair in tests/fixtures/code_sentinel_dotnet_rules.json.

- csharp.json adds injection families the pattern packs did not reach (LDAP
  filters, XPath expressions, Zip Slip extraction, process argument strings,
  BSON filter parsing), run-time type/assembly loading, key-derivation and RSA
  padding strength, certificate password and revocation handling, Data
  Protection key storage, Identity password policy, SameSite, the
  trust-boundary assembly attributes, model over-posting and regex timeouts.
- dotnet_config.json covers deployed ASP.NET/IIS/MSBuild configuration:
  trace output, cookieless and non-regenerated sessions, forms-ticket
  protection, header checking, directory browsing, detailed IIS errors,
  inline impersonation credentials, legacy request validation, ASP.NET Core
  DetailedErrors and disabled analysis modes. Checks already in xml.json
  (compilation debug, customErrors, requireSSL, httpOnlyCookies,
  validateRequest, enableViewStateMac, machineKey, enableEventValidation) are
  not duplicated.
- csharp_queries.json adds parse-tree quality rules that regexes cannot state
  precisely: self-assignment, identical conditional branches, self-comparison
  and locking on an interned string literal.
- razor.json adds unencoded output and script-context interpolation.

The C# taint profile gained SSRF, LDAP, XPath and reflection sinks, property
sinks (`Filter`, `Arguments`, `CommandText`, `InnerHtml`) and per-constructor
argument selection. Generic method and property names are gated on the
receiver's declared type, so an unrelated `Filter` or `GetAsync` is suppressed.
SSRF, path and reflection findings carry their own OWASP category rather than
A03.

Scope unchanged by this pass: there is still no Roslyn semantic model, no
overload resolution across assemblies, and no VB.NET profile. A recognized
extension is not evidence of complete language support.

## Validation

Run python artifacts/code-sentinel-review/test_review.py from the project root,
and python -m unittest discover -s tests -p test_code_sentinel_dotnet.py for
the .NET suite.
The review loads isolated parser packages from its test-deps directory; these
are not installed into the web host. Set CODE_SENTINEL_NO_PARSERS=1 to test
fallback mode. Use the pinned requirements for deployment parser support.

Independent labeled applications and comparison-tool runs are required before
making effectiveness claims. These regression fixtures are not an independent
security benchmark.
