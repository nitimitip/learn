import os
import logging
import sqlite3
from sqlalchemy import create_engine, event
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

logger = logging.getLogger(__name__)

# Database configuration.
# Override with the DATABASE_URL env var in production. SQLite is kept as
# the default only so a fresh checkout runs without setup.
#
# IMPORTANT (production / Windows service):
#   SQLite serialises ALL writes behind a single database-level lock. With
#   the health-check Windows service sweeping every minute AND IIS workers
#   writing user/session data to the same file, concurrent writers will
#   hit "database is locked" errors. The busy_timeout pragma below makes
#   writers WAIT instead of failing instantly, and WAL mode lets readers
#   run concurrently with a writer - but this is still a stopgap. For a
#   real multi-process deployment, point DATABASE_URL at PostgreSQL or
#   MSSQL (e.g. mssql+pyodbc://... - you already have an MSSQL driver
#   installed for the database monitors).
DATABASE_URL = os.environ.get('DATABASE_URL', 'sqlite:///project_management.db')

# How long a blocked SQLite writer waits for the lock before giving up (ms).
_SQLITE_BUSY_TIMEOUT_MS = int(os.environ.get('SQLITE_BUSY_TIMEOUT_MS', '30000'))

# Connection-pool bounds (relational servers only; SQLite ignores these).
_POOL_SIZE     = int(os.environ.get('DB_POOL_SIZE',     '10'))
_POOL_OVERFLOW = int(os.environ.get('DB_POOL_OVERFLOW', '20'))


if DATABASE_URL.startswith('postgresql') or DATABASE_URL.startswith('mssql'):
    # Bounded pool so a burst of concurrent requests / sweeps cannot open
    # an unlimited number of server connections. pool_pre_ping discards
    # stale connections (e.g. after the DB server restarts); pool_recycle
    # forces a refresh before most server-side idle timeouts kick in.
    _connect_args = {}
    if DATABASE_URL.startswith('postgresql'):
        _connect_args = {"sslmode": "prefer"}
    _engine_kwargs = dict(
        echo=False,
        pool_pre_ping=True,
        pool_recycle=300,
        pool_size=_POOL_SIZE,
        max_overflow=_POOL_OVERFLOW,
        pool_timeout=30,
        connect_args=_connect_args,
    )
    if DATABASE_URL.startswith('mssql'):
        # fast_executemany dramatically speeds up batched INSERTs through
        # pyodbc. Safe to leave on for normal operation.
        _engine_kwargs["fast_executemany"] = True
    engine = create_engine(DATABASE_URL, **_engine_kwargs)
else:
    # SQLite - `check_same_thread=False` is required because APScheduler's
    # background thread (and the Windows service) use the same engine.
    # A longer `timeout` here is the Python-side equivalent of the
    # busy_timeout pragma and covers connection acquisition too.
    engine = create_engine(
        DATABASE_URL,
        echo=False,
        connect_args={
            "check_same_thread": False,
            "timeout": _SQLITE_BUSY_TIMEOUT_MS / 1000.0,
        },
    )

    # Apply per-connection SQLite pragmas every time a raw connection is
    # opened. SQLAlchemy does not persist pragmas across pooled
    # connections, so this event hook is the correct place.
    @event.listens_for(engine, "connect")
    def _set_sqlite_pragmas(dbapi_connection, _connection_record):
        cursor = dbapi_connection.cursor()
        try:
            # WAL - readers don't block the single writer and vice-versa.
            cursor.execute("PRAGMA journal_mode=WAL")
            # Wait up to N ms for a lock rather than erroring immediately.
            cursor.execute(f"PRAGMA busy_timeout={_SQLITE_BUSY_TIMEOUT_MS}")
            # Enforce ON DELETE CASCADE - SQLite ignores FK actions unless
            # this is switched on per-connection. The health-check models
            # rely on it.
            cursor.execute("PRAGMA foreign_keys=ON")
            # NORMAL is the recommended durability/speed balance under WAL.
            cursor.execute("PRAGMA synchronous=NORMAL")
        finally:
            cursor.close()


# Create session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create base class
Base = declarative_base()


def init_db() -> None:
    """
    Initialize database - create any missing tables.

    IMPORTANT: This function deliberately does NOT drop existing tables on
    error. The previous implementation dropped EVERY table in the database
    if create_all() failed for any reason - that included MIMP reports,
    application status history, AND APScheduler's persisted jobs. A single
    transient error during startup could silently destroy production data.

    If you genuinely need to wipe and recreate (during development), call
    `recreate_all_tables_DESTRUCTIVE()` explicitly. The capital letters in
    the name are a deterrent.
    """
    # Import models so SQLAlchemy registers them on Base.metadata.
    from models import User
    from modules.project_management.models import (
        Project, ProjectStakeholder, ProjectStatusRecipient,
        ProjectMilestone, ProjectTeamMember,
        ProjectTask, TaskDependency, TaskNote, ProjectActivity,
        ProjectRiskLog, ProjectIssue, ProjectDocument,
        ProjectBaseline, BaselineMilestone, BaselineTask,
        GoLivePlan, GoLiveTask, GoLiveConnectivity, GoLiveContact,
        HLDTemplateSection, HLDTemplateColumn,
        ProjectHLD, ProjectHLDSection, ProjectHLDRow,
        EffortResourceDefault,
        SDLCPhaseTemplate, ProjectSDLCPhase, SDLCPhaseMilestone,
    )
    from modules.application_support.models import (
        AppSupportTower, TowerMember, ApplicationCategory,
        ApplicationDetails, ServerDetails, ApplicationAssignment,
        SupportTeam, BusinessUsers, VendorDetails, ExternalInterfaces,
        IndividualJobs, SuiteJobs, FileInventory, ApplicationTask, CriticalIssue,
        SecretVaultEntry, AuditLog, AuditDigestLog,
        TechCatalog, ApplicationTechStack, StandardChecklistItem,
        ApplicationStandardCompliance
    )
    from modules.mimp_report.models import (
        MIMPReport, MIMPApplicationTower, MIMPApplication,
        MIMPApplicationStatus, MIMPSchedulerLock,
    )
    from modules.utility.servers_models import (
        FieldMapping, ServerData, ServerImport, DatabaseReport,
    )
    from modules.file_monitor.models import (
        FileMonitorReport, FileMonitorAlertLog,
        FileMonitorTower, FileMonitorTowerMember,
        DtnFlowMessage, DtnFlowDataItem, DtnFlowCatalogueMeta,
    )
    from modules.application_health_check.models import (
        ApplicationTower, AppTowerMember, HealthCheckReport, URLMonitor,
        ServerMonitor, DatabaseMonitor, EmailNotificationConfig,
        HealthCheckExecution, HealthCheckHistory
    )
    from modules.security.models import (
        SecurityGroupMember, CertificateRecord, CertificateConfig,
        CertificateTeamManager,
    )
    from modules.service_now_analysis.models import (
        ServiceNowGroupMember, GuidePage, GuideDocument, AssignmentGroupContact,
        OpenIncidentEmailSettings, SnowTicketWorkload,
    )
    from modules.todo.models import TodoItem, TodoDigestLog
    from modules.user_profile.models import (
        UserSubGroup, SoftSkill, UserSkill,
    )
    from modules.activity_tracker.models import ActivityEntry
    from modules.resource_utilization.models import (WorkforceHoliday,
                                                     WorkforceSettings)
    from modules.rota.models import (
        RotaAdmin, Rota, RotaMember, RotaShift, RotaAssignment,
        RotaHandover, RotaRequest, RotaAlert, RotaAudit,
    )
    from modules.leave_tracker.models import (
        LeaveRequest, LeaveRequestDate, LeaveSettings,
    )
    from modules.code_sentinel.models import (
        CodeProject, CodeScan, CodeFinding, CodeTriage, CodeApiToken,
    )
    from modules.software_inventory.models import (
        SoftwareGroupMember, SoftwareItem, SoftwareItemTower, SoftwareVersion,
    )
    # Shared version trail for uploaded documents (project docs today; the
    # application-support and ServiceNow-guide files use the same table).
    from file_versions import DocumentVersion

    # Rota: move the previous build's tables aside BEFORE create_all() so the
    # new, smaller ones can be created under the proper names. The rows are
    # carried across by ensure_rota_schema() once the tables exist - the two
    # halves have to straddle create_all(), which is why this one call is up
    # here on its own. Idempotent; see modules/rota/schema.py.
    from modules.rota.schema import retire_legacy_rota_tables
    retire_legacy_rota_tables(engine)

    try:
        Base.metadata.create_all(bind=engine)
        logger.info("Database initialized - tables created or already present.")
    except Exception as e:
        # NEVER drop on failure - that destroys production data including
        # APScheduler jobs and MIMP status history. Just log loudly and
        # let the developer fix the model error.
        logger.error(
            "Database create_all() failed: %s. "
            "Tables were NOT dropped. Investigate the model definition error.",
            e,
            exc_info=True,
        )
        raise

    # ------------------------------------------------------------------
    # Apply indexes that were added to already-existing tables.
    #
    # Base.metadata.create_all() creates a table AND its indexes when the
    # table does not yet exist. But for a table that already exists, it
    # does NOT add newly-declared indexes. After adding the performance
    # indexes to the health-check models, an existing production database
    # would therefore still be missing them.
    #
    # The block below CREATEs each declared index individually, with
    # checkfirst=True, so it is fully idempotent: missing indexes get
    # created, existing ones are skipped, and no data is ever touched.
    # ------------------------------------------------------------------
    try:
        created = 0
        for table in Base.metadata.sorted_tables:
            for index in table.indexes:
                try:
                    index.create(bind=engine, checkfirst=True)
                    created += 1
                except Exception as idx_err:
                    # One bad index must not abort startup - log and move on.
                    logger.warning(
                        "Could not ensure index %s on %s: %s",
                        index.name, table.name, idx_err,
                    )
        logger.info("Index reconciliation complete - %d index(es) ensured.",
                    created)
    except Exception as e:
        # Index reconciliation is best-effort; never fatal.
        logger.warning("Index reconciliation step failed: %s", e, exc_info=True)

    # ------------------------------------------------------------------
    # Lightweight additive column migrations.
    #
    # create_all() never ALTERs an existing table, so columns added to a
    # model after its table already exists in production are silently
    # missing. The block below adds them with `ADD COLUMN`, which every
    # supported backend treats as a safe, non-locking, data-preserving
    # operation. It is fully idempotent: a column that already exists is
    # detected via the inspector and skipped.
    # ------------------------------------------------------------------
    _ensure_columns()
    from modules.application_health_check.schema import ensure_health_schema
    ensure_health_schema(engine)
    # Rota: copy the rotas, members, shifts, assignments, handovers and
    # requests from the retired tables into the new ones. Runs once, on the
    # first boot after the rebuild - see modules/rota/schema.py.
    from modules.rota.schema import ensure_rota_schema
    ensure_rota_schema(engine)



def _ensure_columns(target_engine=None) -> None:
    """
    Add columns that were introduced after their table already existed.

    Dialect-aware: SQL Server uses ``ALTER TABLE ... ADD`` (no COLUMN keyword)
    and ``BIT`` instead of ``BOOLEAN``; SQLite/PostgreSQL use
    ``ALTER TABLE ... ADD COLUMN`` and accept ``BOOLEAN``.

    ``target_engine`` defaults to the app's own engine; the SQLite->MSSQL
    migration script passes the TARGET engine so a pre-existing SQL Server
    schema gains the same additive columns before rows are copied.
    """
    from sqlalchemy import inspect, text

    engine = target_engine if target_engine is not None else globals()['engine']
    dialect = engine.dialect.name.lower()
    is_mssql = dialect in ('mssql', 'pyodbc')

    # Portable column spec: (table, column, generic_type, not_null, default_literal)
    #   generic_type    - 'DATE' | 'BOOLEAN' | 'INTEGER' | 'VARCHAR(n)'
    #   not_null        - bool
    #   default_literal - None | '0' | '1' | ...  (SQL literal, no quoting applied)
    additive = [
        ('project_milestones',    'start_date',         'DATE',         False, None),
        ('project_tasks',         'priority',           'VARCHAR(20)',  False, "'Medium'"),
        ('project_tasks',         'percent_complete',   'INTEGER',      False, '0'),
        ('project_risk_logs',     'probability',        'INTEGER',      False, None),
        ('project_risk_logs',     'impact',             'INTEGER',      False, None),
        ('project_risk_logs',     'owner',              'VARCHAR(200)', False, None),
        ('project_risk_logs',     'mitigation',         'TEXT',         False, None),
        ('project_risk_logs',     'due_date',           'DATE',         False, None),
        ('project_documents',     'is_sensitive',       'BOOLEAN',      True,  '0'),
        ('project_stakeholders',  'designation',        'VARCHAR(200)', False, None),
        ('project_team_members',  'member_group',       'VARCHAR(20)',  False, None),
        ('users',                 'user_group',         'VARCHAR(30)',  False, None),
        ('users',                 'sub_group',          'VARCHAR(100)', False, None),
        ('users',                 'team',               'VARCHAR(20)',  False, None),
        ('projects',              'start_date',         'DATE',         False, None),
        ('projects',              'target_end_date',    'DATE',         False, None),
        ('projects',              'auto_status_email',  'BOOLEAN',      True,  '1'),
        ('projects',              'project_type',         'VARCHAR(20)', False, "'sdlc'"),
        ('projects',              'methodology',          'VARCHAR(20)', False, None),
        ('projects',              'sdlc_score',           'INTEGER',     False, None),
        ('projects',              'sdlc_recommended',     'VARCHAR(20)', False, None),
        ('projects',              'sdlc_override_reason', 'TEXT',        False, None),
        ('sdlc_phase_templates',  'repeatable',           'BOOLEAN',     True,  '0'),
        ('project_sdlc_phases',   'repeatable',           'BOOLEAN',     False, '0'),
        ('project_sdlc_phases',   'default_tasks',        'TEXT',        False, None),
        ('project_sdlc_phases',   'governance',           'TEXT',        False, None),
        ('project_sdlc_phases',   'governance_revision',  'INTEGER',     False, '0'),
        ('hld_template_sections', 'parent_id',          'INTEGER',      False, None),
        ('hld_template_sections', 'doc_type',           'VARCHAR(10)',  False, "'hld'"),
        ('hld_template_sections', 'block_config',       'TEXT',         False, None),
        ('app_support_towers',    'tower_group_names',  'TEXT',         False, None),
        ('tower_members',         'can_manage_secrets', 'BOOLEAN',      True,  '0'),
        ('tower_members',         'is_lead',            'BOOLEAN',      True,  '0'),
        ('application_details',   'category_id',        'INTEGER',      False, None),
        ('support_team',          'source',             'VARCHAR(16)',  False, None),
        ('health_check_reports', 'run_token', 'VARCHAR(36)', False, None),
        ('health_check_reports', 'run_lease_until', 'DATETIME', False, None),
        ('health_check_reports', 'config_version', 'INTEGER', True, '0'),
        ('health_check_reports', 'last_notification_status', 'VARCHAR(20)', False, None),
        ('health_check_reports', 'last_notification_at', 'DATETIME', False, None),
        ('health_check_reports',  'schedule_paused',    'BOOLEAN',      True,  '0'),
        ('health_check_reports',  'manual_run_state',      'VARCHAR(20)', False, None),
        ('health_check_reports',  'manual_run_started_at', 'DATETIME',    False, None),
        ('health_check_reports',  'manual_run_by',         'INTEGER',     False, None),
        ('health_check_reports',  'manual_run_message',    'TEXT',        False, None),
        ('health_check_reports',  'manual_run_heartbeat',  'DATETIME',    False, None),
        ('file_monitor_reports',  'exclusion_rules',    'TEXT',         False, None),
        ('file_monitor_reports',  'alert_enabled',      'BOOLEAN',      False, '0'),
        ('file_monitor_reports',  'alert_emails',       'VARCHAR(500)', False, None),
        ('file_monitor_reports',  'source_stats_config',            'TEXT', False, None),
        ('file_monitor_reports',  'source_exclusion_config',        'TEXT', False, None),
        ('file_monitor_reports',  'intermediate_stats_config',      'TEXT', False, None),
        ('file_monitor_reports',  'intermediate_exclusion_config',  'TEXT', False, None),
        ('file_monitor_reports',  'target_stats_config',            'TEXT', False, None),
        ('file_monitor_reports',  'target_exclusion_config',        'TEXT', False, None),
        ('file_monitor_reports',  'source_display_config',          'TEXT', False, None),
        ('file_monitor_reports',  'intermediate_display_config',    'TEXT', False, None),
        ('file_monitor_reports',  'target_display_config',          'TEXT', False, None),
        ('file_monitor_reports',  'alert_grace_days',               'INTEGER', False, '1'),
        ('file_monitor_reports',  'exclusion_apply_all',            'BOOLEAN', False, '0'),
        ('file_monitor_reports',  'tower_id',                       'INTEGER', False, None),
        ('activity_entries',      'project_task_id',    'INTEGER',      False, None),
        ('code_projects',         'gate_mode',          'VARCHAR(10)',  False, "'full'"),
        ('code_scans',            'gate_mode',          'VARCHAR(10)',  False, "'full'"),
        ('code_scans',            'baseline_scan_id',   'INTEGER',      False, None),
        ('code_scans',            'new_blocker',        'INTEGER',      False, '0'),
        ('code_scans',            'new_critical',       'INTEGER',      False, '0'),
        ('code_scans',            'new_high',           'INTEGER',      False, '0'),
        ('code_scans',            'new_findings',       'INTEGER',      False, '0'),
        ('code_scans',            'heartbeat_at',       'DATETIME',     False, None),
        ('code_findings',         'is_new',             'BOOLEAN',      False, '1'),
        ('snow_ticket_workload',  'resolved_at',        'DATETIME',     False, None),
        ('snow_ticket_workload',  'priority',           'VARCHAR(10)',  False, None),
        ('snow_ticket_workload',  'category',           'VARCHAR(200)', False, None),
        ('snow_ticket_workload',  'subcategory',        'VARCHAR(200)', False, None),
        ('snow_ticket_workload',  'short_description',  'VARCHAR(500)', False, None),
        ('snow_ticket_workload',  'assignment_group',   'VARCHAR(200)', False, None),
        ('snow_ticket_workload',  'state',              'VARCHAR(60)',  False, None),
        # Software Inventory audience. NOT NULL with a 'general' default so
        # every package published before restricted software existed keeps
        # the behaviour it had - open to every signed-in user - instead of
        # landing on a NULL that the access rule would then have to guess at.
        ('software_items',        'visibility',         'VARCHAR(16)',  True,  "'general'"),
        # MIMP schedule state. Nullable with no default on purpose: NULL
        # means "not seeded yet", and the sweep seeds it once from the last
        # SCHEDULER-written observation so an existing report resumes where
        # it was instead of every report firing at once after the upgrade.
        ('mimp_reports',          'last_run_at',        'DATETIME',     False, None),
        ('mimp_reports',          'next_run_at',        'DATETIME',     False, None),
    ]

    def _render_type(generic_type: str) -> str:
        if generic_type == 'BOOLEAN':
            return 'BIT' if is_mssql else 'BOOLEAN'
        return generic_type

    def _render_add(table: str, column: str, generic_type: str,
                    not_null: bool, default_literal) -> str:
        col_type = _render_type(generic_type)
        # SQL Server: "ALTER TABLE t ADD col TYPE [DEFAULT x] [NOT NULL]"
        # Others:     "ALTER TABLE t ADD COLUMN col TYPE [NOT NULL DEFAULT x]"
        if is_mssql:
            parts = [f'ALTER TABLE {table} ADD {column} {col_type}']
            if default_literal is not None:
                parts.append(f'DEFAULT {default_literal}')
            if not_null:
                parts.append('NOT NULL')
            return ' '.join(parts)
        parts = [f'ALTER TABLE {table} ADD COLUMN {column} {col_type}']
        if not_null:
            parts.append('NOT NULL')
        if default_literal is not None:
            parts.append(f'DEFAULT {default_literal}')
        return ' '.join(parts)

    try:
        inspector = inspect(engine)
        existing_tables = set(inspector.get_table_names())
    except Exception as e:
        logger.warning("Could not inspect schema for column migration: %s", e)
        return

    added = 0
    with engine.begin() as conn:
        for table, column, gtype, not_null, default_literal in additive:
            if table not in existing_tables:
                continue  # create_all() will have built it with the column
            try:
                cols = {c['name'] for c in inspector.get_columns(table)}
            except Exception as e:
                logger.warning("Could not read columns of %s: %s", table, e)
                continue
            if column in cols:
                continue
            try:
                conn.execute(text(_render_add(table, column, gtype,
                                              not_null, default_literal)))
                added += 1
                logger.info("Added missing column %s.%s", table, column)
            except Exception as e:
                logger.warning("Could not add column %s.%s: %s", table, column, e)

    # Backfill milestone.start_date so existing rows satisfy the
    # "task within milestone start/end" rule. Fall back to the milestone's
    # end_date when no better signal exists. The only non-portable piece is
    # SQLite's date(created_at); SQL Server uses CAST(created_at AS DATE).
    created_at_as_date = (
        'CAST(created_at AS DATE)' if is_mssql else 'date(created_at)'
    )
    try:
        with engine.begin() as conn:
            conn.execute(text(
                "UPDATE project_milestones "
                "SET start_date = COALESCE("
                "  (SELECT MIN(t.start_date) FROM project_tasks t "
                "     WHERE t.milestone_id = project_milestones.id), "
                f"  {created_at_as_date}, end_date) "
                "WHERE start_date IS NULL"
            ))
    except Exception as e:
        logger.warning("Could not backfill milestone start_date: %s", e)

    # Backfill sdlc_phase_milestones (the stage->milestone mapping) from the
    # two earlier cuts of the SDLC feature: the original phase-side link
    # (project_sdlc_phases.milestone_id) and the interim milestone-side link
    # (project_milestones.sdlc_phase_id). Each legacy column only exists on
    # databases created under that cut, so each statement is allowed to fail
    # silently - the NOT EXISTS guard keeps both idempotent.
    for legacy_sql in (
        "INSERT INTO sdlc_phase_milestones (phase_id, milestone_id) "
        "SELECT p.id, p.milestone_id FROM project_sdlc_phases p "
        "WHERE p.milestone_id IS NOT NULL AND NOT EXISTS "
        "  (SELECT 1 FROM sdlc_phase_milestones l "
        "     WHERE l.phase_id = p.id AND l.milestone_id = p.milestone_id)",
        "INSERT INTO sdlc_phase_milestones (phase_id, milestone_id) "
        "SELECT m.sdlc_phase_id, m.id FROM project_milestones m "
        "WHERE m.sdlc_phase_id IS NOT NULL AND NOT EXISTS "
        "  (SELECT 1 FROM sdlc_phase_milestones l "
        "     WHERE l.phase_id = m.sdlc_phase_id AND l.milestone_id = m.id)",
    ):
        try:
            with engine.begin() as conn:
                conn.execute(text(legacy_sql))
        except Exception:
            pass

    if added:
        logger.info("Column migration complete - %d column(s) added.", added)


def recreate_all_tables_DESTRUCTIVE() -> None:
    """
    Drop and recreate every table. DEVELOPMENT USE ONLY.

    Wipes ALL data including:
        - User accounts and their hashed passwords
        - All projects, applications, towers, support data
        - All MIMP reports and status history
        - All APScheduler persisted jobs
        - All other module data

    Only call this manually from a developer shell, never from app startup.
    """
    logger.warning("DESTRUCTIVE: Dropping and recreating all tables.")
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    logger.warning("DESTRUCTIVE: All tables recreated. ALL DATA LOST.")


def get_db_session():
    """Get database session"""
    return SessionLocal()


def close_db_session(session):
    """Close database session"""
    session.close()