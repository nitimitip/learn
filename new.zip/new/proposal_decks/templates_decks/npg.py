"""
NPG - enterprise slate + crimson corporate deck.

Brand-aligned with the NPG AppAssist index hero: a deep-slate canvas that
resolves into the house crimson (``#9F1C33`` - the index hero's brand red),
a coloured header bar on every slide, stroke icons throughout, and a
slate->crimson gradient cover.

Body slides use a high-contrast *editorial / annual-report* layout - white
canvas, dark ink type, hairline-ruled lists, financial-style tables, navy
emphasis panels and crimson rules - structurally distinct from the other
three templates' bespoke layouts.

Renders the full canonical 15-slide proposal set defined in schema.py.

Self-contained and fully offline: no web-font imports - the type is a system
font stack (Segoe UI / Georgia / Consolas) so the downloaded deck renders the
same on any machine with no internet connection.
"""

from __future__ import annotations

from ..render_common import (
    Deck, esc, esc_br, footer_positions, gantt_geometry, gantt_unit, skip_attr, risk_class,
    filled, join_filled, resource_plan, plan_split_text, fmt_num,
    effort_matrix_html, effort_summary_html,
)

META = {
    'id': 'npg',
    'name': 'NPG - Slate & Crimson',
    'tagline': 'Editorial annual-report body on a white canvas, coloured header bar, hairline rules & navy panels. Corporate & on-brand.',
    'body_bg': '#9F1C33',
    'accent': '#9F1C33',
}

# --- SVG icon library (stroke icons) ---------------------------------------
I_ALERT = '<path d="M10.3 3.8 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.8a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/>'
I_SHIELD = '<path d="M12 2 3 7v6c0 5 3.8 8.5 9 9 5.2-.5 9-4 9-9V7z"/><path d="m9 12 2 2 4-4"/>'
I_TREND = '<path d="M3 17l6-6 4 4 8-8"/><path d="M21 7v6"/><path d="M21 7h-6"/>'
I_CHART = '<path d="M3 3v18h18"/><path d="M19 9l-5 5-4-4-3 3"/>'
I_CHECK = '<path d="M20 6 9 17l-5-5"/>'
I_DASH = '<path d="M5 12h14"/>'
I_CLOCK = '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'
I_REFRESH = '<path d="M21 12a9 9 0 1 1-9-9"/><path d="M21 5v4h-4"/>'
I_LOCK = '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>'
I_ARROW = '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>'
I_CAL = '<path d="M8 2v4M16 2v4M3 10h18"/><rect x="3" y="4" width="18" height="18" rx="2"/><path d="m9 16 2 2 4-4"/>'
I_USER = '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>'
STACK_ICONS = [
    '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/>',
    '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
    '<path d="M17.5 19a4.5 4.5 0 0 0 .5-9 6 6 0 0 0-11.5-2A4 4 0 0 0 6 19z"/>',
    '<circle cx="12" cy="12" r="3"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4M5 5l3 3M16 16l3 3M19 5l-3 3M8 16l-3 3"/>',
]

CSS = r"""
:root{
  --navy:#1F2734;--slate:#33414F;--accent:#9F1C33;--accent-2:#C7424F;--white:#FFFFFF;
  --bg:#FFFFFF;--ink:#10161F;--muted:#4A5663;--line:#D9DEE4;--line-2:#BDC5CE;
  --green:#177A52;--amber:#B98300;--red:#C03434;
  --display:'Segoe UI',system-ui,-apple-system,'Helvetica Neue',Arial,sans-serif;
  --body:'Segoe UI',system-ui,-apple-system,'Helvetica Neue',Arial,sans-serif;
  --mono:'Consolas','SFMono-Regular','Courier New',monospace;
  --pad:84px;--bar-h:150px;--foot-h:64px;
}
*{box-sizing:border-box;}
.slide{display:flex;flex-direction:column;background:var(--bg);font-family:var(--body);color:var(--ink);overflow:hidden;}
.bar{height:var(--bar-h);flex:0 0 var(--bar-h);background:linear-gradient(120deg,var(--accent) 0%,#86142a 100%);color:var(--white);display:flex;align-items:center;gap:26px;padding:0 var(--pad);position:relative;}
.bar::after{content:"";position:absolute;left:0;bottom:0;height:4px;width:100%;background:rgba(0,0,0,.22);}
.bar-logo{display:flex;align-items:center;gap:12px;font-family:var(--display);font-weight:700;font-size:19px;letter-spacing:.02em;color:#fff;white-space:nowrap;}
.bar .bar-logo{margin-left:0;}
.bar .bar-logo .mark{background:#fff;color:var(--accent);}
.bar-logo .mark{width:34px;height:34px;border-radius:7px;background:linear-gradient(135deg,var(--accent),var(--accent-2));display:grid;place-items:center;font-size:17px;font-weight:800;color:#fff;}
.bar-titles{display:flex;flex-direction:column;gap:8px;min-width:0;flex:1;padding-left:26px;border-left:1px solid rgba(255,255,255,.28);}
.bar-eyebrow{font-family:var(--mono);font-size:14px;letter-spacing:.22em;text-transform:uppercase;color:rgba(255,255,255,.72);}
.bar h2{font-family:var(--display);font-weight:700;font-size:40px;letter-spacing:-.01em;margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.bar-index{margin-left:auto;font-family:var(--display);font-size:66px;font-weight:800;color:rgba(255,255,255,.24);letter-spacing:-.02em;line-height:1;}
.body{flex:1 1 auto;padding:52px var(--pad) 30px;min-height:0;display:flex;flex-direction:column;}
.foot{height:var(--foot-h);flex:0 0 var(--foot-h);display:flex;align-items:center;justify-content:space-between;padding:0 var(--pad);font-family:var(--mono);font-size:13.5px;letter-spacing:.08em;color:var(--muted);border-top:1px solid var(--line);background:var(--bg);}
.foot .conf{color:var(--accent);font-weight:600;}
.foot .dot{opacity:.4;padding:0 12px;}
.eyebrow{font-family:var(--mono);font-size:15px;letter-spacing:.2em;text-transform:uppercase;color:var(--accent);font-weight:600;}
.sectionhint{font-family:var(--mono);font-size:14px;letter-spacing:.18em;text-transform:uppercase;color:var(--muted);}
/* --- editorial body language ------------------------------------------- */
.kicker{display:flex;align-items:center;gap:14px;font-family:var(--mono);font-size:14px;letter-spacing:.22em;text-transform:uppercase;color:var(--accent);font-weight:700;}
.kicker::before{content:"";width:30px;height:3px;background:var(--accent);flex:none;}
.lead{font-size:27px;line-height:1.55;color:var(--ink);max-width:1450px;font-weight:400;}
.lead strong{color:var(--accent);font-weight:700;}
.split{display:flex;gap:0;flex:1;min-height:0;align-items:stretch;}
.split>.cell{padding:0 56px;display:flex;flex-direction:column;min-width:0;}
.split>.cell:first-child{padding-left:0;}
.split>.cell:last-child{padding-right:0;}
.split>.cell+.cell{border-left:1px solid var(--line);}
/* KPI rail (exec) */
.kpis{display:flex;flex-direction:column;justify-content:center;flex:1;}
.kpi{display:grid;grid-template-columns:330px 1fr;gap:36px;padding:34px 0 34px 28px;border-top:1px solid var(--line);align-items:center;position:relative;}
.kpi:first-child{border-top:0;}
.kpi::before{content:"";position:absolute;left:0;top:36px;bottom:36px;width:4px;background:var(--kc,var(--accent));}
.kpi .ktag{font-family:var(--mono);font-size:13px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:var(--kc,var(--accent));}
.kpi .kmetric{font-family:var(--display);font-weight:800;font-size:62px;line-height:1.05;letter-spacing:-.02em;color:var(--navy);margin-top:8px;}
.kpi h3{font-family:var(--display);font-weight:700;font-size:23px;margin:0 0 8px;color:var(--ink);}
.kpi p{margin:0;font-size:19px;line-height:1.5;color:var(--muted);}
/* numbered editorial list (challenge pains) */
.plist{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;justify-content:center;flex:1;}
.plist li{display:grid;grid-template-columns:78px 1fr;gap:20px;padding:25px 0;border-top:1px solid var(--line);}
.plist li:first-child{border-top:0;padding-top:0;}
.plist li:last-child{padding-bottom:0;}
.plist .pn{font-family:var(--display);font-weight:800;font-size:32px;line-height:1.15;color:var(--accent);}
.plist b{display:block;font-size:21px;font-weight:700;color:var(--ink);margin-bottom:5px;}
.plist span{display:block;font-size:18px;line-height:1.5;color:var(--muted);}
/* navy emphasis panel */
.panel{background:var(--navy);color:#fff;padding:44px 48px;display:flex;flex-direction:column;}
.panel .pkick{display:flex;align-items:center;gap:14px;font-family:var(--mono);font-size:14px;letter-spacing:.22em;text-transform:uppercase;color:var(--accent-2);font-weight:700;}
.panel .pkick::before{content:"";width:30px;height:3px;background:var(--accent-2);flex:none;}
.panel .imp{padding:24px 0;border-top:1px solid rgba(255,255,255,.16);}
.panel .imp:first-of-type{border-top:0;}
.panel .imp .v{font-family:var(--display);font-weight:800;font-size:54px;line-height:1;letter-spacing:-.02em;color:var(--accent-2);}
.panel .imp .l{color:rgba(255,255,255,.72);font-size:18px;margin-top:8px;line-height:1.4;}
/* mapping rows (solution) */
.maprow{display:grid;grid-template-columns:1fr 40px 1.1fr;gap:18px;padding:21px 0;border-top:1px solid var(--line);align-items:center;}
.maprow:first-child{border-top:0;padding-top:0;}
.maprow .need{font-size:18px;color:var(--muted);line-height:1.4;}
.maprow .sol{font-size:18.5px;font-weight:700;color:var(--ink);line-height:1.4;}
/* architecture (solution) */
.arch{display:flex;flex-direction:column;gap:13px;align-items:center;}
.arch .layer{display:flex;gap:13px;width:100%;}
.arch .node{flex:1;background:#F7F8FA;border:1px solid var(--line-2);padding:16px 10px;text-align:center;font-family:var(--mono);font-size:13.5px;font-weight:600;color:var(--slate);}
.arch .node.edge{background:var(--navy);color:#fff;border-color:var(--navy);}
/* ruled checklist (scope) */
.slist{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;}
.slist li{display:flex;gap:15px;align-items:flex-start;padding:14px 0;border-top:1px solid var(--line);font-size:19px;line-height:1.45;color:var(--ink);}
.slist li:first-child{border-top:0;padding-top:0;}
.slist.dim li{color:var(--muted);}
/* phase strip (scope) */
.pstrip{display:flex;gap:34px;position:relative;margin-top:20px;}
.pstrip::before{content:"";position:absolute;top:23px;left:0;right:34px;height:1px;background:var(--line-2);}
.pstep{flex:1;position:relative;z-index:1;}
.pstep .pq{width:46px;height:46px;background:var(--navy);color:#fff;display:grid;place-items:center;font-family:var(--display);font-weight:800;font-size:20px;border:4px solid var(--bg);}
.pstep b{display:block;font-size:19px;font-weight:700;color:var(--ink);margin:14px 0 5px;}
.pstep p{margin:0;font-size:16.5px;line-height:1.45;color:var(--muted);}
/* gantt (roadmap) */
.gtrack{position:relative;height:44px;}
.gbar{position:absolute;top:7px;bottom:7px;background:linear-gradient(90deg,var(--navy),var(--slate));}
.gbar.hot{background:linear-gradient(90deg,var(--accent),var(--accent-2));}
.gms{position:absolute;top:50%;width:15px;height:15px;background:var(--accent);transform:translate(-50%,-50%) rotate(45deg);border:2px solid #fff;box-shadow:0 0 0 1.5px var(--accent);}
/* member rows (team) */
.mgrid{display:grid;grid-template-columns:1fr 1fr;column-gap:64px;}
.mrow{display:flex;gap:18px;align-items:flex-start;padding:21px 0;border-top:1px solid var(--line);}
.mrow b{display:block;font-size:19.5px;font-weight:700;color:var(--ink);}
.mrow .role{font-family:var(--mono);font-size:13px;color:var(--accent);letter-spacing:.04em;margin:3px 0 7px;text-transform:uppercase;}
.mrow p{margin:0;font-size:16px;line-height:1.45;color:var(--muted);}
/* stack columns */
.stackcols{display:flex;flex:1;align-items:stretch;}
.stackcol{flex:1;padding:0 38px;min-width:0;}
.stackcol:first-child{padding-left:0;}
.stackcol:last-child{padding-right:0;}
.stackcol+.stackcol{border-left:1px solid var(--line);}
.stackh{display:flex;align-items:center;gap:12px;font-family:var(--display);font-weight:700;font-size:22px;color:var(--navy);padding-bottom:15px;border-bottom:3px solid var(--accent);margin-bottom:8px;}
.stackcol ul{list-style:none;margin:0;padding:0;}
.stackcol li{font-size:18.5px;color:var(--ink);padding:12px 0 12px 20px;position:relative;border-top:1px solid var(--line);}
.stackcol li:first-child{border-top:0;}
.stackcol li::before{content:"";position:absolute;left:0;top:21px;width:7px;height:7px;background:var(--accent);}
/* financial-style ruled table */
.fin{width:100%;border-collapse:collapse;font-size:19px;}
.fin th{text-align:left;font-family:var(--mono);font-size:13.5px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);padding:0 20px 13px 0;border-bottom:2.5px solid var(--navy);}
.fin th:last-child{padding-right:0;}
.fin td{padding:16px 20px 16px 0;border-bottom:1px solid var(--line);color:var(--ink);vertical-align:top;line-height:1.45;}
.fin td:last-child{padding-right:0;}
.fin .num{font-family:var(--mono);color:var(--accent);font-weight:700;}
.fin tr.total td{border-top:2.5px solid var(--navy);border-bottom:0;font-family:var(--display);font-weight:800;font-size:21px;color:var(--navy);padding-top:18px;}
.fin tr.hl td{background:rgba(159,28,51,.05);}
.fin tr.hl td:first-child{color:var(--accent);font-weight:700;box-shadow:inset 3px 0 0 var(--accent);padding-left:14px;}
.rx-role{font-weight:700;white-space:nowrap;}
.rx-loc{display:inline-flex;align-items:center;gap:8px;}
.rx-loc i{width:11px;height:11px;border-radius:50%;display:inline-block;flex:none;}
.rx-matrix th.c{text-align:center;padding-left:0;padding-right:0;}
.rx-dense td,.rx-dense th{font-size:13px !important;}
.rx-strip{display:grid;grid-template-columns:1fr 1.7fr 1fr 1fr;}
.rx-mix{display:flex;height:11px;overflow:hidden;}
.rx-mix span{display:block;height:100%;}
.rx-legend{display:flex;flex-direction:column;gap:6px;margin-top:11px;}
.fin.rx-matrix{font-size:16.5px;}
.fin.rx-matrix td{padding:10px 14px 10px 0;}
.fin .c{text-align:center;}
.fin .r{text-align:right;}
.rx-rowtotal{font-weight:700;color:var(--accent);}
.rx-zero{color:var(--line-2);}
.rx-loc{font-family:var(--mono);font-size:13.5px;}
.rx-strip{background:var(--navy);color:#fff;}
.rx-cell{padding:22px 30px;border-left:1px solid rgba(255,255,255,.14);}
.rx-cell:first-child{border-left:0;}
.rx-v{font-family:var(--display);font-weight:800;font-size:40px;line-height:1;letter-spacing:-.02em;color:var(--accent-2);}
.rx-l{font-size:15px;color:rgba(255,255,255,.72);margin-top:8px;}
.rx-mix{background:rgba(255,255,255,.12);}
.rx-mix span+span{border-left:2px solid var(--navy);}
.rx-legend{font-size:15px;color:rgba(255,255,255,.78);}
.rx-strip .rx-loc{color:#fff;font-weight:700;}
/* pricing rail */
.recbox{background:var(--navy);color:#fff;padding:34px 38px;border-top:5px solid var(--accent);}
.recbox .rtag{display:inline-block;background:var(--accent);color:#fff;font-family:var(--mono);font-size:12px;font-weight:700;padding:5px 12px;letter-spacing:.12em;margin-bottom:14px;}
.recbox h3{font-family:var(--display);font-weight:700;font-size:24px;margin:0 0 10px;color:#fff;}
.recbox p{color:rgba(255,255,255,.76);font-size:17.5px;line-height:1.5;margin:0 0 18px;}
.recbox .rprice{font-family:var(--display);font-weight:800;font-size:38px;letter-spacing:-.01em;}
.altbox{border:1px solid var(--line);border-top:5px solid var(--line-2);padding:30px 38px;}
.altbox h3{font-family:var(--display);font-weight:700;font-size:21px;margin:0 0 10px;color:var(--navy);}
.altbox p{color:var(--muted);font-size:17px;line-height:1.5;margin:0 0 14px;}
.altbox .aprice{font-family:var(--display);font-weight:800;font-size:30px;color:var(--navy);}
/* dots / legend */
.dotlabel{display:inline-flex;align-items:center;gap:10px;font-weight:600;font-family:var(--mono);font-size:15px;}
.rdot{width:13px;height:13px;border-radius:50%;display:inline-block;}
.rdot.r{background:var(--red);}.rdot.a{background:var(--amber);}.rdot.g{background:var(--green);}
/* info rows (support / compliance) */
.inforow{display:flex;gap:20px;align-items:flex-start;padding:26px 0;border-top:1px solid var(--line);}
.inforow:first-child{border-top:0;padding-top:0;}
.inforow .isq{flex:none;width:54px;height:54px;background:rgba(159,28,51,.08);display:grid;place-items:center;}
.inforow b{display:block;font-family:var(--display);font-size:21px;font-weight:700;color:var(--navy);margin-bottom:6px;}
.inforow p{margin:0;font-size:18px;line-height:1.5;color:var(--muted);}
/* escalation stepper */
.esteps{display:flex;gap:14px;align-items:stretch;margin-top:18px;}
.estep{flex:1;text-align:center;}
.estep .eq{width:46px;height:46px;margin:0 auto 10px;background:var(--navy);color:#fff;display:grid;place-items:center;font-family:var(--display);font-weight:800;font-size:19px;}
.estep b{display:block;font-size:17.5px;color:var(--ink);}
.estep span{display:block;color:var(--muted);font-size:15px;margin-top:3px;line-height:1.35;}
/* horizon timeline (scalability) */
.tl{position:relative;display:grid;gap:48px;}
.tl::before{content:"";position:absolute;top:10px;left:3%;right:3%;height:2px;background:var(--line-2);}
.tnode{position:relative;z-index:1;}
.tnode .tdot{width:21px;height:21px;border-radius:50%;background:var(--accent);border:4px solid var(--bg);box-shadow:0 0 0 1.5px var(--accent);}
.tnode .tphase{font-family:var(--mono);font-size:13px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:var(--accent);margin:16px 0 6px;}
.tnode h3{font-family:var(--display);font-weight:700;font-size:22px;color:var(--navy);margin:0 0 12px;}
.tnode ul{list-style:none;margin:0;padding:0;}
.tnode li{font-size:16.5px;color:var(--muted);line-height:1.4;padding:8px 0 8px 18px;position:relative;border-top:1px solid var(--line);}
.tnode li:first-child{border-top:0;}
.tnode li::before{content:"";position:absolute;left:0;top:15px;width:6px;height:6px;background:var(--accent);}
/* glossary definition rows */
.grow{display:grid;grid-template-columns:215px 1fr;gap:22px;padding:15px 0;border-top:1px solid var(--line);font-size:18px;line-height:1.45;}
.grow:first-child{border-top:0;padding-top:0;}
.grow b{color:var(--navy);font-family:var(--display);font-weight:700;}
.grow span{color:var(--ink);}
/* next-steps process */
.nsteps{display:grid;gap:44px;margin-bottom:42px;}
.nstep{border-top:3px solid var(--navy);padding-top:20px;}
.nstep .nn{font-family:var(--display);font-weight:800;font-size:52px;line-height:1;color:var(--accent);letter-spacing:-.02em;}
.nstep h3{font-family:var(--display);font-weight:700;font-size:22px;color:var(--ink);margin:14px 0 8px;}
.nstep p{margin:0 0 12px;font-size:17.5px;line-height:1.5;color:var(--muted);}
.nstep .when{font-family:var(--mono);font-size:14px;font-weight:600;color:var(--accent);letter-spacing:.06em;}
.band{background:var(--navy);color:#fff;display:flex;align-items:center;gap:46px;padding:32px 46px;}
.band .bdiv{width:1px;align-self:stretch;background:rgba(255,255,255,.2);flex:none;}
.icon{width:30px;height:30px;stroke:var(--accent);stroke-width:1.8;fill:none;stroke-linecap:round;stroke-linejoin:round;}
.icon.lg{width:34px;height:34px;}
.avatar{border-radius:50%;background:rgba(159,28,51,.08);border:1px solid rgba(159,28,51,.18);display:grid;place-items:center;color:var(--accent);}
.avatar svg{width:54%;height:54%;stroke:currentColor;stroke-width:1.7;fill:none;stroke-linecap:round;stroke-linejoin:round;}
.slide.dark{background:linear-gradient(135deg,var(--navy) 0%,var(--accent) 100%);color:#fff;}
.slide.dark .body{color:#fff;}
.circuit{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.05) 1px,transparent 1px);background-size:64px 64px;mask-image:radial-gradient(ellipse 90% 80% at 70% 40%,#000 30%,transparent 78%);-webkit-mask-image:radial-gradient(ellipse 90% 80% at 70% 40%,#000 30%,transparent 78%);}
.glow{position:absolute;border-radius:50%;filter:blur(120px);opacity:.5;pointer-events:none;}
@media (prefers-reduced-motion:no-preference){
  [data-deck-active] .anim{animation:rise .55s cubic-bezier(.2,.7,.3,1) both;}
  [data-deck-active] .anim.d1{animation-delay:.06s;}[data-deck-active] .anim.d2{animation-delay:.12s;}
  [data-deck-active] .anim.d3{animation-delay:.18s;}[data-deck-active] .anim.d4{animation-delay:.24s;}
  @keyframes rise{from{opacity:0;transform:translateY(16px);}to{opacity:1;transform:none;}}
}
"""


def _svg(paths, cls='icon', style=''):
    st = f' style="{style}"' if style else ''
    return f'<svg viewBox="0 0 24 24" class="{cls}"{st}>{paths}</svg>'


def _avatar(size):
    """A circular user-icon avatar (placeholder for a head-shot)."""
    return (f'<div class="avatar" style="width:{size}px;height:{size}px;flex:0 0 {size}px;">'
            f'<svg viewBox="0 0 24 24">{I_USER}</svg></div>')


# Readable on both the white table and the navy numbers panel.
_LOC_COLOR = {'onshore': 'var(--accent-2)', 'nearshore': 'var(--amber)', 'offshore': '#6F8AA6'}


def _loc_color(loc):
    return _LOC_COLOR.get((loc or '').strip().lower(), 'var(--slate)')


def _resourcing_slide(deck, header, foot, intro, when):
    """Team Composition & Effort - the Resource Effort Matrix (effort only, no cost)."""
    plan = resource_plan(deck)
    body = ''
    if plan:
        body = f'''<div class="anim d1" style="flex:1;min-height:0;display:flex;flex-direction:column;justify-content:center;">
        {effort_matrix_html(plan, table_cls="fin", heat_rgb="159,28,51", loc_color=_loc_color)}
      </div>
      <div class="anim d2" style="margin-top:22px;">{effort_summary_html(plan, _loc_color)}</div>'''
    notes = deck.text('resourcing', 'assumptions').strip()
    notes_html = when(notes, f'''<div class="anim d3" style="border-left:4px solid var(--accent);padding:4px 0 4px 26px;margin-top:20px;">
      <p style="margin:0;font-size:16.5px;line-height:1.5;color:var(--muted);max-width:1600px;">{esc(notes)}</p>
    </div>''')
    return f'''<section class="slide"{skip_attr(deck.enabled("resourcing"))} data-screen-label="11 Team Composition">
  {header("resourcing")}
  <div class="body">
    {intro("resourcing")}
    {body}
    {notes_html}
  </div>
  {foot("resourcing")}
</section>'''


def render(payload) -> str:
    deck = payload if isinstance(payload, Deck) else Deck(payload)
    pos = footer_positions(deck)
    letter, short = esc(deck.m('logo_letter')), esc(deck.m('brand_short'))

    def logo():
        return f'<div class="bar-logo"><span class="mark">{letter}</span> {short}</div>'

    from ..schema import SLIDE_BY_KEY

    def header(key):
        n, _ = pos[key]
        meta = SLIDE_BY_KEY[key]
        return (f'<header class="bar">{logo()}'
                f'<div class="bar-titles"><span class="bar-eyebrow">{esc(meta["eyebrow"])}</span>'
                f'<h2>{esc(meta["title"])}</h2></div>'
                f'<span class="bar-index">{n}</span></header>')

    def foot(key):
        n, t = pos[key]
        return ('<footer class="foot"><span><span class="conf">'
                f'{esc(deck.m("confidential")).upper()}</span></span>'
                f'<span>{esc(deck.m("doc_date"))} <span class="dot">-</span> {esc(deck.m("doc_version"))}</span>'
                f'<span>{n} / {t}</span></footer>')

    def intro(key):
        t = (deck.text(key, 'lead') or '').strip()
        return f'<p class="lead anim" style="margin:0 0 34px;">{esc(t)}</p>' if t else ''

    def when(cond, html_):
        """Emit ``html_`` only when its content exists - no empty placeholders."""
        return html_ if cond else ''

    def labelled(label, value, extra=''):
        v = (value or '').strip()
        return when(v, f'<div><div class="sectionhint" style="color:rgba(255,255,255,.55);margin-bottom:8px;">{label}</div>'
                       f'<div style="font-size:21px;font-weight:600;{extra}">{esc(v)}</div></div>')

    out = []

    # ---- 1 COVER ----
    client = deck.m('client_name').strip()
    conf = deck.m('confidential').strip()
    out.append(f'''<section class="slide dark"{skip_attr(deck.enabled("cover"))} data-screen-label="01 Cover">
  <div class="circuit"></div>
  <div class="glow" style="width:680px;height:680px;background:var(--accent);right:-120px;top:-160px;"></div>
  <div class="glow" style="width:520px;height:520px;background:var(--accent-2);left:-140px;bottom:-200px;opacity:.32;"></div>
  <div class="body" style="padding:96px var(--pad) 80px;justify-content:space-between;position:relative;z-index:2;">
    <div style="display:flex;align-items:center;justify-content:space-between;">
      <div class="bar-logo" style="font-size:23px;"><span class="mark" style="width:42px;height:42px;font-size:20px;">{letter}</span> {short}&nbsp;<span style="font-weight:500;color:rgba(255,255,255,.6);">{esc(deck.m("brand_name"))}</span></div>
      <div class="sectionhint" style="color:rgba(255,255,255,.5);">Technology Solution Proposal</div>
    </div>
    <div class="anim d1" style="max-width:1450px;">
      {when(client, f'<div class="eyebrow" style="color:#fff;margin-bottom:28px;">Prepared for &nbsp;-&nbsp; {esc(client)}</div>')}
      <h1 style="font-family:var(--display);font-weight:800;font-size:96px;line-height:1.02;letter-spacing:-.025em;margin:0 0 30px;">{esc_br(deck.text("cover","title"))}</h1>
      {when(filled(deck.text("cover","tagline")), f'<p style="font-size:28px;line-height:1.5;color:rgba(255,255,255,.78);max-width:1080px;margin:0;">{esc(deck.text("cover","tagline"))}</p>')}
    </div>
    <div style="display:flex;gap:64px;align-items:flex-end;justify-content:space-between;">
      <div style="display:flex;gap:64px;">
        {labelled("Prepared by", deck.m("brand_name"))}
        {labelled("Date", deck.m("doc_date"))}
        {labelled("Version", deck.m("doc_version"), "font-family:var(--mono);")}
      </div>
      {when(conf, f'<div class="sectionhint" style="color:#fff;border:1px solid rgba(255,255,255,.4);padding:10px 18px;border-radius:4px;">{esc(conf)}</div>')}
    </div>
  </div>
</section>''')

    # ---- 2 EXECUTIVE SUMMARY ----
    kindmap = {
        'problem': ('var(--red)', 'The problem'),
        'solution': ('var(--accent)', 'Our answer'),
        'value': ('var(--green)', 'The value'),
    }
    kpi_html = []
    for i, r in enumerate(deck.table('exec', 'stats')[:3]):
        kind = (r.get('kind') or 'solution').strip().lower()
        kc, _ = kindmap.get(kind, kindmap['solution'])
        kpi_html.append(f'''<div class="kpi anim d{i+1}" style="--kc:{kc};">
        <div><div class="ktag">{esc(r.get("heading"))}</div><div class="kmetric">{esc(r.get("metric"))}</div></div>
        <p>{esc(r.get("desc"))}</p></div>''')
    exec_lead = deck.text('exec', 'lead').strip()
    out.append(f'''<section class="slide"{skip_attr(deck.enabled("exec"))} data-screen-label="02 Executive Summary">
  {header("exec")}
  <div class="body">
    <div class="split" style="flex:1;">
      {when(exec_lead, f"""<div class="cell anim" style="flex:1;justify-content:center;gap:28px;">
        <div class="kicker">The opportunity</div>
        <p class="lead" style="margin:0;font-size:29px;">{esc(exec_lead)}</p>
      </div>""")}
      {when(kpi_html, f"""<div class="cell" style="flex:1.25;">
        <div class="kpis">{''.join(kpi_html)}</div>
      </div>""")}
    </div>
  </div>
  {foot("exec")}
</section>''')

    # ---- 3 CHALLENGE ----
    pains = ''.join(
        f'<li><span class="pn">{i+1:02d}</span><div><b>{esc(r.get("heading"))}</b>'
        f'<span>{esc(r.get("detail"))}</span></div></li>'
        for i, r in enumerate(deck.table('challenge', 'pains')))
    impacts = ''.join(
        f'<div class="imp"><div class="v">{esc(r.get("metric"))}</div>'
        f'<div class="l">{esc(r.get("label"))}</div></div>'
        for r in deck.table('challenge', 'impacts'))
    out.append(f'''<section class="slide"{skip_attr(deck.enabled("challenge"))} data-screen-label="03 Business Challenge">
  {header("challenge")}
  <div class="body">
    <div style="display:flex;gap:64px;flex:1;align-items:stretch;">
      {when(pains, f"""<div class="anim d1" style="flex:1.35;display:flex;flex-direction:column;">
        <div class="kicker" style="margin-bottom:10px;">Current pain points</div>
        <ul class="plist">{pains}</ul>
      </div>""")}
      {when(impacts, f"""<div class="panel anim d2" style="flex:1;">
        <div class="pkick" style="margin-bottom:14px;">Business impact</div>
        <div style="flex:1;display:flex;flex-direction:column;justify-content:center;">{impacts}</div>
      </div>""")}
    </div>
  </div>
  {foot("challenge")}
</section>''')

    # ---- 4 OPPORTUNITY / BUSINESS CASE ----
    drivers = ''.join(
        f'<li><span class="pn">{i+1:02d}</span><div><b>{esc(r.get("driver"))}</b>'
        f'<span>{esc(r.get("detail"))}</span></div></li>'
        for i, r in enumerate(deck.table('opportunity', 'drivers')[:4]))
    align = ' <span style="color:var(--line-2);padding:0 12px;">-</span> '.join(
        f'<span style="font-family:var(--mono);font-size:15.5px;font-weight:600;color:var(--slate);">{esc(a)}</span>'
        for a in deck.list('opportunity', 'alignment')[:4])
    inaction = deck.text('opportunity', 'inaction').strip()
    action = deck.text('opportunity', 'action').strip()
    opp_panel = ''
    if inaction or action:
        parts = []
        if inaction:
            parts.append(f'''<div>
          <div class="pkick" style="margin-bottom:12px;">Cost of inaction</div>
          <p style="margin:0;font-size:18px;line-height:1.55;color:rgba(255,255,255,.78);">{esc(inaction)}</p>
        </div>''')
        if action:
            rule = 'border-top:1px solid rgba(255,255,255,.16);padding-top:26px;' if inaction else ''
            parts.append(f'''<div style="{rule}">
          <div class="pkick" style="margin-bottom:12px;color:#5BC894;">Benefit of acting now</div>
          <p style="margin:0;font-size:18px;line-height:1.55;color:rgba(255,255,255,.78);">{esc(action)}</p>
        </div>''')
        opp_panel = f'<div class="panel anim d2" style="flex:1;justify-content:center;gap:30px;">{"".join(parts)}</div>'
    out.append(f'''<section class="slide"{skip_attr(deck.enabled("opportunity"))} data-screen-label="04 Opportunity">
  {header("opportunity")}
  <div class="body">
    {intro("opportunity")}
    <div style="display:flex;gap:64px;flex:1;align-items:stretch;">
      {when(drivers, f"""<div class="anim d1" style="flex:1.35;display:flex;flex-direction:column;">
        <div class="kicker" style="margin-bottom:10px;">Market &amp; internal drivers</div>
        <ul class="plist">{drivers}</ul>
      </div>""")}
      {opp_panel}
    </div>
    {when(align, f"""<div class="anim d3" style="display:flex;align-items:center;gap:22px;border-top:1px solid var(--line);padding-top:22px;margin-top:30px;">
      <span class="kicker" style="flex:none;">Strategic alignment</span><div>{align}</div>
    </div>""")}
  </div>
  {foot("opportunity")}
</section>''')

    # ---- 5 SOLUTION ----
    layers = deck.table('solution', 'arch_layers')
    layer_html = []
    for li, lr in enumerate(layers):
        nodes = ''.join(
            f'<div class="node{" edge" if li == 1 else ""}">{esc(n.strip())}</div>'
            for n in str(lr.get('nodes', '')).split(',') if n.strip()) or '<div style="flex:1;"></div>'
        layer_html.append(f'<div class="layer">{nodes}</div>')
        if li < len(layers) - 1:
            layer_html.append('<svg width="20" height="18" viewBox="0 0 20 22" style="stroke:var(--line-2);stroke-width:2;fill:none;"><path d="M10 0v18"/><path d="m3 12 7 7 7-7"/></svg>')
    smap = ''.join(
        f'<div class="maprow"><span class="need">{esc(r.get("need"))}</span>'
        f'{_svg(I_ARROW, "icon", "width:24px;height:24px;")}'
        f'<span class="sol">{esc(r.get("solution"))}</span></div>'
        for r in deck.table('solution', 'solution_map'))
    caption = deck.text('solution', 'arch_caption').strip()
    out.append(f'''<section class="slide"{skip_attr(deck.enabled("solution"))} data-screen-label="05 Proposed Solution">
  {header("solution")}
  <div class="body">
    {intro("solution")}
    <div class="split" style="flex:1;">
      {when(layers or caption, f"""<div class="cell anim d1" style="flex:1.25;justify-content:center;">
        <div class="kicker" style="margin-bottom:28px;">Target architecture</div>
        <div class="arch">{''.join(layer_html)}
          {when(caption, f'<div style="font-family:var(--mono);font-size:12.5px;letter-spacing:.14em;color:var(--muted);margin-top:8px;text-transform:uppercase;">{esc(caption)}</div>')}
        </div>
      </div>""")}
      {when(smap, f"""<div class="cell anim d2" style="flex:1;justify-content:center;">
        <div class="kicker" style="margin-bottom:22px;">Business need &nbsp;->&nbsp; our solution</div>
        <div>{smap}</div>
      </div>""")}
    </div>
  </div>
  {foot("solution")}
</section>''')

    # ---- 6 KEY BENEFITS ----
    ben_icons = [I_TREND, I_CHART, I_USER, I_SHIELD, I_REFRESH, I_CLOCK]
    bens = ''.join(
        f'''<div style="border-top:3px solid var(--navy);padding-top:20px;">
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <span class="isq" style="width:48px;height:48px;display:grid;place-items:center;background:rgba(159,28,51,.08);">{_svg(ben_icons[i % 6], "icon lg")}</span>
          <span style="font-family:var(--display);font-weight:800;font-size:46px;letter-spacing:-.02em;color:var(--accent);">{esc(r.get("metric"))}</span>
        </div>
        <b style="display:block;font-family:var(--display);font-size:21px;font-weight:700;color:var(--ink);margin:16px 0 7px;">{esc(r.get("title"))}</b>
        <p style="margin:0;font-size:16.5px;line-height:1.5;color:var(--muted);">{esc(r.get("desc"))}</p></div>'''
        for i, r in enumerate(deck.table('benefits', 'items')[:6]))
    out.append(f'''<section class="slide"{skip_attr(deck.enabled("benefits"))} data-screen-label="06 Key Benefits">
  {header("benefits")}
  <div class="body">
    {intro("benefits")}
    <div class="anim d1" style="flex:1;display:grid;grid-template-columns:repeat(3,1fr);gap:44px 56px;align-content:center;">{bens}</div>
  </div>
  {foot("benefits")}
</section>''')

    # ---- 7 APPROACH & METHODOLOGY ----
    methods = ' <span style="color:var(--line-2);padding:0 14px;">/</span> '.join(
        f'<span style="font-family:var(--mono);font-size:16px;font-weight:600;color:var(--navy);">{esc(m)}</span>'
        for m in deck.list('approach', 'methodologies'))
    phases = ''.join(
        f'<div class="pstep"><span class="pq">{i+1}</span><b>{esc(r.get("name"))}</b>'
        f'<p>{esc(r.get("desc"))}</p></div>'
        for i, r in enumerate(deck.table('approach', 'phases')))
    collab = deck.text('approach', 'collaboration').strip()
    out.append(f'''<section class="slide"{skip_attr(deck.enabled("approach"))} data-screen-label="07 Approach">
  {header("approach")}
  <div class="body">
    {intro("approach")}
    {when(methods, f"""<div class="anim d1" style="display:flex;align-items:center;gap:26px;padding-bottom:24px;border-bottom:1px solid var(--line);">
      <div class="kicker">Delivery methodology</div><div>{methods}</div>
    </div>""")}
    <div class="anim d2" style="flex:1;display:flex;flex-direction:column;justify-content:center;">
      {when(phases, f"""<div class="kicker" style="margin-bottom:20px;">Phased plan</div>
      <div class="pstrip">{phases}</div>""")}
    </div>
    {when(collab, f"""<div class="band anim d3">
      {_svg(I_USER, "icon lg", "stroke:var(--accent-2);width:42px;height:42px;flex:0 0 42px;")}
      <div>
        <div class="sectionhint" style="color:var(--accent-2);">How we'll work with you</div>
        <p style="margin:8px 0 0;font-size:18px;line-height:1.55;color:rgba(255,255,255,.8);">{esc(collab)}</p>
      </div>
    </div>""")}
  </div>
  {foot("approach")}
</section>''')

    # ---- 8 ROADMAP ----
    bars, total = gantt_geometry(deck)
    unit_prefix, unit_word = gantt_unit(deck)
    months = max(int(round(total)), 1)
    shown = min(months, 18)
    grid_bg = f'background-image:repeating-linear-gradient(90deg,var(--line) 0,var(--line) 1px,transparent 1px,transparent {100/shown:.4f}%);'
    month_cells = ''.join(f'<div>{unit_prefix}{i+1}</div>' for i in range(shown))
    rows_html = []
    for b in bars:
        cls = 'gbar hot' if b['milestone'] else 'gbar'
        ms = f'<span class="gms" style="left:{b["end"]}%;"></span>' if b['milestone'] else ''
        rows_html.append(f'''<div style="display:grid;grid-template-columns:190px 1fr;gap:26px;align-items:center;border-bottom:1px solid var(--line);">
        <div style="font-weight:700;font-size:18.5px;padding:14px 0;">{esc(b["name"])}</div>
        <div class="gtrack" style="{grid_bg}">
          <div class="{cls}" style="left:{b["left"]}%;width:{b["width"]}%;"></div>{ms}
        </div></div>''')
    ms_legend = when(any(b['milestone'] for b in bars), '''<div style="display:flex;gap:30px;margin-top:28px;font-family:var(--mono);font-size:14px;color:var(--muted);">
        <span style="display:flex;align-items:center;gap:10px;"><span style="width:13px;height:13px;background:var(--accent);transform:rotate(45deg);display:inline-block;"></span> Milestone gate</span>
      </div>''')
    out.append(f'''<section class="slide"{skip_attr(deck.enabled("roadmap"))} data-screen-label="08 Roadmap">
  {header("roadmap")}
  <div class="body">
    {intro("roadmap")}
    {when(rows_html, f"""<div class="anim d1" style="flex:1;display:flex;flex-direction:column;justify-content:center;">
      <div style="display:grid;grid-template-columns:190px 1fr;gap:26px;font-family:var(--mono);font-size:13px;font-weight:700;letter-spacing:.08em;color:var(--muted);border-bottom:2.5px solid var(--navy);padding-bottom:12px;">
        <div style="text-transform:uppercase;">Phase</div><div style="display:grid;grid-template-columns:repeat({shown},1fr);">{month_cells}</div></div>
      <div style="display:flex;flex-direction:column;">{''.join(rows_html)}</div>
      {ms_legend}
    </div>""")}
  </div>
  {foot("roadmap")}
</section>''')

    # ---- 9 RISK ----
    rrows = ''.join(
        f'<tr><td style="font-weight:700;">{esc(r.get("risk"))}</td>'
        f'<td><span class="dotlabel"><span class="rdot {risk_class(r.get("probability"))}"></span>{esc(r.get("probability"))}</span></td>'
        f'<td>{esc(r.get("mitigation"))}</td></tr>'
        for r in deck.table('risk', 'risks'))
    out.append(f'''<section class="slide"{skip_attr(deck.enabled("risk"))} data-screen-label="09 Risks & Mitigations">
  {header("risk")}
  <div class="body">
    {intro("risk")}
    {when(rrows, f"""<div class="anim d1" style="flex:1;display:flex;flex-direction:column;justify-content:center;">
      <table class="fin"><thead><tr><th style="width:30%;">Risk</th><th style="width:16%;">Probability</th><th>Mitigation</th></tr></thead><tbody>{rrows}</tbody></table>
      <div style="display:flex;gap:30px;margin-top:26px;font-family:var(--mono);font-size:14px;color:var(--muted);">
        <span class="dotlabel"><span class="rdot g"></span> Low</span><span class="dotlabel"><span class="rdot a"></span> Medium</span><span class="dotlabel"><span class="rdot r"></span> High</span>
      </div>
    </div>""")}
  </div>
  {foot("risk")}
</section>''')

    # ---- 10 TEAM ----
    members = ''.join(
        f'<div class="mrow">{_avatar(56)}<div><b>{esc(r.get("name"))}</b>'
        f'<div class="role">{esc(r.get("role"))}</div><p>{esc(r.get("resp"))}</p></div></div>'
        for r in deck.table('team', 'members'))
    lead_name = deck.text('team', 'lead_name').strip()
    lead_title = deck.text('team', 'lead_title').strip()
    lead_resp = deck.text('team', 'lead_resp').strip()
    lead_panel = when(lead_name or lead_title or lead_resp, f'''<div class="panel anim d1" style="flex:0 0 430px;justify-content:center;gap:18px;">
        <div class="pkick">Engagement lead</div>
        <div class="avatar" style="width:88px;height:88px;background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.25);color:#fff;"><svg viewBox="0 0 24 24">{I_USER}</svg></div>
        <div>
          {when(lead_name, f'<div style="font-family:var(--display);font-weight:800;font-size:28px;">{esc(lead_name)}</div>')}
          {when(lead_title, f'<div style="font-family:var(--mono);font-size:14px;color:var(--accent-2);margin-top:6px;letter-spacing:.06em;text-transform:uppercase;">{esc(lead_title)}</div>')}
        </div>
        {when(lead_resp, f'<p style="margin:0;font-size:17.5px;line-height:1.55;color:rgba(255,255,255,.74);">{esc(lead_resp)}</p>')}
      </div>''')
    # One-line resourcing summary so the Team slide already answers "how many
    # people, where" - the full plan is on the Team Composition slide.
    plan = resource_plan(deck) if deck.enabled('resourcing') else None
    glance = ''
    if plan:
        facts = [f'<b>{fmt_num(plan["count"])}</b> people', plan_split_text(plan),
                 f'<b>{fmt_num(plan["total"])}</b> person-days',
                 f'<b>{plan["n"]}</b> {plan["word"]}{"s" if plan["n"] != 1 else ""}']
        glance = f'''<div class="anim d3" style="display:flex;align-items:center;gap:26px;border-top:1px solid var(--line);padding-top:20px;margin-top:28px;">
      <span class="kicker" style="flex:none;">Team at a glance</span>
      <span style="font-family:var(--mono);font-size:16px;color:var(--slate);">{' <span style="color:var(--line-2);padding:0 10px;">|</span> '.join(facts)}</span>
      <span style="margin-left:auto;font-family:var(--mono);font-size:13px;letter-spacing:.08em;color:var(--muted);text-transform:uppercase;">Resource plan -> slide {pos["resourcing"][0]}</span>
    </div>'''
    out.append(f'''<section class="slide"{skip_attr(deck.enabled("team"))} data-screen-label="10 Team">
  {header("team")}
  <div class="body">
    {intro("team")}
    <div style="display:flex;gap:64px;flex:1;align-items:stretch;">
      {lead_panel}
      {when(members, f"""<div class="anim d2" style="flex:1;display:flex;flex-direction:column;justify-content:center;min-width:0;">
        <div class="kicker" style="margin-bottom:10px;">Core delivery team</div>
        <div class="mgrid">{members}</div>
      </div>""")}
    </div>
    {glance}
  </div>
  {foot("team")}
</section>''')

    # ---- 11 TEAM COMPOSITION & EFFORT ----
    out.append(_resourcing_slide(deck, header, foot, intro, when))

    # ---- 11 INVESTMENT & ROI ----
    prows = ''.join(
        f'<tr><td class="num">{esc(r.get("phase"))}</td><td>{esc(r.get("deliverable"))}</td>'
        f'<td>{esc(r.get("duration"))}</td><td style="text-align:right;font-weight:700;">{esc(r.get("investment"))}</td></tr>'
        for r in deck.table('pricing', 'phases'))
    roi = ''.join(
        f'''<div style="flex:1;border-top:3px solid var(--navy);padding-top:14px;">
        <div style="font-family:var(--display);font-weight:800;font-size:38px;letter-spacing:-.02em;color:var(--accent);">{esc(r.get("value"))}</div>
        <div style="font-size:16.5px;font-weight:700;color:var(--ink);margin-top:5px;">{esc(r.get("label"))}</div>
        <div style="font-size:14.5px;color:var(--muted);margin-top:2px;">{esc(r.get("note"))}</div></div>'''
        for r in deck.table('pricing', 'roi')[:3])
    t_label, t_amount = deck.text('pricing', 'total_label').strip(), deck.text('pricing', 'total_amount').strip()
    total_row = when(t_label or t_amount, f'<tr class="total"><td colspan="3">{esc(t_label)}</td><td style="text-align:right;font-size:25px;">{esc(t_amount)}</td></tr>')
    rec = [deck.text('pricing', k).strip() for k in ('rec_name', 'rec_desc', 'rec_price')]
    alt = [deck.text('pricing', k).strip() for k in ('alt_name', 'alt_desc', 'alt_price')]
    rec_box = when(any(rec), f'''<div class="recbox">
          <span class="rtag">RECOMMENDED</span>
          {when(rec[0], f"<h3>{esc(rec[0])}</h3>")}
          {when(rec[1], f"<p>{esc(rec[1])}</p>")}
          {when(rec[2], f'<div class="rprice">{esc(rec[2])}</div>')}
        </div>''')
    alt_box = when(any(alt), f'''<div class="altbox">
          <h3>Alternative{": " + esc(alt[0]) if alt[0] else ""}</h3>
          {when(alt[1], f"<p>{esc(alt[1])}</p>")}
          {when(alt[2], f'<div class="aprice">{esc(alt[2])}</div>')}
        </div>''')
    price_left = ''
    if prows or total_row or roi:
        price_left = f'''<div class="anim d1" style="flex:1.7;display:flex;flex-direction:column;">
        {when(prows or total_row, f"""<div class="kicker" style="margin-bottom:22px;">Pricing by phase</div>
        <table class="fin"><thead><tr><th>Phase</th><th>Deliverable</th><th>Duration</th><th style="text-align:right;">Investment</th></tr></thead>
        <tbody>{prows}{total_row}</tbody></table>""")}
        {when(roi, f"""<div style="margin-top:auto;padding-top:30px;">
          <div class="kicker" style="margin-bottom:18px;">The return</div>
          <div style="display:flex;gap:40px;">{roi}</div>
        </div>""")}
      </div>'''
    out.append(f'''<section class="slide"{skip_attr(deck.enabled("pricing"))} data-screen-label="12 Investment & ROI">
  {header("pricing")}
  <div class="body">
    <div style="display:flex;gap:64px;flex:1;align-items:stretch;">
      {price_left}
      {when(rec_box or alt_box, f"""<div class="anim d2" style="flex:1;display:flex;flex-direction:column;gap:26px;justify-content:center;">
        {rec_box}
        {alt_box}
      </div>""")}
    </div>
  </div>
  {foot("pricing")}
</section>''')

    # ---- 12 SUCCESS METRICS & KPIs ----
    krows = ''.join(
        f'<tr><td style="font-weight:700;">{esc(r.get("kpi"))}</td>'
        f'<td style="color:var(--muted);">{esc(r.get("baseline"))}</td>'
        f'<td class="num">{esc(r.get("target"))}</td>'
        f'<td style="font-family:var(--mono);">{esc(r.get("when"))}</td></tr>'
        for r in deck.table('kpis', 'rows')[:7])
    cadence = deck.text('kpis', 'cadence').strip()
    out.append(f'''<section class="slide"{skip_attr(deck.enabled("kpis"))} data-screen-label="13 Success Metrics">
  {header("kpis")}
  <div class="body">
    {intro("kpis")}
    <div class="anim d1" style="flex:1;display:flex;flex-direction:column;justify-content:center;">
      {when(krows, f"""<table class="fin"><thead><tr><th style="width:36%;">KPI</th><th style="width:20%;">Baseline</th><th style="width:20%;">Target</th><th>Lands by</th></tr></thead><tbody>{krows}</tbody></table>""")}
    </div>
    {when(cadence, f"""<div class="anim d2" style="border-left:4px solid var(--accent);padding:6px 0 6px 26px;margin-top:30px;">
      <p style="margin:0;font-size:18px;line-height:1.55;color:var(--muted);max-width:1300px;">{esc(cadence)}</p>
    </div>""")}
  </div>
  {foot("kpis")}
</section>''')

    # ---- 13 NEXT STEPS ----
    nrows = deck.table('nextsteps', 'steps')
    steps = ''.join(
        f'<div class="nstep"><div class="nn">{i+1:02d}</div><h3>{esc(r.get("title"))}</h3>'
        f'<p>{esc(r.get("desc"))}</p><div class="when">{esc(r.get("when"))}</div></div>'
        for i, r in enumerate(nrows))
    dl = [deck.text('nextsteps', k).strip() for k in ('deadline_label', 'deadline_date', 'deadline_note')]
    poc_name = deck.text('nextsteps', 'poc_name').strip()
    poc_line = join_filled(' - ', deck.text('nextsteps', 'poc_email'), deck.text('nextsteps', 'poc_phone'))
    dl_html = when(any(dl), f'''{_svg(I_CAL, "icon lg", "stroke:var(--accent-2);width:46px;height:46px;flex:0 0 46px;")}
      <div style="flex:1.3;">
        {when(dl[0], f'<div class="sectionhint" style="color:var(--accent-2);">{esc(dl[0])}</div>')}
        {when(dl[1], f'<div style="font-family:var(--display);font-weight:800;font-size:33px;margin-top:5px;">{esc(dl[1])}</div>')}
        {when(dl[2], f'<div style="color:rgba(255,255,255,.65);font-size:16.5px;margin-top:3px;">{esc(dl[2])}</div>')}
      </div>''')
    poc_html = when(poc_name or poc_line, f'''<div style="flex:1;display:flex;align-items:center;gap:22px;">
        <div class="avatar" style="width:68px;height:68px;flex:0 0 68px;background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.25);color:#fff;"><svg viewBox="0 0 24 24">{I_USER}</svg></div>
        <div>
          <div class="sectionhint" style="color:var(--accent-2);">Your point of contact</div>
          {when(poc_name, f'<div style="font-weight:700;font-size:22px;margin-top:5px;">{esc(poc_name)}</div>')}
          {when(poc_line, f'<div style="color:rgba(255,255,255,.65);font-size:16px;font-family:var(--mono);margin-top:3px;">{poc_line}</div>')}
        </div>
      </div>''')
    out.append(f'''<section class="slide"{skip_attr(deck.enabled("nextsteps"))} data-screen-label="14 Next Steps">
  {header("nextsteps")}
  <div class="body">
    {when(steps, f"""<div class="nsteps anim d1" style="grid-template-columns:repeat({min(max(len(nrows), 1), 4)},1fr);flex:1;align-content:center;">{steps}</div>""")}
    {when(dl_html or poc_html, f"""<div class="band anim d2"{"" if steps else ' style="margin-top:auto;margin-bottom:auto;"'}>
      {dl_html}
      {when(dl_html and poc_html, '<div class="bdiv"></div>')}
      {poc_html}
    </div>""")}
  </div>
  {foot("nextsteps")}
</section>''')

    # ---- 14 THANK YOU ----
    out.append(f'''<section class="slide dark"{skip_attr(deck.enabled("thankyou"))} data-screen-label="15 Thank You">
  <div class="circuit"></div>
  <div class="glow" style="width:620px;height:620px;background:var(--accent);left:-160px;top:-160px;opacity:.4;"></div>
  <div class="glow" style="width:520px;height:520px;background:var(--accent-2);right:-160px;bottom:-200px;opacity:.32;"></div>
  <div class="body" style="position:relative;z-index:2;justify-content:center;padding:0 var(--pad);">
    <div class="anim d1" style="max-width:1300px;">
      <div class="eyebrow" style="color:#fff;margin-bottom:26px;">Let's build it together</div>
      <h1 style="font-family:var(--display);font-weight:800;font-size:104px;line-height:1;letter-spacing:-.025em;margin:0 0 30px;">{esc(deck.text("thankyou","headline"))}</h1>
      {when(filled(deck.text("thankyou","message")), f'<p style="font-size:27px;line-height:1.55;color:rgba(255,255,255,.78);max-width:920px;margin:0 0 56px;">{esc(deck.text("thankyou","message"))}</p>')}
      <div style="display:flex;gap:70px;flex-wrap:wrap;">
        {labelled("Email", deck.text("thankyou","email"), "font-family:var(--mono);")}
        {labelled("Phone", deck.text("thankyou","phone"), "font-family:var(--mono);")}
        {labelled("Web", deck.text("thankyou","web"), "font-family:var(--mono);")}
      </div>
    </div>
  </div>
  <div style="position:absolute;bottom:54px;left:var(--pad);right:var(--pad);z-index:2;display:flex;align-items:center;justify-content:space-between;">
    <div class="bar-logo" style="font-size:23px;"><span class="mark" style="width:42px;height:42px;font-size:20px;">{letter}</span> {short}&nbsp;<span style="font-weight:500;color:rgba(255,255,255,.6);">{esc(deck.m("brand_name"))}</span></div>
    <div class="sectionhint" style="color:rgba(255,255,255,.5);">{esc(deck.m("confidential"))} - {esc(deck.m("doc_date"))} - {esc(deck.m("doc_version"))}</div>
  </div>
</section>''')

    return '\n'.join(out)
