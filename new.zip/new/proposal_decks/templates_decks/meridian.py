"""
Meridian - luxe editorial consulting deck.

A distinct *left-rail* layout: every slide carries a deep-teal sidebar holding
the brand, a large serif slide number, the section eyebrow + title and the
confidentiality footer, with the content set on a warm ivory canvas to the
right. Deep-teal + gold accents and Georgia serif headings give it a premium,
print-like feel - structurally unlike the other themes (which run a full-width
header bar across the top).

Renders the full canonical 15-slide proposal set defined in schema.py.

Self-contained and fully offline: no web-font imports. Headings use the system
serif (Georgia / Times) so the elegant serif character survives with no
internet connection; body/mono fall back to the platform UI + mono fonts.
"""

from __future__ import annotations

from ..render_common import (
    Deck, esc, esc_br, footer_positions, gantt_geometry, gantt_unit, skip_attr, risk_class,
    filled, join_filled, resource_plan, plan_split_text, fmt_num,
    effort_matrix_html, effort_summary_html,
)
from ..schema import SLIDE_BY_KEY

META = {
    'id': 'meridian',
    'name': 'Meridian - Teal & Gold',
    'tagline': 'Left-rail editorial layout, deep-teal & gold, elegant serif headings. Premium consulting.',
    'body_bg': '#0F4C4A',
    'accent': '#0F4C4A',
}

# --- stroke icon library ---------------------------------------------------
I_ALERT = '<path d="M10.3 3.8 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.8a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/>'
I_SHIELD = '<path d="M12 2 3 7v6c0 5 3.8 8.5 9 9 5.2-.5 9-4 9-9V7z"/><path d="m9 12 2 2 4-4"/>'
I_TREND = '<path d="M3 17l6-6 4 4 8-8"/><path d="M21 7v6"/><path d="M21 7h-6"/>'
I_CHART = '<path d="M3 3v18h18"/><path d="M19 9l-5 5-4-4-3 3"/>'
I_CHECK = '<path d="M20 6 9 17l-5-5"/>'
I_DASH = '<path d="M5 12h14"/>'
I_CLOCK = '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'
I_REFRESH = '<path d="M21 12a9 9 0 1 1-9-9"/><path d="M21 5v4h-4"/>'
I_LOCK = '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>'
I_ARROW = '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>'
I_CAL = '<path d="M8 2v4M16 2v4M3 10h18"/><rect x="3" y="4" width="18" height="18" rx="2"/><path d="m9 16 2 2 4-4"/>'
I_USER = '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>'
STACK_ICONS = [
    '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/>',
    '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
    '<path d="M17.5 19a4.5 4.5 0 0 0 .5-9 6 6 0 0 0-11.5-2A4 4 0 0 0 6 19z"/>',
    '<circle cx="12" cy="12" r="3"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4M5 5l3 3M16 16l3 3M19 5l-3 3M8 16l-3 3"/>',
]

CSS = r"""
:root{
  --teal:#0F4C4A;--teal2:#13635F;--teal-d:#0A3735;--gold:#C2883A;--gold-l:#E0B05E;
  --ivory:#F6F3EA;--paper:#FFFFFF;--fg:#1C2B2A;--muted:#6A746F;--line:#E7DFCF;--line2:#DED3BC;
  --danger:#B4453B;--green:#2E7D5B;--amber:#C2883A;
  --serif:Georgia,'Times New Roman','Times',serif;
  --body:'Segoe UI',system-ui,-apple-system,'Helvetica Neue',Arial,sans-serif;
  --mono:'Consolas','SFMono-Regular','Courier New',monospace;
}
*{box-sizing:border-box;}
.slide.md{display:flex;background:var(--ivory);font-family:var(--body);color:var(--fg);overflow:hidden;}
.md-rail{flex:0 0 440px;background:radial-gradient(130% 130% at 85% 0%,var(--teal2) 0%,var(--teal) 48%,var(--teal-d) 100%);color:var(--ivory);padding:70px 52px;display:flex;flex-direction:column;justify-content:space-between;position:relative;overflow:hidden;}
.md-rail::after{content:"";position:absolute;right:0;top:0;bottom:0;width:5px;background:linear-gradient(180deg,var(--gold-l),var(--gold));}
.md-brand{display:flex;align-items:center;gap:12px;font:700 19px var(--serif);position:relative;z-index:1;}
.md-brand .mk{width:40px;height:40px;border-radius:8px;background:linear-gradient(135deg,var(--gold),var(--gold-l));color:#3a2606;display:grid;place-items:center;font:800 18px var(--serif);flex:none;}
.md-brand .sub{font:400 13px var(--body);opacity:.72;}
.md-rmid{position:relative;z-index:1;}
.md-rail .num{font:700 96px/1 var(--serif);color:var(--gold-l);opacity:.92;}
.md-rail .eyebrow{font:600 13px var(--mono);letter-spacing:.26em;text-transform:uppercase;color:rgba(255,255,255,.62);margin:20px 0 0;}
.md-rail h2{font:700 42px/1.12 var(--serif);margin:14px 0 0;letter-spacing:-.01em;}
.md-rail .rule{width:64px;height:3px;background:var(--gold);margin-top:24px;}
.md-foot{font:600 12px var(--mono);letter-spacing:.07em;color:rgba(255,255,255,.55);display:flex;flex-direction:column;gap:7px;position:relative;z-index:1;}
.md-foot .conf{color:var(--gold-l);letter-spacing:.14em;}
.md-main{flex:1 1 auto;min-width:0;padding:62px 70px;display:flex;flex-direction:column;}
.md-lead{font:400 25px/1.55 var(--body);color:var(--fg);max-width:1180px;}
.md-lead strong{color:var(--teal);font-weight:600;}
.md-hint{font:700 13px var(--mono);letter-spacing:.2em;text-transform:uppercase;color:var(--gold);}
.md-row{display:flex;gap:26px;}.md-col{display:flex;flex-direction:column;}
.md-grid{display:grid;gap:22px;}
.md-card{background:var(--paper);border:1px solid var(--line);border-radius:6px;padding:28px 30px;}
.md-card h3{font:700 22px var(--serif);margin:0 0 12px;color:var(--teal);}
.md-stat{background:var(--paper);border:1px solid var(--line);border-radius:6px;border-top:4px solid var(--gold);padding:30px;display:flex;flex-direction:column;gap:12px;}
.md-stat .ic{width:54px;height:54px;border-radius:50%;background:rgba(15,76,74,.08);color:var(--teal);display:grid;place-items:center;}
.md-stat .lbl{font:600 12px var(--mono);letter-spacing:.18em;text-transform:uppercase;color:var(--muted);}
.md-stat .big{font:700 46px/1 var(--serif);color:var(--teal);}
.md-stat h4{margin:0;font:700 21px var(--serif);color:var(--fg);}
.md-stat p{margin:0;font-size:17px;line-height:1.5;color:var(--muted);}
.ic svg,.md-ic{width:28px;height:28px;stroke:currentColor;stroke-width:1.7;fill:none;stroke-linecap:round;stroke-linejoin:round;}
.md-tbl{width:100%;border-collapse:collapse;background:var(--paper);border:1px solid var(--line);font-size:18px;}
.md-tbl th{background:var(--teal);color:var(--ivory);text-align:left;font:600 14px var(--serif);letter-spacing:.03em;padding:15px 22px;text-transform:uppercase;}
.md-tbl td{padding:14px 22px;border-top:1px solid var(--line);color:var(--fg);vertical-align:top;line-height:1.45;}
.md-tbl tr:nth-child(even) td{background:#FAF7EF;}
.md-tbl .num{font-family:var(--mono);color:var(--gold);font-weight:700;}
.md-chips{display:flex;flex-wrap:wrap;gap:10px;}
.md-chip{font:600 15px var(--body);padding:8px 16px;border-radius:999px;background:rgba(15,76,74,.07);border:1px solid var(--line);color:var(--teal);}
.md-chip.plain{background:var(--paper);color:var(--fg);}
.md-num{width:46px;height:46px;border-radius:50%;flex:none;background:var(--teal);color:var(--ivory);display:grid;place-items:center;font:700 21px var(--serif);}
.md-pain{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:18px;flex:1;justify-content:center;}
.md-pain li{display:flex;gap:14px;align-items:flex-start;font-size:17px;line-height:1.45;}
.md-pain .bi{flex:none;width:32px;height:32px;border-radius:50%;display:grid;place-items:center;background:rgba(180,69,59,.1);color:var(--danger);}
.md-pain .bi svg{width:17px;height:17px;}
.md-pain b{display:block;color:var(--fg);}.md-pain span{color:var(--muted);font-size:15px;}
.md-rdot{width:12px;height:12px;border-radius:50%;display:inline-block;}
.md-rdot.r{background:var(--danger);}.md-rdot.a{background:var(--amber);}.md-rdot.g{background:var(--green);}
.md-dotlabel{display:inline-flex;align-items:center;gap:9px;font:700 15px var(--mono);}
.md-team{flex:0 1 290px;max-width:320px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:10px;padding:24px 18px;}
.md-shot{border-radius:50%;background:rgba(15,76,74,.08);border:1px solid var(--line);display:grid;place-items:center;color:var(--teal);}
.md-shot svg{width:54%;height:54%;stroke:currentColor;stroke-width:1.7;fill:none;stroke-linecap:round;stroke-linejoin:round;}
.md-role{font:700 12px var(--mono);color:var(--gold);text-transform:uppercase;letter-spacing:.05em;}
.md-stackh{display:flex;align-items:center;gap:12px;font:700 20px var(--serif);color:var(--teal);padding-bottom:12px;margin-bottom:12px;border-bottom:1px solid var(--line);}
.md-stack ul{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:12px;}
.md-stack li{font-size:17px;color:var(--fg);padding-left:18px;position:relative;}
.md-stack li::before{content:"";position:absolute;left:0;top:8px;width:7px;height:7px;border-radius:50%;background:var(--gold);}
.md-cert{display:flex;align-items:center;gap:14px;}
.md-seal{width:52px;height:52px;border-radius:50%;border:2px solid var(--gold);color:var(--gold);display:grid;place-items:center;font:800 12px var(--mono);flex:none;}
.md-cert b{display:block;font:700 19px var(--serif);color:var(--fg);}
.md-cert div div{color:var(--muted);font-size:15px;margin-top:2px;}
.md-future{list-style:none;margin:8px 0 0;padding:0;display:flex;flex-direction:column;gap:7px;}
.md-future li{font-size:15px;color:var(--muted);line-height:1.4;padding-left:16px;position:relative;}
.md-future li::before{content:"";position:absolute;left:0;top:8px;width:6px;height:6px;border-radius:50%;background:var(--gold);}
.md-gloss td b{color:var(--fg);font-family:var(--serif);}
.md-gtrack{position:relative;height:40px;background:var(--paper);border:1px solid var(--line);border-radius:6px;}
.md-gbar{position:absolute;top:6px;bottom:6px;border-radius:5px;background:linear-gradient(90deg,var(--teal),var(--teal2));}
.md-gms{position:absolute;top:50%;width:16px;height:16px;background:var(--gold);border:3px solid var(--ivory);border-radius:50%;transform:translate(-50%,-50%);box-shadow:0 0 0 1px var(--gold);}
.md-vtl{position:relative;display:grid;align-content:center;}
.md-vtl .line{position:absolute;top:34px;left:7%;right:7%;height:3px;background:linear-gradient(90deg,var(--teal),var(--gold));}
.md-vnode{position:relative;z-index:1;display:flex;flex-direction:column;align-items:center;text-align:center;}
.md-vdot{width:68px;height:68px;border-radius:50%;background:var(--teal);color:var(--ivory);display:grid;place-items:center;font:700 20px var(--serif);border:5px solid var(--ivory);}
.md-steps{display:flex;flex-direction:column;}
.md-step{display:flex;gap:18px;align-items:flex-start;position:relative;padding-bottom:26px;}
.md-step:last-child{padding-bottom:0;}
.md-step::before{content:"";position:absolute;left:23px;top:52px;bottom:0;width:2px;background:var(--line);}
.md-step:last-child::before{display:none;}
.md-sn{flex:none;width:48px;height:48px;border-radius:50%;background:var(--teal);color:var(--ivory);display:grid;place-items:center;font:700 20px var(--serif);z-index:2;}
.md-step h4{margin:0 0 5px;font:700 20px var(--serif);color:var(--fg);}
.md-step p{margin:0;font-size:16px;color:var(--muted);line-height:1.45;}
.md-arch{flex:1;display:flex;flex-direction:column;gap:12px;align-items:center;justify-content:center;padding:24px;border:1.5px dashed var(--line2);border-radius:6px;background:repeating-linear-gradient(135deg,#EFEADD 0 14px,#F6F3EA 14px 28px);}
.md-arch .layer{display:flex;gap:14px;width:100%;}
.md-arch .node{flex:1;background:var(--paper);border:1px solid var(--line);border-radius:6px;padding:13px;text-align:center;font:600 13px var(--mono);color:var(--fg);}
.md-arch .node.edge{background:var(--teal);color:var(--ivory);border:none;}
.rx-role{font-weight:700;white-space:nowrap;}
.rx-loc{display:inline-flex;align-items:center;gap:8px;}
.rx-loc i{width:11px;height:11px;border-radius:50%;display:inline-block;flex:none;}
.rx-matrix th.c{text-align:center;padding-left:0;padding-right:0;}
.rx-dense td,.rx-dense th{font-size:13px !important;}
.rx-strip{display:grid;grid-template-columns:1fr 1.7fr 1fr 1fr;}
.rx-mix{display:flex;height:11px;overflow:hidden;}
.rx-mix span{display:block;height:100%;}
.rx-legend{display:flex;flex-direction:column;gap:6px;margin-top:11px;}
.md-tbl.rx-matrix{font-size:16px;}
.md-tbl.rx-matrix th{padding:12px 10px;font-size:12.5px;white-space:nowrap;}
.md-tbl.rx-matrix td{padding:10px 10px;}
.md-tbl .c{text-align:center;}
.md-tbl .r{text-align:right;}
.md-tbl tr.total td{background:var(--teal);color:var(--ivory);font:700 17px var(--serif);border-top:0;}
.rx-rowtotal{font-weight:700;color:var(--teal);}
.rx-zero{color:var(--line2);}
.rx-loc{font:600 13.5px var(--mono);}
.rx-loc i{box-shadow:0 0 0 1px rgba(0,0,0,.12);}
.rx-strip{background:var(--teal);color:var(--ivory);border-radius:6px;border-top:4px solid var(--gold);}
.rx-cell{padding:18px 24px;border-left:1px solid rgba(255,255,255,.14);}
.rx-cell:first-child{border-left:0;}
.rx-v{font:700 36px/1 var(--serif);color:var(--gold-l);}
.rx-l{font-size:14.5px;opacity:.8;margin-top:8px;}
.rx-mix{border-radius:999px;background:rgba(255,255,255,.14);}
.rx-mix span+span{border-left:2px solid var(--teal);}
.rx-legend{font-size:14.5px;}
.rx-strip .rx-loc{color:var(--ivory);}
/* hero (cover / thank-you) */
.slide.md-hero{position:relative;display:flex;flex-direction:column;justify-content:space-between;padding:90px 100px;background:radial-gradient(125% 125% at 82% 8%,var(--teal2) 0%,var(--teal) 46%,var(--teal-d) 100%);color:var(--ivory);overflow:hidden;font-family:var(--body);}
.md-hero .mesh{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.05) 1px,transparent 1px);background-size:66px 66px;-webkit-mask-image:radial-gradient(ellipse 80% 80% at 78% 35%,#000 30%,transparent 75%);mask-image:radial-gradient(ellipse 80% 80% at 78% 35%,#000 30%,transparent 75%);}
.md-hero .glow{position:absolute;border-radius:50%;filter:blur(120px);pointer-events:none;background:var(--gold);opacity:.22;}
.md-hero .z{position:relative;z-index:2;}
.md-hero h1{font:700 92px/1.05 var(--serif);letter-spacing:-.02em;margin:0 0 26px;}
.md-eyebrow-h{font:600 16px var(--mono);letter-spacing:.24em;text-transform:uppercase;color:var(--gold-l);}
@media (prefers-reduced-motion:no-preference){
  [data-deck-active] .anim{animation:mdrise .55s cubic-bezier(.2,.7,.3,1) both;}
  [data-deck-active] .anim.d1{animation-delay:.06s;}[data-deck-active] .anim.d2{animation-delay:.12s;}
  [data-deck-active] .anim.d3{animation-delay:.18s;}[data-deck-active] .anim.d4{animation-delay:.24s;}
  @keyframes mdrise{from{opacity:0;transform:translateY(16px);}to{opacity:1;transform:none;}}
}
"""


def _svg(paths, cls='md-ic', style=''):
    st = f' style="{style}"' if style else ''
    return f'<svg viewBox="0 0 24 24" class="{cls}"{st}>{paths}</svg>'


def _seal(name):
    import re
    token = re.sub(r'[^A-Za-z0-9]', '', (name or '').split(' ')[0])[:4]
    return esc(token.upper() or '*')


_LOC_COLOR = {'onshore': 'var(--gold-l)', 'nearshore': '#E08A5E', 'offshore': '#7FC4BE'}


def _loc_color(loc):
    return _LOC_COLOR.get((loc or '').strip().lower(), 'var(--muted)')


def _when(cond, html_):
    """Emit ``html_`` only when its content exists - no empty placeholders."""
    return html_ if cond else ''


def _resourcing_body(deck):
    """The Resource Effort Matrix + summary strip (effort only, no cost)."""
    plan = resource_plan(deck)
    if not plan:
        return ''
    return f'''<div class="anim d1" style="flex:1;min-height:0;display:flex;flex-direction:column;justify-content:center;">
        {effort_matrix_html(plan, table_cls="md-tbl", heat_rgb="194,136,58", loc_color=_loc_color)}
      </div>
      <div class="anim d2" style="margin-top:20px;">{effort_summary_html(plan, _loc_color)}</div>'''


def render(payload) -> str:
    deck = payload if isinstance(payload, Deck) else Deck(payload)
    pos = footer_positions(deck)
    short, brand = esc(deck.m('brand_short')), esc(deck.m('brand_name'))
    letter = esc(deck.m('logo_letter'))

    def rail(key):
        n, t = pos[key]
        m = SLIDE_BY_KEY[key]
        return f'''<div class="md-rail">
    <div class="md-brand"><span class="mk">{letter}</span> {short} <span class="sub">{brand}</span></div>
    <div class="md-rmid">
      <div class="num">{n}</div>
      <div class="eyebrow">{esc(m["eyebrow"])}</div>
      <h2>{esc(m["title"])}</h2>
      <div class="rule"></div>
    </div>
    <div class="md-foot"><span class="conf">{esc(deck.m("confidential")).upper()}</span><span>{esc(deck.m("doc_date"))} - {esc(deck.m("doc_version"))}</span><span>{n} / {t}</span></div>
  </div>'''

    def slide(key, body, *, label):
        return (f'<section class="slide md"{skip_attr(deck.enabled(key))} data-screen-label="{label}">'
                f'{rail(key)}<div class="md-main">{body}</div></section>')

    def lead_intro(key):
        t = (deck.text(key, 'lead') or '').strip()
        return f'<p class="md-lead anim" style="margin:0 0 28px;">{esc(t)}</p>' if t else ''

    when = _when

    def hero_item(label, value, mono=True):
        v = (value or '').strip()
        return when(v, f'<div><div style="font:600 13px var(--mono);letter-spacing:.16em;text-transform:uppercase;opacity:.55;margin-bottom:8px;">{label}</div>'
                       f'<div style="font-size:21px;font-weight:600;{"font-family:var(--mono);" if mono else ""}">{esc(v)}</div></div>')

    out = []

    # ---- 1 COVER (hero) ----
    out.append(f'''<section class="slide md-hero"{skip_attr(deck.enabled("cover"))} data-screen-label="01 Cover">
  <div class="mesh"></div>
  <div class="glow" style="width:660px;height:660px;right:-150px;top:-180px;"></div>
  <div class="z" style="display:flex;align-items:center;justify-content:space-between;">
    <div style="display:flex;align-items:center;gap:14px;font:700 24px var(--serif);"><span style="width:44px;height:44px;border-radius:9px;background:linear-gradient(135deg,var(--gold),var(--gold-l));color:#3a2606;display:grid;place-items:center;font:800 20px var(--serif);">{letter}</span> {short} <span style="font:400 15px var(--body);opacity:.72;">{brand}</span></div>
    <div style="font:600 14px var(--mono);letter-spacing:.18em;text-transform:uppercase;opacity:.65;">Technology Solution Proposal</div>
  </div>
  <div class="z anim" style="max-width:1450px;">
    {when(filled(deck.m("client_name")), f'<div class="md-eyebrow-h" style="margin-bottom:26px;">Prepared for &nbsp;-&nbsp; {esc(deck.m("client_name"))}</div>')}
    <h1>{esc_br(deck.text("cover","title"))}</h1>
    {when(filled(deck.text("cover","tagline")), f'<p style="font:400 28px/1.5 var(--body);opacity:.85;max-width:1080px;margin:0;">{esc(deck.text("cover","tagline"))}</p>')}
  </div>
  <div class="z" style="display:flex;gap:60px;align-items:flex-end;justify-content:space-between;">
    <div style="display:flex;gap:60px;">
      {hero_item("Prepared by", deck.m("brand_name"), False)}
      {hero_item("Date", deck.m("doc_date"), False)}
      {hero_item("Version", deck.m("doc_version"))}
    </div>
    {when(filled(deck.m("confidential")), f'<div style="font:600 13px var(--mono);letter-spacing:.16em;text-transform:uppercase;border:1px solid var(--gold-l);color:var(--gold-l);padding:10px 18px;border-radius:6px;">{esc(deck.m("confidential"))}</div>')}
  </div>
</section>''')

    # ---- 2 EXEC ----
    kmap = {'problem': (I_ALERT, 'var(--danger)', 'rgba(180,69,59,.1)'),
            'solution': (I_SHIELD, 'var(--teal)', 'rgba(15,76,74,.08)'),
            'value': (I_TREND, 'var(--green)', 'rgba(46,125,91,.1)')}
    boxes = []
    for i, r in enumerate(deck.table('exec', 'stats')[:3]):
        kind = (r.get('kind') or 'solution').strip().lower()
        paths, col, bg = kmap.get(kind, kmap['solution'])
        boxes.append(f'<div class="md-stat anim d{i+1}" style="border-top-color:{col};"><div class="ic" style="color:{col};background:{bg};">{_svg(paths)}</div><span class="lbl">{esc(r.get("heading"))}</span><div class="big" style="color:{col};">{esc(r.get("metric"))}</div><p>{esc(r.get("desc"))}</p></div>')
    out.append(slide('exec', f'''{when(filled(deck.text("exec","lead")), f'<p class="md-lead anim" style="margin:0 0 36px;">{esc(deck.text("exec","lead"))}</p>')}
      {when(boxes, f'<div class="md-grid anim d1" style="grid-template-columns:repeat({max(len(boxes), 1)},1fr);flex:1;align-content:center;">{"".join(boxes)}</div>')}''', label='02 Executive Summary'))

    # ---- 3 CHALLENGE ----
    pains = ''.join(
        f'<li><span class="bi">{_svg(I_ALERT)}</span><div><b>{esc(r.get("heading"))}</b><span>{esc(r.get("detail"))}</span></div></li>'
        for r in deck.table('challenge', 'pains'))
    impacts = ''.join(
        f'<div><div style="font:700 46px/1 var(--serif);color:var(--gold-l);">{esc(r.get("metric"))}</div><div style="color:rgba(255,255,255,.72);font-size:17px;margin-top:8px;">{esc(r.get("label"))}</div></div>'
        for r in deck.table('challenge', 'impacts'))
    out.append(slide('challenge', f'''<div class="md-row" style="flex:1;align-items:stretch;">
      {when(pains, f'<div class="md-card anim d1" style="flex:1;display:flex;flex-direction:column;"><h3 style="color:var(--danger);display:flex;align-items:center;gap:12px;">{_svg(I_ALERT,"md-ic","stroke:var(--danger);width:26px;height:26px;")} Current Pain Points</h3><ul class="md-pain">{pains}</ul></div>')}
      {when(impacts, f'<div class="md-card anim d2" style="flex:1;background:var(--teal);color:var(--ivory);border-color:var(--teal);display:flex;flex-direction:column;"><h3 style="color:var(--ivory);">Business Impact</h3><div style="display:grid;grid-template-columns:1fr 1fr;gap:28px;flex:1;align-content:center;">{impacts}</div></div>')}
    </div>''', label='03 Current State'))

    # ---- 4 OPPORTUNITY / BUSINESS CASE ----
    drivers = ''.join(
        f'<li><span class="bi" style="background:rgba(15,76,74,.08);color:var(--teal);">{_svg(I_TREND)}</span>'
        f'<div><b>{esc(r.get("driver"))}</b><span>{esc(r.get("detail"))}</span></div></li>'
        for r in deck.table('opportunity', 'drivers')[:4])
    align_chips = ''.join(f'<span class="md-chip">{esc(a)}</span>'
                          for a in deck.list('opportunity', 'alignment')[:4])
    opp_cards = ''
    for fk, col, label in (('inaction', 'var(--danger)', 'Cost of Inaction'), ('action', 'var(--green)', 'Benefit of Acting Now')):
        t = deck.text('opportunity', fk).strip()
        if t:
            opp_cards += (f'<div class="md-card" style="flex:1;border-top:4px solid {col};"><h3 style="color:{col};">{label}</h3>'
                          f'<p style="margin:0;font-size:17px;line-height:1.55;color:var(--muted);">{esc(t)}</p></div>')
    out.append(slide('opportunity', f'''{lead_intro('opportunity')}<div class="md-row" style="flex:1;align-items:stretch;">
      {when(drivers, f'<div class="md-card anim d1" style="flex:1.15;display:flex;flex-direction:column;"><h3 style="display:flex;align-items:center;gap:12px;">{_svg(I_TREND,"md-ic","stroke:var(--teal);width:26px;height:26px;")} Market &amp; Internal Drivers</h3><ul class="md-pain">{drivers}</ul></div>')}
      {when(opp_cards, f'<div class="md-col anim d2" style="flex:1;gap:20px;">{opp_cards}</div>')}
    </div>
    {when(align_chips, f'<div class="md-chips anim d3" style="margin-top:24px;"><span class="md-hint" style="align-self:center;">Strategic alignment</span>{align_chips}</div>')}''', label='04 Opportunity'))

    # ---- 5 SOLUTION ----
    layers = deck.table('solution', 'arch_layers')
    arch = []
    for i, lr in enumerate(layers):
        nodes = ''.join(f'<div class="node{" edge" if i==1 else ""}">{esc(nn.strip())}</div>' for nn in str(lr.get('nodes', '')).split(',') if nn.strip())
        arch.append(f'<div class="layer">{nodes}</div>')
        if i < len(layers) - 1:
            arch.append('<svg width="18" height="16" viewBox="0 0 20 22" style="stroke:var(--muted);stroke-width:2;fill:none;"><path d="M10 0v18"/><path d="m3 12 7 7 7-7"/></svg>')
    caption = deck.text('solution', 'arch_caption').strip()
    cap_html = when(caption, f'<div style="font:600 12px var(--mono);letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin-top:6px;">{esc(caption)}</div>')
    smap = ''.join(f'<tr><td>{esc(r.get("need"))}</td><td style="font-weight:700;color:var(--teal);">{esc(r.get("solution"))}</td></tr>' for r in deck.table('solution', 'solution_map'))
    out.append(slide('solution', f'''{lead_intro('solution')}<div class="md-row" style="flex:1;align-items:stretch;">
        {when(arch or caption, f'<div class="md-col anim d1" style="flex:1.2;"><span class="md-hint" style="margin-bottom:12px;">Target architecture</span><div class="md-arch">{"".join(arch)}{cap_html}</div></div>')}
        {when(smap, f'<div class="md-col anim d2" style="flex:1;"><span class="md-hint" style="margin-bottom:12px;">Pain point -> solution</span><table class="md-tbl"><thead><tr><th>Business Need</th><th>Our Solution</th></tr></thead><tbody>{smap}</tbody></table></div>')}
      </div>''', label='05 Proposed Solution'))

    # ---- 6 KEY BENEFITS ----
    ben_icons = [I_TREND, I_CHART, I_USER, I_SHIELD, I_REFRESH, I_CLOCK]
    bens = ''.join(
        f'''<div class="md-stat"><div style="display:flex;align-items:center;justify-content:space-between;">
        <div class="ic">{_svg(ben_icons[i % 6])}</div>
        <div class="big" style="font-size:40px;">{esc(r.get("metric"))}</div></div>
        <h4>{esc(r.get("title"))}</h4><p style="font-size:15.5px;">{esc(r.get("desc"))}</p></div>'''
        for i, r in enumerate(deck.table('benefits', 'items')[:6]))
    out.append(slide('benefits', f'''{lead_intro('benefits')}<div class="md-grid anim d1" style="grid-template-columns:repeat(3,1fr);flex:1;align-content:center;">{bens}</div>''', label='06 Key Benefits'))

    # ---- 7 APPROACH & METHODOLOGY ----
    methods = ''.join(f'<span class="md-chip">{esc(m)}</span>' for m in deck.list('approach', 'methodologies'))
    pcs = ''.join(f'<div class="md-card" style="flex:1;display:flex;gap:15px;align-items:flex-start;padding:22px 24px;"><span class="md-num">{i+1}</span><div><strong style="font-size:18px;color:var(--fg);">{esc(r.get("name"))}</strong><div style="color:var(--muted);font-size:15px;margin-top:4px;">{esc(r.get("desc"))}</div></div></div>' for i, r in enumerate(deck.table('approach', 'phases')))
    collab = deck.text('approach', 'collaboration').strip()
    out.append(slide('approach', f'''{lead_intro('approach')}{when(methods, f'<div class="md-row anim d1" style="margin-bottom:26px;align-items:center;"><span class="md-hint">Delivery methodology</span><div class="md-chips">{methods}</div></div>')}
      <div class="anim d2" style="flex:1;display:flex;flex-direction:column;justify-content:center;">{when(pcs, f'<span class="md-hint">Phased plan</span><div class="md-row" style="margin-top:14px;">{pcs}</div>')}</div>
      {when(collab, f"""<div class="md-card anim d3" style="background:var(--teal);color:var(--ivory);border-color:var(--teal);border-top:4px solid var(--gold);margin-top:26px;">
        <h3 style="color:var(--gold-l);">How We'll Work With You</h3>
        <p style="margin:0;font-size:17px;line-height:1.55;opacity:.88;">{esc(collab)}</p>
      </div>""")}''', label='07 Approach'))

    # ---- 8 ROADMAP ----
    bars, total = gantt_geometry(deck)
    unit_prefix, unit_word = gantt_unit(deck)
    months = max(int(round(total)), 1)
    mo_cells = ''.join(f'<div>{unit_prefix}{i+1}</div>' for i in range(min(months, 18)))
    grows = []
    for b in bars:
        ms = f'<span class="md-gms" style="left:{b["end"]}%;"></span>' if b['milestone'] else ''
        grows.append(f'<div style="display:grid;grid-template-columns:170px 1fr;gap:22px;align-items:center;"><div style="font-weight:600;font-size:17px;">{esc(b["name"])}</div><div class="md-gtrack"><div class="md-gbar" style="left:{b["left"]}%;width:{b["width"]}%;"></div>{ms}</div></div>')
    ms_legend = when(any(b['milestone'] for b in bars), '<div style="display:flex;gap:24px;margin-top:26px;font:600 14px var(--mono);color:var(--muted);"><span style="display:flex;align-items:center;gap:8px;"><span style="width:14px;height:14px;background:var(--gold);border-radius:50%;"></span> Milestone gate</span></div>')
    out.append(slide('roadmap', f'''{lead_intro('roadmap')}
      {when(grows, f"""<div class="anim d1" style="flex:1;display:flex;flex-direction:column;justify-content:center;">
        <div style="display:grid;grid-template-columns:170px 1fr;gap:22px;font:600 13px var(--mono);color:var(--muted);border-bottom:1px solid var(--line);padding-bottom:10px;margin-bottom:22px;"><div></div><div style="display:grid;grid-template-columns:repeat({min(months,18)},1fr);text-align:center;">{mo_cells}</div></div>
        <div style="display:flex;flex-direction:column;gap:16px;">{''.join(grows)}</div>
        {ms_legend}
      </div>""")}''', label='08 Roadmap'))

    # ---- 9 RISK ----
    rrows = ''.join(f'<tr><td>{esc(r.get("risk"))}</td><td><span class="md-dotlabel"><span class="md-rdot {risk_class(r.get("probability"))}"></span>{esc(r.get("probability"))}</span></td><td>{esc(r.get("mitigation"))}</td></tr>' for r in deck.table('risk', 'risks'))
    out.append(slide('risk', f'''{lead_intro('risk')}{when(rrows, f"""<div class="anim d1" style="flex:1;display:flex;flex-direction:column;justify-content:center;">
      <table class="md-tbl"><thead><tr><th style="width:30%;">Risk</th><th style="width:16%;">Probability</th><th>Mitigation</th></tr></thead><tbody>{rrows}</tbody></table>
      <div style="display:flex;gap:28px;margin-top:22px;font:600 14px var(--mono);color:var(--muted);"><span class="md-dotlabel"><span class="md-rdot g"></span> Low</span><span class="md-dotlabel"><span class="md-rdot a"></span> Medium</span><span class="md-dotlabel"><span class="md-rdot r"></span> High</span></div>
    </div>""")}''', label='09 Risks & Mitigations'))

    # ---- 10 TEAM ----
    members = deck.table('team', 'members')
    cards = ''.join(f'<div class="md-card md-team"><div class="md-shot" style="width:62px;height:62px;"><svg viewBox="0 0 24 24">{I_USER}</svg></div><div><strong style="font-size:18px;">{esc(r.get("name"))}</strong><div class="md-role">{esc(r.get("role"))}</div></div><p style="margin:0;font-size:15px;color:var(--muted);line-height:1.45;">{esc(r.get("resp"))}</p></div>' for r in members)
    ln, lt, lr = (deck.text('team', k).strip() for k in ('lead_name', 'lead_title', 'lead_resp'))
    lead_card = when(ln or lt or lr, f'''<div class="anim d1" style="display:flex;justify-content:center;margin-bottom:6px;">
        <div class="md-card" style="width:380px;text-align:center;border-top:4px solid var(--gold);display:flex;flex-direction:column;align-items:center;gap:10px;padding:24px;"><div class="md-shot" style="width:74px;height:74px;"><svg viewBox="0 0 24 24">{I_USER}</svg></div><div>{when(ln, f'<strong style="font-size:21px;">{esc(ln)}</strong>')}{when(lt, f'<div class="md-role">{esc(lt)}</div>')}</div>{when(lr, f'<p style="margin:0;font-size:15px;color:var(--muted);">{esc(lr)}</p>')}</div>
      </div>''')
    plan = resource_plan(deck) if deck.enabled('resourcing') else None
    glance = ''
    if plan:
        facts = [f'<b>{fmt_num(plan["count"])}</b> people', plan_split_text(plan),
                 f'<b>{fmt_num(plan["total"])}</b> person-days',
                 f'<b>{plan["n"]}</b> {plan["word"]}{"s" if plan["n"] != 1 else ""}']
        glance = (f'<div class="md-chips anim d3" style="margin-top:20px;align-items:center;"><span class="md-hint" style="align-self:center;">Team at a glance</span>'
                  + ''.join(f'<span class="md-chip plain">{x}</span>' for x in facts)
                  + f'<span class="md-hint" style="align-self:center;margin-left:auto;color:var(--muted);">Full plan -> slide {pos["resourcing"][0]}</span></div>')
    out.append(slide('team', f'''{lead_intro('team')}{lead_card}
      {when(lead_card and cards, '<div style="height:24px;width:2px;background:var(--line2);margin:0 auto;"></div>')}
      {when(cards, f'<div class="md-row anim d2" style="flex:1;align-items:center;justify-content:center;flex-wrap:wrap;">{cards}</div>')}
      {glance}''', label='10 Team'))

    # ---- 11 TEAM COMPOSITION & EFFORT ----
    notes = deck.text('resourcing', 'assumptions').strip()
    out.append(slide('resourcing', f'''{lead_intro('resourcing')}{_resourcing_body(deck)}
      {when(notes, f'<div class="md-card anim d3" style="border-top:4px solid var(--gold);margin-top:20px;padding:18px 26px;"><p style="margin:0;font-size:16px;line-height:1.55;color:var(--muted);">{esc(notes)}</p></div>')}''', label='11 Team Composition'))

    # ---- 12 INVESTMENT & ROI ----
    prows = ''.join(f'<tr><td class="num">{esc(r.get("phase"))}</td><td>{esc(r.get("deliverable"))}</td><td>{esc(r.get("duration"))}</td><td style="text-align:right;font-weight:700;">{esc(r.get("investment"))}</td></tr>' for r in deck.table('pricing', 'phases'))
    roi = ''.join(
        f'''<div style="flex:1;text-align:center;padding:0 10px;">
        <div style="font:700 34px/1 var(--serif);color:var(--gold);">{esc(r.get("value"))}</div>
        <div style="font-weight:700;font-size:15.5px;color:var(--fg);margin-top:7px;">{esc(r.get("label"))}</div>
        <div style="color:var(--muted);font-size:13.5px;margin-top:3px;">{esc(r.get("note"))}</div></div>'''
        for r in deck.table('pricing', 'roi')[:3])
    t_label, t_amount = deck.text('pricing', 'total_label').strip(), deck.text('pricing', 'total_amount').strip()
    total_row = when(t_label or t_amount, f'<tr style="background:var(--teal);"><td colspan="3" style="color:var(--ivory);font:700 19px var(--serif);">{esc(t_label)}</td><td style="text-align:right;color:var(--ivory);font:700 23px var(--serif);">{esc(t_amount)}</td></tr>')
    rec = [deck.text('pricing', k).strip() for k in ('rec_name', 'rec_desc', 'rec_price')]
    alt = [deck.text('pricing', k).strip() for k in ('alt_name', 'alt_desc', 'alt_price')]
    rec_card = when(any(rec), (
        '<div class="md-card" style="background:var(--teal);color:var(--ivory);border-color:var(--teal);border-top:4px solid var(--gold);"><span style="display:inline-block;background:var(--gold);color:#3a2606;font:700 12px var(--mono);padding:5px 11px;border-radius:999px;letter-spacing:.08em;margin-bottom:12px;">RECOMMENDED</span>'
        + when(rec[0], f'<h3 style="color:var(--ivory);">{esc(rec[0])}</h3>')
        + when(rec[1], f'<p style="opacity:.85;font-size:17px;line-height:1.5;margin:0 0 16px;">{esc(rec[1])}</p>')
        + when(rec[2], f'<div style="font:700 34px var(--serif);">{esc(rec[2])}</div>') + '</div>'))
    alt_card = when(any(alt), (
        f'<div class="md-card" style="flex:1;"><h3>Alternative{": " + esc(alt[0]) if alt[0] else ""}</h3>'
        + when(alt[1], f'<p style="color:var(--muted);font-size:17px;line-height:1.5;margin:0 0 12px;">{esc(alt[1])}</p>')
        + when(alt[2], f'<div style="font:700 28px var(--serif);color:var(--teal);">{esc(alt[2])}</div>') + '</div>'))
    price_left = when(prows or total_row or roi, (
        '<div class="anim d1" style="flex:1.7;">'
        + when(prows or total_row, f'<span class="md-hint">Pricing by phase</span><table class="md-tbl" style="margin-top:14px;"><thead><tr><th>Phase</th><th>Deliverable</th><th>Duration</th><th style="text-align:right;">Investment</th></tr></thead><tbody>{prows}{total_row}</tbody></table>')
        + when(roi, f'<div class="md-card" style="margin-top:{"20px" if (prows or total_row) else "0"};"><h3 style="margin-bottom:18px;">The Return</h3><div class="md-row">{roi}</div></div>')
        + '</div>'))
    out.append(slide('pricing', f'''<div class="md-row" style="flex:1;align-items:stretch;">
      {price_left}
      {when(rec_card or alt_card, f'<div class="anim d2" style="flex:1;display:flex;flex-direction:column;gap:20px;">{rec_card}{alt_card}</div>')}
    </div>''', label='12 Investment & ROI'))

    # ---- 13 SUCCESS METRICS & KPIs ----
    krows = ''.join(
        f'<tr><td style="font-weight:700;">{esc(r.get("kpi"))}</td><td style="color:var(--muted);">{esc(r.get("baseline"))}</td>'
        f'<td class="num">{esc(r.get("target"))}</td><td>{esc(r.get("when"))}</td></tr>'
        for r in deck.table('kpis', 'rows')[:7])
    cadence = deck.text('kpis', 'cadence').strip()
    out.append(slide('kpis', f'''{lead_intro('kpis')}<div class="anim d1" style="flex:1;display:flex;flex-direction:column;justify-content:center;">
      {when(krows, f'<table class="md-tbl"><thead><tr><th style="width:36%;">KPI</th><th style="width:20%;">Baseline</th><th style="width:20%;">Target</th><th>Lands by</th></tr></thead><tbody>{krows}</tbody></table>')}
    </div>
    {when(cadence, f'<div class="md-card anim d2" style="border-top:4px solid var(--gold);margin-top:22px;"><p style="margin:0;font-size:17px;line-height:1.55;color:var(--muted);">{esc(cadence)}</p></div>')}''', label='13 Success Metrics'))

    # ---- 14 NEXT STEPS ----
    steps = ''.join(f'<div class="md-step"><div class="md-sn">{i+1}</div><div><h4>{esc(r.get("title"))}</h4><p>{esc(r.get("desc"))}</p><span class="md-chip plain" style="margin-top:8px;display:inline-block;">{esc(r.get("when"))}</span></div></div>' for i, r in enumerate(deck.table('nextsteps', 'steps')))
    dl = [deck.text('nextsteps', k).strip() for k in ('deadline_label', 'deadline_date', 'deadline_note')]
    poc_name = deck.text('nextsteps', 'poc_name').strip()
    poc_lines = join_filled('<br>', deck.text('nextsteps', 'poc_email'), deck.text('nextsteps', 'poc_phone'))
    dl_card = when(any(dl), (
        f'<div class="md-card" style="background:var(--teal);color:var(--ivory);border-color:var(--teal);display:flex;align-items:center;gap:20px;">{_svg(I_CAL,"md-ic","stroke:var(--gold-l);width:42px;height:42px;flex:none;")}<div>'
        + when(dl[0], f'<div style="font:600 13px var(--mono);letter-spacing:.14em;text-transform:uppercase;color:var(--gold-l);">{esc(dl[0])}</div>')
        + when(dl[1], f'<div style="font:700 32px var(--serif);margin-top:4px;">{esc(dl[1])}</div>')
        + when(dl[2], f'<div style="opacity:.72;font-size:16px;">{esc(dl[2])}</div>') + '</div></div>'))
    poc_card = when(poc_name or poc_lines, (
        f'<div class="md-card" style="display:flex;align-items:center;gap:18px;"><div class="md-shot" style="width:70px;height:70px;flex:none;"><svg viewBox="0 0 24 24">{I_USER}</svg></div><div><div class="md-hint">Point of contact</div>'
        + when(poc_name, f'<div style="font-weight:700;font-size:21px;margin-top:4px;">{esc(poc_name)}</div>')
        + when(poc_lines, f'<div style="color:var(--muted);font:500 15px var(--mono);">{poc_lines}</div>') + '</div></div>'))
    out.append(slide('nextsteps', f'''<div class="md-row" style="flex:1;align-items:stretch;gap:40px;">
      {when(steps, f'<div class="md-col anim d1" style="flex:1.1;justify-content:center;"><span class="md-hint" style="margin-bottom:24px;">Path to mobilise</span><div class="md-steps">{steps}</div></div>')}
      {when(dl_card or poc_card, f'<div class="md-col anim d2" style="flex:.85;gap:20px;justify-content:center;">{dl_card}{poc_card}</div>')}
    </div>''', label='14 Next Steps'))

    # ---- 15 THANK YOU (hero) ----
    out.append(f'''<section class="slide md-hero"{skip_attr(deck.enabled("thankyou"))} data-screen-label="15 Thank You" style="justify-content:center;">
  <div class="mesh"></div>
  <div class="glow" style="width:620px;height:620px;left:-160px;top:-160px;"></div>
  <div class="z anim" style="max-width:1300px;">
    <div class="md-eyebrow-h" style="margin-bottom:24px;">Let's build it together</div>
    <h1 style="font-size:100px;margin-bottom:28px;">{esc(deck.text("thankyou","headline"))}</h1>
    {when(filled(deck.text("thankyou","message")), f'<p style="font:400 27px/1.55 var(--body);opacity:.85;max-width:920px;margin:0 0 52px;">{esc(deck.text("thankyou","message"))}</p>')}
    <div style="display:flex;gap:64px;flex-wrap:wrap;">
      {hero_item("Email", deck.text("thankyou","email"))}
      {hero_item("Phone", deck.text("thankyou","phone"))}
      {hero_item("Web", deck.text("thankyou","web"))}
    </div>
  </div>
  <div class="z" style="position:absolute;bottom:54px;left:100px;right:100px;display:flex;align-items:center;justify-content:space-between;">
    <div style="display:flex;align-items:center;gap:12px;font:700 22px var(--serif);"><span style="width:42px;height:42px;border-radius:9px;background:linear-gradient(135deg,var(--gold),var(--gold-l));color:#3a2606;display:grid;place-items:center;font:800 18px var(--serif);">{letter}</span> {short} <span style="font:400 14px var(--body);opacity:.72;">{brand}</span></div>
    <div style="font:600 14px var(--mono);letter-spacing:.1em;opacity:.55;">{esc(deck.m("confidential"))} - {esc(deck.m("doc_date"))} - {esc(deck.m("doc_version"))}</div>
  </div>
</section>''')

    return '\n'.join(out)
