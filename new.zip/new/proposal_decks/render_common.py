"""
Shared helpers for the proposal-deck renderers: HTML escaping, input
normalisation, small text utilities, and the self-contained document wrapper
that inlines the <deck-stage> presentation engine.
"""

from __future__ import annotations

import html
import os
import re

from .schema import SLIDES, SLIDE_BY_KEY, META_FIELDS, default_data, slides_for, slide_has_content

# render_common.py lives at <root>/modules/project_management/proposal_decks/
# - four levels up is the application root that holds static/.
_DECK_JS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))),
    'static', 'js', 'proposal', 'deck-stage.js',
)
_deck_js_cache = None


def deck_stage_js() -> str:
    """Read (and cache) the shared deck-stage.js engine for inlining."""
    global _deck_js_cache
    if _deck_js_cache is None:
        try:
            with open(_DECK_JS_PATH, 'r', encoding='utf-8') as fh:
                _deck_js_cache = fh.read()
        except OSError:
            _deck_js_cache = '/* deck-stage.js unavailable */'
    return _deck_js_cache


# --- text utilities --------------------------------------------------------

def esc(value) -> str:
    """HTML-escape a scalar (None -> '')."""
    if value is None:
        return ''
    return html.escape(str(value), quote=True)


def esc_br(value) -> str:
    """Escape and turn newlines into <br>."""
    return esc(value).replace('\n', '<br>')


def lines(value):
    """Split a textarea/list value into clean non-empty lines."""
    if isinstance(value, (list, tuple)):
        return [str(v).strip() for v in value if str(v).strip()]
    return [ln.strip() for ln in str(value or '').split('\n') if ln.strip()]


def parts(value, sep=','):
    """Split a delimited string (commas by default) into clean items."""
    return [p.strip() for p in str(value or '').replace('\n', sep).split(sep) if p.strip()]


def num(value, default=0.0):
    try:
        return float(str(value).strip())
    except (TypeError, ValueError):
        return default


def filled(*values) -> bool:
    """True when any value (str / list / dict) holds non-blank content."""
    for v in values:
        if isinstance(v, dict):
            v = list(v.values())
        if isinstance(v, (list, tuple)):
            if filled(*v):
                return True
        elif str(v if v is not None else '').strip():
            return True
    return False


def join_filled(sep, *values) -> str:
    """Escape and join only the non-blank values - no dangling separators."""
    return sep.join(esc(str(v).strip()) for v in values if str(v or '').strip())


def fmt_num(value, places=1) -> str:
    """12.0 -> '12', 2.25 -> '2.3' (thousands separated)."""
    s = f'{value:,.{places}f}'
    return s.rstrip('0').rstrip('.') if '.' in s else s


# --- normalisation ---------------------------------------------------------

def coerce_deck(payload) -> dict:
    """
    Return a fully-formed deck dict the renderers can trust, merging posted
    data over the schema defaults and discarding anything malformed. The deck
    *structure* (which slides exist, which columns a table has) always comes
    from the trusted schema - never from the client.
    """
    payload = payload if isinstance(payload, dict) else {}
    template = str(payload.get('template') or 'npg')
    out = default_data(template)

    meta_in = payload.get('meta') if isinstance(payload.get('meta'), dict) else {}
    for f in META_FIELDS:
        if f['key'] in meta_in and meta_in[f['key']] is not None:
            out['meta'][f['key']] = str(meta_in[f['key']])

    slides_in = payload.get('slides') if isinstance(payload.get('slides'), dict) else {}
    for s in slides_for(template):
        sin = slides_in.get(s['key']) if isinstance(slides_in.get(s['key']), dict) else {}
        slot = out['slides'][s['key']]
        # required toggle (cover / thank-you are always on)
        if s.get('lockable', True):
            slot['enabled'] = bool(sin.get('enabled', True))
        else:
            slot['enabled'] = True
        fin = sin.get('fields') if isinstance(sin.get('fields'), dict) else {}
        for f in s['fields']:
            if f['key'] not in fin:
                continue
            slot['fields'][f['key']] = _coerce_field(f, fin[f['key']])
        # A slide whose content was cleared entirely has nothing to show - drop
        # it like a toggled-off slide rather than ship an empty placeholder.
        if s.get('lockable', True) and not slide_has_content(s, slot['fields']):
            slot['enabled'] = False
    return out


def _coerce_field(field, value):
    ftype = field['type']
    if ftype in ('text', 'textarea', 'select'):
        return '' if value is None else str(value)
    if ftype == 'list':
        if isinstance(value, list):
            return [str(v) for v in value]
        return lines(value)
    if ftype == 'table':
        cols = {c['key'] for c in field['columns']}
        # A dropdown cell always carries a value, so it alone never makes a
        # row real - otherwise a cleared row would still draw (e.g. a lone
        # risk-probability dot).
        typed = {c['key'] for c in field['columns'] if c.get('type') != 'select'} or cols
        rows = []
        if isinstance(value, list):
            for raw in value:
                if not isinstance(raw, dict):
                    continue
                row = {k: ('' if raw.get(k) is None else str(raw.get(k))) for k in cols}
                if any(row[k].strip() for k in typed):
                    rows.append(row)
        return rows
    return value


# --- accessors used by renderers -------------------------------------------

class Deck:
    """Thin convenience wrapper over a coerced deck dict."""

    def __init__(self, payload):
        self.data = coerce_deck(payload)
        self.meta = self.data['meta']
        self.template = self.data['template']

    def m(self, key, default=''):
        return self.meta.get(key, default)

    def has(self, slide_key):
        """Whether this deck's template includes the slide at all."""
        return slide_key in self.data['slides']

    def enabled(self, slide_key):
        slot = self.data['slides'].get(slide_key)
        return bool(slot and slot.get('enabled'))

    def f(self, slide_key, field_key, default=None):
        slot = self.data['slides'].get(slide_key)
        if not slot:
            return default
        return slot['fields'].get(field_key, default)

    def text(self, slide_key, field_key):
        return self.f(slide_key, field_key, '') or ''

    def list(self, slide_key, field_key):
        v = self.f(slide_key, field_key, [])
        return lines(v) if not isinstance(v, list) else [x for x in v if str(x).strip()]

    def table(self, slide_key, field_key):
        v = self.f(slide_key, field_key, [])
        return v if isinstance(v, list) else []


# --- resource effort matrix (shared by all templates) ------------------------

# Columns beyond this are not drawn - the slide stays legible at 1920px.
MAX_PERIODS = 24


def effort_series(value):
    """'0, 20, 20; 10' -> [0.0, 20.0, 20.0, 10.0] (blanks / junk count as 0)."""
    return [max(num(p, 0), 0) for p in re.split(r'[,;\s]+', str(value or '').strip()) if p]


def resource_plan(deck: Deck):
    """
    The Resource Effort Matrix behind the Team Composition & Effort slide,
    computed once for every template (same shape as the Effort Estimate tool).

    Each row carries person-days PER PERSON for each period; the row total is
    that sum x # resources, the period totals are the column sums. Returns
    ``None`` when the matrix is empty.
    """
    rows_in = deck.table('resourcing', 'resources')
    if not rows_in:
        return None
    unit = (deck.text('resourcing', 'period_unit') or 'Month').strip().lower()
    prefix, word = ('W', 'week') if unit.startswith('w') else ('M', 'month')
    rows, n = [], 0
    for r in rows_in:
        raw_count = str(r.get('count') or '').strip()
        count = max(num(raw_count, 1), 0) if raw_count else 1.0
        series = effort_series(r.get('effort'))[:MAX_PERIODS]
        n = max(n, len(series))
        rows.append({'role': r.get('role', ''), 'location': (r.get('location') or '').strip() or 'Unassigned',
                     'count': count, 'series': series})
    n = max(n, 1)
    groups = {}
    period_totals = [0.0] * n
    for row in rows:
        row['series'] = row['series'] + [0.0] * (n - len(row['series']))
        row['total'] = sum(row['series']) * row['count']
        for i, v in enumerate(row['series']):
            period_totals[i] += v * row['count']
        g = groups.setdefault(row['location'], {'location': row['location'], 'count': 0.0, 'pds': 0.0})
        g['count'] += row['count']
        g['pds'] += row['total']
    total = sum(period_totals)
    count = sum(r['count'] for r in rows)
    order = {'onshore': 0, 'nearshore': 1, 'offshore': 2}
    split = sorted(groups.values(), key=lambda g: (order.get(g['location'].lower(), 9), g['location']))
    for g in split:
        # Share of EFFORT, not heads: a part-time onshore architect should not
        # look like a full-time developer.
        g['pct'] = round(g['pds'] / total * 100) if total else (round(g['count'] / count * 100) if count else 0)
    peak_i = max(range(n), key=lambda i: period_totals[i])
    return {
        'rows': rows, 'n': n, 'labels': [f'{prefix}{i + 1}' for i in range(n)], 'word': word,
        'period_totals': period_totals, 'total': total, 'count': count, 'split': split,
        'peak_label': f'{prefix}{peak_i + 1}', 'peak': period_totals[peak_i],
        'max_cell': max([v for r in rows for v in r['series']] or [0]),
    }


def plan_split_text(plan) -> str:
    """'4 onshore / 13 offshore' - the one-line mix used on the Team slide."""
    return ' / '.join(f'{fmt_num(g["count"])} {esc(g["location"].lower())}' for g in plan['split'])


def _loc_badge(loc, loc_color):
    return f'<span class="rx-loc"><i style="background:{loc_color(loc)};"></i>{esc(loc)}</span>'


def effort_matrix_html(plan, *, table_cls, heat_rgb, loc_color, total_cls='total'):
    """
    The Resource Effort Matrix table, shared by all four templates (each
    supplies its table class, accent RGB and location colours; the ``rx-*``
    classes are styled per template). Non-zero cells are heat-shaded by effort
    so the ramp-up and roll-off read at a glance.
    """
    dense = plan['n'] > 12
    pad = 'padding:9px 3px;' if dense else 'padding:10px 6px;'
    head = ('<th>Role</th><th>Location</th><th class="r"># Res.</th>'
            + ''.join(f'<th class="c">{lab}</th>' for lab in plan['labels'])
            + '<th class="r">Total PDs</th>')
    top = plan['max_cell'] or 1

    def cell(v):
        if not v:
            return f'<td class="c rx-zero" style="{pad}">-</td>'
        alpha = 0.10 + 0.45 * (v / top)
        return f'<td class="c" style="{pad}background:rgba({heat_rgb},{alpha:.2f});">{fmt_num(v)}</td>'

    body = ''.join(
        f'<tr><td class="rx-role">{esc(r["role"])}</td><td style="white-space:nowrap;">{_loc_badge(r["location"], loc_color)}</td>'
        f'<td class="r">{fmt_num(r["count"])}</td>'
        + ''.join(cell(v) for v in r['series'])
        + f'<td class="r rx-rowtotal">{fmt_num(r["total"])}</td></tr>'
        for r in plan['rows'])
    foot = (f'<tr class="{total_cls}"><td colspan="2">Totals</td><td class="r">{fmt_num(plan["count"])}</td>'
            # no inline padding here - the template's total-row style owns it
            + ''.join(f'<td class="c">{fmt_num(v)}</td>' for v in plan['period_totals'])
            + f'<td class="r">{fmt_num(plan["total"])}</td></tr>')
    return (f'<table class="{table_cls} rx-matrix{" rx-dense" if dense else ""}"><thead><tr>{head}</tr></thead>'
            f'<tbody>{body}{foot}</tbody></table>')


def effort_summary_html(plan, loc_color) -> str:
    """The four-figure strip under the matrix: people, mix, total effort, peak."""
    n, word = plan['n'], plan['word']
    segs = ''.join(f'<span style="width:{g["pct"]}%;background:{loc_color(g["location"])};"></span>'
                   for g in plan['split'] if g['pct'] > 0)
    legend = ''.join(
        f'<div>{_loc_badge(g["location"], loc_color)} <b>{fmt_num(g["count"])}</b> people - {g["pct"]}% of effort</div>'
        for g in plan['split'])
    return (
        '<div class="rx-strip">'
        f'<div class="rx-cell"><div class="rx-v">{fmt_num(plan["count"])}</div>'
        f'<div class="rx-l">people across {len(plan["rows"])} roles</div></div>'
        f'<div class="rx-cell rx-wide"><div class="rx-mix">{segs}</div><div class="rx-legend">{legend}</div></div>'
        f'<div class="rx-cell"><div class="rx-v">{fmt_num(plan["total"])}</div>'
        f'<div class="rx-l">person-days over {n} {word}{"s" if n != 1 else ""}</div></div>'
        f'<div class="rx-cell"><div class="rx-v">{plan["peak_label"]}</div>'
        f'<div class="rx-l">peak {word} - {fmt_num(plan["peak"])} person-days</div></div>'
        '</div>')


# --- gantt geometry (shared by all templates) ------------------------------

def gantt_unit(deck: Deck):
    """The roadmap axis unit as (prefix, word) - ('W', 'week') or ('M', 'month').

    Driven by the roadmap slide's free-text ``unit`` field so a deck can run a
    week-by-week programme without the axis claiming months. Anything that
    doesn't start with a "w" keeps the historical month behaviour.
    """
    raw = (deck.text('roadmap', 'unit') or '').strip().lower()
    return ('W', 'week') if raw.startswith('w') else ('M', 'month')


def gantt_geometry(deck: Deck):
    """
    Normalise roadmap phases into {name, left, width, milestone} percentages.
    Bars are clamped to the [0,100] track derived from total_months.
    """
    total = max(num(deck.text('roadmap', 'total_months'), 9), 1)
    out = []
    for row in deck.table('roadmap', 'phases'):
        start = max(num(row.get('start'), 0), 0)
        dur = max(num(row.get('duration'), 0), 0)
        left = min(start / total * 100, 100)
        width = max(min(dur / total * 100, 100 - left), 1.5)
        out.append({
            'name': row.get('name', ''),
            'left': round(left, 2),
            'width': round(width, 2),
            'end': round(min(left + width, 100), 2),
            'milestone': str(row.get('milestone', 'No')).strip().lower() in ('yes', 'true', '1'),
        })
    return out, total


# --- document wrapper ------------------------------------------------------

_SLIDE_RE = re.compile(r'^\s*<section', re.IGNORECASE)


def wrap_document(deck_title: str, css: str, slides_html: str,
                  body_bg: str = '#0b0b0c') -> str:
    """Assemble the final, self-contained presentation HTML."""
    # The engine's source contains the literal "</script>" in its usage docs;
    # left as-is it would prematurely close our inline <script> tag. Escape it.
    engine = deck_stage_js().replace('</script>', '<\\/script>')
    return (
        '<!DOCTYPE html>\n<html lang="en">\n<head>\n'
        '<meta charset="UTF-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
        f'<title>{esc(deck_title)}</title>\n'
        '<style>\ndeck-stage:not(:defined){visibility:hidden;}\n'
        f'html,body{{margin:0;background:{body_bg};}}\n'
        f'{css}\n</style>\n'
        '</head>\n'
        f'<body>\n<deck-stage width="1920" height="1080">\n{slides_html}\n</deck-stage>\n'
        f'<script>\n{engine}\n</script>\n'
        '</body>\n</html>\n'
    )


def skip_attr(enabled: bool) -> str:
    """`data-deck-skip` marks a slide so the engine drops it from nav + print."""
    return '' if enabled else ' data-deck-skip'


class _Positions(dict):
    """Slide-position map that tolerates keys outside the template's slide
    set (a renderer may emit a section for a slide its template dropped -
    that section carries data-deck-skip and is never shown)."""

    def __init__(self, total):
        super().__init__()
        self._total = total

    def __missing__(self, key):
        return ('--', self._total)


def footer_positions(deck: Deck):
    """
    Map each slide key to ('NN', 'TT') where TT is the count of *enabled*
    slides and NN is this slide's 1-based position among them. Disabled or
    unknown slides get ('--', TT) - they're hidden anyway. Only the deck
    template's own slide set is counted.
    """
    deck_slides = slides_for(deck.template)
    enabled_keys = [s['key'] for s in deck_slides if deck.enabled(s['key'])]
    total = f'{len(enabled_keys):02d}'
    pos = _Positions(total)
    n = 0
    for s in deck_slides:
        if deck.enabled(s['key']):
            n += 1
            pos[s['key']] = (f'{n:02d}', total)
        else:
            pos[s['key']] = ('--', total)
    return pos


def risk_class(prob: str) -> str:
    p = (prob or '').strip().lower()
    if p.startswith('h'):
        return 'r'
    if p.startswith('l'):
        return 'g'
    return 'a'
