"""
Proposal-deck builder (stateless, guest + member).

A small sub-package of the project-management blueprint that lets anyone build
an IT proposal presentation from a form and download it as a single,
self-contained HTML deck. ONE form, four designs: the four templates - NPG,
Helix, Meridian and Apex - all consume the same canonical 15-slide input set
(Title -> Executive Summary -> Current State -> Opportunity -> Solution ->
Benefits -> Approach -> Roadmap -> Risks -> Team -> Team Composition & Effort ->
Investment & ROI -> KPIs ->
Next Steps -> Thank You) and differ only in presentation and layout.
Nothing is persisted server-side - the page keeps the user's input in the
browser only, and the export endpoint builds the HTML purely from the posted
data (mirroring the guest-HLD flow).
"""

from .deck_builder import build_deck_html, TEMPLATES, TEMPLATE_IDS
from .schema import SLIDES, META_FIELDS, default_data, slides_for

__all__ = [
    'build_deck_html', 'TEMPLATES', 'TEMPLATE_IDS',
    'SLIDES', 'META_FIELDS', 'default_data', 'slides_for',
]
