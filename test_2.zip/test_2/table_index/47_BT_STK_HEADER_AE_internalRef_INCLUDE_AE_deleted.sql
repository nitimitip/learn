/******************************************************************************
  RECOMMENDED INDEX CHANGE - NOT EXECUTED - REVIEW AND TEST BEFORE DEPLOYMENT
  Index 47 (phase 2, V2-03, 2026-10-20)
  Table : dbo.BT_STK_HEADER (1,971,063 rows; clustered 64,968 pages, this index 8,028 pages)
  Index : IX_BT_STK_HEADER_AE_internalRef ON (AE_internalRef)  ->  same key, INCLUDE (AE_deleted)
          Rebuilt in place (DROP_EXISTING): same name and key, so any
          code or plan that uses it keeps working.
  WHY
    usp_GetActivityBasedOnTypeAndWildCardName (V2-03) filters
    AE_deleted = 'N' AND AE_internalRef LIKE <pattern> and returns TOP 20 by the
    clustered key. Without the deleted flag in this index every matching
    row costs a key lookup, so prefixes matching thousands of rows fall
    back to a clustered walk (up to 64,968 pages). With it, the search
    reads at most this index (~8,028 pages) + 20 lookups.
  WRITE OVERHEAD
    Low: AE_deleted is a 1-char flag that changes on (soft) delete only.
    Size grows by ~1-2 bytes per row.
  SAFETY
    The batch only acts when the index exists with exactly the key
    (AE_internalRef), no included columns and no filter; otherwise it prints why
    and does nothing. Fill factor and data compression are read from the
    current index and kept.
  DEPLOY ORDER: indexes 44-50 first, then optimization_v2/sp/usp_GetActivityBasedOnTypeAndWildCardName.sql
  (its guard 3 refuses to deploy without them).
******************************************************************************/

DECLARE @obj int = OBJECT_ID('dbo.BT_STK_HEADER');
DECLARE @ixid int = (SELECT index_id FROM sys.indexes WHERE object_id = @obj AND name = 'IX_BT_STK_HEADER_AE_internalRef');
DECLARE @fill int, @comp nvarchar(60), @sql nvarchar(max);

IF @ixid IS NULL
    PRINT 'SKIPPED: IX_BT_STK_HEADER_AE_internalRef does not exist.';
ELSE IF EXISTS (SELECT 1 FROM sys.index_columns ic JOIN sys.columns c
                  ON c.object_id = ic.object_id AND c.column_id = ic.column_id
                WHERE ic.object_id = @obj AND ic.index_id = @ixid
                  AND c.name = 'AE_deleted' AND ic.is_included_column = 1)
    PRINT 'SKIPPED: IX_BT_STK_HEADER_AE_internalRef already includes AE_deleted.';
ELSE IF (SELECT COUNT(*) FROM sys.index_columns WHERE object_id = @obj AND index_id = @ixid) <> 1
     OR NOT EXISTS (SELECT 1 FROM sys.index_columns ic JOIN sys.columns c
                      ON c.object_id = ic.object_id AND c.column_id = ic.column_id
                    WHERE ic.object_id = @obj AND ic.index_id = @ixid AND ic.key_ordinal = 1
                      AND c.name = 'AE_internalRef')
     OR EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = @obj AND index_id = @ixid
                  AND (has_filter = 1 OR is_unique = 1 OR type <> 2))
    PRINT 'SKIPPED: IX_BT_STK_HEADER_AE_internalRef is not the expected nonclustered (AE_internalRef) index; review by hand.';
ELSE
BEGIN
    SELECT @fill = fill_factor FROM sys.indexes WHERE object_id = @obj AND index_id = @ixid;
    SELECT TOP (1) @comp = data_compression_desc FROM sys.partitions
    WHERE object_id = @obj AND index_id = @ixid ORDER BY partition_number;
    -- ONLINE = ON requires Enterprise/Developer/Azure; remove on Standard.
    SET @sql = N'CREATE NONCLUSTERED INDEX IX_BT_STK_HEADER_AE_internalRef ON dbo.BT_STK_HEADER (AE_internalRef)'
             + N' INCLUDE (AE_deleted) WITH (DROP_EXISTING = ON, ONLINE = ON, SORT_IN_TEMPDB = ON'
             + CASE WHEN @fill > 0 THEN N', FILLFACTOR = ' + CAST(@fill AS nvarchar(3)) ELSE N'' END
             + N', DATA_COMPRESSION = ' + @comp + N');';
    PRINT @sql;
    EXEC sys.sp_executesql @sql;
END
GO

/* ROLLBACK (back to the key-only index; same fill factor/compression rule)
CREATE NONCLUSTERED INDEX IX_BT_STK_HEADER_AE_internalRef ON dbo.BT_STK_HEADER (AE_internalRef)
    WITH (DROP_EXISTING = ON, ONLINE = ON, SORT_IN_TEMPDB = ON);
*/
