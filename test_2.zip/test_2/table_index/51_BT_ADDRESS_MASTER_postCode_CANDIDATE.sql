/******************************************************************************
  CANDIDATE INDEX - NOT EXECUTED - GATED ON EVIDENCE - DO NOT DEPLOY YET
  Index 51 (phase 2, V2-04, 2026-10-20)
  Table : dbo.BT_ADDRESS_MASTER (6,279,178 rows; clustered PK_BT_ADDRESS_MASTER_1
          on ADDRESS_ID, 560.4 MB ~= 71,731 pages, DATA_COMPRESSION = PAGE)
  Index : IX_BT_ADDRESS_MASTER_postCode ON (postCode) INCLUDE (parentID, deleted)

  GATE
    Deploy ONLY when one of these says so (one decision, two procedures):
      - validation/v2_04_validation.sql outcome A (PRC_ACT_uspEnquiryQuery:
        the expensive calls are postcode searches over an address scan), or
      - validation/v2_02_validation.sql outcome C (SP_ACT_GET_MATCHINGCUST:
        only the postcode statement is big and it is one address scan),
    AND the test-copy HARD STOP in V2-04.7 passed. The batch below does
    nothing until @gate_passed is set to 1 by hand.

  WHY
    Nothing on the table leads with postCode (indexes: the clustered PK and
    IX_BT_ADDRESS_MASTER_parentID only). Both readers compare it exactly:
      - PRC_ACT_uspEnquiryQuery (B02): AND b.postCode = @pPostCode (after
        cleansing) or LIKE when the user typed '%'. Today: one 71,731-page
        address scan per postcode search, then enquiries via index 18.
        2026-10-20: 74,847 reads per call = 71,731 + ~3.1k (fit, 2 calls).
      - SP_ACT_GET_MATCHINGCUST: cust_id IN (SELECT parentID FROM
        BT_ADDRESS_MASTER WHERE postcode = @pPostcode). parentID is in the
        INCLUDE, so this is a seek with no lookups.
    Side effect [Inferred, not measured]: PRC_ACT_uspSiteActQuery_v3 wraps
    the postcode in '%..%' (cannot seek); for a postcode-only search its
    ADDRESS_ID collection (deleted + postCode) is covered by this index and
    can scan it instead of the clustered index.
    Expected (estimate, not measured): seek ~3-4 pages + the matched
    addresses (V2-04.6 median rows per postcode) instead of 71,731 pages.

  SIZE / WRITE OVERHEAD
    ~6.28M rows x (postCode ~6-8 bytes + parentID 4 + deleted 1 +
    ADDRESS_ID 4 + row overhead) ~= 130-190 MB before compression; the
    clustered index's compression setting is copied (PAGE today), which
    usually shrinks a sorted varchar key well. V2-04.6 avg_key_bytes gives
    the real key length.
    Writes: the PK had 75,786 writes in the phase-1 window; this index is
    maintained on every address insert and on postCode / parentID /
    deleted updates. The PK already shows row-lock waits (RowLockWaitMs
    1,930,884), so watch address write latency after deploy (P section).
    Build: one scan of 560 MB + a sort of 6.28M rows (SORT_IN_TEMPDB).
    ONLINE only on Enterprise / Developer / Azure; on Standard the build
    blocks address writes - quiet window only.

  OVERLAP CHECK
    Different leading key from both existing indexes; none made redundant.
    The batch refuses if ANY index already leads with postCode.
******************************************************************************/

DECLARE @gate_passed bit = 0;   -- set to 1 only after the GATE above is met

DECLARE @obj int = OBJECT_ID('dbo.BT_ADDRESS_MASTER');
DECLARE @comp nvarchar(60), @online nvarchar(3), @sql nvarchar(max), @existing sysname;

SELECT TOP (1) @existing = i.name
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
WHERE i.object_id = @obj AND ic.key_ordinal = 1 AND c.name = 'postCode';

IF @gate_passed = 0
    PRINT 'NOT DEPLOYED: index 51 is a candidate. Set @gate_passed = 1 only after V2-04 outcome A or V2-02 outcome C and the V2-04.7 HARD STOP check.';
ELSE IF @obj IS NULL
    PRINT 'SKIPPED: dbo.BT_ADDRESS_MASTER does not exist.';
ELSE IF @existing IS NOT NULL
    PRINT 'SKIPPED: index ' + @existing + ' already leads with postCode.';
ELSE
BEGIN
    SELECT TOP (1) @comp = data_compression_desc
    FROM sys.partitions WHERE object_id = @obj AND index_id = 1;
    SET @online = CASE WHEN CONVERT(int, SERVERPROPERTY('EngineEdition')) IN (3, 5, 8) THEN N'ON' ELSE N'OFF' END;
    IF @online = N'OFF'
        PRINT 'WARNING: ONLINE index build not available on this edition; the build blocks address writes.';

    SET @sql = N'CREATE NONCLUSTERED INDEX IX_BT_ADDRESS_MASTER_postCode'
             + N' ON dbo.BT_ADDRESS_MASTER (postCode) INCLUDE (parentID, deleted)'
             + N' WITH (ONLINE = ' + @online + N', SORT_IN_TEMPDB = ON, FILLFACTOR = 90'
             + N', DATA_COMPRESSION = ' + ISNULL(@comp, N'NONE') + N');';
    PRINT @sql;
    EXEC sys.sp_executesql @sql;
END
GO

/* ROLLBACK
DROP INDEX IX_BT_ADDRESS_MASTER_postCode ON dbo.BT_ADDRESS_MASTER;
*/
