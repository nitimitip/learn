/******************************************************************************
  RECOMMENDED INDEX - NOT EXECUTED - REVIEW AND TEST BEFORE DEPLOYMENT
  Index 55 (phase 2, V2-06, 2026-10-22)
  Table : dbo.BT_STK_HEADER (1,971,063 rows; clustered 507.57 MB = 64,969 pages)
  Index : IX_BT_STK_HEADER_AE_mpan2 ON (AE_mpan2, AE_AEID)
          Same shape as the existing ADM_IX_AE_mpan1_AE_AEID (27.81 MB).
  WHY
    usp_CheckIfMPANIsDuplicate (production baseline: 1,335 execs, 369 ms,
    CPU 1,494 ms (parallel), 143,989 reads/call, 8.2 min total) runs 12
    COUNT statements, 6 on BT_STK_HEADER and 6 on BT_CTK_HEADER:
      ae_aeid = @ActivityID ...            -> PK seek (~3 pages)     x 4
      ae_aeid <> @ActivityID AND AE_mpan1  -> mpan1 index seek        x 4
      ae_aeid <> @ActivityID AND AE_mpan2  -> FULL clustered scan     x 4
    The 8 seek statements read a few dozen pages at most, so the four
    AE_mpan2 statements are ~all of the 143,989 [Confirmed by elimination].
    143,989 = 1.07 x (64,969 + 70,249): about one scan of each table per
    call on average (for example: about half the calls run all four scans
    and the rest skip, when both MPANs are empty). Which mix is not known
    and does not change the fix.
    With 54 + 55 every statement seeks: expected (estimate, not measured)
    ~40-60 reads per call, serial, a few ms. No SP change.
  SIZE / WRITE OVERHEAD
    ~28 MB (same as the mpan1 index). The clustered index had 16,511
    writes in the baseline window; maintained on inserts and AE_mpan2
    updates. Build: one scan of 508 MB + sort (SORT_IN_TEMPDB). ONLINE
    only on Enterprise / Developer / Azure.
  NOTE
    When one of the two MPANs is '' the check counts AE_mpan2 = '' rows
    (a range seek over all '' rows; V2-06.1 counts them).
  OVERLAP CHECK
    No existing index leads with AE_mpan2. The batch refuses if one does.
******************************************************************************/

DECLARE @obj int = OBJECT_ID('dbo.BT_STK_HEADER');
DECLARE @comp nvarchar(60), @online nvarchar(3), @sql nvarchar(max), @existing sysname;

SELECT TOP (1) @existing = i.name
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
WHERE i.object_id = @obj AND ic.key_ordinal = 1 AND c.name = 'AE_mpan2';

IF @obj IS NULL
    PRINT 'SKIPPED: dbo.BT_STK_HEADER does not exist.';
ELSE IF @existing IS NOT NULL
    PRINT 'SKIPPED: index ' + @existing + ' already leads with AE_mpan2.';
ELSE
BEGIN
    SELECT TOP (1) @comp = data_compression_desc
    FROM sys.partitions WHERE object_id = @obj AND index_id = 1;
    SET @online = CASE WHEN CONVERT(int, SERVERPROPERTY('EngineEdition')) IN (3, 5, 8) THEN N'ON' ELSE N'OFF' END;
    IF @online = N'OFF'
        PRINT 'WARNING: ONLINE index build not available on this edition; the build blocks STK writes.';

    SET @sql = N'CREATE NONCLUSTERED INDEX IX_BT_STK_HEADER_AE_mpan2'
             + N' ON dbo.BT_STK_HEADER (AE_mpan2, AE_AEID)'
             + N' WITH (ONLINE = ' + @online + N', SORT_IN_TEMPDB = ON'
             + N', DATA_COMPRESSION = ' + ISNULL(@comp, N'NONE') + N');';
    PRINT @sql;
    EXEC sys.sp_executesql @sql;
END
GO

/* ROLLBACK
DROP INDEX IX_BT_STK_HEADER_AE_mpan2 ON dbo.BT_STK_HEADER;
*/
