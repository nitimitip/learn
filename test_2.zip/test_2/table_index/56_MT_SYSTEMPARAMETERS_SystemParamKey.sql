/******************************************************************************
  RECOMMENDED INDEX - NOT EXECUTED - REVIEW AND TEST BEFORE DEPLOYMENT
  Index 56 (phase 2, V2-08, 2026-10-22)
  Table : dbo.MT_SYSTEMPARAMETERS (1,216 rows; clustered 0.23 MB ~= 29 pages;
          PK_MT_SYSTEMPARAMETERS on SystemParamID only)
  Index : IX_MT_SYSTEMPARAMETERS_SystemParamKey ON (SystemParamKey)
          INCLUDE (SystemParamNvalue, SystemParamCvalue, SystemParamDvalue,
                   SystemParamTvalue, SystemParamContext, SystemParamDeleted,
                   SystemParamType)
  WHY
    Production baseline (Index/index_size.xlsx): the PK shows 13,650,015
    SCANS, 0 seeks, 0 lookups and 0 writes in the window. Every reader
    filters on SystemParamKey, which has no index, so each read scans the
    whole table (~29 pages, 1,216 string compares): ~370-400M logical reads
    per window in total.
    Who [Confirmed by grep, partial]: 23 live SPs read it, all with SARGable
    predicates: SystemParamKey = '<literal>' (TopSearchRows in the search
    SPs, ACTIVITY_VIEW_ALL_COMPANIES, *_COMPLETE_STATUS, MPAN dirs),
    = @ParamKey (varchar(50) parameters, usp_getsystemparam*), LIKE
    '<prefix>%' (PLA message board / templates). Execs x statements of the
    SPs in slowrunningSP.xlsx = ~144k, i.e. ~1% of the scans; the other
    ~99% come from callers not in QPID_SP/ (functions such as
    dbo.intRefPrefix - called per row by CDMS_ACT_LOV_TypCatDecode - or
    application SQL) [Inferred]. V2-08.1 lists the module readers; the
    index serves any reader whose predicate is SARGable on the key.
  DESIGN
    Key SystemParamKey (varchar(100) NULL). Not UNIQUE: uniqueness is not
    known (V2-08.2) and sp_addsLetter inserts rows. INCLUDE = every value /
    flag column the SPs read, so the seek needs no key lookup (the table is
    tiny; the index is about the size of the table). Expected: 2 pages per
    lookup instead of ~29. Writes: 0 in the window - no write overhead.
  SAFETY
    Refuses if any index already leads with SystemParamKey. Reads the
    clustered compression and keeps it. ONLINE by edition (the build takes
    milliseconds either way). A plain index changes no results; plans that
    read several parameters in one statement may pick a different access
    path, which cannot change rows.
  DEPLOY: any window, before or after the SPs (independent of V2-06 / V2-07).
******************************************************************************/

DECLARE @obj int = OBJECT_ID('dbo.MT_SYSTEMPARAMETERS');
DECLARE @comp nvarchar(60), @online nvarchar(3), @sql nvarchar(max), @existing sysname;

SELECT TOP (1) @existing = i.name
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
WHERE i.object_id = @obj AND ic.key_ordinal = 1 AND c.name = 'SystemParamKey';

IF @obj IS NULL
    PRINT 'SKIPPED: dbo.MT_SYSTEMPARAMETERS does not exist.';
ELSE IF @existing IS NOT NULL
    PRINT 'SKIPPED: index ' + @existing + ' already leads with SystemParamKey.';
ELSE
BEGIN
    SELECT TOP (1) @comp = data_compression_desc
    FROM sys.partitions WHERE object_id = @obj AND index_id = 1;
    SET @online = CASE WHEN CONVERT(int, SERVERPROPERTY('EngineEdition')) IN (3, 5, 8) THEN N'ON' ELSE N'OFF' END;

    SET @sql = N'CREATE NONCLUSTERED INDEX IX_MT_SYSTEMPARAMETERS_SystemParamKey'
             + N' ON dbo.MT_SYSTEMPARAMETERS (SystemParamKey)'
             + N' INCLUDE (SystemParamNvalue, SystemParamCvalue, SystemParamDvalue, SystemParamTvalue,'
             + N' SystemParamContext, SystemParamDeleted, SystemParamType)'
             + N' WITH (ONLINE = ' + @online + N', DATA_COMPRESSION = ' + ISNULL(@comp, N'NONE') + N');';
    PRINT @sql;
    EXEC sys.sp_executesql @sql;
END
GO

/* ROLLBACK
DROP INDEX IX_MT_SYSTEMPARAMETERS_SystemParamKey ON dbo.MT_SYSTEMPARAMETERS;
*/
