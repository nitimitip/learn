/******************************************************************************
  RECOMMENDED INDEX - NOT EXECUTED - REVIEW AND TEST BEFORE DEPLOYMENT
  Index 54 (phase 2, V2-06, 2026-10-22)
  Table : dbo.BT_CTK_HEADER (2,125,841 rows; clustered 548.82 MB = 70,249 pages, PAGE compressed)
  Index : IX_BT_CTK_HEADER_AE_mpan2 ON (AE_mpan2, AE_AEID)
          Same shape as the existing ADM_MI_IX_AE_mpan1_AE_AEID (28.88 MB).
  WHY
    AE_mpan2 (varchar(50) NULL) has no index, so every equality filter on
    it scans the whole clustered index. Two live readers, both production
    baseline (Index/slowrunningSP.xlsx):
      PRC_ACT_uspCTKQuery (Find CTK): 111 execs, 70,989 reads/call =
        98.96% of one clustered scan (OR mpan1 / mpan2). Needs the V2-06
        SP rewrite as well to seek both halves.
      usp_CheckIfMPANIsDuplicate (MPAN save check): 1,335 execs, 369 ms,
        CPU 1,494 ms (parallel), 143,989 reads/call. Its two CTK statements
        on AE_mpan2 scan this table; no SP change needed (see index 55 for
        the STK half).
    AE_AEID is in the key (as in the mpan1 index) so the duplicate check's
    "ae_aeid <> @ActivityID" counts are answered from this index alone.
  SIZE / WRITE OVERHEAD
    ~29 MB (same as the mpan1 index). The clustered index had 22,334
    writes in the baseline window; this index is maintained on inserts and
    on AE_mpan2 updates (usp_AddOrAmendComplexTask / SimpleTask,
    sp_provideMPANS / XT_provideMPANS).
    Build: one scan of 549 MB + a sort of 2.1M short keys (SORT_IN_TEMPDB).
    ONLINE only on Enterprise / Developer / Azure; on Standard the build
    blocks CTK writes for its duration - quiet window only.
  NOTE
    A search for '' (empty MPAN) seeks the whole '' range. The Find CTK
    screen never searches '' (len > 1 test); the duplicate check does when
    one of its two MPANs is '' - V2-06.1 counts the '' / NULL rows.
  OVERLAP CHECK
    No existing index leads with AE_mpan2 (index_size.xlsx / index.xlsx).
    The batch refuses if one does.
  DEPLOY ORDER: this index (and 55), then optimization_v2/sp/PRC_ACT_uspCTKQuery.sql.
******************************************************************************/

DECLARE @obj int = OBJECT_ID('dbo.BT_CTK_HEADER');
DECLARE @comp nvarchar(60), @online nvarchar(3), @sql nvarchar(max), @existing sysname;

SELECT TOP (1) @existing = i.name
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
WHERE i.object_id = @obj AND ic.key_ordinal = 1 AND c.name = 'AE_mpan2';

IF @obj IS NULL
    PRINT 'SKIPPED: dbo.BT_CTK_HEADER does not exist.';
ELSE IF @existing IS NOT NULL
    PRINT 'SKIPPED: index ' + @existing + ' already leads with AE_mpan2.';
ELSE
BEGIN
    SELECT TOP (1) @comp = data_compression_desc
    FROM sys.partitions WHERE object_id = @obj AND index_id = 1;
    SET @online = CASE WHEN CONVERT(int, SERVERPROPERTY('EngineEdition')) IN (3, 5, 8) THEN N'ON' ELSE N'OFF' END;
    IF @online = N'OFF'
        PRINT 'WARNING: ONLINE index build not available on this edition; the build blocks CTK writes.';

    SET @sql = N'CREATE NONCLUSTERED INDEX IX_BT_CTK_HEADER_AE_mpan2'
             + N' ON dbo.BT_CTK_HEADER (AE_mpan2, AE_AEID)'
             + N' WITH (ONLINE = ' + @online + N', SORT_IN_TEMPDB = ON'
             + N', DATA_COMPRESSION = ' + ISNULL(@comp, N'NONE') + N');';
    PRINT @sql;
    EXEC sys.sp_executesql @sql;
END
GO

/* ROLLBACK
DROP INDEX IX_BT_CTK_HEADER_AE_mpan2 ON dbo.BT_CTK_HEADER;
*/
