/******************************************************************************
  OPTIMIZED VERSION V2-01 - PENDING VALIDATION - DO NOT DEPLOY UNTESTED
  Procedure : [dbo].[SP_GET_HEADER_DETAILS]
  Original  : QPID_SP/SP_GET_HEADER_DETAILS.sql
  Replaces  : Batch 29 version (optimization/sp/SP_GET_HEADER_DETAILS.sql),
              which REGRESSED on UAT. Do NOT promote the B29 file;
              production goes original -> V2-01.
  Batch     : V2-01 (2026-10-20)
  Generated : optimization_v2/tools/gen_v2_01.py (inverse transform =
              original, checked)
  Depends on: index 42 IX_BT_ACT_BILLOFMATERIALS_BOM_addToProject (already
              deployed on UAT with B29 - keep it; production needs it
              before this procedure) and the existing index on
              BOM_generatedProject.

  WHY:
    Original (production baseline): 2,536 execs, avg 363.72 ms, CPU
    197.21 ms, reads 8,857 (one 7,720-page BOM scan per call through
    coalesce(BOM_generatedProject,BOM_addToProject) = <project id>).
    B29 version on UAT, 2026-10-20: 6 execs, avg 4,084.10 ms, CPU
    3,785.16 ms, reads 2,670,802. B29 wrote V twice inside an OR; in 6 of
    7 places V is a scalar subquery, so no seek was possible and the
    subquery ran per BOM row (~519k rows x ~3-5 reads ~= the measured
    reads).

  WHAT CHANGED (and nothing else):
    The 7 BOMRef subqueries (lines 62, 78, 107, 126, 151, 171, 194)
        (select top 1 BOM_InternalRef from BT_ACT_BILLOFMATERIALS
          where coalesce(g,a) = V | IN (V) and <live>)
    became
        (select top 1 b.BOM_InternalRef from (select V AS pid) x
          cross apply (select BOM_InternalRef, BOM_bomID ... where g = x.pid and <live>
                       union all
                       select BOM_InternalRef, BOM_bomID ... where g IS NULL and a = x.pid and <live>) b
          order by b.BOM_bomID)
    CREATE -> ALTER.

  WHY IT IS EQUIVALENT:
    g = BOM_generatedProject, a = BOM_addToProject (int NULL), v = V.
    - x has exactly one row, pid = v (NULL when V finds no live project).
      'IN (select top 1 ...)' is a set of 0 or 1 values, so it is the same
      as '= (that scalar)': no value -> no row in both forms.
    - coalesce(g,a) = v  <=>  (g = v) OR (g IS NULL AND a = v); the two
      halves are disjoint (g = v needs g NOT NULL), so UNION ALL returns
      each qualifying BOM exactly once. v NULL -> no row in both forms.
    - V is evaluated ONCE (B29 evaluated it twice; on line 107 that was a
      TOP 1 on non-unique AE_RootID).
    - Column resolution: V's unqualified names (ae_aeid, ae_deleted) are
      in its own FROM tables; BT_ACT_BILLOFMATERIALS has no such columns,
      so moving V out of the BOM WHERE changes no binding.
    - ORDER BY b.BOM_bomID: the original TOP 1 had no ORDER BY, i.e. ANY
      qualifying BOM. In practice the original clustered scan returned
      the lowest BOM_bomID; the ORDER BY makes that pick deterministic.
      Only projects with more than one live BOM are affected (V2-01.2).

  EXPECTED (estimate, NOT measured):
    Per BOMRef: one seek on the BOM_generatedProject index (+ 1-2 key
    lookups for BOM_InternalRef / BOM_deleted), one seek on index 42
    (covering), a sort of 1-2 rows: ~10 reads instead of ~7,720.
    Call: 8,857 -> ~200-1,100 reads; 364 ms -> < 100 ms.

  UNCHANGED (inherited, reported in Batch 29 notes, NOT fixed):
    - 'PH%': ph.AE_AEID = ... OR ph.AE_internalref = ... and isnull(...)
      - AND binds before OR (deleted filter on the ref match only).
    - SUBSTRING(@activityRef, n, ...) vs int: error 245 on a non-numeric
      suffix.
    - 'CTK%': COUNT over PLA_PROD.dbo.PLA_ACT_ACTIVITYEVENT.
    - Scalar UDFs fn_rpt_GetReformatReturnAddress_NoSiteName, udf_StripHTML.

  ROLLBACK: optimization_v2/rollback/SP_GET_HEADER_DETAILS_ORIGINAL.sql
******************************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
----------------------------------------------------------------
-- Added By	  :	Anirban Dhara
-- Added date : 30-JUN-2023
-- Description:	ALTER PROCEDURE [dbo].[SP_GET_HEADER_DETAILS] 
----------------------------------------------------------------


ALTER PROCEDURE [dbo].[SP_GET_HEADER_DETAILS] 
	@activityRef VARCHAR(50)

AS
				DECLARE @ae_aeid1 INT;
                DECLARE @ae_aeid2 INT;
BEGIN

		IF @activityRef like 'QUO%'
			BEGIN
				select top 1 q.ae_internalref as QuoteRef ,
				(select top 1 ae_internalref from BT_ENQUIRY_MASTER where ae_aeid=q.AE_ParentID and isnull(ae_deleted,'N')='N') as EnquiryRef ,
				(select top 1 CUST_REFERENCE from BT_CUSTOMER_MASTER where cust_id = q.ae_customer) as CustomerRef,
				(select top 1 CUST_ORG_NAME from BT_CUSTOMER_MASTER where cust_id = q.ae_customer) as CustomerName,
				(select dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(ae_address) from BT_ENQUIRY_MASTER where ae_aeid=q.AE_ParentID) as SiteAddress
				from  BT_QUOTE_MASTER q 
				where q.AE_internalRef=@activityRef and isnull(ae_deleted,'N')='N'
				
		END
		IF @activityRef like 'EST%'
			BEGIN
				select top 1 
				es.ae_internalref as EstimateRef,
				(select top 1 ae_internalref from BT_QUOTE_MASTER where ae_aeid =es.AE_ParentID and isnull(ae_deleted,'N')='N') as QuoteRef ,
				(select top 1 ae_internalref from BT_ENQUIRY_MASTER where ae_aeid =es.AE_RootID and isnull(ae_deleted,'N')='N') as EnquiryRef ,
				(select top 1 CUST_REFERENCE from BT_CUSTOMER_MASTER where cust_id = es.ae_customer) as CustomerRef,
				(select top 1 CUST_ORG_NAME from BT_CUSTOMER_MASTER where cust_id = es.ae_customer) as CustomerName,
				(select dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(ae_address) from BT_ENQUIRY_MASTER where ae_aeid=es.AE_rootID) as SiteAddress,
				(select AE_networkDistributor from BT_ENQUIRY_MASTER where ae_aeid=es.AE_rootID) as NetworkDistributor,
				(select replace([dbo].udf_StripHTML(ltrim(rtrim(ae_summarydescription))),'nbsp;','') from BT_QUOTE_MASTER where ae_aeid=es.AE_ParentID) as SchemeDescription
				from BT_ESTIMATE_MASTER es 
				WHERE es.AE_internalRef=@activityRef and isnull(ae_deleted,'N')='N'
		END
		IF @activityRef like 'BOM%'
			BEGIN
				select top 1 b.BOM_InternalRef as BOMRef,
				(select top 1 ae_internalRef from BT_ESTIMATE_MASTER where ae_aeid = b.BOM_estimateParentId and isnull(ae_deleted,'N')='N') as EstimateRef,
				(select top 1 ae_internalref from BT_QUOTE_MASTER where ae_aeid=(select top 1 ae_parentid from BT_ESTIMATE_MASTER where ae_aeid = b.BOM_estimateParentId and isnull(ae_deleted,'N')='N') and isnull(ae_deleted,'N')='N') as QuoteRef,
				(select top 1 ae_internalref from BT_ENQUIRY_MASTER where ae_aeid=(select top 1 ae_Rootid from BT_ESTIMATE_MASTER where ae_aeid = b.BOM_estimateParentId and isnull(ae_deleted,'N')='N') and isnull(ae_deleted,'N')='N') as EnquiryRef,
				(select top 1 CUST_REFERENCE from BT_CUSTOMER_MASTER where cust_id = (select top 1 ae_customer from BT_ESTIMATE_MASTER where ae_aeid = b.BOM_estimateParentId and isnull(ae_deleted,'N')='N') ) as CustomerRef,
				(select top 1 CUST_ORG_NAME from BT_CUSTOMER_MASTER where cust_id = (select top 1 ae_customer from BT_ESTIMATE_MASTER where ae_aeid = b.BOM_estimateParentId and isnull(ae_deleted,'N')='N') ) as CustomerName
				from BT_ACT_BILLOFMATERIALS b 
				WHERE b.BOM_internalref=@activityRef and isnull(bom_deleted,'N')='N'
		END
		IF @activityRef like 'U%'
			BEGIN
				select top 1 p.ae_internalref as ProjectRef,
			   (select top 1 b.BOM_InternalRef from (select p.ae_aeid AS pid) x cross apply (select BOM_InternalRef, BOM_bomID from BT_ACT_BILLOFMATERIALS where BOM_generatedProject = x.pid and isnull(bom_deleted,'N')='N' union all select BOM_InternalRef, BOM_bomID from BT_ACT_BILLOFMATERIALS where BOM_generatedProject IS NULL and BOM_addToProject = x.pid and isnull(bom_deleted,'N')='N') b order by b.BOM_bomID) as BOMRef,
			   (select top 1 ae_internalref from BT_ESTIMATE_MASTER where AE_ParentID =(select top 1 ae_aeid from BT_QUOTE_MASTER where ae_parentId=p.ae_rootID and isnull(ae_deleted,'N')='N') and isnull(ae_deleted,'N')='N') as EstimateRef ,
			   (select top 1 ae_internalref from BT_QUOTE_MASTER where AE_ParentID =p.AE_RootID and isnull(ae_deleted,'N')='N') as QuoteRef ,
			   (select top 1 ae_internalref from BT_ENQUIRY_MASTER where ae_aeid =p.ae_rootID and isnull(ae_deleted,'N')='N') as EnquiryRef ,
			   (select top 1 CUST_REFERENCE from BT_CUSTOMER_MASTER where cust_id = p.ae_customer ) as CustomerRef,
			   (select top 1 CUST_ORG_NAME from BT_CUSTOMER_MASTER where cust_id = p.ae_customer) as CustomerName,
			   p.AE_AEID as ProjectID,
			   p.ae_customer as CustomerID,
			   (select dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(ae_address) from BT_ENQUIRY_MASTER where ae_aeid=p.ae_rootID) as SiteAddress
				from BT_PROJ_U_HEADER p 
	           WHERE p.AE_AEID=Substring(@activityRef,2,len(@activityRef)) and isnull(ae_deleted,'N')='N'
			END
		IF @activityRef like 'STK%'
			BEGIN
				select top 1 s.ae_internalref as STKRef,
				(select top 1 AE_internalRef from BT_PROJ_U_HEADER where ae_aeid= s.AE_ParentID and isnull(ae_deleted,'N')='N') as ProjectRef,
				(select top 1 b.BOM_InternalRef from (select (select top 1 ae_aeid from BT_PROJ_U_HEADER where ae_aeid= s.AE_ParentID and isnull(ae_deleted,'N')='N') AS pid) x cross apply (select BOM_InternalRef, BOM_bomID from BT_ACT_BILLOFMATERIALS where BOM_generatedProject = x.pid and isnull(bom_deleted,'N')='N' union all select BOM_InternalRef, BOM_bomID from BT_ACT_BILLOFMATERIALS where BOM_generatedProject IS NULL and BOM_addToProject = x.pid and isnull(bom_deleted,'N')='N') b order by b.BOM_bomID) as BOMRef,
				(select top 1 AE_internalRef from BT_ESTIMATE_MASTER where AE_ParentID =(select top 1 ae_aeid from BT_QUOTE_MASTER where ae_parentId=(select top 1 ae_rootID from BT_PROJ_U_HEADER where ae_aeid= s.AE_ParentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N') as EstimateRef ,
				(select top 1 ae_internalref from BT_QUOTE_MASTER where AE_ParentID =(select top 1 ae_rootID from BT_PROJ_U_HEADER where ae_aeid= s.AE_ParentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N') as QuoteRef ,
				(select top 1 AE_internalRef from BT_ENQUIRY_MASTER where ae_aeid=(select top 1 ae_rootID from BT_PROJ_U_HEADER where ae_aeid= s.AE_ParentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N') as EnquiryRef ,
				(select top 1 CUST_REFERENCE from BT_CUSTOMER_MASTER where cust_id = s.ae_customer) as CustomerRef,
				(select top 1 CUST_ORG_NAME from BT_CUSTOMER_MASTER where cust_id = s.ae_customer) as CustomerName,
				s.ae_customer as CustomerID,
				s.AE_ParentID as ProjectID,
				s.AE_AEID as STKID,
				(select dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(ae_address) from BT_ENQUIRY_MASTER where ae_aeid=s.AE_RootID) as SiteAddress
				from  BT_STK_HEADER s
				WHERE s.AE_AEID=Substring(@activityRef,4,len(@activityRef)) and isnull(ae_deleted,'N')='N'

			END
			IF @activityRef like 'PH%'
			BEGIN

			select top 1 @ae_aeid1 =ae_aeid from BT_PROJ_U_HEADER where AE_RootID= (select AE_ParentID from BT_PROJ_HEADER ph where ph.AE_AEID=Substring(@activityRef,3,len(@activityRef)) OR ph.AE_internalref=@activityRef and isnull(ae_deleted,'N')='N'
			) and isnull(ae_deleted,'N')='N'


			select top 1 @ae_aeid2 = ae_aeid from BT_PROJ_U_HEADER where ae_aeid= (select AE_ParentID from BT_PROJ_HEADER ph where ph.AE_AEID=Substring(@activityRef,3,len(@activityRef)) OR ph.AE_internalref=@activityRef and isnull(ae_deleted,'N')='N'
			) and isnull(ae_deleted,'N')='N'

			IF @ae_aeid1 <> ''
			BEGIN 
			select top 1 ph.ae_internalref as PHRef,
							(select top 1 AE_internalRef from BT_PROJ_U_HEADER where AE_RootID= ph.AE_ParentID and isnull(ae_deleted,'N')='N') as ProjectRef,
							(select top 1 ae_aeid from BT_PROJ_U_HEADER where AE_RootID= ph.AE_ParentID and isnull(ae_deleted,'N')='N') as ProjectID,
							(select top 1 b.BOM_InternalRef from (select (select top 1 ae_aeid from BT_PROJ_U_HEADER where AE_RootID= ph.AE_ParentID and isnull(ae_deleted,'N')='N') AS pid) x cross apply (select BOM_InternalRef, BOM_bomID from BT_ACT_BILLOFMATERIALS where BOM_generatedProject = x.pid and isnull(bom_deleted,'N')='N' union all select BOM_InternalRef, BOM_bomID from BT_ACT_BILLOFMATERIALS where BOM_generatedProject IS NULL and BOM_addToProject = x.pid and isnull(bom_deleted,'N')='N') b order by b.BOM_bomID) as BOMRef,
							(select top 1 AE_internalRef from BT_ESTIMATE_MASTER where AE_ParentID in (select top 1 ae_aeid from BT_QUOTE_MASTER where ae_parentId=(select top 1 ae_rootID from BT_PROJ_U_HEADER where AE_RootID= ph.AE_ParentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N') as EstimateRef ,
							(select top 1 ae_internalref from BT_QUOTE_MASTER where AE_ParentID in (select top 1 ae_rootID from BT_PROJ_U_HEADER where AE_RootID= ph.AE_ParentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N') as QuoteRef ,
							(select top 1 AE_internalRef from BT_ENQUIRY_MASTER where ae_aeid in (select top 1 ae_rootID from BT_PROJ_U_HEADER where AE_RootID= ph.AE_ParentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N') as EnquiryRef ,
							(select top 1 CUST_REFERENCE from BT_CUSTOMER_MASTER where cust_id = ph.ae_customer) as CustomerRef,
							(select top 1 CUST_ORG_NAME from BT_CUSTOMER_MASTER where cust_id = ph.ae_customer) as CustomerName,
							ph.ae_customer as CustomerID,
							--(select top 1 AE_internalRef from BT_PROJ_U_HEADER where ae_aeid= ph.AE_ParentID and isnull(ae_deleted,'N')='N') as ProjectID,
							--ph.AE_ParentID as ProjectID,
							ph.ae_aeid  as  PHID,
							(select dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(ae_address) from BT_ENQUIRY_MASTER where ae_aeid=ph.AE_RootID) as SiteAddress
							from  BT_PROJ_HEADER ph
							WHERE ph.AE_AEID=Substring(@activityRef,3,len(@activityRef)) OR ph.AE_internalref=@activityRef and isnull(ae_deleted,'N')='N'
			END 
			ELSE IF @ae_aeid2 <> ''
			BEGIN 
			select top 1 ph.ae_internalref as PHRef,
							(select top 1 AE_internalRef from BT_PROJ_U_HEADER where ae_aeid= ph.AE_ParentID and isnull(ae_deleted,'N')='N') as ProjectRef,
							(select top 1 ae_aeid from BT_PROJ_U_HEADER where ae_aeid= ph.AE_ParentID and isnull(ae_deleted,'N')='N') as ProjectID,
							(select top 1 b.BOM_InternalRef from (select (select top 1 ae_aeid from BT_PROJ_U_HEADER where ae_aeid= ph.AE_ParentID and isnull(ae_deleted,'N')='N') AS pid) x cross apply (select BOM_InternalRef, BOM_bomID from BT_ACT_BILLOFMATERIALS where BOM_generatedProject = x.pid and isnull(bom_deleted,'N')='N' union all select BOM_InternalRef, BOM_bomID from BT_ACT_BILLOFMATERIALS where BOM_generatedProject IS NULL and BOM_addToProject = x.pid and isnull(bom_deleted,'N')='N') b order by b.BOM_bomID) as BOMRef,
							(select top 1 AE_internalRef from BT_ESTIMATE_MASTER where AE_ParentID =(select top 1 ae_aeid from BT_QUOTE_MASTER where ae_parentId=(select top 1 ae_rootID from BT_PROJ_U_HEADER where ae_aeid= ph.AE_ParentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N') as EstimateRef ,
							(select top 1 ae_internalref from BT_QUOTE_MASTER where AE_ParentID =(select top 1 ae_rootID from BT_PROJ_U_HEADER where ae_aeid= ph.AE_ParentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N') as QuoteRef ,
							(select top 1 AE_internalRef from BT_ENQUIRY_MASTER where ae_aeid=(select top 1 ae_rootID from BT_PROJ_U_HEADER where ae_aeid= ph.AE_ParentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N') as EnquiryRef ,
							(select top 1 CUST_REFERENCE from BT_CUSTOMER_MASTER where cust_id = ph.ae_customer) as CustomerRef,
							(select top 1 CUST_ORG_NAME from BT_CUSTOMER_MASTER where cust_id = ph.ae_customer) as CustomerName,
							ph.ae_customer as CustomerID,
							--(select top 1 AE_internalRef from BT_PROJ_U_HEADER where ae_aeid= ph.AE_ParentID and isnull(ae_deleted,'N')='N') as ProjectID,
							--ph.AE_ParentID as ProjectID,
							ph.ae_aeid  as  PHID,
							(select dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(ae_address) from BT_ENQUIRY_MASTER where ae_aeid=ph.AE_RootID) as SiteAddress
							from  BT_PROJ_HEADER ph
							WHERE ph.AE_AEID=Substring(@activityRef,3,len(@activityRef)) OR ph.AE_internalref=@activityRef and isnull(ae_deleted,'N')='N'

			END 
			END
		IF @activityRef like 'CTK%'
		BEGIN
			DECLARE @CountCTK int; 
			SELECT @CountCTK=count(ae_internalref) from PLA_PROD.dbo.PLA_ACT_ACTIVITYEVENT where ae_internalref in (select ae_internalref from BT_CTK_HEADER where ae_aeid=Substring(@activityRef,4,len(@activityRef)))
			IF @CountCTK = 0
			BEGIN
				select top 1 c.ae_internalRef as CTKRef,
				(select top 1 AE_internalRef from BT_STK_HEADER where ae_aeid= c.AE_ParentID and isnull(ae_deleted,'N')='N') as STKRef,
				(select top 1 AE_internalRef from BT_PROJ_U_HEADER where ae_aeid= (select s.AE_ParentID from BT_STK_HEADER s where s.ae_aeid=c.AE_parentID and isnull(ae_deleted,'N')='N') and isnull(ae_deleted,'N')='N') as ProjectRef,
				(select top 1 b.BOM_InternalRef from (select (select top 1 ae_aeid from BT_PROJ_U_HEADER where ae_aeid= (select s.AE_ParentID from BT_STK_HEADER s where s.ae_aeid=c.AE_parentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N') AS pid) x cross apply (select BOM_InternalRef, BOM_bomID from BT_ACT_BILLOFMATERIALS where BOM_generatedProject = x.pid and isnull(bom_deleted,'N')='N' union all select BOM_InternalRef, BOM_bomID from BT_ACT_BILLOFMATERIALS where BOM_generatedProject IS NULL and BOM_addToProject = x.pid and isnull(bom_deleted,'N')='N') b order by b.BOM_bomID) as BOMRef,
				(select top 1 AE_internalRef from BT_ESTIMATE_MASTER where AE_ParentID =(select top 1 ae_aeid from BT_QUOTE_MASTER where ae_parentId=(select top 1 ae_rootID from BT_PROJ_U_HEADER where ae_aeid=(select s.AE_ParentID from BT_STK_HEADER s where s.ae_aeid=c.AE_parentID and isnull(ae_deleted,'N')='N') and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N') as EstimateRef ,
				(select top 1 ae_internalref from BT_QUOTE_MASTER where AE_ParentID =(select top 1 ae_rootID from BT_PROJ_U_HEADER where ae_aeid= (select s.AE_ParentID from BT_STK_HEADER s where s.ae_aeid=c.AE_parentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N' )and isnull(ae_deleted,'N')='N') as QuoteRef ,
				(select top 1 AE_internalRef from BT_ENQUIRY_MASTER where ae_aeid=(select top 1 ae_rootID from BT_PROJ_U_HEADER where ae_aeid= (select s.AE_ParentID from BT_STK_HEADER s where s.ae_aeid=c.AE_parentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N' )and isnull(ae_deleted,'N')='N') as EnquiryRef ,
				(select top 1 CUST_REFERENCE from BT_CUSTOMER_MASTER where cust_id = c.ae_customer) as CustomerRef,
				(select top 1 CUST_ORG_NAME from BT_CUSTOMER_MASTER where cust_id = c.ae_customer) as CustomerName,
				c.ae_customer as CustomerID,
				(select s.AE_ParentID from BT_STK_HEADER s where s.ae_aeid=c.AE_parentID and isnull(ae_deleted,'N')='N')as ProjectID,
				c.AE_ParentID as STKID,
				c.AE_AEID as CTKID,
				(select dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(ae_address) from BT_ENQUIRY_MASTER where ae_aeid=c.AE_RootID) as SiteAddress
				from  BT_CTK_HEADER c
				WHERE c.AE_AEID=Substring(@activityRef,4,len(@activityRef)) and isnull(ae_deleted,'N')='N'
			END
			ELSE IF @CountCTK <> 0
			BEGIN
				--------------To show migrated PLA CTK header also-------------
				select top 1 c.ae_internalRef as CTKRef,
				(select top 1 AE_internalRef from BT_STK_HEADER where ae_aeid= c.AE_ParentID and isnull(ae_deleted,'N')='N') as STKRef,
				(select top 1 AE_internalRef from BT_PROJ_U_HEADER where ae_aeid= c.AE_parentProjID and isnull(ae_deleted,'N')='N') as ProjectRef,
				(select top 1 b.BOM_InternalRef from (select (select top 1 ae_aeid from BT_PROJ_U_HEADER where ae_aeid= c.AE_parentProjID and isnull(ae_deleted,'N')='N') AS pid) x cross apply (select BOM_InternalRef, BOM_bomID from BT_ACT_BILLOFMATERIALS where BOM_generatedProject = x.pid and isnull(bom_deleted,'N')='N' union all select BOM_InternalRef, BOM_bomID from BT_ACT_BILLOFMATERIALS where BOM_generatedProject IS NULL and BOM_addToProject = x.pid and isnull(bom_deleted,'N')='N') b order by b.BOM_bomID) as BOMRef,
				(select top 1 AE_internalRef from BT_ESTIMATE_MASTER where AE_ParentID =(select top 1 ae_aeid from BT_QUOTE_MASTER where ae_parentId=(select top 1 ae_rootID from BT_PROJ_U_HEADER where ae_aeid=c.AE_parentProjID and isnull(ae_deleted,'N')='N') and isnull(ae_deleted,'N')='N') and isnull(ae_deleted,'N')='N') as EstimateRef ,
				(select top 1 ae_internalref from BT_QUOTE_MASTER where AE_ParentID =c.AE_rootid and isnull(ae_deleted,'N')='N') as QuoteRef ,
				(select top 1 AE_internalRef from BT_ENQUIRY_MASTER where ae_aeid=c.AE_rootid and isnull(ae_deleted,'N')='N')  as EnquiryRef ,
				(select top 1 CUST_REFERENCE from BT_CUSTOMER_MASTER where cust_id = c.ae_customer) as CustomerRef,
				(select top 1 CUST_ORG_NAME from BT_CUSTOMER_MASTER where cust_id = c.ae_customer) as CustomerName,
				c.ae_customer as CustomerID,
				(select s.AE_ParentID from BT_STK_HEADER s where s.ae_aeid=c.AE_parentID and isnull(ae_deleted,'N')='N')as ProjectID,
				c.AE_ParentID as STKID,
				c.AE_AEID as CTKID,
				(select dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(ae_address) from BT_ENQUIRY_MASTER where ae_aeid=c.AE_RootID) as SiteAddress
				from  BT_CTK_HEADER c
				WHERE c.AE_AEID=Substring(@activityRef,4,len(@activityRef)) and isnull(ae_deleted,'N')='N'
			END
			END
			IF @activityRef like 'TUL%'
			BEGIN
			DECLARE @CTKaeid int; 
			SELECT @CTKaeid=tutl_ae_aeid from BT_ACT_TIME_UTIL where tutl_internalref=@activityRef
			
				select top 1 c.ae_internalRef as CTKRef,
				(select top 1 AE_internalRef from BT_STK_HEADER where ae_aeid= c.AE_ParentID and isnull(ae_deleted,'N')='N') as STKRef,
				(select top 1 AE_internalRef from BT_PROJ_U_HEADER where ae_aeid= (select s.AE_ParentID from BT_STK_HEADER s where s.ae_aeid=c.AE_parentID and isnull(ae_deleted,'N')='N') and isnull(ae_deleted,'N')='N') as ProjectRef,
				(select top 1 b.BOM_InternalRef from (select (select top 1 ae_aeid from BT_PROJ_U_HEADER where ae_aeid= (select s.AE_ParentID from BT_STK_HEADER s where s.ae_aeid=c.AE_parentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N') AS pid) x cross apply (select BOM_InternalRef, BOM_bomID from BT_ACT_BILLOFMATERIALS where BOM_generatedProject = x.pid and isnull(bom_deleted,'N')='N' union all select BOM_InternalRef, BOM_bomID from BT_ACT_BILLOFMATERIALS where BOM_generatedProject IS NULL and BOM_addToProject = x.pid and isnull(bom_deleted,'N')='N') b order by b.BOM_bomID) as BOMRef,
				(select top 1 AE_internalRef from BT_ESTIMATE_MASTER where AE_ParentID =(select top 1 ae_aeid from BT_QUOTE_MASTER where ae_parentId=(select top 1 ae_rootID from BT_PROJ_U_HEADER where ae_aeid=(select s.AE_ParentID from BT_STK_HEADER s where s.ae_aeid=c.AE_parentID and isnull(ae_deleted,'N')='N') and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N') as EstimateRef ,
				(select top 1 ae_internalref from BT_QUOTE_MASTER where AE_ParentID =(select top 1 ae_rootID from BT_PROJ_U_HEADER where ae_aeid= (select s.AE_ParentID from BT_STK_HEADER s where s.ae_aeid=c.AE_parentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N' )and isnull(ae_deleted,'N')='N') as QuoteRef ,
				(select top 1 AE_internalRef from BT_ENQUIRY_MASTER where ae_aeid=(select top 1 ae_rootID from BT_PROJ_U_HEADER where ae_aeid= (select s.AE_ParentID from BT_STK_HEADER s where s.ae_aeid=c.AE_parentID and isnull(ae_deleted,'N')='N')and isnull(ae_deleted,'N')='N' )and isnull(ae_deleted,'N')='N') as EnquiryRef ,
				(select top 1 CUST_REFERENCE from BT_CUSTOMER_MASTER where cust_id = c.ae_customer) as CustomerRef,
				(select top 1 CUST_ORG_NAME from BT_CUSTOMER_MASTER where cust_id = c.ae_customer) as CustomerName,
				c.ae_customer as CustomerID,
				(select s.AE_ParentID from BT_STK_HEADER s where s.ae_aeid=c.AE_parentID and isnull(ae_deleted,'N')='N')as ProjectID,
				c.AE_ParentID as STKID,
				c.AE_AEID as CTKID,
				(select dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(ae_address) from BT_ENQUIRY_MASTER where ae_aeid=c.AE_RootID) as SiteAddress
				,@activityRef as TULRef
				from  BT_CTK_HEADER c
				WHERE c.AE_AEID=@CTKaeid and isnull(ae_deleted,'N')='N'
			END
	END

GO
