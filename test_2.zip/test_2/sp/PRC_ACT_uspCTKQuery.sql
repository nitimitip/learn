/******************************************************************************
  V2-06 - OPTIMIZED PROCEDURE - NOT EXECUTED - REVIEW AND TEST BEFORE DEPLOYMENT
  Procedure : [dbo].[PRC_ACT_uspCTKQuery]  (Find CTK screen)
  Original  : QPID_SP/PRC_ACT_uspCTKQuery.sql (not changed in phase 1)
  Batch     : V2-06 (2026-10-22)
  Generated : optimization_v2/tools/gen_v2_06.py (emulated original text ==
              new SELECT tokens; inverse transform == original: checked)
  Depends on: table_index/54_BT_CTK_HEADER_AE_mpan2.sql (warning only).

  WHY:
    Production baseline: 111 execs, avg 678.34 ms, CPU 869.67 ms
    (parallel), avg reads 70,989. BT_CTK_HEADER clustered = 548.82 MB =
    70,249 pages, so 98.96% of every call is ONE full clustered scan.
    Cause: WHERE AE_mpan1 = 'x' OR AE_mpan2 = 'x'. AE_mpan1 has an index,
    AE_mpan2 has none, so the OR can only be answered by a scan.

  WHAT CHANGED:
    1. Static SQL instead of EXEC(): same columns, names, joins and hints.
    2. MPAN given: <select> WHERE AE_mpan1 = @MPAN UNION <select> WHERE
       AE_mpan2 = @MPAN (two seeks). No MPAN (NULL or 1 char): the same
       unfiltered select as before (all CTKs).
    3. CREATE -> ALTER. PRINT of the built text removed (message only).

  WHY IT IS EQUIVALENT:
    UNION returns the distinct rows of both halves = the distinct rows
    matching either column = SELECT DISTINCT ... OR. Neither version has
    an ORDER BY (row order was and is plan-dependent). @MPAN is
    varchar(50) like the old literal and the columns, so the comparison
    (collation, trailing spaces) is the same.

  BEHAVIOUR DIFFERENCE (sign-off, same item as B02-2 / B06-2):
    An MPAN containing a quote used to give a syntax error (or inject
    SQL); it is now searched literally.

  EXPECTED: an estimate, not measured: ~20-40 reads per search (two index
    seeks + key lookups + customer / contact seeks) instead of 70,989.

  ROLLBACK: optimization_v2/rollback/PRC_ACT_uspCTKQuery_ORIGINAL.sql
******************************************************************************/
-- Guard: warns (does not stop) when index 54 is missing. Without it the
-- AE_mpan2 half scans BT_CTK_HEADER once, which is what the original does
-- on every call, so the procedure is never worse than today.
IF NOT EXISTS (SELECT 1 FROM sys.indexes i
               JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
               JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
               WHERE i.object_id = OBJECT_ID('dbo.BT_CTK_HEADER') AND ic.key_ordinal = 1
                 AND c.name = 'AE_mpan2' AND i.is_disabled = 0)
    PRINT 'WARNING: no index leads with BT_CTK_HEADER.AE_mpan2 - deploy table_index/54 first; the AE_mpan2 half will scan.';
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* SP3*/
ALTER PROCEDURE [dbo].[PRC_ACT_uspCTKQuery]
@MPAN VARCHAR(50)
AS
-- =============================================
-- Author:		<Madhumita Mondal>
-- Create date: <29-04-2021>
-- Description:	<To Search Data using MPAN>
-- =============================================
-- V2-06 (2026-10-22): the same SELECT as static SQL. The OR over two
-- columns is split into a UNION of two seeks (index
-- ADM_MI_IX_AE_mpan1_AE_AEID and index 54 on AE_mpan2); UNION removes
-- duplicates exactly as DISTINCT did over the OR. @MPAN is a parameter,
-- no longer a literal in the text. The PRINT of the built text is gone.
IF len(isnull(@MPAN,'')) > 1
BEGIN
	SELECT DISTINCT AE_internalRef AS [CTK Reference No], AE_AEID AS [CTK No],C.CUST_ORG_NAME AS [Customer Name],
	AE_summaryDescription [CTK Description],
	 Con.con_personalTitle + ' ' + Con.con_forename + ' '+ Con.con_surname AS [Contact Name]
	 FROM BT_CTK_HEADER A WITH (NOLOCK)
	INNER JOIN BT_CUSTOMER_MASTER C WITH (NOLOCK) on A.AE_customer=C.CUST_ID
	 LEFT OUTER JOIN BT_CONTACTS_MASTER Con WITH (NOLOCK) on Con.con_contactID=C.CUST_PRIM_CONTACTID
	 WHERE AE_mpan1 = @MPAN
	UNION
	SELECT DISTINCT AE_internalRef AS [CTK Reference No], AE_AEID AS [CTK No],C.CUST_ORG_NAME AS [Customer Name],
	AE_summaryDescription [CTK Description],
	 Con.con_personalTitle + ' ' + Con.con_forename + ' '+ Con.con_surname AS [Contact Name]
	 FROM BT_CTK_HEADER A WITH (NOLOCK)
	INNER JOIN BT_CUSTOMER_MASTER C WITH (NOLOCK) on A.AE_customer=C.CUST_ID
	 LEFT OUTER JOIN BT_CONTACTS_MASTER Con WITH (NOLOCK) on Con.con_contactID=C.CUST_PRIM_CONTACTID
	 WHERE AE_mpan2 = @MPAN
END
ELSE
BEGIN
	SELECT DISTINCT AE_internalRef AS [CTK Reference No], AE_AEID AS [CTK No],C.CUST_ORG_NAME AS [Customer Name],
	AE_summaryDescription [CTK Description],
	 Con.con_personalTitle + ' ' + Con.con_forename + ' '+ Con.con_surname AS [Contact Name]
	 FROM BT_CTK_HEADER A WITH (NOLOCK)
	INNER JOIN BT_CUSTOMER_MASTER C WITH (NOLOCK) on A.AE_customer=C.CUST_ID
	 LEFT OUTER JOIN BT_CONTACTS_MASTER Con WITH (NOLOCK) on Con.con_contactID=C.CUST_PRIM_CONTACTID
END




GO
