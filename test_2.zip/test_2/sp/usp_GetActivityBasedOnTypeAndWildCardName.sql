/******************************************************************************
  V2-03 - PENDING VALIDATION - DEPLOY INDEXES 44-50 FIRST (guard 3 enforces it)
  Procedure : [dbo].[usp_GetActivityBasedOnTypeAndWildCardName]
  Original  : QPID_SP/usp_GetActivityBasedOnTypeAndWildCardName.sql
  Builds on : Batch 02 (optimization/sp/..., deployed on UAT only; it is
              contained in V2-03, so production goes original -> V2-03)
  Batch     : V2-03 (2026-10-20)
  Generated : optimization_v2/tools/gen_v2_03.py (original + B02 edits ==
              deployed B02 file; inverse of V2-03 edits == B02: checked)

  WHY:
    Baseline : 18,815 execs, 1,848.56 ms, CPU 901 ms, 115,566 reads.
    B02      : 17 execs, 1,579.94 ms, CPU 1,272.46 ms, 92,920 reads (-20%).
    92,920 reads is a large part of one clustered scan (ENQ 151.0k, QUO
    145.3k, PH 79.3k, CTK 70.2k, STK 65.0k pages); the ref indexes are
    1.0k-10.4k pages. B02 made the ref filter SARGable, but:
    (1) Each IX_<table>_<ref> index holds the ref only, so every matching
        row needs a key lookup to test the deleted flag. For a prefix that
        matches thousands of rows the optimizer therefore prefers walking
        the clustered PK in AE_AEID order and stopping at 20 matches.
    (2) That walk is costed with a ROW GOAL that assumes matches are spread
        evenly over AE_AEID. They are not: refs are <prefix> + a sequential
        number (STK/CTK = 'STK'/'CTK' + AE_AEID, ENQ = 'ENQ' + enquiry id,
        QUO = 'QUO' + quote id; live refs mix 6-7 digit legacy ids and 8
        digit ids such as ENQ23026620), so the matches of a prefix sit in
        one AE_AEID range and the walk reads everything before it.
    (3) A pattern with a leading wildcard from the caller cannot seek at all
        and scans the clustered index today.
    [Inferred from code + sizes; the branch mix and patterns are not in
    the stats. validation/v2_03_validation.sql V2-03.1 reads them from
    Query Store when it is on.]

  WHAT CHANGED (and nothing else), in each of the 8 branches:
    IF (@CDMSRef IS NULL OR @CDMSRef = '')
        <B02 statement, unchanged>
    ELSE
        <the same statement text>
        OPTION (RECOMPILE, USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
    With indexes 44-50 (ref index INCLUDE deleted flag; TUL: index 04)
    the no-row-goal plan reads the ref index range (or, for a leading
    wildcard, the whole ref index), keeps the non-deleted rows, TOP-N
    sorts them on the clustered key and looks up 20 rows. Worst case =
    one ref index (1.0k-10.4k pages) + ~60 lookup reads, whatever the
    pattern. NULL / '' keep the B02 plan: their walk stops after the
    first 20 live rows, which the hint would make far worse.

  WHY IT IS EQUIVALENT:
    Both copies of each statement are the same text (asserted by the
    generator); a hint changes plan choice only. ORDER BY is on the
    unique clustered key (AE_AEID / BOM_bomID), so TOP 20 is
    deterministic, except TUL (Tutl_TimeUtil_Id is the first column of a
    two-column PK): ties there were plan-dependent in B02 too.
    '   ' = '' in T-SQL (trailing blanks), so a blank-only ref takes the
    B02 path; its rows are the same either way.

  COST: unchanged compile (B02 already recompiles). Index 44-50 writes are
    low (4.3k-6.8k NC writes per index in the stats window); only a change
    of the deleted flag adds a write to the ref index.

  ROLLBACK: UAT -> optimization_v2/rollback/usp_GetActivityBasedOnTypeAndWildCardName_B02.sql;
    production -> .../usp_GetActivityBasedOnTypeAndWildCardName_ORIGINAL.sql. Indexes 44-50 can stay (they only add
    an INCLUDE); each file has its own rollback block.
******************************************************************************/

-- GUARD 1 (from Batch 02): every ref column must be case-insensitive
IF EXISTS (
    SELECT 1
    FROM sys.columns c
    WHERE (   (c.object_id IN (OBJECT_ID('dbo.BT_PROJ_U_HEADER'), OBJECT_ID('dbo.BT_STK_HEADER'),
                               OBJECT_ID('dbo.BT_CTK_HEADER'), OBJECT_ID('dbo.BT_PROJ_HEADER'),
                               OBJECT_ID('dbo.BT_ENQUIRY_MASTER'), OBJECT_ID('dbo.BT_QUOTE_MASTER'))
               AND c.name = 'AE_internalRef')
           OR (c.object_id = OBJECT_ID('dbo.BT_ACT_BILLOFMATERIALS') AND c.name = 'BOM_internalRef')
           OR (c.object_id = OBJECT_ID('dbo.BT_ACT_TIME_UTIL')       AND c.name = 'Tutl_internalRef'))
      AND (c.collation_name IS NULL OR c.collation_name NOT LIKE '%[_]CI[_]%')
)
BEGIN
    RAISERROR('Case-sensitive collation found on a ref column: UPPER() removal is NOT equivalent. Deployment aborted.', 16, 1);
    SET NOEXEC ON;
END
-- GUARD 2: USE HINT('DISABLE_OPTIMIZER_ROWGOAL') needs SQL Server 2016 SP1+
-- (the table scripts carry OPTIMIZE_FOR_SEQUENTIAL_KEY, i.e. 2019+; checked anyway)
IF CAST(SERVERPROPERTY('ProductMajorVersion') AS int) < 13
   OR (CAST(SERVERPROPERTY('ProductMajorVersion') AS int) = 13
       AND CAST(SERVERPROPERTY('ProductLevel') AS nvarchar(20)) = N'RTM')
BEGIN
    RAISERROR('USE HINT needs SQL Server 2016 SP1 or later. Deployment aborted.', 16, 1);
    SET NOEXEC ON;
END
-- GUARD 3: indexes 44-50 must be deployed first. Without the deleted flag in
-- the ref index, a no-row-goal plan can choose a FULL clustered scan where
-- B02 sometimes got away with a partial one, i.e. worse than today.
IF EXISTS (
    SELECT 1
    FROM (VALUES ('BT_ENQUIRY_MASTER', 'IX_BT_ENQUIRY_MASTER_AE_internalRef', 'AE_deleted'),
                 ('BT_QUOTE_MASTER', 'IX_BT_QUOTE_MASTER_AE_internalRef', 'AE_deleted'),
                 ('BT_CTK_HEADER', 'IX_BT_CTK_HEADER_AE_internalRef', 'AE_deleted'),
                 ('BT_STK_HEADER', 'IX_BT_STK_HEADER_AE_internalRef', 'AE_deleted'),
                 ('BT_PROJ_U_HEADER', 'IX_BT_PROJ_U_HEADER_AE_internalRef', 'AE_deleted'),
                 ('BT_PROJ_HEADER', 'IX_BT_PROJ_HEADER_AE_internalRef', 'AE_deleted'),
                 ('BT_ACT_BILLOFMATERIALS', 'IX_BT_ACT_BILLOFMATERIALS_BOM_internalRef', 'BOM_deleted')) v(t, ix, col)
    WHERE NOT EXISTS (
        SELECT 1
        FROM sys.indexes i
        JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
        JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
        WHERE i.object_id = OBJECT_ID('dbo.' + v.t) AND i.name = v.ix
          AND c.name = v.col AND ic.is_included_column = 1)
)
BEGIN
    RAISERROR('A ref index lacks its deleted-flag INCLUDE: deploy optimization_v2/table_index/44-50 first. Deployment aborted.', 16, 1);
    SET NOEXEC ON;
END
-- Advisory only: the TUL branch needs phase-1 index 04 to avoid a 34.9k-page scan
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.BT_ACT_TIME_UTIL')
                 AND name = 'IX_BT_ACT_TIME_UTIL_Tutl_internalRef')
    PRINT 'WARNING: index 04 (IX_BT_ACT_TIME_UTIL_Tutl_internalRef) is missing; TUL searches keep scanning.';
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		TCS: Sumanta Dhara
-- Create date: 29-Jan-2020
-- Description:	It returns the Activity like Project, STK and CTK based on Activity Type and wild card internal ref.
-- 14-Oct-2026	Perf batch 02: SARGable ref filter (CI collation), OPTION (RECOMPILE)
-- 20-Oct-2026	Perf V2-03: ref pattern path without row goal, OPTION (RECOMPILE, USE HINT); needs indexes 44-50
-- =============================================
-- [usp_GetActivityBasedOnTypeAndWildCardName] 'TUL','TUL179',null,null,null,null,1,20
ALTER PROCEDURE [dbo].[usp_GetActivityBasedOnTypeAndWildCardName] 
(	-- Add the parameters for the stored procedure here
	@ActivityType VARCHAR(20), 
	@CDMSRef VARCHAR(30) = null,
	@ProjectID int = null,
	@SimpleTaskID int = null,
	@CDMSProjectRef VARCHAR(30) = NULL,
	@CDMSSimpleTaskRef VARCHAR(30) = NULL,
	@PageNumber INT  = 1 ,
	@PageSize INT = 10
)
AS
BEGIN
	SET NOCOUNT ON;
	Set @PageSize=20
	IF(UPPER(@ActivityType) = 'PROJECT')
	BEGIN 
		
				IF (@CDMSRef IS NULL OR @CDMSRef = '')
				SELECT	top (@PageSize)
						case when source_SYS='CDA' Then Concat(AE_internalRef,' - CEES PROJECT') Else Concat(AE_internalRef,' - UKD PROJECT') End CDMSRef,
						AE_relativeName AS ActivityName, 
						AE_dateCreated AS CreateDate, 
						AE_AEID, 
						@ActivityType AS ActivityType,
						AE_customer AS CustomerID,
						AE_parentProjID AS ProjectID
				FROM [dbo].[BT_PROJ_U_HEADER] 
				WHERE AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR AE_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY AE_AEID
				OPTION (RECOMPILE)
				ELSE -- V2-03: ref pattern supplied; no row goal, cost bounded by the ref index
				SELECT	top (@PageSize)
						case when source_SYS='CDA' Then Concat(AE_internalRef,' - CEES PROJECT') Else Concat(AE_internalRef,' - UKD PROJECT') End CDMSRef,
						AE_relativeName AS ActivityName, 
						AE_dateCreated AS CreateDate, 
						AE_AEID, 
						@ActivityType AS ActivityType,
						AE_customer AS CustomerID,
						AE_parentProjID AS ProjectID
				FROM [dbo].[BT_PROJ_U_HEADER] 
				WHERE AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR AE_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY AE_AEID
				OPTION (RECOMPILE, USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
	END
	ELSE IF(UPPER(@ActivityType) = 'STK')
	BEGIN 
		
				IF (@CDMSRef IS NULL OR @CDMSRef = '')
				SELECT  top (@PageSize)
						AE_internalRef AS CDMSRef, 
						AE_relativeName AS ActivityName, 
						AE_dateCreated AS CreateDate, 
						AE_AEID, 
						@ActivityType AS ActivityType,
						AE_customer AS CustomerID,
						AE_parentProjID AS ProjectID
				FROM [dbo].[BT_STK_HEADER] 
				WHERE AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR AE_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY AE_AEID
				OPTION (RECOMPILE)
				ELSE -- V2-03: ref pattern supplied; no row goal, cost bounded by the ref index
				SELECT  top (@PageSize)
						AE_internalRef AS CDMSRef, 
						AE_relativeName AS ActivityName, 
						AE_dateCreated AS CreateDate, 
						AE_AEID, 
						@ActivityType AS ActivityType,
						AE_customer AS CustomerID,
						AE_parentProjID AS ProjectID
				FROM [dbo].[BT_STK_HEADER] 
				WHERE AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR AE_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY AE_AEID
				OPTION (RECOMPILE, USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
	END
	ELSE IF(UPPER(@ActivityType) = 'CTK')
	BEGIN 
		
				IF (@CDMSRef IS NULL OR @CDMSRef = '')
				SELECT top (@PageSize)
						AE_internalRef AS CDMSRef, 
						AE_relativeName AS ActivityName, 
						AE_dateCreated AS CreateDate, 
						AE_AEID, 
						@ActivityType AS ActivityType,
						AE_customer AS CustomerID,
						AE_parentProjID AS ProjectID
				FROM [dbo].[BT_CTK_HEADER] 
				WHERE AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR AE_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY AE_AEID
				OPTION (RECOMPILE)
				ELSE -- V2-03: ref pattern supplied; no row goal, cost bounded by the ref index
				SELECT top (@PageSize)
						AE_internalRef AS CDMSRef, 
						AE_relativeName AS ActivityName, 
						AE_dateCreated AS CreateDate, 
						AE_AEID, 
						@ActivityType AS ActivityType,
						AE_customer AS CustomerID,
						AE_parentProjID AS ProjectID
				FROM [dbo].[BT_CTK_HEADER] 
				WHERE AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR AE_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY AE_AEID
				OPTION (RECOMPILE, USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
	END
	ELSE IF(UPPER(@ActivityType) = 'PROGRESSH')
	BEGIN 
		
				IF (@CDMSRef IS NULL OR @CDMSRef = '')
				SELECT  top (@PageSize)
						AE_internalRef AS CDMSRef, 
						AE_relativeName AS ActivityName, 
						AE_dateCreated AS CreateDate, 
						AE_AEID, 
						@ActivityType AS ActivityType,
						AE_customer AS CustomerID,
						AE_parentProjID AS ProjectID
				FROM [dbo].[BT_PROJ_HEADER] 
				WHERE AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR AE_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY AE_AEID
				OPTION (RECOMPILE)
				ELSE -- V2-03: ref pattern supplied; no row goal, cost bounded by the ref index
				SELECT  top (@PageSize)
						AE_internalRef AS CDMSRef, 
						AE_relativeName AS ActivityName, 
						AE_dateCreated AS CreateDate, 
						AE_AEID, 
						@ActivityType AS ActivityType,
						AE_customer AS CustomerID,
						AE_parentProjID AS ProjectID
				FROM [dbo].[BT_PROJ_HEADER] 
				WHERE AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR AE_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY AE_AEID
				OPTION (RECOMPILE, USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
	END
	ELSE IF(UPPER(@ActivityType) = 'ENQ')
	BEGIN 
		
				IF (@CDMSRef IS NULL OR @CDMSRef = '')
				SELECT  top (@PageSize)
						AE_internalRef AS CDMSRef, 
						AE_relativeName AS ActivityName, 
						AE_dateCreated AS CreateDate, 
						AE_AEID, 
						@ActivityType AS ActivityType,
						AE_customer AS CustomerID,
						AE_parentProjID AS ProjectID
				FROM [dbo].BT_ENQUIRY_MASTER 
				WHERE AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR AE_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY AE_AEID
				OPTION (RECOMPILE)
				ELSE -- V2-03: ref pattern supplied; no row goal, cost bounded by the ref index
				SELECT  top (@PageSize)
						AE_internalRef AS CDMSRef, 
						AE_relativeName AS ActivityName, 
						AE_dateCreated AS CreateDate, 
						AE_AEID, 
						@ActivityType AS ActivityType,
						AE_customer AS CustomerID,
						AE_parentProjID AS ProjectID
				FROM [dbo].BT_ENQUIRY_MASTER 
				WHERE AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR AE_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY AE_AEID
				OPTION (RECOMPILE, USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
	END
	ELSE IF(UPPER(@ActivityType) = 'QUO')
	BEGIN 
		
				IF (@CDMSRef IS NULL OR @CDMSRef = '')
				SELECT  top (@PageSize)
						AE_internalRef AS CDMSRef, 
						AE_relativeName AS ActivityName, 
						AE_dateCreated AS CreateDate, 
						AE_AEID, 
						@ActivityType AS ActivityType,
						AE_customer AS CustomerID,
						AE_parentProjID AS ProjectID
				FROM [dbo].BT_QUOTE_MASTER 
				WHERE AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR AE_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY AE_AEID
				OPTION (RECOMPILE)
				ELSE -- V2-03: ref pattern supplied; no row goal, cost bounded by the ref index
				SELECT  top (@PageSize)
						AE_internalRef AS CDMSRef, 
						AE_relativeName AS ActivityName, 
						AE_dateCreated AS CreateDate, 
						AE_AEID, 
						@ActivityType AS ActivityType,
						AE_customer AS CustomerID,
						AE_parentProjID AS ProjectID
				FROM [dbo].BT_QUOTE_MASTER 
				WHERE AE_deleted = 'N'
				AND (@CDMSRef IS NULL OR AE_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY AE_AEID
				OPTION (RECOMPILE, USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
	END
	ELSE IF(UPPER(@ActivityType) = 'BOM')
	BEGIN 
			
				IF (@CDMSRef IS NULL OR @CDMSRef = '')
				SELECT top (@PageSize) BOM_internalRef AS CDMSRef, 
						'' AS ActivityName, 
						BOM_dateCreated AS CreateDate, 
						BOM_bomID AS AE_AEID, 
						@ActivityType AS ActivityType,
						(Select  CUST_ID from BT_CUSTOMER_MASTER where CUST_ID =(SELECT BT_QUOTE_MASTER.AE_customer FROM BT_QUOTE_MASTER 
						WHERE BT_QUOTE_MASTER.AE_AEID=(SELECT AE_PARENTID FROM BT_ESTIMATE_MASTER where AE_AEID=b.BOM_estimateParentID)))  AS CustomerID,
						'0' AS ProjectID
				FROM [dbo].BT_ACT_BILLOFMATERIALS  b
				WHERE BOM_deleted = 'N'
				AND (@CDMSRef IS NULL OR BOM_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY AE_AEID
				OPTION (RECOMPILE)
				ELSE -- V2-03: ref pattern supplied; no row goal, cost bounded by the ref index
				SELECT top (@PageSize) BOM_internalRef AS CDMSRef, 
						'' AS ActivityName, 
						BOM_dateCreated AS CreateDate, 
						BOM_bomID AS AE_AEID, 
						@ActivityType AS ActivityType,
						(Select  CUST_ID from BT_CUSTOMER_MASTER where CUST_ID =(SELECT BT_QUOTE_MASTER.AE_customer FROM BT_QUOTE_MASTER 
						WHERE BT_QUOTE_MASTER.AE_AEID=(SELECT AE_PARENTID FROM BT_ESTIMATE_MASTER where AE_AEID=b.BOM_estimateParentID)))  AS CustomerID,
						'0' AS ProjectID
				FROM [dbo].BT_ACT_BILLOFMATERIALS  b
				WHERE BOM_deleted = 'N'
				AND (@CDMSRef IS NULL OR BOM_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY AE_AEID
				OPTION (RECOMPILE, USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
	END
	ELSE IF(UPPER(@ActivityType) = 'TUL')
	BEGIN 
			
				IF (@CDMSRef IS NULL OR @CDMSRef = '')
				SELECT top (@PageSize) Tutl_internalRef AS CDMSRef, 
						'' AS ActivityName, 
						Tutl_dateCreated AS CreateDate, 
						Tutl_TimeUtil_Id AS AE_AEID, 
						@ActivityType AS ActivityType,
						'0'  AS CustomerID,
						'0' AS ProjectID
				FROM [dbo].BT_ACT_TIME_UTIL  b
				WHERE Tutl_deleted = 'N'
				AND (@CDMSRef IS NULL OR Tutl_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY Tutl_TimeUtil_Id
				OPTION (RECOMPILE)
				ELSE -- V2-03: ref pattern supplied; no row goal, cost bounded by the ref index
				SELECT top (@PageSize) Tutl_internalRef AS CDMSRef, 
						'' AS ActivityName, 
						Tutl_dateCreated AS CreateDate, 
						Tutl_TimeUtil_Id AS AE_AEID, 
						@ActivityType AS ActivityType,
						'0'  AS CustomerID,
						'0' AS ProjectID
				FROM [dbo].BT_ACT_TIME_UTIL  b
				WHERE Tutl_deleted = 'N'
				AND (@CDMSRef IS NULL OR Tutl_internalRef like UPPER(@CDMSRef) + '%')
				ORDER BY Tutl_TimeUtil_Id
				OPTION (RECOMPILE, USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
	END
END
GO
SET NOEXEC OFF
GO
