/******************************************************************************
  V2-02 CONDITIONAL CANDIDATE - DEPLOY ONLY IF V2-02.1 / V2-02.2 SAY SO
  Procedure : [dbo].[SP_ACT_GET_MATCHINGCUST]
  Original  : QPID_SP/SP_ACT_GET_MATCHINGCUST.sql (NOT changed in phase 1)
  Batch     : V2-02 (2026-10-20)
  Generated : optimization_v2/tools/gen_v2_02.py (inverse transform =
              original, checked)
  Depends on: nothing (no index).

  WHY:
    Baseline : 1,072 execs, avg 949.83 ms, CPU 466.52 ms, reads 13,990.
    2026-10-20: 12 execs, avg 2,706.92 ms, CPU 1,601.90 ms, reads 299,622.
    No phase-1 change touched this procedure, its three tables
    (BT_CUSTOMER_MASTER, BT_CONTACTS_MASTER, BT_ADDRESS_MASTER) or their
    indexes. The post-deploy window started with a fresh plan cache, so
    the procedure was recompiled with whatever parameters the first call
    had: one cached plan serves 10 statements in 9 search branches, and
    each is compiled for the sniffed (mostly NULL / '') values.
    Arithmetic: with the good plan for each branch the most expensive
    branch is ~76k reads (address: one BT_ADDRESS_MASTER scan, 71.7k
    pages); 12 calls x 76k = 0.9M, but the window has 3.6M. So some calls
    cost more than any branch's good plan. Two shapes fit:
      (a) plan: address branch as a per-customer nested loop (196,901
          customers x 3-page PK seek ~= 0.6M, plus the contacts join);
      (b) rows: a broad search returning many rows, each paying the
          address UDF + 2 scalar lookups.
    OPTION (RECOMPILE) fixes (a): every statement is compiled for the real
    values, including the local pattern variables (@vAddress,
    @vCUST_ORG_NAME), which the optimizer otherwise guesses.

  WHAT CHANGED (and nothing else):
    OPTION (RECOMPILE) on the 10 SELECT statements (lines 74, 87, 104,
    126, 140, 152, 165, 180, 198, 220). CREATE -> ALTER.

  WHY IT IS EQUIVALENT:
    A query hint changes how a plan is chosen, never which rows qualify.
    TOP 50 statements keep ORDER BY UPDATED_ON desc (ties on UPDATED_ON
    were already plan-dependent).

  COST: one compile per executed statement (one per call; ~200 calls a
    day in the baseline window).

  UNCHANGED (Batch 28 notes, app team, NOT fixed): address-branch AND/OR
    precedence (deleted customers returned), CUST_PRIM_CONTACTID =
    con_parentID join (repeated rows), two result sets from the telephone
    branch, '%' applied twice to @pContactPref, NULL name parts.

  ROLLBACK: optimization_v2/rollback/SP_ACT_GET_MATCHINGCUST_ORIGINAL.sql
******************************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
  
  
  
ALTER PROCEDURE [dbo].[SP_ACT_GET_MATCHINGCUST]   
  
 @pCUST_ORG_NAME VARCHAR(500) = NULL,  
 @pContactPref VARCHAR(500) = NULL,  
 @pContactFirst VARCHAR(500) = NULL,  
 @pContactLast VARCHAR(500) = NULL,  
 @pCustrefID  VARCHAR(25) = NULL,  
 @pAddress  VARCHAR(500) = NULL,  
 @ptelephoneno VARCHAR(50) = NULL,  
 @pContEmail  VARCHAR(50) = NULL,  
 @pPostcode  VARCHAR(50) = NULL,  
 @pCFSID   VARCHAR(50) = NULL,  
 @pContCFSID   VARCHAR(50) = NULL,  
 @pErrorMessage  VARCHAR(5000) OUTPUT   
  
/**************************************************************             
-- Procedure Name : [CDMS_ACT_uspGetCustomerData]  ,  
-- Description  : Populate Recently updated customer by user  
-- Parameters  :   
        
      @pErrorMessage - Output parameter to return the error message  
  
-- Return Value : 0 Success     
--      1 Failure  
  
-- Date Created Created By    Modifications  
-- 23-Oct-2019  Madhumita       
**************************************************************/  
AS  
BEGIN  
  
 SET NOCOUNT ON;  
 DECLARE @vContactname nvarchar(max)  
 DECLARE @vCUST_ORG_NAME nvarchar(max)  
 DECLARE @vAddress nvarchar(max)  
 DECLARE @vContEmail nvarchar(max)  
  
BEGIN TRY  
  SET @pErrorMessage = ''  
    
  --SET @pCustrefID = 'CUS1216'  
   
SET @pContactPref = '%'+LTRIM(RTRIM(@pContactPref))+'%'  
SET @pContactFirst = '%'+LTRIM(RTRIM(@pContactFirst))+'%'  
SET @pContactLast = '%'+LTRIM(RTRIM(@pContactLast))+'%'  
SET @pContactPref = '%'+LTRIM(RTRIM(@pContactPref))+'%'  
SET @vCUST_ORG_NAME = '%'+LTRIM(RTRIM(@pCUST_ORG_NAME))+'%'  
SET @vContEmail = '%'+LTRIM(RTRIM(@pContEmail))+'%'  
SET @vAddress = '%'+LTRIM(RTRIM(@pAddress))+'%'  
  
IF @pCustrefID<>''  
BEGIN  
  
  SELECT cust.[cust_reference] AS [Customer Reference]  
 ,cust.[cust_org_name] AS [Customer Name]  
 ,cust.source_sys  
 ,(SELECT dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(address_id)  --addressLine5+','+addressLine8+','+postCode   
 FROM BT_ADDRESS_MASTER Where ADDRESS_ID=CUST_PRIM_ADDRID) AS [Primary Address]  
 ,(SELECT con_contactname FROM BT_CONTACTS_MASTER WHERE con_contactID=CUST_PRIM_CONTACTID) AS [Primary Contact]  
 ,cust.[CUST_ID] AS [CustomerID],CFSID  
 FROM BT_CUSTOMER_MASTER cust  
 WHERE cust.cust_reference = @pCustrefID  
 and CUST_DELETED = 'N'  
 ORDER BY cust.UPDATED_ON desc OPTION (RECOMPILE);  
END  
ELSE IF @pContEmail<>''  
BEGIN  
 SELECT   cust.[cust_reference] AS [Customer Reference]  
 ,cust.[cust_org_name] AS [Customer Name],cust.source_sys  
 ,(SELECT dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(address_id) --addressLine5+','+addressLine8+','+postCode   
 FROM BT_ADDRESS_MASTER Where ADDRESS_ID=CUST_PRIM_ADDRID) AS [Primary Address]  
 ,(SELECT con_contactname FROM BT_CONTACTS_MASTER WHERE con_contactID=CUST_PRIM_CONTACTID) AS [Primary Contact]  
 ,cust.[CUST_ID] AS [CustomerID]  
 FROM BT_CUSTOMER_MASTER cust  
 WHERE CUST_ID in (select con_parentID FROM BT_CONTACTS_MASTER WHERE con_email like '%'+LTRIM(RTRIM(@pContEmail))+'%')  
 and CUST_DELETED = 'N'  
 ORDER BY cust.UPDATED_ON desc OPTION (RECOMPILE);  
END  
ELSE IF @ptelephoneno<>''  
BEGIN  
SELECT  distinct cust.[cust_reference] AS [Customer Reference]  
 ,cust.[cust_org_name] AS [Customer Name],cust.source_sys  
 ,(SELECT dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(address_id) --addressLine5+','+addressLine8+','+postCode   
 FROM BT_ADDRESS_MASTER Where ADDRESS_ID=CUST_PRIM_ADDRID) AS [Primary Address]  
 ,(SELECT con_contactname FROM BT_CONTACTS_MASTER WHERE con_contactID=CUST_PRIM_CONTACTID) AS [Primary Contact]  
 ,cust.[CUST_ID] AS [CustomerID]  
 FROM BT_CUSTOMER_MASTER cust  
 WHERE (CUST_ID in ((select con_parentID FROM BT_CONTACTS_MASTER WHERE   
 con_deleted='N'   
 and (con_telephone = @ptelephoneno OR con_mobile = @ptelephoneno))  
  )  
  Or   
 cust_id in (select cust_id from  BT_CUSTOMER_MASTER c where c.CUST_TELEPHONE = @ptelephoneno))  
    and CUST_DELETED = 'N' OPTION (RECOMPILE)  
  
 SELECT  distinct cust.[cust_reference] AS [Customer Reference]  
 ,cust.[cust_org_name] AS [Customer Name],cust.source_sys  
 ,(SELECT dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(address_id) --addressLine5+','+addressLine8+','+postCode   
 FROM BT_ADDRESS_MASTER Where ADDRESS_ID=CUST_PRIM_ADDRID) AS [Primary Address]  
 ,(SELECT con_contactname FROM BT_CONTACTS_MASTER WHERE con_contactID=CUST_PRIM_CONTACTID) AS [Primary Contact]  
 ,cust.[CUST_ID] AS [CustomerID]  
 FROM BT_CUSTOMER_MASTER cust  
 WHERE CUST_ID in (select con_parentID FROM BT_CONTACTS_MASTER WHERE con_deleted='N' and (con_telephone = @ptelephoneno  
  OR con_mobile = @ptelephoneno)  
  )  
 and CUST_DELETED = 'N'  
 UNION ALL  
 SELECT   cust.[cust_reference] AS [Customer Reference]  
 ,cust.[cust_org_name] AS [Customer Name],cust.source_sys  
 ,(SELECT dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(address_id) --addressLine5+','+addressLine8+','+postCode   
 FROM BT_ADDRESS_MASTER Where ADDRESS_ID=CUST_PRIM_ADDRID) AS [Primary Address]  
 ,(SELECT con_contactname FROM BT_CONTACTS_MASTER WHERE con_contactID=CUST_PRIM_CONTACTID) AS [Primary Contact]  
 ,cust.[CUST_ID] AS [CustomerID]  
 FROM BT_CUSTOMER_MASTER cust  
 WHERE cust.CUST_TELEPHONE = @ptelephoneno  
 and CUST_DELETED = 'N' OPTION (RECOMPILE)  
 --ORDER BY cust.UPDATED_ON desc;  
END  
ELSE IF @pCFSID<>''  
BEGIN  
 SELECT   cust.[cust_reference] AS [Customer Reference]  
 ,cust.[cust_org_name] AS [Customer Name],cust.source_sys  
 ,(SELECT dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(address_id) --addressLine5+','+addressLine8+','+postCode   
 FROM BT_ADDRESS_MASTER Where ADDRESS_ID=CUST_PRIM_ADDRID) AS [Primary Address]  
 ,(SELECT con_contactname FROM BT_CONTACTS_MASTER WHERE con_contactID=CUST_PRIM_CONTACTID) AS [Primary Contact]  
 ,cust.[CUST_ID] AS [CustomerID]  
 FROM BT_CUSTOMER_MASTER cust  
 WHERE cust.CFSID = @pCFSID  
 and CUST_DELETED = 'N'  
 ORDER BY cust.UPDATED_ON desc OPTION (RECOMPILE);  
END  
ELSE IF @pContCFSID<>''  
BEGIN  
 SELECT   cust.[cust_reference] AS [Customer Reference]  
 ,cust.[cust_org_name] AS [Customer Name],cust.source_sys  
 ,(SELECT dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(address_id) --addressLine5+','+addressLine8+','+postCode   
 FROM BT_ADDRESS_MASTER Where ADDRESS_ID=CUST_PRIM_ADDRID) AS [Primary Address]  
 ,(SELECT con_contactname FROM BT_CONTACTS_MASTER WHERE con_contactID=CUST_PRIM_CONTACTID) AS [Primary Contact]   
 ,cust.[CUST_ID] AS [CustomerID]  
 FROM BT_CUSTOMER_MASTER cust  
 WHERE CUST_ID in (select con_parentID FROM BT_CONTACTS_MASTER WHERE con_CFSID = @pContCFSID) and CUST_DELETED = 'N'  
 ORDER BY cust.UPDATED_ON desc OPTION (RECOMPILE);  
END  
ELSE IF @pPostcode<>''  
BEGIN  
 SELECT   cust.[cust_reference] AS [Customer Reference]  
 ,cust.[cust_org_name] AS [Customer Name],cust.source_sys  
 ,(SELECT dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(address_id) --addressLine5+','+addressLine8+','+postCode   
 FROM BT_ADDRESS_MASTER Where ADDRESS_ID=CUST_PRIM_ADDRID) AS [Primary Address]  
 ,(SELECT con_contactname FROM BT_CONTACTS_MASTER WHERE con_contactID=CUST_PRIM_CONTACTID) AS [Primary Contact]  
 ,cust.[CUST_ID] AS [CustomerID]  
 FROM BT_CUSTOMER_MASTER cust  
 WHERE cust_id in (select  parentID from  BT_ADDRESS_MASTER WHERE postcode = @pPostcode)  
 and CUST_DELETED = 'N'  
 ORDER BY cust.UPDATED_ON desc OPTION (RECOMPILE)  
  
END  
ELSE IF @pCUST_ORG_NAME<>''  
BEGIN  
 SELECT   cust.[cust_reference] AS [Customer Reference]  
 ,cust.[cust_org_name] AS [Customer Name],cust.source_sys  
 ,(SELECT dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(address_id) --addressLine5+','+addressLine8+','+postCode   
 FROM BT_ADDRESS_MASTER Where ADDRESS_ID=CUST_PRIM_ADDRID) AS [Primary Address]  
 ,(SELECT con_contactname FROM BT_CONTACTS_MASTER WHERE con_contactID=CUST_PRIM_CONTACTID) AS [Primary Contact]  
 ,cust.[CUST_ID] AS [CustomerID],CFSID  
 FROM BT_CUSTOMER_MASTER cust  
 WHERE cust.CUST_ORG_NAME like @vCUST_ORG_NAME  
 and CUST_DELETED = 'N'  
 --OR CUST_ID in (SELECT con_parentID FROM  BT_CONTACTS_MASTER WHERE con_jobTitle +' '+ con_forename +' '+ con_surname like @vCUST_ORG_NAME and CUST_DELETED = 'N')   
 ORDER BY cust.UPDATED_ON desc OPTION (RECOMPILE);  
END  
ELSE IF @pContactPref<>'' or @pContactFirst<>'' or @pContactLast<>''  
BEGIN  
 SELECT   top 50 cust.[cust_reference] AS [Customer Reference]  
 ,cust.[cust_org_name] AS [Customer Name],cust.source_sys  
 ,(SELECT dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(address_id) --addressLine5+','+addressLine8+','+postCode   
 FROM BT_ADDRESS_MASTER Where ADDRESS_ID=CUST_PRIM_ADDRID) AS [Primary Address]  
 ,(SELECT con_contactname FROM BT_CONTACTS_MASTER WHERE con_contactID=CUST_PRIM_CONTACTID) AS [Primary Contact]  
 ,cust.[CUST_ID] AS [CustomerID]  
 FROM BT_CUSTOMER_MASTER cust  
 LEFT OUTER JOIN BT_ADDRESS_MASTER addr  
 ON cust.[cust_prim_AddrID] = addr.ADDRESS_ID  
 LEFT OUTER JOIN BT_CONTACTS_MASTER con  
 --ON cust.[CUST_PRIM_CONTACTID] = con.con_contactID  
 ON cust.cust_id = con.con_parentID  
 WHERE con.con_contactName like +'%'+ @pContactPref+' '+ @pContactFirst+' '+@pContactLast +'%'  
 and CUST_DELETED = 'N'  
 ORDER BY cust.UPDATED_ON desc OPTION (RECOMPILE);  
END  
ELSE IF @pAddress<>''  
BEGIN  
 SELECT  top 50 cust.[cust_reference] AS [Customer Reference]  
 ,cust.[cust_org_name] AS [Customer Name],cust.source_sys  
 ,(SELECT dbo.fn_rpt_GetReformatReturnAddress_NoSiteName(address_id) --addressLine5+','+addressLine8+','+postCode   
 FROM BT_ADDRESS_MASTER Where ADDRESS_ID=CUST_PRIM_ADDRID) AS [Primary Address]  
 ,(SELECT con_contactname FROM BT_CONTACTS_MASTER WHERE con_contactID=CUST_PRIM_CONTACTID) AS [Primary Contact]  
 ,cust.[CUST_ID] AS [CustomerID]  
 FROM BT_CUSTOMER_MASTER cust  
 LEFT OUTER JOIN BT_ADDRESS_MASTER addr  
 ON cust.[cust_prim_AddrID] = addr.ADDRESS_ID  
 LEFT OUTER JOIN BT_CONTACTS_MASTER con  
 ON cust.[CUST_PRIM_CONTACTID] = con.con_parentID  
 WHERE  addr.addressLine1 like @vAddress  
 OR addr.addressLine2 like @vAddress  
 OR addr.addressLine3 like @vAddress  
 OR addr.addressLine4 like @vAddress  
 OR addr.addressLine5 like @vAddress  
 OR addr.addressLine6 like @vAddress  
 and CUST_DELETED = 'N'  
 ORDER BY cust.UPDATED_ON desc OPTION (RECOMPILE)  
  
END  
  
  
  RETURN 0  
END TRY  
  
BEGIN CATCH  
  SELECT @pErrorMessage='Error Code: ' + CAST (ERROR_NUMBER() AS VARCHAR(10)) + ', Error: ' + ERROR_MESSAGE()  
  RETURN 1  
END CATCH   
END   
GO
