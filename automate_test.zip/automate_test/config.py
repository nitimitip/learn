"""Offline configuration and default browser locations.

Everything here works with no network access. Per-install values come from
environment variables; secrets are generated on first start and kept in
instance/ so they never live in source or in the database.
"""
import os
import secrets
from pathlib import Path

from cryptography.fernet import Fernet

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("QA_DATA_DIR", BASE_DIR)).resolve()
INSTANCE_DIR = DATA_DIR / "instance"
REPORTS_DIR = DATA_DIR / "reports"
# UPLOAD_FILE steps may only reference files inside this folder.
TEST_DATA_DIR = DATA_DIR / "test_data"
# Files a run downloads, kept only until its browser session closes.
DOWNLOADS_DIR = INSTANCE_DIR / "downloads"
DB_PATH = DATA_DIR / "qa_platform.db"
# Server log files (portal.log and its rotated copies).
LOG_DIR = Path(os.environ.get("QA_LOG_DIR", DATA_DIR / "logs")).resolve()

# Files the Admin uploads to the Tool Library, stored under random names.
TOOLS_DIR = DATA_DIR / "tool_files"
# Largest Tool Library attachment. Other forms keep the 16 MB limit in Config.
TOOL_MAX_UPLOAD_MB = max(int(os.environ.get("QA_TOOL_MAX_UPLOAD_MB", "200")), 1)

for _folder in (INSTANCE_DIR, REPORTS_DIR, TEST_DATA_DIR, LOG_DIR, TOOLS_DIR):
    _folder.mkdir(parents=True, exist_ok=True)

DEFAULT_EDGE_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]
DEFAULT_CHROME_PATHS = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
]

# Servers the launched browser may send Windows credentials to. "*" matches the
# platform specification; narrow it (for example "*.corp.local") to stop a test
# step from sending the service account's credentials to an arbitrary host.
AUTH_SERVER_ALLOWLIST = os.environ.get("QA_AUTH_SERVER_ALLOWLIST", "*")
AUTH_DELEGATE_ALLOWLIST = os.environ.get("QA_AUTH_DELEGATE_ALLOWLIST", "*")

# Mail server for forgot-password emails. Same defaults as AppAssist.
SMTP_SERVER = os.environ.get("QA_SMTP_SERVER", "mail1.northernpowergrid.com")
SMTP_PORT = int(os.environ.get("QA_SMTP_PORT", "25"))
EMAIL_FROM = os.environ.get("QA_EMAIL_FROM", "NPgAppAssist@northernpowergrid.com")

MAX_WAIT_SECONDS = 600
SCREENSHOT_TIMEOUT_MS = 15000
MIN_NAVIGATION_TIMEOUT_MS = 30000
# How long the *_IF_VISIBLE keywords wait before treating an element as absent.
VISIBLE_GRACE_MS = 1500
MAX_BLOCK_REPEAT = 50
# REPEAT_BLOCK multiplies when nested, so the expanded test case has its own limit.
MAX_EXPANDED_STEPS = 5000

# Relative date tokens such as {TODAY_DATE+7} accept offsets up to this many days.
MAX_DATE_OFFSET_DAYS = 3650
# TYPE_SEQUENTIALLY: pause between keystrokes, so search-as-you-type fields keep up.
TYPE_DELAY_MS = 60
# Failure diagnostics: JS errors, console errors and HTTP errors kept per step.
MAX_STEP_DIAGNOSTICS = 5

# Watchdog. A run that is still going after MAX_RUN_DURATION_SEC stops before its
# next step. One stuck inside a single step (a hung browser) has its browser killed
# WATCHDOG_KILL_GRACE_SEC later, which makes that step fail and the run end.
MAX_RUN_DURATION_SEC = int(os.environ.get("QA_MAX_RUN_DURATION_SEC", "3600"))
WATCHDOG_KILL_GRACE_SEC = 120
# Closing a browser or context that takes longer than this is treated as hung,
# and the browser's process tree is killed so no msedge.exe / chrome.exe is left.
BROWSER_CLOSE_TIMEOUT_SEC = 10

# Server log, rotated so it can never fill the disk: 5 MB x (1 + 3 backups).
LOG_FILE = LOG_DIR / "portal.log"
LOG_MAX_BYTES = 5 * 1024 * 1024
LOG_BACKUP_COUNT = 3
LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s: %(message)s"
LOG_VIEW_LINES = 200

# Finished runs each application keeps. Screenshots live in the database, so a
# higher number makes it larger. Values below 1 are treated as 1.
KEEP_RUNS_PER_APP = int(os.environ.get("QA_KEEP_RUNS_PER_APP", "20"))

# Performance section. Each pair is (Fast up to, Acceptable up to); above is Slow.
# Ratings only inform: a slow page never fails a test.
PERF_LOAD_MS = (3000, 8000)
PERF_RESPONSE_MS = (800, 1800)
PERF_API_MS = (1000, 3000)
PERF_SETTLE_MIN_MS = 500
PERF_SETTLE_MAX_MS = 5000
PERF_MAX_PAGE_ROWS = 500
PERF_MAX_API_ROWS = 200
# An Angular or React screen counts as drawn once its requests have finished and
# its content has stopped changing for this long. One that never settles within
# the maximum stays "Not finished" instead of reporting a misleading time.
PERF_SPA_QUIET_MS = 300
PERF_SPA_MAX_MS = 10000
# A screen change within this long of a click or Enter is timed from that click, so
# work an Angular route resolver does before the address changes is included. A click
# that leaves the address alone counts as an in-page view (a dialog, a drawer, a tab
# panel) once it adds a dialog or at least PERF_SPA_MIN_ELEMENTS elements.
PERF_SPA_INTERACTION_MS = 5000
PERF_SPA_MIN_ELEMENTS = 15


def _read_or_create(path, factory):
    """Return the key stored at path, generating it on first use."""
    if path.exists():
        return path.read_bytes().strip()
    value = factory()
    # 'x' fails if another process won the race; then read what it wrote.
    try:
        with open(path, "xb") as handle:
            handle.write(value)
    except FileExistsError:
        return path.read_bytes().strip()
    return value


def secret_key():
    return _read_or_create(
        INSTANCE_DIR / "flask_secret.key", lambda: secrets.token_hex(32).encode()
    ).decode()


def fernet():
    """Cipher for application service credentials. Losing the key file means
    stored passwords must be re-entered; it does not affect anything else."""
    return Fernet(_read_or_create(INSTANCE_DIR / "credentials.key", Fernet.generate_key))


class Config:
    SECRET_KEY = secret_key()
    SQLALCHEMY_DATABASE_URI = f"sqlite:///{DB_PATH.as_posix()}"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {"connect_args": {"timeout": 30, "check_same_thread": False}}
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    # Set QA_HTTPS=1 when the portal sits behind TLS.
    SESSION_COOKIE_SECURE = os.environ.get("QA_HTTPS") == "1"
    REMEMBER_COOKIE_HTTPONLY = True
    HOST = os.environ.get("QA_HOST", "127.0.0.1")
    PORT = int(os.environ.get("QA_PORT", "5000"))
