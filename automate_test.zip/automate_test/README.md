# QA Automation Portal

Keyword-driven web test automation for air-gapped networks. Python, Flask, SQLite and Playwright,
running tests in the Microsoft Edge or Google Chrome already installed on the server. Nothing is
fetched from the internet at runtime.

In plain English: the portal is a robot assistant. Testers write steps in plain words (open this
page, type this name, press Save, check the green message), and the portal opens a real browser
and does exactly that against .NET, Angular and React applications. It then writes a colour-coded
Excel and PDF report. No programming is needed. The full beginner guide, with a glossary, a
variables masterclass and a cookbook of common scenarios, is the **How To** page inside the portal
(`/how-to`).

## Quick start for new joiners

1. **Register** on the sign-in page. New accounts are `Guest` (read-only). Ask an Admin to make you a
   `Test Member` (write and run tests) or `Test Manager` (also manage applications and their logins).
2. **Open your application** under **Applications**. If it is missing, a Test Manager adds it with
   its Base URL and test account.
3. **Create a reusable `Login` block**: **New test case**, tick **Reusable block**, and use
   `{AUTH_USERNAME}` and `{AUTH_PASSWORD}` so no password is ever typed into a step.
4. **Find elements without HTML knowledge**: in Edge or Chrome, right-click an element, **Inspect**,
   right-click the highlighted line, **Copy > Copy outerHTML**. In the step editor press **Find
   Locator from HTML**, paste, **Generate locators**, then **Use in Step N** on the row marked Best.
5. **Build a test case** that starts with `CALL_BLOCK` `Login` and ends with a `VERIFY_` step. Or
   write many at once in the Excel template under **Import**.
6. **Run it**: **Run suite**, choose Edge or Chrome and **Headless** (no window) or **Visible
   (Headed)** (watch it on the server's screen), tick the test case, **Start run**. Download the
   Excel or PDF report from the run page.

| Role | Can do |
|---|---|
| Guest | Read everything, download reports and exports. Every new account starts here. |
| Test Member | Also create, edit, import and run test cases and blocks, and abort runs. |
| Test Manager | Also add, edit and delete applications and their saved credentials. |
| Admin | Also manage users and roles, and system settings under **Users & System**. |

## Offline installation

Requires Python 3.11+ on the server. `playwright install` is not needed and must not be run: the
Playwright wheel contains its driver, and the browsers are the ones already installed.

On a machine with internet access and the **same Python version and OS**:

```
pip download -r requirements.txt -d wheelhouse
```

Copy `wheelhouse/` and this folder to the server, then:

```
python -m venv .venv
.venv\Scripts\activate
pip install --no-index --find-links wheelhouse -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000 and sign in as `admin` / `Admin@123`. **Change this password straight
away** (the dashboard warns until you do), then check the browsers under **Users & System**.

## Configuration

| Variable | Default | Purpose |
|---|---|---|
| `QA_HOST` | `127.0.0.1` | Listen address. Set `0.0.0.0` to serve the network. |
| `QA_PORT` | `5000` | Listen port. |
| `QA_HTTPS` | off | Set `1` behind TLS so session cookies are marked Secure. |
| `QA_DATA_DIR` | app folder | Where the database, keys, reports and test data live. |
| `QA_AUTH_SERVER_ALLOWLIST` | `*` | Hosts the browser may send Windows credentials to. |
| `QA_AUTH_DELEGATE_ALLOWLIST` | `*` | Hosts the browser may delegate Kerberos tickets to. |
| `QA_SMTP_SERVER` | `mail1.northernpowergrid.com` | Mail server for forgot-password emails. |
| `QA_SMTP_PORT` | `25` | Mail server port. |
| `QA_EMAIL_FROM` | `NPgAppAssist@northernpowergrid.com` | Sender of forgot-password emails. |
| `QA_LOG_DIR` | `logs` under the data folder | Folder for `portal.log` and its rotated copies. |
| `QA_MAX_RUN_DURATION_SEC` | `3600` | Watchdog: a run still going after this many seconds stops before its next step. `0` turns it off. |

Fixed values in `config.py`: `BROWSER_CLOSE_TIMEOUT_SEC` (10), `WATCHDOG_KILL_GRACE_SEC` (120),
`LOG_FILE` (`logs/portal.log`), `LOG_MAX_BYTES` (5 MB), `LOG_BACKUP_COUNT` (3),
`MAX_DATE_OFFSET_DAYS` (3650), `TYPE_DELAY_MS` (60) and `MAX_STEP_DIAGNOSTICS` (5).

## Operating notes

- **One process only.** Runs are executed by one worker thread inside `python app.py`. Do not run
  the app under several worker processes. Runs queue and execute one at a time.
- **Restart behaviour.** Runs that were queued or running when the portal stopped are marked
  `Aborted` at next start.
- **Backups.** Keep `qa_platform.db` and `instance/` together. `instance/credentials.key` decrypts
  stored application passwords; without it they must be re-entered.
- **Windows service.** A service has no desktop, so Visible (Headed) runs only appear when the portal
  runs in a signed-in session. Single Sign-On uses the identity the portal runs under.
- **Windows credentials.** With the default `*` allowlists, the browser will answer an NTLM/Kerberos
  challenge from any host and may delegate tickets to it, and any Test Member can point a NAVIGATE
  step at any host. Set the two allowlist variables to your internal domains in production.
- **Forgot password.** The sign-in page emails a temporary password, at most once per account every
  15 minutes. The page says the same thing whatever happens, so a mail failure only shows in the
  log, and the old password keeps working.
- **Deleting users.** A user with no history is removed. One who created applications or test cases,
  or triggered runs, keeps a row so that history still has a name, shown as `name (deleted)`. Either
  way the username and email can be registered again.
- **Deleting an application** removes everything that belongs to it, table by table rather than
  relying on cascades: test cases and steps, runs, test case and step results with their
  screenshots, and page and API performance rows, plus any old saved report files. Deleted pages
  are overwritten (`secure_delete`) and the WAL file is checkpointed, so screenshots and captured
  values do not linger in the database file. The delete is checked afterwards and rolled back if
  anything is left. A run in progress must be aborted first.
- **Upload files.** `UPLOAD_FILE` only reads from the `test_data/` folder. Copy files there on the
  server; the input data is the file name.
- **Server log.** `python app.py` logs to the console and to `logs/portal.log` (set `QA_LOG_DIR` for another folder), rotated at 5 MB
  with 3 older copies (`portal.log.1` to `.3`), so at most 20 MB. Admins read the newest 200 lines
  under **Server logs** on **Users & System**, filter to warnings and errors (tracebacks stay with
  their record), and download the current file. `/admin/logs` returns the same lines as JSON. The
  test suite does not write this file.
- **Watchdog.** A run stops before its next step once it is older than `QA_MAX_RUN_DURATION_SEC`
  (60 minutes), with the note *Run exceeded maximum allowed duration of 60 minutes and was terminated
  by the watchdog.* A step stuck inside a frozen browser never reaches that check, so 120 seconds
  later the browser itself is killed, which fails the stuck step at once.
- **Hung browsers.** Every browser is started with a unique `--qa-portal-session=<id>` switch. Closing
  a context or browser runs with a 10-second timer; if the close has not returned by then, the
  browser's process tree is killed (`taskkill /F /T` on Windows, `SIGKILL` elsewhere), found by that
  switch through PowerShell `Get-CimInstance` or `/proc`. No `msedge.exe` or `chrome.exe` is left
  behind, and other browsers on the server are never touched. Playwright objects can only be used
  from the thread that made them, so the close itself stays on the run thread and only the kill runs
  on the timer thread.

## Writing tests

### Keywords

| Keyword | Locator | Input data | Notes |
|---|---|---|---|
| `NAVIGATE` | - | optional | Blank opens the Base URL; a relative path joins to it. http/https only. |
| `WAIT_SECONDS` | - | seconds | Up to 600. |
| `WAIT_FOR_ELEMENT` | required | - | Waits until visible. |
| `SCROLL_TO` | optional | optional | Locator: scrolls it into view, then `bottom`, `top` or pixels scroll inside it (virtual grids). No locator: scrolls the page by `bottom`, `top`, `500` or `-500`. |
| `SWITCH_TO_NEW_WINDOW` | - | optional | Moves to a new tab or pop-up. Blank takes the newest; text matches part of its address or title. |
| `CLOSE_WINDOW` | - | - | Closes the current window and returns to the one before it. |
| `SWITCH_TO_WINDOW` | - | `main`, number or text | Moves to any open window without closing the current one. |
| `SWITCH_TO_FRAME` | required | - | Later steps search inside this iframe. |
| `SWITCH_TO_MAIN_FRAME` | - | - | Back to the top-level page. A new document or a window change also does this. |
| `CLICK`, `DOUBLE_CLICK`, `HOVER` | required | - | |
| `CLICK_AND_SWITCH_WINDOW` | required | optional | Clicks, waits for the tab or pop-up the click opens, and carries on there. Text matches part of its address or title. |
| `DRAG_AND_DROP` | required | `type\|value` | Destination, such as `css\|#dropzone`. |
| `CLICK_IF_VISIBLE` | required | optional seconds | Clicks if it appears in time (default 1.5 s), otherwise passes. |
| `FILL_IF_VISIBLE` | required | optional | Fills if it appears within 1.5 s, otherwise passes. |
| `PREPARE_DIALOG` | - | `accept`, `dismiss` or `accept\|text` | Answer to the next browser pop-up. |
| `FILL` | required | optional | Replaces content. Blank clears the field. |
| `TYPE_SEQUENTIALLY` | required | text | Clears, then types one key every 60 ms, for search-as-you-type, autocomplete and rich-text fields. |
| `SELECT_DROPDOWN` | required | label or value | |
| `CHECK`, `UNCHECK` | required | - | |
| `PRESS_KEY` | optional | key | `Enter`, `Tab`, `Control+A`. |
| `UPLOAD_FILE` | required | file name | Inside `test_data/`. The locator is a file input, or a Browse button that opens the file picker. |
| `VERIFY_TEXT_CONTAINS` | optional | text | No locator checks the whole page. |
| `VERIFY_ELEMENT_VISIBLE` | required | - | |
| `VERIFY_ELEMENT_NOT_VISIBLE` | required | - | Hidden or not on the page: a deleted row, a closed dialog, a finished spinner. |
| `VERIFY_TEXT_NOT_PRESENT` | optional | text | The text does not appear. No locator checks the whole page. |
| `VERIFY_ELEMENT_ENABLED`, `VERIFY_ELEMENT_DISABLED` | required | - | |
| `VERIFY_ELEMENT_COUNT` | required | `5`, `> 0`, `>= 1`, `< 10`, `== 5`, `!= 0` | Number of matching elements, retried until the timeout. The error gives the real count. |
| `CAPTURE_SCREENSHOT` | optional | optional caption | Proof of pass: the element, or the whole page. Shown on the run page, the Excel **Evidence** sheet and PDF section 6. |
| `VERIFY_VALUE` | required | value | Exact match. |
| `VERIFY_URL` | - | text | URL contains the text. |
| `VERIFY_DIALOG_TEXT` | - | text | The latest browser pop-up contains the text. |
| `VERIFY_DOWNLOAD` | - | optional name | A non-empty file downloaded. `*` is a wildcard. Store As is optional. |
| `VERIFY_PRINT_CALLED` | - | - | The page asked to print since the last check. No print dialog opens during a run. |
| `SOFT_VERIFY_TEXT_CONTAINS`, `SOFT_VERIFY_ELEMENT_VISIBLE`, `SOFT_VERIFY_VALUE`, `SOFT_VERIFY_URL` | as `VERIFY_*` | as `VERIFY_*` | A failure is recorded and the test case carries on. It still ends as Fail. |
| `STORE_TEXT`, `STORE_INPUT_VALUE` | required | - | Needs a Store As name. Fails if empty. |
| `STORE_REGEX` | optional | regex | Group 1 if present, otherwise the whole match. |
| `STORE_DIALOG_TEXT` | - | - | Needs a Store As name. Saves the latest browser pop-up's message. |
| `STORE_ELEMENT_COUNT` | required | - | Needs a Store As name. Saves how many elements match now (does not wait). |
| `CALL_BLOCK` | - | `name` or `name \| KEY=VALUE \| ...` | Runs a reusable block's steps in place, optionally setting variables for it first, such as `Login \| USER=checker_01 \| DEPT=Finance`. |
| `CALL_BLOCK_IF_VISIBLE` | required | block name | Runs the block only if the element appears within 1.5 s. |
| `CALL_BLOCK_IF` | optional | `condition \|\| name` | With a locator: `visible`, `not_visible`, `enabled`, `checked`, `text_contains:x`, `text_equals:x`, `value_equals:x`. Without: `{VAR} == x`, `!=`, `contains`, `not_contains`, `>`, `<`. |
| `REPEAT_BLOCK` | - | `name \| count` | Runs the block up to 50 times. |
| `REPEAT_BLOCK_UNTIL` | required | `name \| max \| text` | Runs the block until the element is visible, or shows the text, at most 50 times. Fails if never met. |

Locator types:

| Type | Value | Notes |
| --- | --- | --- |
| `test_id` | `order-id` | `data-testid` attribute. The most reliable when present. |
| `label` | `Username` | Field by its label. Ignores case, matches part of the label. |
| `role` | `button\|Save` | What it is, then its name. |
| `placeholder` | `Search orders` | Input by its hint text. Ignores case, matches part of it. |
| `id` | `orderRef` | Exact id. |
| `id_ends_with` | `txtOrderRef` | End of the id, for ASP.NET ids such as `ctl00_MainContent_txtOrderRef`. |
| `name` | `email` | Exact `name` attribute. |
| `title` | `Delete row` | Tooltip of an icon button. Ignores case, matches part of it. |
| `text` | `Order saved` | Visible text. Ignores case, matches part of it. |
| `row_action` | `{ORDER_ID} \| Edit` | Button or link in the table row containing the text. |
| `css` | `button.save` | CSS selector. |
| `xpath` | `//tr[td='PO-1']//a` | XPath expression. |

If a locator matches several elements the step fails. To pick one, end the value with ` @first`,
` @last` or a number counted from 1, as in `button|Save @first` or `Edit @2`. This works for every
type, `xpath` included, except after a `/` in XPath, where `//a/ @first` is an attribute. The suffix
goes after any `||` frames.

A backslash makes these literal text: `Yes \|| No` finds the text `Yes || No`, and `Room \@2` finds
`Room @2` instead of the second `Room`. Values without a backslash behave exactly as before.

To reach inside an iframe for one step, put the frame's CSS selector before `||`, as in
`iframe#editor || button|Save`, and frames inside frames read from the outside in. For several steps,
use `SWITCH_TO_FRAME`.

### Export and import

**Export Excel** and **Export CSV** on an application download its test cases in the import format,
for anyone who can read them. To change a suite in Excel, edit the file and import it with **Update
existing test cases with matching names** ticked: a matching test case keeps its id, and its details
and steps are replaced. Test cases not in the file are left alone, and a file with any problem changes
nothing. Left unticked, a name that already exists rejects the file.

### Locator Tool

**Locator Tool** in the menu (`/tools/locator-generator`) takes HTML copied from the browser's
developer tools and lists each useful element with ranked locators and a suggested keyword. In the
step builder, **Find Locator from HTML** (or a step's **Find** button) applies the choice to a step.
An optional row context such as `{ORDER_ID}` replaces the row text in table locators.

The parsing runs on the server with the Python standard library, in `engine/locator_generator.py`,
and the pasted HTML is neither saved nor rendered. Each candidate is checked against the snippet: one
matching several elements gets a number and a warning, and dynamic ids (`mat-input-4`, `:r1:`) are
flagged. A snippet can show that a locator is not unique, but not that it is unique on the whole page.

### Tokens and variables

Anything in curly braces is replaced just before the step runs, in **Locator value** and **Input
data**, on its own or inside other text (`PO-{RANDOM_INT}`, `{ORDER_ID} | Approve`). Names are case
sensitive.

| Variable | Category | Gives you | Example input | Example result | Use it for |
|---|---|---|---|---|---|
| `{RANDOM_INT}` | A: dynamic | Random 6-digit number, 100000-999999 | `PO-{RANDOM_INT}` | `PO-482913` | Unique PO, invoice and employee numbers |
| `{TIMESTAMP}` | A: dynamic | Server date and time, `YYYYMMDDHHMMSS` | `user_{TIMESTAMP}@corp.local` | `user_20261107143015@corp.local` | Unique names and emails that show when they were made |
| `{TODAY_DATE}` | A: dynamic | Server date, `YYYY-MM-DD` | `{TODAY_DATE+7}` | `2026-11-14` | Date fields, checking today's date on screen |
| `{TODAY_DMY}` | A: dynamic | Server date, `DD/MM/YYYY` | `{TODAY_DMY-30}` | `08/10/2026` | UK and European date fields |
| `{TODAY_MDY}` | A: dynamic | Server date, `MM/DD/YYYY` | `{TODAY_MDY}` | `11/07/2026` | US-format date pickers |
| `{UUID}` | A: dynamic | 36-character unique id | `{UUID}` | `3f2b8c1e-9a4d-4e7b-8f10-2c6d5a7e9b34` | Correlation keys, external references |
| `{AUTH_USERNAME}` | B: credentials | User name saved on the application | `{AUTH_USERNAME}` | `svc_qa` | Login screens; change it once on the application |
| `{AUTH_PASSWORD}` | B: credentials | Encrypted password saved on the application | `{AUTH_PASSWORD}` | `********` in results | Always, instead of typing a password |
| `{YOUR_NAME}` | C: your own | A value a `STORE_` step captured earlier in the run | `{ORDER_ID}` | `1042` | Passing data between steps and test cases |

- **Category A is new every time it appears.** To type a random value and check the same value later,
  `FILL` it once, capture it straight away with `STORE_INPUT_VALUE`, and use your own variable after.
- **Category B** exists only when the application's auth type is not None and the credentials are
  saved. The password is replaced by `********` in live progress, step results, errors, captured
  variables and both reports. A password typed as plain input data is not masked.
- **Category C** names use letters, digits and underscores, not starting with a digit, and cannot
  reuse a built-in name. `STORE_TEXT` reads text on the page, `STORE_INPUT_VALUE` reads a text box,
  `STORE_REGEX` pulls part of a sentence (`Request #(REQ-\d+)` keeps `REQ-88412`). A variable lasts
  for the run, so a later test case can use it: set its **Depends on** to the test case that stores
  it and queue it after that one.

- **Date offsets.** The three date tokens take `+N` or `-N` calendar days, up to 3650 either way:
  `{TODAY_DATE+7}`, `{TODAY_DMY-30}`. A larger offset is refused when saving. Only these three take
  an offset, so other text such as `{COUNT+1}` is left as it is.
- **Block arguments.** `CALL_BLOCK` `Login | USER=checker_01 | DEPT=Finance` sets `{USER}` and
  `{DEPT}` (tokens in a value are filled in first), then runs `Login`. The call shows as one step
  before the block's steps. The values stay set afterwards, a value cannot contain `|`, and a key
  cannot be a built-in token. Input with a `|` but no `=` is still read as a block name.

A `{TOKEN}` with no value blocks the test case before it starts. Arguments count as values for the
block they are passed to.

### How a run behaves

- Each application keeps its newest 20 finished runs, or the number in the `QA_KEEP_RUNS_PER_APP`
  environment variable (at least 1). When a run finishes, including an aborted one, older runs and
  their screenshots are deleted. The dashboard shows one result per application, from its newest run.
  Download a report first if you need to keep one for longer.
- Reports are Excel or PDF, built when downloaded from a finished run, on the run page or in the
  **Latest report** column of **Applications**. Both open with a summary, followed by test case
  results, issues with failure screenshots, step details, performance and captured variables. A run
  with `CAPTURE_SCREENSHOT` steps adds an **Evidence** sheet and a *Proof-of-pass screenshots* section.
- Test cases run strictly in queue order, in one browser session. A passing test case leaves the
  session as it is, so a login or an open page carries into the next one.
- A failing step takes a full-page screenshot, stops that test case and resets the browser session.
  The next test case starts from a blank page, so begin with `NAVIGATE`. A failed `SOFT_VERIFY_*` step
  also takes a screenshot and fails the test case, but the remaining steps still run.
- A failed step also lists up to five things the application itself reported during that step:
  `JS Error: ...` (uncaught exceptions), `Console Error: ...`, `HTTP 500 on POST /api/orders`
  (any status of 400 or more) and failed requests. They appear under the step on the run page and in
  its error details in both reports, with the password masked and query strings left out.
- **Teardown block.** A test case can name a reusable block under **Teardown block (runs even if test
  fails)**. It runs after the last step, or after the step that failed, with its steps labelled
  `[Teardown]` and numbered after the test case's own. A failed teardown step adds
  `Teardown step N ... failed` below the test case's own message, never replaces it, and never turns a
  pass into a fail, but the browser session is reset. A teardown does not run in a run aborted by a
  user or by the watchdog, and a reusable block cannot have one. The import and export files carry it
  in the `teardown_block` column; an update import without that column keeps each teardown.
- A test case is `Skipped/Blocked`, with the reason recorded, if its dependency did not pass or did
  not run earlier in the queue, a token has no value, a block is missing, or it has no steps.
- Browser `confirm()` and `alert()` dialogs are accepted automatically, unless `PREPARE_DIALOG` has
  chosen a different answer for the next one. `window.print()` never opens the print dialog: each
  page counts its print requests, which `VERIFY_PRINT_CALLED` checks.
- `CALL_BLOCK_IF` and `REPEAT_BLOCK_UNTIL` are prepared before the run like the other block keywords.
  A loop is laid out as a check, then the block and a check again, up to its maximum. The first check
  that is met skips the rest, and the last one fails the test case if it is still not met.
- Step results and performance tables leave out the query string and any non-route `#` part of an
  address, because they can hold sign-in tokens. A failed `VERIFY_URL` quotes the full address in its
  error, because that is what you need to see to fix it.
- A database from an earlier version is upgraded at startup: missing columns are added and rows are kept.
- Locators and `VERIFY_*` steps wait and retry up to the default timeout. After an action that reloads
  the page (such as a .NET postback), follow it with `VERIFY_*` or `WAIT_FOR_ELEMENT` on something
  only the new page has before any `STORE_*`, which could otherwise read the old page.
- Steps stay in the current window until a `SWITCH_TO_NEW_WINDOW` step, which waits for the new window
  to appear and load, or a `CLICK_AND_SWITCH_WINDOW` step, which clicks and moves in one. If a pop-up closes itself, the test returns to the window before it. New tabs and
  pop-ups are measured even if the test never switches to them, and `confirm()` and `alert()` dialogs in
  them are accepted.
- A switched window carries into the next test case if the current one passes, like any other session
  state. A failure closes every window.

### Performance

Every finished run has a Performance section on the run page and in both reports. No
steps are needed. It lists:

- **Page loads**: one row per document in any tab or pop-up, with the step that started it, response
  time, first paint, content ready, full load, requests and size.
- **AJAX / API calls**: grouped by test case and address, with call count, average and slowest. This is
  the server response time of Angular and React screens, which change without a page load.
- **SPA views**: Angular and React screen changes, listed with the page loads. A change within 5 s of a
  click, Enter or Space is timed from that click (`PERF_SPA_INTERACTION_MS`), so data a route resolver
  loads before the address changes is included. A click that changes only the query (`?tab=history`)
  is a view, stored as `?tab=*`. A click that changes nothing in the address is a view once it adds a
  dialog or at least `PERF_SPA_MIN_ELEMENTS` (15) elements, named after the dialog's heading or
  `In-page view update`.

Ratings only inform and never fail a test. Change the limits with the `PERF_*` values in `config.py`.
Each page is timed once from the portal server, so a repeat visit may be faster because of the browser
cache. Query values are never stored, because they can hold session tokens: page loads and API calls drop the
query, and SPA views keep only the parameter names. The results tables are
created automatically at next start, and runs from before this feature show no performance data.

### Bulk import

Download the Excel or CSV template from **Import** on an application's test case page. Each row is one
step, grouped by `test_case_name`. The Excel template has dropdowns on `action_keyword` and
`locator_type` and a `Keywords` reference sheet. An import is all-or-nothing: any problem rejects the
whole file and lists the affected rows. Existing test case names are only replaced when **Update
existing test cases with matching names** is ticked (see Export and import above).

### Editing the How To page

The page text lives in `guide_content.py` and is laid out by `templates/how_to.html`. Keep the file
ASCII only. The tests in `tests/test_rbac.py` check that every keyword, locator type, token and role
is documented, and that every step shown anywhere in the guide passes `validate_step()` with no field
silently dropped. The page uses only `static/css/enterprise.css` and native `<details>` elements,
with no script of its own.

### Recording a test case (tools/record_test_case.py)

A stand-alone recorder: it opens Edge on the application, records what you do, and writes an
import workbook in the format above (sheet `Test Steps`, plus a `Recorder Notes` sheet).

```
python tools/record_test_case.py --url https://host/app/login --name "Create order"
```

- Clicks, typing, dropdowns, check boxes, uploads, drag and drop, Enter/Escape, iframes, pop-up
  windows, browser dialogs (PREPARE_DIALOG is put before the click that raised it), print and
  downloads are recorded.
- **Alt+Right-Click** an element opens the keyword menu: verify text / value / visible / not visible /
  enabled / disabled / count, soft checks, save text, a regex match or a count to a variable, hover,
  wait until visible, click if visible, scroll into view, element screenshot, run a block if visible.
  Values are typed in the menu itself (no browser prompt), and a click outside it only closes it.
- The toolbar at the bottom right adds Verify URL, Wait, Scroll, Call block and Screenshot steps.
- **Shift+Alt+Click** adds a quick check instead of clicking; **Shift+Alt+S** adds a screenshot step.
- `--block`, `--depends-on NAME` and `--teardown BLOCK` fill the test case's own columns. The
  workbook also has a Keywords sheet and drop-downs, like the portal's import template.
- Close the browser (or Ctrl+C) to finish. The file is saved after every step, to the
  `output_folder` / `file_name` in `tools/tools_config.ini` plus `_<date>_<time>.xlsx`
  (default `recordings/<name>_<date>_<time>.xlsx`) unless `--out` is given, and every step is run
  through `validate_step()` at the end. All three tools in `tools/` read their own section of that
  file, and each has a `<tool>_guide.txt` next to it.
- Passwords are never saved: they become `{AUTH_PASSWORD}`, and the user name typed before them
  `{AUTH_USERNAME}` (`--keep-typed-username` keeps it).
- Same-site addresses are written relative, so set the application's Base URL to the recorded site.
- Other options: `--browser chrome`, `--windows-auth "*.corp.local"`, `--ignore-https-errors`,
  `--absolute-urls`.
- Hover is recorded only from the menu (Alt+Right-Click > Hover). Drag and drop is recorded for
  HTML5 drag (draggable elements); libraries that drag with plain mouse moves are not.

## Tests

```
pip install -r requirements-dev.txt
python -m pytest tests
```

The suite drives real Edge and Chrome (headed tests briefly open windows) and writes UI screenshots
to `tests/_screenshots/`.
