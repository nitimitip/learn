"""QA Automation Portal: Flask application, routes and RBAC decorators."""
import base64
import csv
import hashlib
import hmac
import io
import json
import os
import logging
import re
import secrets
import threading
import time
from functools import wraps
from logging.handlers import RotatingFileHandler
from types import SimpleNamespace
from urllib.parse import urlsplit

from flask import (
    Flask, Response, abort, flash, jsonify, redirect, render_template, request, send_file,
    session, url_for,
)
from flask_login import (
    LoginManager, current_user, login_required, login_user, logout_user,
)
from markupsafe import Markup, escape
from openpyxl import Workbook, load_workbook
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
from openpyxl.styles import Font
from openpyxl.worksheet.datavalidation import DataValidation
from sqlalchemy import func

import config
import guide_content
from engine import browser_factory, report_excel, report_generator, report_pdf, runner
from engine.browser_factory import BROWSER_LABELS
from engine.keywords import KEYWORDS, LOCATOR_TYPES, block_name_of, validate_step
from engine.locator_generator import SnippetError, generate_locators
from password_reset import generate_temp_password, send_password_reset_email
from models import (
    AUTH_TYPES, ROLE_ADMIN, ROLE_GUEST, ROLE_MANAGER, ROLE_MEMBER, ROLES, RUN_ABORTED, RUN_ACTIVE,
    RUN_COMPLETED, RUN_QUEUED, TC_BLOCKED, TC_PENDING, TECH_STACKS, Application, TestCase,
    TestCaseResult, TestRun, TestStep, TestStepResult, TestingTool, User, db, get_system_config,
    init_db, next_run_number, purge_application, utcnow,
)
from werkzeug.utils import secure_filename

log = logging.getLogger(__name__)

app = Flask(__name__)
app.config.from_object(config.Config)
db.init_app(app)

login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message = None

ROLES_TEST_EDIT = (ROLE_MEMBER, ROLE_MANAGER, ROLE_ADMIN)
ROLES_APP_EDIT = (ROLE_MANAGER, ROLE_ADMIN)

USERNAME_RE = re.compile(r"^[A-Za-z0-9._-]{3,80}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+$")
MIN_PASSWORD_LENGTH = 8
MAX_IMPORT_ROWS = 5000
RUNS_PER_PAGE = 25

LOGIN_MAX_FAILURES = 5
LOGIN_LOCK_SECONDS = 300
_login_failures = {}
_login_lock = threading.Lock()

# One emailed reset per account in this time, so nobody who knows a colleague's
# address can keep changing their password.
RESET_COOLDOWN_SECONDS = 900
_last_reset = {}


@login_manager.user_loader
def load_user(user_id):
    user = db.session.get(User, int(user_id))
    # Flask-Login only checks is_active at login; returning None here also ends
    # the existing session of an account the Admin has deactivated.
    return user if user and user.is_active else None


def role_required(*roles):
    """Allow only the listed roles. Anonymous users go to the login page."""
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            if current_user.role not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


# --------------------------------------------------------------------------
# Request plumbing: CSRF, security headers, template helpers
# --------------------------------------------------------------------------

def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_urlsafe(32)
    return session["_csrf"]


TOOL_UPLOAD_ENDPOINTS = ("tool_new", "tool_edit")


@app.before_request
def allow_large_tool_uploads():
    """Registered before check_csrf, which reads the form: the limit must be set before
    the body is parsed. Only an Admin saving a Tool Library entry gets the larger one."""
    if (request.endpoint in TOOL_UPLOAD_ENDPOINTS and request.method == "POST"
            and current_user.is_authenticated and current_user.role == ROLE_ADMIN):
        request.max_content_length = config.TOOL_MAX_UPLOAD_MB * 1024 * 1024 + 1024 * 1024


@app.before_request
def check_csrf():
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return
    sent = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token") or ""
    expected = session.get("_csrf", "")
    if not expected or not hmac.compare_digest(sent, expected):
        abort(400, description="Your session expired or the form is out of date. Reload and retry.")


@app.after_request
def security_headers(response):
    # connect-src and the rest also enforce the no-external-calls rule in the browser.
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
        "script-src 'self'; connect-src 'self'; frame-ancestors 'none'; "
        "base-uri 'self'; form-action 'self'"
    )
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "same-origin"
    return response


@app.context_processor
def template_helpers():
    role = current_user.role if current_user.is_authenticated else None
    return {
        "can_edit_tests": role in ROLES_TEST_EDIT,
        "can_manage_apps": role in ROLES_APP_EDIT,
        "is_admin": role == ROLE_ADMIN,
    }


# Globals rather than context values: imported macros don't see the render context.
app.jinja_env.globals.update(
    csrf_token=csrf_token,
    KEEP_RUNS=max(config.KEEP_RUNS_PER_APP, 1),
    BROWSER_LABELS=BROWSER_LABELS,
    AUTH_TYPES=AUTH_TYPES,
    fmt_dt=report_generator.format_dt,
    fmt_dur=report_generator.format_duration,
    fmt_ms=report_generator.format_ms,
    fmt_bytes=report_generator.format_bytes,
)


@app.template_filter("guide_text")
def guide_text(text):
    """Escape help text, then show `backticked` parts as code."""
    return Markup(re.sub(r"`([^`]+)`", r"<code>\1</code>", str(escape(text))))


@app.errorhandler(400)
@app.errorhandler(403)
@app.errorhandler(404)
@app.errorhandler(413)
def http_error(error):
    if error.code == 413 and request.endpoint in TOOL_UPLOAD_ENDPOINTS:
        message = f"The file is larger than the {config.TOOL_MAX_UPLOAD_MB} MB Tool Library limit. Nothing was saved."
        return render_template("error.html", code=413, message=message), 413
    return render_template("error.html", code=error.code, message=error.description), error.code


@app.errorhandler(500)
def server_error(error):
    db.session.rollback()
    return render_template(
        "error.html", code=500, message="Something went wrong on the server. Details are in the log."
    ), 500


def safe_next(target):
    """Only follow local redirects after login."""
    if not target:
        return None
    parts = urlsplit(target)
    if parts.scheme or parts.netloc or not target.startswith("/") or target.startswith("//"):
        return None
    return target


# --------------------------------------------------------------------------
# Authentication
# --------------------------------------------------------------------------

def _login_key():
    return f"{request.remote_addr}|{request.form.get('username', '').strip().lower()}"


def _is_locked(key):
    with _login_lock:
        entry = _login_failures.get(key)
        if not entry:
            return False
        count, last = entry
        if time.monotonic() - last > LOGIN_LOCK_SECONDS:
            del _login_failures[key]
            return False
        return count >= LOGIN_MAX_FAILURES


def _note_failure(key):
    with _login_lock:
        count = _login_failures.get(key, (0, 0))[0]
        _login_failures[key] = (count + 1, time.monotonic())


def _clear_login_failures(username):
    """A new password should work at once, even if the account was locked out."""
    suffix = f"|{username.lower()}"
    with _login_lock:
        for key in [key for key in _login_failures if key.endswith(suffix)]:
            del _login_failures[key]


@app.route("/")
def index():
    return redirect(url_for("dashboard" if current_user.is_authenticated else "login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        key = _login_key()
        if _is_locked(key):
            flash("Too many failed attempts. Try again in a few minutes.", "error")
            return render_template("login.html"), 429
        user = User.query.filter(
            func.lower(User.username) == request.form.get("username", "").strip().lower()
        ).first()
        if user and user.check_password(request.form.get("password", "")):
            if not user.is_active:
                flash("This account is deactivated. Contact your administrator.", "error")
                return render_template("login.html"), 403
            with _login_lock:
                _login_failures.pop(key, None)
            session.clear()  # new session id contents on privilege change
            login_user(user)
            return redirect(safe_next(request.args.get("next")) or url_for("dashboard"))
        _note_failure(key)
        flash("Incorrect username or password.", "error")
        return render_template("login.html"), 401
    return render_template("login.html")


def _password_problem(password, confirm):
    if len(password) < MIN_PASSWORD_LENGTH:
        return f"Password must be at least {MIN_PASSWORD_LENGTH} characters."
    if password != confirm:
        return "The two passwords do not match."
    return None


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        first_name = request.form.get("first_name", "").strip()
        last_name = request.form.get("last_name", "").strip()
        problem = _password_problem(password, request.form.get("confirm_password", ""))
        missing = [label for label, value in (
            ("Username", username), ("First name", first_name), ("Last name", last_name),
            ("Email", email), ("Password", password),
            ("Confirm password", request.form.get("confirm_password", "")),
        ) if not value]
        if missing:
            problem = f"Every field is required. Fill in: {', '.join(missing)}."
        elif not USERNAME_RE.match(username):
            problem = "Username must be 3-80 letters, digits, dots, dashes or underscores."
        elif User.query.filter(func.lower(User.username) == username.lower()).first():
            problem = "That username is already taken."
        else:
            problem = (
                _email_problem(email) or _name_problem("First name", first_name)
                or _name_problem("Last name", last_name) or problem
            )
        if problem:
            flash(problem, "error")
            return render_template("register.html"), 400
        # The role is never read from the form: every sign-up starts as Guest.
        user = User(username=username, email=email, role=ROLE_GUEST, first_name=first_name, last_name=last_name)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash("Account created with Guest (read-only) access. An Admin can raise your role.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        if not email:
            flash("Enter your email address.", "error")
            return render_template("forgot_password.html"), 400
        user = User.query.filter(func.lower(User.email) == email).first()
        if user and user.is_active:
            now = time.monotonic()
            with _login_lock:
                last = _last_reset.get(user.id)
                allowed = last is None or now - last >= RESET_COOLDOWN_SECONDS
            if allowed:
                temp_password = generate_temp_password()
                # Stored only after the mail is accepted, so a mail failure leaves
                # the existing password working.
                if send_password_reset_email(user.email, user.username, temp_password):
                    user.set_password(temp_password)
                    db.session.commit()
                    _clear_login_failures(user.username)
                    with _login_lock:
                        _last_reset[user.id] = now
            else:
                log.warning("Password reset for %s ignored: one was sent recently", user.username)
        # The same answer for every outcome, so this page never reveals an account.
        flash("If that email address matches an account, a new temporary password has been sent to it.", "success")
        return redirect(url_for("login"))
    return render_template("forgot_password.html")


@app.route("/logout", methods=["POST"])
@login_required
def logout():
    logout_user()
    session.clear()
    return redirect(url_for("login"))


MAX_NAME_LENGTH = 80


def _name_problem(label, value):
    if len(value) > MAX_NAME_LENGTH:
        return f"{label} can be at most {MAX_NAME_LENGTH} characters."
    if any(ord(char) < 32 for char in value):
        return f"{label} cannot contain control characters."
    return None


def _email_problem(email, user_id=None):
    """None if the address can be used. The check ignores case, like sign-in does."""
    if not EMAIL_RE.match(email) or len(email) > 200:
        return "Enter a valid email address."
    taken = User.query.filter(func.lower(User.email) == email)
    if user_id is not None:
        taken = taken.filter(User.id != user_id)
    return "That email address is already registered." if taken.first() else None


def _profile_page(status=200, details=None):
    """details: what was typed into a rejected details form, so it is not lost."""
    return render_template("profile.html", details=details or {}), status


@app.route("/account/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        first_name = request.form.get("first_name", "").strip()
        last_name = request.form.get("last_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        problem = (
            _name_problem("First name", first_name) or _name_problem("Last name", last_name)
            or _email_problem(email, current_user.id)
        )
        # The email receives forgot-password mail, so changing it takes the password:
        # otherwise anyone at an unlocked screen could take over the account.
        if not problem and email != current_user.email.lower() and not current_user.check_password(
            request.form.get("current_password", "")
        ):
            problem = "Enter your current password to change your email address."
        if problem:
            flash(problem, "error")
            return _profile_page(400, request.form)
        current_user.first_name, current_user.last_name, current_user.email = first_name, last_name, email
        db.session.commit()
        flash("Profile details saved.", "success")
        return redirect(url_for("profile"))
    return _profile_page()


@app.route("/account/password", methods=["GET", "POST"])
@login_required
def change_password():
    if request.method == "POST":
        new_password = request.form.get("new_password", "")
        problem = _password_problem(new_password, request.form.get("confirm_password", ""))
        if not current_user.check_password(request.form.get("current_password", "")):
            problem = "Your current password is incorrect."
        if problem:
            flash(problem, "error")
            return _profile_page(400)
        current_user.set_password(new_password)
        db.session.commit()
        flash("Password changed.", "success")
        return redirect(url_for("profile"))
    # The password form lives on the profile page; old links still land on it.
    return redirect(url_for("profile", _anchor="password"))


# --------------------------------------------------------------------------
# Dashboard
# --------------------------------------------------------------------------

# Worst first, so what needs attention is at the top of the dashboard.
_OUTCOME_ORDER = {"Failing": 0, "Incomplete": 1, "Not run": 2, "Passing": 3}


def _latest_finished_runs():
    """Each application's newest finished run, by application id."""
    latest_ids = (
        db.session.query(func.max(TestRun.id))
        .filter(TestRun.status.notin_(RUN_ACTIVE)).group_by(TestRun.app_id)
    )
    return {run.app_id: run for run in TestRun.query.filter(TestRun.id.in_(latest_ids))}


def _application_results():
    """One row per application. The result comes from its latest finished run, so
    a run in progress does not blank the result until it has finished."""
    latest = _latest_finished_runs()
    # Oldest first, because that is the run the worker is on or will take next.
    in_progress = {}
    for run in TestRun.query.filter(TestRun.status.in_(RUN_ACTIVE)).order_by(TestRun.id):
        in_progress.setdefault(run.app_id, run)
    # Reusable blocks run inside other cases, so they don't count as cases to cover.
    case_counts = dict(
        db.session.query(TestCase.app_id, func.count())
        .filter(TestCase.is_reusable_block.is_(False)).group_by(TestCase.app_id).all()
    )
    covered = dict(
        db.session.query(TestCaseResult.test_run_id, func.count(func.distinct(TestCase.id)))
        .join(TestCase, TestCaseResult.test_case_id == TestCase.id)
        .filter(
            TestCase.is_reusable_block.is_(False),
            TestCaseResult.test_run_id.in_([run.id for run in latest.values()]),
        )
        .group_by(TestCaseResult.test_run_id).all()
    )
    rows = []
    for application in Application.query.order_by(Application.name).all():
        run = latest.get(application.id)
        rows.append(SimpleNamespace(
            application=application, run=run, active_run=in_progress.get(application.id),
            outcome=report_generator.outcome_of(run), cases=case_counts.get(application.id, 0),
            covered=covered.get(run.id, 0) if run else 0,
        ))
    rows.sort(key=lambda row: _OUTCOME_ORDER[row.outcome])  # stable: names stay sorted
    return rows


@app.route("/dashboard")
@login_required
def dashboard():
    rows = _application_results()
    outcomes = {name: sum(row.outcome == name for row in rows) for name in _OUTCOME_ORDER}
    finished = [row.run for row in rows if row.run]
    passed = sum(run.passed_tests for run in finished)
    failed = sum(run.failed_tests for run in finished)
    skipped = sum(run.skipped_tests for run in finished)
    default_password = (
        current_user.username == "admin" and current_user.check_password("Admin@123")
    )
    return render_template(
        "dashboard.html",
        rows=rows, outcomes=outcomes,
        stats={
            "applications": len(rows),
            "test_cases": sum(row.cases for row in rows),
            "not_covered": sum(row.cases - row.covered for row in rows),
            "active": TestRun.query.filter(TestRun.status.in_(RUN_ACTIVE)).count(),
        },
        passed=passed, failed=failed, skipped=skipped,
        donut=report_generator.donut_svg(passed, failed, skipped),
        default_password=default_password,
        colors={"passed": report_generator.COLOR_PASS, "failed": report_generator.COLOR_FAIL,
                "skipped": report_generator.COLOR_SKIP},
    )


# --------------------------------------------------------------------------
# Help
# --------------------------------------------------------------------------

@app.route("/how-to")
@login_required
def how_to():
    categories = {}
    for name, spec in KEYWORDS.items():
        categories.setdefault(spec["category"], []).append(name)
    return render_template(
        "how_to.html", guide=guide_content, keywords=KEYWORDS, categories=categories,
        import_columns=IMPORT_COLUMNS, max_wait=config.MAX_WAIT_SECONDS,
        max_rows=MAX_IMPORT_ROWS, default_timeout_ms=get_system_config().default_timeout_ms,
    )


# --------------------------------------------------------------------------
# Locator tool
# --------------------------------------------------------------------------
@app.route("/tools/locator-generator")
@login_required
def locator_tool():
    return render_template("locator_tool.html")


@app.route("/api/tools/generate-locators", methods=["POST"])
@login_required
def api_generate_locators():
    # Works on the pasted text only: nothing is stored, rendered or fetched.
    body = request.get_json(silent=True)
    body = body if isinstance(body, dict) else {}
    try:
        return jsonify(generate_locators(body.get("html"), body.get("hint")))
    except SnippetError as exc:
        return jsonify(error=str(exc)), 400


# --------------------------------------------------------------------------
# Tool Library: testing tools the Admin publishes for everyone to download
# --------------------------------------------------------------------------

TOOL_NAME_MAX = 150
TOOL_TEXT_MAX = 20000
_COPY_CHUNK = 1024 * 1024


def _tool_path(stored_name):
    # stored_name is always our own hex name, so it cannot leave TOOLS_DIR.
    return config.TOOLS_DIR / stored_name


def _remove_tool_file(stored_name):
    if not stored_name:
        return
    try:
        _tool_path(stored_name).unlink()
    except FileNotFoundError:
        pass
    except OSError as exc:  # a file open elsewhere on Windows: leave it, log it
        log.warning("Tool file %s could not be removed: %s", stored_name, exc)


def _store_tool_upload(upload):
    """Copy an upload into TOOLS_DIR under a random name. Returns
    (stored_name, original name, size, sha256) or raises ValueError with a message."""
    original = secure_filename(upload.filename or "") or "tool-file"
    limit = config.TOOL_MAX_UPLOAD_MB * 1024 * 1024
    stored = secrets.token_hex(16)
    partial = _tool_path(stored + ".part")
    digest = hashlib.sha256()
    size = 0
    try:
        with open(partial, "xb") as handle:
            while True:
                chunk = upload.stream.read(_COPY_CHUNK)
                if not chunk:
                    break
                size += len(chunk)
                if size > limit:
                    raise ValueError(f"The file is larger than the {config.TOOL_MAX_UPLOAD_MB} MB limit.")
                digest.update(chunk)
                handle.write(chunk)
        if not size:
            raise ValueError("The attached file is empty.")
        os.replace(partial, _tool_path(stored))
    except BaseException:
        try:
            partial.unlink()
        except OSError:
            pass
        raise
    return stored, original[:255], size, digest.hexdigest()


def _tool_form(tool, status=200):
    return render_template(
        "tool_form.html", tool=tool, max_mb=config.TOOL_MAX_UPLOAD_MB,
    ), status


def _save_tool(tool):
    """Apply the form to the record and store any new file. Returns an error or None.
    The caller commits; the replaced file's stored name is returned on tool._old_file."""
    form = request.form
    name = form.get("name", "").strip()
    description = form.get("description", "").strip()
    if not name:
        return "Name is required."
    if len(name) > TOOL_NAME_MAX:
        return f"Name must be at most {TOOL_NAME_MAX} characters."
    if not description:
        return "Description is required."
    texts = {
        "description": description,
        "prerequisites": form.get("prerequisites", "").strip(),
        "instructions": form.get("instructions", "").strip(),
    }
    if any(len(value) > TOOL_TEXT_MAX for value in texts.values()):
        return f"Description, prerequisites and instructions are each limited to {TOOL_TEXT_MAX} characters."
    clash = TestingTool.query.filter(func.lower(TestingTool.name) == name.lower())
    if tool.id:
        clash = clash.filter(TestingTool.id != tool.id)
    if clash.first():
        return f"A tool named '{name}' already exists."
    upload = request.files.get("attachment")
    has_upload = bool(upload and upload.filename)
    if not has_upload and not tool.stored_name:
        return "Attach the tool file people will download."
    if has_upload:
        try:
            stored, original, size, sha = _store_tool_upload(upload)
        except ValueError as exc:
            return str(exc)
        tool._old_file = tool.stored_name
        tool.stored_name, tool.file_name, tool.file_size, tool.file_sha256 = stored, original, size, sha
        tool.uploaded_by = current_user.id
    tool.name = name
    for field, value in texts.items():
        setattr(tool, field, value)
    tool.updated_at = utcnow()
    return None


def _commit_tool(tool):
    """Commit; on failure remove the file this request stored. Returns True on success."""
    old_file = getattr(tool, "_old_file", None)
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        if old_file is not None:
            _remove_tool_file(tool.stored_name)
        raise
    if old_file:
        _remove_tool_file(old_file)
    return True


@app.route("/tools/library")
@login_required
def tool_library():
    tools = TestingTool.query.order_by(func.lower(TestingTool.name)).all()
    return render_template("tool_library.html", tools=tools)


@app.route("/tools/library/<int:tool_id>")
@login_required
def tool_detail(tool_id):
    tool = db.get_or_404(TestingTool, tool_id)
    return render_template(
        "tool_detail.html", tool=tool, file_present=_tool_path(tool.stored_name).is_file(),
    )


@app.route("/tools/library/<int:tool_id>/download")
@login_required
def tool_download(tool_id):
    tool = db.get_or_404(TestingTool, tool_id)
    path = _tool_path(tool.stored_name)
    if not tool.stored_name or not path.is_file():
        flash("The file for this tool is missing on the server. Ask an Admin to upload it again.", "error")
        return redirect(url_for("tool_detail", tool_id=tool.id))
    log.info("Tool %s (%s) downloaded by %s", tool.id, tool.file_name, current_user.username)
    return send_file(
        path, mimetype="application/octet-stream", as_attachment=True,
        download_name=tool.file_name or "tool-file", max_age=0,
    )


@app.route("/tools/library/new", methods=["GET", "POST"])
@role_required(ROLE_ADMIN)
def tool_new():
    tool = TestingTool(name="", description="", prerequisites="", instructions="")
    if request.method == "POST":
        problem = _save_tool(tool)
        if problem:
            flash(problem, "error")
            return _tool_form(tool, 400)
        db.session.add(tool)
        _commit_tool(tool)
        flash(f"Added {tool.name} to the Tool Library.", "success")
        return redirect(url_for("tool_detail", tool_id=tool.id))
    return _tool_form(tool)


@app.route("/tools/library/<int:tool_id>/edit", methods=["GET", "POST"])
@role_required(ROLE_ADMIN)
def tool_edit(tool_id):
    tool = db.get_or_404(TestingTool, tool_id)
    if request.method == "POST":
        problem = _save_tool(tool)
        if problem:
            db.session.rollback()
            flash(problem, "error")
            return _tool_form(tool, 400)
        _commit_tool(tool)
        flash(f"Saved {tool.name}.", "success")
        return redirect(url_for("tool_detail", tool_id=tool.id))
    return _tool_form(tool)


@app.route("/tools/library/<int:tool_id>/delete", methods=["POST"])
@role_required(ROLE_ADMIN)
def tool_delete(tool_id):
    tool = db.get_or_404(TestingTool, tool_id)
    name, stored = tool.name, tool.stored_name
    db.session.delete(tool)
    db.session.commit()
    _remove_tool_file(stored)
    flash(f"Deleted {name} from the Tool Library.", "success")
    return redirect(url_for("tool_library"))


# --------------------------------------------------------------------------
# Admin
# --------------------------------------------------------------------------

LOG_FILTERS = ("all", "problems")  # problems: warnings and errors, with their tracebacks
_LOG_RECORD_RE = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}")
_LOG_LEVEL_RE = re.compile(r"^\S+ \S+ (DEBUG|INFO|WARNING|ERROR|CRITICAL) ")
_LOG_TAIL_BYTES = 1024 * 1024  # the newest part of the file, enough for 200 lines of tracebacks


def read_log_tail(problems_only=False, limit=None):
    """The newest lines of the server log, oldest first, as [(level, text)]. A traceback
    belongs to the record above it, so the problems filter keeps it with its record."""
    limit = limit or config.LOG_VIEW_LINES
    try:
        with open(config.LOG_FILE, "rb") as handle:
            handle.seek(0, io.SEEK_END)
            size = handle.tell()
            handle.seek(max(0, size - _LOG_TAIL_BYTES))
            data = handle.read()
    except FileNotFoundError:
        return []
    lines = data.decode("utf-8", errors="replace").splitlines()
    if size > _LOG_TAIL_BYTES and lines:
        lines = lines[1:]  # the first line was cut in half by the seek
    kept, level = [], ""
    for line in lines:
        if _LOG_RECORD_RE.match(line):
            match = _LOG_LEVEL_RE.match(line)
            level = match.group(1) if match else ""
        if problems_only and level not in ("WARNING", "ERROR", "CRITICAL"):
            continue
        kept.append((level or "INFO", line))
    return kept[-limit:]


@app.route("/admin/users")
@role_required(ROLE_ADMIN)
def admin_users():
    system = get_system_config()
    log_filter = request.args.get("log", "all")
    if log_filter not in LOG_FILTERS:
        log_filter = "all"
    return render_template(
        "admin_users.html",
        users=User.query.filter(User.deleted_at.is_(None)).order_by(User.username).all(),
        roles=ROLES,
        system=system,
        detection=browser_factory.detect_browsers(system),
        log_filter=log_filter,
        log_lines=read_log_tail(log_filter == "problems"),
        log_path=str(config.LOG_FILE),
        log_exists=config.LOG_FILE.exists(),
    )


@app.route("/admin/logs")
@role_required(ROLE_ADMIN)
def admin_logs():
    """The newest lines as JSON, for scripts and monitoring."""
    problems = request.args.get("log") == "problems"
    return jsonify(lines=[
        {"level": level, "text": text} for level, text in read_log_tail(problems)
    ])


@app.route("/admin/logs/download")
@role_required(ROLE_ADMIN)
def admin_logs_download():
    # Read into memory (at most LOG_MAX_BYTES): a file held open while it downloads would
    # stop the log rotating on Windows.
    try:
        data = config.LOG_FILE.read_bytes()
    except FileNotFoundError:
        flash("There is no server log yet. It is written once the portal runs as a server.", "warning")
        return redirect(url_for("admin_users", _anchor="server-logs"))
    stamp = utcnow().strftime("%Y%m%d_%H%M%S")
    return send_file(
        io.BytesIO(data), mimetype="text/plain", as_attachment=True,
        download_name=f"portal_log_{stamp}.log",
    )


def _other_active_admins(user_id):
    return User.query.filter(
        User.role == ROLE_ADMIN, User.is_active.is_(True), User.id != user_id
    ).count()


def _live_user_or_404(user_id):
    user = db.get_or_404(User, user_id)
    if user.deleted_at:
        abort(404)
    return user


def _has_history(user):
    return any(
        model.query.filter(column == user.id).first()
        for model, column in (
            (Application, Application.created_by),
            (TestCase, TestCase.created_by),
            (TestRun, TestRun.triggered_by),
            (TestingTool, TestingTool.uploaded_by),
        )
    )


def _retire_user(user):
    """Keep the row for the history that points at it, but free the username and email
    and make the account impossible to use."""
    base = f"{user.username[:60]} (deleted"
    name = f"{base})"
    copy = 2
    while User.query.filter(User.username == name).first():
        name = f"{base} {copy})"
        copy += 1
    user.username = name
    user.email = f"deleted-{user.id}@deleted.invalid"
    user.set_password(secrets.token_urlsafe(32))
    user.is_active = False
    user.deleted_at = utcnow()


@app.route("/admin/users/<int:user_id>/reset-password", methods=["GET", "POST"])
@role_required(ROLE_ADMIN)
def admin_reset_password(user_id):
    user = _live_user_or_404(user_id)
    if user.id == current_user.id:
        # Your own password needs your current one, whoever is at the keyboard.
        return redirect(url_for("change_password"))
    if request.method == "POST":
        problem = _password_problem(
            request.form.get("new_password", ""), request.form.get("confirm_password", "")
        )
        if problem:
            flash(problem, "error")
            return render_template("admin_reset_password.html", target=user), 400
        user.set_password(request.form["new_password"])
        db.session.commit()
        _clear_login_failures(user.username)
        flash(f"Password reset for {user.username}.", "success")
        return redirect(url_for("admin_users"))
    return render_template("admin_reset_password.html", target=user)


@app.route("/admin/users/<int:user_id>/delete", methods=["POST"])
@role_required(ROLE_ADMIN)
def admin_delete_user(user_id):
    user = _live_user_or_404(user_id)
    # The signed-in Admin always stays, so this also protects the last active Admin.
    if user.id == current_user.id:
        flash("You cannot delete your own account.", "error")
        return redirect(url_for("admin_users"))
    username = user.username
    if _has_history(user):
        _retire_user(user)
    else:
        db.session.delete(user)
    db.session.commit()
    _clear_login_failures(username)
    flash(f"Deleted user {username}.", "success")
    return redirect(url_for("admin_users"))


@app.route("/admin/users/<int:user_id>", methods=["POST"])
@role_required(ROLE_ADMIN)
def admin_update_user(user_id):
    user = _live_user_or_404(user_id)
    role = request.form.get("role", user.role)
    active = request.form.get("is_active") == "on"
    if role not in ROLES:
        abort(400, description="Unknown role.")
    if user.role == ROLE_ADMIN and user.is_active and (role != ROLE_ADMIN or not active):
        if not _other_active_admins(user.id):
            flash("This is the last active Admin, so it must stay an active Admin.", "error")
            return redirect(url_for("admin_users"))
    user.role = role
    user.is_active = active
    db.session.commit()
    flash(f"Updated {user.username}: {role}, {'active' if active else 'deactivated'}.", "success")
    return redirect(url_for("admin_users"))


@app.route("/admin/config", methods=["POST"])
@role_required(ROLE_ADMIN)
def admin_update_config():
    system = get_system_config()
    default_browser = request.form.get("default_browser", "")
    if default_browser not in BROWSER_LABELS:
        abort(400, description="Unknown browser.")
    try:
        timeout = int(request.form.get("default_timeout_ms", ""))
        if not 1000 <= timeout <= 600000:
            raise ValueError
    except ValueError:
        flash("Default timeout must be a whole number from 1000 to 600000 ms.", "error")
        return redirect(url_for("admin_users"))
    system.default_browser = default_browser
    system.edge_executable_path = request.form.get("edge_executable_path", "").strip().strip('"')
    system.chrome_executable_path = request.form.get("chrome_executable_path", "").strip().strip('"')
    system.default_headless = request.form.get("default_headless") == "on"
    system.default_timeout_ms = timeout
    db.session.commit()
    flash("System configuration saved.", "success")
    return redirect(url_for("admin_users"))


@app.route("/admin/browsers/detect")
@role_required(ROLE_ADMIN)
def admin_detect_browsers():
    return jsonify(browser_factory.detect_browsers(get_system_config()))


# --------------------------------------------------------------------------
# Applications
# --------------------------------------------------------------------------

@app.route("/applications")
@login_required
def applications():
    rows = Application.query.order_by(Application.name).all()
    tc_counts = dict(
        db.session.query(TestCase.app_id, func.count()).group_by(TestCase.app_id).all()
    )
    return render_template(
        "applications.html", applications=rows, tc_counts=tc_counts,
        latest_runs=_latest_finished_runs(),
    )


def _save_application(application):
    """Apply the form to the record. Returns an error message or None."""
    form = request.form
    name = form.get("name", "").strip()
    base_url = form.get("base_url", "").strip()
    tech_stack = form.get("tech_stack", "")
    browser = form.get("preferred_browser", "")
    auth_type = form.get("auth_type", "")
    if not name:
        return "Application name is required."
    parts = urlsplit(base_url)
    if parts.scheme.lower() not in ("http", "https") or not parts.netloc:
        return "Base URL must be a full http:// or https:// address."
    if tech_stack not in TECH_STACKS or browser not in BROWSER_LABELS or auth_type not in AUTH_TYPES:
        return "Choose a valid tech stack, browser and auth type."
    duplicate = Application.query.filter(func.lower(Application.name) == name.lower())
    if application.id:
        duplicate = duplicate.filter(Application.id != application.id)
    if duplicate.first():
        return f"An application named '{name}' already exists."

    application.name = name
    application.description = form.get("description", "").strip()
    application.base_url = base_url
    application.tech_stack = tech_stack
    application.preferred_browser = browser
    application.auth_type = auth_type
    if auth_type == "None":
        application.ad_domain = application.auth_username = ""
        application.set_password("")
    else:
        application.ad_domain = form.get("ad_domain", "").strip() if auth_type == "OnPrem_AD" else ""
        application.auth_username = form.get("auth_username", "").strip()
        # Blank keeps the stored password: it is never sent back to the browser.
        if form.get("clear_password") == "on":
            application.set_password("")
        elif form.get("auth_password"):
            application.set_password(form["auth_password"])
    return None


def _application_form(application, status=200):
    return render_template(
        "application_form.html", application=application, tech_stacks=TECH_STACKS
    ), status


@app.route("/applications/new", methods=["GET", "POST"])
@role_required(*ROLES_APP_EDIT)
def application_new():
    application = Application(
        preferred_browser=get_system_config().default_browser, tech_stack="Other", auth_type="None",
        name="", description="", base_url="", ad_domain="", auth_username="",
        auth_password_encrypted="",
    )
    if request.method == "POST":
        error = _save_application(application)
        if error:
            flash(error, "error")
            return _application_form(application, 400)
        application.created_by = current_user.id
        db.session.add(application)
        db.session.commit()
        flash(f"Application '{application.name}' created.", "success")
        return redirect(url_for("testcases", app_id=application.id, tab="cases"))
    return _application_form(application)


@app.route("/applications/<int:app_id>/edit", methods=["GET", "POST"])
@role_required(*ROLES_APP_EDIT)
def application_edit(app_id):
    application = db.get_or_404(Application, app_id)
    if request.method == "POST":
        error = _save_application(application)
        if error:
            flash(error, "error")
            return _application_form(application, 400)
        db.session.commit()
        flash("Application saved.", "success")
        return redirect(url_for("applications"))
    return _application_form(application)


@app.route("/applications/<int:app_id>/delete", methods=["POST"])
@role_required(*ROLES_APP_EDIT)
def application_delete(app_id):
    application = db.get_or_404(Application, app_id)
    if TestRun.query.filter(TestRun.app_id == app_id, TestRun.status.in_(RUN_ACTIVE)).first():
        flash("This application has a run in progress. Abort it first.", "error")
        return redirect(url_for("applications"))
    name = application.name
    run_ids = [run.id for run in application.runs]
    try:
        removed = purge_application(app_id)
    except Exception:
        log.exception("Deleting application %s failed", app_id)
        flash(f"Application '{name}' could not be deleted. Nothing was changed. Details are in the server log.", "error")
        return redirect(url_for("applications"))
    for run_id in run_ids:
        report_generator.delete_report(run_id)
    flash(
        f"Application '{name}' was deleted with all its data: {removed['test_cases']} test case(s), "
        f"{removed['test_steps']} step(s), {removed['test_runs']} run(s), "
        f"{removed['test_step_results']} step result(s) and screenshots, and "
        f"{removed['page_performance'] + removed['api_performance']} performance row(s).", "success",
    )
    return redirect(url_for("applications"))


# --------------------------------------------------------------------------
# Test cases
# --------------------------------------------------------------------------

@app.route("/applications/<int:app_id>/testcases")
@login_required
def testcases(app_id):
    """Application page: a Test runs tab and a Test cases tab."""
    application = db.get_or_404(Application, app_id)
    tab = request.args.get("tab", "runs")
    if tab not in ("runs", "cases"):
        tab = "runs"
    page = max(request.args.get("page", 1, type=int), 1)
    pagination = (
        TestRun.query.filter_by(app_id=application.id)
        .order_by(TestRun.id.desc())
        .paginate(page=page, per_page=RUNS_PER_PAGE, error_out=False)
    )
    return render_template(
        "testcases.html", application=application, test_cases=application.test_cases,
        tab=tab, pagination=pagination,
    )


def _creates_cycle(case_id, depends_on_id):
    seen = set()
    current = depends_on_id
    while current is not None:
        if current == case_id or current in seen:
            return True
        seen.add(current)
        parent = db.session.get(TestCase, current)
        current = parent.depends_on_tc_id if parent else None
    return False


def _parse_steps(raw_steps, app_id, own_name, is_block):
    """Validate submitted steps. Returns (clean_steps, error_messages)."""
    clean, errors = [], []
    block_names = {
        name for (name,) in db.session.query(TestCase.name)
        .filter_by(app_id=app_id, is_reusable_block=True).all()
    }
    if is_block:
        block_names.add(own_name)
    for number, raw in enumerate(raw_steps, start=1):
        if not isinstance(raw, dict):
            errors.append(f"Step {number}: invalid data")
            continue
        step, problems = validate_step(raw)
        errors.extend(f"Step {number}: {problem}" for problem in problems)
        if step:
            block = block_name_of(step["action_keyword"], step["input_data"])
            if block:
                if block not in block_names:
                    errors.append(f"Step {number}: no reusable block named '{block}'")
                elif block == own_name:
                    errors.append(f"Step {number}: a block cannot call itself")
            clean.append(step)
    return clean, errors


def _case_form(application, case, steps, status=200):
    others = [tc for tc in application.test_cases if tc.id != case.id]
    return render_template(
        "testcase_form.html", application=application, case=case, steps=steps,
        other_cases=others, keywords=KEYWORDS, locator_types=LOCATOR_TYPES,
        block_names=[tc.name for tc in others if tc.is_reusable_block],
        teardown_blocks=[tc for tc in others if tc.is_reusable_block],
    ), status


def _teardown_users(case):
    """Names of the test cases that use this one as their teardown block."""
    if not case.id:
        return []
    return [tc.name for tc in TestCase.query.filter_by(teardown_block_id=case.id).order_by(TestCase.name)]


def _steps_as_dicts(case):
    return [{
        "action_keyword": s.action_keyword, "locator_type": s.locator_type or "",
        "locator_value": s.locator_value or "", "input_data": s.input_data or "",
        "store_variable_name": s.store_variable_name or "", "description": s.description or "",
    } for s in case.steps]


def _save_case(application, case):
    """Apply the submitted form. Returns (raw_steps, errors) and leaves the session
    uncommitted so the caller can commit or roll back."""
    form = request.form
    name = form.get("name", "").strip()
    is_block = form.get("is_reusable_block") == "on"
    errors = []
    try:
        raw_steps = json.loads(form.get("steps_json") or "[]")
        if not isinstance(raw_steps, list):
            raise ValueError
    except ValueError:
        return [], ["The step list could not be read. Reload the page and try again."]

    if not name:
        errors.append("Test case name is required.")
    duplicate = TestCase.query.filter(TestCase.app_id == application.id, TestCase.name == name)
    if case.id:
        duplicate = duplicate.filter(TestCase.id != case.id)
    if name and duplicate.first():
        errors.append(f"A test case named '{name}' already exists in this application.")

    depends_on_id = None
    raw_dep = form.get("depends_on_tc_id", "")
    if raw_dep:
        dependency = db.session.get(TestCase, int(raw_dep)) if raw_dep.isdigit() else None
        if not dependency or dependency.app_id != application.id:
            errors.append("Choose a dependency from this application.")
        elif case.id and _creates_cycle(case.id, dependency.id):
            errors.append(f"Depending on '{dependency.name}' would create a dependency loop.")
        else:
            depends_on_id = dependency.id

    teardown_id = None
    raw_teardown = form.get("teardown_block_id", "")
    if raw_teardown:
        teardown = db.session.get(TestCase, int(raw_teardown)) if raw_teardown.isdigit() else None
        if not teardown or teardown.app_id != application.id or not teardown.is_reusable_block:
            errors.append("Choose a teardown block from this application's reusable blocks.")
        elif case.id and teardown.id == case.id:
            errors.append("A test case cannot be its own teardown block.")
        elif is_block:
            errors.append(
                "A reusable block cannot have a teardown block: it would not run when another "
                "test case calls the block. Set the teardown on the test case instead."
            )
        else:
            teardown_id = teardown.id
    if not is_block and case.is_reusable_block:
        users = _teardown_users(case)
        if users:
            errors.append(
                f"This must stay a reusable block: it is the teardown block of {', '.join(users)}."
            )

    clean_steps, step_errors = _parse_steps(raw_steps, application.id, name, is_block)
    errors.extend(step_errors)
    if errors:
        return raw_steps, errors

    case.name = name
    case.description = form.get("description", "").strip()
    case.is_reusable_block = is_block
    case.depends_on_tc_id = depends_on_id
    case.teardown_block_id = teardown_id
    case.updated_at = utcnow()
    case.steps = [TestStep(step_order=i, **step) for i, step in enumerate(clean_steps, start=1)]
    return raw_steps, []


def _form_preview(case):
    """Show the user's rejected input again without touching the database row."""
    raw_dep = request.form.get("depends_on_tc_id", "")
    raw_teardown = request.form.get("teardown_block_id", "")
    return SimpleNamespace(
        id=case.id, name=request.form.get("name", ""),
        description=request.form.get("description", ""),
        is_reusable_block=request.form.get("is_reusable_block") == "on",
        depends_on_tc_id=int(raw_dep) if raw_dep.isdigit() else None,
        teardown_block_id=int(raw_teardown) if raw_teardown.isdigit() else None,
    )


@app.route("/applications/<int:app_id>/testcases/new", methods=["GET", "POST"])
@role_required(*ROLES_TEST_EDIT)
def testcase_new(app_id):
    application = db.get_or_404(Application, app_id)
    if request.method == "POST":
        case = TestCase(app_id=application.id, created_by=current_user.id)
        raw_steps, errors = _save_case(application, case)
        if errors:
            for error in errors:
                flash(error, "error")
            return _case_form(application, _form_preview(case), raw_steps, 400)
        db.session.add(case)
        db.session.commit()
        flash(f"Test case '{case.name}' created.", "success")
        return redirect(url_for("testcases", app_id=app_id, tab="cases"))
    blank = SimpleNamespace(
        id=None, name="", description="", is_reusable_block=False, depends_on_tc_id=None,
        teardown_block_id=None,
    )
    return _case_form(application, blank, [])


def _get_case(case_id):
    return db.get_or_404(TestCase, case_id)


@app.route("/testcases/<int:case_id>")
@login_required
def testcase_view(case_id):
    case = _get_case(case_id)
    return render_template("testcase_view.html", case=case, application=case.application)


@app.route("/testcases/<int:case_id>/edit", methods=["GET", "POST"])
@role_required(*ROLES_TEST_EDIT)
def testcase_edit(case_id):
    case = _get_case(case_id)
    application = case.application
    if request.method == "POST":
        raw_steps, errors = _save_case(application, case)
        if errors:
            for error in errors:
                flash(error, "error")
            return _case_form(application, _form_preview(case), raw_steps, 400)
        db.session.commit()
        flash("Test case saved.", "success")
        return redirect(url_for("testcase_view", case_id=case.id))
    return _case_form(application, case, _steps_as_dicts(case))


@app.route("/testcases/<int:case_id>/clone", methods=["POST"])
@role_required(*ROLES_TEST_EDIT)
def testcase_clone(case_id):
    source = _get_case(case_id)
    existing = {name for (name,) in db.session.query(TestCase.name).filter_by(app_id=source.app_id)}
    name = f"{source.name} (Copy)"
    suffix = 2
    while name in existing:
        name = f"{source.name} (Copy {suffix})"
        suffix += 1
    clone = TestCase(
        app_id=source.app_id, name=name, description=source.description,
        depends_on_tc_id=source.depends_on_tc_id, is_reusable_block=source.is_reusable_block,
        teardown_block_id=source.teardown_block_id, created_by=current_user.id,
        steps=[TestStep(
            step_order=step.step_order, action_keyword=step.action_keyword,
            locator_type=step.locator_type, locator_value=step.locator_value,
            input_data=step.input_data, store_variable_name=step.store_variable_name,
            description=step.description,
        ) for step in source.steps],
    )
    db.session.add(clone)
    db.session.commit()
    flash(f"Cloned as '{name}'.", "success")
    return redirect(url_for("testcase_edit", case_id=clone.id))


@app.route("/testcases/<int:case_id>/delete", methods=["POST"])
@role_required(*ROLES_TEST_EDIT)
def testcase_delete(case_id):
    case = _get_case(case_id)
    app_id, name = case.app_id, case.name
    # The foreign key does this too, but a database upgraded before teardown blocks
    # existed must not keep an id that points nowhere.
    TestCase.query.filter_by(teardown_block_id=case.id).update({"teardown_block_id": None})
    db.session.delete(case)
    db.session.commit()
    flash(f"Test case '{name}' deleted. Its results stay in the runs that are kept.", "success")
    return redirect(url_for("testcases", app_id=app_id, tab="cases"))


# --------------------------------------------------------------------------
# Bulk import and templates
# --------------------------------------------------------------------------

IMPORT_COLUMNS = [
    "test_case_name", "test_case_description", "is_reusable_block", "depends_on", "step_order",
    "action_keyword", "locator_type", "locator_value", "input_data", "store_variable_name",
    "step_description", "teardown_block",
]
_SAMPLE_ROWS = [
    ["Create Order", "Log in and create an order", "no", "", 1, "NAVIGATE", "", "", "/login", "", "Open login page"],
    ["Create Order", "", "", "", 2, "FILL", "label", "Username", "{AUTH_USERNAME}", "", "Enter user"],
    ["Create Order", "", "", "", 3, "FILL", "label", "Password", "{AUTH_PASSWORD}", "", "Enter password"],
    ["Create Order", "", "", "", 4, "CLICK", "role", "button|Sign in", "", "", "Submit login"],
    ["Create Order", "", "", "", 5, "FILL", "id", "orderRef", "PO-{RANDOM_INT}", "", "Order reference"],
    ["Create Order", "", "", "", 6, "CLICK", "css", "#saveOrder", "", "", "Save order"],
    ["Create Order", "", "", "", 7, "STORE_TEXT", "test_id", "order-id", "", "ORDER_ID", "Capture order number"],
    ["Verify Order", "Find the order created above", "no", "Create Order", 1, "NAVIGATE", "", "", "/orders/{ORDER_ID}", "", "Open order"],
    ["Verify Order", "", "", "", 2, "VERIFY_TEXT_CONTAINS", "css", "h1", "{ORDER_ID}", "", "Heading shows the order"],
]


def _steps_csv(rows, filename):
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(IMPORT_COLUMNS)
    writer.writerows(rows)
    return Response(
        chr(0xFEFF) + buffer.getvalue(), mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


def _steps_workbook(rows, filename):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Test Steps"
    sheet.append(IMPORT_COLUMNS)
    for cell in sheet[1]:
        cell.font = Font(bold=True)
    for number, row in enumerate(rows, start=2):
        for column, value in enumerate(row, start=1):
            cell = sheet.cell(row=number, column=column)
            if isinstance(value, str):
                # A step's text is never a formula, even one like =Total.
                cell.value = ILLEGAL_CHARACTERS_RE.sub("", value)
                cell.data_type = "s"
                cell.quotePrefix = value.startswith(("=", "+", "-", "@"))
            else:
                cell.value = value
    for column, width in zip("ABCDEFGHIJKL", (22, 32, 12, 18, 8, 26, 12, 24, 26, 18, 30, 20)):
        sheet.column_dimensions[column].width = width
    sheet.freeze_panes = "A2"

    reference = workbook.create_sheet("Keywords")
    reference.append(["keyword", "category", "locator", "input_data", "stores_variable", "what_it_does"])
    for cell in reference[1]:
        cell.font = Font(bold=True)
    for name, spec in KEYWORDS.items():
        stores = {True: "yes", False: "no"}.get(spec["store"], spec["store"])
        reference.append([name, spec["category"], spec["locator"], spec["input"], stores, spec["help"]])
    for column, width in zip("ABCDEF", (26, 26, 10, 10, 15, 80)):
        reference.column_dimensions[column].width = width

    keyword_list = DataValidation(type="list", formula1=f"=Keywords!$A$2:$A${len(KEYWORDS) + 1}", allow_blank=True)
    locator_list = DataValidation(type="list", formula1=f'"{",".join(LOCATOR_TYPES)}"', allow_blank=True)
    sheet.add_data_validation(keyword_list)
    sheet.add_data_validation(locator_list)
    keyword_list.add(f"F2:F{MAX_IMPORT_ROWS + 1}")
    locator_list.add(f"G2:G{MAX_IMPORT_ROWS + 1}")

    output = io.BytesIO()
    workbook.save(output)
    output.seek(0)
    return send_file(
        output, as_attachment=True, download_name=filename,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.route("/import-template.<fmt>")
@login_required
def import_template(fmt):
    if fmt == "csv":
        return _steps_csv(_SAMPLE_ROWS, "test_case_import_template.csv")
    if fmt != "xlsx":
        abort(404)
    return _steps_workbook(_SAMPLE_ROWS, "test_case_import_template.xlsx")


def _export_rows(application):
    """Every step as an import row, so the file can be edited and imported back. The
    test case's own fields go on its first row. A test case with no steps has no row."""
    rows = []
    for case in application.test_cases:
        for order, step in enumerate(case.steps, start=1):
            first = order == 1
            rows.append([
                case.name,
                case.description if first else "",
                ("yes" if case.is_reusable_block else "no") if first else "",
                case.depends_on.name if first and case.depends_on else "",
                order, step.action_keyword, step.locator_type or "", step.locator_value or "",
                step.input_data or "", step.store_variable_name or "", step.description or "",
                case.teardown_block.name if first and case.teardown_block else "",
            ])
    return rows


@app.route("/applications/<int:app_id>/testcases/export.<fmt>")
@login_required
def testcases_export(app_id, fmt):
    application = db.get_or_404(Application, app_id)
    if fmt not in ("csv", "xlsx"):
        abort(404)
    name = re.sub(r"[^A-Za-z0-9]+", "_", application.name).strip("_")[:60] or "Application"
    filename = f"{name}_test_cases.{fmt}"
    rows = _export_rows(application)
    return _steps_csv(rows, filename) if fmt == "csv" else _steps_workbook(rows, filename)


def _cell_text(value, keep_spaces=False):
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value) if keep_spaces else str(value).strip()


def _read_import_rows(upload):
    """Yield (row_number, {column: text}) from a .csv or .xlsx upload."""
    filename = (upload.filename or "").lower()
    if filename.endswith(".csv"):
        data = upload.read()
        try:
            text = data.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = data.decode("cp1252", errors="replace")
        table = list(csv.reader(io.StringIO(text)))
    elif filename.endswith(".xlsx"):
        workbook = load_workbook(io.BytesIO(upload.read()), read_only=True, data_only=True)
        table = [list(row) for row in workbook.worksheets[0].iter_rows(values_only=True)]
        workbook.close()
    else:
        raise ValueError("Upload a .csv or .xlsx file.")
    if not table:
        raise ValueError("The file is empty.")
    if len(table) > MAX_IMPORT_ROWS + 1:
        raise ValueError(f"The file has more than {MAX_IMPORT_ROWS} rows.")
    header = [_cell_text(h).lower().replace(" ", "_") for h in table[0]]
    missing = {"test_case_name", "action_keyword"} - set(header)
    if missing:
        raise ValueError(f"Missing column(s): {', '.join(sorted(missing))}.")
    rows = []
    for number, row in enumerate(table[1:], start=2):
        # Spaces can matter in a FILL value; validate_step trims them where they don't.
        values = {h: _cell_text(v, keep_spaces=h == "input_data") for h, v in zip(header, row) if h}
        if any(values.values()):
            rows.append((number, values))
    return rows


def _import_plan(rows, application, overwrite=False):
    """Group rows into test cases and validate everything. Returns (plan, errors). With
    overwrite, a name already in the application replaces that test case, so what the
    file says about it is checked as if the old version were already gone."""
    plan = {}
    errors = []
    for number, values in rows:
        name = values.get("test_case_name", "")
        if not name:
            errors.append(f"Row {number}: test_case_name is blank.")
            continue
        entry = plan.setdefault(name, {
            "description": "", "block": False, "depends_on": "", "rows": [],
            # None: the file has no teardown_block column, so an update keeps the old one.
            "teardown": None,
        })
        entry["description"] = entry["description"] or values.get("test_case_description", "")
        entry["depends_on"] = entry["depends_on"] or values.get("depends_on", "")
        if "teardown_block" in values:
            entry["teardown"] = entry["teardown"] or values["teardown_block"]
        if values.get("is_reusable_block", "").lower() in ("yes", "y", "true", "1"):
            entry["block"] = True
        order_text = values.get("step_order", "")
        if order_text and not order_text.isdigit():
            errors.append(f"Row {number}: step_order must be a whole number.")
        entry["rows"].append((int(order_text) if order_text.isdigit() else len(entry["rows"]) + 1, number, values))

    existing = {tc.name: tc for tc in application.test_cases}
    replaced = set(plan) & set(existing) if overwrite else set()
    block_names = {tc.name for tc in application.test_cases if tc.is_reusable_block and tc.name not in replaced}
    block_names |= {name for name, entry in plan.items() if entry["block"]}
    # A test case the file leaves alone may call a block the file is turning off.
    no_longer_blocks = {name for name in replaced if existing[name].is_reusable_block and not plan[name]["block"]}
    for case in application.test_cases:
        if case.name not in replaced:
            for step in case.steps:
                called = block_name_of(step.action_keyword, step.input_data)
                if called in no_longer_blocks:
                    errors.append(
                        f"Test case '{called}' must stay a reusable block: '{case.name}' calls it."
                    )
            if case.teardown_block and case.teardown_block.name in no_longer_blocks:
                errors.append(
                    f"Test case '{case.teardown_block.name}' must stay a reusable block: it is the "
                    f"teardown block of '{case.name}'."
                )
    for name, entry in plan.items():
        if name in existing and not overwrite:
            errors.append(
                f"Test case '{name}' already exists in this application. Rename or delete it first, "
                "or tick the option to update existing test cases."
            )
        dep = entry["depends_on"]
        if dep and dep not in existing and dep not in plan:
            errors.append(f"Test case '{name}': depends_on '{dep}' was not found.")
        teardown = entry["teardown"]
        if teardown is None and name in replaced and existing[name].teardown_block:
            teardown = existing[name].teardown_block.name  # kept, so checked like a new one
        if teardown:
            if teardown not in block_names:
                errors.append(f"Test case '{name}': teardown_block '{teardown}' is not a reusable block.")
            elif teardown == name:
                errors.append(f"Test case '{name}' cannot be its own teardown block.")
            elif entry["block"]:
                errors.append(f"Test case '{name}' is a reusable block, so it cannot have a teardown block.")
        entry["rows"].sort(key=lambda item: item[0])
        entry["steps"] = []
        for _order, number, values in entry["rows"]:
            step, problems = validate_step({
                **values, "description": values.get("step_description", ""),
            })
            errors.extend(f"Row {number}: {problem}" for problem in problems)
            if step:
                called = block_name_of(step["action_keyword"], step["input_data"])
                if called and called not in block_names:
                    errors.append(f"Row {number}: no reusable block named '{called}'.")
                entry["steps"].append(step)

    def depends_on(name):
        if name in plan:
            return plan[name]["depends_on"]
        case = existing.get(name)
        return case.depends_on.name if case and case.depends_on else ""

    # Dependencies must not loop. Updating a test case can close a loop through one the
    # file leaves alone, so the walk follows both.
    for name in plan:
        seen = {name}
        current = depends_on(name)
        while current:
            if current in seen:
                errors.append(f"Test case '{name}': depends_on forms a loop.")
                break
            seen.add(current)
            current = depends_on(current)
    return plan, errors


@app.route("/applications/<int:app_id>/testcases/import", methods=["POST"])
@role_required(*ROLES_TEST_EDIT)
def testcases_import(app_id):
    application = db.get_or_404(Application, app_id)
    upload = request.files.get("file")
    if not upload or not upload.filename:
        flash("Choose a file to import.", "error")
        return redirect(url_for("testcases", app_id=app_id, tab="cases"))
    try:
        rows = _read_import_rows(upload)
    except ValueError as exc:
        flash(str(exc), "error")
        return redirect(url_for("testcases", app_id=app_id, tab="cases"))
    except Exception:
        log.exception("Could not read import file")
        flash("That file could not be read. Check it is a valid .csv or .xlsx file.", "error")
        return redirect(url_for("testcases", app_id=app_id, tab="cases"))

    overwrite = request.form.get("overwrite_existing") == "on"
    plan, errors = _import_plan(rows, application, overwrite)
    if not plan and not errors:
        errors.append("The file has no step rows.")
    if errors:
        # All-or-nothing: a half-imported suite is harder to fix than a rejected file.
        for error in errors[:15]:
            flash(error, "error")
        if len(errors) > 15:
            flash(f"...and {len(errors) - 15} more problems.", "error")
        flash("Nothing was imported.", "error")
        return redirect(url_for("testcases", app_id=app_id, tab="cases"))

    existing = {tc.name: tc for tc in application.test_cases}
    imported, updated = {}, 0
    for name, entry in plan.items():
        # An update keeps the row, so other test cases' links to it and past results stay.
        case = existing.get(name) if overwrite else None
        if case is None:
            case = TestCase(app_id=app_id, name=name, created_by=current_user.id)
            db.session.add(case)
        else:
            updated += 1
        case.description = entry["description"]
        case.is_reusable_block = entry["block"]
        case.steps = [TestStep(step_order=i, **s) for i, s in enumerate(entry["steps"], start=1)]
        case.updated_at = utcnow()
        imported[name] = case
    db.session.flush()
    for name, entry in plan.items():
        dep = entry["depends_on"]
        imported[name].depends_on_tc_id = (imported.get(dep) or existing[dep]).id if dep else None
        teardown = entry["teardown"]
        if teardown is not None:  # the file has the column; blank removes the teardown
            imported[name].teardown_block_id = (imported.get(teardown) or existing[teardown]).id if teardown else None
    db.session.commit()
    total_steps = sum(len(entry["steps"]) for entry in plan.values())
    note = f", updating {updated} existing" if updated else ""
    flash(f"Imported {len(plan)} test case(s) with {total_steps} step(s){note}.", "success")
    return redirect(url_for("testcases", app_id=app_id, tab="cases"))


# --------------------------------------------------------------------------
# Runs
# --------------------------------------------------------------------------

@app.route("/applications/<int:app_id>/run", methods=["GET", "POST"])
@role_required(*ROLES_TEST_EDIT)
def run_setup(app_id):
    application = db.get_or_404(Application, app_id)
    system = get_system_config()
    if request.method == "POST":
        browser = request.form.get("browser", "")
        if browser not in BROWSER_LABELS:
            abort(400, description="Unknown browser.")
        try:
            ordered_ids = [int(v) for v in request.form.get("queue", "").split(",") if v]
        except ValueError:
            abort(400, description="Invalid test case selection.")
        ordered_ids = list(dict.fromkeys(ordered_ids))
        cases = {tc.id: tc for tc in application.test_cases}
        queue = [cases[i] for i in ordered_ids if i in cases]
        if not queue or len(queue) != len(ordered_ids):
            flash("Select at least one test case from this application.", "error")
            return redirect(url_for("run_setup", app_id=app_id))

        positions = {tc.id: index for index, tc in enumerate(queue)}
        for index, case in enumerate(queue):
            dep = case.depends_on_tc_id
            if dep and positions.get(dep, len(queue)) > index:
                flash(
                    f"'{case.name}' depends on '{case.depends_on.name}', which is not earlier "
                    "in the queue, so it will be marked Skipped/Blocked.", "warning",
                )

        run = TestRun(
            app_id=app_id, triggered_by=current_user.id, requested_browser=browser,
            browser_used=browser, headless=request.form.get("mode") != "headed",
            status=RUN_QUEUED, total_tests=len(queue), run_no=next_run_number(app_id),
        )
        run.case_results = [
            TestCaseResult(
                test_case_id=tc.id, test_case_name=tc.name, execution_order=i,
                status=TC_PENDING, total_steps=len(tc.steps),
            )
            for i, tc in enumerate(queue, start=1)
        ]
        db.session.add(run)
        db.session.commit()
        return redirect(url_for("run_detail", run_id=run.id))
    return render_template(
        "run_setup.html", application=application, test_cases=application.test_cases,
        default_browser=application.preferred_browser or system.default_browser,
        default_headless=system.default_headless,
        detection=browser_factory.detect_browsers(system),
    )


def _progress_percent(run):
    if not run.total_tests:
        return 0
    done = run.passed_tests + run.failed_tests + run.skipped_tests
    return round(done / run.total_tests * 100)


@app.route("/runs")
@login_required
def runs():
    # The Test Runs page was merged into each application's Test runs tab.
    # The address stays so old bookmarks land somewhere useful.
    return redirect(url_for("applications"))


def _run_body(run):
    return render_template(
        "_run_body.html", run=run, variables=report_generator.parse_variables(run),
        progress=_progress_percent(run), perf=report_generator.performance_summary(run),
    )


@app.route("/runs/<int:run_id>")
@login_required
def run_detail(run_id):
    run = db.get_or_404(TestRun, run_id)
    return render_template("run_detail.html", run=run, body=Markup(_run_body(run)))


@app.route("/runs/<int:run_id>/status")
@login_required
def run_status(run_id):
    run = db.get_or_404(TestRun, run_id)
    return jsonify(active=run.active, status=run.status, html=_run_body(run))


@app.route("/runs/<int:run_id>/abort", methods=["POST"])
@role_required(*ROLES_TEST_EDIT)
def run_abort(run_id):
    run = db.get_or_404(TestRun, run_id)
    if not run.active:
        flash("This run has already finished.", "warning")
        return redirect(url_for("run_detail", run_id=run_id))
    run.abort_requested = True
    db.session.flush()
    # A queued run has no worker to notice the flag; end it here. The WHERE guards
    # against the worker claiming it in between.
    ended = db.session.execute(
        db.update(TestRun)
        .where(TestRun.id == run_id, TestRun.status == RUN_QUEUED)
        .values(status=RUN_ABORTED, completed_at=utcnow(), notes="Run aborted by user before it started.")
    ).rowcount
    if ended:
        db.session.expire(run)
        for result in run.case_results:
            result.status = TC_BLOCKED
            result.error_message = "Run aborted before this test case started."
        run.skipped_tests = run.total_tests
    db.session.commit()
    if ended:
        runner.prune_finished_runs(run.app_id)
    flash("Abort requested. The run stops after the current step." if not ended else "Run aborted.", "success")
    return redirect(url_for("run_detail", run_id=run_id))


@app.route("/step-results/<int:step_id>/screenshot")
@login_required
def step_screenshot(step_id):
    step = db.get_or_404(TestStepResult, step_id)
    if not step.screenshot_base64:
        abort(404)
    return Response(base64.b64decode(step.screenshot_base64), mimetype="image/png")


def _report_download(run_id, extension, build, mimetype):
    run = db.get_or_404(TestRun, run_id)
    if run.active:
        flash("The report is available when the run has finished.", "warning")
        return redirect(url_for("run_detail", run_id=run_id))
    return send_file(
        io.BytesIO(build(run)), mimetype=mimetype, as_attachment=True,
        download_name=report_generator.report_filename(run, extension),
    )


@app.route("/runs/<int:run_id>/report.xlsx")
@login_required
def run_report_excel(run_id):
    return _report_download(
        run_id, "xlsx", report_excel.render_excel,
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.route("/runs/<int:run_id>/report.pdf")
@login_required
def run_report_pdf(run_id):
    return _report_download(run_id, "pdf", report_pdf.render_pdf, "application/pdf")


# --------------------------------------------------------------------------
# Startup
# --------------------------------------------------------------------------

def configure_logging():
    """Console plus a rotating file in instance/, on the root logger, so errors from the
    run worker and waitress are kept when nobody is watching the terminal. Safe to call
    more than once."""
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    formatter = logging.Formatter(config.LOG_FORMAT)
    if not root.handlers:
        console = logging.StreamHandler()
        console.setFormatter(formatter)
        root.addHandler(console)
    if not any(getattr(handler, "_qa_portal_log", False) for handler in root.handlers):
        try:
            file_handler = RotatingFileHandler(
                config.LOG_FILE, maxBytes=config.LOG_MAX_BYTES,
                backupCount=config.LOG_BACKUP_COUNT, encoding="utf-8",
            )
        except OSError as exc:  # a read-only folder must not stop the portal starting
            log.warning("Server log file %s cannot be written: %s", config.LOG_FILE, exc)
            return
        file_handler.setFormatter(formatter)
        file_handler._qa_portal_log = True
        root.addHandler(file_handler)


def bootstrap(start_worker=True):
    """Prepare the database and, for serving, start the single run worker."""
    if start_worker:
        configure_logging()
    with app.app_context():
        init_db()
        runner.recover_interrupted_runs()
        runner.prune_finished_runs()
    if start_worker:
        runner.start_worker(app)


def main():
    configure_logging()
    bootstrap()
    from waitress import serve
    log.info("QA Automation Portal on http://%s:%s", app.config["HOST"], app.config["PORT"])
    serve(app, host=app.config["HOST"], port=app.config["PORT"], threads=8)


if __name__ == "__main__":
    main()
