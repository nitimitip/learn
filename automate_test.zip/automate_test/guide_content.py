"""Text of the How To page. Backticks show as code. Tests check that every keyword,
locator type and token is explained and that every example is a step the portal accepts.
Keep this file ASCII only: production servers read it with a cp1252 code page."""


def step(keyword, locator_type="", locator_value="", input_data="", store="", description=""):
    return {
        "action_keyword": keyword, "locator_type": locator_type, "locator_value": locator_value,
        "input_data": input_data, "store_variable_name": store, "description": description,
    }


# --------------------------------------------------------------------------
# Start here: welcome, roles and the first 10 minutes
# --------------------------------------------------------------------------

PORTAL_INTRO = [
    "Think of the portal as a robot assistant that sits at a computer for you. You write down, in plain steps, what a tester would do: open this page, type this name, press Save, check that the green message appears. The robot then opens a real Microsoft Edge or Google Chrome browser and does exactly that, as fast and as often as you like.",
    "It works with the web applications your teams build and support, whether they are older `.NET` pages or modern `Angular` and `React` screens. You never write program code. Every step is picked from dropdowns or typed into a spreadsheet.",
    "When a run finishes, the portal tells you which test cases passed and which failed, shows a screenshot of the exact moment something went wrong, times how fast each page loaded, and gives you a colour-coded Excel and PDF report that you can send to your manager or attach to a defect.",
]

# Plain-English meanings for words a new joiner will meet on the page.
JARGON = [
    ("Locator", "The directions the robot uses to find one thing on the screen, like a seat number on a theatre ticket. `label` + `Username` means: the box whose label says Username."),
    ("Element", "Any single thing on a web page: a button, a text box, a link, a table cell, a message."),
    ("HTML", "The text a web page is really made of. The browser reads it and draws the screen you see, like a builder following a floor plan."),
    ("DOM", "The browser's live copy of that floor plan: every element on the page, arranged like a family tree. When the screen changes, the DOM changes."),
    ("Inspect", "A right-click option in Edge and Chrome that shows the HTML behind whatever you clicked on. It looks technical, but you only need it to copy one line."),
    ("Keyword", "The action a step performs, such as `CLICK` or `FILL`. It is the verb of the step."),
    ("Token / variable", "A placeholder in curly braces, like `{ORDER_ID}`. Just before the step runs, the portal swaps it for a real value, the way a mail merge swaps `<<Name>>` for a customer's name."),
    ("Regex (regular expression)", "A search pattern for picking a piece out of a longer sentence. `Order #(\\d+)` means: find `Order #`, then keep the digits that follow. Like telling someone: read me only the number after the hash sign."),
    ("Iframe", "A window within a window: a second web page hanging inside the first one, like a picture in a frame. The robot has to be told to look inside the frame, because it cannot see through the glass."),
    ("SPA (single-page application)", "An Angular or React application that changes the screen without loading a new page, like a presenter flipping slides on one projector instead of walking to a new room."),
    ("Headless", "Running the browser with its window switched off, like a radio that plays with the display turned off. It is faster and is the normal choice. Visible (Headed) shows the window, which helps when you are working out a failure."),
    ("Selector (CSS / XPath)", "Two technical ways of writing a locator. CSS describes what an element looks like (the button with class save). XPath gives turn-by-turn directions through the page (inside the row for PO-1, take the Edit link). Use them only when the simpler locator types cannot do the job."),
    ("Strict mode violation", "The portal's way of saying: your directions lead to more than one place. A locator must point at exactly one element, so the step stops rather than guessing."),
    ("Test chaining", "Passing a value from one test case to a later one, such as creating a request in the first and approving that same request in the second."),
]

# (role, what it can see, what it can do)
ROLE_GUIDE = [
    ("Guest", "Dashboard, applications, test cases, runs, reports, the Locator Tool and this guide.", "Read everything and download Excel and PDF reports, test case exports and import templates. Cannot create, change or run anything. Every new account starts here."),
    ("Test Member", "Everything a Guest sees.", "Create, edit, copy, delete and import test cases and reusable blocks. Start runs and abort them. This is the normal role for a tester."),
    ("Test Manager", "Everything a Test Member sees.", "Everything a Test Member does, plus add, edit and delete applications: the Base URL, the login type and the saved service account username and password."),
    ("Admin", "Everything, plus Users & System.", "Everything a Test Manager does, plus change anyone's role, disable, reset or delete accounts, and change system settings such as the default timeout and the browsers."),
]

ROLE_UPGRADE = [
    "Register on the sign-in page: username, first name, last name, email and password are all required. Your account is created as a `Guest`, so you can look around straight away but not change anything.",
    "Ask an `Admin` to upgrade you, by email or Teams. Tell them your portal username and which role you need: `Test Member` to write and run tests, or `Test Manager` if you will also look after applications and their logins.",
    "The Admin opens Users & System, changes your role and saves. Sign out and back in if the new buttons do not appear.",
]

# The first 10 minutes. Each entry: title, plain explanation, how-to list, example steps (or None).
QUICK_START = [
    {
        "id": "qs-app",
        "title": "Pick your application",
        "what": "An application is the website you are testing. It holds the Base URL (the web address everything starts from) and the service account the robot logs in with.",
        "how": [
            "Open `Applications` in the menu on the left.",
            "Find your application and open it. Its page has two tabs: `Test runs` shows past results, and `Test cases` lists the tests.",
            "If your application is not listed, ask a `Test Manager` to add it. They will need the Base URL and the login details of a test account.",
        ],
        "steps": None,
    },
    {
        "id": "qs-block",
        "title": "Create a reusable Login block",
        "what": "Almost every test starts by logging in. Write those steps once as a reusable block, and every other test case runs them with a single `CALL_BLOCK` step. If the login screen ever changes, you fix one block instead of a hundred test cases.",
        "how": [
            "On the application's `Test cases` tab, press `New test case`.",
            "Name it `Login` and tick `Reusable block`.",
            "Add the steps below with `Add step`, then press `Save test case`. `{AUTH_USERNAME}` and `{AUTH_PASSWORD}` pull the login saved on the application, so no real password is ever typed into a step.",
        ],
        "steps": "WORKED_LOGIN",
    },
    {
        "id": "qs-locator",
        "title": "Find elements with the Locator Tool",
        "what": "Every step that touches the screen needs a locator: directions to the button or box. You do not have to know HTML. Let the Locator Tool read the page for you and suggest the best directions.",
        "how": [
            "In Edge or Chrome, right-click the button or box you need and choose `Inspect`.",
            "Right-click the highlighted line and choose `Copy`, then `Copy outerHTML` (Edge may say `Copy element`).",
            "In the test case editor, press `Find Locator from HTML` (or a step's `Find` button), paste, press `Generate locators`, and press `Use in Step N` on the row marked `Best`.",
        ],
        "steps": None,
    },
    {
        "id": "qs-case",
        "title": "Build your first test case",
        "what": "Now write a real test that uses your block. Choose the keyword first on every step, because it decides which other boxes appear. Always finish with a `VERIFY_` step: that is the check that proves the application did the right thing.",
        "how": [
            "Press `New test case`, name it `Open reports` and leave `Reusable block` unticked.",
            "Add the three steps below. The first one runs your whole Login block.",
            "Press `Save test case`. Prefer a spreadsheet? Use `Import` and download the Excel template, which has dropdowns for every column (see the cookbook below).",
        ],
        "steps": "WORKED_BLOCK_CALLER",
    },
    {
        "id": "qs-run",
        "title": "Run it and read the report",
        "what": "A run is the robot doing the work. You choose the browser, whether you want to watch it, and which test cases to run in which order.",
        "how": [
            "On the application, press `Run suite`.",
            "Choose `Microsoft Edge` or `Google Chrome`, and a mode: `Headless` (no window, normal choice) or `Visible (Headed)` (the browser appears on the portal server's screen, useful when a step fails and you want to watch).",
            "Tick `Open reports`. Leave the `Login` block unticked, because your test case already calls it. Press `Start run`.",
            "The run page updates by itself as each step finishes. When it is done, download the `Excel` or `PDF` report from the run page. A failed step shows its error message and a screenshot.",
        ],
        "steps": None,
    },
]


# --------------------------------------------------------------------------
# Variables and dynamic data masterclass
# --------------------------------------------------------------------------

VARIABLE_BASICS = [
    "A variable is a name in curly braces, such as `{ORDER_ID}`. Just before a step runs, the portal replaces it with a real value. You can put one anywhere in `Locator value` or `Input data`, on its own or in the middle of other text: `PO-{RANDOM_INT}`, `{ORDER_ID} | Approve`, `/orders/{ORDER_ID}`.",
    "Names are case sensitive: `{ORDER_ID}`, `{order_id}` and `{Order_Id}` are three different variables.",
    "There are three kinds. Category A makes up a fresh value for you. Category B fetches the application's saved login. Category C holds values you captured from the screen yourself.",
    "If a step uses a variable that will not have a value when it runs, the portal notices before the test case starts and marks it `Skipped/Blocked`, naming the variable. A typo never silently types the wrong thing.",
]

TOKEN_CATEGORIES = [
    ("A", "Built-in dynamic data", "Generated fresh every time they appear. The three date tokens also take a day offset, such as {TODAY_DATE+7} or {TODAY_DMY-30}.", ["RANDOM_INT", "TIMESTAMP", "TODAY_DATE", "TODAY_DMY", "TODAY_MDY", "UUID"]),
    ("B", "Application credentials", "The login saved on the application, with the password kept secret.", ["AUTH_USERNAME", "AUTH_PASSWORD"]),
]

# One entry for every built-in token: what, when, when not, a business scenario and worked steps.
TOKEN_MASTERCLASS = {
    "RANDOM_INT": {
        "what": "A random 6-digit whole number, from `100000` to `999999`.",
        "when": "Whenever a field must be unique: purchase order numbers, invoice references, employee or customer ids. Without it, the second run of the same test fails with a duplicate record error.",
        "when_not": "When you must type the same number again later. Every `{RANDOM_INT}` is a new number, so a second one will not match the first. Store the first one (see the golden rule).",
        "scenario": "A buyer raises a purchase order. The PO number must be unique, and the regression pack runs every night.",
        "examples": [
            (step("FILL", "label", "PO number", "PO-{RANDOM_INT}", description="Enter a unique PO number"), "Types something like `PO-482913`, a different number on every run."),
        ],
    },
    "TIMESTAMP": {
        "what": "The current date and time on the portal server, to the second, with no separators: `YYYYMMDDHHMMSS`, such as `20261107143015`.",
        "when": "Unique user names, email addresses and batch names that also tell you when the record was made, so test data is easy to find and clean up later.",
        "when_not": "When two values are made in the same second, because they would be identical. Add `{RANDOM_INT}` too if you need several in one go.",
        "scenario": "The HR application needs a new starter with an email address nobody has used before.",
        "examples": [
            (step("FILL", "label", "Email", "user_{TIMESTAMP}@corp.local", description="Enter a unique email address"), "Types `user_20261107143015@corp.local`. Anyone reading the database later can see when the test made it."),
        ],
    },
    "TODAY_DATE": {
        "what": "Today's date on the portal server, as year-month-day: `YYYY-MM-DD`, such as `2026-11-07`.",
        "when": "Date fields that accept that format, searching for records created today, and checking that a screen shows today's date.",
        "when_not": "When the screen expects another format, such as `07/11/2026`. Use `{TODAY_DMY}` or `{TODAY_MDY}` there.",
        "scenario": "An invoice raised today must show today's date as its issue date, and its due date is 30 days later.",
        "examples": [
            (step("FILL", "label", "Invoice date", "{TODAY_DATE}", description="Set the invoice date to today"), "Types `2026-11-07` when run on 7 November 2026."),
            (step("VERIFY_TEXT_CONTAINS", "test_id", "issue-date", "{TODAY_DATE}", description="Issue date is today"), "Passes when the issue date on screen contains today's date in the same format."),
            (step("FILL", "label", "Due date", "{TODAY_DATE+30}", description="Due date is 30 days from today"), "Add `+N` or `-N` days, up to 3650 either way: types `2026-12-07` on 7 November 2026. Month and year ends are handled."),
        ],
    },
    "TODAY_DMY": {
        "what": "Today's date on the portal server, as day/month/year: `DD/MM/YYYY`, such as `07/11/2026`. Takes a day offset like `{TODAY_DMY+7}`.",
        "when": "UK and European date fields, and .NET date pickers set to a day-first culture.",
        "when_not": "When the field wants a month first or year first. Look at what the field shows when you pick a date by hand.",
        "scenario": "A delivery must be booked one week ahead, in a form that expects `14/11/2026`.",
        "examples": [
            (step("FILL", "label", "Delivery date", "{TODAY_DMY+7}", description="Deliver in a week"), "Types `14/11/2026` when run on 7 November 2026."),
            (step("VERIFY_TEXT_CONTAINS", "css", ".history", "{TODAY_DMY-1}", description="Yesterday's entry is listed"), "A minus offset counts back: `06/11/2026`."),
        ],
    },
    "TODAY_MDY": {
        "what": "Today's date on the portal server, as month/day/year: `MM/DD/YYYY`, such as `11/07/2026`. Takes a day offset like `{TODAY_MDY+7}`.",
        "when": "Fields built for US formats, which many off-the-shelf Angular and React date pickers use by default.",
        "when_not": "On a day-first form: `11/07/2026` would be read as 11 July.",
        "scenario": "A vendor portal expects the contract start date as `MM/DD/YYYY`.",
        "examples": [
            (step("FILL", "placeholder", "MM/DD/YYYY", "{TODAY_MDY+1}", description="Contract starts tomorrow"), "Types `11/08/2026` when run on 7 November 2026."),
        ],
    },
    "UUID": {
        "what": "A globally unique 36-character identifier, such as `3f2b8c1e-9a4d-4e7b-8f10-2c6d5a7e9b34`.",
        "when": "Fields that need a value nobody else could ever have chosen: correlation keys, transaction references, external integration ids.",
        "when_not": "Fields with a length limit or a fixed pattern, such as a 10-character reference. Use `{RANDOM_INT}` there.",
        "scenario": "A payments screen asks for an external transaction reference that must never repeat.",
        "examples": [
            (step("FILL", "label", "Transaction reference", "{UUID}", description="Enter a unique transaction reference"), "Types a brand-new 36-character id."),
        ],
    },
    "AUTH_USERNAME": {
        "what": "The service account user name saved on the application by a Test Manager.",
        "when": "On every standard login screen. When the test account changes next month, a Test Manager updates it once on the application, and every test case uses the new one at its next run.",
        "when_not": "When a test must log in as a different user from the saved one, such as an approver. Type that user name, or store it in a variable.",
        "scenario": "The team shares one test account per application, and it is rotated every quarter.",
        "examples": [
            (step("FILL", "label", "Username", "{AUTH_USERNAME}", description="Enter the user name"), "Types the user name saved on the application, such as `svc_qa`."),
        ],
    },
    "AUTH_PASSWORD": {
        "what": "The password saved on the application. It is stored encrypted, and only decrypted at the moment the step types it.",
        "when": "Always, in place of a real password. The portal replaces the password with `********` in everything it writes down: live progress, step results, error messages, captured variables and the Excel and PDF reports.",
        "when_not": "Never type a password as plain `Input data`. Only the application's saved password is hidden, so a typed one would appear in results and reports for anyone to read.",
        "scenario": "Reports are attached to defects and emailed to managers. The password must never appear in them.",
        "examples": [
            (step("FILL", "label", "Password", "{AUTH_PASSWORD}", description="Enter the password"), "Types the real password into the box, but the result and the report show `********`."),
        ],
    },
}

# Category A tokens are new every time. Fill once, store, reuse.
GOLDEN_RULE = [
    step("FILL", "label", "PO number", "PO-{RANDOM_INT}", description="Enter a unique PO number"),
    step("STORE_INPUT_VALUE", "label", "PO number", store="PO_NUMBER", description="Remember the PO number"),
    step("CLICK", "role", "button|Save", description="Save the order"),
    step("FILL", "placeholder", "Search orders", "{PO_NUMBER}", description="Search for the same PO"),
    step("VERIFY_TEXT_CONTAINS", "css", ".results-table", "{PO_NUMBER}", description="The new PO is listed"),
]

VARIABLE_RULES = [
    "Make up any name using letters, digits and underscores, not starting with a digit: `ORDER_ID`, `INVOICE_TOTAL`, `CUSTOMER_CODE`, `user2`. Capitals make them easy to spot.",
    "The built-in names (`RANDOM_INT`, `AUTH_PASSWORD` and the rest) are taken and cannot be used as your own.",
    "Storing to the same name again replaces the old value.",
    "A variable lasts for one run: every later step and every later test case in the same run can read it. The next run starts empty, so a value is always captured fresh.",
    "Captured values are listed under `Captured runtime variables` on the run page and in the reports, which helps when checking what a test saw.",
]

# Which STORE_ keyword to use: (keyword, when, what the page looks like, example step)
STORE_CHOOSER = [
    ("STORE_TEXT", "The value is ordinary text on the page: a heading, a label, a table cell, a badge.", '<span data-testid="order-id">1042</span>',
     step("STORE_TEXT", "test_id", "order-id", store="ORDER_ID", description="Remember the order number")),
    ("STORE_INPUT_VALUE", "The value sits inside a text box. Either the application filled it in, or you typed `PO-{RANDOM_INT}` into it and need to remember which number was picked. `STORE_TEXT` cannot read text boxes.", '<input id="orderRef" value="PO-482913">',
     step("STORE_INPUT_VALUE", "id", "orderRef", store="ORDER_REF", description="Remember the reference")),
    ("STORE_REGEX", "The value is buried in a longer sentence, such as a banner that says `Success! Request #REQ-88412 has been sent to manager`, and you want only `REQ-88412`. The part in brackets is what gets kept.", '<div class="alert-success">Success! Request #REQ-88412 has been sent to manager</div>',
     step("STORE_REGEX", "css", ".alert-success", r"Request #(REQ-\d+)", "REQ_ID", "Pull out the request number")),
]

# Test chaining: test case 1 captures, test case 2 reuses.
CHAIN_CREATE = [
    step("CALL_BLOCK", input_data="Login", description="Sign in"),
    step("NAVIGATE", input_data="/requests/new", description="Open the new request form"),
    step("FILL", "label", "Title", "Laptop request {TIMESTAMP}", description="Enter a unique title"),
    step("SELECT_DROPDOWN", "label", "Category", "Hardware", description="Choose the category"),
    step("CLICK", "role", "button|Submit", description="Submit the request"),
    step("VERIFY_TEXT_CONTAINS", "css", ".alert-success", "has been sent", description="Success message is shown"),
    step("STORE_TEXT", "test_id", "request-id", store="REQ_ID", description="Remember the request number"),
]

CHAIN_APPROVE = [
    step("NAVIGATE", input_data="/requests", description="Open the request list"),
    step("FILL", "placeholder", "Search requests", "{REQ_ID}", description="Search for the new request"),
    step("PRESS_KEY", "placeholder", "Search requests", "Enter", description="Run the search"),
    step("CLICK", "row_action", "{REQ_ID} | Approve", description="Approve that exact request"),
    step("VERIFY_TEXT_CONTAINS", "css", ".alert-success", "{REQ_ID}", description="Approval names the request"),
]

CHAIN_NOTES = [
    "Test case 2 has `Depends on` set to `Create Request`. If test case 1 fails, test case 2 is marked `Skipped/Blocked` instead of searching for a request that does not exist.",
    "On the run screen, tick both and put `Create Request` above `Approve Request`. Test cases always run in the order shown.",
    "Test case 2 does not log in again: test case 1 passed, so the browser is still signed in. If test case 1 had failed, the browser would have been reset.",
    "`{REQ_ID}` works in the search box and inside the `row_action` locator, so the Approve button is found in the right row of a busy grid.",
]


CASE_OPTIONS = [
    ("Name", "Required", "A short name that says what is being checked. It must be unique inside the application, and it is what you see in results and what `CALL_BLOCK` and the import file refer to.", "`Create order with urgent flag`"),
    ("Depends on", "Optional", "Another test case in this application that must pass first. If it failed, was skipped, or is not earlier in the run order, this test case is marked Skipped/Blocked instead of running. Choosing it here does not add it to a run: you still need to tick it and place it earlier.", "`Verify Order` depends on `Create Order`"),
    ("Description", "Optional", "A note for the people reading the suite. It has no effect on the run.", "`Checks that a new order appears in the search results.`"),
    ("Reusable block", "Optional", "Tick this for a set of steps that other test cases run with `CALL_BLOCK`, such as a login. A block is still listed on the run screen, but you normally leave it unticked there, because the test cases that call it already run its steps.", "A block named `Login` with four steps"),
    ("Teardown block", "Optional", "A reusable block that runs after the last step even when a step failed, to log out of an application that allows one session, or delete the data the test made. Its steps appear in results labelled `[Teardown]`. A failed teardown step is noted under the test case's own result and never replaces the reason it failed. It does not run when the run is aborted. A reusable block cannot have a teardown of its own.", "`Logout` as the teardown of `Approve Invoice`"),
]

STEP_FIELDS = [
    ("Keyword", "The action this step performs. The other fields switch on and off to match it, so a field you cannot see is not used by that keyword. See the keyword reference below.", "`CLICK`"),
    ("Locator type", "How the portal should find the element on the page: by id, label, visible text and so on. See the locator section below.", "`label`"),
    ("Locator value", "What to look for, written the way the locator type expects it. Tokens and stored variables work here.", "`Username`"),
    ("Input data", "The value the keyword uses: the text to type, the option to choose, the expected text, the URL or the key to press. Tokens and stored variables work here.", "`PO-{RANDOM_INT}`"),
    ("Store as", "Only for the `STORE_` keywords. The variable name to save the value under. Use letters, digits and underscores, and do not start with a digit. Later steps read it as `{NAME}`.", "`ORDER_ID`"),
    ("Description", "Optional, but worth writing. It appears in the live progress and in the results, so a failure reads as `Save the order` rather than as a bare keyword.", "`Save the order`"),
]

STEP_BUTTONS = [
    ("Add step", "Adds a blank step at the end of the list."),
    ("Up / Down, or drag the number", "Changes the order. Steps always run from top to bottom."),
    ("Copy", "Adds a duplicate directly below, which is the quickest way to write similar steps."),
    ("Del", "Removes the step. Nothing is permanent until you press Save test case."),
]

LOCATOR_GUIDE = {
    "label": {
        "plain": 'Like finding a form box by the words printed next to it. If the screen says Username beside a box, the value is `Username`.',
        "finds": "A form field by the text of its label.",
        "html": '<label for="user">Username</label><input id="user">',
        "value": "Username",
        "matching": "Ignores upper and lower case and matches part of the label, so `User` also finds it.",
        "best_for": "Form fields. This is usually the best first choice for inputs, because it reads like the screen and survives page redesigns.",
    },
    "role": {
        "plain": 'Like describing something by what it is and what it says: the button that says Sign in. Write the kind of thing, a `|`, then its words.',
        "finds": "An element by what it is (button, link, checkbox) and, after a `|`, its name. The name is the text a person sees on it.",
        "html": "<button>Sign in</button>",
        "value": "button|Sign in",
        "matching": "The name ignores case and matches part of the text. Without a name (`button`) it means every button, which only works if the page has exactly one.",
        "best_for": "Buttons, links, tabs and checkboxes. Common roles: `button`, `link`, `textbox`, `checkbox`, `radio`, `combobox`, `heading`, `tab`, `menuitem`, `row`, `cell`.",
    },
    "text": {
        "plain": 'Like pointing at words on the screen. Good for messages and menu entries, but short words such as `Save` often appear in several places.',
        "finds": "An element by the text it shows.",
        "html": "<span>Order saved</span>",
        "value": "Order saved",
        "matching": "Ignores case and matches part of the text, so short values often match several elements. Prefer longer, specific text.",
        "best_for": "Messages, menu entries and anything that is not a form field or button.",
    },
    "placeholder": {
        "plain": 'Like finding a box by the grey hint written inside it before you type, such as Search orders.',
        "finds": "An input or text area by its grey hint text, the `placeholder` attribute.",
        "html": '<input placeholder="Search orders">',
        "value": "Search orders",
        "matching": "Ignores upper and lower case and matches part of the text, so `search` also finds it.",
        "best_for": "Search and filter boxes in Angular and React pages that have no `<label>`.",
    },
    "id": {
        "plain": 'Like a name badge a developer pinned on the element. Unique and quick, as long as the developers did not let the computer make it up.',
        "finds": "An element by its `id` attribute. Type the id alone, with no `#`.",
        "html": '<input id="orderRef">',
        "value": "orderRef",
        "matching": "Exact, including upper and lower case. Ids with characters such as `$` or `:` are fine, which suits .NET pages.",
        "best_for": "Pages with stable, readable ids. Avoid ids that change on every load, such as `input-8f3a2`.",
    },
    "id_ends_with": {
        "plain": 'Like recognising a house by its number when the street name in front keeps changing. ASP.NET pages glue long prefixes onto ids, so match the end you recognise.',
        "finds": "An element whose `id` attribute ends with this text.",
        "html": '<input id="ctl00_MainContent_txtOrderRef">',
        "value": "txtOrderRef",
        "matching": "Exact end of the id, including upper and lower case. `Ref` also matches this one, so use the whole control name.",
        "best_for": "ASP.NET WebForms pages, where the part you recognise follows a long prefix that changes with the master page. In a grid, every row has the same ending, so add a number such as `btnEdit @2` or use `row_action`.",
    },
    "name": {
        "plain": "Like the name written on a paper form's box, which the server uses when the form is sent. Older forms often have one.",
        "finds": "A form element by its `name` attribute.",
        "html": '<input name="email">',
        "value": "email",
        "matching": "Exact, including upper and lower case. Radio buttons in a group share a name, so add a number such as `size @2`.",
        "best_for": "Older forms that have names but no usable labels or ids.",
    },
    "title": {
        "plain": 'Like the little yellow tooltip that appears when you rest the mouse on an icon. Ideal for icon buttons with no words.',
        "finds": "An element by its `title` attribute, the tooltip shown when the mouse rests on it.",
        "html": '<button title="Delete row"><img src="bin.png"></button>',
        "value": "Delete row",
        "matching": "Ignores upper and lower case and matches part of the text.",
        "best_for": "Icon buttons with no text of their own.",
    },
    "row_action": {
        "plain": 'Like saying: in the row for PO-1042, press Edit. You name the row by any text in it, and the button by its words.',
        "finds": "A button or link in a table row, chosen by text in that row. Write the row text, then `|`, then the button or link text. A stored variable works as the row text.",
        "html": "<tr><td>PO-1042</td><td><button>Edit</button></td></tr>",
        "value": "PO-1042 | Edit",
        "matching": "Both sides ignore case and match part of the text. So `PO-104` also finds the row for `PO-1042`, and `Edit` also finds `Edit history`, and the step then fails rather than guessing. If the action is not a button or link, it is found by its text.",
        "best_for": "Grids where every row has the same buttons, such as `{ORDER_ID} | Approve`. Also works with `role=row` grids. Shorter and easier to read than the same thing in XPath.",
    },
    "test_id": {
        "plain": 'Like a label the developers stuck on purely so testers can find things. It never changes when the screen is redesigned, so it is always the first choice when it exists.',
        "finds": "An element by its `data-testid` attribute, which developers add specifically for tests.",
        "html": '<span data-testid="order-id">1042</span>',
        "value": "order-id",
        "matching": "Exact, including upper and lower case.",
        "best_for": "The most reliable choice whenever the application provides it. Ask your developers to add them to hard-to-find elements.",
    },
    "css": {
        "plain": 'Like describing something by its appearance: the button with the save class. Powerful, but technical. Use it when the simpler types cannot single the element out.',
        "finds": "An element by a CSS selector.",
        "html": '<button class="btn save">Save</button>',
        "value": "button.save",
        "matching": "Exactly as CSS defines it. `#saveOrder` is an id, `.save` is a class, `input[name='email']` is an attribute.",
        "best_for": "When the easier types cannot single the element out. Avoid long chains like `div > div:nth-child(3) > span`, because they break when the layout changes.",
    },
    "xpath": {
        "plain": 'Like turn-by-turn directions through the page: go to the row whose cell says PO-1, then take its Edit link. The last resort, because the directions break when the layout changes.',
        "finds": "An element by an XPath expression.",
        "html": "<tr><td>PO-1</td><td><a>Edit</a></td></tr>",
        "value": "//tr[td='PO-1']//a[text()='Edit']",
        "matching": "Exactly as XPath defines it. Upper and lower case matter.",
        "best_for": "The last resort, or when you must find one element relative to another, such as the Edit link in the row for a given order.",
    },
}

# How to reach an element inside an iframe, shown after the locator types.
FRAME_GUIDE = [
    (step("CLICK", "role", "iframe#editor || button|Save", description="Save inside the editor frame"), "One step: `||` separates the frame from the locator. The part before it is a CSS selector for the frame. The part after it is written the way the locator type expects."),
    (step("FILL", "label", "#outer || #inner || Username", "{AUTH_USERNAME}", description="Type in a nested frame"), "Frames inside frames read from the outside in."),
    (step("SWITCH_TO_FRAME", "css", "iframe#editor", description="Work inside the editor"), "Several steps: later steps search inside the frame with no need for `||`. Finish with `SWITCH_TO_MAIN_FRAME`."),
]

# Best first, the order a beginner should try them in.
LOCATOR_ORDER = [
    "test_id", "label", "role", "placeholder", "id", "id_ends_with", "name", "title", "text", "row_action",
    "css", "xpath",
]

# Picking one of several matches, shown after the locator types.
PICK_GUIDE = [
    (step("CLICK", "role", "button|Save @first", description="The first Save button"), "`@first` takes the first match on the page."),
    (step("CLICK", "text", "Edit @2", description="The second Edit"), "A number counts from 1 in page order."),
    (step("CLICK", "css", "#footer button @last", description="The last footer button"), "`@last` takes the last match."),
    (step("CLICK", "row_action", "{ORDER_ID} | Edit @2", description="The second Edit in this row"), "Works with every locator type."),
    (step("CLICK", "xpath", "//table//a @2", description="The second link in a table"), "On `xpath` it does the same as `(//table//a)[2]`. After a `/`, as in `//a/ @first`, it is an XPath attribute and is left alone."),
    (step("CLICK", "role", "iframe#editor || button|Save @2", description="The second Save in the frame"), "Goes at the very end, after any frames."),
]

# Text that really contains || or ends in @first, @last or @ and a number.
ESCAPE_GUIDE = [
    (step("CLICK", "text", r"Yes \|| No", description="The Yes || No button"), r"A backslash before `||` makes it part of the text instead of a frame separator. It works in every part of the value, frames included."),
    (step("CLICK", "role", r"button|Room \@2", description="The button named Room @2"), r"A backslash before the `@` makes ` @2` part of the name instead of a pick. `\@first` and `\@last` work the same way."),
    (step("CLICK", "text", r"Room \@2 @last", description="The last Room @2"), "An escaped ending and a real pick can be used together, with the pick last."),
    (step("CLICK", "text", r"#help || Terms \|| conditions", description="Text in a frame"), "Only the unescaped `||` separates the frame from the text."),
]

INTENTS = [
    ("Open a page", "NAVIGATE"),
    ("Type into a field, or clear it", "FILL"),
    ("Type into a search-as-you-type or autocomplete box, key by key", "TYPE_SEQUENTIALLY"),
    ("Scroll to something, or scroll a grid to load more rows", "SCROLL_TO"),
    ("Press a button or follow a link", "CLICK"),
    ("Click something that opens a tab or pop-up, and carry on there", "CLICK_AND_SWITCH_WINDOW"),
    ("Double-click something", "DOUBLE_CLICK"),
    ("Move the mouse over something, such as a menu", "HOVER"),
    ("Drag something onto something else", "DRAG_AND_DROP"),
    ("Close a message or banner only if it appears", "CLICK_IF_VISIBLE"),
    ("Fill a field only if it appears", "FILL_IF_VISIBLE"),
    ("Choose from a dropdown", "SELECT_DROPDOWN"),
    ("Tick a checkbox or radio button", "CHECK"),
    ("Untick a checkbox", "UNCHECK"),
    ("Press Enter, Tab or a shortcut", "PRESS_KEY"),
    ("Attach a file", "UPLOAD_FILE"),
    ("Work in a new tab or pop-up", "SWITCH_TO_NEW_WINDOW"),
    ("Close a tab or pop-up and go back", "CLOSE_WINDOW"),
    ("Go back to an earlier window and leave this one open", "SWITCH_TO_WINDOW"),
    ("Work inside an iframe", "SWITCH_TO_FRAME"),
    ("Leave an iframe", "SWITCH_TO_MAIN_FRAME"),
    ("Answer No to a browser pop-up, or type into a prompt", "PREPARE_DIALOG"),
    ("Wait until something appears", "WAIT_FOR_ELEMENT"),
    ("Wait a fixed time", "WAIT_SECONDS"),
    ("Check that a message or text is shown", "VERIFY_TEXT_CONTAINS"),
    ("Check that an element is visible", "VERIFY_ELEMENT_VISIBLE"),
    ("Check that something has gone, such as a deleted row or a spinner", "VERIFY_ELEMENT_NOT_VISIBLE"),
    ("Check that an error or text is not shown", "VERIFY_TEXT_NOT_PRESENT"),
    ("Check that a button or field can be used", "VERIFY_ELEMENT_ENABLED"),
    ("Check that a button or field is greyed out", "VERIFY_ELEMENT_DISABLED"),
    ("Check how many rows or items there are", "VERIFY_ELEMENT_COUNT"),
    ("Keep a screenshot as proof that a step passed", "CAPTURE_SCREENSHOT"),
    ("Check what a field contains", "VERIFY_VALUE"),
    ("Check which page you are on", "VERIFY_URL"),
    ("Check what a browser pop-up said", "VERIFY_DIALOG_TEXT"),
    ("Check that a file was downloaded", "VERIFY_DOWNLOAD"),
    ("Check that a Print button really prints", "VERIFY_PRINT_CALLED"),
    ("Check text, and carry on if it is wrong", "SOFT_VERIFY_TEXT_CONTAINS"),
    ("Check an element is visible, and carry on if not", "SOFT_VERIFY_ELEMENT_VISIBLE"),
    ("Check what a field contains, and carry on if it is wrong", "SOFT_VERIFY_VALUE"),
    ("Check which page you are on, and carry on if it is wrong", "SOFT_VERIFY_URL"),
    ("Save text from the page for later", "STORE_TEXT"),
    ("Save what a field contains for later", "STORE_INPUT_VALUE"),
    ("Save part of some text for later", "STORE_REGEX"),
    ("Save what a browser pop-up said for later", "STORE_DIALOG_TEXT"),
    ("Save how many rows or items there are for later", "STORE_ELEMENT_COUNT"),
    ("Reuse a set of steps", "CALL_BLOCK"),
    ("Run a set of steps only if something appears", "CALL_BLOCK_IF_VISIBLE"),
    ("Run a set of steps only if a text, a field or a variable says so", "CALL_BLOCK_IF"),
    ("Run a set of steps several times", "REPEAT_BLOCK"),
    ("Run a set of steps again until something appears, such as Refresh until Completed", "REPEAT_BLOCK_UNTIL"),
]

KEYWORD_GUIDE = {
    "NAVIGATE": {
        "detail": "Opens a page and waits for it to finish loading. Most test cases start with this step. Only `http` and `https` addresses are allowed.",
        "examples": [
            (step("NAVIGATE", description="Open the home page"), "Input data blank: opens the application's Base URL."),
            (step("NAVIGATE", input_data="/orders/new", description="Open the new order page"), "A path starting with `/` goes after the server name. With Base URL `https://app.corp.local/hr/` this opens `https://app.corp.local/orders/new`."),
            (step("NAVIGATE", input_data="orders/new", description="Open a page under the Base URL"), "With no leading `/`, it goes after the Base URL's folder: `https://app.corp.local/hr/orders/new`."),
            (step("NAVIGATE", input_data="/orders/{ORDER_ID}", description="Open the order just created"), "Uses a variable stored by an earlier step."),
        ],
        "tips": ["A full address works too, but a path keeps the test case working when the same application moves to another server."],
    },
    "WAIT_SECONDS": {
        "detail": "Pauses for a fixed time, from 0 to {max_wait} seconds. Decimals such as `0.5` are allowed.",
        "examples": [
            (step("WAIT_SECONDS", input_data="2", description="Let the animation finish"), "Waits 2 seconds, then carries on."),
        ],
        "tips": ["Use this rarely. A fixed wait is either too short on a slow day or wastes time on a fast one. Other keywords already wait for their element, and `WAIT_FOR_ELEMENT` covers the rest."],
    },
    "WAIT_FOR_ELEMENT": {
        "detail": "Waits until the element is visible, up to the timeout. The step fails if it never appears.",
        "examples": [
            (step("WAIT_FOR_ELEMENT", "css", ".results-table", description="Wait for the search results"), "Continues as soon as the table appears."),
        ],
        "tips": ["Useful before a step that reads the page straight after a slow action, such as `STORE_TEXT` after a search."],
    },
    "SWITCH_TO_NEW_WINDOW": {
        "detail": "Moves the test into a new tab or pop-up that the application opened, and waits for it to load. Later steps act on that window until it closes. It waits up to the timeout for the window to appear, so no wait is needed after the click that opens it.",
        "examples": [
            (step("SWITCH_TO_NEW_WINDOW", description="Move to the lookup pop-up"), "Blank input takes the newest window the test has not been in yet."),
            (step("SWITCH_TO_NEW_WINDOW", input_data="/invoice", description="Move to the invoice tab"), "Takes the new window whose address or title contains `/invoice`. Upper and lower case count."),
        ],
        "tips": ["If several new windows are open, or one could still be open from an earlier step, give part of the address or title so the right one is chosen.", "This only moves forward to a new window. To return to an earlier one, use `SWITCH_TO_WINDOW`, or close the current one with `CLOSE_WINDOW`.", "When a click opens the window, `CLICK_AND_SWITCH_WINDOW` does both in one step."],
    },
    "CLOSE_WINDOW": {
        "detail": "Closes the current tab or pop-up and returns to the window the test was in before it. There is no need to call this if the application closes the pop-up by itself: the test returns to the earlier window on its own.",
        "examples": [
            (step("CLOSE_WINDOW", description="Close the lookup pop-up"), "The next step acts on the window that came before it."),
        ],
        "tips": ["The step fails if there is no earlier window to return to, which is usually a sign of a missing `SWITCH_TO_NEW_WINDOW`."],
    },
    "SWITCH_TO_WINDOW": {
        "detail": "Moves to any open window without closing the current one, so a test can go back and forth. `main` or `0` is the window the test started in. `1`, `2` and so on count the other windows in the order the test first moved to them. Anything else is part of a window's address or title, and it waits up to the timeout for one to match.",
        "examples": [
            (step("SWITCH_TO_WINDOW", input_data="main", description="Back to the main window"), "The pop-up stays open, so the test can return to it."),
            (step("SWITCH_TO_WINDOW", input_data="1", description="Back to the invoice window"), "The first window the test moved to after the main one."),
            (step("SWITCH_TO_WINDOW", input_data="/invoice", description="Find the invoice window"), "Any open window whose address or title contains `/invoice`, including one the test has not been in. Upper and lower case count."),
        ],
        "tips": ["Numbers count open windows, so closing a window moves the later ones down by one. If `main` itself was closed, `main` means the oldest window still open.", "Input that is only digits is always a number, never part of a title."],
    },
    "SWITCH_TO_FRAME": {
        "detail": "Moves the test inside an iframe, so that later steps search in it. Use it again to go into a frame inside this one. The test returns to the top-level page after `SWITCH_TO_MAIN_FRAME`, when the page loads a new document, and on any change of window.",
        "examples": [
            (step("SWITCH_TO_FRAME", "css", "iframe#editor", description="Work inside the editor"), "Later steps search inside that frame."),
            (step("SWITCH_TO_FRAME", "id", "paymentFrame", description="Work in the payment frame"), "Any locator type works, as long as it finds the frame element itself. Otherwise the step fails and says what it found."),
        ],
        "tips": ["A .NET postback loads a new document, so use `SWITCH_TO_FRAME` again after it. A screen change in Angular or React does not, so the test stays in the frame.", "For a single step, a locator with `||` is shorter. See the iframe part of the locator section."],
    },
    "SWITCH_TO_MAIN_FRAME": {
        "detail": "Leaves any iframe and returns to the top-level page. If the test is not in a frame, nothing changes and the step passes.",
        "examples": [
            (step("SWITCH_TO_MAIN_FRAME", description="Back to the page"), "The next step searches the whole top-level page again."),
        ],
    },
    "CLICK": {
        "detail": "Clicks the element. The portal first waits for it to be visible, enabled and not moving, so you rarely need a wait beforehand.",
        "examples": [
            (step("CLICK", "role", "button|Save", description="Save the order"), "Clicks the button whose text contains Save."),
            (step("CLICK", "role", "link|Reports", description="Open Reports"), "Follows the link named Reports."),
            (step("CLICK", "xpath", "//tr[td='{ORDER_ID}']//a[text()='Edit']", description="Edit this order"), "Finds the Edit link in the row for the stored order number."),
        ],
        "tips": ["Confirmation pop-ups from the browser (`Are you sure?`) are accepted automatically, so no extra step is needed. To answer differently, use `PREPARE_DIALOG` first.",
                 "If the click opens a new tab or pop-up, the next step still acts on this window. Use `CLICK_AND_SWITCH_WINDOW` to carry on in the new one."],
    },
    "CLICK_AND_SWITCH_WINDOW": {
        "detail": "Clicks the element, waits up to the timeout for the tab or pop-up that the click opens, and carries on in it once it has loaded. Only a window opened by this click counts: one that was already open, even if the test never moved to it, is ignored. With input data, the new window's address or title must contain that text.",
        "examples": [
            (step("CLICK_AND_SWITCH_WINDOW", "role", "button|Lookup", description="Open the lookup pop-up"), "Later steps act on the pop-up."),
            (step("CLICK_AND_SWITCH_WINDOW", "role", "link|Invoice", "/invoice", description="Open the invoice tab"), "Waits for a new window whose address or title contains `/invoice`. Upper and lower case count."),
        ],
        "tips": ["Return with `CLOSE_WINDOW` or `SWITCH_TO_WINDOW`, as after `SWITCH_TO_NEW_WINDOW`.", "If the click opens nothing, the step fails after the timeout and the screenshot shows the window the click was in."],
    },
    "HOVER": {
        "detail": "Moves the mouse over the element and leaves it there, for example to open a menu that appears on hover. It waits for the element first, as `CLICK` does.",
        "examples": [
            (step("HOVER", "role", "link|Reports", description="Open the Reports menu"), "The next step can click an entry in the menu."),
        ],
    },
    "DRAG_AND_DROP": {
        "detail": "Drags the element in the locator onto a destination. Write the destination in the input data as a locator type, then `|`, then a locator value.",
        "examples": [
            (step("DRAG_AND_DROP", "text", "Task 12", "css|#done-column", description="Move the task to Done"), "Drops it on the element with id `done-column`."),
            (step("DRAG_AND_DROP", "id", "card-3", "role|listitem|Completed", description="Move the card"), "A role destination can have a name after a second `|`."),
        ],
        "tips": ["Follow it with a `VERIFY_` step, because a drop the application ignores does not fail by itself.", "Inside a frame, the destination is searched in the same frame."],
    },
    "CLICK_IF_VISIBLE": {
        "detail": "Clicks the element if it appears in time. If it does not, the step passes and the test carries on. It waits 1.5 seconds, or the number of seconds in the input data. Use it for things that only sometimes appear, such as a cookie banner.",
        "examples": [
            (step("CLICK_IF_VISIBLE", "role", "button|Accept cookies", description="Close the cookie banner"), "Waits up to 1.5 seconds. The result shows `clicked` or `not visible (skipped)`."),
            (step("CLICK_IF_VISIBLE", "id", "welcomeClose", "5", description="Close the welcome message"), "Waits up to 5 seconds."),
        ],
        "tips": ["This step cannot catch a missing element, because absent counts as a pass. Use `CLICK` when the element must be there.", "If the locator matches several visible elements, the step still fails."],
    },
    "FILL_IF_VISIBLE": {
        "detail": "Fills the field if it appears within 1.5 seconds. If it does not, the step passes and the test carries on. Blank input clears the field.",
        "examples": [
            (step("FILL_IF_VISIBLE", "label", "Security code", "{CODE}", description="Enter the code if asked"), "Some logins ask for this and others do not."),
        ],
    },
    "DOUBLE_CLICK": {
        "detail": "Double-clicks the element. Use it only where the application really needs a double-click, such as opening a row in a grid.",
        "examples": [
            (step("DOUBLE_CLICK", "text", "PO-1042", description="Open the order from the grid"), "Double-clicks the cell showing PO-1042."),
        ],
    },
    "FILL": {
        "detail": "Replaces whatever is in a text field with the input data. Leave the input blank to clear the field. Spaces you type are kept exactly.",
        "examples": [
            (step("FILL", "label", "Username", "{AUTH_USERNAME}", description="Enter the user name"), "Types the user name saved on the application."),
            (step("FILL", "label", "Password", "{AUTH_PASSWORD}", description="Enter the password"), "Types the saved password. It shows as `********` in results."),
            (step("FILL", "id", "orderRef", "PO-{RANDOM_INT}", description="Enter a unique reference"), "Types something like `PO-482913`, different on each run."),
            (step("FILL", "label", "Comments", description="Clear the comments"), "Input data blank: empties the field."),
        ],
        "tips": ["Never type a real password as plain input data, because only the application's saved password is hidden in results. Save it on the application and use `{AUTH_PASSWORD}`.",
                 "`FILL` works on text boxes and text areas. For dropdowns use `SELECT_DROPDOWN`, and for checkboxes use `CHECK`."],
    },
    "SELECT_DROPDOWN": {
        "detail": "Chooses an option in a standard HTML `<select>` dropdown. The input data must equal the option's visible text or its value.",
        "examples": [
            (step("SELECT_DROPDOWN", "label", "Priority", "High", description="Set the priority"), "Chooses the option shown as High."),
            (step("SELECT_DROPDOWN", "id", "country", "IN", description="Set the country by value"), 'Chooses `<option value="IN">India</option>` by its value.'),
        ],
        "tips": ["Many modern applications draw their own dropdowns, which are not a `<select>`. For those use two `CLICK` steps: one to open the list and one on the option, for example `role` with `option|High`."],
    },
    "PREPARE_DIALOG": {
        "detail": "Chooses the answer to the next browser pop-up (alert, confirm or prompt). Put it before the step that causes the pop-up. It applies to one pop-up, and later ones are accepted as usual.",
        "examples": [
            (step("PREPARE_DIALOG", input_data="dismiss", description="Answer Cancel to the next pop-up"), "Presses Cancel, so a delete confirmation can be tested both ways."),
            (step("PREPARE_DIALOG", input_data="accept|Approved by QA", description="Type the reason"), "Types `Approved by QA` into a prompt and presses OK."),
            (step("PREPARE_DIALOG", input_data="accept", description="Answer OK to the next pop-up"), "Presses OK, which also happens with no step. Use it to clear the last message before `VERIFY_DIALOG_TEXT`."),
        ],
        "tips": ["Without this step every pop-up is accepted automatically, so existing test cases need no change."],
    },
    "CHECK": {
        "detail": "Ticks a checkbox or selects a radio button. If it is already ticked, nothing changes and the step passes.",
        "examples": [
            (step("CHECK", "label", "I agree to the terms", description="Accept the terms"), "Ticks the checkbox with that label."),
            (step("CHECK", "role", "radio|Express delivery", description="Choose express delivery"), "Selects the radio button with that name."),
        ],
    },
    "UNCHECK": {
        "detail": "Clears a checkbox. If it is already clear, nothing changes and the step passes. Radio buttons cannot be cleared this way: `CHECK` a different one instead.",
        "examples": [
            (step("UNCHECK", "label", "Send me newsletters", description="Opt out of newsletters"), "Clears the checkbox."),
        ],
    },
    "PRESS_KEY": {
        "detail": "Presses a key or a combination. With a locator the key goes to that element. With no locator it goes to whatever currently has focus.",
        "examples": [
            (step("PRESS_KEY", "label", "Search", "Enter", description="Submit the search"), "Presses Enter inside the Search box."),
            (step("PRESS_KEY", input_data="Escape", description="Close the pop-up"), "No locator: presses Escape on the page."),
            (step("PRESS_KEY", "label", "Notes", "Control+A", description="Select all the notes"), "Holds Control and presses A."),
        ],
        "tips": ["Key names are case sensitive: `Enter`, `Tab`, `Escape`, `Backspace`, `Delete`, `ArrowDown`, `ArrowUp`, `Home`, `End`, `PageDown`, `F5`. Combine with `+`, as in `Shift+Tab`."],
    },
    "UPLOAD_FILE": {
        "detail": "Attaches a file to a file-upload control. The file must already be in the `test_data` folder on the portal server, so ask an Admin to place it there. Files outside that folder are refused. The locator can be the `<input type=file>` itself, or a styled Browse button that opens the file picker. For a button, the portal clicks it and answers the picker itself, so no Windows dialog appears.",
        "examples": [
            (step("UPLOAD_FILE", "css", "input[type=file]", "invoice.pdf", description="Attach the invoice"), "Attaches `test_data/invoice.pdf`. The input is often hidden, which is fine for this keyword."),
            (step("UPLOAD_FILE", "label", "Attachment", "orders/bulk.xlsx", description="Attach the order file"), "Attaches a file from a subfolder of `test_data`."),
            (step("UPLOAD_FILE", "role", "button|Browse", "invoice.pdf", description="Attach through the Browse button"), "For Angular and React pages whose button opens the picker from script. The result says `(through the file picker)`."),
        ],
        "tips": ["If the element is not a file input and clicking it opens no file picker within the timeout, the step fails. Point the locator at the button that really opens the picker."],
    },
    "VERIFY_TEXT_CONTAINS": {
        "detail": "Checks that the element's text contains the input data, retrying until the timeout. With no locator it checks the whole page. Upper and lower case must match.",
        "examples": [
            (step("VERIFY_TEXT_CONTAINS", "css", ".alert-success", "Order saved", description="Success message is shown"), "Passes if the message contains `Order saved`."),
            (step("VERIFY_TEXT_CONTAINS", input_data="Welcome back", description="Welcome text is on the page"), "No locator: looks anywhere on the page."),
            (step("VERIFY_TEXT_CONTAINS", "css", "h1", "{ORDER_ID}", description="Heading shows the order"), "Compares with a stored variable."),
        ],
        "tips": ["Finish a test case with at least one `VERIFY_` step. A test case with none only proves that nothing crashed, not that the outcome was right."],
    },
    "VERIFY_ELEMENT_VISIBLE": {
        "detail": "Checks that the element is visible on the page, retrying until the timeout.",
        "examples": [
            (step("VERIFY_ELEMENT_VISIBLE", "role", "button|Log out", description="User is logged in"), "Passes once a Log out button is on screen."),
        ],
    },
    "VERIFY_VALUE": {
        "detail": "Checks that an input field's current value equals the input data exactly, retrying until the timeout. Use it for what is inside a field, because `VERIFY_TEXT_CONTAINS` does not read typed values.",
        "examples": [
            (step("VERIFY_VALUE", "label", "Quantity", "5", description="Quantity stayed at 5"), "Passes only if the field holds exactly `5`."),
            (step("VERIFY_VALUE", "id", "orderRef", "{ORDER_REF}", description="Reference was kept"), "Compares with a stored variable."),
        ],
    },
    "VERIFY_URL": {
        "detail": "Checks that the current address contains the input data, retrying until the timeout. Upper and lower case must match.",
        "examples": [
            (step("VERIFY_URL", input_data="/dashboard", description="Login went to the dashboard"), "Passes for any address containing `/dashboard`."),
        ],
    },
    "VERIFY_DIALOG_TEXT": {
        "detail": "Checks that the latest browser pop-up's message contains the input data, retrying until the timeout in case the pop-up comes late. Upper and lower case must match. Place it after the step that causes the pop-up.",
        "examples": [
            (step("VERIFY_DIALOG_TEXT", input_data="Are you sure", description="Confirmation was asked"), "Passes if the message contains `Are you sure`."),
        ],
        "tips": ["The last message is remembered, so an earlier pop-up could make this pass. `PREPARE_DIALOG` clears it, so use it before the step when that matters."],
    },
    "VERIFY_DOWNLOAD": {
        "detail": "Waits up to the timeout for a file to finish downloading and checks that it is not empty. With input data, the file name must contain that text, or match it if the text has a `*`. Upper and lower case must match. Each check uses up one file, so two downloads need two checks. Files are deleted when the browser session ends.",
        "examples": [
            (step("VERIFY_DOWNLOAD", description="A file was downloaded"), "Any file counts. The result shows its name and size."),
            (step("VERIFY_DOWNLOAD", input_data="*.xlsx", store="REPORT_NAME", description="An Excel file was downloaded"), "Store as is optional for this keyword, and saves the file name."),
            (step("VERIFY_DOWNLOAD", input_data="Report", description="The report was downloaded"), "The name must contain `Report`."),
        ],
        "tips": ["Place it after the step that starts the download. It checks the name and size, not what is inside the file."],
    },
    "VERIFY_PRINT_CALLED": {
        "detail": "Checks that the page asked the browser to print, waiting up to the timeout. During a run no print dialog ever opens: every page and pop-up counts its print requests instead, so a Print button can be tested without a Windows dialog stopping the run. Each check uses up the prints counted so far, so a second check needs a second print.",
        "examples": [
            (step("VERIFY_PRINT_CALLED", description="The invoice was sent to print"), "Place it after the step that prints. The result shows how many times, and the page title."),
        ],
        "tips": ["A frame from the same site counts on its page. A page that loads a new document after printing loses its count, so check straight after the print.", "It checks that printing was asked for, not what the printout looks like."],
    },
    "SOFT_VERIFY_TEXT_CONTAINS": {
        "detail": "Works like `VERIFY_TEXT_CONTAINS`, but a failure does not stop the test case. The failed step and a screenshot are recorded, the remaining steps still run, and the test case ends as Fail. Use it to report every wrong value on a screen in one run.",
        "examples": [
            (step("SOFT_VERIFY_TEXT_CONTAINS", "css", "h1", "Order summary", description="Heading is right"), "The test carries on to the next check either way."),
        ],
        "tips": ["Use the normal `VERIFY_` keywords where later steps depend on the result, such as after a login. Each failed soft check waits the full timeout, so many of them can make a run slow."],
    },
    "SOFT_VERIFY_ELEMENT_VISIBLE": {
        "detail": "Works like `VERIFY_ELEMENT_VISIBLE`, but a failure is recorded with a screenshot and the test case carries on. It ends as Fail.",
        "examples": [
            (step("SOFT_VERIFY_ELEMENT_VISIBLE", "role", "button|Export", description="Export button is shown"), "The test carries on to the next check either way."),
        ],
    },
    "SOFT_VERIFY_VALUE": {
        "detail": "Works like `VERIFY_VALUE`, but a failure is recorded with a screenshot and the test case carries on. It ends as Fail.",
        "examples": [
            (step("SOFT_VERIFY_VALUE", "label", "Quantity", "5", description="Quantity is 5"), "The test carries on to the next check either way."),
        ],
    },
    "SOFT_VERIFY_URL": {
        "detail": "Works like `VERIFY_URL`, but a failure is recorded with a screenshot and the test case carries on. It ends as Fail.",
        "examples": [
            (step("SOFT_VERIFY_URL", input_data="/summary", description="On the summary page"), "The test carries on to the next check either way."),
        ],
    },
    "STORE_TEXT": {
        "detail": "Saves the element's visible text into a variable, retrying until the text is not empty. Later steps and later test cases in the same run read it as `{NAME}`.",
        "examples": [
            (step("STORE_TEXT", "test_id", "order-id", store="ORDER_ID", description="Remember the order number"), "If the page shows `1042`, then `{ORDER_ID}` becomes `1042`."),
        ],
    },
    "STORE_INPUT_VALUE": {
        "detail": "Saves what an input field currently contains into a variable, retrying until it is not empty.",
        "examples": [
            (step("STORE_INPUT_VALUE", "id", "orderRef", store="ORDER_REF", description="Remember the reference"), "Saves the value in the field, including one the application filled in itself."),
        ],
        "tips": ["This is how to reuse a generated value. `{RANDOM_INT}` gives a new number every time it is used, so `FILL` with it once, then store the field and use your variable afterwards."],
    },
    "STORE_REGEX": {
        "detail": "Saves part of the text, found with a regular expression, retrying until it matches. If the pattern has a group in brackets, only that group is saved. With no locator it searches the whole page.",
        "examples": [
            (step("STORE_REGEX", "css", ".alert-success", r"Order #(\d+)", "ORDER_ID", "Pull out the order number"), "From `Order #1042 saved` it stores `1042`."),
            (step("STORE_REGEX", input_data=r"[A-Z]{3}-\d{4}", store="TICKET", description="Find the ticket number"), "No brackets and no locator: stores the whole match, such as `INC-2041`."),
        ],
        "tips": [r"Helpful patterns: `\d+` is digits, `\w+` is a word, `.*` is anything, `\s` is a space."],
    },
    "STORE_DIALOG_TEXT": {
        "detail": "Saves the latest browser pop-up's message into a variable, retrying until there is one. Place it after the step that causes the pop-up.",
        "examples": [
            (step("STORE_DIALOG_TEXT", store="POPUP_TEXT", description="Remember the pop-up message"), "If the pop-up said `Saved 3 rows`, then `{POPUP_TEXT}` holds that text."),
        ],
    },
    "CALL_BLOCK": {
        "detail": "Runs every step of a reusable block from this application at this point, exactly as if they were written here. The input data is the block's exact name, and the box suggests the names available. To give the block its own values, add `|` and `KEY=VALUE` pairs after the name: the variables are set just before the block runs, so one `Login` block can sign in as a maker in one test case and a checker in another.",
        "examples": [
            (step("CALL_BLOCK", input_data="Login", description="Sign in first"), "Runs all the steps of the block named `Login`."),
            (step("CALL_BLOCK", input_data="Login | USER=checker_01 | DEPT=Finance", description="Sign in as the checker"), "Sets `{USER}` to `checker_01` and `{DEPT}` to `Finance`, then runs `Login`, whose steps use `{USER}` and `{DEPT}`."),
            (step("CALL_BLOCK", input_data="Create Order | REF=PO-{RANDOM_INT} | DUE={TODAY_DMY+7}", description="Create an order due next week"), "A value can hold tokens and variables. They are filled in when the step runs."),
        ],
        "tips": ["Variables stored inside a block can be used by the steps after it. Blocks can call other blocks, up to 10 levels deep, but a block cannot call itself.",
                 "In results, the block's steps are listed individually and labelled with the block's name. A call with arguments adds one step first, showing what was set, with the password hidden.",
                 "Arguments stay set after the block, like any stored variable. A value cannot contain `|`, and a key cannot be a built-in token such as `TODAY_DATE`. Before the run starts, the portal checks that every `{VARIABLE}` inside the block has a value, counting the arguments."],
    },
    "VERIFY_ELEMENT_NOT_VISIBLE": {
        "detail": "Checks that the element is hidden or not on the page at all, retrying until the timeout. Use it after deleting a record, closing a dialog, or waiting for a loading spinner to finish.",
        "examples": [
            (step("VERIFY_ELEMENT_NOT_VISIBLE", "row_action", "{ORDER_ID} | Delete", description="The deleted order is gone"), "Passes once the row with the order and its Delete button is no longer on screen."),
            (step("VERIFY_ELEMENT_NOT_VISIBLE", "css", ".spinner", description="Loading has finished"), "Waits for the spinner to go, up to the timeout."),
        ],
        "tips": ["A locator with a typo also passes, because the element it names is not there. Check it once with `VERIFY_ELEMENT_VISIBLE` while the element is showing."],
    },
    "VERIFY_TEXT_NOT_PRESENT": {
        "detail": "Checks that the element's text does not contain the input data, retrying until the timeout. With no locator it checks the whole page. Upper and lower case must match.",
        "examples": [
            (step("VERIFY_TEXT_NOT_PRESENT", input_data="Server Error", description="No server error on the page"), "Fails if `Server Error` appears anywhere on the page."),
            (step("VERIFY_TEXT_NOT_PRESENT", "css", ".validation-summary", "required", description="No field is missing"), "Checks one area only."),
        ],
        "tips": ["It passes as soon as the text is absent, so place it after the page has finished updating, for example after a `VERIFY_TEXT_CONTAINS` for the success message."],
    },
    "VERIFY_ELEMENT_ENABLED": {
        "detail": "Checks that the element is enabled, retrying until the timeout: a button that can be pressed, or a field that can be typed into.",
        "examples": [
            (step("VERIFY_ELEMENT_ENABLED", "role", "button|Submit", description="Submit is ready once the form is complete"), "Passes when the Submit button is no longer greyed out."),
        ],
    },
    "VERIFY_ELEMENT_DISABLED": {
        "detail": "Checks that the element is disabled, retrying until the timeout. Use it for rules such as a Submit button that stays greyed out until every required field is filled.",
        "examples": [
            (step("VERIFY_ELEMENT_DISABLED", "role", "button|Submit", description="Submit is blocked on an empty form"), "Passes while the Submit button is disabled."),
            (step("VERIFY_ELEMENT_DISABLED", "label", "Employee number", description="Employee number cannot be edited"), "Works on fields too."),
        ],
    },
    "VERIFY_ELEMENT_COUNT": {
        "detail": "Counts the elements the locator matches and checks the number, retrying until the timeout, because a grid fills in after the page loads. Write a number for an exact count, or put `==`, `!=`, `>`, `>=`, `<` or `<=` in front of it.",
        "examples": [
            (step("VERIFY_ELEMENT_COUNT", "css", "#orders tbody tr", "5", description="Five orders are listed"), "Passes when exactly 5 rows are on the page."),
            (step("VERIFY_ELEMENT_COUNT", "css", "#results tbody tr", "> 0", description="The search found something"), "Passes once there is at least one row."),
            (step("VERIFY_ELEMENT_COUNT", "css", ".error-message", "== 0", description="No error messages"), "Passes at once when there are none, so place it after the page has settled."),
        ],
        "tips": ["A virtual grid (Angular CDK, AG Grid, React Window) only draws the rows on screen, so it counts those. Use `SCROLL_TO` first to load more, or check a total the grid shows in text.", "The error says how many there really were."],
    },
    "CAPTURE_SCREENSHOT": {
        "detail": "Takes a screenshot and keeps it on this passing step as evidence for UAT and compliance sign-off. With a locator it captures that element; with no locator, the whole page. The input data is an optional caption. The screenshot appears on the run page as `Proof of pass`, on the Evidence sheet of the Excel report and in the Proof-of-pass section of the PDF report.",
        "examples": [
            (step("CAPTURE_SCREENSHOT", input_data="Order confirmation", description="Evidence: order confirmed"), "Captures the whole page, with the caption `Order confirmation`."),
            (step("CAPTURE_SCREENSHOT", "css", "#approval-panel", description="Evidence: approval panel"), "Captures only the approval panel. The result says `Screenshot captured`."),
        ],
        "tips": ["Screenshots are stored with the run, so each one makes the database larger. Capture the milestones stakeholders sign off, not every step. Failed steps always get a screenshot of their own."],
    },
    "TYPE_SEQUENTIALLY": {
        "detail": "Clears the field, then types the input data one key at a time, 60 ms apart. Use it where `FILL` is too fast: search-as-you-type boxes, autocomplete and type-ahead dropdowns in Angular and React, and rich-text editors that react to each key.",
        "examples": [
            (step("TYPE_SEQUENTIALLY", "placeholder", "Search customers", "Smith", description="Type the customer name"), "Types S, m, i, t, h, so the suggestion list opens as a person would see it."),
            (step("TYPE_SEQUENTIALLY", "label", "Assign to", "{AUTH_USERNAME}", description="Type the user to assign"), "Variables work as in `FILL`."),
        ],
        "tips": ["Follow it with a `CLICK` on the suggestion, such as `role` `option|Smith, Jane`. Long text takes a while: 100 characters take about 6 seconds."],
    },
    "SCROLL_TO": {
        "detail": "With a locator, scrolls until the element is in view. Add `bottom`, `top` or a number of pixels to then scroll inside that element, which is how a virtual grid or an endless list is told to load more rows. With no locator, scrolls the page itself: `bottom`, `top`, or pixels such as `500` (down) or `-500` (up).",
        "examples": [
            (step("SCROLL_TO", "role", "button|Load more", description="Bring Load more into view"), "Scrolls the page until the button is on screen."),
            (step("SCROLL_TO", "css", ".ag-body-viewport", "bottom", description="Scroll the grid to its last row"), "Scrolls inside the grid, so it draws the rows at the end."),
            (step("SCROLL_TO", input_data="500", description="Scroll down a little"), "No locator: scrolls the page down by 500 pixels."),
        ],
        "tips": ["Most keywords scroll to their element on their own, so this is only needed for lazy loading, sticky headers, or a screenshot of a part lower down."],
    },
    "STORE_ELEMENT_COUNT": {
        "detail": "Saves how many elements the locator matches at this moment, as a number, into a variable. It does not wait, so place it after a step that waits for the list, such as `WAIT_FOR_ELEMENT` on the first row.",
        "examples": [
            (step("STORE_ELEMENT_COUNT", "css", "#orders tbody tr", store="ORDERS_BEFORE", description="Count the orders before adding one"), "If 7 rows are showing, `{ORDERS_BEFORE}` becomes `7`."),
        ],
        "tips": ["Compare it later with `CALL_BLOCK_IF`, such as `{ORDERS_BEFORE} > 0 || Clear Orders`, or show it in a `VERIFY_TEXT_CONTAINS` against a total on screen."],
    },
    "CALL_BLOCK_IF_VISIBLE": {
        "detail": "Runs a reusable block only if the element appears within 1.5 seconds. Otherwise its steps are left out, the step passes and the test carries on. The input data is the block's exact name.",
        "examples": [
            (step("CALL_BLOCK_IF_VISIBLE", "role", "button|Sign in", "Login", description="Log in if needed"), "Runs the `Login` block only if a Sign in button is showing."),
        ],
        "tips": ["The step numbers in the results skip the steps that were left out, and the result says how many there were.", "If a later step uses a variable stored only inside the block, and the block was left out, that step fails and says the variable has no value."],
    },
    "REPEAT_BLOCK": {
        "detail": "Runs a reusable block several times in a row. Write the block's exact name, then `|`, then the count, from 1 to 50. The count must be a number, because blocks are prepared before the run starts.",
        "examples": [
            (step("REPEAT_BLOCK", input_data="Create Item | 3", description="Create three items"), "Runs the `Create Item` block three times."),
        ],
        "tips": ["`{RANDOM_INT}` and the other tokens produce a new value on each repeat, and a stored variable holds the value from the latest repeat.", "In results, each step is labelled with its repeat, such as `[2/3]`. If a step fails, the remaining repeats do not run.", "A test case can expand to at most 5000 steps. Beyond that it is Skipped/Blocked before it starts."],
    },
    "CALL_BLOCK_IF": {
        "detail": "Runs a reusable block only if a condition holds. Otherwise its steps are left out, the step passes with `condition false (skipped)` and the test carries on. Write the condition, then `||`, then the block's exact name. With a locator, the condition is about that element: `visible`, `not_visible`, `enabled`, `checked`, `text_contains:text`, `text_equals:text` or `value_equals:text`. Element conditions wait up to 1.5 seconds. With no condition and no `||`, it means `visible`, as `CALL_BLOCK_IF_VISIBLE` does. With no locator, the condition compares a variable: `{NAME}`, then `==`, `!=`, `contains`, `not_contains`, `>` or `<`, then a value.",
        "examples": [
            (step("CALL_BLOCK_IF", "css", ".status", "text_contains:Pending || Approve Order", description="Approve if still pending"), "Runs the `Approve Order` block only if the status shows `Pending`."),
            (step("CALL_BLOCK_IF", "label", "Send copy", "not_visible || Fill Copy Details", description="Fill the copy details if needed"), "Runs the block only if the checkbox is not showing."),
            (step("CALL_BLOCK_IF", input_data="{ORDER_STATUS} == Open || Close Order", description="Close the order if it is open"), "No locator: compares the variable stored earlier with `Open`."),
            (step("CALL_BLOCK_IF", input_data="{ITEM_COUNT} > 10 || Bulk Approve", description="Bulk approve large orders"), "Both sides are numbers, so they compare as numbers: `9` is less than `10`."),
        ],
        "tips": ["Text comparisons are exact, including upper and lower case. `>` and `<` need numbers on both sides, and fail the step otherwise rather than guess.",
                 "The variable must be stored by an earlier step or test case, or the test case is Skipped/Blocked before it starts. A value containing `||` or `==` is safe: the condition is read before the variable is filled in.",
                 "The block name cannot contain `||`, because the last `||` separates it."],
    },
    "REPEAT_BLOCK_UNTIL": {
        "detail": "Runs a reusable block again and again until the element in the locator is visible, or shows the text, up to a maximum count from 1 to 50. Write the block's exact name, `|`, the maximum, and optionally `|` and the text to wait for. The element is checked first, so a block whose result is already on screen does not run at all. After each run, it waits up to 1.5 seconds for the element. The step fails, with a screenshot, if the maximum is reached first.",
        "examples": [
            (step("REPEAT_BLOCK_UNTIL", "id", "jobStatus", "Refresh Grid | 10 | Completed", description="Refresh until the job completes"), "Runs `Refresh Grid` until the status shows `Completed`, at most 10 times."),
            (step("REPEAT_BLOCK_UNTIL", "role", "button|Download", "Next Page | 20", description="Page through until Download appears"), "No text: stops as soon as the Download button is visible."),
        ],
        "tips": ["In results, the checks are labelled such as `[check 2/10]` and the block's steps such as `[3/10]`. The check that is met says after how many runs, and the remaining runs are left out.",
                 "The maximum must be a number, because blocks are prepared before the run starts. The text can be a `{VARIABLE}`, but cannot contain `|`.",
                 "Each loop counts as its maximum number of runs toward the 5000 step limit."],
    },
}

TOKEN_GUIDE = {
    "RANDOM_INT": ("A random 6-digit number, new each time it is used.", "PO-{RANDOM_INT}", "PO-482913"),
    "UUID": ("A random unique id, new each time it is used.", "{UUID}", "3f2b8c1e-9a4d-4e7b-8f10-2c6d5a7e9b34"),
    "TODAY_DATE": ("Today's date on the portal server, as year-month-day. Add +N or -N days, such as {TODAY_DATE+7}.", "{TODAY_DATE+7}", "2026-11-14"),
    "TODAY_DMY": ("Today's date as day/month/year. Takes the same day offsets.", "{TODAY_DMY-30}", "08/10/2026"),
    "TODAY_MDY": ("Today's date as month/day/year. Takes the same day offsets.", "{TODAY_MDY}", "11/07/2026"),
    "TIMESTAMP": ("The current date and time on the portal server, with no separators. Handy for unique names.", "qa_user_{TIMESTAMP}", "qa_user_20261107143015"),
    "AUTH_USERNAME": ("The user name saved on the application.", "{AUTH_USERNAME}", "svc_qa"),
    "AUTH_PASSWORD": ("The password saved on the application. It is hidden as ******** in results and reports.", "{AUTH_PASSWORD}", "********"),
}

WORKED_LOGIN = [
    step("NAVIGATE", input_data="/login", description="Open the login page"),
    step("FILL", "label", "Username", "{AUTH_USERNAME}", description="Enter the user name"),
    step("FILL", "label", "Password", "{AUTH_PASSWORD}", description="Enter the password"),
    step("CLICK", "role", "button|Sign in", description="Sign in"),
    step("VERIFY_URL", input_data="/dashboard", description="Login reached the dashboard"),
]

WORKED_CREATE = [
    step("NAVIGATE", input_data="/orders/new", description="Open the new order page"),
    step("FILL", "label", "Reference", "PO-{RANDOM_INT}", description="Enter a unique reference"),
    step("SELECT_DROPDOWN", "label", "Priority", "High", description="Set the priority"),
    step("CHECK", "label", "Urgent", description="Flag it as urgent"),
    step("CLICK", "role", "button|Save", description="Save the order"),
    step("VERIFY_TEXT_CONTAINS", "css", ".alert-success", "saved", description="Success message is shown"),
    step("STORE_TEXT", "test_id", "order-id", store="ORDER_ID", description="Remember the order number"),
]

WORKED_VERIFY = [
    step("NAVIGATE", input_data="/orders/{ORDER_ID}", description="Open the order"),
    step("VERIFY_TEXT_CONTAINS", "css", "h1", "{ORDER_ID}", description="Heading shows the order number"),
    step("VERIFY_ELEMENT_VISIBLE", "text", "Urgent", description="Urgent flag was saved"),
]

WORKED_BLOCK_CALLER = [
    step("CALL_BLOCK", input_data="Login", description="Sign in"),
    step("NAVIGATE", input_data="/reports", description="Open reports"),
    step("VERIFY_TEXT_CONTAINS", "css", "h1", "Reports", description="Reports page opened"),
]

STATUS_GUIDE = [
    ("Pass", "Every step passed."),
    ("Fail", "A step failed. The test case stops at that step, and the result holds the error and a screenshot of the page. After a failed SOFT_VERIFY_ step it carries on instead, and every failure is listed."),
    ("Skipped/Blocked", "The test case could not start or the run stopped first, so it says nothing about the application. The reason is shown on the result."),
]

APP_OUTCOME_GUIDE = [
    ("Passing", "The latest run finished, at least one test case passed, and none failed or were skipped."),
    ("Failing", "At least one test case failed in the latest run."),
    ("Incomplete", "Nothing failed, but the run was aborted, a test case was skipped, or no test case ran."),
    ("Not run", "The application has no finished run yet."),
]

PERFORMANCE_GUIDE = [
    ("Opened as", "`Main` is the tab the test started in. `New tab` and `Pop-up` are windows the application opened, for example after a `CLICK`. They are timed even if the test never switches to them. `SPA view` is a screen change in an Angular or React application without a new page: a new path, a route such as `#/orders`, or a click that changes the query, such as a tab that sets `?tab=history`. It is also a dialog, drawer or panel that a click opens without changing the address. Those are named after their heading, or `In-page view update`."),
    ("Address", "For an `SPA view`, query values are replaced by `*`, as in `/orders?tab=*`, so tokens and typed values are never stored. Page loads and API calls leave the query out entirely."),
    ("Step", "The step that started the page load or the screen change, even if it finished during a later step."),
    ("Response", "Time until the server started answering, including any redirects. A high value points at the server."),
    ("First paint", "Time until the browser first drew something on the page."),
    ("Content ready", "Time until the HTML was read and the page's scripts had run. For an `SPA view`, time from the click or key that led to it until the browser first drew the new screen. This includes data the application loaded before changing the address, such as an Angular route resolver."),
    ("Full load", "Time until the page and its images, styles and scripts had loaded. For an `SPA view`, also counted from the click, until the screen's requests had finished and its content had stopped changing."),
    ("Size", "Data downloaded. It can read low when files came from the browser cache or from another site that hides their size."),
]

PERFORMANCE_RATINGS = [
    ("Fast", "Full load up to 3 s and response up to 0.8 s. For an AJAX/API call, up to 1 s."),
    ("Acceptable", "Full load up to 8 s and response up to 1.8 s. For an AJAX/API call, up to 3 s."),
    ("Slow", "Over those limits."),
    ("Failed", "The page or call returned an error status, or could not connect."),
    ("Not finished", "The page had not finished loading when the test moved on or ended."),
]

IMPORT_GUIDE = {
    "test_case_name": ("Required", "Rows with the same name become one test case. The name must not already exist in the application, unless you tick the option to update existing test cases."),
    "test_case_description": ("Optional", "The test case description. Fill it on the first row of the test case."),
    "is_reusable_block": ("Optional", "`yes` makes it a reusable block. `y`, `true` and `1` also work."),
    "depends_on": ("Optional", "The name of the test case it depends on, already in the application or in this file."),
    "step_order": ("Optional", "Whole number. Steps are sorted by it. Left blank, the row's position in the test case is used."),
    "action_keyword": ("Required", "A keyword from the reference on this page."),
    "locator_type": ("When used", "`id`, `id_ends_with`, `name`, `test_id`, `label`, `placeholder`, `role`, `text`, `title`, `row_action`, `css` or `xpath`."),
    "locator_value": ("When used", "Same as the Locator value field."),
    "input_data": ("When used", "Same as the Input data field."),
    "store_variable_name": ("When used", "Same as the Store as field."),
    "step_description": ("Optional", "Same as the step's Description field."),
    "teardown_block": ("Optional", "The name of a reusable block to run after the test case, pass or fail. Fill it on the first row. When updating existing test cases, a file without this column keeps each one's teardown, and a blank cell removes it."),
}

TROUBLESHOOTING = [
    ("No new window opened within 30000 ms", "`SWITCH_TO_NEW_WINDOW` found no window it had not already been in, or none matching the input data.", "Open the failure screenshot to check that the click really opened something, and that the browser did not block it. If you gave input data, check it against the window's address or title. Upper and lower case count."),
    ("No new window opened ... or was open before the click", "`CLICK_AND_SWITCH_WINDOW` clicked, but no window opened within the timeout. A window that was already open does not count, even one the test never moved to.", "Check the failure screenshot that the click reached the right element, and that the browser did not block a pop-up. If the window opens from an earlier step, use `SWITCH_TO_NEW_WINDOW` instead."),
    ("The page did not ask to print", "`VERIFY_PRINT_CALLED` saw no print request since the last check.", "Check that the step before it really prints. If the page loads a new document after printing, check straight after the print step. Each check uses up the prints counted so far."),
    ("Timeout exceeded while waiting for event \"filechooser\"", "`UPLOAD_FILE` was pointed at an element that is not a file input, and clicking it opened no file picker.", "Point the locator at the `<input type=file>`, or at the button that really opens the picker."),
    ("CALL_BLOCK_IF condition on an element must be ...", "The text before `||` is not one of the element conditions.", "Use `visible`, `not_visible`, `enabled`, `checked`, `text_contains:text`, `text_equals:text` or `value_equals:text`, then `||`, then the block name."),
    ("CALL_BLOCK_IF with no locator needs a variable, an operator ...", "With no locator the condition must compare a variable.", "Write it as `{NAME} == value || Block Name`. The operators are `==`, `!=`, `contains`, `not_contains`, `>` and `<`. `>=` and `===` are not offered."),
    ("> compares numbers, but got 'Open' and '3'", "`>` or `<` met a value that is not a number.", "Compare text with `==` or `contains`, or store a number, for example with `STORE_REGEX` and `(\\d+)`."),
    ("The element was still not showing 'X' after 10 iteration(s)", "`REPEAT_BLOCK_UNTIL` ran the block the maximum number of times and the element never showed the text.", "Open the screenshot to see what it showed instead. Raise the maximum, or check that the block really changes the screen. The text must match upper and lower case."),
    ("There is no earlier window to return to", "`CLOSE_WINDOW` ran in the only window the test has been in.", "Add `SWITCH_TO_NEW_WINDOW` before the steps for the new window, or remove the `CLOSE_WINDOW` step."),
    ("There is no window 2. 2 window(s) are open", "`SWITCH_TO_WINDOW` was given a number with no window, counting from 0 in the order the test first moved to them.", "Move to the new window first with `SWITCH_TO_NEW_WINDOW`, or use part of its address or title, which also finds a window the test has not been in."),
    ("SWITCH_TO_FRAME found a <div>, not an iframe", "The locator found an element that is not the frame itself.", "Point the locator at the `<iframe>`, for example `css` with `iframe#editor`."),
    ("Timeout exceeded after a page reload, inside a frame", "A new document was loaded, so the test left the frame and is searching the top-level page.", "Add `SWITCH_TO_FRAME` again after the step that reloads the page."),
    ("No browser pop-up containing 'X'", "`VERIFY_DIALOG_TEXT` saw no pop-up with that text. The message quotes the latest one.", "Check that an earlier step really causes the pop-up, and compare the text. Upper and lower case count."),
    ("No download matching 'X' within 30000 ms", "No file with that name finished downloading. The message lists any others that did.", "Check the name against the list, and that the click really starts a download. Each check uses up one file."),
    ("Reusable blocks expand this test case to more than 5000 steps", "`REPEAT_BLOCK` inside another repeated block multiplies quickly.", "Lower the counts, or split the work into several test cases."),
    ("strict mode violation ... resolved to 3 elements", "The locator matched more than one element, and a step must act on exactly one.", "Make it more specific: use a longer name such as `button|Save order`, or a `test_id` or `id`. To pick an element inside one area, use `css` such as `#footer button`. If they really are identical, add `@first`, `@last` or a number such as `@2` to the end of the value."),
    ("A locator for text with || or ending in @2 finds the wrong element", "Without a backslash, `||` separates frames and a final ` @2` picks the second match.", r"Write `\||` for a literal `||`, and ` \@2`, ` \@first` or ` \@last` for text that really ends that way."),
    ("row_action needs row text and an action on either side of |", "A `row_action` value is missing one side.", "Write it as row text, then `|`, then the button or link text, such as `PO-1042 | Edit`."),
    ("@ numbers count from 1", "A locator value ended in `@0`.", "Use `@1` for the first match, or `@first`."),
    ("Diagnostics during step: HTTP 500 on POST /api/orders", "While the step was failing, the application itself reported a problem: a JavaScript error, a console error or a failed server call. Up to five are listed under the failed step.", "This usually means the defect is in the application, not the test. Give the developers the step, the time and the listed calls. An `HTTP 401` or `403` points at the test account's permissions."),
    ("Run exceeded maximum allowed duration of 60 minutes and was terminated by the watchdog", "The run took longer than the server allows, so it stopped before its next step. A step stuck inside a frozen browser has its browser closed two minutes after the limit.", "Split a long suite into several runs, or look for a step that waits far longer than it should. An Admin can raise the limit with the `QA_MAX_RUN_DURATION_SEC` setting on the server."),
    ("Expected the number of matching elements to be > 0, but found 0", "`VERIFY_ELEMENT_COUNT` never saw the count it wanted within the timeout.", "Check the failure screenshot. For a virtual grid, scroll with `SCROLL_TO` first, because only the rows on screen exist."),
    ("CALL_BLOCK arguments are KEY=VALUE pairs separated by |", "A part after the block name is not a `KEY=VALUE` pair.", "Write it as `Login | USER=checker_01 | DEPT=Finance`. Keys are letters, digits and underscores, and a value cannot contain `|`."),
    ("Teardown step 5 (CLICK) failed", "The teardown block ran but one of its steps failed. The test case keeps its own result, and the next test case starts with a fresh browser.", "Open the teardown step's screenshot. Teardown steps often fail because the main steps stopped on a different page: start the block with a `NAVIGATE` to a known page."),
    ("Timeout 30000ms exceeded", "The element was not found or never became usable in time.", "Open the failure screenshot. Check the locator's spelling, that an earlier step reached the right page, and that the element is not hidden. If it is inside an iframe, use `||` in the locator or `SWITCH_TO_FRAME`. On `SELECT_DROPDOWN`, it can also mean no option has that text or value."),
    ("Locator expected to contain text ... (or Page URL expected ...)", "The page never showed what the `VERIFY_` step expected.", "Compare the expected and actual values in the error. Upper and lower case count."),
    ("Element is not a <select> element", "`SELECT_DROPDOWN` was used on a dropdown the application draws itself.", "Use two `CLICK` steps instead: one to open the list and one on the option."),
    ("Step 3 (FILL) uses {ORDER_ID}, which no earlier step or test case has populated", "The variable does not exist yet, so the test case is Skipped/Blocked before it starts.", "Store it earlier, and check the spelling and case. If another test case stores it, that one must run earlier in the same run. For `{AUTH_USERNAME}` and `{AUTH_PASSWORD}`, set the auth type and credentials on the application."),
    ("Depends on 'X', which did not run earlier in this queue", "The test case it depends on is not in the run, or comes later.", "Tick that test case and move it above this one."),
    ("Depends on 'X', which ended as Fail", "The test case it depends on did not pass, so this one was not attempted.", "Fix that test case first. This one will run once it passes."),
    ("This test case has no steps", "It was queued with an empty step list.", "Add steps, or remove it from the run."),
    ("Step 2 calls reusable block 'X', which does not exist in this application", "The block was renamed, deleted or had its Reusable block option cleared.", "Correct the name in the step that calls it, or restore the block."),
    ("File not found in test_data: x.pdf", "The file is not in the portal server's `test_data` folder.", "Ask an Admin to place it there, and check the spelling."),
    ("Pattern ... found no match", "The `STORE_REGEX` pattern did not match the text.", "Check the pattern against the actual text in the failure screenshot."),
    ("Element text stayed empty", "`STORE_TEXT` or `STORE_INPUT_VALUE` found the element, but it never had a value.", "The locator may point at the wrong element. For a field, use `STORE_INPUT_VALUE`, because `STORE_TEXT` does not read typed values."),
    ("Step 2: CLICK needs a locator value (when saving)", "A required field is blank, so the test case is not saved. Your input stays on the form.", "Fill in the field named in the message. Each keyword's required fields are listed in the reference on this page."),
]

LIMITS = [
    "The Locator Tool reads only the HTML you paste, so it can tell that a locator matches several elements but not that it matches only one on the whole page. It leaves out values that would need a backslash.",
    "An `SPA view` with no address change needs a click or a key to start it, and a dialog or at least 15 new elements to count. A smaller change, such as one line of text, has no row. A change to the query alone counts only after a click or key outside a text field, so search-as-you-type adds no rows.",
    "Only a click, Enter or Space starts the clock for an `SPA view`. A screen the application changes by itself, such as an automatic redirect after a timer, is timed from the address change.",
    "`PREPARE_DIALOG` answers browser pop-ups only, and pop-ups the application draws itself are ordinary page elements. Of the Windows dialogs, the print dialog and the file picker are handled. Any other Windows dialog, such as a certificate prompt, cannot be reached.",
    "`VERIFY_PRINT_CALLED` checks that printing was asked for, not what would be printed. A print from a frame on another site is not counted.",
    "`VERIFY_DOWNLOAD` checks a file's name and size, not its contents.",
    "The block name in `CALL_BLOCK_IF` cannot contain `||`, and the text in `REPEAT_BLOCK_UNTIL` cannot contain `|`. Repeat counts and loop maximums are fixed numbers, not variables.",
    "A `REPEAT_BLOCK_UNTIL` loop is prepared at its full maximum, so the step numbers in results jump over the runs that were not needed.",
    "Runs only start when someone presses Start run. There is no scheduler.",
    "A run stops after the server's maximum run duration, 60 minutes unless an Admin changes it. Teardown blocks do not run in an aborted or stopped run.",
    "Date tokens use the portal server's clock and calendar, not the browser's time zone. Offsets count calendar days, not working days.",
]



# --------------------------------------------------------------------------
# Locator Tool walkthrough and table recipes
# --------------------------------------------------------------------------

LOCATOR_TOOL_STEPS = [
    ("Copy the element from the browser", "Open the application in Edge or Chrome. Right-click the button, box or table row you need and choose `Inspect`. A panel opens with one line highlighted. Right-click that line and choose `Copy`, then `Copy outerHTML` (in some versions of Edge, `Copy element`). To see every element of a form or a grid at once, right-click the line of the whole `<form>` or `<table>` instead."),
    ("Paste it into the Locator Tool", "While editing a test case, press `Find Locator from HTML` at the top, or the `Find` button on the step you are filling in. The same tool is also on its own page under `Locator Tool` in the menu. Paste into `HTML from the browser`. For a table, you can type a stored variable such as `{ORDER_ID}` into `Row context or variable`, so the suggestion works for whichever row the test created."),
    ("Generate and use the best suggestion", "Press `Generate locators`. Each element is listed with its locators best first, the top one marked `Best`. Press `Use in Step N` on the one you want and it fills in that step's locator type and value. On the stand-alone page, press `Copy` instead and paste the value into your step."),
]

LOCATOR_TOOL_TIPS = [
    "A warning under a suggestion means it matched several elements in what you pasted. The tool adds a number such as `@2` for you, but a more specific locator is safer.",
    "Ids such as `mat-input-4` or `:r1:` are flagged as dynamic: Angular and React make them up again on every load, so they will not work tomorrow. Pick a different suggestion.",
    "The tool only sees what you pasted, not the whole page. If you pasted one button, it cannot know whether a second identical button exists elsewhere.",
    "What you paste is neither saved nor shown as a live page.",
]

# Clicking the right button in a busy grid.
ROW_ACTION_GUIDE = [
    (step("CLICK", "row_action", "PO-1042 | Edit", description="Edit order PO-1042"), "Finds the row that contains `PO-1042`, then the `Edit` button or link in that row only."),
    (step("CLICK", "row_action", "{ORDER_ID} | Approve", description="Approve the order just created"), "The row text can be a stored variable, so the test approves exactly the record it made."),
    (step("VERIFY_ELEMENT_VISIBLE", "row_action", "{ORDER_ID} | Approved", description="The row now shows Approved"), "When the right-hand side is not a button or link, it is found by its text in that row."),
    (step("CLICK", "row_action", "Smith | Edit @2", description="The second Edit in the Smith row"), "A row with two Edit links takes a number at the end, as any locator can."),
]


# --------------------------------------------------------------------------
# Cookbook of common testing scenarios
# --------------------------------------------------------------------------

# Each recipe: id, title, goal, keywords it teaches, test cases as (name, options, steps), notes.
COOKBOOK = [
    {
        "id": "recipe-login",
        "title": "Log in once with a reusable block",
        "goal": "Every test case needs to be signed in, but nobody wants to write the login five times.",
        "keywords": ["CALL_BLOCK", "CALL_BLOCK_IF_VISIBLE"],
        "cases": [
            ("Login", "Reusable block ticked", [
                step("NAVIGATE", input_data="/login", description="Open the login page"),
                step("FILL", "label", "Username", "{AUTH_USERNAME}", description="Enter the user name"),
                step("FILL", "label", "Password", "{AUTH_PASSWORD}", description="Enter the password"),
                step("CLICK", "role", "button|Sign in", description="Sign in"),
                step("VERIFY_ELEMENT_VISIBLE", "role", "button|Log out", description="Signed in"),
            ]),
            ("Search customers", "A normal test case, first in the run", [
                step("CALL_BLOCK", input_data="Login", description="Sign in"),
                step("NAVIGATE", input_data="/customers", description="Open customers"),
                step("FILL", "placeholder", "Search customers", "Smith", description="Search for Smith"),
                step("PRESS_KEY", "placeholder", "Search customers", "Enter", description="Run the search"),
                step("VERIFY_TEXT_CONTAINS", "css", ".results-table", "Smith", description="Smith is in the results"),
            ]),
            ("Open orders", "A normal test case, later in the run", [
                step("NAVIGATE", input_data="/orders", description="Open orders"),
                step("CALL_BLOCK_IF_VISIBLE", "role", "button|Sign in", "Login", description="Log in only if asked to"),
                step("NAVIGATE", input_data="/orders", description="Open orders again after any login"),
                step("VERIFY_TEXT_CONTAINS", "css", "h1", "Orders", description="Orders page opened"),
            ]),
        ],
        "notes": [
            "`CALL_BLOCK` always runs the block. Use it in a test case that starts from a fresh browser.",
            "`CALL_BLOCK_IF_VISIBLE` runs the block only when the Sign in button is showing. If the test case before it passed, the browser is still signed in and the login is left out. If that one failed, the browser was reset, the application shows its sign-in page, and the block runs. The same test case works either way.",
        ],
    },
    {
        "id": "recipe-chain",
        "title": "Create a record, capture its id, check it in a second test case",
        "goal": "Prove that a record created on one screen really appears, with the right details, on another.",
        "keywords": ["STORE_INPUT_VALUE", "STORE_REGEX", "row_action"],
        "cases": [
            ("Create Supplier", "Depends on: nothing", [
                step("CALL_BLOCK", input_data="Login", description="Sign in"),
                step("NAVIGATE", input_data="/suppliers/new", description="Open the new supplier form"),
                step("FILL", "label", "Supplier code", "SUP-{RANDOM_INT}", description="Enter a unique code"),
                step("STORE_INPUT_VALUE", "label", "Supplier code", store="SUPPLIER_CODE", description="Remember the code"),
                step("FILL", "label", "Supplier name", "QA Supplier {TIMESTAMP}", description="Enter a unique name"),
                step("CLICK", "role", "button|Save", description="Save the supplier"),
                step("STORE_REGEX", "css", ".alert-success", r"Request #(REQ-\d+)", "REQ_ID", "Pull out the request number"),
            ]),
            ("Check Supplier", "Depends on: Create Supplier", [
                step("NAVIGATE", input_data="/suppliers", description="Open the supplier list"),
                step("FILL", "placeholder", "Search suppliers", "{SUPPLIER_CODE}", description="Search for the new code"),
                step("PRESS_KEY", "placeholder", "Search suppliers", "Enter", description="Run the search"),
                step("VERIFY_ELEMENT_VISIBLE", "row_action", "{SUPPLIER_CODE} | {REQ_ID}", description="Row shows the request number"),
            ]),
        ],
        "notes": [
            "The code was typed from `{RANDOM_INT}`, so it is captured with `STORE_INPUT_VALUE` straight away. A second `{RANDOM_INT}` would be a different number.",
            "The banner says `Success! Request #REQ-88412 has been sent to manager`, so `STORE_REGEX` keeps only `REQ-88412`.",
            "The last step finds the row containing the new code and checks that the same row shows the request number.",
        ],
    },
    {
        "id": "recipe-popup",
        "title": "Handle an optional banner or an Are you sure? pop-up",
        "goal": "Some screens show a cookie banner or a session warning only sometimes, and delete buttons ask Are you sure?",
        "keywords": ["CLICK_IF_VISIBLE", "PREPARE_DIALOG", "VERIFY_DIALOG_TEXT"],
        "cases": [
            ("Cancel a delete", "A normal test case", [
                step("NAVIGATE", input_data="/orders", description="Open the order list"),
                step("CLICK_IF_VISIBLE", "role", "button|Accept cookies", description="Close the cookie banner if shown"),
                step("CLICK_IF_VISIBLE", "role", "button|Stay signed in", "5", description="Dismiss the session warning if shown"),
                step("PREPARE_DIALOG", input_data="dismiss", description="Answer Cancel to the next pop-up"),
                step("CLICK", "row_action", "PO-1042 | Delete", description="Try to delete PO-1042"),
                step("VERIFY_DIALOG_TEXT", input_data="Are you sure", description="Confirmation was asked"),
                step("VERIFY_ELEMENT_VISIBLE", "row_action", "PO-1042 | Delete", description="The order is still there"),
            ]),
        ],
        "notes": [
            "`CLICK_IF_VISIBLE` passes whether or not the banner appeared, and the result says which. Do not use it for anything that must be there.",
            "Browser pop-ups (the plain grey box with OK and Cancel) are answered OK automatically. `PREPARE_DIALOG` changes the answer for the next one only. A pop-up the application draws itself is an ordinary element: click its button.",
        ],
    },
    {
        "id": "recipe-windows",
        "title": "Work in a new tab or a lookup pop-up",
        "goal": "A Lookup button opens a small search window, or a View invoice link opens a new tab.",
        "keywords": ["CLICK_AND_SWITCH_WINDOW", "SWITCH_TO_NEW_WINDOW", "SWITCH_TO_WINDOW", "CLOSE_WINDOW"],
        "cases": [
            ("Pick a supplier from the lookup", "A normal test case", [
                step("CLICK_AND_SWITCH_WINDOW", "role", "button|Lookup supplier", description="Open the lookup pop-up"),
                step("FILL", "placeholder", "Search suppliers", "ACME", description="Search in the pop-up"),
                step("CLICK", "row_action", "ACME Ltd | Select", description="Choose ACME Ltd"),
                step("VERIFY_VALUE", "label", "Supplier", "ACME Ltd", description="Back on the form, supplier is filled"),
            ]),
            ("Check the invoice tab", "A normal test case", [
                step("CLICK", "role", "link|View invoice", description="Open the invoice tab"),
                step("SWITCH_TO_NEW_WINDOW", input_data="/invoice", description="Move to the invoice tab"),
                step("VERIFY_TEXT_CONTAINS", "css", "h1", "Invoice", description="Invoice is shown"),
                step("SWITCH_TO_WINDOW", input_data="main", description="Back to the order, tab stays open"),
                step("VERIFY_ELEMENT_VISIBLE", "role", "button|Save", description="Order form is still there"),
                step("SWITCH_TO_WINDOW", input_data="/invoice", description="Return to the invoice tab"),
                step("CLOSE_WINDOW", description="Close it and go back"),
            ]),
        ],
        "notes": [
            "When the lookup closes itself after Select, the test returns to the form on its own, so no `CLOSE_WINDOW` is needed.",
            "`CLICK_AND_SWITCH_WINDOW` does a click and a `SWITCH_TO_NEW_WINDOW` in one step. Use the two-step form when the window is opened by something other than one click.",
        ],
    },
    {
        "id": "recipe-wait",
        "title": "Wait for a background job to finish",
        "goal": "After pressing Start, the status shows Processing and only changes to Completed when the page is refreshed, some time later.",
        "keywords": ["REPEAT_BLOCK_UNTIL"],
        "cases": [
            ("Refresh Status", "Reusable block ticked", [
                step("CLICK", "role", "button|Refresh", description="Refresh the status"),
                step("WAIT_SECONDS", input_data="3", description="Give the job a moment"),
            ]),
            ("Run the export", "A normal test case", [
                step("NAVIGATE", input_data="/exports", description="Open exports"),
                step("CLICK", "role", "button|Start export", description="Start the export"),
                step("REPEAT_BLOCK_UNTIL", "css", ".job-status", "Refresh Status | 20 | Completed", description="Refresh until Completed"),
                step("VERIFY_TEXT_CONTAINS", "css", ".job-status", "Completed", description="Export completed"),
            ]),
        ],
        "notes": [
            "The status is checked first, then the block runs, then the status is checked again, up to 20 times. If it still does not say `Completed`, the step fails with a screenshot.",
            "A fixed wait inside the block is right here, because it paces the refreshes. Elsewhere, prefer `WAIT_FOR_ELEMENT`.",
        ],
    },
]

EXCEL_RECIPE = {
    "id": "recipe-excel",
    "title": "Write or change 50 steps in Excel",
    "goal": "Typing many steps into the form is slow. A spreadsheet lets you copy rows, fill down and review the whole suite at once.",
    "how": [
        "New suite: on the application, press `Import`, then download the `Excel (.xlsx)` template. Existing suite: press `Export Excel` instead, which gives the same layout filled with your current test cases.",
        "Each row is one step. Rows with the same `test_case_name` become one test case, in `step_order` order. The `action_keyword` and `locator_type` columns have dropdowns, and the `Keywords` sheet explains every keyword, so nothing has to be typed from memory.",
        "Save the file as `.xlsx`, press `Import` and choose it.",
        "If any name already exists in the application, tick `Update existing test cases with matching names`. Matching test cases have their details and steps replaced, and new names are added. Test cases you left out of the file are not touched or deleted.",
        "The import is all or nothing. If one row has a problem, nothing changes and the problems are listed by row number, so you can fix them and import again.",
    ],
    "rows": [
        {"test_case_name": "Login", "test_case_description": "Shared sign-in", "is_reusable_block": "yes", "step_order": "1",
         "action_keyword": "NAVIGATE", "input_data": "/login", "step_description": "Open the login page"},
        {"test_case_name": "Login", "step_order": "2", "action_keyword": "FILL", "locator_type": "label",
         "locator_value": "Username", "input_data": "{AUTH_USERNAME}", "step_description": "Enter the user name"},
        {"test_case_name": "Login", "step_order": "3", "action_keyword": "FILL", "locator_type": "label",
         "locator_value": "Password", "input_data": "{AUTH_PASSWORD}", "step_description": "Enter the password"},
        {"test_case_name": "Login", "step_order": "4", "action_keyword": "CLICK", "locator_type": "role",
         "locator_value": "button|Sign in", "step_description": "Sign in"},
        {"test_case_name": "Create Order", "test_case_description": "New urgent order", "step_order": "1",
         "action_keyword": "CALL_BLOCK", "input_data": "Login", "step_description": "Sign in"},
        {"test_case_name": "Create Order", "step_order": "2", "action_keyword": "FILL", "locator_type": "label",
         "locator_value": "Reference", "input_data": "PO-{RANDOM_INT}", "step_description": "Enter a unique reference"},
        {"test_case_name": "Create Order", "step_order": "3", "action_keyword": "STORE_INPUT_VALUE", "locator_type": "label",
         "locator_value": "Reference", "store_variable_name": "ORDER_REF", "step_description": "Remember the reference"},
    ],
}
