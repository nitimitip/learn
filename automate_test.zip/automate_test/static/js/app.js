/* QA Automation Portal UI behaviour. Plain JavaScript with no external calls. */
(function () {
  "use strict";

  function readJson(id) {
    return JSON.parse(document.getElementById(id).textContent);
  }

  function make(tag, attrs, text) {
    var el = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) { el.setAttribute(key, attrs[key]); });
    if (text !== undefined) { el.textContent = text; }
    return el;
  }

  /* ---- Confirm dialog for forms marked data-confirm ---- */
  function initConfirm() {
    var dialog = document.getElementById("confirm-dialog");
    var message = document.getElementById("confirm-message");
    var pending = null;
    document.addEventListener("submit", function (event) {
      var form = event.target;
      if (form.dataset.confirm && !form.dataset.confirmed) {
        event.preventDefault();
        pending = form;
        message.textContent = form.dataset.confirm;
        dialog.showModal();
      }
    });
    document.getElementById("confirm-cancel").addEventListener("click", function () {
      pending = null;
      dialog.close();
    });
    document.getElementById("confirm-ok").addEventListener("click", function () {
      dialog.close();
      if (pending) {
        pending.dataset.confirmed = "1";
        pending.requestSubmit();
      }
    });
  }

  /* ---- Generic dialog openers ---- */
  function initDialogs() {
    document.querySelectorAll("[data-open-dialog]").forEach(function (button) {
      button.addEventListener("click", function () {
        document.getElementById(button.dataset.openDialog).showModal();
      });
    });
    document.querySelectorAll("[data-close-dialog]").forEach(function (button) {
      button.addEventListener("click", function () { button.closest("dialog").close(); });
    });
  }

  /* ---- Drag to reorder, shared by the step list and the run queue ---- */
  function enableDragSort(container, onChange) {
    var dragged = null;
    container.addEventListener("dragstart", function (event) {
      // Only drag from the row itself, so text in inputs can still be selected.
      var active = document.activeElement;
      if (active && active.closest && active.closest("input, select, textarea") && container.contains(active)) {
        active.blur();
      }
      dragged = event.target.closest("[draggable]");
      if (dragged) {
        dragged.classList.add("dragging");
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", "");
      }
    });
    container.addEventListener("dragover", function (event) {
      var over = event.target.closest("[draggable]");
      if (!dragged || !over || over === dragged) { return; }
      event.preventDefault();
      container.querySelectorAll(".drop-target").forEach(function (el) { el.classList.remove("drop-target"); });
      over.classList.add("drop-target");
    });
    container.addEventListener("drop", function (event) {
      var over = event.target.closest("[draggable]");
      if (!dragged || !over || over === dragged) { return; }
      event.preventDefault();
      var items = Array.prototype.slice.call(container.children);
      if (items.indexOf(dragged) < items.indexOf(over)) {
        over.after(dragged);
      } else {
        over.before(dragged);
      }
      onChange();
    });
    container.addEventListener("dragend", function () {
      if (dragged) { dragged.classList.remove("dragging"); }
      dragged = null;
      container.querySelectorAll(".drop-target").forEach(function (el) { el.classList.remove("drop-target"); });
    });
  }

  /* ---- Step builder ---- */
  function initStepBuilder(form) {
    var keywords = readJson("keyword-data");
    var locatorTypes = readJson("locator-data");
    var blockNames = readJson("block-data");
    var list = document.getElementById("steps");
    var noSteps = document.getElementById("no-steps");
    var counter = 0;

    function keywordSelect(value) {
      var select = make("select", { "data-field": "action_keyword" });
      var groups = {};
      Object.keys(keywords).forEach(function (name) {
        var category = keywords[name].category;
        if (!groups[category]) {
          groups[category] = make("optgroup", { label: category });
          select.appendChild(groups[category]);
        }
        groups[category].appendChild(make("option", { value: name }, name));
      });
      if (value && !keywords[value]) {
        // Keep a rejected value visible so the server's error makes sense.
        select.appendChild(make("option", { value: value }, value));
      }
      select.value = value || "CLICK";
      return select;
    }

    function field(cssClass, labelText, control) {
      var label = make("label", { "class": cssClass }, labelText);
      label.appendChild(control);
      return label;
    }

    var blockKeywords = ["CALL_BLOCK", "CALL_BLOCK_IF_VISIBLE", "CALL_BLOCK_IF", "REPEAT_BLOCK", "REPEAT_BLOCK_UNTIL"];

    function applyKeyword(row) {
      var spec = keywords[row.querySelector('[data-field="action_keyword"]').value];
      if (!spec) { return; }
      var locatorUsed = spec.locator !== "none";
      row.querySelector(".f-loc-type").classList.toggle("is-off", !locatorUsed);
      row.querySelector(".f-loc-value").classList.toggle("is-off", !locatorUsed);
      row.querySelector(".f-input").classList.toggle("is-off", spec.input === "none");
      row.querySelector(".f-store").classList.toggle("is-off", !spec.store);
      var input = row.querySelector('[data-field="input_data"]');
      input.placeholder = spec.input_hint || "";
      var keywordName = row.querySelector('[data-field="action_keyword"]').value;
      if (blockKeywords.indexOf(keywordName) !== -1) {
        input.setAttribute("list", "block-names");
      } else {
        input.removeAttribute("list");
      }
      row.querySelector('[data-field="locator_value"]').placeholder =
        spec.locator === "optional" ? "Optional" : "";
      row.querySelector('[data-field="store_variable_name"]').placeholder =
        spec.store === "optional" ? "Optional" : "ORDER_ID";
      row.querySelector(".step-help").textContent = spec.help;
    }

    function renumber() {
      Array.prototype.forEach.call(list.children, function (row, index) {
        row.querySelector(".step-number").textContent = index + 1;
      });
      noSteps.hidden = list.children.length > 0;
    }

    function addStep(step, afterRow) {
      counter += 1;
      step = step || {};
      var row = make("div", { "class": "step", "draggable": "true", "data-step": counter });

      var handle = make("div", { "class": "step-handle", "title": "Drag to reorder" });
      handle.appendChild(make("span", { "class": "step-number" }));
      handle.appendChild(make("span", { "aria-hidden": "true" }, "::"));
      row.appendChild(handle);

      var fields = make("div", { "class": "step-fields" });
      var keyword = keywordSelect(step.action_keyword);
      fields.appendChild(field("f-keyword", "Keyword", keyword));

      var locatorType = make("select", { "data-field": "locator_type" });
      locatorTypes.forEach(function (type) {
        locatorType.appendChild(make("option", { value: type }, type));
      });
      locatorType.value = step.locator_type || "css";
      fields.appendChild(field("f-loc-type", "Locator type", locatorType));

      var locatorValue = make("input", { "data-field": "locator_value" });
      locatorValue.value = step.locator_value || "";
      fields.appendChild(field("f-loc-value", "Locator value", locatorValue));

      var input = make("input", { "data-field": "input_data" });
      input.value = step.input_data || "";
      fields.appendChild(field("f-input", "Input data", input));

      var store = make("input", { "data-field": "store_variable_name", "placeholder": "ORDER_ID" });
      store.value = step.store_variable_name || "";
      fields.appendChild(field("f-store", "Store as", store));

      var description = make("input", { "data-field": "description" });
      description.value = step.description || "";
      fields.appendChild(field("f-desc", "Description", description));

      fields.appendChild(make("div", { "class": "step-help" }));
      row.appendChild(fields);

      var buttons = make("div", { "class": "step-buttons" });
      [["up", "Up", "Move up"], ["down", "Down", "Move down"], ["copy", "Copy", "Duplicate step"], ["remove", "Del", "Remove step"], ["locate", "Find", "Find a locator from HTML for this step"]]
        .forEach(function (b) {
          buttons.appendChild(make("button", {
            type: "button", "class": "btn btn-icon", "data-action": b[0], title: b[2], "aria-label": b[2],
          }, b[1]));
        });
      row.appendChild(buttons);

      keyword.addEventListener("change", function () { applyKeyword(row); });
      if (afterRow) { afterRow.after(row); } else { list.appendChild(row); }
      applyKeyword(row);
      renumber();
      return row;
    }

    function readRow(row) {
      var data = {};
      row.querySelectorAll("[data-field]").forEach(function (el) {
        data[el.dataset.field] = el.value;
      });
      return data;
    }

    var locatorDialog = initLocatorDialog(list, keywords, addStep, applyKeyword);

    list.addEventListener("click", function (event) {
      var button = event.target.closest("[data-action]");
      if (!button) { return; }
      var row = button.closest(".step");
      var action = button.dataset.action;
      if (action === "locate") {
        locatorDialog.open(row);
        return;
      }
      if (action === "up" && row.previousElementSibling) {
        row.previousElementSibling.before(row);
      } else if (action === "down" && row.nextElementSibling) {
        row.nextElementSibling.after(row);
      } else if (action === "copy") {
        addStep(readRow(row), row);
      } else if (action === "remove") {
        row.remove();
      }
      renumber();
    });

    // Rows are draggable from the handle only, so inputs keep normal selection.
    list.addEventListener("mousedown", function (event) {
      var row = event.target.closest(".step");
      if (row) { row.draggable = Boolean(event.target.closest(".step-handle")); }
    });
    enableDragSort(list, renumber);

    var dataList = make("datalist", { id: "block-names" });
    blockNames.forEach(function (name) { dataList.appendChild(make("option", { value: name })); });
    form.appendChild(dataList);

    document.getElementById("add-step").addEventListener("click", function () {
      var row = addStep({});
      row.querySelector("select").focus();
      row.scrollIntoView({ block: "nearest" });
    });

    readJson("step-data").forEach(function (step) { addStep(step); });
    renumber();

    form.addEventListener("submit", function () {
      var steps = Array.prototype.map.call(list.children, readRow);
      document.getElementById("steps-json").value = JSON.stringify(steps);
    });
  }

  /* ---- Locator tool ---- */

  // navigator.clipboard only exists on HTTPS or localhost, and the portal is often served
  // over plain HTTP on the intranet. A dialog makes everything outside it inert, so the
  // fallback's text area has to sit inside the open dialog to take the selection.
  function copyText(text, near) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).catch(function () { return legacyCopy(text, near); });
    }
    return legacyCopy(text, near);
  }

  function legacyCopy(text, near) {
    var holder = make("textarea", { "class": "lt-copy-buffer", "aria-hidden": "true", readonly: "readonly" });
    holder.value = text;
    (near.closest("dialog") || document.body).appendChild(holder);
    holder.select();
    var copied = false;
    try { copied = document.execCommand("copy"); } catch (error) { copied = false; }
    holder.remove();
    near.focus();
    return copied ? Promise.resolve() : Promise.reject(new Error("copy refused"));
  }

  function flashButton(button, text, cssClass) {
    var original = button.textContent;
    button.textContent = text;
    button.classList.add(cssClass);
    setTimeout(function () {
      button.textContent = original;
      button.classList.remove(cssClass);
    }, 1200);
  }

  function renderCandidate(candidate, element, tool) {
    var row = make("tr", {});
    var typeCell = make("td", { "class": "lt-type" });
    typeCell.appendChild(make("span", { "class": "loc-type" }, candidate.type));
    if (candidate.best) { typeCell.appendChild(make("span", { "class": "pill pill-pass lt-best" }, "Best")); }
    row.appendChild(typeCell);

    var valueCell = make("td", { "class": "lt-value" });
    valueCell.appendChild(make("code", {}, candidate.value));
    if (candidate.note) { valueCell.appendChild(make("div", { "class": "muted small" }, candidate.note)); }
    candidate.warnings.forEach(function (warning) {
      valueCell.appendChild(make("div", { "class": "lt-warning small" }, warning));
    });
    row.appendChild(valueCell);

    var actions = make("td", { "class": "lt-actions" });
    var copy = make("button", {
      type: "button", "class": "btn btn-icon", "data-lt-copy": "1",
      "aria-label": "Copy " + candidate.type + " locator " + candidate.value,
    }, "Copy");
    copy.addEventListener("click", function () {
      copyText(candidate.value, copy).then(
        function () { flashButton(copy, "Copied", "lt-done"); },
        function () { flashButton(copy, "Press Ctrl+C", "lt-failed"); }
      );
    });
    actions.appendChild(copy);
    if (tool.onApply) {
      var apply = make("button", { type: "button", "class": "btn btn-icon btn-apply", "data-lt-apply": "1" }, tool.applyLabel());
      apply.addEventListener("click", function () { tool.onApply(candidate, element); });
      actions.appendChild(apply);
    }
    row.appendChild(actions);
    return row;
  }

  function renderElement(element, tool) {
    var box = make("article", { "class": "lt-element" });
    var head = make("div", { "class": "lt-element-head" });
    head.appendChild(make("strong", {}, element.title));
    var keyword = make("span", { "class": "kw-badge", title: "Suggested keyword" }, element.keyword);
    head.appendChild(keyword);
    if (element.needs_input) { head.appendChild(make("span", { "class": "muted small" }, "needs input data")); }
    box.appendChild(head);
    box.appendChild(make("code", { "class": "lt-opening" }, element.opening_tag));
    element.warnings.forEach(function (warning) {
      box.appendChild(make("div", { "class": "lt-warning small" }, warning));
    });
    var wrap = make("div", { "class": "table-wrap" });
    var table = make("table", { "class": "data lt-table" });
    var body = make("tbody", {});
    element.candidates.forEach(function (candidate) { body.appendChild(renderCandidate(candidate, element, tool)); });
    table.appendChild(body);
    wrap.appendChild(table);
    box.appendChild(wrap);
    return box;
  }

  // Reads the answer whatever it is: an expired session redirects to the login page, which is not JSON.
  function readLocatorAnswer(response) {
    return response.text().then(function (text) {
      var data = null;
      try { data = JSON.parse(text); } catch (error) { data = null; }
      if (data && data.error) { throw new Error(data.error); }
      if (!response.ok || !data || response.redirected) {
        throw new Error("Your session may have ended. Reload the page and try again.");
      }
      return data;
    });
  }

  function initLocatorTool(root, options) {
    options = options || {};
    var html = root.querySelector("[data-lt-html]");
    var hint = root.querySelector("[data-lt-hint]");
    var status = root.querySelector("[data-lt-status]");
    var results = root.querySelector("[data-lt-results]");
    var generate = root.querySelector("[data-lt-generate]");
    var tool = { onApply: options.onApply, applyLabel: options.applyLabel };

    function setStatus(text, isError) {
      status.textContent = text;
      status.classList.toggle("lt-error", Boolean(isError));
    }

    generate.addEventListener("click", function () {
      generate.disabled = true;
      setStatus("Reading the HTML...");
      results.textContent = "";
      fetch(root.dataset.url, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json", Accept: "application/json", "X-CSRF-Token": root.dataset.csrf },
        body: JSON.stringify({ html: html.value, hint: hint.value }),
      })
        .then(readLocatorAnswer)
        .then(function (data) {
          data.elements.forEach(function (element) { results.appendChild(renderElement(element, tool)); });
          var count = data.elements.length + (data.elements.length === 1 ? " element" : " elements");
          setStatus(data.truncated ? "Showing the first " + count + " of " + data.total + ". Paste a smaller part to see the rest." : "Found " + count + ".");
        })
        .catch(function (error) { setStatus(error.message || "The request failed. Try again.", true); })
        .finally(function () { generate.disabled = false; });
    });

    root.querySelector("[data-lt-clear]").addEventListener("click", function () {
      html.value = "";
      hint.value = "";
      results.textContent = "";
      setStatus("");
      html.focus();
    });

    return {
      refreshApplyLabels: function () {
        root.querySelectorAll("[data-lt-apply]").forEach(function (button) { button.textContent = tool.applyLabel(); });
      },
    };
  }

  function initLocatorDialog(list, keywords, addStep, applyKeyword) {
    var dialog = document.getElementById("locator-dialog");
    var picker = document.getElementById("locator-step");
    var setKeyword = document.getElementById("locator-set-keyword");
    var NEW_STEP = "new";
    var lastRow = null;

    function steps() { return Array.prototype.slice.call(list.children); }

    function fillPicker(row) {
      picker.textContent = "";
      steps().forEach(function (item, index) {
        var keyword = item.querySelector('[data-field="action_keyword"]').value;
        var description = item.querySelector('[data-field="description"]').value;
        picker.appendChild(make("option", { value: item.dataset.step },
          "Step " + (index + 1) + ": " + keyword + (description ? " - " + description : "")));
      });
      picker.appendChild(make("option", { value: NEW_STEP }, "A new step at the end"));
      picker.value = row ? row.dataset.step : NEW_STEP;
    }

    function chosenNumber() {
      var index = steps().findIndex(function (item) { return item.dataset.step === picker.value; });
      return index === -1 ? null : index + 1;
    }

    function applyLabel() {
      var number = chosenNumber();
      return number ? "Use in Step " + number : "Use in new step";
    }

    function apply(candidate, element) {
      var row = steps().find(function (item) { return item.dataset.step === picker.value; }) || addStep({});
      var keyword = row.querySelector('[data-field="action_keyword"]');
      // A keyword with no locator hides these fields, so the values would silently be dropped on save.
      var hasLocator = keywords[keyword.value] && keywords[keyword.value].locator !== "none";
      if (setKeyword.checked || !hasLocator) { keyword.value = element.keyword; }
      row.querySelector('[data-field="locator_type"]').value = candidate.type;
      row.querySelector('[data-field="locator_value"]').value = candidate.value;
      applyKeyword(row);
      lastRow = row;
      dialog.close();
      row.scrollIntoView({ block: "center" });
      row.classList.add("step-applied");
      setTimeout(function () { row.classList.remove("step-applied"); }, 1600);
      row.querySelector('[data-field="locator_value"]').focus();
    }

    var tool = initLocatorTool(dialog.querySelector("[data-locator-tool]"), { onApply: apply, applyLabel: applyLabel });
    picker.addEventListener("change", tool.refreshApplyLabels);

    function open(row) {
      fillPicker(row);
      tool.refreshApplyLabels();
      dialog.showModal();
      dialog.querySelector("[data-lt-html]").focus();
    }

    // The toolbar button works on the step last touched, then the last step in the list.
    list.addEventListener("focusin", function (event) {
      var row = event.target.closest(".step");
      if (row) { lastRow = row; }
    });
    document.getElementById("find-locator").addEventListener("click", function () {
      var active = lastRow && lastRow.isConnected ? lastRow : list.lastElementChild;
      open(active);
    });
    return { open: open };
  }

  /* ---- Run queue ---- */
  function initRunSetup() {
    var queue = document.getElementById("queue");
    var field = document.getElementById("queue-field");
    var startButton = document.getElementById("start-run");
    var emptyNote = document.getElementById("queue-empty");
    var boxes = document.querySelectorAll("#available input[type=checkbox]");

    function sync() {
      var ids = [];
      Array.prototype.forEach.call(queue.children, function (item, index) {
        ids.push(item.dataset.caseId);
        item.querySelector(".q-num").textContent = (index + 1) + ".";
      });
      field.value = ids.join(",");
      startButton.disabled = ids.length === 0;
      emptyNote.hidden = ids.length > 0;
    }

    function addToQueue(box) {
      var item = make("li", { draggable: "true", "data-case-id": box.dataset.caseId });
      item.appendChild(make("span", { "class": "q-num" }));
      item.appendChild(make("span", { "class": "q-name" }, box.dataset.caseName));
      [["up", "Up"], ["down", "Down"]].forEach(function (b) {
        item.appendChild(make("button", {
          type: "button", "class": "btn btn-icon", "data-move": b[0],
          "aria-label": "Move " + box.dataset.caseName + " " + b[0],
        }, b[1]));
      });
      queue.appendChild(item);
    }

    boxes.forEach(function (box) {
      box.addEventListener("change", function () {
        if (box.checked) {
          addToQueue(box);
        } else {
          var item = queue.querySelector('[data-case-id="' + box.dataset.caseId + '"]');
          if (item) { item.remove(); }
        }
        sync();
      });
    });

    document.getElementById("add-all").addEventListener("click", function () {
      boxes.forEach(function (box) {
        if (!box.checked) {
          box.checked = true;
          addToQueue(box);
        }
      });
      sync();
    });

    queue.addEventListener("click", function (event) {
      var button = event.target.closest("[data-move]");
      if (!button) { return; }
      var item = button.closest("li");
      if (button.dataset.move === "up" && item.previousElementSibling) {
        item.previousElementSibling.before(item);
      } else if (button.dataset.move === "down" && item.nextElementSibling) {
        item.nextElementSibling.after(item);
      }
      sync();
    });
    enableDragSort(queue, sync);
    sync();
  }

  /* ---- Live run polling ---- */
  function initRunDetail(body) {
    if (body.dataset.active !== "true") { return; }
    var failures = 0;

    function openIds() {
      var open = {};
      body.querySelectorAll("details[id]").forEach(function (el) { open[el.id] = el.open; });
      return open;
    }

    function poll() {
      fetch(body.dataset.statusUrl, { credentials: "same-origin", headers: { Accept: "application/json" } })
        .then(function (response) {
          if (!response.ok) { throw new Error("HTTP " + response.status); }
          return response.json();
        })
        .then(function (data) {
          failures = 0;
          var previous = openIds();
          // The fragment is rendered and escaped by the server's template.
          body.innerHTML = data.html;
          // Keep what the reader expanded, but let newly failed cases open themselves.
          body.querySelectorAll("details[id]").forEach(function (el) {
            if (previous[el.id] && !el.open) { el.open = true; }
          });
          if (data.active) {
            setTimeout(poll, 1500);
          } else {
            var abortForm = document.getElementById("abort-form");
            if (abortForm) { abortForm.remove(); }
            var reports = document.getElementById("report-actions");
            if (reports) { reports.hidden = false; }
          }
        })
        .catch(function () {
          failures += 1;
          setTimeout(poll, Math.min(1500 * (failures + 1), 15000));
        });
    }
    setTimeout(poll, 1000);
  }

  /* ---- Admin browser detection ---- */
  function initDetect(button) {
    button.addEventListener("click", function () {
      button.disabled = true;
      fetch(button.dataset.url, { credentials: "same-origin" })
        .then(function (response) { return response.json(); })
        .then(function (data) {
          Object.keys(data).forEach(function (key) {
            var info = data[key];
            var item = document.querySelector('.detect-item[data-browser="' + key + '"]');
            var state = item.querySelector('[data-role="state"]');
            state.textContent = info.detected ? "Detected" : "Not found";
            state.className = "pill " + (info.detected ? "pill-pass" : "pill-fail");
            item.querySelector('[data-role="path"]').textContent = info.path || "No executable found";
            var warning = item.querySelector('[data-role="warning"]');
            warning.hidden = info.custom_path_valid;
            warning.textContent = "The saved custom path does not exist on this server: " + info.custom_path;
          });
        })
        .finally(function () { button.disabled = false; });
    });
  }

  /* ---- Application form: show only the relevant credential fields ---- */
  function initApplicationForm(form) {
    var authType = form.querySelector("#auth-type");
    function sync() {
      form.querySelectorAll("[data-auth]").forEach(function (el) {
        el.hidden = el.dataset.auth.split(" ").indexOf(authType.value) === -1;
      });
    }
    authType.addEventListener("change", sync);
    sync();
  }

  document.addEventListener("DOMContentLoaded", function () {
    initConfirm();
    initDialogs();
    var stepForm = document.querySelector('[data-page="step-builder"]');
    if (stepForm) { initStepBuilder(stepForm); }
    var standaloneTool = document.querySelector("[data-locator-tool]");
    if (standaloneTool && !standaloneTool.closest("dialog")) { initLocatorTool(standaloneTool); }
    if (document.querySelector('[data-page="run-setup"]')) { initRunSetup(); }
    var runBody = document.querySelector('[data-page="run-detail"]');
    if (runBody) { initRunDetail(runBody); }
    var detect = document.getElementById("detect-browsers");
    if (detect) { initDetect(detect); }
    var appForm = document.querySelector('[data-page="application-form"]');
    if (appForm) { initApplicationForm(appForm); }
  });
})();
