"""What the Excel and PDF run reports share, plus the formatters and donut chart
the portal pages use. The two file builders are report_excel.py and report_pdf.py.
"""
import base64
import io
import json
import logging
import math
import re
from datetime import timezone
from types import SimpleNamespace

from markupsafe import Markup
from PIL import Image

import config
from models import (
    OPENED_POPUP, OPENED_SPA, OPENED_TAB, RATE_FAILED, RATE_FAST, RATE_OK, RATE_SLOW, RATE_UNFINISHED,
    RUN_COMPLETED, STEP_FAIL, TC_PASS, utcnow,
)

log = logging.getLogger(__name__)

COLOR_PASS = "#2a9d6f"
COLOR_FAIL = "#c0392f"
COLOR_SKIP = "#bd7f12"

BROWSER_LABELS = {"msedge": "Microsoft Edge", "chrome": "Google Chrome"}


def format_dt(value):
    """Stored times are naive UTC; show them in the server's local time."""
    if value is None:
        return "-"
    return value.replace(tzinfo=timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S")


def format_duration(seconds):
    if seconds is None:
        return "-"
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes, rest = divmod(int(seconds), 60)
    return f"{minutes}m {rest:02d}s"


def format_ms(value):
    if value is None:
        return "-"
    return f"{value:.0f} ms" if value < 1000 else f"{value / 1000:.2f} s"


def format_bytes(value):
    if value is None:
        return "-"
    if value < 1024:
        return f"{value} B"
    if value < 1024 * 1024:
        return f"{value / 1024:.0f} KB"
    return f"{value / (1024 * 1024):.1f} MB"


def performance_summary(run):
    """Headline figures for the performance section of a run."""
    pages = run.page_metrics
    # A screen change is far smaller than a page load, so averaging them hides slow pages.
    loads = [page.load_ms for page in pages if page.load_ms is not None and page.opened_as != OPENED_SPA]
    return {
        "pages": len(pages),
        "average_load": sum(loads) / len(loads) if loads else None,
        "slowest_load": max(loads) if loads else None,
        "new_tabs": sum(page.opened_as == OPENED_TAB for page in pages),
        "popups": sum(page.opened_as == OPENED_POPUP for page in pages),
        "needs_attention": sum(
            row.rating in (RATE_SLOW, RATE_FAILED, RATE_UNFINISHED)
            for row in [*pages, *run.api_metrics]
        ),
    }


def donut_svg(passed, failed, skipped, size=148):
    """Pass/fail/skip ring with the pass rate in the middle. Used by the dashboard
    and the reports. Text uses currentColor so it follows the page's theme."""
    total = passed + failed + skipped
    center, radius, ring = 60, 50, 13
    circumference = 2 * math.pi * radius
    segments = [(passed, COLOR_PASS, "Passed"), (failed, COLOR_FAIL, "Failed"),
                (skipped, COLOR_SKIP, "Skipped/Blocked")]
    present = [s for s in segments if s[0] > 0]
    gap = 2 if len(present) > 1 else 0
    arcs = []
    offset = 0.0
    for count, color, label in present:
        length = count / total * circumference
        arcs.append(
            f'<circle cx="{center}" cy="{center}" r="{radius}" fill="none" stroke="{color}" '
            f'stroke-width="{ring}" stroke-dasharray="{max(length - gap, 0.5):.2f} {circumference:.2f}" '
            f'stroke-dashoffset="{-offset:.2f}" transform="rotate(-90 {center} {center})">'
            f"<title>{label}: {count} of {total}</title></circle>"
        )
        offset += length
    if not total:
        arcs.append(
            f'<circle cx="{center}" cy="{center}" r="{radius}" fill="none" stroke="currentColor" '
            f'stroke-opacity="0.15" stroke-width="{ring}"/>'
        )
    headline = f"{passed / total * 100:.0f}%" if total else "-"
    return Markup(
        f'<svg viewBox="0 0 120 120" width="{size}" height="{size}" role="img" '
        f'aria-label="Passed {passed}, failed {failed}, skipped {skipped}">'
        + "".join(arcs)
        + f'<text x="60" y="60" text-anchor="middle" font-size="22" font-weight="600" fill="currentColor">{headline}</text>'
        + '<text x="60" y="76" text-anchor="middle" font-size="9.5" fill="currentColor" opacity="0.7">pass rate</text>'
        + "</svg>"
    )


# Report colours: the portal's petrol accent and its pass/fail/skip status tones.
BRAND = "0F5E6E"
BRAND_DARK = "0B4A57"
BRAND_SOFT = "E5F3F6"
INK = "171D1F"
MUTED = "5F6B6E"
LINE = "D2D7D2"
BAND = "F8F9F7"
TONES = {
    "pass": {"solid": COLOR_PASS[1:].upper(), "fill": "E9F5EF", "ink": "14694A"},
    "fail": {"solid": COLOR_FAIL[1:].upper(), "fill": "FBEEEC", "ink": "A32F28"},
    "skip": {"solid": COLOR_SKIP[1:].upper(), "fill": "FBF3E1", "ink": "855807"},
    "none": {"solid": "8C979A", "fill": "EEF0EE", "ink": "4F5A5D"},
}
_TONE_OF = {
    "Pass": "pass", "Passing": "pass", "Completed": "pass", RATE_FAST: "pass",
    "Fail": "fail", "Failing": "fail", RATE_SLOW: "fail", RATE_FAILED: "fail",
    "Skipped/Blocked": "skip", "Incomplete": "skip", "Aborted": "skip",
    RATE_OK: "skip", RATE_UNFINISHED: "skip",
}
PERFORMANCE_NOTE = (
    "Measured once by this test run on the portal server, so treat a single slow reading as a "
    "prompt to check, not a benchmark. Pages already in the browser cache load faster. Ratings "
    "do not affect pass or fail."
)
_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def tone_of(status):
    """Colour family for a status or performance rating."""
    return TONES[_TONE_OF.get(status, "none")]


def outcome_of(run):
    """One word for an application's state, from its latest finished run."""
    if run is None:
        return "Not run"
    if run.failed_tests:
        return "Failing"
    if run.status == RUN_COMPLETED and run.passed_tests and not run.skipped_tests:
        return "Passing"
    return "Incomplete"


def verdict_sentence(run):
    """The result in one sentence, for the top of a report."""
    total = run.total_tests
    if run.failed_tests:
        text = f"{run.failed_tests} of {total} test case(s) failed."
        if run.skipped_tests:
            text += f" {run.skipped_tests} more did not run."
        return text
    if outcome_of(run) == "Passing":
        return f"All {total} test case(s) passed."
    return f"{run.passed_tests} of {total} test case(s) passed; the rest did not finish."


def pass_rate(run):
    """Share of test cases that passed, 0 to 1, or None when there are none."""
    return run.passed_tests / run.total_tests if run.total_tests else None


def clean_text(value):
    """Page text can hold control characters that break both file formats."""
    return "" if value is None else _CONTROL_CHARS.sub("", str(value))


def report_filename(run, extension):
    name = re.sub(r"[^A-Za-z0-9]+", "_", run.application.name).strip("_")[:60] or "Application"
    return f"{name}_Run_{run.number}_Report.{extension}"


def run_details(run):
    """Label and value pairs describing a run."""
    return [
        ("Application", run.application.name),
        ("Base URL", run.application.base_url),
        ("Technology", run.application.tech_stack),
        ("Run number", f"#{run.number}"),
        ("Run status", run.status),
        ("Browser used", BROWSER_LABELS.get(run.browser_used, run.browser_used)),
        ("Mode", "Headless" if run.headless else "Visible (Headed)"),
        ("Triggered by", run.trigger_user.display_name),
        ("Started", format_dt(run.started_at)),
        ("Completed", format_dt(run.completed_at)),
        ("Duration", format_duration(run.duration_sec)),
        ("Report generated", format_dt(utcnow())),
    ]


def run_issues(run):
    """Everything that did not pass: one entry per failed step with its screenshot,
    and one for a test case that has no failed step. Soft checks can fail several
    steps in one test case, and each needs its own evidence."""
    issues = []
    for case in run.case_results:
        if case.status == TC_PASS:
            continue
        failed = [s for s in case.step_results if s.status == STEP_FAIL]
        for step in failed or [None]:
            # With several, the test case's message lists them all, so each keeps its own.
            details = [case.error_message] if len(failed) < 2 else [
                f"Step {step.step_order} ({step.action_keyword}) failed:"
            ]
            details.append(step.error_details if step else None)
            unique = [text for text in dict.fromkeys(details) if text]
            issues.append(SimpleNamespace(
                order=case.execution_order, case=case.test_case_name, status=case.status,
                step=step, problem="\n".join(unique) or "No reason was recorded.",
            ))
    return issues


def evidence_steps(run):
    """Passing steps that carry a screenshot taken as evidence (CAPTURE_SCREENSHOT), in
    run order. Failure screenshots are in run_issues instead."""
    return [
        SimpleNamespace(order=case.execution_order, case=case.test_case_name, step=step)
        for case in run.case_results for step in case.step_results
        if step.status != STEP_FAIL and step.has_screenshot
    ]


def screenshot_image(step, longest_side=1600):
    """A step's screenshot made small enough to embed: (JPEG bytes, width, height).
    None when there is no screenshot or it cannot be read."""
    if step is None or not step.screenshot_base64:
        return None
    try:
        with Image.open(io.BytesIO(base64.b64decode(step.screenshot_base64))) as source:
            picture = source.convert("RGB")
        picture.thumbnail((longest_side, longest_side))
        output = io.BytesIO()
        picture.save(output, "JPEG", quality=82, optimize=True)
    except Exception as exc:
        log.warning("Screenshot of step result %s could not be read: %s", step.id, exc)
        return None
    return output.getvalue(), picture.width, picture.height


def fit_within(width, height, max_width, max_height):
    """Scale a picture to a box, keeping its shape. Never enlarges it."""
    scale = min(max_width / width, max_height / height, 1)
    return width * scale, height * scale


def parse_variables(run):
    try:
        return json.loads(run.runtime_variables_json or "{}")
    except ValueError:
        return {}


def _report_path(run_id):
    return config.REPORTS_DIR / f"test_run_{run_id}.html"


def delete_report(run_id):
    """Remove the HTML file an earlier version saved for this run, if any. A file
    that cannot go only costs disk space."""
    try:
        _report_path(run_id).unlink(missing_ok=True)
    except OSError as exc:
        log.warning("Could not delete the report for run %s: %s", run_id, exc)
