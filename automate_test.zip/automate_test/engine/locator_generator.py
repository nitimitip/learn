"""Turns a pasted HTML snippet into ranked locators for the Locator type and Locator value
fields. Standard library only, and the HTML is only ever parsed, never rendered or run.

Each candidate is checked against the snippet using the same matching rules the browser
applies (Playwright's role, label and text rules are mostly part-of-text and ignore case).
A locator known to match several elements would fail with a strict mode violation, so it is
given an @N (or (...)[N] for XPath) and a warning. A snippet cannot prove a locator is unique
on the whole page: only that it is not.
"""
import re
from html.parser import HTMLParser

from engine.keywords import FRAME_SEPARATOR, INDEX_SUFFIX_RE, KEYWORDS, REQUIRED, TOKEN_RE

MAX_HTML_CHARS = 500_000
MAX_NODES = 5000
MAX_DEPTH = 200
MAX_ELEMENTS = 200
_MAX_VALUE = 300
_SHORT_TEXT = 60

RANK_TEST_ID, RANK_LABEL, RANK_ROLE, RANK_PLACEHOLDER, RANK_ID, RANK_ATTR, RANK_ROW, RANK_FALLBACK = range(1, 9)

DYNAMIC_ID_WARNING = "Dynamic ID warning: may change on reload"
_POSITION_WARNING = "Uses the element's position, so it breaks if the layout changes."

_VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param",
         "source", "track", "wbr"}
# Their content is never on the page as text, so nothing inside them can be a target.
_IGNORED = {"script", "style", "noscript", "template", "head", "title"}
# A start tag that closes an unfinished element, for snippets typed by hand.
_CLOSES = {"tr": {"tr", "td", "th"}, "td": {"td", "th"}, "th": {"td", "th"}, "li": {"li"},
           "option": {"option"}}
_LABELABLE = {"button", "meter", "output", "progress", "select", "textarea", "input"}
_CONTROLS = {"input", "select", "textarea", "button"}
_BUTTON_INPUTS = {"button", "submit", "reset", "image"}
_INPUT_DEFAULT_NAMES = {"submit": "Submit", "reset": "Reset"}
_INPUT_ROLES = {"button": "button", "submit": "button", "reset": "button", "image": "button",
                "checkbox": "checkbox", "radio": "radio", "range": "slider", "number": "spinbutton",
                "search": "searchbox", "text": "textbox", "email": "textbox", "tel": "textbox",
                "url": "textbox"}
_TAG_ROLES = {"button": "button", "h1": "heading", "h2": "heading", "h3": "heading", "h4": "heading",
              "h5": "heading", "h6": "heading", "textarea": "textbox", "tr": "row", "td": "cell",
              "th": "columnheader", "option": "option", "ul": "list", "ol": "list", "li": "listitem",
              "nav": "navigation", "table": "table", "form": "form", "dialog": "dialog"}
# Roles whose accessible name comes from the text inside. Any other role only has a name
# from aria-label, so "alert|Saved" would never match even though the alert shows Saved.
_NAME_FROM_CONTENT = {"button", "cell", "checkbox", "columnheader", "gridcell", "heading", "link",
                      "menuitem", "menuitemcheckbox", "menuitemradio", "option", "radio", "row",
                      "rowheader", "switch", "tab", "tooltip", "treeitem"}
_ROLE_TARGETS = {"button", "link", "checkbox", "radio", "tab", "heading"}
_ACTION_ROLES = {"button", "link", "checkbox", "radio", "switch", "tab", "menuitem", "menuitemcheckbox",
                 "menuitemradio", "option", "combobox", "textbox", "searchbox", "slider", "spinbutton",
                 "listbox", "treeitem"}
_INFO_ROLES = {"alert", "status", "heading", "cell", "gridcell", "columnheader", "rowheader", "tooltip", "log"}
_NO_ROLE = {"presentation", "none", "generic"}
_TEXT_TAGS = {"h1", "h2", "h3", "h4", "h5", "h6", "span", "td", "th"}
_TEXT_PARENTS = _TEXT_TAGS - {"span", "td", "th"} | {"label", "option"}
_ROW_CELL_ROLES = {"cell", "gridcell", "rowheader", "columnheader"}
_ID_PREFIXED = re.compile(r"ctl\d+[_$]|.*(?:ContentPlaceHolder|MainContent)\w*[_$]", re.I)
_ID_TAIL = re.compile(r"[^_$]+(?:[_$]\d+)?$")
_SIMPLE_NAME = re.compile(r"^[A-Za-z][\w-]*$")
_DYNAMIC_IDS = [re.compile(pattern, re.I) for pattern in (
    r"^(mat|cdk|ng|mdc|ui-id|gwt-uid|ext-gen|ember|mui|rc|downshift|headlessui|react-select|j_idt|__bvid__)"
    r"[\w:-]*?\d+[\w-]*$",
    r":r[0-9a-z]*:",  # React useId
    "[" + chr(0xAB) + "]r[0-9a-z]*[" + chr(0xBB) + "]",  # React 19 useId
    r"-\d{3,}$",
)]
_HEX_TAIL = re.compile(r"(?:^|[-_:.])([0-9a-f]{5,})$", re.I)
_UNSTABLE_CLASS = re.compile(
    r"^(ng-|mat-|mdc-|cdk-|css-|sc-|jss|is-|has-|Mui|active$|disabled$|selected$|hover$|focus$|open$|show$|hidden$)"
    r"|\d{3,}|[0-9a-f]{6,}$"
)
_XPATH_SPACE = re.compile(r"[ \t\r\n\f]+")
_INVISIBLE = {0x200B: None, 0xAD: None}
_NBSP = chr(0xA0)


class SnippetError(ValueError):
    """The paste cannot be used. The message is written for the user."""


class Node:
    __slots__ = ("tag", "attrs", "parent", "children", "elements", "nth", "order", "last")

    def __init__(self, tag, attrs, parent, order):
        self.tag, self.parent, self.order = tag, parent, order
        self.attrs = {}
        for key, value in attrs:
            self.attrs.setdefault(key, value or "")
        self.children = []
        self.elements = []  # The element children, filled in once parsing is done.
        self.nth = 1  # Position among siblings with the same tag.
        self.last = order

    def get(self, name):
        return self.attrs.get(name, "")

    @property
    def input_type(self):
        return self.get("type").lower() or "text" if self.tag == "input" else ""


class _TreeBuilder(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.roots, self.nodes, self.stack = [], [], []
        self.ignoring = None

    def _place(self, item):
        (self.stack[-1].children if self.stack else self.roots).append(item)

    def handle_starttag(self, tag, attrs):
        if self.ignoring:
            return
        if tag in _IGNORED:
            if tag not in _VOID:
                self.ignoring = tag
            return
        closes = _CLOSES.get(tag)
        if closes and self.stack and self.stack[-1].tag in closes:
            self.stack.pop()
            if tag == "tr" and self.stack and self.stack[-1].tag == "tr":
                self.stack.pop()
        if len(self.nodes) >= MAX_NODES:
            raise SnippetError(f"That is more than {MAX_NODES} elements. Paste only the part of the page you need.")
        if len(self.stack) >= MAX_DEPTH:
            raise SnippetError(f"That is nested more than {MAX_DEPTH} levels deep. Paste only the part of the page you need.")
        node = Node(tag, attrs, self.stack[-1] if self.stack else None, len(self.nodes))
        self.nodes.append(node)
        self._place(node)
        if tag not in _VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        self.handle_endtag(tag)

    def handle_endtag(self, tag):
        if self.ignoring:
            if tag == self.ignoring:
                self.ignoring = None
            return
        for position in range(len(self.stack) - 1, -1, -1):
            if self.stack[position].tag == tag:
                del self.stack[position:]
                return

    def handle_data(self, data):
        if not self.ignoring:
            self._place(data)


def _norm(text):
    return " ".join(text.translate(_INVISIBLE).split())


def _xnorm(text):
    """What XPath's normalize-space() gives, which leaves a non-breaking space alone."""
    return _XPATH_SPACE.sub(" ", text).strip(" ")


def _short(text, limit=_SHORT_TEXT):
    if len(text) <= limit:
        return text
    return text[:limit].rsplit(" ", 1)[0] or text[:limit]


def _x_fragment(text):
    """The longest stretch XPath can compare, since a nbsp cannot be typed as ASCII here."""
    return _short(max(text.split(_NBSP), key=len).strip())


def xpath_literal(text):
    if "'" not in text:
        return f"'{text}'"
    if '"' not in text:
        return f'"{text}"'
    parts = ", \"'\", ".join(f"'{part}'" for part in text.split("'"))
    return f"concat({parts})"


def _css_string(text):
    escaped = text.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def is_dynamic_id(value):
    if any(pattern.search(value) for pattern in _DYNAMIC_IDS):
        return True
    tail = _HEX_TAIL.search(value)
    return bool(tail) and any(ch.isdigit() for ch in tail.group(1))


def id_tail(value):
    """'ctl00_Main_txtInvoice' gives 'txtInvoice'. None unless it is a compound .NET id:
    a plain 'user_name' must not become 'name', which would match all sorts of things."""
    if "$" not in value and not _ID_PREFIXED.match(value):
        return None
    tail = _ID_TAIL.search(value)
    return tail.group() if tail and tail.group() != value else None


def _stable_classes(node):
    return [name for name in node.get("class").split()
            if _SIMPLE_NAME.match(name) and not _UNSTABLE_CLASS.search(name)]


class Snippet:
    """The parsed tree plus the browser's view of it: text, labels, roles and names."""

    def __init__(self, html):
        builder = _TreeBuilder()
        builder.feed(html)
        builder.close()
        self.roots = [item for item in builder.roots if isinstance(item, Node)]
        self.nodes = builder.nodes
        self._finish_tree()
        self.by_id, self.by_tag = {}, {}
        for node in self.nodes:
            self.by_tag.setdefault(node.tag, []).append(node)
            if node.get("id"):
                self.by_id.setdefault(node.get("id"), node)
        self._pw_text, self._dom_text, self._names = {}, {}, {}
        self._text_norm, self._dom_norm, self._text_lower = {}, {}, {}
        self._roles, self._hidden, self._label_texts = {}, {}, {}
        self._labels = self._link_labels()
        self.rows = [n for n in self.nodes if n.tag == "tr" or self.role(n) == "row"]
        self._row_text = {row: self.text_lower(row) for row in self.rows}

    def _finish_tree(self):
        for node in reversed(self.nodes):
            node.elements = [child for child in node.children if isinstance(child, Node)]
            node.last = node.elements[-1].last if node.elements else node.order
            self._number_siblings(node.elements)
        self._number_siblings(self.roots)

    @staticmethod
    def _number_siblings(siblings):
        seen = {}
        for node in siblings:
            seen[node.tag] = node.nth = seen.get(node.tag, 0) + 1

    def inside(self, node):
        return self.nodes[node.order + 1:node.last + 1]

    def _collect(self, node, cache, own):
        if node in cache:
            return cache[node]
        result = own(node)
        if result is None:
            result = "".join(
                child if isinstance(child, str) else self._collect(child, cache, own) for child in node.children
            )
        cache[node] = result
        return result

    def text(self, node):
        """Playwright's element text: a submit button's value counts as text."""
        def own(item):
            if item.tag == "input" and item.input_type in ("submit", "button"):
                return item.get("value")
            return None
        if node not in self._text_norm:
            self._text_norm[node] = _norm(self._collect(node, self._pw_text, own))
        return self._text_norm[node]

    def text_lower(self, node):
        if node not in self._text_lower:
            self._text_lower[node] = self.text(node).lower()
        return self._text_lower[node]

    def dom_text(self, node):
        """The text XPath's string value sees."""
        if node not in self._dom_norm:
            self._dom_norm[node] = _xnorm(self._collect(node, self._dom_text, lambda _item: None))
        return self._dom_norm[node]

    def is_hidden(self, node):
        if node not in self._hidden:
            self._hidden[node] = (self._hidden_self(node) or node.input_type == "hidden"
                                  or (node.parent is not None and self.is_hidden(node.parent)))
        return self._hidden[node]

    def _link_labels(self):
        linked = {}
        for label in self.by_tag.get("label", []):
            if "for" in label.attrs:
                target = self.by_id.get(label.get("for"))
                targets = [target] if target and self._labelable(target) else []
            else:
                targets = [n for n in self.inside(label) if self._labelable(n)][:1]
            for target in targets:
                linked.setdefault(target, []).append(label)
        return linked

    @staticmethod
    def _labelable(node):
        return node.tag in _LABELABLE and node.input_type != "hidden"

    def _labelled_by(self, node):
        ids = node.get("aria-labelledby").split()
        return [self.by_id[i] for i in ids if i in self.by_id]

    def label_texts(self, node):
        """Every text get_by_label would accept for this element, in its order of precedence."""
        if node not in self._label_texts:
            referenced = self._labelled_by(node)
            if referenced:
                texts = [self.text(item) for item in referenced]
            elif node.get("aria-label").strip():
                texts = [_norm(node.get("aria-label"))]
            else:
                texts = [self.text(label) for label in self._labels.get(node, [])]
            self._label_texts[node] = [text.lower() for text in texts]
        return self._label_texts[node]

    def display_label(self, node):
        """The label as a person reads it: no option text, and no trailing * or :."""
        referenced = self._labelled_by(node)
        if referenced:
            text = " ".join(self.text(item) for item in referenced)
        elif node.get("aria-label").strip():
            text = node.get("aria-label")
        else:
            labels = self._labels.get(node)
            text = self._text_without_controls(labels[0]) if labels else ""
        return _norm(text).rstrip(" *:").strip()

    def _text_without_controls(self, node):
        parts = []
        for child in node.children:
            if isinstance(child, str):
                parts.append(child)
            elif child.tag not in _CONTROLS:
                parts.append(self._text_without_controls(child))
        return "".join(parts)

    def role(self, node):
        if node not in self._roles:
            self._roles[node] = self._work_out_role(node)
        return self._roles[node]

    def _work_out_role(self, node):
        explicit = node.get("role").split()
        if explicit:
            return explicit[0].lower()
        if node.tag == "a":
            return "link" if "href" in node.attrs else ""
        if node.tag == "input":
            return "combobox" if "list" in node.attrs and node.input_type in ("text", "search", "email", "tel", "url") \
                else _INPUT_ROLES.get(node.input_type, "")
        if node.tag == "select":
            return "listbox" if "multiple" in node.attrs or node.get("size") not in ("", "0", "1") else "combobox"
        return _TAG_ROLES.get(node.tag, "")

    def _visible_text(self, node):
        parts = []
        for child in node.children:
            if isinstance(child, str):
                parts.append(child)
            elif self._hidden_self(child):
                continue
            elif child.tag == "img":
                parts.append(child.get("alt"))
            else:
                parts.append(self._visible_text(child))
        return "".join(parts)

    @staticmethod
    def _hidden_self(node):
        style = node.get("style").replace(" ", "").lower()
        return ("hidden" in node.attrs or node.get("aria-hidden").lower() == "true"
                or "display:none" in style or "visibility:hidden" in style)

    def name(self, node):
        """The accessible name, which is what role|name is compared with."""
        if node not in self._names:
            self._names[node] = self._work_out_name(node)
        return self._names[node]

    def _work_out_name(self, node):
        referenced = self._labelled_by(node)
        if referenced:
            return _norm(" ".join(self.text(item) for item in referenced))
        if node.get("aria-label").strip():
            return _norm(node.get("aria-label"))
        if node.tag == "input" and node.input_type in _BUTTON_INPUTS:
            if node.input_type == "image":
                return _norm(node.get("alt") or node.get("title"))
            return _norm(node.get("value") or _INPUT_DEFAULT_NAMES.get(node.input_type, ""))
        if self._labels.get(node):
            return _norm(" ".join(self.text(label) for label in self._labels[node]))
        if self.role(node) in _NAME_FROM_CONTENT:
            name = _norm(self._visible_text(node))
            if name:
                return name
        return _norm(node.get("title"))

    def row_of(self, node):
        parent = node.parent
        while parent is not None:
            if parent.tag == "tr" or self.role(parent) == "row":
                return parent
            parent = parent.parent
        return None

    def cells(self, row):
        kids = row.elements
        marked = [kid for kid in kids if kid.tag in ("td", "th") or self.role(kid) in _ROW_CELL_ROLES]
        return marked or kids

    def is_header_row(self, row):
        cells = self.cells(row)
        return bool(cells) and all(c.tag == "th" or self.role(c) == "columnheader" for c in cells)

    # ---- What each locator type would match ----
    def smallest_with_text(self, wanted, scope=None):
        """get_by_text: the innermost elements containing the text, ignoring case."""
        wanted = _norm(wanted).lower()
        found = []
        for node in self.nodes if scope is None else scope:
            if wanted in self.text_lower(node) and not any(wanted in self.text_lower(k) for k in node.elements):
                found.append(node)
        return found

    def with_role(self, role, name=None, scope=None):
        wanted = None if name is None else _norm(name).lower()
        found = []
        for node in self.nodes if scope is None else scope:
            if self.role(node) == role and not self.is_hidden(node):
                if wanted is None or wanted in self.name(node).lower():
                    found.append(node)
        return found

    def with_label(self, label):
        wanted = _norm(label).lower()
        return [n for n in self.nodes if any(wanted in text for text in self.label_texts(n))]

    def attr_contains(self, attr, value):
        wanted = _norm(value).lower()
        return [n for n in self.nodes if attr in n.attrs and wanted in _norm(n.get(attr)).lower()]

    def attr_equals(self, attr, value, tag=None):
        pool = self.nodes if tag is None else self.by_tag.get(tag, [])
        return [n for n in pool if attr in n.attrs and n.get(attr) == value]


class _Candidates:
    """Collects the candidates of one element. A candidate that does not find its own
    element in the snippet is dropped, which is cheaper than a step that fails later."""

    def __init__(self, node, token):
        self.node, self.token = node, token
        self.items, self.seen = [], set()

    def _usable(self, type_, value):
        plain = value.replace(self.token, "") if self.token else value
        if not value or len(value) > _MAX_VALUE or FRAME_SEPARATOR in value or TOKEN_RE.search(plain):
            return False
        # A value really ending in " @2" would be read as a pick, for every type now.
        return not INDEX_SUFFIX_RE.search(value)

    def add(self, rank, type_, value, matched, note="", warning=""):
        """matched is every element the value would find. Returns True if it found this
        element and nothing else."""
        if not self._usable(type_, value):
            return False
        matched = sorted(set(matched), key=lambda n: n.order)
        if self.node not in matched:
            return False
        warnings = [warning] if warning else []
        if len(matched) > 1:
            position = matched.index(self.node) + 1
            value = f"({value})[{position}]" if type_ == "xpath" else f"{value} @{position}"
            warnings.append(f"Matches {len(matched)} elements in this snippet, so this picks number {position}. "
                            "Check the number against the whole page.")
        if (type_, value) not in self.seen:
            self.seen.add((type_, value))
            self.items.append({"rank": rank, "type": type_, "value": value, "note": note,
                               "warnings": warnings, "matches": len(matched), "best": False})
        return len(matched) == 1

    def finished(self):
        self.items.sort(key=lambda item: item["rank"])
        if self.items:
            clean = [item for item in self.items if not item["warnings"]]
            (clean or self.items)[0]["best"] = True
        return self.items


def _keyword_for(snippet, node, is_action):
    if node.tag == "input":
        kind = node.input_type
        if kind == "file":
            return "UPLOAD_FILE"
        if kind in ("checkbox", "radio"):
            return "CHECK"
        return "CLICK" if kind in _BUTTON_INPUTS else "FILL"
    if node.tag == "select":
        return "SELECT_DROPDOWN"
    if node.tag == "textarea" or "contenteditable" in node.attrs:
        return "FILL"
    role = snippet.role(node)
    if role in ("checkbox", "radio", "switch"):
        return "CHECK"
    if role in ("textbox", "searchbox"):
        return "FILL"
    if is_action:
        return "CLICK"
    return "VERIFY_TEXT_CONTAINS" if snippet.text(node) else "VERIFY_ELEMENT_VISIBLE"


def _is_action(snippet, node):
    if node.tag in ("button", "select", "textarea") or "contenteditable" in node.attrs or "onclick" in node.attrs:
        return True
    if node.tag == "input":
        return node.input_type != "hidden"
    if node.get("role"):
        return snippet.role(node) in _ACTION_ROLES
    return node.tag == "a" and ("href" in node.attrs or bool(snippet.text(node)))


def _is_info(snippet, node):
    if snippet.role(node) in _INFO_ROLES and node.get("role"):
        return True
    if "alert" in node.get("class").lower().split() or any(c.startswith("alert-") for c in node.get("class").lower().split()):
        return True
    return node.tag in _TEXT_TAGS and bool(snippet.text(node))


def _listed_elements(snippet):
    """Actions first, then things worth checking, each in page order. Text inside something
    already listed (the span in a button) is not listed again."""
    actions = [n for n in snippet.nodes if _is_action(snippet, n)]
    listed = set(actions)
    has_listed_inside = set()

    def note_ancestors(node):
        parent = node.parent
        while parent is not None and parent not in has_listed_inside:
            has_listed_inside.add(parent)
            parent = parent.parent

    for node in actions:
        note_ancestors(node)
    info = []
    for node in reversed(snippet.nodes):
        if node in listed:
            continue
        if "data-testid" in node.attrs:
            pass
        elif not _is_info(snippet, node) or node in has_listed_inside or _inside_listed_or_text(snippet, node, listed):
            continue
        info.append(node)
        listed.add(node)
        note_ancestors(node)
    info.reverse()
    return (actions + info) or list(snippet.roots)


def _inside_listed_or_text(snippet, node, listed):
    parent = node.parent
    while parent is not None:
        if parent in listed or parent.tag in _TEXT_PARENTS or _is_info_role(snippet, parent):
            return True
        parent = parent.parent
    return False


def _is_info_role(snippet, node):
    return bool(node.get("role")) and snippet.role(node) in ("alert", "status", "heading", "tooltip", "log")


def _add_id_candidates(snippet, node, picks):
    value = node.get("id")
    if not value:
        return
    full = snippet.attr_equals("id", value)
    tail = id_tail(value)
    if tail:
        picks.add(RANK_ID, "id_ends_with", tail, [n for n in snippet.nodes if n.get("id").endswith(tail)],
                  "Recommended for .NET pages: the prefix before it can change with the master page.")
    picks.add(RANK_ID, "id", value, full, warning=DYNAMIC_ID_WARNING if is_dynamic_id(value) else "")


def _own_xpaths(snippet, node):
    """(expression, the elements it matches, attribute-based?) for this element alone."""
    tag = node.tag
    pool = snippet.by_tag.get(tag, [])
    found = []

    def attribute(attr, value=None):
        value = node.get(attr) if value is None else value
        if value:
            found.append((f"{tag}[@{attr}={xpath_literal(value)}]", snippet.attr_equals(attr, value, tag), True))

    attribute("data-testid")
    attribute("name")
    value = node.get("id")
    if value and not is_dynamic_id(value):
        tail = id_tail(value)
        if tail:
            found.append((f"{tag}[contains(@id,{xpath_literal(tail)})]", [n for n in pool if tail in n.get("id")], True))
        else:
            attribute("id")
    attribute("aria-label")
    attribute("placeholder")
    attribute("title")
    attribute("role")
    if tag == "input" and node.input_type in ("button", "submit", "reset"):
        attribute("value")
    text = snippet.dom_text(node)
    if text and tag not in ("input", "select", "textarea"):
        if _NBSP in text or len(text) > 80:
            piece = _x_fragment(text)
            found.append((f"{tag}[contains(normalize-space(),{xpath_literal(piece)})]",
                          [n for n in pool if piece in snippet.dom_text(n)], False))
        else:
            found.append((f"{tag}[normalize-space()={xpath_literal(text)}]",
                          [n for n in pool if snippet.dom_text(n) == text], False))
    return found


def _own_css(snippet, node):
    tag = node.tag
    pool = snippet.by_tag.get(tag, [])
    found = []

    def attribute(attr):
        if node.get(attr):
            found.append((f"{tag}[{attr}={_css_string(node.get(attr))}]", snippet.attr_equals(attr, node.get(attr), tag)))

    attribute("data-testid")
    value = node.get("id")
    if value and not is_dynamic_id(value):
        tail = id_tail(value)
        if tail:
            found.append((f"{tag}[id$={_css_string(tail)}]", [n for n in pool if n.get("id").endswith(tail)]))
        elif _SIMPLE_NAME.match(value):
            found.append((f"#{value}", snippet.attr_equals("id", value)))
        else:
            attribute("id")
    attribute("name")
    attribute("aria-label")
    attribute("placeholder")
    attribute("title")
    attribute("role")
    classes = _stable_classes(node)[:2]
    if classes:
        found.append((tag + "".join(f".{name}" for name in classes),
                      [n for n in pool if set(classes) <= set(n.get("class").split())]))
    return found


def _add_label_xpath(snippet, node, picks):
    labels = snippet._labels.get(node)
    if not labels or node.tag not in ("input", "select", "textarea"):
        return
    label = labels[0]
    piece = _x_fragment(_xnorm(snippet._text_without_controls(label)).rstrip(" *:"))
    if not piece:
        return
    holders = [item for item in snippet.by_tag["label"] if piece in snippet.dom_text(item)]
    prefix = f"//label[contains(normalize-space(),{xpath_literal(piece)})]"
    if node in snippet.inside(label):
        matched = [n for item in holders for n in snippet.inside(item) if n.tag == node.tag]
        picks.add(RANK_FALLBACK, "xpath", f"{prefix}//{node.tag}", matched, "Relative to the label.")
    else:
        matched = []
        for item in holders:
            following = [n for n in snippet.by_tag[node.tag] if n.order > item.last]
            matched += following[:1]
        picks.add(RANK_FALLBACK, "xpath", f"{prefix}/following::{node.tag}[1]", matched, "Relative to the label.")


def _row_identity(snippet, node, row, hint, token):
    """The text that singles this row out, and the cell holding it (None for a token).
    First cell by default, or the next one if the first also appears in other rows."""
    if token:
        return token, None
    if hint and hint.lower() in snippet.text_lower(row):
        holder = next((c for c in snippet.cells(row) if hint in snippet.dom_text(c)), None)
        return hint, holder
    cells = [c for c in snippet.cells(row) if c is not node and node not in snippet.inside(c) and snippet.text(c)]
    if not cells:
        return None, None
    for cell in cells:
        wanted = _short(snippet.text(cell)).lower()
        if sum(wanted in text for text in snippet._row_text.values()) == 1:
            return _short(snippet.text(cell)), cell
    return _short(snippet.text(cells[0])), cells[0]


def _rows_with_text(snippet, row, text, token):
    if token:
        return [row]
    wanted = _norm(text).lower()
    return [item for item, content in snippet._row_text.items() if wanted in content]


def _row_action_matches(snippet, rows, action):
    """Mirrors resolve_locator: named buttons and links, plus text outside any of those."""
    found = set()
    for row in rows:
        scope = snippet.inside(row)
        found.update(snippet.with_role("button", action, scope))
        found.update(snippet.with_role("link", action, scope))
        for node in snippet.smallest_with_text(action, scope):
            if not _in_button_or_link(snippet, node):
                found.add(node)
    return found


def _in_button_or_link(snippet, node):
    while node is not None:
        if node.tag == "button" or (node.tag == "a" and "href" in node.attrs) or node.get("role").lower() in ("button", "link"):
            return True
        node = node.parent
    return False


def _add_row_candidates(snippet, node, picks, hint, token, own_xpaths):
    row = snippet.row_of(node)
    if row is None or snippet.is_header_row(row) or not _is_action(snippet, node):
        return
    identity, cell = _row_identity(snippet, node, row, hint, token)
    if not identity:
        return
    # An <a> with no href has no link role, but the row_action locator finds it by its text.
    if snippet.role(node) in ("button", "link") or node.tag == "a" or "onclick" in node.attrs:
        action = _short(snippet.name(node) or snippet.text(node))
        if action and "|" not in action:
            rows = _rows_with_text(snippet, row, identity, token)
            note = "Resolved when the step runs." if token else "The row is found by its text."
            picks.add(RANK_ROW, "row_action", f"{identity} | {action}", _row_action_matches(snippet, rows, action), note)

    expressions = own_xpaths[:1] or _type_xpath(snippet, node)
    if not expressions:
        return
    expression, _matched, *_rest = expressions[0]
    target = _matches_in_row_xpath(snippet, node, expression, own_xpaths)
    piece = token or _x_fragment(snippet.dom_text(cell) if cell is not None and not hint else identity)
    if not piece:
        return
    literal = xpath_literal(piece)
    cell_tag = cell.tag if cell is not None and cell.tag in ("td", "th") else "td"
    if row.tag == "tr":
        prefix = f"//tr[{cell_tag}[contains(normalize-space(),{literal})]]"
        same_kind = snippet.by_tag["tr"]
        cells_of = lambda item: [c for c in item.elements if c.tag == cell_tag]
    else:
        prefix = f"//*[@role='row'][*[contains(normalize-space(),{literal})]]"
        same_kind = [item for item in snippet.rows if item.get("role").lower() == "row"]
        cells_of = lambda item: item.elements
    rows = [row] if token else [item for item in same_kind if any(piece in snippet.dom_text(c) for c in cells_of(item))]
    matched = [n for item in rows for n in snippet.inside(item) if n in target]
    picks.add(RANK_FALLBACK, "xpath", f"{prefix}//{expression}", matched, "Relative to the table row.")


def _type_xpath(snippet, node):
    """Inside a row, a control with no attributes is still identified by its type."""
    if node.tag == "input" and node.get("type"):
        kind = node.get("type")
        return [(f"input[@type={xpath_literal(kind)}]", snippet.attr_equals("type", kind, "input"), True)]
    if node.tag in ("select", "textarea", "button", "a"):
        return [(node.tag, snippet.by_tag[node.tag], True)]
    return []


def _matches_in_row_xpath(snippet, node, expression, own_xpaths):
    for item in own_xpaths + _type_xpath(snippet, node):
        if item[0] == expression:
            return set(item[1])
    return {node}


def _position_path(node):
    """Up to four (tag, position) segments ending at this element. The top one has no
    position when it is the snippet's root, since the root's siblings are not known."""
    path = []
    while node is not None and len(path) < 4:
        path.append((node.tag, node.nth))
        node = node.parent
    path.reverse()
    if len(path) > 1 and path[0][1] == 1:
        path[0] = (path[0][0], None)
    return path


def _ends_with_path(node, path):
    for tag, position in reversed(path):
        if node is None or node.tag != tag or (position is not None and node.nth != position):
            return False
        node = node.parent
    return True


def _add_position_candidates(snippet, node, picks, want_xpath, want_css):
    path = _position_path(node)
    matched = [n for n in snippet.by_tag[node.tag] if _ends_with_path(n, path)]
    if want_xpath:
        value = "//" + "/".join(f"{tag}[{pos}]" if pos else tag for tag, pos in path)
        picks.add(RANK_FALLBACK, "xpath", value, matched, warning=_POSITION_WARNING)
    if want_css:
        value = " > ".join(f"{tag}:nth-of-type({pos})" if pos else tag for tag, pos in path)
        picks.add(RANK_FALLBACK, "css", value, matched, warning=_POSITION_WARNING)


def _candidates_for(snippet, node, hint, token):
    picks = _Candidates(node, token)
    if node.get("data-testid"):
        picks.add(RANK_TEST_ID, "test_id", node.get("data-testid"), snippet.attr_equals("data-testid", node.get("data-testid")))

    if node.tag in ("input", "select", "textarea"):
        label = _short(snippet.display_label(node))
        if label:
            picks.add(RANK_LABEL, "label", label, snippet.with_label(label))

    role = snippet.role(node)
    if role and role not in _NO_ROLE and not snippet.is_hidden(node) and (role in _ROLE_TARGETS or node.get("role")):
        name = _short(snippet.name(node))
        if name:
            picks.add(RANK_ROLE, "role", f"{role}|{name}", snippet.with_role(role, name))
        elif node.get("role"):
            picks.add(RANK_ROLE, "role", role, snippet.with_role(role))

    if node.get("placeholder").strip():
        picks.add(RANK_PLACEHOLDER, "placeholder", _short(_norm(node.get("placeholder"))),
                  snippet.attr_contains("placeholder", _short(_norm(node.get("placeholder")))))

    _add_id_candidates(snippet, node, picks)
    if node.get("name"):
        picks.add(RANK_ATTR, "name", node.get("name"), snippet.attr_equals("name", node.get("name")))
    if node.get("title").strip():
        picks.add(RANK_ATTR, "title", _short(_norm(node.get("title"))),
                  snippet.attr_contains("title", _short(_norm(node.get("title")))))
    if node.tag not in ("input", "select", "textarea") and snippet.text(node):
        text = _short(snippet.text(node))
        picks.add(RANK_ATTR, "text", text, snippet.smallest_with_text(text))

    own_xpaths = _own_xpaths(snippet, node)
    _add_row_candidates(snippet, node, picks, hint, token, own_xpaths)
    _add_label_xpath(snippet, node, picks)

    attribute = next((item for item in own_xpaths if item[2]), None)
    wording = next((item for item in own_xpaths if not item[2]), None)
    for item in (attribute, wording):
        if item:
            picks.add(RANK_FALLBACK, "xpath", f"//{item[0]}", item[1])
    css_options = _own_css(snippet, node)
    css = next((item for item in css_options if len(set(item[1])) == 1), css_options[0] if css_options else None)
    if css:
        picks.add(RANK_FALLBACK, "css", css[0], css[1])
    has_xpath = any(item["type"] == "xpath" for item in picks.items)
    has_css = any(item["type"] == "css" for item in picks.items)
    if not has_xpath or not has_css:
        _add_position_candidates(snippet, node, picks, not has_xpath, not has_css)
    return picks.finished()


def _opening_tag(node):
    shown = []
    for key, value in node.attrs.items():
        # A pasted form can hold typed data, which has no business being echoed around.
        if key == "value" and node.input_type not in _BUTTON_INPUTS:
            continue
        shown.append(f'{key}="{value}"' if value else key)
    text = " ".join([node.tag, *shown])
    return f"<{_short(text, 160)}{'...' if len(text) > 160 else ''}>"


def _describe(snippet, node, hint, token):
    is_action = _is_action(snippet, node)
    keyword = _keyword_for(snippet, node, is_action)
    warnings = []
    if snippet.is_hidden(node):
        warnings.append("Hidden in this snippet. Most keywords wait for an element to be visible.")
    title = (snippet.name(node) or snippet.text(node) or snippet.display_label(node) or node.get("placeholder")
             or node.get("name") or node.get("id") or node.tag)
    return {
        "tag": node.tag,
        "position": node.order,
        "title": _short(_norm(title)),
        "opening_tag": _opening_tag(node),
        "kind": "action" if is_action else "info",
        "keyword": keyword,
        "needs_input": KEYWORDS[keyword]["input"] == REQUIRED,
        "warnings": warnings,
        "candidates": _candidates_for(snippet, node, hint, token),
    }


def generate_locators(html, hint=""):
    """Returns {"elements": [...], "total": n, "truncated": bool}. Raises SnippetError with
    a message for the user if the paste cannot be used."""
    html = html if isinstance(html, str) else ""
    hint = _norm(hint if isinstance(hint, str) else "")[:200]
    if not html.strip():
        raise SnippetError("Paste some HTML first.")
    if len(html) > MAX_HTML_CHARS:
        raise SnippetError(f"That is more than {MAX_HTML_CHARS:,} characters. Paste only the part of the page you need.")
    snippet = Snippet(html)
    if not snippet.nodes:
        raise SnippetError("No HTML elements found. In the browser, right-click the element and choose "
                           "Inspect, then Copy, then Copy outerHTML.")
    token = hint if TOKEN_RE.fullmatch(hint) else ""
    listed = _listed_elements(snippet)
    return {
        "elements": [_describe(snippet, node, hint, token) for node in listed[:MAX_ELEMENTS]],
        "total": len(listed),
        "truncated": len(listed) > MAX_ELEMENTS,
    }
