"""Page load and response timings for every page a run opens.

Listeners sit on the browser context rather than on one page, so new tabs and
pop-ups are measured even though test steps stay on the original tab.

Timings come from the browser's own Navigation Timing data and are pushed through
a binding. Reading them from Python instead would be unreliable: Playwright only
delivers events while a step is talking to the browser, so a Python clock would
measure the test's pace, and a pop-up that closes itself would already be gone.

Measuring must never affect a test result, so every entry point here swallows its
own errors.
"""
import bisect
import logging
import math
import re
import time
from urllib.parse import parse_qsl, urlsplit, urlunsplit

import config
from models import OPENED_MAIN, OPENED_POPUP, OPENED_SPA, OPENED_TAB, ApiPerformance, PagePerformance

log = logging.getLogger(__name__)

BINDING = "__qaPerf"
OPENED_OTHER = "Other"  # For example a service worker, which belongs to no page.

# Runs in every document. A window.open page starts on about:blank, and when it
# moves to a same-origin URL Chromium keeps the same window object and does NOT
# run this script again. So the listeners must be on window, must be added while
# still on about:blank, and the report must read the location when it fires.
#
# window.print() would open the Windows print dialog, which no step can reach and
# which holds up a visible run, so every frame counts the calls instead and
# VERIFY_PRINT_CALLED reads the count. A same-origin frame counts on its top page.
#
# An Angular or React screen changes without a new document. Two animation frames
# only show that the browser drew once, which for a screen fetching its data is the
# spinner. So "ready" is that first draw, and "load" waits until the screen's
# requests have finished and its content has stopped changing. A change within
# PERF_SPA_INTERACTION_MS of a click or Enter is timed from that click, which counts
# the time a route resolver spends before the address changes.
#
# The path, the query and a route-style hash (#/orders) name a screen: a same-page
# anchor does not. Query values are compared here, in the browser, and never sent
# on: Python keeps only their names. A change to the query alone is a new screen only
# after a click or key on something other than a text field, so search-as-you-type
# and a screen polling with a changing query stay out of the table.
#
# A click that leaves the address alone is an in-page view once it adds a dialog or
# PERF_SPA_MIN_ELEMENTS elements. If the address then changes with no other click in
# between, the in-page row is withdrawn: the screen change covers the same time.
INIT_SCRIPT = """(() => {
  try {
    window.print = function () {
      let host = window;
      try { if (window.top.document) host = window.top; } catch (e) { /* cross-origin frame */ }
      host.__qaPrintCount = (host.__qaPrintCount || 0) + 1;
      host.__qaLastPrintTitle = document.title;
    };
  } catch (e) { /* the page must still work */ }
  if (window !== window.top) return;
  const send = window.%(binding)s;
  if (typeof send !== 'function') return;
  const report = (phase) => {
    try {
      if (!/^https?:$/.test(location.protocol)) return;
      const nav = performance.getEntriesByType('navigation')[0] || {};
      const paint = performance.getEntriesByName('first-contentful-paint')[0];
      const resources = performance.getEntriesByType('resource');
      send({
        phase, bars: window.locationbar.visible, url: location.href, title: document.title,
        origin: performance.timeOrigin, status: nav.responseStatus,
        response: nav.responseStart, ready: nav.domContentLoadedEventEnd,
        load: nav.loadEventEnd, paint: paint && paint.startTime,
        requests: resources.length + 1,
        bytes: resources.reduce((sum, r) => sum + (r.transferSize || 0), nav.transferSize || 0),
      }).catch(() => {});
    } catch (e) { /* measuring must not disturb the page */ }
  };
  const later = (phase) => () => setTimeout(() => report(phase), 0);
  report('start');
  window.addEventListener('DOMContentLoaded', later('ready'));
  window.addEventListener('load', later('load'));
  try {
    new PerformanceObserver(later('paint')).observe({type: 'paint', buffered: true});
  } catch (e) { /* older browser: first paint stays blank */ }

  const query = () => {
    try {
      return Array.from(new URLSearchParams(location.search), (pair) => pair.join('=')).sort().join('&');
    } catch (e) { return location.search; }
  };
  const place = () => location.pathname + (/^#!?\\//.test(location.hash) ? location.hash : '');
  const route = () => place() + (location.search ? '?' + query() : '');
  let shown = route(), shownPlace = place(), view = 0, batch = 0, open = 0;
  const look = () => { shown = route(); shownPlace = place(); };
  let noteChange = () => {}, stop = () => {};
  let interaction = null, watcher = null, watchTimer = 0;
  const track = () => {
    const mine = batch;
    let pending = true;
    open += 1;
    return () => {
      if (pending && mine === batch) { pending = false; open -= 1; noteChange(); }
    };
  };
  const recent = () => (
    interaction && performance.now() - interaction.at <= %(interaction_ms)d ? interaction : null
  );
  // cause: the click that led here, or null. label: a title for a view with no address change.
  const measure = (cause, label) => {
    stop();
    view += 1; batch += 1; open = 0;
    const mine = view, url = location.href, start = cause ? cause.at : performance.now();
    let last = performance.now(), ready = null;
    const sendView = (timings) => send(Object.assign({
      phase: 'spa', view: mine, start, url, title: label || document.title,
      origin: performance.timeOrigin,
    }, timings)).catch(() => {});
    const observer = new MutationObserver(() => { last = performance.now(); });
    observer.observe(document, {childList: true, subtree: true, characterData: true});
    noteChange = () => { last = performance.now(); };
    stop = () => observer.disconnect();
    sendView({});  // A hidden tab draws no frames, and the screen must still be listed.
    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (mine !== view) return;
      ready = performance.now() - start;
      sendView({ready});
    }));
    const check = () => {
      if (mine !== view) return;
      const now = performance.now();
      if (ready !== null && !open && now - last >= %(quiet_ms)d) {
        stop();
        sendView({ready, load: Math.max(ready, last - start)});
      } else if (now - start < %(max_ms)d) {
        setTimeout(check, 100);
      } else {
        stop();
      }
    };
    setTimeout(check, 100);
  };

  const DIALOG = '[role="dialog"],[role="alertdialog"],[aria-modal="true"],dialog[open]';
  const onScreen = (element) => {
    try { return element.getClientRects().length > 0; } catch (e) { return false; }
  };
  const nameOf = (box) => {
    if (!box) return '';
    let text = box.getAttribute('aria-label') || '';
    const ids = box.getAttribute('aria-labelledby');
    if (!text && ids) {
      text = ids.split(/\\s+/).map((id) => {
        const element = document.getElementById(id);
        return element ? element.textContent : '';
      }).join(' ');
    }
    if (!text) {
      const heading = box.querySelector('h1,h2,h3,h4,h5,h6,[role="heading"]');
      text = heading ? heading.textContent : '';
    }
    return text.replace(/\\s+/g, ' ').trim().slice(0, 200);
  };
  const unwatch = () => {
    if (watcher) { watcher.disconnect(); watcher = null; }
    clearTimeout(watchTimer);
  };
  // After a click, watch for a dialog or a block of new content that is not a screen change.
  const watch = (cause) => {
    unwatch();
    const root = document.documentElement;
    if (!root) return;
    const before = route();
    const already = new Set(Array.from(document.querySelectorAll(DIALOG)).filter(onScreen));
    let added = 0;
    watcher = new MutationObserver((records) => {
      try {
        if (interaction !== cause || route() !== before) { unwatch(); return; }
        let box = null;
        records.forEach((record) => {
          if (record.type === 'attributes') {
            const element = record.target;
            if (!box && element.matches(DIALOG) && !already.has(element) && onScreen(element)) box = element;
            return;
          }
          record.addedNodes.forEach((node) => {
            if (node.nodeType !== 1) return;
            added += 1 + node.getElementsByTagName('*').length;
            const found = box || (node.matches(DIALOG) ? node : node.querySelector(DIALOG));
            if (found && onScreen(found)) box = found;
          });
        });
        if (box || added >= %(min_elements)d) {
          unwatch();
          cause.view = view + 1;  // The number measure() is about to give it.
          measure(cause, nameOf(box) || 'In-page view update');
        }
      } catch (e) { unwatch(); }
    });
    watcher.observe(root, {
      childList: true, subtree: true, attributes: true,
      attributeFilter: ['open', 'class', 'style', 'hidden', 'aria-hidden', 'aria-modal'],
    });
    watchTimer = setTimeout(unwatch, %(interaction_ms)d);
  };
  const editable = (element) => (
    element && (element.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(element.tagName))
  );
  const interacted = (event) => {
    try {
      if (event.type === 'keydown') {
        if (event.key !== 'Enter' && event.key !== ' ') return;
        if (event.key === ' ' && editable(event.target)) return;  // a space typed in a field
      }
      const now = performance.now();
      // A pointerdown starts a click, and Enter on a button sends one: the same interaction.
      if (event.type === 'click' && interaction && now - interaction.at < 1000) return;
      // A click into a field only focuses it, and what typing then adds is not a screen.
      interaction = {at: now, view: 0, field: editable(event.target)};
      if (interaction.field) unwatch(); else watch(interaction);
    } catch (e) { /* measuring must not disturb the page */ }
  };
  ['pointerdown', 'click', 'keydown'].forEach((type) => window.addEventListener(type, interacted, true));

  const changed = () => {
    try {
      const now = route(), queryOnly = place() === shownPlace;
      if (now === shown || !/^https?:$/.test(location.protocol)) return;
      look();
      const cause = recent();
      if (queryOnly && (!cause || cause.field)) return;
      unwatch();
      if (cause && cause.view) {
        send({phase: 'spa', view: cause.view, origin: performance.timeOrigin, discard: true}).catch(() => {});
        cause.view = 0;
      }
      measure(cause, '');
    } catch (e) { /* measuring must not disturb the page */ }
  };
  ['pushState', 'replaceState'].forEach((name) => {
    const original = History.prototype[name];
    History.prototype[name] = function () {
      look();  // This window may have moved on from about:blank since the last look.
      const result = original.apply(this, arguments);
      changed();
      return result;
    };
  });
  window.addEventListener('popstate', changed);
  window.addEventListener('hashchange', changed);
  window.addEventListener('DOMContentLoaded', look);
  const realFetch = window.fetch;
  if (realFetch) {
    window.fetch = function () {
      const finished = track();
      try {
        const answer = realFetch.apply(this, arguments);
        answer.then(finished, finished);
        return answer;
      } catch (e) { finished(); throw e; }
    };
  }
  const realSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function () {
    this.addEventListener('loadend', track());
    return realSend.apply(this, arguments);
  };
})();""" % {
    "binding": BINDING, "quiet_ms": config.PERF_SPA_QUIET_MS, "max_ms": config.PERF_SPA_MAX_MS,
    "interaction_ms": config.PERF_SPA_INTERACTION_MS, "min_elements": config.PERF_SPA_MIN_ELEMENTS,
}


def _timing(value):
    """Browsers report 0 for a stage that has not happened; that is not a time."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    if not math.isfinite(value) or value <= 0:
        return None
    return round(value, 1)


def _count(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        return None
    return int(value) if value >= 0 else None


def _status(value):
    number = _count(value)
    return number if number and 100 <= number <= 599 else None


# A name such as tab or page[size]. Anything else could be a token passed with no name.
_SAFE_PARAM_RE = re.compile(r"^[A-Za-z0-9_.\-\[\]]{1,40}$")


def _query_names(query):
    """'?tab=history&id=7' as '?id=*&tab=*': which parameters a screen has, never their
    values. A parameter whose name does not look like a name shows as a single *."""
    names = sorted({name for name, _value in parse_qsl(query, keep_blank_values=True)})
    if not names:
        return ""
    safe = [f"{name}=*" for name in names if _SAFE_PARAM_RE.match(name)]
    return "?" + "&".join(safe + (["*"] if len(safe) < len(names) else []))


def _short_url(url, query_names=False):
    """Query strings often carry session tokens or typed values, so their values are never
    kept. With query_names, the parameter names are, to tell screens of one page apart."""
    try:
        parts = urlsplit(str(url))
        host = parts.hostname or ""
        netloc = f"{host}:{parts.port}" if parts.port else host
        short = urlunsplit((parts.scheme, netloc, parts.path, "", ""))
        return short + (_query_names(parts.query) if query_names else "")
    except ValueError:
        return str(url).split("?")[0].split("#")[0]


def view_url(url, query_names=False):
    """Like _short_url, but a hash route names the screen, so it is kept. Any other
    fragment can hold a sign-in token, and any query in the route is dropped too."""
    fragment = urlsplit(str(url)).fragment if "#" in str(url) else ""
    if fragment.startswith(("/", "!/")):
        return f"{_short_url(url, query_names)}#{fragment.split('?')[0]}"
    return _short_url(url, query_names)


def _page_of(request):
    """None for a service worker request, or a pop-up navigation that starts
    before Playwright has created the frame."""
    try:
        return request.frame.page
    except Exception:
        return None


def _is_top_level(request):
    try:
        return request.frame.parent_frame is None
    except Exception:
        return True  # No frame yet means a brand new page, not an iframe.


class PerformanceRecorder:
    """Collects in memory for one run; save() writes it when the run ends. Handlers
    only touch memory because they fire in the middle of whatever step is running."""

    def __init__(self, mask=lambda text: text):
        self._mask = mask
        self._marks = []  # (epoch ms, tc_result_id, step number, keyword), oldest first
        self._main_pages = set()
        self._popup_pages = set()
        self._unclassified = []
        self._pages = {}
        self._latest = {}
        self._pending = {}
        self._failed_loads = []
        self._api = {}
        self._api_status = {}
        self._dropped_pages = False

    def attach(self, context):
        try:
            context.expose_binding(BINDING, self._guarded(self._on_report))
            context.add_init_script(INIT_SCRIPT)
            context.on("page", self._guarded(self._unclassified.append))
            context.on("request", self._guarded(self._on_request))
            context.on("response", self._guarded(self._on_response))
            context.on("requestfinished", self._guarded(self._on_finished))
            context.on("requestfailed", self._guarded(self._on_failed))
        except Exception as exc:
            log.warning("Performance capture is off for this browser context: %s", exc)

    @staticmethod
    def _guarded(handler):
        def run(*args):
            try:
                handler(*args)
            except Exception:
                log.exception("Performance capture error (test results are not affected)")
        return run

    def mark_main(self, page):
        self._main_pages.add(page)

    def mark_step(self, tc_result_id, number, keyword):
        self._classify_new_pages()
        self._marks.append((time.time() * 1000, tc_result_id, number, keyword))

    @staticmethod
    def _window_id(page):
        session = page.context.new_cdp_session(page)
        try:
            return session.send("Browser.getWindowForTarget")["windowId"]
        finally:
            session.detach()

    def _classify_new_pages(self):
        """A pop-up is a page in its own browser window; a tab shares the main page's.
        This asks the browser, so it runs between steps and not inside an event
        handler. A pop-up that closes itself first is caught by locationbar.visible
        in its report instead, which only fails for a cross-origin pop-up."""
        pages, self._unclassified[:] = list(self._unclassified), []
        for page in pages:
            try:
                if page in self._main_pages or page.is_closed():
                    continue
                main = next(
                    (other for other in page.context.pages
                     if other in self._main_pages and not other.is_closed()), None,
                )
                if main is not None and self._window_id(page) != self._window_id(main):
                    self._popup_pages.add(page)
            except Exception as exc:
                log.debug("Could not tell whether a page is a pop-up: %s", exc)

    def _step_at(self, epoch_ms):
        """The step running when a navigation began, not the one running when its
        report arrived: a page opened by a click can finish during a later step."""
        if not self._marks:
            return None
        position = bisect.bisect_right([m[0] for m in self._marks], epoch_ms) - 1
        return self._marks[max(position, 0)]

    def _opened_as(self, page):
        if page in self._main_pages:
            return OPENED_MAIN
        return OPENED_POPUP if page in self._popup_pages else OPENED_TAB

    def _text(self, value, limit):
        return self._mask(str(value or ""))[:limit]

    def _on_report(self, source, data):
        page = source["page"]
        if data.get("bars") is False:
            self._popup_pages.add(page)
        origin = _timing(data.get("origin"))
        if origin is None:
            return
        is_view = data.get("phase") == "spa"
        key = (id(page), origin, _count(data.get("view"))) if is_view else (id(page), origin)
        if is_view and data.get("discard"):
            # An in-page view that turned out to be the start of a screen change, which is
            # timed from the same click.
            entry = self._pages.pop(key, None)
            if entry is not None and self._latest.get(page) is entry:
                del self._latest[page]
            return
        entry = self._pages.get(key)
        if entry is None:
            if len(self._pages) >= config.PERF_MAX_PAGE_ROWS:
                self._dropped_pages = True
                return
            # A view's own start decides which step it belongs to.
            began = origin + (_timing(data.get("start")) or 0) if is_view else origin
            entry = self._pages[key] = {"page": page, "origin": began, "is_view": is_view}
        url = view_url(data.get("url"), query_names=True) if is_view else _short_url(data.get("url"))
        entry["url"] = url
        title = self._text(data.get("title"), 200)
        if title:
            entry["title"] = title
        for field, reader in (("status", _status), ("response", _timing), ("ready", _timing),
                              ("load", _timing), ("paint", _timing), ("requests", _count),
                              ("bytes", _count)):
            value = reader(data.get(field))
            if value is not None:
                entry[field] = value
        self._latest[page] = entry
        if is_view:
            return
        # The document arrived, so it is no longer a page with no response.
        for request, waiting in list(self._pending.items()):
            if waiting["url"] == url:
                del self._pending[request]

    def _on_request(self, request):
        if request.is_navigation_request() and _is_top_level(request):
            self._pending[request] = {
                "url": _short_url(request.url), "start": time.time() * 1000,
                "page": _page_of(request),
            }

    def _on_response(self, response):
        request = response.request
        if request.resource_type in ("xhr", "fetch"):
            self._api_status[request] = response.status

    def _on_finished(self, request):
        self._pending.pop(request, None)
        if request.resource_type not in ("xhr", "fetch"):
            return
        timing = request.timing
        elapsed = timing.get("responseEnd", -1)
        if elapsed < 0:
            elapsed = timing.get("responseStart", -1)
        status = self._api_status.pop(request, None)
        call = self._api_entry(request, timing.get("startTime"))
        if call is None:
            return
        call["calls"] += 1
        if elapsed >= 0:
            call["durations"].append(elapsed)
        if status is not None:
            call["status"] = status
            if status >= 400:
                call["failed"] += 1

    def _on_failed(self, request):
        waiting = self._pending.pop(request, None)
        self._api_status.pop(request, None)
        error = request.failure or "Request failed"
        # Aborted is normal: a download, or a newer navigation replacing this one.
        if "ERR_ABORTED" in error:
            return
        if waiting is not None:
            self._failed_loads.append({**waiting, "error": error[:300]})
        elif request.resource_type in ("xhr", "fetch"):
            call = self._api_entry(request, time.time() * 1000)
            if call is not None:
                call["calls"] += 1
                call["failed"] += 1

    def _api_entry(self, request, started):
        step = self._step_at(started) if started else None
        if step is None:
            return None
        page = _page_of(request)
        url = self._text(_short_url(request.url), 1000)
        key = (step[1], self._opened_as(page) if page else OPENED_OTHER, request.method, url)
        return self._api.setdefault(
            key, {"calls": 0, "failed": 0, "durations": [], "status": None}
        )

    def _waiting(self):
        if self._pending:
            return True
        return any(
            "load" not in entry and not page.is_closed() for page, entry in self._latest.items()
        )

    def settle(self, context):
        """Give results still in flight a moment to arrive before the context is
        closed. Always waits the minimum, because the last click may have opened a
        pop-up that Playwright has not told us about yet."""
        try:
            started = time.monotonic()
            while True:
                pages = [page for page in context.pages if not page.is_closed()]
                if not pages:
                    return
                pages[0].wait_for_timeout(100)
                self._classify_new_pages()
                elapsed = (time.monotonic() - started) * 1000
                if elapsed >= config.PERF_SETTLE_MAX_MS:
                    return
                if elapsed >= config.PERF_SETTLE_MIN_MS and not self._waiting():
                    return
        except Exception as exc:
            log.debug("Stopped waiting for performance results: %s", exc)

    def _problem_rows(self, run):
        """Navigations that never produced a document."""
        rows = [(load, load["error"]) for load in self._failed_loads]
        rows += [(load, "No response before the test ended") for load in self._pending.values()]
        for load, error in rows:
            step = self._step_at(load["start"])
            if step is None:
                continue
            yield load["start"], PagePerformance(
                test_run_id=run.id, tc_result_id=step[1], step_order=step[2],
                step_keyword=step[3], url=self._text(load["url"], 1000), error=self._mask(error),
                opened_as=self._opened_as(load["page"]) if load["page"] else OPENED_TAB,
            )

    def _page_rows(self, run):
        for entry in self._pages.values():
            step = self._step_at(entry["origin"])
            if step is None:
                continue
            yield entry["origin"], PagePerformance(
                test_run_id=run.id, tc_result_id=step[1], step_order=step[2],
                step_keyword=step[3],
                opened_as=OPENED_SPA if entry["is_view"] else self._opened_as(entry["page"]),
                url=self._text(entry.get("url"), 1000), title=entry.get("title"),
                http_status=entry.get("status"), response_ms=entry.get("response"),
                first_paint_ms=entry.get("paint"), dom_ready_ms=entry.get("ready"),
                load_ms=entry.get("load"), request_count=entry.get("requests"),
                transfer_bytes=entry.get("bytes"),
            )

    def _api_rows(self, run):
        for (tc_result_id, opened_as, method, url), call in self._api.items():
            durations = call["durations"]
            yield ApiPerformance(
                test_run_id=run.id, tc_result_id=tc_result_id, opened_as=opened_as,
                method=method[:10], url=url, http_status=call["status"], calls=call["calls"],
                failed_calls=call["failed"],
                average_ms=round(sum(durations) / len(durations), 1) if durations else None,
                slowest_ms=round(max(durations), 1) if durations else None,
            )

    def save(self, run):
        pages = list(self._page_rows(run)) + list(self._problem_rows(run))
        pages.sort(key=lambda item: item[0])
        for _when, row in pages:
            run.page_metrics.append(row)
        # A polling screen can make thousands of distinct calls: keep the slow ones.
        calls = sorted(self._api_rows(run), key=lambda c: c.slowest_ms or 0, reverse=True)
        for row in calls[:config.PERF_MAX_API_ROWS]:
            run.api_metrics.append(row)
        if len(calls) > config.PERF_MAX_API_ROWS:
            run.add_note(
                f"Performance: {len(calls)} different AJAX/API calls were made; "
                f"only the {config.PERF_MAX_API_ROWS} slowest are listed."
            )
        if self._dropped_pages:
            run.add_note(
                f"Performance: only the first {config.PERF_MAX_PAGE_ROWS} page loads are listed."
            )

