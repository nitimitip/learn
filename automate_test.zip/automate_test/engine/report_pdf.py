"""The PDF run report: a summary page, then one numbered section per topic. Performance
tables are wide, so that section is landscape."""
import io
import os
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.graphics.charts.doughnut import Doughnut
from reportlab.graphics.shapes import Drawing, String
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFError, TTFont
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import (
    BaseDocTemplate, CondPageBreak, Frame, Image, KeepTogether, NextPageTemplate, PageBreak,
    PageTemplate, Paragraph, Spacer, Table, TableStyle,
)

from engine.report_generator import (
    BAND, BRAND, BRAND_DARK, BRAND_SOFT, COLOR_FAIL, COLOR_PASS, COLOR_SKIP, INK, LINE, MUTED,
    PERFORMANCE_NOTE, clean_text, fit_within, format_bytes, format_dt, format_duration, format_ms,
    outcome_of, parse_variables, pass_rate, performance_summary, run_details, run_issues,
    screenshot_image, tone_of, verdict_sentence, evidence_steps,
)

MARGIN = 15 * mm
TOP_MARGIN = 21 * mm
BOTTOM_MARGIN = 17 * mm
FIRST_PAGE_TOP = 38 * mm
PORTRAIT_WIDTH = A4[0] - 2 * MARGIN
LANDSCAPE_WIDTH = A4[1] - 2 * MARGIN
TABLE_TEXT_LIMIT = 1200  # a table row cannot span pages, so its text must stay short
BLOCK_TEXT_LIMIT = 4000
GLANCE_ISSUES = 8
SHOT_BOX = (PORTRAIT_WIDTH, 125 * mm)


def _load_fonts():
    """Segoe UI or Arial when the server has them, embedded in the file so that text in
    other alphabets shows correctly. The built-in fonts only cover Western text."""
    folder = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
    for regular, bold in (("segoeui.ttf", "segoeuib.ttf"), ("arial.ttf", "arialbd.ttf")):
        try:
            pdfmetrics.registerFont(TTFont("ReportFont", str(folder / regular)))
            pdfmetrics.registerFont(TTFont("ReportFont-Bold", str(folder / bold)))
        except (OSError, TTFError):
            continue
        return "ReportFont", "ReportFont-Bold"
    return "Helvetica", "Helvetica-Bold"


FONT, FONT_BOLD = _load_fonts()


def _hex(value):
    return colors.HexColor("#" + value.lstrip("#"))


def _style(name, size=8.5, font=None, color=INK, **extra):
    return ParagraphStyle(
        name, fontName=font or FONT, fontSize=size, leading=extra.pop("leading", size * 1.28),
        textColor=_hex(color), **extra,
    )


BODY = _style("body", 9.5, spaceAfter=4)
CELL = _style("cell", 7.8)
CELL_BOLD = _style("cell-bold", 7.8, FONT_BOLD)
CELL_MUTED = _style("cell-muted", 7.8, color=MUTED)
HEAD = _style("head", 7.8, FONT_BOLD, BRAND_DARK)
NOTE = _style("note", 8, color=MUTED, spaceBefore=6)
H1 = _style("h1", 14, FONT_BOLD, BRAND_DARK, spaceBefore=4, spaceAfter=7)
H2 = _style("h2", 10.5, FONT_BOLD, INK, spaceBefore=9, spaceAfter=4)


def _text(value, style=CELL, limit=TABLE_TEXT_LIMIT):
    """A paragraph from captured text. Escaping stops it being read as markup."""
    text = clean_text(value)
    lines = text.split("\n")
    max_lines = limit // 40  # many short lines make a row just as tall as one long text
    if len(text) > limit or len(lines) > max_lines:
        text = "\n".join(lines[:max_lines])[:limit] + " ... (shortened: the Excel report has the full text)"
    return Paragraph(escape(text).replace("\n", "<br/>"), style)


def _status_cell(status):
    """Coloured status text; _grid fills the cell behind it."""
    tone = tone_of(status)
    cell = Paragraph(escape(clean_text(status)), _style("status", 7.6, FONT_BOLD, tone["ink"], alignment=TA_CENTER))
    cell.status_fill = tone["fill"]
    return cell


def _grid(rows, widths, repeat=1):
    """A striped table. Rows hold flowables; the first is the header."""
    table = Table(rows, colWidths=widths, repeatRows=repeat)
    commands = [
        ("BACKGROUND", (0, 0), (-1, 0), _hex(BRAND_SOFT)),
        ("LINEBELOW", (0, 0), (-1, 0), 0.9, _hex(BRAND)),
        ("LINEBELOW", (0, 1), (-1, -1), 0.3, _hex(LINE)),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    for index, row in enumerate(rows[1:], 1):
        if index % 2 == 0:
            commands.append(("BACKGROUND", (0, index), (-1, index), _hex(BAND)))
        for column, cell in enumerate(row):
            fill = getattr(cell, "status_fill", None)
            if fill:
                commands.append(("BACKGROUND", (column, index), (column, index), _hex(fill)))
    table.setStyle(TableStyle(commands))
    return table


def _heads(*names):
    return [Paragraph(name, HEAD) for name in names]


def _widths(fixed, total):
    """Column widths in mm, with the single 0 taking whatever is left of the page."""
    spare = total / mm - sum(fixed)
    return [(width or spare) * mm for width in fixed]


def _donut(run, size=118):
    drawing = Drawing(size, size)
    parts = [(run.passed_tests, COLOR_PASS), (run.failed_tests, COLOR_FAIL), (run.skipped_tests, COLOR_SKIP)]
    parts = [part for part in parts if part[0] > 0]
    if parts:
        chart = Doughnut()
        chart.x, chart.y, chart.width, chart.height = 4, 4, size - 8, size - 8
        chart.data = [count for count, _ in parts]
        chart.labels = None
        chart.innerRadiusFraction = 0.64
        chart.slices.strokeColor = colors.white
        chart.slices.strokeWidth = 1.2
        for index, (_, color) in enumerate(parts):
            chart.slices[index].fillColor = colors.HexColor(color)
        drawing.add(chart)
    rate = pass_rate(run)
    drawing.add(String(size / 2, size / 2 - 1, "-" if rate is None else f"{rate * 100:.0f}%",
                       textAnchor="middle", fontName=FONT_BOLD, fontSize=19, fillColor=_hex(INK)))
    drawing.add(String(size / 2, size / 2 - 14, "pass rate", textAnchor="middle",
                       fontName=FONT, fontSize=7.5, fillColor=_hex(MUTED)))
    return drawing


def _verdict_banner(run):
    outcome = outcome_of(run)
    banner = Table([[
        Paragraph(escape(outcome.upper()), _style("verdict", 15, FONT_BOLD, "FFFFFF")),
        Paragraph(escape(verdict_sentence(run)), _style("verdict-text", 10.5, color="FFFFFF")),
    ]], colWidths=[36 * mm, PORTRAIT_WIDTH - 36 * mm])
    banner.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), _hex(tone_of(outcome)["solid"])),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 9),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 9),
    ]))
    return banner


def _kpi_tiles(run):
    tiles = [
        ("Total", run.total_tests, BRAND), ("Passed", run.passed_tests, COLOR_PASS),
        ("Failed", run.failed_tests, COLOR_FAIL), ("Skipped/Blocked", run.skipped_tests, COLOR_SKIP),
        ("Duration", format_duration(run.duration_sec), BRAND_DARK),
    ]
    value_style = _style("kpi", 17, FONT_BOLD, "FFFFFF", alignment=TA_CENTER, leading=21)
    label_style = _style("kpi-label", 7.8, color="FFFFFF", alignment=TA_CENTER)
    table = Table(
        [[Paragraph(str(value), value_style) for _, value, _ in tiles],
         [Paragraph(label, label_style) for label, _, _ in tiles]],
        colWidths=[PORTRAIT_WIDTH / len(tiles)] * len(tiles),
    )
    commands = [("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, 0), 7),
                ("BOTTOMPADDING", (0, 0), (-1, 0), 1), ("TOPPADDING", (0, 1), (-1, 1), 0),
                ("BOTTOMPADDING", (0, 1), (-1, 1), 8)]
    for index, (_, _, color) in enumerate(tiles):
        commands.append(("BACKGROUND", (index, 0), (index, 1), _hex(color)))
        if index:
            commands.append(("LINEBEFORE", (index, 0), (index, 1), 2, colors.white))
    table.setStyle(TableStyle(commands))
    return table


def _details_block(run):
    legend = Table([
        [Paragraph(label, CELL), Paragraph(str(count), CELL_BOLD)]
        for label, count in [("Passed", run.passed_tests), ("Failed", run.failed_tests),
                             ("Skipped/Blocked", run.skipped_tests)]
    ], colWidths=[28 * mm, 10 * mm])
    legend_style = [("TOPPADDING", (0, 0), (-1, -1), 1.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5),
                    ("LEFTPADDING", (0, 0), (-1, -1), 6)]
    for index, color in enumerate((COLOR_PASS, COLOR_FAIL, COLOR_SKIP)):
        legend_style.append(("LINEBEFORE", (0, index), (0, index), 3, colors.HexColor(color)))
    legend.setStyle(TableStyle(legend_style))
    chart_column = 46 * mm
    details = Table(
        [[Paragraph(label, CELL_MUTED), _text(value, CELL_BOLD)] for label, value in run_details(run)],
        colWidths=[27 * mm, PORTRAIT_WIDTH - chart_column - 27 * mm],
    )
    details.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, -1), 0.3, _hex(LINE)),
        ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5),
    ]))
    layout = Table([[[_donut(run), Spacer(1, 4), legend], details]], colWidths=[chart_column, PORTRAIT_WIDTH - chart_column])
    layout.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                                ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    return layout


def _perf_tiles(perf, width):
    tiles = [
        ("Pages measured", perf["pages"]), ("Average load", format_ms(perf["average_load"])),
        ("Slowest load", format_ms(perf["slowest_load"])),
        ("New tabs / pop-ups", f"{perf['new_tabs']} / {perf['popups']}"),
        ("Needs attention", perf["needs_attention"]),
    ]
    value_style = _style("perf", 12, FONT_BOLD, BRAND_DARK, alignment=TA_CENTER, leading=15)
    label_style = _style("perf-label", 7.5, color=MUTED, alignment=TA_CENTER)
    table = Table(
        [[Paragraph(str(value), value_style) for _, value in tiles],
         [Paragraph(label, label_style) for label, _ in tiles]],
        colWidths=[width / len(tiles)] * len(tiles),
    )
    table.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.5, _hex(LINE)), ("BACKGROUND", (0, 0), (-1, -1), _hex(BAND)),
        ("TOPPADDING", (0, 0), (-1, 0), 6), ("BOTTOMPADDING", (0, 1), (-1, 1), 6),
    ]))
    return table


def _summary_section(run, issues):
    story = [_verdict_banner(run), Spacer(1, 7)]
    if run.notes:
        tone = tone_of("Aborted")
        note = Table([[_text(run.notes, _style("run-note", 8.5, color=tone["ink"]))]], colWidths=[PORTRAIT_WIDTH])
        note.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), _hex(tone["fill"]))]))
        story += [note, Spacer(1, 7)]
    story += [_kpi_tiles(run), Spacer(1, 6), Paragraph("Run details and result", H2), _details_block(run)]
    story.append(Paragraph("Needs attention", H2))
    if issues:
        rows = [_heads("Test case", "Status", "Problem")]
        for issue in issues[:GLANCE_ISSUES]:
            rows.append([_text(issue.case, CELL_BOLD), _status_cell(issue.status), _text(issue.problem, limit=220)])
        story.append(_grid(rows, _widths([52, 28, 0], PORTRAIT_WIDTH)))
        if len(issues) > GLANCE_ISSUES:
            story.append(Paragraph(f"{len(issues) - GLANCE_ISSUES} more in section 2.", NOTE))
    else:
        story.append(Paragraph("Every test case passed.", BODY))
    story += [Paragraph("Performance at a glance", H2), _perf_tiles(performance_summary(run), PORTRAIT_WIDTH)]
    return story


def _cases_section(run):
    rows = [_heads("#", "Test case", "Status", "Steps", "Duration", "Reason")]
    for case in run.case_results:
        rows.append([
            _text(case.execution_order), _text(case.test_case_name, CELL_BOLD), _status_cell(case.status),
            _text(len(case.step_results)), _text(format_duration(case.duration_sec)), _text(case.error_message),
        ])
    return [Paragraph("1. Test case results", H1), _grid(rows, _widths([8, 54, 28, 11, 16, 0], PORTRAIT_WIDTH))]


def _issues_section(issues):
    story = [Paragraph("2. Issues and failure evidence", H1)]
    if not issues:
        return story + [Paragraph("Every test case passed.", BODY)]
    for issue in issues:
        tone = tone_of(issue.status)
        status = Paragraph(escape(issue.status), _style("issue-status", 8, FONT_BOLD, tone["ink"], alignment=TA_CENTER))
        title = Table([[_text(f"{issue.order}. {issue.case}", _style("issue", 9.5, FONT_BOLD)), status]],
                      colWidths=[PORTRAIT_WIDTH - 30 * mm, 30 * mm])
        title.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), _hex(tone["fill"])),
            ("LINEBEFORE", (0, 0), (0, 0), 3, _hex(tone["solid"])),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]))
        block = [title, Spacer(1, 3)]
        if issue.step:
            where = f"Step {issue.step.step_order}: {issue.step.action_keyword}"
            if issue.step.description:
                where += f" - {issue.step.description}"
            block += [_text(where, CELL_BOLD), Spacer(1, 2)]
        story.append(KeepTogether(block))
        story.append(_text(issue.problem, _style("problem", 8, color=tone["ink"]), BLOCK_TEXT_LIMIT))
        if issue.step and issue.step.screenshot_base64:
            shot = screenshot_image(issue.step)
            if shot:
                data, width, height = shot
                shown_width, shown_height = fit_within(width, height, *SHOT_BOX)
                story += [Spacer(1, 4), Image(io.BytesIO(data), shown_width, shown_height)]
            else:
                story.append(Paragraph("The failure screenshot could not be read.", NOTE))
        story.append(Spacer(1, 11))
    return story


def _steps_section(run):
    story = [Paragraph("3. Step details", H1)]
    widths = _widths([8, 36, 42, 13, 0, 29], PORTRAIT_WIDTH)
    with_steps = [case for case in run.case_results if case.step_results]
    if not with_steps:
        return story + [Paragraph("No steps have run.", BODY)]
    for case in with_steps:
        rows = [_heads("#", "Keyword", "Description", "Status", "Actual value / error", "Time")]
        for step in case.step_results:
            detail = "\n".join(filter(None, [clean_text(step.actual_value), clean_text(step.error_details)]))
            rows.append([_text(step.step_order), _text(step.action_keyword), _text(step.description),
                         _status_cell(step.status), _text(detail), _text(format_dt(step.timestamp), CELL_MUTED)])
        story += [CondPageBreak(30 * mm), _text(f"{case.execution_order}. {case.test_case_name}", H2), _grid(rows, widths)]
    return story


def _performance_section(run):
    story = [Paragraph("4. Performance", H1)]
    if not (run.page_metrics or run.api_metrics):
        return story + [Paragraph("No page loads were recorded for this run.", BODY)]
    story.append(_perf_tiles(performance_summary(run), LANDSCAPE_WIDTH))
    if run.page_metrics:
        rows = [_heads("Test case", "Step", "Opened as", "Page", "HTTP", "Response", "First paint",
                       "Content ready", "Full load", "Reqs", "Size", "Rating")]
        for page in run.page_metrics:
            address = "\n".join(filter(None, [clean_text(page.title), clean_text(page.url), clean_text(page.error)]))
            rows.append([
                _text(page.case_result.test_case_name), _text(f"{page.step_order} {page.step_keyword}"),
                _text(page.opened_as), _text(address), _text(page.http_status or "-"),
                _text(format_ms(page.response_ms)), _text(format_ms(page.first_paint_ms)),
                _text(format_ms(page.dom_ready_ms)), _text(format_ms(page.load_ms)),
                _text("-" if page.request_count is None else page.request_count),
                _text(format_bytes(page.transfer_bytes)), _status_cell(page.rating),
            ])
        story += [Paragraph("Page loads", H2),
                  _grid(rows, _widths([32, 28, 17, 0, 10, 17, 15, 15, 15, 11, 14, 19], LANDSCAPE_WIDTH))]
    if run.api_metrics:
        rows = [_heads("Test case", "Opened as", "Method", "Address", "HTTP", "Calls", "Failed", "Average", "Slowest", "Rating")]
        for call in sorted(run.api_metrics, key=lambda c: c.slowest_ms or 0, reverse=True):
            rows.append([
                _text(call.case_result.test_case_name), _text(call.opened_as), _text(call.method), _text(call.url),
                _text(call.http_status or "-"), _text(call.calls), _text(call.failed_calls),
                _text(format_ms(call.average_ms)), _text(format_ms(call.slowest_ms)), _status_cell(call.rating),
            ])
        story += [Paragraph("AJAX / API calls, slowest first", H2),
                  _grid(rows, _widths([40, 17, 15, 0, 10, 10, 11, 16, 16, 19], LANDSCAPE_WIDTH))]
    story.append(Paragraph(escape(PERFORMANCE_NOTE), NOTE))
    return story


def _variables_section(run):
    story = [Paragraph("5. Captured runtime variables", H1)]
    variables = parse_variables(run)
    if not variables:
        return story + [Paragraph("No variables were captured.", BODY)]
    rows = [_heads("Variable", "Value")]
    rows += [[_text(name, CELL_BOLD), _text(value)] for name, value in variables.items()]
    return story + [_grid(rows, _widths([50, 0], PORTRAIT_WIDTH))]


def _evidence_section(evidence):
    """Proof-of-pass screenshots taken by CAPTURE_SCREENSHOT. Only added when there are some."""
    story = [Paragraph("6. Proof-of-pass screenshots", H1)]
    for entry in evidence:
        step = entry.step
        where = f"{entry.order}. {entry.case} - step {step.step_order}"
        if step.description:
            where += f": {step.description}"
        block = [_text(where, CELL_BOLD)]
        if step.actual_value:
            block.append(_text(step.actual_value, CELL_MUTED))
        shot = screenshot_image(step)
        if shot:
            data, width, height = shot
            shown_width, shown_height = fit_within(width, height, *SHOT_BOX)
            block += [Spacer(1, 4), Image(io.BytesIO(data), shown_width, shown_height)]
        else:
            block.append(Paragraph("The screenshot could not be read.", NOTE))
        story += [KeepTogether(block), Spacer(1, 11)]
    return story


class _NumberedCanvas(Canvas):
    """Holds pages back until the end, so the footer can say 'Page 2 of 7'."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._held_pages = []

    def showPage(self):
        self._held_pages.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total = len(self._held_pages)
        for state in self._held_pages:
            self.__dict__.update(state)
            self.setFont(FONT, 7.5)
            self.setFillColor(_hex(MUTED))
            self.drawRightString(self._pagesize[0] - MARGIN, 9 * mm, f"Page {self._pageNumber} of {total}")
            super().showPage()
        super().save()


def _fit_line(text, width, font, size):
    """Shorten one line of text to fit a page header."""
    text = clean_text(text).replace("\n", " ")
    while text and pdfmetrics.stringWidth(text, font, size) > width:
        text = text[:-1]
    return text


def _draw_footer(canvas, run):
    canvas.setStrokeColor(_hex(LINE))
    canvas.setLineWidth(0.5)
    canvas.line(MARGIN, 12.5 * mm, canvas._pagesize[0] - MARGIN, 12.5 * mm)
    canvas.setFont(FONT, 7.5)
    canvas.setFillColor(_hex(MUTED))
    canvas.drawString(MARGIN, 9 * mm, f"QA Automation Portal  |  Run #{run.number}  |  All times are server local time")


def _first_page(run):
    def draw(canvas, _document):
        canvas.saveState()
        width, height = canvas._pagesize
        canvas.setFillColor(_hex(BRAND))
        canvas.rect(0, height - 31 * mm, width, 31 * mm, stroke=0, fill=1)
        canvas.setFillColor(_hex(BRAND_DARK))
        canvas.rect(0, height - 33 * mm, width, 2 * mm, stroke=0, fill=1)
        canvas.setFillColor(colors.white)
        canvas.setFont(FONT_BOLD, 21)
        canvas.drawString(MARGIN, height - 15 * mm, "Test Run Report")
        canvas.setFont(FONT, 10.5)
        canvas.drawString(MARGIN, height - 23 * mm,
                          _fit_line(run.application.name, width - 2 * MARGIN - 25 * mm, FONT, 10.5))
        canvas.setFont(FONT_BOLD, 10.5)
        canvas.drawRightString(width - MARGIN, height - 23 * mm, f"Run #{run.number}")
        _draw_footer(canvas, run)
        canvas.restoreState()
    return draw


def _later_page(run):
    def draw(canvas, _document):
        canvas.saveState()
        width, height = canvas._pagesize
        canvas.setFont(FONT_BOLD, 8.5)
        canvas.setFillColor(_hex(BRAND_DARK))
        canvas.drawString(MARGIN, height - 12 * mm, "Test Run Report")
        canvas.setFont(FONT, 8.5)
        canvas.setFillColor(_hex(MUTED))
        heading = _fit_line(f"{run.application.name}  |  Run #{run.number}", width * 0.6, FONT, 8.5)
        canvas.drawRightString(width - MARGIN, height - 12 * mm, heading)
        canvas.setStrokeColor(_hex(BRAND))
        canvas.setLineWidth(1)
        canvas.line(MARGIN, height - 14.5 * mm, width - MARGIN, height - 14.5 * mm)
        _draw_footer(canvas, run)
        canvas.restoreState()
    return draw


def render_pdf(run):
    """The report as PDF bytes."""
    output = io.BytesIO()
    document = BaseDocTemplate(
        output, pagesize=A4, title=f"Test Run #{run.number} - {clean_text(run.application.name)}",
        author="QA Automation Portal", subject="Test run report",
    )
    wide = landscape(A4)
    flush = {"leftPadding": 0, "rightPadding": 0, "topPadding": 0, "bottomPadding": 0}

    def frame(width, height):
        return Frame(MARGIN, BOTTOM_MARGIN, width, height, **flush)

    document.addPageTemplates([
        PageTemplate("first", [frame(PORTRAIT_WIDTH, A4[1] - FIRST_PAGE_TOP - BOTTOM_MARGIN)],
                     onPage=_first_page(run), pagesize=A4),
        PageTemplate("portrait", [frame(PORTRAIT_WIDTH, A4[1] - TOP_MARGIN - BOTTOM_MARGIN)],
                     onPage=_later_page(run), pagesize=A4),
        PageTemplate("wide", [frame(LANDSCAPE_WIDTH, wide[1] - TOP_MARGIN - BOTTOM_MARGIN)],
                     onPage=_later_page(run), pagesize=wide),
    ])
    issues = run_issues(run)
    story = _summary_section(run, issues)
    story += [NextPageTemplate("portrait"), PageBreak()]
    story += _cases_section(run) + [Spacer(1, 12)] + _issues_section(issues)
    story += [CondPageBreak(60 * mm)] + _steps_section(run)
    story += [NextPageTemplate("wide"), PageBreak()] + _performance_section(run)
    story += [NextPageTemplate("portrait"), PageBreak()] + _variables_section(run)
    evidence = evidence_steps(run)
    if evidence:
        story += [PageBreak()] + _evidence_section(evidence)
    document.build(story, canvasmaker=_NumberedCanvas)
    return output.getvalue()
