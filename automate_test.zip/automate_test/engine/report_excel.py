"""The Excel run report: a colour-coded Summary sheet, then one sheet per section."""
import io

from openpyxl import Workbook
from openpyxl.chart import DoughnutChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.chart.series import DataPoint
from openpyxl.drawing.image import Image as SheetImage
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from engine.report_generator import (
    BAND, BRAND, BRAND_DARK, BRAND_SOFT, COLOR_FAIL, COLOR_PASS, COLOR_SKIP, INK, LINE, MUTED,
    PERFORMANCE_NOTE, clean_text, fit_within, format_dt, format_duration, format_ms, outcome_of,
    evidence_steps, parse_variables, pass_rate, performance_summary, run_details, run_issues,
    screenshot_image, tone_of, verdict_sentence,
)

MAX_CELL_TEXT = 32000  # Excel holds 32767 characters in a cell
FORMULA_START = ("=", "+", "-", "@")
SCREENSHOT_BOX = (480, 360)  # pixels
MAX_ROW_POINTS = 400  # Excel's limit is 409
GLANCE_ISSUES = 10
EDGE = Side(style="thin", color=LINE)
BOX = Border(left=EDGE, right=EDGE, top=EDGE, bottom=EDGE)
HEADER_ROW = 4
FIRST_COLUMN, LAST_COLUMN = 2, 7  # the Summary sheet uses B to G
WHITE = "FFFFFF"

SECTIONS = [
    ("Test Cases", "One row per test case: result, step counts and duration"),
    ("Issues", "Everything that did not pass, with reasons and screenshots"),
    ("Step Details", "Every step that ran, in order"),
    ("Page Performance", "Timing of each page, tab and pop-up"),
    ("API Performance", "AJAX and API calls, slowest first"),
    ("Variables", "Values captured during the run"),
]
# Listed, and its sheet added, only when the run captured proof-of-pass screenshots.
EVIDENCE_SECTION = ("Evidence", "Screenshots taken by CAPTURE_SCREENSHOT on passing steps")


def _fill(color):
    return PatternFill("solid", start_color=color, end_color=color)


def _put(sheet, row, column, value, **style):
    """Write a value. Captured page text is forced to plain text so Excel can never
    run it as a formula."""
    cell = sheet.cell(row=row, column=column)
    if isinstance(value, str):
        text = clean_text(value)[:MAX_CELL_TEXT]
        cell.value = text
        cell.data_type = "s"
        if text.startswith(FORMULA_START):
            cell.quotePrefix = True
    else:
        cell.value = value
    for name, setting in style.items():
        setattr(cell, name, setting)
    return cell


def _band_row(sheet, row, first, last, value, color, font, height=None):
    """A merged, filled row."""
    for column in range(first, last + 1):
        sheet.cell(row=row, column=column).fill = _fill(color)
    _put(sheet, row, first, value, font=font,
         alignment=Alignment(horizontal="left", vertical="center", wrap_text=True, indent=1))
    sheet.merge_cells(start_row=row, start_column=first, end_row=row, end_column=last)
    if height:
        sheet.row_dimensions[row].height = height


def _merged_cell(sheet, row, first, last, value, **style):
    """A bordered value across several columns. Excel cannot auto-fit these rows."""
    for column in range(first, last + 1):
        sheet.cell(row=row, column=column).border = BOX
    _put(sheet, row, first, value, border=BOX, **style)
    sheet.merge_cells(start_row=row, start_column=first, end_row=row, end_column=last)


def _estimated_height(text, chars_per_line, minimum=20):
    lines = sum(len(part) // chars_per_line + 1 for part in clean_text(text).split("\n"))
    return min(max(minimum, lines * 15 + 5), MAX_ROW_POINTS)


def _page_setup(sheet, run, landscape=True):
    sheet.sheet_view.showGridLines = False
    sheet.page_setup.orientation = "landscape" if landscape else "portrait"
    sheet.page_setup.paperSize = sheet.PAPERSIZE_A4
    sheet.page_setup.fitToWidth = 1
    sheet.page_setup.fitToHeight = 0
    sheet.sheet_properties.pageSetUpPr.fitToPage = True
    sheet.print_options.horizontalCentered = True
    sheet.oddFooter.left.text = f"Run #{run.number}"
    sheet.oddFooter.center.text = "&A"
    sheet.oddFooter.right.text = "Page &P of &N"


def _table_sheet(workbook, run, title, subtitle, columns, rows, empty, note=None):
    """A section sheet: title band, then a filterable table.
    columns: (header, width, number format or None). A Status or Rating column is
    colour-coded, and a row may set tint to colour the whole row."""
    sheet = workbook.create_sheet(title)
    last = len(columns)
    _band_row(sheet, 1, 1, last, title, BRAND, Font(size=16, bold=True, color=WHITE), 30)
    _band_row(sheet, 2, 1, last, subtitle, BRAND_DARK, Font(size=10, color=WHITE), 20)
    if note:
        _put(sheet, 3, 1, note, font=Font(size=9, italic=True, color=MUTED),
             alignment=Alignment(wrap_text=True, vertical="center"))
        sheet.merge_cells(start_row=3, start_column=1, end_row=3, end_column=last)
        sheet.row_dimensions[3].height = 30
    for index, (header, width, _) in enumerate(columns, 1):
        sheet.column_dimensions[get_column_letter(index)].width = width
        _put(sheet, HEADER_ROW, index, header, fill=_fill(BRAND_SOFT), border=BOX,
             font=Font(bold=True, color=BRAND_DARK),
             alignment=Alignment(horizontal="center", vertical="center", wrap_text=True))
    sheet.row_dimensions[HEADER_ROW].height = 32
    if not rows:
        _band_row(sheet, HEADER_ROW + 1, 1, last, empty, BAND, Font(italic=True, color=MUTED), 24)
    for offset, row in enumerate(rows, 1):
        row_number = HEADER_ROW + offset
        tint = row.get("tint") or (BAND if offset % 2 == 0 else None)
        for index, value in enumerate(row["cells"], 1):
            header, _, number_format = columns[index - 1]
            cell = _put(sheet, row_number, index, value, border=BOX, font=Font(color=INK),
                        alignment=Alignment(vertical="top", wrap_text=True))
            if isinstance(value, int):
                cell.alignment = Alignment(horizontal="center", vertical="top")
            if tint:
                cell.fill = _fill(tint)
            if number_format and value is not None:
                cell.number_format = number_format
            if header in ("Status", "Rating") and isinstance(value, str):
                tone = tone_of(value)
                cell.fill = _fill(tone["fill"])
                cell.font = Font(bold=True, color=tone["ink"])
                cell.alignment = Alignment(horizontal="center", vertical="top", wrap_text=True)
    sheet.freeze_panes = sheet.cell(row=HEADER_ROW + 1, column=1)
    if rows:
        sheet.auto_filter.ref = f"A{HEADER_ROW}:{get_column_letter(last)}{HEADER_ROW + len(rows)}"
    sheet.print_title_rows = f"{HEADER_ROW}:{HEADER_ROW}"
    _page_setup(sheet, run)
    return sheet


def _section_heading(sheet, row, first, last, text):
    _band_row(sheet, row, first, last, text, BRAND, Font(bold=True, color=WHITE, size=11), 22)


def _kpi_tiles(sheet, row, run):
    tiles = [
        ("TOTAL TEST CASES", run.total_tests, BRAND, None),
        ("PASSED", run.passed_tests, COLOR_PASS[1:], None),
        ("FAILED", run.failed_tests, COLOR_FAIL[1:], None),
        ("SKIPPED / BLOCKED", run.skipped_tests, COLOR_SKIP[1:], None),
        ("PASS RATE", pass_rate(run), BRAND_DARK, "0%"),
        ("DURATION", format_duration(run.duration_sec), BRAND_DARK, None),
    ]
    for column, (label, value, color, number_format) in enumerate(tiles, FIRST_COLUMN):
        _put(sheet, row, column, label, fill=_fill(color), border=BOX,
             font=Font(size=9, bold=True, color=WHITE),
             alignment=Alignment(horizontal="center", vertical="center", wrap_text=True))
        cell = _put(sheet, row + 1, column, "-" if value is None else value, fill=_fill(color), border=BOX,
                    font=Font(size=20, bold=True, color=WHITE),
                    alignment=Alignment(horizontal="center", vertical="center"))
        if number_format:
            cell.number_format = number_format
    sheet.row_dimensions[row].height = 20
    sheet.row_dimensions[row + 1].height = 40


def _doughnut(sheet, first_row, anchor):
    """Native chart over the result breakdown table, so it stays editable."""
    chart = DoughnutChart()
    chart.add_data(Reference(sheet, min_col=6, min_row=first_row, max_row=first_row + 2))
    chart.set_categories(Reference(sheet, min_col=5, min_row=first_row, max_row=first_row + 2))
    chart.holeSize = 58
    chart.height, chart.width = 5.2, 9.8
    chart.legend.position = "r"
    series = chart.series[0]
    for index, color in enumerate((COLOR_PASS, COLOR_FAIL, COLOR_SKIP)):
        point = DataPoint(idx=index)
        point.graphicalProperties.solidFill = color[1:]
        point.graphicalProperties.line.solidFill = WHITE
        series.dPt.append(point)
    series.dLbls = DataLabelList()
    series.dLbls.showVal = True
    for hidden in ("showPercent", "showCatName", "showSerName", "showLegendKey", "showLeaderLines"):
        setattr(series.dLbls, hidden, False)
    sheet.add_chart(chart, anchor)


def _details_and_breakdown(sheet, row, run):
    """Run details on the left, result table and chart on the right. Returns the next free row."""
    _section_heading(sheet, row, 2, 4, "Run details")
    _section_heading(sheet, row, 5, 7, "Result breakdown")
    top = row + 1
    details = run_details(run)
    for current, (label, value) in enumerate(details, top):
        _put(sheet, current, 2, label, fill=_fill(BAND), border=BOX, font=Font(bold=True, color=MUTED),
             alignment=Alignment(vertical="top"))
        _merged_cell(sheet, current, 3, 4, value, font=Font(color=INK),
                     alignment=Alignment(wrap_text=True, vertical="top"))
        sheet.row_dimensions[current].height = _estimated_height(value, 38, minimum=19)
    total = run.total_tests
    breakdown = [("Passed", run.passed_tests, "Pass"), ("Failed", run.failed_tests, "Fail"),
                 ("Skipped/Blocked", run.skipped_tests, "Aborted")]
    centered = Alignment(horizontal="center", vertical="top")
    for current, (label, count, status) in enumerate(breakdown, top):
        tone = tone_of(status)
        _put(sheet, current, 5, label, fill=_fill(tone["fill"]), border=BOX, font=Font(bold=True, color=tone["ink"]),
             alignment=Alignment(vertical="top"))
        _put(sheet, current, 6, count, border=BOX, alignment=centered)
        share = _put(sheet, current, 7, count / total if total else 0, border=BOX, alignment=centered)
        share.number_format = "0%"
    if total:
        _doughnut(sheet, top, f"E{top + len(breakdown)}")
    return top + len(details) + 1


def _attention_table(sheet, row, issues):
    _section_heading(sheet, row, FIRST_COLUMN, LAST_COLUMN, "Needs attention")
    row += 1
    if not issues:
        tone = tone_of("Pass")
        _band_row(sheet, row, FIRST_COLUMN, LAST_COLUMN, "Every test case passed.", tone["fill"],
                  Font(bold=True, color=tone["ink"]), 22)
        return row + 2
    wrapped = Alignment(wrap_text=True, vertical="top")
    for issue in issues[:GLANCE_ISSUES]:
        tone = tone_of(issue.status)
        _put(sheet, row, 2, issue.status, fill=_fill(tone["fill"]), border=BOX,
             font=Font(bold=True, color=tone["ink"]),
             alignment=Alignment(horizontal="center", vertical="top", wrap_text=True))
        _merged_cell(sheet, row, 3, 4, issue.case, font=Font(bold=True, color=INK), alignment=wrapped)
        problem = issue.problem[:400]
        _merged_cell(sheet, row, 5, 7, problem, font=Font(color=INK), alignment=wrapped)
        sheet.row_dimensions[row].height = max(
            _estimated_height(problem, 56), _estimated_height(issue.case, 38)
        )
        row += 1
    if len(issues) > GLANCE_ISSUES:
        _band_row(sheet, row, FIRST_COLUMN, LAST_COLUMN, f"{len(issues) - GLANCE_ISSUES} more on the Issues sheet.",
                  BAND, Font(italic=True, color=MUTED), 20)
        row += 1
    return row + 1


def _performance_glance(sheet, row, run):
    _section_heading(sheet, row, FIRST_COLUMN, LAST_COLUMN, "Performance at a glance")
    perf = performance_summary(run)
    glance = [
        ("Pages measured", perf["pages"]), ("Average load", format_ms(perf["average_load"])),
        ("Slowest load", format_ms(perf["slowest_load"])), ("New tabs", perf["new_tabs"]),
        ("Pop-ups", perf["popups"]), ("Needs attention", perf["needs_attention"]),
    ]
    centered = Alignment(horizontal="center", wrap_text=True)
    for column, (label, value) in enumerate(glance, FIRST_COLUMN):
        _put(sheet, row + 1, column, label, fill=_fill(BAND), border=BOX,
             font=Font(size=9, bold=True, color=MUTED), alignment=centered)
        _put(sheet, row + 2, column, value, border=BOX, font=Font(size=12, bold=True, color=BRAND_DARK),
             alignment=centered)
    return row + 4


def _contents(sheet, row, sections):
    _section_heading(sheet, row, FIRST_COLUMN, LAST_COLUMN, "In this workbook")
    for current, (name, purpose) in enumerate(sections, row + 1):
        link = _put(sheet, current, 2, name, border=BOX)
        link.hyperlink = f"#'{name}'!A1"
        link.font = Font(color=BRAND, underline="single", bold=True)
        _merged_cell(sheet, current, 3, LAST_COLUMN, purpose, font=Font(color=INK))


def _summary_sheet(workbook, run, issues, sections):
    sheet = workbook.active
    sheet.title = "Summary"
    sheet.column_dimensions["A"].width = 2
    for column in range(FIRST_COLUMN, LAST_COLUMN + 1):
        sheet.column_dimensions[get_column_letter(column)].width = 18
    first, last = FIRST_COLUMN, LAST_COLUMN
    _band_row(sheet, 1, first, last, "Test Run Report", BRAND, Font(size=20, bold=True, color=WHITE), 36)
    _band_row(sheet, 2, first, last, f"{run.application.name}   |   Run #{run.number}", BRAND_DARK,
              Font(size=11, color=WHITE), 22)
    outcome = outcome_of(run)
    _band_row(sheet, 4, first, last, f"{outcome.upper()}:  {verdict_sentence(run)}", tone_of(outcome)["solid"],
              Font(size=13, bold=True, color=WHITE), 30)
    row = 6
    if run.notes:
        tone = tone_of("Aborted")
        _band_row(sheet, row, first, last, run.notes, tone["fill"], Font(color=tone["ink"]),
                  _estimated_height(run.notes, 110))
        row += 2
    _kpi_tiles(sheet, row, run)
    row = _details_and_breakdown(sheet, row + 3, run)
    row = _attention_table(sheet, row, issues)
    row = _performance_glance(sheet, row, run)
    _contents(sheet, row, sections)
    _page_setup(sheet, run, landscape=False)


def _case_rows(run):
    rows = []
    for case in run.case_results:
        passed = sum(step.status == "Pass" for step in case.step_results)
        rows.append({"cells": [
            case.execution_order, case.test_case_name, case.status, len(case.step_results), passed,
            len(case.step_results) - passed, case.duration_sec, case.error_message,
        ]})
    return rows


def _step_rows(run):
    failed_tint = tone_of("Fail")["fill"]
    return [{
        "tint": failed_tint if step.status == "Fail" else None,
        "cells": [
            case.execution_order, case.test_case_name, step.step_order, step.action_keyword,
            step.description, step.status, step.actual_value, step.error_details,
            format_dt(step.timestamp),
        ],
    } for case in run.case_results for step in case.step_results]


def _issues_sheet(workbook, run, issues):
    rows = [{"cells": [
        issue.order, issue.case, issue.status, issue.step.step_order if issue.step else None,
        issue.step.action_keyword if issue.step else None,
        issue.step.description if issue.step else None, issue.problem, None,
    ]} for issue in issues]
    sheet = _table_sheet(
        workbook, run, "Issues", "Every test case that did not pass, with its reason and failure screenshot",
        [("#", 7, None), ("Test case", 30, None), ("Status", 18, None), ("Step", 8, None),
         ("Keyword", 28, None), ("Description", 28, None), ("Problem", 55, None), ("Screenshot", 70, None)],
        rows, "Every test case passed.",
    )
    _picture_rows(sheet, issues, "H", HEADER_ROW + 1, lambda issue: issue.problem)


def _picture_rows(sheet, entries, column, first_row, text_of):
    """Put each entry's screenshot in its row, making the row tall enough to show it."""
    for row, entry in enumerate(entries, first_row):
        height = _estimated_height(text_of(entry), 55)
        shot = screenshot_image(entry.step)
        if shot:
            data, width, tall = shot
            picture = SheetImage(io.BytesIO(data))
            picture.width, picture.height = fit_within(width, tall, *SCREENSHOT_BOX)
            sheet.add_image(picture, f"{column}{row}")
            height = max(height, picture.height * 0.75 + 6)  # pixels to points
        sheet.row_dimensions[row].height = min(height, MAX_ROW_POINTS)


def _evidence_sheet(workbook, run, evidence):
    rows = [{"cells": [
        entry.order, entry.case, entry.step.step_order, entry.step.action_keyword,
        entry.step.description, entry.step.actual_value, None,
    ]} for entry in evidence]
    sheet = _table_sheet(
        workbook, run, EVIDENCE_SECTION[0], "Proof-of-pass screenshots, in the order the steps ran",
        [("#", 7, None), ("Test case", 30, None), ("Step", 8, None), ("Keyword", 22, None),
         ("Description", 30, None), ("Caption", 34, None), ("Screenshot", 70, None)],
        rows, "No screenshots were captured.",
    )
    _picture_rows(sheet, evidence, "G", HEADER_ROW + 1, lambda entry: entry.step.actual_value or "")


def _page_rows(run):
    return [{"cells": [
        page.case_result.test_case_name, page.step_order, page.step_keyword, page.opened_as,
        page.title, page.url, page.http_status, page.response_ms, page.first_paint_ms,
        page.dom_ready_ms, page.load_ms, page.request_count,
        None if page.transfer_bytes is None else page.transfer_bytes / 1024, page.rating, page.error,
    ]} for page in run.page_metrics]


def _api_rows(run):
    return [{"cells": [
        call.case_result.test_case_name, call.opened_as, call.method, call.url, call.http_status,
        call.calls, call.failed_calls, call.average_ms, call.slowest_ms, call.rating,
    ]} for call in sorted(run.api_metrics, key=lambda c: c.slowest_ms or 0, reverse=True)]


def render_excel(run):
    """The report as .xlsx bytes."""
    workbook = Workbook()
    workbook.properties.title = f"Test Run #{run.number} - {clean_text(run.application.name)}"
    workbook.properties.creator = "QA Automation Portal"
    issues = run_issues(run)
    evidence = evidence_steps(run)
    _summary_sheet(workbook, run, issues, SECTIONS + ([EVIDENCE_SECTION] if evidence else []))
    subtitle = f"{run.application.name}   |   Run #{run.number}"
    _table_sheet(
        workbook, run, "Test Cases", subtitle,
        [("#", 7, None), ("Test case", 42, None), ("Status", 18, None), ("Steps run", 10, None),
         ("Steps passed", 10, None), ("Steps failed", 10, None), ("Duration (s)", 11, "0.0"), ("Reason", 70, None)],
        _case_rows(run), "No test cases in this run.",
    )
    _issues_sheet(workbook, run, issues)
    _table_sheet(
        workbook, run, "Step Details", subtitle,
        [("#", 7, None), ("Test case", 30, None), ("Step", 8, None), ("Keyword", 28, None),
         ("Description", 34, None), ("Status", 11, None), ("Actual value", 44, None),
         ("Error details", 50, None), ("Time", 20, None)],
        _step_rows(run), "No steps have run.",
    )
    _table_sheet(
        workbook, run, "Page Performance", subtitle,
        [("Test case", 26, None), ("Step", 8, None), ("Keyword", 24, None), ("Opened as", 11, None),
         ("Page title", 26, None), ("Address", 44, None), ("HTTP status", 9, None),
         ("Response (ms)", 10, "#,##0"), ("First paint (ms)", 10, "#,##0"), ("Content ready (ms)", 10, "#,##0"),
         ("Full load (ms)", 10, "#,##0"), ("Requests", 9, None), ("Size (KB)", 10, "#,##0"),
         ("Rating", 12, None), ("Error", 36, None)],
        _page_rows(run), "No page loads were recorded.", note=PERFORMANCE_NOTE,
    )
    _table_sheet(
        workbook, run, "API Performance", subtitle,
        [("Test case", 28, None), ("Opened as", 11, None), ("Method", 10, None), ("Address", 60, None),
         ("HTTP status", 9, None), ("Calls", 8, None), ("Failed", 9, None), ("Average (ms)", 10, "#,##0"),
         ("Slowest (ms)", 10, "#,##0"), ("Rating", 12, None)],
        _api_rows(run), "No AJAX or API calls were recorded.", note=PERFORMANCE_NOTE,
    )
    _table_sheet(
        workbook, run, "Variables", subtitle, [("Variable", 32, None), ("Value", 90, None)],
        [{"cells": [name, "" if value is None else str(value)]} for name, value in parse_variables(run).items()],
        "No variables were captured.",
    )
    if evidence:
        _evidence_sheet(workbook, run, evidence)
    output = io.BytesIO()
    workbook.save(output)
    return output.getvalue()
