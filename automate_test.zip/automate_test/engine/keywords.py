"""Action keyword registry, step validation, locator resolution and execution."""
import operator
import re
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Callable, Optional
from urllib.parse import urljoin, urlsplit

from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import expect

import config
from engine.performance import view_url

CALL_BLOCK = "CALL_BLOCK"
CALL_BLOCK_IF_VISIBLE = "CALL_BLOCK_IF_VISIBLE"
CALL_BLOCK_IF = "CALL_BLOCK_IF"
REPEAT_BLOCK = "REPEAT_BLOCK"
REPEAT_BLOCK_UNTIL = "REPEAT_BLOCK_UNTIL"
FRAME_SEPARATOR = "||"
# A backslash in front makes it a literal ||, for text that really contains one.
ESCAPED_FRAME_SEPARATOR = "\\||"
_FRAME_SPLIT_RE = re.compile(r"(?<!\\)\|\|")
LOCATOR_TYPES = [
    "id", "id_ends_with", "name", "test_id", "label", "placeholder", "role", "text", "title",
    "row_action", "css", "xpath",
]
# " @first", " @last" or " @2" at the end of a locator picks one of several matches. An
# escaped " \@2" never matches, because the character before the @ is not a space.
INDEX_SUFFIX_RE = re.compile(r"\s+@(first|last|\d+)$")
_ESCAPED_INDEX_RE = re.compile(r"(\s+)\\@(first|last|\d+)$")
# In XPath, "//a/ @first" is the attribute named first: after these, @ is not a suffix.
_XPATH_OPEN_END_RE = re.compile(r"(?:[/|(\[,=<>!+\-:]|\b(?:and|or|div|mod))$")
VARIABLE_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
# Built-in date tokens and the format of each. Only these take a day offset, as in
# {TODAY_DATE+7} or {TODAY_DMY-30}, so {ANY+1} in other text stays plain text as before.
DATE_TOKENS = {"TODAY_DATE": "%Y-%m-%d", "TODAY_DMY": "%d/%m/%Y", "TODAY_MDY": "%m/%d/%Y"}
_DATE_NAMES = "|".join(DATE_TOKENS)
TOKEN_RE = re.compile(r"\{((?:" + _DATE_NAMES + r")[+-]\d+|[A-Za-z_][A-Za-z0-9_]*)\}")
DATE_TOKEN_RE = re.compile(r"^(" + _DATE_NAMES + r")([+-]\d+)?$")

REQUIRED, OPTIONAL, UNUSED = "required", "optional", "none"


def _kw(category, locator, input_, help_, input_hint="", store=False):
    return {
        "category": category, "locator": locator, "input": input_, "help": help_,
        "input_hint": input_hint, "store": store,
    }


_NAV = "Navigation & Waits"
_FORM = "Form & Mouse Actions"
_VERIFY = "Assertions / Validations"
_STORE = "Data Extraction"
_REUSE = "Reusable Blocks"

KEYWORDS = {
    "NAVIGATE": _kw(_NAV, UNUSED, OPTIONAL, "Open a URL. Blank opens the Base URL; a relative path is joined to it.", "/orders or https://host/page"),
    "WAIT_SECONDS": _kw(_NAV, UNUSED, REQUIRED, "Pause for a fixed time. Prefer WAIT_FOR_ELEMENT.", "Seconds, e.g. 2"),
    "WAIT_FOR_ELEMENT": _kw(_NAV, REQUIRED, UNUSED, "Wait until the element is visible."),
    "SCROLL_TO": _kw(_NAV, OPTIONAL, OPTIONAL, "Scroll the element into view. With no locator, scroll the page: bottom, top, or a number of pixels such as 500 or -500.", "bottom, top, 500 or -500"),
    "SWITCH_TO_NEW_WINDOW": _kw(_NAV, UNUSED, OPTIONAL, "Carry on in a new tab or pop-up the application opened. Blank takes the newest; text picks the one whose address or title contains it.", "Part of the address or title"),
    "CLOSE_WINDOW": _kw(_NAV, UNUSED, UNUSED, "Close the current tab or pop-up and return to the window before it."),
    "SWITCH_TO_WINDOW": _kw(_NAV, UNUSED, REQUIRED, "Move to any open window without closing the current one: main, a number, or part of its address or title.", "main, 1, or part of the address or title"),
    "SWITCH_TO_FRAME": _kw(_NAV, REQUIRED, UNUSED, "Work inside this iframe: later steps search in it until SWITCH_TO_MAIN_FRAME, a new page or a window change."),
    "SWITCH_TO_MAIN_FRAME": _kw(_NAV, UNUSED, UNUSED, "Leave any iframe and work on the top-level page again."),
    "CLICK": _kw(_FORM, REQUIRED, UNUSED, "Click the element."),
    "CLICK_AND_SWITCH_WINDOW": _kw(_FORM, REQUIRED, OPTIONAL, "Click the element and carry on in the tab or pop-up the click opens. Text picks the new window whose address or title contains it.", "Optional: part of the address or title"),
    "DOUBLE_CLICK": _kw(_FORM, REQUIRED, UNUSED, "Double-click the element."),
    "HOVER": _kw(_FORM, REQUIRED, UNUSED, "Move the mouse over the element, for example to open a menu."),
    "DRAG_AND_DROP": _kw(_FORM, REQUIRED, REQUIRED, "Drag the element onto the destination given as locator type|locator value.", "css|#dropzone or label|Completed"),
    "CLICK_IF_VISIBLE": _kw(_FORM, REQUIRED, OPTIONAL, "Click the element if it appears in time, otherwise carry on. Blank waits 1.5 seconds.", "Seconds to wait, e.g. 3"),
    "FILL_IF_VISIBLE": _kw(_FORM, REQUIRED, OPTIONAL, "Fill the field if it appears within 1.5 seconds, otherwise carry on. Blank clears it.", "Text, or a {TOKEN}"),
    "PREPARE_DIALOG": _kw(_FORM, UNUSED, REQUIRED, "Choose the answer to the next browser pop-up: accept, dismiss, or accept|text for a prompt.", "accept, dismiss or accept|Some text"),
    "FILL": _kw(_FORM, REQUIRED, OPTIONAL, "Replace the field's content. Blank clears it.", "Text, or a {TOKEN}"),
    "TYPE_SEQUENTIALLY": _kw(_FORM, REQUIRED, REQUIRED, "Clear the field, then type one key at a time, so search-as-you-type, autocomplete and rich-text fields react to every key.", "Text, or a {TOKEN}"),
    "SELECT_DROPDOWN": _kw(_FORM, REQUIRED, REQUIRED, "Choose a <select> option by visible label or value.", "Option label or value"),
    "CHECK": _kw(_FORM, REQUIRED, UNUSED, "Tick a checkbox or radio button."),
    "UNCHECK": _kw(_FORM, REQUIRED, UNUSED, "Clear a checkbox."),
    "PRESS_KEY": _kw(_FORM, OPTIONAL, REQUIRED, "Press a key, on the element if given, otherwise on the page.", "Enter, Tab, Control+A"),
    "UPLOAD_FILE": _kw(_FORM, REQUIRED, REQUIRED, "Attach a file from the server's test_data folder, through a file input or a Browse button that opens the file picker.", "File name inside test_data"),
    "VERIFY_TEXT_CONTAINS": _kw(_VERIFY, OPTIONAL, REQUIRED, "Element text contains the value. No locator checks the whole page.", "Expected text"),
    "VERIFY_ELEMENT_VISIBLE": _kw(_VERIFY, REQUIRED, UNUSED, "Element is visible."),
    "VERIFY_ELEMENT_NOT_VISIBLE": _kw(_VERIFY, REQUIRED, UNUSED, "Element is hidden or not on the page at all, such as a deleted row, a closed dialog or a finished spinner."),
    "VERIFY_TEXT_NOT_PRESENT": _kw(_VERIFY, OPTIONAL, REQUIRED, "Element text does not contain the value. No locator checks the whole page.", "Text that must not appear"),
    "VERIFY_ELEMENT_ENABLED": _kw(_VERIFY, REQUIRED, UNUSED, "Element is enabled, so it can be clicked or typed into."),
    "VERIFY_ELEMENT_DISABLED": _kw(_VERIFY, REQUIRED, UNUSED, "Element is disabled, such as a Submit button before the form is complete."),
    "VERIFY_ELEMENT_COUNT": _kw(_VERIFY, REQUIRED, REQUIRED, "The number of elements the locator matches, such as table rows, meets the condition, retrying until the timeout.", "5, > 0, >= 1, < 10, == 5 or != 0"),
    "CAPTURE_SCREENSHOT": _kw(_VERIFY, OPTIONAL, OPTIONAL, "Save a screenshot on this passing step as evidence: of the element if a locator is given, otherwise of the whole page.", "Optional caption, e.g. Order confirmation"),
    "VERIFY_VALUE": _kw(_VERIFY, REQUIRED, REQUIRED, "Input's value equals the expected value exactly.", "Expected value"),
    "VERIFY_URL": _kw(_VERIFY, UNUSED, REQUIRED, "Current URL contains the value.", "Part of the URL"),
    "VERIFY_DIALOG_TEXT": _kw(_VERIFY, UNUSED, REQUIRED, "The latest browser pop-up's message contains the value.", "Expected text"),
    "VERIFY_DOWNLOAD": _kw(_VERIFY, UNUSED, OPTIONAL, "A file finished downloading and is not empty. Input checks its name, with * as a wildcard.", "Report or *.xlsx", store=OPTIONAL),
    "VERIFY_PRINT_CALLED": _kw(_VERIFY, UNUSED, UNUSED, "The page asked the browser to print. No print dialog opens during a run."),
    "SOFT_VERIFY_TEXT_CONTAINS": _kw(_VERIFY, OPTIONAL, REQUIRED, "Same as VERIFY_TEXT_CONTAINS, but a failure is recorded and the test case carries on.", "Expected text"),
    "SOFT_VERIFY_ELEMENT_VISIBLE": _kw(_VERIFY, REQUIRED, UNUSED, "Same as VERIFY_ELEMENT_VISIBLE, but a failure is recorded and the test case carries on."),
    "SOFT_VERIFY_VALUE": _kw(_VERIFY, REQUIRED, REQUIRED, "Same as VERIFY_VALUE, but a failure is recorded and the test case carries on.", "Expected value"),
    "SOFT_VERIFY_URL": _kw(_VERIFY, UNUSED, REQUIRED, "Same as VERIFY_URL, but a failure is recorded and the test case carries on.", "Part of the URL"),
    "STORE_TEXT": _kw(_STORE, REQUIRED, UNUSED, "Save the element's visible text to a variable.", store=True),
    "STORE_INPUT_VALUE": _kw(_STORE, REQUIRED, UNUSED, "Save an input's value to a variable.", store=True),
    "STORE_REGEX": _kw(_STORE, OPTIONAL, REQUIRED, "Save a regex match (group 1 if present) from the element text, or the whole page if no locator.", r"Order #(\d+)", store=True),
    "STORE_DIALOG_TEXT": _kw(_STORE, UNUSED, UNUSED, "Save the latest browser pop-up's message to a variable.", store=True),
    "STORE_ELEMENT_COUNT": _kw(_STORE, REQUIRED, UNUSED, "Save how many elements the locator matches right now, such as grid rows, to a variable.", store=True),
    CALL_BLOCK: _kw(_REUSE, UNUSED, REQUIRED, "Run all steps of a reusable block from this application, optionally setting variables for it first.", "Login, or Login | USER=checker_01 | DEPT=Finance"),
    CALL_BLOCK_IF_VISIBLE: _kw(_REUSE, REQUIRED, REQUIRED, "Run a reusable block only if the element appears within 1.5 seconds.", "Name of the reusable block"),
    CALL_BLOCK_IF: _kw(_REUSE, OPTIONAL, REQUIRED, "Run a reusable block only if a condition holds: on the element when a locator is given, otherwise on a variable.", "text_contains:Saved || Block, or {STATUS} == Open || Block"),
    REPEAT_BLOCK: _kw(_REUSE, UNUSED, REQUIRED, "Run a reusable block several times in a row.", "Create Item | 3"),
    REPEAT_BLOCK_UNTIL: _kw(_REUSE, REQUIRED, REQUIRED, "Run a reusable block until the element is visible, or shows the text, up to a maximum number of times.", "Refresh Grid | 10 | Completed"),
}

BLOCK_KEYWORDS = (CALL_BLOCK, CALL_BLOCK_IF_VISIBLE, CALL_BLOCK_IF, REPEAT_BLOCK, REPEAT_BLOCK_UNTIL)
# These read their own {TOKEN}s, part by part: replacing them first could put an operator
# or a separator from a stored value into the text being read.
RAW_INPUT_KEYWORDS = {CALL_BLOCK_IF, REPEAT_BLOCK_UNTIL}
# A failure in one of these is recorded, and the test case carries on.
SOFT_KEYWORDS = {
    "SOFT_VERIFY_TEXT_CONTAINS", "SOFT_VERIFY_ELEMENT_VISIBLE", "SOFT_VERIFY_VALUE", "SOFT_VERIFY_URL",
}
# Spaces can be meaningful in typed text only.
_KEEPS_SPACES = {"FILL", "FILL_IF_VISIBLE", "TYPE_SEQUENTIALLY"}

RESERVED_TOKENS = {
    "RANDOM_INT", "UUID", "TODAY_DATE", "TODAY_DMY", "TODAY_MDY", "TIMESTAMP", "AUTH_USERNAME",
    "AUTH_PASSWORD",
}


def date_token(name, now=None):
    """The value of a date token such as TODAY_DATE, TODAY_DMY+7 or TODAY_MDY-30, or None
    if name is not one. Raises ValueError for an offset beyond MAX_DATE_OFFSET_DAYS."""
    match = DATE_TOKEN_RE.match(name)
    if not match:
        return None
    base, offset = match.group(1), int(match.group(2) or 0)
    if abs(offset) > config.MAX_DATE_OFFSET_DAYS:
        raise ValueError(
            f"{{{name}}}: a date offset must be from -{config.MAX_DATE_OFFSET_DAYS} "
            f"to +{config.MAX_DATE_OFFSET_DAYS} days"
        )
    return ((now or datetime.now()) + timedelta(days=offset)).strftime(DATE_TOKENS[base])


def check_date_tokens(text):
    """Raises ValueError if text has a date token with an offset out of range."""
    for name in TOKEN_RE.findall(text or ""):
        date_token(name)


_BLOCK_ARG_RE = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=(.*)$", re.S)


def parse_call_block(data):
    """'Login | USER=checker_01 | DEPT=Finance' as ('Login', [('USER', 'checker_01'),
    ('DEPT', 'Finance')]). A plain 'Login' has no arguments. Input with a | but no = at
    all is a block name that contains a |, as before arguments existed."""
    data = (data or "").strip()
    name, *parts = data.split("|")
    if not parts or not any("=" in part for part in parts):
        return data, []
    name = name.strip()
    if not name:
        raise ValueError("CALL_BLOCK needs the block name before the first |, such as Login | USER=checker_01")
    arguments, seen = [], set()
    for part in parts:
        match = _BLOCK_ARG_RE.match(part)
        if not match:
            raise ValueError(
                f"CALL_BLOCK arguments are KEY=VALUE pairs separated by |, such as "
                f"Login | USER=checker_01, but got '{part.strip()}'"
            )
        key, value = match.group(1), match.group(2).strip()
        if key in RESERVED_TOKENS:
            raise ValueError(f"CALL_BLOCK argument {key} is a built-in token and cannot be overwritten")
        if key in seen:
            raise ValueError(f"CALL_BLOCK sets {key} twice")
        seen.add(key)
        arguments.append((key, value))
    return name, arguments


_COUNT_RE = re.compile(r"^\s*(==|!=|>=|<=|>|<)?\s*(\d+)\s*$")
_COUNT_OPERATORS = {
    "==": operator.eq, "!=": operator.ne, ">=": operator.ge, "<=": operator.le,
    ">": operator.gt, "<": operator.lt,
}


def parse_count(data):
    """'5' as ('==', 5), and '>= 1' as ('>=', 1)."""
    match = _COUNT_RE.match(data or "")
    if not match:
        raise ValueError(
            "VERIFY_ELEMENT_COUNT needs a whole number, optionally after ==, !=, >, >=, < or <=, "
            "such as 5 or > 0"
        )
    return match.group(1) or "==", int(match.group(2))


MAX_SCROLL_PIXELS = 100000


def parse_scroll(data):
    """'bottom' or 'top', or a number of pixels such as 500 (down) or -500 (up)."""
    text = (data or "").strip().lower()
    if text in ("top", "bottom"):
        return text
    if re.fullmatch(r"[+-]?\d+", text) and abs(int(text)) <= MAX_SCROLL_PIXELS:
        return int(text)
    raise ValueError(
        f"SCROLL_TO input must be bottom, top, or pixels from -{MAX_SCROLL_PIXELS} to {MAX_SCROLL_PIXELS}, "
        "such as 500 or -500"
    )


def parse_repeat(data):
    """'Create Item | 3' as (block name, count). The last | separates them, so a
    block name may contain one. Raises ValueError with a message for the user."""
    name, separator, count = (data or "").rpartition("|")
    name, count = name.strip(), count.strip()
    if not separator or not name or not count.isdecimal():
        raise ValueError("REPEAT_BLOCK needs a block name and a count, such as Create Item | 3")
    if not 1 <= int(count) <= config.MAX_BLOCK_REPEAT:
        raise ValueError(f"REPEAT_BLOCK count must be from 1 to {config.MAX_BLOCK_REPEAT}")
    return name, int(count)


def parse_repeat_until(data):
    """'Refresh Grid | 10' as (block name, maximum, None), and 'Refresh Grid | 10 | Done'
    as (block name, maximum, 'Done'). A third part is only read when the part before it is
    a number, so a block name may still contain a |."""
    parts = (data or "").split("|")
    expected = None
    if len(parts) >= 3 and parts[-2].strip().isdecimal():
        expected = parts.pop().strip()
        if not expected:
            raise ValueError("REPEAT_BLOCK_UNTIL has an empty expected text after the second |")
    name, count = "|".join(parts[:-1]).strip(), parts[-1].strip()
    if len(parts) < 2 or not name or not count.isdecimal():
        raise ValueError(
            "REPEAT_BLOCK_UNTIL needs a block name and a maximum count, such as Refresh Grid | 10, "
            "optionally followed by | and the text to wait for"
        )
    if not 1 <= int(count) <= config.MAX_BLOCK_REPEAT:
        raise ValueError(f"REPEAT_BLOCK_UNTIL count must be from 1 to {config.MAX_BLOCK_REPEAT}")
    return name, int(count), expected


_ELEMENT_CONDITIONS = ("visible", "not_visible", "enabled", "checked")
_TEXT_CONDITIONS = ("text_contains", "text_equals", "value_equals")
_VARIABLE_LEFT_RE = re.compile(r"^(\{[A-Za-z_][A-Za-z0-9_]*\})\s*(.*)$", re.S)
# Longest first, so that "not_contains" is not read as something shorter.
_VARIABLE_OPERATORS = ("not_contains", "contains", "==", "!=", ">", "<")
_CONDITION_HELP = (
    "visible, not_visible, enabled, checked, text_contains:text, text_equals:text or value_equals:text"
)


def _parse_element_condition(text):
    """'visible' as ('visible', None), and 'text_contains:Saved' as ('text_contains', 'Saved')."""
    kind, colon, expected = text.partition(":")
    kind = kind.strip().lower()
    if kind in _ELEMENT_CONDITIONS and not colon:
        return kind, None
    if kind in _TEXT_CONDITIONS and colon:
        expected = expected.strip()
        if kind == "text_contains" and not expected:
            raise ValueError("CALL_BLOCK_IF text_contains: needs the text to look for")
        return kind, expected
    raise ValueError(f"CALL_BLOCK_IF condition on an element must be {_CONDITION_HELP}")


def _parse_variable_condition(text):
    """'{STATUS} == Open' as ('{STATUS}', '==', 'Open'). Read before tokens are replaced,
    so a stored value containing an operator cannot change the meaning."""
    match = _VARIABLE_LEFT_RE.match(text.strip())
    if match:
        left, rest = match.groups()
        for operator in _VARIABLE_OPERATORS:
            if not rest.startswith(operator):
                continue
            expected = rest[len(operator):]
            if operator[0].isalpha() and expected and not expected[0].isspace():
                continue  # "containsX" is not the word contains
            if not operator[0].isalpha() and expected.startswith(("=", "<", ">", "!")):
                break  # ===, >= and <= are not offered, and must not be half read
            return left, operator, expected.strip()
    raise ValueError(
        "CALL_BLOCK_IF with no locator needs a variable, an operator (==, !=, contains, "
        "not_contains, > or <) and a value, such as {STATUS} == Open || Close Order"
    )


def parse_block_if(data, has_locator):
    """CALL_BLOCK_IF input as (condition, block name). With a locator the condition is
    ('element', kind, expected) and may be left out, meaning visible; without one it is
    ('variable', '{NAME}', operator, expected). The last || separates the block name."""
    condition, separator, name = (data or "").rpartition(FRAME_SEPARATOR)
    condition, name = condition.strip(), name.strip()
    if not name:
        raise ValueError("CALL_BLOCK_IF needs a block name after ||, such as visible || Login")
    if has_locator:
        return ("element", *(_parse_element_condition(condition) if separator else ("visible", None))), name
    if not separator:
        raise ValueError(
            "CALL_BLOCK_IF with no locator needs a condition, then ||, then the block name, "
            "such as {STATUS} == Open || Close Order"
        )
    return ("variable", *_parse_variable_condition(condition)), name


def parse_block_call(keyword, data):
    """(block name, count) of a step that calls a reusable block. Raises ValueError with a
    message for the user."""
    if keyword == REPEAT_BLOCK:
        return parse_repeat(data)
    if keyword == REPEAT_BLOCK_UNTIL:
        name, count, _expected = parse_repeat_until(data)
        return name, count
    if keyword == CALL_BLOCK_IF:
        # The name is the same in both forms, so the locator does not matter here.
        name = (data or "").rpartition(FRAME_SEPARATOR)[2].strip()
        if not name:
            raise ValueError("CALL_BLOCK_IF needs a block name after ||, such as visible || Login")
        return name, 1
    if keyword == CALL_BLOCK:
        return parse_call_block(data)[0], 1
    return data, 1


def block_name_of(keyword, data):
    """The reusable block a step calls, or None if it calls none (or cannot be read)."""
    if keyword not in BLOCK_KEYWORDS:
        return None
    try:
        return parse_block_call(keyword, data)[0]
    except ValueError:
        return None


def parse_dialog_plan(data):
    """'accept', 'dismiss' or 'accept|text' as (action, prompt text or None)."""
    action, separator, text = (data or "").partition("|")
    action = action.strip().lower()
    if action not in ("accept", "dismiss") or (separator and action == "dismiss"):
        raise ValueError("PREPARE_DIALOG needs accept, dismiss or accept|text")
    return action, text if separator else None


def split_frames(value):
    """'iframe#a || #b || Save' as (['iframe#a', '#b'], 'Save'). Only an unescaped ||
    separates: a \\|| in any part is a literal ||."""
    *frames, target = _FRAME_SPLIT_RE.split(value)
    frames = [frame.replace(ESCAPED_FRAME_SEPARATOR, FRAME_SEPARATOR).strip() for frame in frames]
    target = target.strip() if frames else target
    return frames, target.replace(ESCAPED_FRAME_SEPARATOR, FRAME_SEPARATOR)


def _unescape_index(value):
    """'Room \\@2' as 'Room @2': text that really ends that way."""
    return _ESCAPED_INDEX_RE.sub(lambda match: f"{match.group(1)}@{match.group(2)}", value)


def split_index_suffix(locator_type, value):
    """'Edit @2' as ('Edit', 2), and 'Save @first' as ('Save', 'first'). 'Room \\@2' is
    the literal text 'Room @2' with no pick, and 'Room \\@2 @first' picks the first of
    those. Numbers count from 1: @0 is refused, because Playwright reads nth(-1) as the
    last element. In XPath, ' @first' after a / or an operator is an attribute, not a pick."""
    match = INDEX_SUFFIX_RE.search(value)
    if match:
        rest = value[:match.start()]
        attribute = locator_type == "xpath" and _XPATH_OPEN_END_RE.search(rest.rstrip())
        if rest.strip() and not attribute:
            pick = match.group(1)
            if pick.isdigit():
                pick = int(pick)
                if pick < 1:
                    raise ValueError("@ numbers count from 1: use @1 for the first match")
            return _unescape_index(rest), pick
    return _unescape_index(value), None


def parse_row_action(value):
    """'PO-1042 | Edit' as (row text, action text). The last | separates them, so row text
    may contain one."""
    row_text, separator, action = (value or "").rpartition("|")
    row_text, action = row_text.strip(), action.strip()
    if not separator or not row_text or not action:
        raise ValueError("row_action needs row text and an action on either side of |, such as PO-1042 | Edit")
    return row_text, action


def _check_locator_value(locator_type, value):
    """Raises ValueError with a message for the user. Only the part after any frames counts."""
    _frames, target = split_frames(value)
    target, _pick = split_index_suffix(locator_type, target.strip())
    if locator_type == "row_action":
        parse_row_action(target)


def parse_destination(data):
    """'css|#dropzone' as (locator type, locator value)."""
    locator_type, _, value = (data or "").partition("|")
    locator_type, value = locator_type.strip().lower(), value.strip()
    if locator_type not in LOCATOR_TYPES or not value:
        raise ValueError(
            f"DRAG_AND_DROP needs a destination as type|value, where type is one of {', '.join(LOCATOR_TYPES)}"
        )
    _check_locator_value(locator_type, value)
    return locator_type, value


def _grace_ms(data):
    """The wait of CLICK_IF_VISIBLE. At least 1 ms: Playwright reads 0 as no time limit."""
    if not data:
        return config.VISIBLE_GRACE_MS
    try:
        seconds = float(data)
        if not 0 <= seconds <= config.MAX_WAIT_SECONDS:
            raise ValueError
    except ValueError:
        raise ValueError(f"CLICK_IF_VISIBLE needs a number from 0 to {config.MAX_WAIT_SECONDS}") from None
    return max(seconds * 1000, 1)


# Checked when a step is saved, unless a token means the value is only known at run time.
_INPUT_READERS = {
    "CLICK_IF_VISIBLE": _grace_ms, "PREPARE_DIALOG": parse_dialog_plan, "DRAG_AND_DROP": parse_destination,
    "VERIFY_ELEMENT_COUNT": parse_count, "SCROLL_TO": parse_scroll,
}


def validate_step(raw):
    """Normalise one step dict. Returns (clean_step, errors). Fields the keyword
    does not use are cleared so stale values can't change behaviour later."""
    keyword = str(raw.get("action_keyword") or "").strip().upper()
    spec = KEYWORDS.get(keyword)
    if not spec:
        return None, [f"unknown keyword '{keyword or '(blank)'}'"]
    errors = []

    locator_type = str(raw.get("locator_type") or "").strip().lower()
    locator_value = str(raw.get("locator_value") or "").strip()
    if spec["locator"] == UNUSED:
        locator_type = locator_value = ""
    elif locator_value or spec["locator"] == REQUIRED:
        if not locator_value:
            errors.append(f"{keyword} needs a locator value")
        if locator_type not in LOCATOR_TYPES:
            errors.append(f"{keyword} needs a locator type ({', '.join(LOCATOR_TYPES)})")
        if _FRAME_SPLIT_RE.search(locator_value) and not all(
            part.strip() for part in _FRAME_SPLIT_RE.split(locator_value)
        ):
            errors.append(f"{keyword} has an empty part in its locator: put a frame on each side of ||")
        if locator_value and locator_type in LOCATOR_TYPES:
            try:
                _check_locator_value(locator_type, locator_value)
            except ValueError as exc:
                errors.append(f"{keyword}: {exc}")
    else:
        locator_type = ""

    input_data = str(raw.get("input_data") or "")
    if keyword not in _KEEPS_SPACES:
        input_data = input_data.strip()
    if spec["input"] == UNUSED:
        input_data = ""
    elif spec["input"] == REQUIRED and not input_data:
        errors.append(f"{keyword} needs input data")
    has_token = bool(TOKEN_RE.search(input_data))
    if keyword == "WAIT_SECONDS" and input_data and not has_token:
        try:
            if not 0 <= float(input_data) <= config.MAX_WAIT_SECONDS:
                raise ValueError
        except ValueError:
            errors.append(f"WAIT_SECONDS needs a number from 0 to {config.MAX_WAIT_SECONDS}")
    if keyword == "STORE_REGEX" and input_data and not has_token:
        try:
            re.compile(input_data)
        except re.error as exc:
            errors.append(f"invalid regular expression: {exc}")
    if keyword in _INPUT_READERS and input_data and not has_token:
        try:
            _INPUT_READERS[keyword](input_data)
        except ValueError as exc:
            errors.append(str(exc))
    # Blocks are expanded before a run starts, so the count cannot come from a token. These
    # read their tokens part by part at run time, so they are checked even with one.
    if input_data and keyword in (REPEAT_BLOCK, REPEAT_BLOCK_UNTIL, CALL_BLOCK_IF, CALL_BLOCK):
        try:
            if keyword == CALL_BLOCK_IF:
                parse_block_if(input_data, bool(locator_value))
            else:
                parse_block_call(keyword, input_data)
        except ValueError as exc:
            errors.append(str(exc))
    if keyword == "SCROLL_TO" and not locator_value and not input_data:
        errors.append("SCROLL_TO needs a locator, or input data of bottom, top or a number of pixels")
    for text in (locator_value, input_data):
        try:
            check_date_tokens(text)
        except ValueError as exc:
            errors.append(str(exc))

    store = str(raw.get("store_variable_name") or "").strip()
    if spec["store"] and (spec["store"] is True or store):
        if not VARIABLE_NAME_RE.match(store):
            errors.append(f"{keyword} needs a variable name (letters, digits, underscore)")
        elif store in RESERVED_TOKENS:
            errors.append(f"{store} is a built-in token and cannot be overwritten")
    else:
        store = ""

    return {
        "action_keyword": keyword,
        "locator_type": locator_type or None,
        "locator_value": locator_value or None,
        "input_data": input_data or None,
        "store_variable_name": store or None,
        "description": str(raw.get("description") or "").strip() or None,
    }, errors


# Text inside a named button or link is that button or link, already found by its role.
_OUTSIDE_BUTTON_OR_LINK = (
    "xpath=self::*[not(ancestor-or-self::button or ancestor-or-self::a[@href] "
    "or ancestor-or-self::*[@role='button' or @role='link'])]"
)


def _attribute_value(value):
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _row_action_locator(root, value):
    row_text, action = parse_row_action(value)
    row = root.locator("tr, [role='row']").filter(has_text=row_text)
    named = row.get_by_role("button", name=action).or_(row.get_by_role("link", name=action))
    # Without the filter, <button><span>Edit</span></button> matches twice (the button and
    # the span) and every Angular Material button would be a strict mode violation.
    return named.or_(row.get_by_text(action).locator(_OUTSIDE_BUTTON_OR_LINK))


def _base_locator(page, locator_type, value):
    if locator_type == "id":
        # Attribute form: .NET ids can contain characters that break '#id'.
        return page.locator(f'[id="{_attribute_value(value)}"]')
    if locator_type == "id_ends_with":
        return page.locator(f'[id$="{_attribute_value(value)}"]')
    if locator_type == "name":
        return page.locator(f'[name="{_attribute_value(value)}"]')
    if locator_type == "css":
        return page.locator(value)
    if locator_type == "xpath":
        return page.locator(f"xpath={value}")
    if locator_type == "text":
        return page.get_by_text(value)
    if locator_type == "label":
        return page.get_by_label(value)
    if locator_type == "placeholder":
        return page.get_by_placeholder(value)
    if locator_type == "title":
        return page.get_by_title(value)
    if locator_type == "role":
        # "button|Save" targets the button named Save; "button" alone any button.
        role, _, name = value.partition("|")
        if name.strip():
            return page.get_by_role(role.strip(), name=name.strip())
        return page.get_by_role(role.strip())
    if locator_type == "test_id":
        return page.get_by_test_id(value)
    if locator_type == "row_action":
        return _row_action_locator(page, value)
    raise ValueError(f"Unsupported locator type '{locator_type}'")


def resolve_locator(page, locator_type, value):
    """page is the page or frame to search. 'iframe#a || #b || Save' searches for Save
    inside frame #b, which is inside frame iframe#a, and '\\||' is a literal ||. A final
    ' @first', ' @last' or ' @2' picks one of several matches, for every type, and
    ' \\@2' is the literal text ' @2'."""
    frames, value = split_frames(value)
    for frame in frames:
        page = page.frame_locator(frame)
    value, pick = split_index_suffix(locator_type, value)
    target = _base_locator(page, locator_type, value)
    if pick is None:
        return target
    if pick == "first":
        return target.first
    if pick == "last":
        return target.last
    return target.nth(pick - 1)


@dataclass
class StepEnv:
    page: object
    base_url: str
    timeout_ms: int
    should_abort: Callable[[], bool] = lambda: False
    windows: object = None  # The browser session, which owns the list of open windows.
    active_frame: object = None  # The iframe steps search in; None means the page itself.
    # Replaces {TOKEN}s, for the keywords in RAW_INPUT_KEYWORDS that read them part by part.
    resolve: Callable[[str], str] = lambda text: text
    loop: Optional[tuple] = None  # REPEAT_BLOCK_UNTIL: (iterations run so far, maximum).

    @property
    def root(self):
        return self.active_frame if self.active_frame is not None else self.page


@dataclass
class KeywordResult:
    actual_value: str = ""
    stored_value: Optional[str] = None
    skip_guarded: bool = False  # Leave out the steps this one guards (a block or a loop's rest).
    screenshot: Optional[bytes] = None  # PNG evidence kept on a passing step (CAPTURE_SCREENSHOT).


def _poll_for_text(read, env, describe):
    """Re-read until non-empty: an SPA can render the element before its data."""
    deadline = time.monotonic() + env.timeout_ms / 1000
    while True:
        value = (read() or "").strip()
        if value:
            return value
        if time.monotonic() >= deadline:
            raise AssertionError(f"{describe} stayed empty for {env.timeout_ms} ms")
        env.page.wait_for_timeout(250)


def _navigate(env, _target, data):
    url = urljoin(env.base_url, data) if data else env.base_url
    # A test step must not be able to read the server's own disk through file://.
    if urlsplit(url).scheme.lower() not in ("http", "https"):
        raise ValueError(f"NAVIGATE only allows http and https URLs, got '{url}'")
    env.windows.leave_frame()  # Also covers a move within the page, which keeps its document.
    env.page.goto(url, wait_until="load")
    return KeywordResult(view_url(env.page.url))


def _wait_seconds(env, _target, data):
    seconds = float(data)
    if not 0 <= seconds <= config.MAX_WAIT_SECONDS:
        raise ValueError(f"WAIT_SECONDS must be 0 to {config.MAX_WAIT_SECONDS}")
    deadline = time.monotonic() + seconds
    while (remaining := deadline - time.monotonic()) > 0:
        if env.should_abort():
            break
        time.sleep(min(remaining, 0.5))
    return KeywordResult(f"waited {seconds:g}s")


def _wait_for_element(env, target, _data):
    target.wait_for(state="visible", timeout=env.timeout_ms)
    return KeywordResult("visible")


def _switch_window(env, _target, data):
    env.page = env.windows.switch_to_new_window(data, env.timeout_ms)
    return KeywordResult(view_url(env.page.url))


def _close_window(env, _target, _data):
    env.page = env.windows.close_window()
    return KeywordResult(f"back on {view_url(env.page.url)}")


def _click_and_switch(env, target, data):
    # Only a window opened by this click counts, not one already open and never visited.
    before = env.windows.open_windows()
    target.click()
    env.page = env.windows.switch_to_new_window(data, env.timeout_ms, ignore=before)
    return KeywordResult(view_url(env.page.url))


def _switch_to_window(env, _target, data):
    env.page = env.windows.switch_to_window(data, env.timeout_ms)
    return KeywordResult(view_url(env.page.url))


def _switch_to_frame(env, target, _data):
    target.wait_for(state="attached", timeout=env.timeout_ms)
    tag = target.evaluate("element => element.tagName").lower()
    if tag not in ("iframe", "frame"):
        raise AssertionError(f"SWITCH_TO_FRAME found a <{tag}>, not an iframe.")
    env.windows.enter_frame(target.content_frame)
    return KeywordResult("inside the frame")


def _switch_to_main_frame(env, _target, _data):
    env.windows.leave_frame()
    return KeywordResult("on the main page")


def _visible_within(target, timeout_ms):
    """Only running out of time means absent. A locator matching two elements still
    fails, because skipping there would hide a broken test."""
    try:
        target.wait_for(state="visible", timeout=timeout_ms)
    except PlaywrightTimeoutError:
        return False
    return True


_NOT_VISIBLE = "not visible (skipped)"


def _click_if_visible(_env, target, data):
    if not _visible_within(target, _grace_ms(data)):
        return KeywordResult(_NOT_VISIBLE)
    target.click()
    return KeywordResult("clicked")


def _fill_if_visible(_env, target, data):
    if not _visible_within(target, config.VISIBLE_GRACE_MS):
        return KeywordResult(_NOT_VISIBLE)
    target.fill(data)
    return KeywordResult(data)


def _block_guard(_env, target, _data):
    if _visible_within(target, config.VISIBLE_GRACE_MS):
        return KeywordResult("visible, running the block")
    return KeywordResult(_NOT_VISIBLE, skip_guarded=True)


_READ_MS = 1000  # The element is already visible, so a read that takes longer is stuck.


def _poll(env, check, timeout_ms):
    """True as soon as check() is, False when time runs out. Only running out of time
    means no: any other error, such as two matching elements, still fails the step."""
    deadline = time.monotonic() + timeout_ms / 1000
    while True:
        try:
            if check():
                return True
        except PlaywrightTimeoutError:
            pass
        if time.monotonic() >= deadline:
            return False
        env.page.wait_for_timeout(100)


def _element_condition(env, target, kind, expected, timeout_ms):
    """Whether the element meets the condition within timeout_ms. An element that does not
    appear meets none of them except not_visible. A condition is waited for, not read once,
    because an SPA can show the element before its text or state."""
    if kind == "visible":
        return _visible_within(target, timeout_ms)
    if kind == "not_visible":
        return not _visible_within(target, timeout_ms)
    if not _visible_within(target, timeout_ms):
        return False
    checks = {
        "enabled": lambda: target.is_enabled(timeout=_READ_MS),
        "checked": lambda: target.is_checked(timeout=_READ_MS),
        "text_contains": lambda: expected in target.inner_text(timeout=_READ_MS),
        "text_equals": lambda: target.inner_text(timeout=_READ_MS).strip() == expected,
        "value_equals": lambda: target.input_value(timeout=_READ_MS) == expected,
    }
    return _poll(env, checks[kind], timeout_ms)


_NUMBER_RE = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$")


def _compare(left, operator, right):
    """Numbers compare as numbers when both sides are numbers, so 10 > 9 and 5 == 5.0."""
    left, right = left.strip(), right.strip()
    numeric = bool(_NUMBER_RE.match(left) and _NUMBER_RE.match(right))
    if operator in (">", "<"):
        if not numeric:
            raise AssertionError(f"{operator} compares numbers, but got '{left}' and '{right}'")
        return float(left) > float(right) if operator == ">" else float(left) < float(right)
    if operator in ("==", "!="):
        same = float(left) == float(right) if numeric else left == right
        return same if operator == "==" else not same
    return (right in left) if operator == "contains" else (right not in left)


def _shown(value, limit=80):
    value = str(value)
    return value if len(value) <= limit else value[:limit] + "..."


def _block_if(env, target, data):
    condition, _name = parse_block_if(data, target is not None)
    if condition[0] == "element":
        _, kind, expected = condition
        expected = env.resolve(expected) if expected is not None else None
        met = _element_condition(env, target, kind, expected, config.VISIBLE_GRACE_MS)
        described = kind if expected is None else f"{kind}:{_shown(expected)}"
    else:
        _, left, operator, expected = condition
        left, expected = env.resolve(left), env.resolve(expected)
        met = _compare(left, operator, expected)
        described = f"'{_shown(left)}' {operator} '{_shown(expected)}'"
    if met:
        return KeywordResult(f"{described} is true, running the block")
    return KeywordResult(f"condition false (skipped): {described}", skip_guarded=True)


def _repeat_until(env, target, data):
    """One check of a REPEAT_BLOCK_UNTIL loop. The runner places one before the first
    iteration and one after each, and env.loop says which this is."""
    _name, _count, expected = parse_repeat_until(data)
    done, maximum = env.loop or (0, 0)
    if expected is None:
        met = _element_condition(env, target, "visible", None, config.VISIBLE_GRACE_MS)
        wanted = "visible"
    else:
        expected = env.resolve(expected)
        met = _element_condition(env, target, "text_contains", expected, config.VISIBLE_GRACE_MS)
        wanted = f"showing '{_shown(expected)}'"
    if met:
        if not done:
            return KeywordResult("condition already met, block not run", skip_guarded=True)
        return KeywordResult(f"condition met after {done} iteration(s)", skip_guarded=True)
    if done >= maximum:
        raise AssertionError(f"The element was still not {wanted} after {maximum} iteration(s) of the block.")
    return KeywordResult(f"not {wanted} yet, running iteration {done + 1} of {maximum}")


def _hover(_env, target, _data):
    target.hover()
    return KeywordResult("hovered")


def _drag_and_drop(env, target, data):
    locator_type, value = parse_destination(data)
    target.drag_to(resolve_locator(env.root, locator_type, value))
    return KeywordResult(f"dropped on {value}")


def _prepare_dialog(env, _target, data):
    env.windows.prepare_dialog(parse_dialog_plan(data))
    return KeywordResult(data)


def _verify_dialog(env, _target, data):
    deadline = time.monotonic() + env.timeout_ms / 1000
    while True:
        message = env.windows.last_dialog_message
        if data in message:
            return KeywordResult(message)
        if time.monotonic() >= deadline:
            seen = f"The latest one said '{message}'." if message else "None has appeared."
            raise AssertionError(f"No browser pop-up containing '{data}' within {env.timeout_ms} ms. {seen}")
        env.page.wait_for_timeout(100)


def _store_dialog(env, _target, _data):
    value = _poll_for_text(lambda: env.windows.last_dialog_message, env, "Browser pop-up text")
    return KeywordResult(value, value)


def _verify_download(env, _target, data):
    name, size = env.windows.wait_for_download(data, env.timeout_ms)
    return KeywordResult(f"{name} ({size} bytes)", name)


# Takes the count and clears it in one call, so a second check needs a second print.
_TAKE_PRINTS = """() => {
  const count = window.__qaPrintCount || 0;
  window.__qaPrintCount = 0;
  return {count, title: window.__qaLastPrintTitle || ''};
}"""


def _verify_print(env, _target, _data):
    """performance.INIT_SCRIPT replaces window.print in every page with a counter."""
    deadline = time.monotonic() + env.timeout_ms / 1000
    while True:
        try:
            printed = env.page.evaluate(_TAKE_PRINTS)
        except Exception:  # The page is navigating; ask its next document.
            printed = {"count": 0}
        if printed.get("count"):
            title = printed.get("title") or ""
            return KeywordResult(f"print called {printed['count']} time(s)" + (f" on '{title}'" if title else ""))
        if time.monotonic() >= deadline:
            raise AssertionError(
                f"The page did not ask to print within {env.timeout_ms} ms. A page that loads a new "
                "document after printing loses the count, so check straight after the step that prints."
            )
        env.page.wait_for_timeout(100)


def _click(_env, target, _data):
    target.click()
    return KeywordResult("clicked")


def _double_click(_env, target, _data):
    target.dblclick()
    return KeywordResult("double-clicked")


def _fill(_env, target, data):
    target.fill(data)
    return KeywordResult(data)


def _select(_env, target, data):
    # A plain string matches either the option's value or its label.
    return KeywordResult(", ".join(target.select_option(data)))


def _check(_env, target, _data):
    target.check()
    return KeywordResult("checked")


def _uncheck(_env, target, _data):
    target.uncheck()
    return KeywordResult("unchecked")


def _press_key(env, target, data):
    if target is not None:
        target.press(data)
    else:
        env.page.keyboard.press(data)
    return KeywordResult(data)


def _upload(env, target, data):
    root = config.TEST_DATA_DIR.resolve()
    path = (root / data).resolve()
    # Stops a step attaching arbitrary server files to a page it controls.
    if root not in path.parents:
        raise ValueError(f"UPLOAD_FILE may only use files inside {root}")
    if not path.is_file():
        raise FileNotFoundError(f"File not found in test_data: {data}")
    if target.evaluate("el => el.tagName === 'INPUT' && el.type === 'file'"):
        target.set_input_files(str(path))
        return KeywordResult(path.name)
    # A styled Browse button that opens the file picker from script. Waiting for the picker
    # also stops the Windows dialog from opening, which no step could reach.
    with env.page.expect_file_chooser(timeout=env.timeout_ms) as chooser:
        target.click()
    chooser.value.set_files(str(path))
    return KeywordResult(f"{path.name} (through the file picker)")


def _verify_text(env, target, data):
    element = target if target is not None else env.root.locator("body")
    expect(element).to_contain_text(data, timeout=env.timeout_ms)
    return KeywordResult(f"contains '{data}'")


def _verify_visible(env, target, _data):
    expect(target).to_be_visible(timeout=env.timeout_ms)
    return KeywordResult("visible")


def _verify_value(env, target, data):
    expect(target).to_have_value(data, timeout=env.timeout_ms)
    return KeywordResult(data)


def _verify_url(env, _target, data):
    expect(env.page).to_have_url(re.compile(re.escape(data)), timeout=env.timeout_ms)
    # The address can hold a sign-in token, and step results end up in shared reports.
    return KeywordResult(view_url(env.page.url))


def _verify_not_visible(env, target, _data):
    expect(target).to_be_hidden(timeout=env.timeout_ms)
    return KeywordResult("hidden")


def _verify_text_absent(env, target, data):
    element = target if target is not None else env.root.locator("body")
    expect(element).not_to_contain_text(data, timeout=env.timeout_ms)
    return KeywordResult(f"does not contain '{data}'")


def _verify_enabled(env, target, _data):
    expect(target).to_be_enabled(timeout=env.timeout_ms)
    return KeywordResult("enabled")


def _verify_disabled(env, target, _data):
    expect(target).to_be_disabled(timeout=env.timeout_ms)
    return KeywordResult("disabled")


def _verify_count(env, target, data):
    """Polled, because a grid or a search result list fills in after the page loads."""
    sign, expected = parse_count(data)
    deadline = time.monotonic() + env.timeout_ms / 1000
    while True:
        actual = target.count()
        if _COUNT_OPERATORS[sign](actual, expected):
            return KeywordResult(f"{actual} element(s), {sign} {expected}")
        if time.monotonic() >= deadline:
            raise AssertionError(
                f"Expected the number of matching elements to be {sign} {expected}, "
                f"but found {actual} after {env.timeout_ms} ms."
            )
        env.page.wait_for_timeout(250)


def _store_count(_env, target, _data):
    value = str(target.count())
    return KeywordResult(value, value)


def _capture_screenshot(env, target, data):
    if target is not None:
        image = target.screenshot(timeout=config.SCREENSHOT_TIMEOUT_MS)
    else:
        image = env.page.screenshot(full_page=True, timeout=config.SCREENSHOT_TIMEOUT_MS)
    return KeywordResult(data or "Screenshot captured", screenshot=image)


def _type_sequentially(env, target, data):
    target.clear()
    # The typing itself takes time, on top of waiting for the field.
    timeout = env.timeout_ms + len(data) * config.TYPE_DELAY_MS
    target.press_sequentially(data, delay=config.TYPE_DELAY_MS, timeout=timeout)
    return KeywordResult(data)


_SCROLL_ELEMENT_END = "(el, end) => { el.scrollTop = end === 'top' ? 0 : el.scrollHeight; }"
_SCROLL_PAGE_END = """end => window.scrollTo(0, end === 'top' ? 0 :
  Math.max(document.documentElement.scrollHeight, document.body ? document.body.scrollHeight : 0))"""


def _scroll_to(env, target, data):
    """With a locator: bring it into view, then optionally scroll inside it, which is how
    a virtual grid is told to draw more rows. Without one: scroll the page."""
    where = parse_scroll(data) if data else None
    if target is not None:
        target.scroll_into_view_if_needed(timeout=env.timeout_ms)
        if where is None:
            return KeywordResult("scrolled into view")
        if isinstance(where, str):
            target.evaluate(_SCROLL_ELEMENT_END, where)
            return KeywordResult(f"scrolled the element to the {where}")
        target.hover()
        env.page.mouse.wheel(0, where)
        return KeywordResult(f"scrolled the element by {where} px")
    if isinstance(where, str):
        env.root.evaluate(_SCROLL_PAGE_END, where)
        return KeywordResult(f"scrolled the page to the {where}")
    env.page.mouse.wheel(0, where)
    return KeywordResult(f"scrolled the page by {where} px")


def _store_text(env, target, _data):
    value = _poll_for_text(target.inner_text, env, "Element text")
    return KeywordResult(value, value)


def _store_input(env, target, _data):
    value = _poll_for_text(target.input_value, env, "Input value")
    return KeywordResult(value, value)


def _store_regex(env, target, data):
    pattern = re.compile(data)
    element = target if target is not None else env.root.locator("body")
    deadline = time.monotonic() + env.timeout_ms / 1000
    while True:
        match = pattern.search(element.inner_text())
        value = (match.group(1) if pattern.groups else match.group(0)) if match else None
        if value:
            return KeywordResult(value, value)
        if time.monotonic() >= deadline:
            raise AssertionError(f"Pattern '{data}' found no match in {env.timeout_ms} ms")
        env.page.wait_for_timeout(250)


_HANDLERS = {
    "NAVIGATE": _navigate,
    "WAIT_SECONDS": _wait_seconds,
    "WAIT_FOR_ELEMENT": _wait_for_element,
    "SWITCH_TO_NEW_WINDOW": _switch_window,
    "CLOSE_WINDOW": _close_window,
    "SWITCH_TO_WINDOW": _switch_to_window,
    "SWITCH_TO_FRAME": _switch_to_frame,
    "SWITCH_TO_MAIN_FRAME": _switch_to_main_frame,
    "CLICK": _click,
    "CLICK_AND_SWITCH_WINDOW": _click_and_switch,
    "DOUBLE_CLICK": _double_click,
    "HOVER": _hover,
    "DRAG_AND_DROP": _drag_and_drop,
    "CLICK_IF_VISIBLE": _click_if_visible,
    "FILL_IF_VISIBLE": _fill_if_visible,
    "PREPARE_DIALOG": _prepare_dialog,
    "FILL": _fill,
    "SELECT_DROPDOWN": _select,
    "CHECK": _check,
    "UNCHECK": _uncheck,
    "PRESS_KEY": _press_key,
    "UPLOAD_FILE": _upload,
    "VERIFY_TEXT_CONTAINS": _verify_text,
    "VERIFY_ELEMENT_VISIBLE": _verify_visible,
    "VERIFY_VALUE": _verify_value,
    "VERIFY_URL": _verify_url,
    "VERIFY_DIALOG_TEXT": _verify_dialog,
    "VERIFY_DOWNLOAD": _verify_download,
    "VERIFY_PRINT_CALLED": _verify_print,
    "SOFT_VERIFY_TEXT_CONTAINS": _verify_text,
    "SOFT_VERIFY_ELEMENT_VISIBLE": _verify_visible,
    "SOFT_VERIFY_VALUE": _verify_value,
    "SOFT_VERIFY_URL": _verify_url,
    "STORE_DIALOG_TEXT": _store_dialog,
    CALL_BLOCK_IF_VISIBLE: _block_guard,
    CALL_BLOCK_IF: _block_if,
    REPEAT_BLOCK_UNTIL: _repeat_until,
    "STORE_TEXT": _store_text,
    "STORE_INPUT_VALUE": _store_input,
    "STORE_REGEX": _store_regex,
    "VERIFY_ELEMENT_NOT_VISIBLE": _verify_not_visible,
    "VERIFY_TEXT_NOT_PRESENT": _verify_text_absent,
    "VERIFY_ELEMENT_ENABLED": _verify_enabled,
    "VERIFY_ELEMENT_DISABLED": _verify_disabled,
    "VERIFY_ELEMENT_COUNT": _verify_count,
    "STORE_ELEMENT_COUNT": _store_count,
    "CAPTURE_SCREENSHOT": _capture_screenshot,
    "TYPE_SEQUENTIALLY": _type_sequentially,
    "SCROLL_TO": _scroll_to,
}


def run_keyword(env, keyword, locator_type, locator_value, input_data):
    """Execute one resolved step. Any failure raises, carrying the reason."""
    target = resolve_locator(env.root, locator_type, locator_value) if locator_value else None
    return _HANDLERS[keyword](env, target, input_data or "")
