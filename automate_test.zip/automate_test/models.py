"""SQLAlchemy models and the first-run seeder."""
import logging
import re
from datetime import datetime, timezone

from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import event, select, text, update
from sqlalchemy.engine import Engine
from sqlalchemy.orm import column_property, deferred
from werkzeug.security import check_password_hash, generate_password_hash

import config

log = logging.getLogger(__name__)

db = SQLAlchemy()

ROLE_GUEST = "Guest"
ROLE_MEMBER = "Test Member"
ROLE_MANAGER = "Test Manager"
ROLE_ADMIN = "Admin"
ROLES = [ROLE_GUEST, ROLE_MEMBER, ROLE_MANAGER, ROLE_ADMIN]

TECH_STACKS = [".NET", "Angular", "React", "Other"]
AUTH_TYPES = {"None": "None", "Standard": "Standard Form", "OnPrem_AD": "On-Prem AD"}

RUN_QUEUED = "Queued"
RUN_RUNNING = "Running"
RUN_COMPLETED = "Completed"
RUN_ABORTED = "Aborted"
RUN_ACTIVE = (RUN_QUEUED, RUN_RUNNING)

TC_PENDING = "Pending"
TC_RUNNING = "Running"
TC_PASS = "Pass"
TC_FAIL = "Fail"
TC_BLOCKED = "Skipped/Blocked"

STEP_PASS = "Pass"
STEP_FAIL = "Fail"

OPENED_MAIN = "Main"
OPENED_TAB = "New tab"
OPENED_POPUP = "Pop-up"
OPENED_SPA = "SPA view"

RATE_FAST = "Fast"
RATE_OK = "Acceptable"
RATE_SLOW = "Slow"
RATE_FAILED = "Failed"
RATE_UNFINISHED = "Not finished"
RATE_UNKNOWN = "-"


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


@event.listens_for(Engine, "connect")
def _sqlite_pragmas(dbapi_connection, _record):
    # WAL lets the UI poll while the runner thread commits step results.
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.execute("PRAGMA busy_timeout=30000")
    cursor.close()


def _initial_caps(name):
    """`anup kumar`, `ANUP KUMAR` -> `Anup Kumar`; `mary-jane o'neil` -> `Mary-Jane O'Neil`.
    A name typed in mixed case, such as `McDonald` or `van der Berg`, is kept as typed."""
    words = name.split()
    letters = ["".join(ch for ch in word if ch.isalpha()) for word in words]
    if any(part and not part.islower() and not part.isupper() for part in letters):
        return " ".join(words)
    return " ".join(
        "".join(part[:1].upper() + part[1:].lower() for part in re.split(r"([-'])", word))
        for word in words
    )


class User(UserMixin, db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(200), unique=True, nullable=False)
    first_name = db.Column(db.String(80), nullable=False, default="")
    last_name = db.Column(db.String(80), nullable=False, default="")
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default=ROLE_GUEST)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)
    # Set when a user with history is deleted: the row stays so past runs keep a name.
    deleted_at = db.Column(db.DateTime, nullable=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def full_name(self):
        """First and last name, or "" if neither is set."""
        return " ".join(part for part in (self.first_name, self.last_name) if part)

    @property
    def display_name(self):
        """The name shown on screens and reports: first and last name in initial caps,
        or the username for an account with no names. A deleted account says so."""
        name = " ".join(_initial_caps(part) for part in (self.first_name, self.last_name) if part.strip())
        if not name:
            return self.username  # a deleted account's username already ends "(deleted)"
        return f"{name} (deleted)" if self.deleted_at else name

    @property
    def initials(self):
        if self.first_name and self.last_name:
            return (self.first_name[0] + self.last_name[0]).upper()
        return self.username[:2].upper()


class SystemConfig(db.Model):
    __tablename__ = "system_config"
    id = db.Column(db.Integer, primary_key=True)
    default_browser = db.Column(db.String(10), nullable=False, default="msedge")
    edge_executable_path = db.Column(db.String(500), nullable=False, default="")
    chrome_executable_path = db.Column(db.String(500), nullable=False, default="")
    default_headless = db.Column(db.Boolean, nullable=False, default=True)
    default_timeout_ms = db.Column(db.Integer, nullable=False, default=30000)


class Application(db.Model):
    __tablename__ = "applications"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=False, default="")
    base_url = db.Column(db.String(500), nullable=False)
    tech_stack = db.Column(db.String(20), nullable=False, default="Other")
    preferred_browser = db.Column(db.String(10), nullable=False, default="msedge")
    auth_type = db.Column(db.String(20), nullable=False, default="None")
    ad_domain = db.Column(db.String(150), nullable=False, default="")
    auth_username = db.Column(db.String(200), nullable=False, default="")
    auth_password_encrypted = db.Column(db.Text, nullable=False, default="")
    created_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)
    # Last run number handed out for this application. Never goes down, so a
    # pruned or deleted run's number is not reused.
    run_counter = db.Column(db.Integer, nullable=False, default=0)

    creator = db.relationship("User")
    test_cases = db.relationship(
        "TestCase", back_populates="application", cascade="all, delete-orphan",
        order_by="TestCase.name",
    )
    runs = db.relationship(
        "TestRun", back_populates="application", cascade="all, delete-orphan",
        passive_deletes=True,
    )

    def set_password(self, plain):
        self.auth_password_encrypted = (
            config.fernet().encrypt(plain.encode()).decode() if plain else ""
        )

    def get_password(self):
        """Raises cryptography.fernet.InvalidToken if the key file was replaced."""
        if not self.auth_password_encrypted:
            return ""
        return config.fernet().decrypt(self.auth_password_encrypted.encode()).decode()


class TestCase(db.Model):
    __tablename__ = "test_cases"
    __test__ = False  # not a pytest class
    __table_args__ = (db.UniqueConstraint("app_id", "name", name="uq_testcase_app_name"),)
    id = db.Column(db.Integer, primary_key=True)
    app_id = db.Column(
        db.Integer, db.ForeignKey("applications.id", ondelete="CASCADE"), nullable=False, index=True
    )
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False, default="")
    depends_on_tc_id = db.Column(
        db.Integer, db.ForeignKey("test_cases.id", ondelete="SET NULL"), nullable=True
    )
    is_reusable_block = db.Column(db.Boolean, nullable=False, default=False)
    # A reusable block run after the steps even when one of them failed, to log out or
    # delete test data. Not run when the run is aborted.
    teardown_block_id = db.Column(
        db.Integer, db.ForeignKey("test_cases.id", ondelete="SET NULL"), nullable=True
    )
    created_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    updated_at = db.Column(db.DateTime, nullable=False, default=utcnow, onupdate=utcnow)

    application = db.relationship("Application", back_populates="test_cases")
    depends_on = db.relationship("TestCase", remote_side=[id], foreign_keys=[depends_on_tc_id])
    teardown_block = db.relationship("TestCase", remote_side=[id], foreign_keys=[teardown_block_id])
    creator = db.relationship("User")
    steps = db.relationship(
        "TestStep", back_populates="test_case", cascade="all, delete-orphan",
        order_by="TestStep.step_order",
    )


class TestStep(db.Model):
    __tablename__ = "test_steps"
    __test__ = False
    id = db.Column(db.Integer, primary_key=True)
    test_case_id = db.Column(
        db.Integer, db.ForeignKey("test_cases.id", ondelete="CASCADE"), nullable=False, index=True
    )
    step_order = db.Column(db.Integer, nullable=False)
    action_keyword = db.Column(db.String(40), nullable=False)
    locator_type = db.Column(db.String(20), nullable=True)
    locator_value = db.Column(db.Text, nullable=True)
    input_data = db.Column(db.Text, nullable=True)
    store_variable_name = db.Column(db.String(100), nullable=True)
    description = db.Column(db.Text, nullable=True)

    test_case = db.relationship("TestCase", back_populates="steps")


class TestRun(db.Model):
    __tablename__ = "test_runs"
    __test__ = False
    id = db.Column(db.Integer, primary_key=True)
    app_id = db.Column(
        db.Integer, db.ForeignKey("applications.id", ondelete="CASCADE"), nullable=False, index=True
    )
    triggered_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    # Run number within its application (1, 2, 3 ...), shown to users. id stays
    # the global key used in URLs.
    run_no = db.Column(db.Integer, nullable=True)
    # requested_browser and browser_used differ only after a fallback.
    requested_browser = db.Column(db.String(10), nullable=False, default="msedge")
    browser_used = db.Column(db.String(10), nullable=False, default="msedge")
    headless = db.Column(db.Boolean, nullable=False, default=True)
    status = db.Column(db.String(20), nullable=False, default=RUN_QUEUED, index=True)
    abort_requested = db.Column(db.Boolean, nullable=False, default=False)
    total_tests = db.Column(db.Integer, nullable=False, default=0)
    passed_tests = db.Column(db.Integer, nullable=False, default=0)
    failed_tests = db.Column(db.Integer, nullable=False, default=0)
    skipped_tests = db.Column(db.Integer, nullable=False, default=0)
    runtime_variables_json = db.Column(db.Text, nullable=False, default="{}")
    notes = db.Column(db.Text, nullable=False, default="")
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)
    started_at = db.Column(db.DateTime, nullable=True)
    completed_at = db.Column(db.DateTime, nullable=True)

    application = db.relationship("Application", back_populates="runs")
    trigger_user = db.relationship("User")

    @property
    def number(self):
        """The run number users see: per application, falling back to id."""
        return self.run_no or self.id
    case_results = db.relationship(
        "TestCaseResult", back_populates="run", cascade="all, delete-orphan",
        passive_deletes=True, order_by="TestCaseResult.execution_order",
    )
    page_metrics = db.relationship(
        "PagePerformance", cascade="all, delete-orphan", passive_deletes=True,
        order_by="PagePerformance.id",
    )
    api_metrics = db.relationship(
        "ApiPerformance", cascade="all, delete-orphan", passive_deletes=True,
        order_by="ApiPerformance.id",
    )

    @property
    def active(self):
        return self.status in RUN_ACTIVE

    @property
    def duration_sec(self):
        if not self.started_at:
            return None
        return ((self.completed_at or utcnow()) - self.started_at).total_seconds()

    def add_note(self, text):
        self.notes = f"{self.notes}\n{text}".strip()


class TestCaseResult(db.Model):
    __tablename__ = "test_case_results"
    __test__ = False
    id = db.Column(db.Integer, primary_key=True)
    test_run_id = db.Column(
        db.Integer, db.ForeignKey("test_runs.id", ondelete="CASCADE"), nullable=False, index=True
    )
    # Run history must outlive the test case, so the link is nulled on delete
    # and the name is kept as a snapshot.
    test_case_id = db.Column(
        db.Integer, db.ForeignKey("test_cases.id", ondelete="SET NULL"), nullable=True
    )
    test_case_name = db.Column(db.String(200), nullable=False, default="")
    execution_order = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(20), nullable=False, default=TC_PENDING)
    error_message = db.Column(db.Text, nullable=True)
    duration_sec = db.Column(db.Float, nullable=True)
    total_steps = db.Column(db.Integer, nullable=False, default=0)
    current_step = db.Column(db.String(300), nullable=True)

    run = db.relationship("TestRun", back_populates="case_results")
    test_case = db.relationship("TestCase")
    step_results = db.relationship(
        "TestStepResult", back_populates="case_result", cascade="all, delete-orphan",
        passive_deletes=True, order_by="TestStepResult.step_order",
    )


class TestStepResult(db.Model):
    __tablename__ = "test_step_results"
    __test__ = False
    id = db.Column(db.Integer, primary_key=True)
    tc_result_id = db.Column(
        db.Integer, db.ForeignKey("test_case_results.id", ondelete="CASCADE"),
        nullable=False, index=True,
    )
    step_order = db.Column(db.Integer, nullable=False)
    action_keyword = db.Column(db.String(40), nullable=False)
    description = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(10), nullable=False)
    actual_value = db.Column(db.Text, nullable=True)
    error_details = db.Column(db.Text, nullable=True)
    # Deferred: polling the run page must not load megabytes of PNG per request.
    screenshot_base64 = deferred(db.Column(db.Text, nullable=True))
    timestamp = db.Column(db.DateTime, nullable=False, default=utcnow)

    case_result = db.relationship("TestCaseResult", back_populates="step_results")

    @property
    def diagnostics(self):
        """JS errors, console errors and failed HTTP calls the runner saw while this step
        failed, as a list of lines."""
        text = self.error_details or ""
        if DIAGNOSTICS_HEADING not in text:
            return []
        return text.split(DIAGNOSTICS_HEADING, 1)[1].split(DIAGNOSTICS_BULLET)


# How the runner appends diagnostics to a failed step's error_details.
DIAGNOSTICS_HEADING = "\nDiagnostics during step:\n- "
DIAGNOSTICS_BULLET = "\n- "

TestStepResult.has_screenshot = column_property(
    TestStepResult.__table__.c.screenshot_base64.isnot(None)
)


def _band(value, limits):
    fast, acceptable = limits
    return RATE_FAST if value <= fast else RATE_OK if value <= acceptable else RATE_SLOW


class PagePerformance(db.Model):
    """One document loaded in any tab or pop-up during a run."""
    __tablename__ = "page_performance"
    id = db.Column(db.Integer, primary_key=True)
    test_run_id = db.Column(
        db.Integer, db.ForeignKey("test_runs.id", ondelete="CASCADE"), nullable=False, index=True
    )
    tc_result_id = db.Column(
        db.Integer, db.ForeignKey("test_case_results.id", ondelete="CASCADE"), nullable=False,
        index=True,
    )
    step_order = db.Column(db.Integer, nullable=False)
    step_keyword = db.Column(db.String(40), nullable=False)
    opened_as = db.Column(db.String(10), nullable=False, default=OPENED_MAIN)
    url = db.Column(db.Text, nullable=False, default="")
    title = db.Column(db.String(200), nullable=True)
    http_status = db.Column(db.Integer, nullable=True)
    response_ms = db.Column(db.Float, nullable=True)
    first_paint_ms = db.Column(db.Float, nullable=True)
    dom_ready_ms = db.Column(db.Float, nullable=True)
    load_ms = db.Column(db.Float, nullable=True)
    request_count = db.Column(db.Integer, nullable=True)
    transfer_bytes = db.Column(db.Integer, nullable=True)
    error = db.Column(db.Text, nullable=True)

    case_result = db.relationship("TestCaseResult")

    @property
    def rating(self):
        if self.error or (self.http_status or 0) >= 400:
            return RATE_FAILED
        if self.load_ms is None:
            return RATE_UNFINISHED
        bands = [_band(self.load_ms, config.PERF_LOAD_MS)]
        if self.response_ms is not None:
            bands.append(_band(self.response_ms, config.PERF_RESPONSE_MS))
        for band in (RATE_SLOW, RATE_OK):
            if band in bands:
                return band
        return RATE_FAST


class ApiPerformance(db.Model):
    """AJAX/fetch calls grouped by test case and address. This is the response time
    of an Angular or React screen, which changes without any page load."""
    __tablename__ = "api_performance"
    id = db.Column(db.Integer, primary_key=True)
    test_run_id = db.Column(
        db.Integer, db.ForeignKey("test_runs.id", ondelete="CASCADE"), nullable=False, index=True
    )
    tc_result_id = db.Column(
        db.Integer, db.ForeignKey("test_case_results.id", ondelete="CASCADE"), nullable=False,
        index=True,
    )
    opened_as = db.Column(db.String(10), nullable=False, default=OPENED_MAIN)
    method = db.Column(db.String(10), nullable=False, default="GET")
    url = db.Column(db.Text, nullable=False, default="")
    http_status = db.Column(db.Integer, nullable=True)
    calls = db.Column(db.Integer, nullable=False, default=0)
    failed_calls = db.Column(db.Integer, nullable=False, default=0)
    average_ms = db.Column(db.Float, nullable=True)
    slowest_ms = db.Column(db.Float, nullable=True)

    case_result = db.relationship("TestCaseResult")

    @property
    def rating(self):
        if self.failed_calls:
            return RATE_FAILED
        if self.slowest_ms is None:
            return RATE_UNKNOWN
        return _band(self.slowest_ms, config.PERF_API_MS)


_STEP_NUMBER_RE = re.compile(r"^\s*(?:step\s*)?(?:\d+[.):-]|[-*])\s*", re.I)


class TestingTool(db.Model):
    """A tool the Admin publishes in the Tool Library: details plus one downloadable file.
    The file lives in config.TOOLS_DIR under stored_name, never under the uploaded name."""
    __tablename__ = "testing_tools"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=False, default="")
    prerequisites = db.Column(db.Text, nullable=False, default="")
    instructions = db.Column(db.Text, nullable=False, default="")
    file_name = db.Column(db.String(255), nullable=False, default="")
    stored_name = db.Column(db.String(64), nullable=False, default="")
    file_size = db.Column(db.Integer, nullable=False, default=0)
    file_sha256 = db.Column(db.String(64), nullable=False, default="")
    uploaded_by = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=utcnow)

    uploader = db.relationship("User")

    @staticmethod
    def _lines(text_value):
        return [line.strip() for line in (text_value or "").splitlines() if line.strip()]

    @property
    def prerequisite_list(self):
        return [_STEP_NUMBER_RE.sub("", line) or line for line in self._lines(self.prerequisites)]

    @property
    def instruction_steps(self):
        """One step per line; numbers or bullets typed by the Admin are dropped, since
        the page numbers the steps itself."""
        return [_STEP_NUMBER_RE.sub("", line) or line for line in self._lines(self.instructions)]


def get_system_config():
    return db.session.get(SystemConfig, 1)


def _column_ddl(column, dialect):
    """The ADD COLUMN clause for a model column. SQLite refuses to add NOT NULL with
    no constant default, so such a column is added nullable, because old rows have
    no value to give it."""
    default = column.default.arg if column.default is not None and column.default.is_scalar else None
    clause = f'"{column.name}" {column.type.compile(dialect=dialect)}'
    if default is not None:
        if isinstance(default, bool):
            literal = str(int(default))
        elif isinstance(default, (int, float)):
            literal = str(default)
        else:
            quoted = str(default).replace("'", "''")
            literal = f"'{quoted}'"
        clause += f" DEFAULT {literal}"
        if not column.nullable:
            clause += " NOT NULL"
    elif column.nullable and len(column.foreign_keys) == 1:
        # SQLite allows a foreign key on an added column whose default is NULL, so an
        # upgraded database keeps ON DELETE behaviour the same as a new one.
        key = next(iter(column.foreign_keys))
        clause += f' REFERENCES "{key.column.table.name}"("{key.column.name}")'
        if key.ondelete:
            clause += f" ON DELETE {key.ondelete}"
    return clause


def _migrate_schema():
    """create_all() never changes a table that already exists, so a column added to a
    model after a database was created would make every query on that table fail.
    Add whatever is missing. Column names come from the models, never from input."""
    connection = db.session.connection()
    for table in db.metadata.sorted_tables:
        present = {
            row[1] for row in connection.execute(text(f'PRAGMA table_info("{table.name}")'))
        }
        for column in table.columns:
            if column.name not in present:
                ddl = _column_ddl(column, db.engine.dialect)
                connection.execute(text(f'ALTER TABLE "{table.name}" ADD COLUMN {ddl}'))
                log.info("Database upgrade: added %s.%s", table.name, column.name)
    db.session.commit()


def _application_rows(app_id):
    """(table, WHERE clause) for every row that belongs to an application, children first."""
    runs = "SELECT id FROM test_runs WHERE app_id = :app_id"
    results = f"SELECT id FROM test_case_results WHERE test_run_id IN ({runs})"
    cases = "SELECT id FROM test_cases WHERE app_id = :app_id"
    return [
        ("test_step_results", f"tc_result_id IN ({results})"),
        ("page_performance", f"test_run_id IN ({runs})"),
        ("api_performance", f"test_run_id IN ({runs})"),
        ("test_case_results", f"test_run_id IN ({runs})"),
        ("test_runs", "app_id = :app_id"),
        ("test_steps", f"test_case_id IN ({cases})"),
        ("test_cases", "app_id = :app_id"),
        ("applications", "id = :app_id"),
    ]


def purge_application(app_id):
    """Delete an application and everything that belongs to it: test cases and their
    steps, runs, test case and step results with their screenshots, and performance
    rows. Done table by table rather than trusting cascades, which a database without
    foreign keys switched on, or upgraded from an old version, would skip. secure_delete
    overwrites the freed pages, so screenshots and captured values do not linger in the
    file. Returns {table: rows deleted}. Commits; raises if anything is left."""
    params = {"app_id": app_id}
    removed = {}
    db.session.execute(text("PRAGMA secure_delete = ON"))
    try:
        # Links inside the application, so test cases can go in any order.
        db.session.execute(
            text("UPDATE test_cases SET depends_on_tc_id = NULL, teardown_block_id = NULL WHERE app_id = :app_id"),
            params,
        )
        # A run of another application cannot point at these test cases, but keep the
        # history of any that does rather than fail the delete.
        db.session.execute(text(
            "UPDATE test_case_results SET test_case_id = NULL WHERE test_case_id IN "
            "(SELECT id FROM test_cases WHERE app_id = :app_id)"
        ), params)
        for table, where in _application_rows(app_id):
            removed[table] = db.session.execute(text(f"DELETE FROM {table} WHERE {where}"), params).rowcount
        # Checked inside the transaction, so a delete that leaves anything changes nothing.
        left = {}
        for table, where in _application_rows(app_id):
            count = db.session.execute(text(f"SELECT COUNT(*) FROM {table} WHERE {where}"), params).scalar()
            if count:
                left[table] = count
        if left:
            raise RuntimeError(f"Application {app_id} was not fully deleted: {left}")
        db.session.commit()
    except Exception:
        db.session.rollback()
        raise
    finally:
        db.session.execute(text("PRAGMA secure_delete = OFF"))
    db.session.expire_all()  # objects loaded before the delete are read again, never written back
    try:
        # Moves the deletions out of the -wal file into the database, overwritten.
        db.session.execute(text("PRAGMA wal_checkpoint(TRUNCATE)"))
        db.session.commit()
    except Exception as exc:  # busy with a running run: SQLite checkpoints later anyway
        db.session.rollback()
        log.warning("Checkpoint after deleting application %s skipped: %s", app_id, exc)
    log.info("Deleted application %s: %s", app_id, removed)
    return removed


def next_run_number(app_id):
    """Reserve the next run number for an application inside the caller's
    transaction. The UPDATE takes SQLite's write lock, so two runs started at
    once cannot get the same number."""
    db.session.execute(
        update(Application).where(Application.id == app_id)
        .values(run_counter=Application.run_counter + 1)
    )
    return db.session.execute(
        select(Application.run_counter).where(Application.id == app_id)
    ).scalar_one()


def _number_runs_per_application():
    """Give runs created before per-application numbering a number, oldest first,
    continuing from what each application has already handed out."""
    pending = TestRun.query.filter(TestRun.run_no.is_(None)).order_by(TestRun.id).all()
    if not pending:
        return
    for run in pending:
        run.run_no = next_run_number(run.app_id)
    db.session.commit()
    log.info("Database upgrade: numbered %d runs per application", len(pending))


def init_db():
    """Create tables; on first start seed the Admin account and browser settings."""
    from engine.browser_factory import find_executable

    db.create_all()
    _migrate_schema()
    _number_runs_per_application()
    if not db.session.get(SystemConfig, 1):
        db.session.add(SystemConfig(
            id=1,
            default_browser="msedge",
            edge_executable_path=find_executable("msedge") or "",
            chrome_executable_path=find_executable("chrome") or "",
            default_headless=True,
            default_timeout_ms=30000,
        ))
    # Only an empty table: a deleted "admin" must not come back with the default password.
    if not User.query.first():
        admin = User(username="admin", email="admin@localhost", role=ROLE_ADMIN)
        admin.set_password("Admin@123")
        db.session.add(admin)
    db.session.commit()
