"""Self-service "forgot password": a strong temporary password sent by email.

Follows AppAssist. The web layer shows the same message whether or not the address
matched an account, and only stores the new password once the mail has been accepted,
so a mail failure can never lock anyone out.
"""
import logging
import secrets
import smtplib
from email.message import EmailMessage
from html import escape

import config

log = logging.getLogger(__name__)

# Letters and digits that are easy to confuse (O/0, l/1/I) are left out.
_LOWER = "abcdefghijkmnpqrstuvwxyz"
_UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ"
_DIGITS = "23456789"
_SYMBOLS = "!@#$%*?"
_SMTP_TIMEOUT_SECONDS = 30


def generate_temp_password(length=14):
    """A random password with at least one character of each class."""
    alphabet = _LOWER + _UPPER + _DIGITS + _SYMBOLS
    while True:
        password = "".join(secrets.choice(alphabet) for _ in range(length))
        if all(any(c in group for c in password) for group in (_LOWER, _UPPER, _DIGITS, _SYMBOLS)):
            return password


def _plain_body(username, temp_password):
    return (
        f"Hi {username},\n\n"
        "We received a request to reset the password for your QA Automation Portal account.\n\n"
        f"Your new temporary password is:\n\n    {temp_password}\n\n"
        "Please sign in and change it straight away using Change password in the side menu.\n\n"
        "If you did not request this reset, please contact your administrator.\n"
    )


def _html_body(username, temp_password):
    name, password = escape(username), escape(temp_password)
    return f"""\
<!DOCTYPE html>
<html><body style="margin:0;padding:24px;background:#f4f6f7;font-family:Segoe UI,Arial,sans-serif;">
<table role="presentation" width="520" cellpadding="0" cellspacing="0" align="center" style="background:#ffffff;border:1px solid #d9e0e3;">
  <tr><td style="background:#0f5e6e;color:#ffffff;padding:18px 28px;font-size:18px;font-weight:600;">Password reset</td></tr>
  <tr><td style="padding:24px 28px;color:#1f2d33;font-size:14px;line-height:1.6;">
    <p style="margin:0 0 14px;">Hi {name},</p>
    <p style="margin:0 0 14px;">We received a request to reset the password for your QA Automation Portal account. Your new temporary password is:</p>
    <p style="margin:0 0 18px;padding:14px;text-align:center;background:#f4f6f7;border:1px dashed #d9e0e3;font-family:Consolas,monospace;font-size:20px;font-weight:700;color:#0f5e6e;">{password}</p>
    <p style="margin:0 0 14px;">Please sign in and change it straight away using <strong>Change password</strong> in the side menu.</p>
    <p style="margin:0;color:#5c6b72;font-size:12.5px;">If you did not request this reset, please contact your administrator.</p>
  </td></tr>
</table>
</body></html>
"""


def send_password_reset_email(to_email, username, temp_password):
    """Return True once the mail server has accepted the message. Failures are logged,
    never raised, so the caller's response stays the same either way."""
    try:
        message = EmailMessage()
        message["From"] = config.EMAIL_FROM
        message["To"] = to_email
        message["Subject"] = "QA Automation Portal - your new temporary password"
        message.set_content(_plain_body(username, temp_password))
        message.add_alternative(_html_body(username, temp_password), subtype="html")
        with smtplib.SMTP(config.SMTP_SERVER, config.SMTP_PORT, timeout=_SMTP_TIMEOUT_SECONDS) as server:
            server.send_message(message)
    except Exception:
        log.exception("Password reset email for %s could not be sent", username)
        return False
    log.info("Password reset email sent for %s", username)
    return True
