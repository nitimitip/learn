/* QA Automation Portal UI behaviour. Plain JavaScript with no external calls. */
(function () {
  "use strict";

  function readJson(id) {
    return JSON.parse(document.getElementById(id).textContent);
  }

  function make(tag, attrs, text) {
    var el = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) { el.setAttribute(key, attrs[key]); });
    if (text !== undefined) { el.textContent = text; }
    return el;
  }

  /* ---- Confirm dialog for forms marked data-confirm ---- */
  function initConfirm() {
    var dialog = document.getElementById("confirm-dialog");
    var message = document.getElementById("confirm-message");
    var pending = null;
    document.addEventListener("submit", function (event) {
      var form = event.target;
      if (form.dataset.confirm && !form.dataset.confirmed) {
        event.preventDefault();
        pending = form;
        message.textContent = form.dataset.confirm;
        dialog.showModal();
      }
    });
    document.getElementById("confirm-cancel").addEventListener("click", function () {
      pending = null;
      dialog.close();
    });
    document.getElementById("confirm-ok").addEventListener("click", function () {
      dialog.close();
      if (pending) {
        pending.dataset.confirmed = "1";
        pending.requestSubmit();
      }
    });
  }

  /* ---- Generic dialog openers ---- */
  function initDialogs() {
    document.querySelectorAll("[data-open-dialog]").forEach(function (button) {
      button.addEventListener("click", function () {
        document.getElementById(button.dataset.openDialog).showModal();
      });
    });
    document.querySelectorAll("[data-close-dialog]").forEach(function (button) {
      button.addEventListener("click", function () { button.closest("dialog").close(); });
    });
  }

  /* ---- Drag to reorder, shared by the step list and the run queue ---- */
  function enableDragSort(container, onChange) {
    var dragged = null;
    container.addEventListener("dragstart", function (event) {
      // Only drag from the row itself, so text in inputs can still be selected.
      var active = document.activeElement;
      if (active && active.closest && active.closest("input, select, textarea") && container.contains(active)) {
        active.blur();
      }
      dragged = event.target.closest("[draggable]");
      if (dragged) {
        dragged.classList.add("dragging");
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", "");
      }
    });
    container.addEventListener("dragover", function (event) {
      var over = event.target.closest("[draggable]");
      if (!dragged || !over || over === dragged) { return; }
      event.preventDefault();
      container.querySelectorAll(".drop-target").forEach(function (el) { el.classList.remove("drop-target"); });
      over.classList.add("drop-target");
    });
    container.addEventListener("drop", function (event) {
      var over = event.target.closest("[draggable]");
      if (!dragged || !over || over === dragged) { return; }
      event.preventDefault();
      var items = Array.prototype.slice.call(container.children);
      if (items.indexOf(dragged) < items.indexOf(over)) {
        over.after(dragged);
      } else {
        over.before(dragged);
      }
      onChange();
    });
    container.addEventListener("dragend", function () {
      if (dragged) { dragged.classList.remove("dragging"); }
      dragged = null;
      container.querySelectorAll(".drop-target").forEach(function (el) { el.classList.remove("drop-target"); });
    });
  }

  /* ---- Step builder ---- */

  // A step is stored exactly as before: keyword, locator type, locator value, input data.
  // The editor shows proper fields and writes the typed form (button|Save, Login | 3,
  // visible || Login ...) into hidden inputs, so import, export and the engine are unchanged.

  var LOCATOR_LABELS = {
    id: "ID", id_ends_with: "ID ends with", name: "Name attribute", test_id: "Test ID",
    label: "Field label", placeholder: "Placeholder text", role: "Role and name",
    text: "Visible text", title: "Tooltip text", row_action: "Button in a table row",
    css: "CSS selector", xpath: "XPath",
  };
  var ROLE_NAMES = [
    "button", "link", "textbox", "checkbox", "radio", "combobox", "listbox", "option", "tab",
    "menuitem", "heading", "row", "cell", "columnheader", "gridcell", "dialog", "alert", "img",
    "switch", "searchbox", "spinbutton", "slider", "treeitem", "navigation",
  ];
  var KEY_NAMES = [
    "Enter", "Tab", "Escape", "Backspace", "Delete", "ArrowDown", "ArrowUp", "ArrowLeft",
    "ArrowRight", "Home", "End", "PageDown", "PageUp", "F5", "Control+A", "Control+C",
    "Control+V", "Shift+Tab",
  ];
  // Extra words the keyword search understands, beside each keyword's title and help.
  var SEARCH_WORDS = {
    NAVIGATE: "go url address visit browse link",
    WAIT_SECONDS: "pause sleep delay",
    WAIT_FOR_ELEMENT: "loading spinner ready",
    CLICK: "press tap button link",
    DOUBLE_CLICK: "press twice",
    FILL: "enter input write textbox set",
    TYPE_SEQUENTIALLY: "autocomplete search slowly",
    SELECT_DROPDOWN: "select option list combo pick",
    CHECK: "select checkbox radio",
    UNCHECK: "clear checkbox",
    PRESS_KEY: "enter tab escape keyboard shortcut",
    UPLOAD_FILE: "attach browse",
    HOVER: "mouse over menu",
    DRAG_AND_DROP: "move",
    SCROLL_TO: "page down up bottom top",
    PREPARE_DIALOG: "alert confirm prompt ok cancel",
    VERIFY_DIALOG_TEXT: "alert confirm prompt",
    VERIFY_ELEMENT_COUNT: "rows number table grid",
    VERIFY_DOWNLOAD: "export file excel pdf",
    CAPTURE_SCREENSHOT: "picture image photo proof",
  };

  function searchWords(name) {
    var words = SEARCH_WORDS[name] || "";
    if (name.indexOf("VERIFY") !== -1) { words += " assert validate expect confirm test"; }
    if (name.indexOf("STORE_") === 0) { words += " save capture read variable copy get"; }
    if (name.indexOf("BLOCK") !== -1) { words += " reuse shared steps function loop if condition"; }
    if (name.indexOf("WINDOW") !== -1) { words += " tab popup pop-up"; }
    if (name.indexOf("FRAME") !== -1) { words += " iframe"; }
    return words;
  }

  function trimmed(text) {
    return String(text === undefined || text === null ? "" : text).trim();
  }

  // options: [[value, label], ...]. A value not in the list is kept, so nothing typed
  // or imported earlier is lost by opening the editor.
  function choice(options, value, attrs) {
    var select = make("select", attrs || {});
    var known = false;
    options.forEach(function (option) {
      select.appendChild(make("option", { value: option[0] }, option[1]));
      if (option[0] === value) { known = true; }
    });
    if (value && !known) { select.appendChild(make("option", { value: value }, value)); }
    if (value || known) { select.value = value; }
    return select;
  }

  /* Locator value: "frame || frame || target @2". The same rules as engine/keywords.py. */

  function splitFrames(value) {
    var parts = [];
    var current = "";
    var i = 0;
    while (i < value.length) {
      if (value.charAt(i) === "\\" && value.substr(i + 1, 2) === "||") {
        current += "\\||";  // an escaped separator is plain text
        i += 3;
      } else if (value.substr(i, 2) === "||") {
        parts.push(current);
        current = "";
        i += 2;
      } else {
        current += value.charAt(i);
        i += 1;
      }
    }
    var target = current;
    return {
      frames: parts.map(trimmed).join(" || "),
      target: parts.length ? trimmed(target) : target,
    };
  }

  var INDEX_SUFFIX = /\s+@(first|last|\d+)$/;
  var XPATH_OPEN_END = /(?:[\/|(\[,=<>!+\-:]|\b(?:and|or|div|mod))$/;

  function parseLocator(type, raw) {
    var split = splitFrames(String(raw || ""));
    var state = { frames: split.frames, target: split.target, pick: "" };
    var match = INDEX_SUFFIX.exec(split.target);
    if (match) {
      var rest = split.target.slice(0, match.index);
      var attribute = type === "xpath" && XPATH_OPEN_END.test(rest.replace(/\s+$/, ""));
      if (trimmed(rest) && !attribute) {
        state.target = rest;
        state.pick = match[1];
      }
    }
    return state;
  }

  function composeLocator(state) {
    var frames = state.frames ? state.frames + " || " : "";
    if (!trimmed(state.target)) { return frames; }
    return frames + state.target + (state.pick ? " @" + state.pick : "");
  }

  /* Input data of the keywords that have a typed form. parse() returns the values for
     the fields, or null when the text cannot be shown in them, and then the step keeps
     one plain box with the text as typed. */
  function stepForms(locatorTypes) {
    var forms = {};
    var blockField = { key: "block", label: "Block to run", kind: "block" };
    var isNumber = /^\d+$/;

    forms.CALL_BLOCK = {
      fields: [blockField, { key: "pairs", label: "Values to give the block (optional)", kind: "pairs" }],
      parse: function (raw) {
        var text = trimmed(raw);
        var parts = text.split("|");
        var hasValues = parts.slice(1).some(function (part) { return part.indexOf("=") !== -1; });
        if (parts.length < 2 || !hasValues) { return { block: text, pairs: [] }; }
        var pairs = [];
        for (var i = 1; i < parts.length; i += 1) {
          var match = /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=([\s\S]*)$/.exec(parts[i]);
          if (!match) { return null; }
          pairs.push({ key: match[1], value: trimmed(match[2]) });
        }
        return { block: trimmed(parts[0]), pairs: pairs };
      },
      compose: function (state) {
        var text = state.block;
        state.pairs.forEach(function (pair) {
          if (pair.key || pair.value) { text += " | " + pair.key + "=" + pair.value; }
        });
        return text;
      },
    };

    forms.CALL_BLOCK_IF_VISIBLE = {
      fields: [blockField],
      parse: function (raw) { return { block: trimmed(raw) }; },
      compose: function (state) { return state.block; },
    };

    forms.REPEAT_BLOCK = {
      fields: [blockField, { key: "times", label: "How many times", kind: "number", min: 1, max: 50 }],
      parse: function (raw) {
        var text = trimmed(raw);
        if (!text) { return { block: "", times: "2" }; }
        var at = text.lastIndexOf("|");
        if (at === -1) { return { block: text, times: "" }; }
        var times = trimmed(text.slice(at + 1));
        if (!isNumber.test(times)) { return null; }
        return { block: trimmed(text.slice(0, at)), times: times };
      },
      compose: function (state) { return state.block ? state.block + " | " + state.times : ""; },
    };

    forms.REPEAT_BLOCK_UNTIL = {
      fields: [
        blockField,
        { key: "max", label: "Try at most (times)", kind: "number", min: 1, max: 50 },
        { key: "until", label: "Stop when the element shows this text (blank: when it is visible)", kind: "text", wide: true },
      ],
      parse: function (raw) {
        var text = trimmed(raw);
        if (!text) { return { block: "", max: "10", until: "" }; }
        var parts = text.split("|");
        var until = "";
        if (parts.length >= 3 && isNumber.test(trimmed(parts[parts.length - 2]))) {
          until = trimmed(parts.pop());
        }
        if (parts.length < 2) { return { block: text, max: "", until: "" }; }
        var max = trimmed(parts.pop());
        if (!isNumber.test(max)) { return null; }
        return { block: trimmed(parts.join("|")), max: max, until: until };
      },
      compose: function (state) {
        if (!state.block) { return ""; }
        return state.block + " | " + state.max + (state.until ? " | " + state.until : "");
      },
    };

    var textConditions = ["text_contains", "text_equals", "value_equals"];
    var elementConditions = ["visible", "not_visible", "enabled", "checked"];
    var operators = ["not_contains", "contains", "==", "!=", ">", "<"];  // longest first

    function onElement(state) { return state.mode === "element"; }
    function onVariable(state) { return state.mode === "variable"; }

    forms.CALL_BLOCK_IF = {
      fields: [
        { key: "mode", label: "Check", kind: "select", options: [["element", "An element on the page"], ["variable", "A stored variable"]] },
        { key: "cond", label: "The element", kind: "select", showIf: onElement, options: [
          ["visible", "is visible"], ["not_visible", "is not visible"], ["enabled", "is enabled"],
          ["checked", "is ticked"], ["text_contains", "has text containing"],
          ["text_equals", "has exactly this text"], ["value_equals", "has exactly this field value"],
        ] },
        { key: "expected", label: "Text", kind: "text", showIf: function (state) {
          return onElement(state) && textConditions.indexOf(state.cond) !== -1;
        } },
        { key: "variable", label: "Variable name", kind: "text", placeholder: "STATUS", showIf: onVariable },
        { key: "op", label: "Comparison", kind: "select", showIf: onVariable, options: [
          ["==", "equals"], ["!=", "does not equal"], ["contains", "contains"],
          ["not_contains", "does not contain"], [">", "is greater than"], ["<", "is less than"],
        ] },
        { key: "value", label: "Value", kind: "text", showIf: onVariable },
        blockField,
      ],
      // With no locator the engine reads the condition as one on a variable.
      noLocator: onVariable,
      parse: function (raw, hasLocator) {
        var state = { mode: "element", cond: "visible", expected: "", variable: "", op: "==", value: "", block: "" };
        var text = trimmed(raw);
        if (!text) { return state; }
        var at = text.lastIndexOf("||");
        state.block = trimmed(at === -1 ? text : text.slice(at + 2));
        if (at === -1) { return state; }
        var condition = trimmed(text.slice(0, at));
        var variable = /^\{([A-Za-z_][A-Za-z0-9_]*)\}\s*([\s\S]*)$/.exec(condition);
        if (!hasLocator && variable) {
          var rest = variable[2];
          for (var i = 0; i < operators.length; i += 1) {
            var op = operators[i];
            if (rest.indexOf(op) !== 0) { continue; }
            var expected = rest.slice(op.length);
            var word = /[a-z]/.test(op.charAt(0));
            if (word && expected && !/^\s/.test(expected)) { continue; }
            if (!word && /^[=<>!]/.test(expected)) { return null; }
            state.mode = "variable";
            state.variable = variable[1];
            state.op = op;
            state.value = trimmed(expected);
            return state;
          }
          return null;
        }
        var colon = condition.indexOf(":");
        var kind = trimmed(colon === -1 ? condition : condition.slice(0, colon)).toLowerCase();
        if (colon === -1 && elementConditions.indexOf(kind) !== -1) {
          state.cond = kind;
          return state;
        }
        if (colon !== -1 && textConditions.indexOf(kind) !== -1) {
          state.cond = kind;
          state.expected = trimmed(condition.slice(colon + 1));
          return state;
        }
        return null;
      },
      compose: function (state) {
        if (onVariable(state)) {
          var name = trimmed(state.variable).replace(/^\{/, "").replace(/\}$/, "");
          if (!name && !state.value && !state.block) { return ""; }
          return "{" + name + "} " + state.op + " " + state.value + " || " + state.block;
        }
        if (!state.block && state.cond === "visible") { return ""; }
        var hasText = textConditions.indexOf(state.cond) !== -1;
        return state.cond + (hasText ? ":" + state.expected : "") + " || " + state.block;
      },
    };

    forms.DRAG_AND_DROP = {
      fields: [
        { key: "type", label: "Drop target: found by", kind: "select", options: locatorTypes.map(function (type) {
          return [type, (LOCATOR_LABELS[type] || type) + " (" + type + ")"];
        }) },
        { key: "value", label: "Drop target: value", kind: "text", wide: true, placeholder: "#dropzone" },
      ],
      parse: function (raw) {
        var text = trimmed(raw);
        if (!text) { return { type: "css", value: "" }; }
        var at = text.indexOf("|");
        var type = trimmed(at === -1 ? "" : text.slice(0, at)).toLowerCase();
        if (locatorTypes.indexOf(type) === -1) { return null; }
        return { type: type, value: trimmed(text.slice(at + 1)) };
      },
      compose: function (state) { return state.value ? state.type + "|" + state.value : ""; },
    };

    forms.PREPARE_DIALOG = {
      fields: [
        { key: "answer", label: "Answer the pop-up with", kind: "select", options: [
          ["accept", "OK (accept)"], ["dismiss", "Cancel (dismiss)"], ["text", "Typed text, then OK"],
        ] },
        { key: "text", label: "Text to type", kind: "text", showIf: function (state) { return state.answer === "text"; } },
      ],
      parse: function (raw) {
        var text = trimmed(raw);
        var at = text.indexOf("|");
        var action = trimmed(at === -1 ? text : text.slice(0, at)).toLowerCase();
        if (!text || (action === "accept" && at === -1)) { return { answer: "accept", text: "" }; }
        if (action === "dismiss" && at === -1) { return { answer: "dismiss", text: "" }; }
        if (action === "accept") { return { answer: "text", text: text.slice(at + 1) }; }
        return null;
      },
      compose: function (state) {
        return state.answer === "text" ? "accept|" + state.text : state.answer;
      },
    };

    forms.VERIFY_ELEMENT_COUNT = {
      fields: [
        { key: "op", label: "There must be", kind: "select", options: [
          ["==", "exactly"], [">=", "at least"], [">", "more than"], ["<=", "at most"],
          ["<", "fewer than"], ["!=", "any number except"],
        ] },
        { key: "count", label: "Number", kind: "number", min: 0 },
      ],
      parse: function (raw) {
        if (!trimmed(raw)) { return { op: "==", count: "" }; }
        var match = /^\s*(==|!=|>=|<=|>|<)?\s*(\d+)\s*$/.exec(raw);
        return match ? { op: match[1] || "==", count: match[2] } : null;
      },
      compose: function (state) {
        if (state.count === "") { return ""; }
        return state.op === "==" ? state.count : state.op + " " + state.count;
      },
    };

    forms.SCROLL_TO = {
      fields: [
        { key: "where", label: "Scroll", kind: "select", options: [
          ["view", "Bring the element into view (needs a locator)"], ["bottom", "To the bottom"],
          ["top", "To the top"], ["pixels", "By a number of pixels"],
        ] },
        { key: "pixels", label: "Pixels (a minus number scrolls up)", kind: "number", showIf: function (state) {
          return state.where === "pixels";
        } },
      ],
      parse: function (raw) {
        var text = trimmed(raw).toLowerCase();
        if (!text) { return { where: "view", pixels: "500" }; }
        if (text === "top" || text === "bottom") { return { where: text, pixels: "500" }; }
        return /^[+-]?\d+$/.test(text) ? { where: "pixels", pixels: text } : null;
      },
      compose: function (state) {
        if (state.where === "view") { return ""; }
        return state.where === "pixels" ? state.pixels : state.where;
      },
    };

    forms.SWITCH_TO_WINDOW = {
      fields: [
        { key: "which", label: "Move to", kind: "select", options: [
          ["main", "The main (first) window"], ["number", "A window by its number"],
          ["text", "The window whose address or title contains"],
        ] },
        { key: "number", label: "Window number (0 is the main window)", kind: "number", min: 0, showIf: function (state) {
          return state.which === "number";
        } },
        { key: "text", label: "Part of the address or title", kind: "text", wide: true, showIf: function (state) {
          return state.which === "text";
        } },
      ],
      parse: function (raw) {
        var text = trimmed(raw);
        if (!text || text.toLowerCase() === "main") { return { which: "main", number: "1", text: "" }; }
        if (isNumber.test(text)) { return { which: "number", number: text, text: "" }; }
        return { which: "text", number: "1", text: text };
      },
      compose: function (state) {
        if (state.which === "main") { return "main"; }
        return state.which === "number" ? state.number : state.text;
      },
    };

    return forms;
  }

  /* Searchable list of every keyword, in plain words. */
  function initKeywordDialog(keywords) {
    var dialog = document.getElementById("keyword-dialog");
    var search = document.getElementById("keyword-search");
    var results = document.getElementById("keyword-results");
    var none = document.getElementById("keyword-none");
    var target = null;
    var groups = {};
    var items = [];

    Object.keys(keywords).forEach(function (name) {
      var spec = keywords[name];
      if (!groups[spec.category]) {
        var section = make("section", { "class": "kw-group" });
        section.appendChild(make("h3", {}, spec.category));
        groups[spec.category] = section;
        results.appendChild(section);
      }
      var button = make("button", { type: "button", "class": "kw-item", "data-keyword": name });
      var head = make("span", { "class": "kw-item-head" });
      head.appendChild(make("strong", {}, spec.title || name));
      head.appendChild(make("code", { "class": "kw-badge" }, name));
      button.appendChild(head);
      button.appendChild(make("span", { "class": "kw-item-help" }, spec.help));
      groups[spec.category].appendChild(button);
      items.push({
        button: button,
        text: [spec.title, name, name.replace(/_/g, " "), spec.help, spec.category, searchWords(name)]
          .join(" ").toLowerCase(),
      });
    });

    function filter() {
      var words = search.value.toLowerCase().split(/\s+/).filter(Boolean);
      var shown = 0;
      items.forEach(function (item) {
        var match = words.every(function (word) { return item.text.indexOf(word) !== -1; });
        item.button.hidden = !match;
        if (match) { shown += 1; }
      });
      Object.keys(groups).forEach(function (category) {
        groups[category].hidden = !groups[category].querySelector(".kw-item:not([hidden])");
      });
      none.hidden = shown > 0;
    }

    search.addEventListener("input", filter);
    search.addEventListener("keydown", function (event) {
      if (event.key !== "Enter") { return; }
      event.preventDefault();
      var first = results.querySelector(".kw-item:not([hidden])");
      if (first) { first.click(); }
    });
    results.addEventListener("click", function (event) {
      var button = event.target.closest(".kw-item");
      if (!button || !target) { return; }
      target.value = button.dataset.keyword;
      target.dispatchEvent(new Event("change", { bubbles: true }));
      dialog.close();
      target.focus();
    });

    return {
      open: function (select) {
        target = select;
        search.value = "";
        filter();
        dialog.showModal();
        search.focus();
      },
    };
  }

  function initStepBuilder(form) {
    var keywords = readJson("keyword-data");
    var locatorTypes = readJson("locator-data");
    var blockNames = readJson("block-data");
    var forms = stepForms(locatorTypes);
    var list = document.getElementById("steps");
    var noSteps = document.getElementById("no-steps");
    var keywordDialog = initKeywordDialog(keywords);
    var counter = 0;
    var UNKNOWN = { locator: "optional", input: "optional", store: "optional", help: "", input_hint: "" };

    function keywordSelect(value) {
      var select = make("select", { "data-field": "action_keyword" });
      var groups = {};
      Object.keys(keywords).forEach(function (name) {
        var category = keywords[name].category;
        if (!groups[category]) {
          groups[category] = make("optgroup", { label: category });
          select.appendChild(groups[category]);
        }
        var title = keywords[name].title;
        groups[category].appendChild(make("option", { value: name }, title ? title + " (" + name + ")" : name));
      });
      if (value && !keywords[value]) {
        // Keep a rejected value visible so the server's error makes sense.
        select.appendChild(make("option", { value: value }, value));
      }
      select.value = value || "CLICK";
      return select;
    }

    function field(cssClass, labelText, control) {
      var label = make("label", { "class": cssClass }, labelText);
      label.appendChild(control);
      return label;
    }

    function fieldOf(row, name) {
      return row.querySelector('[data-field="' + name + '"]');
    }

    /* ---- Locator fields ---- */

    function pickState(row) {
      var pick = row.querySelector('[data-loc="pick"]').value;
      return pick === "n" ? trimmed(row.querySelector('[data-loc="nth"]').value) : pick;
    }

    function targetOf(row) {
      var part = function (name) {
        var input = row.querySelector('[data-part="' + name + '"]');
        return input ? input.value : "";
      };
      var type = row._locType;
      if (type === "role") {
        var role = trimmed(part("role"));
        var name = trimmed(part("name"));
        return name ? role + "|" + name : role;
      }
      if (type === "row_action") {
        var rowText = trimmed(part("row"));
        var action = trimmed(part("action"));
        return rowText || action ? rowText + " | " + action : "";
      }
      return part("value");
    }

    function saveLocator(row) {
      row.querySelector(".loc-nth").hidden = row.querySelector('[data-loc="pick"]').value !== "n";
      fieldOf(row, "locator_value").value = composeLocator({
        frames: trimmed(row.querySelector('[data-loc="frames"]').value),
        target: targetOf(row),
        pick: pickState(row),
      });
    }

    // Shows the stored locator value in the fields. state replaces what is stored, for a
    // change of locator type that keeps the frame and the pick but not the old target.
    function loadLocator(row, state) {
      var type = fieldOf(row, "locator_type").value;
      state = state || parseLocator(type, fieldOf(row, "locator_value").value);
      row._locType = type;
      row.querySelector('[data-loc="frames"]').value = state.frames;
      var pick = row.querySelector('[data-loc="pick"]');
      var nth = row.querySelector('[data-loc="nth"]');
      if (/^\d+$/.test(state.pick)) {
        pick.value = "n";
        nth.value = state.pick;
      } else {
        pick.value = state.pick;
      }
      var more = row.querySelector(".loc-more");
      if (state.frames || state.pick) { more.open = true; }

      var box = row.querySelector(".loc-target");
      box.textContent = "";
      function part(name, labelText, value, attrs) {
        var input = make("input", attrs || {});
        input.setAttribute("data-part", name);
        input.value = value;
        box.appendChild(field("g-field", labelText, input));
      }
      var target = state.target;
      var at;
      if (type === "role") {
        at = target.indexOf("|");
        part("role", "Role", trimmed(at === -1 ? target : target.slice(0, at)), { list: "role-names", placeholder: "button" });
        part("name", "Name or text on it", at === -1 ? "" : trimmed(target.slice(at + 1)), { placeholder: "Save" });
      } else if (type === "row_action") {
        at = target.lastIndexOf("|");
        part("row", "Row text", trimmed(at === -1 ? target : target.slice(0, at)), { placeholder: "PO-1042" });
        part("action", "Action", at === -1 ? "" : trimmed(target.slice(at + 1)), { placeholder: "Edit" });
      } else {
        part("value", "Locator value", target, { placeholder: row._locatorOptional ? "Optional" : "" });
      }
      saveLocator(row);
    }

    function changeLocatorType(row) {
      var special = function (type) { return type === "role" || type === "row_action"; };
      var type = fieldOf(row, "locator_type").value;
      var state = parseLocator(row._locType, fieldOf(row, "locator_value").value);
      // "button|Save" means nothing as a CSS selector, and the other way round.
      if (special(row._locType) || special(type)) { state.target = ""; }
      loadLocator(row, state);
    }

    /* ---- Input data fields ---- */

    function pairRow(pair) {
      var line = make("div", { "class": "g-pair" });
      var key = make("input", { "data-pair": "key", "aria-label": "Variable name", placeholder: "USER" });
      key.value = pair.key;
      var value = make("input", { "data-pair": "value", "aria-label": "Value", placeholder: "checker_01" });
      value.value = pair.value;
      line.appendChild(key);
      line.appendChild(make("span", { "aria-hidden": "true" }, "="));
      line.appendChild(value);
      line.appendChild(make("button", {
        type: "button", "class": "btn btn-icon", "data-pair-remove": "1", "aria-label": "Remove this value",
      }, "Remove"));
      return line;
    }

    function makeControl(spec, value) {
      if (spec.kind === "select") { return choice(spec.options, value); }
      if (spec.kind === "block") {
        var options = [["", blockNames.length ? "Choose a block" : "No reusable blocks yet"]];
        blockNames.forEach(function (name) { options.push([name, name]); });
        return choice(options, value);
      }
      if (spec.kind === "pairs") {
        var group = make("div", { "class": "g-pairs" });
        value.forEach(function (pair) { group.appendChild(pairRow(pair)); });
        group.appendChild(make("button", { type: "button", "class": "btn btn-icon", "data-pair-add": "1" }, "Add a value"));
        return group;
      }
      var attrs = { placeholder: spec.placeholder || "" };
      if (spec.kind === "number") {
        attrs.type = "number";
        if (spec.min !== undefined) { attrs.min = spec.min; }
        if (spec.max !== undefined) { attrs.max = spec.max; }
      }
      var input = make("input", attrs);
      input.value = value;
      return input;
    }

    function readControl(spec, control) {
      if (spec.kind !== "pairs") { return spec.kind === "text" ? control.value : trimmed(control.value); }
      return Array.prototype.map.call(control.querySelectorAll(".g-pair"), function (line) {
        return {
          key: trimmed(line.querySelector('[data-pair="key"]').value),
          value: trimmed(line.querySelector('[data-pair="value"]').value),
        };
      });
    }

    function buildInput(row, carryBlock) {
      var name = fieldOf(row, "action_keyword").value;
      var spec = keywords[name] || UNKNOWN;
      var raw = fieldOf(row, "input_data");
      var box = row.querySelector(".f-input");
      var holder = box.querySelector(".g-fields");
      var definition = forms[name];
      var state = definition ? definition.parse(raw.value, Boolean(trimmed(fieldOf(row, "locator_value").value))) : null;
      holder.textContent = "";
      box.classList.toggle("is-guided", Boolean(state));
      row._form = null;

      if (!state) {
        var input = make("input", { placeholder: spec.input_hint || "" });
        if (name === "PRESS_KEY") { input.setAttribute("list", "key-names"); }
        input.value = raw.value;
        holder.appendChild(field("g-field g-wide", "Input data", input));
        if (definition) {
          holder.appendChild(make("div", { "class": "g-note" },
            "This step was written by hand in a form the fields cannot show, so it is kept as text."));
        }
        row._syncInput = function () { raw.value = input.value; };
        return;
      }

      if (carryBlock && state.block !== undefined) { state.block = carryBlock; }
      var controls = {};
      var wrappers = {};
      definition.fields.forEach(function (item) {
        var control = makeControl(item, state[item.key]);
        var wrapper;
        if (item.kind === "pairs") {
          wrapper = make("div", { "class": "g-field g-wide" });
          wrapper.appendChild(make("span", { "class": "g-label" }, item.label));
          wrapper.appendChild(control);
        } else {
          wrapper = field("g-field" + (item.wide ? " g-wide" : ""), item.label, control);
        }
        controls[item.key] = control;
        wrappers[item.key] = wrapper;
        holder.appendChild(wrapper);
      });
      row._form = { state: state };
      row._syncInput = function () {
        definition.fields.forEach(function (item) { state[item.key] = readControl(item, controls[item.key]); });
        definition.fields.forEach(function (item) {
          wrappers[item.key].hidden = Boolean(item.showIf && !item.showIf(state));
        });
        row.classList.toggle("loc-unused", Boolean(definition.noLocator && definition.noLocator(state)));
        raw.value = definition.compose(state);
      };
      row._syncInput();
    }

    function applyKeyword(row) {
      var name = fieldOf(row, "action_keyword").value;
      var spec = keywords[name] || UNKNOWN;
      var changed = row._keyword !== undefined && row._keyword !== name;
      var carryBlock = changed && row._form && row._form.state.block ? row._form.state.block : "";
      // "Login | 3" means nothing to a keyword with other fields, so it is not carried over.
      if (changed && (row._form || forms[name])) { fieldOf(row, "input_data").value = ""; }
      row._keyword = name;
      row._locatorOptional = spec.locator === "optional";
      row.classList.remove("loc-unused");

      var locatorUsed = spec.locator !== "none";
      row.querySelector(".f-loc-type").classList.toggle("is-off", !locatorUsed);
      row.querySelector(".f-loc-value").classList.toggle("is-off", !locatorUsed);
      row.querySelector(".loc-more").classList.toggle("is-off", !locatorUsed);
      row.querySelector(".f-input").classList.toggle("is-off", spec.input === "none");
      row.querySelector(".f-store").classList.toggle("is-off", !spec.store);
      loadLocator(row);
      buildInput(row, carryBlock);
      fieldOf(row, "store_variable_name").placeholder = spec.store === "optional" ? "Optional" : "ORDER_ID";

      var help = row.querySelector(".step-help");
      help.textContent = "";
      help.appendChild(make("code", { "class": "kw-badge" }, name));
      help.appendChild(document.createTextNode(" " + spec.help));
    }

    function renumber() {
      Array.prototype.forEach.call(list.children, function (row, index) {
        row.querySelector(".step-number").textContent = index + 1;
      });
      noSteps.hidden = list.children.length > 0;
    }

    function addStep(step, afterRow) {
      counter += 1;
      step = step || {};
      var row = make("div", { "class": "step", "draggable": "true", "data-step": counter });

      var handle = make("div", { "class": "step-handle", "title": "Drag to reorder" });
      handle.appendChild(make("span", { "class": "step-number" }));
      handle.appendChild(make("span", { "aria-hidden": "true" }, "::"));
      row.appendChild(handle);

      var fields = make("div", { "class": "step-fields" });
      var keyword = keywordSelect(step.action_keyword);
      var keywordBox = make("div", { "class": "f-keyword" });
      keywordBox.appendChild(field("", "Keyword", keyword));
      keywordBox.appendChild(make("button", {
        type: "button", "class": "btn btn-icon", "data-action": "search",
        title: "Search for a step by what it does", "aria-label": "Search actions",
      }, "Search"));
      fields.appendChild(keywordBox);

      var locatorType = choice(locatorTypes.map(function (type) {
        return [type, (LOCATOR_LABELS[type] || type) + " (" + type + ")"];
      }), step.locator_type || "css", { "data-field": "locator_type" });
      fields.appendChild(field("f-loc-type", "Locator type", locatorType));

      var locatorBox = make("div", { "class": "f-loc-value" });
      var locatorValue = make("input", { type: "hidden", "data-field": "locator_value" });
      locatorValue.value = step.locator_value || "";
      locatorBox.appendChild(locatorValue);
      locatorBox.appendChild(make("div", { "class": "g-fields loc-target" }));
      fields.appendChild(locatorBox);

      var more = make("details", { "class": "loc-more" });
      more.appendChild(make("summary", {}, "Inside a frame, or one of several matches"));
      var moreFields = make("div", { "class": "g-fields" });
      moreFields.appendChild(field("g-field g-wide", "Inside this frame (CSS of the iframe; blank if none)",
        make("input", { "data-loc": "frames", placeholder: "iframe#editor" })));
      moreFields.appendChild(field("g-field", "If several elements match, use", choice([
        ["", "the only one (stop if there are several)"], ["first", "the first"], ["last", "the last"], ["n", "number ..."],
      ], "", { "data-loc": "pick" })));
      var nth = field("g-field loc-nth", "Which one, counting from 1", make("input", { type: "number", min: 1, "data-loc": "nth" }));
      nth.hidden = true;
      moreFields.appendChild(nth);
      more.appendChild(moreFields);
      fields.appendChild(more);

      var inputBox = make("div", { "class": "f-input" });
      var input = make("input", { type: "hidden", "data-field": "input_data" });
      input.value = step.input_data || "";
      inputBox.appendChild(input);
      inputBox.appendChild(make("div", { "class": "g-fields" }));
      fields.appendChild(inputBox);

      var store = make("input", { "data-field": "store_variable_name", "placeholder": "ORDER_ID" });
      store.value = step.store_variable_name || "";
      fields.appendChild(field("f-store", "Store as", store));

      var description = make("input", { "data-field": "description" });
      description.value = step.description || "";
      fields.appendChild(field("f-desc", "Description", description));

      fields.appendChild(make("div", { "class": "step-help" }));
      row.appendChild(fields);

      var buttons = make("div", { "class": "step-buttons" });
      [["up", "Up", "Move up"], ["down", "Down", "Move down"], ["copy", "Copy", "Duplicate step"], ["remove", "Del", "Remove step"], ["locate", "Find", "Find a locator from HTML for this step"]]
        .forEach(function (b) {
          buttons.appendChild(make("button", {
            type: "button", "class": "btn btn-icon", "data-action": b[0], title: b[2], "aria-label": b[2],
          }, b[1]));
        });
      row.appendChild(buttons);

      keyword.addEventListener("change", function () { applyKeyword(row); });
      locatorType.addEventListener("change", function () { changeLocatorType(row); });
      function sync(event) {
        var target = event.target;
        if (target === keyword || target === locatorType) { return; }
        if (target.closest(".f-loc-value, .loc-more")) {
          saveLocator(row);
        } else if (target.closest(".f-input")) {
          row._syncInput();
        }
      }
      fields.addEventListener("input", sync);
      fields.addEventListener("change", sync);
      inputBox.addEventListener("click", function (event) {
        var add = event.target.closest("[data-pair-add]");
        var remove = event.target.closest("[data-pair-remove]");
        if (add) {
          var line = pairRow({ key: "", value: "" });
          add.before(line);
          line.querySelector("input").focus();
        } else if (remove) {
          remove.closest(".g-pair").remove();
        } else {
          return;
        }
        row._syncInput();
      });

      if (afterRow) { afterRow.after(row); } else { list.appendChild(row); }
      applyKeyword(row);
      renumber();
      return row;
    }

    function readRow(row) {
      var data = {};
      row.querySelectorAll("[data-field]").forEach(function (el) {
        data[el.dataset.field] = el.value;
      });
      // A condition on a variable takes no locator, whatever was typed before the switch.
      if (row.classList.contains("loc-unused")) { data.locator_value = ""; }
      return data;
    }

    var locatorDialog = initLocatorDialog(list, keywords, addStep, applyKeyword);

    list.addEventListener("click", function (event) {
      var button = event.target.closest("[data-action]");
      if (!button) { return; }
      var row = button.closest(".step");
      var action = button.dataset.action;
      if (action === "locate") {
        locatorDialog.open(row);
        return;
      }
      if (action === "search") {
        keywordDialog.open(row.querySelector('[data-field="action_keyword"]'));
        return;
      }
      if (action === "up" && row.previousElementSibling) {
        row.previousElementSibling.before(row);
      } else if (action === "down" && row.nextElementSibling) {
        row.nextElementSibling.after(row);
      } else if (action === "copy") {
        addStep(readRow(row), row);
      } else if (action === "remove") {
        row.remove();
      }
      renumber();
    });

    // Rows are draggable from the handle only, so inputs keep normal selection.
    list.addEventListener("mousedown", function (event) {
      var row = event.target.closest(".step");
      if (row) { row.draggable = Boolean(event.target.closest(".step-handle")); }
    });
    enableDragSort(list, renumber);

    [["block-names", blockNames], ["role-names", ROLE_NAMES], ["key-names", KEY_NAMES]].forEach(function (entry) {
      var dataList = make("datalist", { id: entry[0] });
      entry[1].forEach(function (name) { dataList.appendChild(make("option", { value: name })); });
      form.appendChild(dataList);
    });

    // A token chip goes into the text box that was last typed in.
    var lastText = null;
    function rememberText(event) {
      var target = event.target;
      if (target.tagName === "INPUT" && target.type === "text" && !target.dataset.noToken) { lastText = target; }
    }
    list.addEventListener("focusin", rememberText);
    var tokenBar = form.querySelector(".token-bar");
    var chipTitle = "Click to put this in the box you were typing in";
    tokenBar.querySelectorAll(".token-chip").forEach(function (chip) { chip.title = chipTitle; });
    tokenBar.addEventListener("click", function (event) {
      var chip = event.target.closest(".token-chip");
      if (!chip || !lastText || !lastText.isConnected) { return; }
      var start = lastText.selectionStart === null ? lastText.value.length : lastText.selectionStart;
      var end = lastText.selectionEnd === null ? start : lastText.selectionEnd;
      lastText.value = lastText.value.slice(0, start) + chip.textContent + lastText.value.slice(end);
      lastText.focus();
      lastText.setSelectionRange(start + chip.textContent.length, start + chip.textContent.length);
      lastText.dispatchEvent(new Event("input", { bubbles: true }));
    });

    /* ---- Variables of the test case ---- */
    var variableList = document.getElementById("variables");
    var noVariables = document.getElementById("no-variables");
    var ownLabel = document.getElementById("own-token-label");

    function readVariables() {
      return Array.prototype.map.call(variableList.children, function (row) {
        return {
          name: row.querySelector('[data-var="name"]').value.trim(),
          value: row.querySelector('[data-var="value"]').value,
          keep: row.querySelector('[data-var="keep"]').checked,
        };
      });
    }

    // The test case's own variables are offered as chips next to the built-in tokens.
    function syncVariables() {
      noVariables.hidden = variableList.children.length > 0;
      tokenBar.querySelectorAll(".token-chip[data-own]").forEach(function (chip) { chip.remove(); });
      var names = [];
      readVariables().forEach(function (item) {
        if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(item.name) && names.indexOf(item.name) === -1) { names.push(item.name); }
      });
      ownLabel.hidden = names.length === 0;
      names.forEach(function (name) {
        tokenBar.appendChild(make("code", { "class": "token-chip", "data-own": "1", title: chipTitle }, "{" + name + "}"));
      });
    }

    function addVariable(item) {
      var row = make("div", { "class": "var-row" });
      var name = make("input", {
        type: "text", "data-var": "name", "data-no-token": "1", "aria-label": "Test case variable name",
        placeholder: "NEW_USER", maxlength: "100", autocomplete: "off", spellcheck: "false",
      });
      name.value = item.name || "";
      var value = make("input", {
        type: "text", "data-var": "value", "aria-label": "Test case variable value",
        placeholder: "qa{RANDOM_INT}", maxlength: "2000", autocomplete: "off", spellcheck: "false",
      });
      value.value = item.value || "";
      var keep = make("label", { "class": "check", title: "Use the value an earlier test case of the same run gave this name. The value here is used only when there is none." });
      var box = make("input", { type: "checkbox", "data-var": "keep" });
      box.checked = Boolean(item.keep);
      keep.appendChild(box);
      keep.appendChild(document.createTextNode(" Keep earlier value"));
      row.appendChild(name);
      row.appendChild(make("span", { "aria-hidden": "true" }, "="));
      row.appendChild(value);
      row.appendChild(keep);
      row.appendChild(make("button", {
        type: "button", "class": "btn btn-icon", "data-var-remove": "1", "aria-label": "Remove this variable",
      }, "Remove"));
      variableList.appendChild(row);
      return row;
    }

    variableList.addEventListener("focusin", rememberText);
    variableList.addEventListener("input", syncVariables);
    variableList.addEventListener("click", function (event) {
      var button = event.target.closest("[data-var-remove]");
      if (button) {
        button.closest(".var-row").remove();
        syncVariables();
      }
    });
    document.getElementById("add-variable").addEventListener("click", function () {
      addVariable({}).querySelector("input").focus();
      syncVariables();
    });
    readJson("variable-data").forEach(addVariable);
    syncVariables();

    document.getElementById("add-step").addEventListener("click", function () {
      var row = addStep({});
      row.querySelector("select").focus();
      row.scrollIntoView({ block: "nearest" });
    });

    readJson("step-data").forEach(function (step) { addStep(step); });
    renumber();

    form.addEventListener("submit", function () {
      var steps = Array.prototype.map.call(list.children, readRow);
      document.getElementById("steps-json").value = JSON.stringify(steps);
      document.getElementById("variables-json").value = JSON.stringify(readVariables());
    });
  }

  /* ---- Locator tool ---- */

  // navigator.clipboard only exists on HTTPS or localhost, and the portal is often served
  // over plain HTTP on the intranet. A dialog makes everything outside it inert, so the
  // fallback's text area has to sit inside the open dialog to take the selection.
  function copyText(text, near) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).catch(function () { return legacyCopy(text, near); });
    }
    return legacyCopy(text, near);
  }

  function legacyCopy(text, near) {
    var holder = make("textarea", { "class": "lt-copy-buffer", "aria-hidden": "true", readonly: "readonly" });
    holder.value = text;
    (near.closest("dialog") || document.body).appendChild(holder);
    holder.select();
    var copied = false;
    try { copied = document.execCommand("copy"); } catch (error) { copied = false; }
    holder.remove();
    near.focus();
    return copied ? Promise.resolve() : Promise.reject(new Error("copy refused"));
  }

  function flashButton(button, text, cssClass) {
    var original = button.textContent;
    button.textContent = text;
    button.classList.add(cssClass);
    setTimeout(function () {
      button.textContent = original;
      button.classList.remove(cssClass);
    }, 1200);
  }

  function renderCandidate(candidate, element, tool) {
    var row = make("tr", {});
    var typeCell = make("td", { "class": "lt-type" });
    typeCell.appendChild(make("span", { "class": "loc-type" }, candidate.type));
    if (candidate.best) { typeCell.appendChild(make("span", { "class": "pill pill-pass lt-best" }, "Best")); }
    row.appendChild(typeCell);

    var valueCell = make("td", { "class": "lt-value" });
    valueCell.appendChild(make("code", {}, candidate.value));
    if (candidate.note) { valueCell.appendChild(make("div", { "class": "muted small" }, candidate.note)); }
    candidate.warnings.forEach(function (warning) {
      valueCell.appendChild(make("div", { "class": "lt-warning small" }, warning));
    });
    row.appendChild(valueCell);

    var actions = make("td", { "class": "lt-actions" });
    var copy = make("button", {
      type: "button", "class": "btn btn-icon", "data-lt-copy": "1",
      "aria-label": "Copy " + candidate.type + " locator " + candidate.value,
    }, "Copy");
    copy.addEventListener("click", function () {
      copyText(candidate.value, copy).then(
        function () { flashButton(copy, "Copied", "lt-done"); },
        function () { flashButton(copy, "Press Ctrl+C", "lt-failed"); }
      );
    });
    actions.appendChild(copy);
    if (tool.onApply) {
      var apply = make("button", { type: "button", "class": "btn btn-icon btn-apply", "data-lt-apply": "1" }, tool.applyLabel());
      apply.addEventListener("click", function () { tool.onApply(candidate, element); });
      actions.appendChild(apply);
    }
    row.appendChild(actions);
    return row;
  }

  function renderElement(element, tool) {
    var box = make("article", { "class": "lt-element" });
    var head = make("div", { "class": "lt-element-head" });
    head.appendChild(make("strong", {}, element.title));
    var keyword = make("span", { "class": "kw-badge", title: "Suggested keyword" }, element.keyword);
    head.appendChild(keyword);
    if (element.needs_input) { head.appendChild(make("span", { "class": "muted small" }, "needs input data")); }
    box.appendChild(head);
    box.appendChild(make("code", { "class": "lt-opening" }, element.opening_tag));
    element.warnings.forEach(function (warning) {
      box.appendChild(make("div", { "class": "lt-warning small" }, warning));
    });
    var wrap = make("div", { "class": "table-wrap" });
    var table = make("table", { "class": "data lt-table" });
    var body = make("tbody", {});
    element.candidates.forEach(function (candidate) { body.appendChild(renderCandidate(candidate, element, tool)); });
    table.appendChild(body);
    wrap.appendChild(table);
    box.appendChild(wrap);
    return box;
  }

  // Reads the answer whatever it is: an expired session redirects to the login page, which is not JSON.
  function readLocatorAnswer(response) {
    return response.text().then(function (text) {
      var data = null;
      try { data = JSON.parse(text); } catch (error) { data = null; }
      if (data && data.error) { throw new Error(data.error); }
      if (!response.ok || !data || response.redirected) {
        throw new Error("Your session may have ended. Reload the page and try again.");
      }
      return data;
    });
  }

  function initLocatorTool(root, options) {
    options = options || {};
    var html = root.querySelector("[data-lt-html]");
    var hint = root.querySelector("[data-lt-hint]");
    var status = root.querySelector("[data-lt-status]");
    var results = root.querySelector("[data-lt-results]");
    var generate = root.querySelector("[data-lt-generate]");
    var tool = { onApply: options.onApply, applyLabel: options.applyLabel };

    function setStatus(text, isError) {
      status.textContent = text;
      status.classList.toggle("lt-error", Boolean(isError));
    }

    generate.addEventListener("click", function () {
      generate.disabled = true;
      setStatus("Reading the HTML...");
      results.textContent = "";
      fetch(root.dataset.url, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json", Accept: "application/json", "X-CSRF-Token": root.dataset.csrf },
        body: JSON.stringify({ html: html.value, hint: hint.value }),
      })
        .then(readLocatorAnswer)
        .then(function (data) {
          data.elements.forEach(function (element) { results.appendChild(renderElement(element, tool)); });
          var count = data.elements.length + (data.elements.length === 1 ? " element" : " elements");
          setStatus(data.truncated ? "Showing the first " + count + " of " + data.total + ". Paste a smaller part to see the rest." : "Found " + count + ".");
        })
        .catch(function (error) { setStatus(error.message || "The request failed. Try again.", true); })
        .finally(function () { generate.disabled = false; });
    });

    root.querySelector("[data-lt-clear]").addEventListener("click", function () {
      html.value = "";
      hint.value = "";
      results.textContent = "";
      setStatus("");
      html.focus();
    });

    return {
      refreshApplyLabels: function () {
        root.querySelectorAll("[data-lt-apply]").forEach(function (button) { button.textContent = tool.applyLabel(); });
      },
    };
  }

  function initLocatorDialog(list, keywords, addStep, applyKeyword) {
    var dialog = document.getElementById("locator-dialog");
    var picker = document.getElementById("locator-step");
    var setKeyword = document.getElementById("locator-set-keyword");
    var NEW_STEP = "new";
    var lastRow = null;

    function steps() { return Array.prototype.slice.call(list.children); }

    function fillPicker(row) {
      picker.textContent = "";
      steps().forEach(function (item, index) {
        var keyword = item.querySelector('[data-field="action_keyword"]').value;
        var description = item.querySelector('[data-field="description"]').value;
        picker.appendChild(make("option", { value: item.dataset.step },
          "Step " + (index + 1) + ": " + keyword + (description ? " - " + description : "")));
      });
      picker.appendChild(make("option", { value: NEW_STEP }, "A new step at the end"));
      picker.value = row ? row.dataset.step : NEW_STEP;
    }

    function chosenNumber() {
      var index = steps().findIndex(function (item) { return item.dataset.step === picker.value; });
      return index === -1 ? null : index + 1;
    }

    function applyLabel() {
      var number = chosenNumber();
      return number ? "Use in Step " + number : "Use in new step";
    }

    function apply(candidate, element) {
      var row = steps().find(function (item) { return item.dataset.step === picker.value; }) || addStep({});
      var keyword = row.querySelector('[data-field="action_keyword"]');
      // A keyword with no locator hides these fields, so the values would silently be dropped on save.
      var hasLocator = keywords[keyword.value] && keywords[keyword.value].locator !== "none";
      if (setKeyword.checked || !hasLocator) { keyword.value = element.keyword; }
      row.querySelector('[data-field="locator_type"]').value = candidate.type;
      row.querySelector('[data-field="locator_value"]').value = candidate.value;
      applyKeyword(row);
      lastRow = row;
      dialog.close();
      row.scrollIntoView({ block: "center" });
      row.classList.add("step-applied");
      setTimeout(function () { row.classList.remove("step-applied"); }, 1600);
      var first = row.querySelector(".loc-target input");
      if (first) { first.focus(); }
    }

    var tool = initLocatorTool(dialog.querySelector("[data-locator-tool]"), { onApply: apply, applyLabel: applyLabel });
    picker.addEventListener("change", tool.refreshApplyLabels);

    function open(row) {
      fillPicker(row);
      tool.refreshApplyLabels();
      dialog.showModal();
      dialog.querySelector("[data-lt-html]").focus();
    }

    // The toolbar button works on the step last touched, then the last step in the list.
    list.addEventListener("focusin", function (event) {
      var row = event.target.closest(".step");
      if (row) { lastRow = row; }
    });
    document.getElementById("find-locator").addEventListener("click", function () {
      var active = lastRow && lastRow.isConnected ? lastRow : list.lastElementChild;
      open(active);
    });
    return { open: open };
  }

  /* ---- Run queue ---- */
  function initRunSetup() {
    var queue = document.getElementById("queue");
    var field = document.getElementById("queue-field");
    var startButton = document.getElementById("start-run");
    var emptyNote = document.getElementById("queue-empty");
    var boxes = document.querySelectorAll("#available input[type=checkbox]");

    function sync() {
      var ids = [];
      Array.prototype.forEach.call(queue.children, function (item, index) {
        ids.push(item.dataset.caseId);
        item.querySelector(".q-num").textContent = (index + 1) + ".";
      });
      field.value = ids.join(",");
      startButton.disabled = ids.length === 0;
      emptyNote.hidden = ids.length > 0;
    }

    function addToQueue(box) {
      var item = make("li", { draggable: "true", "data-case-id": box.dataset.caseId });
      item.appendChild(make("span", { "class": "q-num" }));
      item.appendChild(make("span", { "class": "q-name" }, box.dataset.caseName));
      [["up", "Up"], ["down", "Down"]].forEach(function (b) {
        item.appendChild(make("button", {
          type: "button", "class": "btn btn-icon", "data-move": b[0],
          "aria-label": "Move " + box.dataset.caseName + " " + b[0],
        }, b[1]));
      });
      queue.appendChild(item);
    }

    boxes.forEach(function (box) {
      box.addEventListener("change", function () {
        if (box.checked) {
          addToQueue(box);
        } else {
          var item = queue.querySelector('[data-case-id="' + box.dataset.caseId + '"]');
          if (item) { item.remove(); }
        }
        sync();
      });
    });

    document.getElementById("add-all").addEventListener("click", function () {
      boxes.forEach(function (box) {
        if (!box.checked) {
          box.checked = true;
          addToQueue(box);
        }
      });
      sync();
    });

    queue.addEventListener("click", function (event) {
      var button = event.target.closest("[data-move]");
      if (!button) { return; }
      var item = button.closest("li");
      if (button.dataset.move === "up" && item.previousElementSibling) {
        item.previousElementSibling.before(item);
      } else if (button.dataset.move === "down" && item.nextElementSibling) {
        item.nextElementSibling.after(item);
      }
      sync();
    });
    enableDragSort(queue, sync);
    sync();
  }

  /* ---- Live run polling ---- */
  function initRunDetail(body) {
    if (body.dataset.active !== "true") { return; }
    var failures = 0;

    function openIds() {
      var open = {};
      body.querySelectorAll("details[id]").forEach(function (el) { open[el.id] = el.open; });
      return open;
    }

    function poll() {
      fetch(body.dataset.statusUrl, { credentials: "same-origin", headers: { Accept: "application/json" } })
        .then(function (response) {
          if (!response.ok) { throw new Error("HTTP " + response.status); }
          return response.json();
        })
        .then(function (data) {
          failures = 0;
          var previous = openIds();
          // The fragment is rendered and escaped by the server's template.
          body.innerHTML = data.html;
          // Keep what the reader expanded, but let newly failed cases open themselves.
          body.querySelectorAll("details[id]").forEach(function (el) {
            if (previous[el.id] && !el.open) { el.open = true; }
          });
          if (data.active) {
            setTimeout(poll, 1500);
          } else {
            var abortForm = document.getElementById("abort-form");
            if (abortForm) { abortForm.remove(); }
            var reports = document.getElementById("report-actions");
            if (reports) { reports.hidden = false; }
          }
        })
        .catch(function () {
          failures += 1;
          setTimeout(poll, Math.min(1500 * (failures + 1), 15000));
        });
    }
    setTimeout(poll, 1000);
  }

  /* ---- Admin browser detection ---- */
  function initDetect(button) {
    button.addEventListener("click", function () {
      button.disabled = true;
      fetch(button.dataset.url, { credentials: "same-origin" })
        .then(function (response) { return response.json(); })
        .then(function (data) {
          Object.keys(data).forEach(function (key) {
            var info = data[key];
            var item = document.querySelector('.detect-item[data-browser="' + key + '"]');
            var state = item.querySelector('[data-role="state"]');
            state.textContent = info.detected ? "Detected" : "Not found";
            state.className = "pill " + (info.detected ? "pill-pass" : "pill-fail");
            item.querySelector('[data-role="path"]').textContent = info.path || "No executable found";
            var warning = item.querySelector('[data-role="warning"]');
            warning.hidden = info.custom_path_valid;
            warning.textContent = "The saved custom path does not exist on this server: " + info.custom_path;
          });
        })
        .finally(function () { button.disabled = false; });
    });
  }

  /* ---- Application form: show only the relevant credential fields ---- */
  function initApplicationForm(form) {
    var authType = form.querySelector("#auth-type");
    function sync() {
      form.querySelectorAll("[data-auth]").forEach(function (el) {
        el.hidden = el.dataset.auth.split(" ").indexOf(authType.value) === -1;
      });
    }
    authType.addEventListener("change", sync);
    sync();
  }

  /* ---- Search box over a table: hides the rows that do not hold every word typed ---- */
  function initRowFilter(input) {
    var body = document.querySelector(input.dataset.filterRows);
    var count = document.querySelector(input.dataset.filterCount);
    var none = document.querySelector(input.dataset.filterNone);
    if (!body) { return; }
    var rows = Array.prototype.slice.call(body.children);
    var texts = rows.map(function (row) { return (row.dataset.filterText || row.textContent).toLowerCase(); });
    function apply() {
      var words = input.value.toLowerCase().split(/\s+/).filter(Boolean);
      var shown = 0;
      rows.forEach(function (row, index) {
        var match = words.every(function (word) { return texts[index].indexOf(word) !== -1; });
        row.hidden = !match;
        if (match) { shown += 1; }
      });
      if (count) {
        count.textContent = words.length
          ? shown + " of " + rows.length + " shown"
          : rows.length + (rows.length === 1 ? " application" : " applications");
      }
      if (none) { none.hidden = shown > 0; }
      body.closest("table").hidden = shown === 0;
    }
    input.addEventListener("input", apply);
    // A browser keeps the typed text when the user comes back to the page.
    apply();
  }

  document.addEventListener("DOMContentLoaded", function () {
    initConfirm();
    initDialogs();
    document.querySelectorAll("[data-filter-rows]").forEach(initRowFilter);
    var stepForm = document.querySelector('[data-page="step-builder"]');
    if (stepForm) { initStepBuilder(stepForm); }
    var standaloneTool = document.querySelector("[data-locator-tool]");
    if (standaloneTool && !standaloneTool.closest("dialog")) { initLocatorTool(standaloneTool); }
    if (document.querySelector('[data-page="run-setup"]')) { initRunSetup(); }
    var runBody = document.querySelector('[data-page="run-detail"]');
    if (runBody) { initRunDetail(runBody); }
    var detect = document.getElementById("detect-browsers");
    if (detect) { initDetect(detect); }
    var appForm = document.querySelector('[data-page="application-form"]');
    if (appForm) { initApplicationForm(appForm); }
  });
})();
