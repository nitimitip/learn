---
name: appassist-hld
description: Write a High-Level Design (HLD) in the Northern Powergrid AppAssist template. Use whenever the user asks to create, draft, write, update or revise an HLD or high-level design. Produces either a JSON draft that opens in AppAssist for review and editing (recommended) or the finished Word document in the official AppAssist template and colours.
---

# AppAssist HLD

Write a High-Level Design that follows the AppAssist HLD template exactly, then deliver it as an AppAssist JSON draft or as the finished Word document.

The template is fixed by AppAssist: 57 sections, in a set order, each with a set type. Content is bound to sections by database IDs, so always build the draft with the helper in `scripts/appassist_doc.py`. It addresses sections by number or title, applies the IDs for you, and checks the result. Never hand-write the JSON.

## Workflow

1. **Understand the request.** Read everything the user gave you: description, notes, emails, attached files. Find the project name; ask for it if it is missing, because it is printed on the cover.

2. **Ask which output the user wants**, once, before writing - unless they already said:
   - **AppAssist JSON file (recommended).** It opens with the Open button on the "Create & Download an HLD" page in AppAssist (Project Management). There the user can review and edit every section, switch a section to Not Required, save progress, and download the Word document.
   - **Final Word document.** The finished .docx in the official template. It cannot be opened in AppAssist for editing.

   Recommend the JSON file and say why in one sentence: the user can review and edit each section in AppAssist before the document is issued.

3. **Ask clarifying questions.** Compare what you know with what the template needs. Ask only about gaps that materially change the content, in ONE numbered batch of at most 6 short questions, most important first, with a suggested answer where you can. Typical gaps: business ask and scope; hosting (on-premise or cloud) and environments; components and technologies; integrations and data flows; data classification and volumes; authentication and user roles; service tier, RTO and RPO; support teams; risks, assumptions and dependencies.
   If the user says to proceed or to assume, stop asking, continue, and record each assumption.

4. **Read `references/template.md`** for the sections, their types, columns, fixed rows and guidance.

5. **Build the draft** with a Python script that uses the helper (see "Building the draft").

6. **Save and check.** `d.save()` writes the JSON and prints a report. Fix every ERROR and run again. Read each WARNING and either fix it or be ready to explain it.

7. **Deliver.**
   - JSON choice: give the user the `.json` file. Then tell them: open AppAssist > Project Management > Create & Download an HLD, click **Open**, choose the file, review and edit the sections, then click **Download Word**.
   - Word choice: call `d.docx()` and give the user the `.docx`. It is produced by AppAssist's own renderer, so the template, colours and fonts are exact. Offer the JSON file as well, in case they want to edit later.

8. **Close.** After the file, list briefly: assumptions you made; every TBC item and the section it is in; sections marked Not Required and why. Offer to revise. For a revision, change the script and regenerate the complete file - never hand over a fragment.

## Building the draft

```python
import sys
sys.path.insert(0, "<path to this skill>/scripts")
from appassist_doc import Draft

d = Draft.new("Customer Portal Replacement")

d.text("1", "The solution replaces ...\n- Hosting: ...\n- Integration: ...")
d.table("3.2", [["R1", "Business Requirements Document", "v1.0, Business Analysis"]],
        intro="Documents used in preparing this design.")
d.table("4.3.5", [["Silver", "08:00 to 17:30 Mon - Fri, excluding Public Holidays\n99.95% availability"]])
d.table("5.2.6", [["Portal web tier (DMZ)", "Fault API (corporate)", "Fault reports",
                   "HTTPS / 443", "TLS 1.2+, mutual authentication"]])
d.text("7.4", "N/A - the solution introduces no application user roles because ...")
d.table("11.1", [["RSK-1", "IF the identity service is delayed THEN go-live slips",
                  "Agree dates with the identity team", "Med", "Hi", "Project Manager"]])
d.not_required("9")

ok = d.save()          # writes <project>_HLD_draft.json and prints the report
# d.docx()             # only when the user chose the Word document
```

Helper calls (a section is its number or its exact title):

| Call | Use for |
|---|---|
| `d.text(section, content)` | NARRATIVE sections |
| `d.table(section, rows, intro=None)` | TABLE sections - replaces all rows; each row is a list in column order |
| `d.fixed(section, {label: [values]}, intro=None)` | completing FIXED ROWS without retyping their fixed text |
| `d.add_rows(section, rows)` | extra rows after the fixed ones |
| `d.not_required(section)` | a section that does not apply |
| `d.save(path=None)` | check, write the JSON, print the report; returns True when clean |
| `d.docx(path=None)` | write the Word document |

`Draft.new(name)` starts with every section present and empty, and fixed rows already in place. The helper raises a clear error if a section does not exist, is the wrong type, or a row has too many values - fix the script rather than working around it.

If you cannot run Python at all, say so and stop; do not type the JSON by hand. If only `d.docx()` fails because `python-docx` is unavailable, try `pip install python-docx`; if that is not possible, deliver the JSON file and tell the user to download the Word document from AppAssist. Only if the user insists on a Word file from you, build it by following `references/word-style-guide.md`.

## Writing rules

- Cover every section, in order. Never add, rename, merge or re-order sections.
- Follow each section's type and guidance. Guidance is for you; never copy it into the document.
- A section that truly does not apply is marked Not Required. Do not delete it and do not write filler to avoid an empty section.
- Never invent facts: names of people, dates, costs, volumes, server names, URLs, IP addresses, reference numbers, test or audit results. Where a fact is unknown write `TBC` in that cell or sentence and report it at the end.
- Professional UK English: plain, specific, third person, short paragraphs.
- Plain text only. A bullet is a line starting with `- `. Use `\n` between paragraphs and bullets, and for a line break inside a table cell. No Markdown, no HTML, no emoji.
- Tables: one fact per row, IDs sequential and unique, every row complete.
- A table's `intro` is one or two sentences that lead into it. Leave it out to get the default "Below is the brief description of <section title>."
- Never put passwords, keys or other secrets in the document; say where they are held instead.

## HLD rules

- Executive Summary: at most one page, short sentences and bullets, understandable by any stakeholder.
- Requirements tables: in "Solution Alignment" name the section of this document that meets the requirement.
- Target Service Level: ask which tier applies (Gold, Silver or Bronze) and keep only that row, with the standard characteristics shown in the template reference.
- Security and Compliance is mandatory: complete every sub-section. If one does not apply, keep it Required and write "N/A" with the reason; do not mark it Not Required.
- Technology: state product names and versions only if the user gave them. Network Integration needs one row per data flow: source and zone, destination and zone, data, protocol and port, security controls.
- Storage: give 1, 3 and 5 year figures in GB or TBC. DR and BCP: state RTO and RPO.
- Risks are written as IF ... THEN ... statements with mitigation, likelihood and impact (Hi, Med or Low) and an owner. Design decisions carry an ID, agreed date and rationale.
- You cannot draw diagrams. Where a diagram belongs, describe the architecture in words and add the line "Diagram to be inserted: <what it shows>".
- Elsewhere, where a sub-section does not apply, keep the heading and state why.

## Reference files

- `references/template.md` - every section: number, title, type, columns, fixed rows, guidance. Read it before writing.
- `references/json-format.md` - the shape of the JSON file, for information. The helper produces it.
- `references/word-style-guide.md` - the Word template's look. Needed only if the renderer cannot run.
- `assets/template.json` - the template data the helper reads, including the AppAssist database IDs. Do not edit it.

## Boundaries

You only produce HLDs here. For a BRD, an SSIA or a proposal deck, use the matching AppAssist skill. If the user asks for a different layout, colour scheme or section list, explain that the template is fixed by AppAssist and offer the closest compliant option.
