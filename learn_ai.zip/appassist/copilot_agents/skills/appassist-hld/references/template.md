# HLD template

Every section of the High-Level Design, in document order. Address a section in the helper by its
NUMBER (for example "2.4.1") or its exact TITLE.

Section types and the helper call that fills them:

- NARRATIVE - free text: `d.text(section, "...")`
- TABLE - rows of cells in the column order shown: `d.table(section, rows, intro=...)`
- TABLE with FIXED ROWS - the first column(s) are part of the form: `d.fixed(section, {first-cell text: [values for the remaining columns]})`

GUIDANCE is advice to you, the author. Never copy it into the document.

## Outline

```
1  Executive Summary   [NARRATIVE]
2  Context   [NARRATIVE]
3  Introduction   [NARRATIVE]
  3.1  Purpose   [NARRATIVE]
  3.2  References   [TABLE]
4  Scope   [NARRATIVE]
  4.1  In Scope   [NARRATIVE]
  4.2  Out of Scope   [NARRATIVE]
  4.3  Outcomes   [NARRATIVE]
    4.3.1  Non-Functional Requirements   [TABLE]
    4.3.2  Functional Requirements   [TABLE]
    4.3.3  Business or Client Problem   [NARRATIVE]
    4.3.4  Stakeholder Obligations   [NARRATIVE]
    4.3.5  Target Service Level   [TABLE]
5  Architectural Solution Design Overview   [NARRATIVE]
  5.1  Baseline Technology Architecture   [NARRATIVE]
  5.2  Target Technology Architecture   [NARRATIVE]
    5.2.1  Host Components   [NARRATIVE]
    5.2.2  Application Components   [NARRATIVE]
    5.2.3  Database Components   [NARRATIVE]
    5.2.4  Storage Components   [TABLE]
    5.2.5  Middleware Components   [NARRATIVE]
    5.2.6  Network Integration   [TABLE]
    5.2.7  Integration, Interface and Co-Existence   [NARRATIVE]
    5.2.8  Backup and Recovery   [NARRATIVE]
    5.2.9  DR and BCP   [NARRATIVE]
    5.2.10  As is:   [NARRATIVE]
    5.2.11  To-Be Conceptual Architecture   [NARRATIVE]
    5.2.12  Process View   [NARRATIVE]
  5.3  Architecture and Solution Design Decisions   [TABLE]
  5.4  Architecture Patterns and Integration Requirements   [TABLE]
6  Business Architecture   [NARRATIVE]
7  Security and Compliance   [NARRATIVE]
  7.1  Data Security   [NARRATIVE]
    7.1.1  Data Classification   [NARRATIVE]
    7.1.2  Data Encryption (In Transit & At Rest)   [NARRATIVE]
  7.2  Data Governance   [NARRATIVE]
  7.3  Identity and Access Management Controls   [NARRATIVE]
  7.4  User Roles   [NARRATIVE]
  7.5  Privileged System Roles   [NARRATIVE]
  7.6  Monitoring, Logging & Auditing   [NARRATIVE]
  7.7  Security Hardening   [NARRATIVE]
  7.8  Secrets Management   [NARRATIVE]
  7.9  Firewall & Network Security   [NARRATIVE]
  7.10  Compliance Requirements   [NARRATIVE]
  7.11  Security Testing   [NARRATIVE]
  7.12  Risk Management   [NARRATIVE]
  7.13  Security Operations   [NARRATIVE]
8  Implementation View   [TABLE]
9  Decommissioning   [NARRATIVE]
10  Support   [TABLE]
11  Risk, Assumptions, Issues and Dependencies   [NARRATIVE]
  11.1  Risks   [TABLE]
  11.2  Assumptions   [TABLE]
  11.3  Issues   [TABLE]
  11.4  Dependencies   [TABLE]
  11.5  Constraints   [TABLE]
```

## Section detail

### 1  Executive Summary
- TYPE: NARRATIVE
- GUIDANCE: Maximum of one page (two if summary graphics are included). Short sentences, extensive use of bullet points - the 'elevator pitch' any stakeholder can understand without the detail. Include a target solution overview diagram if it aids clarity.

### 2  Context
- TYPE: NARRATIVE
- GUIDANCE: Contextual information relevant to the solution. Outline the requirement or business ask, and the principles considered for the design.

### 3  Introduction
- TYPE: NARRATIVE
- GUIDANCE: Sets out the broad boundaries of the solution at a conceptual level. Where a sub-section does not apply, keep the heading and state why it does not apply, so the content template does not reduce over time.

### 3.1  Purpose
- TYPE: NARRATIVE
- GUIDANCE: State the purpose of the document - a common understanding of the technical architecture of the solution, its intended audience and what it must achieve.

### 3.2  References
- TYPE: TABLE
- GUIDANCE: Cite document name, location, author and version, and a URL where available.
- COLUMNS (3): ID | Title | Document Details

### 4  Scope
- TYPE: NARRATIVE
- GUIDANCE: The areas this project covers and does not cover, and the outcomes it delivers.

### 4.1  In Scope
- TYPE: NARRATIVE
- GUIDANCE: Outline the areas this project covers. Highlight which components are new and which are re-used; a simple context diagram helps.

### 4.2  Out of Scope
- TYPE: NARRATIVE
- GUIDANCE: Identify what is out of scope and, where known, the project/workstream it is in scope of and whether it was considered as part of this design.

### 4.3  Outcomes
- TYPE: NARRATIVE
- GUIDANCE: A bulleted list of outcomes the solution will provide - the basis for stakeholders to agree the solution gives them what they requested.

### 4.3.1  Non-Functional Requirements
- TYPE: TABLE
- GUIDANCE: Non-functional requirements identified as architecturally significant in delivering the outcomes.
- COLUMNS (3): ID | Non-Functional Requirement | Solution Alignment

### 4.3.2  Functional Requirements
- TYPE: TABLE
- GUIDANCE: Functional requirements identified as architecturally significant in delivering the outcomes; note in 'Solution Alignment' the section that meets each.
- COLUMNS (3): ID | Functional Requirement | Solution Alignment

### 4.3.3  Business or Client Problem
- TYPE: NARRATIVE
- GUIDANCE: The business need being addressed, described through business use cases and user stories.

### 4.3.4  Stakeholder Obligations
- TYPE: NARRATIVE
- GUIDANCE: Actions stakeholders must carry out that are obligations key to the delivery of the outcomes (not engagement obligations).

### 4.3.5  Target Service Level
- TYPE: TABLE
- GUIDANCE: Record the agreed service level for this solution and its characteristics. Standard NPg service tiers (keep the applicable one and delete the rest): Gold - Services provided all day, every day - 99.99% availability - Back on-line within 30 minutes of a failure - No more than one unplanned outage per year - Dual site resilience Silver - 08:00 to 17:30 Mon - Fri, excluding Public Holidays - 99.95% availability - Back on-line within 2 hours of a failure - Disaster recovery within 3 days of a failure - 6 months mean time between failures (MTBF) - Resilient within a single data centre Bronze - 08:00 to 17:30 Mon - Fri, excluding Public Holidays
- COLUMNS (2): Service Level | Characteristics
- STANDARD ROWS (3), already in a new draft. Replace them with `d.table` to keep only what applies.
  - Gold | Services provided all day, every day / 99.99% availability / Back on-line within 30 minutes of a failure / No more than one unplanned outage per year / Dual site resilience
  - Silver | 08:00 to 17:30 Mon - Fri, excluding Public Holidays / 99.95% availability / Back on-line within 2 hours of a failure / Disaster recovery within 3 days of a failure / 6 months mean time between failures (MTBF) / Resilient within a single data centre
  - Bronze | 08:00 to 17:30 Mon - Fri, excluding Public Holidays

### 5  Architectural Solution Design Overview
- TYPE: NARRATIVE
- GUIDANCE: The baseline and target technology architecture, the key design decisions and the patterns and integrations used within the solution.

### 5.1  Baseline Technology Architecture
- TYPE: NARRATIVE
- GUIDANCE: Include only where needed to inform key decisions - the foundation the solution will be built upon and the existing standards it must align with.

### 5.2  Target Technology Architecture
- TYPE: NARRATIVE
- GUIDANCE: All aspects of the target (to-be) architecture, with a high-level logical diagram of the end state plus diagrams for any significant transition states.

### 5.2.1  Host Components
- TYPE: NARRATIVE
- GUIDANCE: Standard (S/M/L) server sizing, existing vs new hardware, deployment locations and capacity requirements.

### 5.2.2  Application Components
- TYPE: NARRATIVE
- GUIDANCE: Application tiers (client/web/application/database), the technologies and versions proposed, and their vendor support status.

### 5.2.3  Database Components
- TYPE: NARRATIVE
- GUIDANCE: Expected data volumes, likely SAN storage needs and any Enterprise Service Bus functions.

### 5.2.4  Storage Components
- TYPE: TABLE
- GUIDANCE: 1 / 3 / 5 year storage growth forecast for environment management, placement and costing.
- COLUMNS (4): Storage Type | 1 Year (GB) | 3 Year (GB) | 5 Year (GB)

### 5.2.5  Middleware Components
- TYPE: NARRATIVE
- GUIDANCE: Any middleware required (e.g. Apache Tomcat, WebLogic, MuleSoft, JBoss, ActiveMQ).

### 5.2.6  Network Integration
- TYPE: TABLE
- GUIDANCE: Network impact, changed traffic patterns across WAN/LAN, encryption used and bandwidth impact. Include the data flow table.
- COLUMNS (5): Source System (Zone) | Destination System (Zone) | Data Description | Protocol / Port | Security Controls

### 5.2.7  Integration, Interface and Co-Existence
- TYPE: NARRATIVE
- GUIDANCE: Test/dev environments, the interfaces required (including to/from external organisations) and their nature (real-time, batch, read-only).

### 5.2.8  Backup and Recovery
- TYPE: NARRATIVE
- GUIDANCE: Which components require backups, how they are performed and any volumetric issues.

### 5.2.9  DR and BCP
- TYPE: NARRATIVE
- GUIDANCE: Disaster Recovery and Business Continuity approach, including how the solution meets the designated RTO and RPO and any testing obligations.

### 5.2.10  As is:
- TYPE: NARRATIVE
- GUIDANCE: How the service currently operates, to understand and compare against the existing environment.

### 5.2.11  To-Be Conceptual Architecture
- TYPE: NARRATIVE
- GUIDANCE: A conceptual view using objects familiar to the business; bring all elements together into as-is and to-be diagrams.

### 5.2.12  Process View
- TYPE: NARRATIVE
- GUIDANCE: Business process changes - the main process categories, the steps in each process and the role that carries out each step.

### 5.3  Architecture and Solution Design Decisions
- TYPE: TABLE
- GUIDANCE: Decisions that impact the overall solution and that might not adhere to standard patterns and integrations.
- COLUMNS (3): ID | Agreed Date | Decision and Rationale

### 5.4  Architecture Patterns and Integration Requirements
- TYPE: TABLE
- GUIDANCE: Proposed patterns and integrations used within the solution.
- COLUMNS (3): ID | Title Ref | Pattern & Integration Description

### 6  Business Architecture
- TYPE: NARRATIVE
- GUIDANCE: Each business role within the solution, plus any location or organisational changes and the impact to the overall business models.

### 7  Security and Compliance
- TYPE: NARRATIVE
- GUIDANCE: Mandatory section - complete all sub-sections. Where a sub-section is not applicable, denote it N/A. Refer to BHE Security Policies & NPg Baseline Security Controls.

### 7.1  Data Security
- TYPE: NARRATIVE
- GUIDANCE: Technical controls covering data integrity, content filtering, encryption and anonymisation, and the controls the DPIA requires for moving data between trust zones.

### 7.1.1  Data Classification
- TYPE: NARRATIVE
- GUIDANCE: How data is classified, tagged, tracked and stored.

### 7.1.2  Data Encryption (In Transit & At Rest)
- TYPE: NARRATIVE
- GUIDANCE: Encryption ciphers, bit depth and protocols for data at rest and in transit, where they are controlled from, and related cryptography (PKI, self-certs).

### 7.2  Data Governance
- TYPE: NARRATIVE
- GUIDANCE: Lifecycle management, ownership, quality and retention.

### 7.3  Identity and Access Management Controls
- TYPE: NARRATIVE
- GUIDANCE: SSO, MFA, PAM and access routing.

### 7.4  User Roles
- TYPE: NARRATIVE
- GUIDANCE: Application user roles and their permissions.

### 7.5  Privileged System Roles
- TYPE: NARRATIVE
- GUIDANCE: Administrative roles under least-privilege principles.

### 7.6  Monitoring, Logging & Auditing
- TYPE: NARRATIVE
- GUIDANCE: Event capture, logging and SIEM integration.

### 7.7  Security Hardening
- TYPE: NARRATIVE
- GUIDANCE: Hardening against corporate rules and CIS Benchmarks.

### 7.8  Secrets Management
- TYPE: NARRATIVE
- GUIDANCE: Credential, token and key storage.

### 7.9  Firewall & Network Security
- TYPE: NARRATIVE
- GUIDANCE: Boundary controls and intrusion detection.

### 7.10  Compliance Requirements
- TYPE: NARRATIVE
- GUIDANCE: Alignment with baseline security checklists and policies.

### 7.11  Security Testing
- TYPE: NARRATIVE
- GUIDANCE: Vulnerability scanning and SAST/DAST.

### 7.12  Risk Management
- TYPE: NARRATIVE
- GUIDANCE: Security risks, their categories and the controls applied.

### 7.13  Security Operations
- TYPE: NARRATIVE
- GUIDANCE: Operating model and SOC integration.

### 8  Implementation View
- TYPE: TABLE
- GUIDANCE: How the solution will be delivered - the high-level activities and the organisation teams responsible for each.
- COLUMNS (5): High-Level Activity | Organisation Team 1 | Organisation Team 2 | Organisation Team 3 | Organisation Team 4

### 9  Decommissioning
- TYPE: NARRATIVE
- GUIDANCE: How legacy components and data stores will be retired and securely sanitised once live.

### 10  Support
- TYPE: TABLE
- GUIDANCE: The support model for the solution and the responsibilities of each support team.
- COLUMNS (4): Responsibility | Support Team 1 | Support Team 2 | Support Team 3

### 11  Risk, Assumptions, Issues and Dependencies
- TYPE: NARRATIVE
- GUIDANCE: The project RAID position for this design.

### 11.1  Risks
- TYPE: TABLE
- GUIDANCE: Risks as IF/THEN statements with mitigation, likelihood, impact and owner.
- COLUMNS (6): ID | Risk (If, then statement) | Mitigation (How will the risk be managed) | Likelihood (Hi/Med/Low) | Impact (Hi/Med/Low) | Owner

### 11.2  Assumptions
- TYPE: TABLE
- GUIDANCE: Assumptions made, their origination and owner.
- COLUMNS (4): ID | Assumption | Origination | Owner

### 11.3  Issues
- TYPE: TABLE
- GUIDANCE: Current issues, their origination and owner.
- COLUMNS (4): ID | Issue | Origination | Owner

### 11.4  Dependencies
- TYPE: TABLE
- GUIDANCE: Dependencies the delivery relies upon and their owners.
- COLUMNS (3): ID | Dependencies | Owner

### 11.5  Constraints
- TYPE: TABLE
- GUIDANCE: Known constraints that influence the design decisions.
- COLUMNS (3): ID | Constraint | Solution Impact
