APPASSIST COPILOT SKILLS
========================================================================
Four skills for Microsoft 365 Copilot agents (Agent Builder, used from
Microsoft Teams or the Copilot app). One skill per module:

  appassist-brd.zip        Business Requirements Document
  appassist-hld.zip        High-Level Design
  appassist-ssia.zip       System Security Impact Assessment
  appassist-proposal.zip   Proposal deck

Each .zip is the upload package. The folder of the same name is its
unpacked content, kept so the files can be read and maintained.

WHAT A SKILL ADDS TO THE AGENT
  * The AppAssist template, loaded complete when the agent needs it.
  * A helper script that builds the AppAssist JSON draft for the agent
    (sections addressed by number or title; the database IDs are applied
    by the script) and checks it before it is handed over.
  * AppAssist's own renderer, so the "final document" option produces
    exactly what AppAssist produces: the Word document for BRD / HLD /
    SSIA, and the HTML presentation for the proposal.

HOW TO INSTALL
  1. Open the agent in Agent Builder > Configure > Skills > Add.
  2. Upload the matching .zip (upload the zip, not SKILL.md on its own).
  3. Keep Code interpreter ON - the skills run Python.
  4. Replace the agent's Instructions with the short text below. The
     longer Part 2 of <Module>_agent_config.txt is for an agent WITHOUT
     the skill; do not use both.

  Skills in Agent Builder may still be a preview feature in your tenant.
  If Configure shows no Skills section, use the *_agent_config.txt files
  on their own, as before.

INSTRUCTIONS FOR AN AGENT THAT HAS THE SKILL  (paste, replacing <DOC>)
  ----------------------------------------------------------------------
  You are the AppAssist <DOC> Agent for Northern Powergrid. Whenever the
  user asks for a <DOC>, use the appassist-<doc> skill and follow it
  exactly. Before writing, ask whether the user wants the AppAssist JSON
  file (recommended, because every section can then be reviewed and
  edited in AppAssist) or the final document. Ask clarifying questions in
  one short batch when information that matters is missing. Never invent
  facts; mark unknowns as TBC and list them at the end. You only produce
  <DOC>s; send other requests to the matching AppAssist agent.
  ----------------------------------------------------------------------
  <DOC> / <doc> is one of: BRD / brd, HLD / hld, SSIA / ssia,
  proposal deck / proposal.

  One agent can also carry all four skills (the limit is eight per
  agent) if you prefer a single "AppAssist Documents" agent.

THE DATABASE IDs  (BRD, HLD and SSIA only)
  AppAssist binds draft content to template sections by database ID.
  The IDs inside each skill (assets/template.json) were read from:
      C:\Users\anup0\OneDrive\Desktop\claude_code\appassist_v1\project_management.db
  Another installation (production) can have different IDs, and they
  change when an administrator edits a template. Symptom: a file opens
  in AppAssist with sections empty or content in the wrong section.

  To re-point a skill at another installation, export two CSV files
  (with a header row) from that database, once per document type
  ('brd', 'hld', 'ssia'):

    sections.csv
      SELECT id, parent_id, position, title FROM hld_template_sections
       WHERE doc_type = 'brd';
    columns.csv
      SELECT c.id, c.section_id, c.sort_order, c.name
        FROM hld_template_columns c
        JOIN hld_template_sections s ON s.id = c.section_id
       WHERE s.doc_type = 'brd';

  then, inside the unpacked skill folder:

    python scripts/appassist_doc.py set-ids sections.csv columns.csv

  The command checks that the database template matches the skill title
  for title before it changes anything, and lists the differences if it
  does not. Zip the folder again (SKILL.md at the top level of the zip)
  and upload it in place of the old one.

  The proposal skill has no IDs and works on every installation.

REQUIREMENTS IN THE COPILOT SANDBOX
  JSON drafts and the proposal deck need only standard Python.
  The Word document needs the python-docx package; if it is missing the
  skill tells the agent to deliver the JSON file instead.
