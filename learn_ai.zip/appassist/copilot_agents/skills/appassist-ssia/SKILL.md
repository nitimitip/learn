---
name: appassist-ssia
description: Write a System Security Impact Assessment (SSIA) in the Northern Powergrid AppAssist template. Use whenever the user asks to create, draft, write, update or revise an SSIA or system security impact assessment. Produces either a JSON draft that opens in AppAssist for review and editing (recommended) or the finished Word document in the official AppAssist template and colours.
---

# AppAssist SSIA

Write a System Security Impact Assessment that follows the AppAssist SSIA template exactly, then deliver it as an AppAssist JSON draft or as the finished Word document.

The template is fixed by AppAssist: 32 sections, in a set order, each with a set type. Content is bound to sections by database IDs, so always build the draft with the helper in `scripts/appassist_doc.py`. It addresses sections by number or title, applies the IDs for you, and checks the result. Never hand-write the JSON.

## Workflow

1. **Understand the request.** Read everything the user gave you: description, notes, emails, attached files. Find the project name; ask for it if it is missing, because it is printed on the cover.

2. **Ask which output the user wants**, once, before writing - unless they already said:
   - **AppAssist JSON file (recommended).** It opens with the Open button on the "Create & Download an SSIA" page in AppAssist (Project Management). There the user can review and edit every section, switch a section to Not Required, save progress, and download the Word document.
   - **Final Word document.** The finished .docx in the official template. It cannot be opened in AppAssist for editing.

   Recommend the JSON file and say why in one sentence: the user can review and edit each section in AppAssist before the document is issued.

3. **Ask clarifying questions.** Compare what you know with what the template needs. Ask only about gaps that materially change the content, in ONE numbered batch of at most 6 short questions, most important first, with a suggested answer where you can. Typical gaps: what the solution does and who uses it; hosting and whether it is cloud based; Internet exposure in or out; data processed (personal, financial) and DPIA reference; authentication and Active Directory; links to the operational control system (PoF) or Smart Metering; third parties and suppliers; whether it is a P1 service; encryption in transit and at rest; penetration test status.
   If the user says to proceed or to assume, stop asking, continue, and record each assumption.

4. **Read `references/template.md`** for the sections, their types, columns, fixed rows and guidance.

5. **Build the draft** with a Python script that uses the helper (see "Building the draft").

6. **Save and check.** `d.save()` writes the JSON and prints a report. Fix every ERROR and run again. Read each WARNING and either fix it or be ready to explain it.

7. **Deliver.**
   - JSON choice: give the user the `.json` file. Then tell them: open AppAssist > Project Management > Create & Download an SSIA, click **Open**, choose the file, review and edit the sections, then click **Download Word**.
   - Word choice: call `d.docx()` and give the user the `.docx`. It is produced by AppAssist's own renderer, so the template, colours and fonts are exact. Offer the JSON file as well, in case they want to edit later.

8. **Close.** After the file, list briefly: assumptions you made; every TBC item and the section it is in; sections marked Not Required and why. Offer to revise. For a revision, change the script and regenerate the complete file - never hand over a fragment.

## Building the draft

```python
import sys
sys.path.insert(0, "<path to this skill>/scripts")
from appassist_doc import Draft

d = Draft.new("Customer Portal Replacement")

d.text("1", "This screening was completed against the design at ...")
d.fixed("1.1", {"Name of Programme / Project / Policy": ["Customer Portal Replacement"],
                "Date Completed": ["TBC"]})
# Screening: the key is the question number; values fill Yes | No | N/A | Comments / Notes
d.fixed("1.2", {"3": ["Y", "", "", "Hosted in a public cloud tenancy."],
                "4": ["Y", "", "", "Customer name, address and contact details."],
                "16": ["", "", "N/A", "No third-party supplier is involved."]})
d.text("1.3", "A full SSIA is required. Questions 3 and 4 drive that outcome ...")
# Detailed question 3.3 expands screening question 3
d.answer("3.3", "Yes", "Provider, region and tenancy: ...\nIdentity and network controls: ...")
d.answer("3.2", "Not Applicable", "The solution has no connection to Smart Metering.")
d.fixed("6", {"Approval Signature": ["", ""]})

ok = d.save()          # writes <project>_SSIA_draft.json and prints the report
# d.docx()             # only when the user chose the Word document
```

Helper calls (a section is its number or its exact title):

| Call | Use for |
|---|---|
| `d.text(section, content)` | NARRATIVE sections |
| `d.table(section, rows, intro=None)` | TABLE sections - replaces all rows; each row is a list in column order |
| `d.fixed(section, {label: [values]}, intro=None)` | completing FIXED ROWS without retyping their fixed text |
| `d.add_rows(section, rows)` | extra rows after the fixed ones |
| `d.answer(section, response, detail)` | QUESTION sections - a short response, then the detail |
| `d.not_required(section)` | a section that does not apply |
| `d.save(path=None)` | check, write the JSON, print the report; returns True when clean |
| `d.docx(path=None)` | write the Word document |

`Draft.new(name)` starts with every section present and empty, and fixed rows already in place. The helper raises a clear error if a section does not exist, is the wrong type, or a row has too many values - fix the script rather than working around it.

If you cannot run Python at all, say so and stop; do not type the JSON by hand. If only `d.docx()` fails because `python-docx` is unavailable, try `pip install python-docx`; if that is not possible, deliver the JSON file and tell the user to download the Word document from AppAssist. Only if the user insists on a Word file from you, build it by following `references/word-style-guide.md`.

## Writing rules

- Cover every section, in order. Never add, rename, merge or re-order sections.
- Follow each section's type and guidance. Guidance is for you; never copy it into the document.
- A section that truly does not apply is marked Not Required. Do not delete it and do not write filler to avoid an empty section.
- Never invent facts: names of people, dates, costs, volumes, server names, URLs, IP addresses, reference numbers, test or audit results. Where a fact is unknown write `TBC` in that cell or sentence and report it at the end.
- Professional UK English: plain, specific, third person, short paragraphs.
- Plain text only. A bullet is a line starting with `- `. Use `\n` between paragraphs and bullets, and for a line break inside a table cell. No Markdown, no HTML, no emoji.
- Tables: one fact per row, IDs sequential and unique, every row complete.
- A table's `intro` is one or two sentences that lead into it. Leave it out to get the default "Below is the brief description of <section title>."
- Never put passwords, keys or other secrets in the document; say where they are held instead.

## SSIA rules

- Screening Questions: the 18 fixed questions are already in the draft; answer each with `d.fixed`. Mark exactly one of the Yes, No and N/A columns with "Y", "N" or "N/A", leave the other two empty, and justify every answer in Comments.
- "Reasons SSIA Is / Is Not Required": state plainly whether a full SSIA is required and which Yes answers caused it. Any Yes means it is required.
- Detailed questions: answer every one with exactly one row - a short response (for example Not Applicable, Yes, No, Partially, Controls in place) and then the full detail: boundary, protocol, authentication, encryption, monitoring, as the question's guidance asks. A blank answer is not an assessment; if a question does not apply, respond Not Applicable and say why.
- The assessment must not contradict itself: detailed question N expands screening question N, and both must describe the same security position as the architecture and deployment sections.
- Tables with fixed first-column labels (ownership, deployment summary, environments, governance, appendix, sign-off): keep the labels exactly and complete the other columns.
- Never state that a control, DPIA, audit or penetration test exists unless the user confirmed it. Otherwise write "TBC - to be confirmed by <role>".
- Sign-off and approval names stay blank unless the user supplied them. If an HLD exists, ask for it and keep the SSIA consistent with it.
- Detailed question N is section 3.N. Screening question N is the fixed row whose first cell is "N".
- Section 6 has two rows labelled "Name (in capitals)". To fill both, pass `d.fixed` a list of (label, values) pairs; they bind in row order.

## Reference files

- `references/template.md` - every section: number, title, type, columns, fixed rows, guidance. Read it before writing.
- `references/json-format.md` - the shape of the JSON file, for information. The helper produces it.
- `references/word-style-guide.md` - the Word template's look. Needed only if the renderer cannot run.
- `assets/template.json` - the template data the helper reads, including the AppAssist database IDs. Do not edit it.

## Boundaries

You only produce SSIAs here. For a BRD, an HLD or a proposal deck, use the matching AppAssist skill. If the user asks for a different layout, colour scheme or section list, explain that the template is fixed by AppAssist and offer the closest compliant option.
