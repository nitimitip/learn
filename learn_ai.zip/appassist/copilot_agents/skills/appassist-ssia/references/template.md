# SSIA template

Every section of the System Security Impact Assessment, in document order. Address a section in the helper by its
NUMBER (for example "2.4.1") or its exact TITLE.

Section types and the helper call that fills them:

- NARRATIVE - free text: `d.text(section, "...")`
- TABLE - rows of cells in the column order shown: `d.table(section, rows, intro=...)`
- TABLE with FIXED ROWS - the first column(s) are part of the form: `d.fixed(section, {first-cell text: [values for the remaining columns]})`
- QUESTION - one questionnaire item: `d.answer(section, response, detail)`

GUIDANCE is advice to you, the author. Never copy it into the document.

## Outline

```
1  System Security Impact Assessment Initial Screening Checklist   [NARRATIVE]
  1.1  Screening Ownership   [TABLE]
  1.2  Screening Questions   [TABLE]
  1.3  Reasons SSIA Is / Is Not Required   [NARRATIVE]
2  System Security Impact Assessment (SSIA) Detailed Assessment   [NARRATIVE]
  2.1  Assessment Ownership   [TABLE]
  2.2  Project Aim & Strategic Context   [NARRATIVE]
  2.3  Architecture Evolution (AS-IS vs TO-BE)   [TABLE]
  2.4  Application Deployment Summary   [TABLE]
  2.5  Application Environments & URLs   [TABLE]
3  Detailed Security Impact Assessment Questions   [NARRATIVE]
  3.1  Describe the security controls in place for connections to the operational control system (PoF) environment   [QUESTION]
  3.2  Describe the security controls in place for connections to the Smart Metering environment   [QUESTION]
  3.3  Detail the 'Cloud' solution   [QUESTION]
  3.4  Describe the personal or financial data being processed. Confirm that a DPIA has been completed and provide the reference   [QUESTION]
  3.5  Detail the security controls in place for the solution to accept incoming connections from the Internet   [QUESTION]
  3.6  Detail the security controls in place for the solution to make outbound connections to the Internet   [QUESTION]
  3.7  Detail the 3rd parties who will use this solution   [QUESTION]
  3.8  Detail how the users will authenticate   [QUESTION]
  3.9  Detail how the solution will integrate with Active Directory   [QUESTION]
  3.10  Detail the security controls in place for the solution to exchange data with other systems   [QUESTION]
  3.11  If the system is classified as P1, detail the security controls which will enable resilience   [QUESTION]
  3.12  Describe how the interaction with the regulatory requirements and data feeds will be protected   [QUESTION]
  3.13  Provide details of the regulation this solution must comply with   [QUESTION]
  3.14  Provide details on how authentication and cross boundary traffic is encrypted   [QUESTION]
  3.15  Provide details on how data is encrypted at rest   [QUESTION]
  3.16  Provide the process which will allow an audit of the supplier on IT security processes and principles, or the most recent information security audit report   [QUESTION]
  3.17  Provide the process the supplier will follow should there be a security incident, detailing the notification and engagement   [QUESTION]
  3.18  Provide the appropriate output from the most recent penetration test   [QUESTION]
4  SSIA Governance Overview   [TABLE]
5  Appendix & Reference Materials   [TABLE]
6  Authorisation & Sign-Off   [TABLE]
```

## Section detail

### 1  System Security Impact Assessment Initial Screening Checklist
- TYPE: NARRATIVE
- GUIDANCE: This checklist is used by any programme, project, policy or technical development that will touch on security issues. Answering 'Yes' to any of these questions is an indication that a full SSIA is required; answers can be expanded as the project develops.

### 1.1  Screening Ownership
- TYPE: TABLE
- GUIDANCE: Who completed the screening, in what role, and who authorised it. The field labels are pre-filled - complete the Details column.
- COLUMNS (2): Field | Details
- FIXED ROWS (5), already in a new draft. Complete each with `d.fixed`; the values you pass fill: Details
  - Name of Programme / Project / Policy
  - Individual completing SIA screening (name)
  - Individual completing SIA screening (role)
  - Date Completed
  - Authorised by

### 1.2  Screening Questions
- TYPE: TABLE
- GUIDANCE: Answer every question Yes / No / N/A and justify each answer in the comments. The standard question set is pre-filled - add a row for any additional screening question that applies.
- COLUMNS (6): No. | Screening Question | Yes | No | N/A | Comments / Notes
- FIXED ROWS (18), already in a new draft. Complete each with `d.fixed`; the values you pass fill: Yes | No | N/A | Comments / Notes
  - 1 | Does the solution access the operational control system (PoF) environment?
  - 2 | Does the solution access the Smart Metering environment?
  - 3 | Is the solution 'cloud' based?
  - 4 | Will the solution process any sensitive, personal, personnel or financial data?
  - 5 | Will the solution be required to accept incoming connections from the Internet?
  - 6 | Will the solution require an outbound connection to the Internet?
  - 7 | Will the solution be available to 3rd parties?
  - 8 | Will the solution require users to authenticate?
  - 9 | Will the solution integrate with Active Directory?
  - 10 | Will the solution require any data exchange with the operational control system, Smart Metering, or non-corporate networks?
  - 11 | Will the service be a P1 service?
  - 12 | Will the service interact with regulatory requirement data feeds?
  - 13 | Will the service provide a regulatory requirement?
  - 14 | Is all authentication and cross-network-boundary traffic encrypted?
  - 15 | Is data encrypted at rest?
  - 16 | Can we carry out an audit of the 3rd party for IT security processes and principles?
  - 17 | Is there an agreed process the supplier follows should there be a security incident?
  - 18 | Has a penetration test been performed on the solution?

### 1.3  Reasons SSIA Is / Is Not Required
- TYPE: NARRATIVE
- GUIDANCE: State plainly whether a full SSIA is required and which 'Yes' answers drove that outcome. Where no assessment is required, justify it.

### 2  System Security Impact Assessment (SSIA) Detailed Assessment
- TYPE: NARRATIVE
- GUIDANCE: The full detailed security impact assessment: the project parameters, the architectural objectives, and the specific security controls evaluated.

### 2.1  Assessment Ownership
- TYPE: TABLE
- GUIDANCE: Who carried out the detailed assessment, and how to reach them. The field labels are pre-filled - complete the Details column.
- COLUMNS (2): Field | Details
- FIXED ROWS (5), already in a new draft. Complete each with `d.fixed`; the values you pass fill: Details
  - Name of Project / Programme
  - Name
  - Role
  - Section
  - Contact Details

### 2.2  Project Aim & Strategic Context
- TYPE: NARRATIVE
- GUIDANCE: Explain what the project aims to achieve, the benefits to the business, to individuals and to other parties, and the security, governance and audit requirements it must continue to meet.

### 2.3  Architecture Evolution (AS-IS vs TO-BE)
- TYPE: TABLE
- GUIDANCE: The current position against the proposed position, so a reviewer can see exactly what changes.
- COLUMNS (2): Current State (AS-IS) | Proposed State (TO-BE)

### 2.4  Application Deployment Summary
- TYPE: TABLE
- GUIDANCE: Scope, business areas, workstream, user base, data and integrations. The field labels are pre-filled - complete the Details column.
- COLUMNS (2): Deployment Field | Details
- FIXED ROWS (6), already in a new draft. Complete each with `d.fixed`; the values you pass fill: Details
  - Scope
  - Business Areas
  - Workstream
  - Total User Base
  - Data
  - Integrations

### 2.5  Application Environments & URLs
- TYPE: TABLE
- GUIDANCE: Every environment the solution is deployed into, its address, and who can reach it.
- COLUMNS (3): Environment | URL / Endpoint | Hosting / Access Scope
- FIXED ROWS (2), already in a new draft. Complete each with `d.fixed`; the values you pass fill: URL / Endpoint | Hosting / Access Scope
  - Non-Production
  - Production

### 3  Detailed Security Impact Assessment Questions
- TYPE: NARRATIVE
- GUIDANCE: Answer every question below. Where a question does not apply, respond 'Not Applicable' and state why - a blank answer is not an assessment.

### 3.1  Describe the security controls in place for connections to the operational control system (PoF) environment
- TYPE: QUESTION
- GUIDANCE: If there is no connectivity, respond 'Not Applicable' and say why. Otherwise describe the boundary, the protocol, the authentication and the monitoring.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.2  Describe the security controls in place for connections to the Smart Metering environment
- TYPE: QUESTION
- GUIDANCE: Cover the interface, the data crossing it, and the controls protecting it.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.3  Detail the 'Cloud' solution
- TYPE: QUESTION
- GUIDANCE: Name the provider, region, tenancy model and service type, and the controls applied to identity, network, data and logging. Respond 'Not Applicable' for an on-premise solution.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.4  Describe the personal or financial data being processed. Confirm that a DPIA has been completed and provide the reference
- TYPE: QUESTION
- GUIDANCE: Identify the data categories, the lawful basis, the retention period, and the Data Protection Impact Assessment reference (or why one is not required).
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.5  Detail the security controls in place for the solution to accept incoming connections from the Internet
- TYPE: QUESTION
- GUIDANCE: Describe the perimeter: firewall, reverse proxy, WAF, TLS termination, authentication and rate limiting.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.6  Detail the security controls in place for the solution to make outbound connections to the Internet
- TYPE: QUESTION
- GUIDANCE: Describe egress control: proxy, allow-list, inspection and logging.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.7  Detail the 3rd parties who will use this solution
- TYPE: QUESTION
- GUIDANCE: Name each party, what they access, how access is granted and revoked, and the contractual security obligations that apply.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.8  Detail how the users will authenticate
- TYPE: QUESTION
- GUIDANCE: Describe the identity source, credential type, multi-factor position, session handling and the role-based access model.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.9  Detail how the solution will integrate with Active Directory
- TYPE: QUESTION
- GUIDANCE: Describe the integration method, the protocol and port, encryption in transit, the service accounts used, and group-to-role mapping.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.10  Detail the security controls in place for the solution to exchange data with other systems
- TYPE: QUESTION
- GUIDANCE: For each interface state the direction, transport, encryption, authentication and integrity checks.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.11  If the system is classified as P1, detail the security controls which will enable resilience
- TYPE: QUESTION
- GUIDANCE: Cover high availability, failover, backup and restore, RTO and RPO, and the disaster-recovery position.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.12  Describe how the interaction with the regulatory requirements and data feeds will be protected
- TYPE: QUESTION
- GUIDANCE: Identify each regulated feed, the boundary it crosses, and the controls protecting confidentiality, integrity and availability.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.13  Provide details of the regulation this solution must comply with
- TYPE: QUESTION
- GUIDANCE: List the applicable regulation and standards, and how compliance is evidenced.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.14  Provide details on how authentication and cross boundary traffic is encrypted
- TYPE: QUESTION
- GUIDANCE: State the protocols, versions, cipher policy and certificate management for every boundary crossed.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.15  Provide details on how data is encrypted at rest
- TYPE: QUESTION
- GUIDANCE: Cover the database, the file store and backup media, the mechanism used, and key management. Where encryption at rest is not applied, state the compensating controls.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.16  Provide the process which will allow an audit of the supplier on IT security processes and principles, or the most recent information security audit report
- TYPE: QUESTION
- GUIDANCE: State the audit right, its frequency, and reference the most recent information security audit report or certification.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.17  Provide the process the supplier will follow should there be a security incident, detailing the notification and engagement
- TYPE: QUESTION
- GUIDANCE: Cover detection, the notification timescale, the escalation path and the post-incident review commitment.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 3.18  Provide the appropriate output from the most recent penetration test
- TYPE: QUESTION
- GUIDANCE: Reference the test scope, date and tester, the findings by severity, and the remediation status of each.
- ANSWER: a short response, then the detail (Response | Details / Security Controls in Place)

### 4  SSIA Governance Overview
- TYPE: TABLE
- GUIDANCE: The governance review. The review questions are pre-filled - complete the Details / Recommendation column.
- COLUMNS (2): Governance Review Question | Details / Recommendation
- FIXED ROWS (2), already in a new draft. Complete each with `d.fixed`; the values you pass fill: Details / Recommendation
  - What changes have been made or recommended as a result of the SSIA process?
  - At which key milestones in the project's lifecycle will the SSIA be revisited?

### 5  Appendix & Reference Materials
- TYPE: TABLE
- GUIDANCE: Cite every supporting document by name, version and location, so the assessment can be re-created by someone else.
- COLUMNS (2): Field / Reference Document | Details & File Location
- FIXED ROWS (3), already in a new draft. Complete each with `d.fixed`; the values you pass fill: Details & File Location
  - High Level Design (HLD)
  - Network Details
  - DPIA Reference

### 6  Authorisation & Sign-Off
- TYPE: TABLE
- GUIDANCE: Approval is required by the IT Security Architect prior to gateway progression.
- COLUMNS (3): Role / Sign-Off Field | Name / Signature | Date
- FIXED ROWS (5), already in a new draft. Complete each with `d.fixed`; the values you pass fill: Name / Signature | Date
  - Person completing SSIA - Signature
  - Name (in capitals)
  - Updated By
  - Approval Signature
  - Name (in capitals)
