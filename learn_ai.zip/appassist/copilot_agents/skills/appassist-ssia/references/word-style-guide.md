# AppAssist SSIA - Word document style guide

Fallback only: `d.docx()` already produces this exact document. Use this guide only when the renderer cannot run and the user still needs a Word file from you.

```
1. COLOURS  (hex, no leading #)
------------------------------------------------------------------------
  9F1C33  brand red     top-level heading text, content-table header fill,
                        cover title panel fill, cover masthead text + rule
  7E1628  deep red      top-level heading NUMBER, table-header cell border,
                        header project name, footer "Northern Powergrid",
                        "DOCUMENT CONTROL" label, "Not applicable." lead-in
  17365D  navy          front-matter sub-headings, entry field labels,
                        sub-table captions
  4F81BD  blue          sub-section heading text (level 2 and deeper)
  385D8A  deep blue     sub-section heading NUMBER, paragraph-field labels
  1B1B20  ink           page titles, intro paragraph, grey-header text
  33333B  body          all body text and table cell text
  6B6B75  muted         notes, header document type, footer text
  FFFFFF  white         text on red fills
  E8B4BE  rose          secondary text on the red cover panel
  D9D9D9  grey header   front-matter table header fill, cover label column
  BFBFBF  grey border   borders of grey header cells and cover grids
  F2F2F2  zebra band    fill of every SECOND data row in every table
  C9CFD8  gridline      borders of ordinary data cells
  D7DEE7  hairline      header / footer separator rules
  EEF1F6  tint          "Not applicable" and confidentiality panel fill
  F8EFF2  answer tint   left (response) cell of an SSIA question


2. FONTS
------------------------------------------------------------------------
  Calibri   everything unless stated (the Normal style: Calibri 10.5 pt,
            colour 33333B)
  Georgia   cover masthead, cover title lines, page titles, heading NUMBERS
  Consolas  section numbers in the cached table of contents


3. PAGE SETUP
------------------------------------------------------------------------
  Margins: top 1.0 in, bottom 1.0 in, left 0.9 in, right 0.9 in.
  Header and footer distance from the page edge: 0.4 in.
  "Different first page" ON - the cover carries no header and no footer.

  Header (every page after the cover), one line with a right tab stop at
  the full text width and a D7DEE7 rule underneath:
      left   PROJECT NAME IN CAPITALS        8 pt bold 7E1628
      right  the document header label       8 pt 6B6B75
  Footer, one line with a D7DEE7 rule above:
      left   Confidential - NPg Internal Use Only      8 pt 6B6B75
      right  Page X of Y   -   Northern Powergrid      (PAGE and NUMPAGES
             fields; "Northern Powergrid" 8 pt bold 7E1628)

  Document properties: title "<document noun> - <project name>",
  subject = header label, author "Northern Powergrid - AppAssist".
  File name: <project name with spaces as underscores>_<BRD|HLD|SSIA>.docx


4. WORDING FOR THE SSIA
------------------------------------------------------------------------
  document noun      System Security Impact Assessment
  header label       System Security Impact Assessment (SSIA)
  cover line 3       Information Security Assurance
  cover line 4       System Security Impact Assessment


5. PAGE ORDER
------------------------------------------------------------------------
  1. Cover page                 (page break)
  2. Document Control page(s)   (page break)
  3. Table of Contents          (page break)
  4. The numbered body sections, in template order


6. COVER PAGE  (top to bottom)
------------------------------------------------------------------------
  a. Masthead: "NORTHERN POWERGRID", Georgia 11 pt bold 9F1C33, with a
     9F1C33 rule underneath.
  b. Title panel: a full-width single-cell table filled 9F1C33 with a
     7E1628 bottom border, generous padding, four centred lines:
        I N F O R M A T I O N   S Y S T E M S     Calibri 9 pt bold E8B4BE
        <PROJECT NAME IN CAPITALS>                Georgia 28 pt bold FFFFFF
        <cover line 3>                            Georgia 13 pt italic E8B4BE
        <cover line 4>                            Georgia 15 pt bold FFFFFF
  c. Two-column label/value grid (label cell filled D9D9D9, 9 pt bold ink;
     value 10.5 pt ink; BFBFBF borders):
        Date            today's date, e.g. 14 November 2026
        Version         (blank)
        Classification  Confidential - NPg Internal Use Only
  d. Label "DOCUMENT CONTROL", 9 pt bold 7E1628, hairline rule beneath,
     then the same style of grid:
        Document Status            (blank)
        Author(s)                  Northern Powergrid - AppAssist
        Business Owner             Northern Powergrid
        Document Location          (blank)
        Document internal review   1 year after initial publication
        Document external review   3 years after publication
  e. Confidentiality panel: paragraph filled EEF1F6 with a thick 9F1C33
     left bar. "CONFIDENTIAL  " 8 pt bold 7E1628, then 8 pt 6B6B75:
     "This document contains proprietary information of Northern Powergrid
     and is intended for internal use only. It must not be reproduced or
     distributed, in whole or in part, without prior written consent.
     Printed copies are only valid on the date they were printed."


7. DOCUMENT CONTROL PAGE
------------------------------------------------------------------------
  Page title: Georgia 18 pt bold 1B1B20 with a 9F1C33 rule beneath.
  Each block: a sub-heading (Calibri 12.5 pt bold 17365D), an optional
  9 pt italic 6B6B75 note, then a table with a GREY header row (fill
  D9D9D9, 9 pt bold ink) and zebra data rows. Pre-fill the rows shown and
  leave the stated number of extra EMPTY rows for manual completion.
  Use real names only when the user supplied them; otherwise leave blank.

SSIA - page title "Document Control & Governance"
    Governance Header     Field | Details
                          Document Status | Draft
                          Product Reference | System Security Impact Assessment
                          Data Classification | INTERNAL
                          Author(s) | ; Document Owner | ; Document Location |
    Revision History      Version | Summary of Changes | Author | Date
                          0.1 | Initial SSIA draft |  | today
                          1.0 | First approved baseline |  |          (+3 empty)
    Approved By           Version | Name | Role / Job Title | Date Approved
                          roles: IS Security Operations Manager, Security
                          Architect, Solution Architect, Business Owner (+1 empty)
    Distribution List     Version | Name | Role / Job Title | Date of Issue  (4 empty)
    Glossary              Abbreviation / Acronym | Definition
                          SSIA, SIA, DPIA, HLD, AD, SSO, MFA, SCIM, RBAC, PoF,
                          GDPR, LDAPS, TLS, SFTP, WAF, SIEM, RTO, RPO, P1, VPC
                          - plus every acronym the document uses      (+2 empty)
    Related Documents     Title | Purpose | Version                   (3 empty)


8. TABLE OF CONTENTS
------------------------------------------------------------------------
  Page title "Table of Contents" (same style as the Document Control
  title). Insert a real Word TOC field  TOC \o "1-3" \h \z \u  and set
  updateFields in the document settings so Word refreshes it on open. As
  the visible fallback list, print each section two levels deep:
  number (Consolas 10 pt bold 9F1C33) then title (level 1 bold ink, level 2
  body colour), indented 5 mm per level. Append "   (Not Required)" in 8 pt
  italic muted to a section marked not required. SSIA questions are NOT
  listed in the contents.


9. BODY SECTIONS
------------------------------------------------------------------------
  Headings use the real Word styles Heading 1 .. Heading 4 (so they feed
  the navigation pane and the TOC) with this explicit formatting, no left
  indent, keep-with-next:
      level 1   16 pt    number Georgia bold 7E1628, title Calibri bold 9F1C33
      level 2   13 pt    number Georgia bold 385D8A, title Calibri bold 4F81BD
      level 3   11.5 pt  same colours as level 2
      level 4+  11 pt    same colours as level 2
  Format: "<number>   <title>" (three spaces). Numbers come from the
  template reference: 1, 1.1, 2.4.1 ...

  Body content is indented under its heading: 6 mm + 4 mm per level.

  NARRATIVE section: one paragraph per line of content, Calibri 10.5 pt
  33333B, 4 pt after. A line starting "- " is a List Bullet paragraph.

  TABLE section: first the intro paragraph (10 pt 1B1B20; default text
  "Below is the brief description of <section title>."), then a full-width
  table:
      header row   fill 9F1C33, border 7E1628, text 9 pt bold FFFFFF,
                   marked "repeat as header row"
      data rows    9 pt 33333B, C9CFD8 borders, every second row filled
                   F2F2F2, rows not allowed to split across pages
      empty table  one merged row: "No entries recorded." 9 pt italic muted
      a line break inside a cell stays a line break in the same cell


  QUESTION (SSIA questionnaire): no numbered heading. A full-width
  two-column table per question:
      row 1  one merged cell, fill 9F1C33, border 7E1628, 9.5 pt bold white:
             "Question <n>: <the question text>"
      row 2  left cell filled F8EFF2 holding the short response in 9 pt
             bold 7E1628; right cell the detail in 9 pt body
  <n> is the last part of the section number (3.7 -> Question 7).
  A question marked not required keeps this layout with the answer
  "Not Applicable" | "This question has been assessed and is not applicable
  for <project name>."

  NOT REQUIRED section (any other type): keep the numbered heading, then
  one paragraph filled EEF1F6 with a 9F1C33 left bar:
      "Not applicable. " 10 pt bold 7E1628, followed by, 10 pt italic muted:
      "This section has been assessed and is not applicable for <project
      name>. No further detail is required within the scope of this
      <document noun>."

  Guidance text from the template reference is NEVER printed.


10. CHECK BEFORE YOU HAND THE FILE OVER
------------------------------------------------------------------------
  * Every section of the template is present, in order, with its number.
  * No heading, table header or colour differs from this guide.
  * No Markdown symbols (**, #, |) appear anywhere in the text.
  * The cover has no header or footer; every other page has both.
  * Tables are full width and their header row is red (body) or grey
    (document control) - never Word's default blue.
```
