---
name: appassist-proposal
description: Write an IT proposal deck in the Northern Powergrid AppAssist proposal template (15 slides, four designs - npg, helix, meridian, apex). Use whenever the user asks to create, draft, write, update or revise a proposal, proposal deck, pitch or client presentation. Produces either a JSON draft that opens in AppAssist for review and editing (recommended) or the finished presentation in the exact AppAssist design.
---

# AppAssist Proposal Deck

Write a proposal that follows the AppAssist proposal template exactly, then deliver it as an AppAssist JSON draft or as the finished deck.

The template is fixed by AppAssist: 15 slides in a set order, each with set fields, length limits and row limits, rendered in one of four designs. Always build the draft with the helper in `scripts/appassist_proposal.py`: it knows every slide, field and limit, checks the result, and renders the deck with AppAssist's own code. Never hand-write the JSON.

## Workflow

1. **Understand the request.** Read everything the user gave you: brief, notes, emails, attached files (an RFP, a BRD, an effort estimate). Identify the client, the company making the proposal, and what is proposed.

2. **Ask which output the user wants**, once, before writing - unless they already said:
   - **AppAssist JSON file (recommended).** It opens with the Open button on the Proposal deck page in AppAssist (Project Management). There the user can review and edit every slide, switch slides on or off, change the design, and download the deck.
   - **Final presentation.** The finished deck: one self-contained HTML file that presents full screen in any browser, identical to AppAssist's own download. Print > Save as PDF gives one slide per page. It cannot be opened in AppAssist for editing.

   Recommend the JSON file and say why in one sentence: the user can review and edit each slide in AppAssist before the deck is sent.
   Ask which design to use as part of the same question:
   - `npg` - Slate & Crimson: editorial annual-report look on white, crimson header bar. Corporate and on-brand. The default.
   - `helix` - Midnight Navy: centred slides on a dark navy canvas with one azure accent. Modern.
   - `meridian` - Teal & Gold: left-rail layout, deep teal and gold, serif headings. Premium consulting.
   - `apex` - Executive Brief: serif on ivory with bronze hairlines. Written for the boardroom.

3. **Ask clarifying questions.** Compare what you know with what the slides need. Ask only about gaps that materially change the content, in ONE numbered batch of at most 6 short questions, most important first, with a suggested answer where you can. Typical gaps: client name and your company name; the client's current problems and their business impact; the proposed solution and its main components; duration and phases; team roles, headcount and onshore or offshore split; price, commercial model and currency; success measures; contact person and sign-off date.
   If the user says to proceed or to assume, stop asking, continue, and record each assumption.

4. **Read `references/schema.md`** for every slide, field, column, length limit and row limit.

5. **Build the draft** with a Python script that uses the helper (see "Building the draft").

6. **Save and check.** `p.save()` writes the JSON and prints a report. Fix every ERROR and run again. A WARNING about length means the text will overflow its slide: shorten it.

7. **Deliver.**
   - JSON choice: give the user the `.json` file. Then tell them: open AppAssist > Project Management > Proposal deck, click **Open**, choose the file, review and edit the slides, then click **Download Deck**.
   - Final presentation: call `p.deck()` and give the user the `.html` file. Offer the JSON file as well, in case they want to edit later. If they specifically need PowerPoint, say that AppAssist decks are HTML and that Print > Save as PDF is the supported export.

8. **Close.** After the file, list briefly: assumptions you made; fields left empty or slides left out for lack of information; any text you shortened to fit. Offer to revise. For a revision, change the script and regenerate the complete file.

## Building the draft

```python
import sys
sys.path.insert(0, "<path to this skill>/scripts")
from appassist_proposal import Proposal

p = Proposal.new(client="Acme Energy", template="npg")
p.meta(brand_name="Northern Powergrid", brand_short="NPG", logo_letter="N",
       doc_date="November 2026", doc_version="v1.0")

p.slide("cover", title="Customer Portal\nReplacement Proposal",
        tagline="A phased programme to replace the end-of-life portal.")
p.slide("exec", lead="...", stats=[
    {"kind": "Problem", "metric": "9 yrs", "heading": "The Problem", "desc": "..."},
    {"kind": "Solution", "metric": "Cloud", "heading": "The Solution", "desc": "..."},
    {"kind": "Value", "metric": "-20%", "heading": "The Value", "desc": "..."}])
p.slide("roadmap", lead="...", unit="Months", total_months="6", phases=[
    {"name": "Discovery", "start": "0", "duration": "1", "milestone": "Yes"},
    {"name": "Build", "start": "1", "duration": "4", "milestone": "No"},
    {"name": "Go-Live", "start": "5", "duration": "1", "milestone": "Yes"}])
p.slide("risk", lead="...", risks=[
    {"risk": "Data migration errors", "probability": "Medium", "mitigation": "..."}])
p.disable("team")              # a slide with nothing real to say

ok = p.save()                  # writes <client>_<design>_proposal_draft.json and prints the report
# p.deck()                     # only when the user chose the final presentation
```

Helper calls:

| Call | Use for |
|---|---|
| `Proposal.new(client, template)` | a new, EMPTY proposal - every field is "" or [] |
| `p.meta(**fields)` | brand name, wordmark, logo letter, client, date, version, confidentiality label |
| `p.slide(key, **fields)` | the fields of one slide; text is a string, a list is a list of strings, a table is a list of row dicts keyed by column key |
| `p.disable(key)` | leave a slide out (cover and thankyou are always included) |
| `p.design(template)` | change the design |
| `p.save(path=None)` | check, write the JSON, print the report; returns True when clean |
| `p.deck(path=None)` | write the finished HTML deck |

The helper raises a clear error for an unknown slide, field or column - fix the script rather than working around it. Run `python scripts/appassist_proposal.py schema` for a compact list of every key and limit.

If you cannot run Python at all, say so and stop; do not type the JSON by hand.

## Writing rules

- Slides are read at a glance: short, concrete, benefit-led phrases. No filler.
- Respect every length limit and row limit in `references/schema.md`. Count characters; shorten rather than overflow.
- A new proposal starts empty. Whatever you leave empty is simply not drawn, and a slide with no content is left out, so never pad a slide to avoid a gap.
- Never invent facts: people's names, prices, savings, percentages, dates, contact details, client statistics. If a figure is unknown, leave that field or row out, or disable the slide, and report it at the end.
- A `select` value must be one of the listed options, spelled the same.
- Professional UK English. Plain text only: no Markdown, no HTML, no emoji. `\n` is a line break where a field is a textarea.
- Keep the story consistent: the pain points (slide 3) map to the solution (slide 5); phases match across approach, roadmap and pricing; the same duration, total price and names appear everywhere.
- Roadmap: `start` and `duration` are numbers in the chosen unit ("Months" or "Weeks"), counted from 0; `total_months` is the length of the axis in that unit; no phase may end past it.
- Resourcing: `effort` is person-days PER PERSON for each period, comma-separated ("0, 20, 20, 10"). A full-time person is about 20 a month or 5 a week. Use only roles and effort the user gave or approved. Totals are calculated for you.
- Pricing: `total_amount` equals the sum of the phase investments, and the recommended model's price agrees with it. Use the user's currency.
- Meta: `brand_short` is a wordmark of at most 14 characters; `logo_letter` is a single letter.

## Reference files

- `references/schema.md` - every design, meta field, slide, field, column and limit. Read it before writing.
- `scripts/proposal_decks/` and `scripts/deck-stage.js` - AppAssist's own schema and deck renderers, unchanged. Do not edit.

## Boundaries

You only produce proposal decks here. For a BRD, an HLD or an SSIA, use the matching AppAssist skill. Never promise outcomes, prices or dates the user has not confirmed. If the user asks for extra slides or a different layout, explain that the slide set is fixed by AppAssist and offer the closest slide.
