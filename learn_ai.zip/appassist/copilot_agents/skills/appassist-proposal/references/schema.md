# Proposal deck schema

Every design, meta field, slide, field, column and limit. "max N chars" is the length that fits the slide; "max N rows / items" is a hard limit.

```
DESIGNS  (value of "template")
------------------------------
  "npg"  NPG - Slate & Crimson
          Editorial annual-report body on a white canvas, coloured header bar, hairline rules & navy panels. Corporate & on-brand.
  "helix"  Helix - Midnight Navy
          Centred, hero-led slides on a calm midnight-navy canvas - quiet slate cards, one azure accent. Modern & professional.
  "meridian"  Meridian - Teal & Gold
          Left-rail editorial layout, deep-teal & gold, elegant serif headings. Premium consulting.
  "apex"  Apex - Executive Brief
          The proposal as a serif-on-ivory boardroom paper - hairline rules, bronze accents, written for executives.

META  ("meta" object - brand chrome shown on every slide)
---------------------------------------------------------
  "brand_name"  Your company name  (max 40 chars)  - Shown on the cover and the thank-you slide.
  "brand_short"  Logo wordmark  (max 14 chars)  - Short brand mark shown in the header of every slide.
  "logo_letter"  Logo monogram  (max 2 chars)  - Single letter shown in the logo badge.
  "client_name"  Client / prospect name  (max 44 chars)  - Who the proposal is prepared for.
  "doc_date"  Date  (max 18 chars)
  "doc_version"  Version  (max 10 chars)
  "confidential"  Confidentiality label  (max 20 chars)

SLIDES  ("slides" object, in deck order)
----------------------------------------

SLIDE 1  key "cover"  -  Cover Slide   (always included)
  PURPOSE: Hero opening with the proposal title, client, date and version.
  FIELD "title"  [textarea]  Proposal title  (max 64 chars)
      note: Use a line break to control where the title wraps.
  FIELD "tagline"  [textarea]  Tagline / summary line  (max 190 chars)

SLIDE 2  key "exec"  -  Executive Summary
  PURPOSE: The story in 60 seconds - a lead paragraph plus three stat boxes (problem, solution, value).
  FIELD "lead"  [textarea]  Summary paragraph  (max 320 chars)
  FIELD "stats"  [table]  Highlight stats  (max 3 rows)
      COLUMN "kind"  Type  (options: Problem / Solution / Value)
      COLUMN "metric"  Metric  (max 14 chars)
      COLUMN "heading"  Heading  (max 22 chars)
      COLUMN "desc"  Description  (max 120 chars)

SLIDE 3  key "challenge"  -  Current State & Pain Points
  PURPOSE: An honest look at today - pain points on one side, business impact of doing nothing on the other.
  FIELD "pains"  [table]  Current pain points  (max 5 rows)
      COLUMN "heading"  Pain point  (max 34 chars)
      COLUMN "detail"  Detail  (max 120 chars)
  FIELD "impacts"  [table]  Business impact of doing nothing  (max 4 rows)
      COLUMN "metric"  Metric  (max 12 chars)
      COLUMN "label"  Description  (max 56 chars)

SLIDE 4  key "opportunity"  -  Opportunity & Business Case
  PURPOSE: Why now - market drivers, cost of inaction vs. benefit of action, and strategic alignment.
  FIELD "lead"  [textarea]  Intro line  (max 220 chars)
  FIELD "drivers"  [table]  Market & internal drivers  (max 4 rows)
      COLUMN "driver"  Driver / trend  (max 34 chars)
      COLUMN "detail"  Why it matters  (max 110 chars)
  FIELD "inaction"  [textarea]  Cost of inaction  (max 220 chars)
  FIELD "action"  [textarea]  Benefit of acting now  (max 220 chars)
  FIELD "alignment"  [list]  Strategic alignment  (max 64 chars per item; max 4 items)
      note: One alignment point per line.

SLIDE 5  key "solution"  -  Proposed Solution
  PURPOSE: What we recommend - overview, target architecture, and a pain-point -> solution mapping.
  FIELD "lead"  [textarea]  Solution overview  (max 220 chars)
  FIELD "arch_layers"  [table]  Target architecture (top to bottom)  (max 5 rows)
      COLUMN "layer"  Layer  (max 18 chars)
      COLUMN "nodes"  Components (comma-separated)  (max 80 chars)
  FIELD "arch_caption"  [text]  Architecture caption  (max 64 chars)
  FIELD "solution_map"  [table]  Pain point -> solution mapping  (max 7 rows)
      COLUMN "need"  Business Need  (max 40 chars)
      COLUMN "solution"  Our Solution  (max 40 chars)

SLIDE 6  key "benefits"  -  Key Benefits
  PURPOSE: What the client actually gains - a scannable benefits grid with a headline metric each.
  FIELD "lead"  [textarea]  Intro line  (max 200 chars)
  FIELD "items"  [table]  Benefits  (max 6 rows)
      COLUMN "title"  Benefit  (max 26 chars)
      COLUMN "metric"  Headline metric  (max 10 chars)
      COLUMN "desc"  Description  (max 90 chars)

SLIDE 7  key "approach"  -  Approach & Methodology
  PURPOSE: How we'll make it happen - methodology badges, a phased plan, and the collaboration model.
  FIELD "lead"  [textarea]  Intro line  (max 210 chars)
  FIELD "methodologies"  [list]  Methodology badges  (max 26 chars per item; max 6 items)
      note: One badge per line.
  FIELD "phases"  [table]  Phased plan  (max 6 rows)
      COLUMN "name"  Phase  (max 18 chars)
      COLUMN "desc"  Description  (max 40 chars)
  FIELD "collaboration"  [textarea]  How we'll work with you  (max 220 chars)

SLIDE 8  key "roadmap"  -  Roadmap & Timeline
  PURPOSE: A horizontal Gantt-style timeline. Set the unit (months or weeks); start/duration are counted in it. Mark milestone gates.
  FIELD "lead"  [textarea]  Intro line  (max 170 chars)
  FIELD "unit"  [text]  Timeline unit  (max 10 chars; setting, not content)
      note: "Months" or "Weeks" - sets the axis labels (M1, M2... or W1, W2...) and the unit the two columns below are counted in.
  FIELD "total_months"  [text]  Total timeline (in the unit above)  (max 4 chars; setting, not content)
      note: Used to scale the Gantt bars.
  FIELD "phases"  [table]  Phases  (max 7 rows)
      COLUMN "name"  Phase  (max 18 chars)
      COLUMN "start"  Start (unit)  (max 5 chars; a number, written as a string)
      COLUMN "duration"  Duration (units)  (max 5 chars; a number, written as a string)
      COLUMN "milestone"  Milestone gate  (options: Yes / No)

SLIDE 9  key "risk"  -  Risks & Mitigations
  PURPOSE: Risk / probability / mitigation table with red-amber-green indicators.
  FIELD "lead"  [textarea]  Intro line  (max 210 chars)
  FIELD "risks"  [table]  Risks  (max 8 rows)
      COLUMN "risk"  Risk  (max 40 chars)
      COLUMN "probability"  Probability  (options: Low / Medium / High)
      COLUMN "mitigation"  Mitigation  (max 110 chars)

SLIDE 10  key "team"  -  Team & Capabilities
  PURPOSE: An org chart: one engagement lead over a row of role cards.
  FIELD "lead"  [textarea]  Intro line  (max 210 chars)
  FIELD "lead_name"  [text]  Engagement lead - name  (max 24 chars)
  FIELD "lead_title"  [text]  Engagement lead - title  (max 30 chars)
  FIELD "lead_resp"  [textarea]  Engagement lead - responsibility  (max 80 chars)
  FIELD "members"  [table]  Key personnel  (max 6 rows)
      COLUMN "name"  Name  (max 20 chars)
      COLUMN "role"  Role / Title  (max 28 chars)
      COLUMN "resp"  Responsibility  (max 70 chars)

SLIDE 11  key "resourcing"  -  Team Composition & Effort
  PURPOSE: A Resource Effort Matrix - headcount per role, onshore / offshore, and the person-days each role puts in per week or month. Row, period and grand totals are calculated for you. Import a saved Effort Estimate to fill it.
  FIELD "lead"  [textarea]  Intro line  (max 200 chars)
  FIELD "period_unit"  [select]  Effort is planned per  (options: Month / Week; setting, not content)
      note: Sets the matrix columns (M1, M2... or W1, W2...). A full-time person is about 20 person-days a month or 5 a week.
  FIELD "resources"  [table]  Resource effort matrix  (max 12 rows)
      note: One number per week / month, in order - e.g. "0, 20, 20, 10". Row total = sum x # resources. Up to 24 periods are shown.
      COLUMN "role"  Role  (max 28 chars)
      COLUMN "location"  Location  (options: Onshore / Offshore / Nearshore)
      COLUMN "count"  # Resources  (max 4 chars; a number, written as a string)
      COLUMN "effort"  Person-days per person, per period (comma-separated)  (max 120 chars)
  FIELD "assumptions"  [textarea]  Notes & assumptions  (max 220 chars)

SLIDE 12  key "pricing"  -  Investment & ROI
  PURPOSE: Pricing by phase, the return story (ROI, payback, cost of standing still), and engagement models.
  FIELD "phases"  [table]  Pricing by phase  (max 7 rows)
      COLUMN "phase"  Phase  (max 6 chars)
      COLUMN "deliverable"  Deliverable  (max 40 chars)
      COLUMN "duration"  Duration  (max 12 chars)
      COLUMN "investment"  Investment  (max 16 chars)
  FIELD "total_label"  [text]  Total label  (max 24 chars)
  FIELD "total_amount"  [text]  Total amount  (max 16 chars)
  FIELD "roi"  [table]  Return on investment  (max 3 rows)
      COLUMN "label"  Measure  (max 26 chars)
      COLUMN "value"  Value  (max 10 chars)
      COLUMN "note"  Note  (max 40 chars)
  FIELD "rec_name"  [text]  Recommended model - name  (max 30 chars)
  FIELD "rec_desc"  [textarea]  Recommended model - description  (max 140 chars)
  FIELD "rec_price"  [text]  Recommended model - price  (max 20 chars)
  FIELD "alt_name"  [text]  Alternative model - name  (max 30 chars)
  FIELD "alt_desc"  [textarea]  Alternative model - description  (max 120 chars)
  FIELD "alt_price"  [text]  Alternative model - price  (max 20 chars)

SLIDE 13  key "kpis"  -  Success Metrics & KPIs
  PURPOSE: A KPI scorecard - baseline, target and when each lands, plus the reporting cadence.
  FIELD "lead"  [textarea]  Intro line  (max 200 chars)
  FIELD "rows"  [table]  KPIs  (max 7 rows)
      COLUMN "kpi"  KPI  (max 34 chars)
      COLUMN "baseline"  Baseline  (max 12 chars)
      COLUMN "target"  Target  (max 12 chars)
      COLUMN "when"  By when  (max 10 chars)
  FIELD "cadence"  [textarea]  Reporting cadence  (max 150 chars)

SLIDE 14  key "nextsteps"  -  Next Steps
  PURPOSE: A 3-step action timeline, a highlighted sign-off deadline and a point-of-contact card.
  FIELD "steps"  [table]  Action steps  (max 5 rows)
      COLUMN "title"  Step  (max 28 chars)
      COLUMN "desc"  Description  (max 110 chars)
      COLUMN "when"  When  (max 16 chars)
  FIELD "deadline_label"  [text]  Deadline label  (max 24 chars)
  FIELD "deadline_date"  [text]  Deadline date  (max 24 chars)
  FIELD "deadline_note"  [text]  Deadline note  (max 60 chars)
  FIELD "poc_name"  [text]  Point of contact - name  (max 24 chars)
  FIELD "poc_email"  [text]  Point of contact - email  (max 44 chars)
  FIELD "poc_phone"  [text]  Point of contact - phone  (max 26 chars)

SLIDE 15  key "thankyou"  -  Thank You / Q&A   (always included)
  PURPOSE: Closing slide with contact details, an invitation for questions and the company logo.
  FIELD "headline"  [text]  Headline  (max 24 chars)
  FIELD "message"  [textarea]  Closing message  (max 200 chars)
  FIELD "email"  [text]  Email  (max 40 chars)
  FIELD "phone"  [text]  Phone  (max 26 chars)
  FIELD "web"  [text]  Website  (max 40 chars)

NOTES ON THE CALCULATED SLIDES
------------------------------
  roadmap     "start" and "duration" are counted in the "unit" field ("Months" or "Weeks"), measured from 0. "total_months" is the length of the whole axis in that unit; every bar must end at or before it (start + duration <= total).
  resourcing  "effort" is person-days PER PERSON for each period, comma-separated, in order ("0, 20, 20, 10"). A full-time person is about 20 person-days a month or 5 a week. Row total = sum x "count"; totals are calculated for you. At most 24 periods are drawn.
  pricing     "total_amount" must equal the sum of the phase "investment" values, and "rec_price" must agree with it.
  exec        "stats" takes at most 3 rows: one Problem, one Solution, one Value.
```
