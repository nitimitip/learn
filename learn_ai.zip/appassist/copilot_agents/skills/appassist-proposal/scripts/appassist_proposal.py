#!/usr/bin/env python3
"""
AppAssist proposal helper - builds, checks and renders a proposal deck.

The slide schema and the four deck designs are AppAssist's own code, copied
unchanged into scripts/proposal_decks/. Nothing here needs a third-party package.

Use it from Python (recommended):

    import sys; sys.path.insert(0, "<this skill>/scripts")
    from appassist_proposal import Proposal

    p = Proposal.new(client="Acme Energy", template="npg")
    p.meta(brand_name="Northern Powergrid", brand_short="NPG", logo_letter="N",
           doc_date="November 2026", doc_version="v1.0")
    p.slide("cover", title="Customer Portal\\nReplacement Proposal", tagline="...")
    p.slide("risk", lead="...", risks=[
        {"risk": "Data migration errors", "probability": "Medium", "mitigation": "..."}])
    p.disable("team")
    ok = p.save()        # checks the draft, writes the .json, prints a report
    p.deck()             # only when the user asked for the finished deck

A new proposal starts EMPTY: every field is "" or []. Whatever you do not
fill is simply not drawn, and a slide with no content is left out.

Command line:

    python appassist_proposal.py schema
    python appassist_proposal.py skeleton "<client name>" [design] [out.json]
    python appassist_proposal.py validate <draft.json>
    python appassist_proposal.py deck <draft.json> [out.html]
"""

import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from proposal_decks import (     # noqa: E402
    build_deck_html, TEMPLATES, TEMPLATE_IDS, SLIDES, META_FIELDS, default_data)
from proposal_decks.schema import slide_has_content   # noqa: E402
from proposal_decks import render_common as _rc       # noqa: E402

# The deck engine script ships beside this file rather than in AppAssist's
# static folder; point the (unchanged) renderer at it.
_rc._DECK_JS_PATH = os.path.join(HERE, 'deck-stage.js')

KIND = 'appassist-proposal-deck-draft'
SLIDE_BY_KEY = dict((s['key'], s) for s in SLIDES)
SAMPLE = default_data(TEMPLATE_IDS[0])


def _s(value):
    return '' if value is None else str(value)


def _slug(text, fallback):
    s = re.sub(r'[^a-z0-9]+', '-', _s(text).lower()).strip('-')[:60]
    return s or fallback


def _num(text):
    """'$140,000' -> 140000.0 ; None when the text is not a plain amount."""
    t = _s(text).strip()
    if not t or re.search(r'[kKmM]\b|/', t):
        return None
    digits = re.sub(r'[^\d.]', '', t)
    try:
        return float(digits) if digits else None
    except ValueError:
        return None


class Proposal(object):
    """A proposal draft, in exactly the shape the builder's Open button reads."""

    def __init__(self, data):
        self.data = data

    @classmethod
    def new(cls, client='', template='npg'):
        if template not in TEMPLATE_IDS:
            raise ValueError('Design must be one of: %s' % ', '.join(TEMPLATE_IDS))
        meta = dict((f['key'], '') for f in META_FIELDS)
        meta['client_name'] = _s(client).strip()
        meta['confidential'] = 'Confidential'
        slides = {}
        for s in SLIDES:
            fields = {}
            for f in s['fields']:
                if f.get('config'):
                    fields[f['key']] = f['default']        # a unit / basis setting
                else:
                    fields[f['key']] = [] if f['type'] in ('list', 'table') else ''
            slides[s['key']] = {'enabled': True, 'fields': fields}
        slides['roadmap']['fields']['total_months'] = ''
        return cls({'kind': KIND, 'version': 1, 'template': template,
                    'meta': meta, 'slides': slides})

    @classmethod
    def load(cls, path):
        with open(path, 'r', encoding='utf-8') as fh:
            return cls(json.load(fh))

    # -- writing content ----------------------------------------------------

    def design(self, template):
        if template not in TEMPLATE_IDS:
            raise ValueError('Design must be one of: %s' % ', '.join(TEMPLATE_IDS))
        self.data['template'] = template
        return self

    def meta(self, **values):
        known = [f['key'] for f in META_FIELDS]
        for k, v in values.items():
            if k not in known:
                raise KeyError('Unknown meta field "%s". Allowed: %s' % (k, ', '.join(known)))
            self.data['meta'][k] = _s(v)
        return self

    def slide(self, key, **fields):
        if key not in SLIDE_BY_KEY:
            raise KeyError('Unknown slide "%s". Slides: %s' % (key, ', '.join(SLIDE_BY_KEY)))
        spec = dict((f['key'], f) for f in SLIDE_BY_KEY[key]['fields'])
        slot = self.data['slides'].setdefault(key, {'enabled': True, 'fields': {}})
        slot['enabled'] = True
        for k, v in fields.items():
            if k not in spec:
                raise KeyError('Slide "%s" has no field "%s". Fields: %s'
                               % (key, k, ', '.join(spec)))
            f = spec[k]
            if f['type'] == 'list':
                v = [_s(i) for i in (v if isinstance(v, (list, tuple)) else _s(v).split('\n'))]
            elif f['type'] == 'table':
                cols = [c['key'] for c in f['columns']]
                rows = []
                for row in v:
                    if not isinstance(row, dict):
                        raise TypeError('%s.%s rows are objects keyed by: %s'
                                        % (key, k, ', '.join(cols)))
                    bad = [c for c in row if c not in cols]
                    if bad:
                        raise KeyError('%s.%s has no column "%s". Columns: %s'
                                       % (key, k, bad[0], ', '.join(cols)))
                    rows.append(dict((c, _s(row.get(c))) for c in cols))
                v = rows
            else:
                v = _s(v)
            slot['fields'][k] = v
        return self

    def disable(self, key):
        if key not in SLIDE_BY_KEY:
            raise KeyError('Unknown slide "%s".' % key)
        if not SLIDE_BY_KEY[key].get('lockable', True):
            raise ValueError('The "%s" slide is always included.' % key)
        self.data['slides'][key]['enabled'] = False
        return self

    # -- checking -----------------------------------------------------------

    def validate(self):
        errors, warnings = [], []
        d = self.data
        if not isinstance(d, dict):
            return ['The file is not a JSON object.'], warnings
        if d.get('kind') != KIND:
            errors.append('"kind" must be "%s" - AppAssist refuses the file otherwise.' % KIND)
        if d.get('template') not in TEMPLATE_IDS:
            errors.append('"template" must be one of: %s.' % ', '.join(TEMPLATE_IDS))
        meta = d.get('meta') if isinstance(d.get('meta'), dict) else {}
        slides = d.get('slides') if isinstance(d.get('slides'), dict) else {}

        for f in META_FIELDS:
            v = meta.get(f['key'])
            if v is None:
                errors.append('meta.%s is missing (omitted fields show sample text).' % f['key'])
            elif not _s(v).strip() and f['key'] != 'confidential':
                warnings.append('meta.%s is empty.' % f['key'])
            elif f['budget'] and len(_s(v)) > f['budget']:
                warnings.append('meta.%s is %d chars (fits %d).' % (f['key'], len(_s(v)), f['budget']))
            if _s(v).strip() and _s(v) == f['default'] and f['key'] not in ('confidential', 'doc_version'):
                warnings.append('meta.%s still holds the sample text "%s".' % (f['key'], v))
        for k in meta:
            if k not in [f['key'] for f in META_FIELDS]:
                errors.append('Unknown meta field "%s".' % k)
        for k in slides:
            if k not in SLIDE_BY_KEY:
                errors.append('Unknown slide "%s".' % k)

        shown = []
        for s in SLIDES:
            slot = slides.get(s['key'])
            if not isinstance(slot, dict):
                errors.append('Slide "%s" is missing (omitted slides show sample text).' % s['key'])
                continue
            fields = slot.get('fields') if isinstance(slot.get('fields'), dict) else {}
            enabled = slot.get('enabled', True) is not False or not s.get('lockable', True)
            spec = dict((f['key'], f) for f in s['fields'])
            for k in fields:
                if k not in spec:
                    errors.append('%s: unknown field "%s".' % (s['key'], k))
            if not enabled:
                continue
            if s.get('lockable', True) and not slide_has_content(s, fields):
                warnings.append('Slide "%s" is enabled but empty - it will be left out.' % s['key'])
                continue
            shown.append(s['key'])
            for f in s['fields']:
                tag = '%s.%s' % (s['key'], f['key'])
                if f['key'] not in fields:
                    errors.append('%s is missing (omitted fields show sample text) - '
                                  'set it, or use "" / [].' % tag)
                    continue
                v = fields[f['key']]
                sample = SAMPLE['slides'][s['key']]['fields'][f['key']]
                if not f.get('config') and v and v == sample:
                    warnings.append('%s still holds AppAssist sample content.' % tag)
                if f['type'] in ('text', 'textarea', 'select'):
                    if not isinstance(v, str):
                        errors.append('%s must be a string.' % tag)
                    elif f['options'] and v not in f['options']:
                        errors.append('%s must be one of: %s.' % (tag, ' / '.join(f['options'])))
                    elif f['budget'] and len(v) > f['budget']:
                        warnings.append('%s is %d chars (fits %d) - shorten it.'
                                        % (tag, len(v), f['budget']))
                elif f['type'] == 'list':
                    if not isinstance(v, list) or not all(isinstance(i, str) for i in v):
                        errors.append('%s must be a list of strings.' % tag)
                        continue
                    if f['max_items'] and len(v) > f['max_items']:
                        errors.append('%s has %d items (max %d).' % (tag, len(v), f['max_items']))
                    for i in v:
                        if f['budget'] and len(i) > f['budget']:
                            warnings.append('%s item "%s..." is %d chars (fits %d).'
                                            % (tag, i[:24], len(i), f['budget']))
                elif f['type'] == 'table':
                    if not isinstance(v, list) or not all(isinstance(r, dict) for r in v):
                        errors.append('%s must be a list of row objects.' % tag)
                        continue
                    if f['max_items'] and len(v) > f['max_items']:
                        errors.append('%s has %d rows (max %d).' % (tag, len(v), f['max_items']))
                    cols = dict((c['key'], c) for c in f['columns'])
                    for n, row in enumerate(v, 1):
                        for ck, cv in row.items():
                            if ck not in cols:
                                errors.append('%s row %d: unknown column "%s".' % (tag, n, ck))
                                continue
                            c = cols[ck]
                            if not isinstance(cv, str):
                                errors.append('%s row %d: "%s" must be a string.' % (tag, n, ck))
                            elif c['options'] and cv not in c['options']:
                                errors.append('%s row %d: "%s" must be one of: %s.'
                                              % (tag, n, ck, ' / '.join(c['options'])))
                            elif c['type'] == 'number' and cv.strip() and _num(cv) is None:
                                errors.append('%s row %d: "%s" must be a number.' % (tag, n, ck))
                            elif c['budget'] and len(cv) > c['budget']:
                                warnings.append('%s row %d: "%s" is %d chars (fits %d).'
                                                % (tag, n, ck, len(cv), c['budget']))

        # Cross-slide arithmetic
        if 'roadmap' in shown:
            f = slides['roadmap']['fields']
            total = _num(f.get('total_months'))
            if f.get('phases') and not total:
                errors.append('roadmap.total_months is required when phases are given.')
            if _s(f.get('unit')).strip().lower() not in ('months', 'weeks'):
                errors.append('roadmap.unit must be "Months" or "Weeks".')
            for row in f.get('phases') or []:
                a, b = _num(row.get('start')), _num(row.get('duration'))
                if total and a is not None and b is not None and a + b > total + 1e-9:
                    errors.append('roadmap: phase "%s" ends at %g, past the total of %g.'
                                  % (row.get('name'), a + b, total))
        if 'pricing' in shown:
            f = slides['pricing']['fields']
            parts = [_num(r.get('investment')) for r in f.get('phases') or []]
            total = _num(f.get('total_amount'))
            if parts and all(p is not None for p in parts) and total is not None \
                    and abs(sum(parts) - total) > 0.5:
                errors.append('pricing: phases add up to %s but total_amount says %s.'
                              % ('{:,.0f}'.format(sum(parts)), f.get('total_amount')))
        if 'exec' in shown:
            kinds = [r.get('kind') for r in slides['exec']['fields'].get('stats') or []]
            if len(kinds) != len(set(kinds)):
                warnings.append('exec.stats: use one Problem, one Solution and one Value.')
        self.shown = shown
        return errors, warnings

    def report(self):
        errors, warnings = self.validate()
        shown = getattr(self, 'shown', [])
        left_out = [s['key'] for s in SLIDES if s['key'] not in shown]
        print('Proposal for "%s", design "%s": %d of %d slides in the deck.' % (
            (self.data.get('meta') or {}).get('client_name'), self.data.get('template'),
            len(shown), len(SLIDES)))
        if left_out:
            print('  left out: ' + ', '.join(left_out))
        for w in warnings:
            print('  WARNING: ' + w)
        for e in errors:
            print('  ERROR:   ' + e)
        print('RESULT: %s' % ('FAILED - fix every ERROR and run again' if errors
                              else 'OK - ready to deliver'))
        return not errors

    # -- output -------------------------------------------------------------

    def default_json_name(self):
        return '%s_%s_proposal_draft.json' % (
            _slug((self.data.get('meta') or {}).get('client_name'), 'proposal'),
            self.data.get('template'))

    def save(self, path=None):
        path = path or self.default_json_name()
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(self.data, fh, indent=2, ensure_ascii=True)
        ok = self.report()
        print('Saved %s' % os.path.abspath(path))
        return ok

    def deck(self, path=None):
        """Write the finished deck with AppAssist's own renderer (one HTML file)."""
        client = _s((self.data.get('meta') or {}).get('client_name')).strip()
        safe = re.sub(r'[^\w.-]+', '_', client or 'proposal') or 'proposal'
        path = path or '%s_%s_proposal.html' % (safe, self.data.get('template'))
        with open(path, 'w', encoding='utf-8') as fh:
            fh.write(build_deck_html(self.data.get('template'), self.data))
        print('Saved %s' % os.path.abspath(path))
        return path


def print_schema():
    print('DESIGNS: ' + ', '.join('%s (%s)' % (t['id'], t['name']) for t in TEMPLATES))
    print('META: ' + ', '.join('%s<=%d' % (f['key'], f['budget']) for f in META_FIELDS))
    for s in SLIDES:
        print('\n%d  %s  -  %s' % (s['num'], s['key'], s['title']))
        for f in s['fields']:
            extra = []
            if f['budget']:
                extra.append('<=%d chars' % f['budget'])
            if f['max_items']:
                extra.append('<=%d rows' % f['max_items'])
            if f['options']:
                extra.append('one of ' + '/'.join(f['options']))
            print('   %-16s %-8s %s' % (f['key'], f['type'], ', '.join(extra)))
            for c in f['columns']:
                cx = []
                if c['budget']:
                    cx.append('<=%d' % c['budget'])
                if c['options']:
                    cx.append('/'.join(c['options']))
                print('      . %-12s %s' % (c['key'], ' '.join(cx)))


def main(argv):
    if len(argv) < 2 or argv[1] in ('-h', '--help', 'help'):
        print(__doc__)
        return 0
    cmd, args = argv[1], argv[2:]
    if cmd == 'schema':
        print_schema()
        return 0
    if cmd == 'skeleton' and args:
        p = Proposal.new(args[0], args[1] if len(args) > 1 else 'npg')
        path = args[2] if len(args) > 2 else p.default_json_name()
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(p.data, fh, indent=2, ensure_ascii=True)
        print('Saved %s' % os.path.abspath(path))
        return 0
    if cmd == 'validate' and args:
        return 0 if Proposal.load(args[0]).report() else 1
    if cmd == 'deck' and args:
        p = Proposal.load(args[0])
        if not p.report():
            return 1
        p.deck(args[1] if len(args) > 1 else None)
        return 0
    print(__doc__)
    return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv))
