#!/usr/bin/env python3
"""
AppAssist document helper - builds, checks and renders a BRD / HLD / SSIA.

One file serves all three document skills; which document it produces is
decided by ../assets/template.json (the AppAssist master template for this
skill, including the database IDs AppAssist uses to bind content).

Use it from Python (recommended - you never handle a database ID):

    import sys; sys.path.insert(0, "<this skill>/scripts")
    from appassist_doc import Draft

    d = Draft.new("Customer Portal Replacement")
    d.text("1", "First paragraph.\\n- a bullet\\n- another bullet")
    d.table("2.2", [["OBJ-1", "Cut call volume", "Calls per month", "-20%"]],
            intro="The objectives the initiative is measured against.")
    d.entries("5.2", [{"fields": {"title": "...", "priority": "Must"}}])
    d.fixed("1.1", {"Date Completed": ["TBC"]})        # complete a fixed row
    d.answer("3.4", "Yes", "Personnel data is processed ...")   # SSIA question
    d.not_required("15.2")
    ok = d.save()              # checks the draft, writes the .json, prints a report
    d.docx()                   # only when the user asked for the Word document

A section is addressed by its NUMBER ("2.4.1") or its exact TITLE, both as
printed in references/template.md.

Command line:

    python appassist_doc.py outline
    python appassist_doc.py skeleton "<project name>" [out.json]
    python appassist_doc.py validate <draft.json>
    python appassist_doc.py docx <draft.json> [out.docx]
    python appassist_doc.py set-ids <sections.csv> <columns.csv>

Only the docx command needs a third-party package (python-docx).
"""

import csv
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_PATH = os.path.join(HERE, '..', 'assets', 'template.json')


def load_template():
    with open(TEMPLATE_PATH, 'r', encoding='utf-8') as fh:
        return json.load(fh)


def _norm(text):
    return re.sub(r'\s+', ' ', str(text or '').strip().rstrip(':')).lower()


def _slug(text, fallback):
    s = re.sub(r'[^a-z0-9]+', '-', str(text or '').lower()).strip('-')[:60]
    return s or fallback


def _safe(text, fallback='document'):
    return re.sub(r'[^\w.-]+', '_', str(text or '').strip()) or fallback


def _s(value):
    return '' if value is None else str(value)


# ---------------------------------------------------------------------------
# Draft
# ---------------------------------------------------------------------------

class Draft(object):
    """An AppAssist draft, in exactly the shape the builder's Open button reads."""

    def __init__(self, data, template=None):
        self.template = template or load_template()
        self.data = data
        self.nodes = self.template['sections']

    # -- construction -------------------------------------------------------

    @classmethod
    def new(cls, project_name):
        """A complete, empty draft: every section present, fixed rows pre-filled."""
        template = load_template()
        sections = {}
        for node in template['sections']:
            entry = {'is_required': True, 'short_description': '', 'content': '', 'rows': []}
            cols = node['columns']
            if node['type'] == 'ENTRIES':
                entry['blocks'] = []
            elif node['type'] == 'QUESTION':
                entry['rows'] = [dict((str(c['id']), '') for c in cols)]
            for fixed in node.get('fixed_rows') or []:
                entry['rows'].append(dict(
                    (str(c['id']), _s(fixed[i]) if i < len(fixed) else '')
                    for i, c in enumerate(cols)))
            sections[str(node['id'])] = entry
        return cls({'kind': template['kind'], 'version': 1,
                    'project_name': _s(project_name).strip(), 'sections': sections}, template)

    @classmethod
    def load(cls, path):
        with open(path, 'r', encoding='utf-8') as fh:
            return cls(json.load(fh))

    # -- addressing ---------------------------------------------------------

    def _node(self, key):
        key = _s(key).strip()
        hits = [n for n in self.nodes if n['number'] == key]
        if not hits:
            hits = [n for n in self.nodes if _norm(n['title']) == _norm(key)]
        if len(hits) == 1:
            return hits[0]
        if not hits:
            raise KeyError('No section "%s" in the %s template. Use a number or exact '
                           'title from references/template.md.' % (key, self.template['abbr']))
        raise KeyError('"%s" matches %d sections (%s) - use the section number.'
                       % (key, len(hits), ', '.join(n['number'] for n in hits)))

    def _entry(self, node, want=None):
        if want and node['type'] not in want:
            raise TypeError('Section %s "%s" is %s, not %s.' % (
                node['number'], node['title'], node['type'], ' / '.join(want)))
        entry = self.data['sections'].setdefault(str(node['id']), {})
        entry['is_required'] = True
        return entry

    def _row(self, node, values):
        cols = node['columns']
        if isinstance(values, dict):
            raise TypeError('Rows are lists of cell values in column order, not dicts.')
        values = list(values)
        if len(values) > len(cols):
            raise ValueError('Section %s has %d columns (%s) but a row has %d values.' % (
                node['number'], len(cols), ' | '.join(c['name'] for c in cols), len(values)))
        return dict((str(c['id']), _s(values[i]) if i < len(values) else '')
                    for i, c in enumerate(cols))

    # -- writing content ----------------------------------------------------

    def text(self, section, content):
        """Body of a NARRATIVE section. "- " starts a bullet; "\\n" separates lines."""
        node = self._node(section)
        self._entry(node, ('NARRATIVE',))['content'] = _s(content).strip()
        return self

    def table(self, section, rows, intro=None):
        """Replace a TABLE section's rows. Each row: a list, one value per column."""
        node = self._node(section)
        entry = self._entry(node, ('TABLE',))
        entry['rows'] = [self._row(node, r) for r in rows]
        if intro is not None:
            entry['short_description'] = _s(intro).strip()
        return self

    def fixed(self, section, values_by_label, intro=None):
        """
        Complete the FIXED ROWS of a table without retyping their fixed text.
        `values_by_label` maps the row's first-cell text (for a numbered
        questionnaire, its number as a string) to the list of values for the
        REMAINING columns, in column order. Where two fixed rows share a label,
        pass a list of (label, values) pairs instead; they bind in row order.
        """
        node = self._node(section)
        entry = self._entry(node, ('TABLE',))
        fixed = node.get('fixed_rows') or []
        if not fixed:
            raise TypeError('Section %s has no fixed rows - use table().' % node['number'])
        cols = node['columns']
        by_label = {}
        for row in entry.get('rows') or []:
            by_label.setdefault(_norm(row.get(str(cols[0]['id']))), []).append(row)
        items = (list(values_by_label.items()) if isinstance(values_by_label, dict)
                 else [tuple(pair) for pair in values_by_label])
        used = {}
        for label, values in items:
            rows = by_label.get(_norm(label))
            if not rows:
                raise KeyError('Section %s has no fixed row "%s". Rows: %s' % (
                    node['number'], label, ', '.join(_s(f[0]) for f in fixed)))
            nth = used.get(_norm(label), 0)
            if nth >= len(rows):
                raise KeyError('Section %s has only %d row(s) labelled "%s".' % (
                    node['number'], len(rows), label))
            used[_norm(label)] = nth + 1
            row = rows[nth]
            n_fixed = max(len(f) for f in fixed)
            values = [values] if isinstance(values, str) else list(values)
            free = cols[n_fixed:]
            if len(values) > len(free):
                raise ValueError('Fixed row "%s" takes %d value(s) (%s), got %d.' % (
                    label, len(free), ' | '.join(c['name'] for c in free), len(values)))
            for i, col in enumerate(free):
                if i < len(values):
                    row[str(col['id'])] = _s(values[i])
        if intro is not None:
            entry['short_description'] = _s(intro).strip()
        return self

    def add_rows(self, section, rows):
        """Append extra rows to a TABLE section (after any fixed rows)."""
        node = self._node(section)
        entry = self._entry(node, ('TABLE',))
        entry.setdefault('rows', []).extend(self._row(node, r) for r in rows)
        return self

    def entries(self, section, blocks, intro=None):
        """
        Replace an ENTRIES section's blocks. Each block:
            {"fields": {"<field key>": "text", ...},
             "tables": {"<sub-table key>": [["cell", ...], ...]}}
        Blocks are numbered automatically in list order (BR-1, BR-2 ...).
        """
        node = self._node(section)
        entry = self._entry(node, ('ENTRIES',))
        out = []
        for block in blocks:
            out.append({
                'fields': dict((str(k), _s(v)) for k, v in (block.get('fields') or {}).items()),
                'tables': dict((str(k), [[_s(c) for c in row] for row in rows])
                               for k, rows in (block.get('tables') or {}).items()),
            })
        entry['blocks'] = out
        if intro is not None:
            entry['short_description'] = _s(intro).strip()
        return self

    def answer(self, section, response, detail):
        """Answer one QUESTION: a short response classification, then the detail."""
        node = self._node(section)
        self._entry(node, ('QUESTION',))['rows'] = [self._row(node, [response, detail])]
        return self

    def not_required(self, section):
        """Mark a section Not Required - the document prints a 'Not applicable' note."""
        node = self._node(section)
        entry = self.data['sections'].setdefault(str(node['id']), {})
        entry.update({'is_required': False, 'short_description': '', 'content': '', 'rows': []})
        if node['type'] == 'ENTRIES':
            entry['blocks'] = []
        return self

    # -- checking -----------------------------------------------------------

    def validate(self):
        """Return (errors, warnings). Errors must be fixed before delivery."""
        errors, warnings = [], []
        t, d = self.template, self.data
        if not isinstance(d, dict):
            return ['The file is not a JSON object.'], warnings
        if d.get('kind') != t['kind']:
            errors.append('"kind" must be "%s" (found %r) - AppAssist refuses the file otherwise.'
                          % (t['kind'], d.get('kind')))
        if not _s(d.get('project_name')).strip():
            errors.append('"project_name" is empty - it is printed on the cover.')
        sections = d.get('sections')
        if not isinstance(sections, dict):
            return errors + ['"sections" must be an object keyed by section ID.'], warnings

        known = dict((str(n['id']), n) for n in self.nodes)
        for key in sections:
            if key not in known:
                errors.append('Unknown section ID "%s" - not in the %s template.' % (key, t['abbr']))
        tbc = 0
        for node in self.nodes:
            where = 'Section %s "%s"' % (node['number'], node['title'])
            entry = sections.get(str(node['id']))
            if entry is None:
                errors.append('%s is missing from the draft.' % where)
                continue
            if not isinstance(entry, dict):
                errors.append('%s must be an object.' % where)
                continue
            required = entry.get('is_required', True) is not False
            content = _s(entry.get('content'))
            rows = entry.get('rows') or []
            blocks = entry.get('blocks') or []
            col_ids = [str(c['id']) for c in node['columns']]
            texts = [content, _s(entry.get('short_description'))]

            if not isinstance(rows, list) or not isinstance(blocks, list):
                errors.append('%s: "rows" and "blocks" must be lists.' % where)
                continue
            live_rows = []
            for i, row in enumerate(rows, 1):
                if not isinstance(row, dict):
                    errors.append('%s row %d must be an object keyed by column ID.' % (where, i))
                    continue
                for cid, value in row.items():
                    if cid not in col_ids:
                        errors.append('%s row %d uses column ID "%s", which is not a column '
                                      'of this section.' % (where, i, cid))
                    elif not isinstance(value, str):
                        errors.append('%s row %d: every cell must be a string.' % (where, i))
                    else:
                        texts.append(value)
                if any(_s(v).strip() for v in row.values()):
                    live_rows.append(row)

            if not required:
                if content.strip() or live_rows or blocks:
                    warnings.append('%s is Not Required but still carries content - it will '
                                    'not be printed.' % where)
                continue

            if node['type'] == 'NARRATIVE':
                if rows:
                    errors.append('%s is NARRATIVE - it takes "content", not rows.' % where)
                if not content.strip():
                    warnings.append('%s is empty. Write it, or mark it Not Required.' % where)
            elif node['type'] == 'TABLE':
                if content.strip():
                    warnings.append('%s is a TABLE - its "content" is never printed; use the '
                                    'intro or the rows.' % where)
                if not live_rows:
                    warnings.append('%s has no rows. Add them, or mark it Not Required.' % where)
                if node.get('fixed_keep'):
                    have = set(_norm(r.get(col_ids[0])) for r in live_rows)
                    n_fixed = max(len(f) for f in node['fixed_rows'])
                    for fixed in node['fixed_rows']:
                        if _norm(fixed[0]) not in have:
                            errors.append('%s: fixed row "%s" was removed or reworded.'
                                          % (where, fixed[0]))
                    for row in live_rows:
                        if not any(_s(row.get(c)).strip() for c in col_ids[n_fixed:]):
                            warnings.append('%s: row "%s" is not completed.'
                                            % (where, _s(row.get(col_ids[0]))[:50]))
                if node.get('one_mark'):
                    marks = [str(c['id']) for c in node['columns'] if c['name'] in ('Yes', 'No', 'N/A')]
                    for row in live_rows:
                        if sum(1 for c in marks if _s(row.get(c)).strip()) != 1:
                            errors.append('%s: row "%s" must mark exactly one of Yes / No / N/A.'
                                          % (where, _s(row.get(col_ids[0]))[:40]))
            elif node['type'] == 'QUESTION':
                if len(live_rows) != 1:
                    errors.append('%s takes exactly ONE answer row (found %d).'
                                  % (where, len(live_rows)))
                elif not all(_s(live_rows[0].get(c)).strip() for c in col_ids):
                    errors.append('%s: give both the short response and the detail.' % where)
            elif node['type'] == 'ENTRIES':
                conf = node['block']
                fkeys = [f['key'] for f in conf.get('fields') or []]
                tcols = dict((tb['key'], len(tb.get('columns') or [])) for tb in conf.get('tables') or [])
                if not blocks:
                    warnings.append('%s has no entries. Add them, or mark it Not Required.' % where)
                for i, block in enumerate(blocks, 1):
                    tag = '%s entry %s-%d' % (where, conf.get('prefix'), i)
                    if not isinstance(block, dict):
                        errors.append('%s must be an object.' % tag)
                        continue
                    fields = block.get('fields') or {}
                    for k, v in fields.items():
                        if k not in fkeys:
                            errors.append('%s: unknown field "%s" (allowed: %s).'
                                          % (tag, k, ', '.join(fkeys)))
                        texts.append(_s(v))
                    if not _s(fields.get('title')).strip():
                        errors.append('%s has no "title".' % tag)
                    elif re.match(r'^\s*%s-?\d+' % re.escape(conf.get('prefix') or ''),
                                  _s(fields.get('title'))):
                        warnings.append('%s: the title starts with an ID - entries are '
                                        'numbered automatically.' % tag)
                    for k, trows in (block.get('tables') or {}).items():
                        if k not in tcols:
                            errors.append('%s: unknown sub-table "%s" (allowed: %s).'
                                          % (tag, k, ', '.join(tcols)))
                            continue
                        for trow in trows:
                            if not isinstance(trow, list) or len(trow) > tcols[k]:
                                errors.append('%s: sub-table "%s" rows are lists of at most %d '
                                              'values.' % (tag, k, tcols[k]))
                            else:
                                texts.extend(_s(c) for c in trow)

            for value in texts:
                tbc += len(re.findall(r'\bTBC\b', value))
                if re.search(r'\*\*|^#{1,6} |^\|.*\|$|<[a-zA-Z/][^>]*>', value, re.M):
                    warnings.append('%s contains Markdown or HTML markup - use plain text.' % where)
                    break
        self.tbc_count = tbc
        return errors, warnings

    def report(self):
        errors, warnings = self.validate()
        sections = self.data.get('sections') or {}
        off = [n for n in self.nodes
               if (sections.get(str(n['id'])) or {}).get('is_required', True) is False]
        print('%s draft for "%s": %d sections, %d Not Required, %d TBC marker(s).' % (
            self.template['abbr'], self.data.get('project_name'), len(self.nodes),
            len(off), getattr(self, 'tbc_count', 0)))
        for n in off:
            print('  not required: %s %s' % (n['number'], n['title']))
        for w in warnings:
            print('  WARNING: ' + w)
        for e in errors:
            print('  ERROR:   ' + e)
        print('RESULT: %s' % ('FAILED - fix every ERROR and run again' if errors
                              else 'OK - ready to deliver'))
        return not errors

    # -- output -------------------------------------------------------------

    def default_json_name(self):
        return '%s_%s_draft.json' % (_slug(self.data.get('project_name'), self.template['code']),
                                     self.template['abbr'])

    def save(self, path=None):
        """Write the .json AppAssist opens. Returns True when the draft is clean."""
        path = path or self.default_json_name()
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(self.data, fh, indent=2, ensure_ascii=True)
        ok = self.report()
        print('Saved %s' % os.path.abspath(path))
        return ok

    def docx(self, path=None):
        """Write the Word document with AppAssist's own renderer. Returns the path."""
        sys.path.insert(0, HERE)
        import docx_renderer as r          # needs python-docx
        t = self.template
        name = _s(self.data.get('project_name')).strip()
        sections = self.data.get('sections') or {}
        ordered = []
        for node in self.nodes:
            data = sections.get(str(node['id'])) or {}
            qa = node['type'] == 'QUESTION'
            has_table = node['type'] in ('TABLE', 'QUESTION')
            valid = set(str(c['id']) for c in node['columns'])
            rows = []
            if has_table:
                for raw in data.get('rows') or []:
                    if not isinstance(raw, dict):
                        continue
                    cells = dict((str(k), _s(v)) for k, v in raw.items() if str(k) in valid)
                    if any(v.strip() for v in cells.values()):
                        rows.append(cells)
            block = node.get('block')
            intro = ''
            if (has_table or block) and not qa:
                intro = (_s(data.get('short_description')).strip()
                         or 'Below is the brief description of %s.'
                         % ((node['title'] or 'this section').strip()))
            ordered.append({
                'number': node['number'],
                'q_number': node['number'].rsplit('.', 1)[-1],
                'qa': qa,
                'depth': node['depth'],
                'title': node['title'],
                'has_table': has_table,
                'columns': [{'id': c['id'], 'name': c['name']} for c in node['columns']],
                'rows': rows,
                'block': block,
                'blocks': r._sanitise_blocks(block, data.get('blocks')),
                'intro': intro,
                'content': _s(data.get('content')),
                'is_required': bool(data.get('is_required', True)),
            })
        path = path or '%s_%s.docx' % (_safe(name), t['abbr'])
        with open(path, 'wb') as fh:
            fh.write(r._assemble_document(name, ordered, doc_type=t['code']))
        print('Saved %s' % os.path.abspath(path))
        return path


# ---------------------------------------------------------------------------
# Maintenance: re-point the template at another AppAssist installation
# ---------------------------------------------------------------------------

def set_ids(sections_csv, columns_csv):
    """
    Rewrite the IDs in assets/template.json from two CSV exports of the target
    AppAssist database (header row required; see the skills README for the
    two queries). The section tree must match this template title for title;
    if it does not, nothing is changed and the differences are listed.
    """
    template = load_template()

    def read(path):
        with open(path, 'r', encoding='utf-8-sig', newline='') as fh:
            return [dict((k.strip().lower(), (v or '').strip()) for k, v in row.items())
                    for row in csv.DictReader(fh)]

    secs, cols = read(sections_csv), read(columns_csv)
    kids = {}
    for s in secs:
        kids.setdefault(s.get('parent_id') or '', []).append(s)
    for group in kids.values():
        group.sort(key=lambda s: (int(s['position'] or 0), int(s['id'])))
    live = []

    def walk(parent, prefix):
        for i, s in enumerate(kids.get(parent, []), 1):
            number = '%s.%d' % (prefix, i) if prefix else str(i)
            live.append((number, s))
            walk(s['id'], number)
    walk('', '')
    walk('NULL', '') if not live else None

    problems = []
    if len(live) != len(template['sections']):
        problems.append('section count differs: template %d, database %d'
                        % (len(template['sections']), len(live)))
    for node, (number, s) in zip(template['sections'], live):
        if node['number'] != number or _norm(node['title']) != _norm(s['title']):
            problems.append('%s "%s"  vs database  %s "%s"'
                            % (node['number'], node['title'], number, s['title']))
    by_section = {}
    for c in cols:
        by_section.setdefault(c['section_id'], []).append(c)
    if not problems:
        for node, (number, s) in zip(template['sections'], live):
            mine = sorted(by_section.get(s['id'], []),
                          key=lambda c: (int(c['sort_order'] or 0), int(c['id'])))
            if [_norm(c['name']) for c in mine] != [_norm(c['name']) for c in node['columns']]:
                problems.append('%s "%s": columns differ (%s  vs database  %s)' % (
                    node['number'], node['title'],
                    ' | '.join(c['name'] for c in node['columns']),
                    ' | '.join(c['name'] for c in mine)))
    if problems:
        print('The database template does not match this skill - nothing changed:')
        for p in problems[:40]:
            print('  ' + p)
        return False
    changed = 0
    for node, (number, s) in zip(template['sections'], live):
        mine = sorted(by_section.get(s['id'], []),
                      key=lambda c: (int(c['sort_order'] or 0), int(c['id'])))
        changed += int(node['id'] != int(s['id']))
        node['id'] = int(s['id'])
        for col, db_col in zip(node['columns'], mine):
            col['id'] = int(db_col['id'])
    with open(TEMPLATE_PATH, 'w', encoding='utf-8') as fh:
        json.dump(template, fh, indent=1, ensure_ascii=True)
    print('template.json updated: %d sections checked, %d section ID(s) changed.'
          % (len(live), changed))
    return True


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------

def main(argv):
    if len(argv) < 2 or argv[1] in ('-h', '--help', 'help'):
        print(__doc__)
        return 0
    cmd, args = argv[1], argv[2:]
    if cmd == 'outline':
        t = load_template()
        for n in t['sections']:
            print('%s%s  %s   [%s]' % ('  ' * n['depth'], n['number'], n['title'], n['type']))
        return 0
    if cmd == 'skeleton' and args:
        draft = Draft.new(args[0])
        path = args[1] if len(args) > 1 else draft.default_json_name()
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(draft.data, fh, indent=2, ensure_ascii=True)
        print('Saved %s' % os.path.abspath(path))
        return 0
    if cmd == 'validate' and args:
        return 0 if Draft.load(args[0]).report() else 1
    if cmd == 'docx' and args:
        draft = Draft.load(args[0])
        if not draft.report():
            return 1
        draft.docx(args[1] if len(args) > 1 else None)
        return 0
    if cmd == 'set-ids' and len(args) == 2:
        return 0 if set_ids(args[0], args[1]) else 1
    print(__doc__)
    return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv))
