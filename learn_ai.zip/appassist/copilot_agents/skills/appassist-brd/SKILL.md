---
name: appassist-brd
description: Write a Business Requirements Document (BRD) in the Northern Powergrid AppAssist template. Use whenever the user asks to create, draft, write, update or revise a BRD or business requirements document. Produces either a JSON draft that opens in AppAssist for review and editing (recommended) or the finished Word document in the official AppAssist template and colours.
---

# AppAssist BRD

Write a Business Requirements Document that follows the AppAssist BRD template exactly, then deliver it as an AppAssist JSON draft or as the finished Word document.

The template is fixed by AppAssist: 42 sections, in a set order, each with a set type. Content is bound to sections by database IDs, so always build the draft with the helper in `scripts/appassist_doc.py`. It addresses sections by number or title, applies the IDs for you, and checks the result. Never hand-write the JSON.

## Workflow

1. **Understand the request.** Read everything the user gave you: description, notes, emails, attached files. Find the project name; ask for it if it is missing, because it is printed on the cover.

2. **Ask which output the user wants**, once, before writing - unless they already said:
   - **AppAssist JSON file (recommended).** It opens with the Open button on the "Create & Download a BRD" page in AppAssist (Project Management). There the user can review and edit every section, switch a section to Not Required, save progress, and download the Word document.
   - **Final Word document.** The finished .docx in the official template. It cannot be opened in AppAssist for editing.

   Recommend the JSON file and say why in one sentence: the user can review and edit each section in AppAssist before the document is issued.

3. **Ask clarifying questions.** Compare what you know with what the template needs. Ask only about gaps that materially change the content, in ONE numbered batch of at most 6 short questions, most important first, with a suggested answer where you can. Typical gaps: business problem and objectives with measures; sponsor and stakeholders; in scope and out of scope; current process and pain points; key requirements and priorities; constraints, dependencies and target dates; budget and expected benefits.
   If the user says to proceed or to assume, stop asking, continue, and record each assumption.

4. **Read `references/template.md`** for the sections, their types, columns, fixed rows and guidance.

5. **Build the draft** with a Python script that uses the helper (see "Building the draft").

6. **Save and check.** `d.save()` writes the JSON and prints a report. Fix every ERROR and run again. Read each WARNING and either fix it or be ready to explain it.

7. **Deliver.**
   - JSON choice: give the user the `.json` file. Then tell them: open AppAssist > Project Management > Create & Download a BRD, click **Open**, choose the file, review and edit the sections, then click **Download Word**.
   - Word choice: call `d.docx()` and give the user the `.docx`. It is produced by AppAssist's own renderer, so the template, colours and fonts are exact. Offer the JSON file as well, in case they want to edit later.

8. **Close.** After the file, list briefly: assumptions you made; every TBC item and the section it is in; sections marked Not Required and why. Offer to revise. For a revision, change the script and regenerate the complete file - never hand over a fragment.

## Building the draft

```python
import sys
sys.path.insert(0, "<path to this skill>/scripts")
from appassist_doc import Draft

d = Draft.new("Customer Portal Replacement")

d.text("1", "The customer portal is end of life ...\n- Problem: ...\n- Proposal: ...")
d.table("1.1", [["Problem", "..."], ["Solution", "..."], ["Sponsor", "TBC"]],
        intro="The essentials of the initiative at a glance.")
d.table("2.2", [["OBJ-1", "Reduce inbound calls", "Calls per month", "-20% by Q4"]])
d.table("5.1", [["BR-1", "Customers can report a fault online", "Must", "OBJ-1", "Workshop 1"]])
d.entries("5.2", [{"fields": {
    "title": "Online fault reporting",
    "priority": "Must",
    "description": "Customers need to report a fault without calling ...",
    "rationale": "...", "detail": "...", "dependencies": "FR-1, FR-2"}}])
d.entries("8", [{"fields": {"title": "Customer reports a fault", "actor": "Customer",
                             "goal": "...", "priority": "Must"},
                 "tables": {"main_flow": [["1", "Opens the fault form", "Shows the form"]],
                            "alt_flows": [["1a", "Address not found", "Offers manual entry"]]}}])
d.not_required("15.2")

ok = d.save()          # writes <project>_BRD_draft.json and prints the report
# d.docx()             # only when the user chose the Word document
```

Helper calls (a section is its number or its exact title):

| Call | Use for |
|---|---|
| `d.text(section, content)` | NARRATIVE sections |
| `d.table(section, rows, intro=None)` | TABLE sections - replaces all rows; each row is a list in column order |
| `d.fixed(section, {label: [values]}, intro=None)` | completing FIXED ROWS without retyping their fixed text |
| `d.add_rows(section, rows)` | extra rows after the fixed ones |
| `d.entries(section, blocks, intro=None)` | ENTRIES sections - each block is `{"fields": {...}, "tables": {...}}` |
| `d.not_required(section)` | a section that does not apply |
| `d.save(path=None)` | check, write the JSON, print the report; returns True when clean |
| `d.docx(path=None)` | write the Word document |

`Draft.new(name)` starts with every section present and empty, and fixed rows already in place. The helper raises a clear error if a section does not exist, is the wrong type, or a row has too many values - fix the script rather than working around it.

If you cannot run Python at all, say so and stop; do not type the JSON by hand. If only `d.docx()` fails because `python-docx` is unavailable, try `pip install python-docx`; if that is not possible, deliver the JSON file and tell the user to download the Word document from AppAssist. Only if the user insists on a Word file from you, build it by following `references/word-style-guide.md`.

## Writing rules

- Cover every section, in order. Never add, rename, merge or re-order sections.
- Follow each section's type and guidance. Guidance is for you; never copy it into the document.
- A section that truly does not apply is marked Not Required. Do not delete it and do not write filler to avoid an empty section.
- Never invent facts: names of people, dates, costs, volumes, server names, URLs, IP addresses, reference numbers, test or audit results. Where a fact is unknown write `TBC` in that cell or sentence and report it at the end.
- Professional UK English: plain, specific, third person, short paragraphs.
- Plain text only. A bullet is a line starting with `- `. Use `\n` between paragraphs and bullets, and for a line break inside a table cell. No Markdown, no HTML, no emoji.
- Tables: one fact per row, IDs sequential and unique, every row complete.
- A table's `intro` is one or two sentences that lead into it. Leave it out to get the default "Below is the brief description of <section title>."
- Never put passwords, keys or other secrets in the document; say where they are held instead.

## BRD rules

- Business Objectives are SMART; each has a measure and a target.
- Requirements say WHAT is needed, not how. Each is atomic, uniquely identified and testable. Priority is MoSCoW: Must, Should, Could or Won't.
- Every business requirement appears twice, in the same order: one row in the Register (BR-1, BR-2 ...) and one entry in the Detailed Specifications. Entries are numbered automatically, so never type the ID into an entry title. The same applies to functional requirements (FR-n) and use cases (UC-n).
- Every functional requirement is written "The system shall ..." and traces to a BR. Every NFR is measurable. Acceptance criteria use Given / When / Then and reference an FR.
- The Traceability Matrix has one row per chain: objective, BR, FR, use case, acceptance criterion, test case (TBC if not yet written). Nothing in it may be missing from the earlier sections.
- RACI: exactly one A per row. Risks: Probability and Impact are High, Medium or Low, each with an owner and a mitigation.
- Cost-Benefit and Financial Metrics use only figures the user supplied; otherwise TBC.
- Write the Executive Summary last, about one page.

## Reference files

- `references/template.md` - every section: number, title, type, columns, fixed rows, guidance. Read it before writing.
- `references/json-format.md` - the shape of the JSON file, for information. The helper produces it.
- `references/word-style-guide.md` - the Word template's look. Needed only if the renderer cannot run.
- `assets/template.json` - the template data the helper reads, including the AppAssist database IDs. Do not edit it.

## Boundaries

You only produce BRDs here. For an HLD, an SSIA or a proposal deck, use the matching AppAssist skill. If the user asks for a different layout, colour scheme or section list, explain that the template is fixed by AppAssist and offer the closest compliant option.
