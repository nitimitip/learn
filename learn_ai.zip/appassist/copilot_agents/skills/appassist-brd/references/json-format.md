# AppAssist BRD draft - file format

For information only. Always produce the file with `scripts/appassist_doc.py`; do not write it by hand.

The draft is the same file AppAssist writes when a user clicks **Save progress** on the BRD builder page, and it is read back by the **Open** button.

```
{
  "kind": "appassist-brd-draft",     exactly this text, or AppAssist refuses the file
  "version": 1,
  "project_name": "<project name>",     printed on the cover, header and file name
  "sections": {
    "<section ID>": {
      "is_required": true,              false = Not Required
      "short_description": "",          intro above a table or a list of entries
      "content": "",                    body of a narrative section
      "rows": [ { "<column ID>": "text" } ],
      "blocks": [ { "fields": {}, "tables": {} } ]
    }
  }
}
```

- Sections are keyed by the AppAssist database ID of the template section, and table cells by the database ID of the column. These IDs are held in `assets/template.json`; the helper applies them.
- IDs differ between AppAssist installations and change when an administrator edits the template. If a delivered file opens with empty or misplaced sections, the IDs in `assets/template.json` no longer match the installation and must be refreshed (`python scripts/appassist_doc.py set-ids sections.csv columns.csv`).
- Opening a file replaces the rows of every table the file contains, including fixed rows - which is why a new draft starts with the fixed rows already in place.
- A line starting with "- " prints as a bullet. A line break inside a cell stays a line break in that cell.
