# BRD template

Every section of the Business Requirements Document, in document order. Address a section in the helper by its
NUMBER (for example "2.4.1") or its exact TITLE.

Section types and the helper call that fills them:

- NARRATIVE - free text: `d.text(section, "...")`
- TABLE - rows of cells in the column order shown: `d.table(section, rows, intro=...)`
- TABLE with FIXED ROWS - the first column(s) are part of the form: `d.fixed(section, {first-cell text: [values for the remaining columns]})`
- ENTRIES - repeating blocks with fields and sub-tables: `d.entries(section, blocks, intro=...)`

GUIDANCE is advice to you, the author. Never copy it into the document.

## Outline

```
1  Executive Summary   [NARRATIVE]
  1.1  Key Points at a Glance   [TABLE]
2  Introduction   [NARRATIVE]
  2.1  Purpose of this Document   [NARRATIVE]
  2.2  Business Objectives   [TABLE]
  2.3  Project Background & Context   [NARRATIVE]
  2.4  Scope   [NARRATIVE]
    2.4.1  In Scope   [TABLE]
    2.4.2  Out of Scope   [TABLE]
  2.5  Definitions, Acronyms & Abbreviations   [TABLE]
3  Stakeholder Analysis   [TABLE]
  3.1  RACI Matrix   [TABLE]
4  Current State & Future State   [NARRATIVE]
  4.1  Current State (As-Is)   [NARRATIVE]
    4.1.1  Pain Points & Opportunities   [TABLE]
  4.2  Future State (To-Be)   [NARRATIVE]
5  Business Requirements   [NARRATIVE]
  5.1  Business Requirements Register (Summary)   [TABLE]
  5.2  Detailed Business Requirement Specifications   [ENTRIES]
6  Functional Requirements   [NARRATIVE]
  6.1  Functional Requirements Register (Summary)   [TABLE]
  6.2  Detailed Functional Requirement Specifications   [ENTRIES]
7  Non-Functional Requirements (NFRs)   [TABLE]
8  Use Cases & Scenarios   [ENTRIES]
9  Business Rules   [TABLE]
10  Data Requirements   [NARRATIVE]
  10.1  Data Dictionary   [TABLE]
  10.2  Data Migration & Integration   [TABLE]
11  Assumptions, Constraints & Dependencies   [NARRATIVE]
  11.1  Assumptions   [TABLE]
  11.2  Constraints   [TABLE]
  11.3  Dependencies   [TABLE]
12  Risk Assessment   [TABLE]
13  Cost-Benefit Analysis   [TABLE]
  13.1  Financial Metrics   [TABLE]
14  Acceptance Criteria   [TABLE]
15  Requirements Traceability Matrix (RTM)   [TABLE]
16  Appendices   [NARRATIVE]
  16.1  Process Flow Diagrams   [NARRATIVE]
  16.2  Wireframes / Mock-ups   [NARRATIVE]
  16.3  Supporting Analysis   [NARRATIVE]
  16.4  Open Issues / Parking Lot   [TABLE]
```

## Section detail

### 1  Executive Summary
- TYPE: NARRATIVE
- GUIDANCE: A concise, executive-level narrative (about one page). Summarise the business problem, the proposed solution, the expected value, and the ask. Written last, read first.

### 1.1  Key Points at a Glance
- TYPE: TABLE
- GUIDANCE: One-line summaries of the essentials: problem, solution, sponsor, budget range, target date, expected benefit.
- COLUMNS (2): Aspect | Summary

### 2  Introduction
- TYPE: NARRATIVE

### 2.1  Purpose of this Document
- TYPE: NARRATIVE
- GUIDANCE: State why this BRD exists and who should use it.

### 2.2  Business Objectives
- TYPE: TABLE
- GUIDANCE: Objectives should be SMART - Specific, Measurable, Achievable, Relevant, Time-bound.
- COLUMNS (4): ID | Business Objective | Success Measure / KPI | Target

### 2.3  Project Background & Context
- TYPE: NARRATIVE
- GUIDANCE: Explain the drivers behind the initiative - market, regulatory, operational, strategic.

### 2.4  Scope
- TYPE: NARRATIVE
- GUIDANCE: The boundaries of the initiative - what is included and what is deliberately excluded.

### 2.4.1  In Scope
- TYPE: TABLE
- GUIDANCE: List every item the initiative will deliver or change.
- COLUMNS (3): # | In-Scope Item | Description / Notes

### 2.4.2  Out of Scope
- TYPE: TABLE
- GUIDANCE: Identify what is excluded and why, to manage expectations.
- COLUMNS (3): # | Out-of-Scope Item | Rationale

### 2.5  Definitions, Acronyms & Abbreviations
- TYPE: TABLE
- GUIDANCE: Define every term or acronym a reader outside the project team may not know.
- COLUMNS (2): Term / Acronym | Definition

### 3  Stakeholder Analysis
- TYPE: TABLE
- GUIDANCE: Identify everyone affected by, or influencing, the initiative. Use the Influence/Interest rating to prioritise engagement.
- COLUMNS (5): Stakeholder / Group | Role | Responsibility / Interest | Influence | Interest

### 3.1  RACI Matrix
- TYPE: TABLE
- GUIDANCE: R = Responsible - A = Accountable - C = Consulted - I = Informed. Exactly one 'A' per activity.
- COLUMNS (5): Activity / Deliverable | Sponsor | BA | Dev Lead | QA

### 4  Current State & Future State
- TYPE: NARRATIVE

### 4.1  Current State (As-Is)
- TYPE: NARRATIVE
- GUIDANCE: Describe how the process/system operates today, including pain points. Reference or embed the As-Is process map.

### 4.1.1  Pain Points & Opportunities
- TYPE: TABLE
- GUIDANCE: The specific problems in the current state and their business impact.
- COLUMNS (4): ID | Pain Point | Impact | Severity

### 4.2  Future State (To-Be)
- TYPE: NARRATIVE
- GUIDANCE: Describe the desired end-state after the solution is delivered. Reference or embed the To-Be process map.

### 5  Business Requirements
- TYPE: NARRATIVE
- GUIDANCE: High-level requirements expressing WHAT the business needs (not how). Each must be uniquely identifiable, atomic, and testable. Priority uses MoSCoW: Must / Should / Could / Won't.

### 5.1  Business Requirements Register (Summary)
- TYPE: TABLE
- GUIDANCE: At-a-glance list of all business requirements for traceability.
- COLUMNS (5): Req ID | Requirement Statement (summary) | Priority | Objective Ref | Source

### 5.2  Detailed Business Requirement Specifications
- TYPE: ENTRIES
- GUIDANCE: One full specification block per business requirement - use Add to create BR-1, BR-2, ... Each block gives room for the complete narrative: description, rationale, expected outcome and dependencies.
- ENTRY PREFIX: BR (numbered automatically in list order - never type the ID into the title)
- FIELDS:
  - `title` - Requirement Title (one line). Short, unique requirement title
  - `priority` - Priority (MoSCoW) (one line). Must / Should / Could / Won't
  - `description` - Description (paragraphs). Describe the business need in full - the capability required, the context, who is affected, and the desired outcome.
  - `rationale` - Business Rationale / Justification (paragraphs). Why this is needed; the value or problem it addresses.
  - `detail` - Detailed Requirement / Expected Outcome (paragraphs). Elaborate the specifics: scope, conditions, business rules involved, volumes, and any edge cases.
  - `dependencies` - Dependencies / Related Requirements (paragraphs). Related IDs, upstream/downstream dependencies, or assumptions.

### 6  Functional Requirements
- TYPE: NARRATIVE
- GUIDANCE: Specific system behaviours that satisfy the business requirements. Trace each back to a BR-ID.

### 6.1  Functional Requirements Register (Summary)
- TYPE: TABLE
- GUIDANCE: At-a-glance list of all functional requirements for traceability.
- COLUMNS (5): FR ID | Functional Requirement (summary) | Priority | Traces to BR | Acceptance Ref

### 6.2  Detailed Functional Requirement Specifications
- TYPE: ENTRIES
- GUIDANCE: One full specification block per functional requirement - use Add to create FR-1, FR-2, ... State each as 'The system shall ...' with actor, action and triggering condition.
- ENTRY PREFIX: FR (numbered automatically in list order - never type the ID into the title)
- FIELDS:
  - `title` - Requirement Title (one line). Short, unique requirement title
  - `priority` - Priority (MoSCoW) (one line). Must / Should / Could / Won't
  - `description` - Description (paragraphs). State the functional requirement: 'The system shall ...'. Include actor, action, and triggering condition.
  - `rationale` - Business Rationale / Justification (paragraphs). Why this is needed; the value or problem it addresses.
  - `detail` - Detailed Requirement / Expected Outcome (paragraphs). Elaborate the specifics: scope, conditions, business rules involved, volumes, and any edge cases.
  - `dependencies` - Dependencies / Related Requirements (paragraphs). Related IDs, upstream/downstream dependencies, or assumptions.

### 7  Non-Functional Requirements (NFRs)
- TYPE: TABLE
- GUIDANCE: Quality attributes and constraints - HOW WELL the system must perform. Make every NFR measurable.
- COLUMNS (4): NFR ID | Category | Requirement (measurable) | Priority

### 8  Use Cases & Scenarios
- TYPE: ENTRIES
- GUIDANCE: Document each significant interaction between an actor and the system - use Add to create UC-1, UC-2, ... Each use case carries its actor, goal and priority plus its data fields, main flow and alternate/exception flows.
- ENTRY PREFIX: UC (numbered automatically in list order - never type the ID into the title)
- FIELDS:
  - `title` - Use Case Name (one line). e.g. Customer registers for the portal
  - `actor` - Primary Actor (one line). Who initiates this use case
  - `goal` - Goal / Description (paragraphs). What the actor is trying to achieve and why.
  - `priority` - Priority (one line). Must / Should / Could / Won't
- SUB-TABLE `data_fields` - Data Fields: Field | Description
- SUB-TABLE `main_flow` - Main (Happy-Path) Flow: Step No | Actor Action | System Response
- SUB-TABLE `alt_flows` - Alternate / Exception Flows: Ref No | Condition | Alternate Behaviour

### 9  Business Rules
- TYPE: TABLE
- GUIDANCE: Constraints and policies the solution must enforce, independent of any specific requirement.
- COLUMNS (4): Rule ID | Business Rule | Type | Ref FR

### 10  Data Requirements
- TYPE: NARRATIVE

### 10.1  Data Dictionary
- TYPE: TABLE
- GUIDANCE: Define each key data element the solution captures, stores, or processes.
- COLUMNS (5): Field Name | Description | Type | Mandatory | Validation / Format

### 10.2  Data Migration & Integration
- TYPE: TABLE
- GUIDANCE: Data moving between systems - one row per source-to-target flow.
- COLUMNS (4): Source | Target | Data / Object | Method

### 11  Assumptions, Constraints & Dependencies
- TYPE: NARRATIVE

### 11.1  Assumptions
- TYPE: TABLE
- GUIDANCE: What is being taken as true, and the impact if it turns out to be false.
- COLUMNS (3): ID | Assumption | Impact if False

### 11.2  Constraints
- TYPE: TABLE
- GUIDANCE: Fixed limitations the solution must work within (budget, time, technology, regulation).
- COLUMNS (3): ID | Constraint | Type

### 11.3  Dependencies
- TYPE: TABLE
- GUIDANCE: External deliverables or decisions this initiative relies upon.
- COLUMNS (4): ID | Dependency | Owner | Needed By

### 12  Risk Assessment
- TYPE: TABLE
- GUIDANCE: Probability x Impact drives the rating. Assign an owner and mitigation to every High/Medium risk.
- COLUMNS (6): ID | Risk Description | Probability | Impact | Mitigation / Response | Owner

### 13  Cost-Benefit Analysis
- TYPE: TABLE
- GUIDANCE: Summarise the financial justification. Detailed models may be attached as an appendix.
- COLUMNS (4): Category | Year 1 | Year 2 | Year 3

### 13.1  Financial Metrics
- TYPE: TABLE
- GUIDANCE: Headline financial measures, e.g. NPV, ROI, payback period.
- COLUMNS (2): Metric | Value

### 14  Acceptance Criteria
- TYPE: TABLE
- GUIDANCE: Define the objective conditions under which the business will accept the delivered solution. Ideally in Given / When / Then form.
- COLUMNS (3): AC ID | Acceptance Criterion (Given / When / Then) | Ref FR

### 15  Requirements Traceability Matrix (RTM)
- TYPE: TABLE
- GUIDANCE: Traces every requirement from business objective through to test coverage, ensuring nothing is lost or gold-plated.
- COLUMNS (6): Objective | Business Req | Functional Req | Use Case | Acceptance | Test Case

### 16  Appendices
- TYPE: NARRATIVE

### 16.1  Process Flow Diagrams
- TYPE: NARRATIVE
- GUIDANCE: Insert or link As-Is / To-Be process maps, swimlane diagrams, or BPMN models.

### 16.2  Wireframes / Mock-ups
- TYPE: NARRATIVE
- GUIDANCE: Insert or link UI wireframes and screen mock-ups.

### 16.3  Supporting Analysis
- TYPE: NARRATIVE
- GUIDANCE: Insert or link detailed financial models, survey data, or research.

### 16.4  Open Issues / Parking Lot
- TYPE: TABLE
- GUIDANCE: Unresolved questions to be settled before or during delivery.
- COLUMNS (4): ID | Open Issue / Question | Owner | Status
