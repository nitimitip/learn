"""
log_utils.py - multi-process-safe file logging for the IIS worker pool.

WHY THIS EXISTS
---------------
The application is hosted by IIS + wfastcgi with maxInstances="8", so EIGHT
independent Python processes run the same code and log to the same folder.

logging.handlers.RotatingFileHandler and TimedRotatingFileHandler are both
unsafe in that arrangement on Windows. Their rollover step RENAMES the active
file (app.log -> app.log.1). A rename only succeeds when no other process
holds a handle on the file - and here seven other workers always do. The
rename raises WinError 32 ("The process cannot access the file because it is
being used by another process"), the rollover fails, and log records are lost
exactly when something interesting is happening.

The fix is the one health_monitor_app_sched.py already uses for the Windows
service: never rename anything. Write straight into a file whose name encodes
the date, and switch to a new name when the date changes. Retention is done
by DELETING old dated files, which needs no handle on the active one.

For the web tier the filename also carries the PID, so the eight workers never
share a handle at all:

    logs/app_2026-08-21_p10432.log
    logs/app_2026-08-21_p10433.log
    ...

Reading across workers is a glob, and `type app_2026-08-21_*.log` (or Get-Content)
gives the whole day. Set APP_LOG_ONE_FILE=1 to drop the PID suffix if you would
rather have a single file per day and accept interleaved appends (appends of a
single record are atomic on Windows for the sizes we write, but the per-PID
default removes the question entirely).

USAGE
-----
    from log_utils import DatedFileHandler

    handler = DatedFileHandler(log_dir, 'app', retention_days=30)
    handler.setFormatter(logging.Formatter(...))
    root.addHandler(handler)
"""

import datetime
import logging
import os
import re


# Default retention for dated log files, in days. Override per handler.
DEFAULT_RETENTION_DAYS = 30

# Whether the PID is appended to the filename. Per-PID files are the safe
# default under the IIS worker pool; set APP_LOG_ONE_FILE=1 for one file
# per day shared by every worker.
_ONE_FILE_PER_DAY = os.environ.get('APP_LOG_ONE_FILE') == '1'


class DatedFileHandler(logging.FileHandler):
    """Write to <prefix>_<YYYY-MM-DD>[_p<pid>].log, switching file on date change.

    A drop-in replacement for RotatingFileHandler / TimedRotatingFileHandler
    that never renames a file, so it is safe when several processes log to the
    same directory at the same time.

    Parameters
    ----------
    log_dir        Directory to write into. Created if missing.
    prefix         Filename stem, e.g. 'app' -> app_2026-08-21_p1234.log
    retention_days Dated files older than this are deleted on each day switch
                   and once at construction. None disables purging.
    include_pid    Force the PID suffix on or off. None (default) follows the
                   APP_LOG_ONE_FILE environment variable.
    """

    def __init__(self, log_dir, prefix, retention_days=DEFAULT_RETENTION_DAYS,
                 encoding='utf-8', include_pid=None):
        self._log_dir = os.path.abspath(log_dir)
        self._prefix = prefix
        self._retention_days = retention_days
        if include_pid is None:
            include_pid = not _ONE_FILE_PER_DAY
        self._pid_suffix = '_p%d' % os.getpid() if include_pid else ''

        os.makedirs(self._log_dir, exist_ok=True)

        # Matches this prefix's dated files with OR without a PID suffix, so a
        # deployment that flips APP_LOG_ONE_FILE still purges the older shape.
        self._name_re = re.compile(
            r'^' + re.escape(prefix) + r'_(\d{4}-\d{2}-\d{2})(_p\d+)?\.log$'
        )

        self._current_date = datetime.date.today()
        super().__init__(self._path_for(self._current_date),
                         mode='a', encoding=encoding, delay=False)
        self._purge_old()

    def _path_for(self, day):
        name = '%s_%s%s.log' % (self._prefix, day.isoformat(), self._pid_suffix)
        return os.path.join(self._log_dir, name)

    def _purge_old(self):
        """Delete dated files past the retention window. Best effort.

        The date comes from the FILENAME, not the mtime, so copying the log
        folder around does not reset the clock. Today's file always has a date
        >= cutoff, so the file currently open is never a deletion candidate.
        A file another worker still holds open simply fails to delete and is
        retried on the next day switch.
        """
        if not self._retention_days:
            return
        cutoff = datetime.date.today() - datetime.timedelta(days=self._retention_days)
        try:
            entries = os.listdir(self._log_dir)
        except OSError:
            return
        for name in entries:
            match = self._name_re.match(name)
            if not match:
                continue
            try:
                file_date = datetime.datetime.strptime(match.group(1), '%Y-%m-%d').date()
            except ValueError:
                continue
            if file_date < cutoff:
                try:
                    os.remove(os.path.join(self._log_dir, name))
                except OSError:
                    # Held open by another worker, or already gone. Either way
                    # the next day switch will try again.
                    pass

    def emit(self, record):
        # On the first record of a new local date, close the old file and open
        # the new dated one. The logging framework holds this handler's lock
        # around emit(), so the stream swap is serialised against concurrent
        # log calls within this process; across processes each has its own file
        # (or, with APP_LOG_ONE_FILE=1, its own append-mode handle).
        today = datetime.date.today()
        if today != self._current_date:
            self._current_date = today
            try:
                if self.stream:
                    self.stream.close()
            finally:
                self.stream = None
            self.baseFilename = os.path.abspath(self._path_for(today))
            self.stream = self._open()
            self._purge_old()
        super().emit(record)


def has_dated_handler(logger, prefix=None):
    """True when `logger` already carries a DatedFileHandler (for `prefix`).

    Import-time handler installation can run twice - wfastcgi may import a
    module again after a reload, and the test suite imports main_app per
    session. Callers use this to avoid stacking duplicate handlers, which
    would write every record two or more times.
    """
    for handler in logger.handlers:
        if isinstance(handler, DatedFileHandler):
            if prefix is None or handler._prefix == prefix:
                return True
    return False
