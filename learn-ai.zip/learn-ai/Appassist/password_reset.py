"""
password_reset.py - Self-service "forgot password" support.

Generates a strong temporary password and emails it to the address on file,
advising the user to change it after signing in. SMTP configuration follows the
same convention as the rest of the app (SMTP_SERVER / SMTP_PORT / EMAIL_FROM),
so no new deployment settings are required.

The web layer (main_app.py) always shows the same generic confirmation whether
or not the email matched an account, so this module never reveals account
existence to the caller.
"""

import logging
import os
import secrets
import smtplib
import string
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

logger = logging.getLogger(__name__)

# SMTP (shared convention with the rest of the app)
_SMTP_SERVER = os.environ.get('SMTP_SERVER', 'mail1.northernpowergrid.com')
_SMTP_PORT = int(os.environ.get('SMTP_PORT', '25'))
_EMAIL_FROM = os.environ.get('EMAIL_FROM', 'NPgAppAssist@northernpowergrid.com')

# NPG palette (kept in step with the other product emails); the header and
# footer come from the shared NPG theme (email_theme.py).
from email_theme import hero_rows, footer_rows

# Palette comes from the shared theme; the aliases keep the f-strings below
# unchanged.
from email_theme import (                             # noqa: E402
    NPG_RED as _NPG_RED, NPG_DARK as _NPG_DARK, NPG_LIGHT as _NPG_LIGHT,
    NPG_BORDER as _NPG_BORDER, NPG_TEXT as _NPG_TEXT,
    NPG_TEXT_MUTED as _NPG_TEXT_MUTED, FONT as _FONT,
)


def generate_temp_password(length=14):
    """Return a strong random password.

    Drawn from letters + digits + a small symbol set, guaranteeing at least one
    of each class so it satisfies common complexity rules. Ambiguous characters
    (O/0, l/1/I) are excluded to keep the emailed password easy to type.
    """
    lowers = 'abcdefghijkmnpqrstuvwxyz'
    uppers = 'ABCDEFGHJKLMNPQRSTUVWXYZ'
    digits = '23456789'
    symbols = '!@#$%*?'
    alphabet = lowers + uppers + digits + symbols

    while True:
        pwd = ''.join(secrets.choice(alphabet) for _ in range(length))
        if (any(c in lowers for c in pwd)
                and any(c in uppers for c in pwd)
                and any(c in digits for c in pwd)
                and any(c in symbols for c in pwd)):
            return pwd


def _build_plaintext(firstname, username, temp_password):
    name = firstname or 'there'
    return (
        f"Hi {name},\n\n"
        f"We received a request to reset the password for your NPG App Assist "
        f"account ({username}).\n\n"
        f"Your new temporary password is:\n\n"
        f"    {temp_password}\n\n"
        f"For your security, please sign in and change this password straight "
        f"away from the 'change password' option in the top-right menu.\n\n"
        f"If you did not request this reset, please contact your administrator.\n\n"
        f"- NPG App Assist"
    )


def _build_html(firstname, username, temp_password):
    name = firstname or 'there'
    hero = hero_rows('NPG APP ASSIST &middot; ACCOUNT SECURITY', 'Password reset', width=520)
    footer = footer_rows('Account Security', width=520)
    return f"""\
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<body style="margin:0;padding:0;background:{_NPG_LIGHT};">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" bgcolor="{_NPG_LIGHT}">
    <tr><td align="center" style="padding:34px 16px 40px 16px;">
      <table role="presentation" width="520" cellpadding="0" cellspacing="0"
             style="max-width:520px;background:#ffffff;border:1px solid {_NPG_BORDER};border-bottom-color:#C6D0DE;border-collapse:separate;border-spacing:0;border-radius:14px;font-family:{_FONT};">
        {hero}
        <tr>
          <td style="padding:26px 28px;color:{_NPG_TEXT};font-size:14px;line-height:1.6;">
            <p style="margin:0 0 14px;">Hi {name},</p>
            <p style="margin:0 0 14px;">
              We received a request to reset the password for your account
              (<strong>{username}</strong>). Your new temporary password is:
            </p>
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
              <tr><td align="center" style="padding:6px 0 18px;">
                <div style="display:inline-block;background:{_NPG_LIGHT};border:1px dashed {_NPG_BORDER};
                            border-collapse:separate;border-spacing:0;border-radius:8px;padding:14px 22px;font-family:Consolas,Menlo,monospace;
                            font-size:20px;font-weight:700;letter-spacing:1px;color:{_NPG_RED};">
                  {temp_password}
                </div>
              </td></tr>
            </table>
            <p style="margin:0 0 14px;">
              For your security, please sign in and change this password straight away
              using the <strong>change password</strong> option in the top-right menu.
            </p>
            <p style="margin:0;color:{_NPG_TEXT_MUTED};font-size:12.5px;">
              If you did not request this reset, please contact your administrator.
            </p>
          </td>
        </tr>
        {footer}
      </table>
    </td></tr>
  </table>
</body>
</html>
"""


def send_password_reset_email(to_email, firstname, username, temp_password):
    """Send the temporary-password email. Returns True on success, False otherwise.

    All SMTP/connection errors are caught and logged so the caller can keep its
    response generic regardless of the outcome.
    """
    try:
        msg = MIMEMultipart('alternative')
        msg['From'] = _EMAIL_FROM
        msg['To'] = to_email
        msg['Subject'] = 'NPG App Assist - your new temporary password'
        msg.attach(MIMEText(_build_plaintext(firstname, username, temp_password), 'plain', 'utf-8'))
        msg.attach(MIMEText(_build_html(firstname, username, temp_password), 'html', 'utf-8'))

        with smtplib.SMTP(_SMTP_SERVER, _SMTP_PORT, timeout=30) as server:
            server.send_message(msg)

        logger.info("Password reset email sent to %s", to_email)
        return True
    except smtplib.SMTPException as exc:
        logger.error("SMTP error sending password reset email: %s", exc)
        return False
    except Exception:
        logger.exception("Unexpected error sending password reset email")
        return False
