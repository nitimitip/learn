"""
oracle_client.py - one-time Oracle driver bootstrap (DPI-1047 guard).

Preferred driver: python-oracledb, using the auto thick/thin pattern proven
in gis_data2/services/db_service.py:

    auto (default) -> try THICK mode (loads the Oracle Instant Client, which
                      is required for accounts that still use the legacy 10g
                      password verifier); if the client libraries are not
                      available, fall back to THIN mode, which needs NO
                      Oracle Client install at all.
    thick          -> require thick; get_oracle_driver() raises with
                      instructions if the client libraries cannot be loaded.
    thin           -> force thin (only safe when every monitored account has
                      an 11g+ password verifier).

The thin fallback is what fixes ``DPI-1047: Cannot locate a 64-bit Oracle
Client library`` on hosts without an Instant Client: cx_Oracle is
thick-only and dies, while python-oracledb keeps working in thin mode.
Hosts that DO ship the client (e.g. prod SV301077) still get thick mode,
so 10g-verifier accounts keep authenticating exactly as before.

cx_Oracle remains a fallback for environments where python-oracledb is not
installed; there the original ensure_oracle_client() PATH pinning applies.

Environment variables (e.g. in .env, loaded by both the web app and the
scheduler service):
    ORACLE_CLIENT_LIB_DIR  Instant Client directory (pins thick mode to it;
                           needed under SCM/IIS where the process PATH lacks
                           the interactive user's entries)
    ORACLE_CLIENT_MODE     auto (default) | thin | thick
"""

import logging
import os
import threading

logger = logging.getLogger(__name__)

# RLock: get_oracle_driver()'s cx_Oracle fallback calls ensure_oracle_client()
# while already holding the lock.
_lock = threading.RLock()
_initialized = False   # cx_Oracle ensure_oracle_client() guard
_driver = None         # module returned by get_oracle_driver()


def ensure_oracle_client(cx_Oracle):
    """Pin cx_Oracle to the Instant Client named by ORACLE_CLIENT_LIB_DIR.

    Idempotent and thread-safe; call it before any cx_Oracle.connect().
    The cx_Oracle module is passed in (rather than imported here) so this
    helper stays importable on hosts without the driver installed.
    """
    global _initialized
    if _initialized:
        return
    with _lock:
        if _initialized:
            return
        lib_dir = os.environ.get('ORACLE_CLIENT_LIB_DIR')
        if lib_dir:
            try:
                cx_Oracle.init_oracle_client(lib_dir=lib_dir)
                logger.info('cx_Oracle pinned to Oracle Client at %s', lib_dir)
            except Exception as e:
                # init_oracle_client() can only run once per process; if some
                # other module (e.g. the MIMP probes) initialised first with
                # the same directory, that's success, not failure.
                if 'already' in str(e).lower():
                    pass
                else:
                    logger.warning(
                        'init_oracle_client(lib_dir=%s) failed: %s -- '
                        'falling back to the normal PATH-based DLL search.',
                        lib_dir, e,
                    )
        _initialized = True


def _init_oracledb_mode(oracledb):
    """Decide thick vs thin ONCE per process, before the first connection.

    init_oracle_client() cannot be called after a thin connection exists,
    so this must run before any pool/connect. Thick is preferred because
    thin mode rejects legacy 10g password verifiers with DPY-3015.
    """
    mode = (os.environ.get('ORACLE_CLIENT_MODE') or 'auto').strip().lower()
    if mode == 'thin':
        logger.info('python-oracledb THIN mode forced by ORACLE_CLIENT_MODE.')
        return

    lib_dir = os.environ.get('ORACLE_CLIENT_LIB_DIR')
    try:
        if lib_dir:
            oracledb.init_oracle_client(lib_dir=lib_dir)
        else:
            oracledb.init_oracle_client()
        logger.info(
            'python-oracledb THICK mode enabled (Oracle Client libraries '
            'loaded%s).', ' from ' + lib_dir if lib_dir else '',
        )
    except Exception as exc:
        # Another module (e.g. the MIMP probes) may have initialised thick
        # mode first - that is success, not failure.
        if 'already' in str(exc).lower():
            return
        if mode == 'thick':
            raise RuntimeError(
                "ORACLE_CLIENT_MODE is 'thick' but the Oracle Client "
                "libraries could not be loaded: {}. Install the 64-bit "
                "Oracle Instant Client or set ORACLE_CLIENT_LIB_DIR to its "
                "directory.".format(exc)
            ) from exc
        logger.warning(
            'Oracle Client libraries unavailable (%s) - falling back to '
            'python-oracledb THIN mode (no client install needed). Accounts '
            'that still use legacy 10g password verifiers will fail with '
            'DPY-3015; install the Instant Client for those.', exc,
        )


def get_oracle_driver():
    """Return a ready-to-use Oracle DBAPI module (oracledb preferred).

    Idempotent and thread-safe. Raises ImportError when neither
    python-oracledb nor cx_Oracle is installed. Callers must use keyword
    arguments with .connect(user=..., password=..., dsn=...) - positional
    (user, password, dsn) is cx_Oracle-only and breaks under oracledb.
    """
    global _driver
    if _driver is not None:
        return _driver
    with _lock:
        if _driver is not None:
            return _driver
        try:
            import oracledb
        except ImportError:
            import cx_Oracle  # ImportError here = no Oracle driver at all
            logger.info(
                'python-oracledb not installed - using cx_Oracle (thick '
                'mode; requires the Oracle Instant Client).'
            )
            ensure_oracle_client(cx_Oracle)
            _driver = cx_Oracle
            return _driver
        _init_oracledb_mode(oracledb)
        _driver = oracledb
        return _driver
