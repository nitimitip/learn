import os
import base64
import binascii
import logging

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC


# ---------------------------------------------------------------------------
# Encryption key derivation
# ---------------------------------------------------------------------------

_LEGACY_SALT = b'npg_file_monitor_salt'  # historic static salt - kept so old data decrypts
_DEFAULT_SECRET = 'default-secret-key'


def _derived_key(secret: str) -> bytes:
    """PBKDF2-derive a Fernet key from a secret (the historic scheme)."""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=_LEGACY_SALT,
        iterations=100000,
    )
    return base64.urlsafe_b64encode(kdf.derive(secret.encode()))


def get_encryption_key():
    """The PRIMARY key - used for every new encryption.

    Priority: ENCRYPTION_KEY env var -> derived from SESSION_SECRET via PBKDF2
    (falling back to a default secret so a fresh checkout runs without setup).
    """
    key_env = os.environ.get('ENCRYPTION_KEY')
    if key_env:
        return key_env.encode()
    return _derived_key(os.environ.get('SESSION_SECRET', _DEFAULT_SECRET))


def _candidate_keys():
    """Every key a stored value may have been encrypted under, primary first.

    This makes decryption SELF-HEALING across key configuration changes:
    a deployment that later gains (or changes) ENCRYPTION_KEY / SESSION_SECRET
    can still read values written before the change - no manual re-encryption
    step, no server access, no migration script needed. New values are always
    written under the primary key (see encrypt_data).
    """
    keys = [get_encryption_key()]

    session_secret = os.environ.get('SESSION_SECRET')
    if session_secret:
        keys.append(_derived_key(session_secret))
    keys.append(_derived_key(_DEFAULT_SECRET))

    seen, ordered = set(), []
    for k in keys:
        if k not in seen:
            seen.add(k)
            ordered.append(k)
    return ordered


# ---------------------------------------------------------------------------
# Sentinel exception
# ---------------------------------------------------------------------------

class CredentialDecryptionError(Exception):
    """Raised when a stored credential cannot be decrypted by ANY known key.

    Common causes:
    * Value was never encrypted (legacy plaintext row created before the
      encrypt_data() fix in routes.py was deployed). Re-save the entry.
    * Value was encrypted under an ENCRYPTION_KEY / SESSION_SECRET that is no
      longer present in the environment. Restore that env var, or re-save
      the entry from the UI.
    * Stored value is corrupt or not valid base64.
    """


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def encrypt_data(data):
    """Encrypt a string for storage. Empty/None input returns ''.

    Always uses the PRIMARY key. The output is a base64-urlsafe string that
    decrypt_data() can read.
    """
    if not data:
        return ''

    f = Fernet(get_encryption_key())
    encrypted = f.encrypt(data.encode())
    return base64.urlsafe_b64encode(encrypted).decode()


def decrypt_data(encrypted_data):
    """Decrypt a value previously written by encrypt_data().

    Empty/None input returns ''. Tries the primary key first, then every
    legacy key the value may have been written under (SESSION_SECRET-derived,
    default-derived) - so credentials stay readable across key configuration
    changes without any manual migration.

    On failure with every known key, a CredentialDecryptionError is raised
    with a precise reason. The caller is expected to surface this to the user
    (and the application log) rather than silently treating the credential
    as empty.
    """
    if not encrypted_data:
        return ''

    # Step 1: base64 decode - catches legacy plaintext written before
    # encryption was enabled.
    try:
        encrypted_bytes = base64.urlsafe_b64decode(encrypted_data.encode())
    except (binascii.Error, ValueError) as exc:
        msg = (
            "Stored credential is not valid base64 - likely a legacy "
            "plaintext value written before encryption was wired up. "
            "Re-save the entry from the UI."
        )
        logging.error("CredentialDecryptionError: %s (underlying: %s)", msg, exc)
        raise CredentialDecryptionError(msg) from exc

    # Step 2: Fernet decrypt - try the primary key, then each legacy key.
    last_exc = None
    for key in _candidate_keys():
        try:
            return Fernet(key).decrypt(encrypted_bytes).decode()
        except InvalidToken as exc:
            last_exc = exc

    msg = (
        "Stored credential failed decryption with every known key - it was "
        "encrypted under an ENCRYPTION_KEY / SESSION_SECRET that is no longer "
        "configured, or the stored value is corrupt. Restore the original "
        "env var, or re-save the entry from the UI."
    )
    logging.error("CredentialDecryptionError: %s", msg)
    raise CredentialDecryptionError(msg) from last_exc
