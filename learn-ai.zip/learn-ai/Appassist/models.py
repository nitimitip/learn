from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean
from sqlalchemy.sql import func
from werkzeug.security import generate_password_hash, check_password_hash
from database import Base

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(80), unique=True, nullable=False)
    firstname=Column(String(256), nullable=False)
    lastname=Column(String(256), nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(256), nullable=False)
    role = Column(String(20), nullable=False, default='team_member')  # admin, project_manager, team_member
    # Profile organisation (managed on the My Profile page). user_group is
    # 'application' or 'infra'; sub_group stores the picked value's NAME from
    # the admin-managed user_sub_groups list (kept as text so deleting a list
    # value never breaks the users who had it); team is 'Project' or 'BAU'.
    user_group = Column(String(30))
    sub_group  = Column(String(100))
    team       = Column(String(20))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    is_active = Column(Boolean, default=True)
    
    def set_password(self, password):
        """Set password hash"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check password"""
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'
