/*
 * pm_progress_io.js - shared "save / open work-in-progress" helper for the
 * Project Management guest tools (HLD builder, Effort Estimate, Project
 * Planning).
 *
 * Mirrors the Architect Diagram's Save/Open pattern: the current working copy
 * is downloaded to the user's own device as an editable .json file and can be
 * re-opened later to continue. NOTHING is sent to or stored on the server - the
 * browser writes the file and reads it back from disk, so guests can keep a copy
 * of incomplete work and resume it.
 *
 * Each tool stamps its file with a distinct `kind` so a file saved from one tool
 * can't be loaded into another by mistake.
 *
 * window.PMProgress.save(kind, payload, filename)
 *     Downloads {kind, version, savedAt, ...payload} as a pretty .json file.
 * window.PMProgress.open(fileInput, kind, onload)
 *     Reads the chosen file, validates kind, and calls onload(data).
 * window.PMProgress.slug(text, fallback)
 *     Filename-safe slug, e.g. "My Project" -> "my-project".
 */
(function () {
    "use strict";

    function download(blob, name) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = name;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    }

    function slug(text, fallback) {
        var s = (text || '').toString().toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '')
            .slice(0, 60);
        return s || (fallback || 'untitled');
    }

    window.PMProgress = {
        save: function (kind, payload, filename) {
            var data = { kind: kind, version: 1, savedAt: new Date().toISOString() };
            Object.keys(payload || {}).forEach(function (k) { data[k] = payload[k]; });
            download(
                new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }),
                filename || (slug(null) + '.json')
            );
        },

        open: function (fileInput, kind, onload) {
            var file = fileInput.files && fileInput.files[0];
            fileInput.value = '';               // allow re-opening the same file
            if (!file) return;
            var reader = new FileReader();
            reader.onload = function () {
                var data;
                try {
                    data = JSON.parse(reader.result);
                } catch (e) {
                    alert('That file could not be read — it is not a valid saved-progress file.');
                    return;
                }
                if (!data || data.kind !== kind) {
                    alert('This file was not saved from this page, so it cannot be opened here.');
                    return;
                }
                onload(data);
            };
            reader.readAsText(file);
        },

        slug: slug
    };
})();
