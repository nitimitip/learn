/*
   Collapsible module sidebar categories.

   Each module layout renders its left sidebar as a series of
   .sidebar-section blocks, every one led by a .sidebar-label heading.
   This script turns those headings into collapse toggles: clicking a
   heading shows or hides the nav items under it.

   Defaults: the first category stays open, the rest start collapsed.
   Each category remembers the user's open/closed choice per module in
   localStorage. Category collapse is ignored while the sidebar is in
   its icon-only rail mode (body/app has .sidebar-collapsed), where the
   labels are hidden and every item is already reduced to an icon.

   The needed CSS is injected here so a layout only has to load this one
   file, with no extra stylesheet link.
*/
(function () {
  var sidebar = document.querySelector('.sidebar');
  if (!sidebar) return;
  var sections = sidebar.querySelectorAll('.sidebar-section');
  if (!sections.length) return;

  // Inject the styling once.
  if (!document.getElementById('aa-cat-style')) {
    var st = document.createElement('style');
    st.id = 'aa-cat-style';
    st.textContent =
      '.sidebar .sidebar-label{cursor:pointer;user-select:none;display:flex;' +
        'align-items:center;justify-content:space-between;gap:8px;}' +
      '.sidebar .sidebar-label .aa-cat-chevron{flex:0 0 auto;opacity:.55;' +
        'transition:transform .18s ease;}' +
      '.sidebar .sidebar-section.is-cat-collapsed .sidebar-label .aa-cat-chevron{' +
        'transform:rotate(-90deg);}' +
      '#appShell:not(.sidebar-collapsed) .sidebar .sidebar-section.is-cat-collapsed ' +
        '.nav-item{display:none;}';
    document.head.appendChild(st);
  }

  // Storage namespace keyed to the current module (first path segment).
  var ns = 'aaCat:' + (location.pathname.split('/')[1] || 'root') + ':';

  sections.forEach(function (section, idx) {
    var label = section.querySelector('.sidebar-label');
    if (!label) return;

    var key = ns + (label.textContent || String(idx)).trim().toLowerCase().replace(/\s+/g, '-');

    // Add a chevron once so users see the section is collapsible.
    if (!label.querySelector('.aa-cat-chevron')) {
      var chev = document.createElement('span');
      chev.className = 'aa-cat-chevron';
      chev.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" ' +
        'stroke="currentColor" stroke-width="2.4" stroke-linecap="round" ' +
        'stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>';
      label.appendChild(chev);
    }

    label.setAttribute('role', 'button');
    label.setAttribute('tabindex', '0');

    var stored = null;
    try { stored = localStorage.getItem(key); } catch (e) {}
    // Default: first category open, the rest collapsed.
    var collapsed = stored === null ? (idx !== 0) : (stored === '1');
    section.classList.toggle('is-cat-collapsed', collapsed);
    label.setAttribute('aria-expanded', collapsed ? 'false' : 'true');

    function toggle() {
      var isCol = section.classList.toggle('is-cat-collapsed');
      label.setAttribute('aria-expanded', isCol ? 'false' : 'true');
      try { localStorage.setItem(key, isCol ? '1' : '0'); } catch (e) {}
    }

    label.addEventListener('click', toggle);
    label.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
    });
  });
})();
