// File Monitor System JavaScript
// Handles dynamic form behavior and connectivity testing

document.addEventListener('DOMContentLoaded', function() {
    console.log('File Monitor System loaded');
   
    // Initialize form behaviors
    initializeSystemTypeSelectors();
    initializeIntermediateToggle();
    initializeConnectivityTesting();
   
    // Auto-set date inputs to default range (last 2 days)
    initializeDateInputs();
   
    // Debug: Check if elements exist
    const systemSelects = document.querySelectorAll('.system-type-select');
    const intermediateToggle = document.getElementById('has_intermediate');
    console.log('Found system selects:', systemSelects.length);
    console.log('Found intermediate toggle:', intermediateToggle ? 'yes' : 'no');
});

function initializeSystemTypeSelectors() {
    const systemTypeSelects = document.querySelectorAll('.system-type-select');
   
    systemTypeSelects.forEach(select => {
        select.addEventListener('change', function() {
            const prefix = this.dataset.prefix;
            const systemType = this.value;
           
            // Hide all config sections for this prefix
            const dbConfig = document.getElementById(`${prefix}_db_config`);
            const sftpConfig = document.getElementById(`${prefix}_sftp_config`);
           
            if (dbConfig) dbConfig.style.display = 'none';
            if (sftpConfig) sftpConfig.style.display = 'none';
           
            // Show relevant config section
            if (systemType === 'oracle' || systemType === 'mssql') {
                if (dbConfig) {
                    dbConfig.style.display = 'block';
                    setRequiredFields(prefix, 'db');
                }
            } else if (systemType === 'log') {
                if (sftpConfig) {
                    sftpConfig.style.display = 'block';
                    setRequiredFields(prefix, 'sftp');
                }
            }
        });
    });
}

function setRequiredFields(prefix, configType) {
    // Remove all required attributes for this prefix
    const allInputs = document.querySelectorAll(`[name^="${prefix}_"]`);
    allInputs.forEach(input => {
        input.removeAttribute('required');
    });
   
    // Set required fields based on config type
    if (configType === 'db') {
        const requiredFields = [
            'connection_string', 'username', 'password',
            'sql_query', 'filename_column'
        ];
        requiredFields.forEach(field => {
            const input = document.querySelector(`[name="${prefix}_${field}"]`);
            if (input) input.setAttribute('required', 'required');
        });
    } else if (configType === 'sftp') {
        const requiredFields = [
            'hostname', 'path', 'sftp_username',
            'sftp_password', 'file_naming_convention', 'data_fileName'
        ];
        requiredFields.forEach(field => {
            const input = document.querySelector(`[name="${prefix}_${field}"]`);
            if (input) input.setAttribute('required', 'required');
        });
    }
}

function initializeIntermediateToggle() {
    const intermediateToggle = document.getElementById('has_intermediate');
    const intermediateSection = document.getElementById('intermediate_system');
   
    if (intermediateToggle && intermediateSection) {
        intermediateToggle.addEventListener('change', function() {
            if (this.checked) {
                intermediateSection.style.display = 'block';
                // Set required attribute on intermediate name and system type
                const intermediateName = document.getElementById('intermediate_name');
                const intermediateType = document.getElementById('intermediate_system_type');
               
                if (intermediateName) intermediateName.setAttribute('required', 'required');
                if (intermediateType) intermediateType.setAttribute('required', 'required');
            } else {
                intermediateSection.style.display = 'none';
                // Remove all required attributes from intermediate fields
                const intermediateInputs = document.querySelectorAll('[name^="intermediate_"]');
                intermediateInputs.forEach(input => {
                    input.removeAttribute('required');
                });
            }
        });
    }
}

function initializeConnectivityTesting() {
    const testButtons = document.querySelectorAll('.test-connectivity');
   
    testButtons.forEach(button => {
        button.addEventListener('click', function() {
            const prefix = this.dataset.prefix;
            testSystemConnectivity(prefix, this);
        });
    });
}

function testSystemConnectivity(prefix, button) {
    const systemTypeSelect = document.getElementById(`${prefix}_system_type`);
    const systemType = systemTypeSelect.value;
   
    if (!systemType) {
        showAlert('Please select a system type first', 'warning');
        return;
    }
   
    // Update button state
    button.classList.add('testing');
    button.disabled = true;
    button.innerHTML = '<span class="loading-spinner"></span> Testing...';
   
    // Collect configuration data
    const config = collectSystemConfig(prefix, systemType);
   
    // Send test request
    // CSRF token: the route is csrf_protect-ed; the token is published in a
    // <meta> tag by the layout and accepted via the X-CSRFToken header.
    const csrfMeta = document.querySelector('meta[name="csrf-token"]');
    fetch('/file-monitor/test-connectivity', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfMeta ? csrfMeta.content : ''
        },
        body: JSON.stringify({
            system_type: systemType,
            config: config
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            button.classList.remove('testing', 'error');
            button.classList.add('success');
            button.innerHTML = `
                Connected
            `;
            showAlert(data.message, 'success');
        } else {
            button.classList.remove('testing', 'success');
            button.classList.add('error');
            button.innerHTML = `
                Failed
            `;
            showAlert(data.message, 'error');
        }
    })
    .catch(error => {
        button.classList.remove('testing', 'success');
        button.classList.add('error');
        button.innerHTML = `
            Error
        `;
        showAlert('Network error occurred', 'error');
        console.error('Connectivity test error:', error);
    })
    .finally(() => {
        button.disabled = false;
       
        // Reset button after 3 seconds
        setTimeout(() => {
            button.classList.remove('testing', 'success', 'error');
            button.innerHTML = `
                Test Connection
            `;
        }, 3000);
    });
}

function collectSystemConfig(prefix, systemType) {
    const config = {};
   
    if (systemType === 'oracle' || systemType === 'mssql') {
        config.connection_string = getValue(`${prefix}_connection_string`);
        config.username = getValue(`${prefix}_username`);
        config.password = getValue(`${prefix}_password`);
        config.test_query = systemType === 'oracle' ? 'SELECT 1 FROM DUAL' : 'SELECT 1';
    } else if (systemType === 'log') {
        config.hostname = getValue(`${prefix}_hostname`);
        config.username = getValue(`${prefix}_sftp_username`);
        config.password = getValue(`${prefix}_sftp_password`);
        config.path = getValue(`${prefix}_path`) || '/';
    }
   
    return config;
}

function getValue(fieldName) {
    const field = document.querySelector(`[name="${fieldName}"]`);
    return field ? field.value : '';
}

function showAlert(message, type) {
    // Create alert element
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show`;
    // Server messages can echo connection errors / user-entered config —
    // escape them so they can never carry live markup.
    const safeMessage = String(message ?? '')
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    alertDiv.innerHTML = `
        ${safeMessage}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
   
    // Insert at top of main content. base.html pages expose `main .container`;
    // the standalone file-monitor layout exposes `.main .content`.
    const mainContent = document.querySelector('main .container') || document.querySelector('.main .content');
    if (mainContent) {
        mainContent.insertBefore(alertDiv, mainContent.firstChild);

        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }
}

function initializeDateInputs() {
    const startDateInput = document.getElementById('start_date');
    const endDateInput = document.getElementById('end_date');
   
    if (startDateInput && endDateInput) {
        // Only set defaults if they're empty
        if (!startDateInput.value) {
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            startDateInput.value = yesterday.toISOString().split('T')[0];
        }
       
        if (!endDateInput.value) {
            const today = new Date();
            endDateInput.value = today.toISOString().split('T')[0];
        }
    }
}

// Form validation before submission
document.addEventListener('submit', function(e) {
    if (e.target.id === 'reportForm') {
        if (!validateReportForm()) {
            e.preventDefault();
            return false;
        }
    }
});

function validateReportForm() {
    const applicationName = getValue('application_name');
    if (!applicationName) {
        showAlert('Please enter the application name', 'error');
        return false;
    }

    // The form configures up to two flows via toggles; at least one must be on.
    const inbound = document.querySelector('[name="configure_inbound"]');
    const outbound = document.querySelector('[name="configure_outbound"]');
    const flows = [];
    if (inbound && inbound.checked) flows.push({ prefix: 'in__', label: 'Inbound' });
    if (outbound && outbound.checked) flows.push({ prefix: 'out__', label: 'Outbound' });

    // Legacy single-flow form fallback (no toggles on the page).
    if (!inbound && !outbound) {
        return true;
    }
    if (flows.length === 0) {
        showAlert('Select at least one flow: Inbound or Outbound', 'error');
        return false;
    }

    for (const flow of flows) {
        const p = flow.prefix;
        const systems = ['source', 'target'];
        const hasInter = document.querySelector(`[name="${p}has_intermediate"]`);
        if (hasInter && hasInter.checked) systems.splice(1, 0, 'intermediate');

        for (const sys of systems) {
            const type = getValue(`${p}${sys}_system_type`);
            if (!getValue(`${p}${sys}_name`) || !type) {
                showAlert(`${flow.label}: please fill in the ${sys} system name and type`, 'error');
                return false;
            }
            // The filename location is mandatory - matching is meaningless
            // without it.
            if (type === 'log') {
                if (!getValue(`${p}${sys}_data_fileName`)) {
                    showAlert(`${flow.label} ${sys}: File Name Position is required`, 'error');
                    return false;
                }
            } else if (!getValue(`${p}${sys}_filename_column`)) {
                showAlert(`${flow.label} ${sys}: Filename Column is required`, 'error');
                return false;
            }
            // At least one display field - the tables show only these.
            const dispRefs = Array.from(
                document.querySelectorAll(`input[name="${p}${sys}_disp_ref"]`)
            ).some(el => el.value.trim() !== '');
            if (!dispRefs) {
                showAlert(`${flow.label} ${sys}: select at least one display field (Records to Display)`, 'error');
                return false;
            }
        }
    }
    return true;
}

// Export functions for potential external use
window.FileMonitor = {
    testSystemConnectivity,
    showAlert,
    validateReportForm
};
