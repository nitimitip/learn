(() => {
  'use strict';
  const dialog=document.getElementById('triageDialog');
  if (!dialog) return;
  let target=null, status='', pending=false, opener=null;
  const note=document.getElementById('triageNote');
  const error=document.getElementById('triageError');
  const save=document.getElementById('triageSave');
  const cancel=document.getElementById('triageCancel');
  dialog.setAttribute('aria-labelledby','triageTitle');
  document.querySelectorAll('.triage-btn').forEach(button=>button.addEventListener('click',()=>{
    target=button.closest('.triage-cell'); status=button.dataset.status; opener=button.closest('.dropdown').querySelector('[data-bs-toggle]');
    document.getElementById('triageTitle').textContent=({OPEN:'Reopen finding',FALSE_POSITIVE:'Mark as false positive',ACCEPTED_RISK:'Accept this risk'})[status];
    document.getElementById('triageContext').textContent=button.closest('tr').querySelector('.finding-file').textContent;
    note.value=''; error.textContent=''; dialog.showModal(); note.focus();
  }));
  cancel.addEventListener('click',()=>dialog.close());
  dialog.addEventListener('cancel',e=>{if(pending)e.preventDefault();});
  dialog.addEventListener('close',()=>opener?.focus());
  document.getElementById('triageForm').addEventListener('submit',async event=>{
    event.preventDefault(); if(pending)return;
    pending=true; save.disabled=true; cancel.disabled=true; save.textContent='Saving…'; error.textContent='';
    try {
      const response=await fetch(dialog.dataset.url,{method:'POST',credentials:'same-origin',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({csrf_token:document.querySelector('meta[name="csrf-token"]').content,
          fingerprint:target.dataset.fingerprint,status,note:note.value})});
      const result=await response.json();
      if(!response.ok || !result.ok)throw new Error(result.error || 'Could not save this decision. Please retry.');
      const chip=document.createElement('span');
      chip.className=status==='OPEN'?'muted':`triage-chip triage-${status}`;
      chip.textContent=result.label; chip.title=note.value;
      target.querySelector('.triage-current').replaceChildren(chip);
      target.closest('tr').classList.toggle('finding-suppressed',status!=='OPEN');
      dialog.close();
      const toast=document.getElementById('triageFeedback'); toast.hidden=false;
      toast.textContent='Decision saved. Historical scores are unchanged; re-scan to refresh the gate.';
      setTimeout(()=>{toast.hidden=true;},7000);
    } catch(err) { error.textContent=err instanceof SyntaxError?'Session or server response unavailable. Refresh and retry.':err.message; }
    finally {pending=false;save.disabled=false;cancel.disabled=false;save.textContent='Save decision';}
  });
})();
