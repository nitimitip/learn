/*
   The project bar's section strip: right-edge fade and reveal-the-current.

   Shared, because the strip is shared. It renders as live tab BUTTONS on the
   project page and as LINKS on the pages scoped one level deeper (the Go-Live
   plan form) - see templates/project_management/_modbar_project.html - and
   both modes overflow at the same widths, so both need this. It keys on the
   strip's id alone and does nothing when the page has no strip, so the layout
   can load it unconditionally.

   Tab-specific behaviour - history, the breadcrumb tail, Plotly's resize -
   stays with the page that owns the panes.
*/
(function () {
    const strip = document.getElementById('projectTabs');
    if (!strip) return;

    // A section opened from a URL must not arrive with its own tab sitting
    // under the fade at the right edge, so bring it into view. scrollLeft
    // rather than scrollIntoView: the latter would also scroll the page.
    //
    // Scroll the minimum that reveals it, and do it again after load -
    // webfonts and the count badges settle late, and a position computed
    // before that is already wrong by the time anyone sees it.
    function revealActive() {
        const active = strip.querySelector('.nav-link.active');
        if (!active) return;
        const a = active.getBoundingClientRect(), s = strip.getBoundingClientRect();
        if (a.right > s.right - 12) {
            strip.scrollLeft += (a.right - s.right) + 12;
        } else if (a.left < s.left) {
            strip.scrollLeft -= (s.left - a.left);
        }
    }

    // The fade at the right edge means "there is more this way", so it may
    // only show when there IS more. CSS cannot ask whether a box overflows.
    function syncFade() {
        strip.classList.toggle('is-scrollable',
                               strip.scrollWidth > strip.clientWidth + 1);
    }

    function sync() { syncFade(); revealActive(); }

    sync();
    window.addEventListener('load', sync);
    window.addEventListener('resize', sync);
})();
