/* Presentation and navigation only; no changes to project actions or stored data. */
(() => {
  'use strict';
  /* Legacy Project Management shell.
     The module now renders the shared application chrome, whose navigation is
     owned by _chrome_sidenav.html. This block only runs if the old PM-specific
     sidebar is still on the page, so the content enhancements further down
     keep working either way. */
  const shell = document.getElementById('appShell');
  const sidebar = document.getElementById('pmNavigation');
  const toggle = document.getElementById('sidebarToggle');
  const close = document.querySelector('.pm-nav-close');
  const collapse = document.getElementById('sidebarCollapse');
  const mobile = matchMedia('(max-width: 992px)');
  if (shell && sidebar && toggle && close && collapse) {
  sidebar.classList.add('pm-nav-ready');
  document.querySelectorAll('.pm-nav-group').forEach((button, index) => {
    const section = button.closest('.sidebar-section');
    button.addEventListener('click', () => {
      const open = section.classList.toggle('is-open');
      button.setAttribute('aria-expanded', String(open));
    });
    section.querySelectorAll('a').forEach(link => {
      if (!link.title) link.title = link.textContent.trim();
    });
  });
  function sync() {
    const open = shell.classList.contains('sidebar-open');
    sidebar.inert = mobile.matches && !open;
    toggle.setAttribute('aria-expanded', String(open));
    const collapsed = shell.classList.contains('sidebar-collapsed');
    collapse.setAttribute('aria-label', collapsed ? 'Expand sidebar' : 'Collapse sidebar');
    collapse.title = collapsed ? 'Expand sidebar' : 'Collapse sidebar';
  }
  const dismiss = () => { shell.classList.remove('sidebar-open'); sync(); toggle.focus(); };
  toggle.addEventListener('click', () => { sync(); if(shell.classList.contains('sidebar-open')) close.focus(); });
  close.addEventListener('click', dismiss);
  new MutationObserver(sync).observe(shell,{attributes:true,attributeFilter:['class']});
  mobile.addEventListener('change',sync);
  sync();
  document.addEventListener('keydown', event => {
    if (!mobile.matches || !shell.classList.contains('sidebar-open')) return;
    if(event.key === 'Escape') { event.preventDefault(); dismiss(); }
    if(event.key === 'Tab') {
      const items = [...sidebar.querySelectorAll('a,button')].filter(el => el.getClientRects().length);
      const first = items[0], last = items[items.length-1];
      if(event.shiftKey && document.activeElement===first){event.preventDefault();last.focus();}
      else if(!event.shiftKey && document.activeElement===last){event.preventDefault();first.focus();}
    }
  });
  } /* end legacy PM shell */

  // Large tables scroll locally, preserving the page width and all columns.
  document.querySelectorAll('.content table.tbl').forEach(table => {
    if(table.closest('.table-responsive,.pm-table-scroll,.card-body.flush')) return;
    const wrapper = document.createElement('div'); wrapper.className='pm-table-scroll';
    table.before(wrapper); wrapper.append(table);
  });
  // Jump links make long project forms easier to navigate without hiding fields.
  document.querySelectorAll('#projectForm,#editForm').forEach(form => {
    const sections=[...form.querySelectorAll('.form-section')];
    if(sections.length<3) return;
    const nav=document.createElement('nav'); nav.className='pm-section-jumps';nav.setAttribute('aria-label','Form sections');
    const entries=[];
    sections.forEach((section,index)=>{
      const heading=section.querySelector('h3'); if(!heading)return;
      if(!section.id)section.id='pm-form-section-'+index;
      const link=document.createElement('a');link.href='#'+section.id;
      link.textContent=heading.textContent.trim();
      const badge=document.createElement('span');badge.textContent=String(index+1).padStart(2,'0');link.prepend(badge);
      link.addEventListener('click',()=>{section.tabIndex=-1;section.focus({preventScroll:true});});
      nav.append(link);
      entries.push({section,link,badge});
    });
    form.before(nav);
    const update=()=>{let number=0;entries.forEach(({section,link,badge})=>{link.hidden=!section.getClientRects().length;if(!link.hidden)badge.textContent=String(++number).padStart(2,'0');});};
    new MutationObserver(update).observe(form,{attributes:true,subtree:true,attributeFilter:['style','hidden','class']});
    update();
  });
  document.querySelectorAll('.btn-icon-square[title], .icon-btn[title]').forEach(el=>{if(!el.hasAttribute('aria-label'))el.setAttribute('aria-label',el.title);});
})();
