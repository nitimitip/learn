/* ============================================================
   ServiceNow Analysis - front-end glue
   Module-scoped. Renders inside the host's NPG App Assist shell.
   Expects Bootstrap 5 + Bootstrap Icons from the host, and Plotly
   from /static/service_now_analysis/js/vendor/plotly.min.js.
   ============================================================ */

// Resolve the blueprint URL prefix. The blueprint is mounted at
// /service-now-analysis by main_app.py - this constant lets the
// front end build URLs without hardcoding the prefix.
const SNOW_BASE = (() => {
  // Strip trailing slash
  const path = window.location.pathname.replace(/\/+$/, "");
  // Match the prefix: take everything up to and including the first
  // /service-now-analysis segment.
  const m = path.match(/^(.*?\/service-now-analysis)(\/|$)/);
  return m ? m[1] : "/service-now-analysis";
})();

const PLOTLY_CFG = { responsive: true, displayModeBar: false };

// Unified colour palette
// One ordered sequence used wherever we need categorical colours
// (treemap, donut, generic bar charts). NPG-aligned. Avoids Plotly's
// default rainbow and keeps every chart visually consistent with the
// host's brand palette.
const SNOW_CATEGORICAL = [
  "#AB1236", // NPG red
  "#1D293D", // NPG navy
  "#2563EB", // blue
  "#0EA5A4", // teal
  "#7C3AED", // violet
  "#F59E0B", // amber
  "#22C55E", // green
  "#EC4899", // pink
  "#0891B2", // cyan
  "#EA580C", // orange
  "#475569", // slate
  "#A16207", // bronze
];

// A categorical colour for index `i` that stays distinguishable past the
// end of the palette. Plain modulo wrapping gives the 13th series the
// same colour as the 1st, which on a stacked bar reads as one segment;
// the assignment-group type mix routinely runs past twelve categories.
// Each wrap lightens then darkens the base colour instead.
function snowCycleColor(i) {
  const base  = SNOW_CATEGORICAL[i % SNOW_CATEGORICAL.length];
  const cycle = Math.floor(i / SNOW_CATEGORICAL.length);
  if (!cycle) return base;
  return snowShade(base, (cycle % 2) ? 0.42 : -0.32);
}

// Mix a #rrggbb toward white (amount > 0) or black (amount < 0).
function snowShade(hex, amount) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex));
  if (!m) return hex;
  const n = parseInt(m[1], 16);
  const target = amount > 0 ? 255 : 0;
  const t = Math.abs(amount);
  const ch = s => Math.round(((n >> s) & 255) * (1 - t) + target * t);
  return "#" + [ch(16), ch(8), ch(0)]
    .map(v => v.toString(16).padStart(2, "0")).join("");
}

// Sequential ramp for treemap-style "more is bigger" visuals - runs
// from a soft NPG-pale through to deep NPG red.
const SNOW_SEQUENTIAL = [
  [0,    "#FFE4EA"],
  [0.3,  "#F4A4B6"],
  [0.6,  "#D0163F"],
  [1,    "#8A0E2C"],
];

// Shared Plotly layout defaults - typography, transparent backgrounds,
// soft gridlines. Pass to every newPlot via `Object.assign(SNOW_LAYOUT, ...)`.
const SNOW_LAYOUT = {
  font: {
    family: "'DM Sans', system-ui, -apple-system, sans-serif",
    size: 12,
    color: "#1D293D",
  },
  paper_bgcolor: "rgba(0,0,0,0)",
  plot_bgcolor:  "rgba(0,0,0,0)",
  colorway: SNOW_CATEGORICAL,
  hoverlabel: {
    bgcolor: "#1D293D",
    bordercolor: "#1D293D",
    font: { color: "#fff", family: "'DM Sans', sans-serif", size: 12 },
  },
  xaxis: {
    automargin: true,
    gridcolor: "#F1F5F9",
    linecolor: "#E5E7EB",
    zerolinecolor: "#E5E7EB",
    tickfont: { size: 11, color: "#6B7280" },
    titlefont: { size: 11, color: "#6B7280" },
  },
  yaxis: {
    automargin: true,
    gridcolor: "#F1F5F9",
    linecolor: "#E5E7EB",
    zerolinecolor: "#E5E7EB",
    tickfont: { size: 11, color: "#6B7280" },
    titlefont: { size: 11, color: "#6B7280" },
  },
  legend: {
    font: { size: 11, color: "#374151" },
  },
  // Geometry half of the premium chart treatment in npg_module.css ("THE
  // FIGURES"): the stylesheet lights and grounds each mark, this rounds it.
  // On a stack Plotly rounds only the TOP of the whole column, which is
  // right - a stack is one column, not a pile of separate objects.
  barcornerradius: 3,
};

// Deep-merge two layout objects so chart-specific overrides win without
// losing the shared defaults (e.g. an override for one axis property
// shouldn't wipe out the others).
function snowLayout(overrides) {
  const out = JSON.parse(JSON.stringify(SNOW_LAYOUT));
  for (const [k, v] of Object.entries(overrides || {})) {
    if (v && typeof v === "object" && !Array.isArray(v) && out[k] && typeof out[k] === "object") {
      out[k] = Object.assign({}, out[k], v);
    } else {
      out[k] = v;
    }
  }
  return out;
}

const PRIORITY_COLOR = {
  "P1": "#dc3545", "1": "#dc3545",
  "P2": "#fd7e14", "2": "#fd7e14",
  "P3": "#0d6efd", "3": "#0d6efd",
  "P4": "#6c757d", "4": "#6c757d",
};

function fmtNum(n, digits = 1) {
  if (n === null || n === undefined || Number.isNaN(n)) return "-";
  return Number(n).toLocaleString(undefined, {
    maximumFractionDigits: digits, minimumFractionDigits: 0
  });
}

function escapeHtml(s) {
  if (s === null || s === undefined) return "";
  return String(s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

function priorityBadge(p) {
  const k = String(p || "").trim();
  const cls = PRIORITY_COLOR[k] ? `snow-prio-badge priority-${k}` : "snow-prio-badge";
  return `<span class="${cls}">${escapeHtml(k || "-")}</span>`;
}

function riskPill(score) {
  const s = Number(score) || 0;
  let cls = "snow-risk-low", lbl = "Low";
  if (s >= 0.7)      { cls = "snow-risk-high";   lbl = "High"; }
  else if (s >= 0.4) { cls = "snow-risk-medium"; lbl = "Med"; }
  return `<span class="snow-risk-pill ${cls}">${lbl} ${fmtNum(s * 100, 0)}%</span>`;
}

async function fetchJson(url, opts = {}) {
  const res = await fetch(url, opts);
  const ctype = res.headers.get("content-type") || "";

  // Always read the body once. We need it to surface errors.
  const text = await res.text();

  // If the server didn't claim JSON, we may still try to parse; but a
  // non-JSON 5xx page is more useful as a snippet of text.
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch (err) {
      // Most common cause in production: payload contains NaN/Infinity
      // tokens, which RFC 8259 rejects. The browser's JSON.parse refuses,
      // so we surface a helpful error instead of returning null.
      const looksLikeNaN = /\b(NaN|Infinity|-Infinity)\b/.test(text);
      const hint = looksLikeNaN
        ? " (response contains NaN/Infinity - check server logs; usually means missing values in numeric columns slipped past sanitisation)"
        : "";
      throw new Error(
        `Server returned malformed JSON (status ${res.status})${hint}`
      );
    }
  }

  if (!res.ok) {
    const msg = (data && data.error) || `Request failed (${res.status})`;
    throw new Error(msg);
  }
  if (data === null) {
    throw new Error(`Server returned an empty response (status ${res.status})`);
  }
  return data;
}

/* ============================================================
   Upload page - one uploader per section, scoped to a root
   element so the Incident and Service Request panes can coexist.
   `endpoint` is the blueprint-relative POST target ("/upload" or
   "/upload-service-request").
   ============================================================ */
function initUploadPage(rootId, endpoint) {
  const root = rootId ? document.getElementById(rootId) : document;
  if (!root) return;
  endpoint = endpoint || "/upload";

  const $ = (sel) => root.querySelector(sel);
  const dz = $(".js-drop");
  const inp = $(".js-file");
  const browseBtn = $(".js-browse");
  const fileMeta = $(".js-meta");
  const fileName = $(".js-name");
  const fileSize = $(".js-size");
  const errBox = $(".js-error");
  const errMsg = $(".js-error-msg");
  const missingList = $(".js-missing");
  const progress = $(".js-progress");
  const progressBar = $(".js-progress-bar");
  const progressPct = $(".js-progress-pct");
  const progressLabel = $(".js-progress-label");

  if (!dz) return;

  const showError = (msg, missing) => {
    errMsg.textContent = msg;
    if (missing && missing.length) {
      missingList.classList.remove("d-none");
      missingList.innerHTML = missing.map(c => `<li><code>${escapeHtml(c)}</code></li>`).join("");
    } else {
      missingList.classList.add("d-none");
    }
    errBox.classList.remove("d-none");
  };
  const clearError = () => {
    errBox.classList.add("d-none");
    missingList.classList.add("d-none");
  };

  const beginUpload = (file) => {
    clearError();
    fileName.textContent = file.name;
    fileSize.textContent = `${(file.size / 1024 / 1024).toFixed(2)} MB`;
    fileMeta.classList.remove("d-none");

    progress.classList.remove("d-none");
    progressBar.style.width = "0%";
    progressPct.textContent = "0%";
    progressLabel.textContent = "Uploading...";

    const fd = new FormData();
    fd.append("file", file);

    const xhr = new XMLHttpRequest();
    xhr.open("POST", `${SNOW_BASE}${endpoint}`);

    xhr.upload.onprogress = (e) => {
      if (!e.lengthComputable) return;
      const pct = Math.round((e.loaded / e.total) * 100);
      progressBar.style.width = `${pct}%`;
      progressPct.textContent = `${pct}%`;
      if (pct >= 100) progressLabel.textContent = "Analysing...";
    };

    xhr.onload = () => {
      let data = {};
      try { data = JSON.parse(xhr.responseText); } catch (_) {}
      if (xhr.status >= 200 && xhr.status < 300 && data.ok) {
        progressBar.classList.remove("progress-bar-animated");
        progressLabel.textContent = "Done - redirecting...";
        window.location.href = data.redirect;
      } else {
        progress.classList.add("d-none");
        showError(data.error || `Upload failed (${xhr.status})`, data.missing_required);
      }
    };
    xhr.onerror = () => {
      progress.classList.add("d-none");
      showError("Network error during upload.");
    };
    xhr.send(fd);
  };

  browseBtn.addEventListener("click", () => inp.click());
  dz.addEventListener("click", (e) => {
    if (e.target === browseBtn || browseBtn.contains(e.target)) return;
    inp.click();
  });
  inp.addEventListener("change", (e) => {
    if (e.target.files.length) beginUpload(e.target.files[0]);
  });

  ["dragenter", "dragover"].forEach(ev =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add("dragover"); })
  );
  ["dragleave", "drop"].forEach(ev =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove("dragover"); })
  );
  dz.addEventListener("drop", (e) => {
    if (e.dataTransfer.files.length) beginUpload(e.dataTransfer.files[0]);
  });
}

/* ============================================================
   Template generator page
   ============================================================ */
function initTemplatePage() {
  const form = document.getElementById("templateForm");
  if (!form) return;

  const errBox = document.getElementById("tg_error");
  const errMsg = document.getElementById("tg_error_msg");
  const placeholder = document.getElementById("tg_placeholder");
  const result = document.getElementById("tg_result");
  const submitBtn = document.getElementById("tg_submit");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    errBox.classList.add("d-none");

    const desc = document.getElementById("tg_description").value.trim();
    if (desc.length < 10) {
      errMsg.textContent = "Please provide a longer description (at least 10 characters).";
      errBox.classList.remove("d-none");
      return;
    }

    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Generating...';

    try {
      const data = await fetchJson(`${SNOW_BASE}/template/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          description: desc,
          scope: document.getElementById("tg_scope").value,
          environment: document.getElementById("tg_environment").value,
          caller: document.getElementById("tg_caller").value || "Unknown",
        }),
      });

      const t = data.template;
      placeholder.classList.add("d-none");
      result.classList.remove("d-none");

      const setField = (name, val) => {
        document.querySelectorAll(`[data-field="${name}"]`).forEach(el => {
          if (name === "priority") {
            el.textContent = val || "-";
            el.className = `priority-badge priority-${val || ""}`;
          } else {
            el.textContent = val || "-";
          }
        });
      };

      setField("short_description", t.short_description);
      setField("category", t.category);
      setField("subcategory", t.subcategory || "-");
      setField("priority", t.priority);
      setField("impact", t.impact);
      setField("urgency", t.urgency);
      setField("assignment_group", t.assignment_group);
      setField("environment", t.environment);
      setField("estimated_resolution_hours", fmtNum(t.estimated_resolution_hours, 1));

      const conf = t.confidence || {};
      const confParts = [];
      if (conf.category)         confParts.push(`category ${fmtNum(conf.category * 100, 0)}%`);
      if (conf.priority)         confParts.push(`priority ${fmtNum(conf.priority * 100, 0)}%`);
      if (conf.assignment_group) confParts.push(`routing ${fmtNum(conf.assignment_group * 100, 0)}%`);
      const confEl = document.getElementById("tg_confidence");
      if (t.fallback_mode) {
        confEl.innerHTML = '<span class="badge bg-warning text-dark me-1">fallback</span>Models not trained - values are rule-based.';
      } else if (confParts.length) {
        confEl.innerHTML = `<i class="fas fa-chart-column me-1"></i>Confidence: ${confParts.join(" - ")}`;
      } else {
        confEl.textContent = "";
      }

      const stepsCard = document.getElementById("tg_steps_card");
      const stepsOl = document.getElementById("tg_steps");
      const rcEl = document.getElementById("tg_root_cause");
      const steps = t.suggested_resolution_steps || [];
      if (steps.length) {
        stepsCard.classList.remove("d-none");
        rcEl.textContent = t.likely_root_cause ? `Likely root cause: ${t.likely_root_cause}` : "";
        stepsOl.innerHTML = steps.map(s => `<li>${escapeHtml(s)}</li>`).join("");
      } else {
        stepsCard.classList.add("d-none");
      }

      const simCard = document.getElementById("tg_similar_card");
      const simList = document.getElementById("tg_similar");
      const sims = t.similar_incidents || [];
      if (sims.length) {
        simCard.classList.remove("d-none");
        // Map similarity % to a colour band the same way the Similar
        // Incident page does, so identical scores produce identical
        // colours across both pages. >=70 high (green), 50-70 medium
        // (amber), <50 low (grey).
        const bandFor = function (p) {
          const n = Number(p) || 0;
          return n >= 70 ? "high" : n >= 50 ? "medium" : "low";
        };
        simList.innerHTML = sims.map(s => `
          <li class="list-group-item d-flex justify-content-between align-items-center">
            <span>
              <code class="me-2">${escapeHtml(s.id)}</code>
              ${escapeHtml((s.title || "").slice(0, 80))}
            </span>
            <span class="snow-quality-pill snow-quality-pill--small" data-band="${bandFor(s.similarity)}">${fmtNum(s.similarity, 1)}%</span>
          </li>
        `).join("");
      } else {
        simCard.classList.add("d-none");
      }

    } catch (err) {
      errMsg.textContent = err.message;
      errBox.classList.remove("d-none");
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = '<i class="fas fa-wand-magic-sparkles me-1"></i>Generate template';
    }
  });

  document.getElementById("tg_copy").addEventListener("click", () => {
    const lines = [];
    document.querySelectorAll("#tg_result [data-field]").forEach(el => {
      const label = el.previousElementSibling ? el.previousElementSibling.textContent.trim() : "";
      const val = el.textContent.trim();
      if (label && val && val !== "-") lines.push(`${label}: ${val}`);
    });
    const steps = Array.from(document.querySelectorAll("#tg_steps li"))
                       .map((li, i) => `  ${i + 1}. ${li.textContent.trim()}`);
    if (steps.length) {
      lines.push("");
      lines.push("Suggested resolution steps:");
      lines.push(...steps);
    }
    const text = lines.join("\n");
    navigator.clipboard.writeText(text).then(() => {
      const btn = document.getElementById("tg_copy");
      const orig = btn.innerHTML;
      btn.innerHTML = '<i class="fas fa-check me-1"></i>Copied';
      setTimeout(() => { btn.innerHTML = orig; }, 1500);
    });
  });
}


/* ============================================================
   CR Template Generator page
   ============================================================ */
function initChangeTemplatePage() {
  const form = document.getElementById('crTemplateForm');
  if (!form) return;

  const elTitle     = document.getElementById('cr_title');
  const elDesc      = document.getElementById('cr_description');
  const elStart     = document.getElementById('cr_planned_start');
  const elEnd       = document.getElementById('cr_planned_end');
  const elEnv       = document.getElementById('cr_environment');
  const elReqBy     = document.getElementById('cr_requested_by');
  const elServers   = document.getElementById('cr_servers');
  const elSubmit    = document.getElementById('cr_tg_submit');

  const elQuality    = document.getElementById('cr_quality');
  const qualityFill  = elQuality ? elQuality.querySelector('.snow-quality-meter-fill') : null;
  const qualityScore = elQuality ? elQuality.querySelector('.snow-quality-meter-score') : null;
  const qualityBand  = elQuality ? elQuality.querySelector('.snow-quality-meter-band') : null;

  const elError       = document.getElementById('cr_tg_error');
  const elErrorMsg    = document.getElementById('cr_tg_error_msg');
  const elPlaceholder = document.getElementById('cr_tg_placeholder');
  const elResult      = document.getElementById('cr_tg_result');

  // Live local quality meter - mirrors server-side score_cr_description
  function localQualityScore(text) {
    text = (text || '').trim();
    const words = text.split(/\s+/).filter(Boolean);
    let score = 0;
    if (words.length >= 40) score += 25;
    else if (words.length >= 20) score += 18;
    else if (words.length >= 10) score += 10;

    if (!/^(make\s+(some\s+)?changes?|fix\s+something|update\s+stuff|patch\s+it)/i.test(text)) {
      score += 15;
    }
    const W = {
      what:  /\b(server|application|database|service|system|cluster|cmdb|ci|module|patch|upgrade|deploy|config)\b/i,
      where: /\b(production|prod|uat|test|dev|environment|site|location|region|cluster)\b/i,
      when:  /\b(today|tonight|this\s+\w+|next\s+\w+|after|during|window|maintenance|scheduled)\b/i,
      why:   /\b(because|due\s+to|in\s+order\s+to|to\s+fix|to\s+resolve|to\s+enable|security|performance|compliance)\b/i,
    };
    let answered = 0;
    for (const k in W) if (W[k].test(text)) answered++;
    score += Math.min(8 * answered, 32);
    if (/\b(KB\d+|v\d+\.\d|\d+\.\d+\.\d+|patch\s+\w+|PRB\d+|INC\d+|CHG\d+|RFC\d+)\b/i.test(text)) score += 18;
    else score += 5;
    if (text.indexOf('\n') >= 0 || /^\s*[\-\*\d]\./m.test(text) || words.length > 30) score += 10;
    else score += 5;
    return Math.min(100, Math.round(score));
  }
  function bandOf(score) {
    return score >= 75 ? 'green' : score >= 50 ? 'amber' : 'red';
  }
  function updateLiveQuality() {
    if (!elQuality) return;
    const text = elDesc.value || '';
    if (text.trim().length < 5) { elQuality.classList.add('d-none'); return; }
    const score = localQualityScore(text);
    const band  = bandOf(score);
    qualityFill.style.width = score + '%';
    qualityFill.dataset.band = band;
    qualityScore.textContent = score + '/100';
    qualityBand.textContent  = band.charAt(0).toUpperCase() + band.slice(1);
    qualityBand.dataset.band = band;
    elQuality.classList.remove('d-none');
  }
  if (elDesc) elDesc.addEventListener('input', updateLiveQuality);

  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    elError.classList.add('d-none');
    elSubmit.disabled = true;
    elSubmit.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Generating...</span>';

    try {
      const payload = {
        title:         elTitle.value.trim(),
        description:   elDesc.value.trim(),
        planned_start: elStart.value,
        planned_end:   elEnd.value,
        environment:   elEnv.value,
        requested_by:  (elReqBy && elReqBy.value || '').trim(),
        server_list:   (elServers && elServers.value || '').trim(),
      };
      const resp = await fetch('/service-now-analysis/api/change-template', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload),
      });
      const data = await resp.json();

      if (!resp.ok || data.status === 'error') {
        elErrorMsg.textContent = data.message || 'Generation failed.';
        elError.classList.remove('d-none');
        return;
      }
      if (data.status === 'no_models') {
        elErrorMsg.textContent = data.message;
        elError.classList.remove('d-none');
        return;
      }
      renderCrTemplate(data);
    } catch (err) {
      elErrorMsg.textContent = 'Network error: ' + err.message;
      elError.classList.remove('d-none');
    } finally {
      elSubmit.disabled = false;
      elSubmit.innerHTML = '<i class="fas fa-wand-magic-sparkles"></i><span>Generate template</span>';
    }
  });

  function renderCrTemplate(data) {
    elPlaceholder.classList.add('d-none');
    elResult.classList.remove('d-none');

    const t = data.template || {};
    const q = data.quality || {sections: {}, overall: {}};
    const planSrc = data.plan_source || {};

    // Disclaimer text from server (falls back to the inline default if missing)
    if (planSrc.disclaimer) {
      const disc = document.getElementById('cr_tg_disclaimer_text');
      if (disc) disc.textContent = planSrc.disclaimer;
    }

    // Overall
    document.getElementById('cr_tg_overall_score').textContent = (q.overall.score ?? '-');
    const ovBand = document.getElementById('cr_tg_overall_band');
    ovBand.textContent = (q.overall.band || '-').toUpperCase();
    ovBand.dataset.band = q.overall.band || '';
    const weakest = (q.overall.weakest_sections || []);
    document.getElementById('cr_tg_overall_weakest').textContent =
      weakest.length ? 'Weakest: ' + weakest.join(', ').replace(/_/g, ' ') : '';

    // Server warnings
    const warnings = (data.server_lookup && data.server_lookup.warnings) || [];
    const wEl = document.getElementById('cr_tg_warnings');
    const wList = document.getElementById('cr_tg_warnings_list');
    wList.innerHTML = '';
    if (warnings.length) {
      warnings.forEach(w => {
        const li = document.createElement('li');
        li.textContent = w;
        wList.appendChild(li);
      });
      wEl.classList.remove('d-none');
    } else {
      wEl.classList.add('d-none');
    }

    // Plan source / provenance line
    renderPlanSource(planSrc);

    // Fields table - grouped into four logical sections so the user
    // sees clear chunks (Identification / Timing / Classification /
    // Risk & routing) rather than one continuous list of rows.
    const tbody = document.getElementById('cr_tg_fields_table');
    tbody.innerHTML = '';
    const sections = [
      { heading: 'Identification', rows: [
        ['Title',            t.title,                  q.sections.title],
        ['Description',      shortPara(t.description), q.sections.description],
      ]},
      { heading: 'Timing & environment', rows: [
        ['Type',             t.type,                            q.sections.type],
        ['Planned start',    fmtDate(t.planned_start),          q.sections.planned_window],
        ['Planned end',      fmtDate(t.planned_end),            null],
        ['Environment',      t.environment || '-',              q.sections.environment],
      ]},
      { heading: 'Classification', rows: [
        ['Category',         t.category,         q.sections.category],
        ['Sub-category',     t.subcategory,      q.sections.subcategory],
        ['Business service', t.business_service, q.sections.business_service],
      ]},
      { heading: 'Risk & routing', rows: [
        ['Risk',             t.risk,                                                 q.sections.risk],
        ['Priority',         t.priority,                                             q.sections.priority],
        ['Impact / Urgency', (t.impact || '-') + ' - ' + (t.urgency || '-'),         q.sections.impact],
        ['Assignment group', t.assignment_group,                                     q.sections.assignment_group],
      ]},
    ];
    sections.forEach(section => {
      const trH = document.createElement('tr');
      trH.className = 'snow-section-divider';
      trH.innerHTML = '<td colspan="3">' + esc(section.heading) + '</td>';
      tbody.appendChild(trH);
      section.rows.forEach(([label, val, qual]) => {
        const tr = document.createElement('tr');
        tr.innerHTML =
          '<th>' + esc(label) + '</th>' +
          '<td>' + (val ? esc(String(val)) : '<span class="text-muted">-</span>') + '</td>' +
          '<td class="snow-cr-fields-quality">' + qualityPill(qual) + '</td>';
        tbody.appendChild(tr);
      });
    });

    // Plans
    fillStepsList('cr_tg_impl_steps',    t.implementation_plan,
                  'cr_tg_impl_quality',  q.sections.implementation_plan);
    fillStepsList('cr_tg_backout_steps', t.backout_plan,
                  'cr_tg_backout_quality', q.sections.backout_plan);
    fillStepsList('cr_tg_test_steps',    t.test_plan,
                  'cr_tg_test_quality',  q.sections.test_plan);

    // Risk & impact analysis
    document.getElementById('cr_tg_ria_text').textContent = t.risk_impact_analysis || '-';
    setQualityPill('cr_tg_ria_quality', q.sections.risk_impact_analysis);

    // Similar past CRs
    const list = document.getElementById('cr_tg_similar_list');
    list.innerHTML = '';
    (data.similar_changes || []).forEach((s, idx) => {
      // The chosen CR isn't always the top-scoring one - when the
      // recency tiebreaker fires it can be a slightly lower-scoring
      // but newer CR. Match by id so the badge always lands on the
      // actual source CR. Show the badge for any lift mode.
      const isBestMatch = (
        planSrc.best_match_id &&
        s.change_id === planSrc.best_match_id &&
        (planSrc.mode === 'high_confidence_match' ||
         planSrc.mode === 'best_available_match')
      );
      const li = document.createElement('li');
      li.className = 'list-group-item';
      li.innerHTML =
        '<div class="d-flex justify-content-between align-items-start gap-3">' +
          '<div>' +
            '<div class="fw-semibold">' +
              esc(s.change_id) + ' - ' + esc(s.title) +
              (isBestMatch ? ' <span class="badge bg-success ms-2">Used as plan source</span>' : '') +
            '</div>' +
            '<div class="small text-muted">' +
              esc(s.type) + ' - ' + esc(s.risk) + ' - ' + esc(s.category) +
              ' - ' + esc(s.assignment_group) +
            '</div>' +
          '</div>' +
          '<span class="snow-quality-pill snow-quality-pill--small" data-band="green">' +
            s.similarity_score + '%</span>' +
        '</div>';
      list.appendChild(li);
    });

    window.__lastCrTemplate    = t;
    window.__lastCrQuality     = q;
    window.__lastCrPlanSource  = planSrc;
    window.__lastCrSimilar     = data.similar_changes || [];
  }

  // Render the plan-source banner above the plan columns.
  // Modes emitted by change_predict.py since the always-lift policy:
  //   - high_confidence_match : best CR scored >= HIGH_CONFIDENCE_PCT (70%)
  //                             Show GREEN "Plans lifted from CHGxxxx (NN% match)"
  //   - best_available_match  : best CR scored between MIN_MATCH_PCT_FOR_LIFT
  //                             and HIGH_CONFIDENCE_PCT - still verbatim, but
  //                             show AMBER "Plans lifted from CHGxxxx (NN% match)"
  //                             with a "best available - review carefully" tone.
  //   - no_corpus_match       : nothing similar - hide the banner; plan
  //                             columns show their own "draft manually" state.
  function renderPlanSource(ps) {
    const el = document.getElementById('cr_tg_plan_source');
    const subtitle = document.getElementById('cr_tg_plans_subtitle');
    if (!el) return;
    if (!ps || !ps.mode || ps.mode === 'no_corpus_match') {
      el.classList.add('d-none');
      if (subtitle) subtitle.textContent =
        'No similar past CRs were found - please draft plans manually.';
      return;
    }
    if (ps.mode === 'high_confidence_match') {
      el.dataset.mode = 'high';
      el.innerHTML =
        '<i class="fas fa-bullseye" style="color:#15803D"></i>' +
        '<div>' +
          '<strong>Plans lifted from ' + esc(ps.best_match_id || '-') +
          ' (' + (ps.best_match_score || 0) + '% match)' + '</strong>' +
          (ps.best_match_title ? '<div class="small text-muted">' +
              esc(ps.best_match_title) + '</div>' : '') +
        '</div>';
      if (subtitle) subtitle.textContent =
        'Lifted verbatim from the highest-similarity past CR. Cross-validate before use.';
    } else if (ps.mode === 'best_available_match') {
      // New mode - best CR is below the high-confidence threshold but
      // still above the minimum lift floor. Same green-style banner so
      // the user clearly sees which CR drove the content; the amber
      // styling and "best available" wording flag that the match
      // wasn't strong enough to be high-confidence.
      el.dataset.mode = 'fallback';
      el.innerHTML =
        '<i class="fas fa-circle-info" style="color:#B45309"></i>' +
        '<div>' +
          '<strong>Plans lifted from ' + esc(ps.best_match_id || '-') +
          ' (' + (ps.best_match_score || 0) + '% match - best available)' + '</strong>' +
          (ps.best_match_title ? '<div class="small text-muted">' +
              esc(ps.best_match_title) + '</div>' : '') +
        '</div>';
      if (subtitle) subtitle.textContent =
        'Best-matching past CR is below the high-confidence threshold - review every step carefully.';
    } else {
      // Unknown mode - hide rather than show an empty banner.
      el.classList.add('d-none');
      return;
    }
    el.classList.remove('d-none');
  }

  function fillStepsList(listId, steps, qualityId, qualityObj) {
    const ol = document.getElementById(listId);
    if (!ol) return;

    // Tag the list so the CSS can colour the step-number chip per plan.
    // listId convention: cr_tg_impl_steps / cr_tg_backout_steps / cr_tg_test_steps
    const planType =
      listId.indexOf('impl') >= 0    ? 'impl'    :
      listId.indexOf('backout') >= 0 ? 'backout' :
      listId.indexOf('test') >= 0    ? 'test'    : '';
    if (planType) ol.setAttribute('data-plan', planType);

    ol.innerHTML = '';
    if (!steps || !steps.length) {
      const li = document.createElement('li');
      li.className = 'snow-steps-empty';
      li.textContent = 'No steps available.';
      ol.appendChild(li);
    } else {
      steps.forEach(s => {
        const li = document.createElement('li');
        li.textContent = s;
        ol.appendChild(li);
      });
    }
    setQualityPill(qualityId, qualityObj);
  }

  function setQualityPill(id, q) {
    if (!id) return;
    const el = document.getElementById(id);
    if (!el || !q) {
      if (el) { el.textContent = '-'; el.dataset.band = ''; }
      return;
    }
    el.textContent = q.score + '/100';
    el.dataset.band = q.band;
    el.title = q.note || '';
  }

  function qualityPill(q) {
    if (!q) return '';
    return '<span class="snow-quality-pill snow-quality-pill--small" data-band="' +
      esc(q.band) + '" title="' + esc(q.note || '') + '">' + q.score + '</span>';
  }

  function fmtDate(s) {
    if (!s) return '-';
    try {
      const d = new Date(s);
      if (isNaN(d.getTime())) return s;
      return d.toLocaleString();
    } catch (e) { return s; }
  }

  function shortPara(s) {
    if (!s) return '-';
    return s.length > 240 ? s.slice(0, 240) + '...' : s;
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // Copy & export
  document.getElementById('cr_tg_copy').addEventListener('click', function () {
    const t = window.__lastCrTemplate; if (!t) return;
    navigator.clipboard.writeText(buildPlainTextTemplate(t)).then(() => {
      this.innerHTML = '<i class="fas fa-check"></i><span>Copied!</span>';
      setTimeout(() => {
        this.innerHTML = '<i class="fas fa-clipboard"></i><span>Copy template</span>';
      }, 1500);
    });
  });

  // Excel export - POSTs the rendered template payload to the server,
  // which uses openpyxl to build a styled .xlsx (sections, plan
  // tables, similar-CR list, banded quality pills, source provenance).
  // We prefer this over a client-side blob because openpyxl is already
  // installed and yields a much more polished file than anything we
  // could put together in the browser.
  document.getElementById('cr_tg_export_xlsx').addEventListener('click', async function () {
    const t = window.__lastCrTemplate; if (!t) return;
    const btn = this;
    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Building...</span>';

    try {
      const resp = await fetch('/service-now-analysis/download/cr-template-excel', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          template:        t,
          plan_source:     window.__lastCrPlanSource || {},
          similar_changes: window.__lastCrSimilar || [],
          quality:         window.__lastCrQuality || {},
        }),
      });

      const ct = resp.headers.get('content-type') || '';
      if (!resp.ok || ct.includes('application/json')) {
        // Server returned an error - try to extract a message
        let msg = 'Excel export failed.';
        try { const j = await resp.json(); msg = j.error || msg; } catch (_) {}
        alert(msg);
        return;
      }

      const blob = await resp.blob();
      const cd   = resp.headers.get('content-disposition') || '';
      const m    = cd.match(/filename="?([^"]+)"?/);
      const name = (m && m[1]) || 'cr_template.xlsx';

      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = name;
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      URL.revokeObjectURL(a.href);
    } catch (err) {
      alert('Network error: ' + err.message);
    } finally {
      btn.disabled = false;
      btn.innerHTML = originalHtml;
    }
  });

  function buildPlainTextTemplate(t) {
    const lines = [
      'CR TEMPLATE',
      '===========',
      'Title: '          + (t.title || ''),
      'Type: '           + (t.type || ''),
      'Planned start: '  + (t.planned_start || ''),
      'Planned end: '    + (t.planned_end || ''),
      'Environment: '    + (t.environment || ''),
      '',
      'Description:',
      t.description || '',
      '',
      'Category: '          + (t.category || ''),
      'Sub-category: '      + (t.subcategory || ''),
      'Business service: '  + (t.business_service || ''),
      'Risk: '              + (t.risk || ''),
      'Priority: '          + (t.priority || ''),
      'Impact: '            + (t.impact || '') + ' - Urgency: ' + (t.urgency || ''),
      'Assignment group: '  + (t.assignment_group || ''),
      '',
      'IMPLEMENTATION PLAN:',
    ];
    (t.implementation_plan || []).forEach((s, i) => lines.push((i + 1) + '. ' + s));
    lines.push('', 'BACKOUT PLAN:');
    (t.backout_plan || []).forEach((s, i) => lines.push((i + 1) + '. ' + s));
    lines.push('', 'TEST PLAN:');
    (t.test_plan || []).forEach((s, i) => lines.push((i + 1) + '. ' + s));
    lines.push('', 'RISK & IMPACT ANALYSIS:',
               t.risk_impact_analysis_with_warnings || t.risk_impact_analysis || '');
    lines.push('',
      '------------------------------------------------------------',
      'Disclaimer: these steps are generated from historical CRs for',
      'reference only. Cross-validate every step before submitting.');
    return lines.join('\n');
  }

}


/* ============================================================
   Similar incident finder page
   Renders both incident matches AND any related Problem tickets
   returned by the same /similar/search endpoint.
   ============================================================ */
function initSimilarPage() {
  const form = document.getElementById('similarForm');
  if (!form) return;

  const elDesc            = document.getElementById('sim_description');
  const elCat             = document.getElementById('sim_category');
  const elPri             = document.getElementById('sim_priority');
  const elTopn            = document.getElementById('sim_topn');
  const elSubmit          = document.getElementById('sim_submit');
  const elStatus          = document.getElementById('sim_status');
  const elResults         = document.getElementById('sim_results');
  const elRec             = document.getElementById('sim_recommendation');

  // Optional Problem section (similar.html may or may not include it)
  const elProblemsSection = document.getElementById('sim_problems_section');
  const elProblemsList    = document.getElementById('sim_problems_list');
  const elProblemsSummary = document.getElementById('sim_problems_summary');
  const elProblemsBand    = document.getElementById('sim_problems_best_band');

  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    elStatus.classList.add('d-none');
    elResults.innerHTML = '';
    elRec.classList.add('d-none');
    if (elProblemsSection) elProblemsSection.classList.add('d-none');

    elSubmit.disabled = true;
    elSubmit.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Searching...</span>';

    try {
      const payload = {
        description: elDesc.value.trim(),
        category:    elCat.value,
        priority:    elPri.value,
        top_n:       parseInt(elTopn.value, 10),
      };
      // FIX: hit the route that actually exists.
      const resp = await fetch('/service-now-analysis/similar/search', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload),
      });

      // Defensive: if the server returned HTML (e.g. an auth redirect)
      // surface a useful error instead of letting JSON.parse blow up.
      const ct = resp.headers.get('content-type') || '';
      if (!ct.includes('application/json')) {
        const text = await resp.text();
        throw new Error('Server returned ' + resp.status + ' (non-JSON). ' +
                        'First 80 chars: ' + text.slice(0, 80));
      }

      const data = await resp.json();
      if (!data.ok) {
        elStatus.className = 'alert alert-warning';
        elStatus.innerHTML = '<i class="fas fa-circle-info"></i> ' +
          escapeHtml(data.error || 'Search failed.');
        elStatus.classList.remove('d-none');
        return;
      }

      const incidents = data.result || {};
      const problems  = data.problems || {status: 'no_models', matches: []};
      renderProblemMatches(problems);
      renderIncidentMatches(incidents);

      // Fetch the synthesised recommendation if we have incident matches
      if (incidents.matches && incidents.matches.length) {
        try {
          const recResp = await fetch('/service-now-analysis/similar/synthesize', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({matches: incidents.matches}),
          });
          if (recResp.headers.get('content-type','').includes('application/json')) {
            const recData = await recResp.json();
            if (recData.ok) renderRecommendation(recData.recommendation);
          }
        } catch (_) { /* recommendation is optional */ }
      }
    } catch (err) {
      elStatus.className = 'alert alert-danger';
      elStatus.innerHTML = '<i class="fas fa-circle-xmark"></i> ' + escapeHtml(err.message);
      elStatus.classList.remove('d-none');
    } finally {
      elSubmit.disabled = false;
      elSubmit.innerHTML = '<i class="fas fa-magnifying-glass"></i><span>Search</span>';
    }
  });

  function renderProblemMatches(problems) {
    if (!elProblemsSection) return;
    if (!problems || problems.status !== 'ok' || !(problems.matches || []).length) {
      elProblemsSection.classList.add('d-none');
      return;
    }
    const matches = problems.matches;
    const bestBand = problems.best_band || matches[0].similarity_band;

    elProblemsBand.dataset.band = bestBand;
    elProblemsBand.textContent = bestBand.toUpperCase() + ' MATCH';
    elProblemsSummary.textContent = matches.length + ' open Problem ticket' +
      (matches.length === 1 ? '' : 's') +
      ' may be related - review before raising a new incident.';

    elProblemsList.innerHTML = '';
    matches.forEach(p => {
      const li = document.createElement('li');
      li.className = 'list-group-item p-3';
      li.innerHTML =
        '<div class="d-flex justify-content-between align-items-start gap-3 mb-2">' +
          '<div class="flex-grow-1">' +
            '<div class="d-flex align-items-center gap-2 flex-wrap mb-1">' +
              '<span class="fw-semibold">' + escSim(p.problem_id) + '</span>' +
              (p.is_known_error ? '<span class="badge bg-warning text-dark">Known error</span>' : '') +
              (p.is_major_problem ? '<span class="badge bg-danger">Major problem</span>' : '') +
              '<span class="snow-quality-pill snow-quality-pill--small" data-band="' +
                  escSim(p.similarity_band) + '">' + p.similarity_score + '% match</span>' +
            '</div>' +
            '<div class="fw-semibold mb-1">' + (p.title_highlighted || escSim(p.title)) + '</div>' +
            '<div class="small text-muted mb-2">' +
              'State: <strong>' + escSim(p.state) + '</strong>' +
              (p.assignment_group ? ' - ' + escSim(p.assignment_group) : '') +
              (p.configuration_item ? ' - CI: ' + escSim(p.configuration_item) : '') +
              (p.priority ? ' - ' + escSim(p.priority) : '') +
            '</div>' +
            (p.description_snippet ?
              '<div class="small mb-2">' + p.description_snippet + '</div>' : '') +
            (p.workaround ?
              '<div class="small mb-1"><strong>Workaround:</strong> ' +
                escSim(p.workaround.slice(0, 300)) +
                (p.workaround.length > 300 ? '...' : '') + '</div>' : '') +
            (p.cause_notes ?
              '<div class="small text-muted"><strong>Cause:</strong> ' +
                escSim(p.cause_notes.slice(0, 250)) +
                (p.cause_notes.length > 250 ? '...' : '') + '</div>' : '') +
          '</div>' +
        '</div>';
      elProblemsList.appendChild(li);
    });
    elProblemsSection.classList.remove('d-none');
  }

  function renderIncidentMatches(result) {
    if (!result || result.status !== 'ok') {
      elStatus.className = 'alert alert-warning';
      elStatus.innerHTML = '<i class="fas fa-circle-info"></i> ' +
        escapeHtml(result && result.message ? result.message : 'No matches found.');
      elStatus.classList.remove('d-none');
      return;
    }
    const matches = result.matches || [];
    const html = matches.map(m =>
      '<div class="card mb-3">' +
        '<div class="card-body p-3">' +
          '<div class="d-flex justify-content-between align-items-start gap-3 mb-2">' +
            '<div class="flex-grow-1">' +
              '<div class="d-flex align-items-center gap-2 mb-1">' +
                '<span class="fw-semibold">' + escSim(m.incident_id) + '</span>' +
                '<span class="snow-quality-pill snow-quality-pill--small" data-band="' +
                    escSim(m.similarity_band) + '">' + m.similarity_score + '%</span>' +
                '<span class="badge bg-light text-dark">' + escSim(m.priority) + '</span>' +
              '</div>' +
              '<div class="fw-semibold mb-1">' + (m.title_highlighted || escSim(m.title)) + '</div>' +
              '<div class="small text-muted mb-2">' +
                escSim(m.category) +
                (m.subcategory ? ' > ' + escSim(m.subcategory) : '') +
                (m.assignment_group ? ' - ' + escSim(m.assignment_group) : '') +
              '</div>' +
              (m.description_snippet ?
                '<div class="small mb-2">' + m.description_snippet + '</div>' : '') +
              (m.resolution_steps && m.resolution_steps.length ?
                '<div class="small"><strong>Resolution:</strong><ul class="mb-0">' +
                  m.resolution_steps.slice(0, 5).map(s => '<li>' + escSim(s) + '</li>').join('') +
                '</ul></div>' : '') +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>'
    ).join('');
    elResults.innerHTML = html;
  }

  function renderRecommendation(rec) {
    if (!rec || !rec.recommended_steps || !rec.recommended_steps.length) return;
    document.getElementById('sim_rec_confidence').textContent = rec.confidence;
    document.getElementById('sim_rec_cause').textContent =
      rec.likely_root_cause || '(not explicit in matches)';
    const stepsEl = document.getElementById('sim_rec_steps');
    stepsEl.innerHTML = '';
    rec.recommended_steps.forEach(s => {
      const li = document.createElement('li');
      li.textContent = s;
      stepsEl.appendChild(li);
    });
    elRec.classList.remove('d-none');
  }

  function escSim(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
}



/* ============================================================
   Summary Report page
   Shares the same SNOW_LAYOUT/colour palette as the ML dashboard.
   ============================================================ */
async function initSummaryPage(sessionId) {
  const loading = document.getElementById("summaryLoading");
  const content = document.getElementById("summaryContent");
  const errBox  = document.getElementById("summaryError");
  const errMsg  = document.getElementById("summaryErrorMsg");

  try {
    const json = await fetchJson(`${SNOW_BASE}/api/summary/${sessionId}`);
    if (!json || !json.data) {
      throw new Error("Server returned an unexpected response shape (no `data` field).");
    }
    const d = json.data;
    // Stash for the optional decorateSummaryReport() call below - used
    // by the "How is this calculated?" tab and the per-section
    // chart/table toggles. Idempotent and safe if the decorator is
    // missing (the decorator function is loaded later in this same
    // file, so under normal circumstances it will be defined).
    window.__snow_summary_data       = d;
    window.__snow_summary_decorated  = false;

    // Each section in its own try/catch so one bad payload can't black
    // out the whole report. Same defensive pattern as the ML dashboard.
    const sections = [
      ["Quality Score",   () => renderSummaryQuality(d.quality_score || {}, d.support_quality || {})],
      ["SLA Trends",      () => renderSummarySla(d.sla_trends || {})],
      ["Resolution Time", () => renderSummaryReso(d.resolution_times || {})],
      ["Priority Trends", () => renderSummaryPri(d.priority_trends || {})],
      ["State Trends",    () => renderSummaryStates(d.state_trends || {})],
      ["Incident Types",  () => renderSummaryTypes(d.incident_types || {})],
      ["Reopened",        () => renderSummaryReopen(d.reopened_incidents || {})],
      ["Long-Open",       () => renderSummaryLongOpen(d.long_open_incidents || {})],
      ["Assignment Groups", () => renderSummaryGroups(d.assignment_groups || {})],
    ];
    const failures = [];
    for (const [name, fn] of sections) {
      try { fn(); } catch (err) {
        console.error(`Section "${name}" failed to render:`, err);
        failures.push(`${name}: ${err.message}`);
      }
    }

    // Inject the calculation tab and chart/table toggles. This lives in
    // a separate IIFE later in the file; calling it here once all the
    // existing sections have rendered ensures every chart container
    // already exists in the DOM.
    if (typeof window.decorateSummaryReport === 'function') {
      try { window.decorateSummaryReport(); }
      catch (err) { console.error('decorateSummaryReport failed:', err); }
    }

    loading.classList.add("d-none");
    content.classList.remove("d-none");

    if (failures.length) {
      errMsg.innerHTML =
        `<strong>Some sections could not be rendered:</strong><ul class="mb-0 mt-1 small">` +
        failures.map(f => `<li>${escapeHtml(f)}</li>`).join("") +
        `</ul>`;
      errBox.classList.remove("d-none");
    }
  } catch (err) {
    loading.classList.add("d-none");
    errMsg.textContent = err.message;
    errBox.classList.remove("d-none");
  }
}

/* --- Section 1: Quality Score (gauge + weight breakdown) --- */
function renderSummaryQuality(q, support) {
  const score  = q.score;
  const rating = q.rating || "-";
  const m      = q.metrics || {};

  // Header pill - colour by rating band
  const pill = document.getElementById("sQualityHeader");
  let tone = "";
  if (rating === "Excellent") tone = "success";
  else if (rating === "Good") tone = "success";
  else if (rating === "Average") tone = "warning";
  else if (rating === "Bad") tone = "danger";
  pill.className = `snow-panel-stat${tone ? " snow-panel-stat--" + tone : ""}`;
  pill.innerHTML = `<i class="fas fa-award"></i> ${escapeHtml(rating)}`;

  document.getElementById("sQualityScore").textContent =
    (typeof score === "number") ? `${fmtNum(score, 1)}` : (score || "-");
  document.getElementById("sQualityRating").textContent = rating;

  document.getElementById("sKpiSla").textContent     = `${fmtNum(m.sla_met_pct, 1)}%`;
  document.getElementById("sKpiResol").textContent   = `${fmtNum(m.avg_resolution_hours, 1)}h`;
  document.getElementById("sKpiReopen").textContent  = `${fmtNum(m.reopen_rate, 1)}%`;
  document.getElementById("sKpiBacklog").textContent = fmtNum(m.open_incidents, 0);
  document.getElementById("sKpiHighPri").textContent = `${fmtNum(m.high_priority_pct, 1)}%`;

  // Horizontal bar chart of contribution by metric
  const w = q.weightages || {};
  const labelMap = {
    sla_met:           "SLA Met",
    resolution_time:   "Resolution Time",
    reopen_rate:       "Reopen Rate",
    incident_backlog:  "Incident Backlog",
    high_priority:     "High Priority %",
    customer_feedback: "Customer Feedback",
  };
  const order = ["sla_met", "resolution_time", "reopen_rate", "incident_backlog", "high_priority", "customer_feedback"];
  const labels   = order.map(k => labelMap[k]);
  const contribs = order.map(k => (w[k] || {}).contribution || 0);
  const weights  = order.map(k => (w[k] || {}).weight || 0);

  Plotly.newPlot("chartWeightBars", [{
    type: "bar", orientation: "h",
    x: contribs, y: labels,
    text: contribs.map((v, i) => `${v} / ${weights[i]}`),
    textposition: "outside",
    textfont: { family: "'DM Sans', sans-serif", size: 11, color: "#1D293D" },
    cliponaxis: false,
    marker: {
      color: contribs.map((v, i) => weights[i] ? (v / weights[i] >= 0.8 ? "#22C55E"
                                          : v / weights[i] >= 0.6 ? "#F59E0B"
                                          : "#DC3545") : "#94A3B8"),
      line: { width: 0 },
    },
    hovertemplate: "<b>%{y}</b><br>Score %{x} of %{customdata}<extra></extra>",
    customdata: weights,
  }], snowLayout({
    margin: { l: 8, r: 50, t: 8, b: 30 },
    xaxis: { title: "Contribution to score" },
    yaxis: { autorange: "reversed" },
    height: 280, bargap: 0.32,
  }), PLOTLY_CFG);
}

/* --- Section 2: SLA Trends --- */
function renderSummarySla(p) {
  const rows = p.chart_data || [];
  const pill = document.getElementById("sSlaHeader");
  if (!rows.length) {
    pill.className = "snow-panel-stat";
    pill.innerHTML = '<i class="fas fa-circle-info"></i> No data';
    document.getElementById("chartSlaTrend").innerHTML =
      '<div class="text-center text-muted py-5">No SLA data available.</div>';
    return;
  }
  const months = rows.map(r => r.month);
  const met    = rows.map(r => r.sla_met);
  const breach = rows.map(r => r.sla_breach);
  const pct    = rows.map(r => r.sla_met_pct);

  const latest = pct[pct.length - 1] || 0;
  const tone = latest >= 90 ? "success" : latest >= 75 ? "warning" : "danger";
  pill.className = `snow-panel-stat snow-panel-stat--${tone}`;
  pill.innerHTML = `<i class="fas fa-bullseye"></i> Latest ${fmtNum(latest, 1)}% met`;

  Plotly.newPlot("chartSlaTrend", [
    { type: "bar", name: "SLA Met",    x: months, y: met,    marker: { color: "#22C55E", line: { width: 0 } } },
    { type: "bar", name: "SLA Breach", x: months, y: breach, marker: { color: "#DC3545", line: { width: 0 } } },
    { type: "scatter", mode: "lines+markers", name: "SLA Met %",
      x: months, y: pct, yaxis: "y2",
      line: { color: "#1D293D", width: 3 }, marker: { size: 8, color: "#1D293D" } },
  ], snowLayout({
    margin: { l: 8, r: 8, t: 36, b: 8 },
    barmode: "stack",
    xaxis: { title: "Month" },
    yaxis: { title: "Tickets" },
    yaxis2: {
      title: "SLA Met %", overlaying: "y", side: "right",
      range: [0, 105], gridcolor: "transparent",
      tickfont: { size: 11, color: "#6B7280" },
      titlefont: { size: 11, color: "#6B7280" },
    },
    legend: { orientation: "h", y: 1.14, x: 0, xanchor: "left",
              font: { size: 11, color: "#374151" } },
    height: 380, bargap: 0.3,
  }), PLOTLY_CFG);
}

/* --- Section 3: Resolution Time histogram --- */
function renderSummaryReso(p) {
  const rows = p.chart_data || [];
  const stats = p.stats || {};
  const pill = document.getElementById("sResoHeader");
  pill.className = "snow-panel-stat";
  pill.innerHTML =
    `<i class="fas fa-clock"></i> Median ${fmtNum(stats.median_hours, 1)}h ` +
    `<span class="snow-stat-divider"></span> Mean ${fmtNum(stats.mean_hours, 1)}h`;

  if (!rows.length) {
    document.getElementById("chartResoBars").innerHTML =
      '<div class="text-center text-muted py-5">No resolution-time data.</div>';
    return;
  }
  Plotly.newPlot("chartResoBars", [{
    type: "bar",
    x: rows.map(r => r.bin),
    y: rows.map(r => r.count),
    text: rows.map(r => `${r.percentage}%`),
    textposition: "outside",
    textfont: { family: "'DM Sans', sans-serif", size: 11, color: "#1D293D" },
    cliponaxis: false,
    marker: {
      color: rows.map((_, i) => SNOW_CATEGORICAL[i % SNOW_CATEGORICAL.length]),
      line: { width: 0 },
    },
    hovertemplate: "<b>%{x}</b><br>%{y} tickets - %{text}<extra></extra>",
  }], snowLayout({
    margin: { l: 8, r: 8, t: 16, b: 8 },
    yaxis: { title: "Tickets" },
    height: 320, bargap: 0.3,
  }), PLOTLY_CFG);
}

/* --- Section 4: Priority Trends --- */
function renderSummaryPri(p) {
  const rows = p.chart_data || [];
  const pill = document.getElementById("sPriHeader");
  if (!rows.length) {
    pill.className = "snow-panel-stat";
    pill.innerHTML = '<i class="fas fa-circle-info"></i> No data';
    document.getElementById("chartPriTrend").innerHTML =
      '<div class="text-center text-muted py-5">No priority data.</div>';
    return;
  }
  const months = rows.map(r => r.month);
  const totalLatest = (rows[rows.length - 1].p1 || 0) + (rows[rows.length - 1].p2 || 0);
  pill.className = "snow-panel-stat";
  pill.innerHTML = `<i class="fas fa-flag"></i> ${rows.length} months tracked`;

  const traces = ["P1", "P2", "P3", "P4"].map(pri => ({
    type: "bar", name: pri,
    x: months,
    y: rows.map(r => r[pri.toLowerCase()] || 0),
    marker: { color: PRIORITY_COLOR[pri], line: { width: 0 } },
  }));
  Plotly.newPlot("chartPriTrend", traces, snowLayout({
    margin: { l: 8, r: 8, t: 36, b: 8 },
    barmode: "stack",
    xaxis: { title: "Month" },
    yaxis: { title: "Tickets" },
    legend: { orientation: "h", y: 1.14, x: 0, xanchor: "left",
              font: { size: 11, color: "#374151" } },
    height: 320, bargap: 0.3,
  }), PLOTLY_CFG);
}

/* --- Section 5: State trends --- */
function renderSummaryStates(p) {
  const rows = p.chart_data || [];
  const pill = document.getElementById("sStateHeader");
  if (!rows.length) {
    pill.className = "snow-panel-stat";
    pill.innerHTML = '<i class="fas fa-circle-info"></i> No data';
    document.getElementById("chartStateTrend").innerHTML =
      '<div class="text-center text-muted py-5">No state data.</div>';
    return;
  }
  // Discover state-name keys (everything except 'month')
  const stateKeys = Object.keys(rows[0]).filter(k => k !== "month");
  const months = rows.map(r => r.month);
  pill.className = "snow-panel-stat";
  pill.innerHTML = `<i class="fas fa-bars-progress"></i> ${stateKeys.length} states`;

  const traces = stateKeys.map((k, i) => ({
    type: "bar", name: k.replace(/_/g, " "),
    x: months,
    y: rows.map(r => r[k] || 0),
    marker: { color: SNOW_CATEGORICAL[i % SNOW_CATEGORICAL.length], line: { width: 0 } },
  }));
  Plotly.newPlot("chartStateTrend", traces, snowLayout({
    margin: { l: 8, r: 8, t: 36, b: 8 },
    barmode: "stack",
    xaxis: { title: "Month" },
    yaxis: { title: "Tickets" },
    legend: { orientation: "h", y: 1.14, x: 0, xanchor: "left",
              font: { size: 11, color: "#374151" } },
    height: 320, bargap: 0.3,
  }), PLOTLY_CFG);
}

/* --- Section 6: Incident types pie --- */
function renderSummaryTypes(p) {
  const rows = p.chart_data || [];
  const pill = document.getElementById("sTypesHeader");
  if (!rows.length) {
    pill.className = "snow-panel-stat";
    pill.innerHTML = '<i class="fas fa-circle-info"></i> No data';
    document.getElementById("chartTypes").innerHTML =
      '<div class="text-center text-muted py-5">No category data.</div>';
    return;
  }
  pill.className = "snow-panel-stat";
  pill.innerHTML = `<i class="fas fa-tags"></i> Top ${rows.length} categories`;

  Plotly.newPlot("chartTypes", [{
    type: "pie", hole: 0.55,
    labels: rows.map(r => r.type),
    values: rows.map(r => r.count),
    textinfo: "label+percent",
    textfont: { size: 11, color: "#fff", family: "'DM Sans', sans-serif" },
    marker: {
      colors: rows.map((_, i) => SNOW_CATEGORICAL[i % SNOW_CATEGORICAL.length]),
      line: { color: "#fff", width: 2 },
    },
    hovertemplate: "<b>%{label}</b><br>%{value} tickets - %{percent}<extra></extra>",
  }], snowLayout({
    margin: { l: 8, r: 8, t: 8, b: 8 },
    height: 320, showlegend: false,
  }), PLOTLY_CFG);
}

/* --- Section 7: Reopened distribution --- */
function renderSummaryReopen(p) {
  const rows = p.chart_data || [];
  const stats = p.stats || {};
  const pill = document.getElementById("sReopenHeader");
  const rate = Number(stats.reopen_rate) || 0;
  const tone = rate <= 2 ? "success" : rate <= 10 ? "warning" : "danger";
  pill.className = `snow-panel-stat snow-panel-stat--${tone}`;
  pill.innerHTML = `<i class="fas fa-rotate-left"></i> ${rate}% reopen rate`;

  document.getElementById("sReopenCount").textContent = fmtNum(stats.reopened_incidents, 0);
  document.getElementById("sReopenRate").textContent  = `${rate}%`;
  document.getElementById("sReopenAvg").textContent   = fmtNum(stats.avg_reopens, 1);

  if (!rows.length) {
    document.getElementById("chartReopen").innerHTML =
      '<div class="text-center text-muted py-4"><i class="fas fa-circle-check fa-2x mb-2 d-block"></i>No reopened incidents - nice!</div>';
    return;
  }
  Plotly.newPlot("chartReopen", [{
    type: "bar",
    x: rows.map(r => `${r.reopen_count}x`),
    y: rows.map(r => r.incident_count),
    text: rows.map(r => `${r.percentage}%`),
    textposition: "outside",
    textfont: { family: "'DM Sans', sans-serif", size: 11, color: "#1D293D" },
    cliponaxis: false,
    marker: {
      color: rows.map(r => r.reopen_count >= 3 ? "#DC3545" : r.reopen_count === 2 ? "#F59E0B" : "#FBBF24"),
      line: { width: 0 },
    },
    hovertemplate: "<b>Reopened %{x}</b><br>%{y} incidents - %{text}<extra></extra>",
  }], snowLayout({
    margin: { l: 8, r: 8, t: 16, b: 8 },
    xaxis: { title: "Times reopened" },
    yaxis: { title: "Incidents" },
    height: 260, bargap: 0.4,
  }), PLOTLY_CFG);
}

/* --- Section 8: Long-open age bands --- */
function renderSummaryLongOpen(p) {
  const rows = p.chart_data || [];
  const stats = p.stats || {};
  const pill = document.getElementById("sLongOpenHeader");
  const over30 = Number(stats.over_30_days) || 0;
  const tone = over30 === 0 ? "success" : over30 > 50 ? "danger" : "warning";
  pill.className = `snow-panel-stat snow-panel-stat--${tone}`;
  pill.innerHTML = `<i class="fas fa-hourglass-half"></i> ${over30} open > 30 days`;

  document.getElementById("sOpenTotal").textContent   = fmtNum(stats.total_open, 0);
  document.getElementById("sOpenAvgDays").textContent = fmtNum(stats.avg_days_open, 1);
  document.getElementById("sOpenOver30").textContent  = fmtNum(stats.over_30_days, 0);

  if (!rows.length) {
    document.getElementById("chartLongOpen").innerHTML =
      '<div class="text-center text-muted py-4"><i class="fas fa-circle-check fa-2x mb-2 d-block"></i>No open backlog.</div>';
    return;
  }
  // Sequential ramp - older = redder
  const colours = ["#FBBF24", "#F59E0B", "#FB923C", "#EF4444", "#991B1B"];
  Plotly.newPlot("chartLongOpen", [{
    type: "bar",
    x: rows.map(r => r.bin),
    y: rows.map(r => r.count),
    text: rows.map(r => `${r.percentage}%`),
    textposition: "outside",
    textfont: { family: "'DM Sans', sans-serif", size: 11, color: "#1D293D" },
    cliponaxis: false,
    marker: { color: rows.map((_, i) => colours[i % colours.length]), line: { width: 0 } },
    hovertemplate: "<b>%{x}</b><br>%{y} incidents - %{text}<extra></extra>",
  }], snowLayout({
    margin: { l: 8, r: 8, t: 16, b: 8 },
    xaxis: { title: "Age band" },
    yaxis: { title: "Open tickets" },
    height: 260, bargap: 0.3,
  }), PLOTLY_CFG);
}

/* --- Section 9: Assignment group analysis ---
   Three views of the same payload:
     1. Workload vs speed - volume bars against a median-resolution line,
        so a team that is busy AND slow separates from one that is merely
        busy.
     2. Request-type mix - what each group's volume is actually made of.
     3. Per-group detail - every type with the time that team took on it.
   A value the server could not state honestly (an SLA % with no SLA
   field, an average with nothing resolved) arrives as null and is
   rendered "n/a" rather than as a zero. */
function renderSummaryGroups(p) {
  const pill = document.getElementById("sGroupsHeader");
  const note = document.getElementById("sGroupsNote");
  const body = document.getElementById("sGroupsBody");
  const gone = document.getElementById("sGroupsUnavailable");

  if (!p || !p.available) {
    pill.className = "snow-panel-stat";
    pill.innerHTML = '<i class="fas fa-circle-info"></i> Not available';
    gone.classList.remove("d-none");
    gone.innerHTML =
      '<i class="fas fa-people-group fa-2x mb-2 d-block"></i>' +
      escapeHtml(p && p.reason ? p.reason :
                 "No assignment-group data in this upload.");
    return;
  }

  const groups = p.groups || [];
  const totals = p.totals || {};
  const cls    = p.classification || {};

  pill.className = "snow-panel-stat";
  pill.innerHTML = `<i class="fas fa-people-group"></i> ${groups.length} groups`;
  body.classList.remove("d-none");

  // Caveats that travel with the numbers: where the group labels came
  // from, what the SLA column is based on, how the types were named.
  const notes = [];
  if (p.group_source_label) notes.push(p.group_source_label);
  if (cls.method_label) notes.push(cls.method_label);
  if (!p.sla_basis) {
    notes.push("SLA met % is shown as n/a: this export carried no SLA field " +
               "and no resolved timestamp to recompute one.");
  }
  if (cls.unclassified) {
    notes.push(`${cls.unclassified} tickets (${cls.unclassified_pct}%) could ` +
               `not be named by either stage and are counted as Unclassified ` +
               `rather than folded into a real type.`);
  }
  if (notes.length) {
    note.classList.remove("d-none");
    document.getElementById("sGroupsNoteBody").innerHTML =
      notes.map(n => `<div>${escapeHtml(n)}</div>`).join("");
  }

  const distinctTypes = new Set();
  groups.forEach(g => (g.request_types || []).forEach(t =>
    distinctTypes.add(t.type)));

  const na = v => (v === null || v === undefined) ? "n/a" : fmtNum(v, 1);
  document.getElementById("sGrpKpiGroups").textContent  = fmtNum(totals.groups, 0);
  document.getElementById("sGrpKpiTypes").textContent   = distinctTypes.size;
  document.getElementById("sGrpKpiAvg").textContent     =
    totals.avg_resolution_hours === null ? "n/a" : na(totals.avg_resolution_hours) + "h";
  document.getElementById("sGrpKpiMedian").textContent  =
    totals.median_resolution_hours === null ? "n/a" : na(totals.median_resolution_hours) + "h";
  document.getElementById("sGrpKpiSla").textContent     =
    totals.sla_met_pct === null ? "n/a" : na(totals.sla_met_pct) + "%";
  document.getElementById("sGrpKpiBacklog").textContent = fmtNum(totals.ageing_backlog, 0);

  renderGroupWorkloadChart(p.chart_data || [], p);
  renderGroupTypeChart(groups);
  renderGroupDetail(groups, p);
}

function renderGroupWorkloadChart(rows, p) {
  const host = document.getElementById("chartGroupWorkload");
  if (!rows.length) {
    host.innerHTML = '<div class="text-center text-muted py-5">No groups to chart.</div>';
    return;
  }
  const labels = rows.map(r => r.group);
  Plotly.newPlot("chartGroupWorkload", [
    {
      type: "bar", name: "Resolved",
      x: labels, y: rows.map(r => r.resolved),
      marker: { color: "#1D293D", line: { width: 0 } },
      hovertemplate: "<b>%{x}</b><br>%{y} resolved<extra></extra>",
    },
    {
      type: "bar", name: "Still open",
      x: labels, y: rows.map(r => r.open),
      marker: { color: "#F59E0B", line: { width: 0 } },
      hovertemplate: "<b>%{x}</b><br>%{y} still open<extra></extra>",
    },
    {
      type: "scatter", mode: "lines+markers", name: "Median resolution (h)",
      x: labels, y: rows.map(r => r.median_resolution_hours),
      yaxis: "y2",
      connectgaps: false,
      line: { color: "#AB1236", width: 2.5 },
      marker: { size: 8, color: "#AB1236" },
      hovertemplate: "<b>%{x}</b><br>median %{y}h<extra></extra>",
    },
  ], snowLayout({
    barmode: "stack",
    margin: { l: 8, r: 8, t: 16, b: 8 },
    xaxis: { title: "Assignment group", tickangle: -25, automargin: true },
    yaxis: { title: "Tickets", automargin: true },
    yaxis2: {
      title: "Median resolution (hours)", overlaying: "y", side: "right",
      showgrid: false, rangemode: "tozero", automargin: true,
    },
    legend: { orientation: "h", y: 1.14, x: 0, xanchor: "left",
              font: { size: 11, color: "#374151" } },
    height: 380, bargap: 0.3,
  }), PLOTLY_CFG);
}

function renderGroupTypeChart(groups) {
  const host = document.getElementById("chartGroupTypes");
  const top = groups.slice(0, 10);
  if (!top.length) {
    host.innerHTML = '<div class="text-center text-muted py-5">No request types to chart.</div>';
    return;
  }
  // One trace per request type, so each group's bar reads as its mix.
  // Types are ordered by total volume across the estate, which keeps the
  // legend and the stack order stable between groups.
  const totals = {};
  top.forEach(g => (g.request_types || []).forEach(t => {
    totals[t.type] = (totals[t.type] || 0) + t.count;
  }));
  const ordered = Object.keys(totals).sort((a, b) => totals[b] - totals[a]);

  // Reversed so the largest group renders at the TOP of a horizontal chart.
  const labels = top.map(g => g.group).reverse();
  const traces = ordered.map((type, i) => ({
    type: "bar", orientation: "h", name: type,
    y: labels,
    x: top.slice().reverse().map(g => {
      const hit = (g.request_types || []).find(t => t.type === type);
      return hit ? hit.count : 0;
    }),
    marker: { color: snowCycleColor(i), line: { width: 0 } },
    hovertemplate: `<b>%{y}</b><br>${escapeHtml(type)}: %{x} tickets<extra></extra>`,
  }));

  Plotly.newPlot("chartGroupTypes", traces, snowLayout({
    barmode: "stack",
    margin: { l: 8, r: 8, t: 16, b: 8 },
    xaxis: { title: "Tickets" },
    yaxis: { automargin: true },
    legend: { orientation: "h", y: -0.18, x: 0, xanchor: "left",
              font: { size: 11, color: "#374151" } },
    height: Math.max(420, 60 + top.length * 42),
    bargap: 0.35,
  }), PLOTLY_CFG);
}

function renderGroupDetail(groups, p) {
  const host = document.getElementById("sGroupsDetail");
  host.innerHTML = "";
  const na = v => (v === null || v === undefined) ? "n/a" : fmtNum(v, 1);

  groups.forEach((g, index) => {
    const box = document.createElement("details");
    box.className = "snow-group-card";
    if (index === 0) box.open = true;

    const thin = g.thin_sample
      ? `<span class="snow-group-flag" title="Fewer than ${p.thin_sample_below} tickets - the averages below are not a performance result.">thin sample</span>`
      : "";

    const summary = document.createElement("summary");
    summary.className = "snow-group-summary";
    summary.innerHTML =
      `<span class="snow-group-name">${escapeHtml(g.group)}${thin}</span>` +
      `<span class="snow-group-stats">` +
        `<span><strong>${fmtNum(g.total, 0)}</strong> tickets</span>` +
        `<span><strong>${fmtNum(g.open, 0)}</strong> open</span>` +
        `<span>avg <strong>${na(g.avg_resolution_hours)}</strong>h</span>` +
        `<span>median <strong>${na(g.median_resolution_hours)}</strong>h</span>` +
        `<span>SLA <strong>${g.sla_met_pct === null ? "n/a" : na(g.sla_met_pct) + "%"}</strong></span>` +
      `</span>`;
    box.appendChild(summary);

    const wrap = document.createElement("div");
    wrap.className = "snow-section-table-scroll";
    const rows = g.request_types || [];
    wrap.innerHTML =
      '<table class="snow-section-table-data"><thead><tr>' +
      ["Request type", "Tickets", "Share", "Resolved", "Open",
       "Avg (h)", "Median (h)", "P90 (h)", "Longest (h)",
       "Total effort (h)", "SLA met", "Labelled by"]
        .map(h => `<th>${h}</th>`).join("") +
      '</tr></thead><tbody>' +
      rows.map(t =>
        "<tr>" +
        `<td><strong>${escapeHtml(t.type)}</strong></td>` +
        `<td>${fmtNum(t.count, 0)}</td>` +
        `<td>${na(t.share_pct)}%</td>` +
        `<td>${fmtNum(t.resolved, 0)}</td>` +
        `<td>${fmtNum(t.open, 0)}</td>` +
        `<td>${na(t.avg_hours)}</td>` +
        `<td>${na(t.median_hours)}</td>` +
        `<td>${na(t.p90_hours)}</td>` +
        `<td>${na(t.max_hours)}</td>` +
        `<td>${na(t.total_hours)}</td>` +
        `<td>${t.sla_met_pct === null ? "n/a" : na(t.sla_met_pct) + "%"}</td>` +
        `<td><span class="snow-group-flag snow-group-flag--${escapeHtml(t.label_source)}">` +
          `${t.label_source === "model" ? "clustered" : t.label_source === "rule" ? "rule" : "unnamed"}` +
        `</span></td>` +
        "</tr>").join("") +
      '</tbody></table>';
    box.appendChild(wrap);
    host.appendChild(box);
  });
}


/* ============================================================
   Plotly responsive resize handler - fixes Auto-Resolve donut
   overlap when bootstrap stacks columns at lg/xl breakpoints.
   Plotly's responsive:true only handles a subset of resize
   events; this debounced window-resize callback explicitly
   invokes Plotly.Plots.resize() on every dashboard chart, so
   the chart canvas always re-fits to its container.
   ============================================================ */
(function () {
  if (typeof Plotly === 'undefined') return;
  const chartIds = [
    'chartCategoryDist', 'chartSlaScatter',
    'chartEtaByPriority', 'chartEtaByTeam',
    'chartChronicBar', 'chartWorkload',
    'chartAutoResolveDonut',
    'chartWeightBars', 'chartSlaTrend', 'chartResoBars',
    'chartPriTrend', 'chartStateTrend', 'chartTypes',
    'chartReopen', 'chartLongOpen',
    'chartGroupWorkload', 'chartGroupTypes',
  ];
  let t = null;
  window.addEventListener('resize', function () {
    if (t) clearTimeout(t);
    t = setTimeout(function () {
      chartIds.forEach(function (id) {
        const el = document.getElementById(id);
        if (el && el.classList.contains('js-plotly-plot')) {
          try { Plotly.Plots.resize(el); } catch (e) { /* ignore */ }
        }
      });
    }, 120);
  });
})();

/* ============================================================================
   SUMMARY REPORT - calculation tab + chart/table toggles
   ----------------------------------------------------------------------------
   Append this whole block to the END of snow.js.

   THIS FILE adds two features:

   1.  Section 1 (Weighted contribution by metric) gets a tab strip:
         [ Chart ]  [ How is this calculated? ]
       The second tab shows a per-metric breakdown of formula, weight,
       bands, and source column - read straight from the new
       `calculation_breakdown` field on the server response.

   2.  Sections 2-8 each get a small toggle:
         [ Chart ]  [ Table ]
       Chart view is unchanged. Table view renders a per-incident table
       with a search box and per-column filter dropdowns, populated from
       the new `incident_rows` field on each section's server response.

   IMPLEMENTATION NOTES
   --------------------
   - No changes are needed to summary.html. The toggle controls and
     hidden table containers are injected at runtime next to each
     existing chart container.
   - One small edit to initSummaryPage (above) is needed so it stashes
     the response payload on window.__snow_summary_data - see the
     PATCH section at the very bottom of this file. Without that one
     line, the toggles still appear but the table view will be empty.
   ============================================================================ */

(function () {
  'use strict';

  // Map server response keys -> existing chart container IDs.
  // The decoration logic uses the chart id to locate its panel root,
  // injects the toggle, and creates a sibling table container.
  const SECTION_DEFS = [
    {
      key:      'sla_trends',
      chartId:  'chartSlaTrend',
      headers: [
        { field: 'incident_id',      label: 'Incident' },
        { field: 'opened_at',        label: 'Opened' },
        { field: 'priority',         label: 'Priority' },
        { field: 'sla_target_hours', label: 'SLA Target (h)' },
        { field: 'resolution_hours', label: 'Resolution (h)' },
        { field: 'sla_met',          label: 'SLA Met' },
      ],
      filterCols: ['priority', 'sla_met'],
    },
    {
      key:      'resolution_times',
      chartId:  'chartResoBars',
      headers: [
        { field: 'incident_id',      label: 'Incident' },
        { field: 'resolution_hours', label: 'Hours' },
        { field: 'time_range',       label: 'Bucket' },
        { field: 'priority',         label: 'Priority' },
        { field: 'category',         label: 'Category' },
        { field: 'opened_at',        label: 'Opened' },
      ],
      filterCols: ['time_range', 'priority', 'category'],
    },
    {
      key:      'priority_trends',
      chartId:  'chartPriTrend',
      headers: [
        { field: 'incident_id', label: 'Incident' },
        { field: 'priority',    label: 'Priority' },
        { field: 'opened_at',   label: 'Opened' },
        { field: 'category',    label: 'Category' },
        { field: 'state',       label: 'State' },
      ],
      filterCols: ['priority', 'category', 'state'],
    },
    {
      key:      'state_trends',
      chartId:  'chartStateTrend',
      headers: [
        { field: 'incident_id',      label: 'Incident' },
        { field: 'state',            label: 'State' },
        { field: 'opened_at',        label: 'Opened' },
        { field: 'priority',         label: 'Priority' },
        { field: 'assignment_group', label: 'Assignment' },
      ],
      filterCols: ['state', 'priority', 'assignment_group'],
    },
    {
      key:      'incident_types',
      chartId:  'chartTypes',
      headers: [
        { field: 'incident_id', label: 'Incident' },
        { field: 'category',    label: 'Category' },
        { field: 'subcategory', label: 'Sub-category' },
        { field: 'priority',    label: 'Priority' },
        { field: 'state',       label: 'State' },
        { field: 'opened_at',   label: 'Opened' },
      ],
      filterCols: ['category', 'priority', 'state'],
    },
    {
      key:      'reopened_incidents',
      chartId:  'chartReopen',
      headers: [
        { field: 'incident_id',    label: 'Incident' },
        { field: 'times_reopened', label: 'Reopened' },
        { field: 'reopen_count',   label: '#' },
        { field: 'priority',       label: 'Priority' },
        { field: 'category',       label: 'Category' },
        { field: 'state',          label: 'State' },
        { field: 'opened_at',      label: 'Opened' },
      ],
      filterCols: ['times_reopened', 'priority', 'state'],
    },
    {
      key:      'long_open_incidents',
      chartId:  'chartLongOpen',
      headers: [
        { field: 'incident_id',      label: 'Incident' },
        { field: 'days_open',        label: 'Days Open' },
        { field: 'age_band',         label: 'Age Band' },
        { field: 'state',            label: 'State' },
        { field: 'priority',         label: 'Priority' },
        { field: 'assignment_group', label: 'Assignment' },
        { field: 'opened_at',        label: 'Opened' },
      ],
      filterCols: ['age_band', 'state', 'priority', 'assignment_group'],
    },
    {
      key:      'assignment_groups',
      chartId:  'chartGroupWorkload',
      headers: [
        { field: 'incident_id',      label: 'Incident' },
        { field: 'assignment_group', label: 'Assignment Group' },
        { field: 'request_type',     label: 'Request Type' },
        { field: 'labelled_by',      label: 'Labelled By' },
        { field: 'priority',         label: 'Priority' },
        { field: 'state',            label: 'State' },
        { field: 'resolution_hours', label: 'Resolution (h)' },
        { field: 'sla_met',          label: 'SLA Met' },
        { field: 'opened_at',        label: 'Opened' },
      ],
      filterCols: ['assignment_group', 'request_type', 'labelled_by',
                   'priority', 'state'],
    },
  ];

  // Public entry: called from initSummaryPage after rendering completes.
  // Idempotent - calling twice is safe (returns immediately the second time).
  window.decorateSummaryReport = function () {
    const data = window.__snow_summary_data;
    if (!data) return;
    if (window.__snow_summary_decorated) return;
    window.__snow_summary_decorated = true;

    // Section 1 - calculation tab
    const cb = (data.quality_score || {}).calculation_breakdown || [];
    if (cb.length) decorateCalculationTab(cb);

    // Sections 2-8 - toggle + table
    SECTION_DEFS.forEach(def => {
      const rows = ((data[def.key]) || {}).incident_rows || [];
      decorateSectionToggle(def, rows);
    });
  };

  // Section 1 - calculation breakdown tab next to the contribution chart
  function decorateCalculationTab(rows) {
    const chart = document.getElementById('chartWeightBars');
    if (!chart || chart.parentElement.querySelector('.snow-tabbed-tabs')) return;

    const host = chart.parentElement; // the <div class="col-12"> wrapper
    // Wrap chart in a chart-pane div, add tabs above
    const tabs = document.createElement('div');
    tabs.className = 'snow-tabbed-tabs';
    tabs.innerHTML =
      '<button type="button" class="snow-tabbed-tab is-active" data-pane="chart">Chart</button>' +
      '<button type="button" class="snow-tabbed-tab" data-pane="calc">How is this calculated?</button>';
    host.insertBefore(tabs, chart);

    // Pane wrapping: original chart becomes one pane; calc gets a new sibling
    const chartPane = document.createElement('div');
    chartPane.className = 'snow-tabbed-pane';
    chartPane.dataset.pane = 'chart';
    host.insertBefore(chartPane, chart);
    chartPane.appendChild(chart);

    const calcPane = document.createElement('div');
    calcPane.className = 'snow-tabbed-pane is-hidden';
    calcPane.dataset.pane = 'calc';
    host.appendChild(calcPane);

    rows.forEach(r => calcPane.appendChild(buildCalcRow(r)));

    // Tab click handler
    tabs.addEventListener('click', e => {
      const btn = e.target.closest('.snow-tabbed-tab');
      if (!btn) return;
      const pane = btn.dataset.pane;
      tabs.querySelectorAll('.snow-tabbed-tab').forEach(b =>
        b.classList.toggle('is-active', b === btn));
      host.querySelectorAll('.snow-tabbed-pane').forEach(p =>
        p.classList.toggle('is-hidden', p.dataset.pane !== pane));
      // Force chart resize when switching back so it redraws cleanly
      if (pane === 'chart' && typeof Plotly !== 'undefined') {
        try { Plotly.Plots.resize(chart); } catch (_) {}
      }
    });
  }

  function buildCalcRow(r) {
    const wrap = document.createElement('div');
    wrap.className = 'snow-calc-row';
    let bandsHtml = '';
    if (Array.isArray(r.bands) && r.bands.length) {
      bandsHtml = '<table class="snow-calc-bands"><tbody>' +
        r.bands.map(b => {
          if ('signal' in b) {
            return '<tr>' +
              '<td class="snow-calc-band-cond">' + esc(b.signal) + '</td>' +
              '<td class="snow-calc-band-rule">' + esc(b.rule || '') + '</td>' +
              '<td class="snow-calc-band-score">weight ' + esc(String(b.weight)) + '%</td>' +
              '</tr>';
          }
          return '<tr>' +
            '<td class="snow-calc-band-cond">' + esc(b.if) + '</td>' +
            '<td class="snow-calc-band-rule"></td>' +
            '<td class="snow-calc-band-score">-> ' + esc(String(b.score)) + '</td>' +
            '</tr>';
        }).join('') +
        '</tbody></table>';
    }
    wrap.innerHTML =
      '<div class="snow-calc-row-head">' +
        '<div class="snow-calc-metric">' + esc(r.metric) + '</div>' +
        '<div class="snow-calc-weight">Weight ' + esc(String(r.weight)) + '%</div>' +
      '</div>' +
      '<div class="snow-calc-formula">' + esc(r.formula) + '</div>' +
      bandsHtml +
      '<div class="snow-calc-source">Source: <code>' + esc(r.source_column || '-') + '</code>' +
        (r.is_proxy ? ' <span class="badge bg-info text-dark ms-1">proxy</span>' : '') +
      '</div>';
    return wrap;
  }

  // Sections 2-8 - Chart / Table toggle injected next to existing chart
  function decorateSectionToggle(def, rows) {
    const chart = document.getElementById(def.chartId);
    if (!chart) return;
    if (chart.parentElement.querySelector('.snow-section-toggle')) return; // already done

    const host = chart.parentElement;

    // Toggle bar
    const toggle = document.createElement('div');
    toggle.className = 'snow-section-toggle mb-3';
    toggle.innerHTML =
      '<button type="button" class="is-active" data-view="chart"><i class="fas fa-chart-column"></i> Chart</button>' +
      '<button type="button" data-view="table"' + (rows.length ? '' : ' disabled') + '>' +
        '<i class="fas fa-table"></i> Table' +
        '<span class="snow-section-toggle-count">' + (rows.length ? rows.length : '') + '</span>' +
      '</button>';
    host.insertBefore(toggle, chart);

    // Table container - hidden until first switch
    const tableHost = document.createElement('div');
    tableHost.className = 'snow-section-table d-none';
    chart.parentElement.insertBefore(tableHost, chart.nextSibling);

    // No rows? Tooltip on disabled button explains why
    if (!rows.length) {
      toggle.querySelector('[data-view="table"]').title =
        'No incident-level rows available for this section.';
    }

    let tableBuilt = false;
    toggle.addEventListener('click', e => {
      const btn = e.target.closest('button[data-view]');
      if (!btn || btn.disabled) return;
      const view = btn.dataset.view;
      toggle.querySelectorAll('button[data-view]').forEach(b =>
        b.classList.toggle('is-active', b === btn));

      if (view === 'table') {
        if (!tableBuilt) {
          buildIncidentTable(tableHost, def, rows);
          tableBuilt = true;
        }
        chart.classList.add('d-none');
        tableHost.classList.remove('d-none');
      } else {
        tableHost.classList.add('d-none');
        chart.classList.remove('d-none');
        if (typeof Plotly !== 'undefined') {
          try { Plotly.Plots.resize(chart); } catch (_) {}
        }
      }
    });
  }

  function buildIncidentTable(container, def, rows) {
    container.innerHTML = '';

    // Controls row: search + per-column filters + result count
    const controls = document.createElement('div');
    controls.className = 'snow-table-controls';

    const searchWrap = document.createElement('div');
    searchWrap.className = 'snow-table-search';
    searchWrap.innerHTML = '<i class="fas fa-magnifying-glass"></i>';
    const searchInput = document.createElement('input');
    searchInput.type = 'search';
    searchInput.className = 'form-control form-control-sm';
    searchInput.placeholder = 'Search across all columns...';
    searchWrap.appendChild(searchInput);
    controls.appendChild(searchWrap);

    const filterSelects = {};
    (def.filterCols || []).forEach(col => {
      const distinct = Array.from(new Set(
        rows.map(r => String(r[col] || '')).filter(Boolean)
      )).sort();
      if (distinct.length < 2) return;
      const sel = document.createElement('select');
      sel.className = 'form-select form-select-sm';
      const colLabel = col.replace(/_/g, ' ');
      sel.innerHTML =
        '<option value="">All ' + esc(colLabel) + '</option>' +
        distinct.map(v => '<option>' + esc(v) + '</option>').join('');
      controls.appendChild(sel);
      filterSelects[col] = sel;
    });

    const meta = document.createElement('div');
    meta.className = 'snow-table-meta ms-auto';
    controls.appendChild(meta);
    container.appendChild(controls);

    // Scrollable table region
    const wrap = document.createElement('div');
    wrap.className = 'snow-section-table-scroll';
    const tbl = document.createElement('table');
    tbl.className = 'snow-section-table-data';
    tbl.innerHTML =
      '<thead><tr>' +
      def.headers.map(h =>
        '<th data-field="' + esc(h.field) + '">' + esc(h.label) + '</th>'
      ).join('') +
      '</tr></thead><tbody></tbody>';
    wrap.appendChild(tbl);
    container.appendChild(wrap);

    const tbody = tbl.querySelector('tbody');
    const PAGE = 200;
    let renderedCount = 0;
    let currentFiltered = [];
    let observer = null;

    function passesFilters(row) {
      const q = (searchInput.value || '').toLowerCase().trim();
      if (q) {
        const hay = def.headers
          .map(h => String(row[h.field] || ''))
          .join(' ').toLowerCase();
        if (hay.indexOf(q) < 0) return false;
      }
      for (const col in filterSelects) {
        const v = filterSelects[col].value;
        if (v && String(row[col] || '') !== v) return false;
      }
      return true;
    }

    function rowToHtml(row) {
      return '<tr>' + def.headers.map(h => {
        const v = row[h.field];
        const cls = (h.field === 'incident_id') ? ' class="snow-incident-id"' : '';
        return '<td' + cls + '>' + esc(String(v == null ? '' : v)) + '</td>';
      }).join('') + '</tr>';
    }

    function appendChunk() {
      const slice = currentFiltered.slice(renderedCount, renderedCount + PAGE);
      if (!slice.length) return;
      tbody.insertAdjacentHTML('beforeend', slice.map(rowToHtml).join(''));
      renderedCount += slice.length;
      if (renderedCount < currentFiltered.length) {
        // Lazy-load the rest as the user scrolls
        const sentinel = document.createElement('tr');
        sentinel.className = 'snow-section-table-sentinel';
        sentinel.innerHTML =
          '<td colspan="' + def.headers.length + '" class="text-center text-muted small py-2">' +
          'Loading more (' + (currentFiltered.length - renderedCount) + ' remaining)...' +
          '</td>';
        tbody.appendChild(sentinel);
        if (observer) observer.disconnect();
        observer = new IntersectionObserver(entries => {
          if (entries[0].isIntersecting) {
            observer.disconnect();
            sentinel.remove();
            appendChunk();
          }
        }, { root: wrap, rootMargin: '120px' });
        observer.observe(sentinel);
      }
    }

    function rerender() {
      if (observer) { observer.disconnect(); observer = null; }
      tbody.innerHTML = '';
      renderedCount = 0;
      currentFiltered = rows.filter(passesFilters);
      meta.textContent =
        currentFiltered.length.toLocaleString() + ' of ' +
        rows.length.toLocaleString() + ' incidents';
      appendChunk();
    }

    let debounceTimer = null;
    searchInput.addEventListener('input', () => {
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(rerender, 150);
    });
    Object.values(filterSelects).forEach(s =>
      s.addEventListener('change', rerender));

    rerender();
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
})();


/* ============================================================
   Robust responsive chart sizing (ResizeObserver).
   ------------------------------------------------------------
   The older window-resize handler above only fires on a *browser*
   resize and only for a fixed list of chart ids. That misses two
   real cases that left charts misaligned with their adjacent
   tables:
     1. Collapsing/expanding the module sidebar changes the content
        width WITHOUT a window resize event.
     2. New charts (e.g. the Open Incidents report) aren't in the
        hardcoded id list.
   A ResizeObserver watching the main content column re-fits EVERY
   rendered Plotly plot (queried live by class) whenever its
   container's width actually changes - the definitive fix for the
   "table/graph alignment shifts when the window is resized" issue.
   ============================================================ */
(function () {
  if (typeof Plotly === 'undefined' || typeof ResizeObserver === 'undefined') return;

  function resizeAllPlots() {
    document.querySelectorAll('.js-plotly-plot').forEach(function (el) {
      try { Plotly.Plots.resize(el); } catch (e) { /* ignore */ }
    });
  }

  function attach() {
    var target = document.querySelector('.main .content') ||
                 document.querySelector('.main') ||
                 document.body;
    if (!target) return;
    var t = null;
    var ro = new ResizeObserver(function () {
      if (t) clearTimeout(t);
      t = setTimeout(resizeAllPlots, 120);
    });
    ro.observe(target);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', attach);
  } else {
    attach();
  }
})();



