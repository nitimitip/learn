/*
   Disclosure menus in the module bar (<details class="npg-menu">).

   The element opens and closes on its own; this only adds the two behaviours
   a menu is expected to have and <details> does not: close when you click
   away, and close on Escape. Loaded by module layouts that use a menu.
*/
(function () {
  'use strict';
  var menus = document.querySelectorAll('details.npg-menu');
  if (!menus.length) return;

  document.addEventListener('click', function (event) {
    menus.forEach(function (menu) {
      if (menu.open && !menu.contains(event.target)) menu.open = false;
    });
  });

  document.addEventListener('keydown', function (event) {
    if (event.key !== 'Escape') return;
    menus.forEach(function (menu) {
      if (!menu.open) return;
      menu.open = false;
      var summary = menu.querySelector('summary');
      if (summary && menu.contains(document.activeElement)) summary.focus();
    });
  });

  /* Only one open at a time. */
  menus.forEach(function (menu) {
    menu.addEventListener('toggle', function () {
      if (!menu.open) return;
      menus.forEach(function (other) { if (other !== menu) other.open = false; });
    });
  });
})();
