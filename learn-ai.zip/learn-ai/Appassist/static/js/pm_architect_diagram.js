/* =====================================================================
   Architect Diagram  (Project Management module)
   ---------------------------------------------------------------------
   A stateless, in-browser architecture diagramming canvas. Nothing is
   persisted to the server - the whole diagram lives only in this browser
   tab, so closing/reloading the tab discards it. Users keep their work by
   exporting a self-contained PNG / SVG (every icon is inlined as a data
   URI, so the export captures the COMPLETE canvas with no missing pieces).

   Powered by JointJS (MPL-2.0) + jQuery / Lodash / Backbone (MIT), all
   vendored locally. No network calls at runtime.
   ===================================================================== */
(function () {
  'use strict';

  const root = document.getElementById('adEditor');
  if (!root || typeof joint === 'undefined') return;

  const paperEl = document.getElementById('adPaper');
  const wrap    = paperEl.parentElement;        // .ad-canvas-wrap
  const GRID    = 10;

  // State
  let snapEnabled  = true;
  let currentScale = 1;
  let selectedView = null;
  let connType     = 'solid';     // active connector style for new links

  // ===================================================================
  //  Icon library - inline SVG so every export is fully self-contained
  // ===================================================================
  function iconUri(inner, color) {
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" ' +
                'fill="none" stroke="' + color + '" stroke-width="1.7" ' +
                'stroke-linecap="round" stroke-linejoin="round">' + inner + '</svg>';
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }

  // Each category: { name, color, items:[{id,label,svg}] }
  const CATEGORIES = [
    { name: 'Compute', color: '#2563eb', items: [
      { id: 'server',     label: 'Server / Host',     svg: '<rect x="4" y="3" width="16" height="8" rx="1.5"/><rect x="4" y="13" width="16" height="8" rx="1.5"/><circle cx="8" cy="7" r="1"/><circle cx="8" cy="17" r="1"/><path d="M12 7h5M12 17h5"/>' },
      { id: 'vm',         label: 'Virtual Machine',   svg: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/><path d="M10 8l4 2.5-4 2.5z"/>' },
      { id: 'container',  label: 'Container',         svg: '<rect x="3" y="10" width="4" height="4"/><rect x="8" y="10" width="4" height="4"/><rect x="13" y="10" width="4" height="4"/><rect x="8" y="5" width="4" height="4"/><path d="M3 18c2 1.5 6 2 9 2 6 0 8-4 8-6"/>' },
      { id: 'serverless', label: 'Serverless / Fn',   svg: '<path d="M13 2L5 13h6l-2 9 9-12h-6z"/>' },
      { id: 'cpu',        label: 'CPU / Processor',   svg: '<rect x="7" y="7" width="10" height="10" rx="1.5"/><rect x="10" y="10" width="4" height="4"/><path d="M10 3v3M14 3v3M10 18v3M14 18v3M3 10h3M3 14h3M18 10h3M18 14h3"/>' },
      { id: 'k8s',        label: 'Kubernetes',        svg: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="2.5"/><path d="M12 4v3M12 17v3M5.5 8.5l2.5 1.4M16 14.1l2.5 1.4M18.5 8.5L16 9.9M8 14.1l-2.5 1.4"/>' },
    ]},
    { name: 'App Tier', color: '#4f46e5', items: [
      { id: 'appserver', label: 'Application Server', svg: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 8h18"/><circle cx="6" cy="5.5" r=".7"/><circle cx="12" cy="15" r="2.2"/><path d="M12 11.6v-1.2M12 19.6v-1.2M8.6 15H7.4M16.6 15h-1.2M9.6 12.6l-.9-.9M15.3 18.3l-.9-.9M9.6 17.4l-.9.9M15.3 11.7l-.9.9"/>' },
      { id: 'webserver', label: 'Web Server',         svg: '<circle cx="12" cy="8" r="5"/><path d="M7 8h10M12 3a7.5 7.5 0 0 1 0 10M12 3a7.5 7.5 0 0 0 0 10"/><rect x="3" y="16" width="18" height="5" rx="1.2"/><circle cx="6.5" cy="18.5" r=".8"/><path d="M10 18.5h8"/>' },
      { id: 'jobsched',  label: 'Job Scheduler / Batch', svg: '<circle cx="9" cy="9" r="6"/><path d="M9 5.8V9l2.2 2.2"/><path d="M16.5 14.5h5M16.5 17.5h5M16.5 20.5h5M14 14.5h.01M14 17.5h.01M14 20.5h.01"/>' },
      { id: 'esb',       label: 'ESB / Integration Hub', svg: '<rect x="9" y="9" width="6" height="6" rx="1"/><path d="M12 4.5V9M12 15v4.5M4.5 12H9M15 12h4.5"/><circle cx="12" cy="3" r="1.3"/><circle cx="12" cy="21" r="1.3"/><circle cx="3" cy="12" r="1.3"/><circle cx="21" cy="12" r="1.3"/>' },
      { id: 'reportsrv', label: 'Report / BI Server', svg: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8"/><path d="M8 17v-4M12 17v-7M16 17v-2.5"/>' },
      { id: 'workflow',  label: 'Workflow Engine',    svg: '<rect x="3" y="3" width="6" height="6" rx="1"/><rect x="15" y="9" width="6" height="6" rx="1"/><rect x="3" y="15" width="6" height="6" rx="1"/><path d="M9 6h4a2 2 0 0 1 2 2v1M15 18h-4a2 2 0 0 1-2-2v-1"/>' },
    ]},
    { name: 'Enterprise Infra', color: '#9d174d', items: [
      { id: 'winserver',  label: 'Windows Server',    svg: '<rect x="5" y="3" width="14" height="18" rx="2"/><circle cx="9" cy="7" r="1"/><path d="M12 7h4"/><path d="M9 12h2.5v2.5H9zM12.5 12H15v2.5h-2.5zM9 15.5h2.5V18H9zM12.5 15.5H15V18h-2.5z"/>' },
      { id: 'unixserver', label: 'Unix / AIX Server', svg: '<rect x="5" y="3" width="14" height="18" rx="2"/><circle cx="9" cy="7" r="1"/><path d="M12 7h4"/><path d="M8.5 12.5l2.5 2.5-2.5 2.5M13 17.5h3"/>' },
      { id: 'cluster',    label: 'Cluster / HA Pair', svg: '<rect x="3" y="4" width="8" height="6" rx="1"/><rect x="13" y="4" width="8" height="6" rx="1"/><path d="M7 10v4h10v-4M12 14v3"/><ellipse cx="12" cy="19.5" rx="3" ry="1.4"/>' },
      { id: 'mainframe',  label: 'Mainframe',         svg: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M4 8.7h16M4 15.4h16"/><circle cx="8" cy="5.3" r="1"/><circle cx="8" cy="12" r="1"/><circle cx="8" cy="18.7" r="1"/><path d="M12 5.3h5M12 12h5M12 18.7h5"/>' },
      { id: 'san',        label: 'SAN / NAS Storage', svg: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9.3h18M3 14.6h18"/><circle cx="7" cy="6.7" r=".9"/><circle cx="7" cy="12" r=".9"/><circle cx="7" cy="17.3" r=".9"/><path d="M11 6.7h6M11 12h6M11 17.3h6"/>' },
      { id: 'tape',       label: 'Tape / Offsite Backup', svg: '<rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="8.5" cy="12" r="2.2"/><circle cx="15.5" cy="12" r="2.2"/><path d="M10.7 12h2.6"/>' },
      { id: 'adldap',     label: 'AD / LDAP Directory', svg: '<rect x="9" y="3" width="6" height="5" rx="1"/><rect x="3" y="16" width="6" height="5" rx="1"/><rect x="15" y="16" width="6" height="5" rx="1"/><path d="M12 8v3M6 16v-2.5h12V16M12 11v5"/>' },
      { id: 'mailsrv',    label: 'SMTP / Mail Server', svg: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7.5l9 6 9-6"/>' },
    ]},
    { name: 'Network', color: '#0d9488', items: [
      { id: 'lb',          label: 'Load Balancer',  svg: '<circle cx="12" cy="5" r="2.5"/><circle cx="5" cy="19" r="2.5"/><circle cx="12" cy="19" r="2.5"/><circle cx="19" cy="19" r="2.5"/><path d="M12 7.5v3M12 10.5L5 16.5M12 10.5v6M12 10.5l7 6"/>' },
      { id: 'router',      label: 'Router / Switch', svg: '<rect x="3" y="13" width="18" height="7" rx="1.5"/><circle cx="7" cy="16.5" r="1"/><path d="M10 16.5h8"/><path d="M8 9l3-3M16 9l-3-3M12 3v3"/>' },
      { id: 'firewall',    label: 'Firewall',       svg: '<rect x="3" y="5" width="18" height="14" rx="1"/><path d="M3 9.7h18M3 14.3h18M9 5v4.7M15 5v4.7M6 9.7v4.6M12 9.7v4.6M18 9.7v4.6M9 14.3V19M15 14.3V19"/>' },
      { id: 'dns',         label: 'DNS',            svg: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.6 2.6 15.4 0 18M12 3c-2.6 2.6-2.6 15.4 0 18"/>' },
      { id: 'cdn',         label: 'CDN',            svg: '<circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>' },
      { id: 'apigw',       label: 'API Gateway',    svg: '<rect x="4" y="6" width="16" height="12" rx="1.5"/><path d="M9 9l-2 3 2 3M15 9l2 3-2 3"/>' },
      { id: 'proxy',       label: 'Reverse Proxy',  svg: '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 16V8l8 8V8"/>' },
      { id: 'vpngw',       label: 'VPN Gateway',    svg: '<path d="M3 20V12a9 9 0 0 1 18 0v8"/><path d="M3 20h4M17 20h4"/><path d="M9 20v-5a3 3 0 0 1 6 0v5"/>' },
    ]},
    { name: 'Storage', color: '#7c3aed', items: [
      { id: 'sqldb',    label: 'SQL Database',    svg: '<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v12c0 1.7 3.1 3 7 3s7-1.3 7-3V6"/><path d="M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3"/>' },
      { id: 'nosql',    label: 'NoSQL Database',  svg: '<ellipse cx="12" cy="5" rx="6" ry="2.4"/><path d="M6 5v4c0 1.4 2.7 2.4 6 2.4s6-1 6-2.4V5"/><path d="M6 11v4c0 1.4 2.7 2.4 6 2.4s6-1 6-2.4v-4"/><path d="M6 17v2c0 1.4 2.7 2.4 6 2.4s6-1 6-2.4v-2"/>' },
      { id: 'object',   label: 'Object Storage',  svg: '<path d="M5 6h14l-1.4 13a2 2 0 0 1-2 1.8H8.4a2 2 0 0 1-2-1.8z"/><ellipse cx="12" cy="6" rx="7" ry="2.2"/>' },
      { id: 'cache',    label: 'Cache',           svg: '<ellipse cx="12" cy="6" rx="7" ry="2.6"/><path d="M5 6v12c0 1.5 3.1 2.7 7 2.7s7-1.2 7-2.7V6"/><path d="M13 9l-3 4h2l-1 3 3-4h-2z"/>' },
      { id: 'warehouse',label: 'Data Warehouse',  svg: '<path d="M3 21V8l9-5 9 5v13"/><path d="M3 21h18M9 21v-6h6v6"/><path d="M7 11h2M15 11h2"/>' },
      { id: 'fileshare',label: 'File Storage',    svg: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>' },
      { id: 'backup',   label: 'Backup / Archive',svg: '<rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v9a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V9"/><path d="M9.5 13h5"/>' },
      { id: 'oracledb', label: 'Oracle Database', svg: '<ellipse cx="12" cy="5.5" rx="7" ry="2.6"/><path d="M5 5.5V18c0 1.6 3.1 2.9 7 2.9s7-1.3 7-2.9V5.5"/><circle cx="12" cy="13.5" r="2.8"/>' },
      { id: 'mssqldb',  label: 'SQL Server DB',   svg: '<ellipse cx="12" cy="5.5" rx="7" ry="2.6"/><path d="M5 5.5V18c0 1.6 3.1 2.9 7 2.9s7-1.3 7-2.9V5.5"/><path d="M9.5 10.5h5v5.5h-5zM12 10.5V16M9.5 13.2h5"/>' },
      { id: 'dbrepl',   label: 'DB Replication / DR', svg: '<ellipse cx="7" cy="4.8" rx="4" ry="1.6"/><path d="M3 4.8v6c0 .9 1.8 1.6 4 1.6s4-.7 4-1.6v-6"/><ellipse cx="17" cy="11.8" rx="4" ry="1.6"/><path d="M13 11.8v6c0 .9 1.8 1.6 4 1.6s4-.7 4-1.6v-6"/><path d="M7 14.5v2.5a3 3 0 0 0 3 3h.8M9.3 18.5l1.5 1.5-1.5 1.5"/>' },
      { id: 'flatfile', label: 'Flat File / Extract', svg: '<path d="M6 3h8l4 4v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M14 3v4h4"/><path d="M8 12h2M11.5 12h2M15 12h1.5M8 15h2M11.5 15h2M15 15h1.5M8 18h2M11.5 18h2"/>' },
    ]},
    { name: 'Security', color: '#dc2626', items: [
      { id: 'lock',     label: 'Encryption',      svg: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15" r="1.4"/>' },
      { id: 'iam',      label: 'IAM / Identity',  svg: '<rect x="4" y="3" width="16" height="18" rx="2"/><circle cx="12" cy="10" r="2.5"/><path d="M8 17a4 4 0 0 1 8 0"/><path d="M10 3h4v2h-4z"/>' },
      { id: 'tls',      label: 'TLS Certificate', svg: '<rect x="4" y="4" width="16" height="11" rx="1.5"/><path d="M7 8h10M7 11h6"/><circle cx="12" cy="18" r="3"/><path d="M10.5 20l-1 3 2.5-1.5L14 23l-1-3"/>' },
      { id: 'waf',      label: 'WAF',             svg: '<path d="M12 3l7 3v5c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6z"/><path d="M5.5 10.5h13M12 4.5v15"/>' },
      { id: 'vpnsec',   label: 'VPN',             svg: '<path d="M12 3l7 3v5c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6z"/><circle cx="12" cy="10" r="2"/><path d="M12 12v4"/>' },
      { id: 'secrets',  label: 'Secrets Manager', svg: '<circle cx="8" cy="8" r="4"/><path d="M11 11l8 8M16 16l2-2M18 18l2-2"/>' },
      { id: 'bastion',  label: 'Bastion Host',    svg: '<path d="M12 2l7 3v6c0 4-3 7-7 9-4-2-7-5-7-9V5z"/><path d="M9 11h6M9 14h6M12 8v9"/>' },
    ]},
    { name: 'Messaging', color: '#d97706', items: [
      { id: 'queue',    label: 'Message Queue',   svg: '<rect x="4" y="6" width="3.5" height="12" rx="1"/><rect x="10.25" y="6" width="3.5" height="12" rx="1"/><rect x="16.5" y="6" width="3.5" height="12" rx="1"/><path d="M2 12h2"/>' },
      { id: 'eventbus', label: 'Event Bus',       svg: '<path d="M3 14h18"/><rect x="4" y="10" width="4" height="4" rx="1"/><rect x="10" y="10" width="4" height="4" rx="1"/><rect x="16" y="10" width="4" height="4" rx="1"/><path d="M6 10V7M12 10V7M18 10V7"/>' },
      { id: 'pubsub',   label: 'Pub/Sub Topic',   svg: '<circle cx="12" cy="12" r="2.5"/><path d="M8 8a6 6 0 0 0 0 8M16 8a6 6 0 0 1 0 8M5 5a10 10 0 0 0 0 14M19 5a10 10 0 0 1 0 14"/>' },
      { id: 'webhook',  label: 'Webhook',         svg: '<path d="M9 9a3 3 0 1 1 4 2.6L9.5 17.5"/><circle cx="7.5" cy="17.5" r="2.5"/><circle cx="16.5" cy="17.5" r="2.5"/><path d="M10 17.5h4M12.5 8.5l3 6"/>' },
      { id: 'mesh',     label: 'Service Mesh',    svg: '<circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/><circle cx="12" cy="12" r="2"/><path d="M7.4 7.4l3.2 3.2M16.6 7.4l-3.2 3.2M7.4 16.6l3.2-3.2M16.6 16.6l-3.2-3.2"/>' },
      { id: 'etl',      label: 'ETL / Pipeline',  svg: '<path d="M3 8h7M3 16h11"/><path d="M7 5l3 3-3 3M11 13l3 3-3 3"/><circle cx="18" cy="8" r="2.5"/>' },
      { id: 'api',      label: 'API (REST/GQL)',  svg: '<path d="M8 5c-2 0-2 2.5-2 3.5S5 11 4 12c1 1 2 1.5 2 3.5s0 3 2 3M16 5c2 0 2 2.5 2 3.5s1 2 2 3c-1 1-2 1.5-2 3.5s0 3-2 3"/>' },
      { id: 'sftp',     label: 'SFTP / File Transfer', svg: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 14.5l3-3 3 3M12 11.5v6"/>' },
    ]},
    { name: 'Clients', color: '#0ea5e9', items: [
      { id: 'browser',  label: 'Web Browser',     svg: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 8h18"/><circle cx="6" cy="6" r="0.6"/><circle cx="8.5" cy="6" r="0.6"/>' },
      { id: 'mobile',   label: 'Mobile App',      svg: '<rect x="7" y="3" width="10" height="18" rx="2"/><path d="M11 18h2"/>' },
      { id: 'desktop',  label: 'Desktop Client',  svg: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>' },
      { id: 'iot',      label: 'IoT / Sensor',    svg: '<rect x="8" y="10" width="8" height="8" rx="1"/><path d="M10.5 13.5h3"/><path d="M6 8a8 8 0 0 1 12 0M8.5 9.5a5 5 0 0 1 7 0"/>' },
      { id: 'extapi',   label: '3rd-party API',   svg: '<path d="M14 3h7v7M21 3l-9 9"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>' },
      { id: 'cli',      label: 'CLI / Terminal',  svg: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9l3 3-3 3M12 15h5"/>' },
      { id: 'admin',    label: 'Admin Portal',    svg: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 8h18"/><circle cx="12" cy="14" r="2.2"/><path d="M12 11v-1M12 18v-1M9.5 14h-1M15.5 14h-1M10.3 12.3l-.7-.7M14.4 16.4l-.7-.7M10.3 15.7l-.7.7M14.4 11.6l-.7.7"/>' },
    ]},
    { name: 'Monitoring', color: '#059669', items: [
      { id: 'logging',  label: 'Logging',         svg: '<path d="M6 3h8l4 4v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M14 3v4h4M8 12h8M8 15h8M8 18h5"/>' },
      { id: 'metrics',  label: 'Metrics',         svg: '<path d="M4 4v16h16"/><path d="M8 16v-3M12 16v-6M16 16v-9"/>' },
      { id: 'alert',    label: 'Alerting',        svg: '<path d="M18 9a6 6 0 0 0-12 0c0 5-2 6-2 6h16s-2-1-2-6"/><path d="M10.5 20a2 2 0 0 0 3 0"/>' },
      { id: 'cicd',     label: 'CI/CD Pipeline',  svg: '<path d="M4 12a8 8 0 0 1 14-5.3M20 12a8 8 0 0 1-14 5.3"/><path d="M18 3v4h-4M6 21v-4h4"/>' },
      { id: 'tracing',  label: 'Tracing',         svg: '<circle cx="5" cy="6" r="2"/><circle cx="12" cy="14" r="2"/><circle cx="19" cy="8" r="2"/><path d="M6.5 7.5l4 5M13.5 13l4-3.5"/>' },
      { id: 'iac',      label: 'IaC / Config',    svg: '<path d="M8 9l-3 3 3 3M16 9l3 3-3 3M13 7l-2 10"/>' },
      { id: 'uptime',   label: 'Health Check',    svg: '<path d="M3 12h4l2-5 3 9 2-6 2 2h5"/>' },
      { id: 'itsm',     label: 'ITSM / Ticketing',svg: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M15.5 5v14"/><path d="M6 9h6M6 12h6M6 15h4"/><path d="M18.5 9v.01M18.5 12v.01M18.5 15v.01"/>' },
      { id: 'monagent', label: 'Monitoring Agent',svg: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.5"/><path d="M12 12l5.5-5.5"/><circle cx="12" cy="12" r="1"/>' },
      { id: 'antivirus',label: 'Antivirus / EDR', svg: '<path d="M12 3l7 3v5c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6z"/><path d="M9 12l2.2 2.2L15.5 10"/>' },
    ]},
    { name: 'Cloud & Zones', color: '#f97316', items: [
      { id: 'cloud',    label: 'Cloud Provider',  svg: '<path d="M7 18a4 4 0 0 1 0-8 5 5 0 0 1 9.6-1.3A3.5 3.5 0 0 1 18 18z"/>' },
      { id: 'region',   label: 'Region / AZ',     svg: '<path d="M12 21s7-6 7-11a7 7 0 0 0-14 0c0 5 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>' },
      { id: 'internet', label: 'Internet',        svg: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>' },
      { id: 'onprem',   label: 'On-premise',      svg: '<path d="M4 21V6l8-3 8 3v15"/><path d="M4 21h16M9 21v-4h6v4M8 9h2M8 13h2M14 9h2M14 13h2"/>' },
      { id: 'vpc',      label: 'VPC / VNet',      svg: '<rect x="3" y="6" width="18" height="13" rx="2" stroke-dasharray="3 2"/><path d="M9 13a3 3 0 0 1 6 0"/>' },
      { id: 'subnet',   label: 'Subnet',          svg: '<rect x="3" y="3" width="18" height="18" rx="2" stroke-dasharray="3 2"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18"/>' },
      { id: 'edge',     label: 'Edge / PoP',      svg: '<circle cx="12" cy="12" r="3"/><circle cx="12" cy="4" r="1.3"/><circle cx="12" cy="20" r="1.3"/><circle cx="4" cy="12" r="1.3"/><circle cx="20" cy="12" r="1.3"/><path d="M12 9V5.3M12 18.7V15M9 12H5.3M18.7 12H15"/>' },
    ]},
    { name: 'Users & Actors', color: '#475569', items: [
      { id: 'enduser',  label: 'End User',        svg: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>' },
      { id: 'opsadmin', label: 'Admin / Operator',svg: '<circle cx="9" cy="8" r="3.5"/><path d="M3 21a6 6 0 0 1 12 0"/><circle cx="18" cy="15" r="2"/><path d="M18 12v-1M18 19v-1M21 15h-1M16 15h-1"/>' },
      { id: 'developer',label: 'Developer',       svg: '<circle cx="12" cy="7" r="3.5"/><path d="M5 21a7 7 0 0 1 14 0"/><path d="M9 13l-2 2 2 2M15 13l2 2-2 2"/>' },
      { id: 'partner',  label: 'External System', svg: '<rect x="4" y="4" width="11" height="6" rx="1"/><rect x="4" y="14" width="11" height="6" rx="1"/><path d="M19 4v7M19 4l2 2M19 4l-2 2"/>' },
      { id: 'bot',      label: 'Bot / Automation',svg: '<rect x="5" y="8" width="14" height="11" rx="2"/><circle cx="9.5" cy="13" r="1.3"/><circle cx="14.5" cy="13" r="1.3"/><path d="M12 5v3M9 19v2M15 19v2M3 12v3M21 12v3"/><circle cx="12" cy="4" r="1.4"/>' },
    ]},
    // flow:true items create real flowchart shapes (not icon cards).
    { name: 'Flow Shapes', color: '#475569', items: [
      { id: 'flowproc',  label: 'Process',     flow: true, svg: '<rect x="3" y="7" width="18" height="10" rx="2"/>' },
      { id: 'flowdec',   label: 'Decision',    flow: true, svg: '<path d="M12 4l8 8-8 8-8-8z"/>' },
      { id: 'flowstart', label: 'Start / End', flow: true, svg: '<rect x="3" y="7" width="18" height="10" rx="5"/>' },
      { id: 'flownote',  label: 'Sticky Note', flow: true, svg: '<path d="M4 4h16v11l-5 5H4z"/><path d="M15 20v-5h5"/>' },
    ]},
  ];

  // Flat lookup: id -> { label, accent, uri, svg, flow }
  // The raw `svg` string is kept so a node's icon can be re-tinted when the
  // user recolours it; `flow` marks palette items that create flowchart
  // shapes instead of icon cards.
  const SYS = {};
  CATEGORIES.forEach(function (cat) {
    cat.items.forEach(function (it) {
      SYS[it.id] = {
        label: it.label, accent: cat.color,
        uri: iconUri(it.svg, cat.color),
        svg: it.svg, flow: !!it.flow
      };
    });
  });

  // Ports (hover-to-reveal connectors on four sides)
  const PORTS = {
    groups: {
      link: {
        position: { name: 'absolute' },
        markup: [{ tagName: 'circle', selector: 'circle' }],
        attrs: { circle: { r: 6, magnet: 'active', fill: '#ffffff', stroke: '#2563eb', strokeWidth: 1.8 } }
      }
    },
    items: [
      { id: 'top',    group: 'link', args: { x: '50%',  y: '0%'  } },
      { id: 'right',  group: 'link', args: { x: '100%', y: '50%' } },
      { id: 'bottom', group: 'link', args: { x: '50%',  y: '100%'} },
      { id: 'left',   group: 'link', args: { x: '0%',   y: '50%' } }
    ]
  };
  function applyPorts(el) {
    el.prop('ports/groups', joint.util.cloneDeep(PORTS.groups));
    el.addPorts(joint.util.cloneDeep(PORTS.items));
  }

  // ===================================================================
  //  Custom elements
  // ===================================================================

  // A "system" node: rounded card with an inlined icon + label INSIDE the
  // box (keeping the label within the element's bounds so exports never
  // clip it).
  // Bottom-right resize handle shared by system & flow nodes. Hidden until
  // the element is hovered (see .ad-resize-h CSS in architectdiagram.css).
  const RESIZE_HANDLE = {
    x: 'calc(w-13)', y: 'calc(h-13)', width: 11, height: 11,
    fill: '#94a3b8', stroke: '#ffffff', strokeWidth: 1, rx: 2,
    cursor: 'nwse-resize', event: 'element:resize'
  };

  const SystemNode = joint.dia.Element.define('ad.System', {
    size: { width: 98, height: 86 },
    attrs: {
      body:  { width: 'calc(w)', height: 'calc(h)', fill: '#ffffff', stroke: '#94a3b8', strokeWidth: 1.4, rx: 10, ry: 10 },
      // icon/label positions are h-relative so the card can be resized.
      icon:  { x: 'calc(w/2-17)', y: 'calc(h/2-31)', width: 34, height: 34, preserveAspectRatio: 'xMidYMid meet' },
      label: { x: 'calc(w/2)', y: 'calc(h/2+11)', textAnchor: 'middle', textVerticalAnchor: 'top',
               fill: '#334155', fontSize: 11.5, fontFamily: 'inherit',
               textWrap: { width: -8, height: 28, ellipsis: true } },
      handle: joint.util.cloneDeep(RESIZE_HANDLE)
    }
  }, {
    markup: [
      { tagName: 'rect',  selector: 'body' },
      { tagName: 'image', selector: 'icon' },
      { tagName: 'text',  selector: 'label' },
      { tagName: 'rect',  selector: 'handle', className: 'ad-resize-h' }
    ]
  });

  // A grouping zone / boundary box. Transparent interior (so children stay
  // clickable), dashed coloured border, a draggable header band carrying an
  // editable title, and a bottom-right resize handle.
  const ZoneNode = joint.dia.Element.define('ad.Zone', {
    size: { width: 280, height: 190 },
    attrs: {
      body:   { width: 'calc(w)', height: 'calc(h)', fill: 'none', stroke: '#64748b', strokeWidth: 1.6, strokeDasharray: '7 5', rx: 10, ry: 10 },
      header: { width: 'calc(w)', height: 26, fill: '#64748b', fillOpacity: 0.10, stroke: 'none', rx: 10, ry: 10, cursor: 'move' },
      label:  { x: 12, y: 13, textAnchor: 'start', textVerticalAnchor: 'middle',
                fill: '#475569', fontSize: 12.5, fontWeight: 600, fontFamily: 'inherit', text: '', cursor: 'move' },
      handle: { x: 'calc(w-15)', y: 'calc(h-15)', width: 12, height: 12, fill: '#64748b', stroke: '#ffffff', strokeWidth: 1, rx: 2, cursor: 'nwse-resize', event: 'element:resize' }
    }
  }, {
    markup: [
      { tagName: 'rect', selector: 'body' },
      { tagName: 'rect', selector: 'header' },
      { tagName: 'text', selector: 'label' },
      // ad-export-omit: stays visible on canvas but is stripped from exports
      { tagName: 'rect', selector: 'handle', className: 'ad-export-omit' }
    ]
  });

  // A free text label (no border). pointer-events:all keeps the transparent
  // box clickable/draggable.
  const TextNode = joint.dia.Element.define('ad.Text', {
    size: { width: 150, height: 34 },
    attrs: {
      body:  { width: 'calc(w)', height: 'calc(h)', fill: 'none', stroke: 'none', pointerEvents: 'all' },
      label: { x: 'calc(w/2)', y: 'calc(h/2)', textAnchor: 'middle', textVerticalAnchor: 'middle',
               fill: '#1f2937', fontSize: 14, fontFamily: 'inherit', text: 'Text',
               textWrap: { width: -4, height: 0, ellipsis: false } }
    }
  }, {
    markup: [
      { tagName: 'rect', selector: 'body' },
      { tagName: 'text', selector: 'label' }
    ]
  });

  // Richer layout building blocks
  // The vocabulary needed for a polished "solution architecture" picture
  // (cf. the home-path architecture.png) rather than a loose icon sketch:
  //   - Card      - accent-stroked box with a bold TITLE + description line
  //   - Container - solid titled panel that other shapes NEST inside
  //   - Section   - uppercase lane / column header label
  //   - Caption   - wrapped, muted footnote paragraph
  // Cards & containers carry two text rows; double-clicking edits both
  // (first line = title, remaining lines = description).
  const ACCENT = '#2563eb';

  const CardNode = joint.dia.Element.define('ad.Card', {
    size: { width: 210, height: 78 },
    attrs: {
      body:  { width: 'calc(w)', height: 'calc(h)', fill: '#ffffff', stroke: ACCENT, strokeWidth: 1.6, rx: 12, ry: 12 },
      // Optional glyph (server / db / lb ...) docked at the left edge; zero
      // size until makeCard() assigns one, so plain cards are unaffected.
      icon:  { x: 11, y: 'calc(h/2-12)', width: 0, height: 0, preserveAspectRatio: 'xMidYMid meet' },
      title: { x: 'calc(w/2)', y: 'calc(h/2-9)', textAnchor: 'middle', textVerticalAnchor: 'middle',
               fill: ACCENT, fontSize: 13.5, fontWeight: 700, fontFamily: 'inherit', text: 'Title',
               textWrap: { width: -18, height: 20, ellipsis: true } },
      desc:  { x: 'calc(w/2)', y: 'calc(h/2+13)', textAnchor: 'middle', textVerticalAnchor: 'middle',
               fill: '#475569', fontSize: 11, fontFamily: 'inherit', text: 'Description',
               textWrap: { width: -18, height: 30, ellipsis: true } },
      handle: joint.util.cloneDeep(RESIZE_HANDLE)
    }
  }, {
    markup: [
      { tagName: 'rect',  selector: 'body' },
      { tagName: 'image', selector: 'icon' },
      { tagName: 'text',  selector: 'title' },
      { tagName: 'text',  selector: 'desc' },
      { tagName: 'rect',  selector: 'handle', className: 'ad-resize-h' }
    ]
  });

  const ContainerNode = joint.dia.Element.define('ad.Container', {
    size: { width: 470, height: 300 },
    attrs: {
      body:   { width: 'calc(w)', height: 'calc(h)', fill: '#fbfaff', stroke: ACCENT, strokeWidth: 1.8, rx: 14, ry: 14 },
      title:  { x: 'calc(w/2)', y: 23, textAnchor: 'middle', textVerticalAnchor: 'middle',
                fill: ACCENT, fontSize: 15, fontWeight: 700, fontFamily: 'inherit', text: 'Container',
                textWrap: { width: -28, height: 24, ellipsis: true } },
      desc:   { x: 'calc(w/2)', y: 42, textAnchor: 'middle', textVerticalAnchor: 'middle',
                fill: '#6b7280', fontSize: 11, fontFamily: 'inherit', text: '',
                textWrap: { width: -28, height: 16, ellipsis: true } },
      handle: { x: 'calc(w-15)', y: 'calc(h-15)', width: 12, height: 12, fill: '#94a3b8', stroke: '#ffffff', strokeWidth: 1, rx: 2, cursor: 'nwse-resize', event: 'element:resize' }
    }
  }, {
    markup: [
      { tagName: 'rect', selector: 'body' },
      { tagName: 'text', selector: 'title' },
      { tagName: 'text', selector: 'desc' },
      { tagName: 'rect', selector: 'handle', className: 'ad-resize-h' }
    ]
  });

  const SectionNode = joint.dia.Element.define('ad.Section', {
    size: { width: 200, height: 26 },
    attrs: {
      body:  { width: 'calc(w)', height: 'calc(h)', fill: 'none', stroke: 'none', pointerEvents: 'all' },
      label: { x: 'calc(w/2)', y: 'calc(h/2)', textAnchor: 'middle', textVerticalAnchor: 'middle',
               fill: '#64748b', fontSize: 13, fontWeight: 700, letterSpacing: 0.6, fontFamily: 'inherit', text: 'SECTION',
               textWrap: { width: -4, height: 0, ellipsis: false } }
    }
  }, {
    markup: [
      { tagName: 'rect', selector: 'body' },
      { tagName: 'text', selector: 'label' }
    ]
  });

  const CaptionNode = joint.dia.Element.define('ad.Caption', {
    size: { width: 520, height: 48 },
    attrs: {
      body:  { width: 'calc(w)', height: 'calc(h)', fill: 'none', stroke: 'none', pointerEvents: 'all' },
      label: { x: 'calc(w/2)', y: 'calc(h/2)', textAnchor: 'middle', textVerticalAnchor: 'middle',
               fill: '#6b7280', fontSize: 11.5, fontFamily: 'inherit', text: 'Caption',
               textWrap: { width: -6, height: 0, ellipsis: false } }
    }
  }, {
    markup: [
      { tagName: 'rect', selector: 'body' },
      { tagName: 'text', selector: 'label' }
    ]
  });

  // Flowchart shapes (Process / Decision / Start-End / Sticky note)
  const FLOW_LABEL = {
    x: 'calc(w/2)', y: 'calc(h/2)', textAnchor: 'middle', textVerticalAnchor: 'middle',
    fill: '#1f2937', fontSize: 12.5, fontFamily: 'inherit',
    textWrap: { width: -16, height: -10, ellipsis: true }
  };
  function flowMarkup(bodyTag) {
    return [
      { tagName: bodyTag, selector: 'body' },
      { tagName: 'text',  selector: 'label' },
      { tagName: 'rect',  selector: 'handle', className: 'ad-resize-h' }
    ];
  }

  const FlowProcess = joint.dia.Element.define('ad.FlowProcess', {
    size: { width: 130, height: 56 },
    attrs: {
      body:   { width: 'calc(w)', height: 'calc(h)', rx: 6, ry: 6, fill: '#ffffff', stroke: '#475569', strokeWidth: 1.6 },
      label:  joint.util.assign({ text: 'Process' }, joint.util.cloneDeep(FLOW_LABEL)),
      handle: joint.util.cloneDeep(RESIZE_HANDLE)
    }
  }, { markup: flowMarkup('rect') });

  const FlowDecision = joint.dia.Element.define('ad.FlowDecision', {
    size: { width: 140, height: 90 },
    attrs: {
      body:   { refPoints: '0,10 10,0 20,10 10,20', fill: '#ffffff', stroke: '#475569', strokeWidth: 1.6 },
      label:  joint.util.assign({ text: 'Decision?' },
                joint.util.cloneDeep(FLOW_LABEL), { textWrap: { width: -56, height: -36, ellipsis: true } }),
      handle: joint.util.cloneDeep(RESIZE_HANDLE)
    }
  }, { markup: flowMarkup('polygon') });

  const FlowStartEnd = joint.dia.Element.define('ad.FlowStartEnd', {
    size: { width: 130, height: 48 },
    attrs: {
      body:   { width: 'calc(w)', height: 'calc(h)', rx: 'calc(h/2)', ry: 'calc(h/2)', fill: '#ffffff', stroke: '#475569', strokeWidth: 1.6 },
      label:  joint.util.assign({ text: 'Start / End' }, joint.util.cloneDeep(FLOW_LABEL)),
      handle: joint.util.cloneDeep(RESIZE_HANDLE)
    }
  }, { markup: flowMarkup('rect') });

  const FlowNote = joint.dia.Element.define('ad.FlowNote', {
    size: { width: 150, height: 92 },
    attrs: {
      body:   { width: 'calc(w)', height: 'calc(h)', rx: 3, ry: 3, fill: '#fef9c3', stroke: '#ca8a04', strokeWidth: 1.2 },
      label:  joint.util.assign({ text: 'Note' }, joint.util.cloneDeep(FLOW_LABEL), { fill: '#713f12' }),
      handle: joint.util.cloneDeep(RESIZE_HANDLE)
    }
  }, { markup: flowMarkup('rect') });

  const FLOW_CTORS = {
    flowproc:  FlowProcess,
    flowdec:   FlowDecision,
    flowstart: FlowStartEnd,
    flownote:  FlowNote
  };

  function makeSystem(id) {
    const def = SYS[id];
    const el = new SystemNode();
    el.attr('icon/xlink:href', def.uri);
    el.attr('label/text', def.label);
    el.attr('body/stroke', def.accent);
    el.prop('adShape', id);   // remembered so recolouring can re-tint the icon
    return el;
  }

  function makeFlow(id) {
    const el = new FLOW_CTORS[id]();
    el.prop('adShape', id);
    return el;
  }

  // Layout building blocks. Cards & containers are connectable (ports);
  // sections & captions are plain labels. `color` (optional) re-tints them.
  // `icon` (optional, a SYS id like 'server' / 'sqldb') docks a tinted glyph
  // at the card's left edge - icon and text together.
  function makeCard(title, desc, color, icon) {
    const el = new CardNode();
    el.attr('title/text', title != null ? title : 'Title');
    el.attr('desc/text',  desc  != null ? desc  : 'Description');
    if (icon && SYS[icon]) {
      el.prop('adShape', icon);   // remembered so recolouring re-tints it
      el.attr('icon/xlink:href', iconUri(SYS[icon].svg, color || ACCENT));
      el.attr('icon/width', 24);
      el.attr('icon/height', 24);
      // Centre the text in the space right of the glyph.
      el.attr('title/x', 'calc(w/2+14)');
      el.attr('desc/x',  'calc(w/2+14)');
      el.attr('title/textWrap/width', -52);
      el.attr('desc/textWrap/width',  -52);
    }
    applyPorts(el);
    if (color) recolorCell(el, color);
    return el;
  }
  function makeContainer(title, desc, color) {
    const el = new ContainerNode();
    el.attr('title/text', title != null ? title : 'Container');
    el.attr('desc/text',  desc  != null ? desc  : '');
    applyPorts(el);
    if (color) recolorCell(el, color);
    return el;
  }
  function makeSection(text, color) {
    const el = new SectionNode();
    el.attr('label/text', (text != null ? text : 'Section').toUpperCase());
    if (color) recolorCell(el, color);
    return el;
  }
  function makeCaption(text, color) {
    const el = new CaptionNode();
    el.attr('label/text', text != null ? text : 'Caption');
    if (color) recolorCell(el, color);
    return el;
  }

  // Recolouring (toolbar swatches act on the current selection)
  function recolorCell(model, color) {
    if (model.isLink()) {
      model.attr('line/stroke', color);
      ['sourceMarker', 'targetMarker'].forEach(function (m) {
        const marker = model.attr('line/' + m);
        if (marker && marker.type !== 'none') {
          model.attr('line/' + m + '/fill', color);
          model.attr('line/' + m + '/stroke', color);
        }
      });
      return;
    }
    const type = model.get('type');
    if (type === 'ad.System') {
      model.attr('body/stroke', color);
      const def = SYS[model.prop('adShape')];
      if (def) model.attr('icon/xlink:href', iconUri(def.svg, color));
    } else if (type === 'ad.Zone') {
      model.attr('body/stroke', color);
      model.attr('header/fill', color);
      model.attr('label/fill', color);
    } else if (type === 'ad.Text') {
      model.attr('label/fill', color);
    } else if (type === 'ad.Card' || type === 'ad.Container') {
      model.attr('body/stroke', color);
      model.attr('title/fill', color);
      if (type === 'ad.Card') {
        const cdef = SYS[model.prop('adShape')];
        if (cdef) model.attr('icon/xlink:href', iconUri(cdef.svg, color));
      }
    } else if (type === 'ad.Section' || type === 'ad.Caption') {
      model.attr('label/fill', color);
    } else if (type === 'ad.FlowNote') {
      model.attr('body/stroke', color);
      model.attr('label/fill', color);
    } else {
      model.attr('body/stroke', color);
    }
  }

  // Palette
  function tilePreview(uri) {
    return '<img src="' + uri + '" alt="" draggable="false">';
  }
  function renderPalette() {
    const body = document.getElementById('adPaletteBody');
    const frag = document.createDocumentFragment();
    CATEGORIES.forEach(function (cat) {
      const group = document.createElement('div');
      group.className = 'ad-pgroup';

      const head = document.createElement('button');
      head.type = 'button';
      head.className = 'ad-pgroup-head';
      head.innerHTML = '<span class="ad-pgroup-dot" style="background:' + cat.color + '"></span>' +
                       '<span class="ad-pgroup-name">' + cat.name + '</span>' +
                       '<i class="fas fa-chevron-down ad-pgroup-caret"></i>';
      head.addEventListener('click', function () { group.classList.toggle('collapsed'); });

      const grid = document.createElement('div');
      grid.className = 'ad-pgroup-grid';
      cat.items.forEach(function (it) {
        const tile = document.createElement('div');
        tile.className = 'ad-shape';
        tile.draggable = true;
        tile.dataset.shape = it.id;
        tile.dataset.search = it.label.toLowerCase();
        tile.title = it.label;
        tile.innerHTML = '<span class="ad-shape-preview">' + tilePreview(SYS[it.id].uri) + '</span>' +
                         '<span class="ad-shape-label">' + it.label + '</span>';
        tile.addEventListener('dragstart', function (e) {
          e.dataTransfer.setData('text/ad-shape', it.id);
          e.dataTransfer.effectAllowed = 'copy';
        });
        tile.addEventListener('dblclick', function () { dropAtCenter(it.id); });
        grid.appendChild(tile);
      });

      group.appendChild(head);
      group.appendChild(grid);
      frag.appendChild(group);
    });
    body.innerHTML = '';
    body.appendChild(frag);
  }

  // Palette search
  const searchInput = document.getElementById('adPaletteSearch');
  if (searchInput) {
    searchInput.addEventListener('input', function () {
      const q = this.value.trim().toLowerCase();
      document.querySelectorAll('#adPaletteBody .ad-pgroup').forEach(function (group) {
        let any = false;
        group.querySelectorAll('.ad-shape').forEach(function (tile) {
          const hit = !q || tile.dataset.search.indexOf(q) !== -1;
          tile.style.display = hit ? '' : 'none';
          if (hit) any = true;
        });
        group.style.display = any ? '' : 'none';
        if (q) group.classList.remove('collapsed');
      });
    });
  }

  // Paper + graph
  const graph = new joint.dia.Graph({}, { cellNamespace: joint.shapes });
  const paper = new joint.dia.Paper({
    el: paperEl,
    model: graph,
    width: paperEl.clientWidth || 800,
    height: paperEl.clientHeight || 600,
    // gridSize is the SNAP step - JointJS quantises every pointer coordinate
    // and every drag position to it, so this is what the "Snap to grid"
    // toggle actually flips (GRID <-> 1). drawGridSize pins the painted mesh
    // at GRID so the backdrop never changes when snapping is turned off.
    gridSize: GRID,
    drawGridSize: GRID,
    drawGrid: { name: 'mesh', args: { color: '#e6e9ee' } },
    background: { color: '#ffffff' },
    cellViewNamespace: joint.shapes,
    defaultConnectionPoint: { name: 'boundary' },
    defaultConnector: { name: 'rounded' },
    defaultRouter: { name: 'normal' },
    linkPinning: false,
    snapLinks: { radius: 28 },
    markAvailable: true,
    // Containers & zones act as real parents: a shape dragged inside one is
    // embedded, so moving the boundary carries its children with it.
    embeddingMode: true,
    findParentBy: 'bbox',
    validateEmbedding: function (childView, parentView) {
      const ct = childView.model.get('type');
      if (ct === 'ad.Zone' || ct === 'ad.Container') return false;   // boundaries don't nest into things
      const pt = parentView.model.get('type');
      return pt === 'ad.Zone' || pt === 'ad.Container';
    },
    clickThreshold: 5,
    defaultLink: function () { return makeLink(connType); },
    validateConnection: function (cvS, mS, cvT, mT) {
      if (cvS === cvT) return false;
      return cvT && cvT.model && cvT.model.isElement() && cvT.model.get('type') !== 'ad.Zone';
    },
    validateMagnet: function (cellView, magnet) {
      return magnet.getAttribute('magnet') === 'active';
    }
  });

  function resize() { paper.setDimensions(paperEl.clientWidth, paperEl.clientHeight); }
  window.addEventListener('resize', resize);

  // Connectors
  const ARROW = { type: 'path', d: 'M 10 -5 0 0 10 5 z', fill: '#5b6472', stroke: '#5b6472' };
  const NONE  = { type: 'none' };
  function makeLink(type) {
    const line = {
      stroke: '#5b6472', strokeWidth: 2,
      strokeDasharray: '', sourceMarker: NONE,
      targetMarker: joint.util.cloneDeep(ARROW)
    };
    if (type === 'dashed') { line.strokeDasharray = '7 5'; }
    else if (type === 'bidir') { line.sourceMarker = joint.util.cloneDeep(ARROW); }
    else if (type === 'thick') { line.strokeWidth = 5; line.targetMarker = NONE; line.stroke = '#475569'; }
    const lk = new joint.shapes.standard.Link({ attrs: { line: line } });
    // 'ortho' = right-angle (Manhattan) routing - classic enterprise style.
    lk.router(type === 'ortho'
      ? { name: 'manhattan', args: { padding: 16, step: GRID } }
      : { name: 'normal' });
    lk.prop('adType', type);
    return lk;
  }
  function styleSelectedLink(type) {
    if (selectedView && selectedView.model && selectedView.model.isLink && selectedView.model.isLink()) {
      const m = selectedView.model;
      const fresh = makeLink(type);
      m.attr('line', fresh.attr('line'));
      m.router(fresh.router());
      m.prop('adType', type);
    }
  }
  document.querySelectorAll('.ad-conn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      connType = btn.dataset.conn;
      document.querySelectorAll('.ad-conn').forEach(function (b) { b.classList.toggle('is-on', b === btn); });
      styleSelectedLink(connType);
    });
  });

  // Create + place shapes
  function placeElement(el, lx, ly, opts) {
    opts = opts || {};
    const sz = el.size();
    let px = lx - sz.width / 2, py = ly - sz.height / 2;
    if (snapEnabled) { px = Math.round(px / GRID) * GRID; py = Math.round(py / GRID) * GRID; }
    el.position(px, py);
    el.addTo(graph);
    if (opts.back) el.toBack();
    return el;
  }
  // How a palette item materialises when dropped: 'icon' = compact appliance
  // glyph with a caption (SystemNode); 'card' = the polished accent-bordered
  // card (icon + bold title + description) the templates use - so a user can
  // hand-build the same professional icon+text look. Flow shapes ignore this.
  let dropStyle = 'icon';
  document.querySelectorAll('.ad-seg-btn[data-drop]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      dropStyle = btn.dataset.drop;
      document.querySelectorAll('.ad-seg-btn[data-drop]').forEach(function (b) {
        b.classList.toggle('is-on', b === btn);
      });
    });
  });
  function dropShape(id, lx, ly) {
    const sys = SYS[id];
    if (!sys) return;
    let el;
    if (dropStyle === 'card' && !sys.flow) {
      // label becomes the title; a placeholder description invites an edit.
      el = makeCard(sys.label, 'Description', sys.accent, id);   // ports applied inside
    } else {
      el = sys.flow ? makeFlow(id) : makeSystem(id);
      applyPorts(el);
    }
    return placeElement(el, lx, ly);
  }
  function centerLocal() {
    const r = paperEl.getBoundingClientRect();
    return paper.clientToLocalPoint(r.left + paperEl.clientWidth / 2, r.top + paperEl.clientHeight / 2);
  }
  function dropAtCenter(id) { const c = centerLocal(); dropShape(id, c.x, c.y); }

  // Drag-and-drop from palette
  wrap.addEventListener('dragover', function (e) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; wrap.classList.add('is-dragover'); });
  wrap.addEventListener('dragleave', function (e) { if (e.target === wrap) wrap.classList.remove('is-dragover'); });
  wrap.addEventListener('drop', function (e) {
    e.preventDefault();
    wrap.classList.remove('is-dragover');
    const id = e.dataTransfer.getData('text/ad-shape');
    if (!id) return;
    const p = paper.clientToLocalPoint(e.clientX, e.clientY);
    dropShape(id, p.x, p.y);
  });

  // Toolbar: add Text / Zone
  document.getElementById('adAddText').addEventListener('click', function () {
    const c = centerLocal();
    placeElement(new TextNode(), c.x, c.y);
  });
  document.getElementById('adAddZone').addEventListener('click', function () {
    const c = centerLocal();
    const zone = new ZoneNode();
    zone.attr('label/text', 'Zone');   // identify the dashed box on the canvas
    placeElement(zone, c.x, c.y, { back: true });
  });

  // Toolbar: add Card / Container / Section / Caption (the richer blocks)
  document.getElementById('adAddCard').addEventListener('click', function () {
    const c = centerLocal(); placeElement(makeCard(), c.x, c.y);
  });
  document.getElementById('adAddContainer').addEventListener('click', function () {
    const c = centerLocal(); placeElement(makeContainer(), c.x, c.y, { back: true });
  });
  document.getElementById('adAddSection').addEventListener('click', function () {
    const c = centerLocal(); placeElement(makeSection('Section'), c.x, c.y);
  });
  document.getElementById('adAddCaption').addEventListener('click', function () {
    const c = centerLocal(); placeElement(makeCaption('Caption - double-click to edit.'), c.x, c.y);
  });

  // Toolbar: insert a connector legend. Production diagrams carry a legend
  // so a reader never has to guess what a line style means. Placed to the
  // right of the existing content (or at the canvas origin when empty);
  // built from ordinary cells so it stays fully editable and exports as-is.
  document.getElementById('adAddLegend').addEventListener('click', function () {
    const bbox = graph.getBBox();
    const x0 = bbox ? Math.round((bbox.x + bbox.width + 60) / GRID) * GRID : 80;
    const y0 = bbox ? Math.round(bbox.y / GRID) * GRID : 80;
    const zone = new ZoneNode();
    zone.resize(300, 190);
    zone.position(x0, y0);
    zone.attr('label/text', 'Legend');
    zone.addTo(graph);
    zone.toBack();
    [
      { type: 'solid',  text: 'Synchronous call' },
      { type: 'dashed', text: 'Async / event-driven' },
      { type: 'bidir',  text: 'Bidirectional traffic' },
      { type: 'thick',  text: 'Bulk data flow' }
    ].forEach(function (row, i) {
      const y = y0 + 52 + i * 32;
      const lk = makeLink(row.type);
      lk.source({ x: x0 + 18, y: y });
      lk.target({ x: x0 + 92, y: y });
      lk.addTo(graph);
      const txt = new TextNode();
      txt.resize(180, 24);
      txt.attr('label/text', row.text);
      txt.attr('label/fontSize', 12);
      txt.attr('label/textAnchor', 'start');
      txt.attr('label/x', 6);
      txt.position(x0 + 100, y - 12);
      txt.addTo(graph);
    });
  });

  // ===================================================================
  //  Starter templates - generic, fully editable scaffolds (NOT tied to
  //  any one system). They drop a colour-coded skeleton you rename in
  //  place: every box edits on double-click, every arrow re-styles. A
  //  varied accent palette keeps tiers visually distinct.
  // ===================================================================
  const TPL = {
    blue: '#2563eb', indigo: '#4f46e5', teal: '#0d9488', purple: '#7c3aed',
    red: '#b91c1c', amber: '#d97706', green: '#15803d', grey: '#475569'
  };

  // A builder handed to each template: helpers position/size a shape and
  // record it, plus links and parent->child embeds (applied after add).
  function builder() {
    const cells = [], embeds = [];
    function put(el, x, y, w, h) { if (w) el.resize(w, h); el.position(x, y); cells.push(el); return el; }
    return {
      cells: cells, embeds: embeds,
      section:   function (t, x, y, w, c)          { return put(makeSection(t, c || TPL.grey), x, y, w || 210, 24); },
      // `ic` (optional): a palette icon id ('server', 'sqldb', 'lb', ...)
      // rendered inside the card next to the text.
      card:      function (t, d, x, y, w, h, c, ic) { return put(makeCard(t, d, c || TPL.blue, ic), x, y, w || 200, h || 72); },
      container: function (t, d, x, y, w, h, c)    { return put(makeContainer(t, d, c || TPL.grey), x, y, w || 460, h || 300); },
      caption:   function (t, x, y, w, c)          { return put(makeCaption(t, c || TPL.grey), x, y, w || 680, 46); },
      // Templates use text shapes only (cards / containers / sections) -
      // icon appliances stay available from the palette for manual use.
      link:      function (s, t, type, c) {
        const lk = makeLink(type || 'solid');
        lk.source({ id: s.id }); lk.target({ id: t.id });
        if (c) recolorCell(lk, c);
        cells.push(lk); return lk;
      },
      embed: function (parent, child) { embeds.push([parent, child]); return child; }
    };
  }

  const TEMPLATES = {
    tier3: { label: '3-Tier Web App', title: 'Three-Tier Web Application', build: function (b) {
      b.section('Clients', 0, 36, 210);
      const web = b.card('Web Browser', 'Desktop users', 0, 66, 210, 66, TPL.blue, 'browser');
      const mob = b.card('Mobile App', 'iOS / Android', 0, 150, 210, 66, TPL.blue, 'mobile');
      const box = b.container('Application Tier', '(HTTPS - load-balanced)', 300, 30, 470, 360, TPL.indigo);
      const lb  = b.card('Load Balancer', 'Distributes traffic', 320, 86, 430, 50, TPL.teal, 'lb');
      const ws  = b.card('Web Server', 'Static + routing', 320, 150, 205, 58, TPL.indigo, 'webserver');
      const as  = b.card('App Server', 'Business logic', 545, 150, 205, 58, TPL.indigo, 'appserver');
      const ch  = b.card('Cache', 'In-memory store', 320, 222, 205, 58, TPL.purple, 'cache');
      const au  = b.card('Auth Service', 'Identity & tokens', 545, 222, 205, 58, TPL.red, 'iam');
      const api = b.card('API Layer', 'REST / GraphQL', 320, 294, 430, 50, TPL.amber, 'api');
      [lb, ws, as, ch, au, api].forEach(function (c) { b.embed(box, c); });
      b.section('Data Tier', 840, 36, 240);
      const db  = b.card('Primary Database', 'SQL store', 840, 66, 240, 70, TPL.purple, 'sqldb');
      const rep = b.card('Replica / DR', 'Read-only standby', 840, 158, 240, 70, TPL.purple, 'dbrepl');
      b.link(web, box, 'solid', TPL.blue);
      b.link(mob, box, 'solid', TPL.blue);
      b.link(box, db, 'solid', TPL.purple);
      b.link(db, rep, 'dashed', TPL.grey);
      b.caption('Edit any box (double-click - first line is the title, the rest is the description). Drag from a node edge to connect; recolour from the toolbar swatches.', 150, 430, 760);
    }},

    micro: { label: 'Microservices / API', title: 'Microservices Architecture', build: function (b) {
      b.section('Clients', 0, 36, 210);
      const cl = b.card('Web / Mobile', 'Front-end clients', 0, 66, 210, 66, TPL.blue, 'browser');
      const box = b.container('Services', '(behind API gateway)', 300, 30, 470, 360, TPL.grey);
      const gw  = b.card('API Gateway', 'Routing - auth - rate-limit', 320, 86, 430, 50, TPL.amber, 'apigw');
      const s1  = b.card('Service A', 'Bounded context', 320, 150, 135, 58, TPL.indigo, 'container');
      const s2  = b.card('Service B', 'Bounded context', 467, 150, 135, 58, TPL.teal, 'container');
      const s3  = b.card('Service C', 'Bounded context', 614, 150, 136, 58, TPL.purple, 'container');
      const bus = b.card('Message Bus', 'Async events / queue', 320, 222, 430, 50, TPL.red, 'queue');
      const mesh = b.card('Service Mesh', 'mTLS - observability', 320, 286, 430, 50, TPL.green, 'mesh');
      [gw, s1, s2, s3, bus, mesh].forEach(function (c) { b.embed(box, c); });
      b.section('Data Stores', 840, 36, 240);
      const d1 = b.card('Service DB', 'Per-service store', 840, 66, 240, 64, TPL.purple, 'sqldb');
      const d2 = b.card('Cache', 'Low-latency reads', 840, 150, 240, 64, TPL.teal, 'cache');
      const d3 = b.card('Object Storage', 'Files & blobs', 840, 234, 240, 64, TPL.amber, 'object');
      b.link(cl, gw, 'solid', TPL.blue);
      b.link(s1, d1, 'solid', TPL.purple);
      b.link(s2, d2, 'solid', TPL.teal);
      b.link(s3, d3, 'solid', TPL.amber);
      b.caption('A generic microservices skeleton - rename services and stores to fit your domain. Dashed connectors read as asynchronous / event-driven flows.', 150, 430, 760);
    }},

    pipeline: { label: 'Data Pipeline (ETL)', title: 'Data Pipeline', build: function (b) {
      b.section('Sources', 0, 36, 210);
      const o1 = b.card('Operational DB', 'Transactional source', 0, 66, 210, 60, TPL.blue, 'sqldb');
      const o2 = b.card('Event Stream', 'Real-time feed', 0, 138, 210, 60, TPL.teal, 'pubsub');
      const o3 = b.card('Flat Files', 'Batch extracts', 0, 210, 210, 60, TPL.amber, 'flatfile');
      const box = b.container('Processing', '(orchestrated pipeline)', 300, 30, 440, 300, TPL.indigo);
      const ing = b.card('Ingestion', 'Land raw data', 320, 86, 400, 50, TPL.blue, 'etl');
      const tr  = b.card('Transform / Clean', 'Normalise & enrich', 320, 150, 400, 50, TPL.indigo, 'workflow');
      const val = b.card('Validation', 'Quality & dedupe', 320, 214, 195, 50, TPL.red, 'uptime');
      const orc = b.card('Orchestration', 'Schedule & retry', 525, 214, 195, 50, TPL.purple, 'jobsched');
      [ing, tr, val, orc].forEach(function (c) { b.embed(box, c); });
      b.section('Serving', 810, 36, 240);
      const dw = b.card('Data Warehouse', 'Curated tables', 810, 66, 240, 60, TPL.purple, 'warehouse');
      const bi = b.card('BI / Dashboards', 'Reports & analytics', 810, 138, 240, 60, TPL.green, 'reportsrv');
      const ml = b.card('ML / Models', 'Feature store', 810, 210, 240, 60, TPL.amber, 'bot');
      b.link(o1, box, 'solid', TPL.blue);
      b.link(o2, box, 'dashed', TPL.teal);
      b.link(o3, box, 'solid', TPL.amber);
      b.link(box, dw, 'solid', TPL.purple);
      b.link(dw, bi, 'solid', TPL.green);
      b.link(dw, ml, 'solid', TPL.amber);
      b.caption('Sources flow left-to-right through processing into the serving layer. Swap labels for your own systems; use the thick connector for high-volume data flows.', 130, 360, 780);
    }},

    hubspoke: { label: 'Cloud Hub & Spoke', title: 'Cloud Hub & Spoke Network', build: function (b) {
      b.section('On-Premises', 0, 36, 210);
      const dc = b.card('Corporate DC', 'Private network', 0, 66, 210, 70, TPL.grey, 'onprem');
      const hub = b.container('Hub VNet', '(shared connectivity)', 300, 30, 440, 250, TPL.indigo);
      const vpn = b.card('VPN / ExpressRoute', 'Hybrid link', 320, 86, 400, 48, TPL.blue, 'vpngw');
      const fw  = b.card('Firewall', 'North-south inspection', 320, 146, 195, 48, TPL.red, 'firewall');
      const bas = b.card('Bastion', 'Secure admin access', 525, 146, 195, 48, TPL.amber, 'bastion');
      const shr = b.card('Shared Services', 'DNS - identity', 320, 206, 400, 48, TPL.teal, 'dns');
      [vpn, fw, bas, shr].forEach(function (c) { b.embed(hub, c); });
      b.section('Spoke Networks', 810, 36, 250);
      const sp1 = b.container('Spoke - Production', '', 810, 64, 250, 110, TPL.green);
      const w1  = b.card('Workloads', 'App & data tiers', 826, 102, 218, 56, TPL.green, 'server');
      b.embed(sp1, w1);
      const sp2 = b.container('Spoke - Non-Prod', '', 810, 190, 250, 110, TPL.purple);
      const w2  = b.card('Workloads', 'Dev / test / UAT', 826, 228, 218, 56, TPL.purple, 'server');
      b.embed(sp2, w2);
      b.link(dc, vpn, 'solid', TPL.grey);
      b.link(hub, sp1, 'bidir', TPL.green);
      b.link(hub, sp2, 'bidir', TPL.purple);
      b.caption('A hub-and-spoke landing zone: shared connectivity & security live in the hub; each spoke holds isolated workloads. Bidirectional links show peered traffic.', 130, 340, 780);
    }},

    cleanup: { label: 'Source -> Clean-up', title: 'Source-to-Clean-up Reconciliation', build: function (b) {
      // Source / destination systems feed a central application; reviewed
      // fixes flow out to a validation-then-production clean-up lane.
      b.section('Source Systems', 0, 36, 210);
      const src = b.card('Source System', 'Reference data feed', 0, 66, 210, 64, TPL.blue, 'server');
      b.section('Destination Systems', 0, 150, 210);
      const sor  = b.card('System of Record', 'Primary store', 0, 180, 210, 60, TPL.red, 'sqldb');
      const repo = b.card('Data Repository', 'Secondary store', 0, 252, 210, 60, TPL.red, 'nosql');
      const file = b.card('File Extracts', 'Batch / file mode', 0, 324, 210, 60, TPL.amber, 'flatfile');

      const box = b.container('Reconciliation Application', '(web app - corporate network - HTTPS)', 300, 30, 470, 380, TPL.red);
      const ui  = b.card('Web Interface', 'Select scope & run comparison', 320, 90, 430, 50, TPL.blue, 'browser');
      const cfg = b.card('Configuration', 'Per-item rules & modes', 320, 154, 205, 58, TPL.indigo, 'iac');
      const con = b.card('Connectivity Layer', 'Reads source & destination', 545, 154, 205, 58, TPL.teal, 'esb');
      const eng = b.card('Comparison Engine', 'Missing / mismatch detection', 320, 226, 430, 50, TPL.purple, 'cpu');
      const rep = b.card('Discrepancy Report', 'Summary & detail output', 320, 290, 205, 56, TPL.green, 'reportsrv');
      const fix = b.card('Solution / Fix File', 'Review-ready fix actions', 545, 290, 205, 56, TPL.amber, 'flatfile');
      [ui, cfg, con, eng, rep, fix].forEach(function (c) { b.embed(box, c); });

      b.section('Clean-up', 840, 36, 240);
      const val  = b.card('Validation Instance', 'Apply & re-test fix', 840, 66, 240, 70, TPL.green, 'uptime');
      const prod = b.card('Production', 'Clean-up applied', 840, 160, 240, 70, TPL.red, 'server');

      b.link(src,  box,  'solid', TPL.blue);
      b.link(sor,  box,  'solid', TPL.red);
      b.link(repo, box,  'solid', TPL.red);
      b.link(file, box,  'solid', TPL.amber);
      b.link(box,  val,  'solid', TPL.green);
      b.link(val,  prod, 'solid', TPL.grey);
      b.caption('Source & destination systems are read over HTTPS and compared; discrepancies are reported and fix files emitted for review. Fixes are validated, then applied for clean-up - generic placeholders you rename per engagement.', 150, 440, 760);
    }},

    dmz: { label: 'Secure DMZ + Firewalls', title: 'Secure Web Application (DMZ)', build: function (b) {
      // Classic perimeter design: untrusted traffic crosses a firewall/WAF
      // into the DMZ, then a second firewall guards the trusted zone.
      b.section('Public Internet', 0, 66, 210);
      const usr = b.card('Users / Internet', 'Untrusted clients', 0, 96, 210, 70, TPL.blue, 'internet');
      const fw1 = b.card('Perimeter Firewall', 'Ingress filtering', 250, 96, 150, 72, TPL.red, 'firewall');
      const dmz = b.container('DMZ (Perimeter Network)', '', 410, 30, 300, 240, TPL.amber);
      const rp  = b.card('Reverse Proxy / WAF', 'TLS termination & filtering', 430, 86, 260, 56, TPL.amber, 'waf');
      const web = b.card('Web / Presentation', 'Public-facing tier', 430, 158, 260, 56, TPL.indigo, 'webserver');
      b.embed(dmz, rp); b.embed(dmz, web);
      const fw2 = b.card('Internal Firewall', 'Zone segmentation', 740, 120, 140, 72, TPL.red, 'firewall');
      const inz = b.container('Trusted / Internal Zone', '', 890, 30, 320, 300, TPL.green);
      const app = b.card('Application Server', 'Business logic', 910, 86, 280, 50, TPL.indigo, 'appserver');
      const iam = b.card('Identity / IAM', 'AuthN & AuthZ', 910, 144, 280, 50, TPL.purple, 'iam');
      const db  = b.card('Database', 'Encrypted at rest', 910, 202, 280, 50, TPL.teal, 'sqldb');
      const mon = b.card('Monitoring / SIEM', 'Logging & alerts', 910, 260, 280, 46, TPL.grey, 'logging');
      [app, iam, db, mon].forEach(function (c) { b.embed(inz, c); });
      b.link(usr, fw1, 'solid', TPL.blue);
      b.link(fw1, rp,  'solid', TPL.red);
      b.link(web, fw2, 'solid', TPL.indigo);
      b.link(fw2, app, 'solid', TPL.red);
      b.link(app, db,  'solid', TPL.teal);
      b.caption('Untrusted traffic passes a perimeter firewall / WAF into the DMZ, then a second firewall segments the trusted internal zone (defence in depth). Rename tiers to fit your estate.', 130, 380, 880);
    }},

    zerotrust: { label: 'Zero-Trust Access', title: 'Zero-Trust Network Access', build: function (b) {
      // No implicit network trust: every request is brokered and evaluated
      // by the policy plane before reaching a resource.
      b.section('Users & Devices', 0, 56, 210);
      const usr  = b.card('User + Device', 'Verified each request', 0, 86, 210, 70, TPL.blue, 'enduser');
      const ztna = b.card('ZTNA Broker', 'Access gateway', 250, 88, 130, 66, TPL.red, 'bastion');
      const pep  = b.container('Policy Enforcement', '(verify every request)', 400, 24, 320, 250, TPL.purple);
      const idp  = b.card('Identity Provider', 'SSO - MFA', 420, 84, 280, 52, TPL.indigo, 'iam');
      const pe   = b.card('Policy Engine', 'Risk & context decisions', 420, 144, 280, 52, TPL.purple, 'workflow');
      const dev  = b.card('Device Posture', 'Health & compliance', 420, 204, 280, 52, TPL.teal, 'antivirus');
      [idp, pe, dev].forEach(function (c) { b.embed(pep, c); });
      const res  = b.container('Protected Resources', '', 790, 24, 320, 250, TPL.green);
      const ia   = b.card('Internal Apps', 'Private workloads', 810, 84, 280, 52, TPL.indigo, 'appserver');
      const saas = b.card('SaaS / Cloud', 'External services', 810, 144, 280, 52, TPL.amber, 'cloud');
      const data = b.card('Data Stores', 'Least-privilege access', 810, 204, 280, 52, TPL.teal, 'sqldb');
      [ia, saas, data].forEach(function (c) { b.embed(res, c); });
      b.link(usr, ztna, 'solid', TPL.blue);
      b.link(ztna, pep, 'solid', TPL.red);
      b.link(pep, res,  'solid', TPL.green);
      b.caption('Zero-trust: every request is authenticated, authorised and continuously verified by the policy plane before it reaches a resource - there is no implicit network trust.', 150, 320, 820);
    }},

    serverless: { label: 'Cloud Serverless Web App', title: 'Cloud-Native Serverless Web Application', build: function (b) {
      b.section('Clients', 0, 36, 210);
      const cl  = b.card('Web / Mobile App', 'SPA + native clients', 0, 86, 210, 70, TPL.blue, 'browser');
      const edge = b.container('Edge', '(global entry)', 270, 30, 200, 250, TPL.teal);
      const cdn = b.card('CDN', 'Static assets & cache', 286, 86, 168, 56, TPL.teal, 'cdn');
      const waf = b.card('WAF', 'L7 threat filtering', 286, 158, 168, 56, TPL.red, 'waf');
      b.embed(edge, cdn); b.embed(edge, waf);
      const plat = b.container('Serverless Platform', '(managed - scale-to-zero - pay-per-use)', 530, 30, 470, 350, TPL.indigo);
      const gw  = b.card('API Gateway', 'AuthN - throttle - route', 550, 86, 430, 50, TPL.amber, 'apigw');
      const f1  = b.card('Function: API', 'Synchronous business logic', 550, 150, 205, 58, TPL.indigo, 'serverless');
      const f2  = b.card('Function: Worker', 'Async / background jobs', 775, 150, 205, 58, TPL.purple, 'serverless');
      const q   = b.card('Queue / Event Bus', 'Decouples API from workers', 550, 222, 430, 48, TPL.red, 'queue');
      const idp = b.card('Managed Identity', 'Sign-in - tokens - MFA', 550, 284, 430, 48, TPL.green, 'iam');
      [gw, f1, f2, q, idp].forEach(function (c) { b.embed(plat, c); });
      b.section('Managed Data', 1060, 36, 240);
      const db  = b.card('Serverless Database', 'Auto-scaling store', 1060, 66, 240, 62, TPL.purple, 'sqldb');
      const obj = b.card('Object Storage', 'Files - media - exports', 1060, 146, 240, 62, TPL.amber, 'object');
      const mon = b.card('Monitoring', 'Logs - traces - alarms', 1060, 226, 240, 62, TPL.green, 'metrics');
      b.link(cl, cdn, 'solid', TPL.blue);
      b.link(cdn, waf, 'solid', TPL.teal);
      b.link(waf, gw, 'solid', TPL.red);
      b.link(gw, f1, 'solid', TPL.indigo);
      b.link(f1, q, 'dashed', TPL.red);
      b.link(q, f2, 'dashed', TPL.red);
      b.link(f1, db, 'solid', TPL.purple);
      b.link(f2, obj, 'solid', TPL.amber);
      b.link(plat, mon, 'dashed', TPL.grey);
      b.caption('A fully managed, pay-per-use stack: the CDN serves static assets, the API gateway fronts short-lived functions, and queues decouple async work. Rename to your provider\'s services (Lambda / Cloud Functions / Azure Functions...).', 200, 430, 820);
    }},

    k8splat: { label: 'Kubernetes Platform', title: 'Kubernetes Container Platform', build: function (b) {
      b.section('Traffic', 0, 36, 210);
      const usr = b.card('Users / Clients', 'External traffic', 0, 66, 210, 64, TPL.blue, 'enduser');
      const lb  = b.card('Cloud Load Balancer', 'L4 entry point', 0, 150, 210, 64, TPL.teal, 'lb');
      const clu = b.container('Kubernetes Cluster', '(multi-node - self-healing - declarative)', 300, 30, 500, 360, TPL.indigo);
      const ing = b.card('Ingress Controller', 'TLS - host / path routing', 320, 86, 460, 50, TPL.amber, 'apigw');
      const s1  = b.card('Deployment A', 'Pods - replicas - HPA', 320, 150, 145, 58, TPL.indigo, 'container');
      const s2  = b.card('Deployment B', 'Pods - replicas - HPA', 478, 150, 145, 58, TPL.teal, 'container');
      const s3  = b.card('Deployment C', 'Pods - replicas - HPA', 635, 150, 145, 58, TPL.purple, 'container');
      const cfg = b.card('Config & Secrets', 'ConfigMaps - sealed secrets', 320, 222, 225, 50, TPL.red, 'secrets');
      const msh = b.card('Service Mesh', 'mTLS - retries - telemetry', 555, 222, 225, 50, TPL.green, 'mesh');
      const opr = b.card('Platform Add-ons', 'DNS - cert-manager - autoscaler', 320, 286, 460, 48, TPL.grey, 'k8s');
      [ing, s1, s2, s3, cfg, msh, opr].forEach(function (c) { b.embed(clu, c); });
      b.section('Supply Chain & State', 870, 36, 260);
      const reg  = b.card('Container Registry', 'Signed, scanned images', 870, 66, 250, 60, TPL.amber, 'container');
      const gits = b.card('CI/CD (GitOps)', 'Build -> scan -> sync', 870, 142, 250, 60, TPL.blue, 'cicd');
      const db   = b.card('Managed Database', 'State lives outside pods', 870, 218, 250, 60, TPL.purple, 'sqldb');
      const obs  = b.card('Observability', 'Metrics - logs - traces', 870, 294, 250, 60, TPL.green, 'metrics');
      b.link(usr, lb, 'solid', TPL.blue);
      b.link(lb, ing, 'solid', TPL.teal);
      b.link(gits, reg, 'solid', TPL.blue);
      b.link(reg, clu, 'dashed', TPL.amber);
      b.link(s2, db, 'solid', TPL.purple);
      b.link(clu, obs, 'dashed', TPL.green);
      b.caption('Workloads run as declarative deployments behind an ingress; images arrive from CI/CD through the registry (GitOps pull), and state lives in managed services outside the cluster.', 180, 440, 800);
    }},

    eventdrv: { label: 'Event-Driven / Streaming', title: 'Event-Driven Streaming Architecture', build: function (b) {
      b.section('Producers', 0, 36, 210);
      const p1 = b.card('Microservices', 'Domain events', 0, 66, 210, 60, TPL.indigo, 'container');
      const p2 = b.card('CDC / Databases', 'Change data capture', 0, 142, 210, 60, TPL.purple, 'sqldb');
      const p3 = b.card('IoT / Edge', 'Telemetry streams', 0, 218, 210, 60, TPL.teal, 'iot');
      const brk = b.container('Event Backbone', '(Kafka / Pub-Sub - partitioned - replayable)', 300, 30, 440, 290, TPL.red);
      const t1  = b.card('Topics / Streams', 'Ordered, durable event log', 320, 86, 400, 54, TPL.red, 'queue');
      const sch = b.card('Schema Registry', 'Contracts & compatibility', 320, 154, 400, 50, TPL.amber, 'flatfile');
      const dlq = b.card('Dead-Letter Queue', 'Poison-message isolation', 320, 218, 400, 50, TPL.grey, 'queue');
      [t1, sch, dlq].forEach(function (c) { b.embed(brk, c); });
      const sp = b.card('Stream Processing', 'Windowing - joins - enrichment', 300, 360, 440, 56, TPL.indigo, 'etl');
      b.section('Consumers', 810, 36, 240);
      const c1 = b.card('Downstream Services', 'React to events', 810, 66, 240, 60, TPL.indigo, 'container');
      const c2 = b.card('Real-time Analytics', 'Dashboards - alerting', 810, 142, 240, 60, TPL.green, 'metrics');
      const c3 = b.card('Data Lake / Warehouse', 'Cold path - full history', 810, 218, 240, 60, TPL.purple, 'warehouse');
      b.link(p1, brk, 'dashed', TPL.indigo);
      b.link(p2, brk, 'dashed', TPL.purple);
      b.link(p3, brk, 'dashed', TPL.teal);
      b.link(brk, c1, 'dashed', TPL.indigo);
      b.link(brk, c2, 'dashed', TPL.green);
      b.link(brk, sp, 'thick', TPL.red);
      b.link(sp, c3, 'thick', TPL.purple);
      b.caption('Producers publish immutable events to a durable, replayable backbone; consumers subscribe independently (dashed = async). Stream processors serve the hot path while the lake keeps history.', 130, 460, 800);
    }},

    cicd: { label: 'CI/CD DevOps Pipeline', title: 'CI/CD DevOps Pipeline', build: function (b) {
      b.section('Source', 0, 36, 200);
      const dev = b.card('Developers', 'Feature branches + PRs', 0, 66, 200, 64, TPL.blue, 'developer');
      const scm = b.card('Git Repository', 'Code review - protected main', 0, 150, 200, 64, TPL.grey, 'iac');
      const ci  = b.container('Continuous Integration', '(runs on every commit)', 280, 30, 420, 250, TPL.indigo);
      const bld = b.card('Build & Unit Tests', 'Compile - test - coverage gate', 300, 86, 380, 50, TPL.indigo, 'cicd');
      const sec = b.card('Security Scans', 'SAST - dependencies - secrets', 300, 150, 380, 50, TPL.red, 'antivirus');
      const art = b.card('Artifact / Image', 'Versioned & signed', 300, 214, 380, 48, TPL.amber, 'container');
      [bld, sec, art].forEach(function (c) { b.embed(ci, c); });
      const cd  = b.container('Continuous Delivery', '(promote the same artifact)', 770, 30, 430, 250, TPL.green);
      const dv  = b.card('Dev / QA', 'Auto-deploy + smoke tests', 790, 86, 390, 50, TPL.teal, 'server');
      const stg = b.card('Staging', 'Integration & performance', 790, 150, 390, 50, TPL.amber, 'server');
      const prd = b.card('Production', 'Approval gate - canary / blue-green', 790, 214, 390, 48, TPL.red, 'server');
      [dv, stg, prd].forEach(function (c) { b.embed(cd, c); });
      const mon = b.card('Monitoring & Rollback', 'Health - alerts - auto-rollback', 770, 330, 430, 54, TPL.purple, 'alert');
      b.link(dev, scm, 'solid', TPL.blue);
      b.link(scm, ci, 'solid', TPL.grey);
      b.link(ci, cd, 'solid', TPL.indigo);
      b.link(prd, mon, 'dashed', TPL.purple);
      b.caption('Commits flow through automated build, test and security gates into one versioned artifact, promoted unchanged through environments - production sits behind an approval gate with canary / rollback.', 150, 440, 820);
    }},

    dr: { label: 'DR - Active / Passive', title: 'Disaster Recovery (Active-Passive)', build: function (b) {
      const gdns = b.card('Global DNS / Traffic Manager', 'Health checks - failover routing', 330, 0, 400, 56, TPL.amber, 'dns');
      const pri  = b.container('Primary Region (Active)', '(serves all traffic)', 60, 120, 420, 310, TPL.green);
      const lb1  = b.card('Load Balancer', 'Public entry', 80, 176, 380, 48, TPL.teal, 'lb');
      const ap1  = b.card('Application Tier', 'Full capacity', 80, 238, 380, 52, TPL.indigo, 'appserver');
      const db1  = b.card('Primary Database', 'Read / write', 80, 304, 380, 52, TPL.purple, 'sqldb');
      const bkp  = b.card('Backups', 'Point-in-time - offsite copy', 80, 370, 380, 44, TPL.grey, 'backup');
      [lb1, ap1, db1, bkp].forEach(function (c) { b.embed(pri, c); });
      const drz  = b.container('DR Region (Passive / Standby)', '(pilot-light - promoted on failover)', 580, 120, 420, 310, TPL.grey);
      const lb2  = b.card('Load Balancer', 'Idle until failover', 600, 176, 380, 48, TPL.teal, 'lb');
      const ap2  = b.card('Application Tier', 'Minimal footprint - scales up on failover', 600, 238, 380, 52, TPL.indigo, 'appserver');
      const db2  = b.card('Replica Database', 'Async replication - promote to primary', 600, 304, 380, 52, TPL.purple, 'dbrepl');
      const run  = b.card('Runbook / Automation', 'Tested failover procedure', 600, 370, 380, 44, TPL.red, 'bot');
      [lb2, ap2, db2, run].forEach(function (c) { b.embed(drz, c); });
      b.link(gdns, pri, 'solid', TPL.green);
      b.link(gdns, drz, 'dashed', TPL.grey);
      b.link(db1, db2, 'dashed', TPL.purple);
      b.caption('Traffic normally routes to the active region; the database replicates asynchronously to a scaled-down standby. On failure, DNS fails over and the standby is promoted - state your RPO / RTO targets here and rehearse the runbook.', 130, 470, 840);
    }},

    soa: { label: 'Enterprise Integration (API-led)', title: 'Enterprise Integration - API-led Layers', build: function (b) {
      b.section('Consumers', 0, 0, 240);
      const web = b.card('Web Portal', 'Customer channel', 0, 30, 240, 60, TPL.blue, 'browser');
      const mob = b.card('Mobile App', 'Field / customer channel', 280, 30, 240, 60, TPL.teal, 'mobile');
      const prt = b.card('Partners / B2B', 'External integrations', 560, 30, 240, 60, TPL.amber, 'partner');
      const exp = b.container('Experience APIs', '(per-channel shaping - no business logic)', 0, 130, 800, 110, TPL.indigo);
      const ex1 = b.card('Web BFF', 'Aggregated views', 20, 182, 240, 52, TPL.indigo, 'api');
      const ex2 = b.card('Mobile BFF', 'Lean payloads', 280, 182, 240, 52, TPL.indigo, 'api');
      const ex3 = b.card('Partner API', 'Contracted - rate-limited', 540, 182, 240, 52, TPL.indigo, 'api');
      [ex1, ex2, ex3].forEach(function (c) { b.embed(exp, c); });
      const prc = b.container('Process APIs / Orchestration', '(business processes - composition - ESB)', 0, 280, 800, 110, TPL.purple);
      const pr1 = b.card('Order Process', 'Cross-system orchestration', 20, 332, 375, 52, TPL.purple, 'workflow');
      const pr2 = b.card('Customer 360', 'Composite views & rules', 405, 332, 375, 52, TPL.purple, 'workflow');
      b.embed(prc, pr1); b.embed(prc, pr2);
      const sys = b.container('System APIs', '(unlock systems of record - isolate change)', 0, 430, 800, 110, TPL.teal);
      const sy1 = b.card('ERP API', '', 20, 482, 180, 52, TPL.teal, 'api');
      const sy2 = b.card('CRM API', '', 220, 482, 180, 52, TPL.teal, 'api');
      const sy3 = b.card('Mainframe API', '', 420, 482, 180, 52, TPL.teal, 'api');
      const sy4 = b.card('Data API', '', 620, 482, 160, 52, TPL.teal, 'api');
      [sy1, sy2, sy3, sy4].forEach(function (c) { b.embed(sys, c); });
      b.section('Systems of Record', 0, 580, 300);
      const erp = b.card('ERP', 'Finance - supply chain', 0, 610, 180, 60, TPL.grey, 'appserver');
      const crm = b.card('CRM', 'Customers - cases', 220, 610, 180, 60, TPL.grey, 'appserver');
      const mf  = b.card('Legacy / Mainframe', 'Core transactions', 440, 610, 180, 60, TPL.grey, 'mainframe');
      const dbs = b.card('Databases', 'Operational stores', 660, 610, 140, 60, TPL.grey, 'sqldb');
      b.link(web, exp, 'solid', TPL.blue);
      b.link(mob, exp, 'solid', TPL.teal);
      b.link(prt, exp, 'solid', TPL.amber);
      b.link(exp, prc, 'solid', TPL.indigo);
      b.link(prc, sys, 'solid', TPL.purple);
      b.link(sy1, erp, 'solid', TPL.grey);
      b.link(sy2, crm, 'solid', TPL.grey);
      b.link(sy3, mf,  'solid', TPL.grey);
      b.link(sy4, dbs, 'solid', TPL.grey);
      b.caption('Classic API-led / SOA layering: experience APIs shape data per channel, process APIs own business logic, system APIs insulate the estate from change in the systems of record.', 60, 700, 700);
    }},

    genai: { label: 'GenAI / RAG Application', title: 'GenAI Application (Retrieval-Augmented Generation)', build: function (b) {
      b.section('Users', 0, 36, 210);
      const usr = b.card('Chat / Copilot UI', 'Web & in-app assistant', 0, 66, 210, 70, TPL.blue, 'browser');
      const app = b.container('AI Application Layer', '(your code - owns the prompt & the data)', 290, 30, 460, 340, TPL.indigo);
      const api = b.card('Chat API', 'Sessions - streaming responses', 310, 86, 420, 48, TPL.blue, 'api');
      const orc = b.card('Orchestrator / Agent', 'Prompt assembly - tool calls - memory', 310, 148, 420, 50, TPL.indigo, 'bot');
      const gua = b.card('Guardrails', 'Input/output policy - PII redaction', 310, 212, 420, 48, TPL.red, 'waf');
      const evl = b.card('Evals & Telemetry', 'Quality - cost - latency tracking', 310, 274, 420, 48, TPL.green, 'metrics');
      [api, orc, gua, evl].forEach(function (c) { b.embed(app, c); });
      const llm = b.card('LLM API (e.g. Claude)', 'Reasoning - generation - tool use', 830, 60, 250, 70, TPL.purple, 'cpu');
      b.section('Knowledge (RAG)', 830, 166, 250);
      const vdb = b.card('Vector Database', 'Semantic search index', 830, 196, 250, 60, TPL.teal, 'nosql');
      const ing = b.card('Ingestion Pipeline', 'Chunk - embed - refresh', 830, 272, 250, 60, TPL.amber, 'etl');
      const src = b.card('Document Sources', 'Wikis - tickets - policies - files', 830, 348, 250, 60, TPL.grey, 'fileshare');
      b.link(usr, api, 'solid', TPL.blue);
      b.link(orc, llm, 'bidir', TPL.purple);
      b.link(orc, vdb, 'solid', TPL.teal);
      b.link(src, ing, 'solid', TPL.grey);
      b.link(ing, vdb, 'solid', TPL.amber);
      b.caption('Retrieval-augmented generation: the orchestrator retrieves relevant chunks from the vector index, assembles them into the prompt and calls the LLM - guardrails and evals wrap every request. The model never stores your data.', 150, 440, 830);
    }}
  };

  function applyTemplate(id) {
    const tpl = TEMPLATES[id];
    if (!tpl) return;
    if (graph.getCells().length &&
        !confirm('Insert the "' + tpl.label + '" template? This replaces the current canvas.')) return;
    clearSelection();
    graph.clear();
    const titleEl = document.getElementById('adTitle');
    if (titleEl) titleEl.value = tpl.title;
    const b = builder();
    tpl.build(b);
    graph.addCells(b.cells);
    b.embeds.forEach(function (pair) { pair[0].embed(pair[1]); });
    clearSelection();
    fit();
  }

  const tplSelect = document.getElementById('adTemplate');
  if (tplSelect) {
    tplSelect.addEventListener('change', function () {
      const id = this.value;
      this.value = '';            // reset so the same template can be re-picked
      if (id) applyTemplate(id);
    });
  }

  // Selection + tools
  // Two layers: `selectedView` (primary click selection) and `multiSel`
  // (a Set of element models picked with the Shift+drag rubber band).
  const multiSel = new Set();

  function highlightModel(model, on) {
    const view = paper.findViewByModel(model);
    if (!view) return;
    try {
      if (on) {
        joint.highlighters.mask.add(view, { selector: 'root' }, 'ad-msel', {
          padding: 4, attrs: { stroke: '#0ea5e9', 'stroke-width': 2, 'stroke-dasharray': '4 2' }
        });
      } else {
        joint.highlighters.mask.remove(view, 'ad-msel');
      }
    } catch (e) {}
  }
  function clearMulti() {
    multiSel.forEach(function (m) { highlightModel(m, false); });
    multiSel.clear();
  }
  function setMulti(models) {
    clearMulti();
    models.forEach(function (m) { multiSel.add(m); highlightModel(m, true); });
  }
  function clearSingle() {
    if (selectedView) {
      try { joint.highlighters.mask.remove(selectedView, 'ad-sel'); } catch (e) {}
      selectedView = null;
    }
  }
  function clearSelection() { clearSingle(); clearMulti(); }
  function allSelectedModels() {
    const out = new Set(multiSel);
    if (selectedView && selectedView.model) out.add(selectedView.model);
    return Array.from(out);
  }
  function select(view) {
    clearSingle();
    // Clicking a member of the rubber-band selection keeps the group (so it
    // can be dragged as one); clicking anything else dissolves it.
    if (!multiSel.has(view.model)) clearMulti();
    selectedView = view;
    try {
      joint.highlighters.mask.add(view, { selector: 'root' }, 'ad-sel', {
        padding: 5, attrs: { stroke: '#2563eb', 'stroke-width': 2, 'stroke-dasharray': '4 2' }
      });
    } catch (e) {}
    // Reflect a selected link's style in the connector toolbar
    if (view.model && view.model.isLink && view.model.isLink()) {
      const t = view.model.prop('adType') || 'solid';
      document.querySelectorAll('.ad-conn').forEach(function (b) { b.classList.toggle('is-on', b.dataset.conn === t); });
    }
  }

  // Dragging one member of a multi-selection moves the whole group.
  let groupMoving = false;
  graph.on('change:position', function (cell, newPos, opt) {
    if (groupMoving || !opt || !opt.ui) return;
    if (!multiSel.has(cell)) return;
    const prev = cell.previous('position');
    const dx = newPos.x - prev.x, dy = newPos.y - prev.y;
    if (!dx && !dy) return;
    groupMoving = true;
    multiSel.forEach(function (m) { if (m !== cell && m.isElement()) m.translate(dx, dy); });
    groupMoving = false;
  });

  // Rubber-band selection (Shift + drag on the blank canvas)
  let band = null;   // { x0,y0,x1,y1 (paper-local), el (overlay div) }
  function drawBand() {
    const p0 = paper.localToClientPoint(band.x0, band.y0);
    const p1 = paper.localToClientPoint(band.x1, band.y1);
    const r  = wrap.getBoundingClientRect();
    band.el.style.left   = (Math.min(p0.x, p1.x) - r.left) + 'px';
    band.el.style.top    = (Math.min(p0.y, p1.y) - r.top)  + 'px';
    band.el.style.width  = Math.abs(p1.x - p0.x) + 'px';
    band.el.style.height = Math.abs(p1.y - p0.y) + 'px';
  }
  function finishBand() {
    const rect = {
      x: Math.min(band.x0, band.x1), y: Math.min(band.y0, band.y1),
      width: Math.abs(band.x1 - band.x0), height: Math.abs(band.y1 - band.y0)
    };
    band.el.remove();
    band = null;
    if (rect.width < 4 && rect.height < 4) return;
    setMulti(graph.findModelsInArea(rect, { strict: false }));
  }
  paper.on('blank:pointerdown', function (evt, x, y) {
    if (!evt.shiftKey) return;
    clearSelection();
    const el = document.createElement('div');
    el.className = 'ad-rubber';
    wrap.appendChild(el);
    band = { x0: x, y0: y, x1: x, y1: y, el: el };
    drawBand();
  });
  paper.on('blank:pointermove', function (evt, x, y) {
    if (!band) return;
    band.x1 = x; band.y1 = y;
    drawBand();
  });
  paper.on('blank:pointerup', function () { if (band) finishBand(); });
  document.addEventListener('mouseup', function () { if (band) finishBand(); });

  // Delete action shared by the red X on elements and links: clears our
  // selection bookkeeping first so no stale view/model survives the removal.
  function removeToolAction(evt, view) {
    if (selectedView === view) clearSingle();
    multiSel.delete(view.model);
    view.model.remove({ ui: true });
  }
  const REMOVE_BTN_MARKUP = [
    { tagName: 'circle', selector: 'button',
      attributes: { r: 9, fill: '#ef4444', stroke: '#ffffff', 'stroke-width': 1.5, cursor: 'pointer' } },
    { tagName: 'path', selector: 'icon',
      attributes: { d: 'M -3.5 -3.5 3.5 3.5 M -3.5 3.5 3.5 -3.5', fill: 'none',
                    stroke: '#ffffff', 'stroke-width': 2, 'pointer-events': 'none' } }
  ];
  // Hover shows only vertices + delete. The arrow-shaped end handles used to
  // re-connect a link (Source/TargetArrowhead) attach ONLY to a selected
  // link - shown on hover they made every fresh one-way link look
  // bidirectional until the mouse moved away.
  const linkTools = function (withArrowheads) {
    // vertexAdding only on the selected toolset: its invisible full-length
    // hit path otherwise swallows plain clicks (so links could never be
    // selected) and added a stray bend point on every click.
    const tools = [new joint.linkTools.Vertices({ vertexAdding: withArrowheads })];
    if (withArrowheads) {
      tools.push(new joint.linkTools.SourceArrowhead());
      tools.push(new joint.linkTools.TargetArrowhead());
    }
    tools.push(new joint.linkTools.Remove({ distance: 20, action: removeToolAction, markup: joint.util.cloneDeep(REMOVE_BTN_MARKUP) }));
    return new joint.dia.ToolsView({
      name: withArrowheads ? 'link-full' : 'link-hover',
      tools: tools
    });
  };
  const elementTools = function () {
    return new joint.dia.ToolsView({ tools: [
      new joint.elementTools.Remove({
        x: '100%', y: 0, offset: { x: 8, y: -8 },
        action: removeToolAction, markup: joint.util.cloneDeep(REMOVE_BTN_MARKUP)
      })
    ]});
  };
  function ensureTools(view) {
    if (view.model.isLink()) {
      const full = selectedView === view;
      if (!view.hasTools(full ? 'link-full' : 'link-hover')) view.addTools(linkTools(full));
    } else if (!view.hasTools()) {
      view.addTools(elementTools());
    }
  }
  paper.on('link:mouseenter', function (lv) { ensureTools(lv); });
  paper.on('link:mouseleave', function (lv) { if (selectedView !== lv) lv.removeTools(); });
  paper.on('element:mouseenter', function (ev) { ensureTools(ev); });
  paper.on('element:mouseleave', function (ev) { if (selectedView !== ev) ev.removeTools(); });
  // Shift / Ctrl / Cmd + click TOGGLES an element in the multi-selection.
  // This is the discoverable way to build a group on a dense canvas (where
  // there is no blank space to start a rubber band), and it's what Align /
  // Distribute need to operate on. Any existing single selection is folded
  // into the group so "click one, Shift-click a second" yields two.
  function toggleMulti(view) {
    const model = view.model;
    if (!model.isElement()) return;
    if (selectedView && selectedView.model && selectedView.model !== model &&
        selectedView.model.isElement()) {
      const prev = selectedView.model;
      clearSingle();
      multiSel.add(prev); highlightModel(prev, true);
    } else {
      clearSingle();
    }
    if (multiSel.has(model)) { multiSel.delete(model); highlightModel(model, false); }
    else                     { multiSel.add(model);    highlightModel(model, true);  }
  }
  paper.on('element:pointerdown', function (ev, evt) {
    if (evt && (evt.shiftKey || evt.ctrlKey || evt.metaKey)) {
      toggleMulti(ev);
      ensureTools(ev);
      return;
    }
    select(ev);
    ensureTools(ev);   // the selected element always carries its delete X
  });
  // Links select on CLICK, not pointerdown: while a link is being drawn the
  // pointer events route through the new link view, and selecting it
  // mid-creation attached the arrow-shaped end handles - which read as a
  // second arrowhead on a brand-new one-way connector. A click is a
  // pointerup whose gesture saw (almost) no mousemoves; creation/reroute
  // drags see many and are skipped.
  paper.on('link:pointerup', function (lv, evt) {
    let moved = 0;
    try { moved = (paper.eventData(evt) || {}).mousemoved || 0; } catch (e) {}
    if (moved > 5) return;
    select(lv);
    ensureTools(lv);
  });
  paper.on('blank:pointerdown', function () { clearSelection(); });

  // Zone resize (custom handle -> 'element:resize' event)
  let resizing = null;
  paper.on('element:resize', function (view, evt) {
    evt.stopPropagation();
    const s = view.model.size();
    resizing = { model: view.model, sw: s.width, sh: s.height, sx: evt.clientX, sy: evt.clientY };
  });
  document.addEventListener('mousemove', function (e) {
    if (!resizing) return;
    const dw = (e.clientX - resizing.sx) / currentScale;
    const dh = (e.clientY - resizing.sy) / currentScale;
    let w = resizing.sw + dw, h = resizing.sh + dh;
    // Resizing is a custom handle, so the paper's grid never touches it -
    // quantise here as well, otherwise "Snap to grid" only covers moves.
    if (snapEnabled) { w = Math.round(w / GRID) * GRID; h = Math.round(h / GRID) * GRID; }
    resizing.model.resize(Math.max(90, Math.round(w)), Math.max(60, Math.round(h)));
  });
  document.addEventListener('mouseup', function () { resizing = null; });

  // Grid snapping on move
  function snapModel(m) {
    const p = m.position();
    m.position(Math.round(p.x / GRID) * GRID, Math.round(p.y / GRID) * GRID);
  }
  paper.on('element:pointerup', function (ev) {
    if (!snapEnabled || resizing) return;
    groupMoving = true;   // snapping the group must not re-trigger group move
    snapModel(ev.model);
    if (multiSel.has(ev.model)) {
      multiSel.forEach(function (m) { if (m !== ev.model && m.isElement()) snapModel(m); });
    }
    groupMoving = false;
  });

  // Inline label editing (double-click)
  let editor = null;
  let editorOutside = null;   // outside-pointerdown listener for the open editor
  function openEditor(value, clientX, clientY, multiline, commit) {
    closeEditor();
    editor = document.createElement(multiline ? 'textarea' : 'input');
    editor.className = 'ad-label-editor';
    editor.value = value || '';
    editor.style.position = 'fixed';
    editor.style.left = clientX + 'px';
    editor.style.top = clientY + 'px';
    if (multiline) { editor.rows = Math.max(2, (value || '').split('\n').length); editor.style.textAlign = 'left'; }
    document.body.appendChild(editor);
    editor.focus(); editor.select();
    // Guard: closeEditor() nulls `editor`, and removing the node can fire a
    // synchronous blur - so bail out if there's nothing open anymore.
    const done = function (save) { if (!editor) return; if (save) commit(editor.value); closeEditor(); };
    editor.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { e.preventDefault(); done(false); }
      else if (e.key === 'Enter' && (!multiline || e.ctrlKey || e.metaKey)) { e.preventDefault(); done(true); }
    });
    editor.addEventListener('blur', function () { done(true); });
    // The JointJS paper calls preventDefault on pointerdown, which stops the
    // input from blurring when you click the canvas - so commit & close on any
    // pointerdown outside the editor. Deferred so this same dblclick is ignored.
    editorOutside = function (e) { if (editor && e.target !== editor) done(true); };
    setTimeout(function () { if (editorOutside) document.addEventListener('mousedown', editorOutside, true); }, 0);
  }
  function closeEditor() {
    if (editorOutside) { document.removeEventListener('mousedown', editorOutside, true); editorOutside = null; }
    if (editor) { editor.remove(); editor = null; }
  }

  paper.on('element:pointerdblclick', function (ev, evt) {
    const model = ev.model;
    const type  = model.get('type');
    const bbox  = ev.getBBox();
    const center = paper.localToClientPoint(bbox.x + bbox.width / 2, bbox.y + bbox.height / 2);
    if (type === 'ad.Zone') {
      const hdr = paper.localToClientPoint(model.position().x + 60, model.position().y + 13);
      openEditor(model.attr('label/text'), hdr.x, hdr.y, false, function (v) { model.attr('label/text', v); });
      return;
    }
    // Card / Container: one editor for both rows - line 1 is the title, the
    // remaining lines become the description.
    if (type === 'ad.Card' || type === 'ad.Container') {
      const title = model.attr('title/text') || '';
      const desc  = model.attr('desc/text')  || '';
      const top   = paper.localToClientPoint(bbox.x + bbox.width / 2, bbox.y + 16);
      openEditor(desc ? (title + '\n' + desc) : title, top.x, top.y, true, function (v) {
        const lines = v.split('\n');
        model.attr('title/text', lines.shift() || '');
        model.attr('desc/text', lines.join('\n').trim());
      });
      return;
    }
    if (type === 'ad.Section') {
      openEditor(model.attr('label/text') || '', center.x, center.y, false, function (v) {
        model.attr('label/text', (v || '').toUpperCase());
      });
      return;
    }
    const multiline = type === 'ad.Text' || type === 'ad.FlowNote' || type === 'ad.Caption';
    openEditor(model.attr('label/text') || '', center.x, center.y, multiline, function (v) {
      model.attr('label/text', v);
    });
  });

  paper.on('link:pointerdblclick', function (lv, evt) {
    const cur = (lv.model.label(0) && lv.model.label(0).attrs && lv.model.label(0).attrs.text)
      ? lv.model.label(0).attrs.text.text : '';
    openEditor(cur || '', evt.clientX, evt.clientY, false, function (v) {
      lv.model.label(0, {
        position: 0.5,
        attrs: {
          text: { text: v, fontSize: 12, fontFamily: 'inherit', fill: '#1f2430' },
          rect: { fill: '#ffffff', stroke: '#d8dde3', strokeWidth: 1, rx: 3, ry: 3 }
        }
      });
    });
  });

  // Zoom + pan
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function updateZoom() { document.getElementById('adZoomLabel').textContent = Math.round(currentScale * 100) + '%'; }
  function zoomTo(scale, ox, oy) {
    scale = clamp(scale, 0.2, 3);
    const r = paperEl.getBoundingClientRect();
    if (ox == null) { ox = r.width / 2; oy = r.height / 2; }
    const t = paper.translate();
    const beta = scale / currentScale;
    paper.scale(scale);
    paper.translate(ox - beta * (ox - t.tx), oy - beta * (oy - t.ty));
    currentScale = scale;
    updateZoom();
  }
  document.getElementById('adZoomIn').addEventListener('click', function () { zoomTo(currentScale + 0.15); });
  document.getElementById('adZoomOut').addEventListener('click', function () { zoomTo(currentScale - 0.15); });
  document.getElementById('adZoomFit').addEventListener('click', fit);
  paperEl.addEventListener('wheel', function (e) {
    e.preventDefault();
    const r = paperEl.getBoundingClientRect();
    zoomTo(currentScale + (e.deltaY < 0 ? 0.1 : -0.1), e.clientX - r.left, e.clientY - r.top);
  }, { passive: false });
  function fit() {
    const bbox = graph.getBBox();
    if (!bbox) { paper.scale(1); paper.translate(0, 0); currentScale = 1; updateZoom(); return; }
    const pad = 40;
    const s = clamp(Math.min((paperEl.clientWidth - pad * 2) / bbox.width,
                             (paperEl.clientHeight - pad * 2) / bbox.height), 0.2, 2);
    paper.scale(s);
    paper.translate(pad - bbox.x * s, pad - bbox.y * s);
    currentScale = s;
    updateZoom();
  }

  // Pan by dragging the blank canvas (Shift+drag is rubber-band selection)
  let panning = null;
  paper.on('blank:pointerdown', function (evt) {
    if (evt.shiftKey) return;
    const t = paper.translate();
    panning = { sx: evt.clientX, sy: evt.clientY, tx: t.tx, ty: t.ty };
  });
  paper.on('blank:pointermove', function (evt) {
    if (!panning) return;
    paper.translate(panning.tx + (evt.clientX - panning.sx), panning.ty + (evt.clientY - panning.sy));
  });
  paper.on('blank:pointerup cell:pointerup', function () { panning = null; });

  // Undo / redo
  // Whole-graph JSON snapshots, captured on a debounce so one drag (a burst
  // of change events) lands as ONE history entry.
  const HISTORY_LIMIT = 60;
  let undoStack = [], redoStack = [];
  let lastState = JSON.stringify(graph.toJSON());
  let restoring = false;

  function updateUndoButtons() {
    document.getElementById('adUndo').disabled = !undoStack.length;
    document.getElementById('adRedo').disabled = !redoStack.length;
  }
  const captureHistory = _.debounce(function () {
    if (restoring) return;
    const now = JSON.stringify(graph.toJSON());
    if (now === lastState) return;
    undoStack.push(lastState);
    if (undoStack.length > HISTORY_LIMIT) undoStack.shift();
    redoStack = [];
    lastState = now;
    updateUndoButtons();
  }, 300);
  graph.on('add remove change', captureHistory);

  function restoreState(state) {
    restoring = true;
    clearSelection();
    graph.fromJSON(JSON.parse(state));
    captureHistory.cancel();   // drop the capture scheduled by the restore itself
    restoring = false;
    lastState = state;
    updateUndoButtons();
  }
  function undo() {
    captureHistory.flush();    // bank any pending edit first
    if (!undoStack.length) return;
    redoStack.push(lastState);
    restoreState(undoStack.pop());
  }
  function redo() {
    if (!redoStack.length) return;
    undoStack.push(lastState);
    restoreState(redoStack.pop());
  }
  document.getElementById('adUndo').addEventListener('click', undo);
  document.getElementById('adRedo').addEventListener('click', redo);

  // Clipboard (copy / paste / duplicate)
  let clipboard  = [];   // detached clones; survives deleting the originals
  let pasteCount = 0;

  function cloneCells(cells) {
    const elems = cells.filter(function (c) { return c.isElement(); });
    const links = cells.filter(function (c) { return c.isLink(); });
    const map = {};
    const outE = elems.map(function (e) { const c = e.clone(); map[e.id] = c; return c; });
    const outL = [];
    links.forEach(function (l) {
      const s = l.source(), t = l.target();
      if (!s.id || !t.id || !map[s.id] || !map[t.id]) return;
      const c = l.clone();
      c.source(joint.util.assign({}, s, { id: map[s.id].id }));
      c.target(joint.util.assign({}, t, { id: map[t.id].id }));
      outL.push(c);
    });
    return outE.concat(outL);
  }
  function selectionCells() {
    const elems = allSelectedModels().filter(function (m) { return m.isElement(); });
    const ids = {};
    elems.forEach(function (m) { ids[m.id] = true; });
    // Bring along the links whose BOTH ends are in the selection.
    const links = graph.getLinks().filter(function (l) {
      const s = l.source().id, t = l.target().id;
      return s && t && ids[s] && ids[t];
    });
    return elems.concat(links);
  }
  function copySelection() {
    const cells = selectionCells();
    if (!cells.length) return false;
    clipboard = cloneCells(cells);
    pasteCount = 0;
    return true;
  }
  function pasteClipboard() {
    if (!clipboard.length) return;
    pasteCount += 1;
    const cells = cloneCells(clipboard);
    const off = 24 * pasteCount;
    cells.forEach(function (c) { if (c.isElement()) c.translate(off, off); });
    graph.addCells(cells);
    clearSelection();
    setMulti(cells.filter(function (c) { return c.isElement(); }));
  }
  function duplicateSelection() { if (copySelection()) pasteClipboard(); }

  // Colour swatches (apply to current selection)
  document.querySelectorAll('.ad-swatch').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const models = allSelectedModels();
      if (!models.length) return;
      models.forEach(function (m) { recolorCell(m, btn.dataset.color); });
    });
  });

  // Align / distribute (toolbar) - layout hygiene for multi-selections.
  // Operates on the top-level members of the selection only: when a
  // container AND its embedded children are both selected, moving the
  // container already carries the children, so they are skipped to avoid
  // double moves. translate() (not position()) is used so embeds follow.
  function topLevelSelection() {
    const els = allSelectedModels().filter(function (m) { return m.isElement(); });
    const inSel = {};
    els.forEach(function (m) { inSel[m.id] = true; });
    return els.filter(function (m) {
      let p = m.getParentCell();
      while (p) { if (inSel[p.id]) return false; p = p.getParentCell(); }
      return true;
    });
  }
  function alignSelection(mode) {
    const boxes = topLevelSelection().map(function (m) { return { m: m, b: m.getBBox() }; });
    if (boxes.length < 2) return;
    const minX = Math.min.apply(null, boxes.map(function (o) { return o.b.x; }));
    const maxX = Math.max.apply(null, boxes.map(function (o) { return o.b.x + o.b.width; }));
    const minY = Math.min.apply(null, boxes.map(function (o) { return o.b.y; }));
    const maxY = Math.max.apply(null, boxes.map(function (o) { return o.b.y + o.b.height; }));
    const cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
    boxes.forEach(function (o) {
      let x = o.b.x, y = o.b.y;
      if      (mode === 'left')    x = minX;
      else if (mode === 'right')   x = maxX - o.b.width;
      else if (mode === 'hcenter') x = cx - o.b.width / 2;
      else if (mode === 'top')     y = minY;
      else if (mode === 'bottom')  y = maxY - o.b.height;
      else if (mode === 'vcenter') y = cy - o.b.height / 2;
      if (snapEnabled) { x = Math.round(x / GRID) * GRID; y = Math.round(y / GRID) * GRID; }
      o.m.translate(x - o.b.x, y - o.b.y);
    });
  }
  function distributeSelection(axis) {
    const horiz = axis === 'h';
    const boxes = topLevelSelection().map(function (m) { return { m: m, b: m.getBBox() }; })
      .sort(function (a, b2) { return horiz ? a.b.x - b2.b.x : a.b.y - b2.b.y; });
    if (boxes.length < 3) return;
    const first = boxes[0].b, last = boxes[boxes.length - 1].b;
    const span  = horiz ? (last.x + last.width - first.x) : (last.y + last.height - first.y);
    const total = boxes.reduce(function (s, o) { return s + (horiz ? o.b.width : o.b.height); }, 0);
    const gap   = (span - total) / (boxes.length - 1);
    let cursor  = horiz ? first.x : first.y;
    boxes.forEach(function (o) {
      const x = horiz ? cursor : o.b.x;
      const y = horiz ? o.b.y : cursor;
      o.m.translate(x - o.b.x, y - o.b.y);
      cursor += (horiz ? o.b.width : o.b.height) + gap;
    });
  }
  // Transient hint bubble on the canvas - so Align / Distribute never feel
  // "dead" when the selection is too small to act on.
  let hintTimer = null;
  function flashHint(msg) {
    let el = document.getElementById('adHint');
    if (!el) {
      el = document.createElement('div');
      el.id = 'adHint';
      el.className = 'ad-hint';
      wrap.appendChild(el);
    }
    el.textContent = msg;
    el.classList.add('is-on');
    clearTimeout(hintTimer);
    hintTimer = setTimeout(function () { el.classList.remove('is-on'); }, 2600);
  }
  document.querySelectorAll('.ad-align').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const n = topLevelSelection().length;
      if (btn.dataset.align) {
        if (n < 2) { flashHint('Select 2 or more shapes first - Shift-click each shape (or Shift-drag a box around them), then align.'); return; }
        alignSelection(btn.dataset.align);
      } else if (btn.dataset.dist) {
        if (n < 3) { flashHint('Select 3 or more shapes to distribute them evenly - Shift-click each shape.'); return; }
        distributeSelection(btn.dataset.dist);
      }
    });
  });

  // Diagram file: save to / open from a local .json file
  // Nothing touches the server - the diagram is downloaded by the browser
  // and re-opened from disk, so guests can use it and nothing is stored.
  const FILE_KIND  = 'appassist-architect-diagram';
  const titleInput = document.getElementById('adTitle');

  function diagramFilename(ext) {
    const raw  = (titleInput && titleInput.value.trim()) || '';
    const slug = raw.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);
    return (slug || 'architecture-diagram') + ext;
  }
  document.getElementById('adSaveJson').addEventListener('click', function () {
    if (!graph.getCells().length) { alert('Add some shapes before saving.'); return; }
    const payload = {
      kind: FILE_KIND, version: 1,
      title: titleInput ? titleInput.value.trim() : '',
      savedAt: new Date().toISOString(),
      graph: graph.toJSON()
    };
    download(new Blob([JSON.stringify(payload)], { type: 'application/json' }),
             diagramFilename('.json'));
  });
  const openInput = document.getElementById('adOpenFile');
  document.getElementById('adOpenJson').addEventListener('click', function () { openInput.click(); });
  openInput.addEventListener('change', function () {
    const file = openInput.files && openInput.files[0];
    openInput.value = '';
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function () {
      let data;
      try { data = JSON.parse(reader.result); } catch (e) { alert('Not a valid diagram file.'); return; }
      if (!data || data.kind !== FILE_KIND || !data.graph || !Array.isArray(data.graph.cells)) {
        alert('Not a valid diagram file - expected a .json saved from this canvas.');
        return;
      }
      if (graph.getCells().length &&
          !confirm('Opening this file replaces the current canvas. Continue?')) return;
      try {
        clearSelection();
        graph.fromJSON(data.graph);
      } catch (e) {
        graph.clear();
        alert('Could not load the diagram: ' + (e && e.message ? e.message : e));
        return;
      }
      if (titleInput && data.title) titleInput.value = data.title;
      fit();
    };
    reader.readAsText(file);
  });

  // Draft autosave (localStorage) - production-grade crash safety while
  // keeping the no-server promise: the draft lives only in THIS browser.
  // Saved on a debounce after every graph change; an empty canvas clears
  // the draft (so an intentional Clear is not resurrected on reload).
  const DRAFT_KEY = 'appassist.architect-diagram.draft';
  const saveDraft = _.debounce(function () {
    if (restoring) return;
    try {
      if (!graph.getCells().length) { localStorage.removeItem(DRAFT_KEY); return; }
      localStorage.setItem(DRAFT_KEY, JSON.stringify({
        kind: FILE_KIND, version: 1,
        title: titleInput ? titleInput.value.trim() : '',
        savedAt: new Date().toISOString(),
        graph: graph.toJSON()
      }));
    } catch (e) { /* quota / private mode - autosave is best-effort */ }
  }, 800);
  graph.on('add remove change', saveDraft);
  if (titleInput) titleInput.addEventListener('input', saveDraft);

  // On load, offer to restore an autosaved draft (never silently applied -
  // the user may have opened a fresh tab on purpose).
  function offerDraftRestore() {
    let raw = null;
    try { raw = localStorage.getItem(DRAFT_KEY); } catch (e) {}
    if (!raw) return;
    let data;
    try { data = JSON.parse(raw); } catch (e) { return; }
    if (!data || data.kind !== FILE_KIND || !data.graph ||
        !Array.isArray(data.graph.cells) || !data.graph.cells.length) return;
    let when = '';
    if (data.savedAt) {
      const d = new Date(data.savedAt);
      if (!isNaN(d)) when = ' from ' + d.toLocaleString();
    }
    const flag = document.createElement('div');
    flag.className = 'ad-canvas-flag ad-restore-flag';
    flag.innerHTML =
      '<i class="fas fa-clock-rotate-left"></i> ' +
      'A draft' + when + ' was auto-saved in this browser.' +
      '<button type="button" class="ad-flag-btn" data-act="restore">Restore</button>' +
      '<button type="button" class="ad-flag-btn ad-flag-btn-ghost" data-act="discard">Discard</button>';
    flag.addEventListener('click', function (e) {
      const act = e.target && e.target.dataset ? e.target.dataset.act : null;
      if (!act) return;
      if (act === 'restore') {
        if (graph.getCells().length &&
            !confirm('Restoring the draft replaces what is on the canvas now. Continue?')) return;
        try {
          clearSelection();
          graph.fromJSON(data.graph);
          if (titleInput && data.title) titleInput.value = data.title;
          fit();
        } catch (err) {
          alert('Could not restore the draft: ' + (err && err.message ? err.message : err));
        }
      } else {
        try { localStorage.removeItem(DRAFT_KEY); } catch (e2) {}
      }
      flag.remove();
    });
    wrap.appendChild(flag);
  }

  // Toolbar: snap / delete / clear
  document.getElementById('adSnapToggle').addEventListener('click', function () {
    snapEnabled = !snapEnabled;
    this.classList.toggle('is-on', snapEnabled);
    // The paper does the drag-time snapping itself, so the step has to change
    // with the toggle - otherwise turning snap off changes nothing on screen.
    paper.setGridSize(snapEnabled ? GRID : 1);
    flashHint(snapEnabled ? 'Snap to grid ON - ' + GRID + 'px steps'
                          : 'Snap to grid OFF - free pixel placement');
  });
  document.getElementById('adDelete').addEventListener('click', removeSelected);
  document.getElementById('adClear').addEventListener('click', function () {
    if (graph.getCells().length && !confirm('Clear the entire canvas?')) return;
    graph.clear(); clearSelection();
  });
  function removeSelected() {
    const models = allSelectedModels();
    if (!models.length) return;
    clearSelection();
    models.forEach(function (m) { m.remove(); });
  }

  // Keyboard shortcuts
  document.addEventListener('keydown', function (e) {
    if (editor) return;
    const t = e.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
    const mod = e.ctrlKey || e.metaKey;
    const k = e.key;

    if (k === 'Delete' || k === 'Backspace') {
      if (selectedView || multiSel.size) { e.preventDefault(); removeSelected(); }
    } else if (mod && (k === 'z' || k === 'Z')) {
      e.preventDefault();
      if (e.shiftKey) redo(); else undo();
    } else if (mod && (k === 'y' || k === 'Y')) {
      e.preventDefault(); redo();
    } else if (mod && (k === 'c' || k === 'C')) {
      if (copySelection()) e.preventDefault();
    } else if (mod && (k === 'v' || k === 'V')) {
      if (clipboard.length) { e.preventDefault(); pasteClipboard(); }
    } else if (mod && (k === 'd' || k === 'D')) {
      e.preventDefault(); duplicateSelection();
    } else if (k.indexOf('Arrow') === 0) {
      const models = allSelectedModels().filter(function (m) { return m.isElement(); });
      if (!models.length) return;
      e.preventDefault();
      // Shift = fine 1px nudge; with snap off every nudge is already 1px.
      const step = (e.shiftKey || !snapEnabled) ? 1 : GRID;
      const dx = k === 'ArrowLeft' ? -step : (k === 'ArrowRight' ? step : 0);
      const dy = k === 'ArrowUp'   ? -step : (k === 'ArrowDown'  ? step : 0);
      groupMoving = true;
      models.forEach(function (m) { m.translate(dx, dy); });
      groupMoving = false;
    }
  });

  // ===================================================================
  //  Export - fully client-side & self-contained
  //  Uses the RENDERED bounding box (via SVG getBBox) so EVERYTHING on the
  //  canvas - node labels, zone titles, free text and link labels - is
  //  captured. Nothing is left out of the saved image.
  // ===================================================================
  function buildExportSVG() {
    if (!graph.getCells().length) { alert('Add some shapes before saving.'); return null; }

    // Render the graph into a detached, grid-free, non-interactive paper.
    const holder = document.createElement('div');
    holder.style.cssText = 'position:absolute;left:-100000px;top:0;width:4000px;height:4000px;';
    document.body.appendChild(holder);
    const ep = new joint.dia.Paper({
      el: holder, model: graph, width: 4000, height: 4000,
      gridSize: 1, drawGrid: false, interactive: false,
      background: { color: '#ffffff' }, cellViewNamespace: joint.shapes
    });
    if (ep.updateViews) ep.updateViews();

    const svg = ep.svg;
    // Strip ports, tool layers and editor-only resize handles. The handles
    // are hidden on screen by the page stylesheet, but the exported SVG has
    // no stylesheet - left in, they print as grey squares on every node.
    svg.querySelectorAll(
      '.joint-port, .joint-tools, .joint-grid-layer, .ad-resize-h, .ad-export-omit'
    ).forEach(function (n) { n.remove(); });

    // True rendered bounds (includes text geometry).
    let bx;
    try { bx = svg.getBBox(); } catch (e) { bx = null; }
    if (!bx || !bx.width) {
      const gb = graph.getBBox(); bx = { x: gb.x, y: gb.y, width: gb.width, height: gb.height };
    }
    const pad = 28;
    const minX = Math.floor(bx.x - pad);
    let   minY = Math.floor(bx.y - pad);
    const W = Math.ceil(bx.width + pad * 2);
    let   H = Math.ceil(bx.height + pad * 2);

    // Title block: when a diagram title is set, reserve a header band above
    // the content carrying the title and the export date.
    const title   = (titleInput && titleInput.value.trim()) || '';
    const TITLE_H = title ? 58 : 0;
    minY -= TITLE_H;
    H    += TITLE_H;

    const out = svg.cloneNode(true);
    out.setAttribute('width', W);
    out.setAttribute('height', H);
    out.setAttribute('viewBox', minX + ' ' + minY + ' ' + W + ' ' + H);
    out.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    out.setAttribute('xmlns:xlink', 'http://www.w3.org/1999/xlink');

    // Opaque white background covering the whole viewBox.
    const bg = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    bg.setAttribute('x', minX); bg.setAttribute('y', minY);
    bg.setAttribute('width', W); bg.setAttribute('height', H);
    bg.setAttribute('fill', '#ffffff');
    out.insertBefore(bg, out.firstChild);

    if (title) {
      const NS = 'http://www.w3.org/2000/svg';
      const mkText = function (str, y, size, weight, fill) {
        const t = document.createElementNS(NS, 'text');
        t.setAttribute('x', minX + pad);
        t.setAttribute('y', y);
        t.setAttribute('font-family', 'Segoe UI, Arial, sans-serif');
        t.setAttribute('font-size', size);
        t.setAttribute('font-weight', weight);
        t.setAttribute('fill', fill);
        t.textContent = str;
        return t;
      };
      const when = new Date().toLocaleDateString(undefined,
        { day: '2-digit', month: 'short', year: 'numeric' });
      out.appendChild(mkText(title, minY + 28, 17, '600', '#111827'));
      out.appendChild(mkText('Architecture diagram - ' + when, minY + 46, 11, '400', '#6b7280'));
      const rule = document.createElementNS(NS, 'line');
      rule.setAttribute('x1', minX + pad); rule.setAttribute('x2', minX + W - pad);
      rule.setAttribute('y1', minY + TITLE_H - 2); rule.setAttribute('y2', minY + TITLE_H - 2);
      rule.setAttribute('stroke', '#e5e7eb'); rule.setAttribute('stroke-width', '1');
      out.appendChild(rule);
    }

    ep.remove();
    holder.remove();
    return { svg: out, width: W, height: H };
  }

  function download(blob, name) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  document.getElementById('adExportSvg').addEventListener('click', function () {
    const o = buildExportSVG(); if (!o) return;
    const str = '<?xml version="1.0" encoding="UTF-8"?>\n' + new XMLSerializer().serializeToString(o.svg);
    download(new Blob([str], { type: 'image/svg+xml;charset=utf-8' }), diagramFilename('.svg'));
  });

  document.getElementById('adExportPng').addEventListener('click', function () {
    const o = buildExportSVG(); if (!o) return;
    const scale = 2;
    const str = new XMLSerializer().serializeToString(o.svg);
    const img = new Image();
    const svgUrl = URL.createObjectURL(new Blob([str], { type: 'image/svg+xml;charset=utf-8' }));
    img.onload = function () {
      const canvas = document.createElement('canvas');
      canvas.width = o.width * scale; canvas.height = o.height * scale;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(svgUrl);
      canvas.toBlob(function (blob) { download(blob, diagramFilename('.png')); }, 'image/png');
    };
    img.onerror = function () { URL.revokeObjectURL(svgUrl); alert('Could not render the PNG. Try the SVG export instead.'); };
    img.src = svgUrl;
  });

  // Boot
  renderPalette();
  resize();
  updateZoom();
  updateUndoButtons();
  offerDraftRestore();
})();
