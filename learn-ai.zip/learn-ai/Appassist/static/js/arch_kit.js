/* =====================================================================
   arch_kit.js - the drawing kit the Application Support architecture
   diagrams are built on.

   A diagram page owns two things and nothing else: a LAYOUT (where the
   boxes go) and a set of PAINTERS (what one box looks like). Everything
   between those two - orthogonal routing, label placement that does not
   overstrike, the paint order that keeps wires out of cards, pan/zoom,
   and the standalone SVG/PNG export - is generic, and lives here.

   The model is deliberately a plain data structure:

       { w, h, bands[], caps[], routes[], pills[], nodes[], empty }

   because it is rendered TWICE - once as HTML cards over an SVG wire
   layer for the screen, once as a self-contained SVG document for the
   download. Screen and download therefore cannot disagree about what is
   on the diagram; they read the same model.

   Colours are literal hex rather than CSS custom properties: the export
   travels to a file no stylesheet follows, and the module's own tokens
   are authored in oklch(), which means nothing to Visio or Office.

   ASCII only, ES5 only - production serves this to browsers on Windows
   estates that predate the ES6 assumptions a bundler would make.
   ===================================================================== */

/* global window, document */
window.ArchKit = (function () {
    'use strict';

    var SVGNS = 'http://www.w3.org/2000/svg';

    /* ---- palette ------------------------------------------------------
       The literal form of the NPG design language (npg.css). It is stated
       as hex rather than read from the custom properties because this kit
       renders TWICE - once into the page, once into a standalone SVG that
       travels to a file no stylesheet follows - and the tokens are
       authored in oklch(), which means nothing to Visio or Office.

       Three families, and the split is deliberate:

         NEUTRALS   the cool Slate ramp. A diagram sitting on a warm
                    off-white ground inside a cool slate application is
                    the single thing that made this canvas read as a
                    different product; every surface, hairline and label
                    below is the same value the rest of the estate uses.

         WIRES      three hues, all on the COOL half of the wheel, so a
                    line can never be mistaken for a criticality mark.
                    Teal and blue keep the families they already had;
                    only the brown that carried "leaves the boundary"
                    moves, to a violet that survives being printed.

         BC*        business criticality, restated in the application's
                    own status ramp (--stop / --warn / --ok) so a BC1
                    system is the same red here as everywhere else. */
    var C = {
        brand: '#ab1236', brandDeep: '#7d0c27', soft: '#fdf1f4',
        text: '#0f1626', t2: '#333e52', t3: '#5a6478', mute: '#79839a',
        border: '#d3dbe7', bstrong: '#bbc6d6', hair: '#e8edf4',
        surface: '#FFFFFF', sunken: '#eef2f8', canvas: '#f6f8fc',
        page: '#e7ecf3',
        wire: '#7c5cbf',        /* traffic that leaves the domain          */
        wint: '#0e7490',        /* traffic that stays inside it            */
        bidi: '#1d4ed8',
        bc1: '#b42318', bc2: '#b45309', bc3: '#0f7050',
        bc1s: '#fdeeed', bc2s: '#fdf2e4', bc3s: '#e7f5ef'
    };
    var SANS = "'Segoe UI', Calibri, Arial, Helvetica, sans-serif";
    var MONO = "Consolas, 'Courier New', monospace";
    var MID = '\u00B7';

    /* Corner radius on the routed wires. A constant, not a knob: a
       mixed-radius estate reads as two different diagrams. */
    var CORNER = 8;

    /* ---- DOM helpers -------------------------------------------------
       Everything below builds nodes and assigns textContent. Estate
       records are user-entered free text (application, domain, vendor and
       member names), so none of it may ever reach innerHTML. Style
       strings are built only from numbers and from the palette above,
       never from record text. */
    function el(tag, cls, text) {
        var n = document.createElement(tag);
        if (cls) { n.className = cls; }
        if (text !== undefined && text !== null) { n.textContent = String(text); }
        return n;
    }
    function svgEl(tag, attrs, text) {
        var n = document.createElementNS(SVGNS, tag);
        for (var k in attrs) {
            if (Object.prototype.hasOwnProperty.call(attrs, k)
                    && attrs[k] !== null && attrs[k] !== undefined) {
                n.setAttribute(k, attrs[k]);
            }
        }
        if (text !== undefined && text !== null) {
            n.appendChild(document.createTextNode(String(text)));
        }
        return n;
    }
    function clear(node) {
        while (node && node.firstChild) { node.removeChild(node.firstChild); }
    }
    function trunc(s, n) {
        s = (s === null || s === undefined) ? '' : String(s);
        return s.length <= n ? s : s.slice(0, Math.max(1, n - 1)) + '\u2026';
    }
    function plural(n, one, many) {
        return n + ' ' + (n === 1 ? one : (many || one + 's'));
    }
    function px(v) { return Math.round(v * 100) / 100 + 'px'; }

    /* A card that is reachable and operable from the keyboard. A real
       <button> already answers Enter and Space by firing click, so it
       only needs the label and the handler; anything else has to be
       taught all of it. */
    function interactive(node, label, activate) {
        node.setAttribute('aria-label', label);
        node.addEventListener('click', activate);
        if (node.tagName === 'BUTTON') { return node; }
        node.setAttribute('tabindex', '0');
        node.setAttribute('role', 'button');
        node.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ' || e.key === 'Spacebar') {
                e.preventDefault();
                activate();
            }
        });
        return node;
    }

    function bcInk(bc) {
        return bc === 'BC1' ? C.bc1 : bc === 'BC2' ? C.bc2
             : bc === 'BC3' ? C.bc3 : C.t3;
    }
    function bcSoft(bc) {
        return bc === 'BC1' ? C.bc1s : bc === 'BC2' ? C.bc2s
             : bc === 'BC3' ? C.bc3s : C.sunken;
    }

    /* ---- orthogonal routing ------------------------------------------
       Every wire is a run of axis-aligned segments with rounded corners.
       The corner is cut back from the vertex by at most half the shorter
       leg, so a short segment rounds proportionally instead of
       overshooting into the next one. */
    function orthPath(pts) {
        if (pts.length < 2) { return ''; }
        if (!CORNER) {
            return 'M' + pts.map(function (p) {
                return p.x + ' ' + p.y;
            }).join(' L');
        }
        var d = 'M' + pts[0].x + ' ' + pts[0].y;
        for (var i = 1; i < pts.length - 1; i += 1) {
            var p = pts[i], a = pts[i - 1], b = pts[i + 1];
            var v1x = p.x - a.x, v1y = p.y - a.y;
            var v2x = b.x - p.x, v2y = b.y - p.y;
            var l1 = Math.sqrt(v1x * v1x + v1y * v1y) || 1;
            var l2 = Math.sqrt(v2x * v2x + v2y * v2y) || 1;
            var rr = Math.min(CORNER, l1 / 2, l2 / 2);
            d += ' L' + (p.x - v1x / l1 * rr) + ' ' + (p.y - v1y / l1 * rr);
            d += ' Q' + p.x + ' ' + p.y + ' '
               + (p.x + v2x / l2 * rr) + ' ' + (p.y + v2y / l2 * rr);
        }
        var e = pts[pts.length - 1];
        return d + ' L' + e.x + ' ' + e.y;
    }

    /* ---- the model ---------------------------------------------------- */
    function newModel(w, h) {
        return { w: w, h: h, bands: [], caps: [], routes: [], pills: [],
                 nodes: [], empty: null };
    }
    function addRoute(m, pts, opts) {
        opts = opts || {};
        m.routes.push({
            pts: pts, d: orthPath(pts),
            stroke: opts.stroke, width: opts.width || 1.7,
            opacity: opts.opacity === undefined ? 1 : opts.opacity,
            dash: opts.dash || null, marker: opts.marker || null,
            markerStart: opts.markerStart || null,
            pair: opts.pair || null
        });
    }
    function addCap(m, x, y, text, anchor) {
        m.caps.push({ x: x, y: y, text: text, anchor: anchor || 'start' });
    }
    function addBand(m, band) { m.bands.push(band); }
    function addNode(m, node) { m.nodes.push(node); return node; }

    /* Slide a label along its OWN wire until it clears every label
       already placed. Lanes sit close enough together that two labels on
       adjacent lanes overlap whenever their runs share any x, so the
       midpoint cannot simply be taken. A wire whose entire run is spoken
       for gives its label up to the panel, which lists every interface
       anyway: overstruck text is worse than no text. */
    var PILL_SLACK = 54;
    var PILL_H = 16;

    function pillOverlaps(m, x, y, w) {
        return m.pills.some(function (p) {
            return x < p.x + p.w + 4 && x + w + 4 > p.x
                && y < p.y + PILL_H + 4 && y + PILL_H + 4 > p.y;
        });
    }
    /* `axis` is the direction of the wire the label rides on: 'x' for a
       horizontal run, where the pill slides left and right, 'y' for a
       vertical one. Returns the free coordinate along that axis, or null
       when the whole run is spoken for. */
    function placePill(m, x, y, w, range, axis) {
        var vert = axis === 'y';
        var size = vert ? PILL_H : w;
        var lo = Math.min(range[0], range[1]);
        var hi = Math.max(range[0], range[1]);
        /* A run shorter than its own label is not a reason to lose the
           label. The pill may overhang its own wire; what it may not do
           is overstrike another pill - so widen the window about the
           midpoint and let the clash test be the only thing that can
           actually suppress a label. */
        if (hi - lo < size) {
            var mid = (lo + hi) / 2;
            lo = mid - size / 2 - PILL_SLACK;
            hi = mid + size / 2 + PILL_SLACK;
        }
        var start = vert ? y : x;
        var clash = function (at) {
            return vert ? pillOverlaps(m, x, at, w) : pillOverlaps(m, at, y, w);
        };
        if (!clash(start) && start >= lo && start + size <= hi) { return start; }
        for (var step = 12; step <= hi - lo; step += 12) {
            if (start + step + size <= hi && !clash(start + step)) {
                return start + step;
            }
            if (start - step >= lo && !clash(start - step)) {
                return start - step;
            }
        }
        return null;
    }
    function addPill(m, cx, cy, text, color, bg, fg, range, axis) {
        var t = String(text === null || text === undefined ? '' : text).trim();
        if (!t) { return; }
        var w = 16 + t.length * 6.1;
        var x = cx - w / 2, y = cy - PILL_H / 2;
        if (range) {
            var at = placePill(m, x, y, w, range, axis);
            if (at === null) { return; }
            if (axis === 'y') { y = at; } else { x = at; }
        }
        m.pills.push({ x: x, y: y, w: w, text: t,
                       color: color, bg: bg || C.surface, fg: fg || color });
    }
    /* The stretch of a run a label may sit on, kept clear of the turns at
       either end. */
    function span(a, b) {
        return [Math.min(a, b) + 10, Math.max(a, b) - 10];
    }

    /* ---- arrow heads --------------------------------------------------
       One <defs> per renderer, prefixed, because the screen and the
       export are two documents in the same page and duplicate marker ids
       would cross-wire them. */
    var MARKERS = [
        ['mkWire', C.wire], ['mkInt', C.wint], ['mkIn', C.bc3],
        ['mkBidi', C.bidi], ['mkGrey', C.t3], ['mkBrand', C.brand]
    ];
    function markerDefs(prefix) {
        var defs = svgEl('defs');
        MARKERS.forEach(function (entry) {
            var mk = svgEl('marker', {
                id: prefix + entry[0], viewBox: '0 0 10 10', refX: '9',
                refY: '5', markerWidth: '6', markerHeight: '6',
                orient: 'auto-start-reverse'
            });
            mk.appendChild(svgEl('path', { d: 'M0,0 L10,5 L0,10 z',
                                           fill: entry[1] }));
            defs.appendChild(mk);
        });
        return defs;
    }

    /* ---- screen renderer ----------------------------------------------
       Painting order is load-bearing. A BACKDROP (a domain container) is
       an opaque surface the wires travel over: it is scenery, and it goes
       down BEFORE the wire layer. Everything else goes down after,
       because keeping routes out of the cards is the whole point of the
       orthogonal channels. Get this backwards and the container swallows
       every wire inside it.

       `painters` maps a node's `kind` to { dom, svg, backdrop }. */
    function paint(worldEl, model, painters) {
        clear(worldEl);
        if (!model) { return null; }
        worldEl.style.width = px(model.w);
        worldEl.style.height = px(model.h);

        var isBackdrop = function (n) {
            var p = painters[n.kind];
            return !!(p && p.backdrop);
        };

        model.bands.forEach(function (b) {
            var d = el('div', 'arch-band');
            d.style.cssText = 'left:' + px(b.x) + ';top:' + px(b.y)
                + ';width:' + px(b.w) + ';height:' + px(b.h)
                + ';border-radius:' + px(b.radius || 0)
                + ';background:' + (b.fill || 'transparent') + ';border:1px '
                + (b.dash ? 'dashed' : 'solid') + ' ' + (b.stroke || C.border) + ';';
            if (b.cap) { d.appendChild(el('div', 'arch-band-cap', b.cap)); }
            worldEl.appendChild(d);
        });

        model.nodes.forEach(function (n) {
            if (isBackdrop(n)) { worldEl.appendChild(painters[n.kind].dom(n)); }
        });

        var wires = svgEl('svg', {
            'class': 'arch-wires', width: model.w, height: model.h,
            viewBox: '0 0 ' + model.w + ' ' + model.h, 'aria-hidden': 'true'
        });
        wires.appendChild(markerDefs('arch'));
        model.routes.forEach(function (r) {
            wires.appendChild(svgEl('path', {
                'class': 'arch-route', d: r.d, fill: 'none', stroke: r.stroke,
                'stroke-width': r.width, 'stroke-opacity': r.opacity,
                'stroke-dasharray': r.dash, 'stroke-linejoin': 'round',
                'marker-end': r.marker ? 'url(#arch' + r.marker + ')' : null,
                'marker-start': r.markerStart
                    ? 'url(#arch' + r.markerStart + ')' : null,
                'data-pair': r.pair
            }));
        });
        worldEl.appendChild(wires);

        model.pills.forEach(function (p) {
            var d = el('div', 'arch-pill', p.text);
            d.style.cssText = 'left:' + px(p.x) + ';top:' + px(p.y)
                + ';width:' + px(p.w) + ';background:' + p.bg
                + ';border:1px solid ' + p.color + ';color:' + p.fg + ';';
            worldEl.appendChild(d);
        });

        model.caps.forEach(function (c) {
            var d = el('div', 'arch-cap', c.text);
            var css = 'top:' + px(c.y - 12) + ';';
            if (c.anchor === 'end') { css += 'right:' + px(model.w - c.x) + ';'; }
            else if (c.anchor === 'middle') { css += 'left:0;right:0;text-align:center;'; }
            else { css += 'left:' + px(c.x) + ';'; }
            d.style.cssText = css;
            worldEl.appendChild(d);
        });

        model.nodes.forEach(function (n) {
            if (!isBackdrop(n)) { worldEl.appendChild(painters[n.kind].dom(n)); }
        });

        /* Last, so nothing can cover it: a focus card is still drawn when
           it has nothing attached, and the note explaining that would
           otherwise sit underneath it. */
        if (model.empty) {
            var note = el('div', 'arch-empty-canvas', model.empty);
            if (model.emptyAt !== undefined && model.emptyAt !== null) {
                note.style.top = px(model.emptyAt);
                note.style.transform = 'none';
            }
            worldEl.appendChild(note);
        }
        return wires;
    }

    /* An absolutely positioned box at a node's coordinates - the first
       line of nearly every DOM painter. */
    function baseBox(node, cls, tag) {
        var d = el(tag || 'div', cls);
        d.style.position = 'absolute';
        d.style.left = px(node.x);
        d.style.top = px(node.y);
        d.style.width = px(node.w);
        d.style.height = px(node.h);
        return d;
    }

    /* ---- export primitives --------------------------------------------- */
    function svgText(x, y, text, o) {
        o = o || {};
        return svgEl('text', {
            x: x, y: y, 'font-size': o.size || 12, 'font-weight': o.weight || null,
            fill: o.fill || C.text, 'text-anchor': o.anchor || null,
            'font-family': o.mono ? MONO : SANS,
            'letter-spacing': o.ls || null, opacity: o.opacity === undefined
                ? null : o.opacity
        }, text);
    }
    function svgRect(x, y, w, h, o) {
        o = o || {};
        return svgEl('rect', {
            x: x, y: y, width: w, height: h,
            rx: o.rx === undefined ? null : o.rx,
            fill: o.fill || 'none', stroke: o.stroke || null,
            'stroke-width': o.sw || (o.stroke ? 1 : null),
            'stroke-dasharray': o.dash || null, 'fill-opacity': o.fo || null,
            opacity: o.opacity === undefined ? null : o.opacity
        });
    }
    /* Rough character budget for a fixed-width box. SVG text neither
       wraps nor ellipsises, so the cut has to happen before it is drawn. */
    function fit(text, width, size) {
        return trunc(text, Math.max(3, Math.floor(width / (size * 0.55))));
    }

    /* The drawing's real extent, so a one-application sheet is not padded
       out to the whole landscape's dimensions. */
    function modelBounds(model) {
        var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        function box(x, y, w, h) {
            if (x < minX) { minX = x; }
            if (y < minY) { minY = y; }
            if (x + w > maxX) { maxX = x + w; }
            if (y + h > maxY) { maxY = y + h; }
        }
        model.bands.forEach(function (b) { box(b.x, b.y, b.w, b.h); });
        model.nodes.forEach(function (n) { box(n.x, n.y, n.w, n.h); });
        model.pills.forEach(function (p) { box(p.x, p.y, p.w, PILL_H); });
        model.caps.forEach(function (c) {
            var w = c.text.length * 6.4;
            var x = c.anchor === 'end' ? c.x - w
                  : (c.anchor === 'middle' ? c.x - w / 2 : c.x);
            box(x, c.y - 12, w, 14);
        });
        model.routes.forEach(function (r) {
            r.pts.forEach(function (p) { box(p.x - 1, p.y - 1, 2, 2); });
        });
        if (minX === Infinity) { return null; }
        return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
    }

    /* A standalone, self-describing sheet: banner, legend, the drawing,
       and a footer that says where it came from. `opts` carries
       { title, subtitle, legendTitle, legendRows, footerLeft, footerRight }. */
    function exportSvg(model, painters, opts) {
        if (!model) { return null; }
        var box = modelBounds(model);
        if (!box) { return null; }
        opts = opts || {};
        var legend = opts.legendRows || [];

        var PAD = 44, HEAD = 96, LEGEND = legend.length ? 34 : 8, FOOT = 30;
        var w = Math.max(Math.ceil(box.w) + PAD * 2, 760);
        var h = Math.ceil(box.h) + PAD * 2 + HEAD + LEGEND + FOOT;

        var doc = svgEl('svg', {
            xmlns: SVGNS, width: w, height: h,
            viewBox: '0 0 ' + w + ' ' + h, 'font-family': SANS
        });
        doc.appendChild(markerDefs('ex'));
        doc.appendChild(svgRect(0, 0, w, h, { fill: C.sunken }));
        doc.appendChild(svgRect(0, 0, w, 64, { fill: C.brand }));
        doc.appendChild(svgRect(0, 64, w, 24, { fill: C.brandDeep }));

        doc.appendChild(svgText(PAD, 40, opts.title || '',
                                { size: 22, weight: 700, fill: '#FFFFFF' }));
        doc.appendChild(svgText(w - PAD, 40, opts.kicker || '',
                                { size: 12.5, fill: '#f2c3cf', anchor: 'end' }));
        doc.appendChild(svgText(PAD, 81, opts.subtitle || '',
                                { size: 11.5, fill: '#f2c3cf' }));

        /* legend strip - a diagram that travels has to explain its marks */
        if (legend.length) {
            var lx = PAD, ly = HEAD + 12;
            var lt = opts.legendTitle || '';
            if (lt) {
                doc.appendChild(svgText(lx, ly, lt,
                    { size: 10, fill: C.t3, mono: true, ls: '1.2' }));
                lx += lt.length * 6.6 + 22;
            }
            legend.forEach(function (r) {
                if (r.line) {
                    doc.appendChild(svgEl('path', {
                        d: 'M' + lx + ' ' + (ly - 4) + ' L' + (lx + 22) + ' ' + (ly - 4),
                        stroke: r.line, 'stroke-width': 3,
                        'stroke-dasharray': r.dash ? '4 3' : null
                    }));
                    lx += 28;
                } else {
                    doc.appendChild(svgRect(lx, ly - 9, 15, 11, {
                        rx: 2, fill: r.fill, stroke: r.edge || C.bstrong, sw: 0.7
                    }));
                    lx += 21;
                }
                doc.appendChild(svgText(lx, ly, r.text, { size: 11, fill: C.text }));
                lx += r.text.length * 5.9 + 20;
            });
        }

        var g = svgEl('g', {
            transform: 'translate(' + Math.round((w - box.w) / 2 - box.x) + ' '
                     + Math.round(HEAD + LEGEND + PAD - box.y) + ')'
        });
        model.bands.forEach(function (b) {
            g.appendChild(svgRect(b.x, b.y, b.w, b.h, {
                rx: b.radius || 0, fill: b.fill, stroke: b.stroke,
                dash: b.dash || null
            }));
            if (b.cap) {
                g.appendChild(svgText(b.x + 16, b.y + 26, b.cap,
                    { size: 10.5, fill: C.mute, mono: true, ls: '1.3' }));
            }
        });
        /* Same three decks as the screen: backdrops, wires, then the cards
           the wires must not be drawn over. */
        model.nodes.forEach(function (n) {
            if (painters[n.kind] && painters[n.kind].backdrop) {
                painters[n.kind].svg(g, n);
            }
        });
        model.routes.forEach(function (r) {
            g.appendChild(svgEl('path', {
                d: r.d, fill: 'none', stroke: r.stroke, 'stroke-width': r.width,
                'stroke-opacity': r.opacity, 'stroke-dasharray': r.dash,
                'stroke-linejoin': 'round',
                'marker-end': r.marker ? 'url(#ex' + r.marker + ')' : null,
                'marker-start': r.markerStart ? 'url(#ex' + r.markerStart + ')' : null
            }));
        });
        model.caps.forEach(function (c) {
            g.appendChild(svgText(c.x, c.y, c.text, {
                size: 10.5, fill: C.mute, mono: true, ls: '1.3',
                anchor: c.anchor === 'start' ? null : c.anchor
            }));
        });
        model.nodes.forEach(function (n) {
            if (painters[n.kind] && !painters[n.kind].backdrop) {
                painters[n.kind].svg(g, n);
            }
        });
        model.pills.forEach(function (p) {
            g.appendChild(svgRect(p.x, p.y, p.w, PILL_H, {
                rx: 8, fill: p.bg, stroke: p.color, sw: 1
            }));
            g.appendChild(svgText(p.x + p.w / 2, p.y + 11.5, p.text, {
                size: 9.5, fill: p.fg, anchor: 'middle', mono: true
            }));
        });
        doc.appendChild(g);

        doc.appendChild(svgText(PAD, h - 11, opts.footerLeft || '',
                                { size: 10.5, fill: C.t3 }));
        doc.appendChild(svgText(w - PAD, h - 11, opts.footerRight || '',
                                { size: 10.5, fill: C.t3, anchor: 'end' }));
        return doc;
    }

    function triggerDownload(href, filename, revoke) {
        var a = document.createElement('a');
        a.href = href;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        if (revoke) {
            window.setTimeout(function () { window.URL.revokeObjectURL(href); }, 4000);
        }
    }
    function downloadSvg(doc, filename) {
        if (!doc) { return; }
        var xml = '<?xml version="1.0" encoding="UTF-8"?>'
                + String.fromCharCode(10)
                + new window.XMLSerializer().serializeToString(doc);
        var blob = new window.Blob([xml], { type: 'image/svg+xml;charset=utf-8' });
        triggerDownload(window.URL.createObjectURL(blob), filename, true);
    }
    /* The export document rasterised, as a PNG data URL.
     *
     * Two callers with two different budgets: the PNG download wants the
     * sharpest file the browser will make, while the PDF export has to post
     * the same picture up to the server, where an unbounded canvas would
     * mean an unbounded request. `opts.maxWidth` caps the long edge for the
     * second case; `opts.scale` is the multiplier the first one wants.
     *
     * Asynchronous because the SVG has to be decoded as an image before it
     * can be drawn - `cb(dataUrl)` on success, `cb(null)` if the browser
     * refuses the image, so a caller can degrade rather than hang. */
    function renderPng(doc, opts, cb) {
        if (!doc) { cb(null); return; }
        opts = opts || {};
        var w = Number(doc.getAttribute('width'));
        var h = Number(doc.getAttribute('height'));
        var scale = opts.scale || 2;
        if (opts.maxWidth && w * scale > opts.maxWidth) {
            scale = opts.maxWidth / w;
        }
        var xml = new window.XMLSerializer().serializeToString(doc);
        var img = new window.Image();
        img.onload = function () {
            var canvas = document.createElement('canvas');
            canvas.width = Math.max(1, Math.round(w * scale));
            canvas.height = Math.max(1, Math.round(h * scale));
            var ctx = canvas.getContext('2d');
            ctx.fillStyle = C.sunken;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.scale(scale, scale);
            ctx.drawImage(img, 0, 0);
            try {
                cb(canvas.toDataURL('image/png'));
            } catch (err) {
                cb(null);
            }
        };
        img.onerror = function () { cb(null); };
        img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(xml);
    }
    function downloadPng(doc, filename) {
        renderPng(doc, { scale: 2 }, function (url) {
            if (url) { triggerDownload(url, filename); }
        });
    }
    function stampedFilename(parts, ext) {
        var d = new Date();
        var stamp = d.getFullYear() + ('0' + (d.getMonth() + 1)).slice(-2)
                  + ('0' + d.getDate()).slice(-2);
        return parts.join('-').replace(/[^A-Za-z0-9._-]+/g, '-')
                   .replace(/-+/g, '-').toLowerCase() + '-' + stamp + '.' + ext;
    }

    /* ---- viewport -----------------------------------------------------
       Pan, zoom and fit over a fixed coordinate world. The world is
       scaled and translated AS A WHOLE, so nothing inside it ever needs
       to know about the viewport - which is what lets the layout be
       authored in absolute coordinates. */
    function viewport(stage, worldEl, opts) {
        opts = opts || {};
        var view = { x: 0, y: 0, k: 1 };
        var fitK = 1;
        var current = null;
        var drag = null;

        function apply() {
            worldEl.style.transform = 'translate(' + px(view.x) + ', '
                + px(view.y) + ') scale(' + view.k + ')';
        }
        /* Never magnifies: the layout is authored at 1:1 and blowing it
           up only makes a small estate look coarse. */
        function fit() {
            var r = stage.getBoundingClientRect();
            if (!current || !r.width || !r.height) { return; }
            var pad = 16;
            var k = Math.min(1, (r.width - pad * 2) / current.w,
                             (r.height - pad * 2) / current.h);
            fitK = k;
            view.k = k;
            view.x = (r.width - current.w * k) / 2;
            view.y = (r.height - current.h * k) / 2;
            apply();
        }
        function zoomAt(mx, my, f) {
            var k = Math.max(fitK * 0.5, Math.min(3, view.k * f));
            f = k / view.k;
            view.x = mx - (mx - view.x) * f;
            view.y = my - (my - view.y) * f;
            view.k = k;
            apply();
        }
        function zoomBy(f) {
            var r = stage.getBoundingClientRect();
            zoomAt(r.width / 2, r.height / 2, f);
        }

        stage.addEventListener('wheel', function (e) {
            e.preventDefault();
            var r = stage.getBoundingClientRect();
            zoomAt(e.clientX - r.left, e.clientY - r.top,
                   e.deltaY < 0 ? 1.1 : 1 / 1.1);
        }, { passive: false });

        stage.addEventListener('mousedown', function (e) {
            if (e.target.closest('.arch-card')) { return; }
            drag = { x: e.clientX, y: e.clientY, vx: view.x, vy: view.y };
            stage.classList.add('panning');
        });
        window.addEventListener('mousemove', function (e) {
            if (!drag) { return; }
            var dx = e.clientX - drag.x, dy = e.clientY - drag.y;
            if (dx * dx + dy * dy > 9) { drag.moved = true; }
            view.x = drag.vx + dx;
            view.y = drag.vy + dy;
            apply();
        });
        window.addEventListener('mouseup', function () {
            /* A press that began on empty canvas and did not turn into a
               pan is a click on the background: the conventional way to
               drop a selection. */
            if (drag && !drag.moved && opts.onBackgroundClick) {
                opts.onBackgroundClick();
            }
            drag = null;
            stage.classList.remove('panning');
        });

        var resizeTimer;
        window.addEventListener('resize', function () {
            window.clearTimeout(resizeTimer);
            resizeTimer = window.setTimeout(fit, 120);
        });

        return {
            /* `keep` re-applies the current pan/zoom instead of re-fitting,
               so a filter or a selection does not throw the reader's view
               away. */
            attach: function (model, keep) {
                current = model;
                if (keep) { apply(); } else { fit(); }
            },
            fit: fit,
            zoomIn: function () { zoomBy(1.2); },
            zoomOut: function () { zoomBy(1 / 1.2); }
        };
    }

    return {
        SVGNS: SVGNS, C: C, SANS: SANS, MONO: MONO, MID: MID,
        el: el, svgEl: svgEl, clear: clear, trunc: trunc, plural: plural,
        px: px, interactive: interactive, bcInk: bcInk, bcSoft: bcSoft,
        orthPath: orthPath, newModel: newModel, addRoute: addRoute,
        addPill: addPill, addCap: addCap, addBand: addBand, addNode: addNode,
        span: span, PILL_H: PILL_H,
        paint: paint, baseBox: baseBox, markerDefs: markerDefs,
        svgText: svgText, svgRect: svgRect, fit: fit,
        modelBounds: modelBounds, exportSvg: exportSvg,
        downloadSvg: downloadSvg, downloadPng: downloadPng,
        renderPng: renderPng,
        stampedFilename: stampedFilename, viewport: viewport
    };
}());
