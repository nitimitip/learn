/* Shared navigation behavior for every Workforce screen. */
(function () {
  var toggle = document.getElementById('sidebarToggle');
  var shell = document.getElementById('appShell');
  if (!toggle || !shell) return;
  var sidebar = document.getElementById('workforceSidebar');
  var mobile = window.matchMedia('(max-width: 992px)');
  function setOpen(open, restoreFocus) {
    shell.classList.toggle('sidebar-open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
    if (sidebar) sidebar.inert = mobile.matches && !open;
    if (restoreFocus) toggle.focus();
  }
  setOpen(false);
  mobile.addEventListener('change', function () { setOpen(false); });
  toggle.addEventListener('click', function () {
    setOpen(!shell.classList.contains('sidebar-open'));
  });
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && shell.classList.contains('sidebar-open')) setOpen(false, true);
  });
  shell.addEventListener('click', function (event) {
    if (!event.target.closest('.sidebar') && !event.target.closest('#sidebarToggle')) setOpen(false);
  });
  // Associate legacy filter labels with their controls without changing form names.
  document.querySelectorAll('label.form-label').forEach(function (label, index) {
    if (label.htmlFor) return;
    var control = label.parentElement.querySelector('input,select,textarea');
    if (!control) return;
    if (!control.id) control.id = 'wf-field-' + index;
    label.htmlFor = control.id;
  });
})();
