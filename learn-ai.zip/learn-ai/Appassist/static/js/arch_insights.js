/*
 * arch_insights.js - the analysis panels below both architecture diagrams.
 *
 * WHY THIS EXISTS
 * ---------------
 * The Architecture View (grouped by delivery tower) and the Enterprise
 * Architect view (grouped by business area) draw the SAME estate and ask the
 * same questions of it. The server already answers those questions once, in
 * modules/application_support/insights.py, parameterised by the grouping.
 * This file is the other half of that bargain: one renderer for both pages,
 * so a panel added here appears on both and a number fixed here is fixed on
 * both. Two copies of this would have disagreed within a week.
 *
 * WHAT IT RENDERS
 *
 * Three tiers, in the order a business architect reads them.
 *
 * The BRIEF - renderBrief(): the Business Architecture reading of the
 *   estate as ten visuals (KPI rail, share bars, bullet chart against
 *   target, short tables), each with three lines: shows / why / action.
 *
 * The EXECUTIVE half - the reading of the estate:
 *   executive     the estate health index, the summary paragraph that gets
 *                 pasted into a pack, what is working, what needs a
 *                 decision, and the three items to commission first
 *   scorecard     seven graded dimensions, each a business question, each
 *                 showing the drivers that produced the grade
 *   agenda        the findings filed the way work is commissioned - by
 *                 theme, against a role, in a Now / Next / Later horizon
 *   profiles      one plain-language card per group, ordered by risk
 *
 * The EVIDENCE half - the measurement underneath it. Every figure in the
 * executive half is computed from these, never separately:
 *   tiles         headline measures for the estate as recorded
 *   matrix        the DIRECTIONAL group-to-group integration matrix, with
 *                 fan-out / fan-in margins, heat shading, three readings and
 *                 a click-through to the actual application-to-application
 *                 links behind any cell
 *   coupling      per-group cohesion, autonomy and role
 *   applications  the applications carrying the most traffic
 *   continuity    criticality inversion, third-party dependency, thin cover
 *   protocols     the integration-style mix
 *   externals     third-party systems ranked by reach across the estate
 *   ownership     the cross-tab against the OTHER grouping
 *   technology    standardisation and one-of-a-kind technologies
 *   coverage      how much of the map is evidence and how much is inference
 *
 * Every section is optional: mount() is handed a map of element ids and
 * simply skips the ones the page did not ask for.
 *
 * The numbers come from the insights pack. The click-through needs the raw
 * graph as well - the pack deliberately carries aggregates rather than every
 * edge - so mount() takes both, and group membership is read from the graph's
 * own grouping payload exactly as the server reads it. Neither side
 * re-derives what the other already decided.
 */
window.ArchInsights = (function () {
    'use strict';

    var K = window.ArchKit;
    var MID = (K && K.MID) || '\u00B7';
    var DASH = '\u2014';

    function el(tag, cls, text) {
        var n = document.createElement(tag);
        if (cls) { n.className = cls; }
        if (text !== undefined && text !== null) { n.textContent = text; }
        return n;
    }
    function clear(node) {
        while (node && node.firstChild) { node.removeChild(node.firstChild); }
    }
    function plural(n, one, many) {
        return n + ' ' + (n === 1 ? one : (many || one + 's'));
    }
    function trunc(s, n) {
        s = String(s === undefined || s === null ? '' : s);
        return s.length > n ? s.slice(0, n - 1) + '\u2026' : s;
    }
    function pct(v) { return (v === null || v === undefined) ? 'n/a' : v + '%'; }

    /* Where a section's body and its summary counter live. Missing ids are
       not an error - a page may show four of these panels and not the rest. */
    function node(ids, key) {
        var id = ids && ids[key];
        return id ? document.getElementById(id) : null;
    }
    function setCount(ids, key, value) {
        var n = node(ids, key);
        if (n) { n.textContent = value; }
    }

    /* ---- generic table -------------------------------------------------
       columns: [{ head, cls, cell(row) -> string | Node }] */
    function table(columns, rows, opts) {
        opts = opts || {};
        var wrap = el('div', 'ins-wrap');
        var t = el('table', 'ins-table');
        var thead = el('thead');
        var hr = el('tr');
        columns.forEach(function (c) {
            var th = el('th', c.cls || null, c.head);
            hr.appendChild(th);
        });
        thead.appendChild(hr);
        t.appendChild(thead);
        var tbody = el('tbody');
        rows.forEach(function (row) {
            var tr = el('tr');
            columns.forEach(function (c) {
                var td = el('td', c.cls || null);
                var value = c.cell(row);
                if (value instanceof Node) { td.appendChild(value); }
                else { td.textContent = (value === null || value === undefined
                                         || value === '') ? '\u2014'
                                        : String(value); }
                tr.appendChild(td);
            });
            tbody.appendChild(tr);
        });
        t.appendChild(tbody);
        if (opts.caption) {
            t.appendChild(el('caption', null, opts.caption));
        }
        wrap.appendChild(t);
        return wrap;
    }

    function section(body, heading, note) {
        if (heading) {
            var h = el('p', 'ins-note');
            h.appendChild(el('strong', null, heading));
            if (note) {
                h.appendChild(document.createTextNode(' ' + MID + ' ' + note));
            }
            body.appendChild(h);
        } else if (note) {
            body.appendChild(el('p', 'ins-note', note));
        }
    }

    function empty(body, text) {
        body.appendChild(el('p', 'ins-empty', text));
    }

    /* A clickable name that drills the diagram above to that thing. Falls
       back to plain text when the page did not supply a handler, so a panel
       is never a dead button. */
    function link(text, title, handler) {
        if (!handler) { return el('span', 'ins-name', text); }
        var b = el('button', 'ins-name', text);
        b.type = 'button';
        b.style.cssText = 'background:none;border:0;padding:0;font:inherit;'
            + 'color:var(--brand-ink);cursor:pointer;text-align:left;'
            + 'font-weight:600;';
        b.title = title || ('Open ' + text);
        b.addEventListener('click', handler);
        return b;
    }
    function chip(text, title, handler) {
        var n = el(handler ? 'button' : 'span', 'ins-chip', text);
        if (handler) {
            n.type = 'button';
            n.addEventListener('click', handler);
        }
        if (title) { n.title = title; }
        return n;
    }

    /* ===================================================================
       Group membership - read from the graph exactly as the server reads it
       =================================================================== */
    var SOURCE = { tower: 'towers', domain: 'categories' };

    function membership(graph, grouping) {
        var of = new Map();
        (graph[SOURCE[grouping] || 'categories'] || []).forEach(function (g) {
            (g.app_ids || []).forEach(function (id) { of.set(id, g.id); });
        });
        return of;
    }

    /* Each link as one or two directed flows - a bi-directional interface is
       one edge in the graph but genuinely traffic both ways, which is the
       same rule insights._directed_pairs applies server-side. */
    function flows(graph) {
        var out = [];
        (graph.links || []).forEach(function (l) {
            out.push({ src: l.src_app, dst: l.dst_app, link: l });
            if (l.bidir) { out.push({ src: l.dst_app, dst: l.src_app, link: l }); }
        });
        return out;
    }

    /* ===================================================================
       Headline tiles
       =================================================================== */
    function renderTiles(body, data) {
        clear(body);
        var h = data.headline || {};
        var noun = data.noun || 'group';
        [
            { k: 'Applications', v: h.apps,
              s: 'active records in the estate' },
            { k: data.plural || 'Groups', v: h.groups,
              s: 'holding at least one application' },
            { k: 'Cross-' + noun + ' interfaces', v: h.cross,
              s: plural(h.pairs || 0, 'connected ' + noun + ' pair') },
            { k: 'Estate autonomy', v: pct(h.autonomy),
              s: 'share of interfaces that never leave their own ' + noun },
            { k: 'Within-' + noun + ' interfaces', v: h.intra,
              s: 'traffic that stays inside one ' + noun },
            { k: 'External systems', v: h.externals,
              s: 'third parties the estate feeds or reads from' },
            { k: 'Evidence-backed', v: pct(h.evidence),
              s: 'links matched by a recorded hostname, not a name' },
            { k: 'High findings', v: h.high,
              s: h.high ? 'need an owner and a date' : 'nothing at high severity' }
        ].forEach(function (t) {
            var card = el('div', 'ins-tile');
            card.appendChild(el('div', 'k', t.k));
            card.appendChild(el('div', 'v', t.v === undefined ? '\u2014' : t.v));
            card.appendChild(el('div', 's', t.s));
            body.appendChild(card);
        });
    }

    /* ===================================================================
       The Business Architecture brief

       The top of the panel, and in practice the only part most readers
       open. It is written for a Business Architecture review: ten
       questions, each answered by ONE visual - a KPI rail, a stacked
       share bar, a proportion chart, a bullet chart against target, or a
       short table - and three lines under it saying what the visual
       shows, why it matters and what to decide.

       Everything here is drawn from data.brief (arch_brief.py), including
       the three lines: they are computed beside the figures they describe
       so the words on screen, in the PDF and in the numbers cannot
       disagree. Nothing here is a paragraph.
       =================================================================== */

    /* A card. One question per card, a heading that states the question, and
       a figure in the corner that answers it before the reader looks at
       anything else. */
    function briefCard(cls, title, hint, figure) {
        var card = el('section', 'brief-card ' + (cls || ''));
        var head = el('header', 'bc-head');
        var left = el('div', 'bc-headings');
        left.appendChild(el('h4', 'bc-title', title));
        if (hint) { left.appendChild(el('p', 'bc-hint', hint)); }
        head.appendChild(left);
        if (figure) {
            var fig = el('div', 'bc-figure' + (figure.tone ? ' t-' + figure.tone : ''));
            fig.appendChild(el('span', 'bc-fig-v', figure.value));
            if (figure.label) {
                fig.appendChild(el('span', 'bc-fig-l', figure.label));
            }
            head.appendChild(fig);
        }
        card.appendChild(head);
        var body = el('div', 'bc-body');
        card.appendChild(body);
        return { card: card, body: body };
    }

    /* Three short lines under every visual - what it shows, why it
       matters, what to do - served with the numbers (arch_brief
       .build_readings) so the PDF says exactly the same thing. */
    function reading(card, r) {
        if (!r) { return; }
        var box = el('div', 'bc-read');
        [['Shows', r.shows], ['Why', r.why], ['Action', r.action]]
            .forEach(function (p) {
                if (!p[1]) { return; }
                var line = el('p', 'bc-read-line');
                line.appendChild(el('span', 'bc-read-k', p[0]));
                line.appendChild(document.createTextNode(p[1]));
                box.appendChild(line);
            });
        card.body.appendChild(box);
    }

    /* A labelled proportion bar. The share is relative to the biggest row in
       its own card, not to 100 - a mix where nothing passes 20% would
       otherwise render as six empty tracks. */
    function meterRow(label, value, share, tone, title) {
        var row = el('div', 'bmeter' + (tone ? ' t-' + tone : ''));
        var lab = el('span', 'bm-lab', label);
        if (title) { lab.title = title; }
        row.appendChild(lab);
        var track = el('span', 'bm-track');
        var fill = el('span', 'bm-fill');
        fill.style.width = Math.max(0, Math.min(100, share || 0)) + '%';
        track.appendChild(fill);
        row.appendChild(track);
        row.appendChild(el('span', 'bm-val', value));
        return row;
    }

    /* The criticality spread as ONE segmented bar rather than three separate
       ones: the question is what share of the estate sits in each tier, and
       three bars make that a subtraction. */
    function tierBar(tiers, total) {
        var bar = el('div', 'btier');
        tiers.forEach(function (t) {
            if (!t.count) { return; }
            var code = String(t.code || 'na').toLowerCase();
            var seg = el('span', 'bt-seg bt-' + code);
            seg.style.width = (total ? (100 * t.count / total) : 0) + '%';
            seg.title = t.label + ' ' + MID + ' ' + plural(t.count, 'application');
            seg.appendChild(el('span', 'bt-n', String(t.count)));
            bar.appendChild(seg);
        });
        return bar;
    }

    /* A part-to-whole bar for any mix: segments [{label, value, tone,
       title}], plus a legend row so identity is never colour alone. */
    function shareBar(segments, total) {
        var wrap = el('div', 'bshare');
        var bar = el('div', 'bshare-bar');
        var legend = el('div', 'bshare-legend');
        segments.forEach(function (s) {
            if (!s.value) { return; }
            var share = total ? (100 * s.value / total) : 0;
            var seg = el('span', 'bs-seg t-' + (s.tone || 'brand'));
            seg.style.width = share + '%';
            seg.title = s.label + ' ' + MID + ' ' + s.value + ' (' + share.toFixed(1) + '%)';
            if (share >= 9) { seg.appendChild(el('span', 'bs-n', String(s.value))); }
            bar.appendChild(seg);
            var key = el('span', 'bs-key');
            key.appendChild(el('span', 'bs-swatch t-' + (s.tone || 'brand')));
            key.appendChild(document.createTextNode(s.label + ' '));
            key.appendChild(el('b', null, s.value + ' ' + MID + ' ' + share.toFixed(0) + '%'));
            if (s.title) { key.title = s.title; }
            legend.appendChild(key);
        });
        wrap.appendChild(bar);
        wrap.appendChild(legend);
        return wrap;
    }

    /* A status pill: met / close / gap / not measured, and the horizon
       marks. Text plus colour, never colour alone. */
    var STATUS_LABEL = { met: 'Met', close: 'Close', gap: 'Gap',
                         unmeasured: 'Not measured' };
    function pill(kind, text) {
        return el('span', 'bpill p-' + kind, text);
    }

    function renderBrief(ctx) {
        var host = node(ctx.ids, 'brief');
        if (!host) { return; }
        clear(host);
        var b = ctx.data.brief;
        if (!b) {
            empty(host, 'The architecture brief is not available for this estate yet.');
            return;
        }
        host.appendChild(briefRail(b));
        /* Eight question cards in a packed two-column flow rather than a
           grid: cards of very different heights in a grid leave a
           card-sized hole beside the shortest one. The risk and decision
           cards are the brief's conclusion, so they sit outside that flow
           and span the full width. */
        host.appendChild(packColumns(host, [
            briefCapability(ctx, b),
            briefIntegration(ctx, b),
            briefDependency(ctx, b),
            briefExternals(ctx, b),
            briefPlatform(ctx, b),
            briefOwnership(ctx, b),
            briefAlignment(ctx, b),
            briefOpportunities(ctx, b)
        ]));
        host.appendChild(briefRisks(ctx, b));
        host.appendChild(briefDecisions(ctx, b));
    }

    /* Eight cards of very different heights into two columns. A CSS grid
       leaves a card-sized hole beside the shortest card and a column flow
       leaves the tail of one column empty, so the cards are measured and
       each one goes into whichever column is currently shorter. Reading
       order is preserved down each column. Below the one-column
       breakpoint the stylesheet stacks the two columns, so the packing is
       harmless there. */
    function packColumns(host, cards) {
        var grid = el('div', 'brief-grid');
        var cols = [el('div', 'brief-col'), el('div', 'brief-col')];
        grid.appendChild(cols[0]);
        grid.appendChild(cols[1]);
        /* Measure off-screen at the column width the grid will give them. */
        var probe = el('div', 'brief-grid brief-probe');
        var probeCol = el('div', 'brief-col');
        probe.appendChild(probeCol);
        probe.appendChild(el('div', 'brief-col'));
        host.appendChild(probe);
        var heights = cards.map(function (card) {
            probeCol.appendChild(card);
            var h = card.offsetHeight || 0;
            probeCol.removeChild(card);
            return h;
        });
        host.removeChild(probe);
        var tall = [0, 0];
        cards.forEach(function (card, i) {
            var side = tall[1] < tall[0] ? 1 : 0;
            cols[side].appendChild(card);
            tall[side] += heights[i] + 14;
        });
        return grid;
    }

    /* ---- the metric rail ----------------------------------------------- */
    function briefRail(b) {
        var rail = el('div', 'brief-rail');
        (b.rail || []).forEach(function (m) {
            var cell = el('div', 'brail' + (m.tone ? ' t-' + m.tone : ''));
            cell.appendChild(el('div', 'br-lab', m.label));
            cell.appendChild(el('div', 'br-val', String(m.value)));
            cell.appendChild(el('div', 'br-note', m.note || ''));
            rail.appendChild(cell);
        });
        return rail;
    }

    /* ---- business capabilities ----------------------------------------- */
    function briefCapability(ctx, b) {
        var cap = b.capability || {};
        var tiers = cap.tiers || [];
        var noun = b.noun || 'group';
        var card = briefCard('bc-capability', 'Business capabilities',
            'criticality tiers, and where the critical ones sit',
            { value: String(cap.bc1 || 0), label: 'BC1 systems',
              tone: cap.bc1 ? 'critical' : '' });

        card.body.appendChild(tierBar(tiers, cap.total || 0));
        card.body.appendChild(table([
            { head: 'Tier', cell: function (t) {
                  var s = el('span');
                  s.appendChild(el('span', 'btr-code bt-' + String(t.code || 'na').toLowerCase(), t.code || 'n/r'));
                  s.appendChild(document.createTextNode(' ' + t.label.replace(/^Tier \d - /, '')));
                  return s;
              } },
            { head: 'Apps', cls: 'num', cell: function (t) { return t.count + ' ' + MID + ' ' + pct(t.pct); } },
            { head: 'Links', cls: 'num', cell: function (t) { return t.connections; } },
            { head: '3rd-party', cls: 'num', cell: function (t) { return t.external_facing || DASH; } },
            { head: 'Unlinked', cls: 'num', cell: function (t) { return t.isolated || DASH; } }
        ], tiers));

        var groups = (cap.by_group || []).slice(0, 6);
        if (groups.length) {
            card.body.appendChild(el('p', 'bc-sub', 'By ' + noun));
            card.body.appendChild(table([
                { head: b.label || 'Group', cell: function (g) {
                      return link(trunc(g.name, 30), 'Open ' + g.name,
                          ctx.onOpenGroup ? function () { ctx.onOpenGroup(g.id); } : null);
                  } },
                { head: 'Apps', cls: 'num', cell: function (g) { return g.apps; } },
                { head: 'BC1', cls: 'num', cell: function (g) { return g.bc1 || DASH; } },
                { head: 'BC2', cls: 'num', cell: function (g) { return (g.mix || {}).BC2 || DASH; } },
                { head: 'BC3', cls: 'num', cell: function (g) { return (g.mix || {}).BC3 || DASH; } },
                { head: 'BC1 share', cls: 'num', cell: function (g) { return pct(g.bc1_pct); } }
            ], groups));
        }
        reading(card, (b.readings || {}).capability);
        return card.card;
    }

    /* ---- key systems and integrations ---------------------------------- */
    function briefIntegration(ctx, b) {
        var it = b.integration || {};
        var card = briefCard('bc-integration', 'Integration patterns',
            'how the estate joins its systems together',
            { value: pct(it.loose_pct), label: 'loosely coupled',
              tone: (it.loose_pct >= 50) ? 'good' : 'warn' });

        var TONE = { loose: 'good', tight: 'warn', unknown: 'mute' };
        card.body.appendChild(shareBar((it.patterns || []).map(function (p) {
            return { label: p.pattern, value: p.count,
                     tone: TONE[p.coupling] || 'brand', title: p.note };
        }), it.interfaces || 0));

        card.body.appendChild(briefFacts([
            ['Connections', it.connections],
            ['Interface records', it.interfaces],
            ['Crossing a ' + (b.noun || 'group'), it.cross_group],
            ['Protocols in use', it.protocol_count]
        ]));
        reading(card, (b.readings || {}).integration);
        return card.card;
    }

    /* Four small figures under a chart. Deliberately not a table: they are
       read, not compared. */
    function briefFacts(pairs) {
        var facts = el('div', 'bfacts');
        pairs.forEach(function (f) {
            var cell = el('div', 'bfact');
            cell.appendChild(el('span', 'bf-v', String(f[1])));
            cell.appendChild(el('span', 'bf-k', f[0]));
            facts.appendChild(cell);
        });
        return facts;
    }

    /* ---- application dependencies -------------------------------------- */
    var DEP_SHOWN = 8;

    function briefDependency(ctx, b) {
        var dep = b.dependency || {};
        var rows = (dep.rows || []).slice(0, DEP_SHOWN);
        var card = briefCard('bc-dependency', 'Key systems and dependencies',
            'the applications most of the estate runs through',
            { value: String((dep.hubs || []).length), label: 'load bearing',
              tone: (dep.hubs || []).length ? 'warn' : '' });

        if (!rows.length) {
            empty(card.body, 'No application-to-application connection has '
                + 'resolved yet.');
        } else {
            card.body.appendChild(table([
                { head: 'Application',
                  cell: function (r) {
                      return link(trunc(r.app, 30), 'Open ' + r.app,
                          ctx.onOpenApp ? function () { ctx.onOpenApp(r.app_id); } : null);
                  } },
                { head: 'BC', cls: 'num', cell: function (r) { return r.bc || DASH; } },
                { head: 'Depends on', cls: 'num',
                  cell: function (r) { return r.upstream + r.ext_upstream; } },
                { head: 'Feeds', cls: 'num',
                  cell: function (r) { return r.downstream + r.ext_downstream; } },
                { head: 'Cross-' + (b.noun || 'group'), cls: 'num',
                  cell: function (r) { return r.cross || DASH; } }
            ], rows));
            if ((dep.total_connected || 0) > rows.length) {
                card.body.appendChild(el('p', 'bc-more',
                    '+ ' + (dep.total_connected - rows.length)
                    + ' more connected applications in Supporting evidence'));
            }
        }
        reading(card, (b.readings || {}).dependency);
        return card.card;
    }

    /* ---- upstream and downstream third parties -------------------------- */
    var EXT_SHOWN = 6;

    function briefExternals(ctx, b) {
        var dep = b.dependency || {};
        var rows = (dep.externals || []).slice(0, EXT_SHOWN);
        var card = briefCard('bc-externals', 'Third-party systems',
            'suppliers the estate reads from or feeds',
            { value: String(dep.external_count || 0), label: 'systems' });

        if (!rows.length) {
            empty(card.body, 'Every recorded interface resolves to an '
                + 'application inside the estate.');
        } else {
            card.body.appendChild(table([
                { head: 'System', cell: function (r) { return trunc(r.name, 30); } },
                { head: 'Direction',
                  cell: function (r) {
                      var key = String(r.role).toLowerCase().split(' ').join('-');
                      return el('span', 'bdir d-' + key, r.role);
                  } },
                { head: 'Apps', cls: 'num', cell: function (r) { return r.apps; } },
                { head: 'BC1', cls: 'num', cell: function (r) { return r.bc1 || DASH; } }
            ], rows));
            if ((dep.external_count || 0) > rows.length) {
                card.body.appendChild(el('p', 'bc-more',
                    '+ ' + (dep.external_count - rows.length) + ' more'));
            }
        }
        reading(card, (b.readings || {}).externals);
        return card.card;
    }

    /* ---- technology dependencies --------------------------------------- */
    var OS_SHOWN = 5;

    function briefPlatform(ctx, b) {
        var pf = b.platform || {};
        var card = briefCard('bc-platform', 'Technology dependencies',
            'operating systems, then the recorded stack',
            { value: String((pf.os_dated || []).length), label: 'lifecycle checks',
              tone: (pf.os_dated || []).length ? 'warn' : 'good' });

        if (!(pf.os || []).length) {
            empty(card.body, 'No operating system is recorded against any '
                + 'server or application stack.');
        } else {
            var max = pf.os[0].apps || 1;
            pf.os.slice(0, OS_SHOWN).forEach(function (o) {
                card.body.appendChild(meterRow(
                    o.name + (o.dated ? '  \u25B2' : ''),
                    plural(o.apps, 'app') + (o.servers
                        ? '  ' + MID + '  ' + plural(o.servers, 'server') : ''),
                    100 * o.apps / max,
                    o.dated ? 'warn' : 'brand',
                    o.dated ? 'Lifecycle check needed for this platform'
                            : 'Recorded from ' + o.source));
            });
            if (pf.os.length > OS_SHOWN) {
                card.body.appendChild(el('p', 'bc-more',
                    '+ ' + (pf.os.length - OS_SHOWN) + ' more operating systems'));
            }
        }

        if ((pf.stack || []).length) {
            card.body.appendChild(table([
                { head: 'Layer', cell: function (s) { return s.label; } },
                { head: 'Distinct', cls: 'num', cell: function (s) { return s.distinct; } },
                { head: 'Used once', cls: 'num', cell: function (s) { return s.singletons || DASH; } },
                { head: 'Most used', cell: function (s) {
                      return (s.top || []).slice(0, 2).map(function (t) {
                          return t.name + ' (' + t.apps + ')';
                      }).join(', ');
                  } }
            ], pf.stack));
        }
        card.body.appendChild(briefFacts([
            ['Servers', pf.servers],
            ['Sites', pf.location_count],
            ['Stacks recorded', pct(pf.documented_pct)],
            ['Single-use tech', pf.singleton_count]
        ]));
        reading(card, (b.readings || {}).platform);
        return card.card;
    }

    /* ---- ownership and accountability ---------------------------------- */
    var OWN_SHOWN = 6;

    function briefOwnership(ctx, b) {
        var own = b.ownership || {};
        var rows = (own.rows || []).slice(0, OWN_SHOWN);
        var total = (own.owner_named || 0) + (own.owner_missing || 0);
        var card = briefCard('bc-ownership', 'Ownership and accountability',
            'who stands behind each ' + (b.noun || 'group'),
            { value: pct(own.owner_pct), label: 'owner named',
              tone: own.owner_missing ? ((own.bc1_unowned || []).length ? 'critical' : 'warn') : 'good' });

        var src = own.sourcing || {};
        card.body.appendChild(shareBar([
            { label: 'Vendor supplied', value: src.vendor || 0, tone: 'brand' },
            { label: 'Bespoke', value: src.bespoke || 0, tone: 'accent' },
            { label: 'Sourcing not recorded', value: src.unknown || 0, tone: 'mute' }
        ], total));

        if (rows.length) {
            var counterpart = own.has_lead ? 'Business areas' : 'Supported by';
            card.body.appendChild(table([
                { head: own.label || 'Group', cell: function (r) {
                      return link(trunc(r.name, 26), 'Open ' + r.name,
                          ctx.onOpenGroup ? function () { ctx.onOpenGroup(r.id); } : null);
                  } },
                { head: counterpart, cell: function (r) {
                      var shown = (r.counterparts || []).slice(0, 2);
                      var names = shown.map(function (n) { return trunc(n, 18); }).join(', ');
                      if (r.counterpart_count > shown.length) {
                          names += ' +' + (r.counterpart_count - shown.length);
                      }
                      var cell = el('span', null, names || DASH);
                      cell.title = (r.counterparts || []).join(', ');
                      return cell;
                  } },
                { head: 'Lead', cell: function (r) {
                      var leads = r.leads || [];
                      var cell = el('span', null, leads.length
                          ? trunc(leads[0], 18) + (leads.length > 1 ? ' +' + (leads.length - 1) : '')
                          : DASH);
                      cell.title = leads.join(', ');
                      return cell;
                  } },
                { head: 'Owner named', cls: 'num', cell: function (r) { return r.owner_named + '/' + r.apps; } },
                { head: 'BC1 unowned', cls: 'num', cell: function (r) {
                      return r.bc1_unowned ? el('span', 'bwarn', String(r.bc1_unowned)) : DASH;
                  } }
            ], rows));
        } else {
            empty(card.body, 'No ' + (b.noun || 'group') + ' holds an application yet.');
        }
        reading(card, (b.readings || {}).ownership);
        return card.card;
    }

    /* ---- strategic alignment ------------------------------------------- */
    function briefAlignment(ctx, b) {
        var al = b.alignment || {};
        var rows = al.rows || [];
        var card = briefCard('bc-alignment', 'Strategic alignment',
            'the estate against the architecture principles, each with a target',
            { value: (al.met || 0) + '/' + (al.measured || 0), label: 'principles met',
              tone: (al.measured && al.met === al.measured) ? 'good'
                    : (al.met < (al.measured || 0) - 2 ? 'warn' : '') });

        var list = el('div', 'balign');
        rows.forEach(function (r) {
            var row = el('div', 'bal-row s-' + r.status);
            row.title = r.why + ' ' + MID + ' ' + r.measure;
            var lab = el('span', 'bal-lab', r.label);
            row.appendChild(lab);
            var track = el('span', 'bal-track');
            var fill = el('span', 'bal-fill');
            fill.style.width = (r.value === null || r.value === undefined ? 0
                : Math.max(0, Math.min(100, r.value))) + '%';
            track.appendChild(fill);
            var tick = el('span', 'bal-target');
            tick.style.left = Math.max(0, Math.min(100, r.target)) + '%';
            tick.title = 'Target ' + r.target + '%';
            track.appendChild(tick);
            row.appendChild(track);
            row.appendChild(el('span', 'bal-val',
                (r.value === null || r.value === undefined) ? DASH : r.value + '%'));
            row.appendChild(pill(r.status, STATUS_LABEL[r.status] || r.status));
            list.appendChild(row);
        });
        card.body.appendChild(list);
        card.body.appendChild(el('p', 'bc-more',
            'Bar = estate today, tick = target. Hover a row for the measure.'));
        reading(card, (b.readings || {}).alignment);
        return card.card;
    }

    /* ---- modernisation opportunities ----------------------------------- */
    function briefOpportunities(ctx, b) {
        var op = b.opportunities || {};
        var rows = op.rows || [];
        var card = briefCard('bc-opportunities', 'Modernisation opportunities',
            'what the record already justifies changing',
            { value: String(op.total || 0), label: 'opportunities',
              tone: op.total ? 'warn' : 'good' });

        if (!rows.length) {
            empty(card.body, 'Nothing in the recorded estate calls for change yet.');
        } else {
            card.body.appendChild(table([
                { head: 'Opportunity', cell: function (r) { return r.title; } },
                { head: 'Scope', cls: 'num', cell: function (r) { return r.scope + ' ' + r.unit; } },
                { head: 'First candidates', cell: function (r) {
                      var names = (r.candidates || []).slice(0, 3);
                      var cell = el('span');
                      names.forEach(function (name, i) {
                          if (i) { cell.appendChild(document.createTextNode(', ')); }
                          var app = ctx.appByName.get(name);
                          cell.appendChild(link(trunc(name, 24), name,
                              (app && ctx.onOpenApp)
                                  ? function () { ctx.onOpenApp(app.id); } : null));
                      });
                      if (r.candidate_count > names.length) {
                          cell.appendChild(document.createTextNode(
                              ' +' + (r.candidate_count - names.length)));
                      }
                      return cell;
                  } },
                { head: 'Benefit', cell: function (r) { return r.benefit; } }
            ], rows));
        }
        reading(card, (b.readings || {}).opportunities);
        return card.card;
    }

    /* ---- architecture and technology risk ------------------------------- */
    function briefRisks(ctx, b) {
        var risk = b.risks || {};
        var rows = risk.rows || [];
        var counts = risk.counts || {};
        var card = briefCard('bc-risks', 'Risks and architectural concerns',
            'ranked by consequence, architecture and technology only',
            { value: String(counts.high || 0), label: 'high',
              tone: counts.high ? 'critical' : 'good' });

        if (!rows.length) {
            empty(card.body, 'Nothing in the recorded estate raises an '
                + 'architecture or technology concern.');
        } else {
            card.body.appendChild(table([
                { head: 'Severity', cell: function (r) {
                      return el('span', 'ins-sev ' + r.severity, r.severity);
                  } },
                { head: 'Risk', cell: function (r) { return el('b', null, r.title); } },
                { head: 'Measure', cls: 'num', cell: function (r) { return r.metric; } },
                { head: 'Area', cell: function (r) { return r.area; } },
                { head: 'Affects', cell: function (r) {
                      var items = r.items || [];
                      if (!items.length) { return DASH; }
                      var text = items.slice(0, 3).map(function (n) { return trunc(n, 28); }).join(', ');
                      if (items.length > 3) { text += ' +' + (items.length - 3); }
                      return text;
                  } }
            ], rows));
        }
        reading(card, (b.readings || {}).risks);
        return card.card;
    }

    /* ---- decisions required -------------------------------------------- */
    function briefDecisions(ctx, b) {
        var dec = b.decisions || {};
        var rows = dec.rows || [];
        var hz = dec.horizons || {};
        var card = briefCard('bc-decisions', 'Decisions required',
            'one line each, with the role that can take it and how soon it costs',
            { value: String(dec.total || 0), label: 'decisions',
              tone: hz.Now ? 'critical' : (dec.total ? 'warn' : 'good') });

        if (!rows.length) {
            empty(card.body, 'No decision is outstanding on the recorded estate.');
        } else {
            card.body.appendChild(table([
                { head: '#', cls: 'num', cell: function (r, i) { return String(rows.indexOf(r) + 1); } },
                { head: 'When', cell: function (r) {
                      return pill('hz-' + String(r.horizon).toLowerCase(), r.horizon);
                  } },
                { head: 'Decision', cell: function (r) { return el('b', null, r.decision); } },
                { head: 'Because', cell: function (r) { return r.because; } },
                { head: 'Owner', cell: function (r) { return r.owner; } }
            ], rows));
            if ((dec.total || 0) > rows.length) {
                card.body.appendChild(el('p', 'bc-more',
                    '+ ' + (dec.total - rows.length)
                    + ' more, listed under Full written assessment'));
            }
        }
        reading(card, (b.readings || {}).decisions);
        return card.card;
    }

    /* ===================================================================
       The integration matrix

       Three readings of one grid, because three different questions get
       asked of it:

         Directional  cell (row, col) = interfaces flowing FROM the row's
                      group INTO the column's. Who serves whom.
         Combined     the two directions added together - the older,
                      symmetric reading, kept because "how tightly are these
                      two joined" is still a question.
         Applications distinct application pairs rather than interfaces -
                      strips out the same two systems talking six ways.

       The diagonal is never blanked: traffic that stays inside a group is
       that group's cohesion, and it belongs on the same grid as the traffic
       that leaves.
       =================================================================== */
    var MODES = [
        { key: 'directed', label: 'Directional',
          hint: 'row feeds column' },
        { key: 'combined', label: 'Combined',
          hint: 'both directions added together' },
        { key: 'apps', label: 'Application pairs',
          hint: 'distinct application-to-application pairs' }
    ];

    function cellValue(cells, i, j, mode) {
        var a = cells[i][j];
        if (mode === 'apps') {
            if (i === j) { return a.app_pairs; }
            return a.app_pairs + cells[j][i].app_pairs;
        }
        if (mode === 'combined' && i !== j) {
            return a.count + cells[j][i].count;
        }
        return a.count;
    }

    function heatClass(value, max) {
        if (!value || !max) { return ''; }
        var step = Math.ceil((value / max) * 5);
        return 'h' + Math.min(5, Math.max(1, step));
    }

    function renderMatrix(ctx) {
        var body = node(ctx.ids, 'matrix');
        if (!body) { return; }
        var data = ctx.data;
        var matrix = data.matrix || {};
        var groups = matrix.groups || [];
        var cells = matrix.cells || [];
        var rows = matrix.rows || [];
        var noun = data.noun || 'group';
        setCount(ctx.ids, 'matrixCount', (matrix.totals || {}).pairs || 0);

        clear(body);
        if (groups.length < 2) {
            empty(body, 'At least two populated ' + noun + 's are needed '
                + 'before an integration matrix says anything.');
            return;
        }

        var mode = ctx.matrixMode || 'directed';

        /* ---- toolbar ---- */
        var bar = el('div', 'ins-bar');
        bar.appendChild(el('span', 'ins-lab', 'Reading'));
        var seg = el('div', 'ins-seg');
        MODES.forEach(function (m) {
            var b = el('button', m.key === mode ? 'on' : null, m.label);
            b.type = 'button';
            b.title = m.hint;
            b.setAttribute('aria-pressed', m.key === mode ? 'true' : 'false');
            b.addEventListener('click', function () {
                ctx.matrixMode = m.key;
                renderMatrix(ctx);
            });
            seg.appendChild(b);
        });
        bar.appendChild(seg);
        bar.appendChild(el('div', 'spacer'));
        var csv = el('button', 'ins-link', 'Download CSV');
        csv.type = 'button';
        csv.title = 'The matrix as it is shown, for a spreadsheet';
        csv.addEventListener('click', function () { matrixCsv(ctx, mode); });
        bar.appendChild(csv);
        body.appendChild(bar);

        /* ---- the grid ---- */
        var max = 0;
        for (var a = 0; a < groups.length; a += 1) {
            for (var b = 0; b < groups.length; b += 1) {
                if (a === b) { continue; }
                max = Math.max(max, cellValue(cells, a, b, mode));
            }
        }

        var wrap = el('div', 'ins-wrap');
        var t = el('table', 'ins-matrix');
        var thead = el('thead');
        var hr = el('tr');
        hr.appendChild(el('th', 'corner', 'FROM \\ TO'));
        groups.forEach(function (g) {
            var th = el('th', null, trunc(g.name, 16));
            th.title = g.name + ' ' + MID + ' ' + plural(g.apps, 'application');
            hr.appendChild(th);
        });
        hr.appendChild(el('th', 'margin', 'Out'));
        hr.appendChild(el('th', 'margin', 'In'));
        thead.appendChild(hr);
        t.appendChild(thead);

        var tbody = el('tbody');
        groups.forEach(function (rowGroup, i) {
            var tr = el('tr');
            var th = el('th');
            th.appendChild(link(trunc(rowGroup.name, 26), 'Open '
                + rowGroup.name, ctx.onOpenGroup
                    ? function () { ctx.onOpenGroup(rowGroup.id); } : null));
            th.title = rowGroup.name;
            tr.appendChild(th);

            groups.forEach(function (colGroup, j) {
                var value = cellValue(cells, i, j, mode);
                var td = el('td');
                td.textContent = value ? String(value) : (i === j ? '\u2014' : '\u00B7');
                if (i === j) {
                    td.className = 'self' + (value ? '' : ' zero');
                    td.title = value
                        ? plural(value, 'interface') + ' inside ' + rowGroup.name
                        : 'No traffic recorded inside ' + rowGroup.name;
                } else if (!value) {
                    td.className = 'zero';
                } else {
                    td.className = 'cell ' + heatClass(value, max);
                    td.title = mode === 'apps'
                        ? plural(value, 'application pair') + ' between '
                          + rowGroup.name + ' and ' + colGroup.name
                        : plural(value, 'interface') + ' '
                          + (mode === 'combined' ? 'between ' + rowGroup.name
                             + ' and ' + colGroup.name
                             : 'from ' + rowGroup.name + ' into ' + colGroup.name);
                }
                if (value) {
                    td.addEventListener('click', function () {
                        showPair(ctx, rowGroup, colGroup, mode);
                    });
                }
                tr.appendChild(td);
            });

            var margin = rows[i] || { out: 0, inb: 0 };
            var out = el('td', 'margin', String(margin.out));
            var inb = el('td', 'margin', String(margin.inb));
            out.title = plural(margin.out, 'interface') + ' leaving '
                + rowGroup.name;
            inb.title = plural(margin.inb, 'interface') + ' arriving in '
                + rowGroup.name;
            tr.appendChild(out);
            tr.appendChild(inb);
            tbody.appendChild(tr);
        });
        t.appendChild(tbody);
        wrap.appendChild(t);
        body.appendChild(wrap);

        var readout = el('div');
        readout.id = 'insMatrixReadout';
        body.appendChild(readout);

        var totals = matrix.totals || {};
        section(body, null,
            'Rows are sources, columns are targets. The shaded diagonal is '
            + 'traffic that never leaves the ' + noun + ' - its cohesion. '
            + 'Out and In are the fan-out and fan-in margins. '
            + totals.cross + ' interface(s) cross a ' + noun + ' boundary, '
            + totals.intra + ' stay inside one; a two-way interface counts '
            + 'once in each direction. Click any populated cell to '
            + 'see the applications behind it. The criticality filter on the '
            + 'diagram does not apply here: this is the estate as recorded.');
    }

    /* The links behind one cell, named. The pack carries aggregates on
       purpose - shipping every edge twice would double the payload for a
       panel most readers never open - so this is resolved from the graph
       the page already holds. */
    function showPair(ctx, rowGroup, colGroup, mode) {
        var host = document.getElementById('insMatrixReadout');
        if (!host) { return; }
        clear(host);
        var of = ctx.membership;
        var appById = ctx.appById;
        var wanted = [];
        flows(ctx.graph).forEach(function (f) {
            var gs = of.get(f.src), gd = of.get(f.dst);
            if (gs === undefined || gd === undefined) { return; }
            var hit = (gs === rowGroup.id && gd === colGroup.id);
            if (!hit && mode !== 'directed') {
                hit = (gs === colGroup.id && gd === rowGroup.id);
            }
            if (hit) { wanted.push(f); }
        });

        var box = el('div', 'ins-readout');
        var head = el('div', 'rhead');
        head.textContent = rowGroup.id === colGroup.id
            ? 'Inside ' + rowGroup.name
            : rowGroup.name + ' \u2192 ' + colGroup.name;
        box.appendChild(head);

        if (!wanted.length) {
            box.appendChild(el('div', 'rrow', 'No interfaces on this pair.'));
        }
        var seen = {};
        wanted.forEach(function (f) {
            var src = appById.get(f.src), dst = appById.get(f.dst);
            if (!src || !dst) { return; }
            var key = f.src + '>' + f.dst + '|' + (f.link.connectivity || '');
            if (seen[key]) { return; }
            seen[key] = true;
            var row = el('div', 'rrow');
            row.appendChild(link(src.name, 'Open ' + src.name, ctx.onOpenApp
                ? function () { ctx.onOpenApp(src.id); } : null));
            row.appendChild(el('span', 'arrow', '\u2192'));
            row.appendChild(link(dst.name, 'Open ' + dst.name, ctx.onOpenApp
                ? function () { ctx.onOpenApp(dst.id); } : null));
            var meta = [f.link.connectivity || 'Interface'];
            if (f.link.match === 'host' && f.link.via_host) {
                meta.push('via ' + f.link.via_host);
            } else if (f.link.match === 'name') {
                meta.push('matched by name');
            }
            row.appendChild(el('span', null, ' ' + MID + ' ' + meta.join(' ' + MID + ' ')));
            box.appendChild(row);
        });
        host.appendChild(box);
        box.scrollIntoView({ block: 'nearest' });
    }

    function matrixCsv(ctx, mode) {
        var matrix = ctx.data.matrix || {};
        var groups = matrix.groups || [];
        var cells = matrix.cells || [];
        var rows = matrix.rows || [];
        var q = function (s) { return '"' + String(s).replace(/"/g, '""') + '"'; };
        var lines = [['From \\ To'].concat(groups.map(function (g) { return g.name; }))
                     .concat(['Out', 'In']).map(q).join(',')];
        groups.forEach(function (g, i) {
            var line = [q(g.name)];
            groups.forEach(function (_c, j) {
                line.push(cellValue(cells, i, j, mode));
            });
            line.push((rows[i] || {}).out || 0);
            line.push((rows[i] || {}).inb || 0);
            lines.push(line.join(','));
        });
        var blob = new window.Blob([lines.join('\r\n')],
                                   { type: 'text/csv;charset=utf-8' });
        var url = window.URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = (K && K.stampedFilename)
            ? K.stampedFilename([ctx.data.noun + '-integration-matrix', mode], 'csv')
            : 'integration-matrix.csv';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.setTimeout(function () { window.URL.revokeObjectURL(url); }, 4000);
    }

    /* ===================================================================
       THE EXECUTIVE LAYER

       Everything below this comment renders the reading of the estate
       rather than the measurement of it. The panels further down are the
       evidence and stay exactly as precise as they were; these are what a
       business architect opens the page for, and they obey three rules the
       evidence panels do not have to:

         say the verdict first     a grade and a sentence, before any table
         no vocabulary to learn    no fan-in, no autonomy index, no degree
         nothing without a number  every sentence here is computed, and the
                                   figure that produced it is one panel away

       The server does the judging (insights.build_scorecard and friends) so
       that the same words appear on screen, in the CSV and in the PDF. This
       file only lays them out.
       =================================================================== */

    var GRADE_CLASS = { A: 'g-a', B: 'g-b', C: 'g-c', D: 'g-d', E: 'g-e' };

    function gradeClass(grade) {
        return GRADE_CLASS[String(grade || '').toUpperCase()] || 'g-na';
    }

    /* A score out of 100 drawn as an arc. Deliberately not a speedometer
       with a needle: the reader is being shown a position, not a live
       reading, and a dial implies a precision this does not have. */
    function dial(score, grade, band) {
        var wrap = el('div', 'ins-dial ' + gradeClass(grade));
        var size = 132, stroke = 11, r = (size - stroke) / 2;
        var circumference = 2 * Math.PI * r;
        var value = (score === null || score === undefined) ? 0 : score;
        var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 ' + size + ' ' + size);
        svg.setAttribute('class', 'dial-svg');
        svg.setAttribute('role', 'img');
        svg.setAttribute('aria-label', (score === null ? 'Not rated'
            : 'Estate health index ' + score + ' out of 100, grade ' + grade));
        var mk = function (cls, dash) {
            var c = document.createElementNS(
                'http://www.w3.org/2000/svg', 'circle');
            c.setAttribute('cx', size / 2);
            c.setAttribute('cy', size / 2);
            c.setAttribute('r', r);
            c.setAttribute('fill', 'none');
            c.setAttribute('stroke-width', stroke);
            c.setAttribute('stroke-linecap', 'round');
            c.setAttribute('class', cls);
            if (dash) { c.setAttribute('stroke-dasharray', dash); }
            return c;
        };
        svg.appendChild(mk('dial-track'));
        if (score !== null && score !== undefined) {
            var filled = circumference * (value / 100);
            var arc = mk('dial-value',
                filled + ' ' + (circumference - filled));
            arc.setAttribute('transform',
                'rotate(-90 ' + (size / 2) + ' ' + (size / 2) + ')');
            svg.appendChild(arc);
        }
        wrap.appendChild(svg);
        var face = el('div', 'dial-face');
        face.appendChild(el('div', 'dial-score',
            (score === null || score === undefined) ? DASH : String(score)));
        face.appendChild(el('div', 'dial-of',
            (score === null || score === undefined) ? 'not rated' : 'out of 100'));
        wrap.appendChild(face);
        var cap = el('div', 'dial-cap');
        cap.appendChild(el('span', 'dial-grade', grade || 'n/a'));
        cap.appendChild(el('span', 'dial-band', band || ''));
        wrap.appendChild(cap);
        return wrap;
    }

    /* ---- executive summary --------------------------------------------
       The health index, the paragraph, and the three decisions. This is the
       whole page for a reader who reads nothing else, so it is the only
       section that opens expanded. */
    function renderExecutive(ctx) {
        var body = node(ctx.ids, 'executive');
        if (!body) { return; }
        var data = ctx.data;
        var sc = data.scorecard || {};
        var nar = data.narrative || {};
        var h = data.headline || {};
        clear(body);

        setCount(ctx.ids, 'executiveCount',
            (sc.index === null || sc.index === undefined) ? 'n/a'
                : sc.index + '/100');
        var sub = node(ctx.ids, 'executiveSummary');
        if (sub) {
            sub.textContent = (sc.index === null || sc.index === undefined)
                ? 'not enough recorded to grade the estate'
                : sc.band.toLowerCase() + ' ' + DASH + ' '
                  + plural((nar.decisions || []).length, 'decision')
                  + ' to take';
        }

        var top = el('div', 'ins-exec');
        top.appendChild(dial(sc.index, sc.grade, sc.band));

        var prose = el('div', 'exec-prose');
        prose.appendChild(el('div', 'exec-eyebrow',
            (data.view || 'Architecture') + ' ' + MID + ' estate position '
            + 'as at ' + (nar.as_at || '')));
        (nar.summary || []).forEach(function (line) {
            prose.appendChild(el('p', 'exec-line', line));
        });
        top.appendChild(prose);
        body.appendChild(top);

        /* What is working and what is not, side by side and drawn from the
           scorecard rather than written by hand - so an estate that
           improves stops being criticised for it. */
        var cols = el('div', 'exec-cols');
        var pane = function (title, rows, cls, blank) {
            var box = el('div', 'exec-pane ' + cls);
            box.appendChild(el('div', 'exec-pane-h', title));
            if (!rows || !rows.length) {
                box.appendChild(el('p', 'ins-empty', blank));
                return box;
            }
            var list = el('ul', 'exec-list');
            rows.forEach(function (r) {
                var li = el('li');
                var head = el('span', 'exec-dim');
                head.appendChild(el('b', null, r.dimension));
                head.appendChild(el('span', 'exec-badge ' + gradeClass(
                    r.score >= 85 ? 'A' : r.score >= 70 ? 'B'
                        : r.score >= 55 ? 'C' : r.score >= 40 ? 'D' : 'E'),
                    String(r.score)));
                li.appendChild(head);
                li.appendChild(el('span', 'exec-why', r.note));
                list.appendChild(li);
            });
            box.appendChild(list);
            return box;
        };
        cols.appendChild(pane('What is working', nar.working, 'good',
            'No dimension scored well enough to report as a strength.'));
        cols.appendChild(pane('What needs a decision', nar.attention, 'bad',
            'No dimension scored badly enough to need a decision.'));
        body.appendChild(cols);

        if (nar.decisions && nar.decisions.length) {
            body.appendChild(el('div', 'exec-pane-h', 'Take these three first'));
            body.appendChild(el('p', 'ins-note',
                'The highest-severity items, cheapest first within that. '
                + 'Between two things that hurt equally, commission the one '
                + 'that can be closed this month.'));
            var wrap = el('div', 'exec-decisions');
            nar.decisions.forEach(function (d, i) {
                var card = el('div', 'exec-decision hz-'
                    + String(d.horizon).toLowerCase());
                var head = el('div', 'dhead');
                head.appendChild(el('span', 'dnum', String(i + 1)));
                head.appendChild(el('span', 'dtitle', d.title));
                head.appendChild(el('span', 'ins-hz hz-'
                    + String(d.horizon).toLowerCase(), d.horizon));
                card.appendChild(head);
                card.appendChild(el('p', 'dimpact', d.impact));
                var meta = el('div', 'dmeta');
                meta.appendChild(chip(d.owner, 'Role accountable for this'));
                meta.appendChild(chip(d.effort + ' effort',
                    'Indicative cost of closing it'));
                meta.appendChild(chip(d.theme, 'Scorecard dimension'));
                card.appendChild(meta);
                var act = el('div', 'daction');
                act.appendChild(el('b', null, 'Action: '));
                act.appendChild(document.createTextNode(d.action));
                card.appendChild(act);
                wrap.appendChild(card);
            });
            body.appendChild(wrap);
        }
    }

    /* ---- the scorecard -------------------------------------------------
       Seven dimensions, each a graded answer to a question somebody has
       actually been asked. The drivers are printed under the grade because
       a score nobody can take apart is a score nobody will believe. */
    function renderScorecard(ctx) {
        var body = node(ctx.ids, 'scorecard');
        if (!body) { return; }
        var sc = ctx.data.scorecard || {};
        var rows = sc.rows || [];
        clear(body);
        setCount(ctx.ids, 'scorecardCount', rows.length);
        if (!rows.length) {
            empty(body, 'The estate holds nothing to score yet.');
            return;
        }
        section(body, null,
            'Each dimension starts at 100 and is marked down by what the '
            + 'estate record actually says. Every deduction names itself, so '
            + 'a grade can be taken apart in the room. A dimension the '
            + 'estate holds no evidence for is marked not rated and left out '
            + 'of the overall index rather than scored zero.');

        var grid = el('div', 'ins-cards');
        rows.forEach(function (r) {
            var card = el('div', 'ins-card ' + gradeClass(r.grade));
            var head = el('div', 'chead');
            head.appendChild(el('span', 'cgrade ' + gradeClass(r.grade),
                r.grade));
            var titles = el('div', 'ctitles');
            titles.appendChild(el('div', 'ctitle', r.dimension));
            titles.appendChild(el('div', 'cq', r.question));
            head.appendChild(titles);
            var right = el('div', 'cscore');
            right.appendChild(el('div', 'csval',
                r.score === null ? DASH : String(r.score)));
            right.appendChild(el('div', 'csband', r.band));
            head.appendChild(right);
            card.appendChild(head);

            var meter = el('div', 'cmeter');
            var fill = el('div', 'cfill');
            fill.style.width = (r.score === null ? 0 : r.score) + '%';
            meter.appendChild(fill);
            card.appendChild(meter);

            card.appendChild(el('p', 'cverdict', r.verdict));

            if (r.drivers && r.drivers.length) {
                var list = el('div', 'cdrivers');
                r.drivers.forEach(function (d) {
                    var row = el('div', 'cdriver' + (d.impact > 0 ? '' : ' ok'));
                    row.appendChild(el('span', 'dlab', d.label));
                    row.appendChild(el('span', 'dval', d.measure));
                    row.appendChild(el('span', 'dimp',
                        d.impact > 0 ? '-' + d.impact : 'no cost'));
                    row.title = d.note;
                    list.appendChild(row);
                });
                card.appendChild(list);
            }
            card.appendChild(el('div', 'cweight',
                'Weight in the overall index: ' + r.weight + '%'));
            grid.appendChild(card);
        });
        body.appendChild(grid);
    }

    /* ---- the action agenda ---------------------------------------------
       The same findings the analysis produced, filed the way work is
       actually commissioned: by theme, against a role, in a horizon. A
       governance forum does not take decisions one finding at a time. */
    var HORIZON_NOTE = {
        Now: 'the estate is being hurt while these are open',
        Next: 'plan these into the next cycle',
        Later: 'worth doing, nothing breaks meanwhile'
    };

    function renderAgenda(ctx) {
        var body = node(ctx.ids, 'agenda');
        if (!body) { return; }
        var agenda = ctx.data.agenda || {};
        var themes = agenda.themes || [];
        clear(body);
        setCount(ctx.ids, 'agendaCount', agenda.total || 0);
        var summary = node(ctx.ids, 'agendaSummary');
        var hz = agenda.horizons || {};
        if (summary) {
            summary.textContent = (hz.Now || 0) + ' now, ' + (hz.Next || 0)
                + ' next, ' + (hz.Later || 0) + ' later';
        }
        if (!themes.length) {
            empty(body, 'Nothing to commission - no threshold in the analysis '
                + 'was crossed by this estate.');
            return;
        }
        section(body, null,
            'Grouped by the consequence it carries rather than by the '
            + 'analysis that found it, with the role that can close it and '
            + 'how soon leaving it alone starts to cost something. Severity '
            + 'is about how quickly the estate is hurt, not about how hard '
            + 'the fix is - that is the effort tag.');

        var strip = el('div', 'ins-horizons');
        ['Now', 'Next', 'Later'].forEach(function (key) {
            var box = el('div', 'hz-box hz-' + key.toLowerCase());
            box.appendChild(el('div', 'hz-n', String(hz[key] || 0)));
            box.appendChild(el('div', 'hz-k', key));
            box.appendChild(el('div', 'hz-s', HORIZON_NOTE[key]));
            strip.appendChild(box);
        });
        body.appendChild(strip);

        themes.forEach(function (t) {
            var block = el('div', 'ins-theme sev-' + t.severity);
            var head = el('div', 'thead');
            head.appendChild(el('span', 'ttitle', t.theme));
            head.appendChild(el('span', 'ins-hz hz-'
                + String(t.horizon).toLowerCase(), t.horizon));
            head.appendChild(el('span', 'towner', t.owner));
            head.appendChild(el('span', 'tcount',
                plural(t.total, 'item')));
            block.appendChild(head);

            t.rows.forEach(function (f) {
                var card = el('div', 'ins-finding sev-' + f.severity);
                var fh = el('div', 'fhead');
                fh.appendChild(el('span', 'ins-sev ' + f.severity, f.severity));
                fh.appendChild(el('span', 'ftitle', f.title));
                fh.appendChild(el('span', 'farea', f.effort + ' effort'));
                if (f.metric) {
                    fh.appendChild(el('span', 'ins-metric', f.metric));
                }
                card.appendChild(fh);
                if (f.impact) {
                    var imp = el('div', 'fimpact');
                    imp.appendChild(el('b', null, 'Why it matters: '));
                    imp.appendChild(document.createTextNode(f.impact));
                    card.appendChild(imp);
                }
                card.appendChild(el('div', 'fdetail', f.detail));
                var action = el('div', 'faction');
                action.appendChild(el('b', null, 'Do: '));
                action.appendChild(document.createTextNode(f.action));
                card.appendChild(action);
                if (f.items && f.items.length) {
                    var items = el('div', 'fitems');
                    f.items.forEach(function (i) {
                        items.appendChild(chip(i));
                    });
                    card.appendChild(items);
                }
                block.appendChild(card);
            });
            body.appendChild(block);
        });
    }

    /* ---- domain profiles ------------------------------------------------
       One card per group, ordered by risk. The coupling table below answers
       eleven questions at once and is the right thing to have when a
       specific one is being chased; it is the wrong thing to open with,
       because reading it means knowing what fan-in and autonomy mean before
       the first number lands. */
    var RISK_CLASS = { High: 'r-high', Moderate: 'r-mod', Low: 'r-low' };

    function renderProfiles(ctx) {
        var body = node(ctx.ids, 'profiles');
        if (!body) { return; }
        var data = ctx.data;
        var prof = data.profiles || {};
        var rows = prof.rows || [];
        var noun = data.noun || 'group';
        clear(body);
        setCount(ctx.ids, 'profilesCount', rows.length);
        var summary = node(ctx.ids, 'profilesSummary');
        if (summary) {
            summary.textContent = (prof.high || 0) + ' high risk, '
                + (prof.moderate || 0) + ' moderate';
        }
        if (!rows.length) {
            empty(body, 'No ' + noun + ' holds an application yet.');
            return;
        }
        section(body, null,
            'One card per ' + noun + ', highest risk first. Risk is read off '
            + 'what is actually recorded against the applications inside it '
            + '- support cover, dependencies, suppliers and how much of the '
            + 'estate has to move when this one does.');

        var grid = el('div', 'ins-profiles');
        rows.forEach(function (p) {
            var card = el('div', 'ins-profile ' + (RISK_CLASS[p.risk] || 'r-low'));
            var head = el('div', 'phead');
            head.appendChild(link(p.name, 'Open ' + p.name, ctx.onOpenGroup
                ? function () { ctx.onOpenGroup(p.id); } : null));
            head.appendChild(el('span', 'prisk ' + (RISK_CLASS[p.risk] || 'r-low'),
                p.risk + ' risk'));
            card.appendChild(head);

            var facts = el('div', 'pfacts');
            [['Applications', p.apps],
             ['Business critical', p.bc1],
             ['Coupling', p.posture],
             ['Third parties', p.externals]].forEach(function (f) {
                var b = el('div', 'pfact');
                b.appendChild(el('span', 'pk', f[0]));
                b.appendChild(el('span', 'pv', String(f[1])));
                facts.appendChild(b);
            });
            card.appendChild(facts);

            card.appendChild(el('p', 'pheadline', p.headline));
            card.appendChild(el('p', 'prole', p.role_sentence));
            if (p.lead) {
                card.appendChild(el('p', 'plead', 'Lead: ' + p.lead));
            }

            if (p.watch && p.watch.length) {
                var list = el('ul', 'pwatch');
                p.watch.forEach(function (w) {
                    var li = el('li');
                    li.appendChild(el('b', null, w.kind + ': '));
                    li.appendChild(document.createTextNode(w.text));
                    if (w.items && w.items.length) {
                        var chips = el('div', 'ins-chips');
                        w.items.forEach(function (name) {
                            var app = ctx.appByName.get(name);
                            chips.appendChild(chip(name,
                                app ? 'Open ' + name : name,
                                (app && ctx.onOpenApp)
                                    ? function () { ctx.onOpenApp(app.id); }
                                    : null));
                        });
                        li.appendChild(chips);
                    }
                    list.appendChild(li);
                });
                card.appendChild(list);
            }
            grid.appendChild(card);
        });
        body.appendChild(grid);
    }

    /* ===================================================================
       Coupling and autonomy
       =================================================================== */
    function renderCoupling(ctx) {
        var body = node(ctx.ids, 'coupling');
        if (!body) { return; }
        var data = ctx.data;
        var rows = (data.coupling || {}).rows || [];
        var noun = data.noun || 'group';
        clear(body);
        setCount(ctx.ids, 'couplingCount', rows.length);
        if (!rows.length) {
            empty(body, 'No ' + noun + 's hold applications yet.');
            return;
        }
        section(body, null,
            "Autonomy is the share of a " + noun + "'s interfaces that "
            + 'never leave it. Near 100% it can be changed on its own '
            + 'schedule; near 0% it cannot be touched without a conversation '
            + 'with everyone else, whatever the org chart says. Role is read '
            + 'off the fan-in / fan-out balance. "At one end of" is the share '
            + "of the estate's cross-" + noun + ' traffic that touches this '
            + noun + ' - every such interface has two ends, so the column '
            + 'does not sum to 100%.');
        body.appendChild(table([
            { head: data.label || 'Group',
              cell: function (r) {
                  return link(r.name, 'Open ' + r.name, ctx.onOpenGroup
                      ? function () { ctx.onOpenGroup(r.id); } : null);
              } },
            { head: 'Apps', cls: 'num', cell: function (r) { return r.apps; } },
            { head: 'BC1', cls: 'num',
              cell: function (r) { return (r.bc_mix || {}).BC1 || 0; } },
            { head: 'Internal', cls: 'num', cell: function (r) { return r.intra; } },
            { head: 'Out', cls: 'num', cell: function (r) { return r.out; } },
            { head: 'In', cls: 'num', cell: function (r) { return r.inb; } },
            { head: 'Peers', cls: 'num', cell: function (r) { return r.peers; } },
            { head: 'Externals', cls: 'num',
              cell: function (r) { return r.externals; } },
            { head: 'Autonomy', cls: 'num',
              cell: function (r) { return pct(r.autonomy); } },
            { head: 'At one end of', cls: 'num',
              cell: function (r) { return pct(r.share); } },
            { head: 'Role', cell: function (r) { return r.role; } }
        ], rows));
    }

    /* ===================================================================
       Applications carrying the most traffic
       =================================================================== */
    function renderApplications(ctx) {
        var body = node(ctx.ids, 'applications');
        if (!body) { return; }
        var data = ctx.data;
        var apps = data.applications || {};
        var hubs = apps.hubs || [];
        var noun = data.noun || 'group';
        clear(body);
        setCount(ctx.ids, 'applicationsCount', hubs.length);
        if (!hubs.length) {
            empty(body, 'No application records an interface.');
            return;
        }
        section(body, null,
            'Ranked by interfaces rather than by partners: two feeds to the '
            + 'same peer are two things that break. The cross-' + noun
            + ' column is the traffic that turns a local change into an '
            + 'estate-wide conversation.');
        body.appendChild(table([
            { head: 'Application',
              cell: function (r) {
                  return link(r.name, 'Open ' + r.name, ctx.onOpenApp
                      ? function () { ctx.onOpenApp(r.id); } : null);
              } },
            { head: data.label || 'Group', cls: 'mute',
              cell: function (r) { return r.group || 'unassigned'; } },
            { head: 'BC', cell: function (r) { return r.bc || '\u2014'; } },
            { head: 'Interfaces', cls: 'num',
              cell: function (r) { return r.degree; } },
            { head: 'In', cls: 'num', cell: function (r) { return r.inb; } },
            { head: 'Out', cls: 'num', cell: function (r) { return r.out; } },
            { head: 'Cross-' + noun, cls: 'num',
              cell: function (r) { return r.cross; } },
            { head: 'External', cls: 'num', cell: function (r) { return r.ext; } },
            { head: 'Share', cls: 'num',
              cell: function (r) { return pct(r.share); } }
        ], hubs));

        if (apps.isolated && apps.isolated.length) {
            section(body, 'No connections recorded',
                plural(apps.isolated.length, 'application') + ' record no '
                + 'interface in either direction. Some are genuinely '
                + 'standalone; the rest are undocumented.');
            var chips = el('div', 'ins-chips');
            apps.isolated.forEach(function (r) {
                chips.appendChild(chip(r.name, 'Open ' + r.name, ctx.onOpenApp
                    ? function () { ctx.onOpenApp(r.id); } : null));
            });
            body.appendChild(chips);
        }
    }

    /* ===================================================================
       Business-continuity exposure
       =================================================================== */
    function renderContinuity(ctx) {
        var body = node(ctx.ids, 'continuity');
        if (!body) { return; }
        var data = ctx.data;
        var c = data.continuity || {};
        var label = data.label || 'Group';
        clear(body);
        var total = (c.inversions || []).length + (c.third_party || []).length
                  + (c.thin_cover || []).length;
        setCount(ctx.ids, 'continuityCount', total);

        var appLink = function (id, name) {
            return link(name, 'Open ' + name, ctx.onOpenApp
                ? function () { ctx.onOpenApp(id); } : null);
        };

        section(body, 'Criticality inversion',
            'A feed inherits the criticality of what it serves. Where a BC1 '
            + 'application is fed by a BC2 or BC3 system, either the upstream '
            + 'rating or the dependency is wrong.');
        if ((c.inversions || []).length) {
            body.appendChild(table([
                { head: 'Business-critical application',
                  cell: function (r) { return appLink(r.app_id, r.app); } },
                { head: label, cls: 'mute',
                  cell: function (r) { return r.group; } },
                { head: 'Fed by',
                  cell: function (r) { return appLink(r.source_id, r.source); } },
                { head: 'Rated', cell: function (r) { return r.source_bc; } },
                { head: 'Integration style', cls: 'mute',
                  cell: function (r) { return r.style; } }
            ], c.inversions));
        } else {
            empty(body, 'Nothing business-critical depends on anything rated '
                + 'lower than itself.');
        }

        section(body, 'Inbound third-party dependency',
            'A business-critical application fed from outside the estate '
            + 'depends on something nobody here can be paged for.');
        if ((c.third_party || []).length) {
            body.appendChild(table([
                { head: 'Business-critical application',
                  cell: function (r) { return appLink(r.app_id, r.app); } },
                { head: label, cls: 'mute',
                  cell: function (r) { return r.group; } },
                { head: 'Third-party system',
                  cell: function (r) { return r.system; } },
                { head: 'Direction', cls: 'mute',
                  cell: function (r) { return r.direction; } },
                { head: 'Integration style', cls: 'mute',
                  cell: function (r) { return r.style; } }
            ], c.third_party));
        } else {
            empty(body, 'No business-critical application depends on an '
                + 'inbound third-party feed.');
        }

        section(body, 'Support cover',
            'One name is a person, not a rota.');
        if ((c.thin_cover || []).length) {
            body.appendChild(table([
                { head: 'Business-critical application',
                  cell: function (r) { return appLink(r.app_id, r.app); } },
                { head: label, cls: 'mute',
                  cell: function (r) { return r.group; } },
                { head: 'Named contacts', cls: 'num',
                  cell: function (r) { return r.contacts; } },
                { head: 'Contact', cls: 'mute',
                  cell: function (r) { return r.contact; } }
            ], c.thin_cover));
        } else {
            empty(body, 'Every business-critical application names at least '
                + 'two support contacts.');
        }
    }

    /* ===================================================================
       Integration style mix
       =================================================================== */
    function renderProtocols(ctx) {
        var body = node(ctx.ids, 'protocols');
        if (!body) { return; }
        var p = ctx.data.protocols || {};
        var rows = p.rows || [];
        clear(body);
        setCount(ctx.ids, 'protocolsCount', rows.length);
        if (!rows.length) {
            empty(body, 'No interfaces recorded.');
            return;
        }
        section(body, null,
            'Read from the free-text Connectivity Type on each interface. '
            + 'File drops, direct database links and email are flagged as '
            + 'modernisation candidates: none of them is wrong, but each '
            + 'couples two systems in a way that is brittle, hard to observe '
            + "and hard to version. " + pct(p.legacy_pct) + " of the estate's "
            + plural(p.total, 'interface') + ' use one of them.');

        var max = rows.reduce(function (m, r) { return Math.max(m, r.count); }, 0);
        var bars = el('div', 'ins-bars');
        rows.forEach(function (r) {
            var row = el('div', 'ins-barrow' + (r.modernise ? ' warn' : ''));
            var lab = el('div', 'lab', r.style);
            lab.title = r.modernise
                ? 'Modernisation candidate' : 'Integration style';
            row.appendChild(lab);
            var track = el('div', 'track');
            var fill = el('div', 'fill');
            fill.style.width = (max ? (r.count / max) * 100 : 0) + '%';
            track.appendChild(fill);
            row.appendChild(track);
            row.appendChild(el('div', 'val',
                r.count + ' ' + MID + ' ' + pct(r.pct)));
            bars.appendChild(row);
        });
        body.appendChild(bars);
    }

    /* ===================================================================
       Third-party exposure
       =================================================================== */
    function renderExternals(ctx) {
        var body = node(ctx.ids, 'externals');
        if (!body) { return; }
        var data = ctx.data;
        var ext = data.externals || {};
        var rows = ext.rows || [];
        var noun = data.noun || 'group';
        clear(body);
        setCount(ctx.ids, 'externalsCount', rows.length);
        if (!rows.length) {
            empty(body, 'No external systems. Every interface in the estate '
                + 'resolves to another application in it.');
            return;
        }
        var appByName = ctx.appByName;
        section(body, null,
            'Ranked by reach. A third party touching one application is a '
            + 'supplier; one touching applications in several ' + noun + 's '
            + 'is an enterprise dependency no single ' + noun + ' owns.'
            + (ext.shared && ext.shared.length
               ? ' ' + plural(ext.shared.length, 'system') + ' here '
                 + (ext.shared.length === 1 ? 'is' : 'are') + ' depended on by '
                 + 'more than one ' + noun + '.'
               : ''));
        body.appendChild(table([
            { head: 'External system', cell: function (r) {
                  return el('span', 'ins-name', r.name); } },
            { head: noun.charAt(0).toUpperCase() + noun.slice(1) + 's reached',
              cls: 'num', cell: function (r) { return r.groups; } },
            { head: 'Applications', cls: 'num',
              cell: function (r) { return r.apps; } },
            { head: 'BC1', cls: 'num', cell: function (r) { return r.bc1; } },
            { head: 'Connected applications', cell: function (r) {
                  var wrap = el('div', 'ins-chips');
                  wrap.style.marginTop = '0';
                  r.app_names.forEach(function (name) {
                      var app = appByName.get(name);
                      wrap.appendChild(chip(name, 'Open ' + name,
                          (app && ctx.onOpenApp)
                              ? function () { ctx.onOpenApp(app.id); } : null));
                  });
                  return wrap;
              } },
            { head: 'Integration styles', cls: 'mute', cell: function (r) {
                  return r.styles.map(function (s) {
                      return s[0] + ' (' + s[1] + ')';
                  }).join(', ');
              } }
        ], rows));
    }

    /* ===================================================================
       Ownership alignment
       =================================================================== */
    function renderOwnership(ctx) {
        var body = node(ctx.ids, 'ownership');
        if (!body) { return; }
        var data = ctx.data;
        var own = data.ownership || {};
        var rows = own.rows || [];
        var counter = (own.counterpart_label || 'group').toLowerCase();
        clear(body);
        setCount(ctx.ids, 'ownershipCount', (own.fragmented || []).length);
        if (!rows.length) {
            empty(body, 'Nothing to align yet.');
            return;
        }
        section(body, null,
            'A ' + (data.noun || 'group') + ' whose applications sit in '
            + 'several ' + counter + 's has one business conversation with '
            + 'several escalation paths behind it. Neither diagram shows this '
            + 'on its own, which is why it is reported here.');
        body.appendChild(table([
            { head: own.label || 'Group', cell: function (r) {
                  return link(r.name, 'Open ' + r.name, ctx.onOpenGroup
                      ? function () { ctx.onOpenGroup(r.id); } : null);
              } },
            { head: 'Applications', cls: 'num',
              cell: function (r) { return r.apps; } },
            { head: counter.charAt(0).toUpperCase() + counter.slice(1) + 's',
              cls: 'num', cell: function (r) { return r.spread; } },
            { head: 'Largest share', cls: 'num',
              cell: function (r) { return pct(r.concentration); } },
            { head: 'Split across', cell: function (r) {
                  var wrap = el('div', 'ins-chips');
                  wrap.style.marginTop = '0';
                  r.parts.forEach(function (p) {
                      wrap.appendChild(chip(p.name + ' (' + p.apps + ')'));
                  });
                  return wrap;
              } }
        ], rows));
    }

    /* ===================================================================
       Technology standardisation
       =================================================================== */
    function renderTechnology(ctx) {
        var body = node(ctx.ids, 'technology');
        if (!body) { return; }
        var tech = ctx.data.technology || {};
        var summary = tech.summary || [];
        clear(body);
        setCount(ctx.ids, 'technologyCount', (tech.singletons || []).length);
        if (!summary.length) {
            empty(body, 'No technology is recorded against any application. '
                + 'Complete the Technical Details tab to make the estate '
                + 'answerable on versions and end-of-life dates.');
            return;
        }
        section(body, null,
            pct(tech.documented_pct) + ' of applications record a technology '
            + 'stack. A technology used by exactly one application is not '
            + 'automatically wrong, but it is a skill, a licence and a '
            + 'patching obligation the estate carries for a single system - '
            + 'the cheapest rationalisation question there is.');
        body.appendChild(table([
            { head: 'Category', cell: function (r) { return r.label; } },
            { head: 'Distinct', cls: 'num',
              cell: function (r) { return r.distinct; } },
            { head: 'Used once', cls: 'num',
              cell: function (r) { return r.singletons; } },
            { head: 'Most widely used', cell: function (r) {
                  var wrap = el('div', 'ins-chips');
                  wrap.style.marginTop = '0';
                  r.top.forEach(function (e) {
                      wrap.appendChild(chip(e.name + ' (' + e.count + ')',
                          e.groups.join(', ')));
                  });
                  return wrap;
              } }
        ], summary));

        if ((tech.singletons || []).length) {
            section(body, 'Used by a single application', null);
            var chips = el('div', 'ins-chips');
            tech.singletons.forEach(function (e) {
                chips.appendChild(chip(e.name,
                    e.category + ' ' + MID + ' ' + e.apps[0].name,
                    ctx.onOpenApp
                        ? function () { ctx.onOpenApp(e.apps[0].id); } : null));
            });
            body.appendChild(chips);
        }
    }

    /* ===================================================================
       Map confidence and record completeness
       =================================================================== */
    function renderCoverage(ctx) {
        var body = node(ctx.ids, 'coverage');
        if (!body) { return; }
        var cov = ctx.data.coverage || {};
        clear(body);
        setCount(ctx.ids, 'coverageCount', pct(cov.by_host_pct));
        section(body, null,
            'Every connection on the diagram is either backed by a hostname '
            + 'recorded on both sides - evidence - or inferred because two '
            + 'names happened to match. The second kind is usually right and '
            + 'occasionally embarrassing, so the ratio is stated rather than '
            + 'buried. Of ' + plural(cov.links || 0, 'resolved connection')
            + ', ' + (cov.by_host || 0) + ' (' + pct(cov.by_host_pct)
            + ') are evidence and ' + (cov.by_name || 0) + ' ('
            + pct(cov.by_name_pct) + ') are inferred.');
        body.appendChild(table([
            { head: 'Field', cell: function (r) { return r.label; } },
            { head: 'Applications missing it', cls: 'num',
              cell: function (r) { return r.count; } },
            { head: 'Share', cls: 'num', cell: function (r) { return pct(r.pct); } },
            { head: 'Consequence', cls: 'mute',
              cell: function (r) { return r.why; } }
        ], cov.gaps || []));
    }

    /* ===================================================================
       Mount
       =================================================================== */
    function mount(opts) {
        var ctx = {
            graph: opts.graph || {},
            data: opts.data || {},
            grouping: opts.grouping,
            ids: opts.ids || {},
            onOpenApp: opts.onOpenApp || null,
            onOpenGroup: opts.onOpenGroup || null,
            matrixMode: 'directed'
        };
        ctx.membership = membership(ctx.graph, ctx.grouping);
        ctx.appById = new Map();
        ctx.appByName = new Map();
        (ctx.graph.apps || []).forEach(function (a) {
            ctx.appById.set(a.id, a);
            if (!ctx.appByName.has(a.name)) { ctx.appByName.set(a.name, a); }
        });

        var tiles = node(ctx.ids, 'tiles');
        if (tiles) { renderTiles(tiles, ctx.data); }
        renderBrief(ctx);
        renderExecutive(ctx);
        renderScorecard(ctx);
        renderAgenda(ctx);
        renderProfiles(ctx);
        renderMatrix(ctx);
        renderCoupling(ctx);
        renderApplications(ctx);
        renderContinuity(ctx);
        renderProtocols(ctx);
        renderExternals(ctx);
        renderOwnership(ctx);
        renderTechnology(ctx);
        renderCoverage(ctx);
        return ctx;
    }

    /* The analysis pack for one reading of the estate. Rejected responses
       become a rejected promise so the caller can degrade the panels without
       taking the diagram down with them. */
    function load(url, grouping) {
        var sep = url.indexOf('?') === -1 ? '?' : '&';
        return window.fetch(url + sep + 'grouping=' + encodeURIComponent(grouping),
                            { credentials: 'same-origin', cache: 'no-store' })
            .then(function (r) {
                if (!r.ok) { throw new Error('Request failed (' + r.status + ')'); }
                return r.json();
            });
    }


    /* ===================================================================
       The PDF export

       The diagram is drawn in the browser and the analysis is computed on
       the server, so the download has to be a round trip: rasterise the
       SAME export document the PNG and SVG downloads use, post it up with
       the little the server cannot know (which sheet was on screen, which
       filters were set), and save what comes back. Everything else in the
       report is rebuilt server-side from the estate, so a page left open
       overnight cannot print stale figures under a fresh date.

       opts: { url, doc, filename, payload, button }
       =================================================================== */
    function downloadPdf(opts) {
        var button = opts.button;
        var restore = null;
        if (button) {
            restore = button.innerHTML;
            button.disabled = true;
            button.textContent = 'Building PDF' + '\u2026';
        }
        var done = function (message) {
            if (button) {
                button.disabled = false;
                button.innerHTML = restore;
            }
            if (message) { window.alert(message); }
        };
        if (!K || !K.renderPng) { done('This browser cannot export the diagram.'); return; }

        /* Capped rather than sent at full download resolution: the picture
           has to travel in a request body, and 2400px is already sharper
           than an A4 landscape page can print. */
        K.renderPng(opts.doc, { scale: 1.6, maxWidth: 2400 }, function (image) {
            var payload = {};
            Object.keys(opts.payload || {}).forEach(function (k) {
                payload[k] = opts.payload[k];
            });
            payload.image = image || '';
            window.fetch(opts.url, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            }).then(function (r) {
                if (r.ok) { return r.blob(); }
                return r.json().then(function (j) {
                    throw new Error(j.error || ('Request failed (' + r.status + ')'));
                }, function () {
                    throw new Error('Request failed (' + r.status + ')');
                });
            }).then(function (blob) {
                var url = window.URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href = url;
                a.download = opts.filename;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.setTimeout(function () {
                    window.URL.revokeObjectURL(url);
                }, 4000);
                done(null);
            }).catch(function (err) {
                done('The PDF could not be built: ' + err.message);
            });
        });
    }

    return { mount: mount, load: load, downloadPdf: downloadPdf };
}());
