/* Sorting is progressive enhancement; server search works without JavaScript. */
(function () {
  var results = document.getElementById('people-results');
  var sort = document.getElementById('people-sort');
  if (!results || !sort) return;
  sort.closest('.pd-sort').hidden = false;
  function orderPeople() {
    var key = sort.value;
    var cards = Array.from(results.querySelectorAll('.pd-card'));
    cards.sort(function (a, b) {
      var names = a.dataset.name.localeCompare(b.dataset.name, undefined, {sensitivity:'base',numeric:true});
      if (key === 'name-desc') return -names;
      if (key === 'projects' || key === 'applications') return Number(b.dataset[key]) - Number(a.dataset[key]) || names;
      return names;
    });
    cards.forEach(function (card) { results.appendChild(card); });
  }
  sort.addEventListener('change', orderPeople);
  orderPeople();
})();
