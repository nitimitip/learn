/* Shared workspace behavior; all colors remain in the existing theme. */
(() => {
    'use strict';
    document.querySelectorAll('.sidebar a.nav-item.active').forEach(link => link.setAttribute('aria-current', 'page'));
    document.querySelectorAll('.modal .btn-close').forEach(button => button.setAttribute('aria-label', 'Close dialog'));
    document.querySelectorAll('.pm-page-tabs [data-bs-toggle="tab"]').forEach(button => {
        const target = button.getAttribute('data-bs-target');
        const pane = document.querySelector(target);
        button.setAttribute('aria-controls', target.slice(1));
        button.setAttribute('aria-selected', String(button.classList.contains('active')));
        if (pane) pane.setAttribute('aria-labelledby', button.id);
    });
    // Keep links, refresh, and browser history aligned with the visible section.
    document.querySelectorAll('#pmDashTabs, #projectTabs').forEach(tabs => {
        tabs.addEventListener('shown.bs.tab', event => {
            const target = event.target.getAttribute('data-bs-target');
            const url = new URL(window.location.href);
            url.searchParams.set('tab', target.replace(/^#(?:tab|pane)-/, ''));
            history.replaceState(null, '', url);
        });
    });
    // Associate existing form labels without changing submitted field names.
    document.querySelectorAll('.form-label:not([for]), .mini-label:not([for])').forEach((label, index) => {
        const control = label.nextElementSibling;
        if (control && control.matches('input, select, textarea')) {
            if (!control.id) control.id = `pm-field-${index}`;
            label.htmlFor = control.id;
        }
    });
    document.querySelectorAll('form[method="GET"]').forEach(form => {
        const start = form.querySelector('[name="start_date"]');
        const end = form.querySelector('[name="end_date"]');
        if (!start || !end) return;
        const validate = () => end.setCustomValidity(start.value && end.value && end.value < start.value
            ? 'Choose an end date on or after the start date.' : '');
        start.addEventListener('input', validate);
        end.addEventListener('input', validate);
        validate();
    });
})();
