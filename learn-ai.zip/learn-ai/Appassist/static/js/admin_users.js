/*
   User management: client-side search and filtering over the rows already on
   the page. Progressive enhancement - with JavaScript off every account is
   still listed and every control still works, because they are plain links
   and form submissions.
*/
(function () {
  'use strict';

  var search = document.getElementById('u-search');
  var roleFilter = document.getElementById('u-role-filter');
  var statusFilter = document.getElementById('u-status-filter');
  var rows = Array.prototype.slice.call(document.querySelectorAll('#u-rows tr'));
  var noResults = document.getElementById('u-no-results');
  var count = document.getElementById('u-count');
  var results = document.getElementById('u-results');
  var reset = document.getElementById('u-reset');
  var clear = document.getElementById('u-clear');

  if (!search || !rows.length) return;

  function apply() {
    var words = search.value.toLowerCase().trim().split(/\s+/).filter(Boolean);
    var role = roleFilter.value;
    var status = statusFilter.value;
    var shown = 0;

    rows.forEach(function (row) {
      var hay = row.dataset.search.toLowerCase();
      var match = (role === 'all' || row.dataset.role === role) &&
                  (status === 'all' || row.dataset.status === status) &&
                  words.every(function (word) { return hay.indexOf(word) !== -1; });
      row.hidden = !match;
      if (match) shown++;
    });

    /* The toolbar's clear control exists only while something is filtering,
       so it never sits there as a dead button. */
    clear.hidden = !search.value && role === 'all' && status === 'all';

    noResults.hidden = shown > 0;
    count.textContent = shown === rows.length
      ? rows.length + ' shown'
      : shown + ' of ' + rows.length + ' shown';
    results.textContent = shown + (shown === 1 ? ' user' : ' users') + ' shown';
  }

  search.addEventListener('input', apply);
  roleFilter.addEventListener('change', apply);
  statusFilter.addEventListener('change', apply);

  function clearAll() {
    search.value = '';
    roleFilter.value = 'all';
    statusFilter.value = 'all';
    apply();
    search.focus();
  }
  reset.addEventListener('click', clearAll);
  clear.addEventListener('click', clearAll);

  search.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && search.value) {
      search.value = '';
      apply();
    }
  });
})();
