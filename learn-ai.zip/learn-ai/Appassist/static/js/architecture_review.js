/* Shared inventory review and directional change-impact exploration. */
(function (root) {
    'use strict';
    function impact(graph, start, hostOnly) {
        var apps = new Map((graph.apps || []).map(function (a) { return [a.id, a]; }));
        var next = new Map();
        (graph.links || []).forEach(function (l) {
            if (hostOnly && l.match !== 'host') { return; }
            if (!apps.has(l.src_app) || !apps.has(l.dst_app)) { return; }
            function add(a, b) {
                if (!next.has(a)) { next.set(a, new Set()); }
                next.get(a).add(b);
            }
            add(l.src_app, l.dst_app);
            if (l.bidir) { add(l.dst_app, l.src_app); }
        });
        if (!apps.has(start)) { return []; }
        var seen = new Map([[start, 0]]), queue = [start];
        for (var i = 0; i < queue.length; i += 1) {
            var current = queue[i];
            (next.get(current) || []).forEach(function (id) {
                if (seen.has(id)) { return; }
                seen.set(id, seen.get(current) + 1);
                queue.push(id);
            });
        }
        return queue.slice(1).map(function (id) {
            return { app: apps.get(id), hops: seen.get(id) };
        }).sort(function (a, b) {
            return a.hops - b.hops || a.app.name.localeCompare(b.app.name);
        });
    }
    function el(tag, cls, value) {
        var n = document.createElement(tag);
        if (cls) { n.className = cls; }
        if (value !== undefined) { n.textContent = value; }
        return n;
    }
    function mount(opts) {
        var body = document.getElementById('architectureReview');
        if (!body) { return; }
        body.replaceChildren();
        document.querySelectorAll('.review-nav a').forEach(function (anchor) {
            anchor.onclick = function (event) {
                var target = document.querySelector(anchor.getAttribute('href'));
                if (!target) { return; }
                event.preventDefault(); // Preserve the diagram's drill-down URL state.
                if (target.tagName === 'DETAILS') { target.open = true; }
                target.scrollIntoView({ block: 'start' });
            };
        });
        var graph = opts.graph, apps = graph.apps || [], links = graph.links || [];
        var domain = opts.grouping === 'domain';
        var groups = graph[domain ? 'categories' : 'towers'] || [];
        var groupOf = new Map();
        groups.forEach(function (g) {
            (g.app_ids || []).forEach(function (id) { groupOf.set(id, g); });
        });
        var header = el('div', 'review-heading');
        var heading = el('div');
        heading.append(el('p', 'review-kicker', 'ARCHITECTURE REVIEW / CURRENT STATE'));
        heading.append(el('h2', '', domain ? 'Business landscape & change exposure' : 'Application estate & change exposure'));
        heading.append(el('p', '', domain
            ? 'Connect business areas, application dependencies and delivery accountability.'
            : 'Identify integration dependencies and coordinate change across support towers.'));
        header.append(heading);
        header.append(el('span', 'review-stamp', 'Inventory snapshot · ' + (graph.generated_at || 'Time unavailable')));
        body.append(header);
        var metrics = el('div', 'review-metrics');
        var host = links.filter(function (l) { return l.match === 'host'; }).length;
        var classified = apps.filter(function (a) {
            var g = (graph.categories || []).find(function (c) { return (c.app_ids || []).indexOf(a.id) !== -1; });
            return g && !g.uncategorised;
        }).length;
        [
            ['Applications', apps.length, 'Active inventory records'],
            ['Business critical', apps.filter(function (a) { return a.bc === 'BC1'; }).length, 'Recorded as BC1'],
            ['Business area coverage', apps.length ? Math.round(classified / apps.length * 100) + '%' : 'N/A', classified + ' of ' + apps.length + ' applications classified'],
            ['Host-matched links', links.length ? Math.round(host / links.length * 100) + '%' : 'N/A', host + ' of ' + links.length + ' resolved links; not runtime verification']
        ].forEach(function (m) {
            var card = el('div', 'review-metric');
            card.append(el('span', '', m[0]), el('strong', '', m[1]), el('small', '', m[2]));
            metrics.append(card);
        });
        body.append(metrics);
        var explorer = el('details', 'review-explorer');
        explorer.append(el('summary', '', 'Change impact explorer — trace downstream applications'));
        var inner = el('div', 'review-explorer-body');
        inner.append(el('p', '', 'Select a system to trace reachable applications along recorded flow direction. Use this as a change-review shortlist; connectivity alone does not prove failure propagation.'));
        var controls = el('div', 'review-controls');
        var label = el('label', '', 'Application');
        var select = el('select'); select.id = 'reviewApp'; label.htmlFor = select.id;
        var placeholder = el('option', '', 'Choose an application'); placeholder.value = ''; select.append(placeholder);
        apps.slice().sort(function (a, b) { return a.name.localeCompare(b.name); }).forEach(function (a) {
            var option = el('option', '', a.name); option.value = String(a.id); select.append(option);
        });
        var evidenceLabel = el('label', 'review-check');
        var check = el('input'); check.type = 'checkbox';
        evidenceLabel.append(check, document.createTextNode('Host-matched paths only'));
        controls.append(label, select, evidenceLabel); inner.append(controls);
        var result = el('div', 'review-result'); result.setAttribute('aria-live', 'polite');
        function render() {
            result.replaceChildren();
            var app = apps.find(function (a) { return String(a.id) === select.value; });
            if (!app) { result.append(el('p', '', apps.length ? 'Choose a system to see its direct and indirect reach.' : 'No active applications are recorded.')); return; }
            var rows = impact(graph, app.id, check.checked);
            var affected = new Set(rows.map(function (r) { return groupOf.get(r.app.id); }).filter(Boolean));
            var direct = rows.filter(function (r) { return r.hops === 1; }).length;
            var critical = rows.filter(function (r) { return r.app.bc === 'BC1'; }).length;
            result.append(el('h3', '', rows.length + ' reachable applications · ' + critical + ' BC1 · ' + affected.size + (domain ? ' business areas' : ' towers')));
            result.append(el('p', '', direct + ' direct / ' + (rows.length - direct) + ' indirect. Source application excluded. ' + (check.checked ? 'Only host-matched links included.' : 'Host and name matches included.')));
            if (!rows.length) { result.append(el('p', '', 'No downstream paths are recorded for this selection. Missing interfaces may hide dependencies.')); return; }
            var wrap = el('div', 'ins-wrap'), table = el('table', 'ins-table');
            var tr = el('tr');
            ['Application', 'Criticality', domain ? 'Business area' : 'Tower', 'Shortest path'].forEach(function (s) { var th = el('th', '', s); th.scope = 'col'; tr.append(th); });
            var thead = el('thead'); thead.append(tr); table.append(thead);
            var tbody = el('tbody');
            rows.forEach(function (r) {
                var row = el('tr'), name = el('td');
                var button = el('button', 'ins-link', r.app.name); button.type = 'button';
                button.addEventListener('click', function () { opts.onOpenApp(r.app.id); }); name.append(button);
                row.append(name, el('td', '', r.app.bc || 'Unrated'), el('td', '', (groupOf.get(r.app.id) || {}).name || 'Unassigned'), el('td', '', r.hops + (r.hops === 1 ? ' hop · direct' : ' hops · indirect')));
                tbody.append(row);
            });
            table.append(tbody); wrap.append(table); result.append(wrap);
        }
        select.addEventListener('change', render); check.addEventListener('change', render); render();
        inner.append(result); explorer.append(inner); body.append(explorer);
        var note = el('details', 'review-method');
        note.append(el('summary', '', 'Evidence & interpretation'));
        note.append(el('p', '', 'Whole-estate analysis: diagram filters and drill-down do not filter this review. Reach counts unique applications, follows bi-directional links both ways and excludes unresolved external endpoints. Host matching indicates inventory provenance, not operational assurance.'));
        note.append(el('p', '', 'Business areas are application categories, not validated business capabilities or value streams. Scorecard grades are local inventory heuristics, not industry benchmarks or compliance ratings. Investment, retirement and resilience decisions also require business ownership, cost, lifecycle, service objectives and recovery-test evidence.'));
        body.append(note);
    }
    root.ArchitectureReview = { impact: impact, mount: mount };
    if (typeof module !== 'undefined' && module.exports) { module.exports = root.ArchitectureReview; }
}(typeof window !== 'undefined' ? window : globalThis));
