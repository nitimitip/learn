// Utility Tools JavaScript

// Escape a value before interpolating it into innerHTML. Server messages and
// uploaded-file names must never be able to carry live markup.
function escapeHtml(s) {
    return String(s ?? '')
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

document.addEventListener('DOMContentLoaded', function() {
   
    // File Search Form Handler
    const searchForm = document.getElementById('searchForm');
    if (searchForm) {
        searchForm.addEventListener('submit', handleFileSearch);
    }
   
    // File Compare Form Handler
    const compareForm = document.getElementById('compareForm');
    if (compareForm) {
        compareForm.addEventListener('submit', handleFileCompare);
    }
   
    // File Split Form Handler
    const splitForm = document.getElementById('splitForm');
    if (splitForm) {
        splitForm.addEventListener('submit', handleFileSplit);
    }
   
    // Duplicate Removal Form Handler
    const duplicateForm = document.getElementById('duplicateForm');
    if (duplicateForm) {
        duplicateForm.addEventListener('submit', handleDuplicateRemoval);
    }
   
    // Cleanup Button Handler
    const cleanupBtn = document.getElementById('cleanupBtn');
    if (cleanupBtn) {
        cleanupBtn.addEventListener('click', handleCleanup);
    }

    // Show current temp-file count next to the cleanup button on load.
    fetchTempStatus();
});

// File Search Handler
async function handleFileSearch(event) {
    event.preventDefault();
   
    const form = event.target;
    const formData = new FormData(form);
    const resultsDiv = document.getElementById('searchResults');
    const submitBtn = form.querySelector('button[type="submit"]');
   
    // Validation
    const zipFile = formData.get('zip_file');
    const searchText = formData.get('search_text');
    const excelFile = formData.get('excel_file');
   
    if (!zipFile || zipFile.size === 0) {
        showAlert('Please select a ZIP file', 'error', resultsDiv);
        return;
    }
   
    if (!searchText && (!excelFile || excelFile.size === 0)) {
        showAlert('Please provide search text or upload an Excel file with search terms', 'error', resultsDiv);
        return;
    }
   
    try {
        showLoading(submitBtn, 'Searching...');
        resultsDiv.innerHTML = '<div class="alert alert-info"><i class="fas fa-spinner fa-spin me-2"></i>Searching files...</div>';
       
        const response = await fetch('/utility/file-search', {
            method: 'POST',
            body: formData
        });
       
        if (response.ok) {
            // Check if response is JSON or file download
            const contentType = response.headers.get('content-type');
           
            if (contentType && contentType.includes('application/json')) {
                const result = await response.json();
                if (result.error) {
                    showAlert(result.error, 'error', resultsDiv);
                } else {
                    showAlert(result.message, 'info', resultsDiv);
                }
            } else {
                // File download
                const blob = await response.blob();
                const filename = getFilenameFromResponse(response) || 'search_results.zip';
                downloadBlob(blob, filename);
                showAlert('Search completed successfully. Download started.', 'success', resultsDiv);
            }
        } else {
            const error = await response.json();
            showAlert(error.error || 'Search failed', 'error', resultsDiv);
        }
    } catch (error) {
        showAlert('An error occurred during search: ' + error.message, 'error', resultsDiv);
    } finally {
        resetButton(submitBtn, 'Search Files');
    }
}

// File Compare Handler
async function handleFileCompare(event) {
    event.preventDefault();
   
    const form = event.target;
    const formData = new FormData(form);
    const resultsDiv = document.getElementById('compareResults');
    const submitBtn = form.querySelector('button[type="submit"]');
   
    // Validation
    const file1 = formData.get('file1');
    const file2 = formData.get('file2');
   
    if (!file1 || file1.size === 0 || !file2 || file2.size === 0) {
        showAlert('Please select both files for comparison', 'error', resultsDiv);
        return;
    }
   
    try {
        showLoading(submitBtn, 'Comparing...');
        resultsDiv.innerHTML = '<div class="alert alert-info"><i class="fas fa-spinner fa-spin me-2"></i>Comparing files...</div>';
       
        const response = await fetch('/utility/file-compare', {
            method: 'POST',
            body: formData
        });
       
        const result = await response.json();
       
        if (response.ok) {
            if (result.html) {
                resultsDiv.innerHTML = `
                    <div class="card">
                        <div class="card-header">
                            <h6 class="mb-0">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="me-2">
                                    <path d="M19 3H14.82C14.4 1.84 13.3 1 12 1S9.6 1.84 9.18 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM12 3C12.55 3 13 3.45 13 4S12.55 5 12 5 11 4.55 11 4 11.45 3 12 3ZM19 19H5V5H7V7H17V5H19V19Z" fill="currentColor"/>
                                </svg>
                                File Comparison Results
                            </h6>
                        </div>
                        <div class="card-body p-0">
                            <div class="comparison-results">${result.html}</div>
                        </div>
                    </div>
                `;
            } else {
                showAlert('Comparison completed but no differences found', 'info', resultsDiv);
            }
        } else {
            showAlert(result.error || 'Comparison failed', 'error', resultsDiv);
        }
    } catch (error) {
        showAlert('An error occurred during comparison: ' + error.message, 'error', resultsDiv);
    } finally {
        resetButton(submitBtn, 'Compare Files');
    }
}

// File Split Handler
async function handleFileSplit(event) {
    event.preventDefault();
   
    const form = event.target;
    const formData = new FormData(form);
    const resultsDiv = document.getElementById('splitResults');
    const submitBtn = form.querySelector('button[type="submit"]');
   
    // Validation
    const splitFile = formData.get('split_file');
    const chunkSize = formData.get('chunk_size');
   
    if (!splitFile || splitFile.size === 0) {
        showAlert('Please select a file to split', 'error', resultsDiv);
        return;
    }
   
    if (!chunkSize || parseInt(chunkSize) < 1) {
        showAlert('Please enter a valid chunk size', 'error', resultsDiv);
        return;
    }
   
    try {
        showLoading(submitBtn, 'Splitting...');
        resultsDiv.innerHTML = '<div class="alert alert-info"><i class="fas fa-spinner fa-spin me-2"></i>Splitting file...</div>';
       
        const response = await fetch('/utility/file-split', {
            method: 'POST',
            body: formData
        });
       
        if (response.ok) {
            const blob = await response.blob();
            const filename = getFilenameFromResponse(response) || 'split_files.zip';
            downloadBlob(blob, filename);
            showAlert('File splitting completed successfully. Download started.', 'success', resultsDiv);
        } else {
            const error = await response.json();
            showAlert(error.error || 'File splitting failed', 'error', resultsDiv);
        }
    } catch (error) {
        showAlert('An error occurred during file splitting: ' + error.message, 'error', resultsDiv);
    } finally {
        resetButton(submitBtn, 'Split File');
    }
}

// Duplicate Removal Handler
async function handleDuplicateRemoval(event) {
    event.preventDefault();
   
    const form = event.target;
    const formData = new FormData(form);
    const resultsDiv = document.getElementById('duplicateResults');
    const submitBtn = form.querySelector('button[type="submit"]');
   
    // Validation
    const duplicateZip = formData.get('duplicate_zip');
   
    if (!duplicateZip || duplicateZip.size === 0) {
        showAlert('Please select a ZIP file to analyze', 'error', resultsDiv);
        return;
    }
   
    try {
        showLoading(submitBtn, 'Analyzing...');
        resultsDiv.innerHTML = '<div class="alert alert-info"><i class="fas fa-spinner fa-spin me-2"></i>Analyzing for duplicates...</div>';
       
        const response = await fetch('/utility/remove-duplicates', {
            method: 'POST',
            body: formData
        });
       
        const result = await response.json();
       
        if (response.ok) {
            displayDuplicateResults(result, resultsDiv);
        } else {
            showAlert(result.error || 'Duplicate removal failed', 'error', resultsDiv);
        }
    } catch (error) {
        showAlert('An error occurred during duplicate analysis: ' + error.message, 'error', resultsDiv);
    } finally {
        resetButton(submitBtn, 'Remove Duplicates');
    }
}

// Display Duplicate Results
function displayDuplicateResults(result, container) {
    let html = `
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">Duplicate Analysis Results</h6>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <a href="/utility/download/${encodeURIComponent(result.unique_zip)}" class="btn btn-success btn-sm">
                            <i class="fas fa-download me-2"></i>Download Unique Files
                        </a>
                    </div>
    `;
   
    if (result.duplicate_zip) {
        html += `
                    <div class="col-md-6">
                        <a href="/utility/download/${encodeURIComponent(result.duplicate_zip)}" class="btn btn-warning btn-sm">
                            <i class="fas fa-download me-2"></i>Download Duplicate Files
                        </a>
                    </div>
        `;
    }
   
    html += `</div>`;
   
    if (result.duplicates && result.duplicates.length > 0) {
        html += `
                <h6>Duplicate Files Found:</h6>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Original File</th>
                                <th>Duplicate File</th>
                                <th>Hash</th>
                            </tr>
                        </thead>
                        <tbody>
        `;
       
        result.duplicates.forEach(dup => {
            html += `
                            <tr>
                                <td>${escapeHtml(dup.original)}</td>
                                <td>${escapeHtml(dup.duplicate)}</td>
                                <td><small class="text-muted">${escapeHtml(dup.hash.substring(0, 8))}...</small></td>
                            </tr>
            `;
        });
       
        html += `
                        </tbody>
                    </table>
                </div>
        `;
    } else {
        html += `<div class="alert alert-success">No duplicate files found!</div>`;
    }
   
    html += `
            </div>
        </div>
    `;
   
    container.innerHTML = html;
}

// Temp-file status badge
// Fetches the current file count / size from the server and updates the badge
// shown next to the "Clean Up Files" button. Safe to call at any time.
async function fetchTempStatus() {
    const badge = document.getElementById('tempFileBadge');
    if (!badge) return;
    try {
        const res  = await fetch('/utility/temp-status');
        const data = await res.json();
        if (data.error) { badge.textContent = ''; return; }
        if (data.files === 0) {
            badge.textContent = 'No temp files';
            badge.className = 'temp-status-badge temp-status-empty';
        } else {
            const mb = (data.bytes / (1024 * 1024)).toFixed(1);
            badge.textContent = data.files + ' file' + (data.files === 1 ? '' : 's') + ' · ' + mb + ' MB';
            badge.className = 'temp-status-badge temp-status-has-files';
        }
    } catch (_) {
        badge.textContent = '';
    }
}

// Cleanup Handler
// Called when the user clicks "Clean Up Files".
// Shows a spinner on the button, calls the cleanup endpoint, then shows an
// inline toast and refreshes the file-count badge - no browser alert() used.
async function handleCleanup() {
    const btn   = document.getElementById('cleanupBtn');
    const toast = document.getElementById('cleanupToast');

    // Spinner state
    const originalHTML = btn ? btn.innerHTML : '';
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Cleaning…';
    }
    if (toast) { toast.className = 'cleanup-toast'; toast.textContent = ''; }

    try {
        const response = await fetch('/utility/cleanup', { method: 'POST' });
        const result   = await response.json();

        if (response.ok) {
            const n = result.removed ?? 0;
            _showCleanupToast(
                toast,
                'success',
                '<i class="fas fa-check-circle"></i> ' +
                (n === 0
                    ? 'No temp files — workspace is already clean.'
                    : 'Cleaned up ' + n + ' item' + (n === 1 ? '' : 's') + ' from the temp folder.')
            );
        } else {
            _showCleanupToast(
                toast,
                'error',
                '<i class="fas fa-exclamation-circle"></i> Cleanup failed: ' +
                escapeHtml(result.error || 'Unknown error')
            );
        }
    } catch (err) {
        _showCleanupToast(
            toast,
            'error',
            '<i class="fas fa-exclamation-circle"></i> Request failed: ' + escapeHtml(err.message)
        );
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = originalHTML; }
        fetchTempStatus();   // refresh the badge to show 0 files
    }
}

function _showCleanupToast(el, kind, html) {
    if (!el) return;
    el.innerHTML  = html;
    el.className  = 'cleanup-toast cleanup-toast--' + kind + ' cleanup-toast--visible';
    // Auto-hide after 6 s
    clearTimeout(el._hideTimer);
    el._hideTimer = setTimeout(function () {
        el.classList.remove('cleanup-toast--visible');
    }, 6000);
}

// Utility Functions
function showAlert(message, type, container) {
    const alertClass = type === 'error' ? 'danger' : type;
    const icon = type === 'error' ? 'exclamation-triangle' :
                 type === 'success' ? 'check-circle' : 'info-circle';
   
    container.innerHTML = `
        <div class="alert alert-${alertClass}">
            <i class="fas fa-${icon} me-2"></i>${escapeHtml(message)}
        </div>
    `;
}

function showLoading(button, text) {
    button.disabled = true;
    button.innerHTML = `<i class="fas fa-spinner fa-spin me-2"></i>${text}`;
}

function resetButton(button, text) {
    button.disabled = false;
    button.innerHTML = text;
}

function getFilenameFromResponse(response) {
    const disposition = response.headers.get('content-disposition');
    if (disposition && disposition.includes('filename=')) {
        return disposition.split('filename=')[1].replace(/"/g, '');
    }
    return null;
}

function downloadBlob(blob, filename) {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
}

// Server Search Handler
async function handleServerSearch(event) {
    event.preventDefault();
   
    const form = event.target;
    const formData = new FormData(form);
    const searchTerm = formData.get('search_term');
    const searchActiveServer = formData.get('ActiveServer');
    const resultsContainer = document.getElementById('serverSearchResults');
    const submitBtn = form.querySelector('button[type="submit"]');
   
    if (!searchTerm || !searchTerm.trim()) {
        showAlert('Please enter a search term', 'error', resultsContainer);
        return;
    }
   
    try {
        showLoading(submitBtn, 'Searching...');
        resultsContainer.innerHTML = '<div class="alert alert-info"><i class="fas fa-spinner fa-spin me-2"></i>Searching servers...</div>';
       
        const response = await fetch('/utility/server-search/search', {
            method: 'POST',
            body: formData
        });
       
        const data = await response.json();
       
        if (response.ok) {
            displayServerResults(data, resultsContainer);
        } else {
            showAlert(data.error || 'Search failed', 'error', resultsContainer);
        }
    } catch (error) {
        showAlert('Network error occurred: ' + error.message, 'error', resultsContainer);
    } finally {
        resetButton(submitBtn, '<i class="fas fa-search me-2"></i>Search Servers');
    }
}

// Display Server Search Results
function displayServerResults(data, container) {
    if (data.count === 0) {
        container.innerHTML = `
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>No servers found matching your search criteria.
            </div>
        `;
        return;
    }
   
    let html = `
        <div class="alert alert-success">
            <i class="fas fa-check-circle me-2"></i>Found ${data.count} server${data.count === 1 ? '' : 's'} matching your search.
        </div>
        <div class="row">
    `;
   
    data.results.forEach(server => {
        html += `
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="card border-primary h-100">
                    <div class="card-header bg-danger">
                        <h6 class="card-title mb-0 text-primary">
                            <i class="fas fa-server me-2"></i>
                            ${escapeHtml(server['Host Name'] || 'Unknown Server')}
                        </h6>
                    </div>
                    <div class="card-body">
        `;
       
        // Display all fields except Host Name (already in header)
        for (const [key, value] of Object.entries(server)) {
            if (key !== 'Server Name') {
                // Imported spreadsheet values are untrusted — escape both key
                // and value before they reach innerHTML.
                const displayValue = value && value !== 'N/A' ? escapeHtml(value) : '<span class="text-muted">N/A</span>';
                html += `
                    <div class="mb-2">
                        <small class="text-muted d-block">${escapeHtml(key)}:</small><span class="fw-medium">${displayValue}</span>
                    </div>
                `;
            }
        }
       
        html += `
                    </div>
                </div>
            </div>
        `;
    });
   
    html += '</div>';
    container.innerHTML = html;
}

// Initialize event listeners when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Server search form
    const serverSearchForm = document.getElementById('serverSearchForm');
    if (serverSearchForm) {
        serverSearchForm.addEventListener('submit', handleServerSearch);
    }
});

document.addEventListener('DOMContentLoaded',function(){
//Check for a url hash to activate a specific tab
if (window.location.hash){
var tabTrigger=document.querySelector('.nav-tabs button[data-bs-target="' + window.location.hash + '"]');
if (tabTrigger){
var tab = new bootstrap.Tab(tabTrigger);
tab.show()
}
}
});



