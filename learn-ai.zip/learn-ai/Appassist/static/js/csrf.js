/*
 * csrf.js - attach the CSRF token to every same-origin AJAX write.
 *
 * WHY THIS EXISTS
 * ---------------
 * The server now rejects any POST/PUT/PATCH/DELETE without a valid token
 * (csrf_utils.enforce_csrf). HTML forms carry it in a hidden csrf_token
 * field, but the application also makes ~40 fetch() and XMLHttpRequest
 * writes spread across a dozen templates and half a dozen static scripts.
 * Editing each of those call sites would be forty chances to miss one, and
 * every miss is a feature that silently stops working.
 *
 * So the token is attached in ONE place instead. Every layout loads this
 * file, and from then on any same-origin write carries the X-CSRFToken
 * header that csrf_utils._request_token() already knows how to read.
 *
 * SCOPE - it deliberately does NOT touch:
 *   - GET/HEAD/OPTIONS, which the server does not check
 *   - cross-origin requests, so the token is never leaked to another host
 *
 * The token comes from <meta name="csrf-token"> in the page head. It is the
 * per-session token, the same value the hidden form fields carry, so there
 * is nothing extra to keep in sync.
 */
(function () {
    'use strict';

    var meta = document.querySelector('meta[name="csrf-token"]');
    var token = meta ? meta.getAttribute('content') : '';
    if (!token) { return; }

    var UNSAFE = /^(POST|PUT|PATCH|DELETE)$/i;

    // Same-origin test. A relative URL is always same-origin; an absolute one
    // is resolved against the current page before comparing.
    function isSameOrigin(url) {
        try {
            return new URL(url, window.location.href).origin === window.location.origin;
        } catch (e) {
            // Unparseable URL - treat as foreign and send nothing.
            return false;
        }
    }

    // ---- fetch ----------------------------------------------------------
    if (window.fetch) {
        var originalFetch = window.fetch;
        window.fetch = function (input, init) {
            init = init || {};

            // fetch(url, {...}) and fetch(new Request(...)) both occur; read
            // the method and url from whichever form this call used.
            var isRequest = (typeof Request !== 'undefined') && (input instanceof Request);
            var method = init.method || (isRequest ? input.method : 'GET');
            var url = isRequest ? input.url : input;

            if (UNSAFE.test(method) && isSameOrigin(url)) {
                // Headers may arrive as a Headers object, a plain object, or
                // an array of pairs. Normalising to Headers handles all three
                // and leaves any caller-set value alone.
                var headers = new Headers(
                    init.headers || (isRequest ? input.headers : undefined)
                );
                if (!headers.has('X-CSRFToken')) {
                    headers.set('X-CSRFToken', token);
                }
                init = Object.assign({}, init, { headers: headers });

                // Session cookie must ride along or the token cannot be
                // compared against the session that issued it.
                if (!init.credentials) {
                    init.credentials = 'same-origin';
                }
            }
            return originalFetch.call(this, input, init);
        };
    }

    // ---- XMLHttpRequest -------------------------------------------------
    var originalOpen = XMLHttpRequest.prototype.open;
    var originalSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function (method, url) {
        // Stash what send() needs; the header can only be set after open().
        this._csrfUnsafe = UNSAFE.test(method || '') && isSameOrigin(url);
        return originalOpen.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function () {
        if (this._csrfUnsafe) {
            try {
                this.setRequestHeader('X-CSRFToken', token);
            } catch (e) {
                // Already sent, or a caller set it first. Nothing to do.
            }
        }
        return originalSend.apply(this, arguments);
    };
})();
