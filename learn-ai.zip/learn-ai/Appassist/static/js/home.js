/*
   Home page behaviour: module search + area filter, the greeting/date line,
   and the mobile navigation drawer. Progressive enhancement throughout - with
   JavaScript off every module is still listed and linked.
*/
(function () {
  'use strict';

  var input = document.getElementById('module-search');
  var filters = Array.prototype.slice.call(document.querySelectorAll('[data-filter]'));
  var cards = Array.prototype.slice.call(document.querySelectorAll('.home-module'));
  var groups = Array.prototype.slice.call(document.querySelectorAll('.home-group'));
  var empty = document.querySelector('.home-empty');
  var results = document.getElementById('module-results');
  var category = 'all';

  function filterModules() {
    var words = input.value.toLowerCase().trim().split(/\s+/).filter(Boolean);
    var total = 0;

    cards.forEach(function (card) {
      var inArea = category === 'all' || card.dataset.group === category;
      var hay = card.dataset.search.toLowerCase();
      var matches = inArea && words.every(function (word) { return hay.indexOf(word) !== -1; });
      card.hidden = !matches;
      if (matches) total++;
    });

    /* A group section disappears with its last visible card, so the page never
       shows an empty heading. Its count always reflects what is on screen. */
    groups.forEach(function (group) {
      var shown = group.querySelectorAll('.home-module:not([hidden])').length;
      group.hidden = shown === 0;
      var count = group.querySelector('[data-group-count]');
      if (count) count.textContent = shown + (shown === 1 ? ' module' : ' modules');
    });

    filters.forEach(function (button) {
      var selected = button.dataset.filter === category;
      button.classList.toggle('is-selected', selected);
      button.setAttribute('aria-pressed', String(selected));
    });

    empty.hidden = total > 0;
    results.textContent = total + (total === 1 ? ' module' : ' modules') + ' found';
  }

  filters.forEach(function (button) {
    button.addEventListener('click', function () { category = button.dataset.filter; filterModules(); });
  });
  input.addEventListener('input', filterModules);
  document.getElementById('reset-modules').addEventListener('click', function () {
    category = 'all';
    input.value = '';
    filterModules();
    input.focus();
  });

  /* Greeting and date. Europe/London so the line is right for the estate
     regardless of where the browser thinks it is. */
  var now = new Date();
  var hour = Number(new Intl.DateTimeFormat('en-GB', { hour: 'numeric', hour12: false, timeZone: 'Europe/London' }).format(now));
  var greeting = document.getElementById('home-greeting');
  if (greeting) {
    var part = hour < 12 ? 'Good morning' : (hour < 18 ? 'Good afternoon' : 'Good evening');
    greeting.textContent = greeting.textContent.replace(/^Welcome back/, part);
  }
  var date = document.getElementById('home-date');
  date.dateTime = now.toISOString();
  date.textContent = new Intl.DateTimeFormat('en-GB', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Europe/London'
  }).format(now);

  /* Navigation: mark Home current, and wire the mobile drawer so it traps
     focus, closes on Escape and is inert to screen readers while hidden. */
  document.querySelector('.sidenav-link[data-module="home"]').setAttribute('aria-current', 'page');

  var toggle = document.querySelector('.sidenav-toggle');
  var sidebar = document.querySelector('.aa-sidenav');
  sidebar.id = 'home-navigation';
  sidebar.setAttribute('aria-label', 'Module navigation');
  toggle.setAttribute('aria-controls', sidebar.id);
  toggle.setAttribute('aria-expanded', 'false');

  var close = document.createElement('button');
  close.type = 'button';
  close.className = 'home-menu-close';
  close.textContent = 'Close menu';
  close.addEventListener('click', function () {
    document.body.classList.remove('sidenav-open');
    toggle.focus();
  });
  sidebar.prepend(close);

  var media = window.matchMedia('(max-width: 991px)');
  function syncNavigation() {
    var open = document.body.classList.contains('sidenav-open');
    sidebar.inert = media.matches && !open;
    toggle.setAttribute('aria-expanded', String(open));
  }
  new MutationObserver(syncNavigation).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  media.addEventListener('change', syncNavigation);
  toggle.addEventListener('click', function () {
    syncNavigation();
    if (document.body.classList.contains('sidenav-open')) close.focus();
  });
  syncNavigation();

  document.addEventListener('keydown', function (event) {
    if (event.key === '/' && !event.ctrlKey && !event.metaKey && !event.altKey &&
        !event.target.closest('input,textarea,select,[contenteditable="true"]')) {
      event.preventDefault();
      input.focus();
    }
    if (event.key === 'Escape') {
      if (document.body.classList.contains('sidenav-open')) {
        document.body.classList.remove('sidenav-open');
        toggle.focus();
      } else if (event.target === input) {
        input.value = '';
        filterModules();
      }
    }
    if (event.key === 'Tab' && media.matches && document.body.classList.contains('sidenav-open')) {
      var focusable = Array.prototype.slice.call(sidebar.querySelectorAll('a,button'))
        .filter(function (el) { return el.getClientRects().length; });
      var first = focusable[0];
      var last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
})();
