/* Plan & Timeline: nested navigation and charts sized only when visible. */
(() => {
    'use strict';
    const visual = document.getElementById('plan-visual');
    if (!visual) return;
    const charts = new Map();
    const payload = JSON.parse(document.getElementById('pm-plan-data').textContent);
    const ganttData = document.getElementById('pm-gantt-data');
    if (ganttData && !document.getElementById('deliveryTimeline')) {
        const gantt = JSON.parse(ganttData.textContent);
        charts.set('ganttChart', {data: gantt.figure.data, layout: gantt.figure.layout, config: gantt.config});
    }
    const style = getComputedStyle(document.body);
    // Astra uses modern CSS color syntax; Plotly expects RGB/hex colors.
    // Resolve through the browser so charts preserve the exact theme palette.
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = 1;
    const context = canvas.getContext('2d', {willReadFrequently: true});
    const color = token => {
        context.clearRect(0, 0, 1, 1);
        context.fillStyle = style.getPropertyValue(token).trim();
        context.fillRect(0, 0, 1, 1);
        const [r, g, b, a] = context.getImageData(0, 0, 1, 1).data;
        return `rgba(${r}, ${g}, ${b}, ${a / 255})`;
    };
    // Plotly interprets text as markup. Escape task names before charting.
    const escape = value => String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[ch]));
    const rows = payload.rows;
    if (rows.length) {
        const ids = rows.map(row => String(row.id));
        const labels = rows.map(row => escape(row.name.length > 28 ? row.name.slice(0, 27) + '…' : row.name));
        const custom = rows.map(row => [escape(row.name), escape(row.milestone), row.baseline_start, row.baseline_end, row.current_start, row.current_end]);
        const height = Math.max(320, rows.length * 62 + 100);
        const layout = {
            height, autosize: true, margin: {l: 155, r: 35, t: 15, b: 70},
            paper_bgcolor: color('--surface'), plot_bgcolor: color('--surface'),
            font: {family: style.fontFamily, size: 12, color: color('--text-2')},
            yaxis: {type: 'category', categoryorder: 'array', categoryarray: ids, autorange: 'reversed', tickvals: ids, ticktext: labels, automargin: true},
            legend: {orientation: 'h', y: -0.18, x: 0},
            hoverlabel: {namelength: -1},
        };
        const config = {responsive: true, displaylogo: false, displayModeBar: false};
        const windowTrace = (name, start, end, fill) => ({
            type: 'bar', orientation: 'h', name, y: ids,
            base: rows.map(row => row[start]),
            // Inclusive windows keep single-day tasks visible.
            x: rows.map(row => Date.parse(row[end]) - Date.parse(row[start]) + 86400000),
            marker: {color: fill}, customdata: custom,
            hovertemplate: `<b>%{customdata[0]}</b><br>%{customdata[1]}<br>${name}: %{customdata[${start === 'baseline_start' ? 2 : 4}]} → %{customdata[${end === 'baseline_end' ? 3 : 5}]}<extra></extra>`,
        });
        charts.set('baselineScheduleChart', {
            data: [windowTrace('Baseline', 'baseline_start', 'baseline_end', color('--text-3')),
                windowTrace('Current plan', 'current_start', 'current_end', color('--brand'))],
            layout: {...layout, barmode: 'group', bargap: 0.35, xaxis: {type: 'date', tickformat: '%d %b\n%Y', gridcolor: color('--border'), automargin: true}}, config,
        });
        charts.set('baselineVarianceChart', {
            data: [{type: 'bar', orientation: 'h', y: ids, x: rows.map(row => row.variance),
                marker: {color: rows.map(row => color(row.variance > 0 ? '--critical' : row.variance < 0 ? '--success' : '--text-3'))},
                text: rows.map(row => row.variance > 0 ? `+${row.variance}d late` : row.variance < 0 ? `${-row.variance}d early` : 'On plan'),
                textposition: 'outside', cliponaxis: false, customdata: custom,
                hovertemplate: '<b>%{customdata[0]}</b><br>%{customdata[1]}<br>Finish variance: %{x} calendar days<extra></extra>'}],
            layout: {...layout, showlegend: false, margin: {...layout.margin, r: 85},
                xaxis: {title: {text: 'Finish variance (calendar days)'}, zeroline: true, zerolinecolor: color('--text-3'), gridcolor: color('--border'), tickformat: 'd',
                    range: [Math.min(0, ...rows.map(row => row.variance)) - 2, Math.max(0, ...rows.map(row => row.variance)) + 2]}}, config,
        });
    }
    const pending = new Set();
    function renderVisible() {
        if (!visual.offsetWidth || !window.Plotly) return;
        charts.forEach((chart, id) => {
            const element = document.getElementById(id);
            if (!element || !element.offsetWidth || pending.has(id)) return;
            if (element.data) { Plotly.Plots.resize(element); return; }
            pending.add(id);
            Promise.resolve(Plotly.newPlot(element, chart.data, chart.layout, chart.config))
                .catch(() => { element.textContent = 'This chart could not load. Open Detailed Plan to review the schedule.'; })
                .finally(() => pending.delete(id));
        });
    }
    document.getElementById('planViewTabs').addEventListener('shown.bs.tab', event => {
        const url = new URL(location.href);
        url.searchParams.set('tab', 'plan');
        url.searchParams.set('plan_view', event.target.id === 'plan-details-tab' ? 'details' : 'visual');
        history.replaceState(null, '', url);
        requestAnimationFrame(renderVisible);
    });
    document.getElementById('tab-plan')?.addEventListener('shown.bs.tab', () => requestAnimationFrame(renderVisible));
    document.querySelectorAll('[data-plan-details]').forEach(button => button.addEventListener('click', () => {
        bootstrap.Tab.getOrCreateInstance(document.getElementById('plan-details-tab')).show();
        document.getElementById('plan-details-tab').focus();
    }));
    if (window.ResizeObserver) {
        let width = 0;
        new ResizeObserver(() => {
            if (visual.clientWidth && width !== visual.clientWidth) {
                width = visual.clientWidth;
                requestAnimationFrame(renderVisible);
            }
        }).observe(visual);
    }
    document.querySelectorAll('.pm-comparison-detail').forEach(detail => detail.addEventListener('toggle', () => requestAnimationFrame(renderVisible)));
    renderVisible();
})();
