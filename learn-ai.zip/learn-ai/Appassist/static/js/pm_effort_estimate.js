/* ===========================================================================
 * Effort Estimate - client-side spreadsheet
 * ---------------------------------------------------------------------------
 * The whole estimate is a working copy held only in this tab. Admin defaults
 * (predefined roles + per-day rates) are injected as JSON and used to seed new
 * rows and to power "Reset to defaults". Nothing is persisted server-side; the
 * only server round-trip is the Excel export, which POSTs this state as JSON.
 * ======================================================================== */
(function () {
    "use strict";

    var CFG = window.EFFORT_CFG || {};
    var dataEl = document.getElementById('effortData');
    var SEED = {};
    try { SEED = JSON.parse(dataEl.textContent); } catch (e) { SEED = { defaults: [], locations: [] }; }

    var LOCATIONS = SEED.locations || [];
    var DEFAULTS = SEED.defaults || [];   // [{location, role, rate, order}]
    var DEFAULT_WEEKS = 8;

    // roles grouped by location, lifecycle order preserved -> [{role, rate}]
    var ROLES_BY_LOC = {};
    DEFAULTS.forEach(function (d) {
        (ROLES_BY_LOC[d.location] = ROLES_BY_LOC[d.location] || []).push({ role: d.role, rate: d.rate });
    });

    var nf = new Intl.NumberFormat('en-US');
    var nf2 = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 });

    // ---- state --------------------------------------------------------------
    var state = { weeks: DEFAULT_WEEKS, resources: [], tasks: [] };

    function defaultRate(location, role) {
        var list = ROLES_BY_LOC[location] || [];
        for (var i = 0; i < list.length; i++) { if (list[i].role === role) return list[i].rate; }
        return 0;
    }
    function weekLabels() {
        var out = [];
        for (var i = 0; i < state.weeks; i++) out.push('Week ' + (i + 1));
        return out;
    }
    function num(v) { var n = parseFloat(v); return isNaN(n) ? 0 : n; }
    // Number of people in a resource row - never below the default of 1.
    function resCount(res) { return Math.max(1, Math.round(num(res.count)) || 1); }

    // ---- elements -----------------------------------------------------------
    var el = {
        addLocation: document.getElementById('addLocation'),
        addRole: document.getElementById('addRole'),
        addResourceBtn: document.getElementById('addResourceBtn'),
        addWeekBtn: document.getElementById('addWeekBtn'),
        delWeekBtn: document.getElementById('delWeekBtn'),
        matrixHead: document.getElementById('matrixHead'),
        matrixBody: document.getElementById('matrixBody'),
        matrixFoot: document.getElementById('matrixFoot'),
        matrixEmpty: document.getElementById('matrixEmpty'),
        grandPds: document.getElementById('grandPds'),
        grandCost: document.getElementById('grandCost'),
        addTaskBtn: document.getElementById('addTaskBtn'),
        addSubtaskBtn: document.getElementById('addSubtaskBtn'),
        taskHead: document.getElementById('taskHead'),
        taskBody: document.getElementById('taskBody'),
        taskEmpty: document.getElementById('taskEmpty'),
        projectName: document.getElementById('projectName'),
        resetBtn: document.getElementById('resetBtn'),
        exportBtn: document.getElementById('exportBtn')
    };

    // ---- add-resource selectors --------------------------------------------
    function fillLocationSelect() {
        el.addLocation.innerHTML = LOCATIONS.map(function (l) {
            return '<option value="' + l + '">' + l + '</option>';
        }).join('');
        fillRoleSelect();
    }
    function fillRoleSelect() {
        var loc = el.addLocation.value;
        var roles = ROLES_BY_LOC[loc] || [];
        el.addRole.innerHTML = roles.map(function (r) {
            return '<option value="' + esc(r.role) + '">' + esc(r.role) + '</option>';
        }).join('');
    }

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    // ---- matrix render ------------------------------------------------------
    function renderMatrix() {
        var weeks = weekLabels();
        // header
        var head = '<tr><th class="eff-sticky-l">Location</th><th class="eff-role-col">Role</th><th># Resources</th><th>Rate / PD</th>';
        weeks.forEach(function (w) { head += '<th class="eff-wk">' + esc(w) + '</th>'; });
        head += '<th>Total PDs</th><th>Cost</th><th class="eff-x"></th></tr>';
        el.matrixHead.innerHTML = head;

        // body
        var body = '';
        state.resources.forEach(function (res, i) {
            // normalise effort length
            while (res.efforts.length < state.weeks) res.efforts.push(0);
            res.efforts.length = state.weeks;
            body += '<tr>';
            body += '<td class="eff-sticky-l"><span class="eff-loc eff-loc-' + (res.location === 'Offshore' ? 'off' : 'on') + '">' + esc(res.location) + '</span></td>';
            body += '<td class="eff-role-col">' + esc(res.role) + '</td>';
            body += '<td><input type="number" min="1" step="1" class="eff-cell eff-count" data-count="' + i + '" value="' + resCount(res) + '"></td>';
            body += '<td><input type="number" min="0" step="1" class="eff-cell eff-rate" data-rate="' + i + '" value="' + num(res.rate) + '"></td>';
            for (var w = 0; w < state.weeks; w++) {
                body += '<td><input type="number" min="0" step="0.5" class="eff-cell" data-r="' + i + '" data-w="' + w + '" value="' + (res.efforts[w] || 0) + '"></td>';
            }
            body += '<td class="eff-total" data-total-pds="' + i + '">0</td>';
            body += '<td class="eff-cost" data-cost="' + i + '">0</td>';
            body += '<td class="eff-x"><button type="button" class="eff-del" data-del-res="' + i + '" title="Remove resource"><i class="fas fa-trash"></i></button></td>';
            body += '</tr>';
        });
        el.matrixBody.innerHTML = body;

        // foot (week subtotals + totals)
        var foot = '<tr><td class="eff-sticky-l eff-foot-label" colspan="2">Totals</td><td></td><td></td>';
        for (var w = 0; w < state.weeks; w++) foot += '<td class="eff-foot" data-foot-week="' + w + '">0</td>';
        foot += '<td class="eff-foot" data-foot-pds>0</td><td class="eff-foot" data-foot-cost>0</td><td class="eff-x"></td></tr>';
        el.matrixFoot.innerHTML = foot;

        el.matrixEmpty.hidden = state.resources.length > 0;
        document.getElementById('matrixTable').style.display = state.resources.length ? '' : 'none';

        recomputeMatrix();
    }

    function recomputeMatrix() {
        var grandPds = 0, grandCost = 0;
        var weekTotals = new Array(state.weeks).fill(0);
        state.resources.forEach(function (res, i) {
            var rate = num(res.rate);
            var count = resCount(res);
            var totalPds = 0;
            for (var w = 0; w < state.weeks; w++) {
                var v = num(res.efforts[w]) * count;
                totalPds += v;
                weekTotals[w] += v;
            }
            var cost = totalPds * rate;
            grandPds += totalPds;
            grandCost += cost;
            var tEl = el.matrixBody.querySelector('[data-total-pds="' + i + '"]');
            var cEl = el.matrixBody.querySelector('[data-cost="' + i + '"]');
            if (tEl) tEl.textContent = nf2.format(totalPds);
            if (cEl) cEl.textContent = nf.format(Math.round(cost));
        });
        for (var w = 0; w < state.weeks; w++) {
            var fw = el.matrixFoot.querySelector('[data-foot-week="' + w + '"]');
            if (fw) fw.textContent = nf2.format(weekTotals[w]);
        }
        var fp = el.matrixFoot.querySelector('[data-foot-pds]');
        var fc = el.matrixFoot.querySelector('[data-foot-cost]');
        if (fp) fp.textContent = nf2.format(grandPds);
        if (fc) fc.textContent = nf.format(Math.round(grandCost));
        el.grandPds.textContent = nf2.format(grandPds);
        el.grandCost.textContent = nf.format(Math.round(grandCost));
    }

    // ---- task plan helpers ----------------------------------------------------
    // Weeks are planned on SUB-TASKS only. A main task's week cells are
    // read-only and derived: week w is "running" when any of its sub-tasks
    // (the contiguous sub-task rows below it) has week w selected.
    function parentIndex(subIdx) {
        for (var j = subIdx - 1; j >= 0; j--) {
            if (!state.tasks[j].is_subtask) return j;
        }
        return -1;
    }
    function rollupWeeks(mainIdx) {
        var out = new Array(state.weeks).fill(false);
        for (var j = mainIdx + 1; j < state.tasks.length && state.tasks[j].is_subtask; j++) {
            for (var w = 0; w < state.weeks; w++) {
                if (state.tasks[j].weeks[w]) out[w] = true;
            }
        }
        return out;
    }
    function validateTaskPlan() {
        for (var i = 0; i < state.tasks.length; i++) {
            var t = state.tasks[i];
            var label = t.name.trim() || ('row ' + (i + 1));
            if (!t.is_subtask) {
                var hasSub = (i + 1 < state.tasks.length) && state.tasks[i + 1].is_subtask;
                if (!hasSub) {
                    return 'Task "' + label + '" has no sub-task. Every task needs at least ' +
                           'one sub-task — weeks are planned on the sub-tasks.';
                }
            } else if (parentIndex(i) < 0) {
                return 'Sub-task "' + label + '" has no parent task above it.';
            }
        }
        return null;
    }

    // ---- task render --------------------------------------------------------
    function renderTasks() {
        var weeks = weekLabels();
        var head = '<tr><th class="eff-sticky-l eff-task-col">Task / Sub-Task</th>';
        weeks.forEach(function (w) { head += '<th class="eff-wk">' + esc(w) + '</th>'; });
        head += '<th class="eff-x"></th></tr>';
        el.taskHead.innerHTML = head;

        var body = '';
        state.tasks.forEach(function (t, i) {
            while (t.weeks.length < state.weeks) t.weeks.push(false);
            t.weeks.length = state.weeks;
            body += '<tr class="' + (t.is_subtask ? 'eff-subtask' : 'eff-maintask') + '">';
            body += '<td class="eff-sticky-l eff-task-col"><input type="text" class="eff-name" data-task="' + i + '" value="' + esc(t.name) + '" placeholder="' + (t.is_subtask ? 'Sub-task name' : 'Task name') + '"></td>';
            if (t.is_subtask) {
                for (var w = 0; w < state.weeks; w++) {
                    body += '<td class="eff-plan' + (t.weeks[w] ? ' active' : '') + '" data-plan-task="' + i + '" data-plan-week="' + w + '"></td>';
                }
            } else {
                // Main task: read-only rollup of its sub-tasks' weeks.
                var roll = rollupWeeks(i);
                for (var rw = 0; rw < state.weeks; rw++) {
                    body += '<td class="eff-plan eff-plan-ro' + (roll[rw] ? ' active' : '') +
                            '" data-roll-task="' + i + '" data-roll-week="' + rw +
                            '" title="Derived from this task\'s sub-tasks — select weeks on the sub-task rows"></td>';
                }
            }
            body += '<td class="eff-x"><button type="button" class="eff-del" data-del-task="' + i + '" title="Remove row"><i class="fas fa-trash"></i></button></td>';
            body += '</tr>';
        });
        el.taskBody.innerHTML = body;

        el.taskEmpty.hidden = state.tasks.length > 0;
        document.getElementById('taskTable').style.display = state.tasks.length ? '' : 'none';
    }

    // ---- mutations ----------------------------------------------------------
    function addResource() {
        var location = el.addLocation.value;
        var role = el.addRole.value;
        if (!role) return;
        state.resources.push({
            location: location, role: role, rate: defaultRate(location, role),
            count: 1, efforts: new Array(state.weeks).fill(0)
        });
        renderMatrix();
    }
    function addWeek() { state.weeks += 1; renderMatrix(); renderTasks(); }
    function delWeek() {
        if (state.weeks <= 1) return;
        state.weeks -= 1;
        state.resources.forEach(function (r) { r.efforts.length = state.weeks; });
        state.tasks.forEach(function (t) { t.weeks.length = state.weeks; });
        renderMatrix(); renderTasks();
    }
    function addTask(isSub) {
        if (isSub && !state.tasks.some(function (t) { return !t.is_subtask; })) {
            alert('Add a task first — sub-tasks belong to a task.');
            return;
        }
        state.tasks.push({ name: '', is_subtask: !!isSub, weeks: new Array(state.weeks).fill(false) });
        renderTasks();
    }

    function resetAll() {
        if (!confirm('Reset the estimate? This clears all resources, weeks and tasks in this working copy and starts again from the admin defaults.')) return;
        state = { weeks: DEFAULT_WEEKS, resources: [], tasks: [] };
        el.projectName.value = '';
        renderMatrix(); renderTasks();
    }

    // ---- export -------------------------------------------------------------
    function exportXlsx() {
        var planError = validateTaskPlan();
        if (planError) { alert(planError); return; }
        var payload = {
            csrf_token: CFG.csrf,
            project_name: el.projectName.value.trim(),
            weeks: weekLabels(),
            resources: state.resources.map(function (r) {
                return { location: r.location, role: r.role, count: resCount(r), rate: num(r.rate), efforts: r.efforts.map(num) };
            }),
            tasks: state.tasks.map(function (t, i) {
                // Main-task weeks are derived from their sub-tasks.
                var wk = t.is_subtask ? t.weeks.map(Boolean) : rollupWeeks(i);
                return { name: t.name, is_subtask: !!t.is_subtask, weeks: wk };
            })
        };
        el.exportBtn.disabled = true;
        fetch(CFG.exportUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRFToken': CFG.csrf },
            body: JSON.stringify(payload)
        }).then(function (r) {
            if (!r.ok) return r.json().then(function (d) { throw new Error(d.error || 'Export failed'); });
            var disp = r.headers.get('Content-Disposition') || '';
            var m = /filename="?([^"]+)"?/.exec(disp);
            var name = m ? m[1] : 'Effort Estimate.xlsx';
            return r.blob().then(function (blob) { return { blob: blob, name: name }; });
        }).then(function (res) {
            var url = URL.createObjectURL(res.blob);
            var a = document.createElement('a');
            a.href = url; a.download = res.name;
            document.body.appendChild(a); a.click(); a.remove();
            URL.revokeObjectURL(url);
            el.exportBtn.disabled = false;
        }).catch(function (err) {
            el.exportBtn.disabled = false;
            alert(err.message || 'Could not export the estimate.');
        });
    }

    // ---- events -------------------------------------------------------------
    el.addLocation.addEventListener('change', fillRoleSelect);
    el.addResourceBtn.addEventListener('click', addResource);
    el.addWeekBtn.addEventListener('click', addWeek);
    el.delWeekBtn.addEventListener('click', delWeek);
    el.addTaskBtn.addEventListener('click', function () { addTask(false); });
    el.addSubtaskBtn.addEventListener('click', function () { addTask(true); });
    el.resetBtn.addEventListener('click', resetAll);
    el.exportBtn.addEventListener('click', exportXlsx);

    // ---- save / open work-in-progress (.json on the user's device) ----------
    // Mirrors the Architect Diagram: the working copy is downloaded as an
    // editable .json and re-opened later. Nothing touches the server.
    var EFFORT_KIND = 'appassist-effort-estimate';

    function saveProgress() {
        if (!window.PMProgress) return;
        PMProgress.save(EFFORT_KIND,
            { project_name: el.projectName.value, state: state },
            PMProgress.slug(el.projectName.value, 'effort-estimate') + '.json');
    }

    function loadProgress(data) {
        var s = (data && data.state) || {};
        var weeks = Math.max(1, Math.round(num(s.weeks)) || DEFAULT_WEEKS);
        state.weeks = weeks;
        state.resources = Array.isArray(s.resources) ? s.resources.map(function (r) {
            r = r || {};
            var efforts = (Array.isArray(r.efforts) ? r.efforts : []).slice(0, weeks).map(num);
            while (efforts.length < weeks) efforts.push(0);
            return {
                location: r.location || '', role: r.role || '',
                rate: num(r.rate), count: Math.max(1, Math.round(num(r.count)) || 1),
                efforts: efforts
            };
        }) : [];
        state.tasks = Array.isArray(s.tasks) ? s.tasks.map(function (t) {
            t = t || {};
            var wk = (Array.isArray(t.weeks) ? t.weeks : []).slice(0, weeks).map(Boolean);
            while (wk.length < weeks) wk.push(false);
            return { name: t.name || '', is_subtask: !!t.is_subtask, weeks: wk };
        }) : [];
        el.projectName.value = (data && data.project_name) || '';
        renderMatrix();
        renderTasks();
    }

    var effSaveBtn = document.getElementById('effSaveBtn');
    var effOpenBtn = document.getElementById('effOpenBtn');
    var effOpenFile = document.getElementById('effOpenFile');
    if (effSaveBtn) effSaveBtn.addEventListener('click', saveProgress);
    if (effOpenBtn && effOpenFile) {
        effOpenBtn.addEventListener('click', function () { effOpenFile.click(); });
        effOpenFile.addEventListener('change', function () {
            PMProgress.open(effOpenFile, EFFORT_KIND, function (data) {
                if ((state.resources.length || state.tasks.length || el.projectName.value.trim()) &&
                    !confirm('Opening this file replaces your current estimate. Continue?')) return;
                loadProgress(data);
            });
        });
    }

    // matrix cell edits (live recompute, no re-render so focus is kept)
    el.matrixBody.addEventListener('input', function (e) {
        var t = e.target;
        if (t.dataset.rate !== undefined) {
            state.resources[+t.dataset.rate].rate = num(t.value);
            recomputeMatrix();
        } else if (t.dataset.count !== undefined) {
            state.resources[+t.dataset.count].count = num(t.value);
            recomputeMatrix();
        } else if (t.dataset.r !== undefined) {
            state.resources[+t.dataset.r].efforts[+t.dataset.w] = num(t.value);
            recomputeMatrix();
        }
    });
    el.matrixBody.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-del-res]');
        if (btn) { state.resources.splice(+btn.dataset.delRes, 1); renderMatrix(); }
    });

    // task edits
    el.taskBody.addEventListener('input', function (e) {
        var t = e.target;
        if (t.dataset.task !== undefined) state.tasks[+t.dataset.task].name = t.value;
    });
    el.taskBody.addEventListener('click', function (e) {
        var del = e.target.closest('[data-del-task]');
        if (del) { state.tasks.splice(+del.dataset.delTask, 1); renderTasks(); return; }
        var cell = e.target.closest('[data-plan-task]');
        if (cell) {
            var ti = +cell.dataset.planTask, wi = +cell.dataset.planWeek;
            state.tasks[ti].weeks[wi] = !state.tasks[ti].weeks[wi];
            cell.classList.toggle('active', state.tasks[ti].weeks[wi]);
            // Refresh the parent task's derived (read-only) week cells.
            var p = parentIndex(ti);
            if (p >= 0) {
                var roll = rollupWeeks(p);
                el.taskBody.querySelectorAll('[data-roll-task="' + p + '"]').forEach(function (c) {
                    c.classList.toggle('active', roll[+c.dataset.rollWeek]);
                });
            }
        }
    });

    // ---- init ---------------------------------------------------------------
    fillLocationSelect();
    renderMatrix();
    renderTasks();
})();
