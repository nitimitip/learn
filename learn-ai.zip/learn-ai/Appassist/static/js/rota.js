/*
   rota.js - the four pieces of behaviour the Rota screens need.

   EVERYTHING HERE IS PROGRESSIVE. Every control this file enhances works
   without it: a hidden panel is hidden with the `hidden` attribute and shown
   by removing it, the shift-time rows start with one real row already in the
   DOM, the member filter only hides rows that are already there, and the
   weekday block is only collapsed once this file has run. A browser with
   scripting off gets a longer form, not a broken one.

   1. TOGGLES      data-rot-toggle="id" shows/hides #id
   2. WINDOW ROWS  add and remove shift-time rows in the builder
   3. FILTER       data-rot-search="#list" narrows a picker as you type
   4. FREQUENCY    hides the weekday choice for a single-day rota

   No dependencies. Delegated from document, so markup added after load - a
   toggled panel, a new shift row - is covered without rebinding.
*/

(function () {
  'use strict';

  /* ------------------------------------------------------------- 1. TOGGLES
     One handler for every show/hide on every screen. The button keeps
     aria-expanded in step, and focus moves into the panel when it opens so a
     keyboard user is not left behind at the button.
  */
  document.addEventListener('click', function (event) {
    var button = event.target.closest('[data-rot-toggle]');
    if (!button) { return; }

    var panel = document.getElementById(button.getAttribute('data-rot-toggle'));
    if (!panel) { return; }

    var opening = panel.hasAttribute('hidden');
    if (opening) {
      panel.removeAttribute('hidden');
    } else {
      panel.setAttribute('hidden', '');
    }
    button.setAttribute('aria-expanded', opening ? 'true' : 'false');

    if (opening) {
      var first = panel.querySelector('input, select, textarea, button');
      if (first) { first.focus(); }
    }
  });

  /* -------------------------------------------------------- 2. WINDOW ROWS
     The builder's shift-time rows. Adding clones the first row rather than
     building one from a string, so the row's markup lives in the template
     where it can be seen and changed.

     The LAST row is never removable. A form with no time rows at all cannot
     be submitted usefully and the server would only reject it, so the control
     that would create that state is simply not offered.
  */
  function rowContainer(node) {
    return node.closest('.rot-windows');
  }

  function refreshDropButtons(container) {
    var rows = container.querySelectorAll('.rot-window');
    rows.forEach(function (row) {
      var drop = row.querySelector('[data-rot-drop]');
      if (drop) { drop.style.visibility = rows.length > 1 ? '' : 'hidden'; }
    });
  }

  document.addEventListener('click', function (event) {
    var add = event.target.closest('#addWindow');
    if (add) {
      // The button may sit outside the container (the detail screen puts it
      // in the form actions), so fall back to the one container on the page.
      var container = rowContainer(add) ||
                      document.getElementById('windowRows');
      if (!container) { return; }

      var template = container.querySelector('.rot-window');
      if (!template) { return; }

      var copy = template.cloneNode(true);
      copy.querySelectorAll('input').forEach(function (input) {
        if (input.type === 'text') { input.value = ''; }
      });
      container.appendChild(copy);
      refreshDropButtons(container);

      var focusable = copy.querySelector('input');
      if (focusable) { focusable.focus(); }
      return;
    }

    var drop = event.target.closest('[data-rot-drop]');
    if (drop) {
      var holder = rowContainer(drop);
      if (!holder) { return; }
      if (holder.querySelectorAll('.rot-window').length <= 1) { return; }
      drop.closest('.rot-window').remove();
      refreshDropButtons(holder);
    }
  });

  /* ------------------------------------------------------------- 3. FILTER
     Narrows a people picker as you type. Matches on the whole text of the
     row, so a search for an email address works as well as one for a name.
  */
  document.addEventListener('input', function (event) {
    var box = event.target.closest('[data-rot-search]');
    if (!box) { return; }

    var list = document.querySelector(box.getAttribute('data-rot-search'));
    if (!list) { return; }

    var needle = box.value.trim().toLowerCase();
    list.querySelectorAll('.rot-picker-item').forEach(function (item) {
      var hit = !needle ||
                item.textContent.toLowerCase().indexOf(needle) !== -1;
      // A row hidden by the filter but still TICKED would be submitted
      // invisibly, so a filtered-out selection stays visible.
      var ticked = item.querySelector('input:checked');
      item.style.display = (hit || ticked) ? '' : 'none';
    });
  });

  /* ---------------------------------------------------------- 4. FREQUENCY
     A single-day rota has no weekday choice to make - the date already says
     which day it is - so the block is hidden and its boxes are disabled,
     which is what keeps them out of the submission.

     The help text under the date changes with it, because "the week
     containing this date" and "just this date" are different promises and the
     field looks identical either way.
  */
  var HELP = {
    day: 'Just this date.',
    week: 'The whole week containing this date.',
    month: 'The whole month containing this date.'
  };

  function applyFrequency(value) {
    var block = document.getElementById('weekdayBlock');
    if (block) {
      var single = value === 'day';
      block.hidden = single;
      block.querySelectorAll('input[type="checkbox"]').forEach(function (box) {
        box.disabled = single;
      });
    }
    var help = document.getElementById('anchorHelp');
    if (help && HELP[value]) { help.textContent = HELP[value]; }
  }

  function currentFrequency() {
    var picked = document.querySelector('input[name="frequency"]:checked');
    if (picked) { return picked.value; }
    var select = document.querySelector('select[name="frequency"]');
    return select ? select.value : 'week';
  }

  document.addEventListener('change', function (event) {
    var control = event.target.closest('[data-rot-freq]');
    if (!control) { return; }

    // The radio cards carry their selected look as a class.
    if (control.type === 'radio') {
      document.querySelectorAll('.rot-choice-card').forEach(function (card) {
        card.classList.remove('is-on');
      });
      var card = control.closest('.rot-choice-card');
      if (card) { card.classList.add('is-on'); }
    }
    applyFrequency(control.value);
  });

  /* Weekday chips keep their look in step with the box inside them. */
  document.addEventListener('change', function (event) {
    var box = event.target;
    if (!box.matches || !box.matches('.rot-weekday input')) { return; }
    box.closest('.rot-weekday').classList.toggle('is-on', box.checked);
  });

  /* ---------------------------------------------------------------- start */
  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.rot-windows').forEach(refreshDropButtons);
    if (document.getElementById('weekdayBlock')) {
      applyFrequency(currentFrequency());
    }
  });
}());
