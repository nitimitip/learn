/* Code Sentinel interactions; all page content remains usable without JS. */
(() => {
  'use strict';
  const search = document.getElementById('projectSearch');
  if (search) {
    const filter = document.getElementById('projectFilter');
    const sort = document.getElementById('projectSort');
    const rows = [...document.querySelectorAll('[data-project]')];
    const body = rows[0]?.parentElement;
    function update() {
      const query = search.value.trim().toLocaleLowerCase();
      rows.sort((a,b) => sort.value === 'name' ? a.dataset.name.localeCompare(b.dataset.name)
        : sort.value === 'risk' ? Number(b.dataset.risk)-Number(a.dataset.risk)
        : Number(a.dataset.index)-Number(b.dataset.index));
      let count=0;
      rows.forEach(row => {
        row.hidden = !row.dataset.name.toLocaleLowerCase().includes(query) ||
          !(filter.value === 'all' || (filter.value === 'active' ? row.dataset.active === '1' : row.dataset.gate === filter.value));
        if (!row.hidden) count++;
        body.appendChild(row);
      });
      document.getElementById('projectCount').textContent = `${count} of ${rows.length} projects`;
      document.getElementById('projectNoResults').hidden = count > 0;
    }
    search.addEventListener('input', update);
    filter.addEventListener('change', update);
    sort.addEventListener('change', update);
    document.getElementById('projectReset').addEventListener('click', () => {
      search.value=''; filter.value='all'; sort.value='recent'; update();
    });
    document.querySelectorAll('[data-project-focus]').forEach(button => button.addEventListener('click', () => {
      filter.value=button.dataset.projectFocus; search.value=''; update(); search.focus();
    }));
  }
  const form = document.getElementById('newScanForm');
  if (form) {
    const archive = document.getElementById('archive');
    const files = document.getElementById('files');
    const tabs = form.querySelectorAll('[data-bs-toggle="tab"]');
    function selectSource() {
      const zip = document.getElementById('source_type').value === 'upload';
      archive.required=zip; archive.disabled=!zip;
      files.required=!zip; files.disabled=zip;
    }
    tabs.forEach(tab => tab.addEventListener('click',selectSource));
    selectSource();
    form.addEventListener('submit', () => {
      const button=form.querySelector('[type="submit"]');
      button.disabled=true; button.textContent='Uploading source…';
    });
    window.addEventListener('pageshow', event => {
      if (event.persisted) { const button=form.querySelector('[type="submit"]'); button.disabled=false; button.textContent='Start analysis'; }
    });
  }
  document.querySelectorAll('.cs-filters label').forEach((label,i) => {
    const input=label.parentElement.querySelector('input,select');
    if (input) { input.id=input.id || `cs-filter-${i}`; label.htmlFor=input.id; }
  });
  const shell=document.getElementById('appShell');
  const menu=document.getElementById('sidebarToggle');
  if (menu) {
    menu.setAttribute('aria-expanded','false');
    new MutationObserver(() => menu.setAttribute('aria-expanded', String(shell.classList.contains('sidebar-open'))))
      .observe(shell,{attributes:true,attributeFilter:['class']});
    document.addEventListener('keydown',e=>{ if(e.key==='Escape') shell.classList.remove('sidebar-open'); });
  }
})();
