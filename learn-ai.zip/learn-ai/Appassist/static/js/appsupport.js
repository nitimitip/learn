/* Application Support - minimal vanilla interactivity for the redesigned shell.
   No framework dependency. All hooks are data-attribute based so server-rendered
   Jinja markup stays declarative. */
(function () {
  "use strict";

  document.addEventListener("click", function (e) {
    /* Tabs
       <button class="tab" data-tab="overview" data-tabgroup="detail">
       <div class="tab-panel" data-panel="overview" data-tabgroup="detail"> */
    var tab = e.target.closest("[data-tab]");
    if (tab) {
      var group = tab.getAttribute("data-tabgroup") || "";
      var name = tab.getAttribute("data-tab");
      document.querySelectorAll('[data-tab][data-tabgroup="' + group + '"]').forEach(function (t) {
        t.classList.toggle("active", t === tab);
        t.setAttribute('aria-selected', String(t === tab));
        t.tabIndex = t === tab ? 0 : -1;
      });
      document.querySelectorAll('.tab-panel[data-tabgroup="' + group + '"]').forEach(function (p) {
        p.classList.toggle("active", p.getAttribute("data-panel") === name);
      });
      if (tab.getAttribute('role') === 'tab') history.replaceState(null, '', '#' + encodeURIComponent(name));
      return;
    }

    /* Job detail accordion (table row expand)
       <button data-job-toggle="ind-12"> ... <tr class="job-detail-row" data-job-row="ind-12"> */
    var jt = e.target.closest("[data-job-toggle]");
    if (jt) {
      var key = jt.getAttribute("data-job-toggle");
      var rowEl = document.querySelector('.job-detail-row[data-job-row="' + CSS.escape(key) + '"]');
      if (rowEl) {
        var open = rowEl.classList.toggle("open");
        var chev = jt.querySelector("i.fas");
        if (chev) {
          chev.classList.toggle("fa-chevron-down", !open);
          chev.classList.toggle("fa-chevron-up", open);
        }
        var lbl = jt.querySelector("[data-toggle-label]");
        if (lbl) lbl.textContent = open ? "Hide" : "Details";
      }
      return;
    }

    /* Dropdown menus
       <button data-dropdown-toggle> inside .dropdown, sibling .dropdown-menu */
    var dt = e.target.closest("[data-dropdown-toggle]");
    if (dt) {
      var wrap = dt.closest(".dropdown");
      var menu = wrap && wrap.querySelector(".dropdown-menu");
      var willOpen = menu && !menu.classList.contains("open");
      document.querySelectorAll(".dropdown-menu.open").forEach(function (m) { m.classList.remove("open"); });
      if (menu && willOpen) menu.classList.add("open");
      return;
    }

    /* Sidebar mobile toggle */
    var st = e.target.closest("#sidebarToggle");
    if (st) {
      var shell = document.getElementById("appShell");
      if (shell) shell.classList.toggle("sidebar-open");
      return;
    }

    /* Clicking elsewhere closes any open dropdown and mobile sidebar overlay area */
    if (!e.target.closest(".dropdown-menu")) {
      document.querySelectorAll(".dropdown-menu.open").forEach(function (m) { m.classList.remove("open"); });
    }
  });

  /* Escape closes dropdowns */
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      document.querySelectorAll(".dropdown-menu.open").forEach(function (m) { m.classList.remove("open"); });
      var shell = document.getElementById("appShell");
      if (shell) shell.classList.remove("sidebar-open");
    }
  });

  /* Open the tab named by the URL fragment, so a redirect can land the
     user back on the tab they were editing (e.g. .../application/7#technical) */
  window.addEventListener("DOMContentLoaded", function () {
    var name = (window.location.hash || "").replace(/^#/, "");
    /* Whitelist rather than escape: the fragment is attacker-controllable
       and goes straight into a selector. */
    if (!/^[a-zA-Z0-9_-]+$/.test(name)) { return; }
    var tab = document.querySelector('[data-tab="' + name + '"]');
    if (tab) { tab.click(); }
  });

  /* Auto-dismiss success flashes after 6s */
  window.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".flash-success").forEach(function (el) {
      setTimeout(function () { el.style.transition = "opacity .4s"; el.style.opacity = "0"; setTimeout(function(){ el.remove(); }, 400); }, 6000);
    });
  });
})();

/* Local portfolio browsing. All filtering uses the server-authorised page data. */
(function () {
  'use strict';
  var browser = document.querySelector('[data-tower-browser]');
  if (browser) {
    var search = document.getElementById('towerSearch');
    var filter = document.getElementById('towerFilter');
    var sort = document.getElementById('towerSort');
    var list = document.getElementById('towerList');
    var cards = Array.from(list.querySelectorAll('[data-tower-card]'));
    function update() {
      var query = search.value.trim().toLocaleLowerCase();
      var visible = 0;
      cards.sort(function (a, b) {
        var delta = sort.value === 'apps' ? Number(b.dataset.apps) - Number(a.dataset.apps)
          : sort.value === 'quality' ? Number(a.dataset.quality) - Number(b.dataset.quality) : 0;
        return delta || a.dataset.name.localeCompare(b.dataset.name);
      }).forEach(function (card) {
        var d = card.dataset;
        var matches = d.search.toLocaleLowerCase().includes(query) &&
          (filter.value === 'all' || (filter.value === 'attention' && d.attention === '1') ||
           (filter.value === 'critical' && Number(d.critical) > 0) ||
           (filter.value === 'empty' && Number(d.apps) === 0));
        card.hidden = !matches;
        if (matches) visible++;
        list.appendChild(card);
      });
      document.getElementById('towerResults').textContent = visible + ' of ' + cards.length + ' towers';
      document.getElementById('towerNoResults').hidden = visible !== 0;
    }
    function reset() { search.value = ''; filter.value = 'all'; sort.value = 'name'; update(); search.focus(); }
    search.addEventListener('input', update);
    filter.addEventListener('change', update);
    sort.addEventListener('change', update);
    document.getElementById('towerReset').addEventListener('click', reset);
    document.querySelector('[data-reset-towers]').addEventListener('click', reset);
    update();
  }

  var shell = document.getElementById('appShell');
  var toggle = document.getElementById('sidebarToggle');
  var scrim = document.getElementById('sidebarScrim');
  var sidebar = document.getElementById('supportSidebar');
  var mobile = window.matchMedia('(max-width: 900px)');
  function syncSidebar() {
    var open = shell && shell.classList.contains('sidebar-open');
    if (toggle) toggle.setAttribute('aria-expanded', String(!!open));
    if (scrim) scrim.hidden = !open;
    if (sidebar) sidebar.inert = mobile.matches && !open;
  }
  mobile.addEventListener('change', syncSidebar);
  if (shell) new MutationObserver(syncSidebar).observe(shell, { attributes: true, attributeFilter: ['class'] });
  if (scrim) scrim.addEventListener('click', function () { shell.classList.remove('sidebar-open'); toggle.focus(); });
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      var input = document.querySelector('.topbar-search input');
      if (input && input.getClientRects().length) { e.preventDefault(); input.focus(); }
    }
    if (e.key === 'Escape' && toggle && toggle.getAttribute('aria-expanded') === 'true') toggle.focus();
  });
  document.querySelectorAll('.nav-item').forEach(function (link) {
    link.setAttribute('aria-label', link.textContent.trim());
    if (link.classList.contains('active')) link.setAttribute('aria-current', 'page');
  });
  document.querySelectorAll('button[title], a.btn-icon[title]').forEach(function (el) {
    if (!el.hasAttribute('aria-label')) el.setAttribute('aria-label', el.title);
  });
  syncSidebar();
})();

(function () {
  'use strict';
  document.querySelectorAll('.tabs').forEach(function (bar, index) {
    var tabs = Array.from(bar.querySelectorAll('[data-tab]'));
    if (!tabs.length) return;
    bar.setAttribute('role', 'tablist');
    bar.setAttribute('aria-label', 'Application sections');
    tabs.forEach(function (tab, position) {
      var panel = Array.from(document.querySelectorAll('.tab-panel')).find(function (candidate) {
        return candidate.dataset.panel === tab.dataset.tab && candidate.dataset.tabgroup === tab.dataset.tabgroup;
      });
      tab.id = tab.id || 'support-tab-' + index + '-' + position;
      tab.setAttribute('role', 'tab');
      tab.setAttribute('aria-selected', String(tab.classList.contains('active')));
      tab.tabIndex = tab.classList.contains('active') ? 0 : -1;
      if (panel) {
        panel.id = panel.id || 'support-panel-' + index + '-' + position;
        panel.setAttribute('role', 'tabpanel');
        panel.setAttribute('aria-labelledby', tab.id);
        tab.setAttribute('aria-controls', panel.id);
      }
      tab.addEventListener('keydown', function (event) {
        var next;
        if (event.key === 'ArrowRight') next = (position + 1) % tabs.length;
        if (event.key === 'ArrowLeft') next = (position + tabs.length - 1) % tabs.length;
        if (event.key === 'Home') next = 0;
        if (event.key === 'End') next = tabs.length - 1;
        if (next !== undefined) { event.preventDefault(); tabs[next].focus(); tabs[next].click(); }
      });
    });
  });
})();
