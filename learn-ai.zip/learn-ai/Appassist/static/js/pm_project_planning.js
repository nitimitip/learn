/* ===========================================================================
 * Project Planning - client-side schedule planner
 * ---------------------------------------------------------------------------
 * A working copy held ONLY in this browser tab: a project name + description,
 * a hierarchy of Milestones -> Tasks -> Sub-tasks, and a set of user-defined
 * timeline columns whose labels auto-increment in one of three formats
 * (Day N / Week N / running calendar date). Nothing is persisted server-side;
 * closing the tab discards the plan. The only round-trip is the Excel
 * download, which POSTs this state as JSON.
 * ======================================================================== */
(function () {
    "use strict";

    var CFG = window.PLAN_CFG || {};

    var DEFAULT_COLS = 8;

    // ---- state --------------------------------------------------------------
    var state = {
        format: 'day',                 // 'day' | 'week' | 'date'
        startDate: todayISO(),
        step: 1,                       // days between date columns
        cols: DEFAULT_COLS,
        milestones: []                 // [{name, marks:[], tasks:[{name, marks:[], subtasks:[{name, marks:[]}]}]}]
    };

    function todayISO() {
        var d = new Date();
        var m = String(d.getMonth() + 1).padStart(2, '0');
        var day = String(d.getDate()).padStart(2, '0');
        return d.getFullYear() + '-' + m + '-' + day;
    }

    function pad2(n) { return String(n).padStart(2, '0'); }

    // ---- elements -----------------------------------------------------------
    var el = {
        name: document.getElementById('planName'),
        desc: document.getElementById('planDesc'),
        format: document.getElementById('planFormat'),
        startWrap: document.getElementById('planStartWrap'),
        start: document.getElementById('planStart'),
        step: document.getElementById('planStep'),
        addCol: document.getElementById('planAddColBtn'),
        delCol: document.getElementById('planDelColBtn'),
        addMilestone: document.getElementById('planAddMilestoneBtn'),
        head: document.getElementById('planHead'),
        body: document.getElementById('planBody'),
        empty: document.getElementById('planEmpty'),
        clear: document.getElementById('planClearBtn'),
        exportBtn: document.getElementById('planExportBtn')
    };
    if (!el.body) { return; }          // planning tab not on this page

    el.start.value = state.startDate;

    // ---- column labels ------------------------------------------------------
    function columnLabels() {
        var out = [];
        if (state.format === 'date') {
            var base = parseISO(state.startDate) || new Date();
            var step = Math.max(1, parseInt(state.step, 10) || 1);
            for (var i = 0; i < state.cols; i++) {
                var d = new Date(base.getTime());
                d.setDate(d.getDate() + i * step);
                out.push(pad2(d.getDate()) + '-' + pad2(d.getMonth() + 1) + '-' + d.getFullYear());
            }
        } else {
            var word = state.format === 'week' ? 'Week ' : 'Day ';
            for (var j = 0; j < state.cols; j++) out.push(word + (j + 1));
        }
        return out;
    }

    function parseISO(s) {
        if (!s) return null;
        var p = s.split('-');
        if (p.length !== 3) return null;
        var d = new Date(+p[0], +p[1] - 1, +p[2]);
        return isNaN(d.getTime()) ? null : d;
    }

    function timeframeLabel() {
        if (state.format === 'date') {
            var step = Math.max(1, parseInt(state.step, 10) || 1);
            var labels = columnLabels();
            var from = labels.length ? labels[0] : '—';
            return 'Calendar dates from ' + from + (step > 1 ? (' (every ' + step + ' days)') : ' (daily)');
        }
        return state.format === 'week' ? 'Week-based' : 'Day-based';
    }

    // ---- mark-array sizing --------------------------------------------------
    function fitMarks(arr) {
        arr = arr || [];
        if (arr.length > state.cols) arr.length = state.cols;
        while (arr.length < state.cols) arr.push(false);
        return arr;
    }
    function resizeAllMarks() {
        eachRow(function (row) { row.marks = fitMarks(row.marks); });
    }

    // ---- hierarchy helpers --------------------------------------------------
    // Visit every milestone/task/subtask, passing the row object + level.
    function eachRow(fn) {
        state.milestones.forEach(function (m) {
            fn(m, 'milestone');
            (m.tasks || []).forEach(function (t) {
                fn(t, 'task');
                (t.subtasks || []).forEach(function (s) { fn(s, 'subtask'); });
            });
        });
    }

    function newRow() { return { name: '', marks: fitMarks([]) }; }

    function addMilestone() {
        var m = newRow(); m.tasks = [];
        state.milestones.push(m);
        render();
    }
    function addTask(mi) {
        var t = newRow(); t.subtasks = [];
        state.milestones[mi].tasks.push(t);
        render();
    }
    function addSubtask(mi, ti) {
        state.milestones[mi].tasks[ti].subtasks.push(newRow());
        render();
    }

    // Resolve a "p" path attribute ("0", "0.2", "0.2.1") to a row object.
    function rowAtPath(path) {
        var p = String(path).split('.').map(Number);
        var m = state.milestones[p[0]];
        if (p.length === 1) return m;
        var t = m.tasks[p[1]];
        if (p.length === 2) return t;
        return t.subtasks[p[2]];
    }
    function removeAtPath(path) {
        var p = String(path).split('.').map(Number);
        if (p.length === 1) state.milestones.splice(p[0], 1);
        else if (p.length === 2) state.milestones[p[0]].tasks.splice(p[1], 1);
        else state.milestones[p[0]].tasks[p[1]].subtasks.splice(p[2], 1);
        render();
    }

    // ---- column add / delete ------------------------------------------------
    function addColumn() { state.cols += 1; resizeAllMarks(); render(); }
    function delColumn() {
        if (state.cols <= 1) return;
        state.cols -= 1; resizeAllMarks(); render();
    }

    // ---- render -------------------------------------------------------------
    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function render() {
        var labels = columnLabels();

        // header
        var th = '<tr><th class="eff-sticky-l plan-name-col">Milestone / Task / Sub-Task</th>';
        labels.forEach(function (l) { th += '<th class="eff-wk">' + esc(l) + '</th>'; });
        th += '<th class="eff-x"></th></tr>';
        el.head.innerHTML = th;

        // body
        var html = '';
        state.milestones.forEach(function (m, mi) {
            html += rowHtml(m, 'milestone', String(mi), labels.length,
                '<button type="button" class="btn btn-xs plan-add-task" data-p="' + mi + '"><i class="fas fa-plus"></i> Task</button>');
            (m.tasks || []).forEach(function (t, ti) {
                html += rowHtml(t, 'task', mi + '.' + ti, labels.length,
                    '<button type="button" class="btn btn-xs plan-add-sub" data-p="' + mi + '.' + ti + '"><i class="fas fa-diagram-next"></i> Sub-task</button>');
                (t.subtasks || []).forEach(function (s, si) {
                    html += rowHtml(s, 'subtask', mi + '.' + ti + '.' + si, labels.length, '');
                });
            });
        });
        el.body.innerHTML = html;

        var none = state.milestones.length === 0;
        el.empty.hidden = !none;
        document.getElementById('planTable').style.display = none ? 'none' : '';
    }

    function rowHtml(row, level, path, ncols, addBtn) {
        var cls = 'plan-row plan-' + level;
        var ph = level === 'milestone' ? 'Milestone name'
               : level === 'task' ? 'Task name' : 'Sub-task name';
        var out = '<tr class="' + cls + '">';
        out += '<td class="eff-sticky-l plan-name-col">'
             + '<span class="plan-tag plan-tag-' + level + '">' + level.charAt(0).toUpperCase() + level.slice(1).replace('task', '-task') + '</span>'
             + '<input type="text" class="eff-name plan-name" data-p="' + path + '" value="' + esc(row.name) + '" placeholder="' + ph + '">'
             + addBtn + '</td>';
        for (var i = 0; i < ncols; i++) {
            var on = row.marks[i] ? ' active' : '';
            out += '<td class="eff-plan plan-cell plan-cell-' + level + on + '" data-p="' + path + '" data-col="' + i + '"></td>';
        }
        out += '<td class="eff-x"><button type="button" class="eff-del plan-del" data-p="' + path + '" title="Remove"><i class="fas fa-trash"></i></button></td>';
        out += '</tr>';
        return out;
    }

    // ---- events: meta -------------------------------------------------------
    el.format.addEventListener('change', function () {
        state.format = el.format.value;
        el.startWrap.hidden = (state.format !== 'date');
        render();
    });
    el.start.addEventListener('change', function () { state.startDate = el.start.value || todayISO(); render(); });
    el.step.addEventListener('input', function () { state.step = Math.max(1, parseInt(el.step.value, 10) || 1); render(); });

    el.addCol.addEventListener('click', addColumn);
    el.delCol.addEventListener('click', delColumn);
    el.addMilestone.addEventListener('click', addMilestone);

    // ---- events: grid (delegated) -------------------------------------------
    el.body.addEventListener('input', function (e) {
        var t = e.target;
        if (t.classList.contains('plan-name')) {
            rowAtPath(t.dataset.p).name = t.value;   // no re-render -> keep focus
        }
    });
    el.body.addEventListener('click', function (e) {
        var cell = e.target.closest('.plan-cell');
        if (cell) {
            var row = rowAtPath(cell.dataset.p);
            var i = +cell.dataset.col;
            row.marks[i] = !row.marks[i];
            cell.classList.toggle('active', !!row.marks[i]);
            return;
        }
        var addTaskBtn = e.target.closest('.plan-add-task');
        if (addTaskBtn) { addTask(+addTaskBtn.dataset.p); return; }
        var addSubBtn = e.target.closest('.plan-add-sub');
        if (addSubBtn) { var p = addSubBtn.dataset.p.split('.'); addSubtask(+p[0], +p[1]); return; }
        var delBtn = e.target.closest('.plan-del');
        if (delBtn) { removeAtPath(delBtn.dataset.p); return; }
    });

    // ---- clear --------------------------------------------------------------
    el.clear.addEventListener('click', function () {
        if (state.milestones.length && !confirm('Clear the whole plan? This cannot be undone.')) return;
        state.milestones = [];
        render();
    });

    // ---- export -------------------------------------------------------------
    function buildPayload() {
        var rows = [];
        eachRow(function (row, level) {
            rows.push({ level: level, name: (row.name || '').trim(), marks: row.marks.map(Boolean) });
        });
        return {
            csrf_token: CFG.csrf,
            project_name: el.name.value.trim(),
            description: el.desc.value.trim(),
            timeframe: timeframeLabel(),
            columns: columnLabels(),
            rows: rows
        };
    }

    function exportXlsx() {
        if (!state.milestones.length) { alert('Add at least one milestone before downloading.'); return; }
        var payload = buildPayload();
        el.exportBtn.disabled = true;
        fetch(CFG.exportUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRFToken': CFG.csrf },
            body: JSON.stringify(payload)
        }).then(function (r) {
            if (!r.ok) return r.json().then(function (d) { throw new Error(d.error || 'Download failed'); });
            var disp = r.headers.get('Content-Disposition') || '';
            var m = /filename="?([^"]+)"?/.exec(disp);
            var name = m ? m[1] : 'Project Plan.xlsx';
            return r.blob().then(function (blob) { return { blob: blob, name: name }; });
        }).then(function (res) {
            var url = URL.createObjectURL(res.blob);
            var a = document.createElement('a');
            a.href = url; a.download = res.name;
            document.body.appendChild(a); a.click(); a.remove();
            URL.revokeObjectURL(url);
            el.exportBtn.disabled = false;
        }).catch(function (err) {
            el.exportBtn.disabled = false;
            alert(err.message || 'Could not download the plan.');
        });
    }
    el.exportBtn.addEventListener('click', exportXlsx);

    // ---- save / open work-in-progress (.json on the user's device) ----------
    // Mirrors the Architect Diagram: the plan is downloaded as an editable
    // .json and re-opened later. Nothing touches the server.
    var PLAN_KIND = 'appassist-project-plan';

    function normRow(r) {
        return { name: (r && r.name) || '', marks: Array.isArray(r && r.marks) ? r.marks.map(Boolean) : [] };
    }
    function normMilestone(m) {
        var mm = normRow(m);
        mm.tasks = Array.isArray(m && m.tasks) ? m.tasks.map(function (t) {
            var tt = normRow(t);
            tt.subtasks = Array.isArray(t && t.subtasks) ? t.subtasks.map(normRow) : [];
            return tt;
        }) : [];
        return mm;
    }

    function savePlan() {
        if (!window.PMProgress) return;
        PMProgress.save(PLAN_KIND,
            { project_name: el.name.value, description: el.desc.value, state: state },
            PMProgress.slug(el.name.value, 'project-plan') + '.json');
    }

    function loadPlan(data) {
        var s = (data && data.state) || {};
        state.format = (['day', 'week', 'date'].indexOf(s.format) >= 0) ? s.format : 'day';
        state.startDate = s.startDate || todayISO();
        state.step = Math.max(1, parseInt(s.step, 10) || 1);
        state.cols = Math.max(1, Math.round(parseFloat(s.cols)) || DEFAULT_COLS);
        state.milestones = Array.isArray(s.milestones) ? s.milestones.map(normMilestone) : [];
        el.name.value = (data && data.project_name) || '';
        el.desc.value = (data && data.description) || '';
        el.format.value = state.format;
        el.startWrap.hidden = (state.format !== 'date');
        el.start.value = state.startDate;
        el.step.value = state.step;
        resizeAllMarks();   // fit every row's marks to the column count
        render();
    }

    var planSaveBtn = document.getElementById('planSaveBtn');
    var planOpenBtn = document.getElementById('planOpenBtn');
    var planOpenFile = document.getElementById('planOpenFile');
    if (planSaveBtn) planSaveBtn.addEventListener('click', savePlan);
    if (planOpenBtn && planOpenFile) {
        planOpenBtn.addEventListener('click', function () { planOpenFile.click(); });
        planOpenFile.addEventListener('change', function () {
            PMProgress.open(planOpenFile, PLAN_KIND, function (data) {
                if ((state.milestones.length || el.name.value.trim()) &&
                    !confirm('Opening this file replaces your current plan. Continue?')) return;
                loadPlan(data);
            });
        });
    }

    // ---- boot ---------------------------------------------------------------
    render();
})();
