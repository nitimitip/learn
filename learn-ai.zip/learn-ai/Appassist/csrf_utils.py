"""
csrf_utils.py - shared CSRF protection for routes defined on the Flask app
itself (login, registration, password changes, admin user management).

Mirrors the per-session token scheme already used by the project_management
and application_support blueprints: a random token stored in the session,
submitted back as a hidden `csrf_token` form field (or an `X-CSRFToken`
header / `csrf_token` JSON key for AJAX calls), and compared in constant
time. The same `session['csrf_token']` key is used everywhere, so one token
works across the whole application no matter which page generated it.
"""

import secrets
from functools import wraps
from urllib.parse import urlparse

from flask import flash, jsonify, redirect, request, session, url_for


def generate_csrf_token():
    """Return the session's CSRF token, creating one on first use."""
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_hex(16)
    return session['csrf_token']


def validate_csrf_token(token):
    """Constant-time compare of a submitted token against the session token."""
    if not token or 'csrf_token' not in session:
        return False
    return secrets.compare_digest(session['csrf_token'], token)


def _request_token():
    """Extract the submitted token from form body, header, or JSON body."""
    token = request.form.get('csrf_token') or request.headers.get('X-CSRFToken')
    if not token and request.is_json:
        data = request.get_json(silent=True) or {}
        token = data.get('csrf_token')
    return token


def _safe_referrer():
    """The referring page, but only if it is on this host (no open redirect).

    Falls back to '/' when there is no usable referrer AND url_for('index')
    cannot be built. That second case is not hypothetical: this function runs
    on the CSRF rejection path, so a BuildError here would turn "your token
    expired" into a 500 - the confusing failure instead of the clear one.
    """
    ref = request.referrer
    if ref and urlparse(ref).netloc == request.host:
        return ref
    try:
        return url_for('index')
    except Exception:
        return '/'


def csrf_protect(f):
    """Reject state-changing requests that lack a valid CSRF token.

    Only POST/PUT/PATCH/DELETE are checked; GET passes through, so the same
    decorator can wrap mixed-method routes like login.

    Kept for the routes that already carry it, and harmless alongside the
    application-wide gate below - validating the same token twice costs one
    constant-time compare. New routes need neither: enforce_csrf() covers
    every endpoint by default.
    """
    @wraps(f)
    def wrapper(*args, **kwargs):
        if request.method in UNSAFE_METHODS:
            if not validate_csrf_token(_request_token()):
                flash('Invalid or missing security token. Please try again.', 'error')
                return redirect(_safe_referrer())
        return f(*args, **kwargs)
    return wrapper


# ---------------------------------------------------------------------------
# Application-wide CSRF gate
#
# Per-route @csrf_protect was opt-in, and an audit found 57 state-changing
# routes that had simply never been given it - creating and deleting towers,
# reports and applications, uploading exports, wiping working data. The gate
# below inverts that: every POST/PUT/PATCH/DELETE is checked unless the view
# is explicitly marked @csrf_exempt, so a route added tomorrow is protected
# by default rather than by remembering.
# ---------------------------------------------------------------------------

UNSAFE_METHODS = ('POST', 'PUT', 'PATCH', 'DELETE')

# Attribute stamped on a view function by @csrf_exempt.
_EXEMPT_ATTR = '_csrf_exempt'


def csrf_exempt(f):
    """Mark a view as not requiring a CSRF token.

    Only correct where the caller genuinely cannot hold a session cookie and
    authenticates some other way - the Code Sentinel CI ingest endpoint, which
    presents a bearer token. A browser-driven route must never use this: if a
    form or fetch is failing the check, the fix is to send the token.
    """
    setattr(f, _EXEMPT_ATTR, True)
    return f


def _wants_json():
    """True when the caller is an API/AJAX client that should get JSON back.

    A fetch() handed an HTML redirect reports a confusing parse error rather
    than the actual problem, so answer those in their own language.
    """
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return True
    if request.is_json:
        return True
    accept = request.headers.get('Accept', '')
    return 'application/json' in accept and 'text/html' not in accept


def enforce_csrf(app):
    """Install the application-wide CSRF gate on `app`.

    Registered from main_app AFTER the upload-limit hook, because that hook
    must set request.max_content_length before anything here touches
    request.form (reading the form is what parses - and therefore size-checks -
    the body).
    """
    @app.before_request
    def _csrf_gate():
        if request.method not in UNSAFE_METHODS:
            return None

        endpoint = request.endpoint
        if endpoint is None:
            # No route matched; let Flask produce its own 404/405.
            return None

        view = app.view_functions.get(endpoint)
        if view is not None and getattr(view, _EXEMPT_ATTR, False):
            return None

        if validate_csrf_token(_request_token()):
            return None

        if _wants_json():
            return jsonify({
                'error': 'Invalid or missing security token. '
                         'Reload the page and try again.'
            }), 403

        flash('Invalid or missing security token. Please try again.', 'error')
        return redirect(_safe_referrer())

    return _csrf_gate
