"""
migrate_sqlite_to_mssql.py
ONE-OFF data migration: copy every row from the existing SQLite database
(``project_management.db``) into a Microsoft SQL Server database.

What it does
------------
1. Opens the SOURCE SQLite engine and the TARGET MSSQL engine.
2. Registers every ORM model so ``Base.metadata`` knows the full schema.
3. Creates the schema on the target (``create_all`` - existing tables are
   left untouched).
4. Copies each table's rows in foreign-key-safe order
   (``Base.metadata.sorted_tables``), preserving primary-key values by
   wrapping each table's inserts in ``SET IDENTITY_INSERT ... ON/OFF``.
5. Reseeds each IDENTITY column so future inserts continue after the highest
   migrated id.

It is RE-RUNNABLE in two modes:
    --truncate   empty every target table first, then copy (clean reload)
    (default)    skip any target table that already has rows (resume / top-up)

Usage
-----
    # 1. Install the SQL Server ODBC driver + pyodbc (already in requirements).
    # 2. Point the target at your SQL Server instance, then run:

    set SOURCE_SQLITE_URL=sqlite:///project_management.db
    set TARGET_MSSQL_URL=mssql+pyodbc://<user>:<password>@<host>/AppAssist?driver=ODBC+Driver+17+for+SQL+Server
    (or use trusted_connection=yes and omit the credentials entirely)

    python migrate_sqlite_to_mssql.py                 # copy, skip non-empty tables
    python migrate_sqlite_to_mssql.py --truncate      # wipe target tables, then copy
    python migrate_sqlite_to_mssql.py --dry-run       # report row counts only, write nothing

WARNING:  TAKE A BACKUP of the target SQL Server database before running with
    --truncate. This script moves data, it does not version it.

Notes
-----
* JSON columns: SQLAlchemy stores ``JSON`` as NVARCHAR(max) on SQL Server.
  Values round-trip transparently because both sides go through the ORM's
  JSON type, so this script reads/writes raw column values and lets the
  driver handle them.
* Booleans: SQLite stores 0/1 integers; SQL Server uses BIT. pyodbc accepts
  Python ints/bools for BIT columns, so no manual coercion is needed.
* Encrypted credentials (Secret Vault passwords, health-check monitor
  passwords, file-monitor connection strings) are copied VERBATIM as
  ciphertext. Decryption on the target is self-healing (crypto_utils tries
  the configured key, then the legacy derived keys), so they stay readable
  as long as the new deployment keeps the same ENCRYPTION_KEY /
  SESSION_SECRET - or none at all, if the source used the defaults.
* `resource_contracts` is DELIBERATELY not migrated: the table is an orphan
  left behind by the old Resource Tracker contract feature (model and routes
  removed 2026-07-10 when T&M was rebuilt on Project Management tasks). No
  code reads it; its handful of legacy rows stay in the SQLite file only.
* APScheduler jobstore tables (apscheduler_jobs / _mimp / _cert / _todo /
  _snow_open / _fm / _app_support) are DELIBERATELY not migrated: they are not part of
  Base.metadata and hold pickled job state tied to the old process. The
  Windows service recreates every job on its first start against the new
  DATABASE_URL - nothing to carry over.
* After the copy, a verification pass compares per-table row counts between
  source and target and prints any mismatch, so a silently-skipped or
  partially-copied table cannot go unnoticed.
* The model list in _register_metadata() is kept exhaustive on purpose;
  tests/test_mssql_parity.py fails if a model class is added to the app but
  not named here (and in database.py / mssql_database.py).
"""

from __future__ import annotations

import os
import sys

from sqlalchemy import create_engine, text, inspect, select, func


# Connection URLs
SOURCE_SQLITE_URL = os.environ.get(
    'SOURCE_SQLITE_URL',
    'sqlite:///project_management.db',
)
TARGET_MSSQL_URL = os.environ.get(
    'TARGET_MSSQL_URL',
    # Trusted-connection default for a local SQLEXPRESS instance. Override via
    # the TARGET_MSSQL_URL env var for a real deployment.
    'mssql+pyodbc://@localhost\\SQLEXPRESS/AppAssist'
    '?driver=ODBC+Driver+17+for+SQL+Server&trusted_connection=yes',
)

# How many rows to insert per executemany batch.
BATCH_SIZE = int(os.environ.get('MIGRATION_BATCH_SIZE', '1000'))


def _register_metadata():
    """
    Import every model so Base.metadata is fully populated, then return Base.

    We import the project's own ``database.Base`` so the model classes (which
    do ``from database import Base``) register against the SAME metadata object
    we use to create tables and discover sort order.
    """
    import database  # the app's existing module - its Base is what models use

    # NOTE: `from module import (...)` executes the WHOLE module, so every
    # model class defined in it registers on Base.metadata even if not named
    # below. The lists are nonetheless kept exhaustive so this file documents
    # the full schema and stays in lock-step with database.py::init_db().
    from models import User  # noqa: F401
    from modules.project_management.models import (  # noqa: F401
        Project, ProjectStakeholder, ProjectStatusRecipient,
        ProjectMilestone, ProjectTeamMember,
        ProjectTask, TaskDependency, TaskNote, ProjectActivity,
        ProjectRiskLog, ProjectDocument,
        ProjectBaseline, BaselineMilestone, BaselineTask,
        GoLivePlan, GoLiveTask, GoLiveConnectivity, GoLiveContact,
        HLDTemplateSection, HLDTemplateColumn,
        ProjectHLD, ProjectHLDSection, ProjectHLDRow,
        EffortResourceDefault,
        SDLCPhaseTemplate, ProjectSDLCPhase, SDLCPhaseMilestone,
    )
    from modules.application_support.models import (  # noqa: F401
        AppSupportTower, TowerMember, ApplicationCategory,
        ApplicationDetails, ServerDetails, ApplicationAssignment,
        SupportTeam, BusinessUsers, VendorDetails, ExternalInterfaces,
        IndividualJobs, SuiteJobs, FileInventory, ApplicationTask, CriticalIssue,
        SecretVaultEntry, AuditLog, AuditDigestLog,
        TechCatalog, ApplicationTechStack, StandardChecklistItem,
        ApplicationStandardCompliance,
    )
    from modules.mimp_report.models import (  # noqa: F401
        MIMPReport, MIMPApplicationTower, MIMPApplication,
        MIMPApplicationStatus, MIMPSchedulerLock,
    )
    from modules.utility.servers_models import (  # noqa: F401
        FieldMapping, ServerData, ServerImport, DatabaseReport,
    )
    from modules.file_monitor.models import (  # noqa: F401
        FileMonitorReport, FileMonitorAlertLog,
        FileMonitorTower, FileMonitorTowerMember,
        DtnFlowMessage, DtnFlowDataItem, DtnFlowCatalogueMeta,
    )
    from modules.application_health_check.models import (  # noqa: F401
        ApplicationTower, AppTowerMember, HealthCheckReport, URLMonitor,
        ServerMonitor, DatabaseMonitor, EmailNotificationConfig,
        HealthCheckExecution, HealthCheckHistory,
    )
    from modules.security.models import (  # noqa: F401
        SecurityGroupMember, CertificateRecord, CertificateConfig,
        CertificateTeamManager,
    )
    from modules.service_now_analysis.models import (  # noqa: F401
        ServiceNowGroupMember, GuidePage, GuideDocument, AssignmentGroupContact,
        OpenIncidentEmailSettings, SnowTicketWorkload,
    )
    from modules.todo.models import TodoItem, TodoDigestLog  # noqa: F401
    from modules.user_profile.models import (  # noqa: F401
        UserSubGroup, SoftSkill, UserSkill,
    )
    from modules.activity_tracker.models import ActivityEntry  # noqa: F401
    from modules.resource_utilization.models import (  # noqa: F401
        WorkforceHoliday, WorkforceSettings,
    )
    from modules.rota.models import (  # noqa: F401
        RotaAdmin, Rota, RotaMember, RotaShift, RotaAssignment,
        RotaHandover, RotaRequest, RotaAlert, RotaAudit,
    )
    from modules.code_sentinel.models import (  # noqa: F401
        CodeProject, CodeScan, CodeFinding, CodeTriage, CodeApiToken,
    )
    from modules.software_inventory.models import (  # noqa: F401
        SoftwareGroupMember, SoftwareItem, SoftwareItemTower, SoftwareVersion,
    )
    # Shared document version trail. It does NOT live in any module's models.py
    # (one table serves project_management, application_support and the
    # ServiceNow guide), so it only registers on Base.metadata if imported here
    # explicitly - miss this and the table is never created on the target and
    # every document's version history is silently left behind.
    from file_versions import DocumentVersion  # noqa: F401
    return database.Base


def _identity_columns(table):
    """Return the names of autoincrement integer PK columns for a table."""
    cols = []
    for col in table.primary_key.columns:
        # SQLAlchemy marks server-side autoincrement PKs; an Integer single-PK
        # column maps to a SQL Server IDENTITY column under create_all().
        if col.autoincrement in (True, 'auto') and col.primary_key:
            cols.append(col.name)
    return cols


def _read_rows(source_engine, table):
    """
    Yield all rows of a table from the source as list[dict], ordered by primary
    key. Ascending-PK order means a self-referential table (e.g. the HLD
    template tree, where a child's parent always has a lower id) copies parents
    before children, so per-row FK checks on the target never fail.
    """
    select_stmt = table.select()
    if list(table.primary_key.columns):
        select_stmt = select_stmt.order_by(*table.primary_key.columns)
    with source_engine.connect() as conn:
        result = conn.execution_options(stream_results=True).execute(
            select_stmt
        )
        keys = result.keys()
        for row in result:
            yield dict(zip(keys, row))


def _row_count(engine, table) -> int:
    with engine.connect() as conn:
        return conn.execute(
            select(func.count()).select_from(table)
        ).scalar() or 0


def _copy_table(source_engine, target_engine, table, *, dry_run: bool) -> int:
    """Copy one table SQLite->MSSQL, preserving PK ids. Returns rows copied."""
    src_total = _row_count(source_engine, table)
    if src_total == 0:
        print(f"  {table.name:<32} source empty - nothing to copy")
        return 0

    if dry_run:
        print(f"  {table.name:<32} would copy {src_total} row(s)")
        return 0

    has_identity = bool(_identity_columns(table))
    insert_stmt = table.insert()

    copied = 0
    batch: list[dict] = []

    with target_engine.begin() as conn:
        # Allow explicit values into the IDENTITY column so foreign keys that
        # reference these ids stay valid across the copy. SET IDENTITY_INSERT
        # takes no bind parameters, so the identifier is quoted via the
        # dialect's preparer.
        qname = conn.dialect.identifier_preparer.format_table(table)
        if has_identity:
            conn.execute(text(f"SET IDENTITY_INSERT {qname} ON"))

        for row in _read_rows(source_engine, table):
            batch.append(row)
            if len(batch) >= BATCH_SIZE:
                conn.execute(insert_stmt, batch)
                copied += len(batch)
                batch = []
        if batch:
            conn.execute(insert_stmt, batch)
            copied += len(batch)

        if has_identity:
            conn.execute(text(f"SET IDENTITY_INSERT {qname} OFF"))

    print(f"  {table.name:<32} copied {copied}/{src_total} row(s)")
    return copied


def _reseed_identities(target_engine, tables) -> None:
    """
    After copying with IDENTITY_INSERT, the IDENTITY counter still sits at its
    pre-load value. DBCC CHECKIDENT realigns it to MAX(id) so the next normal
    INSERT does not collide with a migrated id.
    """
    with target_engine.begin() as conn:
        for table in tables:
            if not _identity_columns(table):
                continue
            try:
                safe_name = table.name.replace("'", "''")
                conn.execute(text(
                    f"DBCC CHECKIDENT ('{safe_name}', RESEED)"
                ))
            except Exception as e:
                print(f"  WARN reseed {table.name}: {e}")
    print("Identity columns reseeded.")


def _truncate_targets(target_engine, tables) -> None:
    """
    Empty target tables in REVERSE FK order so child rows go before parents.
    DELETE (not TRUNCATE) because FK constraints forbid TRUNCATE on referenced
    tables; DELETE with FKs still works given the right order.
    """
    print("Truncating target tables (reverse FK order)...")
    with target_engine.begin() as conn:
        for table in reversed(tables):
            try:
                conn.execute(table.delete())
            except Exception as e:
                print(f"  WARN delete {table.name}: {e}")


def _verify(source_engine, target_engine, tables) -> bool:
    """
    Compare per-table row counts between source and target.

    Returns True when every table matches. A mismatch is loud but non-fatal:
    resume mode legitimately skips tables that already held rows, so the
    operator decides whether a difference is expected.
    """
    print("\nVerification (source vs target row counts):")
    ok = True
    for table in tables:
        try:
            src = _row_count(source_engine, table)
            tgt = _row_count(target_engine, table)
        except Exception as e:
            print(f"  {table.name:<32} VERIFY ERROR: {e}")
            ok = False
            continue
        if src != tgt:
            print(f"  {table.name:<32} MISMATCH source={src} target={tgt}")
            ok = False
    if ok:
        print("  All table row counts match.")
    return ok


def _source_sqlite_path(url: str):
    """File path of a sqlite:/// URL, or None for non-file sources."""
    if not url.startswith('sqlite:///'):
        return None
    path = url[len('sqlite:///'):]
    return path or None


def run(*, dry_run: bool = False, truncate: bool = False) -> None:
    print(f"Source (SQLite): {SOURCE_SQLITE_URL}")
    print(f"Target (MSSQL) : {TARGET_MSSQL_URL}\n")

    # Guard against a typo'd source path: connecting to a missing SQLite file
    # silently CREATES a new empty database, and the migration would then
    # "succeed" having copied nothing.
    src_path = _source_sqlite_path(SOURCE_SQLITE_URL)
    if src_path is not None and not os.path.isfile(src_path):
        print(f"ERROR: source SQLite file not found: {src_path}\n"
              f"Set SOURCE_SQLITE_URL to the existing database file.")
        sys.exit(1)

    Base = _register_metadata()

    source_engine = create_engine(
        SOURCE_SQLITE_URL,
        connect_args={"check_same_thread": False},
    )
    # fast_executemany is a pyodbc/mssql-only kwarg; passing it to another
    # dialect (e.g. a sqlite target during a --dry-run rehearsal) raises at
    # create_engine time, so only apply it for mssql URLs.
    target_kwargs = (
        {"fast_executemany": True}
        if TARGET_MSSQL_URL.lower().startswith('mssql') else {}
    )
    target_engine = create_engine(TARGET_MSSQL_URL, **target_kwargs)

    target_dialect = target_engine.dialect.name.lower()
    if target_dialect not in ('mssql', 'pyodbc') and not dry_run:
        print(f"ERROR: target dialect is '{target_dialect}', expected mssql. "
              f"Set TARGET_MSSQL_URL to a SQL Server URL.")
        sys.exit(1)

    # 1. Build the schema on the target (idempotent; existing tables kept).
    #    create_all only creates MISSING tables - it never ALTERs existing
    #    ones - so the app's additive column migration is applied to the
    #    target too. Without it, a target table created by an older release
    #    (e.g. file_monitor_reports before the per-system config columns)
    #    would reject the copied rows.
    if not dry_run:
        print("Ensuring target schema (create_all + additive columns)...")
        Base.metadata.create_all(bind=target_engine)
        import database
        database._ensure_columns(target_engine)

    tables = list(Base.metadata.sorted_tables)  # FK-safe parent->child order
    print(f"{len(tables)} table(s) to process.\n")

    # 2. Optional clean reload.
    if truncate and not dry_run:
        _truncate_targets(target_engine, tables)
        print()

    # 3. Copy each table.
    total = 0
    target_insp = None if dry_run else inspect(target_engine)
    for table in tables:
        # Default (resume) mode: skip a target table that already has rows.
        if not dry_run and not truncate:
            if table.name in target_insp.get_table_names():
                if _row_count(target_engine, table) > 0:
                    print(f"  {table.name:<32} target not empty - skipped "
                          f"(use --truncate to overwrite)")
                    continue
        try:
            total += _copy_table(source_engine, target_engine, table,
                                 dry_run=dry_run)
        except Exception as e:
            # _copy_table wraps each table in ONE transaction, so a failure
            # rolls that table back cleanly (IDENTITY_INSERT included).
            # Continuing past a failed parent would only cascade FK errors
            # into every child table, so stop here with clear context.
            print(f"\nERROR copying table '{table.name}': {e}\n"
                  f"The failed table was rolled back; previously copied "
                  f"tables were committed. Fix the cause and re-run (resume "
                  f"mode skips the completed tables automatically).")
            source_engine.dispose()
            target_engine.dispose()
            sys.exit(1)

    # 4. Realign identity counters.
    if not dry_run:
        print()
        _reseed_identities(target_engine, tables)

    # 5. Verify: per-table row counts must match on both sides.
    verified = True
    if not dry_run:
        verified = _verify(source_engine, target_engine, tables)

    source_engine.dispose()
    target_engine.dispose()

    print(f"\n{'DRY-RUN - nothing written.' if dry_run else 'Migration complete.'} "
          f"Rows copied: {total}")
    if not dry_run and not verified:
        print("WARNING: row-count mismatches found - review the verification "
              "output above (expected if you resumed into a partly-loaded "
              "target; otherwise re-run with --truncate).")
        sys.exit(2)


if __name__ == '__main__':
    run(
        dry_run='--dry-run' in sys.argv,
        truncate='--truncate' in sys.argv,
    )
