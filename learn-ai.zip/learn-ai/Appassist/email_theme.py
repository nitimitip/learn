"""
email_theme.py - the shared NPG App Assist email theme.

Every notification email in the application (health check, MIMP, project
status, to-do digest, ServiceNow summary, certificate expiry, password reset)
uses the same visual identity, built from the helpers below:

  * A deep-burgundy masthead under a brighter red brand rule: tracked eyebrow
    and big white title on the left, the NORTHERN POWERGRID wordmark
    top-right, chips underneath. The brand hue at chrome weight - a module
    hero gets its colour on screen from a burgundy radial, which the Word
    engine cannot draw, so the band carries it flat instead.
  * A graphite footer band naming the sending module, under its own red rule
    - the application's one dark value, so a message keeps the product's
    pairing: brand above, chrome below, light workspace between.
  * Chips, callouts, stat tiles, buttons and rules as tiny tables.

WHY THIS LOOKS "FLATTER" THAN THE APPLICATION AND MUST STAY THAT WAY

The web theme (npg.css) gets its material from radial gradients, rgba tints,
box-shadow and border-radius. Desktop Outlook renders HTML with the WORD
engine and silently drops all four. An email that leans on them looks right
in Outlook on the web and broken on the desktop - which is what the gradient
masthead this file used to ship actually did, VML fallback and all.

So the email language is the same DESIGN carried by different means: the type
ramp, the neutral ramp, the spacing rhythm and the flat brand values are
shared with npg.css; the material is not. Concretely:

  * Colour is a solid table-cell fill set with BOTH the `bgcolor` attribute
    and inline `background-color` - never a gradient, never rgba. Any
    translucency is PRE-BLENDED to a hex value (see CHIP_BG).
  * The logo is a styled-text wordmark, not an image: embedded/hosted images
    are blocked by default in many Outlook configurations, text always
    renders.
  * Nested tables + inline styles; no <div> layout, no flex, pre-uppercased
    labels, explicit pixel line-heights with `mso-line-height-rule:exactly`.
  * border-radius is progressive enhancement only - every element must still
    read correctly as a square-cornered box.
  * State is carried by a tint fill plus a hairline on ALL FOUR sides, never
    by a coloured stripe down one edge (the same rule as the web theme: a
    single-side accent border reads as something stuck on).

Callers keep their own body content and drop `hero_rows(...)` /
`footer_rows(...)` into the container table where their header/footer rows
go. The newer primitives - `callout`, `stat_tile`, `button`, `rule_row`,
`section_label` - are optional: they exist so a body stops hand-rolling the
same tinted box five different ways.

Preview: artifacts/email-theme/render_previews.py renders every email to HTML
with stub data. Re-run it after touching this file.
"""

# ---------------------------------------------------------------------------
# Palette - single source of truth for email colours.
#
# The neutrals are the Slate ramp from npg.css (--ink / --page / --line), so
# an email and the screen it links to are the same colours. The names are the
# original ones because nine modules import them.
# ---------------------------------------------------------------------------
NPG_RED        = '#AB1236'   # brand: links, primary buttons, accents
NPG_RED_DARK   = '#7D0C27'   # --npg-deep
NPG_DARK       = '#0F1626'   # --ink: headings and figures
NPG_INK        = '#333E52'   # --ink-2: body copy
NPG_LIGHT      = '#E7ECF3'   # --page: the canvas an email sits on
NPG_BORDER     = '#D3DBE7'   # --line: hairlines, card edges, table rules
NPG_BORDER_2   = '#BBC6D6'   # --line-2: stronger edge
NPG_TEXT       = '#0F1626'   # alias of NPG_DARK, kept for callers
NPG_TEXT_MUTED = '#5A6478'   # --ink-3: muted / secondary prose
NPG_TINT       = '#FDF1F4'   # --npg-tint: the faintest brand wash

# THE MASTHEAD BAND. Deep burgundy: the brand hue carried at chrome weight.
#
# The band was briefly graphite, to match the ground a module hero stands on.
# That ground works on screen because a burgundy radial lights it; flat in an
# email it arrived as a cold near-black slab with the brand reduced to the 3px
# spine - right by the token, wrong to the eye. This is dark enough to frame
# the message rather than shout at it, and reads as NPg at a glance.
NPG_BAND       = '#4A0E1E'

# Graphite - the application's one dark value (--graphite, the module rail).
# The FOOTER band, so a message keeps the pairing the product uses: brand
# above, chrome below, light workspace between.
NPG_GRAPHITE   = '#20242E'
GRAPHITE_LINE  = '#333A47'

# The corporate broadcast maroon, the masthead until 2026-09-13. Kept because
# it is the NPg email banner colour and callers may still want it.
NPG_MAROON     = '#7A1215'

# Band text. Pre-blended white, because Outlook ignores rgba(): the eyebrow
# sits on the burgundy masthead, the footer note on the graphite band.
EYEBROW_FG     = '#DBCFD2'   # ~white .80 over NPG_BAND       (9.8:1)
FOOT_FG        = '#AEB6C4'   # ~white .62 over NPG_GRAPHITE   (7.4:1)

# A chip is a lifted fill with a lighter hairline edge - both pre-blended over
# the masthead band.
CHIP_BG        = '#6B3946'   # white .18 over NPG_BAND
CHIP_BORDER    = '#7D515D'   # white .28 over NPG_BAND
CHIP_FG        = '#FFFFFF'

# Kept for compatibility: the banner background as an inline-style prefix.
HERO_BG = f'background-color:{NPG_BAND};'

# "Segoe UI" is present on every Windows desktop running Outlook and is the
# closest available stand-in for Geist; Arial carries everything else. Public,
# because every email body sets a font per cell and they must all set THIS one
# - a masthead in one face over a body in another is the tell of a template
# that grew in two halves.
FONT = "'Segoe UI',Arial,sans-serif"
_FONT = FONT

# Status tones. Fill / hairline / text, flat and pre-blended - the email
# rendition of the --ok / --warn / --stop / --info tints in npg.css.
TONES = {
    'ok':      {'bg': '#E7F5EF', 'border': '#BFE3D5', 'fg': '#0B5B41', 'accent': '#0F7050'},
    'warn':    {'bg': '#FDF2E4', 'border': '#F0D7B2', 'fg': '#8A4308', 'accent': '#B45309'},
    'stop':    {'bg': '#FDEEED', 'border': '#F3C9C6', 'fg': '#8F1C13', 'accent': '#B42318'},
    'info':    {'bg': '#ECF2FD', 'border': '#C6D8F7', 'fg': '#13489F', 'accent': '#175CD3'},
    'brand':   {'bg': NPG_TINT,  'border': '#EDCFD8', 'fg': '#8D0F2C', 'accent': NPG_RED},
    'neutral': {'bg': '#F2F5FA', 'border': NPG_BORDER, 'fg': NPG_INK,  'accent': NPG_TEXT_MUTED},
}


def tone(name):
    """Look up a status tone, falling back to neutral for unknown names."""
    return TONES.get(name, TONES['neutral'])


# ---------------------------------------------------------------------------
# Building blocks
# ---------------------------------------------------------------------------

def badge(bg: str, fg: str, label: str, border: str = '') -> str:
    """A chip badge as a tiny table - Outlook-safe (labels pre-uppercased by
    the caller; border-radius is progressive enhancement only). `border`
    draws the hairline edge that keeps a chip from reading as a blob; it
    defaults to the fill, which is the old flat look."""
    edge = border or bg
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
        f'style="display:inline-table;border-collapse:separate;border-spacing:0;">'
        f'<tr><td bgcolor="{bg}" style="background-color:{bg};padding:6px 13px;'
        f'font-family:{_FONT};font-size:10px;font-weight:bold;color:{fg};'
        f'mso-line-height-rule:exactly;line-height:13px;letter-spacing:1.3px;'
        f'border:1px solid {edge};border-radius:999px;">{label}</td></tr>'
        f'</table>'
    )


def wordmark(small: bool = False, on_dark: bool = True) -> str:
    """The NORTHERN POWERGRID wordmark as styled text (never an image, so it
    cannot be blocked). Stacked, right-aligned and upright - the italic of
    the older banner was the one thing that really dated it.

    The full stop is set in brand red. It is the only piece of colour in the
    lockup and the printed mark carries the same accent; at this size it is
    what stops the wordmark reading as plain bold type."""
    size, lh = (10, 13) if small else (12.5, 15)
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0">'
        f'<tr><td align="right" style="font-family:{_FONT};font-size:{size}px;'
        f'font-weight:bold;color:#FFFFFF;letter-spacing:3.2px;'
        f'mso-line-height-rule:exactly;line-height:{lh}px;">NORTHERN</td></tr>'
        f'<tr><td align="right" style="font-family:{_FONT};font-size:{size}px;'
        f'font-weight:bold;color:#FFFFFF;letter-spacing:1.8px;'
        f'mso-line-height-rule:exactly;line-height:{lh}px;">POWERGRID'
        f'<span style="color:{NPG_RED};">.</span></td></tr>'
        f'</table>'
    )


def kicker_row() -> str:
    """A 5px solid NPG-red brand bar. Not part of the standard masthead (the
    NPg banner has none) but kept for callers that want a rule."""
    return (
        f'<tr><td bgcolor="{NPG_RED}" style="background-color:{NPG_RED};'
        f'height:5px;line-height:5px;font-size:0;">&nbsp;</td></tr>'
    )


def rule_row(color: str = NPG_BORDER, height: int = 1) -> str:
    """A full-width hairline as its own row - the divider between sections of
    a container table."""
    return (
        f'<tr><td bgcolor="{color}" style="background-color:{color};'
        f'height:{height}px;line-height:{height}px;font-size:0;">&nbsp;</td></tr>'
    )


def section_label(text: str, color: str = NPG_TEXT_MUTED) -> str:
    """The tracked uppercase label that names a band of content. Same ramp as
    .npg-eyebrow on the web - 10.5px, .14em, muted ink (never --ink-4: this
    is prose, and it has to pass contrast)."""
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr><td style="font-family:{_FONT};font-size:10.5px;font-weight:bold;'
        f'color:{color};letter-spacing:1.5px;text-transform:uppercase;'
        f'mso-line-height-rule:exactly;line-height:15px;">{text}</td></tr>'
        f'</table>'
    )


def callout(tone_name: str, title: str, body: str = '') -> str:
    """A state block: tint fill, hairline on ALL FOUR sides, tinted heading.

    This replaces the 4px coloured stripe down the left edge that the older
    emails used. Same reasoning as the web theme - a single-side accent reads
    as something stuck onto the box rather than part of it - and it survives
    Outlook, which renders a one-sided border at an unpredictable width.
    """
    pal = tone(tone_name)
    body_html = ''
    if body:
        # The TITLE carries the state colour. The body is prose and sits on
        # the normal ink ramp - a whole paragraph in alert red is shouting,
        # and it measures worse against a tinted ground than plain ink does.
        body_html = (
            f'<tr><td style="padding-top:6px;font-family:{_FONT};font-size:13px;'
            f'color:{NPG_INK};mso-line-height-rule:exactly;line-height:20px;">'
            f'{body}</td></tr>'
        )
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
        f'bgcolor="{pal["bg"]}" style="background-color:{pal["bg"]};'
        f'border:1px solid {pal["border"]};border-collapse:separate;border-spacing:0;border-radius:10px;">'
        f'<tr><td style="padding:16px 18px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr><td style="font-family:{_FONT};font-size:13.5px;font-weight:bold;'
        f'color:{pal["fg"]};letter-spacing:-0.1px;'
        f'mso-line-height-rule:exactly;line-height:19px;">{title}</td></tr>'
        f'{body_html}'
        f'</table>'
        f'</td></tr></table>'
    )


def stat_tile(value, label: str, tone_name: str = 'neutral') -> str:
    """One figure and its label, as a tile. Figures are the point of most of
    these emails, so they get the full type ramp: 30px bold in the tone's own
    accent over a tracked 10.5px label."""
    pal = tone(tone_name)
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
        f'bgcolor="{pal["bg"]}" style="background-color:{pal["bg"]};'
        f'border:1px solid {pal["border"]};border-collapse:separate;border-spacing:0;border-radius:10px;">'
        f'<tr><td align="center" style="padding:14px 10px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0">'
        f'<tr><td align="center" style="font-family:{_FONT};font-size:30px;font-weight:bold;'
        f'color:{pal["accent"]};mso-line-height-rule:exactly;line-height:34px;">{value}</td></tr>'
        f'<tr><td align="center" style="font-family:{_FONT};font-size:10.5px;font-weight:bold;'
        f'color:{pal["fg"]};letter-spacing:1.2px;text-transform:uppercase;'
        f'mso-line-height-rule:exactly;line-height:15px;padding-top:3px;">{label}</td></tr>'
        f'</table>'
        f'</td></tr></table>'
    )


def button(href: str, label: str, tone_name: str = 'brand') -> str:
    """A primary action as a table cell, not an <a> with padding - Outlook
    ignores padding on inline elements, so the cell has to be the button."""
    bg = NPG_RED if tone_name == 'brand' else tone(tone_name)['accent']
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
        f'style="display:inline-table;border-collapse:separate;border-spacing:0;">'
        f'<tr><td bgcolor="{bg}" align="center" '
        f'style="background-color:{bg};border:1px solid {NPG_RED_DARK};'
        f'border-radius:10px;padding:12px 24px;">'
        f'<a href="{href}" style="font-family:{_FONT};font-size:13px;font-weight:bold;'
        f'color:#FFFFFF;text-decoration:none;display:inline-block;'
        f'mso-line-height-rule:exactly;line-height:16px;">{label}</a>'
        f'</td></tr></table>'
    )


# The envelope's corner radius. The two bands carry it on their OUTER
# corners so they follow the container card in clients that can draw one;
# Word ignores it and the whole envelope stays square, which is equally
# correct - that is the contract for every radius in this file.
CARD_RADIUS = 14


def _band_td(inner_html: str, bg: str, radius: str = '') -> str:
    """A <td> painted a flat band colour. `bgcolor` is the attribute every
    engine honours (including desktop Outlook's Word renderer); the inline
    style repeats it for clients that prefer CSS."""
    rad = f'border-collapse:separate;border-spacing:0;border-radius:{radius};' if radius else ''
    return (
        f'<td bgcolor="{bg}" '
        f'style="background-color:{bg};padding:0;{rad}">{inner_html}</td>'
    )


def hero_rows(eyebrow: str, title: str, chips=(), width: int = 600,
              subtitle: str = '') -> str:
    """The themed email header.

    THE COMPOSITION, and why each part earns its place:

      * A 3px rule across the very top in the brighter brand red - the spine.
        It is the first thing the eye meets, and the one saturated colour
        above the fold.
      * A deep-burgundy band. On screen a module hero is lit by a burgundy
        radial over graphite; the Word engine draws neither gradients nor
        radials, so the band states the hue flat and lets the spine supply the
        highlight the radial would have given it.
      * Inside it, one three-step ramp and nothing else: a tracked eyebrow
        naming the report, the title at 28/36 (the largest type in the
        message, so it had better be the thing worth reading), an optional
        one-line summary, then the chips. The steps are separated by space,
        never by a rule - restraint is what makes a masthead read premium.
      * The wordmark sits top-right against the eyebrow, giving the band one
        column of content and one fixed anchor.

    Returns full <tr> rows for the caller's 100%-width container table.
    `eyebrow` / `title` / `subtitle` may contain entities and must be
    pre-escaped by the caller; `chips` is an iterable of badge(...)
    fragments. `width` is accepted for compatibility (the old VML gradient
    needed it) and ignored.
    """
    chips = [c for c in chips if c]
    chips_html = ''
    if chips:
        cells = ''.join(
            f'<td style="padding-right:8px;">{c}</td>' if i < len(chips) - 1
            else f'<td>{c}</td>'
            for i, c in enumerate(chips)
        )
        chips_html = (
            f'<tr><td colspan="2" style="padding-top:20px;">'
            f'<table role="presentation" cellpadding="0" cellspacing="0" '
            f'border="0"><tr>{cells}</tr></table></td></tr>'
        )

    subtitle_html = ''
    if subtitle:
        subtitle_html = (
            f'<tr><td colspan="2" style="padding-top:10px;font-family:{_FONT};'
            f'font-size:13.5px;color:{FOOT_FG};mso-line-height-rule:exactly;'
            f'line-height:21px;">{subtitle}</td></tr>'
        )

    inner = (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr><td class="px-32" style="padding:32px 32px 30px 32px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr>'
        f'<td valign="top" style="font-family:{_FONT};font-size:10.5px;font-weight:bold;'
        f'color:{EYEBROW_FG};mso-line-height-rule:exactly;line-height:15px;'
        f'letter-spacing:1.8px;padding-bottom:13px;">{eyebrow}</td>'
        f'<td align="right" valign="top" style="padding-left:20px;white-space:nowrap;">'
        f'{wordmark()}</td>'
        f'</tr>'
        f'<tr><td colspan="2" style="font-family:{_FONT};font-size:28px;font-weight:bold;'
        f'color:#FFFFFF;letter-spacing:-0.2px;mso-line-height-rule:exactly;'
        f'line-height:36px;">{title}</td></tr>'
        f'{subtitle_html}'
        f'{chips_html}'
        f'</table>'
        f'</td></tr></table>'
    )
    return (
        f'<tr><td bgcolor="{NPG_RED}" style="background-color:{NPG_RED};height:3px;'
        f'line-height:3px;font-size:0;'
        f'border-collapse:separate;border-spacing:0;border-radius:{CARD_RADIUS}px {CARD_RADIUS}px 0 0;">&nbsp;</td></tr>'
        + f'<tr>{_band_td(inner, NPG_BAND)}</tr>'
    )


def footer_rows(module_line: str, width: int = 600, note: str = '') -> str:
    """The themed email footer: a graphite band closing the envelope, under a
    1px brand hairline.

    Deliberately asymmetric with the masthead - 3px of red opens the message,
    1px closes it. Two equal slabs read as a border; this reads as a
    beginning and an end. The band carries the sending module (so a reader
    knows which part of App Assist is talking to them), the standing
    do-not-reply note, and the small wordmark.

    `module_line` names the module, e.g.
    'Security &middot; Certificate Monitoring'. `note` replaces the standing
    note for a sender that needs its own. `width` is accepted for
    compatibility and ignored."""
    note = note or 'Generated automatically &middot; Do not reply to this message'
    inner = (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr><td class="px-32" style="padding:22px 32px 24px 32px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr>'
        f'<td valign="top" style="font-family:{_FONT};font-size:12px;font-weight:bold;'
        f'color:#FFFFFF;mso-line-height-rule:exactly;line-height:17px;'
        f'letter-spacing:0.2px;padding-bottom:5px;">'
        f'NPG App Assist &middot; {module_line}</td>'
        f'<td align="right" valign="top" rowspan="2" '
        f'style="padding-left:20px;white-space:nowrap;">{wordmark(small=True)}</td>'
        f'</tr>'
        f'<tr><td style="font-family:{_FONT};font-size:11px;color:{FOOT_FG};'
        f'mso-line-height-rule:exactly;line-height:16px;">{note}</td></tr>'
        f'</table>'
        f'</td></tr></table>'
    )
    return (
        rule_row(NPG_RED, 1)
        + '<tr>' + _band_td(inner, NPG_GRAPHITE,
                            f'0 0 {CARD_RADIUS}px {CARD_RADIUS}px') + '</tr>'
    )
