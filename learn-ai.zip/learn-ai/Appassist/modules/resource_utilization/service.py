"""
Resource Utilization - calculation service.

Pure logic only (no DB access) so it is unit-testable; the routes feed it
plain values queried from the ORM.

The utilization model - TIMESHEET ACTUALS
-----------------------------------------
Utilization measures what people actually worked, not what was planned for
them. For a chosen period and each user:

* capacity      = working days (Mon-Fri, minus the admin-managed holiday
                  calendar) in the period x the standard day hours, MINUS
                  any leave hours logged (the leave category reduces
                  capacity instead of counting as work - someone on leave
                  never reads as under-utilized)
* worked hours  = the timesheet hours the user logged in the Activity
                  Tracker within the period, excluding leave - including
                  weekend entries (production issues, deployments), which
                  count in full on top of the weekday capacity, so overtime
                  pushes utilization above 100% instead of being hidden
* utilization % = worked hours / capacity
* billable %    = billable hours / capacity, where billable = every worked
                  hour whose category is not in the admin-managed
                  non-billable list (uncategorised entries count billable)

Task allocation, BAU application support and ServiceNow workload are shown
as CONTEXT next to the number (how many projects/tasks, how many supported
applications, how many incidents/SRs in the last year) - they explain the
demand on a person but never inflate the utilization figure. A 3-day task
finished in 1 day therefore reads as 1 day of actual work, not 3.

Because the number is self-reported, every view carries a timesheet
COMPLIANCE signal: the share of working days that have at least one entry
(a leave entry counts - the day is accounted for). Low utilization + low
compliance means "didn't log", not "idle".

Default bands: below 70% under-utilized, 70-100% healthy, above 100%
over-utilized - admin-configurable via the workforce settings (routes load
the saved thresholds and pass them in; this module stays pure).
"""

from datetime import date, timedelta

from modules.activity_tracker.models import STANDARD_DAY_HOURS


# Utilization bands (percentages) - defaults; the admin-saved thresholds
# from workforce settings override these via the band/stats keyword args.
UNDER_UTILIZED_BELOW = 70.0
OVER_UTILIZED_ABOVE  = 100.0

# Period presets offered on every dashboard page, in display order.
PERIOD_PRESETS = [
    ('this_week',  'This week'),
    ('last_week',  'Last week'),
    ('this_month', 'This month'),
    ('last_month', 'Last month'),
    ('last_30',    'Last 30 days'),
    ('last_90',    'Last 90 days'),
]
PERIOD_PRESET_KEYS = [k for k, _ in PERIOD_PRESETS]
PERIOD_PRESET_LABELS = dict(PERIOD_PRESETS)
DEFAULT_PERIOD = 'this_month'


# ---------------------------------------------------------------------------
# Periods
# ---------------------------------------------------------------------------

def resolve_period(preset, start_raw=None, end_raw=None, today=None):
    """
    Return (start_date, end_date, preset_key) for a preset or a custom range.

    Unknown presets fall back to DEFAULT_PERIOD. A custom range needs both
    dates parseable and start <= end, otherwise it also falls back.
    """
    today = today or date.today()

    if preset == 'custom':
        try:
            start = date.fromisoformat(str(start_raw))
            end = date.fromisoformat(str(end_raw))
            if start <= end:
                return start, end, 'custom'
        except (TypeError, ValueError):
            pass
        preset = DEFAULT_PERIOD

    if preset not in PERIOD_PRESET_KEYS:
        preset = DEFAULT_PERIOD

    monday = today - timedelta(days=today.weekday())
    if preset == 'this_week':
        return monday, monday + timedelta(days=6), preset
    if preset == 'last_week':
        return monday - timedelta(days=7), monday - timedelta(days=1), preset
    if preset == 'last_month':
        first_this = today.replace(day=1)
        last_prev = first_this - timedelta(days=1)
        return last_prev.replace(day=1), last_prev, preset
    if preset == 'last_30':
        return today - timedelta(days=29), today, preset
    if preset == 'last_90':
        return today - timedelta(days=89), today, preset
    # this_month
    return today.replace(day=1), today, preset


def period_label(preset, start, end):
    if preset in PERIOD_PRESET_LABELS:
        return PERIOD_PRESET_LABELS[preset]
    return f"{start.strftime('%d %b %Y')} - {end.strftime('%d %b %Y')}"


# ---------------------------------------------------------------------------
# Working days and bands
# ---------------------------------------------------------------------------

def working_days(start, end, holidays=None):
    """
    All Mon-Fri dates in [start, end], inclusive, excluding any date in
    `holidays` (a set/collection of dates from the holiday calendar).
    """
    if start > end:
        return []
    holidays = holidays or ()
    days = []
    d = start
    while d <= end:
        if d.weekday() < 5 and d not in holidays:
            days.append(d)
        d += timedelta(days=1)
    return days


def utilization_band(percent, under=None, over=None):
    """'low' / 'healthy' / 'over' - or 'none' when there is no capacity."""
    if percent is None:
        return 'none'
    if percent > (over if over is not None else OVER_UTILIZED_ABOVE):
        return 'over'
    if percent < (under if under is not None else UNDER_UTILIZED_BELOW):
        return 'low'
    return 'healthy'


BAND_LABELS = {
    'over':    'Over-utilized',
    'healthy': 'Healthy',
    'low':     'Under-utilized',
    'none':    'No capacity',
}


# ---------------------------------------------------------------------------
# Per-user and aggregated statistics
# ---------------------------------------------------------------------------

def compute_user_stats(hours_by_date, start, end, *, billable_by_date=None,
                       leave_by_date=None, day_hours=None, holidays=None,
                       under=None, over=None):
    """
    Timesheet utilization for one user over [start, end].

    hours_by_date    - {date: WORKED hours logged} (leave excluded; any
                       dates - only those inside the range count). Weekend
                       hours count in full while capacity counts weekdays
                       only - overtime shows up.
    billable_by_date - {date: billable hours} subset of the worked hours
                       (category not in the non-billable list). Optional.
    leave_by_date    - {date: leave-category hours}. Leave on a working day
                       REDUCES capacity (capped at one day's hours per day)
                       instead of counting as work, and marks the day as
                       accounted-for in the compliance signal.
    day_hours        - standard day hours (default STANDARD_DAY_HOURS).
    holidays         - holiday-calendar dates excluded from capacity.
    under / over     - band thresholds (default the module constants).
    """
    per_day = float(day_hours or STANDARD_DAY_HOURS)
    workdays = working_days(start, end, holidays)
    capacity_days = len(workdays)
    workday_set = set(workdays)

    leave_hours = 0.0
    leave_days_accounted = set()
    for d, hours in (leave_by_date or {}).items():
        if not (start <= d <= end) or d not in workday_set:
            continue
        h = min(float(hours or 0.0), per_day)   # a day of leave at most
        if h > 0:
            leave_hours += h
            leave_days_accounted.add(d)

    capacity_hours = max(capacity_days * per_day - leave_hours, 0.0)

    worked = 0.0
    billable = 0.0
    weekend_hours = 0.0
    logged_weekdays = set()
    for d, hours in (hours_by_date or {}).items():
        if not (start <= d <= end):
            continue
        h = float(hours or 0.0)
        worked += h
        if d.weekday() >= 5 or d not in workday_set:
            # Weekend or holiday work: extra hours on top of capacity.
            weekend_hours += h
        elif h > 0:
            logged_weekdays.add(d)
    for d, hours in (billable_by_date or {}).items():
        if start <= d <= end and float(hours or 0.0) > 0:
            billable += float(hours)

    accounted_days = len(logged_weekdays | leave_days_accounted)

    percent = (round(worked / capacity_hours * 100.0, 1)
               if capacity_hours else None)
    billable_percent = (round(billable / capacity_hours * 100.0, 1)
                        if capacity_hours else None)
    compliance = (round(accounted_days / capacity_days * 100.0)
                  if capacity_days else None)

    return {
        'capacity_days':    capacity_days,
        'capacity_hours':   round(capacity_hours, 2),
        'worked_hours':     round(worked, 2),
        'billable_hours':   round(billable, 2),
        'billable_percent': billable_percent,
        'weekend_hours':    round(weekend_hours, 2),
        'leave_hours':      round(leave_hours, 2),
        'logged_days':      accounted_days,
        'compliance':       compliance,       # % of working days accounted
        'percent':          percent,
        'band':             utilization_band(percent, under, over),
    }


def aggregate_stats(user_stats, under=None, over=None):
    """
    Roll a list of per-user stat dicts (compute_user_stats output) up into
    one group-level dict. Percent is hours-weighted: total worked hours over
    total capacity, not a mean of the members' percentages. Compliance is
    likewise day-weighted.
    """
    capacity = sum(s['capacity_hours'] for s in user_stats)
    worked = sum(s['worked_hours'] for s in user_stats)
    billable = sum(s.get('billable_hours', 0.0) for s in user_stats)
    weekend = sum(s['weekend_hours'] for s in user_stats)
    leave = sum(s.get('leave_hours', 0.0) for s in user_stats)
    capacity_days = sum(s['capacity_days'] for s in user_stats)
    logged_days = sum(s['logged_days'] for s in user_stats)
    percent = round(worked / capacity * 100.0, 1) if capacity else None
    return {
        'headcount':        len(user_stats),
        'capacity_hours':   round(capacity, 2),
        'worked_hours':     round(worked, 2),
        'billable_hours':   round(billable, 2),
        'billable_percent': (round(billable / capacity * 100.0, 1)
                             if capacity else None),
        'weekend_hours':    round(weekend, 2),
        'leave_hours':      round(leave, 2),
        'compliance':       (round(logged_days / capacity_days * 100.0)
                             if capacity_days else None),
        'percent':          percent,
        'band':             utilization_band(percent, under, over),
        'over_count':       sum(1 for s in user_stats if s['band'] == 'over'),
        'low_count':        sum(1 for s in user_stats if s['band'] == 'low'),
    }


def group_users(rows, key_func):
    """
    Group (user, stats) pairs by key_func(user) -> {key: [(user, stats)...]}
    preserving first-seen key order. Empty/None keys map to ''.
    """
    grouped = {}
    for user, stats in rows:
        key = key_func(user) or ''
        grouped.setdefault(key, []).append((user, stats))
    return grouped


# ---------------------------------------------------------------------------
# T&M allocation consumption (driven by Project Management)
# ---------------------------------------------------------------------------
#
# The T&M "contract" IS the project-task allocation: a resource assigned to
# a task for 3 working days at 8h/day has a 24-hour allocation. Consumption
# comes from the SAME timesheet actuals as utilization - the hours the
# resource logged AGAINST THAT TASK (entries linked via
# ActivityEntry.project_task_id). There is one timesheet entry form; linking
# it to a task is what burns the allocation.
#
# Extension has two triggers, either one flags the engagement:
#   * hours logged on a date AFTER the task's planned end ("allocated for
#     3 days, still filling the timesheet on day 4"), or
#   * more hours than the allocation sold, whatever the dates.
#
# Bands: <80% ok - 80-100% nearing - =100% reached (allocation used)
#        - extended when either trigger fires.

ALLOCATION_NEARING_PCT = 80.0

ALLOCATION_BAND_LABELS = {
    'ok':       'On track',
    'nearing':  'Nearing allocation',
    'reached':  'Allocation used',
    'exceeded': 'Extended',
}


def allocation_band(percent, after_end_hours=0.0):
    if after_end_hours and after_end_hours > 0:
        return 'exceeded'
    if percent is None:
        return 'ok'
    if percent > 100.0:
        return 'exceeded'
    if percent >= 100.0:
        return 'reached'
    if percent >= ALLOCATION_NEARING_PCT:
        return 'nearing'
    return 'ok'


def task_allocation(start, end, hours_per_day=None, holidays=None):
    """(allocated_days, allocated_hours) for a task's planned window."""
    per_day = float(hours_per_day or STANDARD_DAY_HOURS)
    days = len(working_days(start, end, holidays))
    return days, days * per_day


def split_task_hours(hours_by_date, end):
    """
    (consumed_hours, days_logged, after_end_hours, after_end_days) from a
    {date: hours} map of the entries LINKED to one task. Every linked hour
    consumes the allocation; hours dated after the planned end are the
    extension the business must see.
    """
    consumed = 0.0
    days_logged = 0
    after_hours = 0.0
    after_days = 0
    for d, hours in (hours_by_date or {}).items():
        h = float(hours or 0.0)
        consumed += h
        if h > 0:
            days_logged += 1
            if end is not None and d > end:
                after_hours += h
                after_days += 1
    return round(consumed, 2), days_logged, round(after_hours, 2), after_days


def allocation_consumption(allocated_hours, hours_per_day, consumed_hours,
                           after_end_hours=0.0, days_logged=0,
                           after_end_days=0):
    """
    How much of a task's T&M allocation the linked timesheet hours have
    consumed. `consumed_days` is the hours-equivalent in allocation days
    (consumed / hours_per_day); `days_logged` (calendar days with an entry)
    rides along as context - 3 allocated days can be burned across 5 half
    days.
    """
    allocated = float(allocated_hours or 0.0)
    per_day = float(hours_per_day or STANDARD_DAY_HOURS) or STANDARD_DAY_HOURS
    consumed = round(float(consumed_hours or 0.0), 2)
    after_hours = round(float(after_end_hours or 0.0), 2)

    percent = (round(consumed / allocated * 100.0, 1) if allocated else None)
    remaining = round(max(allocated - consumed, 0.0), 2)
    overrun = round(max(consumed - allocated, 0.0), 2)

    return {
        'allocated_hours': round(allocated, 2),
        'allocated_days':  round(allocated / per_day, 2),
        'hours_per_day':   per_day,
        'consumed_hours':  consumed,
        'consumed_days':   round(consumed / per_day, 2),
        'days_logged':     days_logged,
        'remaining_hours': remaining,
        'remaining_days':  round(remaining / per_day, 2),
        'overrun_hours':   overrun,
        'after_end_hours': after_hours,
        'after_end_days':  after_end_days,
        'percent':         percent,
        'band':            allocation_band(percent, after_hours),
    }
