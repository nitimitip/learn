"""
Resource Utilization - workforce configuration models.

Two small admin-managed tables that make the utilization math defensible:

* ``workforce_holidays``  - the public-holiday calendar. working_days()
  subtracts these dates, so a month with two bank holidays no longer
  inflates everyone's capacity (and depresses utilization + compliance).

* ``workforce_settings``  - a single row of tunables with safe defaults:
  the utilization band thresholds, the standard working day in hours, and
  which activity categories are NON-billable. Entries without a category
  count as billable (forgiving default); the leave category is always
  non-billable and always capacity-reducing.

Both are read by ``load_settings()`` / ``load_holidays()`` below - the
service layer stays pure and receives plain values.

No cross-module foreign keys by design: this module owns only the two
config tables above. All utilization figures are DERIVED at query time from
Project Management (assigned tasks = allocations) and the Activity Tracker
(timesheet entries), joined in the service layer - so there is deliberately
no allocation/timesheet table here, and no FK from here into projects/users.
"""

import logging
from datetime import date, datetime, timedelta

from sqlalchemy import Column, Date, DateTime, Float, Integer, String, Text
from sqlalchemy.sql import func

from database import Base
from modules.activity_tracker.models import (ACTIVITY_CATEGORIES,
                                             LEAVE_CATEGORY,
                                             STANDARD_DAY_HOURS)

logger = logging.getLogger(__name__)

# Defaults used until an admin saves a settings row (and to fill any blank
# field on a saved row).
DEFAULT_UNDER_PCT = 70.0
DEFAULT_OVER_PCT = 100.0
DEFAULT_DAY_HOURS = STANDARD_DAY_HOURS

# Categories that do NOT count as billable work by default. Everything else
# - including entries with no category at all - counts as billable.
DEFAULT_NON_BILLABLE = ['Meeting', 'Training', 'Documentation', 'Admin',
                        LEAVE_CATEGORY, 'Other']


class WorkforceHoliday(Base):
    """One public-holiday date excluded from working-day capacity."""
    __tablename__ = 'workforce_holidays'

    id           = Column(Integer, primary_key=True)
    holiday_date = Column(Date, nullable=False, unique=True, index=True)
    name         = Column(String(120), nullable=False)
    created_at   = Column(DateTime, default=func.now())

    def __repr__(self):
        return f'<WorkforceHoliday {self.holiday_date} {self.name!r}>'


class WorkforceSettings(Base):
    """The single settings row (created on first admin save)."""
    __tablename__ = 'workforce_settings'

    id                      = Column(Integer, primary_key=True)
    under_utilized_below    = Column(Float, nullable=False,
                                     default=DEFAULT_UNDER_PCT)
    over_utilized_above     = Column(Float, nullable=False,
                                     default=DEFAULT_OVER_PCT)
    day_hours               = Column(Float, nullable=False,
                                     default=DEFAULT_DAY_HOURS)
    # Comma-separated category names treated as non-billable.
    non_billable_categories = Column(Text)
    updated_by              = Column(String(100))
    updated_at              = Column(DateTime, default=func.now(),
                                     onupdate=func.now())

    def __repr__(self):
        return (f'<WorkforceSettings under<{self.under_utilized_below} '
                f'over>{self.over_utilized_above} '
                f'day={self.day_hours}h>')


def parse_category_list(raw) -> list:
    """Comma-separated text -> clean category-name list (order preserved)."""
    out = []
    for part in (raw or '').split(','):
        name = part.strip()
        if name and name not in out:
            out.append(name)
    return out


def load_settings(db_session) -> dict:
    """
    The effective workforce settings as a plain dict (defaults when no row
    has been saved yet, or per-field when a saved value is missing/invalid):

      under_pct / over_pct - utilization band thresholds (percent)
      day_hours            - the standard working day used for capacity
      non_billable         - set of category names that are not billable
                             (always includes the leave category)
    """
    row = None
    try:
        row = db_session.query(WorkforceSettings).first()
    except Exception as e:                              # pragma: no cover
        logger.warning('Could not load workforce settings: %s', e)

    under = row.under_utilized_below if row else None
    over = row.over_utilized_above if row else None
    day_hours = row.day_hours if row else None
    non_billable = (parse_category_list(row.non_billable_categories)
                    if row and row.non_billable_categories is not None
                    else list(DEFAULT_NON_BILLABLE))

    if not under or under <= 0:
        under = DEFAULT_UNDER_PCT
    if not over or over <= under:
        over = max(DEFAULT_OVER_PCT, under)
    if not day_hours or not (1.0 <= day_hours <= 24.0):
        day_hours = DEFAULT_DAY_HOURS

    non_billable_set = set(non_billable)
    non_billable_set.add(LEAVE_CATEGORY)   # leave is never billable

    return {
        'under_pct': float(under),
        'over_pct': float(over),
        'day_hours': float(day_hours),
        'non_billable': non_billable_set,
    }


def load_holidays(db_session, start=None, end=None) -> set:
    """Holiday dates as a set, optionally restricted to [start, end]."""
    try:
        query = db_session.query(WorkforceHoliday.holiday_date)
        if start is not None:
            query = query.filter(WorkforceHoliday.holiday_date >= start)
        if end is not None:
            query = query.filter(WorkforceHoliday.holiday_date <= end)
        return {d for (d,) in query.all()}
    except Exception as e:                              # pragma: no cover
        logger.warning('Could not load workforce holidays: %s', e)
        return set()


def billable_category_choices() -> list:
    """Categories offered on the settings page (leave is forced, not offered)."""
    return [c for c in ACTIVITY_CATEGORIES if c != LEAVE_CATEGORY]


# ---------------------------------------------------------------------------
# Holiday-calendar Excel upload (bulk load of a whole year)
# ---------------------------------------------------------------------------

# Sanity cap on parsed holidays per upload - a full year is ~10-20 rows,
# multi-year calendars stay comfortably below this.
MAX_HOLIDAY_UPLOAD_ROWS = 500

# Cell text treated as a header row (skipped silently, not "invalid").
_HEADER_TOKENS = {'date', 'holiday date', 'holiday_date', 'day'}

# String date formats accepted besides ISO (dd-first, matching the app's
# display convention).
_DATE_FORMATS = ('%d/%m/%Y', '%d-%m-%Y', '%d.%m.%Y',
                 '%d %b %Y', '%d-%b-%Y', '%d %B %Y')

# Excel's day-serial epoch (1900 date system as openpyxl exposes it).
_EXCEL_EPOCH = date(1899, 12, 30)


def coerce_holiday_date(value):
    """A cell value -> date, or None when it cannot be read as one."""
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, (int, float)) and 1 < value < 200000:
        return _EXCEL_EPOCH + timedelta(days=int(value))
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return None
        try:
            return date.fromisoformat(raw)
        except ValueError:
            pass
        for fmt in _DATE_FORMATS:
            try:
                return datetime.strptime(raw, fmt).date()
            except ValueError:
                continue
    return None


def parse_holiday_rows(rows):
    """
    Parse spreadsheet rows (iterables of cell values; only the first two
    cells count: date, holiday name) into upload entries.

    Returns ([(date, name)...], stats) where stats counts what was skipped:
    'weekend' (capacity already excludes them), 'invalid' (unreadable date
    or missing name) and 'duplicate' (same date again later in the file -
    the first occurrence wins). Blank rows and a header row are ignored
    silently.
    """
    entries, seen = [], set()
    stats = {'weekend': 0, 'invalid': 0, 'duplicate': 0}
    for row in rows or ():
        cells = list(row or ())[:2] + [None, None]
        raw_date, raw_name = cells[0], cells[1]
        name = str(raw_name).strip() if raw_name is not None else ''
        d = coerce_holiday_date(raw_date)
        if d is None and not name:
            continue                       # blank row
        if d is None and str(raw_date or '').strip().lower() in _HEADER_TOKENS:
            continue                       # header row
        if d is None or not name:
            stats['invalid'] += 1
            continue
        if d.weekday() >= 5:
            stats['weekend'] += 1
            continue
        if d in seen:
            stats['duplicate'] += 1
            continue
        seen.add(d)
        entries.append((d, name[:120]))
        if len(entries) >= MAX_HOLIDAY_UPLOAD_ROWS:
            break
    return entries, stats


def upsert_holidays(db_session, entries):
    """
    Apply parsed (date, name) entries to the holiday table: new dates are
    added, an existing date gets its name updated. Returns
    (added, updated, unchanged). Caller commits.
    """
    existing = {h.holiday_date: h
                for h in db_session.query(WorkforceHoliday).all()}
    added = updated = unchanged = 0
    for d, name in entries:
        row = existing.get(d)
        if row is None:
            db_session.add(WorkforceHoliday(holiday_date=d, name=name))
            added += 1
        elif row.name != name:
            row.name = name
            updated += 1
        else:
            unchanged += 1
    return added, updated, unchanged
