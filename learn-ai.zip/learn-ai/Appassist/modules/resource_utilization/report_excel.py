"""
Resource Utilization -> professional Excel (.xlsx) report.

Rendered per scope (all resources, Application / Infra, or any deeper
drill-down) from the utilization dashboard. Styling mirrors
planning_excel.py / effort_excel.py - the NPG red title band, bordered
banded tables - so the file reads as a deliverable from the same system.

Utilization is TIMESHEET-BASED (hours actually logged vs capacity, with
the holiday calendar excluded and leave hours reducing capacity); project
tasks, supported applications and ServiceNow workload appear as context
columns, never in the percentage.

Excel behaviours (so the file works like a spreadsheet, not a screenshot):
* percentage / compliance columns are REAL numbers with number formats -
  they sort and filter correctly (blank when there is no capacity)
* every table carries an AutoFilter and frozen header row
* the utilization column gets an in-cell data bar
* every sheet is print-ready: landscape, fit-to-width, repeated header
  row, sheet name + page numbers in the footer

Sheets:
* Summary         - scope, period, KPI table, methodology (incl. the
                    configured thresholds, holiday calendar and data
                    freshness)
* Breakdown       - Team x Sub-group roll-up with a utilization bar chart
* Trend           - week-by-week utilization across the period (line chart)
* People          - one row per person: utilization, billable split, leave
                    and the full workload context
* T&M Allocations - one row per assigned project task: the planned volume
                    (working days x day hours) vs the timesheet hours
                    logged against the task, with after-end (extension)
                    and overrun columns. build_allocations_report()
                    renders the same table as a standalone register.

build_user_tickets_report() writes a separate, single-person workbook -
the ServiceNow ticket list offered from the People Explorer individual
page (Summary / Incidents / Service Requests / Themes). It renders the
SAME numbers the page shows, from the same helpers, so the download can
never disagree with the screen it was downloaded from.
"""

from datetime import datetime

from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.formatting.rule import DataBarRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.properties import PageSetupProperties

from modules.activity_tracker.models import STANDARD_DAY_HOURS
from modules.user_profile.models import (team_includes_bau,
                                         team_includes_project)

from .service import aggregate_stats, group_users

# Brand palette - NPG (Northern Powergrid) red, as in planning_excel.py
BRAND       = "AB1236"   # title band
BRAND_MID   = "7E0D27"   # subtitle / column-header band
BORDER_CLR  = "D7DEE7"
TEXT        = "1D293D"
MUTED       = "6B7280"
STRIPE      = "F6F8FB"
BAR_CLR     = "2563EB"
TOTAL_FILL  = "EEF2F6"

# Number formats: real numbers that sort/filter, shown with their unit.
PCT_FMT  = '0.0"%"'
PCT0_FMT = '0"%"'
HRS_FMT  = '0.##'
# Real date/datetime cells (not strings), so a ticket sheet sorts and
# filters by date the way a spreadsheet user expects.
DATE_FMT     = 'dd mmm yyyy'
DATETIME_FMT = 'dd mmm yyyy hh:mm'

BAND_FILL = {
    'over':    ("FEE2E2", "991B1B"),
    'healthy': ("DCFCE7", "166534"),
    'low':     ("FEF3C7", "92400E"),
    'none':    ("F1F5F9", "64748B"),
}

# T&M allocation consumption bands (allocation = task working days x day h).
ALLOCATION_BAND_FILL = {
    'ok':       ("DCFCE7", "166534"),
    'nearing':  ("FEF3C7", "92400E"),
    'reached':  ("EDE9FE", "5B21B6"),
    'exceeded': ("FEE2E2", "991B1B"),
}

THIN = Side(style="thin", color=BORDER_CLR)
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT   = Alignment(horizontal="left", vertical="center", wrap_text=True)


def _default_wf():
    from .service import OVER_UTILIZED_ABOVE, UNDER_UTILIZED_BELOW
    return {'under_pct': UNDER_UTILIZED_BELOW,
            'over_pct': OVER_UTILIZED_ABOVE,
            'day_hours': STANDARD_DAY_HOURS,
            'non_billable': set()}


def _title_band(ws, row, title, subtitle, ncols):
    """Two-row brand title band. Returns the next free row."""
    ws.merge_cells(start_row=row, start_column=1, end_row=row,
                   end_column=ncols)
    c = ws.cell(row=row, column=1, value=title)
    c.font = Font(bold=True, size=15, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=BRAND)
    c.alignment = LEFT
    ws.row_dimensions[row].height = 28

    ws.merge_cells(start_row=row + 1, start_column=1, end_row=row + 1,
                   end_column=ncols)
    c = ws.cell(row=row + 1, column=1, value=subtitle)
    c.font = Font(size=10.5, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=BRAND_MID)
    c.alignment = LEFT
    ws.row_dimensions[row + 1].height = 18
    return row + 3


def _section(ws, row, text, ncols):
    ws.merge_cells(start_row=row, start_column=1, end_row=row,
                   end_column=ncols)
    c = ws.cell(row=row, column=1, value=text)
    c.font = Font(bold=True, size=11, color=BRAND)
    c.alignment = LEFT
    return row + 1


def _header_row(ws, row, headers):
    for col, h in enumerate(headers, start=1):
        c = ws.cell(row=row, column=col, value=h)
        c.font = Font(bold=True, size=10, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=BRAND_MID)
        c.alignment = CENTER
        c.border = BORDER
    ws.row_dimensions[row].height = 20
    return row + 1


def _data_cell(ws, row, col, value, stripe=False, align=None, bold=False,
               color=TEXT, fill=None, num_format=None):
    c = ws.cell(row=row, column=col, value=value)
    c.font = Font(size=10, bold=bold, color=color)
    c.alignment = align or LEFT
    c.border = BORDER
    if num_format:
        c.number_format = num_format
    if fill:
        c.fill = PatternFill("solid", fgColor=fill)
    elif stripe:
        c.fill = PatternFill("solid", fgColor=STRIPE)
    return c


def _num_cell(ws, row, col, value, num_format=HRS_FMT, stripe=False,
              bold=False, color=TEXT, fill=None):
    """Numeric cell (None -> blank) so Excel can sort/filter the column."""
    return _data_cell(ws, row, col, value if value is not None else None,
                      stripe=stripe, align=CENTER, bold=bold, color=color,
                      fill=fill, num_format=num_format)


def _status_cell(ws, row, col, stats, band_labels):
    bg, fg = BAND_FILL[stats['band']]
    label = band_labels[stats['band']]
    if stats['percent'] is not None:
        label = f"{label} - {stats['percent']}%"
    _data_cell(ws, row, col, label, align=CENTER, bold=True,
               color=fg, fill=bg)


def _person_name(person):
    name = f"{(person.firstname or '').capitalize()} " \
           f"{(person.lastname or '').capitalize()}".strip()
    return name or person.username


def _workload_context(person, c):
    parts = []
    if team_includes_bau(person.team):
        parts.append(f"{c['support_apps']} application(s) supported")
    if team_includes_project(person.team):
        parts.append(f"{c['projects']} project(s) - {c['tasks']} task(s)")
    return ' - '.join(parts)


def _allocation_status_cell(ws, row, col, stats, allocation_band_labels):
    bg, fg = ALLOCATION_BAND_FILL[stats['band']]
    label = allocation_band_labels[stats['band']]
    if stats['percent'] is not None:
        label = f"{label} - {stats['percent']}%"
    _data_cell(ws, row, col, label, align=CENTER, bold=True,
               color=fg, fill=bg)


def _page_setup(ws, ncols, header_row=None):
    """Print-ready sheet: landscape, fit-to-width, repeated header row,
    sheet name + page numbers in the footer."""
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    ws.oddFooter.left.text = ws.title
    ws.oddFooter.right.text = "Page &P of &N"
    if header_row:
        ws.print_title_rows = f'{header_row}:{header_row}'


def _auto_filter(ws, header_row, last_row, ncols):
    if last_row >= header_row:
        ws.auto_filter.ref = (f"A{header_row}:"
                              f"{get_column_letter(ncols)}{last_row}")


def _data_bar(ws, col, first_row, last_row, max_value=150):
    """In-cell data bar on a percentage column (mirrors the dashboard)."""
    if last_row < first_row:
        return
    ref = (f"{get_column_letter(col)}{first_row}:"
           f"{get_column_letter(col)}{last_row}")
    ws.conditional_formatting.add(ref, DataBarRule(
        start_type='num', start_value=0,
        end_type='num', end_value=max_value,
        color=BAR_CLR, showValue=True))


def _write_allocations_sheet(wb, *, sheet_title, band_title, subtitle,
                             allocation_rows, allocation_band_labels,
                             day_hours=None, first_sheet=False):
    """
    One row per assigned project task (= one T&M allocation): the planned
    volume (working days x day hours, holiday calendar excluded), the
    timesheet hours logged against the task, the hours dated after the
    planned end (the extension) and the status.
    `allocation_rows` is [(task, project, person-or-None, stats)].
    """
    per_day = day_hours or STANDARD_DAY_HOURS
    ws = wb.active if first_sheet else wb.create_sheet(sheet_title)
    ws.title = sheet_title
    ws.sheet_view.showGridLines = False
    widths = (22, 20, 24, 11, 11, 10, 13, 12, 13, 13, 13, 14, 10, 18)
    for i, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = width

    row = _title_band(ws, 1, band_title, subtitle, len(widths))
    row = _section(
        ws, row,
        f"Allocation = the task's planned working days x {per_day:g}h "
        "(holiday calendar excluded). Consumption = timesheet hours logged "
        "against the task; hours after the planned end date are the "
        "EXTENSION the business must see.", len(widths))
    header_row_idx = row
    row = _header_row(ws, row, [
        "Resource", "Project", "Task", "Start", "Planned end",
        "Days alloc.", "Allocated (h)", "Logged (h)", "Logged (days)",
        "After end (h)", "Remaining (h)", "Overrun (h)", "% used",
        "Status"])

    first_data_row = row
    stripe = False
    for task, project, person, s in allocation_rows:
        name = _person_name(person) if person else f"user #{task.assigned_to}"
        _data_cell(ws, row, 1, name, stripe=stripe, bold=True)
        _data_cell(ws, row, 2, project.name if project else '-',
                   stripe=stripe)
        _data_cell(ws, row, 3, task.name, stripe=stripe)
        _data_cell(ws, row, 4, task.start_date.strftime('%d %b %Y'),
                   stripe=stripe, align=CENTER)
        _data_cell(ws, row, 5, task.end_date.strftime('%d %b %Y'),
                   stripe=stripe, align=CENTER)
        for col, val in ((6, s['allocated_days']), (7, s['allocated_hours']),
                         (8, s['consumed_hours']), (9, s['consumed_days']),
                         (11, s['remaining_hours'])):
            _num_cell(ws, row, col, val, stripe=stripe)
        _num_cell(ws, row, 10, s['after_end_hours'], stripe=stripe,
                  bold=s['after_end_hours'] > 0,
                  color="991B1B" if s['after_end_hours'] > 0 else TEXT)
        _num_cell(ws, row, 12, s['overrun_hours'], stripe=stripe,
                  bold=s['overrun_hours'] > 0,
                  color="991B1B" if s['overrun_hours'] > 0 else TEXT)
        _num_cell(ws, row, 13, s['percent'], num_format=PCT_FMT,
                  stripe=stripe)
        _allocation_status_cell(ws, row, 14, s, allocation_band_labels)
        row += 1
        stripe = not stripe
    last_data_row = row - 1

    # Totals across the listed allocations.
    total_allocated = round(sum(s['allocated_hours']
                                for _, _, _, s in allocation_rows), 2)
    total_logged = round(sum(s['consumed_hours']
                             for _, _, _, s in allocation_rows), 2)
    total_after = round(sum(s['after_end_hours']
                            for _, _, _, s in allocation_rows), 2)
    total_overrun = round(sum(s['overrun_hours']
                              for _, _, _, s in allocation_rows), 2)
    _data_cell(ws, row, 1, "TOTAL", bold=True, fill=TOTAL_FILL)
    for col in (2, 3, 4, 5, 6, 9, 11, 13, 14):
        _data_cell(ws, row, col, '', fill=TOTAL_FILL)
    _num_cell(ws, row, 7, total_allocated, bold=True, fill=TOTAL_FILL)
    _num_cell(ws, row, 8, total_logged, bold=True, fill=TOTAL_FILL)
    _num_cell(ws, row, 10, total_after, bold=True, fill=TOTAL_FILL,
              color="991B1B" if total_after else TEXT)
    _num_cell(ws, row, 12, total_overrun, bold=True, fill=TOTAL_FILL,
              color="991B1B" if total_overrun else TEXT)

    ws.freeze_panes = f"A{first_data_row}"
    _auto_filter(ws, header_row_idx, last_data_row, len(widths))
    _data_bar(ws, 13, first_data_row, last_data_row)
    _page_setup(ws, len(widths), header_row=header_row_idx)
    return ws


def build_allocations_report(stream, *, rows, allocation_band_labels,
                             generated_by='', day_hours=None):
    """Standalone T&M allocation register: `rows` is [(task, project, person, stats)]."""
    wb = Workbook()
    _write_allocations_sheet(
        wb, sheet_title="T&M Allocations",
        band_title="T&M Allocation Register",
        subtitle=f"generated {datetime.now().strftime('%d %b %Y %H:%M')}"
                 + (f"   |   by {generated_by}" if generated_by else ""),
        allocation_rows=rows,
        allocation_band_labels=allocation_band_labels,
        day_hours=day_hours,
        first_sheet=True)
    wb.save(stream)
    return wb


def build_utilization_report(stream, *, scope_title, period, rows, ctx,
                             band_labels, group_labels, unassigned_label,
                             generated_by='', allocation_rows=None,
                             allocation_band_labels=None, wf=None,
                             weekly=None, holidays_in_period=None,
                             snow_as_of=None):
    """
    Write the workbook for [(user, stats)] `rows` + context onto `stream`.

    wf                 - workforce settings dict (band thresholds, day
                         hours); defaults preserved for callers/tests that
                         do not pass one.
    weekly             - [(week_start_date, agg)] for the Trend sheet.
    holidays_in_period - weekday holiday dates inside the period.
    snow_as_of         - datetime of the latest ServiceNow workload capture.
    """
    wf = wf or _default_wf()
    agg = aggregate_stats([s for _, s in rows], under=wf['under_pct'],
                          over=wf['over_pct'])
    period_text = (f"{period['label']}  -  "
                   f"{period['start'].strftime('%d %b %Y')} - "
                   f"{period['end'].strftime('%d %b %Y')}")
    holidays_in_period = holidays_in_period or []

    wb = Workbook()

    # ------------------------------------------------------------- Summary
    ws = wb.active
    ws.title = "Summary"
    ws.sheet_view.showGridLines = False
    for col, width in zip('ABCDEF', (34, 18, 14, 14, 14, 14)):
        ws.column_dimensions[col].width = width

    row = _title_band(
        ws, 1, f"Resource Utilization Report - {scope_title}",
        f"{period_text}   |   generated "
        f"{datetime.now().strftime('%d %b %Y %H:%M')}"
        + (f"   |   by {generated_by}" if generated_by else ""), 6)

    row = _section(ws, row, "Key figures (timesheet-based)", 6)
    kpis = [
        ("People in scope", agg['headcount'], None),
        ("Capacity (hours)", agg['capacity_hours'], HRS_FMT),
        ("Hours logged", agg['worked_hours'], HRS_FMT),
        ("of which billable hours", agg['billable_hours'], HRS_FMT),
        ("of which weekend / extra hours", agg['weekend_hours'], HRS_FMT),
        ("Leave hours (capacity reduced)", agg['leave_hours'], HRS_FMT),
        ("Utilization", agg['percent'], PCT_FMT),
        ("Billable utilization", agg['billable_percent'], PCT_FMT),
        ("Status", band_labels[agg['band']], None),
        ("Timesheet compliance", agg['compliance'], PCT0_FMT),
        ("Over-utilized people", agg['over_count'], None),
        ("Under-utilized people", agg['low_count'], None),
        ("Public holidays in the period", len(holidays_in_period), None),
    ]
    for i, (label, value, fmt) in enumerate(kpis):
        _data_cell(ws, row + i, 1, label, stripe=i % 2 == 0, bold=True)
        if fmt:
            _num_cell(ws, row + i, 2, value, num_format=fmt,
                      stripe=i % 2 == 0)
        else:
            _data_cell(ws, row + i, 2, value, stripe=i % 2 == 0,
                       align=CENTER)

    note_row = row + len(kpis) + 2
    note_row = _section(ws, note_row, "How utilization is calculated", 6)
    notes = [
        "Utilization is based on ACTUAL work: the hours people logged in "
        "the Activity Tracker timesheet.",
        f"Capacity = working days (Mon-Fri, public holidays excluded) in "
        f"the period x {wf['day_hours']:g} hours, minus any leave hours "
        "logged (leave reduces capacity - someone on approved leave never "
        "reads as under-utilized).",
        "Utilization % = hours logged / capacity. Weekend and holiday "
        "hours (production issues, deployments) count in full on top of "
        "weekday capacity, so overtime pushes utilization above 100%.",
        "Billable utilization counts only hours whose category is "
        "billable (categories such as meetings, training, documentation "
        "and admin are excluded; uncategorised entries count as billable).",
        f"Bands: below {wf['under_pct']:g}% under-utilized - "
        f"{wf['under_pct']:g}-{wf['over_pct']:g}% healthy - above "
        f"{wf['over_pct']:g}% over-utilized. Group figures are "
        "hours-weighted.",
        "Timesheet compliance = share of working days with at least one "
        "entry (a leave entry counts - the day is accounted for). Low "
        "utilization with low compliance means hours were not logged, not "
        "that the person was idle.",
        "Projects/tasks assigned, applications supported (BAU) and "
        "ServiceNow incidents / service requests worked in the last year "
        "are shown as workload CONTEXT on the People sheet - they are "
        "never added to the utilization figure.",
    ]
    if holidays_in_period:
        listed = ', '.join(f"{d.strftime('%d %b')}" for d in
                           holidays_in_period[:12])
        if len(holidays_in_period) > 12:
            listed += ', ...'
        notes.append(f"Public holidays excluded from capacity in this "
                     f"period: {listed}.")
    if snow_as_of:
        notes.append("ServiceNow workload context is as of the last Batch "
                     f"Analysis upload on "
                     f"{snow_as_of.strftime('%d %b %Y %H:%M')}.")
    for i, n in enumerate(notes):
        ws.merge_cells(start_row=note_row + i, start_column=1,
                       end_row=note_row + i, end_column=6)
        c = ws.cell(row=note_row + i, column=1, value="*  " + n)
        c.font = Font(size=9.5, color=MUTED)
        c.alignment = LEFT
        ws.row_dimensions[note_row + i].height = 14
    _page_setup(ws, 6)

    # ----------------------------------------------------------- Breakdown
    ws = wb.create_sheet("Breakdown")
    ws.sheet_view.showGridLines = False
    widths = (20, 22, 9, 13, 12, 12, 12, 11, 12, 13, 12, 18)
    for i, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = width

    row = _title_band(ws, 1, f"Breakdown - {scope_title}", period_text,
                      len(widths))
    row = _section(ws, row, "Team x sub-group roll-up", len(widths))
    bd_header_row = row
    row = _header_row(ws, row, [
        "Team", "Sub-group", "People", "Capacity (h)", "Logged (h)",
        "Billable (h)", "Weekend (h)", "Leave (h)", "Compliance",
        "Utilization %", "Billable %", "Status"])

    chart_first_data_row = row
    stripe = False
    by_team = group_users(rows, lambda u: u.team)
    for team_key in sorted(by_team, key=lambda k: (k == '', k)):
        team_rows = by_team[team_key]
        by_sub = group_users(team_rows, lambda u: u.sub_group)
        for sub_key in sorted(by_sub, key=lambda k: (k == '', k)):
            sub_rows = by_sub[sub_key]
            sub_agg = aggregate_stats([s for _, s in sub_rows],
                                      under=wf['under_pct'],
                                      over=wf['over_pct'])
            _data_cell(ws, row, 1, team_key or unassigned_label,
                       stripe=stripe, bold=True)
            _data_cell(ws, row, 2, sub_key or unassigned_label,
                       stripe=stripe)
            for col, val, fmt in (
                    (3, sub_agg['headcount'], None),
                    (4, sub_agg['capacity_hours'], HRS_FMT),
                    (5, sub_agg['worked_hours'], HRS_FMT),
                    (6, sub_agg['billable_hours'], HRS_FMT),
                    (7, sub_agg['weekend_hours'], HRS_FMT),
                    (8, sub_agg['leave_hours'], HRS_FMT),
                    (9, sub_agg['compliance'], PCT0_FMT),
                    (10, sub_agg['percent'], PCT_FMT),
                    (11, sub_agg['billable_percent'], PCT_FMT)):
                _num_cell(ws, row, col, val, num_format=fmt or HRS_FMT,
                          stripe=stripe)
            _status_cell(ws, row, 12, sub_agg, band_labels)
            row += 1
            stripe = not stripe
    chart_last_data_row = row - 1

    # Grand total row.
    _data_cell(ws, row, 1, "TOTAL", bold=True, fill=TOTAL_FILL)
    _data_cell(ws, row, 2, scope_title, bold=True, fill=TOTAL_FILL)
    for col, val, fmt in ((3, agg['headcount'], None),
                          (4, agg['capacity_hours'], HRS_FMT),
                          (5, agg['worked_hours'], HRS_FMT),
                          (6, agg['billable_hours'], HRS_FMT),
                          (7, agg['weekend_hours'], HRS_FMT),
                          (8, agg['leave_hours'], HRS_FMT),
                          (9, agg['compliance'], PCT0_FMT),
                          (10, agg['percent'], PCT_FMT),
                          (11, agg['billable_percent'], PCT_FMT)):
        _num_cell(ws, row, col, val, num_format=fmt or HRS_FMT, bold=True,
                  fill=TOTAL_FILL)
    _status_cell(ws, row, 12, agg, band_labels)

    ws.freeze_panes = f"A{chart_first_data_row}"
    _auto_filter(ws, bd_header_row, chart_last_data_row, len(widths))
    _data_bar(ws, 10, chart_first_data_row, chart_last_data_row)
    _page_setup(ws, len(widths), header_row=bd_header_row)

    if chart_last_data_row >= chart_first_data_row:
        bar = BarChart()
        bar.type = "col"
        bar.title = "Utilization % by sub-group"
        bar.height, bar.width = 8.5, 22
        bar.y_axis.title = "Utilization %"
        data = Reference(ws, min_col=10, min_row=chart_first_data_row - 1,
                         max_row=chart_last_data_row)
        cats = Reference(ws, min_col=2, min_row=chart_first_data_row,
                         max_row=chart_last_data_row)
        bar.add_data(data, titles_from_data=True)
        bar.set_categories(cats)
        bar.legend = None
        bar.series[0].graphicalProperties.solidFill = BAR_CLR
        ws.add_chart(bar, f"A{row + 3}")

    # ---------------------------------------------------------------- Trend
    if weekly:
        ws = wb.create_sheet("Trend")
        ws.sheet_view.showGridLines = False
        widths = (16, 13, 12, 12, 12, 13, 12, 18)
        for i, width in enumerate(widths, start=1):
            ws.column_dimensions[get_column_letter(i)].width = width

        row = _title_band(ws, 1, f"Weekly trend - {scope_title}",
                          period_text, len(widths))
        row = _section(ws, row, "Week-by-week utilization (weeks clipped "
                                "to the period)", len(widths))
        tr_header_row = row
        row = _header_row(ws, row, [
            "Week starting", "Capacity (h)", "Logged (h)", "Billable (h)",
            "Leave (h)", "Utilization %", "Billable %", "Status"])
        tr_first = row
        stripe = False
        for week_start, wagg in weekly:
            _data_cell(ws, row, 1, week_start.strftime('%d %b %Y'),
                       stripe=stripe, bold=True)
            for col, val, fmt in ((2, wagg['capacity_hours'], HRS_FMT),
                                  (3, wagg['worked_hours'], HRS_FMT),
                                  (4, wagg['billable_hours'], HRS_FMT),
                                  (5, wagg['leave_hours'], HRS_FMT),
                                  (6, wagg['percent'], PCT_FMT),
                                  (7, wagg['billable_percent'], PCT_FMT)):
                _num_cell(ws, row, col, val, num_format=fmt, stripe=stripe)
            _status_cell(ws, row, 8, wagg, band_labels)
            row += 1
            stripe = not stripe
        tr_last = row - 1

        ws.freeze_panes = f"A{tr_first}"
        _page_setup(ws, len(widths), header_row=tr_header_row)

        if tr_last > tr_first:
            line = LineChart()
            line.title = "Utilization % by week"
            line.height, line.width = 8.5, 22
            line.y_axis.title = "Utilization %"
            data = Reference(ws, min_col=6, min_row=tr_header_row,
                             max_row=tr_last)
            cats = Reference(ws, min_col=1, min_row=tr_first,
                             max_row=tr_last)
            line.add_data(data, titles_from_data=True)
            line.set_categories(cats)
            line.legend = None
            s = line.series[0]
            s.graphicalProperties.line.solidFill = BAR_CLR
            s.graphicalProperties.line.width = 22000
            s.smooth = False
            ws.add_chart(line, f"A{tr_last + 3}")

    # -------------------------------------------------------------- People
    ws = wb.create_sheet("People")
    ws.sheet_view.showGridLines = False
    widths = (24, 15, 12, 10, 16, 12, 11, 11, 11, 10, 12, 13, 11, 26,
              12, 12, 18)
    for i, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = width

    row = _title_band(ws, 1, f"People - {scope_title}", period_text,
                      len(widths))
    pp_header_row = row
    row = _header_row(ws, row, [
        "Name", "Username", "Group", "Team", "Sub-group", "Capacity (h)",
        "Logged (h)", "Billable (h)", "Weekend (h)", "Leave (h)",
        "Compliance", "Utilization %", "Billable %", "Workload context",
        "Incidents (1y)", "Service req. (1y)", "Status"])

    pp_first = row
    people = sorted(rows, key=lambda r: -(r[1]['percent'] or 0))
    stripe = False
    for person, s in people:
        c = ctx.get(person.id, {'support_apps': 0, 'projects': 0, 'tasks': 0,
                                'incidents_1y': 0, 'srs_1y': 0})
        _data_cell(ws, row, 1, _person_name(person), stripe=stripe,
                   bold=True)
        _data_cell(ws, row, 2, person.username, stripe=stripe)
        _data_cell(ws, row, 3,
                   group_labels.get(person.user_group, unassigned_label)
                   if person.user_group else unassigned_label, stripe=stripe)
        _data_cell(ws, row, 4, person.team or unassigned_label,
                   stripe=stripe)
        _data_cell(ws, row, 5, person.sub_group or unassigned_label,
                   stripe=stripe)
        for col, val, fmt in ((6, s['capacity_hours'], HRS_FMT),
                              (7, s['worked_hours'], HRS_FMT),
                              (8, s['billable_hours'], HRS_FMT),
                              (9, s['weekend_hours'], HRS_FMT),
                              (10, s['leave_hours'], HRS_FMT),
                              (11, s['compliance'], PCT0_FMT),
                              (12, s['percent'], PCT_FMT),
                              (13, s['billable_percent'], PCT_FMT)):
            _num_cell(ws, row, col, val, num_format=fmt, stripe=stripe)
        _data_cell(ws, row, 14, _workload_context(person, c), stripe=stripe)
        _num_cell(ws, row, 15, c['incidents_1y'], num_format='0',
                  stripe=stripe)
        _num_cell(ws, row, 16, c['srs_1y'], num_format='0', stripe=stripe)
        _status_cell(ws, row, 17, s, band_labels)
        row += 1
        stripe = not stripe
    pp_last = row - 1

    ws.freeze_panes = f"A{pp_first}"
    _auto_filter(ws, pp_header_row, pp_last, len(widths))
    _data_bar(ws, 12, pp_first, pp_last)
    _page_setup(ws, len(widths), header_row=pp_header_row)

    # ---------------------------------------------------- T&M Allocations
    if allocation_rows:
        _write_allocations_sheet(
            wb, sheet_title="T&M Allocations",
            band_title=f"T&M Allocations - {scope_title}",
            subtitle=period_text,
            allocation_rows=allocation_rows,
            allocation_band_labels=allocation_band_labels or {},
            day_hours=wf['day_hours'])

    wb.save(stream)
    return wb


# ---------------------------------------------------------------------------
# One person's ServiceNow ticket list (People Explorer -> individual)
# ---------------------------------------------------------------------------

# Priority fills for the ticket sheets - a severity ramp, so P1 rows are
# findable by eye. Mirrors PRIORITY_COLORS on the web page.
PRIORITY_FILL = {
    'P1':      ("FEE2E2", "991B1B"),
    'P2':      ("FFEDD5", "9A3412"),
    'P3':      ("DBEAFE", "1E40AF"),
    'P4':      ("CCFBF1", "115E59"),
    'Not set': ("F1F5F9", "64748B"),
}

TICKET_TYPE_LABELS = {
    'incident': 'Incident',
    'service_request': 'Service request',
    'other': 'Other',
}

# One blank-cell convention across every ticket sheet: the export did not
# say, so the workbook does not either.
NOT_STATED = "Not stated"


def _ticket_value(value):
    """A stated value, or the explicit 'not stated' marker."""
    text = (value or '').strip() if isinstance(value, str) else value
    return text if text else NOT_STATED


def _days_between(start, end):
    """Whole days between two datetimes, or None when either is missing."""
    if not start or not end:
        return None
    return round((end - start).total_seconds() / 86400.0, 1)


def _write_ticket_sheet(wb, *, sheet_title, band_title, subtitle, tickets,
                        first_sheet=False):
    """
    One sheet listing tickets of a single type, newest first.

    Always written even when empty: a person who worked no service requests
    should see an explicit "none captured" sheet rather than a workbook
    whose shape changes from month to month.
    """
    ws = wb.active if first_sheet else wb.create_sheet()
    ws.title = sheet_title
    ws.sheet_view.showGridLines = False

    headers = ["Ticket", "Opened", "Priority", "State", "Short description",
               "Category", "Subcategory", "Assignment group", "Resolved",
               "Days to resolve"]
    widths = (16, 18, 12, 14, 58, 22, 22, 26, 18, 14)
    for col, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(col)].width = width

    row = _title_band(ws, 1, band_title, subtitle, len(headers))
    header_row = row
    row = _header_row(ws, row, headers)
    first_data = row

    if not tickets:
        ws.merge_cells(start_row=row, start_column=1, end_row=row,
                       end_column=len(headers))
        _data_cell(ws, row, 1,
                   "No tickets of this type were captured for this person "
                   "in the workload window.", color=MUTED)
        _page_setup(ws, len(headers), header_row=header_row)
        return ws

    stripe = False
    for ticket in tickets:
        _data_cell(ws, row, 1, ticket.get('number'), stripe=stripe,
                   bold=True)
        _data_cell(ws, row, 2, ticket.get('opened_at'), stripe=stripe,
                   align=CENTER, num_format=DATETIME_FMT)
        priority = ticket.get('priority') or 'Not set'
        bg, fg = PRIORITY_FILL.get(priority, PRIORITY_FILL['Not set'])
        _data_cell(ws, row, 3, priority, align=CENTER, bold=True,
                   color=fg, fill=bg)
        _data_cell(ws, row, 4, _ticket_value(ticket.get('state')),
                   stripe=stripe, align=CENTER)
        _data_cell(ws, row, 5, _ticket_value(ticket.get('title')),
                   stripe=stripe)
        _data_cell(ws, row, 6, _ticket_value(ticket.get('category')),
                   stripe=stripe)
        _data_cell(ws, row, 7, _ticket_value(ticket.get('subcategory')),
                   stripe=stripe)
        _data_cell(ws, row, 8, _ticket_value(ticket.get('assignment_group')),
                   stripe=stripe)
        _data_cell(ws, row, 9, ticket.get('resolved_at'), stripe=stripe,
                   align=CENTER, num_format=DATETIME_FMT)
        _num_cell(ws, row, 10,
                  _days_between(ticket.get('opened_at'),
                                ticket.get('resolved_at')),
                  num_format=HRS_FMT, stripe=stripe)
        row += 1
        stripe = not stripe

    ws.freeze_panes = f"A{first_data}"
    _auto_filter(ws, header_row, row - 1, len(headers))
    _page_setup(ws, len(headers), header_row=header_row)
    return ws


def _write_themes_sheet(wb, *, person_name, themes_analysis):
    """The ML theme grouping, one row per theme, largest first."""
    ws = wb.create_sheet()
    ws.title = "Themes"
    ws.sheet_view.showGridLines = False

    headers = ["Theme", "Tickets", "Share", "Incidents", "Service requests",
               "Priority mix", "Main category", "First seen", "Last seen",
               "Example tickets"]
    widths = (34, 10, 10, 12, 17, 24, 24, 14, 14, 52)
    for col, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(col)].width = width

    row = _title_band(
        ws, 1, f"Ticket themes - {person_name}",
        "Groups of tickets of a similar nature", len(headers))

    row = _section(ws, row, "How these groups were formed", len(headers))
    ws.merge_cells(start_row=row, start_column=1, end_row=row,
                   end_column=len(headers))
    method_cell = _data_cell(ws, row, 1, themes_analysis['method_label'],
                             color=MUTED)
    method_cell.alignment = Alignment(horizontal="left", vertical="top",
                                      wrap_text=True)
    ws.row_dimensions[row].height = 42
    row += 2

    header_row = row
    row = _header_row(ws, row, headers)
    first_data = row

    themes = themes_analysis.get('themes') or []
    if not themes:
        ws.merge_cells(start_row=row, start_column=1, end_row=row,
                       end_column=len(headers))
        _data_cell(ws, row, 1,
                   "No themes could be formed from the captured tickets.",
                   color=MUTED)
        _page_setup(ws, len(headers), header_row=header_row)
        return ws

    stripe = False
    for theme in themes:
        _data_cell(ws, row, 1, theme['label'], stripe=stripe, bold=True)
        _num_cell(ws, row, 2, theme['size'], num_format='0', stripe=stripe)
        _num_cell(ws, row, 3, theme['share'], num_format=PCT_FMT,
                  stripe=stripe)
        _num_cell(ws, row, 4, theme['incidents'], num_format='0',
                  stripe=stripe)
        _num_cell(ws, row, 5, theme['service_requests'], num_format='0',
                  stripe=stripe)
        _data_cell(ws, row, 6, theme['priority_summary'], stripe=stripe,
                   align=CENTER)
        _data_cell(ws, row, 7, theme['top_category'], stripe=stripe)
        _data_cell(ws, row, 8, theme['first_seen'], stripe=stripe,
                   align=CENTER, num_format=DATE_FMT)
        _data_cell(ws, row, 9, theme['last_seen'], stripe=stripe,
                   align=CENTER, num_format=DATE_FMT)
        _data_cell(ws, row, 10,
                   '; '.join(f"{s['number']} {s['title']}".strip()
                             for s in theme['samples']),
                   stripe=stripe)
        row += 1
        stripe = not stripe

    if themes_analysis.get('unthemed'):
        _data_cell(ws, row, 1, "Not in a named theme", bold=True,
                   fill=TOTAL_FILL)
        _num_cell(ws, row, 2, themes_analysis['unthemed'], num_format='0',
                  fill=TOTAL_FILL)
        for col in range(3, len(headers) + 1):
            _data_cell(ws, row, col,
                       ("Too few tickets of their kind, or no short "
                        "description to group on") if col == 3 else None,
                       fill=TOTAL_FILL)
        row += 1

    ws.freeze_panes = f"A{first_data}"
    _auto_filter(ws, header_row, row - 1, len(headers))
    _page_setup(ws, len(headers), header_row=header_row)
    return ws


def build_user_tickets_report(stream, *, person_name, person_meta, tickets,
                              priority_rows, themes_analysis,
                              window_days, generated_by='', snow_as_of=None):
    """
    Write one person's ServiceNow ticket workbook onto `stream`.

    person_name     - display name for the title band.
    person_meta     - [(label, value)] profile facts (role, group, team).
    tickets         - ticket dicts, newest first (see routes._workload_tickets).
    priority_rows   - priority_breakdown() output; the same numbers the
                      page's priority chart plots.
    themes_analysis - analyse_themes() output; the same groups the page's
                      themes tab lists.
    window_days     - the capture window the counts cover.
    snow_as_of      - datetime of the latest Batch Analysis capture.

    Sheets: Summary, Incidents, Service Requests, Themes. Both ticket
    sheets are always present so the workbook keeps one shape.
    """
    incidents = [t for t in tickets if t.get('type') != 'service_request']
    service_requests = [t for t in tickets
                        if t.get('type') == 'service_request']
    generated = datetime.now().strftime('%d %b %Y %H:%M')
    window_text = f"ServiceNow tickets worked in the last {window_days} days"

    wb = Workbook()

    # ------------------------------------------------------------- Summary
    ws = wb.active
    ws.title = "Summary"
    ws.sheet_view.showGridLines = False
    for col, width in zip('ABCDE', (38, 18, 16, 16, 16)):
        ws.column_dimensions[col].width = width

    row = _title_band(
        ws, 1, f"ServiceNow Workload - {person_name}",
        f"{window_text}   |   generated {generated}"
        + (f"   |   by {generated_by}" if generated_by else ""), 5)

    if person_meta:
        row = _section(ws, row, "Person", 5)
        for i, (label, value) in enumerate(person_meta):
            _data_cell(ws, row + i, 1, label, stripe=i % 2 == 0, bold=True)
            _data_cell(ws, row + i, 2, value or NOT_STATED,
                       stripe=i % 2 == 0)
        row += len(person_meta) + 1

    row = _section(ws, row, "Ticket volume", 5)
    figures = [
        ("Incidents worked", len(incidents)),
        ("Service requests worked", len(service_requests)),
        ("Total tickets", len(tickets)),
        ("Resolved (resolution date recorded)",
         sum(1 for t in tickets if t.get('resolved_at'))),
    ]
    for i, (label, value) in enumerate(figures):
        _data_cell(ws, row + i, 1, label, stripe=i % 2 == 0, bold=True)
        _num_cell(ws, row + i, 2, value, num_format='0', stripe=i % 2 == 0)
    row += len(figures) + 1

    row = _section(ws, row, "By priority", 5)
    header_row = row
    row = _header_row(ws, row, ["Priority", "Incidents", "Service requests",
                                "Total", "Share"])
    total_tickets = len(tickets)
    stripe = False
    for entry in priority_rows:
        bg, fg = PRIORITY_FILL.get(entry['key'], PRIORITY_FILL['Not set'])
        _data_cell(ws, row, 1, entry['label'], bold=True, color=fg, fill=bg)
        _num_cell(ws, row, 2, entry['incidents'], num_format='0',
                  stripe=stripe)
        _num_cell(ws, row, 3, entry['service_requests'], num_format='0',
                  stripe=stripe)
        _num_cell(ws, row, 4, entry['total'], num_format='0', stripe=stripe,
                  bold=True)
        _num_cell(ws, row, 5,
                  round(entry['total'] * 100.0 / total_tickets, 1)
                  if total_tickets else None,
                  num_format=PCT_FMT, stripe=stripe)
        row += 1
        stripe = not stripe
    _auto_filter(ws, header_row, row - 1, 5)
    row += 1

    row = _section(ws, row, "How to read this workbook", 5)
    notes = [
        "The ticket list is captured from the ServiceNow Batch Analysis "
        "uploads and matched to this person by the assignee display name "
        "exactly as ServiceNow exported it.",
        f"The window is the last {window_days} days by ticket opened date; "
        "a ticket the export gave no opened date still counts, because it "
        "was captured and therefore exists.",
        f"'{NOT_STATED}' means the export left that field blank. It is "
        "never replaced with a most-common value - an attribute this "
        "workbook shows is one ServiceNow actually recorded.",
        "Ticket counts are workload CONTEXT. They are never part of the "
        "utilization percentage, which is timesheet-based.",
        "Every new Batch Analysis upload replaces the captured tickets of "
        "its type, so this workbook reflects the most recent export - "
        "export the full window you want counted.",
    ]
    for note in notes:
        ws.merge_cells(start_row=row, start_column=1, end_row=row,
                       end_column=5)
        c = _data_cell(ws, row, 1, f"- {note}", color=MUTED)
        c.alignment = Alignment(horizontal="left", vertical="top",
                                wrap_text=True)
        ws.row_dimensions[row].height = 30
        row += 1

    if snow_as_of:
        row += 1
        _data_cell(ws, row, 1, "Ticket data captured", bold=True)
        _data_cell(ws, row, 2, snow_as_of, align=CENTER,
                   num_format=DATETIME_FMT)

    _page_setup(ws, 5)

    _write_ticket_sheet(
        wb, sheet_title="Incidents",
        band_title=f"Incidents - {person_name}",
        subtitle=f"{len(incidents)} incident(s)   |   {window_text}",
        tickets=incidents)
    _write_ticket_sheet(
        wb, sheet_title="Service Requests",
        band_title=f"Service requests - {person_name}",
        subtitle=f"{len(service_requests)} service request(s)   |   "
                 f"{window_text}",
        tickets=service_requests)
    _write_themes_sheet(wb, person_name=person_name,
                        themes_analysis=themes_analysis)

    wb.save(stream)
    return wb
