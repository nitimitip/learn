"""
Centralised configuration for the Software Inventory blueprint.

Everything that governs WHERE a package lands on disk, HOW MANY revisions of
it are kept, and HOW BIG an upload may be lives here, so the module stays the
single source of truth for its own limits (the same contract utility,
service_now_analysis and code_sentinel follow - see the upload-size policy note
in main_app.py).

Upload size
-----------
The requirement is "no size limit" - these are application installers and a
single .exe/.iso can run to several GB. Two things have to agree before that
actually works:

  1. MAX_CONTENT_LENGTH below (the Flask/Werkzeug body cap for this blueprint).
     It MUST be a concrete integer, never None: Flask 3.1's
     request.max_content_length getter falls back to the app-wide
     MAX_CONTENT_LENGTH config whenever the per-request value is None, so
     setting None here would silently reinstate the 16 MB global floor instead
     of lifting it. The default below is therefore a deliberately absurd
     ceiling rather than "unlimited".

  2. IIS request filtering in web.config:
        <requestLimits maxAllowedContentLength="..." />
     IIS rejects the request before Flask ever sees it, and its ceiling is a
     uint32 - 4294967295 bytes (4 GB) is the hardest limit IIS can express.
     A package larger than that cannot be uploaded through IIS at all and has
     to be placed on the share by other means.

Disk headroom
-------------
Werkzeug spools a multipart body larger than 500 KB into a temporary file
(the system TEMP drive) and the view then copies it into UPLOAD_ROOT. A 4 GB
upload therefore needs ~4 GB free on TEMP *and* ~4 GB free on the uploads
volume at the same moment. Point TEMP at a roomy drive on the web server if
they are not the same disk.
"""

import os

# Project root: appassist/modules/software_inventory/config.py -> up three.
_PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
)

# Where the binaries live. Under secure_uploads/ on purpose: that segment is
# listed in web.config's <hiddenSegments>, so IIS refuses to serve anything
# from it directly. Every download goes through the download route, which
# checks the session first.
UPLOAD_ROOT = os.environ.get(
    'SOFTWARE_INVENTORY_UPLOAD_DIR',
    os.path.join(_PROJECT_ROOT, 'secure_uploads', 'software_inventory'),
)

# Revisions kept per software name, INCLUDING the current one. A fifth upload
# prunes the oldest (row + file). Mirrors file_versions.MAX_VERSIONS, which is
# the app-wide convention for "how much history an uploaded artifact keeps".
MAX_VERSIONS = int(os.environ.get('SOFTWARE_INVENTORY_MAX_VERSIONS', '4'))

# Per-request body cap for this blueprint only - see the module docstring for
# why this is a number and not None. 64 GB: far beyond any real installer, so
# it behaves as "no limit" while still bounding a runaway request.
MAX_CONTENT_LENGTH = int(
    os.environ.get('SOFTWARE_INVENTORY_MAX_UPLOAD_MB', str(64 * 1024))
) * 1024 * 1024

# Copy buffer for the stream-to-disk save. 4 MB keeps the syscall count sane on
# a multi-GB file without holding a meaningful amount of memory per worker.
COPY_CHUNK_BYTES = int(os.environ.get('SOFTWARE_INVENTORY_CHUNK_BYTES',
                                      str(4 * 1024 * 1024)))


def ensure_upload_root():
    """Make sure the uploads directory exists. Safe to call repeatedly."""
    os.makedirs(UPLOAD_ROOT, exist_ok=True)
    return UPLOAD_ROOT
