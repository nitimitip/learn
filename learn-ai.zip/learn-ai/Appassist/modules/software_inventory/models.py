"""
models.py - Software Inventory.

Two tables, in a parent/child shape that falls straight out of the
requirement "if a new file is uploaded under the same name, keep up to 4
versions":

  software_items     one row per PRODUCT (the name the user searches for)
  software_versions  one row per uploaded FILE, newest first, max 4 kept

and two alongside them:

  software_group_members  who may publish. See SoftwareGroupMember below.
  software_item_towers    which towers a RESTRICTED product is published to.
                          See SoftwareItemTower below.

Who may download
----------------
A product is either GENERAL - every signed-in user may download it, which is
how the shelf started and still the default - or RESTRICTED to one or more
application-support towers, in which case only the members of those towers
(plus the people who may publish) may download it.

The audience belongs to the PRODUCT, not to a release. Restricting rev 4 while
rev 3 stayed open would hand out the same installer one click lower down, so
there is nothing a per-version audience could actually enforce.

Why the name is the grouping key
--------------------------------
The upload form has no "which product is this?" picker - the admin types a
name, and an existing name means "this is a new release of that product".
``name_key`` is the case-folded, whitespace-collapsed form of ``name`` and
carries the UNIQUE constraint, so "Acrobat Reader", "acrobat reader" and
"Acrobat  Reader" all land on the same product instead of quietly creating
three near-duplicate rows that a wildcard search would then return together.
``name`` keeps the admin's original casing for display.

Retention
---------
``revision`` is a 1-based counter that only ever goes up, per product. It is
NOT the user-facing version: that is ``version_label``, free text the admin
types ("2.6.0", "R2024b", "SP3"), because vendor version strings do not sort
or increment in any way a database could infer. Pruning keys off ``revision``
so the trail is well-defined even when two uploads carry the same label.

size_bytes is BigInteger, not Integer: a 3 GB installer overflows a 32-bit
INT on SQL Server (2,147,483,647 bytes = 2 GB), which is squarely inside the
range this module exists to handle.
"""

from sqlalchemy import (
    BigInteger, Column, DateTime, ForeignKey, Index, Integer, String, Text,
    UniqueConstraint,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from database import Base


def name_key(name):
    """The matching form of a product name: case-folded, whitespace-collapsed.

    Used for BOTH the uniqueness check and the "same name = new version"
    lookup, so the two can never disagree about what counts as the same
    product.
    """
    return ' '.join((name or '').split()).lower()


# ---------------------------------------------------------------------------
# Audience
#
# Stored as a word rather than a boolean so the column says what it means in a
# row dump, and so a third audience can be added later without a migration
# that has to reinterpret every existing True/False.
# ---------------------------------------------------------------------------

VISIBILITY_GENERAL = 'general'
VISIBILITY_RESTRICTED = 'restricted'
VISIBILITIES = (VISIBILITY_GENERAL, VISIBILITY_RESTRICTED)


class SoftwareGroupMember(Base):
    """Who is allowed to publish to the shelf.

    The module started admin-only, which meant the people who actually own a
    piece of software could not put it on the shelf without going through an
    administrator. Membership is the middle rung: a member publishes, edits and
    deletes software exactly as an admin does.

    Managing the LIST stays with administrators - a group that can add itself
    to is not a permission, so `add` and `remove` are admin-gated in routes.py
    even though everything the group unlocks is not.

    `user_id` is UNIQUE: membership is a fact about a person, not something
    that can be held twice. Deliberately the same shape as
    security_group_members, so the two modules behave identically and a reader
    who knows one knows the other.
    """
    __tablename__ = 'software_group_members'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False,
                     unique=True)
    added_by = Column(Integer, ForeignKey('users.id'))
    added_at = Column(DateTime, default=func.now())

    user = relationship('User', foreign_keys=[user_id])

    def __repr__(self):
        return '<SoftwareGroupMember user_id=%s>' % self.user_id


class SoftwareItem(Base):
    """One product in the inventory. Owns its version trail."""
    __tablename__ = 'software_items'

    id = Column(Integer, primary_key=True)

    name = Column(String(200), nullable=False)          # as typed, for display
    name_key = Column(String(200), nullable=False)      # matching form, unique
    description = Column(Text)

    # 'general' (everyone signed in) or 'restricted' (named towers only).
    # NOT derived from "does this product have tower rows?": a tower row that
    # goes missing would then silently republish the package to the whole
    # organisation. The flag is the statement of intent and the rows are the
    # grant, so losing the rows fails CLOSED - nobody but a publisher can
    # download it - which is the only safe direction for that mistake.
    visibility = Column(String(16), nullable=False,
                        default=VISIBILITY_GENERAL,
                        server_default=VISIBILITY_GENERAL)

    created_by = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=func.now())
    # Stamped on every new upload, so "sort by date" means "most recently
    # released", which is what someone hunting for a download actually wants.
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    versions = relationship(
        'SoftwareVersion',
        back_populates='software',
        order_by='SoftwareVersion.revision.desc()',
        cascade='all, delete-orphan',
    )

    # delete-orphan: removing a product takes its grants with it. A grant to a
    # product that no longer exists is not a record of anything.
    towers = relationship(
        'SoftwareItemTower',
        back_populates='software',
        cascade='all, delete-orphan',
    )

    __table_args__ = (
        UniqueConstraint('name_key', name='uq_software_items_name_key'),
        Index('ix_software_items_name_key', 'name_key'),
    )

    @property
    def is_restricted(self):
        """True when only named towers may download this product."""
        return self.visibility == VISIBILITY_RESTRICTED

    def __repr__(self):
        return '<SoftwareItem %s>' % self.name


class SoftwareItemTower(Base):
    """One tower a restricted product is published to.

    The tower is the audience unit because it is the one the organisation
    already maintains: application support owns ``app_support_towers`` and its
    ``tower_members``, people are added and removed there as they join and
    leave a team, and this module gets that for free instead of growing a
    second, immediately-stale list of names.

    Rows are meaningless while ``SoftwareItem.visibility`` is 'general' - the
    publish form clears them when a product is set back to general, so a
    product that is later restricted again starts from no grant rather than
    from whatever it happened to be restricted to months ago.

    A tower is retired (``is_active = False``), never deleted, so the FK here
    does not dangle. A grant to a retired tower keeps working: its members
    keep the access they had, and the tower simply stops appearing in the
    picker for new grants.
    """
    __tablename__ = 'software_item_towers'

    id = Column(Integer, primary_key=True)
    software_id = Column(Integer, ForeignKey('software_items.id'),
                         nullable=False)
    tower_id = Column(Integer, ForeignKey('app_support_towers.id'),
                      nullable=False, index=True)

    granted_by = Column(Integer, ForeignKey('users.id'))
    granted_at = Column(DateTime, default=func.now())

    software = relationship('SoftwareItem', back_populates='towers')

    __table_args__ = (
        # Leading column is software_id, so this doubles as the index for
        # "which towers is this product published to?" - the question every
        # catalogue render asks.
        UniqueConstraint('software_id', 'tower_id',
                         name='uq_software_item_tower'),
    )

    def __repr__(self):
        return '<SoftwareItemTower software=%s tower=%s>' % (
            self.software_id, self.tower_id)


class SoftwareVersion(Base):
    """One uploaded file for a product. At most MAX_VERSIONS survive."""
    __tablename__ = 'software_versions'

    id = Column(Integer, primary_key=True)
    software_id = Column(Integer, ForeignKey('software_items.id'),
                         nullable=False, index=True)

    revision = Column(Integer, nullable=False)          # 1-based, ascending
    version_label = Column(String(100))                 # vendor version, free text

    stored_filename = Column(String(255), nullable=False)   # name on disk
    original_filename = Column(String(255))                 # what was uploaded
    size_bytes = Column(BigInteger)                         # GB-scale: see docstring
    sha256 = Column(String(64))     # shown so a download can be verified

    uploaded_by = Column(Integer, ForeignKey('users.id'))
    uploaded_at = Column(DateTime, default=func.now())

    software = relationship('SoftwareItem', back_populates='versions')

    __table_args__ = (
        UniqueConstraint('software_id', 'revision',
                         name='uq_software_version_revision'),
        Index('ix_software_versions_item_rev', 'software_id', 'revision'),
    )

    @property
    def display_label(self):
        """What the download button says: the vendor version, else the revision."""
        return self.version_label or ('rev %d' % self.revision)

    @property
    def size_display(self):
        """Human-readable size. Installers are GB-scale, so bytes are useless."""
        size = self.size_bytes
        if size is None:
            return 'unknown'
        units = ('B', 'KB', 'MB', 'GB', 'TB')
        value = float(size)
        for unit in units:
            if value < 1024 or unit == units[-1]:
                return ('%d %s' % (value, unit) if unit == 'B'
                        else '%.1f %s' % (value, unit))
            value /= 1024
        return '%d B' % size

    def __repr__(self):
        return '<SoftwareVersion %s rev%s>' % (self.software_id, self.revision)
