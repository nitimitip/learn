from .routes import software_inventory_bp

__all__ = ['software_inventory_bp']
