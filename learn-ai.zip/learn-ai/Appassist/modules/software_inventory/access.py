"""
access.py - who may download a package.

The shelf started with one answer to that question: any signed-in user. It now
has two, because some packages are licensed to a team rather than to the whole
organisation, and handing those to everyone with a login is a licensing problem
dressed up as a convenience.

  GENERAL     every signed-in user may download it. The default, and what
              every package published before this existed still is.
  RESTRICTED  only members of the towers the publisher named may download it,
              plus the people who may publish.

Why towers
----------
Application Support already owns the list: ``app_support_towers`` and the
``tower_members`` rows underneath it are maintained as people join and leave a
team. Reusing it means a leaver loses their downloads the moment they come off
the tower, with nobody having to remember this module exists. A second list of
names kept here would be wrong within a month.

Why publishers keep access
--------------------------
Anyone who can publish can already replace, rename or delete any package on the
shelf - including its file. Blocking their download would protect nothing, and
would stop them checking what they had just published, so it is not attempted.
That is a deliberate decision and the About page states it.

Failing closed
--------------
Every "cannot answer" path here returns NO ACCESS, never access: a restricted
product whose grants have all gone, a user object with no id, a tower that no
longer resolves. Restricted software is restricted because somebody said so,
and the cost of a wrong "yes" is a licence breach while the cost of a wrong
"no" is somebody asking to be added to a tower.

This module deliberately holds the blueprint's only import of the
application_support models, so there is one place to look when the tower schema
moves.
"""

import logging

from modules.application_support.models import AppSupportTower, TowerMember

from .models import (SoftwareItemTower, VISIBILITIES, VISIBILITY_GENERAL,
                     VISIBILITY_RESTRICTED)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Reading the tower side
# ---------------------------------------------------------------------------

def active_towers(db_session):
    """Towers offerable in the publish form: [{'id', 'name'}], name-ordered.

    Active ones only. A retired tower must not be grantable - retiring it is
    how an administrator says the team no longer exists - but an existing
    grant to one keeps working, which is why ``tower_names`` below looks up
    ALL towers rather than only these.
    """
    rows = (db_session.query(AppSupportTower.id, AppSupportTower.tower_name)
            .filter(AppSupportTower.is_active == True)      # noqa: E712
            .order_by(AppSupportTower.tower_name)
            .all())
    return [{'id': r[0], 'name': r[1] or ('Tower %d' % r[0])} for r in rows]


def tower_names(db_session, tower_ids):
    """{tower_id: {'name', 'is_active'}} for the ids given, active or not.

    Retired towers are included on purpose: a package granted to one still has
    to be able to say who its audience is, and "Tower 7" is not an answer a
    person can act on.
    """
    ids = [int(t) for t in set(tower_ids or ()) if t is not None]
    if not ids:
        return {}
    rows = (db_session.query(AppSupportTower.id, AppSupportTower.tower_name,
                             AppSupportTower.is_active)
            .filter(AppSupportTower.id.in_(ids))
            .all())
    return {r[0]: {'name': r[1] or ('Tower %d' % r[0]),
                   'is_active': bool(r[2])} for r in rows}


def user_tower_ids(db_session, user):
    """The set of tower ids this person belongs to. Empty for anonymous.

    One query per request, reused for every package on the page - the
    alternative is a membership lookup per restricted row, which on a shelf of
    any size is the whole render.
    """
    if not user or not getattr(user, 'id', None):
        return set()
    rows = (db_session.query(TowerMember.tower_id)
            .filter(TowerMember.user_id == user.id)
            .all())
    return {r[0] for r in rows}


# ---------------------------------------------------------------------------
# Reading the software side
# ---------------------------------------------------------------------------

def item_tower_ids(db_session, item_ids):
    """{software_id: [tower_id, ...]} for the products given.

    One query for the whole page rather than one per package, for the same
    reason as above.
    """
    ids = [int(i) for i in (item_ids or ()) if i is not None]
    if not ids:
        return {}
    rows = (db_session.query(SoftwareItemTower.software_id,
                             SoftwareItemTower.tower_id)
            .filter(SoftwareItemTower.software_id.in_(ids))
            .all())
    grants = {}
    for software_id, tower_id in rows:
        grants.setdefault(software_id, []).append(tower_id)
    return grants


# ---------------------------------------------------------------------------
# The decision
# ---------------------------------------------------------------------------

def allows_download(visibility, granted_tower_ids, member_tower_ids,
                    is_publisher=False):
    """May this person download a product with this audience?

    A pure function of four plain values, so the rule reads in one place and
    so the catalogue - which decides for a page of packages at once - and the
    download route - which decides for one - cannot drift apart. Both call
    this.

    An unrecognised visibility reads as GENERAL rather than as restricted: the
    publish form is whitelisted, so the only way to get one into the column is
    by editing the database by hand, and a typo there must not silently lock a
    shelf nobody has been told is locked.
    """
    if visibility != VISIBILITY_RESTRICTED:
        return True
    if is_publisher:
        return True
    if not granted_tower_ids:
        # Restricted, but no tower holds the grant. Nobody outside the
        # publishing group gets it until somebody says who should.
        return False
    return bool(set(granted_tower_ids) & set(member_tower_ids or ()))


def join_names(names):
    """"the A tower", "the A and B towers" - a list a person reads, not a CSV."""
    names = [n for n in (names or ()) if n]
    if not names:
        return ''
    if len(names) == 1:
        return '%s tower' % names[0]
    return '%s and %s towers' % (', '.join(names[:-1]), names[-1])


def audience_sentence(name, tower_display_names):
    """The line a person without access is shown, in both places they meet it.

    One function, so the catalogue's locked button and the download route's
    refusal say exactly the same thing. Being told two different stories about
    the same package is how somebody concludes the shelf is broken rather than
    that they are simply not on the list.
    """
    if not tower_display_names:
        return ('%s is restricted software, and no tower currently holds '
                'access to it. Ask the software team to publish it to a '
                'tower.' % name)
    return ('%s is restricted software. Only members of the %s can download '
            'it - ask a tower lead to add you, or ask the software team.'
            % (name, join_names(tower_display_names)))


# ---------------------------------------------------------------------------
# Writing the audience
# ---------------------------------------------------------------------------

def read_form_audience(form):
    """(visibility, tower_ids, error) from the publish / edit form.

    ``tower_ids`` comes back de-duplicated, in the order the browser sent it,
    and NOT yet trusted - ``apply_audience`` checks the ids against the tower
    table, because a hand-posted form can name a tower that does not exist and
    a grant to one would be a row nothing could ever satisfy.
    """
    visibility = (form.get('visibility') or VISIBILITY_GENERAL).strip().lower()
    if visibility not in VISIBILITIES:
        visibility = VISIBILITY_GENERAL

    if visibility != VISIBILITY_RESTRICTED:
        return VISIBILITY_GENERAL, [], None

    ids, seen = [], set()
    for raw in form.getlist('tower_ids'):
        raw = (raw or '').strip()
        if raw.isdigit():
            value = int(raw)
            if value not in seen:
                seen.add(value)
                ids.append(value)
    if not ids:
        return (visibility, [],
                'Choose at least one tower, or publish it as general software '
                'available to everyone.')
    return visibility, ids, None


def apply_audience(db_session, item, visibility, tower_ids, user_id):
    """Set a product's audience. Returns (tower_ids_applied, error).

    Does NOT commit - the caller owns the transaction, because on the publish
    path this runs alongside a file that has already landed on disk and the
    two have to succeed or fail together.

    Setting a product back to general CLEARS its grants rather than leaving
    them dormant. A dormant grant is a trap: the next person to restrict the
    package would be handing it to whoever happened to be on the list months
    ago, without ever being shown that list.
    """
    if visibility != VISIBILITY_RESTRICTED:
        clear_grants(db_session, item.id)
        item.visibility = VISIBILITY_GENERAL
        return [], None

    known = set()
    if tower_ids:
        known = {row[0] for row in
                 db_session.query(AppSupportTower.id)
                 .filter(AppSupportTower.id.in_([int(t) for t in tower_ids]))
                 .all()}
    wanted = [t for t in tower_ids if t in known]
    if not wanted:
        return [], ('None of the towers selected could be found. Refresh the '
                    'page and choose again.')

    existing = {row.tower_id: row for row in
                db_session.query(SoftwareItemTower)
                .filter(SoftwareItemTower.software_id == item.id).all()}

    # Diff rather than delete-all-and-re-add: keeping the untouched rows keeps
    # their granted_by / granted_at, which is the record of who opened this
    # package to a tower and when.
    for tower_id, row in existing.items():
        if tower_id not in wanted:
            db_session.delete(row)
    for tower_id in wanted:
        if tower_id not in existing:
            db_session.add(SoftwareItemTower(software_id=item.id,
                                             tower_id=tower_id,
                                             granted_by=user_id))

    item.visibility = VISIBILITY_RESTRICTED
    return wanted, None


def clear_grants(db_session, software_id):
    """Drop every grant on a product. Used when it goes back to general."""
    (db_session.query(SoftwareItemTower)
     .filter(SoftwareItemTower.software_id == software_id)
     .delete(synchronize_session=False))
