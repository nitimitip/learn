"""
routes.py - Software Inventory module.

A shared shelf of installable software: the admin team publishes the packages,
and every signed-in user can find and download them.

Access model
------------
Three levels:

  * MANAGE MEMBERS (add/remove who may publish)  - ``role == 'admin'`` only.
  * PUBLISH (upload, edit, delete a version or a
    product)                                     - software-group MEMBERS,
                                                   and admins.
  * DOWNLOAD / SEARCH                            - any signed-in user for
                                                   GENERAL packages; members
                                                   of the named towers for
                                                   RESTRICTED ones.

"Software-group member" = the user's id is in ``software_group_members``, OR
the user is an admin. Admins are members implicitly and are never listed in
the table, so removing the last named member cannot lock the module.

Managing the list is deliberately NOT delegated: a group that can add itself
to is not a permission. This mirrors the Security module exactly.

There is no anonymous route in this blueprint, not even the listing. The
inventory names the software an organisation runs and hands out its installers;
that is exactly the sort of thing that must not be readable from an
unauthenticated session, so the login check comes first on every view.

Restricted packages
-------------------
A package is published either to everyone or to named application-support
towers - see access.py for the rule and for why the tower is the audience unit.
A restricted package still LISTS for everybody, showing who its audience is;
only the download is withheld. Hiding it outright would mean somebody who needs
the software cannot discover that it exists or who to ask for it, which turns a
five-minute request into a procurement ticket for a licence the organisation
already owns.

The catalogue renders a locked button rather than a download for a person
without access, and the download route enforces the same rule again - the
button is a courtesy, the route is the control, and a stale tab or a pasted URL
meets the route.

Retention
---------
Uploading under a name that already exists appends a revision to that product
and prunes anything past the newest ``config.MAX_VERSIONS`` (4). The prune
deletes the row and the file permanently - there is no recycle bin - so it runs
AFTER the commit, on the paths the pruner hands back (see service.py).

Upload size
-----------
This blueprint is registered in main_app's ``_UPLOAD_LIMITS_BY_BLUEPRINT`` with
``config.MAX_CONTENT_LENGTH``, which lifts the 16 MB global floor for these
routes only. The body is streamed to disk in chunks and never read into memory.
"""

import logging
import os
from datetime import datetime
from functools import wraps

from flask import (
    Blueprint, abort, flash, jsonify, redirect, render_template, request,
    send_file, url_for,
)

from auth import get_current_user
from database import get_db_session
from models import User

from . import access, config, service
from .models import (SoftwareGroupMember, SoftwareItem, SoftwareVersion,
                     VISIBILITY_RESTRICTED, name_key)

logger = logging.getLogger(__name__)

software_inventory_bp = Blueprint('software_inventory', __name__,
                                  template_folder='templates')

# Sort options offered in the UI. Kept as a whitelist rather than trusting the
# query string: the value reaches an ORDER BY, and "whatever the user typed"
# has no business doing that.
SORT_FIELDS = ('name', 'date')
SORT_DIRECTIONS = ('asc', 'desc')
DEFAULT_SORT = 'date'
DEFAULT_DIRECTION = 'desc'


# ---------------------------------------------------------------------------
# Auth gates
# ---------------------------------------------------------------------------

def login_required(view):
    """Every route in this module needs a signed-in user - no public view."""
    @wraps(view)
    def wrapper(*args, **kwargs):
        user = get_current_user()
        if not user:
            flash('Please sign in to access the software inventory.', 'error')
            return redirect(url_for('login'))
        return view(*args, user=user, **kwargs)
    return wrapper


def is_member(db_session, user):
    """True if the user may publish: an admin, or in the software group.

    Takes the caller's session rather than opening its own - every caller
    already has one, and a second session here would be a connection per
    request for a single-row lookup.
    """
    if not user:
        return False
    if user.role == 'admin':
        return True
    return (db_session.query(SoftwareGroupMember)
            .filter_by(user_id=user.id).first() is not None)


def member_required(view):
    """Publishing routes. Wraps login_required, so anonymous still gets login."""
    @wraps(view)
    @login_required
    def wrapper(*args, user=None, **kwargs):
        db_session = get_db_session()
        try:
            allowed = is_member(db_session, user)
        finally:
            db_session.close()
        if not allowed:
            flash('Publishing to the software inventory is limited to the '
                  'software team. Ask an administrator to add you.', 'error')
            return redirect(url_for('software_inventory.index'))
        return view(*args, user=user, **kwargs)
    return wrapper


def admin_required(view):
    """Managing the member list. Admins only - members cannot add members."""
    @wraps(view)
    @login_required
    def wrapper(*args, user=None, **kwargs):
        if not user or user.role != 'admin':
            flash('Administrator access is required to manage members.',
                  'error')
            return redirect(url_for('software_inventory.index'))
        return view(*args, user=user, **kwargs)
    return wrapper


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

def _like_pattern(term):
    """Turn a user's search box into a SQL LIKE pattern.

    Supports the wildcards people actually type - ``*`` for "any run of
    characters" and ``?`` for "one character" - and escapes the SQL wildcards
    ``%`` and ``_`` FIRST, so a product literally named "MS_Office" is
    searchable by that name instead of matching everything. Escaping before
    translating is what keeps the two vocabularies apart; doing it the other way
    round would escape the ``_`` that ``?`` had just produced.

    Two different behaviours, deliberately:

      * no wildcard  -> "contains" (``%term%``). Somebody typing three letters
        into a search box means "find anything with this in it".
      * any wildcard -> an anchored pattern, matching the name end to end, the
        way a filename wildcard does. That is the only reading under which
        ``sql*`` means "starts with sql" rather than being a slower spelling of
        the plain search. Both the search hint and the About page say so.
    """
    term = (term or '').strip()
    if not term:
        return None
    escaped = (term.replace('\\', '\\\\')
                   .replace('%', '\\%')
                   .replace('_', '\\_'))
    pattern = escaped.replace('*', '%').replace('?', '_')
    if '%' not in pattern and '_' not in pattern:
        pattern = '%' + pattern + '%'
    return pattern


def _sort_params():
    """(sort, direction) from the query string, whitelisted."""
    sort = (request.args.get('sort') or DEFAULT_SORT).lower()
    direction = (request.args.get('dir') or DEFAULT_DIRECTION).lower()
    if sort not in SORT_FIELDS:
        sort = DEFAULT_SORT
    if direction not in SORT_DIRECTIONS:
        direction = DEFAULT_DIRECTION
    return sort, direction


# ---------------------------------------------------------------------------
# Views
# ---------------------------------------------------------------------------

@software_inventory_bp.route('/')
@login_required
def index(user=None):
    """The catalogue: search, sort, and the last 4 downloads per product."""
    search = (request.args.get('q') or '').strip()
    sort, direction = _sort_params()

    db_session = get_db_session()
    try:
        query = db_session.query(SoftwareItem)

        pattern = _like_pattern(search)
        if pattern:
            # Matched against name_key (the case-folded form) so the search is
            # case-insensitive on every backend, rather than depending on the
            # collation SQLite or SQL Server happens to be using.
            query = query.filter(
                SoftwareItem.name_key.like(pattern.lower(), escape='\\'))

        if sort == 'name':
            column = SoftwareItem.name_key
        else:
            column = SoftwareItem.updated_at
        query = query.order_by(column.asc() if direction == 'asc'
                               else column.desc())

        items = query.all()

        can_publish = is_member(db_session, user)

        # Three lookups for the WHOLE page rather than per package: the
        # grants on the listed products, the names behind those tower ids,
        # and the viewer's own memberships. Deciding access row by row would
        # otherwise be three queries per restricted package.
        grants = access.item_tower_ids(db_session, [i.id for i in items])
        every_granted_id = {t for ids in grants.values() for t in ids}
        names = access.tower_names(db_session, every_granted_id)
        mine = access.user_tower_ids(db_session, user)

        # Materialise the rows the template needs while the session is open -
        # a lazy relationship would raise DetachedInstanceError after close().
        rows = []
        for item in items:
            versions = sorted(item.versions, key=lambda v: v.revision,
                              reverse=True)[:config.MAX_VERSIONS]

            granted = grants.get(item.id, [])
            restricted = (item.visibility == VISIBILITY_RESTRICTED)
            # Sorted by name so the audience chips read the same way on every
            # render - row order out of the grants table is not stable and a
            # list that reshuffles between refreshes looks like it changed.
            audience = sorted(
                ({'id': t,
                  'name': names.get(t, {}).get('name', 'Tower %d' % t),
                  'is_active': names.get(t, {}).get('is_active', True)}
                 for t in granted),
                key=lambda t: t['name'].lower())
            may_download = access.allows_download(
                item.visibility, granted, mine, is_publisher=can_publish)

            rows.append({
                'id': item.id,
                'name': item.name,
                # The matching form, so the publish form's name watcher can
                # recognise an existing package by the SAME rule the server
                # uses. Folding the name again in JavaScript would be a second
                # implementation of name_key() free to disagree with the first.
                'key': item.name_key,
                'description': item.description or '',
                'updated_at': item.updated_at,
                'restricted': restricted,
                'audience': audience,
                # A publisher who is NOT in one of the towers still gets the
                # download, but the card says so rather than pretending they
                # are on the list - "you can see this because you publish" is
                # a different fact from "you are in the Finance tower".
                'by_publisher': (restricted and can_publish
                                 and not (set(granted) & mine)),
                'can_download': may_download,
                'locked_reason': (None if may_download else
                                  access.audience_sentence(
                                      item.name,
                                      [t['name'] for t in audience])),
                'versions': [{
                    'id': v.id,
                    'revision': v.revision,
                    'label': v.display_label,
                    'version_label': v.version_label or '',
                    'filename': v.original_filename or v.stored_filename,
                    'size': v.size_display,
                    'sha256': v.sha256 or '',
                    'uploaded_at': v.uploaded_at,
                } for v in versions],
            })

        return render_template(
            'software_inventory/index.html',
            user=user,
            # Every package's current audience, keyed by name_key, for the
            # publish form's name watcher - see the template. Deliberately
            # NOT built from `rows`: those are whatever the search left, and a
            # publisher who searched for something else would then get a blank
            # audience pre-selected for a package that is in fact restricted,
            # which is the exact mistake the watcher exists to prevent.
            known_packages=(_audience_map(db_session) if can_publish else {}),
            # Two distinct questions, so two flags. `can_publish` drives every
            # publish / edit / delete control; `is_admin` drives only the link
            # to the member list, which members cannot manage.
            can_publish=can_publish,
            is_admin=(user.role == 'admin'),
            rows=rows,
            search=search,
            sort=sort,
            direction=direction,
            max_versions=config.MAX_VERSIONS,
            total_items=len(rows),
            # Only publishers are offered the audience control, so only they
            # need the tower list - and on a shelf browsed by everyone that
            # is one query saved on the common path.
            towers=(access.active_towers(db_session) if can_publish else []),
        )
    finally:
        db_session.close()


@software_inventory_bp.route('/upload', methods=['POST'])
@member_required
def upload(user=None):
    """Publish a package. An existing name appends a revision to that product.

    The file is streamed straight to its final path, so nothing proportional to
    the upload is ever held in memory. If anything fails after the bytes have
    landed, the partial file is unlinked before the redirect - otherwise a
    failed 3 GB upload would sit on the share for ever with no row pointing at
    it.

    The audience chosen here applies to the PRODUCT, so publishing a new
    release of something that already exists also restates who may download
    it - including the releases already on the shelf. That is deliberate: the
    alternative is releases of one package with different audiences, which
    nothing could enforce because the older one is one click away. The form
    pre-selects the package's current audience as soon as the name matches,
    and the confirmation message names the audience that was actually applied,
    so a re-publish cannot quietly widen access without saying so.
    """
    name = (request.form.get('name') or '').strip()
    description = (request.form.get('description') or '').strip()
    version_label = (request.form.get('version') or '').strip()
    upload_file = request.files.get('file')

    if not name:
        flash('Software name is required.', 'error')
        return _upload_response()
    if not upload_file or not upload_file.filename:
        flash('Please choose a file to upload.', 'error')
        return _upload_response()

    # Checked BEFORE the file is touched: a restricted publish with no tower
    # named is rejected while the only cost is re-picking the file, not after
    # several GB have been written to the share.
    visibility, tower_ids, audience_error = access.read_form_audience(
        request.form)
    if audience_error:
        flash(audience_error, 'error')
        return _upload_response()

    key = name_key(name)
    config.ensure_upload_root()

    db_session = get_db_session()
    dest_path = None
    committed = False
    stale_paths = []
    # Set only when THIS request created the product row. If the request then
    # fails, the rollback takes the row but not the folder the save had already
    # made, so the id is remembered in order to clear that folder up.
    new_item_id = None
    try:
        item = (db_session.query(SoftwareItem)
                .filter(SoftwareItem.name_key == key)
                .first())
        if item is None:
            item = SoftwareItem(name=name, name_key=key,
                                description=description or None,
                                created_by=user.id)
            db_session.add(item)
            # Needed now: the file lands in a folder named after the id.
            db_session.flush()
            new_item_id = item.id
        elif description:
            # A re-upload with a description refreshes the product blurb; an
            # empty box leaves the existing one alone rather than wiping it.
            item.description = description

        applied, audience_error = access.apply_audience(
            db_session, item, visibility, tower_ids, user.id)
        if audience_error:
            db_session.rollback()
            if new_item_id:
                service.remove_item_dir(new_item_id)
            flash(audience_error, 'error')
            return _upload_response()

        revision = service.next_revision(db_session, item.id)
        stored_name = service.build_stored_name(revision, upload_file.filename)
        dest_path = service.resolve_path(item.id, stored_name)
        if not dest_path:
            raise RuntimeError('Refusing to write outside the uploads folder')

        size, sha = service.save_stream(upload_file.stream, dest_path)
        if size == 0:
            db_session.rollback()
            service.remove_files([dest_path])
            if new_item_id:
                service.remove_item_dir(new_item_id)
            flash('That file is empty - nothing was published.', 'error')
            return _upload_response()

        db_session.add(SoftwareVersion(
            software_id=item.id,
            revision=revision,
            version_label=version_label[:100] or None,
            stored_filename=stored_name,
            original_filename=upload_file.filename[:255],
            size_bytes=size,
            sha256=sha,
            uploaded_by=user.id,
        ))
        # autoflush is off on these sessions, so the row the prune must KEEP
        # would otherwise be invisible to the query it runs.
        db_session.flush()

        # Touch the product so "sort by date" tracks the newest release rather
        # than the day the product was first added. onupdate only fires when
        # the row is actually dirty, hence the explicit stamp.
        item.updated_at = datetime.now()
        db_session.flush()

        stale_paths = service.prune_versions(db_session, item.id,
                                             protect=(stored_name,))
        db_session.commit()
        committed = True

        pruned = len(stale_paths)
        msg = 'Published %s%s. %s' % (
            name, (' ' + version_label) if version_label else '',
            _audience_note(db_session, visibility, applied))
        if pruned:
            msg += (' The oldest %d version%s removed to keep the latest %d.'
                    % (pruned, 's were' if pruned != 1 else ' was',
                       config.MAX_VERSIONS))
        flash(msg, 'success')
    except Exception:
        # Includes the unique-constraint trip when two administrators publish
        # the same new name at the same instant. One of them wins; the other is
        # told to try again, and re-publishing then lands as a version of the
        # row the winner created - which is the right outcome either way.
        db_session.rollback()
        logger.exception('Software upload failed for %r', name)
        flash('The upload could not be completed. Please try again.', 'error')
        if dest_path:
            service.remove_files([dest_path])
        if new_item_id:
            service.remove_item_dir(new_item_id)
    finally:
        db_session.close()
        # Unlink ONLY after a successful commit. Earlier - or at all on a failed
        # transaction - would destroy the installer while the rows that point at
        # it survive the rollback.
        if committed:
            service.remove_files(stale_paths)

    return _upload_response()


@software_inventory_bp.route('/<int:item_id>/version/<int:version_id>/download')
@login_required
def download(item_id, version_id, user=None):
    """Download one version.

    Any signed-in user for a GENERAL package; for a RESTRICTED one, a member
    of a tower it was published to, or somebody who may publish. This is the
    control - the catalogue's locked button is only a courtesy, and a stale
    tab, a bookmark or a pasted link arrives straight here.

    A refusal REDIRECTS with the reason rather than returning 403. The person
    has not done anything wrong and there is something useful they can do
    next, so they are told which towers hold the software and sent back to the
    shelf. A 403 page would state only that they are not allowed.
    """
    db_session = get_db_session()
    try:
        # Scoped to the product in the URL, so a version id belonging to
        # another one 404s instead of being served under the wrong name.
        version = (db_session.query(SoftwareVersion)
                   .filter(SoftwareVersion.id == version_id,
                           SoftwareVersion.software_id == item_id)
                   .first())
        if not version:
            abort(404)

        item = (db_session.query(SoftwareItem)
                .filter(SoftwareItem.id == item_id).first())
        if not item:
            abort(404)

        if item.visibility == VISIBILITY_RESTRICTED:
            granted = access.item_tower_ids(db_session, [item.id]).get(item.id,
                                                                      [])
            allowed = access.allows_download(
                item.visibility, granted,
                access.user_tower_ids(db_session, user),
                is_publisher=is_member(db_session, user))
            if not allowed:
                names = access.tower_names(db_session, granted)
                # Logged: a refused download of licensed software is exactly
                # the event somebody will later ask about, and the alternative
                # is having no record that the request was ever made.
                logger.info('Software download refused: item=%s user=%s '
                            'towers=%s', item_id, user.id, granted)
                flash(access.audience_sentence(
                    item.name,
                    sorted((v['name'] for v in names.values()),
                           key=lambda n: n.lower())), 'error')
                return redirect(url_for('software_inventory.index',
                                        **_carry_query_args()))

        path = service.resolve_path(item_id, version.stored_filename)
        if not path or not os.path.exists(path):
            flash('That version is no longer available on disk.', 'error')
            return redirect(url_for('software_inventory.index'))

        download_name = version.original_filename or version.stored_filename
        logger.info('Software download: item=%s rev=%s by user=%s',
                    item_id, version.revision, user.id)
        # conditional=True so a browser can resume a part-downloaded installer
        # with a Range request instead of restarting a multi-GB transfer.
        return send_file(path, as_attachment=True,
                         download_name=download_name, conditional=True)
    finally:
        db_session.close()


@software_inventory_bp.route('/<int:item_id>/version/<int:version_id>/delete',
                             methods=['POST'])
@member_required
def delete_version(item_id, version_id, user=None):
    """Remove one version. Admin only, and permanent."""
    db_session = get_db_session()
    committed = False
    stale_paths = []
    try:
        version = (db_session.query(SoftwareVersion)
                   .filter(SoftwareVersion.id == version_id,
                           SoftwareVersion.software_id == item_id)
                   .first())
        if not version:
            abort(404)

        path = service.resolve_path(item_id, version.stored_filename)
        if path:
            stale_paths.append(path)
        label = version.display_label
        db_session.delete(version)
        db_session.commit()
        committed = True
        flash('Version %s was deleted.' % label, 'success')
    except Exception:
        db_session.rollback()
        logger.exception('Failed to delete software version %s', version_id)
        flash('That version could not be deleted.', 'error')
    finally:
        db_session.close()
        if committed:
            service.remove_files(stale_paths)

    return redirect(url_for('software_inventory.index', **_carry_query_args()))


@software_inventory_bp.route('/<int:item_id>/edit', methods=['POST'])
@member_required
def edit_item(item_id, user=None):
    """Update a package, and optionally publish another release in the same go.

    The panel this backs is the publish panel with the name and description
    filled in. Version and file are left EMPTY there on purpose: an edit is
    usually just a correction, but the one moment an administrator is most
    likely to want a new release is while they are already looking at the
    package. Attaching a file here does exactly what publishing under the same
    name does - appends the next revision and prunes the oldest.

    A rename has to move `name_key` with it, because that column is what search
    matches on and what `upload` checks to decide whether a publish adds a
    version to an existing product or creates a new one. Renaming onto a name
    that already exists is refused rather than merged: merging two products
    would have to renumber one side's revisions, and silently doing that to a
    download history is worse than saying no.

    The file handling mirrors `upload` deliberately - same streamed save, same
    empty-file guard, same rule that a partial file is unlinked on failure and
    superseded files are unlinked only after the commit.

    The audience travels with the rest of the form. The panel opens with the
    package's CURRENT audience already selected, so saving a description fix
    re-saves the same audience rather than resetting it - an edit that quietly
    republished restricted software to everyone would be the worst bug this
    module could have.
    """
    name = (request.form.get('name') or '').strip()
    description = (request.form.get('description') or '').strip()
    version_label = (request.form.get('version') or '').strip()
    upload_file = request.files.get('file')
    has_file = bool(upload_file and upload_file.filename)

    if not name:
        flash('A name is required.', 'error')
        return _upload_response()

    visibility, tower_ids, audience_error = access.read_form_audience(
        request.form)
    if audience_error:
        flash(audience_error, 'error')
        return _upload_response()

    db_session = get_db_session()
    dest_path = None
    committed = False
    stale_paths = []
    try:
        item = db_session.query(SoftwareItem).filter(
            SoftwareItem.id == item_id).first()
        if not item:
            abort(404)

        key = name_key(name)
        clash = (db_session.query(SoftwareItem)
                 .filter(SoftwareItem.name_key == key,
                         SoftwareItem.id != item_id)
                 .first())
        if clash:
            flash('"%s" is already published. Rename it to something else, or '
                  'publish this file under that name to add it as a version.'
                  % clash.name, 'error')
            return _upload_response()

        item.name = name
        item.name_key = key
        item.description = description or None

        applied, audience_error = access.apply_audience(
            db_session, item, visibility, tower_ids, user.id)
        if audience_error:
            db_session.rollback()
            flash(audience_error, 'error')
            return _upload_response()

        pruned = 0
        if has_file:
            config.ensure_upload_root()
            revision = service.next_revision(db_session, item.id)
            stored_name = service.build_stored_name(revision,
                                                    upload_file.filename)
            dest_path = service.resolve_path(item.id, stored_name)
            if not dest_path:
                raise RuntimeError('Refusing to write outside the uploads folder')

            size, sha = service.save_stream(upload_file.stream, dest_path)
            if size == 0:
                db_session.rollback()
                service.remove_files([dest_path])
                flash('That file is empty - nothing was changed.', 'error')
                return _upload_response()

            db_session.add(SoftwareVersion(
                software_id=item.id,
                revision=revision,
                version_label=version_label[:100] or None,
                stored_filename=stored_name,
                original_filename=upload_file.filename[:255],
                size_bytes=size,
                sha256=sha,
                uploaded_by=user.id,
            ))
            # autoflush is off on these sessions, so the row the prune must
            # KEEP would otherwise be invisible to the query it runs.
            db_session.flush()
            # Only a new release moves the product's date - a typo fix should
            # not push a package to the top of "sort by date".
            item.updated_at = datetime.now()
            db_session.flush()
            stale_paths = service.prune_versions(db_session, item.id,
                                                 protect=(stored_name,))
            pruned = len(stale_paths)

        db_session.commit()
        committed = True

        if has_file:
            msg = 'Saved %s and published %s. %s' % (
                name, version_label or 'a new release',
                _audience_note(db_session, visibility, applied))
            if pruned:
                msg += (' The oldest %d version%s removed to keep the latest %d.'
                        % (pruned, 's were' if pruned != 1 else ' was',
                           config.MAX_VERSIONS))
        else:
            msg = '%s was updated. %s' % (
                name, _audience_note(db_session, visibility, applied))
        flash(msg, 'success')
    except Exception:
        db_session.rollback()
        logger.exception('Failed to edit software item %s', item_id)
        flash('That software entry could not be updated.', 'error')
        if dest_path:
            service.remove_files([dest_path])
    finally:
        db_session.close()
        # Unlink ONLY after a successful commit - earlier would destroy an
        # installer whose row survived the rollback.
        if committed:
            service.remove_files(stale_paths)

    return _upload_response()


@software_inventory_bp.route('/<int:item_id>/delete', methods=['POST'])
@member_required
def delete_item(item_id, user=None):
    """Remove a product and every version of it. Admin only, and permanent."""
    db_session = get_db_session()
    committed = False
    stale_paths = []
    try:
        item = db_session.query(SoftwareItem).filter(
            SoftwareItem.id == item_id).first()
        if not item:
            abort(404)

        name = item.name
        stale_paths = service.delete_item_versions(db_session, item.id)
        db_session.delete(item)
        db_session.commit()
        committed = True
        flash('%s and all of its versions were deleted.' % name, 'success')
    except Exception:
        db_session.rollback()
        logger.exception('Failed to delete software item %s', item_id)
        flash('That software entry could not be deleted.', 'error')
    finally:
        db_session.close()
        if committed:
            service.remove_files(stale_paths)
            service.remove_item_dir(item_id)

    return redirect(url_for('software_inventory.index', **_carry_query_args()))


@software_inventory_bp.route('/members')
@admin_required
def manage_members(user=None):
    """Who may publish to the shelf. Admin only, to view and to change.

    Admins are members implicitly and are never rows in this table, so the
    list can never be emptied into a state where nobody can publish.
    """
    db_session = get_db_session()
    try:
        members = db_session.query(SoftwareGroupMember).all()
        member_ids = {m.user_id for m in members}

        users_by_id = {}
        if member_ids:
            users_by_id = {u.id: u for u in db_session.query(User)
                           .filter(User.id.in_(member_ids)).all()}
        adders = {m.added_by for m in members if m.added_by}
        adders_by_id = {}
        if adders:
            adders_by_id = {u.id: u for u in db_session.query(User)
                            .filter(User.id.in_(adders)).all()}

        member_rows = []
        for m in members:
            u = users_by_id.get(m.user_id)
            if not u:
                # The account was hard-deleted out from under the row. Skip it
                # rather than render a blank line; the orphan is harmless
                # because is_member() looks up by the id that no longer exists.
                continue
            added_by = adders_by_id.get(m.added_by)
            member_rows.append({
                'member_id': m.id,
                'user': u,
                'added_at': m.added_at,
                'added_by': added_by.username if added_by else None,
            })
        member_rows.sort(key=lambda r: (r['user'].username or '').lower())

        # Only active accounts, and only those not already members. A disabled
        # account must not be grantable - off-boarding would silently leave a
        # publish permission behind.
        available = db_session.query(User).filter(User.is_active == True)
        if member_ids:
            available = available.filter(~User.id.in_(member_ids))
        available_users = available.order_by(User.username).all()

        admin_count = (db_session.query(User)
                       .filter(User.role == 'admin', User.is_active == True)
                       .count())

        return render_template('software_inventory/members.html',
                               user=user, member_rows=member_rows,
                               available_users=available_users,
                               admin_count=admin_count)
    finally:
        db_session.close()


@software_inventory_bp.route('/members/add', methods=['POST'])
@admin_required
def add_member(user=None):
    """Grant publish rights. Admin only - members cannot add members."""
    target_id = (request.form.get('user_id') or '').strip()
    if not target_id.isdigit():
        flash('Please choose a person to add.', 'error')
        return redirect(url_for('software_inventory.manage_members'))

    db_session = get_db_session()
    try:
        target = db_session.query(User).filter(
            User.id == int(target_id), User.is_active == True).first()
        if not target:
            flash('That account could not be found, or is disabled.', 'error')
            return redirect(url_for('software_inventory.manage_members'))

        existing = db_session.query(SoftwareGroupMember).filter_by(
            user_id=target.id).first()
        if existing:
            flash('%s can already publish software.' % target.username,
                  'warning')
            return redirect(url_for('software_inventory.manage_members'))

        db_session.add(SoftwareGroupMember(user_id=target.id,
                                           added_by=user.id))
        db_session.commit()
        flash('%s can now publish, edit and delete software.'
              % target.username, 'success')
    except Exception:
        db_session.rollback()
        logger.exception('Failed to add software group member %s', target_id)
        flash('That person could not be added.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('software_inventory.manage_members'))


@software_inventory_bp.route('/members/<int:member_id>/remove',
                             methods=['POST'])
@admin_required
def remove_member(member_id, user=None):
    """Revoke publish rights. Admin only.

    Removing a member takes away what they can do next; it changes nothing
    about what they already published. The packages and releases stay, because
    they are a record of what the organisation actually ships.
    """
    db_session = get_db_session()
    try:
        member = db_session.query(SoftwareGroupMember).filter_by(
            id=member_id).first()
        if not member:
            flash('That member is no longer on the list.', 'warning')
            return redirect(url_for('software_inventory.manage_members'))

        target = db_session.query(User).filter(
            User.id == member.user_id).first()
        db_session.delete(member)
        db_session.commit()
        flash('%s can no longer publish software.'
              % (target.username if target else 'That person'), 'success')
    except Exception:
        db_session.rollback()
        logger.exception('Failed to remove software group member %s',
                         member_id)
        flash('That member could not be removed.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('software_inventory.manage_members'))


@software_inventory_bp.route('/about')
@login_required
def about(user=None):
    """What the module is, who can do what, and how retention behaves."""
    return render_template('software_inventory/about.html', user=user,
                           max_versions=config.MAX_VERSIONS,
                           is_admin=(user.role == 'admin'))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _upload_response():
    """Answer the upload form - a redirect, or JSON when posted by XHR.

    A multi-GB upload is posted by XHR so the page can show real progress
    (see index.html). Following a 302 inside that XHR would fetch the
    catalogue page and CONSUME the queued flash message, leaving the user
    with no confirmation once the browser finally navigates. Returning the
    target as JSON instead leaves the flash queued for that navigation, so
    both paths end up showing the same message."""
    target = url_for('software_inventory.index', **_carry_query_args())
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'redirect': target})
    return redirect(target)


def _audience_map(db_session):
    """{name_key: {name, visibility, towers, names}} for every package.

    Feeds the publish form's name watcher, which pre-selects a package's
    CURRENT audience the moment the typed name matches it. Without that, a
    publisher adding release 5 of a tower-restricted package would be looking
    at a form that says "General software" and would republish it to the whole
    organisation by doing nothing.

    Publishers only, and three queries: the shelf is a few hundred rows of
    short strings at most, which is not worth the complexity of fetching only
    the packages the current search left out.
    """
    items = (db_session.query(SoftwareItem.id, SoftwareItem.name,
                              SoftwareItem.name_key, SoftwareItem.visibility)
             .all())
    if not items:
        return {}
    grants = access.item_tower_ids(db_session, [i[0] for i in items])
    names = access.tower_names(
        db_session, {t for ids in grants.values() for t in ids})

    out = {}
    for item_id, name, key, visibility in items:
        granted = grants.get(item_id, [])
        out[key] = {
            'name': name,
            'visibility': visibility or 'general',
            'towers': granted,
            'names': sorted((names.get(t, {}).get('name', 'Tower %d' % t)
                             for t in granted), key=lambda n: n.lower()),
        }
    return out


def _audience_note(db_session, visibility, tower_ids):
    """The sentence appended to every publish / save confirmation.

    Always present, never conditional on the audience having CHANGED. A
    publisher who re-published a package without noticing the audience control
    is exactly the person who needs to be told what it is now, and a message
    that only appears on a change is silent in precisely that case.
    """
    if visibility != VISIBILITY_RESTRICTED:
        return 'It is available to every signed-in user.'
    names = access.tower_names(db_session, tower_ids)
    ordered = sorted((v['name'] for v in names.values()),
                     key=lambda n: n.lower())
    if not ordered:
        return 'It is restricted, but no tower currently holds access to it.'
    return ('Only members of the %s can download it.'
            % access.join_names(ordered))


def _carry_query_args():
    """Keep the caller's search / sort across a POST-redirect-GET."""
    args = {}
    for key in ('q', 'sort', 'dir'):
        value = request.form.get(key) or request.args.get(key)
        if value:
            args[key] = value
    return args
