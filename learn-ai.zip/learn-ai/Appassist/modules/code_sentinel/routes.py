"""
Code Sentinel routes - the web front-end over the CodeSentinel scan engine.

Architecture (central code-quality platform model):
  * This Flask module is the system of record: scan results, findings,
    triage and trends live in the App Assist database.
  * Scanning happens at the code, never in the browser and never inside an
    HTTP request - routes enqueue a background job (jobs.py) and the scan
    page polls for progress.
  * CI pipelines run the existing CLI (`python -m codesentinel scan -f json`)
    and POST the JSON report to /api/scans with a bearer token; the server
    recomputes scores and the quality gate with the server-side gate config
    and triage decisions.

Permission model:
  * any signed-in user      - view dashboards/scans, run zip/git scans, triage
  * admin / project_manager - additionally scan server paths, delete projects
  * admin                   - rules enable/disable, gate config, API tokens
"""

import hashlib
import json
import logging
import os
import secrets
import shutil
from datetime import datetime, timedelta

from flask import (
    render_template, redirect, url_for, flash, request, jsonify,
    send_file, abort,
)
# `col == sql_true()` rather than `col.is_(True)`: SQLAlchemy renders
# the latter as `col IS 1`, which SQLite accepts and SQL SERVER REJECTS
# - T-SQL allows IS only with NULL. Both compile `== true()` to `= 1`.
from sqlalchemy import and_, case, func, or_, true as sql_true, false as sql_false
from sqlalchemy.orm import joinedload
from werkzeug.utils import secure_filename

from auth import get_current_user, require_auth
from csrf_utils import csrf_protect, csrf_exempt
from database import get_db_session

from . import code_sentinel_bp, config, engine, jobs
from .models import (
    CodeApiToken, CodeFinding, CodeProject, CodeScan, CodeTriage,
    DEBT_PER_FINDING, GATE_MODES, GRADE_COLORS, SCORE_DIMENSIONS, SEVERITIES,
    SEVERITY_COLORS, SEVERITY_TINTS, SOURCE_TYPES, TRIAGE_LABELS,
    TRIAGE_STATUSES,
)

logger = logging.getLogger(__name__)

FINDINGS_PER_PAGE = 100


# ---------------------------------------------------------------------------
# Template context
# ---------------------------------------------------------------------------

def _display_name(u) -> str:
    """'First Last' in initial caps; falls back to the username."""
    if not u:
        return '-'
    full = f"{(u.firstname or '').strip().title()} " \
           f"{(u.lastname or '').strip().title()}".strip()
    return full or u.username


@code_sentinel_bp.context_processor
def _inject_common():
    return {
        'user': get_current_user(),
        'SEVERITIES': SEVERITIES,
        'SEVERITY_COLORS': SEVERITY_COLORS,
        'SEVERITY_TINTS': SEVERITY_TINTS,
        'GRADE_COLORS': GRADE_COLORS,
        'TRIAGE_LABELS': TRIAGE_LABELS,
        'SOURCE_TYPES': SOURCE_TYPES,
        'person': _display_name,
        'UPLOAD_RETENTION_DAYS': config.UPLOAD_RETENTION_DAYS,
    }


def _can_manage(user, project) -> bool:
    """Delete / rescan rights: admin, or the PM who created the project."""
    if not user:
        return False
    if user.role == 'admin':
        return True
    return user.role == 'project_manager' and project.created_by == user.id


def _remove_stored_source(source_type, source_ref):
    """Delete a stored upload (zip file or multi-file folder) from disk.

    Confined to UPLOADS_DIR so a tampered DB value can never delete anything
    else on the server.
    """
    if source_type not in ('upload', 'files') or not source_ref:
        return
    base = os.path.abspath(config.UPLOADS_DIR)
    target = os.path.abspath(config.source_path(source_ref))
    try:
        if os.path.commonpath([base, target]) != base:
            return
    except ValueError:   # different drive on Windows
        return
    try:
        if source_type == 'upload' and os.path.isfile(target):
            os.remove(target)
        elif source_type == 'files' and os.path.isdir(target):
            shutil.rmtree(target, ignore_errors=True)
    except OSError:
        logger.warning('Could not remove stored source %s', target)


def _store_zip_upload(archive):
    """Persist an uploaded .zip; returns ('upload', name inside UPLOADS_DIR).

    The NAME is stored, not the absolute path, so the storage root can be
    relocated (CODESENTINEL_STORAGE_DIR) without rewriting the database -
    config.source_path() resolves it back to a full path.
    """
    filename = secure_filename(os.path.basename(archive.filename))
    if not filename or not filename.lower().endswith('.zip'):
        raise ValueError('Only .zip archives are supported.')
    config.ensure_dirs()
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    name = f'{stamp}_{filename}'
    archive.save(os.path.join(config.UPLOADS_DIR, name))
    return 'upload', name


def _store_files_upload(uploads):
    """Persist a multi-file selection; returns ('files', name of its folder)."""
    config.ensure_dirs()
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    name = f'{stamp}_files'
    folder = os.path.join(config.UPLOADS_DIR, name)
    os.makedirs(folder, exist_ok=True)
    saved = 0
    for upload in uploads:
        filename = secure_filename(os.path.basename(upload.filename))
        if not filename:
            continue
        target = os.path.join(folder, filename)
        # Same name uploaded twice: keep both, suffix the later one.
        if os.path.exists(target):
            base, ext = os.path.splitext(filename)
            counter = 1
            while os.path.exists(target):
                target = os.path.join(folder, f'{base}_{counter}{ext}')
                counter += 1
        upload.save(target)
        saved += 1
    if not saved:
        shutil.rmtree(folder, ignore_errors=True)
        raise ValueError('None of the selected files could be stored.')
    return 'files', name


def _source_available(project) -> bool:
    """Whether the stored upload behind a re-scannable project still exists
    (it may have been auto-deleted by the retention purge)."""
    if not project.rescannable or not project.source_ref:
        return False
    path = config.source_path(project.source_ref)
    if project.source_type == 'upload':
        return os.path.isfile(path)
    return os.path.isdir(path)


def _severity_order():
    return case(
        {name: rank for rank, name in enumerate(SEVERITIES)},
        value=CodeFinding.severity, else_=len(SEVERITIES),
    )


def _scan_number(session, scan) -> int:
    """Per-project scan sequence (1, 2, 3 ...) in creation order. Scan ids are
    global across projects and confuse users ('scan 4' on a project with one
    scan); every display uses this project-local number instead."""
    return (session.query(func.count(CodeScan.id))
            .filter(CodeScan.project_id == scan.project_id,
                    CodeScan.id <= scan.id)
            .scalar() or 1)


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------

@code_sentinel_bp.route('/')
@require_auth()
def dashboard():
    session = get_db_session()
    try:
        jobs.purge_old_uploads(session)
        jobs.reap_orphaned_scans(session)
        projects = (
            session.query(CodeProject)
            .options(joinedload(CodeProject.scans))
            .order_by(CodeProject.name)
            .all()
        )
        # Most recently scanned project first (never-scanned projects last,
        # newest project first among those).
        projects.sort(key=lambda p: (
            (p.latest_scan.created_at if p.latest_scan
             and p.latest_scan.created_at else datetime.min),
            p.created_at or datetime.min,
        ), reverse=True)

        completed = [p.latest_completed_scan for p in projects
                     if p.latest_completed_scan]
        totals = {name: sum(s.severity_counts[name] for s in completed)
                  for name in SEVERITIES}
        stats = {
            'projects': len(projects),
            'scans': session.query(func.count(CodeScan.id)).scalar() or 0,
            'gate_passed': sum(1 for s in completed if s.gate_passed),
            'gate_failed': sum(1 for s in completed if s.gate_passed is False),
            'open_findings': sum(s.total_findings or 0 for s in completed),
            'code_lines': sum(s.code_lines or 0 for s in completed),
            'severity_totals': totals,
        }

        return render_template(
            'code_sentinel/dashboard.html',
            projects=projects, stats=stats,
            engine_ok=engine.available(),
        )
    finally:
        session.close()


# ---------------------------------------------------------------------------
# New scan (zip upload / multi-file upload)
# ---------------------------------------------------------------------------

@code_sentinel_bp.route('/new', methods=['GET', 'POST'])
@require_auth()
@csrf_protect
def new_scan():
    user = get_current_user()

    if request.method == 'POST':
        if not engine.available():
            flash('The CodeSentinel engine is not available on this server - '
                  'check the CODESENTINEL_SRC setting.', 'error')
            return redirect(url_for('code_sentinel.new_scan'))

        name = (request.form.get('project_name') or '').strip()
        source_type = request.form.get('source_type') or ''
        if not name:
            flash('Project name is required.', 'error')
            return redirect(url_for('code_sentinel.new_scan'))
        if source_type not in ('upload', 'files'):
            flash('Choose a source for the scan.', 'error')
            return redirect(url_for('code_sentinel.new_scan'))

        session = get_db_session()
        try:
            jobs.purge_old_uploads(session)
            # force=True: an orphaned scan would otherwise read as "in progress"
            # below and lock the user out of scanning this project at all.
            jobs.reap_orphaned_scans(session, force=True)
            project = session.query(CodeProject).filter(
                func.lower(CodeProject.name) == name.lower()).first()

            # Check for an in-flight scan BEFORE touching the stored source -
            # a running scan may be reading the files we would replace.
            if project is not None:
                running = session.query(CodeScan).filter(
                    CodeScan.project_id == project.id,
                    CodeScan.status.in_(('queued', 'running')),
                ).first()
                if running:
                    flash('A scan for this project is already in progress.',
                          'warning')
                    return redirect(url_for('code_sentinel.scan_detail',
                                            scan_id=running.id))

            try:
                if source_type == 'upload':
                    archive = request.files.get('archive')
                    if archive is None or not archive.filename:
                        raise ValueError('Choose a .zip archive to upload.')
                    source_type, source_ref = _store_zip_upload(archive)
                else:  # files - a multi-file selection stored as a directory
                    uploads = [f for f in request.files.getlist('files')
                               if f and f.filename]
                    if not uploads:
                        raise ValueError('Choose one or more source files to '
                                         'upload.')
                    source_type, source_ref = _store_files_upload(uploads)
            except ValueError as exc:
                flash(str(exc), 'error')
                return redirect(url_for('code_sentinel.new_scan'))

            if project is None:
                project = CodeProject(name=name, source_type=source_type,
                                      source_ref=source_ref,
                                      created_by=user.id)
                session.add(project)
                session.flush()
            else:
                # Existing project: the new upload replaces its source - the
                # whole team may publish a new version of the code to scan.
                _remove_stored_source(project.source_type, project.source_ref)
                project.source_type = source_type
                project.source_ref = source_ref

            scan = CodeScan(project_id=project.id, status='queued',
                            trigger='web', triggered_by=user.id)
            session.add(scan)
            session.commit()
            scan_id = scan.id
        finally:
            session.close()

        jobs.enqueue_scan(scan_id)
        flash('Scan queued - results appear on this page as it runs.', 'success')
        return redirect(url_for('code_sentinel.scan_detail', scan_id=scan_id))

    return render_template('code_sentinel/new_scan.html',
                           engine_ok=engine.available())


@code_sentinel_bp.route('/projects/<int:project_id>/upload-scan', methods=['POST'])
@require_auth()
@csrf_protect
def upload_scan(project_id):
    """
    Upload a NEW version of the source under an existing project and scan it.
    Open to the whole team: one file input - a single .zip is treated as an
    archive of the project, anything else as a multi-file selection. The new
    upload replaces the stored source; scan history and trend continue.
    """
    user = get_current_user()
    if not engine.available():
        flash('The CodeSentinel engine is not available on this server - '
              'check the CODESENTINEL_SRC setting.', 'error')
        return redirect(url_for('code_sentinel.project_detail',
                                project_id=project_id))

    session = get_db_session()
    try:
        project = session.query(CodeProject).filter_by(id=project_id).first()
        if project is None:
            abort(404)

        jobs.reap_orphaned_scans(session, force=True)
        running = session.query(CodeScan).filter(
            CodeScan.project_id == project.id,
            CodeScan.status.in_(('queued', 'running')),
        ).first()
        if running:
            flash('A scan for this project is already in progress.', 'warning')
            return redirect(url_for('code_sentinel.scan_detail',
                                    scan_id=running.id))

        uploads = [f for f in request.files.getlist('files')
                   if f and f.filename]
        try:
            if not uploads:
                raise ValueError('Choose the new source files (or one .zip of '
                                 'the project) to upload.')
            if len(uploads) == 1 and uploads[0].filename.lower().endswith('.zip'):
                source_type, source_ref = _store_zip_upload(uploads[0])
            else:
                source_type, source_ref = _store_files_upload(uploads)
        except ValueError as exc:
            flash(str(exc), 'error')
            return redirect(url_for('code_sentinel.project_detail',
                                    project_id=project_id))

        _remove_stored_source(project.source_type, project.source_ref)
        project.source_type = source_type
        project.source_ref = source_ref

        scan = CodeScan(project_id=project.id, status='queued',
                        trigger='web', triggered_by=user.id)
        session.add(scan)
        session.commit()
        scan_id = scan.id
    finally:
        session.close()

    jobs.enqueue_scan(scan_id)
    flash('New version uploaded - scan queued.', 'success')
    return redirect(url_for('code_sentinel.scan_detail', scan_id=scan_id))


@code_sentinel_bp.route('/projects/<int:project_id>/rescan', methods=['POST'])
@require_auth()
@csrf_protect
def rescan(project_id):
    user = get_current_user()
    session = get_db_session()
    try:
        project = session.query(CodeProject).filter_by(id=project_id).first()
        if project is None:
            abort(404)
        if not project.rescannable:
            flash('This project has no re-scannable upload - CI-ingested '
                  'projects are re-scanned from the pipeline.', 'warning')
            return redirect(url_for('code_sentinel.project_detail',
                                    project_id=project_id))
        if not _source_available(project):
            flash('The stored upload for this project was auto-deleted after '
                  f'{config.UPLOAD_RETENTION_DAYS} days to save disk space. '
                  'Upload the source again (same project name) to re-scan.',
                  'warning')
            return redirect(url_for('code_sentinel.project_detail',
                                    project_id=project_id))
        jobs.reap_orphaned_scans(session, force=True)
        running = session.query(CodeScan).filter(
            CodeScan.project_id == project.id,
            CodeScan.status.in_(('queued', 'running')),
        ).first()
        if running:
            flash('A scan for this project is already in progress.', 'warning')
            return redirect(url_for('code_sentinel.scan_detail',
                                    scan_id=running.id))
        scan = CodeScan(project_id=project.id, status='queued',
                        trigger='web', triggered_by=user.id)
        session.add(scan)
        session.commit()
        scan_id = scan.id
    finally:
        session.close()

    jobs.enqueue_scan(scan_id)
    return redirect(url_for('code_sentinel.scan_detail', scan_id=scan_id))


# ---------------------------------------------------------------------------
# Project detail (history + trend)
# ---------------------------------------------------------------------------

@code_sentinel_bp.route('/projects/<int:project_id>')
@require_auth()
def project_detail(project_id):
    user = get_current_user()
    session = get_db_session()
    try:
        project = (
            session.query(CodeProject)
            .options(joinedload(CodeProject.scans)
                     .joinedload(CodeScan.triggered_by_user))
            .filter_by(id=project_id).first()
        )
        if project is None:
            abort(404)

        history = [s for s in project.scans if s.status == 'completed']
        history_chrono = list(reversed(history))
        trend = {
            'labels': [s.finished_at.strftime('%d %b %H:%M')
                       for s in history_chrono if s.finished_at],
            'overall': [s.overall_score for s in history_chrono],
            'security': [s.security_score for s in history_chrono],
            'findings': [s.total_findings for s in history_chrono],
        }
        source_available = _source_available(project)
        return render_template(
            'code_sentinel/project.html',
            project=project, trend_json=json.dumps(trend),
            can_manage=_can_manage(user, project),
            can_rescan=project.rescannable and source_available,
            source_purged=project.rescannable and not source_available,
            gate_modes=GATE_MODES,
        )
    finally:
        session.close()


@code_sentinel_bp.route('/projects/<int:project_id>/delete', methods=['POST'])
@require_auth()
@csrf_protect
def delete_project(project_id):
    user = get_current_user()
    session = get_db_session()
    try:
        project = session.query(CodeProject).filter_by(id=project_id).first()
        if project is None:
            abort(404)
        if not _can_manage(user, project):
            flash('Only an administrator or the project creator can delete a '
                  'project.', 'error')
            return redirect(url_for('code_sentinel.project_detail',
                                    project_id=project_id))
        if any(s.status in ('queued', 'running') for s in project.scans):
            flash('Wait for the running scan to finish before deleting.', 'error')
            return redirect(url_for('code_sentinel.project_detail',
                                    project_id=project_id))

        result_files = [s.result_file for s in project.scans if s.result_file]
        source_type, source_ref = project.source_type, project.source_ref
        name = project.name
        workspace = jobs.project_workspace(project.id)

        session.query(CodeTriage).filter_by(project_id=project.id).delete()
        session.delete(project)   # scans + findings cascade
        session.commit()

        for rel in result_files:
            try:
                os.remove(os.path.join(config.RESULTS_DIR, rel))
            except OSError:
                pass
        _remove_stored_source(source_type, source_ref)
        jobs._clear_workspace(workspace)

        flash(f'Project "{name}" and its scan history were deleted.', 'success')
        return redirect(url_for('code_sentinel.dashboard'))
    finally:
        session.close()


@code_sentinel_bp.route('/projects/<int:project_id>/gate-mode', methods=['POST'])
@require_auth()
@csrf_protect
def set_gate_mode(project_id):
    """
    Switch a project's release gate between full-codebase and new-code-only
    ("clean as you code"). Takes effect from the NEXT scan; historical scan
    verdicts are immutable.
    """
    user = get_current_user()
    mode = (request.form.get('gate_mode') or '').strip()
    session = get_db_session()
    try:
        project = session.query(CodeProject).filter_by(id=project_id).first()
        if project is None:
            abort(404)
        if not _can_manage(user, project):
            flash('Only an administrator or the project creator can change the '
                  'gate mode.', 'error')
            return redirect(url_for('code_sentinel.project_detail',
                                    project_id=project_id))
        if mode not in GATE_MODES:
            flash('Invalid gate mode.', 'error')
            return redirect(url_for('code_sentinel.project_detail',
                                    project_id=project_id))
        project.gate_mode = mode
        session.commit()
        flash(f'Release gate set to "{GATE_MODES[mode]}". This applies from the '
              f'next scan.', 'success')
        return redirect(url_for('code_sentinel.project_detail',
                                project_id=project_id))
    finally:
        session.close()


def _sev_phrase(sev_counts: dict) -> str:
    """'1 CRITICAL, 4 HIGH, 12 MEDIUM' in severity order (non-zero only)."""
    parts = [f'{sev_counts[name]} {name}' for name in SEVERITIES
             if sev_counts.get(name)]
    return ', '.join(parts)


def _score_explanations(session, scan) -> dict:
    """
    Why each score card is what it is, from this scan's OPEN findings
    (triaged false-positive / accepted-risk findings are excluded - they do
    not count against scores).
    """
    rows = (
        session.query(CodeFinding.category, CodeFinding.severity,
                      func.count(CodeFinding.id))
        .outerjoin(CodeTriage, and_(
            CodeTriage.project_id == scan.project_id,
            CodeTriage.fingerprint == CodeFinding.fingerprint))
        .filter(CodeFinding.scan_id == scan.id, CodeTriage.id.is_(None))
        .group_by(CodeFinding.category, CodeFinding.severity)
        .all()
    )

    explains = {}
    for label, categories in SCORE_DIMENSIONS.items():
        sev_counts: dict = {}
        cat_counts: dict = {}
        for category, severity, count in rows:
            if category in categories:
                sev_counts[severity] = sev_counts.get(severity, 0) + count
                cat_counts[category] = cat_counts.get(category, 0) + count
        total = sum(sev_counts.values())
        score = getattr(scan, f'{label.lower()}_score')
        if total == 0:
            reason = 'No open findings in this area - full score.'
        else:
            top = sorted(cat_counts.items(), key=lambda kv: -kv[1])[:2]
            top_str = ', '.join(f'{cat} ({n})' for cat, n in top)
            penalty = 100 - (score if score is not None else 100)
            reason = (f'{total} open finding(s): {_sev_phrase(sev_counts)} - '
                      f'mostly {top_str}. '
                      f'-{penalty} pts for weighted density across '
                      f'{scan.code_lines or 0:,} lines of code.')
        explains[label] = reason

    explains['Overall'] = ('Average of the four areas with Security counted '
                           'twice - security findings hurt the headline '
                           'grade the most.')

    # Technical debt: estimated fix time per open finding, by severity.
    debt_sev: dict = {}
    for _category, severity, count in rows:
        debt_sev[severity] = debt_sev.get(severity, 0) + count
    parts = [f'{debt_sev[name]} {name} x {DEBT_PER_FINDING[name]}'
             for name in SEVERITIES if debt_sev.get(name)]
    explains['debt'] = (' + '.join(parts) if parts
                        else 'No open findings - nothing to fix.')
    return explains


def _scan_summary(scan, explains: dict, gate_reasons: list,
                  gate_notes: list = None) -> list:
    """A few plain-language sentences summarising one scan result."""
    lines = []
    duration = (f' in {scan.duration_seconds:.1f}s'
                if scan.duration_seconds is not None else '')
    lines.append(
        f'Scanned {scan.files_scanned} file(s) '
        f'({scan.files_cached} unchanged, served from cache) - '
        f'{scan.code_lines or 0:,} lines of code{duration}.')

    sev = _sev_phrase(scan.severity_counts)
    if scan.total_findings:
        suppressed = (f' Another {scan.suppressed_findings} finding(s) are '
                      'suppressed by triage decisions and do not count.'
                      if scan.suppressed_findings else '')
        lines.append(f'{scan.total_findings} open finding(s): {sev}.'
                     + suppressed)
    else:
        lines.append('No open findings.'
                     + (f' {scan.suppressed_findings} finding(s) are '
                        'suppressed by triage.'
                        if scan.suppressed_findings else ''))

    dims = {label: getattr(scan, f'{label.lower()}_score')
            for label in SCORE_DIMENSIONS}
    dims = {k: v for k, v in dims.items() if v is not None}
    if dims:
        weakest = min(dims, key=dims.get)
        if dims[weakest] >= 100:
            lines.append('All four quality areas are at a full 100.')
        else:
            lines.append(f'Weakest area: {weakest} at {dims[weakest]}/100 - '
                         'start fixing there for the biggest grade improvement.')

    if scan.gate_passed:
        if gate_notes:
            lines.append(
                'The quality gate PASSED - this build is releasable by the '
                f'configured standard. {len(gate_notes)} reviewer waiver '
                'note(s) accompany it (findings marked false-positive or '
                'accepted-risk, with reasons, listed below).')
        else:
            lines.append('The quality gate PASSED - this build is releasable '
                         'by the configured standard.')
    else:
        lines.append(f'The quality gate FAILED on {len(gate_reasons)} '
                     'condition(s) - see the banner above.')

    lines.append(f'Estimated technical debt: {scan.debt_display} of focused '
                 'fix effort to clear every open finding.')
    return lines


# ---------------------------------------------------------------------------
# Scan detail + progress polling
# ---------------------------------------------------------------------------

@code_sentinel_bp.route('/scans/<int:scan_id>')
@require_auth()
def scan_detail(scan_id):
    user = get_current_user()
    session = get_db_session()
    try:
        jobs.reap_orphaned_scans(session)
        scan = (
            session.query(CodeScan)
            .options(joinedload(CodeScan.project),
                     joinedload(CodeScan.triggered_by_user))
            .filter_by(id=scan_id).first()
        )
        if scan is None:
            abort(404)

        scan_no = _scan_number(session, scan)

        if scan.status != 'completed':
            stale = (scan.status == 'running' and scan.started_at and
                     datetime.now() - scan.started_at >
                     timedelta(hours=config.STALE_RUNNING_HOURS))
            return render_template(
                'code_sentinel/scan_progress.html',
                scan=scan, scan_no=scan_no, project=scan.project, stale=stale,
                can_manage=_can_manage(user, scan.project),
                can_rescan=_source_available(scan.project),
            )

        # ---- Findings with filters + pagination -------------------------
        sel_severity = request.args.get('severity') or ''
        sel_category = request.args.get('category') or ''
        sel_status = request.args.get('status') or ''
        sel_new = request.args.get('new') or ''
        sel_sort = request.args.get('sort', 'severity')
        if sel_sort not in ('severity', 'file', 'new'):
            sel_sort = 'severity'
        q = (request.args.get('q') or '').strip()
        page = max(1, request.args.get('page', 1, type=int))

        base = (
            session.query(CodeFinding, CodeTriage)
            .outerjoin(CodeTriage, and_(
                CodeTriage.project_id == scan.project_id,
                CodeTriage.fingerprint == CodeFinding.fingerprint))
            .filter(CodeFinding.scan_id == scan.id)
        )
        if sel_severity in SEVERITIES:
            base = base.filter(CodeFinding.severity == sel_severity)
        elif sel_severity == 'urgent':
            base = base.filter(CodeFinding.severity.in_(SEVERITIES[:3]))
        if sel_category:
            base = base.filter(CodeFinding.category == sel_category)
        if sel_new == '1':
            base = base.filter(CodeFinding.is_new == sql_true())
        elif sel_new == '0':
            base = base.filter(CodeFinding.is_new == sql_false())
        if sel_status == 'OPEN':
            base = base.filter(CodeTriage.id.is_(None))
        elif sel_status in ('FALSE_POSITIVE', 'ACCEPTED_RISK'):
            base = base.filter(CodeTriage.status == sel_status)
        if q:
            like = '%' + q.replace('!', '!!').replace('%', '!%').replace('_', '!_') + '%'
            base = base.filter(or_(
                CodeFinding.file_path.ilike(like, escape='!'),
                CodeFinding.rule_id.ilike(like, escape='!'),
                CodeFinding.message.ilike(like, escape='!'),
                CodeFinding.cwe.ilike(like, escape='!'),
                CodeFinding.owasp.ilike(like, escape='!'),
            ))

        total = base.count()
        pages = max(1, (total + FINDINGS_PER_PAGE - 1) // FINDINGS_PER_PAGE)
        page = min(page, pages)
        ordering = {'severity': [_severity_order(), CodeFinding.file_path, CodeFinding.line],
                    'file': [CodeFinding.file_path, CodeFinding.line, _severity_order()],
                    'new': [CodeFinding.is_new.desc(), _severity_order(), CodeFinding.file_path, CodeFinding.line]}
        rows = (
            base.order_by(*ordering[sel_sort], CodeFinding.id)
            .offset((page - 1) * FINDINGS_PER_PAGE)
            .limit(FINDINGS_PER_PAGE).all()
        )

        categories = [c for (c,) in session.query(CodeFinding.category)
                      .filter(CodeFinding.scan_id == scan.id)
                      .distinct().order_by(CodeFinding.category)]

        gate_reasons = json.loads(scan.gate_reasons or '[]')
        gate_notes = jobs.waiver_notes_for_scan(session, scan)
        gate_waivers = jobs.waiver_details_for_scan(session, scan)
        explains = _score_explanations(session, scan)
        baseline_no = None
        assurance = []
        if scan.result_file:
            try:
                with open(os.path.join(config.RESULTS_DIR, scan.result_file), encoding='utf-8') as handle:
                    assurance = engine.analysis_assurance(json.load(handle))
            except (OSError, ValueError, engine.CodeSentinelUnavailable):
                logger.warning('Analysis evidence unavailable for scan #%s', scan.id)
        if scan.baseline_scan_id:
            baseline = session.query(CodeScan).filter_by(
                id=scan.baseline_scan_id).first()
            if baseline is not None:
                baseline_no = _scan_number(session, baseline)
        return render_template(
            'code_sentinel/scan.html',
            scan=scan, scan_no=scan_no, project=scan.project, rows=rows,
            categories=categories,
            filters={'severity': sel_severity, 'category': sel_category,
                     'status': sel_status, 'q': q, 'new': sel_new, 'sort': sel_sort},
            page=page, pages=pages, total=total,
            per_page=FINDINGS_PER_PAGE,
            gate_reasons=gate_reasons,
            gate_notes=gate_notes,
            gate_waivers=gate_waivers,
            explains=explains,
            assurance=assurance,
            baseline_no=baseline_no,
            summary_lines=_scan_summary(scan, explains, gate_reasons,
                                        gate_notes),
            export_formats=engine.export_formats() if scan.result_file else [],
            can_rescan=_source_available(scan.project),
        )
    finally:
        session.close()


@code_sentinel_bp.route('/scans/<int:scan_id>/status.json')
@require_auth()
def scan_status(scan_id):
    session = get_db_session()
    try:
        # The page polls this while a scan is in flight, so it is also where an
        # orphaned scan (worker recycled mid-scan) is noticed soonest - the
        # reaper throttles itself to once a minute per process.
        jobs.reap_orphaned_scans(session)
        scan = session.query(CodeScan).filter_by(id=scan_id).first()
        if scan is None:
            abort(404)
        return jsonify({
            'status': scan.status,
            'progress_done': scan.progress_done or 0,
            'progress_total': scan.progress_total or 0,
            'current_file': scan.current_file or '',
            'log': scan.log or '',
            'error': scan.error or '',
        })
    finally:
        session.close()


@code_sentinel_bp.route('/scans/<int:scan_id>/mark-failed', methods=['POST'])
@require_auth()
@csrf_protect
def mark_failed(scan_id):
    """Recover a scan orphaned by a worker recycle (stuck 'running')."""
    user = get_current_user()
    session = get_db_session()
    try:
        scan = session.query(CodeScan).options(
            joinedload(CodeScan.project)).filter_by(id=scan_id).first()
        if scan is None:
            abort(404)
        if not _can_manage(user, scan.project):
            flash('Only an administrator or the project creator can do this.',
                  'error')
        elif scan.status in ('queued', 'running'):
            scan.status = 'failed'
            scan.finished_at = datetime.now()
            scan.error = (scan.error or '') + \
                '\nMarked failed manually (worker presumed recycled).'
            session.commit()
            flash('Scan marked as failed.', 'success')
        return redirect(url_for('code_sentinel.scan_detail', scan_id=scan_id))
    finally:
        session.close()


@code_sentinel_bp.route('/scans/<int:scan_id>/delete', methods=['POST'])
@require_auth()
@csrf_protect
def delete_scan(scan_id):
    user = get_current_user()
    session = get_db_session()
    try:
        scan = session.query(CodeScan).options(
            joinedload(CodeScan.project)).filter_by(id=scan_id).first()
        if scan is None:
            abort(404)
        project_id = scan.project_id
        if not _can_manage(user, scan.project):
            flash('Only an administrator or the project creator can delete '
                  'scans.', 'error')
            return redirect(url_for('code_sentinel.scan_detail', scan_id=scan_id))
        if scan.status in ('queued', 'running'):
            flash('This scan is still running.', 'error')
            return redirect(url_for('code_sentinel.scan_detail', scan_id=scan_id))
        result_file = scan.result_file
        session.delete(scan)
        session.commit()
        if result_file:
            try:
                os.remove(os.path.join(config.RESULTS_DIR, result_file))
            except OSError:
                pass
        flash('Scan deleted.', 'success')
        return redirect(url_for('code_sentinel.project_detail',
                                project_id=project_id))
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Triage
# ---------------------------------------------------------------------------

@code_sentinel_bp.route('/scans/<int:scan_id>/triage', methods=['POST'])
@require_auth()
@csrf_protect
def triage(scan_id):
    """
    Set the triage status of one finding (by fingerprint, project-scoped).
    Applies to scores/gates from the NEXT scan and to every future export;
    historical scan summaries are immutable.
    """
    user = get_current_user()
    fingerprint = (request.form.get('fingerprint') or '').strip()
    status = (request.form.get('status') or '').strip()
    note = (request.form.get('note') or '').strip()
    if not fingerprint or status not in TRIAGE_STATUSES:
        return jsonify({'ok': False, 'error': 'Invalid triage request'}), 400

    session = get_db_session()
    try:
        scan = session.query(CodeScan).filter_by(id=scan_id).first()
        if scan is None:
            abort(404)
        if not session.query(CodeFinding.id).filter_by(
                scan_id=scan.id, fingerprint=fingerprint).first():
            return jsonify({'ok': False, 'error': 'Finding does not belong to this scan'}), 400
        existing = session.query(CodeTriage).filter_by(
            project_id=scan.project_id, fingerprint=fingerprint).first()
        if status == 'OPEN':
            if existing is not None:
                session.delete(existing)
        elif existing is not None:
            existing.status = status
            existing.note = note
            existing.decided_by = user.id
            existing.decided_at = datetime.now()
        else:
            session.add(CodeTriage(
                project_id=scan.project_id, fingerprint=fingerprint,
                status=status, note=note, decided_by=user.id))
        session.commit()
        return jsonify({'ok': True, 'status': status,
                        'label': TRIAGE_LABELS[status],
                        'decided_by': _display_name(user)})
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Exports
# ---------------------------------------------------------------------------

@code_sentinel_bp.route('/scans/<int:scan_id>/export/<format_id>')
@require_auth()
def export_scan(scan_id, format_id):
    session = get_db_session()
    try:
        scan = session.query(CodeScan).options(
            joinedload(CodeScan.project)).filter_by(id=scan_id).first()
        if scan is None:
            abort(404)
        if not scan.result_file:
            flash('This scan has no stored result to export.', 'error')
            return redirect(url_for('code_sentinel.scan_detail', scan_id=scan_id))
        result_path = os.path.join(config.RESULTS_DIR, scan.result_file)
        if not os.path.isfile(result_path):
            flash('The stored result file is missing on the server.', 'error')
            return redirect(url_for('code_sentinel.scan_detail', scan_id=scan_id))

        with open(result_path, encoding='utf-8') as handle:
            document = json.load(handle)
        statuses = jobs.triage_map(session, scan.project_id)
        details = jobs.triage_detail_map(session, scan.project_id)
        project_name = scan.project.name
        gate_mode = scan.gate_mode or 'full'
        baseline_fingerprints = None
        if scan.baseline_scan_id:
            baseline_fingerprints = {fp for (fp,) in session.query(CodeFinding.fingerprint)
                                     .join(CodeScan, CodeFinding.scan_id == CodeScan.id)
                                     .filter(CodeScan.id == scan.baseline_scan_id,
                                             CodeScan.project_id == scan.project_id)}
    finally:
        session.close()

    try:
        path, download_name, mimetype = engine.export_payload(
            document, project_name, statuses, format_id,
            triage_details=details, gate_mode=gate_mode,
            baseline_fingerprints=baseline_fingerprints)
    except ValueError as exc:
        flash(str(exc), 'error')
        return redirect(url_for('code_sentinel.scan_detail', scan_id=scan_id))
    return send_file(path, as_attachment=True, download_name=download_name,
                     mimetype=mimetype)


# ---------------------------------------------------------------------------
# Rules browser
# ---------------------------------------------------------------------------

@code_sentinel_bp.route('/rules')
@require_auth()
def rules():
    user = get_current_user()
    try:
        all_rules = engine.list_rules()
        error = None
    except engine.CodeSentinelUnavailable as exc:
        all_rules, error = [], str(exc)
    return render_template('code_sentinel/rules.html', rules=all_rules,
                           error=error, is_admin=user.role == 'admin')


@code_sentinel_bp.route('/rules/toggle', methods=['POST'])
@require_auth('admin')
@csrf_protect
def toggle_rule():
    rule_id = (request.form.get('rule_id') or '').strip()
    enabled = request.form.get('enabled') == '1'
    if not rule_id:
        return jsonify({'ok': False}), 400
    engine.set_rule_enabled(rule_id, enabled)
    return jsonify({'ok': True, 'rule_id': rule_id, 'enabled': enabled})


# ---------------------------------------------------------------------------
# Settings: quality gate, workers, API tokens (admin)
# ---------------------------------------------------------------------------

@code_sentinel_bp.route('/settings', methods=['GET', 'POST'])
@require_auth('admin')
@csrf_protect
def settings():
    user = get_current_user()
    new_token = None

    if request.method == 'POST':
        action = request.form.get('action') or ''
        if action == 'gate':
            try:
                engine.save_gate_config({
                    'max_blocker': max(0, int(request.form.get('max_blocker', 0))),
                    'max_critical': max(0, int(request.form.get('max_critical', 0))),
                    'max_high': max(0, int(request.form.get('max_high', 0))),
                    'max_duplication': min(1.0, max(
                        0.0, float(request.form.get('max_duplication', 10)) / 100.0)),
                    'min_security_score': min(100, max(
                        0, int(request.form.get('min_security_score', 70)))),
                    'min_language_security_score': min(100, max(
                        0, int(request.form.get('min_language_security_score', 0)))),
                    'fail_on_analysis_errors': request.form.get('fail_on_analysis_errors') == '1',
                    'require_language_parsers': request.form.get('require_language_parsers') == '1',
                })
                engine.set_max_workers(int(request.form.get('max_workers', 0)))
                flash('Quality gate updated. It applies to every scan from now '
                      'on (GUI and CLI included - the setting is shared).',
                      'success')
            except (ValueError, engine.CodeSentinelUnavailable) as exc:
                flash(f'Could not save the gate: {exc}', 'error')
            return redirect(url_for('code_sentinel.settings'))

        session = get_db_session()
        try:
            if action == 'create_token':
                label = (request.form.get('label') or '').strip()
                if not label:
                    flash('Give the token a label (e.g. "Jenkins prod").', 'error')
                    return redirect(url_for('code_sentinel.settings'))
                token = 'cs_' + secrets.token_urlsafe(32)
                session.add(CodeApiToken(
                    label=label,
                    token_hash=hashlib.sha256(token.encode()).hexdigest(),
                    token_prefix=token[:10],
                    created_by=user.id,
                ))
                session.commit()
                new_token = token
                flash('Token created - copy it now, it is shown only once.',
                      'success')
            elif action == 'revoke_token':
                token_row = session.query(CodeApiToken).filter_by(
                    id=request.form.get('token_id', type=int)).first()
                if token_row is not None:
                    token_row.is_active = False
                    session.commit()
                    flash(f'Token "{token_row.label}" revoked.', 'success')
                return redirect(url_for('code_sentinel.settings'))
        finally:
            session.close()

    session = get_db_session()
    try:
        tokens = (session.query(CodeApiToken)
                  .options(joinedload(CodeApiToken.creator))
                  .order_by(CodeApiToken.id.desc()).all())
        try:
            gate = engine.gate_config_dict()
            workers = engine.max_workers()
            engine_error = None
        except engine.CodeSentinelUnavailable as exc:
            gate, workers, engine_error = None, 0, str(exc)
        return render_template(
            'code_sentinel/settings.html',
            gate=gate, workers=workers, tokens=tokens,
            new_token=new_token, engine_error=engine_error,
            ingest_url=url_for('code_sentinel.api_ingest', _external=True),
        )
    finally:
        session.close()


# ---------------------------------------------------------------------------
# CI ingest API (bearer-token auth; no session, no CSRF)
# ---------------------------------------------------------------------------

def _token_auth(session):
    header = request.headers.get('Authorization', '')
    if not header.startswith('Bearer '):
        return None
    token = header[len('Bearer '):].strip()
    if not token:
        return None
    digest = hashlib.sha256(token.encode()).hexdigest()
    row = session.query(CodeApiToken).filter_by(
        token_hash=digest, is_active=True).first()
    if row is not None:
        row.last_used_at = datetime.now()
        session.commit()
    return row


@code_sentinel_bp.route('/api/scans', methods=['POST'])
@csrf_exempt
def api_ingest():
    """
    Ingest a CodeSentinel JSON report from a CI pipeline.

    CSRF-exempt on purpose, and the only endpoint in the application that is.
    The caller is a build agent with no session cookie and no page to take a
    token from; it authenticates with a bearer token instead (_token_auth
    below), which a cross-site request cannot forge because no browser will
    attach it automatically.

        python -m codesentinel scan . --format json --output out/
        curl -X POST <server>/code-sentinel/api/scans \
             -H "Authorization: Bearer <token>" \
             -H "Content-Type: application/json" \
             -H "X-Project-Name: my-service" \
             --data-binary @out/codesentinel_*.json

    The server recomputes scores and the quality gate with the server-side
    gate config and triage decisions, and answers with the verdict so the
    pipeline can fail the build on a gate breach.
    """
    session = get_db_session()
    try:
        token = _token_auth(session)
        if token is None:
            return jsonify({'ok': False, 'error': 'Invalid or missing bearer '
                            'token'}), 401

        document = request.get_json(silent=True)
        if not isinstance(document, dict):
            return jsonify({'ok': False,
                            'error': 'Body must be a CodeSentinel JSON report'}), 400

        name = (request.headers.get('X-Project-Name')
                or (document.get('summary') or {}).get('project') or '').strip()
        if not name:
            return jsonify({'ok': False, 'error':
                            'Provide the project name via the X-Project-Name '
                            'header (or summary.project in the report)'}), 400

        project = session.query(CodeProject).filter(
            func.lower(CodeProject.name) == name.lower()).first()
        if project is None:
            project = CodeProject(name=name, source_type='ci',
                                  source_ref=f'API token: {token.label}')
            session.add(project)
            session.flush()

        # Create the scan row first so the baseline lookup can exclude it and
        # the new-code gate compares against genuinely prior scans.
        scan = CodeScan(project_id=project.id, status='queued', trigger='api')
        session.add(scan)
        session.flush()

        baseline_scan_id, baseline_fingerprints = jobs.baseline_for(
            session, project.id, scan.id)
        try:
            payload = engine.payload_from_ci(
                document, jobs.triage_map(session, project.id),
                baseline_fingerprints=baseline_fingerprints,
                gate_mode=project.gate_mode or 'full',
                baseline_scan_id=baseline_scan_id)
        except (ValueError, engine.CodeSentinelUnavailable) as exc:
            return jsonify({'ok': False, 'error': str(exc)}), 400

        jobs.store_payload(session, scan, payload)
        scan.status = 'completed'
        scan.started_at = scan.started_at or datetime.now()
        scan.finished_at = datetime.now()
        session.commit()

        return jsonify({
            'ok': True,
            'scan_id': scan.id,
            'project': project.name,
            'url': url_for('code_sentinel.scan_detail', scan_id=scan.id,
                           _external=True),
            'grade': scan.grade,
            'overall_score': scan.overall_score,
            'security_score': scan.security_score,
            'total_findings': scan.total_findings,
            'severity_totals': scan.severity_counts,
            'quality_gate': {
                'passed': bool(scan.gate_passed),
                'mode': scan.gate_mode or 'full',
                'reasons': json.loads(scan.gate_reasons or '[]'),
                'new_code': {
                    'baseline_scan_id': scan.baseline_scan_id,
                    'new_findings': scan.new_findings or 0,
                    'new_blocker': scan.new_blocker or 0,
                    'new_critical': scan.new_critical or 0,
                    'new_high': scan.new_high or 0,
                },
            },
        }), 201
    except Exception:
        session.rollback()
        logger.exception('CI ingest failed')
        return jsonify({'ok': False, 'error': 'Internal error while ingesting '
                        'the report'}), 500
    finally:
        session.close()
