"""
Background scan execution.

Scans are long-running and CPU-bound, so they NEVER run inside an HTTP
request: routes create a queued CodeScan row and hand the id to this
module's small thread pool. All job state lives in the database (status,
progress counters, log), so any web worker can serve the polling endpoint
regardless of which worker is running the scan.

Source preparation also lives here (it can be slow too):
  * upload - extract the stored zip into the project workspace
             (zip-slip and zip-bomb protected)
  * files  - scan the stored multi-file upload directory directly
"""

import logging
import os
import shutil
import stat
import time
import zipfile
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta

# `col == sql_true()` rather than `col.is_(True)`: SQLAlchemy renders
# the latter as `col IS 1`, which SQLite accepts and SQL SERVER REJECTS
# - T-SQL allows IS only with NULL. Both compile `== true()` to `= 1`.
from sqlalchemy import func, true as sql_true
from sqlalchemy.orm import joinedload

from database import get_db_session
from . import config, engine
from .models import CodeFinding, CodeProject, CodeScan, CodeTriage

logger = logging.getLogger(__name__)

_executor = ThreadPoolExecutor(
    max_workers=config.SCAN_WORKERS,
    thread_name_prefix='codesentinel-scan',
)


def enqueue_scan(scan_id: int) -> None:
    """Submit a queued CodeScan to the background pool."""
    _executor.submit(_run_job, scan_id)


# ---------------------------------------------------------------------------
# Orphan recovery
#
# A job thread lives inside a web worker process. When that process goes away
# mid-scan - under IIS the FastCGI instance is recycled on activityTimeout /
# idleTimeout / a scheduled app-pool recycle, and a background thread generates
# no FastCGI activity of its own to keep it alive - the thread dies silently
# and its CodeScan row is left at 'queued'/'running' for good. The scan page
# then polls a status that will never change again.
#
# So the job stamps a heartbeat as it works, and any request into the module
# opportunistically fails the scans that have stopped beating.
# ---------------------------------------------------------------------------

_last_reap = [0.0]


def _beat(scan: CodeScan) -> None:
    """Mark the scan as still alive (the caller commits)."""
    scan.heartbeat_at = datetime.now()


def reap_orphaned_scans(session, force: bool = False) -> int:
    """
    Fail every scan whose worker has stopped beating; returns the count.

    Liveness is CodeScan.heartbeat_at, stamped by the job thread on every log
    line and roughly once a second while analysing. No beat for
    HEARTBEAT_STALE_MINUTES means nothing is driving the scan any more. Rows
    that never got to beat fall back to started_at and then created_at, so a
    scan orphaned while still QUEUED is recovered too.

    Safe to call from any worker: the query only ever touches rows that are
    still queued/running AND long past their last beat, so it can never
    clobber a live scan running in a sibling process. Throttled to once a
    minute per process.
    """
    now = time.monotonic()
    if not force and _last_reap[0] and now - _last_reap[0] < 60:
        return 0
    _last_reap[0] = now

    cutoff = datetime.now() - timedelta(minutes=config.HEARTBEAT_STALE_MINUTES)
    orphaned = session.query(CodeScan).filter(
        CodeScan.status.in_(('queued', 'running')),
        func.coalesce(CodeScan.heartbeat_at, CodeScan.started_at,
                      CodeScan.created_at) < cutoff,
    ).all()
    if not orphaned:
        return 0

    for scan in orphaned:
        scan.status = 'failed'
        scan.finished_at = datetime.now()
        scan.current_file = None
        scan.error = (
            'The scan worker stopped responding - no progress for over '
            f'{config.HEARTBEAT_STALE_MINUTES} minutes. The web worker process '
            'was most likely recycled while the scan was running. Re-run the '
            'scan; if it keeps happening, raise the IIS application pool idle '
            'time-out or check the Code Sentinel log for the underlying error.'
        )
    session.commit()
    logger.warning('Code Sentinel reaper: failed %d orphaned scan(s) (%s)',
                   len(orphaned), ', '.join(str(s.id) for s in orphaned))
    return len(orphaned)


# ---------------------------------------------------------------------------
# Storage housekeeping
#
# Uploaded sources (zip archives and multi-file folders) are kept so re-scans
# work, but disk space is bounded: anything older than UPLOAD_RETENTION_DAYS
# is auto-deleted. The project and its scan history are untouched - only the
# re-scan source disappears until it is uploaded again. Runs opportunistically
# (page loads / new scans), throttled to once per hour per process.
# ---------------------------------------------------------------------------

_last_purge = [0.0]


def purge_old_uploads(session, force: bool = False) -> int:
    """Delete expired uploads/workspaces/exports; returns uploads removed."""
    now = time.monotonic()
    if not force and _last_purge[0] and now - _last_purge[0] < 3600:
        return 0
    _last_purge[0] = now
    config.ensure_dirs()

    # Never purge a source that a queued/running scan may be reading.
    active = session.query(CodeProject).join(CodeScan).filter(
        CodeScan.status.in_(('queued', 'running'))).all()
    protected_refs = {os.path.abspath(config.source_path(p.source_ref))
                      for p in active if p.source_ref}
    protected_workspaces = {str(p.id) for p in active}

    removed = 0
    cutoff = time.time() - config.UPLOAD_RETENTION_DAYS * 86400
    for entry in _expired_entries(config.UPLOADS_DIR, cutoff):
        if os.path.abspath(entry) in protected_refs:
            continue
        if _remove_entry(entry):
            removed += 1
    for entry in _expired_entries(config.WORKSPACES_DIR, cutoff):
        if os.path.basename(entry) in protected_workspaces:
            continue
        _remove_entry(entry)

    export_cutoff = time.time() - config.EXPORT_RETENTION_DAYS * 86400
    for entry in _expired_entries(config.EXPORTS_DIR, export_cutoff):
        _remove_entry(entry)

    if removed:
        logger.info('Code Sentinel retention: removed %d stored upload(s) '
                    'older than %d days', removed, config.UPLOAD_RETENTION_DAYS)
    return removed


def _expired_entries(directory: str, cutoff: float) -> list:
    entries = []
    try:
        names = os.listdir(directory)
    except OSError:
        return entries
    for name in names:
        path = os.path.join(directory, name)
        try:
            if _entry_mtime(path) < cutoff:
                entries.append(path)
        except OSError:
            continue
    return entries


def _entry_mtime(path: str) -> float:
    """Newest mtime inside a directory tree (a re-scan touches nothing, so
    the newest file decides the age), or the file's own mtime."""
    if os.path.isfile(path):
        return os.path.getmtime(path)
    newest = os.path.getmtime(path)
    for root, _dirs, files in os.walk(path):
        for name in files:
            try:
                newest = max(newest, os.path.getmtime(os.path.join(root, name)))
            except OSError:
                continue
    return newest


def _remove_entry(path: str) -> bool:
    try:
        if os.path.isfile(path):
            os.remove(path)
        else:
            _clear_workspace(path)
        return True
    except OSError:
        logger.warning('Retention purge could not remove %s', path)
        return False


# ---------------------------------------------------------------------------
# Source preparation
# ---------------------------------------------------------------------------

def project_workspace(project_id: int) -> str:
    """Stable per-project workspace so the incremental cache stays warm."""
    return os.path.join(config.WORKSPACES_DIR, str(project_id))


def safe_extract_zip(zip_path: str, destination: str,
                     max_bytes: int = None) -> int:
    """
    Extract a zip defensively; returns the number of files written.

    * Rejects absolute member names and any path escaping the destination
      (zip-slip).
    * Enforces a total decompressed-size budget (zip-bomb) against the bytes
      ACTUALLY written, not the size the archive declares for itself - a
      crafted archive can under-report member.file_size, so the declared
      total is only a fast pre-check, never the real bound.
    """
    max_bytes = max_bytes or config.MAX_EXTRACTED_BYTES
    limit_mb = max_bytes // (1024 * 1024)
    base = os.path.abspath(destination)
    os.makedirs(base, exist_ok=True)
    written = 0
    total = 0
    with zipfile.ZipFile(zip_path) as archive:
        for member in archive.infolist():
            name = member.filename
            if not name or name.endswith('/'):
                continue
            # Normalise and confine inside the destination directory.
            target = os.path.abspath(os.path.join(base, name))
            try:
                if os.path.commonpath([base, target]) != base:
                    raise ValueError(f'Unsafe path in archive: {name}')
            except ValueError as exc:
                raise ValueError(f'Unsafe path in archive: {name}') from exc
            # Fast reject on the declared size before decompressing anything.
            if total + member.file_size > max_bytes:
                raise ValueError(
                    f'Archive expands beyond the {limit_mb} MB extraction limit.'
                )
            os.makedirs(os.path.dirname(target), exist_ok=True)
            total = _copy_within_budget(archive, member, target, total, max_bytes)
            written += 1
    if written == 0:
        raise ValueError('The archive contains no files.')
    return written


#: Streaming copy chunk. Small enough that a lying member can overshoot the
#: budget by at most this much before the running total trips the guard.
_EXTRACT_CHUNK_BYTES = 1024 * 1024


def _copy_within_budget(archive, member, target: str, total: int,
                        max_bytes: int) -> int:
    """
    Stream one archive member to `target`, aborting the moment the cumulative
    decompressed byte count (across all members) exceeds `max_bytes`. Returns
    the new running total. On breach the partial output file is removed and a
    ValueError is raised, so a zip bomb that lies about its uncompressed size
    still cannot fill the disk.
    """
    limit_mb = max_bytes // (1024 * 1024)
    with archive.open(member) as src, open(target, 'wb') as dst:
        while True:
            chunk = src.read(_EXTRACT_CHUNK_BYTES)
            if not chunk:
                return total
            total += len(chunk)
            if total > max_bytes:
                dst.close()
                try:
                    os.remove(target)
                except OSError:
                    pass
                raise ValueError(
                    f'Archive expands beyond the {limit_mb} MB extraction limit.'
                )
            dst.write(chunk)


def _clear_workspace(path: str) -> None:
    def _on_error(func, target, _exc):
        # git objects are read-only on Windows; make writable then retry.
        os.chmod(target, stat.S_IWRITE)
        func(target)
    if os.path.isdir(path):
        shutil.rmtree(path, onerror=_on_error)


def _prepare_source(scan: CodeScan, project: CodeProject, emit) -> str:
    """Materialise the project's source and return the directory to scan."""
    workspace = project_workspace(project.id)

    if project.source_type == 'upload':
        zip_path = config.source_path(project.source_ref or '')
        if not os.path.isfile(zip_path):
            raise ValueError('The uploaded archive is no longer on the server; '
                             'upload it again.')
        _clear_workspace(workspace)
        emit(f'Extracting {os.path.basename(zip_path)} ...')
        count = safe_extract_zip(zip_path, workspace)
        emit(f'Extracted {count} file(s)')
        return workspace

    if project.source_type == 'files':
        # Multi-file uploads are stored as a directory; scan it in place -
        # the stable path keeps the incremental cache warm across re-scans.
        source_dir = config.source_path(project.source_ref or '')
        if not os.path.isdir(source_dir):
            raise ValueError('The uploaded files are no longer on the server; '
                             'upload them again.')
        count = sum(len(files) for _, _, files in os.walk(source_dir))
        emit(f'Scanning {count} uploaded file(s)')
        return source_dir

    raise ValueError(f'Project source type "{project.source_type}" cannot be '
                     'scanned from the web UI.')


# ---------------------------------------------------------------------------
# The job
# ---------------------------------------------------------------------------

def triage_map(session, project_id: int) -> dict:
    return {
        row.fingerprint: row.status
        for row in session.query(CodeTriage).filter_by(project_id=project_id)
    }


def triage_detail_map(session, project_id: int) -> dict:
    """
    fingerprint -> {status, note, by, at} for every triage decision - the
    reason and attribution the quality-gate waiver notes are built from.
    """
    details = {}
    rows = (session.query(CodeTriage)
            .options(joinedload(CodeTriage.decided_by_user))
            .filter_by(project_id=project_id))
    for row in rows:
        details[row.fingerprint] = {
            'status': row.status,
            'note': row.note or '',
            'by': _user_display(row.decided_by_user),
            'at': row.decided_at.strftime('%Y-%m-%d') if row.decided_at else '',
        }
    return details


def _user_display(user) -> str:
    """Reviewer name for a waiver note: 'First Last', else username."""
    if user is None:
        return ''
    full = f"{user.firstname or ''} {user.lastname or ''}".strip()
    return full or (user.username or '')


def waiver_notes_for_scan(session, scan) -> list:
    """
    Quality-gate waiver notes for one scan, from the CURRENT triage state -
    so a decision made after the scan is reflected immediately. One line per
    waived gate-blocking finding (BLOCKER/CRITICAL/HIGH) plus a summary line
    for lower-severity waivers. Shares the engine's note formatter.
    """
    details = triage_detail_map(session, scan.project_id)
    if not details:
        return []
    rows = (session.query(CodeFinding)
            .filter(CodeFinding.scan_id == scan.id,
                    CodeFinding.fingerprint.in_(list(details)))
            .all())
    notes, minor = [], 0
    for row in rows:
        detail = details.get(row.fingerprint)
        if not detail or detail.get('status') not in ('FALSE_POSITIVE',
                                                       'ACCEPTED_RISK'):
            continue
        if row.severity not in engine.GATE_SEVERITIES:
            minor += 1
            continue
        notes.append(engine.format_waiver_note(
            row.severity, row.category, row.rule_id,
            f"{row.file_path}:{row.line}", detail))
    notes.sort()
    if minor:
        notes.append(engine.minor_waiver_summary(minor))
    return notes


_WAIVER_DECISION = {'FALSE_POSITIVE': 'False positive',
                    'ACCEPTED_RISK': 'Accepted risk'}


def waiver_details_for_scan(session, scan) -> list:
    """
    Structured detail of EVERY waived finding in one scan (any severity), from
    the CURRENT triage state - the rows the scan page's and report's Waived
    Findings table is rendered from. Each item is a dict with location,
    severity, rule_id, category, decision, reason, reviewer.
    """
    details = triage_detail_map(session, scan.project_id)
    if not details:
        return []
    rows = (session.query(CodeFinding)
            .filter(CodeFinding.scan_id == scan.id,
                    CodeFinding.fingerprint.in_(list(details)))
            .all())
    order = {name: i for i, name in enumerate(
        ['BLOCKER', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'])}
    out = []
    for row in rows:
        detail = details.get(row.fingerprint)
        decision = _WAIVER_DECISION.get(detail.get('status')) if detail else None
        if decision is None:
            continue
        out.append({
            'location': f"{row.file_path}:{row.line}",
            'severity': row.severity,
            'rule_id': row.rule_id,
            'category': row.category,
            'decision': decision,
            'reason': (detail.get('note') or '').strip(),
            'reviewer': engine._attribution(detail),
        })
    out.sort(key=lambda w: (order.get(w['severity'], 9), w['location']))
    return out


def baseline_for(session, project_id: int, before_scan_id: int):
    """
    Pick the baseline scan for a new-code comparison and return
    ``(baseline_scan_id, baseline_fingerprints)`` - ``(None, None)`` for the
    project's very first scan (in which case every finding counts as new).

    Preference: the most recent completed scan BEFORE this one that PASSED its
    gate - a known-good reference to hold new code against. If none ever passed,
    fall back to the most recent completed scan so the comparison is still
    against real prior state rather than nothing.
    """
    completed = session.query(CodeScan).filter(
        CodeScan.project_id == project_id,
        CodeScan.status == 'completed',
        CodeScan.id < before_scan_id,
    )
    baseline = (completed.filter(CodeScan.gate_passed == sql_true())
                .order_by(CodeScan.id.desc()).first()
                or completed.order_by(CodeScan.id.desc()).first())
    if baseline is None:
        return None, None
    fingerprints = {
        row.fingerprint
        for row in session.query(CodeFinding.fingerprint)
        .filter(CodeFinding.scan_id == baseline.id)
    }
    return baseline.id, fingerprints


def store_payload(session, scan: CodeScan, payload) -> None:
    """Write the summary columns, findings and result JSON for one scan."""
    for key, value in payload.summary.items():
        setattr(scan, key, value)

    result_name = f'scan_{scan.id}.json'
    config.ensure_dirs()
    import json as _json
    with open(os.path.join(config.RESULTS_DIR, result_name), 'w',
              encoding='utf-8') as handle:
        _json.dump(payload.result_document, handle, ensure_ascii=False)
    scan.result_file = result_name

    if payload.finding_rows:
        rows = [dict(row, scan_id=scan.id) for row in payload.finding_rows]
        session.bulk_insert_mappings(CodeFinding, rows)


def _run_job(scan_id: int) -> None:
    session = get_db_session()
    log_lines = []
    try:
        scan = session.query(CodeScan).filter_by(id=scan_id).first()
        if scan is None or scan.status not in ('queued', 'running'):
            return
        project = session.query(CodeProject).filter_by(id=scan.project_id).first()

        def emit(message: str) -> None:
            log_lines.append(f'{datetime.now().strftime("%H:%M:%S")}  {message}')
            scan.log = '\n'.join(log_lines)
            _beat(scan)
            session.commit()

        scan.status = 'running'
        scan.started_at = datetime.now()
        _beat(scan)
        session.commit()

        source_root = _prepare_source(scan, project, emit)

        last_flush = [0.0]

        def progress(done: int, total: int, name: str) -> None:
            # Throttle DB writes: at most ~1 update/second (plus the final one).
            # This doubles as the liveness heartbeat for the reaper.
            now = time.monotonic()
            if done == total or now - last_flush[0] >= 1.0:
                last_flush[0] = now
                scan.progress_done = done
                scan.progress_total = total
                scan.current_file = name[:400]
                _beat(scan)
                session.commit()

        baseline_scan_id, baseline_fingerprints = baseline_for(
            session, project.id, scan.id)
        gate_mode = project.gate_mode or 'full'
        if gate_mode == 'new':
            emit('Gate scope: NEW CODE only'
                 + (f' (baseline scan #{baseline_scan_id})'
                    if baseline_scan_id else ' (first scan - all code is new)'))

        payload = engine.run_scan(
            source_root,
            triage_statuses=triage_map(session, project.id),
            progress=progress,
            log=emit,
            baseline_fingerprints=baseline_fingerprints,
            gate_mode=gate_mode,
            baseline_scan_id=baseline_scan_id,
        )

        store_payload(session, scan, payload)
        scan.status = 'completed'
        scan.finished_at = datetime.now()
        scan.current_file = None
        session.commit()
        logger.info('Code scan #%s (%s) completed: grade %s, gate %s',
                    scan.id, project.name, scan.grade,
                    'PASSED' if scan.gate_passed else 'FAILED')

    except Exception as exc:  # noqa: BLE001 - job boundary, report everything
        logger.exception('Code scan #%s failed', scan_id)
        try:
            session.rollback()
            scan = session.query(CodeScan).filter_by(id=scan_id).first()
            if scan is not None:
                scan.status = 'failed'
                scan.finished_at = datetime.now()
                scan.error = str(exc)
                if log_lines:
                    scan.log = '\n'.join(log_lines)
                session.commit()
        except Exception:
            logger.exception('Could not record failure for scan #%s', scan_id)
    finally:
        session.close()
