"""
Code Sentinel scan -> professional NPg-branded Excel workbook.

Replaces the engine's plain Excel exporter for downloads from this web app.
Same three sheets and the same columns (Summary / Findings / File metrics),
restyled to the house report style used by the Project Management module:
brand-red title bands, dark-red column headers, bordered + banded rows,
severity/gate chips, freeze panes, autofilter and print-ready page setup.
"""

from __future__ import annotations

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.page import PageMargins
from openpyxl.worksheet.properties import PageSetupProperties

# Brand palette - the HLD / AppAssist NPg red family (matches the PDF export).
BRAND    = "9F1C33"   # title bands & section headers
BRAND_DK = "7E1628"   # subtitles & column-header rows
BAND     = "F1F5F9"   # zebra banding
BORDER   = "D7DEE7"
TEXT     = "1D293D"
MUTED    = "6B7280"

# Chip colours (fill, font)
GOOD = ("DCFCE7", "166534")
BAD  = ("FEE2E2", "991B1B")
WARN = ("FEF3C7", "92400E")
NEUT = ("E2E8F0", "1D293D")

_THIN = Side(style="thin", color=BORDER)
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

CENTER   = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT_TOP = Alignment(horizontal="left", vertical="top", wrap_text=True)


def _rating_colours():
    """Grade/rating letter -> strong hex, from the engine (best effort)."""
    try:
        from codesentinel.domain.scoring import RATING_COLOURS
        return {k: v.lstrip('#').upper() for k, v in RATING_COLOURS.items()}
    except Exception:                                    # noqa: BLE001
        return {}


def _title_band(ws, title, subtitle, ncols):
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    c = ws.cell(row=1, column=1, value=title)
    c.font = Font(name="Calibri", size=15, bold=True, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=BRAND)
    c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[1].height = 30

    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
    s = ws.cell(row=2, column=1, value=subtitle)
    s.font = Font(name="Calibri", size=10, italic=True, color="FFFFFF")
    s.fill = PatternFill("solid", fgColor=BRAND_DK)
    s.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[2].height = 20
    return 4


def _section_header(ws, row, label, ncols):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    h = ws.cell(row=row, column=1, value=label)
    h.font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    h.fill = PatternFill("solid", fgColor=BRAND)
    h.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row].height = 22
    return row + 1


def _header_row(ws, row, headers):
    for col, label in enumerate(headers, start=1):
        cell = ws.cell(row=row, column=col, value=label)
        cell.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=BRAND_DK)
        cell.alignment = CENTER
        cell.border = _BORDER
    ws.row_dimensions[row].height = 26


def _autosize(ws, widths):
    for idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width


def _print_setup(ws, orientation="landscape", repeat_rows=None):
    ws.page_setup.orientation = orientation
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    ws.page_margins = PageMargins(left=0.4, right=0.4, top=0.5, bottom=0.55,
                                  header=0.2, footer=0.25)
    if repeat_rows:
        ws.print_title_rows = repeat_rows
    ws.oddFooter.left.text = "NPg AppAssist - Code Sentinel"
    ws.oddFooter.left.size = 8
    ws.oddFooter.left.color = MUTED
    ws.oddFooter.right.text = "Page &P of &N"
    ws.oddFooter.right.size = 8
    ws.oddFooter.right.color = MUTED


def _chip(cell, colours):
    fill, font_clr = colours
    cell.fill = PatternFill("solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=10, bold=True, color=font_clr)
    cell.alignment = CENTER
    cell.border = _BORDER


def _style_cell(cell, banded=False, center=False, bold=False):
    cell.font = Font(name="Calibri", size=10, bold=bold, color=TEXT)
    cell.alignment = CENTER if center else LEFT_TOP
    cell.border = _BORDER
    if banded:
        cell.fill = PatternFill("solid", fgColor=BAND)


def _empty_row(ws, row, ncols, message):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=message)
    c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
    c.alignment = CENTER


def _severity_chip(cell, severity):
    """Severity value cell tinted with the engine's severity colours."""
    tint = severity.tint_colour.lstrip('#').upper()
    strong = severity.hex_colour.lstrip('#').upper()
    _chip(cell, (tint, strong))


# ---------------------------------------------------------------------------
# Sheets
# ---------------------------------------------------------------------------

def _summary_sheet(wb: Workbook, context) -> None:
    ws = wb.active
    ws.title = "Summary"
    result = context.result
    scorecard = context.scorecard
    _autosize(ws, [28, 42, 18])
    row = _title_band(
        ws, f"Code Quality & Security Audit - {context.project_name}",
        f"Static analysis report - generated {context.generated_at:%d %b %Y %H:%M} - "
        f"{context.tool_name} v{context.tool_version}", 3)

    def field(label, value, *, chip=None, kpi=False):
        nonlocal row
        lc = ws.cell(row=row, column=1, value=label)
        lc.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        lc.fill = PatternFill("solid", fgColor=BRAND_DK)
        lc.alignment = LEFT_TOP
        lc.border = _BORDER
        vc = ws.cell(row=row, column=2, value=value if value not in (None, "") else "-")
        if chip:
            _chip(vc, chip)
            vc.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        else:
            vc.font = Font(name="Calibri", size=11 if kpi else 10, bold=kpi, color=TEXT)
            vc.alignment = LEFT_TOP
            vc.border = _BORDER
        ws.row_dimensions[row].height = 22
        row += 1

    row = _section_header(ws, row, "Report Details", 3)
    field("Project", context.project_name)
    field("Scan root", str(result.root))
    field("Generated", context.generated_at.strftime("%d %b %Y %H:%M:%S"))
    field("Tool", f"{context.tool_name} v{context.tool_version} (fully offline)")
    row += 1

    ratings = _rating_colours()
    row = _section_header(ws, row, "Scores & Quality Gate", 3)
    grade_hex = ratings.get(scorecard.grade)
    field("Overall grade", f"{scorecard.grade}  ({scorecard.overall}/100)",
          chip=(BAND, grade_hex) if grade_hex else None, kpi=True)
    field("Quality gate", context.gate.verdict,
          chip=GOOD if context.gate.passed else BAD)
    field("Security score", scorecard.security, kpi=True)
    field("Reliability score", scorecard.reliability, kpi=True)
    field("Maintainability score", scorecard.maintainability, kpi=True)
    field("Performance score", scorecard.performance, kpi=True)
    field("Maintainability rating",
          f"{scorecard.maintainability_rating} (A best - E worst)")
    field("Technical debt", scorecard.technical_debt)
    field("Risk level", scorecard.risk_level,
          chip=BAD if scorecard.risk_level in ("CRITICAL", "HIGH")
          else (WARN if scorecard.risk_level == "MEDIUM" else GOOD))
    row += 1

    row = _section_header(ws, row, "Scan Statistics", 3)
    field("Files scanned", len(result.analyses), kpi=True)
    field("Files from incremental cache", result.files_from_cache)
    field("Total lines", f"{result.total_lines:,}")
    field("Lines of code", f"{result.total_code_lines:,}")
    field("Total findings", result.total_findings, kpi=True)
    field("Suppressed by triage", result.suppressed_count)
    field("Duplication", f"{result.duplication_ratio:.1%}")
    field("Scan duration", f"{result.duration_seconds:.1f} s")
    row += 1

    severities = result.severity_totals()
    row = _section_header(ws, row, "Findings by Severity", 3)
    _header_row(ws, row, ["Severity", "Count", "Share"])
    row += 1
    if not severities:
        _empty_row(ws, row, 3, "No findings - every file passed all enabled checks.")
        row += 1
    else:
        total = sum(severities.values()) or 1
        for index, (severity, count) in enumerate(severities.items()):
            banded = index % 2 == 1
            _severity_chip(ws.cell(row=row, column=1, value=severity.value), severity)
            _style_cell(ws.cell(row=row, column=2, value=count),
                        banded=banded, center=True, bold=True)
            _style_cell(ws.cell(row=row, column=3, value=f"{count / total:.0%}"),
                        banded=banded, center=True)
            row += 1
        _style_cell(ws.cell(row=row, column=1, value="Total"), bold=True)
        _style_cell(ws.cell(row=row, column=2, value=sum(severities.values())),
                    center=True, bold=True)
        _style_cell(ws.cell(row=row, column=3, value="100%"), center=True, bold=True)
        row += 1

    if not context.gate.passed and context.gate.reasons:
        row += 1
        row = _section_header(ws, row, "Quality-Gate Failures", 3)
        for reason in context.gate.reasons:
            ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=3)
            c = ws.cell(row=row, column=1, value=f"X  {reason}")
            _chip(c, BAD)
            c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
            ws.row_dimensions[row].height = 20
            row += 1

    if context.gate.waivers:
        row += 1
        row = _section_header(ws, row, "Reviewer Waivers", 3)
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=3)
        c = ws.cell(row=row, column=1,
                    value=f"OK  {len(context.gate.waivers)} finding(s) waived "
                          f"(false-positive / accepted-risk) - see the "
                          f"'Waived Findings' sheet for the detail table.")
        _chip(c, GOOD)
        c.alignment = Alignment(horizontal="left", vertical="center",
                                indent=1, wrap_text=True)
        ws.row_dimensions[row].height = 20
        row += 1

    ws.sheet_view.showGridLines = False
    _print_setup(ws, orientation="portrait")


def _waived_sheet(wb: Workbook, context) -> None:
    """Detail table of reviewer-waived findings, with the reason each."""
    ws = wb.create_sheet("Waived Findings")
    headers = ["Location", "Severity", "Rule", "Category", "Decision",
               "Reason", "Reviewer"]
    _autosize(ws, [34, 10, 15, 18, 14, 55, 22])
    _title_band(ws, f"Waived Findings - {context.project_name}",
                "Findings a reviewer marked false-positive or accepted-risk, "
                "excluded from scores and the gate, with the reason recorded.",
                len(headers))
    _header_row(ws, 4, headers)

    row = 5
    for w in context.gate.waivers:
        banded = (row - 5) % 2 == 1
        values = [w.location, w.severity, w.rule_id, w.category, w.decision,
                  w.reason or "", w.reviewer or ""]
        for col, value in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=value)
            _style_cell(cell, banded=banded, center=col == 2)
        row += 1

    ws.freeze_panes = "A5"
    ws.auto_filter.ref = f"A4:{get_column_letter(len(headers))}{row - 1}"
    _print_setup(ws, repeat_rows="4:4")


def _findings_sheet(wb: Workbook, context) -> None:
    from codesentinel.domain.models import relative_to_root

    ws = wb.create_sheet("Findings")
    headers = ["File", "Line", "Severity", "Category", "Rule", "CWE", "OWASP",
               "Confidence", "Tool", "Message", "Remediation", "Code excerpt"]
    _autosize(ws, [38, 7, 12, 18, 15, 10, 13, 11, 10, 55, 50, 60])
    _title_band(ws, f"Findings - {context.project_name}",
                "Open findings after current triage, worst severity first per file. See Analysis Assurance for scope.",
                len(headers))
    _header_row(ws, 4, headers)

    row = 5
    any_findings = False
    for analysis in context.result.analyses:
        rel = relative_to_root(analysis.path, context.result.root)
        for finding in analysis.sorted_findings():
            any_findings = True
            banded = (row - 5) % 2 == 1
            values = [rel, finding.line, finding.severity.value, finding.category,
                      finding.rule_id, finding.cwe, finding.owasp,
                      finding.confidence, finding.tool, finding.message,
                      finding.remediation, finding.snippet]
            for col, value in enumerate(values, start=1):
                cell = ws.cell(row=row, column=col, value=value)
                if col == 3:
                    _severity_chip(cell, finding.severity)
                else:
                    _style_cell(cell, banded=banded, center=col in (2, 6, 8, 9))
            ws.row_dimensions[row].height = max(54, min(240, 14 * max(
                (len(str(value)) // 45 + str(value).count('\n') + 1) for value in values)))
            row += 1
    if not any_findings:
        _empty_row(ws, row, len(headers),
                   "No open findings recorded. Review the gate verdict and Analysis Assurance before release.")
        row += 1

    ws.freeze_panes = "A5"
    ws.auto_filter.ref = f"A4:{get_column_letter(len(headers))}{row - 1}"
    _print_setup(ws, repeat_rows="4:4")


def _metrics_sheet(wb: Workbook, context) -> None:
    from codesentinel.domain.models import relative_to_root

    ws = wb.create_sheet("File metrics")
    headers = ["File", "Language", "Total lines", "Code", "Comments", "Blank",
               "Complexity", "Functions", "Duplicated lines", "Findings"]
    _autosize(ws, [44, 13, 11, 10, 11, 9, 12, 11, 15, 10])
    _title_band(ws, f"File Metrics - {context.project_name}",
                "Per-file size, complexity and findings.", len(headers))
    _header_row(ws, 4, headers)

    row = 5
    for analysis in context.result.analyses:
        rel = relative_to_root(analysis.path, context.result.root)
        m = analysis.metrics
        banded = (row - 5) % 2 == 1
        values = [rel, analysis.language_id,
                  m.total_lines if m else 0, m.code_lines if m else 0,
                  m.comment_lines if m else 0, m.blank_lines if m else 0,
                  m.complexity if m else 0, m.functions if m else 0,
                  m.duplicated_lines if m else 0, analysis.total_issues]
        for col, value in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=value)
            _style_cell(cell, banded=banded, center=col > 2,
                        bold=(col == 10 and value > 0))
        row += 1
    if row == 5:
        _empty_row(ws, row, len(headers), "No files analysed.")
        row += 1

    ws.freeze_panes = "A5"
    ws.auto_filter.ref = f"A4:{get_column_letter(len(headers))}{row - 1}"
    _print_setup(ws, repeat_rows="4:4")


def _assurance_sheet(wb, context):
    from codesentinel.domain.assurance import language_assurance
    ws = wb.create_sheet("Analysis Assurance")
    _autosize(ws, [22, 14, 16, 16, 24, 65])
    row = _title_band(ws, "Analysis Assurance", context.gate_scope + " - " + context.gate.verdict, 6)
    for text in [context.evaluation_note,
                 "Scope: submitted files only. Static analysis does not measure test coverage or runtime security.",
                 "Rules-only languages have less analysis depth. Security scores describe detected findings."]:
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=6)
        cell=ws.cell(row, 1, text); _style_cell(cell); ws.row_dimensions[row].height=30; row+=1
    row+=1
    _header_row(ws, row, ["Language", "Files", "Code lines", "Security / 100", "Coverage", "Analyzer evidence / errors"])
    header=row; row+=1
    for item in language_assurance(context.result):
        values=[item['language'],item['files'],item['lines'],item['security'],item['coverage'],
                ', '.join(item['tools']) + f"; {item['errors']} file(s) with errors; {item['missing']} without evidence"]
        for col,value in enumerate(values,1):
            _style_cell(ws.cell(row,col,value),banded=row%2==0)
        ws.row_dimensions[row].height=44;row+=1
    ws.freeze_panes=f"A{header+1}"
    ws.auto_filter.ref=f"A{header}:F{max(header,row-1)}"
    ws.sheet_view.showGridLines=False
    _print_setup(ws, repeat_rows=f"{header}:{header}")


def build_scan_workbook(context, destination):
    """Write the branded workbook to `destination` and return the path."""
    wb = Workbook()
    _summary_sheet(wb, context)
    _assurance_sheet(wb, context)
    _findings_sheet(wb, context)
    if context.gate.waivers:
        _waived_sheet(wb, context)
    _metrics_sheet(wb, context)
    # Source code can begin with '='. Keep exported evidence as literal text,
    # never executable spreadsheet formulas.
    for sheet in wb:
        for row in sheet:
            for cell in row:
                if cell.data_type == 'f':
                    cell.data_type = 's'
    wb.save(destination)
    return destination
