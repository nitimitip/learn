"""
Code Sentinel database models.

The web module is the system of record for scan results: every scan's
summary, findings, and triage decisions live in the App Assist database so
dashboards, trend charts and role-based triage work like every other module.
The CodeSentinel package keeps only its own incremental file cache.

Severity / status vocabularies deliberately mirror the CodeSentinel domain
model (codesentinel.domain.models) so values round-trip without mapping.
"""

from datetime import datetime

from sqlalchemy import (
    Column, Integer, String, Text, DateTime, Boolean, Float,
    ForeignKey, UniqueConstraint, Index,
)
from sqlalchemy.orm import relationship

from database import Base

# Display order + colours mirror codesentinel.domain.models.Severity.
SEVERITIES = ['BLOCKER', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO']
SEVERITY_RANK = {name: rank for rank, name in enumerate(SEVERITIES)}
SEVERITY_COLORS = {
    'BLOCKER': '#581c87', 'CRITICAL': '#7f1d1d', 'HIGH': '#b91c1c',
    'MEDIUM': '#c2410c', 'LOW': '#a16207', 'INFO': '#1d4ed8',
}
SEVERITY_TINTS = {
    'BLOCKER': '#f3e8ff', 'CRITICAL': '#fee2e2', 'HIGH': '#fee2e2',
    'MEDIUM': '#ffedd5', 'LOW': '#fef3c7', 'INFO': '#dbeafe',
}
GRADE_COLORS = {
    'A+': '#15803d', 'A': '#15803d', 'B': '#65a30d', 'C': '#a16207',
    'D': '#c2410c', 'E': '#b91c1c', 'F': '#7f1d1d',
}

# Triage lifecycle (matches codesentinel IssueStatus; OPEN = no triage row).
TRIAGE_STATUSES = ['OPEN', 'FALSE_POSITIVE', 'ACCEPTED_RISK']
TRIAGE_LABELS = {
    'OPEN': 'Open',
    'FALSE_POSITIVE': 'False positive',
    'ACCEPTED_RISK': 'Accepted risk',
}

SCAN_STATUSES = ['queued', 'running', 'completed', 'failed']

# Release-gate scope, per project. 'full' gates on every open finding in the
# codebase; 'new' gates only on findings introduced since a baseline scan
# (new-code-only gating) so legacy debt never blocks a
# release that adds none.
GATE_MODES = {'full': 'Full codebase', 'new': 'New code only'}

# ---------------------------------------------------------------------------
# Scoring vocabulary - mirrors codesentinel.domain.scoring so the web UI can
# EXPLAIN a score without re-running the engine. Each dimension score starts
# at 100 and loses 2.5 points per weighted-finding-density point per 100 LOC;
# technical debt is the estimated remediation time summed over open findings.
# ---------------------------------------------------------------------------
SEVERITY_WEIGHTS = {'BLOCKER': 15, 'CRITICAL': 10, 'HIGH': 5,
                    'MEDIUM': 2, 'LOW': 1, 'INFO': 0}
DEBT_MINUTES = {'BLOCKER': 240, 'CRITICAL': 120, 'HIGH': 60,
                'MEDIUM': 30, 'LOW': 10, 'INFO': 2}
DEBT_PER_FINDING = {'BLOCKER': '4h', 'CRITICAL': '2h', 'HIGH': '1h',
                    'MEDIUM': '30m', 'LOW': '10m', 'INFO': '2m'}

#: Which finding categories feed each score card (RiskCategory groups).
SCORE_DIMENSIONS = {
    'Security': {'Destructive Operation', 'Injection', 'Hardcoded Secret',
                 'Insecure Configuration', 'Untrusted Code Execution',
                 'Weak Cryptography', 'Vulnerable Dependency'},
    'Reliability': {'Reliability'},
    'Maintainability': {'Maintainability', 'Coding Standards', 'General'},
    'Performance': {'Performance'},
}

# How a project's source is obtained for scanning. Web scans come from an
# upload (a zip archive or a multi-file selection); 'path' and 'git' are
# legacy values kept only so old rows still display a sensible label.
SOURCE_TYPES = {
    'upload': 'Zip upload',
    'files':  'File upload',
    'ci':     'CI pipeline',
    'path':   'Server path (legacy)',
    'git':    'Git repository (legacy)',
}


class CodeProject(Base):
    """One analysed codebase; scans accumulate under it for trend history."""

    __tablename__ = 'code_projects'

    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False, unique=True)
    source_type = Column(String(20), nullable=False)          # SOURCE_TYPES key
    source_ref = Column(String(1000))    # zip path / server dir / git URL / CI note
    gate_mode = Column(String(10), nullable=False, default='full')  # GATE_MODES key
    created_by = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=datetime.now)

    scans = relationship('CodeScan', back_populates='project',
                         cascade='all, delete-orphan',
                         order_by='CodeScan.id.desc()')
    creator = relationship('User', foreign_keys=[created_by])

    @property
    def latest_scan(self):
        return self.scans[0] if self.scans else None

    @property
    def latest_completed_scan(self):
        for scan in self.scans:
            if scan.status == 'completed':
                return scan
        return None

    @property
    def rescannable(self):
        """Only uploaded sources can be re-scanned from the web UI; CI
        projects are re-scanned from the pipeline."""
        return self.source_type in ('upload', 'files')


class CodeScan(Base):
    """One scan run: lifecycle, progress, and the summary scorecard."""

    __tablename__ = 'code_scans'

    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey('code_projects.id'), nullable=False,
                        index=True)
    status = Column(String(20), nullable=False, default='queued')  # SCAN_STATUSES
    trigger = Column(String(10), nullable=False, default='web')    # web | api
    triggered_by = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=datetime.now)
    started_at = Column(DateTime)
    finished_at = Column(DateTime)

    # Live progress (polled by the scan page while running).
    progress_done = Column(Integer, default=0)
    progress_total = Column(Integer, default=0)
    current_file = Column(String(400))
    log = Column(Text)
    error = Column(Text)

    # Liveness. The job thread stamps this every time it makes progress, so a
    # scan whose worker died (IIS recycled the FastCGI instance mid-scan) can
    # be told apart from one that is simply slow: no heartbeat for
    # config.HEARTBEAT_STALE_MINUTES means nobody is driving it any more, and
    # jobs.reap_orphaned_scans() marks it failed. NULL on rows that predate
    # this column and on queued scans that have not started yet - the reaper
    # falls back to started_at, then created_at.
    heartbeat_at = Column(DateTime)

    # Result summary (populated on completion; mirrors the ScoreCard).
    files_scanned = Column(Integer, default=0)
    files_cached = Column(Integer, default=0)
    total_lines = Column(Integer, default=0)
    code_lines = Column(Integer, default=0)
    total_findings = Column(Integer, default=0)
    suppressed_findings = Column(Integer, default=0)
    blocker = Column(Integer, default=0)
    critical = Column(Integer, default=0)
    high = Column(Integer, default=0)
    medium = Column(Integer, default=0)
    low = Column(Integer, default=0)
    info = Column(Integer, default=0)
    duplication = Column(Float, default=0.0)
    security_score = Column(Integer)
    reliability_score = Column(Integer)
    maintainability_score = Column(Integer)
    performance_score = Column(Integer)
    overall_score = Column(Integer)
    grade = Column(String(3))
    maintainability_rating = Column(String(2))
    risk_level = Column(String(10))
    debt_minutes = Column(Integer, default=0)
    gate_passed = Column(Boolean)
    gate_reasons = Column(Text)                 # JSON list of failure reasons

    # New-code gate (new-code-only gating): the mode this scan was gated under,
    # the baseline scan it was compared against, and the count of findings NEW
    # since that baseline (broken out by the gate-blocking severities).
    gate_mode = Column(String(10), nullable=False, default='full')  # GATE_MODES key
    baseline_scan_id = Column(Integer)          # reference scan (NULL = first scan)
    new_blocker = Column(Integer, default=0)
    new_critical = Column(Integer, default=0)
    new_high = Column(Integer, default=0)
    new_findings = Column(Integer, default=0)   # total new since baseline

    # Stored full-result JSON (relative to RESULTS_DIR) used for re-exports.
    result_file = Column(String(300))

    project = relationship('CodeProject', back_populates='scans')
    findings = relationship('CodeFinding', back_populates='scan',
                            cascade='all, delete-orphan')
    triggered_by_user = relationship('User', foreign_keys=[triggered_by])

    @property
    def severity_counts(self):
        return {
            'BLOCKER': self.blocker or 0, 'CRITICAL': self.critical or 0,
            'HIGH': self.high or 0, 'MEDIUM': self.medium or 0,
            'LOW': self.low or 0, 'INFO': self.info or 0,
        }

    @property
    def new_gate_counts(self):
        """New-since-baseline counts for the gate-blocking severities."""
        return {
            'BLOCKER': self.new_blocker or 0, 'CRITICAL': self.new_critical or 0,
            'HIGH': self.new_high or 0,
        }

    @property
    def is_new_code_gate(self):
        return (self.gate_mode or 'full') == 'new'

    @property
    def duration_seconds(self):
        if self.started_at and self.finished_at:
            return (self.finished_at - self.started_at).total_seconds()
        return None

    @property
    def debt_display(self):
        """Human-readable technical debt: '3d 4h', '2h 30m', '45m'."""
        minutes = self.debt_minutes or 0
        if minutes < 60:
            return f'{minutes}m'
        hours, mins = divmod(minutes, 60)
        if hours < 8:
            return f'{hours}h {mins}m' if mins else f'{hours}h'
        days, hours = divmod(hours, 8)   # 8-hour working days
        return f'{days}d {hours}h' if hours else f'{days}d'


class CodeFinding(Base):
    """One finding of one scan (all findings are kept, including triaged)."""

    __tablename__ = 'code_findings'
    __table_args__ = (
        Index('idx_code_findings_scan_sev', 'scan_id', 'severity'),
    )

    id = Column(Integer, primary_key=True)
    scan_id = Column(Integer, ForeignKey('code_scans.id'), nullable=False,
                     index=True)
    fingerprint = Column(String(64), nullable=False, index=True)
    file_path = Column(String(600), nullable=False)
    line = Column(Integer, default=0)
    tool = Column(String(60))
    rule_id = Column(String(60))
    severity = Column(String(10), nullable=False)
    category = Column(String(60))
    cwe = Column(String(30))
    owasp = Column(String(60))
    confidence = Column(String(10))
    message = Column(Text)
    remediation = Column(Text)
    snippet = Column(Text)
    # True when this finding was absent from the scan's baseline (new code).
    # Defaults True so first-scan findings and legacy rows read as new.
    is_new = Column(Boolean, nullable=False, default=True)

    scan = relationship('CodeScan', back_populates='findings')


class CodeTriage(Base):
    """
    A triage decision (false positive / accepted risk), keyed by the
    finding's stable fingerprint so it survives across scans - the same
    mechanism the CodeSentinel desktop app uses, plus user attribution.
    """

    __tablename__ = 'code_triage'
    __table_args__ = (
        UniqueConstraint('project_id', 'fingerprint', name='uq_code_triage'),
    )

    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey('code_projects.id'), nullable=False,
                        index=True)
    fingerprint = Column(String(64), nullable=False)
    status = Column(String(20), nullable=False)     # FALSE_POSITIVE | ACCEPTED_RISK
    note = Column(Text)
    decided_by = Column(Integer, ForeignKey('users.id'))
    decided_at = Column(DateTime, default=datetime.now)

    decided_by_user = relationship('User', foreign_keys=[decided_by])


class CodeApiToken(Base):
    """
    Bearer token for the CI ingest API. Only a SHA-256 hash is stored; the
    clear token is shown once at creation time.
    """

    __tablename__ = 'code_api_tokens'

    id = Column(Integer, primary_key=True)
    label = Column(String(120), nullable=False)
    token_hash = Column(String(64), nullable=False, unique=True)
    token_prefix = Column(String(12), nullable=False)   # display hint only
    is_active = Column(Boolean, nullable=False, default=True)
    created_by = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=datetime.now)
    last_used_at = Column(DateTime)

    creator = relationship('User', foreign_keys=[created_by])
