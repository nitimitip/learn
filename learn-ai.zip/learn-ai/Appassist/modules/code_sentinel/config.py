"""
Code Sentinel module configuration.

The web module does NOT re-implement the analyser: it imports the existing
CodeSentinel package (the same engine the desktop GUI and the
`python -m codesentinel scan` CLI use) as a library. This file owns the two
pieces of wiring that make that possible:

  * where the CodeSentinel source tree lives (CODESENTINEL_SRC), and
  * where its private data (incremental cache, custom rule packs, plugins)
    is kept when running inside App Assist (CODESENTINEL_HOME).

Everything else (upload sizes, workspace layout) is plain module config.
"""

import os

# App Assist root (.../appassist)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ---------------------------------------------------------------------------
# CodeSentinel package location.
# Default: the engine is VENDORED inside this module at
# `modules/code_sentinel/engine/codesentinel`, so App Assist is fully
# self-contained and needs no sibling `code_checker` checkout in production.
# Override with the CODESENTINEL_SRC environment variable to point at a
# different directory that CONTAINS the `codesentinel` package (e.g. a shared
# checkout during development).
# ---------------------------------------------------------------------------
CODESENTINEL_SRC = os.environ.get(
    'CODESENTINEL_SRC',
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'engine'),
)

# ---------------------------------------------------------------------------
# CodeSentinel private data directory (incremental scan cache, user rule
# packs, plugins). Kept inside the app's data folder so the server install
# is self-contained; override with CODESENTINEL_HOME if needed.
#
# Custom/override rule packs are loaded from  <project>/data/codesentinel/rules
# (this dir + "/rules"); drop *.json packs there to add or re-tune rules on top
# of the built-ins that ship inside engine/codesentinel/rules/packs.
# ---------------------------------------------------------------------------
CODESENTINEL_HOME = os.environ.get(
    'CODESENTINEL_HOME',
    os.path.join(BASE_DIR, 'data', 'codesentinel'),
)

# ---------------------------------------------------------------------------
# Module storage (uploaded archives, extracted workspaces, stored results).
#
# PRODUCTION: point CODESENTINEL_STORAGE_DIR at a directory OUTSIDE the web
# root (e.g. E:\AppData\code_sentinel). This module's whole purpose is to
# accept source code from users, and code inside the IIS document root is one
# config edit away from being served: today only the hiddenSegments /
# fileExtensions denials in web.config stop IIS handing back an uploaded .py.
# Keeping the files off the document root removes that class of mistake, and
# it also keeps user uploads clear of anything watching the app directory
# (wfastcgi's restart watcher recycles the worker on any .py write under the
# site root - see WSGI_RESTART_FILE_REGEX in web.config).
#
# The default stays inside the app so a fresh checkout runs with no setup.
# The IIS application pool identity needs read/write on whatever you choose.
# ---------------------------------------------------------------------------
STORAGE_DIR = os.environ.get(
    'CODESENTINEL_STORAGE_DIR',
    os.path.join(BASE_DIR, 'secure_uploads', 'code_sentinel'),
)
UPLOADS_DIR = os.path.join(STORAGE_DIR, 'uploads')          # original .zip files
WORKSPACES_DIR = os.path.join(STORAGE_DIR, 'workspaces')    # extracted / cloned source
RESULTS_DIR = os.path.join(STORAGE_DIR, 'results')          # full scan-result JSON
EXPORTS_DIR = os.path.join(STORAGE_DIR, 'exports')          # generated report files

# Zip uploads: hard cap enforced per-request in main_app.py, and re-checked
# while extracting (total decompressed size) to stop zip bombs.
MAX_CONTENT_LENGTH = int(os.environ.get('CODESENTINEL_MAX_UPLOAD_MB', '200')) * 1024 * 1024
MAX_EXTRACTED_BYTES = int(os.environ.get('CODESENTINEL_MAX_EXTRACT_MB', '1024')) * 1024 * 1024

# Retention for stored uploads (zip archives / multi-file folders). Older
# sources are auto-deleted to keep disk usage bounded; the project and its
# scan history remain - only the re-scan source is gone until re-uploaded.
UPLOAD_RETENTION_DAYS = int(os.environ.get('CODESENTINEL_UPLOAD_RETENTION_DAYS', '30'))

# Generated report downloads are one-shot; purge them much sooner.
EXPORT_RETENTION_DAYS = int(os.environ.get('CODESENTINEL_EXPORT_RETENTION_DAYS', '3'))

# Background scan workers for THIS web process. Scans are CPU-bound and each
# one already saturates a core, so 1 is right for almost every install.
SCAN_WORKERS = int(os.environ.get('CODESENTINEL_SCAN_WORKERS', '1'))

# Analysis parallelism INSIDE one scan. The engine can fan a large scan out
# across a ProcessPoolExecutor, which is right for the desktop GUI and the CLI
# but NOT for a web worker: child processes spawned from an IIS/wfastcgi worker
# are unreliable, and a child that never bootstraps leaves the scan wedged at
# "running" forever (see engine/__init__._apply_execution_policy). Web scans
# therefore run serially in the job thread. Opt back in only on a host that can
# safely spawn children (e.g. waitress run as a Windows service).
SCAN_PARALLEL = os.environ.get('CODESENTINEL_PARALLEL', '0') == '1'

# Liveness. A running scan stamps CodeScan.heartbeat_at every time it makes
# progress (roughly once a second while analysing). A queued/running scan that
# has not beaten for this long has lost its worker - the IIS FastCGI instance
# was recycled mid-scan and the job thread went with it - so the reaper marks
# it failed instead of leaving it "running" forever.
#
# The bound to respect is the longest gap between two beats in a HEALTHY scan:
# zip extraction, file discovery, and the post-analysis duplication/scoring
# pass each run without beating. 15 minutes clears those by a wide margin on
# any codebase this module accepts (200 MB zip cap).
HEARTBEAT_STALE_MINUTES = int(
    os.environ.get('CODESENTINEL_HEARTBEAT_STALE_MINUTES', '15'))

# Backstop for the reaper: a scan still marked running after this long is shown
# as stale on the scan page with a manual "Mark failed" button, in case the
# reaper never ran (e.g. nobody loaded a Code Sentinel page since the recycle).
STALE_RUNNING_HOURS = int(os.environ.get('CODESENTINEL_STALE_HOURS', '6'))


def ensure_dirs() -> None:
    for path in (CODESENTINEL_HOME, UPLOADS_DIR, WORKSPACES_DIR,
                 RESULTS_DIR, EXPORTS_DIR):
        os.makedirs(path, exist_ok=True)


def source_path(source_ref: str) -> str:
    """
    Absolute path of a project's stored upload (the zip file, or the folder a
    multi-file upload was saved into).

    CodeProject.source_ref holds the entry NAME inside UPLOADS_DIR, never an
    absolute path, so STORAGE_DIR can move without rewriting the database.

    Rows written before that change DO hold an absolute path into the old
    location. They are honoured while that path still resolves; once the
    folder has been moved, the same basename is looked up under the current
    UPLOADS_DIR instead - so relocating the storage is a plain folder move
    with no data migration and no broken re-scans.

    Returns '' for an empty ref. Callers must still confine the result to
    UPLOADS_DIR before deleting anything (see routes._remove_stored_source):
    a tampered absolute source_ref must not become a delete primitive.
    """
    if not source_ref:
        return ''
    if os.path.isabs(source_ref):
        if os.path.exists(source_ref):
            return source_ref
        return os.path.join(UPLOADS_DIR, os.path.basename(source_ref))
    return os.path.join(UPLOADS_DIR, source_ref)
