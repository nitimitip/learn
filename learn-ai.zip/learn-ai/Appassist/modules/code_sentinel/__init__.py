from flask import Blueprint

code_sentinel_bp = Blueprint('code_sentinel', __name__)

from . import routes  # noqa: E402,F401  (registers the route handlers)
