"""
Headless scan runner for the VENDORED CodeSentinel engine.

App Assist normally drives the engine through the web module, but this small
script lets you run the same analyzer from the command line on the server -
handy for a smoke test after deployment or for generating a JSON report to
POST at the CI-ingest endpoint, WITHOUT needing the desktop package.

    python modules/code_sentinel/engine/scripts/run_scan.py <path-to-code>
    python modules/code_sentinel/engine/scripts/run_scan.py <path> --json out.json

The engine is loaded from the sibling `codesentinel` package in this folder,
so nothing outside `modules/code_sentinel/engine` is required.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

# Make the vendored `codesentinel` package importable (this file lives at
# engine/scripts/run_scan.py; its parent's parent is the `engine` folder that
# CONTAINS the codesentinel package).
ENGINE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ENGINE_DIR))


def main() -> int:
    parser = argparse.ArgumentParser(description="Run a CodeSentinel scan.")
    parser.add_argument("path", help="File or directory to analyse")
    parser.add_argument("--json", metavar="FILE",
                        help="Write the full result as JSON to FILE")
    parser.add_argument("--quiet", "-q", action="store_true")
    args = parser.parse_args()

    from codesentinel.application import ApplicationServices

    root = Path(args.path).resolve()
    if not root.exists():
        print(f"No such path: {root}", file=sys.stderr)
        return 2

    services = ApplicationServices()
    say = (lambda msg: None) if args.quiet else print
    outcome = services.scan_service.scan(root, log=say, persist=False)

    card = outcome.scorecard
    print(f"\nGrade {card.grade} - overall {card.overall}/100 - "
          f"security {card.security}/100 - gate {outcome.gate.verdict}")
    for reason in outcome.gate.reasons:
        print(f"  x {reason}")

    if args.json:
        from codesentinel.domain.serialization import analysis_to_dict
        document = {
            "summary": {
                "project": root.name,
                "root": str(outcome.result.root),
                "generated_at": (outcome.result.finished_at or "").__str__(),
            },
            "files": [analysis_to_dict(a) for a in outcome.result.analyses],
        }
        Path(args.json).write_text(json.dumps(document, indent=2), encoding="utf-8")
        print(f"\nJSON report written to {args.json}")

    # Non-zero exit when the gate fails, so CI can block on it.
    return 0 if outcome.gate.passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
