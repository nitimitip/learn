"""
Bridge to the CodeSentinel analysis engine.

Everything CodeSentinel-specific funnels through this file: it puts the
package on sys.path, points CODESENTINEL_HOME at the app's data folder
(incremental cache / custom rule packs / plugins), and exposes the handful
of operations the web module needs:

    run_scan(root, ...)          full scan of a directory -> ScanPayload
    payload_from_ci(document)  same payload built from a CI-posted JSON report
    export_payload(...)          render a stored payload with any exporter
    gate_config / max_workers  settings shared with the GUI + CLI (same keys)

Scoring, quality-gate evaluation and triage suppression all reuse the
CodeSentinel domain functions so the web app, GUI and CLI can never drift.
"""

import csv
import json
import logging
import os
import sys
import threading
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from .. import config

logger = logging.getLogger(__name__)

_import_lock = threading.Lock()
_cs = None          # dict of imported codesentinel modules
_settings = None    # codesentinel SettingsRepository (own SQLite, thread-safe)
_file_cache = None  # codesentinel FileCacheRepository (incremental scans)


class CodeSentinelUnavailable(RuntimeError):
    """Raised when the CodeSentinel package cannot be imported."""


def _load():
    """Import the codesentinel package once, lazily, thread-safe."""
    global _cs, _settings, _file_cache
    if _cs is not None:
        return _cs
    with _import_lock:
        if _cs is not None:
            return _cs
        config.ensure_dirs()
        # The engine's own data (cache DB, user rules, plugins) lives under
        # the app's data dir. Must be set before the first codesentinel import.
        os.environ.setdefault('CODESENTINEL_HOME', config.CODESENTINEL_HOME)
        src = config.CODESENTINEL_SRC
        if not os.path.isdir(os.path.join(src, 'codesentinel')):
            raise CodeSentinelUnavailable(
                f'CodeSentinel package not found under "{src}". Set the '
                'CODESENTINEL_SRC environment variable to the directory that '
                'contains the "codesentinel" package.'
            )
        if src not in sys.path:
            sys.path.insert(0, src)
        try:
            from codesentinel import APP_NAME, APP_VERSION
            from codesentinel.analysis.engine import AnalysisEngine
            from codesentinel.analysis.scanner import FileScanner
            from codesentinel.analysis.languages import registry as language_registry
            from codesentinel.domain import models as domain
            from codesentinel.domain.scoring import (
                QualityGate, QualityGateConfig, WaiverDetail, compute_scorecard,
                new_code_result,
            )
            from codesentinel.domain.serialization import (
                analysis_from_dict, analysis_to_dict,
            )
            from codesentinel.infrastructure.database import Database
            from codesentinel.infrastructure.paths import user_rules_dir
            from codesentinel.infrastructure.repositories import (
                FileCacheRepository, SettingsRepository, apply_triage,
            )
            from codesentinel.reporting.base import ReportContext
        except ImportError as exc:
            raise CodeSentinelUnavailable(
                f'CodeSentinel could not be imported from "{src}": {exc}'
            ) from exc

        _apply_execution_policy()
        _apply_report_theme()

        db = Database()
        _settings = SettingsRepository(db)
        _file_cache = FileCacheRepository(db)
        _cs = {
            'APP_NAME': APP_NAME, 'APP_VERSION': APP_VERSION,
            'AnalysisEngine': AnalysisEngine, 'FileScanner': FileScanner,
            'language_registry': language_registry, 'domain': domain,
            'QualityGate': QualityGate, 'QualityGateConfig': QualityGateConfig,
            'WaiverDetail': WaiverDetail,
            'compute_scorecard': compute_scorecard,
            'new_code_result': new_code_result,
            'analysis_from_dict': analysis_from_dict,
            'analysis_to_dict': analysis_to_dict,
            'apply_triage': apply_triage,
            'user_rules_dir': user_rules_dir,
            'ReportContext': ReportContext,
        }
        logger.info('CodeSentinel %s loaded from %s', APP_VERSION, src)
        return _cs


# ---------------------------------------------------------------------------
# Execution policy: NO CHILD PROCESSES under the web host.
#
# The engine analyses a scan of >= PARALLEL_THRESHOLD files across a
# ProcessPoolExecutor. That pays off for the desktop GUI and the CLI, but in a
# web worker it is a hang risk. On Windows a process pool uses the "spawn"
# start method: every child re-launches sys.executable and re-imports the
# parent's __main__ - which under IIS is wfastcgi's host script, not App Assist
# - while inheriting the FastCGI stdio pipes. A child that fails to bootstrap
# raises nothing in the parent: the scan thread simply blocks in as_completed()
# for good, and the CodeScan row stays "running" until someone marks it failed.
# (The engine's own OSError/RuntimeError fallback catches a pool that fails to
# CONSTRUCT - never one that hangs after construction.)
#
# So the web host pushes the threshold out of reach and every scan runs
# serially in its job thread. The engine package is untouched, so the GUI and
# CLI keep their process pool. CODESENTINEL_PARALLEL=1 opts back in.
# ---------------------------------------------------------------------------

def _apply_execution_policy() -> None:
    """Force serial analysis unless the host is known to tolerate spawning."""
    if config.SCAN_PARALLEL:
        logger.info('CodeSentinel process pool ENABLED (CODESENTINEL_PARALLEL=1)')
        return
    from codesentinel.analysis import engine as cs_engine
    cs_engine.PARALLEL_THRESHOLD = sys.maxsize
    logger.info('CodeSentinel scans run serially in-process (no child '
                'processes under the web host)')


# ---------------------------------------------------------------------------
# Report theming: NPg / HLD palette (matches project_management/hld_docx.py).
#
# The CodeSentinel exporters ship a neutral slate theme. For reports downloaded
# from THIS web app we re-point their palette constants at the HLD brand
# colours - red header bands, blue accents, warm greys - WITHOUT touching the
# engine package, so the desktop GUI / CLI keep their own look. Structure and
# content of every report are untouched; severity / pass-fail colours are
# semantic and deliberately left alone.
# ---------------------------------------------------------------------------

_HLD = {
    'red':      '#9F1C33',   # brand red - header bands, section rules
    'red_deep': '#7E1628',   # darker red - header borders
    'blue':     '#4F81BD',   # sub-headings / fix guidance
    'ink':      '#1B1B20',
    'muted':    '#6B6B75',
    'faint':    '#9B9BA3',
    'rose':     '#E8B4BE',   # soft text on the red band
    'tint':     '#EEF1F6',   # panel background
    'band':     '#F2F2F2',   # zebra rows
    'border':   '#D7DEE7',   # hairlines
    'grid':     '#C9CFD8',   # table gridlines
}


def _apply_report_theme() -> None:
    """Re-colour the exporters with the HLD palette (idempotent, fail-soft)."""
    # Excel: header band slate -> brand red.
    try:
        from openpyxl.styles import PatternFill
        from codesentinel.reporting import excel as cs_excel
        cs_excel._HEADER_FILL = PatternFill('solid', fgColor=_HLD['red'].lstrip('#'))
    except Exception:                                    # noqa: BLE001
        logger.warning('Could not theme the Excel exporter', exc_info=True)

    # HTML: retarget the palette literals inside the exporter's inline CSS.
    # Ordered: specific selectors first, then the global colour swaps.
    try:
        from codesentinel.reporting import html as cs_html
        css = cs_html._CSS
        for old, new in (
            ("header.report .sub { color: #94a3b8", "header.report .sub { color: " + _HLD['rose']),
            (".section h2 { font-size: 15px; margin-bottom: 14px; color: #0f172a",
             ".section h2 { font-size: 15px; margin-bottom: 14px; color: " + _HLD['red']),
            (".fix { color: #0369a1", ".fix { color: " + _HLD['blue']),
            ('#1e293b', _HLD['red']),       # header band + table headers
            ('#0f172a', _HLD['ink']),
            ('#94a3b8', _HLD['faint']),     # footer (header .sub already swapped)
            ('#64748b', _HLD['muted']),
            ('#e2e8f0', _HLD['border']),
            ('#cbd5e1', _HLD['grid']),
            ('#f8fafc', _HLD['band']),
            ('#f1f5f9', _HLD['tint']),      # page background + code chips
        ):
            css = css.replace(old, new)
        cs_html._CSS = css
    except Exception:                                    # noqa: BLE001
        logger.warning('Could not theme the HTML exporter', exc_info=True)

    # PDF: swap the Theme palette (reportlab may legitimately be absent).
    # ACCENT drives the section-title underlines, minor headings and fix
    # notes - all brand red per the HLD theme (user: no blue underlines).
    try:
        from reportlab.lib import colors
        from codesentinel.reporting import pdf as cs_pdf
        theme = cs_pdf.Theme
        theme.INK = colors.HexColor(_HLD['ink'])
        theme.BRAND = colors.HexColor(_HLD['red'])       # table headers, file headings
        theme.ACCENT = colors.HexColor(_HLD['red'])      # rules / underlines, minor headings
        theme.MUTED = colors.HexColor(_HLD['muted'])
        theme.FAINT = colors.HexColor(_HLD['faint'])
        theme.HAIRLINE = colors.HexColor(_HLD['border'])
        theme.GRID = colors.HexColor(_HLD['grid'])
        theme.ZEBRA = colors.HexColor(_HLD['band'])
        theme.PANEL = colors.HexColor(_HLD['tint'])
    except ImportError:
        pass                                             # no reportlab -> no PDF exporter
    except Exception:                                    # noqa: BLE001
        logger.warning('Could not theme the PDF exporter', exc_info=True)


def available() -> bool:
    try:
        _load()
        return True
    except CodeSentinelUnavailable:
        return False


def app_version() -> str:
    return _load()['APP_VERSION']


# ---------------------------------------------------------------------------
# Settings shared with the GUI / CLI (same keys in the same settings store).
# ---------------------------------------------------------------------------

def gate_config_dict() -> dict:
    _load()
    cs = _cs
    stored = _settings.get_json('gate.config', {})
    defaults = cs['QualityGateConfig']()
    return {
        'max_blocker': int(stored.get('max_blocker', defaults.max_blocker)),
        'max_critical': int(stored.get('max_critical', defaults.max_critical)),
        'max_high': int(stored.get('max_high', defaults.max_high)),
        'max_duplication': float(stored.get('max_duplication', defaults.max_duplication)),
        'min_security_score': int(stored.get('min_security_score', defaults.min_security_score)),
        'fail_on_analysis_errors': bool(stored.get('fail_on_analysis_errors', True)),
        'require_language_parsers': bool(stored.get('require_language_parsers', False)),
        'min_language_security_score': int(stored.get('min_language_security_score', 0)),
    }


def save_gate_config(values: dict) -> None:
    _load()
    _settings.set_json('gate.config', values)


def _gate(new_code_only: bool = False):
    cs = _load()
    config = dict(gate_config_dict())
    config['new_code_only'] = bool(new_code_only)
    return cs['QualityGate'](cs['QualityGateConfig'](**config))


def disabled_rule_ids() -> list:
    _load()
    return _settings.get_json('rules.disabled', [])


def set_rule_enabled(rule_id: str, enabled: bool) -> None:
    _load()
    disabled = set(disabled_rule_ids())
    if enabled:
        disabled.discard(rule_id)
    else:
        disabled.add(rule_id)
    _settings.set_json('rules.disabled', sorted(disabled))


def max_workers() -> int:
    _load()
    try:
        return int(_settings.get('scan.max_workers', '0'))
    except ValueError:
        return 0


def set_max_workers(value: int) -> None:
    _load()
    _settings.set('scan.max_workers', str(max(0, int(value))))


def list_rules() -> list:
    """Every loaded rule as plain dicts for the rule-browser page."""
    cs = _load()
    engine = cs['AnalysisEngine'](
        cache=None,
        extra_rule_dirs=[cs['user_rules_dir']()],
        disabled_rule_ids=disabled_rule_ids(),
    )
    rules = {}
    for rule in [*engine.rule_set.all_rules(), *engine.rule_set.all_query_rules()]:
        existing = rules.get(rule.id)
        method = 'Syntax query' if hasattr(rule, 'query') else 'Pattern'
        if existing:
            existing['detection'] = 'Pattern + syntax query'
            continue
        rules[rule.id] = {
            'id': rule.id,
            'title': rule.title,
            'severity': rule.severity.value,
            'category': getattr(rule, 'category', ''),
            'languages': list(rule.languages),
            'enabled': rule.enabled,
            'cwe': getattr(rule, 'cwe', ''),
            'remediation': getattr(rule, 'remediation', ''),
            'confidence': rule.confidence,
            'detection': method,
        }
    return [rules[key] for key in sorted(rules)]


# ---------------------------------------------------------------------------
# Scanning
# ---------------------------------------------------------------------------

@dataclass
class ScanPayload:
    """Everything the job runner persists after a scan or a CI ingest."""

    summary: dict          # column values for the CodeScan row
    finding_rows: list     # dicts for CodeFinding rows (ALL findings)
    result_document: dict  # full serialised result for re-exports


def _payload(result, triage_statuses: dict,
             baseline_fingerprints: set | None = None,
             gate_mode: str = 'full',
             baseline_scan_id: int | None = None) -> ScanPayload:
    """
    Build the storage payload from a ScanResult.

    All findings are stored (so triaged ones stay visible with their badge),
    but scores, severity counts and the quality gate are computed on a copy
    with FP/accepted-risk findings suppressed - a finding a human has waved
    through must not fail the release gate.

    ``baseline_fingerprints`` is the fingerprint set of the project's baseline
    scan (``None`` for the first scan). Every finding is flagged new/old against
    it, and when ``gate_mode == 'new'`` the release gate is evaluated over only
    the NEW findings (new-code-only gating) so pre-existing
    debt never blocks a release that introduces none.
    """
    cs = _cs
    domain = cs['domain']
    new_mode = gate_mode == 'new'

    finding_rows = []
    for analysis in result.analyses:
        rel = domain.relative_to_root(analysis.path, result.root)
        fingerprints = domain.assign_fingerprints(analysis.findings, rel)
        for finding, fingerprint in zip(analysis.findings, fingerprints):
            is_new = (baseline_fingerprints is None
                      or fingerprint not in baseline_fingerprints)
            finding_rows.append({
                'fingerprint': fingerprint,
                'file_path': rel,
                'line': finding.line,
                'tool': finding.tool,
                'rule_id': finding.rule_id,
                'severity': finding.severity.value,
                'category': finding.category,
                'cwe': finding.cwe,
                'owasp': finding.owasp,
                'confidence': finding.confidence,
                'message': finding.message,
                'remediation': finding.remediation,
                'snippet': finding.snippet,
                'is_new': is_new,
            })

    scored = _suppressed_copy(result, triage_statuses)
    scorecard = cs['compute_scorecard'](scored)
    gate = _gate(new_code_only=new_mode).evaluate(scored, baseline_fingerprints)
    severities = {s.value: c for s, c in scored.severity_totals().items()}

    # New-since-baseline counts, over the same suppressed set the gate uses.
    new_view = cs['new_code_result'](scored, baseline_fingerprints)
    new_sev = {s.value: c for s, c in new_view.severity_totals().items()}

    summary = {
        'files_scanned': len(result.analyses),
        'files_cached': result.files_from_cache,
        'total_lines': result.total_lines,
        'code_lines': result.total_code_lines,
        'total_findings': scored.total_findings,
        'suppressed_findings': scored.suppressed_count,
        'blocker': severities.get('BLOCKER', 0),
        'critical': severities.get('CRITICAL', 0),
        'high': severities.get('HIGH', 0),
        'medium': severities.get('MEDIUM', 0),
        'low': severities.get('LOW', 0),
        'info': severities.get('INFO', 0),
        'duplication': result.duplication_ratio,
        'security_score': scorecard.security,
        'reliability_score': scorecard.reliability,
        'maintainability_score': scorecard.maintainability,
        'performance_score': scorecard.performance,
        'overall_score': scorecard.overall,
        'grade': scorecard.grade,
        'maintainability_rating': scorecard.maintainability_rating,
        'risk_level': scorecard.risk_level,
        'debt_minutes': scorecard.technical_debt_minutes,
        'gate_mode': gate_mode,
        'baseline_scan_id': baseline_scan_id,
        'new_blocker': new_sev.get('BLOCKER', 0),
        'new_critical': new_sev.get('CRITICAL', 0),
        'new_high': new_sev.get('HIGH', 0),
        'new_findings': new_view.total_findings,
        'gate_passed': gate.passed,
        'gate_reasons': json.dumps(gate.reasons),
    }

    document = {
        'root': str(result.root),
        'started_at': result.started_at.isoformat(),
        'finished_at': result.finished_at.isoformat() if result.finished_at else None,
        'files_from_cache': result.files_from_cache,
        'analyses': [cs['analysis_to_dict'](a) for a in result.analyses],
    }
    return ScanPayload(summary=summary, finding_rows=finding_rows,
                       result_document=document)


def _suppressed_copy(result, triage_statuses: dict):
    """A shallow copy of `result` with triaged findings removed for scoring."""
    cs = _cs
    domain = cs['domain']
    copy = domain.ScanResult(
        root=result.root,
        started_at=result.started_at,
        finished_at=result.finished_at,
        files_from_cache=result.files_from_cache,
    )
    for analysis in result.analyses:
        copy.analyses.append(domain.FileAnalysis(
            path=analysis.path,
            language_id=analysis.language_id,
            findings=list(analysis.findings),
            tools_run=list(analysis.tools_run),
            tool_errors=list(analysis.tool_errors),
            metrics=analysis.metrics,
        ))
    if triage_statuses:
        statuses = {
            fp: domain.IssueStatus(status)
            for fp, status in triage_statuses.items()
            if status in ('FALSE_POSITIVE', 'ACCEPTED_RISK')
        }
        cs['apply_triage'](copy, statuses)
    return copy


def run_scan(root: str, triage_statuses: dict,
             progress=None, log=None,
             baseline_fingerprints: set | None = None,
             gate_mode: str = 'full',
             baseline_scan_id: int | None = None) -> ScanPayload:
    """
    Full scan of a directory tree. Mirrors codesentinel ScanService.scan but
    persists to the App Assist database (via the returned payload) instead of
    the engine's own history, and applies THIS module's triage decisions.

    progress: callable(done, total, filename) - called from worker context.
    log:      callable(str) - human-readable progress lines.
    baseline_fingerprints / gate_mode / baseline_scan_id: new-code gate inputs
        (see :func:`_payload`); default to a full-codebase gate.
    """
    cs = _load()
    emit = log or (lambda message: None)
    root_path = Path(root).resolve()
    if not root_path.is_dir():
        raise ValueError(f'Scan root is not a directory: {root_path}')

    engine = cs['AnalysisEngine'](
        cache=_file_cache,
        max_workers=max_workers(),
        extra_rule_dirs=[cs['user_rules_dir']()],
        disabled_rule_ids=disabled_rule_ids(),
    )
    rules = engine.rule_set.all_rules()
    emit(f'Rule set: {len(rules)} rules '
         f'({len([r for r in rules if r.enabled])} enabled)')

    scanner = cs['FileScanner'](cs['language_registry'])
    discovery = scanner.discover(root_path)
    emit(f'Discovered {len(discovery.files)} analysable file(s)'
         + (f', skipped {discovery.skipped_large} oversized'
            if discovery.skipped_large else '')
         + (' - LIMIT REACHED, scan truncated' if discovery.truncated else ''))

    result = engine.run(discovery.files, root_path, progress)
    emit(f'Analysed {len(result.analyses)} file(s) '
         f'({result.files_from_cache} from cache) in '
         f'{result.duration_seconds:.1f}s')

    payload = _payload(result, triage_statuses,
                       baseline_fingerprints=baseline_fingerprints,
                       gate_mode=gate_mode, baseline_scan_id=baseline_scan_id)
    if payload.summary['suppressed_findings']:
        emit(f"Suppressed {payload.summary['suppressed_findings']} finding(s) "
             'per triage decisions')
    if gate_mode == 'new':
        emit(f"Gate scope: NEW CODE only "
             + (f'(vs baseline scan #{baseline_scan_id})' if baseline_scan_id
                else '(first scan - all findings are new)')
             + f" - {payload.summary['new_findings']} new finding(s)")
    emit(f"QUALITY GATE: {'PASSED' if payload.summary['gate_passed'] else 'FAILED'}")
    for reason in json.loads(payload.summary['gate_reasons']):
        emit(f'  x {reason}')
    return payload


# ---------------------------------------------------------------------------
# CI ingest: a JSON report produced by `python -m codesentinel scan -f json`
# ---------------------------------------------------------------------------

def payload_from_ci(document: dict, triage_statuses: dict,
                    baseline_fingerprints: set | None = None,
                    gate_mode: str = 'full',
                    baseline_scan_id: int | None = None) -> ScanPayload:
    """
    Build a storable payload from a CI-posted CodeSentinel JSON report
    (`{"summary": {...}, "files": [...]}`). Scores and the quality gate are
    recomputed SERVER-side with the server's gate config and this project's
    triage decisions, so CI cannot ship a stale or tampered verdict. The
    new-code gate (baseline comparison) is likewise applied server-side.
    """
    cs = _load()
    domain = cs['domain']

    files = document.get('files')
    if not isinstance(files, list):
        raise ValueError('JSON body must contain a "files" list '
                         '(a CodeSentinel JSON report).')
    summary_in = document.get('summary') or {}
    root = str(summary_in.get('root') or summary_in.get('project') or 'ci-scan')

    result = domain.ScanResult(root=Path(root))
    result.analyses = [cs['analysis_from_dict'](f) for f in files]
    result.files_from_cache = int(summary_in.get('files_from_cache', 0) or 0)
    for stamp, attr in (('started_at', 'started_at'), ('finished_at', 'finished_at')):
        raw = summary_in.get('generated_at') if stamp == 'finished_at' else None
        if raw:
            try:
                setattr(result, attr, datetime.fromisoformat(raw))
            except ValueError:
                pass
    if result.finished_at is None:
        result.finished_at = datetime.now()

    return _payload(result, triage_statuses,
                    baseline_fingerprints=baseline_fingerprints,
                    gate_mode=gate_mode, baseline_scan_id=baseline_scan_id)


# ---------------------------------------------------------------------------
# Exports
# ---------------------------------------------------------------------------

_EXPORT_MIMETYPES = {
    '.pdf': 'application/pdf',
    '.html': 'text/html',
    '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    '.sarif': 'application/sarif+json',
    '.json': 'application/json',
    '.csv': 'text/csv',
    '.xml': 'application/xml',
    '.md': 'text/markdown',
}


def exporter_registry():
    """Exporter registry; PDF degrades gracefully if reportlab is absent."""
    cs = _load()
    try:
        from codesentinel.reporting.base import build_default_registry
        registry = build_default_registry()
    except ImportError:
        # reportlab missing - register everything except the PDF exporter.
        from codesentinel.reporting.base import ExporterRegistry
        from codesentinel.reporting.excel import ExcelExporter
        from codesentinel.reporting.html import HtmlExporter
        from codesentinel.reporting.sarif import SarifExporter
        from codesentinel.reporting.text_formats import (
            CsvExporter, JsonExporter, MarkdownExporter, XmlExporter,
        )
        registry = ExporterRegistry()
        for exporter in (HtmlExporter(), ExcelExporter(), SarifExporter(),
                         JsonExporter(), CsvExporter(), XmlExporter(),
                         MarkdownExporter()):
            registry.register(exporter)
    _register_branded_excel(registry)
    return registry


def _register_branded_excel(registry) -> None:
    """
    Replace the engine's plain Excel exporter with the NPg-branded workbook
    (modules/code_sentinel/excel_report.py) - same sheets and columns, house
    report styling. Registering under the same format_id overrides it for
    THIS web app only.
    """
    try:
        from codesentinel.reporting.base import Exporter
        from ..excel_report import build_scan_workbook
    except Exception:                                    # noqa: BLE001
        logger.warning('Branded Excel exporter unavailable; using the default',
                       exc_info=True)
        return

    class BrandedExcelExporter(Exporter):
        format_id = 'xlsx'
        display_name = 'Excel workbook'
        extension = '.xlsx'

        def export(self, context, destination):
            return build_scan_workbook(context, destination)

    registry.register(BrandedExcelExporter())


#: Formats offered in the download menu: the two report-grade formats (user
#: decision) plus SARIF for tool interchange (GitHub Code Scanning, IDE SARIF
#: viewers, result aggregators). The engine registers more (csv, json, html,
#: xml, markdown) and the export endpoint still honours them by URL / API.
UI_EXPORT_FORMATS = ('pdf', 'xlsx', 'sarif')


def export_formats() -> list:
    try:
        return [
            {'id': e.format_id, 'name': e.display_name, 'extension': e.extension}
            for e in exporter_registry().all()
            if e.format_id in UI_EXPORT_FORMATS
        ]
    except CodeSentinelUnavailable:
        return []


def analysis_assurance(result_document: dict) -> list:
    cs = _load()
    from codesentinel.domain.assurance import language_assurance
    result = cs['domain'].ScanResult(root=Path(str(result_document.get('root', '.'))))
    result.analyses = [cs['analysis_from_dict'](f) for f in result_document.get('analyses', [])]
    return language_assurance(result)


def export_payload(result_document: dict, project_name: str,
                   triage_statuses: dict, format_id: str,
                   triage_details: dict | None = None,
                   gate_mode: str = 'full',
                   baseline_fingerprints: set | None = None):
    """
    Re-render a stored scan with one of the CodeSentinel exporters, applying
    the CURRENT triage decisions and gate config. Returns
    (path, download_name, mimetype).

    `triage_details` (fingerprint -> {status, note, by, at}) drives the gate
    waiver notes that appear in the rendered report; omit it and the report
    simply carries no waiver section.

    CSV is the one findings-only format, so it lists EVERY finding with a
    trailing 'status' column instead of dropping triaged ones - otherwise a
    fully-triaged scan exports as a bare header row that reads as broken.
    All other formats keep the suppress-in-exports behaviour.
    """
    cs = _load()
    domain = cs['domain']
    exporter = exporter_registry().get(format_id)
    if exporter is None:
        raise ValueError(f'Unknown export format: {format_id}')

    result = domain.ScanResult(root=Path(str(result_document.get('root', '.'))))
    result.analyses = [cs['analysis_from_dict'](f)
                       for f in result_document.get('analyses', [])]
    for stamp in ('started_at', 'finished_at'):
        raw = result_document.get(stamp)
        if raw:
            try:
                setattr(result, stamp, datetime.fromisoformat(raw))
            except ValueError:
                pass
    result.files_from_cache = int(result_document.get('files_from_cache', 0) or 0)

    if format_id == 'csv':
        destination = _export_destination(project_name, exporter.extension)
        written = _write_csv_with_status(result, triage_statuses, destination)
        return written, written.name, _EXPORT_MIMETYPES['.csv']

    scored = _suppressed_copy(result, triage_statuses)
    gate = _gate(new_code_only=gate_mode == 'new').evaluate(scored, baseline_fingerprints)
    gate.notes = waiver_notes(result, triage_details or {})
    gate.waivers = waiver_details(result, triage_details or {})
    context = cs['ReportContext'](
        result=scored,
        scorecard=cs['compute_scorecard'](scored),
        gate=gate,
        project_name=project_name,
        gate_scope='New findings since baseline' if gate_mode == 'new' else 'Full codebase',
        evaluation_note='Reevaluated at export with current policy and triage decisions. Historical scan scores are unchanged.',
    )

    destination = _export_destination(project_name, exporter.extension)
    written = exporter.export(context, destination)
    mimetype = _EXPORT_MIMETYPES.get(exporter.extension, 'application/octet-stream')
    return written, written.name, mimetype


def _export_destination(project_name: str, extension: str) -> Path:
    config.ensure_dirs()
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    safe = ''.join(c if c.isalnum() or c in '-_' else '_' for c in project_name)[:60]
    return Path(config.EXPORTS_DIR) / f'codesentinel_{safe}_{stamp}{extension}'


#: Triage status -> the phrase used in a waiver note.
_WAIVER_PHRASE = {
    'FALSE_POSITIVE': 'marked a false positive',
    'ACCEPTED_RISK': 'accepted as a known risk',
}
#: Severities a waiver note is worth spelling out (these are what the gate
#: actually blocks on); lower waived findings get a single summary line.
GATE_SEVERITIES = ('BLOCKER', 'CRITICAL', 'HIGH')


def format_waiver_note(severity: str, category: str, rule_id: str,
                       location: str, detail: dict) -> str:
    """
    One waiver-note line. Shared by the report path (ScanResult) and the UI
    path (DB rows) so both render identically.
    """
    phrase = _WAIVER_PHRASE.get(detail.get('status'), 'waived')
    reason = (detail.get('note') or '').strip()
    attribution = _attribution(detail)
    return (
        f"{severity} - {category} ({rule_id}) at {location} - {phrase}"
        + (f': "{reason}"' if reason else ' (no reason recorded)')
        + (f' [{attribution}]' if attribution else '')
    )


def minor_waiver_summary(count: int) -> str:
    return (f"{count} lower-severity finding(s) also waived by reviewers "
            f"(see the triage view for details).")


def waiver_notes(result, triage_details: dict) -> list:
    """
    Build the quality-gate waiver notes for a scan.

    `triage_details` maps a finding fingerprint to a dict with 'status'
    (FALSE_POSITIVE | ACCEPTED_RISK) and optional 'note', 'by', 'at'. For
    every waived finding at a gate-blocking severity we emit one note naming
    the finding, the decision, the reviewer's reason, and the attribution -
    so a report reader sees exactly WHY the gate passed despite it. Lower-
    severity waivers are summarised in a single trailing line.
    """
    if not triage_details:
        return []
    domain = _cs['domain']
    notes: list = []
    minor = 0
    for analysis in result.analyses:
        rel = domain.relative_to_root(analysis.path, result.root)
        findings = analysis.sorted_findings()
        fingerprints = domain.assign_fingerprints(findings, rel)
        for finding, fingerprint in zip(findings, fingerprints):
            detail = triage_details.get(fingerprint)
            if not detail or detail.get('status') not in _WAIVER_PHRASE:
                continue
            if finding.severity.value not in GATE_SEVERITIES:
                minor += 1
                continue
            notes.append(format_waiver_note(
                finding.severity.value, finding.category, finding.rule_id,
                f"{rel}:{finding.line}", detail))
    if minor:
        notes.append(minor_waiver_summary(minor))
    return notes


def _attribution(detail: dict) -> str:
    who = (detail.get('by') or '').strip()
    when = (detail.get('at') or '').strip()
    if who and when:
        return f"{who}, {when}"
    return who or when


#: Triage status -> the short decision label used in the report table.
_WAIVER_DECISION = {
    'FALSE_POSITIVE': 'False positive',
    'ACCEPTED_RISK': 'Accepted risk',
}


def waiver_details(result, triage_details: dict) -> list:
    """
    Structured detail of EVERY waived finding (any severity) - the rows the
    report's Waived Findings table is rendered from. Returns a list of
    domain.WaiverDetail, severity-ordered.
    """
    if not triage_details:
        return []
    domain = _cs['domain']
    WaiverDetail = _cs['WaiverDetail']
    rows: list = []
    for analysis in result.analyses:
        rel = domain.relative_to_root(analysis.path, result.root)
        findings = analysis.sorted_findings()
        fingerprints = domain.assign_fingerprints(findings, rel)
        for finding, fingerprint in zip(findings, fingerprints):
            detail = triage_details.get(fingerprint)
            if not detail or detail.get('status') not in _WAIVER_DECISION:
                continue
            rows.append(WaiverDetail(
                severity=finding.severity.value,
                category=finding.category,
                rule_id=finding.rule_id,
                location=f"{rel}:{finding.line}",
                decision=_WAIVER_DECISION[detail['status']],
                reason=(detail.get('note') or '').strip(),
                reviewer=_attribution(detail),
            ))
    return rows


#: Engine CsvExporter columns, plus the triage status appended last so any
#: existing consumer that addresses columns by position keeps working.
_CSV_HEADER = [
    'file', 'line', 'severity', 'category', 'rule_id', 'cwe', 'owasp',
    'confidence', 'tool', 'message', 'remediation', 'status',
]


def _write_csv_with_status(result, triage_statuses: dict,
                           destination: Path) -> Path:
    """Findings CSV including triaged rows, labelled via their fingerprint."""
    domain = _cs['domain']
    with destination.open('w', newline='', encoding='utf-8-sig') as handle:
        writer = csv.writer(handle)
        writer.writerow(_CSV_HEADER)
        for analysis in result.analyses:
            rel = domain.relative_to_root(analysis.path, result.root)
            findings = analysis.sorted_findings()
            fingerprints = domain.assign_fingerprints(findings, rel)
            for finding, fingerprint in zip(findings, fingerprints):
                status = triage_statuses.get(fingerprint, 'OPEN')
                writer.writerow([
                    rel, finding.line, finding.severity.value,
                    finding.category, finding.rule_id, finding.cwe,
                    finding.owasp, finding.confidence, finding.tool,
                    finding.message, finding.remediation, status,
                ])
    return destination
