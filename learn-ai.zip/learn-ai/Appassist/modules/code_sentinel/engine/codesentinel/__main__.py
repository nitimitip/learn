"""
CodeSentinel entry point.

    python -m codesentinel                     # launch the desktop GUI
    python -m codesentinel scan PATH [options] # headless scan + reports

The headless mode makes the same engine available to CI pipelines and
scripted audits; its exit code follows the quality gate (0 pass, 2 fail),
so it can gate releases directly.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import APP_NAME, APP_VERSION
from .infrastructure.logging_config import configure_logging


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="codesentinel",
        description=f"{APP_NAME} v{APP_VERSION} - offline static analysis platform.",
    )
    sub = parser.add_subparsers(dest="command")

    scan = sub.add_parser("scan", help="Run a headless scan and export reports.")
    scan.add_argument("path", type=Path, help="File or directory to analyse.")
    scan.add_argument(
        "--format", "-f", default="json",
        help="Comma-separated report formats "
             "(pdf,html,xlsx,sarif,json,csv,xml,markdown).",
    )
    scan.add_argument(
        "--output", "-o", type=Path, default=Path("."),
        help="Directory reports are written to (default: current directory).",
    )
    scan.add_argument("--no-cache", action="store_true",
                      help="Ignore the incremental cache and re-analyse everything.")
    scan.add_argument("--no-history", action="store_true",
                      help="Do not record this scan in the local database.")
    scan.add_argument("--sbom", action="store_true",
                      help="Also emit a CycloneDX SBOM from dependency manifests.")
    scan.add_argument("--quiet", "-q", action="store_true")

    sub.add_parser("rules", help="List every loaded rule.")
    return parser


def _run_scan(args: argparse.Namespace) -> int:
    from .application import ApplicationServices
    from .analysis.dependencies import DependencyScanner

    target: Path = args.path
    if not target.exists():
        print(f"error: path does not exist: {target}", file=sys.stderr)
        return 1

    services = ApplicationServices()
    say = (lambda message: None) if args.quiet else print

    def progress(done: int, total: int, name: str) -> None:
        if not args.quiet and (done % 25 == 0 or done == total):
            say(f"  [{done}/{total}] {name}")

    outcome = services.scan_service.scan(
        target, progress=progress, log=say,
        use_cache=not args.no_cache, persist=not args.no_history,
    )

    args.output.mkdir(parents=True, exist_ok=True)
    context = outcome.report_context()
    stamp = context.generated_at.strftime("%Y%m%d_%H%M%S")
    written: list[Path] = []
    for format_id in [f.strip().lower() for f in args.format.split(",") if f.strip()]:
        exporter = services.exporters.get(format_id)
        if exporter is None:
            print(f"warning: unknown format '{format_id}' "
                  f"(available: {', '.join(services.exporters.format_ids())})",
                  file=sys.stderr)
            continue
        destination = args.output / f"codesentinel_{stamp}{exporter.extension}"
        written.append(exporter.export(context, destination))

    if args.sbom:
        scanner = DependencyScanner()
        deps = scanner.scan(target)
        sbom_path = args.output / f"codesentinel_sbom_{stamp}.json"
        scanner.write_sbom(deps, sbom_path)
        written.append(sbom_path)
        say(f"SBOM: {len(deps)} component(s)")

    for path in written:
        say(f"  -> {path}")

    scorecard = outcome.scorecard
    say(f"Grade {scorecard.grade} ({scorecard.overall}/100) - "
        f"security {scorecard.security} - debt {scorecard.technical_debt} - "
        f"gate {outcome.gate.verdict}")
    return 0 if outcome.gate.passed else 2


def _list_rules() -> int:
    from .application import ApplicationServices

    services = ApplicationServices()
    engine = services.scan_service.build_engine(use_cache=False)
    for rule in engine.rule_set.all_rules():
        state = " " if rule.enabled else "x"
        languages = ",".join(rule.languages)
        print(f"[{state}] {rule.id:14s} {rule.severity.value:8s} "
              f"{languages:22s} {rule.title}")
    print(f"\n{len(engine.rule_set.all_rules())} rules loaded.")
    return 0


def main(argv: list[str] | None = None) -> int:
    # Legacy Windows consoles default to cp1252; never crash on report glyphs.
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(errors="replace")
    configure_logging()
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command == "scan":
        return _run_scan(args)
    if args.command == "rules":
        return _list_rules()

    # No sub-command -> GUI.
    from .ui.app import run_gui

    return run_gui()


if __name__ == "__main__":
    raise SystemExit(main())
