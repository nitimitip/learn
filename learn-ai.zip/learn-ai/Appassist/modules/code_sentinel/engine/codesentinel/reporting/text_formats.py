"""Machine-readable exporters: JSON, CSV, XML, Markdown."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from xml.etree import ElementTree as ET

from ..domain.models import relative_to_root
from ..domain.serialization import analysis_to_dict
from .base import Exporter, ReportContext


def _summary_dict(context: ReportContext) -> dict:
    result = context.result
    scorecard = context.scorecard
    return {
        "project": context.project_name,
        "root": str(result.root),
        "generated_at": context.generated_at.isoformat(),
        "tool": {"name": context.tool_name, "version": context.tool_version},
        "files_scanned": len(result.analyses),
        "files_from_cache": result.files_from_cache,
        "total_lines": result.total_lines,
        "code_lines": result.total_code_lines,
        "total_findings": result.total_findings,
        "suppressed_findings": result.suppressed_count,
        "duration_seconds": round(result.duration_seconds, 2),
        "duplication_ratio": round(result.duplication_ratio, 4),
        "severity_totals": {s.value: c for s, c in result.severity_totals().items()},
        "category_totals": result.category_totals(),
        "language_distribution": result.language_distribution(),
        "scores": {
            "security": scorecard.security,
            "reliability": scorecard.reliability,
            "maintainability": scorecard.maintainability,
            "performance": scorecard.performance,
            "overall": scorecard.overall,
            "grade": scorecard.grade,
            "maintainability_rating": scorecard.maintainability_rating,
            "risk_level": scorecard.risk_level,
            "technical_debt_minutes": scorecard.technical_debt_minutes,
        },
        "quality_gate": {
            "passed": context.gate.passed,
            "reasons": context.gate.reasons,
            "waiver_notes": context.gate.notes,
            "waived_findings": [
                {
                    "location": w.location, "severity": w.severity,
                    "rule_id": w.rule_id, "category": w.category,
                    "decision": w.decision, "reason": w.reason,
                    "reviewer": w.reviewer,
                }
                for w in context.gate.waivers
            ],
        },
    }


class JsonExporter(Exporter):
    format_id = "json"
    display_name = "JSON (machine readable)"
    extension = ".json"

    def export(self, context: ReportContext, destination: Path) -> Path:
        document = {
            "summary": _summary_dict(context),
            "files": [analysis_to_dict(a) for a in context.result.analyses],
        }
        destination.write_text(
            json.dumps(document, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        return destination


class CsvExporter(Exporter):
    format_id = "csv"
    display_name = "CSV (findings table)"
    extension = ".csv"

    _HEADER = [
        "file", "line", "severity", "category", "rule_id", "cwe", "owasp",
        "confidence", "tool", "message", "remediation",
    ]

    def export(self, context: ReportContext, destination: Path) -> Path:
        with destination.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.writer(handle)
            writer.writerow(self._HEADER)
            for analysis in context.result.analyses:
                rel = relative_to_root(analysis.path, context.result.root)
                for finding in analysis.sorted_findings():
                    writer.writerow([
                        rel, finding.line, finding.severity.value,
                        finding.category, finding.rule_id, finding.cwe,
                        finding.owasp, finding.confidence, finding.tool,
                        finding.message, finding.remediation,
                    ])
        return destination


class XmlExporter(Exporter):
    format_id = "xml"
    display_name = "XML (machine readable)"
    extension = ".xml"

    def export(self, context: ReportContext, destination: Path) -> Path:
        root = ET.Element("codesentinel-report", {
            "tool": context.tool_name,
            "version": context.tool_version,
            "generated": context.generated_at.isoformat(),
            "project": context.project_name,
        })
        summary = ET.SubElement(root, "summary")
        for key, value in _summary_dict(context).items():
            if isinstance(value, (str, int, float, bool)):
                ET.SubElement(summary, "metric", {"name": key}).text = str(value)

        gate_el = ET.SubElement(root, "quality-gate",
                                {"passed": str(context.gate.passed).lower()})
        for reason in context.gate.reasons:
            ET.SubElement(gate_el, "failure").text = reason
        for w in context.gate.waivers:
            waiver_el = ET.SubElement(gate_el, "waived-finding", {
                "location": w.location, "severity": w.severity,
                "rule": w.rule_id, "category": w.category,
                "decision": w.decision, "reviewer": w.reviewer,
            })
            waiver_el.text = w.reason

        files_el = ET.SubElement(root, "files")
        for analysis in context.result.analyses:
            rel = relative_to_root(analysis.path, context.result.root)
            file_el = ET.SubElement(files_el, "file", {
                "path": rel, "language": analysis.language_id,
            })
            for finding in analysis.sorted_findings():
                item = ET.SubElement(file_el, "finding", {
                    "rule": finding.rule_id,
                    "severity": finding.severity.value,
                    "line": str(finding.line),
                    "category": finding.category,
                    "cwe": finding.cwe,
                    "owasp": finding.owasp,
                    "confidence": finding.confidence,
                })
                ET.SubElement(item, "message").text = finding.message
                if finding.remediation:
                    ET.SubElement(item, "remediation").text = finding.remediation

        ET.indent(root)
        ET.ElementTree(root).write(destination, encoding="utf-8", xml_declaration=True)
        return destination


class MarkdownExporter(Exporter):
    format_id = "markdown"
    display_name = "Markdown (review notes)"
    extension = ".md"

    def export(self, context: ReportContext, destination: Path) -> Path:
        result = context.result
        scorecard = context.scorecard
        lines: list[str] = [
            f"# Static Analysis Report - {context.project_name}",
            "",
            f"*Generated {context.generated_at:%Y-%m-%d %H:%M} by "
            f"{context.tool_name} v{context.tool_version}*",
            "",
            "## Summary",
            "",
            f"| Metric | Value |",
            f"|---|---|",
            f"| Overall grade | **{scorecard.grade}** ({scorecard.overall}/100) |",
            f"| Quality gate | **{context.gate.verdict}** |",
            f"| Security score | {scorecard.security} |",
            f"| Reliability score | {scorecard.reliability} |",
            f"| Maintainability score | {scorecard.maintainability} |",
            f"| Performance score | {scorecard.performance} |",
            f"| Technical debt | {scorecard.technical_debt} |",
            f"| Files scanned | {len(result.analyses)} |",
            f"| Lines of code | {result.total_code_lines:,} |",
            f"| Total findings | {result.total_findings} |",
            f"| Duplication | {result.duplication_ratio:.1%} |",
            "",
        ]
        if not context.gate.passed:
            lines += ["### Quality-gate failures", ""]
            lines += [f"- {reason}" for reason in context.gate.reasons]
            lines.append("")
        if context.gate.waivers:
            def _cell(text: str) -> str:
                return (text or "-").replace("|", "\\|").replace("\n", " ")
            lines += ["### Waived findings", "",
                      "Findings a reviewer marked false-positive / "
                      "accepted-risk, with the reason recorded at triage:", "",
                      "| Location | Severity | Rule | Category | Decision | "
                      "Reason | Reviewer |",
                      "|---|---|---|---|---|---|---|"]
            for w in context.gate.waivers:
                lines.append(
                    f"| {_cell(w.location)} | {_cell(w.severity)} | "
                    f"{_cell(w.rule_id)} | {_cell(w.category)} | "
                    f"{_cell(w.decision)} | {_cell(w.reason)} | "
                    f"{_cell(w.reviewer)} |")
            lines.append("")

        severities = result.severity_totals()
        if severities:
            lines += ["## Findings by severity", "",
                      "| Severity | Count |", "|---|---|"]
            lines += [f"| {s.value} | {c} |" for s, c in severities.items()]
            lines.append("")

        lines += ["## Findings", ""]
        for analysis in result.analyses:
            if not analysis.findings:
                continue
            rel = relative_to_root(analysis.path, result.root)
            lines += [f"### `{rel}`", ""]
            for finding in analysis.sorted_findings():
                refs = " ".join(x for x in (finding.cwe, finding.owasp) if x)
                lines.append(
                    f"- **{finding.severity.value}** L{finding.line} "
                    f"`{finding.rule_id}` - {finding.message}"
                    + (f" _({refs})_" if refs else "")
                )
                if finding.remediation:
                    lines.append(f"  - Fix: {finding.remediation}")
            lines.append("")

        destination.write_text("\n".join(lines), encoding="utf-8")
        return destination
