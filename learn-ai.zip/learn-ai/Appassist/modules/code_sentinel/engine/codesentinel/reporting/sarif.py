"""
SARIF 2.1.0 exporter - the industry interchange format for SAST results.

SARIF (Static Analysis Results Interchange Format, OASIS standard) is what
GitHub Code Scanning, Azure DevOps, VS Code SARIF viewers and most result
aggregators consume. Emitting it lets CodeSentinel findings flow into any
of those without a bespoke adapter.

Layout notes:
  * One `run` per scan. Every distinct rule seen in the findings gets a
    `reportingDescriptor` in tool.driver.rules; results reference it by
    ruleIndex.
  * `partialFingerprints` carries the same stable fingerprint the triage
    store uses (domain.assign_fingerprints), so an external consumer's
    dedup/baseline logic agrees with CodeSentinel's own.
  * `properties.security-severity` is set per rule - GitHub uses it to
    bucket security alerts (>=9 critical, >=7 high, >=4 medium, else low).
  * File URIs are project-relative POSIX paths under the SRCROOT base, the
    layout GitHub and most viewers expect.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

from ..domain.models import (
    Finding, RiskCategory, Severity, assign_fingerprints, relative_to_root,
)
from .base import Exporter, ReportContext

SARIF_VERSION = "2.1.0"
SARIF_SCHEMA = "https://json.schemastore.org/sarif-2.1.0.json"

#: Key under which the CodeSentinel triage fingerprint is published.
FINGERPRINT_KEY = "codeSentinelFingerprint/v1"

#: SARIF has three levels; everything gate-blocking maps to "error".
_LEVELS: dict[Severity, str] = {
    Severity.BLOCKER: "error",
    Severity.CRITICAL: "error",
    Severity.HIGH: "error",
    Severity.MEDIUM: "warning",
    Severity.LOW: "note",
    Severity.INFO: "note",
}

#: GitHub security-severity scale (CVSS-like, 0.0-10.0, string-typed).
_SECURITY_SEVERITY: dict[Severity, str] = {
    Severity.BLOCKER: "9.8",
    Severity.CRITICAL: "9.1",
    Severity.HIGH: "7.5",
    Severity.MEDIUM: "5.0",
    Severity.LOW: "3.1",
    Severity.INFO: "1.0",
}


def _utc(stamp: datetime | None) -> str | None:
    """SARIF wants UTC ISO-8601 with a trailing Z; naive stamps are local."""
    if stamp is None:
        return None
    if stamp.tzinfo is None:
        stamp = stamp.astimezone()
    return stamp.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _slug(text: str) -> str:
    return "-".join(text.lower().split())


def _rule_descriptor(finding: Finding) -> dict:
    """reportingDescriptor for one rule, from its first-seen finding."""
    tags = []
    if finding.category in RiskCategory.SECURITY_CATEGORIES:
        tags.append("security")
    if finding.category:
        tags.append(_slug(finding.category))
    if finding.cwe:
        tags.append(f"external/cwe/{finding.cwe.lower()}")

    descriptor: dict = {
        "id": finding.rule_id,
        "name": finding.rule_id,
        "shortDescription": {"text": finding.truncated_message(160)},
        "fullDescription": {"text": finding.message},
        "defaultConfiguration": {"level": _LEVELS[finding.severity]},
        "properties": {
            "tags": tags,
            "severity": finding.severity.value,
            "category": finding.category,
            "confidence": finding.confidence,
        },
    }
    if finding.category in RiskCategory.SECURITY_CATEGORIES:
        descriptor['properties']['security-severity'] = _SECURITY_SEVERITY[finding.severity]
    if finding.remediation:
        descriptor["help"] = {"text": finding.remediation}
    if finding.cwe:
        descriptor["properties"]["cwe"] = finding.cwe
    if finding.owasp:
        descriptor["properties"]["owasp"] = finding.owasp
    return descriptor


class SarifExporter(Exporter):
    format_id = "sarif"
    display_name = "SARIF 2.1.0 (code scanning)"
    extension = ".sarif"

    def export(self, context: ReportContext, destination: Path) -> Path:
        result = context.result

        rules: list[dict] = []
        rule_index: dict[str, int] = {}
        results: list[dict] = []

        for analysis in result.analyses:
            rel = relative_to_root(analysis.path, result.root)
            findings = analysis.findings
            fingerprints = assign_fingerprints(findings, rel)
            for finding, fingerprint in zip(findings, fingerprints):
                index = rule_index.get(finding.rule_id)
                if index is None:
                    index = len(rules)
                    rule_index[finding.rule_id] = index
                    rules.append(_rule_descriptor(finding))

                region: dict = {"startLine": max(1, finding.line)}
                if finding.snippet:
                    region["snippet"] = {"text": finding.snippet}
                results.append({
                    "ruleId": finding.rule_id,
                    "ruleIndex": index,
                    "level": _LEVELS[finding.severity],
                    "message": {"text": finding.message},
                    "locations": [{
                        "physicalLocation": {
                            "artifactLocation": {
                                "uri": quote(rel.replace('\\', '/'), safe='/'),
                                "uriBaseId": "SRCROOT",
                            },
                            "region": region,
                        },
                    }],
                    "partialFingerprints": {FINGERPRINT_KEY: fingerprint},
                    "properties": {
                        "severity": finding.severity.value,
                        "category": finding.category,
                        "confidence": finding.confidence,
                        "tool": finding.tool,
                    },
                })

        run: dict = {
            "tool": {
                "driver": {
                    "name": context.tool_name,
                    "version": context.tool_version,
                    "informationUri": "https://codesentinel.local/",
                    "rules": rules,
                },
            },
            "automationDetails": {
                "id": f"codesentinel/{_slug(context.project_name) or 'scan'}",
            },
            "columnKind": "utf16CodeUnits",
            "results": results,
            "properties": {
                "scores": {
                    "security": context.scorecard.security,
                    "reliability": context.scorecard.reliability,
                    "maintainability": context.scorecard.maintainability,
                    "performance": context.scorecard.performance,
                    "overall": context.scorecard.overall,
                    "grade": context.scorecard.grade,
                },
                "qualityGate": {
                    "passed": context.gate.passed,
                    "reasons": context.gate.reasons,
                },
            },
        }

        diagnostics = [error for analysis in result.analyses for error in analysis.tool_errors]
        invocation: dict = {"executionSuccessful": not diagnostics}
        if diagnostics:
            invocation['toolExecutionNotifications'] = [
                {'level': 'error', 'message': {'text': error}} for error in diagnostics]
        started = _utc(result.started_at)
        finished = _utc(result.finished_at)
        if started:
            invocation["startTimeUtc"] = started
        if finished:
            invocation["endTimeUtc"] = finished
        run["invocations"] = [invocation]

        # SRCROOT lets viewers resolve the relative uris. A CI-posted scan
        # may carry a symbolic root ("ci-scan") that has no file URI - the
        # base id is then simply left undeclared, which SARIF permits.
        try:
            root_uri = result.root.resolve().as_uri()
            run["originalUriBaseIds"] = {
                "SRCROOT": {"uri": root_uri.rstrip("/") + "/"},
            }
        except (ValueError, OSError):
            pass

        document = {
            "$schema": SARIF_SCHEMA,
            "version": SARIF_VERSION,
            "runs": [run],
        }
        destination.write_text(
            json.dumps(document, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        return destination
