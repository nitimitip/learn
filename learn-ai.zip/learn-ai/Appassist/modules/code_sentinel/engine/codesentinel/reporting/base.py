"""Exporter contract and registry."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .. import APP_NAME, APP_VERSION
from ..domain.models import ScanResult
from ..domain.scoring import QualityGate, QualityGateResult, ScoreCard, compute_scorecard


@dataclass(slots=True)
class ReportContext:
    """Everything an exporter needs to render one scan."""

    result: ScanResult
    scorecard: ScoreCard
    gate: QualityGateResult
    project_name: str = ""
    generated_at: datetime = field(default_factory=datetime.now)
    tool_name: str = APP_NAME
    tool_version: str = APP_VERSION
    gate_scope: str = 'Full codebase'
    evaluation_note: str = 'Evaluated using the configured static-analysis policy.'

    @classmethod
    def from_result(cls, result: ScanResult, project_name: str = "") -> "ReportContext":
        return cls(
            result=result,
            scorecard=compute_scorecard(result),
            gate=QualityGate().evaluate(result),
            project_name=project_name or result.root.name,
        )


class Exporter(ABC):
    """One output format. Exporters must be side-effect free besides the file."""

    #: Format id used on the CLI (e.g. "pdf") - must be unique.
    format_id: str = ""
    #: Human label shown in the UI.
    display_name: str = ""
    #: Output file extension including the dot.
    extension: str = ""

    @abstractmethod
    def export(self, context: ReportContext, destination: Path) -> Path:
        """Write the report to `destination` and return the written path."""


class ExporterRegistry:
    """Registry of available exporters; plugins may add more."""

    def __init__(self) -> None:
        self._exporters: dict[str, Exporter] = {}

    def register(self, exporter: Exporter) -> None:
        if not exporter.format_id:
            raise ValueError("Exporter must declare a format_id.")
        self._exporters[exporter.format_id] = exporter

    def get(self, format_id: str) -> Exporter | None:
        return self._exporters.get(format_id)

    def all(self) -> list[Exporter]:
        return sorted(self._exporters.values(), key=lambda e: e.format_id)

    def format_ids(self) -> list[str]:
        return sorted(self._exporters)


def build_default_registry() -> ExporterRegistry:
    """Registry with every built-in exporter registered."""
    from .excel import ExcelExporter
    from .html import HtmlExporter
    from .pdf import PdfExporter
    from .sarif import SarifExporter
    from .text_formats import (
        CsvExporter, JsonExporter, MarkdownExporter, XmlExporter,
    )

    registry = ExporterRegistry()
    for exporter in (
        PdfExporter(), HtmlExporter(), ExcelExporter(), SarifExporter(),
        JsonExporter(), CsvExporter(), XmlExporter(), MarkdownExporter(),
    ):
        registry.register(exporter)
    return registry
