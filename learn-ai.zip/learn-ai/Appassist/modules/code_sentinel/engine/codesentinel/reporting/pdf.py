"""
Enterprise PDF audit report (ReportLab).

Structure: cover page (KPI + scorecard bands, severity bar) -> executive
summary -> compliance summary (OWASP / CWE) -> triage index -> contiguous
per-file findings sections -> appendix (scan configuration & metadata).
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import (
    BaseDocTemplate, Flowable, Frame, KeepTogether, NextPageTemplate,
    PageBreak, PageTemplate, Paragraph, Spacer, Table, TableStyle,
)

from ..domain.models import FileAnalysis, ScanResult, Severity, relative_to_root
from ..domain.scoring import RATING_COLOURS, file_rating
from ..domain.assurance import language_assurance
from .base import Exporter, ReportContext

PAGE_SIZE = A4
MARGIN_LEFT = 18 * mm
MARGIN_RIGHT = 18 * mm
MARGIN_TOP = 24 * mm
MARGIN_BOTTOM = 20 * mm
CONTENT_WIDTH = PAGE_SIZE[0] - MARGIN_LEFT - MARGIN_RIGHT


class Theme:
    """Central palette for the PDF layer."""

    INK = colors.HexColor("#0f172a")
    BRAND = colors.HexColor("#1e293b")
    ACCENT = colors.HexColor("#0284c7")
    MUTED = colors.HexColor("#64748b")
    FAINT = colors.HexColor("#94a3b8")
    HAIRLINE = colors.HexColor("#e2e8f0")
    GRID = colors.HexColor("#cbd5e1")
    ZEBRA = colors.HexColor("#f8fafc")
    PANEL = colors.HexColor("#f1f5f9")
    CLEAN = colors.HexColor("#15803d")
    FAIL = colors.HexColor("#b91c1c")


def _severity_colour(severity: Severity) -> colors.Color:
    return colors.HexColor(severity.hex_colour)


def _severity_tint(severity: Severity) -> colors.Color:
    return colors.HexColor(severity.tint_colour)


# ===========================================================================
# Custom flowables
# ===========================================================================


class HorizontalRule(Flowable):
    """A thin full-width rule used to separate sections."""

    def __init__(self, width: float, thickness: float = 0.6,
                 colour: colors.Color = Theme.HAIRLINE,
                 space_before: float = 0.0, space_after: float = 0.0) -> None:
        super().__init__()
        self._width = width
        self._thickness = thickness
        self._colour = colour
        self._space_before = space_before
        self._space_after = space_after

    def wrap(self, available_width: float, available_height: float) -> tuple[float, float]:
        self._width = min(self._width, available_width)
        return self._width, self._thickness + self._space_before + self._space_after

    def draw(self) -> None:
        canvas: Canvas = self.canv
        canvas.setStrokeColor(self._colour)
        canvas.setLineWidth(self._thickness)
        canvas.line(0, self._space_after, self._width, self._space_after)


class KpiCard(Flowable):
    """A metric tile: large numeric value over a small uppercase caption."""

    HEIGHT = 20 * mm

    def __init__(self, value: str, caption: str, width: float,
                 value_colour: colors.Color = Theme.INK,
                 background: colors.Color = Theme.PANEL) -> None:
        super().__init__()
        self._value = value
        self._caption = caption
        self._width = width
        self._value_colour = value_colour
        self._background = background

    def wrap(self, available_width: float, available_height: float) -> tuple[float, float]:
        return self._width, self.HEIGHT

    def draw(self) -> None:
        canvas: Canvas = self.canv
        canvas.setFillColor(self._background)
        canvas.setStrokeColor(Theme.HAIRLINE)
        canvas.setLineWidth(0.5)
        canvas.roundRect(0, 0, self._width, self.HEIGHT, 2 * mm, stroke=1, fill=1)

        canvas.setFillColor(self._value_colour)
        font_size = 16 if len(self._value) <= 8 else 11
        canvas.setFont("Helvetica-Bold", font_size)
        canvas.drawCentredString(self._width / 2, self.HEIGHT - 10.5 * mm, self._value)

        canvas.setFillColor(Theme.MUTED)
        canvas.setFont("Helvetica", 6.5)
        canvas.drawCentredString(self._width / 2, 4.5 * mm, self._caption.upper())


class SeverityBar(Flowable):
    """A stacked proportional bar showing the severity mix across a scan."""

    HEIGHT = 6 * mm

    def __init__(self, breakdown: dict[Severity, int], width: float) -> None:
        super().__init__()
        self._breakdown = breakdown
        self._width = width
        self._total = sum(breakdown.values()) or 1

    def wrap(self, available_width: float, available_height: float) -> tuple[float, float]:
        self._width = min(self._width, available_width)
        return self._width, self.HEIGHT

    def draw(self) -> None:
        canvas: Canvas = self.canv
        cursor = 0.0
        for severity, count in self._breakdown.items():
            segment = self._width * (count / self._total)
            canvas.setFillColor(_severity_colour(severity))
            canvas.rect(cursor, 0, segment, self.HEIGHT, stroke=0, fill=1)
            if segment > 14 * mm:
                canvas.setFillColor(colors.white)
                canvas.setFont("Helvetica-Bold", 6.5)
                canvas.drawCentredString(cursor + segment / 2,
                                         self.HEIGHT / 2 - 2.2,
                                         f"{severity.value} {count}")
            cursor += segment
        canvas.setStrokeColor(Theme.GRID)
        canvas.setLineWidth(0.4)
        canvas.rect(0, 0, self._width, self.HEIGHT, stroke=1, fill=0)


# ===========================================================================
# Page furniture
# ===========================================================================


class PageDecorator:
    """Running header and footer on every page."""

    def __init__(self, document_title: str, subtitle: str) -> None:
        self._title = document_title
        self._subtitle = subtitle
        self._timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")

    def __call__(self, canvas: Canvas, doc: BaseDocTemplate) -> None:
        canvas.saveState()
        self._draw_header(canvas)
        self.draw_footer(canvas, doc.page)
        canvas.restoreState()

    def _draw_header(self, canvas: Canvas) -> None:
        page_width, page_height = PAGE_SIZE
        baseline = page_height - 14 * mm

        canvas.setFillColor(Theme.ACCENT)
        canvas.rect(MARGIN_LEFT, baseline - 0.6 * mm, 3 * mm, 3.4 * mm, stroke=0, fill=1)

        canvas.setFillColor(Theme.BRAND)
        canvas.setFont("Helvetica-Bold", 7.5)
        canvas.drawString(MARGIN_LEFT + 5 * mm, baseline, self._title.upper())

        canvas.setFillColor(Theme.FAINT)
        canvas.setFont("Helvetica", 7)
        canvas.drawRightString(page_width - MARGIN_RIGHT, baseline, self._timestamp)

        canvas.setStrokeColor(Theme.HAIRLINE)
        canvas.setLineWidth(0.5)
        canvas.line(MARGIN_LEFT, baseline - 3 * mm,
                    page_width - MARGIN_RIGHT, baseline - 3 * mm)

    def draw_footer(self, canvas: Canvas, page_number: int) -> None:
        page_width = PAGE_SIZE[0]
        baseline = 12 * mm
        canvas.setStrokeColor(Theme.HAIRLINE)
        canvas.setLineWidth(0.5)
        canvas.line(MARGIN_LEFT, baseline + 4 * mm,
                    page_width - MARGIN_RIGHT, baseline + 4 * mm)
        canvas.setFillColor(Theme.FAINT)
        canvas.setFont("Helvetica", 6.5)
        canvas.drawString(MARGIN_LEFT, baseline, self._subtitle)
        canvas.drawRightString(page_width - MARGIN_RIGHT, baseline,
                               f"Page {page_number}")


class ReportDocTemplate(BaseDocTemplate):
    """Two page templates: clean cover, decorated body."""

    def __init__(self, path: Path, title: str, header_title: str,
                 footer_note: str) -> None:
        super().__init__(
            str(path), pagesize=PAGE_SIZE,
            leftMargin=MARGIN_LEFT, rightMargin=MARGIN_RIGHT,
            topMargin=MARGIN_TOP, bottomMargin=MARGIN_BOTTOM,
            title=title, author="CodeSentinel Enterprise",
            subject="Static analysis findings",
        )
        decorate = PageDecorator(header_title, footer_note)
        frame = Frame(MARGIN_LEFT, MARGIN_BOTTOM, CONTENT_WIDTH,
                      PAGE_SIZE[1] - MARGIN_TOP - MARGIN_BOTTOM,
                      id="content", showBoundary=0)
        cover_frame = Frame(MARGIN_LEFT, MARGIN_BOTTOM, CONTENT_WIDTH,
                            PAGE_SIZE[1] - MARGIN_BOTTOM - 20 * mm,
                            id="cover", showBoundary=0)
        self.addPageTemplates([
            PageTemplate(id="cover", frames=[cover_frame],
                         onPage=lambda c, d: decorate.draw_footer(c, d.page)),
            PageTemplate(id="body", frames=[frame], onPage=decorate),
        ])


# ===========================================================================
# The exporter
# ===========================================================================


class PdfExporter(Exporter):
    format_id = "pdf"
    display_name = "PDF (enterprise audit report)"
    extension = ".pdf"

    def __init__(self) -> None:
        self._styles = self._build_styles()

    # ---- Public API ----------------------------------------------------------

    def export(self, context: ReportContext, destination: Path) -> Path:
        doc = ReportDocTemplate(
            destination,
            title=f"Static Analysis Report - {context.project_name}",
            header_title=f"CodeSentinel - {context.project_name}",
            footer_note="Automated static analysis - findings require engineer triage.",
        )
        story: list[object] = [NextPageTemplate("body")]
        story.extend(self._cover_page(context))
        story.append(PageBreak())
        story.extend(self._executive_summary(context))
        story.extend(self._analysis_assurance(context))
        story.extend(self._compliance_summary(context))
        story.extend(self._waived_findings_section(context))
        story.extend(self._per_file_index(context))
        story.append(PageBreak())

        story.append(Paragraph("Detailed Findings by File", self._styles["Section"]))
        story.append(HorizontalRule(CONTENT_WIDTH, 1.0, Theme.ACCENT, space_after=1))
        story.append(Spacer(1, 5 * mm))
        for index, analysis in enumerate(context.result.analyses, start=1):
            if index > 1:
                story.append(Spacer(1, 6 * mm))
                story.append(HorizontalRule(CONTENT_WIDTH, 0.5, Theme.HAIRLINE))
                story.append(Spacer(1, 6 * mm))
            story.extend(self._file_section(index, analysis, context.result))

        story.append(PageBreak())
        story.extend(self._appendix(context))
        doc.build(story)
        return destination

    # ---- Cover page ------------------------------------------------------------

    def _cover_page(self, context: ReportContext) -> list[object]:
        result = context.result
        scorecard = context.scorecard
        aggregate = result.severity_totals()
        worst = next(iter(aggregate), None)
        clean = sum(1 for a in result.analyses if a.total_issues == 0 and not a.tool_errors and a.tools_run and a.metrics)

        elements: list[object] = [
            Spacer(1, 18 * mm),
            Paragraph("STATIC ANALYSIS - CONFIDENTIAL", self._styles["Eyebrow"]),
            Spacer(1, 2 * mm),
            Paragraph("Code Quality &amp;<br/>Security Audit", self._styles["CoverTitle"]),
            Spacer(1, 5 * mm),
            HorizontalRule(52 * mm, 1.6, Theme.ACCENT),
            Spacer(1, 7 * mm),
            Paragraph(self._escape(
                f"{context.project_name} - {len(result.analyses)} file(s) - "
                f"{result.total_code_lines:,} lines of code"
            ), self._styles["CoverScope"]),
            Spacer(1, 12 * mm),
        ]

        gutter = 4 * mm
        card_width = (CONTENT_WIDTH - 3 * gutter) / 4

        def band(cards: list[KpiCard]) -> Table:
            table = Table([cards], colWidths=[card_width] * len(cards), hAlign="LEFT")
            table.setStyle(TableStyle([
                ("LEFTPADDING", (0, 0), (-1, -1), 0),
                ("RIGHTPADDING", (0, 0), (-2, -1), gutter),
                ("RIGHTPADDING", (-1, 0), (-1, -1), 0),
                ("TOPPADDING", (0, 0), (-1, -1), 0),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
            ]))
            return table

        grade_colour = colors.HexColor(RATING_COLOURS.get(scorecard.grade, "#0f172a"))
        gate_colour = Theme.CLEAN if context.gate.passed else Theme.FAIL
        elements.append(band([
            KpiCard(scorecard.grade, "Overall Grade", card_width, grade_colour),
            KpiCard(context.gate.verdict, "Quality Gate", card_width, gate_colour),
            KpiCard(str(result.total_findings), "Total Findings", card_width,
                    Theme.INK if result.total_findings else Theme.CLEAN),
            KpiCard(worst.value if worst else "NONE", "Highest Severity", card_width,
                    _severity_colour(worst) if worst else Theme.CLEAN),
        ]))
        elements.append(Spacer(1, 6 * mm))
        elements.append(band([
            KpiCard(str(scorecard.security), "Security Score", card_width,
                    Theme.CLEAN if scorecard.security >= 80 else Theme.FAIL),
            KpiCard(str(scorecard.reliability), "Reliability", card_width),
            KpiCard(str(scorecard.maintainability), "Maintainability", card_width),
            KpiCard(str(scorecard.performance), "Performance", card_width),
        ]))
        elements.append(Spacer(1, 6 * mm))
        elements.append(band([
            KpiCard(scorecard.technical_debt, "Technical Debt", card_width),
            KpiCard(scorecard.risk_level, "Risk Level", card_width,
                    Theme.FAIL if scorecard.risk_level in ("CRITICAL", "HIGH")
                    else Theme.CLEAN),
            KpiCard(f"{clean}/{len(result.analyses)}", "No findings / errors", card_width,
                    Theme.CLEAN if clean else Theme.INK),
            KpiCard(f"{result.duplication_ratio:.0%}", "Duplication", card_width,
                    Theme.FAIL if result.duplication_ratio > 0.10 else Theme.INK),
        ]))

        if aggregate:
            elements.extend([
                Spacer(1, 10 * mm),
                Paragraph("Severity Distribution", self._styles["MinorHeading"]),
                Spacer(1, 2 * mm),
                SeverityBar(aggregate, CONTENT_WIDTH),
            ])

        if not context.gate.passed:
            elements.append(Spacer(1, 4 * mm))
            for reason in context.gate.reasons:
                elements.append(Paragraph(
                    f'<font color="#b91c1c">X {self._escape(reason)}</font>',
                    self._styles["Footnote"],
                ))

        if context.gate.waivers:
            elements.append(Spacer(1, 4 * mm))
            elements.append(Paragraph(
                f'<font color="#64748b">Report includes '
                f'{len(context.gate.waivers)} reviewer waiver(s) - see the '
                f'Waived Findings table.</font>',
                self._styles["Footnote"],
            ))

        elements.extend([
            Spacer(1, 10 * mm),
            HorizontalRule(CONTENT_WIDTH, 0.5, Theme.HAIRLINE),
            Spacer(1, 3 * mm),
            Paragraph(
                f"Generated {context.generated_at:%d %B %Y at %H:%M} - "
                f"{context.tool_name} v{context.tool_version} - "
                f"fully offline analysis",
                self._styles["Footnote"],
            ),
        ])
        return elements

    # ---- Executive summary -------------------------------------------------------

    def _executive_summary(self, context: ReportContext) -> list[object]:
        result = context.result
        total = result.total_findings
        clean = sum(1 for a in result.analyses if a.total_issues == 0)
        aggregate = result.severity_totals()

        elements: list[object] = [
            Paragraph("Executive Summary", self._styles["Section"]),
            HorizontalRule(CONTENT_WIDTH, 1.0, Theme.ACCENT, space_after=1),
            Spacer(1, 5 * mm),
            Paragraph(self._verdict(context, total, clean, aggregate),
                      self._styles["Lead"]),
            Spacer(1, 7 * mm),
        ]

        scorecard = context.scorecard
        rows = [
            ("Project", context.project_name),
            ("Scan root", str(result.root)),
            ("Files analysed", f"{len(result.analyses)} "
             f"({result.files_from_cache} from incremental cache)"),
            ("Files with findings", str(len(result.analyses) - clean)),
            ("Total findings", f"{total} "
             f"({result.suppressed_count} suppressed by triage)"),
            ("Lines of code", f"{result.total_code_lines:,}"),
            ("Duplicated lines", f"{result.duplicated_lines:,} "
             f"({result.duplication_ratio:.0%})"),
            ("Overall grade", f"{scorecard.grade} ({scorecard.overall}/100)"),
            ("Maintainability rating",
             f"{scorecard.maintainability_rating} (A best - E worst)"),
            ("Technical debt", scorecard.technical_debt),
            ("Quality gate",
             (f"PASSED with {len(context.gate.notes)} reviewer waiver(s)"
              if context.gate.notes else "PASSED") if context.gate.passed
             else f"FAILED - {'; '.join(context.gate.reasons)}"),
            ("Scan duration", f"{result.duration_seconds:.1f} s"),
        ]
        elements.extend([
            Paragraph("Scope &amp; Outcome", self._styles["MinorHeading"]),
            Spacer(1, 2 * mm),
            self._key_value_table(rows),
            Spacer(1, 7 * mm),
        ])

        if aggregate:
            elements.extend([
                Paragraph("Findings by Severity", self._styles["MinorHeading"]),
                Spacer(1, 2 * mm),
                self._severity_table(aggregate, total),
                Spacer(1, 8 * mm),
            ])

        categories = result.category_totals()
        if categories:
            elements.extend([
                Paragraph("Findings by Risk Category", self._styles["MinorHeading"]),
                Spacer(1, 2 * mm),
                self._count_table("Risk Category", categories, total),
                Spacer(1, 8 * mm),
            ])

        distribution = result.language_distribution()
        if distribution:
            code = result.total_code_lines or 1
            elements.extend([
                Paragraph("Language Distribution", self._styles["MinorHeading"]),
                Spacer(1, 2 * mm),
                self._count_table("Language", distribution, code, suffix=" LOC"),
                Spacer(1, 8 * mm),
            ])
        return elements

    def _compliance_summary(self, context: ReportContext) -> list[object]:
        """OWASP Top-10 and CWE rollups across every finding."""
        owasp: dict[str, int] = {}
        cwe: dict[str, int] = {}
        for _, finding in context.result.all_findings():
            if finding.owasp:
                owasp[finding.owasp] = owasp.get(finding.owasp, 0) + 1
            if finding.cwe:
                cwe[finding.cwe] = cwe.get(finding.cwe, 0) + 1
        if not owasp and not cwe:
            return []

        total = context.result.total_findings or 1
        elements: list[object] = [
            Paragraph("Compliance Mapping", self._styles["Section"]),
            HorizontalRule(CONTENT_WIDTH, 1.0, Theme.ACCENT, space_after=1),
            Spacer(1, 4 * mm),
            Paragraph(
                "Findings mapped to industry taxonomies. Zero findings in a "
                "category does not certify compliance - static analysis covers "
                "only what is visible in source code.",
                self._styles["Lead"],
            ),
            Spacer(1, 5 * mm),
        ]
        if owasp:
            ordered = dict(sorted(owasp.items(), key=lambda kv: -kv[1]))
            elements.extend([
                Paragraph("OWASP Top 10 (2021)", self._styles["MinorHeading"]),
                Spacer(1, 2 * mm),
                self._count_table("OWASP Category", ordered, total),
                Spacer(1, 6 * mm),
            ])
        if cwe:
            ordered = dict(sorted(cwe.items(), key=lambda kv: -kv[1])[:15])
            elements.extend([
                Paragraph("Top CWE Weaknesses", self._styles["MinorHeading"]),
                Spacer(1, 2 * mm),
                self._count_table("CWE", ordered, total),
                Spacer(1, 8 * mm),
            ])
        return elements

    def _verdict(self, context: ReportContext, total: int, clean: int,
                 aggregate: dict[Severity, int]) -> str:
        result = context.result
        count = len(result.analyses)
        if total == 0:
            return (f"No open findings were recorded across {count} file(s). Review analysis coverage and the gate verdict. "
                    f"No quality or security findings were raised.")

        worst = next(iter(aggregate))
        affected = count - clean
        elevated = sum(aggregate.get(s, 0) for s in
                       (Severity.BLOCKER, Severity.CRITICAL, Severity.HIGH))
        sentence = (
            f"Analysis of {count} file(s) surfaced <b>{total} finding(s)</b> across "
            f"<b>{affected} file(s)</b>. The highest severity observed was "
            f'<b><font color="{worst.hex_colour}">{worst.value}</font></b>.'
        )
        if elevated:
            sentence += (f" {elevated} finding(s) are rated HIGH or above and "
                         f"warrant remediation before release.")
        else:
            sentence += (" No findings were rated HIGH or above; the remainder "
                         "are standards and maintainability observations.")

        destructive = sum(1 for _, f in result.all_findings()
                          if f.category == "Destructive Operation")
        secrets = sum(1 for _, f in result.all_findings()
                      if f.category == "Hardcoded Secret")
        if destructive:
            sentence += (
                f' <b><font color="#7f1d1d">{destructive} destructive-operation '
                f"risk(s)</font></b> were identified (wildcard deletes, unguarded "
                f"recursive removal, missing WHERE clauses); these can cause "
                f"irreversible data loss and should be reviewed first."
            )
        if secrets:
            sentence += (f" {secrets} hardcoded credential(s) were detected - "
                         f"rotate the exposed secrets and move them out of "
                         f"source control.")
        return sentence

    # ---- Index and per-file sections ------------------------------------------

    def _per_file_index(self, context: ReportContext) -> list[object]:
        analyses = context.result.analyses
        header = self._header_row(["#", "File", "Findings", "Rating", "Highest Severity"])
        ordered = sorted(
            enumerate(analyses, start=1),
            key=lambda pair: (pair[1].worst_severity.sort_rank if pair[1].worst_severity else 99,
                              -pair[1].total_issues, pair[1].path.name),
        )
        rows: list[list[object]] = [header]
        for original_index, analysis in ordered:
            worst = analysis.worst_severity
            rating = file_rating(analysis)
            rows.append([
                Paragraph(str(original_index), self._styles["CellCentre"]),
                Paragraph(self._escape(
                    relative_to_root(analysis.path, context.result.root)),
                    self._styles["CellStrong"]),
                Paragraph(str(analysis.total_issues), self._styles["CellCentre"]),
                Paragraph(
                    f'<font color="{RATING_COLOURS[rating]}"><b>{rating}</b></font>',
                    self._styles["CellCentre"]),
                self._severity_cell(worst) if worst else Paragraph(
                    '<b>INCOMPLETE</b>' if analysis.tool_errors or not analysis.tools_run or analysis.metrics is None else '<b>NONE RECORDED</b>',
                    self._styles["CellCentre"]),
            ])
        table = Table(rows, colWidths=[10 * mm, 92 * mm, 20 * mm, 18 * mm, 34 * mm],
                      repeatRows=1)
        table.setStyle(self._table_style(columns=5, numeric_cols=(0, 2, 3, 4)))
        return [
            Paragraph("Triage Index", self._styles["MinorHeading"]),
            Spacer(1, 2 * mm),
            table,
        ]

    def _file_section(self, index: int, analysis: FileAnalysis,
                      result: ScanResult) -> list[object]:
        worst = analysis.worst_severity
        badge = (f'<font color="{worst.hex_colour}"><b>{worst.value}</b></font>'
                 if worst else '<b>NONE RECORDED</b>')

        heading = Paragraph(
            f'<font color="#94a3b8">{index:02d}</font>&nbsp;&nbsp;'
            f"{self._escape(relative_to_root(analysis.path, result.root))}",
            self._styles["FileHeading"],
        )
        metrics_bits = ""
        if analysis.metrics:
            m = analysis.metrics
            rating = file_rating(analysis)
            metrics_bits = (
                f"&nbsp;&nbsp;-&nbsp;&nbsp;{m.code_lines} LOC"
                f"&nbsp;&nbsp;-&nbsp;&nbsp;CC {m.complexity}"
                f'&nbsp;&nbsp;-&nbsp;&nbsp;Rating: <font color="'
                f'{RATING_COLOURS[rating]}"><b>{rating}</b></font>'
            )
        subline = Paragraph(
            f"{self._escape(analysis.language_id)}"
            f"&nbsp;&nbsp;-&nbsp;&nbsp;{analysis.total_issues} finding(s)"
            f"&nbsp;&nbsp;-&nbsp;&nbsp;Highest: {badge}{metrics_bits}",
            self._styles["Subline"],
        )
        elements: list[object] = [KeepTogether([heading, Spacer(1, 1.5 * mm), subline])]
        elements.append(Spacer(1, 4 * mm))
        elements.extend(self._findings_table(analysis))
        for error in analysis.tool_errors:
            elements.append(Paragraph(f"* {self._escape(error)}",
                                      self._styles["Warning"]))
        return elements

    def _findings_table(self, analysis: FileAnalysis) -> list[object]:
        findings = analysis.sorted_findings()
        if not findings:
            return [Paragraph("No open findings recorded. Check analysis evidence before concluding this file is clean.",
                              self._styles["Clean"]),
                    Spacer(1, 2 * mm)]

        header = self._header_row(["#", "Severity", "Line", "Rule", "Refs", "Description"])
        rows: list[list[object]] = [header]
        tints: list[tuple] = []
        for row_index, finding in enumerate(findings, start=1):
            description = self._escape(finding.truncated_message())
            if finding.category != "General":
                description = (
                    f'<font color="{Theme.MUTED.hexval()}" size="6.6">'
                    f"<b>{self._escape(finding.category.upper())}</b></font><br/>"
                    f"{description}"
                )
            if finding.remediation:
                remediation = " ".join(finding.remediation.split())
                description += (
                    f'<br/><font color="{Theme.ACCENT.hexval()}" size="7">'
                    f"<b>Fix:</b> {self._escape(remediation)}</font>"
                )
            description += f'<br/><b>Confidence:</b> {self._escape(finding.confidence)}'
            if finding.snippet:
                description += f'<br/><b>Evidence:</b> {self._escape(finding.snippet[:500])}'
            refs = "<br/>".join(x for x in (finding.cwe,
                                            finding.owasp.split("-")[0]) if x)
            rows.append([
                Paragraph(str(row_index), self._styles["CellCentre"]),
                self._severity_cell(finding.severity),
                Paragraph(str(finding.line), self._styles["CellCentre"]),
                Paragraph(self._escape(finding.rule_id), self._styles["MonoCell"]),
                Paragraph(self._escape(refs).replace('&lt;br/&gt;', '<br/>'), self._styles["MonoCell"]),
                Paragraph(description, self._styles["Cell"]),
            ])
            tints.append(("BACKGROUND", (1, row_index), (1, row_index),
                          _severity_tint(finding.severity)))

        table = Table(rows,
                      colWidths=[8 * mm, 20 * mm, 11 * mm, 24 * mm, 18 * mm, 93 * mm],
                      repeatRows=1)
        style = self._table_style(columns=6, numeric_cols=(0, 1, 2), compact=True)
        for command in tints:
            style.add(*command)
        table.setStyle(style)
        return [table, Spacer(1, 3 * mm)]

    # ---- Appendix -----------------------------------------------------------

    def _analysis_assurance(self, context: ReportContext) -> list[object]:
        elements = [PageBreak(), Paragraph("Analysis Assurance", self._styles["Section"]),
                    self._key_value_table([("Gate scope", context.gate_scope),
                                           ("Evaluation", context.evaluation_note)]), Spacer(1, 4 * mm)]
        rows = self._header_row(["Language", "Files / LOC", "Security", "Recorded analysis"])
        data = [rows]
        for row in language_assurance(context.result):
            values = [row['language'], f"{row['files']} / {row['lines']:,}", f"{row['security']}/100",
                      f"{row['coverage']}; {row['errors']} file(s) with errors. " + ', '.join(row['tools'])]
            data.append([Paragraph(self._escape(str(v)), self._styles["Cell"]) for v in values])
        table = Table(data, colWidths=[CONTENT_WIDTH*.17, CONTENT_WIDTH*.16, CONTENT_WIDTH*.14, CONTENT_WIDTH*.53], repeatRows=1)
        table.setStyle(self._table_style(4))
        elements.extend([table, Spacer(1, 3 * mm), Paragraph(
            "Coverage describes analyzer execution on submitted files. Rules-only languages have less analysis depth. "
            "Test coverage and runtime security testing are not measured. Scores describe detected findings, not proof of security.", self._styles["Footnote"]), Spacer(1, 6 * mm)])
        return elements

    def _appendix(self, context: ReportContext) -> list[object]:
        result = context.result
        rows = [
            ("Tool", f"{context.tool_name} v{context.tool_version}"),
            ("Operation mode", "Fully offline - no network access used"),
            ("Scan started", result.started_at.strftime("%Y-%m-%d %H:%M:%S")),
            ("Scan finished",
             result.finished_at.strftime("%Y-%m-%d %H:%M:%S")
             if result.finished_at else "-"),
            ("Duration", f"{result.duration_seconds:.1f} s"),
            ("Files analysed", str(len(result.analyses))),
            ("Served from incremental cache", str(result.files_from_cache)),
            ("Findings suppressed by triage", str(result.suppressed_count)),
            ("Report generated",
             context.generated_at.strftime("%Y-%m-%d %H:%M:%S")),
            ("Digital signature", "Not digitally signed"),
        ]
        return [
            Paragraph("Appendix - Scan Configuration &amp; Metadata",
                      self._styles["Section"]),
            HorizontalRule(CONTENT_WIDTH, 1.0, Theme.ACCENT, space_after=1),
            Spacer(1, 5 * mm),
            self._key_value_table(rows),
            Spacer(1, 6 * mm),
            Paragraph(
                "Methodology: findings are produced by CodeSentinel's built-in "
                "rule engine (pattern + entropy analysis), AST correctness "
                "checks, and Python data-flow taint tracking. Every finding "
                "carries severity, category, CWE/OWASP references, and concrete "
                "remediation guidance. Automated findings are evidence for an "
                "engineering review, not a substitute for one.",
                self._styles["Footnote"],
            ),
        ]

    # ---- Shared table builders -----------------------------------------------

    def _waived_findings_section(self, context: ReportContext) -> list[object]:
        """A detail table of every reviewer-waived finding, with its reason."""
        waivers = context.gate.waivers
        if not waivers:
            return []
        header = ["Location", "Severity", "Rule", "Category", "Decision",
                  "Reason", "Reviewer"]
        data = [[Paragraph(self._escape(h), self._styles["KeyCell"])
                 for h in header]]
        for w in waivers:
            data.append([
                Paragraph(self._escape(w.location), self._styles["Cell"]),
                Paragraph(self._escape(w.severity), self._styles["Cell"]),
                Paragraph(self._escape(w.rule_id), self._styles["Cell"]),
                Paragraph(self._escape(w.category), self._styles["Cell"]),
                Paragraph(self._escape(w.decision), self._styles["Cell"]),
                Paragraph(self._escape(w.reason or "-"), self._styles["Cell"]),
                Paragraph(self._escape(w.reviewer or "-"), self._styles["Cell"]),
            ])
        widths = [0.20, 0.09, 0.12, 0.14, 0.12, 0.21, 0.12]
        table = Table(data, colWidths=[CONTENT_WIDTH * w for w in widths],
                      repeatRows=1)
        table.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("BACKGROUND", (0, 0), (-1, 0), Theme.FAINT),
            ("LINEBELOW", (0, 0), (-1, -1), 0.4, Theme.HAIRLINE),
            ("TOPPADDING", (0, 0), (-1, -1), 3.5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ]))
        return [
            Paragraph("Waived Findings", self._styles["Section"]),
            HorizontalRule(CONTENT_WIDTH, 1.0, Theme.ACCENT, space_after=1),
            Spacer(1, 3 * mm),
            Paragraph(
                "Findings a reviewer marked a false positive or an accepted "
                "risk, excluded from scores and the gate. The reason recorded "
                "at triage is shown for each.", self._styles["Lead"]),
            Spacer(1, 4 * mm),
            table,
            PageBreak(),
        ]

    def _key_value_table(self, rows) -> Table:
        table = Table(
            [[Paragraph(self._escape(k), self._styles["KeyCell"]),
              Paragraph(self._escape(v), self._styles["Cell"])]
             for k, v in rows],
            colWidths=[46 * mm, CONTENT_WIDTH - 46 * mm],
        )
        table.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LINEBELOW", (0, 0), (-1, -2), 0.4, Theme.HAIRLINE),
            ("TOPPADDING", (0, 0), (-1, -1), 3.5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
            ("LEFTPADDING", (0, 0), (0, -1), 0),
            ("RIGHTPADDING", (-1, 0), (-1, -1), 0),
        ]))
        return table

    def _severity_table(self, breakdown: dict[Severity, int], total: int) -> Table:
        header = self._header_row(["Severity", "Count", "Share"])
        denominator = total or 1
        rows: list[list[object]] = [header]
        for severity, count in breakdown.items():
            rows.append([
                self._severity_cell(severity, align_left=True),
                Paragraph(str(count), self._styles["CellCentre"]),
                Paragraph(f"{count / denominator:.0%}", self._styles["CellCentre"]),
            ])
        rows.append([
            Paragraph("Total", self._styles["CellStrong"]),
            Paragraph(f"<b>{total}</b>", self._styles["CellCentre"]),
            Paragraph("<b>100%</b>", self._styles["CellCentre"]),
        ])
        table = Table(rows, colWidths=[44 * mm, 26 * mm, 26 * mm], hAlign="LEFT")
        style = self._table_style(columns=3, numeric_cols=(1, 2))
        style.add("LINEABOVE", (0, -1), (-1, -1), 0.8, Theme.BRAND)
        style.add("BACKGROUND", (0, -1), (-1, -1), Theme.PANEL)
        table.setStyle(style)
        return table

    def _count_table(self, label: str, counts: dict[str, int], total: int,
                     suffix: str = "") -> Table:
        header = self._header_row([label, "Count", "Share"])
        denominator = total or 1
        rows: list[list[object]] = [header]
        for key, count in counts.items():
            rows.append([
                Paragraph(self._escape(str(key)), self._styles["CellStrong"]),
                Paragraph(f"{count:,}{suffix}", self._styles["CellCentre"]),
                Paragraph(f"{count / denominator:.0%}", self._styles["CellCentre"]),
            ])
        table = Table(rows, colWidths=[96 * mm, 39 * mm, 39 * mm], repeatRows=1)
        table.setStyle(self._table_style(columns=3, numeric_cols=(1, 2)))
        return table

    def _header_row(self, labels) -> list[Paragraph]:
        return [Paragraph(label, self._styles["HeaderCell"]) for label in labels]

    def _severity_cell(self, severity: Severity, align_left: bool = False) -> Paragraph:
        style = self._styles["Cell"] if align_left else self._styles["CellCentre"]
        return Paragraph(
            f'<font color="{severity.hex_colour}"><b>{severity.value}</b></font>',
            style,
        )

    def _table_style(self, columns: int, numeric_cols: tuple[int, ...] = (),
                     compact: bool = False) -> TableStyle:
        padding = 3.5 if compact else 4.5
        commands: list[tuple] = [
            ("BACKGROUND", (0, 0), (columns - 1, 0), Theme.BRAND),
            ("TEXTCOLOR", (0, 0), (columns - 1, 0), colors.white),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, Theme.ZEBRA]),
            ("LINEBELOW", (0, 0), (-1, -1), 0.35, Theme.HAIRLINE),
            ("LINEBELOW", (0, 0), (-1, 0), 0.8, Theme.BRAND),
            ("LINEAFTER", (0, 0), (-2, -1), 0.3, Theme.HAIRLINE),
            ("TOPPADDING", (0, 0), (-1, -1), padding),
            ("BOTTOMPADDING", (0, 0), (-1, -1), padding),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ]
        for col in numeric_cols:
            commands.append(("ALIGN", (col, 0), (col, -1), "CENTER"))
        return TableStyle(commands)

    # ---- Styles ----------------------------------------------------------------

    @staticmethod
    def _build_styles() -> dict[str, ParagraphStyle]:
        base = getSampleStyleSheet()
        return {
            "CoverTitle": ParagraphStyle(
                "CoverTitle", parent=base["Title"], fontName="Helvetica-Bold",
                fontSize=30, leading=35, textColor=Theme.INK,
                alignment=TA_LEFT, spaceAfter=0),
            "Eyebrow": ParagraphStyle(
                "Eyebrow", parent=base["Normal"], fontName="Helvetica-Bold",
                fontSize=8, leading=10, textColor=Theme.ACCENT, alignment=TA_LEFT),
            "CoverScope": ParagraphStyle(
                "CoverScope", parent=base["Normal"], fontSize=11, leading=15,
                textColor=Theme.MUTED, alignment=TA_LEFT),
            "Section": ParagraphStyle(
                "Section", parent=base["Heading1"], fontName="Helvetica-Bold",
                fontSize=14, leading=17, textColor=Theme.INK,
                spaceBefore=0, spaceAfter=2),
            "MinorHeading": ParagraphStyle(
                "MinorHeading", parent=base["Heading3"], fontName="Helvetica-Bold",
                fontSize=8.5, leading=11, textColor=Theme.ACCENT,
                spaceBefore=0, spaceAfter=0),
            "FileHeading": ParagraphStyle(
                "FileHeading", parent=base["Heading2"], fontName="Helvetica-Bold",
                fontSize=11.5, leading=14, textColor=Theme.BRAND,
                spaceBefore=0, spaceAfter=0),
            "Subline": ParagraphStyle(
                "Subline", parent=base["Normal"], fontSize=7.5, leading=10,
                textColor=Theme.MUTED),
            "Lead": ParagraphStyle(
                "Lead", parent=base["Normal"], fontSize=9.5, leading=14,
                textColor=Theme.INK),
            "Clean": ParagraphStyle(
                "Clean", parent=base["Normal"], fontSize=9, leading=13,
                textColor=Theme.CLEAN),
            "Warning": ParagraphStyle(
                "Warning", parent=base["Normal"], fontSize=8, leading=11.5,
                textColor=Theme.MUTED, leftIndent=3, spaceAfter=1.5),
            "Cell": ParagraphStyle(
                "Cell", parent=base["Normal"], fontSize=7.8, leading=10.5,
                textColor=Theme.INK),
            "CellCentre": ParagraphStyle(
                "CellCentre", parent=base["Normal"], fontSize=7.8, leading=10.5,
                textColor=Theme.INK, alignment=TA_CENTER),
            "CellStrong": ParagraphStyle(
                "CellStrong", parent=base["Normal"], fontName="Helvetica-Bold",
                fontSize=7.8, leading=10.5, textColor=Theme.INK),
            "KeyCell": ParagraphStyle(
                "KeyCell", parent=base["Normal"], fontName="Helvetica-Bold",
                fontSize=7.8, leading=10.5, textColor=Theme.MUTED),
            "MonoCell": ParagraphStyle(
                "MonoCell", parent=base["Normal"], fontName="Courier",
                fontSize=7.2, leading=9.8, textColor=Theme.INK),
            "HeaderCell": ParagraphStyle(
                "HeaderCell", parent=base["Normal"], fontName="Helvetica-Bold",
                fontSize=7.5, leading=10, textColor=colors.white),
            "Footnote": ParagraphStyle(
                "Footnote", parent=base["Normal"], fontSize=7, leading=10,
                textColor=Theme.FAINT),
        }

    @staticmethod
    def _escape(text: str) -> str:
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
