"""Self-contained HTML report - single file, inline CSS, works offline."""

from __future__ import annotations

import html
from pathlib import Path

from ..domain.models import Severity, relative_to_root
from ..domain.scoring import RATING_COLOURS
from ..domain.assurance import language_assurance
from .base import Exporter, ReportContext

_CSS = """
:root { color-scheme: light; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font: 14px/1.55 'Segoe UI', system-ui, sans-serif; color: #0f172a;
       background: #f1f5f9; padding: 32px; }
.wrap { max-width: 1180px; margin: 0 auto; }
header.report { background: #1e293b; color: #fff; border-radius: 10px;
       padding: 28px 32px; margin-bottom: 24px; }
header.report h1 { font-size: 22px; font-weight: 600; }
header.report .sub { color: #94a3b8; font-size: 12.5px; margin-top: 6px; }
.cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
       gap: 12px; margin-bottom: 24px; }
.card { background: #fff; border: 1px solid #e2e8f0; border-radius: 10px;
       padding: 16px 18px; }
.card .v { font-size: 24px; font-weight: 700; }
.card .k { font-size: 10.5px; letter-spacing: .08em; text-transform: uppercase;
       color: #64748b; margin-top: 4px; }
.section { background: #fff; border: 1px solid #e2e8f0; border-radius: 10px;
       padding: 22px 24px; margin-bottom: 20px; }
.section h2 { font-size: 15px; margin-bottom: 14px; color: #0f172a; }
table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
th { text-align: left; background: #1e293b; color: #fff; padding: 7px 10px;
       font-weight: 600; font-size: 11.5px; }
td { padding: 7px 10px; border-bottom: 1px solid #e2e8f0; vertical-align: top; }
tr:nth-child(even) td { background: #f8fafc; }
.sev { font-weight: 700; font-size: 11px; padding: 2px 8px; border-radius: 99px;
       display: inline-block; }
.bar { display: flex; height: 14px; border-radius: 7px; overflow: hidden;
       border: 1px solid #cbd5e1; margin: 10px 0 4px; }
.gate-pass { color: #15803d; font-weight: 700; }
.gate-fail { color: #b91c1c; font-weight: 700; }
.fix { color: #0369a1; font-size: 12px; }
code { background: #f1f5f9; border-radius: 4px; padding: 1px 5px;
       font: 11.5px/1.4 Consolas, monospace; }
.file-h { font-weight: 600; margin: 18px 0 8px; font-size: 13.5px; }
.file-h small { color: #64748b; font-weight: 400; }
.section p { color:#64748b; font-size:12px; margin:10px 0; }
ol { padding-left:22px; } li { padding:5px 0; }
pre { white-space:pre-wrap; overflow-wrap:anywhere; margin-top:8px; }
.table-wrap { overflow-x:auto; } td { overflow-wrap:anywhere; }
.report-filter { display:flex; gap:12px; align-items:center; font-weight:600; }
input { padding:9px 12px; border:1px solid #cbd5e1; border-radius:6px; font:inherit; max-width:100%; }
[hidden] { display:none!important; }
@media(max-width:650px) { body{padding:12px;} .section{padding:16px;overflow:auto;} header.report{padding:22px;} .report-filter{display:block;} }
@media print { body{background:#fff;padding:0;} .section{break-inside:auto;} tr{break-inside:avoid;} thead{display:table-header-group;} .report-filter,#matchCount{display:none;} [hidden]{display:revert!important;} }
footer { color: #94a3b8; font-size: 11.5px; text-align: center; padding: 12px; }
"""


class HtmlExporter(Exporter):
    format_id = "html"
    display_name = "HTML (interactive report)"
    extension = ".html"

    def export(self, context: ReportContext, destination: Path) -> Path:
        destination.write_text(self.render(context), encoding="utf-8")
        return destination

    # ---- Rendering -----------------------------------------------------------

    def render(self, context: ReportContext) -> str:
        result = context.result
        scorecard = context.scorecard
        e = html.escape

        gate_class = "gate-pass" if context.gate.passed else "gate-fail"
        parts: list[str] = [
            "<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'>",
            "<meta name='viewport' content='width=device-width, initial-scale=1'>",
            f"<title>CodeSentinel Report - {e(context.project_name)}</title>",
            f"<style>{_CSS}</style></head><body><div class='wrap'>",
            "<header class='report'>",
            f"<h1>Static Analysis Report - {e(context.project_name)}</h1>",
            f"<div class='sub'>{e(str(result.root))} - "
            f"{context.generated_at:%d %B %Y %H:%M} - "
            f"{e(context.tool_name)} v{e(context.tool_version)}</div>",
            "</header>",
        ]

        parts.append("<div class='section'><h2>Release decision</h2>"
                     f"<p class='{gate_class}'>{context.gate.verdict} &middot; {e(context.gate_scope)}</p>"
                     f"<p>{e(context.evaluation_note)}</p>"
                     "<p>Scores describe detected findings. Test coverage, runtime testing and complete vulnerability coverage are not measured by this report.</p></div>")
        coverage = language_assurance(result)
        parts.append("<div class='section'><h2>Analysis coverage by language</h2><div class='table-wrap'><table>"
                     "<thead><tr><th>Language</th><th>Files / LOC</th><th>Security</th><th>Analysis evidence</th><th>Errors</th></tr></thead><tbody>")
        for row in coverage:
            parts.append(f"<tr><td>{e(row['language'])}</td><td>{row['files']} / {row['lines']:,}</td>"
                         f"<td>{row['security']}/100</td><td>{e(row['coverage'])}<br><small>{e(', '.join(row['tools']) or 'No tools recorded')}</small></td><td>{row['errors']}</td></tr>")
        parts.append("</tbody></table></div><p>Coverage reflects recorded analyzer execution on submitted files. Rules-only languages have less analysis depth.</p></div>")
        priorities = sorted(result.all_findings(), key=lambda pair: (pair[1].severity.sort_rank, str(pair[0].path), pair[1].line))[:5]
        if priorities:
            parts.append("<div class='section'><h2>Remediation priorities</h2><ol>")
            for analysis, finding in priorities:
                parts.append(f"<li><strong>{e(finding.severity.value)} &middot; {e(finding.rule_id)}</strong> "
                             f"{e(relative_to_root(analysis.path,result.root))}:{finding.line}<br>"
                             f"{e(finding.remediation or finding.message)}</li>")
            parts.append("</ol><p>Top five findings by severity. Review evidence, fix the cause, then re-scan.</p></div>")
        # KPI cards
        grade_colour = RATING_COLOURS.get(scorecard.grade, "#0f172a")
        cards = [
            (scorecard.grade, "Overall grade", grade_colour),
            (context.gate.verdict, "Quality gate",
             "#15803d" if context.gate.passed else "#b91c1c"),
            (str(scorecard.security), "Security", None),
            (str(scorecard.reliability), "Reliability", None),
            (str(scorecard.maintainability), "Maintainability", None),
            (str(scorecard.performance), "Performance", None),
            (scorecard.technical_debt, "Tech debt", None),
            (f"{len(result.analyses)}", "Files", None),
            (f"{result.total_code_lines:,}", "Lines of code", None),
            (str(result.total_findings), "Findings", None),
        ]
        parts.append("<div class='cards'>")
        for value, caption, colour in cards:
            style = f" style='color:{colour}'" if colour else ""
            parts.append(
                f"<div class='card'><div class='v'{style}>{e(value)}</div>"
                f"<div class='k'>{e(caption)}</div></div>"
            )
        parts.append("</div>")

        # Gate failures
        if not context.gate.passed:
            parts.append("<div class='section'><h2>Quality-Gate Failures</h2><ul>")
            parts += [f"<li class='gate-fail'>X {e(r)}</li>" for r in context.gate.reasons]
            parts.append("</ul></div>")

        # Waived findings - the detail table (findings a reviewer marked
        # false-positive / accepted-risk, with the recorded reason).
        if context.gate.waivers:
            parts.append(
                "<div class='section'><h2>Waived Findings</h2>"
                "<p>The report includes the following "
                "reviewer-approved waivers. Each row is a finding a reviewer "
                "marked a false positive or an accepted risk, with the reason "
                "recorded at triage.</p>"
                "<table><thead><tr>"
                "<th>Location</th><th>Severity</th><th>Rule</th>"
                "<th>Category</th><th>Decision</th><th>Reason</th>"
                "<th>Reviewer</th></tr></thead><tbody>")
            for w in context.gate.waivers:
                parts.append(
                    "<tr>"
                    f"<td>{e(w.location)}</td>"
                    f"<td>{e(w.severity)}</td>"
                    f"<td>{e(w.rule_id)}</td>"
                    f"<td>{e(w.category)}</td>"
                    f"<td>{e(w.decision)}</td>"
                    f"<td>{e(w.reason) if w.reason else '-'}</td>"
                    f"<td>{e(w.reviewer) if w.reviewer else '-'}</td>"
                    "</tr>")
            parts.append("</tbody></table></div>")

        # Severity distribution
        severities = result.severity_totals()
        if severities:
            total = sum(severities.values())
            parts.append("<div class='section'><h2>Severity Distribution</h2>")
            parts.append("<div class='bar'>")
            for severity, count in severities.items():
                pct = count / total * 100
                parts.append(
                    f"<div title='{severity.value}: {count}' "
                    f"style='width:{pct:.2f}%;background:{severity.hex_colour}'></div>"
                )
            parts.append("</div><table><tr><th>Severity</th><th>Count</th><th>Share</th></tr>")
            for severity, count in severities.items():
                parts.append(
                    f"<tr><td><span class='sev' style='color:{severity.hex_colour};"
                    f"background:{severity.tint_colour}'>{severity.value}</span></td>"
                    f"<td>{count}</td><td>{count / total:.0%}</td></tr>"
                )
            parts.append("</table></div>")

        # Language distribution
        distribution = result.language_distribution()
        if distribution:
            parts.append("<div class='section'><h2>Language Distribution (code lines)</h2><table>")
            parts.append("<tr><th>Language</th><th>Lines</th></tr>")
            parts += [f"<tr><td>{e(lang)}</td><td>{lines:,}</td></tr>"
                      for lang, lines in distribution.items()]
            parts.append("</table></div>")

        # Findings per file
        parts.append("<div class='section'><h2>Findings</h2><label class='report-filter'>Search findings <input id='findingSearch' type='search' placeholder='File, rule, CWE or message'></label><p id='matchCount' role='status'></p>")
        any_findings = False
        for analysis in result.analyses:
            if not analysis.findings:
                continue
            any_findings = True
            rel = relative_to_root(analysis.path, result.root)
            metric_bits = ""
            if analysis.metrics:
                metric_bits = (f" <small>- {analysis.metrics.code_lines} LOC - "
                               f"CC {analysis.metrics.complexity}</small>")
            parts.append(f"<section class='finding-group'><div class='file-h'>{e(rel)}{metric_bits}</div>")
            parts.append("<table><tr><th>Sev</th><th>Line</th><th>Rule</th>"
                         "<th>Refs</th><th>Description</th></tr>")
            for finding in analysis.sorted_findings():
                refs = " ".join(x for x in (finding.cwe, finding.owasp.split("-")[0]) if x)
                fix = (f"<br><span class='fix'><b>Fix:</b> {e(finding.remediation)}</span>"
                       if finding.remediation else "")
                parts.append(
                    f"<tr data-finding><td><span class='sev' style='color:{finding.severity.hex_colour};"
                    f"background:{finding.severity.tint_colour}'>{finding.severity.value}"
                    f"</span></td><td>{finding.line}</td>"
                    f"<td><code>{e(finding.rule_id)}</code></td>"
                    f"<td>{e(refs)}</td>"
                    f"<td>{e(finding.message)}<br><small>{e(finding.confidence)} confidence</small>"
                    f"<pre><code>{e(finding.snippet)}</code></pre>{fix}</td></tr>"
                )
            parts.append("</table></section>")
        if not any_findings:
            parts.append("<p>No open findings were recorded. Review analysis coverage and the gate verdict before release. "
                         "</p>")
        parts.append("</div>")

        parts.append(
            f"<footer>Generated offline by {e(context.tool_name)} "
            f"v{e(context.tool_version)} - findings require engineer triage."
            "</footer></div><script>"
            "const search=document.getElementById('findingSearch');"
            "search.addEventListener('input',()=>{let count=0;const q=search.value.toLowerCase();"
            "document.querySelectorAll('.finding-group').forEach(group=>{let visible=0;"
            "group.querySelectorAll('[data-finding]').forEach(row=>{row.hidden=!(row.textContent+' '+group.querySelector('.file-h').textContent).toLowerCase().includes(q);if(!row.hidden){visible++;count++;}});group.hidden=!visible;});"
            "document.getElementById('matchCount').textContent=count+' matching findings';});"
            "</script></body></html>"
        )
        return "".join(parts)
