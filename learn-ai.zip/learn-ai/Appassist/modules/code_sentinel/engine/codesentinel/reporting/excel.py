"""Excel workbook export (openpyxl): summary, findings, metrics sheets."""

from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from ..domain.models import relative_to_root
from .base import Exporter, ReportContext

_HEADER_FILL = PatternFill("solid", fgColor="1E293B")
_HEADER_FONT = Font(color="FFFFFF", bold=True, size=10)

_SEVERITY_FILLS = {
    "BLOCKER": PatternFill("solid", fgColor="F3E8FF"),
    "CRITICAL": PatternFill("solid", fgColor="FEE2E2"),
    "HIGH": PatternFill("solid", fgColor="FEE2E2"),
    "MEDIUM": PatternFill("solid", fgColor="FFEDD5"),
    "LOW": PatternFill("solid", fgColor="FEF3C7"),
    "INFO": PatternFill("solid", fgColor="DBEAFE"),
}


def _style_header(sheet, columns: int) -> None:
    for col in range(1, columns + 1):
        cell = sheet.cell(row=1, column=col)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = Alignment(vertical="center")
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = f"A1:{get_column_letter(columns)}{sheet.max_row}"


class ExcelExporter(Exporter):
    format_id = "xlsx"
    display_name = "Excel workbook"
    extension = ".xlsx"

    def export(self, context: ReportContext, destination: Path) -> Path:
        workbook = Workbook()
        self._summary_sheet(workbook, context)
        self._findings_sheet(workbook, context)
        if context.gate.waivers:
            self._waived_sheet(workbook, context)
        self._metrics_sheet(workbook, context)
        workbook.save(destination)
        return destination

    # ---- Sheets ---------------------------------------------------------------

    @staticmethod
    def _summary_sheet(workbook: Workbook, context: ReportContext) -> None:
        sheet = workbook.active
        sheet.title = "Summary"
        result = context.result
        scorecard = context.scorecard

        rows: list[tuple[str, object]] = [
            ("Project", context.project_name),
            ("Root path", str(result.root)),
            ("Generated", context.generated_at.strftime("%Y-%m-%d %H:%M:%S")),
            ("Tool", f"{context.tool_name} v{context.tool_version}"),
            ("", ""),
            ("Overall grade", scorecard.grade),
            ("Overall score", scorecard.overall),
            ("Quality gate", context.gate.verdict),
            ("Security score", scorecard.security),
            ("Reliability score", scorecard.reliability),
            ("Maintainability score", scorecard.maintainability),
            ("Performance score", scorecard.performance),
            ("Technical debt", scorecard.technical_debt),
            ("Risk level", scorecard.risk_level),
            ("", ""),
            ("Files scanned", len(result.analyses)),
            ("Files from cache", result.files_from_cache),
            ("Total lines", result.total_lines),
            ("Code lines", result.total_code_lines),
            ("Total findings", result.total_findings),
            ("Suppressed (triage)", result.suppressed_count),
            ("Duplication", f"{result.duplication_ratio:.1%}"),
            ("Scan duration (s)", round(result.duration_seconds, 2)),
        ]
        for severity, count in result.severity_totals().items():
            rows.append((f"{severity.value} findings", count))

        sheet.append(("Metric", "Value"))
        for row in rows:
            sheet.append(row)
        _style_header(sheet, 2)
        sheet.column_dimensions["A"].width = 26
        sheet.column_dimensions["B"].width = 60
        for reason in context.gate.reasons:
            sheet.append(("Gate failure", reason))
        if context.gate.waivers:
            sheet.append(("Reviewer waivers",
                          f"{len(context.gate.waivers)} - see the "
                          f"'Waived Findings' sheet"))

    @staticmethod
    def _waived_sheet(workbook: Workbook, context: ReportContext) -> None:
        """Detail table of reviewer-waived findings, with reasons."""
        sheet = workbook.create_sheet("Waived Findings")
        sheet.append((
            "Location", "Severity", "Rule", "Category", "Decision",
            "Reason", "Reviewer",
        ))
        for w in context.gate.waivers:
            sheet.append((w.location, w.severity, w.rule_id, w.category,
                          w.decision, w.reason or "", w.reviewer or ""))
        _style_header(sheet, 7)
        for col, width in zip("ABCDEFG", (34, 10, 14, 18, 14, 50, 22)):
            sheet.column_dimensions[col].width = width

    @staticmethod
    def _findings_sheet(workbook: Workbook, context: ReportContext) -> None:
        sheet = workbook.create_sheet("Findings")
        sheet.append((
            "File", "Line", "Severity", "Category", "Rule", "CWE", "OWASP",
            "Confidence", "Tool", "Message", "Remediation",
        ))
        for analysis in context.result.analyses:
            rel = relative_to_root(analysis.path, context.result.root)
            for finding in analysis.sorted_findings():
                sheet.append((
                    rel, finding.line, finding.severity.value, finding.category,
                    finding.rule_id, finding.cwe, finding.owasp,
                    finding.confidence, finding.tool, finding.message,
                    finding.remediation,
                ))
                fill = _SEVERITY_FILLS.get(finding.severity.value)
                if fill:
                    sheet.cell(row=sheet.max_row, column=3).fill = fill
        _style_header(sheet, 11)
        widths = (40, 6, 10, 20, 14, 10, 26, 11, 14, 70, 70)
        for index, width in enumerate(widths, start=1):
            sheet.column_dimensions[get_column_letter(index)].width = width

    @staticmethod
    def _metrics_sheet(workbook: Workbook, context: ReportContext) -> None:
        sheet = workbook.create_sheet("File metrics")
        sheet.append((
            "File", "Language", "Total lines", "Code", "Comments", "Blank",
            "Complexity", "Functions", "Duplicated lines", "Findings",
        ))
        for analysis in context.result.analyses:
            rel = relative_to_root(analysis.path, context.result.root)
            m = analysis.metrics
            sheet.append((
                rel, analysis.language_id,
                m.total_lines if m else 0, m.code_lines if m else 0,
                m.comment_lines if m else 0, m.blank_lines if m else 0,
                m.complexity if m else 0, m.functions if m else 0,
                m.duplicated_lines if m else 0, analysis.total_issues,
            ))
        _style_header(sheet, 10)
        sheet.column_dimensions["A"].width = 44
