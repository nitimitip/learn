"""Rule layer: data-driven rule packs, loader, and the matching engine."""
