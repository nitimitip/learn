"""Plugin discovery and lifecycle."""

from __future__ import annotations

import importlib.util
import logging
from dataclasses import dataclass
from pathlib import Path

from .api import CodeSentinelPlugin, PluginContext

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class LoadedPlugin:
    name: str
    version: str
    description: str
    source: Path
    error: str = ""

    @property
    def ok(self) -> bool:
        return not self.error


class PluginManager:
    """
    Loads every ``*.py`` module in the plugins directory that defines a
    ``Plugin`` class, and activates it against the shared context. A broken
    plugin is reported but never takes the application down.
    """

    def __init__(self, context: PluginContext) -> None:
        self._context = context
        self._loaded: list[LoadedPlugin] = []

    @property
    def loaded(self) -> list[LoadedPlugin]:
        return list(self._loaded)

    def load_directory(self, directory: Path) -> None:
        if not directory.is_dir():
            return
        for module_path in sorted(directory.glob("*.py")):
            if module_path.name.startswith("_"):
                continue
            self._load_one(module_path)

    def _load_one(self, module_path: Path) -> None:
        record = LoadedPlugin(
            name=module_path.stem, version="?", description="", source=module_path
        )
        try:
            spec = importlib.util.spec_from_file_location(
                f"codesentinel_plugin_{module_path.stem}", module_path
            )
            if spec is None or spec.loader is None:
                raise ImportError("Could not create a module spec.")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            plugin_cls = getattr(module, "Plugin", None)
            if plugin_cls is None or not issubclass(plugin_cls, CodeSentinelPlugin):
                raise TypeError(
                    "Module does not define a 'Plugin' subclass of "
                    "CodeSentinelPlugin."
                )
            plugin: CodeSentinelPlugin = plugin_cls()
            plugin.activate(self._context)
            record.name = plugin.name
            record.version = plugin.version
            record.description = plugin.description
            logger.info("Activated plugin %s %s", plugin.name, plugin.version)
        except Exception as exc:  # noqa: BLE001 - plugin faults must be contained
            record.error = f"{exc.__class__.__name__}: {exc}"
            logger.error("Plugin %s failed to load: %s", module_path.name, record.error)
        self._loaded.append(record)
