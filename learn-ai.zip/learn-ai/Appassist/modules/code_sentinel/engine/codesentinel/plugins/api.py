"""
Public plugin API.

A plugin is a Python module dropped into the user plugins directory that
defines a subclass of `CodeSentinelPlugin` named ``Plugin``. On startup the
manager instantiates it and calls `activate(context)`. Through the context
a plugin can:

  * register additional languages (`context.languages.register(spec)`)
  * contribute rule packs (return directories from `rule_pack_dirs()`)
  * register exporters (`context.register_exporter(exporter)`)

Plugins never require changes to core code.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from ..analysis.languages import LanguageRegistry


@dataclass(slots=True)
class PluginContext:
    """Capabilities handed to a plugin during activation."""

    languages: LanguageRegistry
    register_exporter: Callable[[object], None]
    #: Extra rule-pack directories collected from plugins.
    rule_pack_dirs: list[Path] = field(default_factory=list)

    def add_rule_pack_dir(self, path: Path) -> None:
        if path.is_dir():
            self.rule_pack_dirs.append(path)


class CodeSentinelPlugin(ABC):
    """Base class every plugin must subclass (as a class named ``Plugin``)."""

    #: Human-readable plugin name shown in Settings -> Plugins.
    name: str = "Unnamed plugin"
    version: str = "1.0.0"
    description: str = ""

    @abstractmethod
    def activate(self, context: PluginContext) -> None:
        """Register everything this plugin contributes."""
