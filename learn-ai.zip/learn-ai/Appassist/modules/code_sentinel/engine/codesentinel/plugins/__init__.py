"""Plugin framework: extend languages, rules, and exporters without core changes."""

from .api import CodeSentinelPlugin, PluginContext
from .manager import PluginManager

__all__ = ["CodeSentinelPlugin", "PluginContext", "PluginManager"]
