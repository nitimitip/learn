"""Application data locations. Everything stays on the local machine."""

from __future__ import annotations

import os
import sys
from pathlib import Path

from .. import APP_SHORT_NAME


def data_dir() -> Path:
    """Per-user application data directory (created on first use)."""
    override = os.environ.get("CODESENTINEL_HOME")
    if override:
        base = Path(override)
    elif sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home())) / APP_SHORT_NAME
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support" / APP_SHORT_NAME
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / APP_SHORT_NAME
    base.mkdir(parents=True, exist_ok=True)
    return base


def database_path() -> Path:
    return data_dir() / "codesentinel.db"


def log_dir() -> Path:
    path = data_dir() / "logs"
    path.mkdir(parents=True, exist_ok=True)
    return path


def user_rules_dir() -> Path:
    """Directory where administrators drop custom JSON rule packs."""
    path = data_dir() / "rules"
    path.mkdir(parents=True, exist_ok=True)
    return path


def plugins_dir() -> Path:
    """Directory scanned for Python plugin modules."""
    path = data_dir() / "plugins"
    path.mkdir(parents=True, exist_ok=True)
    return path
