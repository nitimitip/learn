"""
SQLite persistence: schema, migrations, and connection management.

One database file holds projects, scan history, issue triage, settings,
and the incremental-scan cache. WAL mode keeps the UI responsive while a
scan writes results.
"""

from __future__ import annotations

import sqlite3
import threading
from pathlib import Path

from .paths import database_path

_SCHEMA = """
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    root_path   TEXT NOT NULL UNIQUE,
    created_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS scans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id      INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    started_at      TEXT NOT NULL,
    finished_at     TEXT,
    files_scanned   INTEGER NOT NULL DEFAULT 0,
    files_cached    INTEGER NOT NULL DEFAULT 0,
    total_lines     INTEGER NOT NULL DEFAULT 0,
    code_lines      INTEGER NOT NULL DEFAULT 0,
    total_findings  INTEGER NOT NULL DEFAULT 0,
    blocker         INTEGER NOT NULL DEFAULT 0,
    critical        INTEGER NOT NULL DEFAULT 0,
    high            INTEGER NOT NULL DEFAULT 0,
    medium          INTEGER NOT NULL DEFAULT 0,
    low             INTEGER NOT NULL DEFAULT 0,
    info            INTEGER NOT NULL DEFAULT 0,
    duplication     REAL NOT NULL DEFAULT 0,
    security_score  INTEGER NOT NULL DEFAULT 100,
    reliability_score INTEGER NOT NULL DEFAULT 100,
    maintainability_score INTEGER NOT NULL DEFAULT 100,
    performance_score INTEGER NOT NULL DEFAULT 100,
    overall_score   INTEGER NOT NULL DEFAULT 100,
    grade           TEXT NOT NULL DEFAULT 'A+',
    debt_minutes    INTEGER NOT NULL DEFAULT 0,
    gate_passed     INTEGER NOT NULL DEFAULT 1,
    gate_reasons    TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_scans_project ON scans(project_id, started_at);

CREATE TABLE IF NOT EXISTS issues (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id      INTEGER NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
    fingerprint  TEXT NOT NULL,
    file_path    TEXT NOT NULL,
    line         INTEGER NOT NULL,
    tool         TEXT NOT NULL,
    rule_id      TEXT NOT NULL,
    severity     TEXT NOT NULL,
    category     TEXT NOT NULL,
    cwe          TEXT NOT NULL DEFAULT '',
    owasp        TEXT NOT NULL DEFAULT '',
    confidence   TEXT NOT NULL DEFAULT 'HIGH',
    message      TEXT NOT NULL,
    remediation  TEXT NOT NULL DEFAULT '',
    snippet      TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_issues_scan ON issues(scan_id);
CREATE INDEX IF NOT EXISTS idx_issues_fp ON issues(fingerprint);

CREATE TABLE IF NOT EXISTS triage (
    project_id   INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    fingerprint  TEXT NOT NULL,
    status       TEXT NOT NULL,
    note         TEXT NOT NULL DEFAULT '',
    decided_at   TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    PRIMARY KEY (project_id, fingerprint)
);

CREATE TABLE IF NOT EXISTS settings (
    key    TEXT PRIMARY KEY,
    value  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS file_cache (
    path          TEXT NOT NULL,
    content_hash  TEXT NOT NULL,
    engine_key    TEXT NOT NULL,
    payload       TEXT NOT NULL,
    cached_at     TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    PRIMARY KEY (path, engine_key)
);
"""

_SCHEMA_VERSION = 1


class Database:
    """Thread-safe SQLite wrapper (one connection per thread)."""

    def __init__(self, path: Path | None = None) -> None:
        self._path = path or database_path()
        self._local = threading.local()
        with self.connection() as conn:
            conn.executescript(_SCHEMA)
            row = conn.execute("SELECT version FROM schema_version").fetchone()
            if row is None:
                conn.execute("INSERT INTO schema_version (version) VALUES (?)",
                             (_SCHEMA_VERSION,))

    @property
    def path(self) -> Path:
        return self._path

    def connection(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self._path, timeout=30)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            conn.execute("PRAGMA synchronous=NORMAL")
            self._local.conn = conn
        return conn

    def close(self) -> None:
        conn = getattr(self._local, "conn", None)
        if conn is not None:
            conn.close()
            self._local.conn = None
