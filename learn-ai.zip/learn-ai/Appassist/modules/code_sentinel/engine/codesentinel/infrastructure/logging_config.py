"""Central logging configuration: rotating local files, console mirror."""

from __future__ import annotations

import logging
import logging.handlers

from .paths import log_dir

_CONFIGURED = False


def configure_logging(level: int = logging.INFO) -> None:
    """Idempotent logging setup used by both the GUI and the CLI."""
    global _CONFIGURED
    if _CONFIGURED:
        return

    root = logging.getLogger()
    root.setLevel(level)

    formatter = logging.Formatter(
        "%(asctime)s %(levelname)-7s %(name)s: %(message)s"
    )

    file_handler = logging.handlers.RotatingFileHandler(
        log_dir() / "codesentinel.log",
        maxBytes=2 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)

    console = logging.StreamHandler()
    console.setFormatter(formatter)
    console.setLevel(logging.WARNING)
    root.addHandler(console)

    _CONFIGURED = True
