"""Infrastructure layer: persistence, settings, logging - all local-only."""
