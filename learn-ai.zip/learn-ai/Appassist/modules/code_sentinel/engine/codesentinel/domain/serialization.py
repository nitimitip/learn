"""Round-trip serialisation of domain objects (cache, database, exporters)."""

from __future__ import annotations

from pathlib import Path

from .models import CodeMetrics, FileAnalysis, Finding, Severity


def finding_to_dict(finding: Finding) -> dict:
    return {
        "tool": finding.tool,
        "rule_id": finding.rule_id,
        "severity": finding.severity.value,
        "line": finding.line,
        "message": finding.message,
        "category": finding.category,
        "cwe": finding.cwe,
        "owasp": finding.owasp,
        "remediation": finding.remediation,
        "confidence": finding.confidence,
        "snippet": finding.snippet,
    }


def finding_from_dict(data: dict) -> Finding:
    return Finding(
        tool=str(data.get("tool", "")),
        rule_id=str(data.get("rule_id", "")),
        severity=Severity.from_string(str(data.get("severity", "INFO"))),
        line=int(data.get("line", 0)),
        message=str(data.get("message", "")),
        category=str(data.get("category", "General")),
        cwe=str(data.get("cwe", "")),
        owasp=str(data.get("owasp", "")),
        remediation=str(data.get("remediation", "")),
        confidence=str(data.get("confidence", "HIGH")),
        snippet=str(data.get("snippet", "")),
    )


def metrics_to_dict(metrics: CodeMetrics) -> dict:
    return {
        "total_lines": metrics.total_lines,
        "code_lines": metrics.code_lines,
        "comment_lines": metrics.comment_lines,
        "blank_lines": metrics.blank_lines,
        "complexity": metrics.complexity,
        "functions": metrics.functions,
        "duplicated_lines": metrics.duplicated_lines,
    }


def metrics_from_dict(data: dict) -> CodeMetrics:
    return CodeMetrics(
        total_lines=int(data.get("total_lines", 0)),
        code_lines=int(data.get("code_lines", 0)),
        comment_lines=int(data.get("comment_lines", 0)),
        blank_lines=int(data.get("blank_lines", 0)),
        complexity=int(data.get("complexity", 1)),
        functions=int(data.get("functions", 0)),
        duplicated_lines=int(data.get("duplicated_lines", 0)),
    )


def analysis_to_dict(analysis: FileAnalysis) -> dict:
    return {
        "path": str(analysis.path),
        "language_id": analysis.language_id,
        "findings": [finding_to_dict(f) for f in analysis.findings],
        "tools_run": list(analysis.tools_run),
        "tool_errors": list(analysis.tool_errors),
        "metrics": metrics_to_dict(analysis.metrics) if analysis.metrics else None,
    }


def analysis_from_dict(data: dict) -> FileAnalysis:
    metrics = data.get("metrics")
    return FileAnalysis(
        path=Path(str(data.get("path", ""))),
        language_id=str(data.get("language_id", "")),
        findings=[finding_from_dict(f) for f in data.get("findings", [])],
        tools_run=list(data.get("tools_run", [])),
        tool_errors=list(data.get("tool_errors", [])),
        metrics=metrics_from_dict(metrics) if metrics else None,
    )
