"""
Core domain model shared by every layer.

Deliberately dependency-free: no Qt, no ReportLab, no SQLite imports.
Everything here is picklable so analyses can cross process boundaries
during parallel scans.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Sequence


class Severity(str, Enum):
    """Normalised severity levels shared across every analyzer and rule pack."""

    BLOCKER = "BLOCKER"
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"

    @property
    def sort_rank(self) -> int:
        """Lower number == more severe. Used for ordering findings."""
        return _SEVERITY_ORDER[self]

    @property
    def hex_colour(self) -> str:
        """Canonical UI/report colour for this severity."""
        return _SEVERITY_COLOURS[self]

    @property
    def tint_colour(self) -> str:
        """Pale background wash used behind severity chips."""
        return _SEVERITY_TINTS[self]

    @classmethod
    def from_string(cls, value: str, default: "Severity | None" = None) -> "Severity":
        """Parse a severity name case-insensitively, falling back to INFO."""
        try:
            return cls(value.strip().upper())
        except ValueError:
            return default if default is not None else cls.INFO


_SEVERITY_ORDER: dict[Severity, int] = {
    Severity.BLOCKER: 0,
    Severity.CRITICAL: 1,
    Severity.HIGH: 2,
    Severity.MEDIUM: 3,
    Severity.LOW: 4,
    Severity.INFO: 5,
}

_SEVERITY_COLOURS: dict[Severity, str] = {
    Severity.BLOCKER: "#581c87",
    Severity.CRITICAL: "#7f1d1d",
    Severity.HIGH: "#b91c1c",
    Severity.MEDIUM: "#c2410c",
    Severity.LOW: "#a16207",
    Severity.INFO: "#1d4ed8",
}

_SEVERITY_TINTS: dict[Severity, str] = {
    Severity.BLOCKER: "#f3e8ff",
    Severity.CRITICAL: "#fee2e2",
    Severity.HIGH: "#fee2e2",
    Severity.MEDIUM: "#ffedd5",
    Severity.LOW: "#fef3c7",
    Severity.INFO: "#dbeafe",
}


class IssueStatus(str, Enum):
    """Triage lifecycle of a finding, persisted across scans by fingerprint."""

    OPEN = "OPEN"
    FALSE_POSITIVE = "FALSE_POSITIVE"
    ACCEPTED_RISK = "ACCEPTED_RISK"
    FIXED = "FIXED"

    @property
    def suppresses(self) -> bool:
        """Whether this status removes the finding from gates and scores."""
        return self in (IssueStatus.FALSE_POSITIVE, IssueStatus.ACCEPTED_RISK)


class RiskCategory:
    """Canonical category labels shared by all built-in rules."""

    DESTRUCTIVE = "Destructive Operation"
    INJECTION = "Injection"
    SECRETS = "Hardcoded Secret"
    INSECURE_CONFIG = "Insecure Configuration"
    CODE_EXECUTION = "Untrusted Code Execution"
    CRYPTOGRAPHY = "Weak Cryptography"
    VULNERABLE_DEPENDENCY = "Vulnerable Dependency"
    RELIABILITY = "Reliability"
    PERFORMANCE = "Performance"
    MAINTAINABILITY = "Maintainability"
    STANDARDS = "Coding Standards"
    GENERAL = "General"

    #: Categories that count toward the Security score.
    SECURITY_CATEGORIES = frozenset({
        DESTRUCTIVE, INJECTION, SECRETS, INSECURE_CONFIG,
        CODE_EXECUTION, CRYPTOGRAPHY, VULNERABLE_DEPENDENCY,
    })


@dataclass(frozen=True, slots=True)
class Finding:
    """A single normalised issue emitted by any analyzer."""

    tool: str
    rule_id: str
    severity: Severity
    line: int
    message: str
    category: str = RiskCategory.GENERAL
    cwe: str = ""
    owasp: str = ""
    remediation: str = ""
    #: Analyzer confidence: HIGH / MEDIUM / LOW.
    confidence: str = "HIGH"
    #: Offending source excerpt (single line, trimmed) when available.
    snippet: str = ""

    def __post_init__(self) -> None:
        # Display one canonical taxonomy key across regex, AST, flow and
        # imported reports; descriptions belong in the message/remediation.
        match = re.match(r'^(A\d{2}:\d{4})(?:\b|-)', self.owasp)
        if match:
            object.__setattr__(self, 'owasp', match.group(1))
        object.__setattr__(self, 'confidence', self.confidence.upper())

    def truncated_message(self, limit: int = 220) -> str:
        """Keep report table cells readable for very verbose rule messages."""
        clean = " ".join(self.message.split())
        return clean if len(clean) <= limit else clean[: limit - 1] + "..."

    def fingerprint(self, relative_path: str, occurrence: int = 0) -> str:
        """
        Stable identity for triage across scans.

        Built from rule + file + normalised offending text so re-ordering a
        file does not orphan triage decisions. Two *different* findings must
        never share a fingerprint, however - otherwise triaging one as a false
        positive would silently suppress the other from the release gate. Two
        safeguards enforce that:

          * findings with no offending text (AST/taint/SQL/shell analyzers
            historically emit none) fall back to a line anchor instead of an
            empty one, so distinct sinks on distinct lines stay distinct; and
          * ``occurrence`` disambiguates the rare case of byte-identical
            offending text for the same rule in one file (assigned by
            :func:`assign_fingerprints`, which is the supported entry point).

        Call :func:`assign_fingerprints` for a whole file's findings rather
        than this method directly - it computes ``occurrence`` deterministically
        so every consumer (storage, gate, UI) agrees on identities.
        """
        anchor = " ".join(self.snippet.split()) or f"@L{self.line}"
        suffix = f"#{occurrence}" if occurrence else ""
        basis = f"{self.rule_id}|{relative_path}|{anchor}{suffix}"
        return hashlib.sha256(basis.encode("utf-8")).hexdigest()[:32]


@dataclass(slots=True)
class CodeMetrics:
    """Size/complexity measures for one file."""

    total_lines: int = 0
    code_lines: int = 0
    comment_lines: int = 0
    blank_lines: int = 0
    #: Approximate cyclomatic complexity: 1 + count of decision points.
    complexity: int = 1
    functions: int = 0
    #: Lines that also appear in a duplicated block elsewhere in the scan.
    duplicated_lines: int = 0

    @property
    def comment_ratio(self) -> float:
        commentable = self.code_lines + self.comment_lines
        return self.comment_lines / commentable if commentable else 0.0

    @property
    def duplication_ratio(self) -> float:
        return self.duplicated_lines / self.code_lines if self.code_lines else 0.0

    @property
    def complexity_per_function(self) -> float:
        if self.functions:
            return self.complexity / self.functions
        return float(self.complexity)


@dataclass(slots=True)
class FileAnalysis:
    """Aggregated result of every analyzer run against one source file."""

    path: Path
    language_id: str
    findings: list[Finding] = field(default_factory=list)
    tools_run: list[str] = field(default_factory=list)
    tool_errors: list[str] = field(default_factory=list)
    metrics: CodeMetrics | None = None
    #: True when this result came from the incremental cache, not a fresh run.
    from_cache: bool = False

    @property
    def total_issues(self) -> int:
        return len(self.findings)

    @property
    def worst_severity(self) -> Severity | None:
        return next(iter(self.severity_breakdown()), None)

    def severity_breakdown(self) -> dict[Severity, int]:
        counts: dict[Severity, int] = {}
        for finding in self.findings:
            counts[finding.severity] = counts.get(finding.severity, 0) + 1
        return dict(sorted(counts.items(), key=lambda kv: kv[0].sort_rank))

    def category_breakdown(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for finding in self.findings:
            counts[finding.category] = counts.get(finding.category, 0) + 1
        return dict(sorted(counts.items(), key=lambda kv: -kv[1]))

    def sorted_findings(self) -> list[Finding]:
        return sorted(self.findings, key=lambda f: (f.severity.sort_rank, f.line))


@dataclass(slots=True)
class ScanResult:
    """One complete scan: every file analysis plus scan-level metadata."""

    root: Path
    analyses: list[FileAnalysis] = field(default_factory=list)
    started_at: datetime = field(default_factory=datetime.now)
    finished_at: datetime | None = None
    files_from_cache: int = 0
    #: Finding fingerprints suppressed by triage decisions (FP / accepted).
    suppressed_count: int = 0

    @property
    def duration_seconds(self) -> float:
        if self.finished_at is None:
            return 0.0
        return (self.finished_at - self.started_at).total_seconds()

    @property
    def total_findings(self) -> int:
        return sum(a.total_issues for a in self.analyses)

    @property
    def total_code_lines(self) -> int:
        return sum(a.metrics.code_lines for a in self.analyses if a.metrics)

    @property
    def total_lines(self) -> int:
        return sum(a.metrics.total_lines for a in self.analyses if a.metrics)

    @property
    def duplicated_lines(self) -> int:
        return sum(a.metrics.duplicated_lines for a in self.analyses if a.metrics)

    @property
    def duplication_ratio(self) -> float:
        code = self.total_code_lines
        return self.duplicated_lines / code if code else 0.0

    def all_findings(self) -> list[tuple[FileAnalysis, Finding]]:
        return [(a, f) for a in self.analyses for f in a.findings]

    def severity_totals(self) -> dict[Severity, int]:
        totals: dict[Severity, int] = {}
        for analysis in self.analyses:
            for severity, count in analysis.severity_breakdown().items():
                totals[severity] = totals.get(severity, 0) + count
        return dict(sorted(totals.items(), key=lambda kv: kv[0].sort_rank))

    def category_totals(self) -> dict[str, int]:
        totals: dict[str, int] = {}
        for analysis in self.analyses:
            for category, count in analysis.category_breakdown().items():
                totals[category] = totals.get(category, 0) + count
        return dict(sorted(totals.items(), key=lambda kv: -kv[1]))

    def language_distribution(self) -> dict[str, int]:
        """Code lines per language id, largest first."""
        dist: dict[str, int] = {}
        for analysis in self.analyses:
            lines = analysis.metrics.code_lines if analysis.metrics else 0
            dist[analysis.language_id] = dist.get(analysis.language_id, 0) + lines
        return dict(sorted(dist.items(), key=lambda kv: -kv[1]))


def assign_fingerprints(findings: "Sequence[Finding]", relative_path: str) -> list[str]:
    """
    Fingerprint every finding in one file, guaranteeing distinct identities.

    Findings that share both rule and offending text (or line anchor, when the
    text is empty) are the only ones that can collide; they are numbered by an
    ``occurrence`` ordinal so each gets a unique fingerprint. The ordinal is
    assigned in a fixed order - by line, then by original position - so the
    result does not depend on the caller's iteration order. That is what lets
    the storage layer (raw order), the UI (severity-sorted order) and the
    triage gate all compute the *same* fingerprint for the same finding.

    Returns a list of fingerprints aligned to ``findings``' order.
    """
    groups: dict[str, list[int]] = {}
    for index, finding in enumerate(findings):
        anchor = " ".join(finding.snippet.split()) or f"@L{finding.line}"
        groups.setdefault(f"{finding.rule_id}\x00{anchor}", []).append(index)

    fingerprints: list[str] = [""] * len(findings)
    for members in groups.values():
        ordered = sorted(members, key=lambda i: (findings[i].line, i))
        for occurrence, index in enumerate(ordered):
            fingerprints[index] = findings[index].fingerprint(relative_path, occurrence)
    return fingerprints


def relative_to_root(path: Path, root: Path) -> str:
    """Best-effort project-relative path used for fingerprints and display."""
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.name


__all__ = [
    "Severity",
    "IssueStatus",
    "RiskCategory",
    "Finding",
    "CodeMetrics",
    "FileAnalysis",
    "ScanResult",
    "assign_fingerprints",
    "relative_to_root",
]
