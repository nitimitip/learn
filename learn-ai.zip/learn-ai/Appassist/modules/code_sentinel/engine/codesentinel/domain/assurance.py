"""Evidence-based language coverage shared by gates and reports.

This describes the files actually analysed, not test coverage or a claim
that every vulnerability in a supported language can be detected.
"""
from collections import defaultdict

from .models import RiskCategory
from .scoring import dimension_score

PARSER_LANGUAGES = frozenset({
    'javascript', 'typescript', 'java', 'csharp', 'go', 'rust', 'kotlin', 'swift',
})

def analysis_depth(language, tools):
    if language == 'python' and 'sentinel-taint' in tools:
        return 'AST checks and bounded data flow; limited Python import linking'
    if language in {'javascript', 'typescript', 'java', 'csharp'} and 'sentinel-tree-sitter' in tools:
        return 'Syntax checks and bounded in-file data flow; no whole-program analysis'
    if language in {'go', 'rust', 'kotlin', 'swift'} and 'sentinel-tree-sitter' in tools:
        return 'Pattern and syntax-query checks; no data-flow analysis'
    if 'sentinel-ast' in tools:
        return 'Pattern and specialist text/statement checks; no compiler type analysis'
    return 'Pattern checks; no syntax tree or data-flow analysis'


def language_assurance(result):
    groups = defaultdict(list)
    for analysis in result.analyses:
        groups[analysis.language_id].append(analysis)
    rows = []
    for language, analyses in sorted(groups.items()):
        tools = sorted({tool for a in analyses for tool in a.tools_run})
        lines = sum(a.metrics.code_lines for a in analyses if a.metrics)
        security = [f for a in analyses for f in a.findings
                    if f.category in RiskCategory.SECURITY_CATEGORIES]
        errors = sum(bool(a.tool_errors) for a in analyses)
        missing = sum(not a.tools_run or a.metrics is None for a in analyses)
        parser_gaps = sum('sentinel-tree-sitter' not in a.tools_run
                          for a in analyses) if language in PARSER_LANGUAGES else 0
        rows.append(dict(language=language, files=len(analyses), lines=lines,
                         findings=sum(len(a.findings) for a in analyses),
                         security=dimension_score(security, lines),
                         tools=tools, errors=errors, missing=missing,
                         parser_gaps=parser_gaps,
                         depth=analysis_depth(language, tools),
                         coverage='Incomplete' if errors or missing else
                         'Rules only' if parser_gaps or tools == ['sentinel-rules']
                         else 'Rules + specialist checks'))
    return rows
