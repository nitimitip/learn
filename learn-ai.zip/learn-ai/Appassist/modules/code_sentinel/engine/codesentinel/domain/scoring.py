"""
Scores, grades, technical debt, and the release quality gate.

All scoring is density-based (weighted findings per unit of code) so that a
large clean codebase is not penalised for its size and a tiny bad file
cannot hide behind a small denominator.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

from .models import (
    FileAnalysis, Finding, RiskCategory, ScanResult, Severity,
    assign_fingerprints, relative_to_root,
)

#: Weighted "remediation effort" per severity, used for ratings and debt.
SEVERITY_WEIGHTS: dict[Severity, int] = {
    Severity.BLOCKER: 15,
    Severity.CRITICAL: 10,
    Severity.HIGH: 5,
    Severity.MEDIUM: 2,
    Severity.LOW: 1,
    Severity.INFO: 0,
}

#: Estimated remediation minutes per severity (technical debt model).
DEBT_MINUTES: dict[Severity, int] = {
    Severity.BLOCKER: 240,
    Severity.CRITICAL: 120,
    Severity.HIGH: 60,
    Severity.MEDIUM: 30,
    Severity.LOW: 10,
    Severity.INFO: 2,
}

#: Rating thresholds on weighted issues per 100 lines of code.
_RATING_BANDS: tuple[tuple[float, str], ...] = (
    (5.0, "A"), (10.0, "B"), (20.0, "C"), (40.0, "D"),
)

RATING_COLOURS: dict[str, str] = {
    "A+": "#15803d",
    "A": "#15803d",
    "B": "#65a30d",
    "C": "#a16207",
    "D": "#c2410c",
    "E": "#b91c1c",
    "F": "#7f1d1d",
}

#: Categories contributing to each score dimension.
_DIMENSIONS: dict[str, frozenset[str]] = {
    "security": RiskCategory.SECURITY_CATEGORIES,
    "reliability": frozenset({RiskCategory.RELIABILITY}),
    "maintainability": frozenset({
        RiskCategory.MAINTAINABILITY, RiskCategory.STANDARDS, RiskCategory.GENERAL,
    }),
    "performance": frozenset({RiskCategory.PERFORMANCE}),
}


def maintainability_rating(findings: Sequence[Finding], code_lines: int) -> str:
    """A (best) to E (worst), from weighted issue density per 100 LOC."""
    if code_lines <= 0:
        return "A" if not findings else "E"
    debt = sum(SEVERITY_WEIGHTS[f.severity] for f in findings)
    density = debt / code_lines * 100
    for threshold, grade in _RATING_BANDS:
        if density <= threshold:
            return grade
    return "E"


def dimension_score(findings: Sequence[Finding], code_lines: int) -> int:
    """
    Map weighted finding density onto a 0-100 score.

    100 == no findings; each weighted-density point per 100 LOC costs
    2.5 score points, floored at 0. An empty file with findings scores 0.
    """
    if not findings:
        return 100
    if code_lines <= 0:
        return 0
    debt = sum(SEVERITY_WEIGHTS[f.severity] for f in findings)
    density = debt / code_lines * 100
    return max(0, round(100 - density * 2.5))


def overall_grade(score: int) -> str:
    """Letter grade for the project health headline."""
    bands = ((97, "A+"), (90, "A"), (80, "B"), (70, "C"), (60, "D"), (50, "E"))
    for threshold, grade in bands:
        if score >= threshold:
            return grade
    return "F"


def format_debt(minutes: int) -> str:
    """Human-readable technical debt: '3d 4h', '2h 30m', '45m'."""
    if minutes < 60:
        return f"{minutes}m"
    hours, mins = divmod(minutes, 60)
    if hours < 8:
        return f"{hours}h {mins}m" if mins else f"{hours}h"
    days, hours = divmod(hours, 8)  # 8-hour working days
    return f"{days}d {hours}h" if hours else f"{days}d"


@dataclass(slots=True)
class ScoreCard:
    """Every score/grade shown on the dashboard, computed from one scan."""

    security: int = 100
    reliability: int = 100
    maintainability: int = 100
    performance: int = 100
    overall: int = 100
    grade: str = "A+"
    maintainability_rating: str = "A"
    technical_debt_minutes: int = 0
    risk_level: str = "LOW"

    @property
    def technical_debt(self) -> str:
        return format_debt(self.technical_debt_minutes)


def compute_scorecard(result: ScanResult) -> ScoreCard:
    """Compute every dashboard score from a completed scan."""
    findings = [f for _, f in result.all_findings()]
    code_lines = result.total_code_lines

    per_dimension: dict[str, int] = {}
    for name, categories in _DIMENSIONS.items():
        subset = [f for f in findings if f.category in categories]
        per_dimension[name] = dimension_score(subset, code_lines)

    # Overall: security weighted double - it is the reason this product exists.
    overall = round(
        (per_dimension["security"] * 2
         + per_dimension["reliability"]
         + per_dimension["maintainability"]
         + per_dimension["performance"]) / 5
    )

    debt = sum(DEBT_MINUTES[f.severity] for f in findings)
    severities = result.severity_totals()
    blocker_like = severities.get(Severity.BLOCKER, 0) + severities.get(Severity.CRITICAL, 0)
    high = severities.get(Severity.HIGH, 0)

    if blocker_like:
        risk = "CRITICAL"
    elif high:
        risk = "HIGH"
    elif severities.get(Severity.MEDIUM, 0):
        risk = "MEDIUM"
    else:
        risk = "LOW"

    return ScoreCard(
        security=per_dimension["security"],
        reliability=per_dimension["reliability"],
        maintainability=per_dimension["maintainability"],
        performance=per_dimension["performance"],
        overall=overall,
        grade=overall_grade(overall),
        maintainability_rating=maintainability_rating(findings, code_lines),
        technical_debt_minutes=debt,
        risk_level=risk,
    )


def new_code_result(
    result: ScanResult,
    baseline_fingerprints: "set[str] | None",
) -> ScanResult:
    """
    A view of ``result`` containing only findings absent from the baseline -
    the "new code" a new-code-only release gate evaluates.

    ``baseline_fingerprints`` is the set of finding fingerprints from the
    reference (baseline) scan. A finding is *new* when its fingerprint is not
    in that set. When the baseline is ``None`` (no reference scan exists yet,
    e.g. the first scan of a project) every finding is treated as new - which
    is both correct and fail-closed: nothing gets a free pass for lack of
    history.

    Fingerprints are computed with :func:`assign_fingerprints`, the same
    collision-free identity the gate, storage and UI use, so "new vs baseline"
    can never be fooled by two distinct findings sharing an id.
    """
    if baseline_fingerprints is None:
        return result

    view = ScanResult(
        root=result.root,
        started_at=result.started_at,
        finished_at=result.finished_at,
        files_from_cache=result.files_from_cache,
    )
    for analysis in result.analyses:
        rel = relative_to_root(analysis.path, result.root)
        fingerprints = assign_fingerprints(analysis.findings, rel)
        new_findings = [
            finding
            for finding, fingerprint in zip(analysis.findings, fingerprints)
            if fingerprint not in baseline_fingerprints
        ]
        view.analyses.append(FileAnalysis(
            path=analysis.path,
            language_id=analysis.language_id,
            findings=new_findings,
            tools_run=list(analysis.tools_run),
            tool_errors=list(analysis.tool_errors),
            metrics=analysis.metrics,
        ))
    return view


@dataclass(frozen=True, slots=True)
class WaiverDetail:
    """One waived finding, as a report-table row (structured, not prose)."""

    severity: str
    category: str
    rule_id: str
    location: str          # "path/to/file.py:42"
    decision: str          # "False positive" | "Accepted risk"
    reason: str = ""
    reviewer: str = ""      # "Name, YYYY-MM-DD" (empty on single-user desktop)


@dataclass(slots=True)
class QualityGateResult:
    """Outcome of the release gate applied to a whole scan."""

    passed: bool
    reasons: list[str] = field(default_factory=list)
    #: Human-readable waiver notes: findings a reviewer marked False Positive
    #: or Accepted Risk that would otherwise have breached the gate, each with
    #: its reason and attribution. Populated by the caller that owns the
    #: triage decisions; documents WHY a gate passed on waived findings.
    notes: list[str] = field(default_factory=list)
    #: Structured detail of EVERY waived finding (any severity) - the rows the
    #: report's Waived Findings table is rendered from.
    waivers: list[WaiverDetail] = field(default_factory=list)

    @property
    def verdict(self) -> str:
        return "PASSED" if self.passed else "FAILED"

    @property
    def has_waivers(self) -> bool:
        return bool(self.notes or self.waivers)


@dataclass(frozen=True, slots=True)
class QualityGateConfig:
    """Tunable gate conditions; defaults mirror a strict release gate."""

    max_blocker: int = 0
    max_critical: int = 0
    max_high: int = 0
    max_duplication: float = 0.10
    min_security_score: int = 70
    #: When True, the severity and security-score conditions are evaluated over
    #: findings NEW since a baseline scan (new-code-only gating) rather than the
    #: whole codebase - so legacy debt never blocks a release that adds none.
    new_code_only: bool = False
    # Integrity checks apply to the whole analysis, including new-code gates.
    fail_on_analysis_errors: bool = True
    require_language_parsers: bool = False
    # Optional language-level floor prevents clean languages diluting risk.
    min_language_security_score: int = 0


class QualityGate:
    """Release gate: every configured condition must hold to pass."""

    def __init__(self, config: QualityGateConfig | None = None) -> None:
        self._config = config or QualityGateConfig()

    def evaluate(
        self,
        result: ScanResult,
        baseline_fingerprints: "set[str] | None" = None,
    ) -> QualityGateResult:
        """
        Evaluate the release gate over ``result``.

        In new-code mode (``config.new_code_only``) the severity and
        security-score conditions are applied to only the findings NEW since
        ``baseline_fingerprints`` - pass the baseline scan's fingerprints.
        The duplication condition is a whole-codebase metric that cannot be
        attributed to new code, so it is only enforced in full-scan mode.
        """
        config = self._config
        new_mode = config.new_code_only
        scope = new_code_result(result, baseline_fingerprints) if new_mode else result
        label = " on new code" if new_mode else ""

        reasons: list[str] = []
        from .assurance import language_assurance
        if not result.analyses or result.total_code_lines <= 0:
            reasons.append('No analysable source code - upload supported, non-empty source files')
        for row in language_assurance(result):
            if config.fail_on_analysis_errors and (row['errors'] or row['missing']):
                reasons.append(f"{row['language']}: analysis incomplete "
                               f"({row['errors']} file(s) with errors, "
                               f"{row['missing']} without analysis evidence)")
            if config.require_language_parsers and row['parser_gaps']:
                reasons.append(f"{row['language']}: parser analysis unavailable for "
                               f"{row['parser_gaps']} file(s); install the language grammar and re-scan")
        if config.min_language_security_score:
            for row in language_assurance(scope):
                if row['security'] < config.min_language_security_score:
                    reasons.append(f"{row['language']} security score {row['security']}{label} "
                                   f"- gate requires at least {config.min_language_security_score}")
        severities = scope.severity_totals()

        checks = (
            (Severity.BLOCKER, config.max_blocker),
            (Severity.CRITICAL, config.max_critical),
            (Severity.HIGH, config.max_high),
        )
        for severity, allowed in checks:
            count = severities.get(severity, 0)
            if count > allowed:
                reasons.append(
                    f"{count} {severity.value} finding(s){label} - "
                    f"gate allows {allowed}"
                )

        if not new_mode and result.total_code_lines and \
                result.duplication_ratio > config.max_duplication:
            reasons.append(
                f"duplicated-line density {result.duplication_ratio:.0%} - "
                f"gate allows at most {config.max_duplication:.0%}"
            )

        scorecard = compute_scorecard(scope)
        if scorecard.security < config.min_security_score:
            reasons.append(
                f"security score {scorecard.security}{label} - gate requires "
                f"at least {config.min_security_score}"
            )

        return QualityGateResult(passed=not reasons, reasons=reasons)


def file_rating(analysis: FileAnalysis) -> str:
    """Per-file maintainability rating used in report tables."""
    code_lines = analysis.metrics.code_lines if analysis.metrics else 0
    return maintainability_rating(analysis.findings, code_lines)
