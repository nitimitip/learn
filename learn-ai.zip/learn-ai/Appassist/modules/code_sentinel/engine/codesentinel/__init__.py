"""
CodeSentinel Enterprise - offline static code analysis platform.

A fully offline, on-premise static analysis product for regulated
environments (government, banking, healthcare, defense). No telemetry,
no cloud APIs, no network access required at any point after install.
"""

from __future__ import annotations

APP_NAME = "CodeSentinel Enterprise"
APP_SHORT_NAME = "CodeSentinel"
APP_VERSION = "4.11.0"
APP_VENDOR = "CodeSentinel"

__version__ = APP_VERSION
