"""Analysis layer: language registry, scanners, metrics, and the engine."""
