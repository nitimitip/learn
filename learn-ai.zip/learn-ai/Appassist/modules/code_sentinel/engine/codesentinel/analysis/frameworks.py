"""
Framework models - extra taint sources/sinks/sanitizers, as data.

Generic language rules miss framework-specific ways of receiving untrusted
input and executing it. A `FrameworkModel` declares those deltas for one
framework; `merge_into` folds every model for a language into its base
`_Profile` so the taint scanner treats them as first-class.

Every addition here is a SPECIFIC construct (an annotation name, a named
method, a JSX attribute), so merging all of a language's models unconditionally
cannot raise the false-positive rate - a source/sink only fires when its exact
pattern is present. Activating models by detected dependency (package.json /
.csproj / pom.xml) is a possible future refinement, not a correctness need.

Covered (the app's stack): Express + React (JS/TS), ASP.NET Core + EF Core +
Dapper (C#), Spring (Java). Python frameworks (Flask/Django) are already
covered by the native taint scanner's ``request.`` source prefix.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace

from ..domain.models import Severity

# Sink tuples mirror those in tree_sitter_analysis (rule, severity, label, CWE).
_SQL = ("TAINT-SQL", Severity.CRITICAL, "SQL execution", "CWE-89")
_XSS = ("TAINT-XSS", Severity.HIGH, "HTML injection (XSS)", "CWE-79")


@dataclass(frozen=True)
class FrameworkModel:
    """Taint-vocabulary deltas contributed by one framework."""

    name: str
    #: Extra dotted source prefixes (member access that denotes input).
    source_prefixes: tuple = ()
    #: Extra source call names (their return value is attacker-influenced).
    source_calls: frozenset = frozenset()
    #: Extra sanitiser call names (they neutralise taint).
    sanitizers: frozenset = frozenset()
    #: Extra call sinks: method name -> (rule, severity, label, CWE).
    sink_calls: dict = field(default_factory=dict)
    #: Extra constructor sinks: type name -> (rule, severity, label, CWE).
    new_sinks: dict = field(default_factory=dict)
    #: Extra assignment-property sinks (el.innerHTML style).
    sink_assign_props: frozenset = frozenset()
    #: Parameter annotations/attributes that bind untrusted input to a param
    #: (ASP.NET [FromQuery], Spring @RequestParam) - the param is a source.
    param_source_annotations: frozenset = frozenset()
    #: JSX attributes that are XSS sinks (React dangerouslySetInnerHTML).
    jsx_sink_attrs: frozenset = frozenset()
    #: Extra names counted as a DB round-trip for the N+1 check.
    db_call_names: frozenset = frozenset()


_EXPRESS = FrameworkModel(
    "express",
    source_prefixes=("req.cookies", "req.signedCookies", "req.hostname",
                     "req.originalUrl", "req.path"),
    source_calls=frozenset({"param"}),          # req.param('x')
)
_REACT = FrameworkModel(
    "react",
    jsx_sink_attrs=frozenset({"dangerouslySetInnerHTML"}),
)
_ASPNETCORE = FrameworkModel(
    "aspnetcore",
    param_source_annotations=frozenset({
        "FromQuery", "FromBody", "FromRoute", "FromForm", "FromHeader",
    }),
)
_EFCORE = FrameworkModel(
    "efcore",
    sink_calls={
        "FromSqlRaw": _SQL, "ExecuteSqlRaw": _SQL, "ExecuteSqlRawAsync": _SQL,
    },
    db_call_names=frozenset({"FromSqlRaw", "ExecuteSqlRaw"}),
)
_DAPPER = FrameworkModel(
    "dapper",
    sink_calls={
        "QueryAsync": _SQL, "ExecuteAsync": _SQL, "QueryFirst": _SQL,
        "QueryFirstOrDefault": _SQL, "QuerySingle": _SQL,
        "QuerySingleOrDefault": _SQL,
    },
)
_SPRING = FrameworkModel(
    "spring",
    param_source_annotations=frozenset({
        "RequestParam", "PathVariable", "RequestBody", "RequestHeader",
        "RequestPart", "ModelAttribute", "CookieValue", "MatrixVariable",
    }),
    sink_calls={
        "queryForObject": _SQL, "queryForList": _SQL, "queryForMap": _SQL,
        "queryForRowSet": _SQL,
    },
)

#: language id -> the framework models that apply to it.
FRAMEWORKS: dict = {
    "javascript": (_EXPRESS, _REACT),
    "typescript": (_EXPRESS, _REACT),
    "csharp": (_ASPNETCORE, _EFCORE, _DAPPER),
    "java": (_SPRING,),
}


def merge_into(base):
    """Return a copy of ``base`` (_Profile) with every framework model folded in."""
    models = FRAMEWORKS.get(base.language_id, ())
    if not models:
        return base

    source_prefixes = tuple(base.source_prefixes)
    source_calls = set(base.source_calls)
    sanitizers = set(base.sanitizers)
    sink_calls = dict(base.sink_calls)
    new_sinks = dict(base.new_sinks)
    sink_assign_props = set(base.sink_assign_props)
    param_annotations = set(base.param_source_annotations)
    jsx_sink_attrs = set(base.jsx_sink_attrs)
    db_call_names = set(base.db_call_names)

    for model in models:
        source_prefixes += tuple(model.source_prefixes)
        source_calls |= set(model.source_calls)
        sanitizers |= set(model.sanitizers)
        sink_calls.update(model.sink_calls)
        new_sinks.update(model.new_sinks)
        sink_assign_props |= set(model.sink_assign_props)
        param_annotations |= set(model.param_source_annotations)
        jsx_sink_attrs |= set(model.jsx_sink_attrs)
        db_call_names |= set(model.db_call_names)

    return replace(
        base,
        source_prefixes=source_prefixes,
        source_calls=frozenset(source_calls),
        sanitizers=frozenset(sanitizers),
        sink_calls=sink_calls,
        new_sinks=new_sinks,
        sink_assign_props=frozenset(sink_assign_props),
        param_source_annotations=frozenset(param_annotations),
        jsx_sink_attrs=frozenset(jsx_sink_attrs),
        db_call_names=frozenset(db_call_names),
    )
