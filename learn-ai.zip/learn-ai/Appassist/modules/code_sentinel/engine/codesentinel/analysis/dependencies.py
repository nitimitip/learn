"""
Dependency inventory & SBOM (offline manifest parsing).

Parses common dependency manifests found in a scanned folder and emits a
component inventory plus a CycloneDX 1.5 JSON SBOM. This is the
offline-feasible half of supply-chain analysis: it tells you exactly WHAT
you depend on and at which versions - the prerequisite for any
vulnerability review against a mirrored advisory feed.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Sequence

from .. import APP_SHORT_NAME, APP_VERSION


@dataclass(frozen=True, slots=True)
class Dependency:
    """One declared third-party component."""

    name: str
    version: str
    ecosystem: str
    source_file: str


class DependencyScanner:
    _REQ_RE = re.compile(r"^\s*([A-Za-z0-9._-]+)\s*(?:==|>=|~=|<=)?\s*([0-9][\w.]*)?")

    def scan(self, root: Path, limit: int = 2000) -> list[Dependency]:
        deps: list[Dependency] = []
        if not root.is_dir():
            root = root.parent
        try:
            candidates = [p for p in root.rglob("*") if p.is_file()][:20000]
        except OSError:
            return deps

        for path in candidates:
            name = path.name.lower()
            try:
                if name in ("requirements.txt", "requirements-dev.txt"):
                    deps += self._python_requirements(path)
                elif name == "package.json":
                    deps += self._npm_package(path)
                elif name.endswith((".csproj", ".vbproj")):
                    deps += self._dotnet_project(path)
                elif name == "pom.xml":
                    deps += self._maven_pom(path)
                elif name == "go.mod":
                    deps += self._go_mod(path)
                elif name == "cargo.toml":
                    deps += self._cargo_toml(path)
            except (OSError, ValueError):
                continue
            if len(deps) >= limit:
                break

        seen: set[tuple[str, str, str]] = set()
        unique: list[Dependency] = []
        for dep in deps:
            key = (dep.ecosystem, dep.name.lower(), dep.version)
            if key not in seen:
                seen.add(key)
                unique.append(dep)
        return sorted(unique, key=lambda d: (d.ecosystem, d.name.lower()))

    def _python_requirements(self, path: Path) -> list[Dependency]:
        out: list[Dependency] = []
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line or line.startswith(("#", "-", "git+", "http")):
                continue
            match = self._REQ_RE.match(line)
            if match and match.group(1):
                out.append(Dependency(match.group(1), match.group(2) or "unpinned",
                                      "PyPI", path.name))
        return out

    @staticmethod
    def _npm_package(path: Path) -> list[Dependency]:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        out: list[Dependency] = []
        for section in ("dependencies", "devDependencies"):
            for name, ver in (data.get(section) or {}).items():
                out.append(Dependency(name, str(ver).lstrip("^~"), "npm", path.name))
        return out

    @staticmethod
    def _dotnet_project(path: Path) -> list[Dependency]:
        text = path.read_text(encoding="utf-8", errors="replace")
        return [
            Dependency(m.group(1), m.group(2), "NuGet", path.name)
            for m in re.finditer(
                r'<PackageReference\s+Include="([^"]+)"\s+Version="([^"]+)"', text
            )
        ]

    @staticmethod
    def _maven_pom(path: Path) -> list[Dependency]:
        text = path.read_text(encoding="utf-8", errors="replace")
        return [
            Dependency(f"{m.group(1)}:{m.group(2)}", m.group(3) or "managed",
                       "Maven", path.name)
            for m in re.finditer(
                r"<dependency>\s*<groupId>([^<]+)</groupId>\s*"
                r"<artifactId>([^<]+)</artifactId>\s*(?:<version>([^<]+)</version>)?",
                text,
            )
        ]

    @staticmethod
    def _go_mod(path: Path) -> list[Dependency]:
        out: list[Dependency] = []
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            match = re.match(r"^\s*([\w./-]+)\s+v([\w.+-]+)", line)
            if match and "/" in match.group(1):
                out.append(Dependency(match.group(1), match.group(2), "Go", path.name))
        return out

    @staticmethod
    def _cargo_toml(path: Path) -> list[Dependency]:
        out: list[Dependency] = []
        in_deps = False
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            stripped = line.strip()
            if stripped.startswith("["):
                in_deps = stripped in ("[dependencies]", "[dev-dependencies]")
                continue
            if in_deps:
                match = re.match(r"""^([\w-]+)\s*=\s*["']([^"']+)["']""", stripped)
                if match:
                    out.append(Dependency(match.group(1), match.group(2),
                                          "crates.io", path.name))
        return out

    @staticmethod
    def write_sbom(deps: Sequence[Dependency], destination: Path) -> Path:
        """Emit a minimal CycloneDX 1.5 JSON SBOM."""
        document = {
            "bomFormat": "CycloneDX",
            "specVersion": "1.5",
            "version": 1,
            "metadata": {
                "timestamp": datetime.now().isoformat(),
                "tools": [{"name": APP_SHORT_NAME, "version": APP_VERSION}],
            },
            "components": [
                {
                    "type": "library",
                    "name": dep.name,
                    "version": dep.version,
                    "purl": f"pkg:{dep.ecosystem.lower()}/{dep.name}@{dep.version}",
                    "properties": [{"name": "sourceManifest", "value": dep.source_file}],
                }
                for dep in deps
            ],
        }
        destination.write_text(json.dumps(document, indent=2), encoding="utf-8")
        return destination
