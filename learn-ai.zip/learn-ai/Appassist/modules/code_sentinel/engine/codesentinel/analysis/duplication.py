"""Cross-file duplicated-code detection (copy/paste detection)."""

from __future__ import annotations

import re
from typing import Sequence

from ..domain.models import FileAnalysis, Finding, RiskCategory, Severity
from .languages import LanguageRegistry
from ..rules.engine import LineMasker

TOOL_NAME = "sentinel-metrics"

#: Literal normalisation (CPD-style): string and numeric literals are
#: replaced by placeholders before hashing, so a pasted block whose only
#: edits are tweaked constants ("prod" -> "test", 30 -> 60) still matches.
#: Identifier renaming (full Type-2 clones) is deliberately NOT normalised -
#: at a 6-line window it would over-match boilerplate.
_STRING_LITERAL = re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'')
_NUMBER_LITERAL = re.compile(r"\b\d+(?:\.\d+)?\b")


class DuplicationDetector:
    """
    Normalised code lines (whitespace-collapsed, literals replaced by
    placeholders) are hashed in sliding windows of `WINDOW` lines; any
    window seen at more than one location marks its lines as duplicated.
    Files exceeding the density threshold receive a finding, and every
    file's duplication ratio feeds the metrics table.
    """

    WINDOW = 6
    #: 3% duplicated density is the common industry quality-gate default.
    DENSITY_THRESHOLD = 0.03

    def __init__(self, registry: LanguageRegistry) -> None:
        self._registry = registry

    def annotate(self, analyses: Sequence[FileAnalysis]) -> None:
        """Set `duplicated_lines` on every metrics object; add findings."""
        prepared: list[tuple[FileAnalysis, list[tuple[int, str]]]] = []
        for analysis in analyses:
            analysis.findings = [f for f in analysis.findings if f.rule_id != 'MET-DUP1']
            if analysis.metrics:
                analysis.metrics.duplicated_lines = 0
            try:
                text = analysis.path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            spec = self._registry.get(analysis.language_id)
            prefixes = spec.comment_prefixes if spec else ()
            lines: list[tuple[int, str]] = []
            raw_lines = text.splitlines()
            if spec:
                raw_lines = LineMasker(spec.comment_prefixes, spec.block_comments,
                                       spec.string_spans, spec.id).mask_lines(raw_lines)
            for line_no, raw in enumerate(raw_lines, start=1):
                stripped = " ".join(raw.split())
                if not stripped or (prefixes and stripped.startswith(prefixes)):
                    continue
                normalised = _NUMBER_LITERAL.sub(
                    "N", _STRING_LITERAL.sub('"S"', stripped))
                lines.append((line_no, normalised))
            prepared.append((analysis, lines))

        # Index every window by its normalised content.
        occurrences: dict[tuple[str, str], list[tuple[int, int]]] = {}
        for file_index, (_, lines) in enumerate(prepared):
            for start in range(len(lines) - self.WINDOW + 1):
                window = "\n".join(entry[1] for entry in lines[start:start + self.WINDOW])
                key = (prepared[file_index][0].language_id, window)
                occurrences.setdefault(key, []).append((file_index, start))

        duplicated: dict[int, set[int]] = {}
        for hits in occurrences.values():
            if len(hits) < 2:
                continue
            for file_index, start in hits:
                duplicated.setdefault(file_index, set()).update(
                    range(start, start + self.WINDOW)
                )

        for file_index, (analysis, lines) in enumerate(prepared):
            dup_lines = duplicated.get(file_index, set())
            if analysis.metrics is not None:
                analysis.metrics.duplicated_lines = len(dup_lines)

            if not lines or analysis.metrics is None:
                continue
            ratio = analysis.metrics.duplication_ratio
            if ratio > self.DENSITY_THRESHOLD and dup_lines:
                first_line = lines[min(dup_lines)][0]
                severity = Severity.MEDIUM if ratio >= 0.10 else Severity.LOW
                analysis.findings.append(Finding(
                    tool=TOOL_NAME,
                    rule_id="MET-DUP1",
                    severity=severity,
                    line=first_line,
                    category=RiskCategory.MAINTAINABILITY,
                    cwe="CWE-1041",
                    message=(
                        f"{ratio:.0%} of this file's code lines "
                        f"({len(dup_lines)} of {analysis.metrics.code_lines}) "
                        f"belong to blocks duplicated elsewhere in the scanned set."
                    ),
                    remediation=(
                        "Extract the repeated block into a shared function/"
                        "procedure or an included library file so a fix in one "
                        "place fixes every copy."
                    ),
                ))
