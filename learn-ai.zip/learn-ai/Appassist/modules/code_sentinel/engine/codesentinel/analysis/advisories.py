"""
Offline software-composition analysis (SCA).

Joins the dependency inventory (``dependencies.DependencyScanner``) against a
bundled advisory database - built once from an OSV / GitHub Advisory snapshot
by ``tools/advisories/import.py`` - and emits a `Finding` for every declared
component whose version falls in a known-vulnerable range.

Fully offline: no network at scan time. The advisory data is a local SQLite
file the operator refreshes on their own cadence; when it is absent, SCA is
silently skipped (like the optional tree-sitter grammars) and the code scan is
unaffected.

The schema is produced by the importer:

    advisories(osv_id PK, summary, details, severity, cwe, aliases,
               published, reference)
    affected(osv_id, ecosystem, package, introduced, fixed, last_affected,
             versions)          -- versions = JSON array or NULL
    meta(key PK, value)         -- snapshot_date, source, advisory_count
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
from pathlib import Path
from typing import Iterable

from ..domain.models import Finding, RiskCategory, Severity
from .dependencies import Dependency, DependencyScanner
from .versions import is_affected, normalize_package

logger = logging.getLogger(__name__)

TOOL_NAME = "sentinel-sca"

#: OSV/GHSA severity labels -> our severity. A matched advisory with an
#: unknown label is treated as HIGH - a known CVE is never "low by default".
_SEVERITY_LABELS = {
    "CRITICAL": Severity.CRITICAL,
    "HIGH": Severity.HIGH,
    "MODERATE": Severity.MEDIUM,
    "MEDIUM": Severity.MEDIUM,
    "LOW": Severity.LOW,
}


def default_db_path() -> "Path | None":
    """
    Resolve the advisory DB, or None when none is installed.

    Order: ``CODESENTINEL_ADVISORY_DB`` env var, then
    ``$CODESENTINEL_HOME/advisories.sqlite``, then a snapshot bundled beside
    the engine (``codesentinel/data/advisories.sqlite``).
    """
    candidates = []
    env = os.environ.get("CODESENTINEL_ADVISORY_DB")
    if env:
        candidates.append(Path(env))
    home = os.environ.get("CODESENTINEL_HOME")
    if home:
        candidates.append(Path(home) / "advisories.sqlite")
    candidates.append(Path(__file__).resolve().parents[1] / "data" / "advisories.sqlite")
    for path in candidates:
        if path.is_file():
            return path
    return None


def severity_from(label: str) -> Severity:
    return _SEVERITY_LABELS.get((label or "").strip().upper(), Severity.HIGH)


class AdvisoryDatabase:
    """Read-only accessor over the bundled advisory SQLite."""

    def __init__(self, path: "str | Path") -> None:
        self._path = str(path)
        uri = f"file:{Path(self._path).as_posix()}?mode=ro"
        self._conn = sqlite3.connect(uri, uri=True, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row

    @property
    def snapshot_date(self) -> str:
        row = self._conn.execute(
            "SELECT value FROM meta WHERE key = 'snapshot_date'").fetchone()
        return row["value"] if row else "unknown"

    def advisories_for(self, ecosystem: str, package: str) -> list:
        """Rows from `affected` joined with `advisories` for one component."""
        return list(self._conn.execute(
            """SELECT a.osv_id, a.summary, a.severity, a.cwe, a.aliases,
                      a.reference, f.introduced, f.fixed, f.last_affected,
                      f.versions
                 FROM affected f JOIN advisories a ON a.osv_id = f.osv_id
                WHERE f.ecosystem = ? AND f.package = ?""",
            (ecosystem, normalize_package(ecosystem, package))))

    def close(self) -> None:
        self._conn.close()


def _fixed_hint(rows: Iterable) -> str:
    fixes = sorted({r["fixed"] for r in rows if r["fixed"]})
    return fixes[0] if fixes else ""


class AdvisoryMatcher:
    """Matches one dependency against the advisory database."""

    def __init__(self, db: AdvisoryDatabase) -> None:
        self._db = db

    def match(self, dep: Dependency) -> list:
        if not dep.version or dep.version == "unpinned":
            return []                        # cannot range-match an unpinned dep
        rows = self._db.advisories_for(dep.ecosystem, dep.name)
        by_advisory: dict = {}
        for row in rows:
            explicit = json.loads(row["versions"]) if row["versions"] else None
            if is_affected(dep.ecosystem, dep.version, row["introduced"],
                           row["fixed"], row["last_affected"], explicit):
                by_advisory.setdefault(row["osv_id"], []).append(row)

        findings = []
        for osv_id, matched in by_advisory.items():
            head = matched[0]
            fixed = _fixed_hint(matched)
            aliases = head["aliases"] or ""
            ref_id = aliases.split(",")[0].strip() if aliases else osv_id
            findings.append(Finding(
                tool=TOOL_NAME, rule_id=osv_id,
                severity=severity_from(head["severity"]),
                line=1, category=RiskCategory.VULNERABLE_DEPENDENCY,
                cwe=(head["cwe"] or "").split(",")[0].strip() or "CWE-1395",
                owasp="A06:2021-Vulnerable and Outdated Components",
                confidence="HIGH",
                snippet=f"{dep.name} {dep.version}",
                message=(
                    f"{dep.name} {dep.version} ({dep.ecosystem}) is affected by "
                    f"{ref_id}: {head['summary'] or 'known vulnerability'}"
                    + (f" Fixed in {fixed}." if fixed else
                       " No fixed version is published.")),
                remediation=(
                    f"Upgrade {dep.name} to {fixed} or later."
                    if fixed else
                    f"Track {ref_id}; no fix is available yet - consider a "
                    f"mitigation or an alternative component.")))
        return findings


class SoftwareCompositionScanner:
    """
    Whole-project SCA: inventory dependencies, match each against the DB, and
    return findings grouped by the manifest that declared them.
    """

    def __init__(self, db: AdvisoryDatabase) -> None:
        self._db = db
        self._matcher = AdvisoryMatcher(db)
        self._deps = DependencyScanner()

    def scan(self, root: Path) -> "dict[str, list[Finding]]":
        """Return ``{manifest_filename: [Finding, ...]}`` for vulnerable deps."""
        by_manifest: dict = {}
        for dep in self._deps.scan(root):
            for finding in self._matcher.match(dep):
                by_manifest.setdefault(dep.source_file, []).append(finding)
        return by_manifest

    def close(self) -> None:
        self._db.close()


def open_default() -> "SoftwareCompositionScanner | None":
    """Build a scanner from the installed advisory DB, or None if absent."""
    path = default_db_path()
    if path is None:
        return None
    try:
        return SoftwareCompositionScanner(AdvisoryDatabase(path))
    except sqlite3.Error:
        logger.warning("Advisory DB at %s could not be opened; SCA skipped",
                       path, exc_info=True)
        return None
