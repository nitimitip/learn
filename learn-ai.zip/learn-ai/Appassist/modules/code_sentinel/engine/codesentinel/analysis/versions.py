"""
Ecosystem-aware version comparison for software-composition analysis.

Matching a dependency version against an advisory's affected range is the
sharp edge of SCA: each ecosystem orders versions differently. This module
provides a total order per ecosystem and an OSV-range containment test.

Supported precisely: PyPI (PEP 440) and npm / crates.io / Go (SemVer) - the
app's ecosystems. Everything else uses a loose numeric comparator that is
correct for ordinary dotted-numeric versions. All comparators are pure and
heavily unit-tested; a wrong answer here is worse than none (a false "safe").
"""

from __future__ import annotations

import re

# A sortable key is a tuple whose natural ordering matches the version order.
# We compare keys with Python's tuple ordering, so every key a comparator
# returns must be internally type-consistent.

_SEMVER_RE = re.compile(
    r"^[vV]?(\d+)\.(\d+)\.(\d+)(?:[-.]?([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?$"
)
_PEP440_RE = re.compile(
    r"^\s*(?:(\d+)!)?"                    # epoch
    r"(\d+(?:\.\d+)*)"                    # release
    r"(?:[-_.]?(a|b|c|rc|alpha|beta|pre|preview)[-_.]?(\d+)?)?"   # pre
    r"(?:[-_.]?(post|rev|r)[-_.]?(\d+)?)?"                        # post
    r"(?:[-_.]?(dev)[-_.]?(\d+)?)?"                               # dev
    r"(?:\+[0-9A-Za-z.]+)?\s*$",         # local (ignored for ordering)
    re.IGNORECASE,
)

# Pre-release phase ordering (lower sorts earlier). Final release == 0.
_PRE_RANK = {"dev": -2, "a": -1, "alpha": -1, "b": 0, "beta": 0,
             "c": 1, "rc": 1, "pre": 1, "preview": 1}


def _int_or_str(token: str):
    return (0, int(token)) if token.isdigit() else (1, token)


def pep440_key(version: str) -> tuple:
    """A total-order key for a PEP 440 version (Python)."""
    match = _PEP440_RE.match(version.strip())
    if not match:
        return _loose_key(version)
    epoch = int(match.group(1) or 0)
    release = tuple(int(p) for p in match.group(2).split("."))
    # dev < pre < release < post. Encode a stage tuple that sorts correctly.
    if match.group(7):                    # devN - pre-release of the release
        stage = (0, int(match.group(8) or 0))
    elif match.group(3):                  # aN / bN / rcN
        stage = (1, _PRE_RANK.get(match.group(3).lower(), 1),
                 int(match.group(4) or 0))
    elif match.group(5):                  # postN
        stage = (3, int(match.group(6) or 0))
    else:                                 # final release
        stage = (2,)
    return (epoch, release, stage)


def semver_key(version: str) -> tuple:
    """A total-order key for a SemVer version (npm, crates.io, Go)."""
    match = _SEMVER_RE.match(version.strip())
    if not match:
        return _loose_key(version)
    major, minor, patch = (int(match.group(i)) for i in (1, 2, 3))
    pre = match.group(4)
    if pre is None:
        # No pre-release sorts AFTER any pre-release of the same core.
        return (major, minor, patch, (1,))
    identifiers = tuple(_int_or_str(part) for part in pre.split("."))
    return (major, minor, patch, (0,) + identifiers)


def _loose_key(version: str) -> tuple:
    """Fallback: split on non-alphanumerics, compare numeric-aware."""
    parts = re.split(r"[.\-_+]", version.strip().lstrip("vV"))
    return tuple(_int_or_str(p) for p in parts if p)


_COMPARATORS = {
    "PyPI": pep440_key,
    "npm": semver_key,
    "crates.io": semver_key,
    "Go": semver_key,
}


def normalize_package(ecosystem: str, name: str) -> str:
    """
    Canonical package name for lookup - the importer and the matcher must
    agree. PyPI is case-insensitive and treats runs of ``-_.`` as equal
    (PEP 503); other ecosystems are lower-cased.
    """
    canon = name.strip().lower()
    if ecosystem == "PyPI":
        canon = re.sub(r"[-_.]+", "-", canon)
    return canon


def version_key(ecosystem: str, version: str) -> tuple:
    return _COMPARATORS.get(ecosystem, _loose_key)(version)


def compare(ecosystem: str, a: str, b: str) -> int:
    """-1 if a < b, 0 if equal, 1 if a > b (per the ecosystem's ordering)."""
    ka, kb = version_key(ecosystem, a), version_key(ecosystem, b)
    try:
        if ka < kb:
            return -1
        if ka > kb:
            return 1
        return 0
    except TypeError:
        # Heterogeneous keys (malformed version) - fall back to string compare.
        sa, sb = str(a), str(b)
        return (sa > sb) - (sa < sb)


def is_affected(ecosystem: str, version: str, introduced: "str | None",
                fixed: "str | None", last_affected: "str | None",
                explicit_versions: "list | None" = None) -> bool:
    """
    Whether ``version`` falls in one OSV affected range.

    OSV semantics: affected when version >= ``introduced`` (``"0"`` or None ==
    from the beginning) and strictly below ``fixed``; ``last_affected`` is an
    inclusive upper bound used when no fix is published. An explicit affected
    ``versions`` list, when given, is authoritative and skips range math.
    """
    if explicit_versions:
        return version in explicit_versions or any(
            compare(ecosystem, version, v) == 0 for v in explicit_versions)

    if introduced not in (None, "0") and compare(ecosystem, version, introduced) < 0:
        return False
    if fixed is not None and compare(ecosystem, version, fixed) >= 0:
        return False
    if last_affected is not None and compare(ecosystem, version, last_affected) > 0:
        return False
    # With no upper bound at all, an "introduced" alone means all >= introduced.
    return True
