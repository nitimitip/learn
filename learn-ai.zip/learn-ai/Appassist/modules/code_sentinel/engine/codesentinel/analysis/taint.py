"""
Python taint analysis (AST data-flow: source -> propagation -> sink).

Intraprocedural taint tracking with one level of interprocedural awareness
for functions defined in the same file. Unlike regex rules, this follows
VALUES: a string read from input() is tracked through assignments,
f-strings, concatenation, and .format() until it reaches a dangerous sink -
or is killed by a sanitiser such as int(). Sinks reached only by clean data
are NOT flagged (removing classic false positives) and sinks reached
indirectly through intermediate variables ARE flagged (removing classic
false negatives).
"""

from __future__ import annotations

import ast
from dataclasses import dataclass

from ..domain.models import Finding, RiskCategory, Severity

TOOL_NAME = "sentinel-taint"

#: sink label -> CWE, for findings synthesised from a summary.
LABEL_CWES = {
    "SQL execution": "CWE-89",
    "OS command execution": "CWE-78",
    "code evaluation": "CWE-95",
    "file access": "CWE-22",
    "server-side request (SSRF)": "CWE-918",
    "file deletion": "CWE-22",
    "TAINT-PATH": "CWE-22",
    "TAINT-SSRF": "CWE-918",
}

# Fully-qualified (dotted) sink descriptors. These are matched against the
# call's DOTTED spelling (requests.get, os.remove) rather than the bare method
# name, so ordinary methods with the same short name - dict.get(),
# list.remove() - never collide with a library sink. `payload_kwargs` names the
# argument that carries the URL/path, so a tainted params=/headers= on
# requests.get is correctly NOT treated as SSRF.
@dataclass(frozen=True)
class _DottedSink:
    rule_id: str
    severity: Severity
    category: str
    cwe: str
    owasp: str
    payload_kwargs: tuple
    remediation: str


_SSRF_SINK = _DottedSink(
    "TAINT-SSRF", Severity.HIGH, RiskCategory.INJECTION, "CWE-918",
    "A10:2021-Server-Side Request Forgery", ("url",),
    "Do not build the request target from user input. Validate the URL against "
    "an allow-list of permitted hosts/schemes, reject internal/loopback/"
    "link-local addresses and redirects to them, and resolve-then-recheck the "
    "host to defeat DNS rebinding.")
_FILE_DELETE_SINK = _DottedSink(
    "TAINT-PATH", Severity.HIGH, RiskCategory.INJECTION, "CWE-22",
    "A01:2021-Broken Access Control", ("path", "name"),
    "Never delete a path derived from user input directly. Confine it to a "
    "known base directory (os.path.realpath then verify it is inside the base), "
    "and reject any '..' or absolute component before the operation.")
_FILE_WRITE_SINK = _DottedSink(
    "TAINT-PATH", Severity.MEDIUM, RiskCategory.INJECTION, "CWE-22",
    "A01:2021-Broken Access Control", ("path", "src", "dst", "filename", "name"),
    "Confine the path to an intended base directory (resolve with realpath and "
    "verify containment) and reject '..'/absolute segments before reading or "
    "writing; do not trust a user-supplied filename as a filesystem path.")


def _build_dotted_sinks() -> dict:
    table = {
        # SSRF (CWE-918): a tainted URL/host drives an outbound request.
        # `urlopen` is unambiguous enough to match bare (from-import form) too.
        "urlopen": _SSRF_SINK,
        "urllib.request.urlopen": _SSRF_SINK,
        "urllib.request.Request": _SSRF_SINK,
        "urllib2.urlopen": _SSRF_SINK,
        # Path traversal (CWE-22): a tainted path drives a filesystem op.
        "os.remove": _FILE_DELETE_SINK,
        "os.unlink": _FILE_DELETE_SINK,
        "os.rmdir": _FILE_DELETE_SINK,
        "os.removedirs": _FILE_DELETE_SINK,
        "shutil.rmtree": _FILE_DELETE_SINK,
        "shutil.copy": _FILE_WRITE_SINK,
        "shutil.copyfile": _FILE_WRITE_SINK,
        "shutil.copy2": _FILE_WRITE_SINK,
        "shutil.move": _FILE_WRITE_SINK,
        "os.rename": _FILE_WRITE_SINK,
        "os.replace": _FILE_WRITE_SINK,
        "os.mkdir": _FILE_WRITE_SINK,
        "os.makedirs": _FILE_WRITE_SINK,
    }
    # Only the verb helpers take the URL as the first positional argument;
    # requests.request(method, url) / httpx.stream(method, url) are
    # method-first, so their URL is not payload-position-0 and they are
    # deliberately omitted rather than mis-inspected.
    for library in ("requests", "httpx"):
        for verb in ("get", "post", "put", "delete", "patch", "head",
                     "options"):
            table[f"{library}.{verb}"] = _SSRF_SINK
    return table


#: dotted call spelling -> sink descriptor (see _build_dotted_sinks).
_DOTTED_SINKS = _build_dotted_sinks()


class PythonTaintScanner:
    """Forward taint propagation over the Python AST."""

    #: Calls whose return value is attacker-influenced.
    _SOURCE_CALLS = frozenset({"input", "raw_input", "recv", "recvfrom", "readline"})
    #: Attribute chains that denote external input (web frameworks, argv).
    _SOURCE_ATTRS = ("request.", "sys.argv", "flask.request", "self.request.")
    #: Conversions that neutralise string-based injection.
    # Quoting is context-specific: shell quoting does not make SQL, paths,
    # URLs or eval safe. Never treat a function named quote as a universal cleanser.
    _SANITIZERS = frozenset({"int", "float", "bool", "len"})

    #: sink name -> (rule id, severity, human label, CWE)
    _SINKS: dict[str, tuple[str, Severity, str, str]] = {
        "execute": ("TAINT-SQL", Severity.CRITICAL, "SQL execution", "CWE-89"),
        "executemany": ("TAINT-SQL", Severity.CRITICAL, "SQL execution", "CWE-89"),
        "executescript": ("TAINT-SQL", Severity.CRITICAL, "SQL execution", "CWE-89"),
        "system": ("TAINT-CMD", Severity.CRITICAL, "OS command execution", "CWE-78"),
        "popen": ("TAINT-CMD", Severity.CRITICAL, "OS command execution", "CWE-78"),
        "eval": ("TAINT-EVAL", Severity.CRITICAL, "code evaluation", "CWE-95"),
        "exec": ("TAINT-EVAL", Severity.CRITICAL, "code evaluation", "CWE-95"),
        "open": ("TAINT-PATH", Severity.MEDIUM, "file access", "CWE-22"),
    }
    _SUBPROCESS_FUNCS = frozenset({"run", "call", "check_call", "check_output", "Popen"})

    #: sink name -> keyword names that carry the injectable payload when it
    #: is passed by keyword instead of positionally. Only THESE keywords are
    #: sink-relevant: a tainted `parameters=` on execute() is the safe,
    #: parameterised form and must never be flagged. `statement` covers
    #: python-oracledb, `operation` the DB-API spec wording.
    _SINK_PAYLOAD_KWARGS: dict[str, tuple[str, ...]] = {
        "execute": ("sql", "query", "operation", "statement"),
        "executemany": ("sql", "query", "operation", "statement"),
        "executescript": ("sql_script", "sql"),
        "system": ("command", "cmd"),
        "popen": ("cmd", "command"),
        "open": ("file", "name"),
    }
    _SUBPROCESS_PAYLOAD_KWARGS = ("args",)

    def scan_text(self, text: str) -> list[Finding]:
        """Parse and scan; returns [] when the file does not parse."""
        try:
            tree = ast.parse(text)
        except (SyntaxError, ValueError, RecursionError):
            return []  # the AST checker reports parse failures
        return self.scan(tree)

    def function_summary(self, func) -> "tuple[int, str] | None":
        """
        Stage 5 summary for one function: (sink line, sink label) when a
        parameter flows into a dangerous sink, else None. This is the
        wrapper pre-pass exposed for cross-file analysis.
        """
        params = {a.arg: func.lineno for a in [*func.args.posonlyargs, *func.args.args, *func.args.kwonlyargs]
                  if a.arg != "self"}
        if not params:
            return None
        self._wrappers = {}
        self._external = {}
        self._summary_mode = True
        hits = self._scan_scope(func.body, dict(params), collect=None)
        self._summary_mode = False
        return hits[0] if hits else None

    def parameter_summary(self, func):
        """Only arguments that actually flow to a sink belong in a summary."""
        positional = [*func.args.posonlyargs, *func.args.args]
        parameters = [(a.arg, i) for i, a in enumerate(positional)]
        parameters += [(a.arg, None) for a in func.args.kwonlyargs]
        flows = []
        self._summary_mode = True
        for name, position in parameters:
            if name in {'self', 'cls'}:
                continue
            hits = self._scan_scope(func.body, {name: func.lineno}, collect=None)
            for line, label in hits:
                item = (name, position, line, label)
                if item not in flows:
                    flows.append(item)
        self._summary_mode = False
        return flows

    def _forwarded_arguments(self, call, flows):
        for name, position, line, label in flows:
            if position is not None and position < len(call.args):
                yield call.args[position], line, label
            for kw in call.keywords:
                if kw.arg == name:
                    yield kw.value, line, label

    def scan(self, tree: ast.AST, external_wrappers: "dict | None" = None) -> list[Finding]:
        """
        `external_wrappers` maps a call spelling - a bare imported name or a
        dotted `module.function` - to (origin display, sink line, sink
        label): sink-forwarding functions defined in OTHER files. Tainted
        calls into them are reported as TAINT-XFILE.
        """
        self._external = dict(external_wrappers or {})
        self._summary_mode = False
        self._aliases = {}
        for node in getattr(tree, 'body', []):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    self._aliases[alias.asname or alias.name.split('.')[0]] = (
                        alias.name if alias.asname else alias.name.split('.')[0])
            elif isinstance(node, ast.ImportFrom) and node.module:
                for alias in node.names:
                    self._aliases[alias.asname or alias.name] = node.module + '.' + alias.name
        findings: list[Finding] = []

        # Pass 1: which locally-defined functions forward a parameter into a
        # sink? (one level of interprocedural analysis)
        self._wrappers: dict[str, tuple[int, str]] = {}
        for node in getattr(tree, 'body', []):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                flows = self.parameter_summary(node)
                if flows:
                    self._wrappers[node.name] = flows

        # Pass 2: real taint from real sources, module level and per function.
        body = tree.body if isinstance(tree, ast.Module) else []
        self._scan_scope(body, {}, collect=findings)
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self._scan_scope(node.body, {}, collect=findings)

        # De-duplicate by (rule, line).
        seen: set[tuple[str, int]] = set()
        unique: list[Finding] = []
        for finding in findings:
            if (finding.rule_id, finding.line) not in seen:
                seen.add((finding.rule_id, finding.line))
                unique.append(finding)
        return unique

    # ---- Scope walker ------------------------------------------------------

    def _scan_scope(
        self,
        body: list[ast.stmt],
        tainted: dict[str, int],
        collect: list[Finding] | None,
    ) -> list[tuple[int, str]]:
        """
        Forward pass over statements tracking `tainted: name -> origin line`.
        Branch states are joined and actual loops use a bounded fixed point.
        When `collect` is a
        list, real findings are appended; when None, raw sink hits are
        returned (used for the wrapper pre-pass with pre-tainted params).
        """
        hits: list[tuple[int, str]] = []

        def expressions(node):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
                return
            if isinstance(node, ast.Call):
                hit = self._check_sink(node, tainted, collect)
                if hit:
                    hits.append(hit)
            for child in ast.iter_child_nodes(node):
                expressions(child)

        def assign(target, origin):
            if isinstance(target, ast.Name):
                if origin is None:
                    tainted.pop(target.id, None)
                else:
                    tainted[target.id] = origin
            elif isinstance(target, (ast.Tuple, ast.List)):
                for item in target.elts:
                    assign(item, origin)

        for stmt in body:
            if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                continue
            if isinstance(stmt, ast.If):
                expressions(stmt.test)
                if isinstance(stmt.test, ast.Constant):
                    branch = stmt.body if stmt.test.value else stmt.orelse
                    hits.extend(self._scan_scope(branch, tainted, collect))
                else:
                    left, right = dict(tainted), dict(tainted)
                    hits.extend(self._scan_scope(stmt.body, left, collect))
                    hits.extend(self._scan_scope(stmt.orelse, right, collect))
                    tainted.clear()
                    tainted.update(right)
                    tainted.update(left)
                continue
            if isinstance(stmt, (ast.For, ast.AsyncFor, ast.While)):
                expressions(stmt.iter if isinstance(stmt, (ast.For, ast.AsyncFor)) else stmt.test)
                if isinstance(stmt, ast.While) and isinstance(stmt.test, ast.Constant) and not stmt.test.value:
                    hits.extend(self._scan_scope(stmt.orelse, tainted, collect))
                    continue
                entry = dict(tainted)
                if isinstance(stmt, (ast.For, ast.AsyncFor)):
                    assign(stmt.target, self._expr_taint(stmt.iter, tainted))
                # Bounded fixed point only for actual loops, never for a
                # straight-line block (which previously allowed backward taint).
                for _ in range(8):
                    before = dict(tainted)
                    hits.extend(self._scan_scope(stmt.body, tainted, collect))
                    tainted.update(entry)  # zero iterations remain possible
                    if tainted == before:
                        break
                hits.extend(self._scan_scope(stmt.orelse, tainted, collect))
                continue
            if isinstance(stmt, (ast.Try, getattr(ast, 'TryStar', ast.Try))):
                entry = dict(tainted)
                hits.extend(self._scan_scope(stmt.body, tainted, collect))
                hits.extend(self._scan_scope(stmt.orelse, tainted, collect))
                for handler in stmt.handlers:
                    branch = dict(entry)
                    hits.extend(self._scan_scope(handler.body, branch, collect))
                    tainted.update(branch)
                hits.extend(self._scan_scope(stmt.finalbody, tainted, collect))
                continue
            if isinstance(stmt, (ast.With, ast.AsyncWith)):
                for item in stmt.items:
                    expressions(item.context_expr)
                    assign(item.optional_vars, self._expr_taint(item.context_expr, tainted))
                hits.extend(self._scan_scope(stmt.body, tainted, collect))
                continue
            expressions(stmt)  # evaluate RHS/sinks before overwriting names
            if isinstance(stmt, (ast.Assign, ast.AnnAssign)) and stmt.value is not None:
                origin = self._expr_taint(stmt.value, tainted)
                for target in stmt.targets if isinstance(stmt, ast.Assign) else [stmt.target]:
                    assign(target, origin)
            elif isinstance(stmt, ast.AugAssign):
                assign(stmt.target, self._expr_taint(stmt.target, tainted) or
                       self._expr_taint(stmt.value, tainted))
            elif isinstance(stmt, ast.Delete):
                for target in stmt.targets:
                    assign(target, None)
            if isinstance(stmt, (ast.Return, ast.Raise, ast.Break, ast.Continue)):
                break
        return hits

    # ---- Expression taint ----------------------------------------------------

    def _expr_taint(self, node: ast.expr, tainted: dict[str, int]) -> int | None:
        """Return the source line the expression's taint originates from."""
        if isinstance(node, ast.Name):
            return tainted.get(node.id)
        if isinstance(node, (ast.Attribute, ast.Subscript)):
            dotted = self._canonical(node)
            if any(dotted.startswith(prefix) or prefix.rstrip(".") == dotted
                   for prefix in self._SOURCE_ATTRS):
                return None if getattr(self, '_summary_mode', False) else node.lineno
            return self._expr_taint(node.value, tainted)
        if isinstance(node, ast.Call):
            name = self._canonical(node.func)
            if name in self._SANITIZERS:
                return None
            if name in self._SOURCE_CALLS:
                return None if getattr(self, '_summary_mode', False) else node.lineno
            # str()/format()/join()/strip() etc. propagate their inputs' taint.
            for arg in list(node.args) + [kw.value for kw in node.keywords]:
                origin = self._expr_taint(arg, tainted)
                if origin is not None:
                    return origin
            if isinstance(node.func, ast.Attribute):
                return self._expr_taint(node.func.value, tainted)
            return None
        if isinstance(node, ast.BinOp):
            return (self._expr_taint(node.left, tainted)
                    or self._expr_taint(node.right, tainted))
        if isinstance(node, ast.JoinedStr):  # f-string
            for value in node.values:
                if isinstance(value, ast.FormattedValue):
                    origin = self._expr_taint(value.value, tainted)
                    if origin is not None:
                        return origin
            return None
        if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
            for element in node.elts:
                origin = self._expr_taint(element, tainted)
                if origin is not None:
                    return origin
        if isinstance(node, (ast.IfExp, ast.BoolOp, ast.Dict, ast.Await, ast.NamedExpr)):
            for child in ast.iter_child_nodes(node):
                if isinstance(child, ast.expr):
                    origin = self._expr_taint(child, tainted)
                    if origin is not None:
                        return origin
        return None

    # ---- Sink detection --------------------------------------------------------

    def _payload_taint(
        self,
        call: ast.Call,
        tainted: dict[str, int],
        payload_kwargs: tuple[str, ...],
    ) -> int | None:
        """
        Taint of the sink's PAYLOAD argument: the first positional argument,
        or - when the payload is passed by keyword (`execute(sql=query)`,
        `subprocess.run(args=cmd)`) - the matching keyword's value. Other
        keywords (parameters=, env=, timeout=) are never payload.
        """
        if call.args:
            return self._expr_taint(call.args[0], tainted)
        for kw in call.keywords:
            if kw.arg is not None and kw.arg in payload_kwargs:
                return self._expr_taint(kw.value, tainted)
        return None

    def _check_sink(
        self,
        call: ast.Call,
        tainted: dict[str, int],
        collect: list[Finding] | None,
    ) -> tuple[int, str] | None:
        name = self._call_name(call)

        # Dotted-name sinks (SSRF, unsafe file operations): matched on the
        # full call spelling so requests.get / os.remove are caught while
        # dict.get / list.remove are not. Only the URL/path payload argument
        # is inspected (params=/headers= on a request are not SSRF).
        dotted = self._canonical(call.func)
        sink = _DOTTED_SINKS.get(dotted)
        if sink is not None:
            payload = self._payload_taint(call, tainted, sink.payload_kwargs)
            if payload is not None:
                if collect is not None:
                    collect.append(self._dotted_finding(call, sink, payload,
                                                        dotted))
                return (call.lineno, sink.rule_id)
            return None

        # subprocess.* with shell=True and a tainted command
        if dotted in {'subprocess.' + n for n in self._SUBPROCESS_FUNCS}:
            shell = any(
                kw.arg == "shell" and isinstance(kw.value, ast.Constant)
                and kw.value.value is True
                for kw in call.keywords
            )
            payload = self._payload_taint(call, tainted,
                                          self._SUBPROCESS_PAYLOAD_KWARGS)
            if shell and payload is not None:
                return self._emit(call, "TAINT-CMD", Severity.CRITICAL,
                                  "OS command execution", "CWE-78",
                                  payload, name, collect)
            return None

        if name in self._SINKS and (
                name in {'execute', 'executemany', 'executescript'} or
                dotted in {'os.system', 'os.popen', 'eval', 'exec', 'open', 'builtins.open'}):
            payload = self._payload_taint(
                call, tainted, self._SINK_PAYLOAD_KWARGS.get(name, ()))
            if payload is not None:
                rule, severity, label, cwe = self._SINKS[name]
                return self._emit(call, rule, severity, label, cwe,
                                  payload, name, collect)
            return None

        # One-level interprocedural: call into a local sink-wrapper function.
        # Keyword arguments forward taint just like positional ones.
        if collect is not None and isinstance(call.func, ast.Name) and name in self._wrappers:
            for arg, sink_line, sink_label in self._forwarded_arguments(call, self._wrappers[name]):
                origin = self._expr_taint(arg, tainted)
                if origin is not None:
                    collect.append(Finding(
                        tool=TOOL_NAME, rule_id="TAINT-CALL",
                        severity=Severity.HIGH, line=call.lineno,
                        category=RiskCategory.INJECTION, cwe=LABEL_CWES.get(sink_label, 'CWE-20'),
                        owasp="A03:2021-Injection",
                        message=(
                            f"Tainted data (from line {origin}) is passed to "
                            f"local function '{name}()', which forwards its "
                            f"parameter into a {sink_label} sink "
                            f"(line {sink_line})."
                        ),
                        remediation="Sanitise/validate before the call, or "
                                    "parameterise the sink inside the function "
                                    "so no caller can inject.",
                    ))
                    return (call.lineno, "call")

        # Cross-file (Stage 5): a tainted call into a sink-forwarding
        # function defined in another scanned file. Lookup is by the exact
        # call spelling - a bare imported name or `module.function` - so
        # `self.helper(...)` or an unrelated same-named method never links.
        if collect is not None and self._external:
            entry = self._external.get(self._dotted(call.func))
            if entry is not None:
                origin_display, sink_line, sink_label = entry[:3]
                arguments = (self._forwarded_arguments(call, entry[3]) if len(entry) > 3 else
                             ((arg, sink_line, sink_label) for arg in
                              list(call.args) + [kw.value for kw in call.keywords if kw.arg is not None]))
                for arg, sink_line, sink_label in arguments:
                    origin = self._expr_taint(arg, tainted)
                    if origin is not None:
                        collect.append(Finding(
                            tool=TOOL_NAME, rule_id="TAINT-XFILE",
                            severity=Severity.HIGH, line=call.lineno,
                            category=RiskCategory.INJECTION,
                            cwe=LABEL_CWES.get(sink_label, "CWE-20"),
                            owasp="A03:2021-Injection", confidence="MEDIUM",
                            message=(
                                f"Cross-file taint: data from line {origin} "
                                f"is passed to '{self._call_name(call)}()', "
                                f"defined in {origin_display}, which forwards "
                                f"its parameter into a {sink_label} sink "
                                f"({origin_display} line {sink_line})."
                            ),
                            remediation="Sanitise/validate before the call, "
                                        "or parameterise the sink inside the "
                                        "shared function so no caller can "
                                        "inject.",
                        ))
                        return (call.lineno, "call")
        return None

    def _emit(
        self,
        call: ast.Call,
        rule: str,
        severity: Severity,
        label: str,
        cwe: str,
        origin: int,
        name: str,
        collect: list[Finding] | None,
    ) -> tuple[int, str]:
        if collect is not None:
            collect.append(Finding(
                tool=TOOL_NAME, rule_id=rule, severity=severity,
                line=call.lineno, category=RiskCategory.INJECTION, cwe=cwe,
                owasp="A03:2021-Injection",
                message=(
                    f"User-controlled data (entering at line {origin}) flows "
                    f"into {label} '{name}()' without sanitisation - "
                    f"identified by bounded static data-flow analysis; review reachability and validation."
                ),
                remediation=(
                    "Break the flow: validate/convert the input at the "
                    "boundary (allow-list, int()), and parameterise the sink "
                    "(bound SQL parameters, argument arrays, no eval)."
                ),
            ))
        return (call.lineno, label)

    @staticmethod
    def _dotted_finding(call: ast.Call, sink: "_DottedSink", origin: int,
                        dotted: str) -> Finding:
        """Build a finding for a dotted SSRF / unsafe-file-operation sink."""
        return Finding(
            tool=TOOL_NAME, rule_id=sink.rule_id, severity=sink.severity,
            line=call.lineno, category=sink.category, cwe=sink.cwe,
            owasp=sink.owasp,
            message=(
                f"User-controlled data (entering at line {origin}) flows into "
                f"'{dotted}()' as the request/path target without validation - "
                f"identified by bounded static data-flow analysis; review reachability and validation."
            ),
            remediation=sink.remediation,
        )

    # ---- Helpers ------------------------------------------------------------

    def _canonical(self, node: ast.expr) -> str:
        dotted = self._dotted(node)
        first, sep, tail = dotted.partition('.')
        return getattr(self, '_aliases', {}).get(first, first) + (sep + tail if sep else '')

    @staticmethod
    def _call_name(call: ast.Call) -> str:
        func = call.func
        if isinstance(func, ast.Name):
            return func.id
        if isinstance(func, ast.Attribute):
            return func.attr
        return ""

    @staticmethod
    def _dotted(node: ast.expr) -> str:
        parts: list[str] = []
        while True:
            if isinstance(node, ast.Attribute):
                parts.append(node.attr)
                node = node.value
            elif isinstance(node, ast.Subscript):
                node = node.value
            elif isinstance(node, ast.Name):
                parts.append(node.id)
                break
            else:
                break
        return ".".join(reversed(parts))
