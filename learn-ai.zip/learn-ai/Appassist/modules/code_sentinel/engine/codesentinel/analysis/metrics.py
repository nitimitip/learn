"""Dependency-free size/complexity measurement."""

from __future__ import annotations

from ..domain.models import CodeMetrics
from .languages import LanguageSpec
from ..rules.engine import LineMasker


class MetricsCalculator:
    """
    Lexical metrics: line categories, decision-point complexity, functions.

    Cyclomatic complexity is approximated by counting decision points
    (branch keywords and short-circuit operators) on code lines - the same
    computed lexically rather than from a full control-flow graph. These are
    estimates; there is no measured equivalence to a compiler-based metric.
    """

    def measure(self, text: str, spec: LanguageSpec) -> CodeMetrics:
        metrics = CodeMetrics()
        prefixes = spec.comment_prefixes
        decisions = spec.decision_pattern
        functions = spec.function_pattern

        lines = text.splitlines()
        visible = LineMasker(spec.comment_prefixes, spec.block_comments,
                             spec.string_spans, spec.id).mask_lines(lines)
        code = LineMasker(spec.comment_prefixes, spec.block_comments,
                          spec.string_spans, spec.id, True).mask_lines(lines)
        for raw, uncommented, tokens in zip(lines, visible, code):
            metrics.total_lines += 1
            stripped = raw.strip()
            if not stripped:
                metrics.blank_lines += 1
                continue
            if not uncommented.strip():
                metrics.comment_lines += 1
                continue
            metrics.code_lines += 1
            if decisions:
                metrics.complexity += len(decisions.findall(tokens))
            if functions and functions.search(tokens):
                metrics.functions += 1

        return metrics
