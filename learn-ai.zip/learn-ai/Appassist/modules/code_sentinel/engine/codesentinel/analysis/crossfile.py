"""
Cross-file taint analysis (roadmap Stage 5).

Links a tainted call site in one Python file to a sink-forwarding function
defined in ANOTHER scanned file - the shared `db_utils.run_query(sql)`
helper pattern that per-file analysis cannot see.

Method:
  1. **Summaries** - every scanned Python file is parsed once; each
     top-level function is summarised via the taint scanner's wrapper
     pre-pass as "parameter reaches a <label> sink at line N" (or nothing).
  2. **Import-aware linking** - a caller is only connected to a summary it
     actually imports: `from mod import fn` (with aliases) binds the bare
     name, `import mod` / `from pkg import mod` binds the dotted
     `mod.fn` spelling. Matching is by module stem, so `app.db_utils`,
     `.db_utils` and `db_utils` all resolve to the scanned db_utils.py.
  3. **Caller re-scan** - files that import at least one summarised name are
     re-scanned with those external wrappers injected; only the resulting
     TAINT-XFILE findings are kept and attached to the caller's analysis.

Precision properties: linking requires an explicit import AND the exact
call spelling (`self.helper(...)` or an unrelated same-named method never
matches); a name summarised in the caller's own file is excluded (the
local TAINT-CALL rule owns that); confidence is MEDIUM because name-based
module resolution cannot see search paths.

Runs AFTER the incremental-cache write-back: cross-file findings depend on
other files, so they are recomputed fresh on every run and never cached.
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import Sequence

from ..domain.models import FileAnalysis, Finding
from .taint import PythonTaintScanner

logger = logging.getLogger(__name__)

TOOL_NAME = "sentinel-xfile"


class _Summary:
    """One sink-forwarding function discovered in a scanned file."""

    __slots__ = ("module_stem", "name", "display", "sink_line", "label", "path", "flows")

    def __init__(self, module_stem: str, name: str, display: str,
                 sink_line: int, label: str, path: Path, flows=()) -> None:
        self.module_stem = module_stem
        self.name = name
        self.display = display
        self.sink_line = sink_line
        self.label = label
        self.path = path
        self.flows = flows


class CrossFileTaintAnalyzer:
    """Builds summaries, resolves imports, and attaches TAINT-XFILE findings."""

    def annotate(self, analyses: Sequence[FileAnalysis]) -> None:
        python_files = [a for a in analyses if a.language_id == "python"]
        if len(python_files) < 2:
            return

        trees: dict = {}         # path -> (ast tree, source text)
        for analysis in python_files:
            parsed = self._parse(analysis.path)
            if parsed is not None:
                trees[analysis.path] = parsed

        summaries = self._collect_summaries(trees)
        if not summaries:
            return

        for analysis in python_files:
            parsed = trees.get(analysis.path)
            if parsed is None:
                continue
            tree, text = parsed
            external = self._resolve_imports(tree, summaries, analysis.path)
            if not external:
                continue
            findings = [
                finding for finding in
                PythonTaintScanner().scan(tree, external_wrappers=external)
                if finding.rule_id == "TAINT-XFILE"
            ]
            if not findings:
                continue
            lines = text.splitlines()
            existing = {(f.rule_id, f.line) for f in analysis.findings}
            for finding in findings:
                if (finding.rule_id, finding.line) in existing:
                    continue
                if not finding.snippet and 1 <= finding.line <= len(lines):
                    finding = _with_snippet(
                        finding, lines[finding.line - 1].strip()[:200])
                analysis.findings.append(finding)
            if TOOL_NAME not in analysis.tools_run:
                analysis.tools_run.append(TOOL_NAME)

    # ---- Internals ----------------------------------------------------------

    @staticmethod
    def _parse(path: Path):
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
            return ast.parse(text), text
        except (OSError, SyntaxError, ValueError, RecursionError):
            return None

    @staticmethod
    def _collect_summaries(trees: dict) -> dict:
        """module stem -> {function name -> _Summary} for every file."""
        scanner = PythonTaintScanner()
        by_module: dict = {}
        stems = {}
        for path in trees:
            stems.setdefault(path.stem.lower(), []).append(path)
        for path, (tree, _text) in trees.items():
            # Stem-based resolution cannot disambiguate package siblings.
            # Do not silently link to whichever same-named module was last.
            if len(stems[path.stem.lower()]) > 1:
                continue
            for node in tree.body:
                if not isinstance(node, (ast.FunctionDef,
                                         ast.AsyncFunctionDef)):
                    continue
                hit = scanner.function_summary(node)
                if hit is None:
                    continue
                sink_line, label = hit
                flows = scanner.parameter_summary(node)
                stem = path.stem.lower()
                by_module.setdefault(stem, {})[node.name] = _Summary(
                    stem, node.name, path.name, sink_line, label, path, flows)
        return by_module

    @staticmethod
    def _resolve_imports(tree, summaries: dict, own_path: Path) -> dict:
        """
        Call spellings this file binds to foreign summaries:
        bare names for `from mod import fn [as alias]`, dotted `mod.fn`
        for `import mod [as alias]` and `from pkg import mod`.
        """
        external: dict = {}

        def bind(spelling: str, summary: _Summary) -> None:
            if summary.path != own_path:      # local wrappers own their file
                external[spelling] = (summary.display, summary.sink_line,
                                      summary.label, summary.flows)

        def module_entry(dotted_module: str):
            stem = dotted_module.rsplit(".", 1)[-1].lower()
            return stem, summaries.get(stem)

        for node in tree.body:
            if isinstance(node, ast.ImportFrom):
                if node.module:
                    _stem, table = module_entry(node.module)
                    if table:
                        for alias in node.names:
                            summary = table.get(alias.name)
                            if summary is not None:
                                bind(alias.asname or alias.name, summary)
                # `from . import db_utils` - the names ARE modules.
                if node.module is None and node.level:
                    for alias in node.names:
                        _stem, table = module_entry(alias.name)
                        if table:
                            local = alias.asname or alias.name
                            for summary in table.values():
                                bind(f"{local}.{summary.name}", summary)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    _stem, table = module_entry(alias.name)
                    if table:
                        # `import a.b.mod` is called as a.b.mod.fn(...);
                        # `import mod as m` as m.fn(...).
                        local = alias.asname if alias.asname else alias.name
                        for summary in table.values():
                            bind(f"{local}.{summary.name}", summary)
        return external


def _with_snippet(finding: Finding, snippet: str) -> Finding:
    from dataclasses import replace
    return replace(finding, snippet=snippet)
