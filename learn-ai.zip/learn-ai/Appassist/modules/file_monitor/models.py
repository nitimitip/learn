from sqlalchemy import (Column, Integer, String, DateTime, Text, Boolean, Enum,
                        ForeignKey, Index, UniqueConstraint)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from database import Base
import enum

class FlowType(enum.Enum):
    INBOUND = "Inbound"
    OUTBOUND = "Outbound"

class SystemType(enum.Enum):
    ORACLE = "oracle"
    MSSQL = "mssql"
    LOG = "log"

# ===========================================================================
# Application Towers - who owns which monitored applications, and who is
# allowed to look at them.
#
# Mirrors application_health_check: an administrator creates the tower and
# adds members; the reports created under it are visible and runnable ONLY
# to those members (administrators see everything). A file-monitor dashboard
# view is not a passive read - it opens live connections to the monitored
# source / intermediate / target systems - so membership gates execution as
# well as visibility.
# ===========================================================================

class FileMonitorTower(Base):
    __tablename__ = 'file_monitor_towers'

    __table_args__ = (
        Index('ix_fm_tower_is_active', 'is_active'),
    )

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    # Comma-separated. Added to every pending-file alert this tower's reports
    # send, on top of the per-report recipients, so a tower-wide distribution
    # list is configured once instead of on each report.
    email_addresses = Column(Text)
    created_at = Column(DateTime, default=func.now())
    created_by = Column(Integer, ForeignKey('users.id'))
    is_active = Column(Boolean, default=True, nullable=False)

    # Reports are NOT cascade-deleted with the tower. A report row carries the
    # whole monitoring configuration (queries, hosts, encrypted credentials),
    # so deleting a tower must never silently destroy it - routes.delete_tower
    # refuses while reports are still attached.
    reports = relationship('FileMonitorReport', back_populates='tower')
    tower_members = relationship(
        'FileMonitorTowerMember',
        back_populates='tower',
        cascade='all, delete-orphan',
        passive_deletes=True,
    )

    def __repr__(self):
        return f'<FileMonitorTower {self.name}>'


class FileMonitorTowerMember(Base):
    __tablename__ = 'file_monitor_tower_members'

    __table_args__ = (
        # A user can only be added to a given tower once.
        UniqueConstraint('tower_id', 'user_id', name='uq_fm_tower_member_tower_user'),
        Index('ix_fm_tower_member_tower_id', 'tower_id'),
        Index('ix_fm_tower_member_user_id', 'user_id'),
    )

    id = Column(Integer, primary_key=True)
    tower_id = Column(Integer, ForeignKey('file_monitor_towers.id', ondelete='CASCADE'),
                      nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    added_at = Column(DateTime, default=func.now())
    added_by = Column(Integer, ForeignKey('users.id'))

    tower = relationship('FileMonitorTower', back_populates='tower_members')

    def __repr__(self):
        return f'<FileMonitorTowerMember tower={self.tower_id} user={self.user_id}>'


class FileMonitorReport(Base):
    __tablename__ = 'file_monitor_reports'
   
    id = Column(Integer, primary_key=True)
    # Owning tower. NULLABLE on purpose: reports created before towers existed
    # keep working and show as "Unassigned" to administrators, who can attach
    # them from the report settings page. An unassigned report has no member
    # list, so only administrators can open its dashboard.
    tower_id = Column(Integer, ForeignKey('file_monitor_towers.id'), index=True)
    application_name = Column(String(200), nullable=False)
    short_summary = Column(Text)
    flow_type = Column(Enum(FlowType), nullable=False)
    # Legacy fixed exclusion slots. Still honoured (treated as auto-column
    # rules) so pre-existing reports keep working, but new configuration goes
    # into exclusion_rules below.
    exclude_data = Column(String(500))
    exclude_data1 = Column(String(500))
    # Dynamic exclusions: JSON list of rules, each
    #   {"column": "<name or '' for auto-detect>", "values": "v1,v2,*.usr", "label": "<optional>"}
    # Different systems exclude on different attributes (region, flow type,
    # file time, ...), so the rule set is per-report and unbounded.
    # (Report-level; applies to the SOURCE data. Kept for reports created
    # before the per-system *_exclusion_config columns below existed.)
    exclusion_rules = Column(Text)

    # Pending-file alerting: previous-day files still pending at source /
    # intermediate trigger a daily email to these comma-separated recipients.
    alert_enabled = Column(Boolean, default=False)
    alert_emails = Column(String(500))

    # Per-system NAMED configuration (JSON text), the primary mechanism since
    # the form rework. Both are optional toggles on the form.
    #
    #   *_stats_config     : [{"name": "Flow Type", "ref": "FLOW_TYPE"}, ...]
    #       'ref' is a COLUMN NAME for oracle/mssql systems and a SPLIT
    #       POSITION (integer) for log systems. Each named stat gets its own
    #       distribution graph. Falls back to the legacy primary/secondary
    #       stats columns / *_stats_pattern when absent.
    #
    #   *_exclusion_config : [{"name": "Non-UK", "ref": "REGION", "values": "EU,IE"}, ...]
    #       Same ref semantics. Source exclusions mark files as
    #       never-meant-for-destination (Excluded bucket + breakdown);
    #       intermediate/target exclusions filter that system's data BEFORE
    #       matching (shared folders/tables carrying other apps' files).
    #   *_display_config   : [{"name": "Region", "ref": "REGION"}, ...]
    #       Which fields the dashboard TABLES show for this system, since the
    #       monitored applications share no common structure. Same ref
    #       semantics (column name for db, split position for log). When
    #       absent, tables show every fetched column (legacy behaviour).
    source_stats_config = Column(Text)
    source_exclusion_config = Column(Text)
    source_display_config = Column(Text)
    intermediate_stats_config = Column(Text)
    intermediate_exclusion_config = Column(Text)
    intermediate_display_config = Column(Text)
    target_stats_config = Column(Text)
    target_exclusion_config = Column(Text)
    target_display_config = Column(Text)

    # Cross-system exclusion. Many applications record only the FILE NAME on
    # one system (typically the source) and hold the attributes exclusions are
    # written against (region, flow type, ...) on another. With this on, the
    # set of FILE NAMES excluded by any system's rules is excluded on every
    # other system too, matched by name - so one rule configured where the
    # attribute actually exists covers the whole pipeline.
    exclusion_apply_all = Column(Boolean, default=False)

    # Alerting grace: a file may stay pending this many days before the daily
    # email flags it. 1 = alert on anything from yesterday or older (default);
    # 2 = tolerate once-a-day downstream batch jobs that run after the sweep.
    alert_grace_days = Column(Integer, default=1)
   
    # Source System
    source_name = Column(String(200), nullable=False)
    source_system_type = Column(Enum(SystemType), nullable=False)
    source_connection_string = Column(Text)  # Encrypted
    source_username = Column(String(100))
    source_password = Column(Text)  # Encrypted
    source_sql_query = Column(Text)
    source_filename_column = Column(String(100))
    source_primary_stats_column = Column(String(100))
    source_secondary_stats_column = Column(String(100))
    source_date_format=Column(String(20))
   
    # SFTP/Log specific fields for source
    source_hostname = Column(String(200))
    source_path = Column(String(500))
    source_sftp_username = Column(String(100))
    source_sftp_password = Column(Text)  # Encrypted
    source_file_naming_convention = Column(String(500))
    source_extraction_pattern = Column(String(500))
    source_data_split=Column(String(10))
    source_data_fileName=Column(Integer)
    source_stats_pattern=Column(Integer)
    # (source_date_format is declared once above)

    # Intermediate System (Optional)
    has_intermediate = Column(Boolean, default=False)
    intermediate_name = Column(String(200))
    intermediate_system_type = Column(Enum(SystemType))
    intermediate_connection_string = Column(Text)  # Encrypted
    intermediate_username = Column(String(100))
    intermediate_password = Column(Text)  # Encrypted
    intermediate_sql_query = Column(Text)
    intermediate_filename_column = Column(String(100))
    intermediate_primary_stats_column = Column(String(100))
    intermediate_secondary_stats_column = Column(String(100))
    intermediate_date_format=Column(String(20))
   
    # SFTP/Log specific fields for intermediate
    intermediate_hostname = Column(String(200))
    intermediate_path = Column(String(500))
    intermediate_sftp_username = Column(String(100))
    intermediate_sftp_password = Column(Text)  # Encrypted
    intermediate_file_naming_convention = Column(String(500))
    intermediate_extraction_pattern = Column(String(500))
    intermediate_data_split=Column(String(10))
    intermediate_data_fileName=Column(Integer)
    intermediate_stats_pattern=Column(Integer)
    intermediate_date_format=Column(String(20))
    
   
    # Target System
    target_name = Column(String(200), nullable=False)
    target_system_type = Column(Enum(SystemType), nullable=False)
    target_connection_string = Column(Text)  # Encrypted
    target_username = Column(String(100))
    target_password = Column(Text)  # Encrypted
    target_sql_query = Column(Text)
    target_filename_column = Column(String(100))
    target_primary_stats_column = Column(String(100))
    target_secondary_stats_column = Column(String(100))
    target_date_format=Column(String(20))
   
    # SFTP/Log specific fields for target
    target_hostname = Column(String(200))
    target_path = Column(String(500))
    target_sftp_username = Column(String(100))
    target_sftp_password = Column(Text)  # Encrypted
    target_file_naming_convention = Column(String(500))
    target_extraction_pattern = Column(String(500))
    target_data_split=Column(String(10))
    target_data_fileName=Column(Integer)
    target_stats_pattern=Column(Integer)
    target_date_format=Column(String(20))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    is_active = Column(Boolean, default=True)

    tower = relationship('FileMonitorTower', back_populates='reports')

    def __repr__(self):
        return f'<FileMonitorReport {self.application_name} - {self.flow_type.value}>'


class FileMonitorAlertLog(Base):
    """One row per (report, alert date) pending-file email actually sent.

    Exists purely to make the daily alert sweep idempotent: a second sweep on
    the same day (service restart, dual scheduler) finds the row and skips the
    email instead of re-spamming the distribution list.
    """
    __tablename__ = 'file_monitor_alert_log'

    id = Column(Integer, primary_key=True)
    # Declared FK to the parent report for referential clarity. No ondelete
    # cascade in the schema: SQLite does not enforce FKs unless the pragma is
    # on, so the purge is done explicitly in application code instead
    # (routes.purge_report_rows deletes these rows and the report row in one
    # transaction). Disabling a report leaves both intact. index=True (kept)
    # backs the per-report "already sent today?" lookup the daily sweep runs.
    report_id = Column(Integer, ForeignKey('file_monitor_reports.id'),
                       nullable=False, index=True)
    alert_date = Column(String(10), nullable=False)   # YYYY-MM-DD local date the sweep ran for
    pending_count = Column(Integer, default=0)
    recipients = Column(String(500))
    sent_at = Column(DateTime, default=func.now())

    def __repr__(self):
        return f'<FileMonitorAlertLog report={self.report_id} {self.alert_date}>'


# ===========================================================================
# Flow Catalogue - reference data parsed from the DTN (MHHS) Web Data
# Specification HTML kept under data/DTN_Flow. These tables are a read-only
# catalogue: every reload (file upload or re-parse) deletes all rows and
# re-inserts from the spec, so nothing here is ever user-edited in place.
# ===========================================================================

class DtnFlowMessage(Base):
    """One market message flow (e.g. D0001 / IF-026) from the specification.

    Repeating child collections (scenario variants, data items, message
    structure, key fields) are stored as JSON text - the catalogue is
    replaced wholesale on every load, so relational child tables would only
    add churn without enabling any extra queries.
    """
    __tablename__ = 'dtn_flow_messages'

    id = Column(Integer, primary_key=True)
    mm_ref = Column(String(20), unique=True, nullable=False, index=True)   # MM00001
    catalogue_ref = Column(String(100), index=True)                        # D0001, IF-026, ...
    name = Column(String(300))
    description = Column(Text)
    version = Column(String(20))
    notes = Column(Text)

    # Counts denormalised so the search/list page never parses the JSON blobs.
    sv_count = Column(Integer, default=0)
    item_count = Column(Integer, default=0)
    key_field_count = Column(Integer, default=0)

    scenario_variants = Column(Text)   # JSON: [{sv_ref, name, source, target, owner, api_route, api_method}]
    data_items = Column(Text)          # JSON: [{di_ref, catalogue_ref, name}]
    structures = Column(Text)          # JSON: [{sv_refs: [...], rows: [{group_id, range, level, marker, di_ref, ...}]}]
    key_fields = Column(Text)          # JSON: [{di_ref, name}] - mandatory items

    def __repr__(self):
        return f'<DtnFlowMessage {self.catalogue_ref} ({self.mm_ref})>'


class DtnFlowDataItem(Base):
    """One data item (field) definition, e.g. DI50003 - MPAN Core."""
    __tablename__ = 'dtn_flow_data_items'

    id = Column(Integer, primary_key=True)
    di_ref = Column(String(20), unique=True, nullable=False, index=True)   # DI50003
    catalogue_ref = Column(String(100), index=True)                        # J0003 / DI-063
    name = Column(String(300))
    description = Column(Text)
    owner = Column(String(200))
    logical_length = Column(String(20))
    decimal_length = Column(String(20))
    physical_length = Column(String(20))
    data_type = Column(String(100))
    data_type_format = Column(String(100))
    notes = Column(Text)
    classification = Column(String(100))      # MHHS Data Classification
    nullable = Column(String(100))            # MHHS Nullable
    mhhs_datatype = Column(String(50))
    yaml_name = Column(String(200))
    enumeration = Column(Text)                # JSON: [{value, description}]
    used_in = Column(Text)                    # JSON: [mm_ref, ...]

    def __repr__(self):
        return f'<DtnFlowDataItem {self.di_ref} {self.name}>'


class DtnFlowCatalogueMeta(Base):
    """Single row describing the currently loaded specification file."""
    __tablename__ = 'dtn_flow_catalogue_meta'

    id = Column(Integer, primary_key=True)
    source_file = Column(String(300))
    spec_title = Column(String(300))
    version = Column(String(20))
    message_count = Column(Integer, default=0)
    item_count = Column(Integer, default=0)
    loaded_at = Column(DateTime, default=func.now())
    loaded_by = Column(String(100))
