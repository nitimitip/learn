"""
alerts.py - File Monitor pending-file email alert.

The failure mode this module exists for: an application generates files with
the SAME name, one gets silently replaced during transfer, and nobody notices
for six months. The dashboard already surfaces pending / duplicate files when
someone LOOKS at it - this sweep makes sure someone is TOLD without looking.

Sweep logic (run_pending_file_alerts, fired daily by scheduler.py):

  * For every active report with alerting enabled and recipients configured,
    probe the live systems over a short trailing window ending YESTERDAY.
    Recipients are the report's own list PLUS the notification addresses of
    its owning Application Tower, so a tower-wide distribution list is
    maintained in one place instead of on every report.
    Today's files are deliberately out of scope - a file created an hour ago
    that hasn't landed yet is normal latency, not an incident.
  * Files from previous days still pending at the source (or stuck at the
    intermediate), plus duplicate groups where downstream received fewer
    copies than the source recorded, trigger one email per report per day.
  * FileMonitorAlertLog makes the sweep idempotent: a second run on the same
    day (service restart, dual scheduler) skips reports already alerted.

Probes reuse get_file_flow_data - the exact same read-only, timeout-bounded
path the dashboard uses - so alerting adds no new load pattern and the window
is kept small (ALERT_LOOKBACK_DAYS, default 3) to stay cheap on production
systems.

Email follows the shared NPG Outlook-safe rules: nested-<table> layout, solid
colours, real <td> accent bars, plain-text alternative part.
"""

from __future__ import annotations

import logging
import os
import smtplib
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from html import escape as _esc

import pandas as pd
from sqlalchemy.orm import joinedload

from database import get_db_session
from email_theme import hero_rows, footer_rows
from .models import FileMonitorReport, FileMonitorAlertLog
from .utils import UNKNOWN_DATE_KEY, _parse_sent_date, get_file_flow_data

logger = logging.getLogger(__name__)

# SMTP (shared convention with the rest of the app)
_SMTP_SERVER = os.environ.get('SMTP_SERVER', 'mail1.northernpowergrid.com')
_SMTP_PORT = int(os.environ.get('SMTP_PORT', '25'))
_EMAIL_FROM = os.environ.get('EMAIL_FROM', 'NPgAppAssist@northernpowergrid.com')

# How many days back (ending yesterday) each alert probe looks. Small on
# purpose: the sweep runs daily, so anything older was already reported on a
# previous day, and a short window bounds the load on the monitored systems.
ALERT_LOOKBACK_DAYS = int(os.environ.get('FM_ALERT_LOOKBACK_DAYS', '3'))

# Cap on how many pending files are listed in the email body. The full list
# lives on the dashboard; the email is a wake-up call, not a report.
_MAX_ROWS_IN_EMAIL = 30

# NPG palette - imported from the shared email theme so a colour is
# defined ONCE for the whole application (email_theme.py). The private
# aliases keep this module's f-strings unchanged.
from email_theme import (                             # noqa: E402
    NPG_RED as _NPG_RED, NPG_LIGHT as _NPG_LIGHT, NPG_BORDER as _NPG_BORDER,
    NPG_TEXT as _NPG_TEXT, NPG_TEXT_MUTED as _NPG_TEXT_MUTED,
    CHIP_BG as _CHIP_BG,
    FONT as _FONT,
)


def _merge_recipients(*raws):
    """Several address lists -> one deduped list, first occurrence wins.

    Used to fold the owning tower's notification addresses in with the
    report's own recipients.
    """
    out, seen = [], set()
    for raw in raws:
        for addr in _parse_recipients(raw):
            if addr.lower() not in seen:
                seen.add(addr.lower())
                out.append(addr)
    return out


def _parse_recipients(raw):
    """Comma/semicolon separated address list -> deduped list, order kept."""
    if not raw:
        return []
    out, seen = [], set()
    for part in str(raw).replace(';', ',').split(','):
        addr = part.strip()
        if not addr or '@' not in addr:
            continue
        # A CR or LF in an address would be written verbatim into the To:
        # header by Python's compat32 policy, letting whoever edits a report's
        # alert list inject Bcc/Reply-To or a second message body.
        if '\r' in addr or '\n' in addr:
            logger.error('FM alert: dropping recipient containing a line break.')
            continue
        if addr.lower() in seen:
            continue
        seen.add(addr.lower())
        out.append(addr)
    return out


def _grace_days(report):
    """How many days a file may stay pending before the alert flags it.

    Default 1 = anything from yesterday or older alerts. Applications whose
    downstream batch runs once a day (possibly AFTER the morning sweep) set 2
    so a file received throughout yesterday gets a full day to be processed
    before it counts as stuck. Never below 1 - today's files are always in
    normal latency."""
    try:
        return max(1, int(getattr(report, 'alert_grace_days', 1) or 1))
    except (TypeError, ValueError):
        return 1


def _collect_previous_day_pending(report, today):
    """Probe *report* and return (pending_df, duplicate_df) for files older
    than the report's grace window.

    pending_df rows carry an extra 'stage' column ('source' / 'intermediate')
    saying where the file is stuck. Raises on probe failure - the caller
    logs and moves to the next report; a dead connection must not look like
    "no pending files".

    Cyclic-processing false positives are handled by two mechanisms:
      * the probe window ends grace_days back, and the downstream read
        already extends one day past the window end (get_system_data), so a
        23:00 file processed at 00:30 next day is seen as PROCESSED;
      * once-a-day downstream jobs that run after the morning sweep are
        covered by setting alert_grace_days=2 on that report.
    Duplicate-copy loss is reported for the whole probed window regardless -
    a dropped copy is historical fact, not latency.
    """
    grace = _grace_days(report)
    end_date = (today - timedelta(days=grace)).strftime('%Y-%m-%d')
    start_date = (today - timedelta(days=grace + ALERT_LOOKBACK_DAYS - 1)).strftime('%Y-%m-%d')

    metrics, dataframes, _plots = get_file_flow_data(
        report,
        report.source_date_format,
        start_date, end_date,
        report.intermediate_date_format,
        report.target_date_format,
    )

    # NO FALSE ALERTS: if ANY configured system could not be read, every
    # pending/duplicate figure is suspect (an unreachable target makes every
    # source file look pending; an unreachable source looks like a clean
    # day). Refuse to alert; the sweep logs and skips this report.
    probe_errors = (metrics or {}).get('probe_errors') or {}
    if probe_errors:
        raise RuntimeError(
            'probe failed - ' + '; '.join(f'{k}: {v}' for k, v in probe_errors.items()))

    frames = []
    for stage, table in (('source', 'source_table'), ('intermediate', 'intermediate_table')):
        pend = (dataframes.get(table) or {}).get('pending')
        if pend is None or pend.empty:
            continue
        pend = pend.copy()
        pend['stage'] = stage
        frames.append(pend)

    if frames:
        pending = pd.concat(frames, ignore_index=True)
        # Keep files older than the grace window only. The probe window
        # already ends grace_days back, but SENT_DATE comes from the
        # monitored system and is not guaranteed to respect the query
        # window - filter defensively.
        if 'SENT_DATE' in pending.columns:
            cutoff = (today - timedelta(days=grace)).date()
            # Each stage stamps SENT_DATE in its OWN configured format, so the
            # rows of each stage are parsed with that system's format. Guessing
            # here sent whole stages down the "unparsed" branch, where every
            # row is kept - so files that were in fact inside the grace window
            # were still alerted on.
            sent_date = pd.Series(index=pending.index, dtype='object')
            for stage, fmt in (('source', report.source_date_format),
                               ('intermediate', report.intermediate_date_format)):
                rows = pending['stage'] == stage
                if rows.any():
                    sent_date.loc[rows] = _parse_sent_date(
                        pending.loc[rows, 'SENT_DATE'], fmt).dt.date
            readable = sent_date.notna()
            older = pd.Series(False, index=pending.index)
            older.loc[readable] = sent_date[readable].map(lambda d: d <= cutoff)
            # An unreadable date is kept: a pending file must never be dropped
            # from an alert just because its date could not be parsed.
            pending = pending[~readable | older]
    else:
        pending = pd.DataFrame(columns=['application_file', 'SENT_DATE', 'stage'])

    dup = dataframes.get('same_name_transfers')
    if dup is not None and not dup.empty and 'missing_in_transit' in dup.columns:
        dup = dup[dup['missing_in_transit']].copy()
    else:
        dup = pd.DataFrame()

    return pending, dup


def run_pending_file_alerts(now=None):
    """Daily sweep entry point. Returns the number of alert emails sent."""
    now = now or datetime.now()
    today_str = now.strftime('%Y-%m-%d')
    sent_count = 0

    db_session = get_db_session()
    try:
        reports = (db_session.query(FileMonitorReport)
                   .options(joinedload(FileMonitorReport.tower))
                   .filter_by(is_active=True, alert_enabled=True)
                   .order_by(FileMonitorReport.application_name)
                   .all())
        # Read the tower addresses HERE, while the session is open. The report
        # objects outlive it below, and touching a relationship on a detached
        # instance would raise instead of just sending fewer emails.
        tower_emails = {r.id: (r.tower.email_addresses if r.tower else None)
                        for r in reports}
    finally:
        db_session.close()

    for report in reports:
        recipients = _merge_recipients(report.alert_emails,
                                       tower_emails.get(report.id))
        if not recipients:
            logger.info('FM alert: report %s (%s) has alerting on but no valid '
                        'recipients on the report or its tower - skipped.',
                        report.id, report.application_name)
            continue

        # Idempotency check FIRST, so a re-run doesn't even re-probe.
        db_session = get_db_session()
        try:
            already = (db_session.query(FileMonitorAlertLog)
                       .filter_by(report_id=report.id, alert_date=today_str)
                       .first())
        finally:
            db_session.close()
        if already:
            logger.info('FM alert: report %s already alerted for %s - skipped.',
                        report.id, today_str)
            continue

        try:
            pending, duplicates = _collect_previous_day_pending(report, now)
        except Exception:
            logger.exception('FM alert: probe failed for report %s (%s) - '
                             'skipping this report, sweep continues.',
                             report.id, report.application_name)
            continue

        if pending.empty and duplicates.empty:
            logger.info('FM alert: report %s (%s) clean - nothing pending from '
                        'previous days.', report.id, report.application_name)
            continue

        if _send_alert_email(report, pending, duplicates, recipients, now):
            sent_count += 1
            db_session = get_db_session()
            try:
                db_session.add(FileMonitorAlertLog(
                    report_id=report.id,
                    alert_date=today_str,
                    pending_count=int(len(pending)),
                    recipients=','.join(recipients)[:500],
                ))
                db_session.commit()
            except Exception:
                db_session.rollback()
                logger.exception('FM alert: could not write alert log for report %s.',
                                 report.id)
            finally:
                db_session.close()

    logger.info('FM alert sweep complete - %d email(s) sent.', sent_count)
    return sent_count


# ---------------------------------------------------------------------------
# Email rendering
# ---------------------------------------------------------------------------

def _send_alert_email(report, pending, duplicates, recipients, now):
    """Build and send the alert. Returns True on success; errors are logged
    and swallowed so one bad SMTP call can't abort the whole sweep."""
    n_pend = len(pending)
    n_dup = len(duplicates)
    try:
        msg = MIMEMultipart('alternative')
        bits = []
        if n_pend:
            bits.append(f'{n_pend} file(s) pending')
        if n_dup:
            bits.append(f'{n_dup} duplicate group(s) lost copies')
        msg['Subject'] = (f"[File Monitor] {report.application_name} "
                          f"({report.flow_type.value}) - {', '.join(bits)} "
                          f"from previous days")
        msg['From'] = _EMAIL_FROM
        msg['To'] = ', '.join(recipients)
        msg['X-Priority'] = '2'

        msg.attach(MIMEText(_build_text(report, pending, duplicates, now), 'plain', 'utf-8'))
        msg.attach(MIMEText(_build_html(report, pending, duplicates, now), 'html', 'utf-8'))

        with smtplib.SMTP(_SMTP_SERVER, _SMTP_PORT, timeout=30) as server:
            server.send_message(msg)
        logger.info('FM alert sent for report %s (%s) to %s - %d pending, %d dup groups.',
                    report.id, report.application_name, recipients, n_pend, n_dup)
        return True
    except Exception:
        logger.exception('FM alert: failed to send email for report %s.', report.id)
        return False


def _sent_date_text(row, report):
    """One pending row's SENT_DATE as 'dd Mon yyyy'.

    Parsed with the format the row's STAGE was queried with; an unreadable
    value is shown verbatim rather than guessed at, so the email never states
    a date the monitored system did not.
    """
    raw = row.get('SENT_DATE', '')
    fmt = (report.intermediate_date_format
           if str(row.get('stage', '')) == 'intermediate'
           else report.source_date_format)
    parsed = _parse_sent_date(pd.Series([raw]), fmt).iloc[0]
    return str(raw) if pd.isna(parsed) else parsed.strftime('%d %b %Y')


def _dup_date_text(row):
    """A duplicate group's date, with the internal unknown-date key shown as a
    dash - the same way the dashboard renders it."""
    value = str(row.get('date', '?'))
    return '-' if value == UNKNOWN_DATE_KEY else value


def _build_text(report, pending, duplicates, now):
    lines = [
        f"File Monitor alert - {report.application_name} ({report.flow_type.value})",
        f"Generated {now.strftime('%d %b %Y %H:%M')}",
        "",
        f"Files from previous days still pending: {len(pending)}",
    ]
    for _, row in pending.head(_MAX_ROWS_IN_EMAIL).iterrows():
        lines.append(f"  - {row.get('application_file', '?')}  "
                     f"[{row.get('stage', 'source')}]  {_sent_date_text(row, report)}")
    if len(pending) > _MAX_ROWS_IN_EMAIL:
        lines.append(f"  ... and {len(pending) - _MAX_ROWS_IN_EMAIL} more (see dashboard).")
    if duplicates is not None and not duplicates.empty:
        lines.append("")
        lines.append(f"Duplicate-name groups with copies lost in transit: {len(duplicates)}")
        for _, row in duplicates.head(_MAX_ROWS_IN_EMAIL).iterrows():
            lines.append(f"  - {_dup_date_text(row)}  {row.get('file_name', '?')}  "
                         f"source={row.get('source_count', '?')} "
                         f"dropped={row.get('sftp_dropped_copies', '?')}")
    lines += ["", "Open the File Monitor dashboard for the full picture."]
    return '\n'.join(lines)


def _badge(text):
    return (f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
            f'style="display:inline-table;"><tr><td bgcolor="{_CHIP_BG}" '
            f'style="background-color:{_CHIP_BG};color:#FFFFFF;font-family:Arial,'
            f'sans-serif;font-size:11px;font-weight:bold;padding:4px 10px;'
            f'mso-line-height-rule:exactly;line-height:14px;">{text}</td></tr></table>')


def _table_rows(headers, rows):
    """Simple bordered data table, Outlook-safe."""
    head = ''.join(
        f'<td style="padding:8px 10px;font-family:{_FONT};font-size:11px;'
        f'font-weight:bold;color:{_NPG_TEXT_MUTED};border-bottom:1px solid {_NPG_BORDER};'
        f'text-align:left;">{h}</td>' for h in headers)
    body = ''
    for r in rows:
        body += '<tr>' + ''.join(
            f'<td style="padding:7px 10px;font-family:{_FONT};font-size:12px;'
            f'color:{_NPG_TEXT};border-bottom:1px solid {_NPG_LIGHT};">{c}</td>'
            for c in r) + '</tr>'
    return (f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
            f'width="100%"><tr>{head}</tr>{body}</table>')


def _build_html(report, pending, duplicates, now):
    n_pend, n_dup = len(pending), len(duplicates)

    pend_rows = []
    for _, row in pending.head(_MAX_ROWS_IN_EMAIL).iterrows():
        sent = _esc(_sent_date_text(row, report))
        pend_rows.append((_esc(str(row.get('application_file', '?'))),
                          _esc(str(row.get('stage', 'source')).capitalize()),
                          sent))
    more_note = ''
    if n_pend > _MAX_ROWS_IN_EMAIL:
        more_note = (f'<tr><td style="padding:8px 0;font-family:{_FONT};'
                     f'font-size:12px;color:{_NPG_TEXT_MUTED};">&hellip; and '
                     f'{n_pend - _MAX_ROWS_IN_EMAIL} more - see the dashboard for the '
                     f'full list.</td></tr>')

    dup_section = ''
    if n_dup:
        dup_rows = [(_esc(_dup_date_text(r)), _esc(str(r.get('file_name', '?'))),
                     str(r.get('source_count', '?')), str(r.get('sftp_dropped_copies', '?')))
                    for _, r in duplicates.head(_MAX_ROWS_IN_EMAIL).iterrows()]
        dup_section = f"""
      <tr><td class="px-32" style="padding:22px 32px 6px;">
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"
               bgcolor="#FEF2F2" style="background-color:#FEF2F2;border:1px solid #FECACA;border-collapse:separate;border-spacing:0;border-radius:10px;">
          <tr>
            <td style="padding:12px 16px;font-family:{_FONT};font-size:13px;color:#991B1B;
                       mso-line-height-rule:exactly;line-height:19px;">
              <strong>{n_dup} duplicate-name group(s)</strong> forwarded FEWER copies than the
              source recorded - at least one file was silently overwritten or dropped in transit.
              This is the exact failure mode this monitor exists to catch; treat it as data loss
              until proven otherwise.
            </td>
          </tr>
        </table>
      </td></tr>
      <tr><td class="px-32" style="padding:10px 32px 4px;">
        {_table_rows(('DATE', 'FILE NAME', 'AT SOURCE', 'COPIES LOST'), dup_rows)}
      </td></tr>"""

    pend_section = ''
    if n_pend:
        pend_section = f"""
      <tr><td class="px-32" style="padding:22px 32px 6px;">
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"
               bgcolor="#FFFBEB" style="background-color:#FFFBEB;border:1px solid #FDE68A;border-collapse:separate;border-spacing:0;border-radius:10px;">
          <tr>
            <td style="padding:12px 16px;font-family:{_FONT};font-size:13px;color:#92400E;
                       mso-line-height-rule:exactly;line-height:19px;">
              <strong>{n_pend} file(s) older than this report's {_grace_days(report)}-day grace
              window</strong> have not reached the next system - they should have completed
              transfer by now.
            </td>
          </tr>
        </table>
      </td></tr>
      <tr><td class="px-32" style="padding:10px 32px 4px;">
        {_table_rows(('FILE NAME', 'STUCK AT', 'FILE DATE'), pend_rows)}
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">{more_note}</table>
      </td></tr>"""

    hero = hero_rows(
        'NPG APP ASSIST &middot; FILE MONITOR ALERT',
        _esc(report.application_name),
        [_badge(f'{report.flow_type.value.upper()} FLOW'),
         _badge(now.strftime('%d %b %Y').upper())])
    footer = footer_rows('File Monitor')

    return f"""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>File Monitor alert &mdash; {_esc(report.application_name)}</title>
  <!--[if mso]>
  <xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch><o:AllowPNG/></o:OfficeDocumentSettings></xml>
  <style type="text/css">table {{border-collapse:collapse;}} td {{mso-line-height-rule:exactly;}}</style>
  <![endif]-->
  <style type="text/css">
    body, table, td {{ -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }}
    table {{ border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }}
    a {{ color:{_NPG_RED}; text-decoration:none; }}
    @media only screen and (max-width:620px) {{
      .container {{ width:100% !important; }}
      .px-32 {{ padding-left:18px !important; padding-right:18px !important; }}
    }}
  </style>
</head>
<body style="margin:0;padding:0;background-color:{_NPG_LIGHT};font-family:{_FONT};">
<div style="display:none;font-size:1px;color:{_NPG_LIGHT};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
{_esc(report.application_name)}: {n_pend} previous-day file(s) pending{', ' + str(n_dup) + ' duplicate group(s) lost copies' if n_dup else ''}
</div>

<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="{_NPG_LIGHT}" style="background-color:{_NPG_LIGHT};">
  <tr><td align="center" style="padding:34px 16px 40px 16px;">
    <!--[if mso]><table role="presentation" align="center" cellpadding="0" cellspacing="0" border="0" width="600"><tr><td><![endif]-->
    <table role="presentation" class="container" cellpadding="0" cellspacing="0" border="0" width="600"
           style="width:600px;max-width:600px;background-color:#FFFFFF;border:1px solid {_NPG_BORDER};border-bottom-color:#C6D0DE;border-collapse:separate;border-spacing:0;border-radius:14px;">

      {hero}
      {dup_section}
      {pend_section}

      <tr><td class="px-32" style="padding:18px 32px 26px;font-family:{_FONT};font-size:12px;
                 color:{_NPG_TEXT_MUTED};mso-line-height-rule:exactly;line-height:18px;">
        Checked window: {ALERT_LOOKBACK_DAYS} day(s) ending {_grace_days(report)} day(s) ago
        (this report's grace period). Files newer than the grace window are never alerted on -
        normal transfer latency applies. Open the File Monitor dashboard for the complete,
        searchable list and the duplicate-file breakdown.
      </td></tr>

      {footer}
    </table>
    <!--[if mso]></td></tr></table><![endif]-->
  </td></tr>
</table>
</body>
</html>"""
