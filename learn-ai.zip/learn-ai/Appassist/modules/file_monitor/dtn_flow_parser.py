"""
dtn_flow_parser.py - parser/loader for the DTN (MHHS) "Web Data Specification"
HTML published at mhhsprogramme.co.uk.

The document is a single machine-generated HTML file (~12 MB) with three parts:

  1. An index of Market Messages (MM00001 ...) with their Local Catalogue
     References (D0001, IF-026, MHHS-REP-003A, ...).
  2. Per-message detail: an information table, Scenario Variants
     (source -> target routing), the Data Items used, and a Message Structure
     table per Scenario Variant (groups, repetition ranges, optionality).
  3. Per-data-item detail: type/length/classification, an optional
     enumeration of valid values, and the list of messages that use it.

parse_spec() walks the document in order with a small state machine keyed on
the h1/h2/h3/h4 headings, and load_spec_to_db() replaces the catalogue tables
with the parsed content (old rows are deleted first, per the upload contract).
"""

import json
import logging
import os
import re

from lxml import html as lxml_html

from .models import DtnFlowMessage, DtnFlowDataItem, DtnFlowCatalogueMeta

logger = logging.getLogger(__name__)

# data/DTN_Flow at the project root (this file lives in modules/file_monitor/)
DTN_FLOW_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    'data', 'DTN_Flow',
)

# Optionality markers used in the L1..L8 columns of a structure table.
OPTIONALITY_LABELS = {
    '1': 'Mandatory',
    'O': 'Optional',
    'C': 'Conditional',
    'G': 'Group',
    'N': 'Not used',
}

_MM_INFO_FIELDS = {
    'mm description': 'description',
    'local catalogue reference': 'catalogue_ref',
    'version': 'version',
    'notes': 'notes',
}

_DI_INFO_FIELDS = {
    'item description': 'description',
    'local catalogue reference': 'catalogue_ref',
    'data item owner': 'owner',
    'logical length': 'logical_length',
    'decimal length': 'decimal_length',
    'physical length': 'physical_length',
    'data type': 'data_type',
    'data type format': 'data_type_format',
    'data item notes': 'notes',
    'mhhs data classification': 'classification',
    'mhhs nullable': 'nullable',
    'mhhs datatype': 'mhhs_datatype',
    'yaml name': 'yaml_name',
}


def find_spec_file():
    """Return the newest .html spec file under data/DTN_Flow, or None."""
    if not os.path.isdir(DTN_FLOW_DIR):
        return None
    candidates = [
        os.path.join(DTN_FLOW_DIR, f)
        for f in os.listdir(DTN_FLOW_DIR)
        if f.lower().endswith(('.html', '.htm'))
    ]
    if not candidates:
        return None
    return max(candidates, key=os.path.getmtime)


def _txt(el):
    """Collapsed text content of an element."""
    return ' '.join(el.text_content().split())


def _info_table(table, mapping, target):
    """Read a label/value table (<b>Label</b> | value) into target via mapping."""
    for tr in table.findall('.//tr'):
        tds = tr.findall('td')
        if len(tds) < 2:
            continue
        label = _txt(tds[0]).lower().strip()
        if label in mapping:
            target[mapping[label]] = _txt(tds[1])


def _structure_row(tds):
    """One row of a Message Structure table (15 cells, L1..L8 in 4..11)."""
    marker, level = '', 0
    for idx in range(8):
        v = _txt(tds[4 + idx])
        if v:
            marker, level = v, idx + 1
            break
    item_cell = tds[12]
    di_ref = ''
    link = item_cell.find('.//a')
    if link is not None:
        m = re.search(r'#(DI\d+)\s*$', link.get('href', ''))
        if m:
            di_ref = m.group(1)
    return {
        'group_id': _txt(tds[0]),
        'group_desc': _txt(tds[1]),
        'range': _txt(tds[2]),
        'condition': _txt(tds[3]),
        'level': level,
        'marker': marker,
        'di_ref': di_ref,
        'item_name': _txt(item_cell),
        'rule': _txt(tds[13]),
        'alt_name': _txt(tds[14]),
    }


def parse_spec(path):
    """Parse the spec HTML into {'title', 'version', 'messages', 'data_items'}."""
    logger.info('Parsing DTN flow specification: %s', path)
    with open(path, 'rb') as f:
        raw = f.read()
    # The published file declares charset=windows-1252.
    text = raw.decode('windows-1252', errors='replace')
    doc = lxml_html.fromstring(text)

    title_el = doc.find('.//title')
    spec_title = _txt(title_el) if title_el is not None else os.path.basename(path)
    m = re.search(r'(\d+(?:\.\d+)+)', spec_title)
    version = m.group(1) if m else ''
    # Pre-release exports (e.g. 3.5.0) carry only "Web Data Specification" in
    # the <title>, so fall back to a dotted version in the file name.
    if not version:
        fm = re.search(r'(\d+(?:\.\d+)+)', os.path.basename(path))
        version = fm.group(1) if fm else ''

    messages, items = {}, {}
    current, kind, section, current_sv = None, None, None, None

    for el in doc.iter('h1', 'h2', 'h3', 'h4', 'table'):
        tag = el.tag
        if tag == 'h1':
            # Index sections (Market Messages / Data Items lists) - their
            # tables must not be consumed by the previous detail block.
            current, kind, section, current_sv = None, None, None, None
        elif tag == 'h2':
            hid = el.get('id') or ''
            heading = _txt(el)
            name = heading.split(' - ', 1)[1].strip() if ' - ' in heading else heading
            if re.fullmatch(r'MM\d+', hid):
                current = messages.setdefault(hid, {
                    'mm_ref': hid, 'name': name, 'catalogue_ref': '',
                    'description': '', 'version': '', 'notes': '',
                    'scenario_variants': [], 'data_items': [], 'structures': [],
                })
                kind = 'mm'
            elif re.fullmatch(r'DI\d+', hid):
                current = items.setdefault(hid, {
                    'di_ref': hid, 'name': name,
                    'enumeration': [], 'used_in': [],
                })
                kind = 'di'
            else:
                current, kind = None, None
            section, current_sv = None, None
        elif tag == 'h3':
            section = _txt(el).lower()
            current_sv = None
        elif tag == 'h4':
            # A structure block header. In the 1.4 spec each Scenario Variant
            # had its own "SVxxxx ..." h4; the 3.5.0 spec has a single
            # per-flow "MMxxxxx - <name> - Message Structure" h4 instead. Only
            # treat the h4 as a structure header when we are inside the
            # structure section (h3 contains "structure" in both formats).
            if (kind == 'mm' and current is not None
                    and section and 'structure' in section):
                svm = re.search(r'\b(SV\d+)\b', _txt(el))
                # A non-SV header means one layout shared by every variant;
                # label it with the flow's actual SV refs (filled in below).
                sv_ref = svm.group(1) if svm else '*ALL*'
                current_sv = {'sv_ref': sv_ref, 'rows': []}
                current['structures'].append(current_sv)
        elif tag == 'table':
            if current is None or not section:
                continue
            if kind == 'mm':
                if 'market message information' in section:
                    _info_table(el, _MM_INFO_FIELDS, current)
                elif 'scenario variants' in section:
                    for tr in el.findall('.//tr'):
                        tds = tr.findall('td')
                        if len(tds) >= 7:
                            current['scenario_variants'].append({
                                'sv_ref': _txt(tds[0]), 'name': _txt(tds[1]),
                                'source': _txt(tds[2]), 'target': _txt(tds[3]),
                                'owner': _txt(tds[4]), 'api_route': _txt(tds[5]),
                                'api_method': _txt(tds[6]),
                            })
                elif 'data items' in section:
                    for tr in el.findall('.//tr'):
                        tds = tr.findall('td')
                        if len(tds) >= 3:
                            current['data_items'].append({
                                'di_ref': _txt(tds[0]),
                                'catalogue_ref': _txt(tds[1]),
                                'name': _txt(tds[2]),
                            })
                elif 'structure' in section and current_sv is not None:
                    for tr in el.findall('.//tr'):
                        tds = tr.findall('td')
                        if len(tds) >= 15:
                            row = _structure_row(tds)
                            if row['group_id'] or row['item_name'] or row['marker']:
                                current_sv['rows'].append(row)
            elif kind == 'di':
                if 'data item information' in section:
                    _info_table(el, _DI_INFO_FIELDS, current)
                elif 'data item enumeration' in section:
                    for tr in el.findall('.//tr'):
                        tds = tr.findall('td')
                        if len(tds) >= 2:
                            current['enumeration'].append({
                                'value': _txt(tds[0]),
                                'description': _txt(tds[1]),
                            })
                elif 'in market messages' in section:
                    for tr in el.findall('.//tr'):
                        tds = tr.findall('td')
                        if len(tds) >= 1 and _txt(tds[0]):
                            current['used_in'].append(_txt(tds[0]))

    for msg in messages.values():
        all_svs = [sv['sv_ref'] for sv in msg['scenario_variants'] if sv.get('sv_ref')]
        msg['structures'] = _dedupe_structures(msg['structures'], all_svs)
        msg['key_fields'] = _derive_key_fields(msg['structures'])

    logger.info('Parsed %d market messages and %d data items (spec %s)',
                len(messages), len(items), version or 'unknown')
    return {
        'title': spec_title,
        'version': version,
        'messages': list(messages.values()),
        'data_items': list(items.values()),
    }


def _dedupe_structures(structures, all_svs=None):
    """Scenario variants almost always share an identical message structure -
    collapse duplicates so each unique layout is stored once with the list of
    variants that use it.

    `all_svs` is the flow's full list of Scenario Variant refs. A structure
    parsed from a single per-flow header (the 3.5.0 format, marked '*ALL*')
    applies to every variant, so it is expanded to that list."""
    unique = []
    seen = {}
    for sv in structures:
        if sv['sv_ref'] == '*ALL*':
            refs = list(all_svs) if all_svs else ['All variants']
        else:
            refs = [sv['sv_ref']]
        key = json.dumps(sv['rows'], sort_keys=True)
        if key in seen:
            for r in refs:
                if r not in seen[key]['sv_refs']:
                    seen[key]['sv_refs'].append(r)
        else:
            entry = {'sv_refs': refs, 'rows': sv['rows']}
            seen[key] = entry
            unique.append(entry)
    return unique


def _derive_key_fields(structures):
    """Key fields = data items marked mandatory ('1') anywhere in the
    message structure. These are the fields every instance of the flow must
    carry, so they are what an analyst keys on when reading a file."""
    out, seen = [], set()
    for struct in structures:
        for row in struct['rows']:
            if row['marker'] == '1' and row['di_ref'] and row['di_ref'] not in seen:
                seen.add(row['di_ref'])
                out.append({'di_ref': row['di_ref'], 'name': row['item_name']})
    return out


def _message_fields(msg):
    """Column values for a DtnFlowMessage from a parsed message dict."""
    return dict(
        catalogue_ref=msg['catalogue_ref'],
        name=msg['name'],
        description=msg['description'],
        version=msg['version'],
        notes=msg['notes'],
        sv_count=len(msg['scenario_variants']),
        item_count=len(msg['data_items']),
        key_field_count=len(msg['key_fields']),
        scenario_variants=json.dumps(msg['scenario_variants']),
        data_items=json.dumps(msg['data_items']),
        structures=json.dumps(msg['structures']),
        key_fields=json.dumps(msg['key_fields']),
    )


def _item_fields(it):
    """Column values for a DtnFlowDataItem from a parsed data-item dict."""
    return dict(
        catalogue_ref=it.get('catalogue_ref', ''),
        name=it['name'],
        description=it.get('description', ''),
        owner=it.get('owner', ''),
        logical_length=it.get('logical_length', ''),
        decimal_length=it.get('decimal_length', ''),
        physical_length=it.get('physical_length', ''),
        data_type=it.get('data_type', ''),
        data_type_format=it.get('data_type_format', ''),
        notes=it.get('notes', ''),
        classification=it.get('classification', ''),
        nullable=it.get('nullable', ''),
        mhhs_datatype=it.get('mhhs_datatype', ''),
        yaml_name=it.get('yaml_name', ''),
        enumeration=json.dumps(it['enumeration']),
        used_in=json.dumps(it['used_in']),
    )


# Accepted load modes (see load_spec_to_db).
LOAD_MODES = ('refresh', 'update')


def load_spec_to_db(db_session, path, loaded_by=None, mode='refresh'):
    """Parse `path` and load its content into the flow catalogue tables.

    Two modes (the "Update Specification" toggle in the UI maps to these):

      * mode='refresh' (default) - TRUNCATE then reload. Every existing row is
        deleted first, so the uploaded spec fully supersedes the previous one.
        Flows that are absent from the new file disappear from the catalogue.

      * mode='update' - UPSERT, no truncate. Flows/items already present
        (matched on mm_ref / di_ref) are updated in place, and any not
        previously present are added. Nothing is deleted, so flows that exist
        only in the older spec are retained. This is how new flows from a
        later spec are merged in without losing the current catalogue.

    Commits on success, raises on failure (the caller rolls back).
    """
    if mode not in LOAD_MODES:
        raise ValueError(f"unknown load mode: {mode!r} (expected one of {LOAD_MODES})")

    parsed = parse_spec(path)

    if mode == 'refresh':
        db_session.query(DtnFlowMessage).delete()
        db_session.query(DtnFlowDataItem).delete()

    # Update mode: prefetch the existing catalogue keyed by ref so a spec
    # with thousands of rows costs two SELECTs, not one per row.
    existing_msgs = {}
    existing_items = {}
    if mode == 'update':
        existing_msgs = {m.mm_ref: m for m in db_session.query(DtnFlowMessage).all()}
        existing_items = {i.di_ref: i for i in db_session.query(DtnFlowDataItem).all()}

    msg_added = msg_updated = 0
    for msg in parsed['messages']:
        fields = _message_fields(msg)
        existing = existing_msgs.get(msg['mm_ref'])
        if existing:
            for attr, value in fields.items():
                setattr(existing, attr, value)
            msg_updated += 1
        else:
            new_msg = DtnFlowMessage(mm_ref=msg['mm_ref'], **fields)
            db_session.add(new_msg)
            if mode == 'update':
                # Track the add so a duplicate ref later in the same file
                # updates it instead of inserting twice (matches the old
                # per-row query behaviour under autoflush).
                existing_msgs[msg['mm_ref']] = new_msg
            msg_added += 1

    item_added = item_updated = 0
    for it in parsed['data_items']:
        fields = _item_fields(it)
        existing = existing_items.get(it['di_ref'])
        if existing:
            for attr, value in fields.items():
                setattr(existing, attr, value)
            item_updated += 1
        else:
            new_item = DtnFlowDataItem(di_ref=it['di_ref'], **fields)
            db_session.add(new_item)
            if mode == 'update':
                existing_items[it['di_ref']] = new_item
            item_added += 1

    # Flush so the meta counts reflect the true catalogue totals after an
    # update merge (not just the size of the file that was loaded this time).
    db_session.flush()
    total_messages = db_session.query(DtnFlowMessage).count()
    total_items = db_session.query(DtnFlowDataItem).count()

    # The meta table is a single descriptive row - always replace it with the
    # details of this load.
    db_session.query(DtnFlowCatalogueMeta).delete()
    db_session.add(DtnFlowCatalogueMeta(
        source_file=os.path.basename(path),
        spec_title=parsed['title'],
        version=parsed['version'],
        message_count=total_messages,
        item_count=total_items,
        loaded_by=loaded_by,
    ))

    db_session.commit()
    logger.info('Flow catalogue %s from %s by %s - flows +%d/~%d, items +%d/~%d '
                '(catalogue now %d flows, %d items)',
                mode, path, loaded_by or 'system',
                msg_added, msg_updated, item_added, item_updated,
                total_messages, total_items)
    return {
        'mode': mode,
        'message_count': total_messages,
        'item_count': total_items,
        'messages_added': msg_added,
        'messages_updated': msg_updated,
        'items_added': item_added,
        'items_updated': item_updated,
        'version': parsed['version'],
    }
