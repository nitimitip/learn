from flask import (
    Blueprint, render_template, request, redirect, url_for, flash, jsonify,
    Response,
)
# `col == sql_true()` rather than `col.is_(True)`: SQLAlchemy renders
# the latter as `col IS 1`, which SQLite accepts and SQL SERVER REJECTS
# - T-SQL allows IS only with NULL. Both compile `== true()` to `= 1`.
from sqlalchemy import func, or_, true as sql_true
from sqlalchemy.orm import joinedload
from werkzeug.utils import secure_filename
from auth import get_current_user, require_auth
from csrf_utils import csrf_protect
from database import get_db_session
from .models import (
    FileMonitorReport, FlowType, SystemType, FileMonitorAlertLog,
    FileMonitorTower, FileMonitorTowerMember,
    DtnFlowMessage, DtnFlowDataItem, DtnFlowCatalogueMeta,
)
from .utils import (
    test_connectivity, encrypt_password, decrypt_password, get_file_flow_data,
    get_file_flow_data_cached, invalidate_flow_cache, capped_view,
    resolve_table, paginate_table, filter_table, TABLE_PARTS,
    parse_exclusion_rules, parse_stats_config, parse_system_exclusions,
    parse_display_config,
)
from . import dtn_flow_parser
from models import User
from datetime import datetime, timedelta
import csv
import io
import json
import os
import logging
import re
import threading

# Create blueprint
file_monitor_bp = Blueprint('file_monitor', __name__, template_folder='templates')

# Hard cap on the dashboard date window. Viewing a dashboard RUNS the report -
# it queries the monitored databases and walks the SFTP logs live - so an
# unbounded range would let one page load place arbitrarily large load on
# production systems. Tower membership decides WHO may do that; this decides
# HOW MUCH they may ask for in one go: the maximum number of inclusive days a
# single view may request.
MAX_DATE_RANGE_DAYS = 15


def _stats_config_json(form, key_base):
    """Named-stat rows ({key_base}_stat_name / _stat_ref) -> JSON or None.

    'ref' is a column name for db systems, a split position for log systems.
    Rows without a ref are dropped; a blank name defaults to the ref.
    """
    names = form.getlist(f'{key_base}_stat_name')
    refs = form.getlist(f'{key_base}_stat_ref')
    entries = []
    for i, ref in enumerate(refs):
        ref = (ref or '').strip()
        if not ref:
            continue
        name = (names[i] if i < len(names) else '').strip() or ref
        entries.append({'name': name, 'ref': ref})
    return json.dumps(entries) if entries else None


def _display_config_json(form, key_base):
    """Records-to-display rows ({key_base}_disp_name / _disp_ref) -> JSON or
    None. Same shape as stats: display name + column name (db) / position (log)."""
    names = form.getlist(f'{key_base}_disp_name')
    refs = form.getlist(f'{key_base}_disp_ref')
    entries = []
    for i, ref in enumerate(refs):
        ref = (ref or '').strip()
        if not ref:
            continue
        name = (names[i] if i < len(names) else '').strip() or ref
        entries.append({'name': name, 'ref': ref})
    return json.dumps(entries) if entries else None


def _parse_grace_days(form):
    """Alert grace period from the form; clamped to >= 1, default 1."""
    try:
        return max(1, int(form.get('alert_grace_days', '1') or '1'))
    except (TypeError, ValueError):
        return 1


def _exclusion_config_json(form, key_base):
    """Per-system exclusion rows ({key_base}_excl_name / _excl_ref /
    _excl_values) -> JSON or None. Rows without values are dropped."""
    names = form.getlist(f'{key_base}_excl_name')
    refs = form.getlist(f'{key_base}_excl_ref')
    values = form.getlist(f'{key_base}_excl_values')
    entries = []
    for i, vals in enumerate(values):
        vals = (vals or '').strip()
        if not vals:
            continue
        entries.append({
            'name': (names[i] if i < len(names) else '').strip(),
            'ref': (refs[i] if i < len(refs) else '').strip(),
            'values': vals,
        })
    return json.dumps(entries) if entries else None


def _validate_system_config(report, system, flow_label=''):
    """Enforce the mandatory parts of one system's configuration.

    Every system must say WHERE the filename lives (column for db, split
    position for log) - without it, matching is meaningless - and must select
    at least one display field so the dashboard tables show exactly what the
    operator chose. Raises ValueError with an operator-readable message.
    """
    where = f"{flow_label + ' ' if flow_label else ''}{system} system"
    system_type = getattr(report, f'{system}_system_type', None)
    if system_type in (SystemType.ORACLE, SystemType.MSSQL):
        if not (getattr(report, f'{system}_filename_column', None) or '').strip():
            raise ValueError(f'{where}: Filename Column is required')
    elif system_type == SystemType.LOG:
        if getattr(report, f'{system}_data_fileName', None) in (None, ''):
            raise ValueError(f'{where}: File Name Position is required')
    if not getattr(report, f'{system}_display_config', None):
        raise ValueError(f'{where}: select at least one display field '
                         f'(Records to Display)')


def _apply_system_fields(report, form, flow_prefix, system, flow_label=''):
    """Populate one system's columns on *report* from the form section
    namespaced {flow_prefix}{system}_* (e.g. in__source_hostname).
    Raises ValueError when a mandatory field is missing."""
    def g(name, default=None):
        return form.get(f'{flow_prefix}{system}_{name}', default)

    system_type = SystemType(g('system_type'))
    setattr(report, f'{system}_system_type', system_type)
    setattr(report, f'{system}_name', g('name'))
    setattr(report, f'{system}_date_format', g('date_format'))

    if system_type in (SystemType.ORACLE, SystemType.MSSQL):
        setattr(report, f'{system}_connection_string', encrypt_password(g('connection_string', '')))
        setattr(report, f'{system}_username', g('username'))
        setattr(report, f'{system}_password', encrypt_password(g('password', '')))
        setattr(report, f'{system}_sql_query', g('sql_query'))
        setattr(report, f'{system}_filename_column', g('filename_column'))
    elif system_type == SystemType.LOG:
        setattr(report, f'{system}_hostname', g('hostname'))
        setattr(report, f'{system}_path', g('path'))
        setattr(report, f'{system}_sftp_username', g('sftp_username'))
        setattr(report, f'{system}_sftp_password', encrypt_password(g('sftp_password', '')))
        setattr(report, f'{system}_file_naming_convention', g('file_naming_convention'))
        setattr(report, f'{system}_extraction_pattern', g('extraction_pattern'))
        setattr(report, f'{system}_data_split', g('data_split'))
        setattr(report, f'{system}_data_fileName', g('data_fileName') or None)

    key_base = f'{flow_prefix}{system}'
    setattr(report, f'{system}_stats_config', _stats_config_json(form, key_base))
    setattr(report, f'{system}_exclusion_config', _exclusion_config_json(form, key_base))
    setattr(report, f'{system}_display_config', _display_config_json(form, key_base))

    _validate_system_config(report, system, flow_label)

# ---------------------------------------------------------------------------
# Tower access control
#
# Every monitored application belongs to an Application Tower. Administrators
# create the towers and add members; from then on a report can only be opened
# by that tower's members - and opening it means RUNNING it, because the
# dashboard probes the live source / intermediate / target systems on every
# view. Membership therefore gates execution, not just visibility.
#
# Reports created before towers existed have tower_id NULL. They form an
# "Unassigned" bucket only administrators can see, so an upgrade never hides a
# report from everybody without anyone noticing.
# ---------------------------------------------------------------------------

def _is_admin(user):
    return bool(user) and getattr(user, 'role', None) == 'admin'


def is_tower_member(user, tower_id, db_session):
    """True when *user* may view and execute this tower's reports.

    Administrators pass for every tower, including the Unassigned bucket
    (tower_id None), which by definition has no member list.
    """
    if _is_admin(user):
        return True
    if not user or tower_id is None:
        return False
    return db_session.query(FileMonitorTowerMember.id).filter_by(
        tower_id=tower_id, user_id=user.id).first() is not None


def _member_tower_ids(user, db_session):
    """The tower ids *user* belongs to (empty for guests).

    Administrators are deliberately NOT expanded here - callers test
    _is_admin() first and skip the filter entirely, so creating a tower never
    requires adding every administrator to it.
    """
    if not user:
        return set()
    rows = db_session.query(FileMonitorTowerMember.tower_id).filter_by(
        user_id=user.id).all()
    return {r[0] for r in rows}


def _visible_towers(user, db_session):
    """Towers *user* may open, name-ordered.

    Administrators get every tower, including deactivated ones (the template
    badges them); members get only the active towers they belong to.
    """
    q = db_session.query(FileMonitorTower).options(
        joinedload(FileMonitorTower.reports),
        joinedload(FileMonitorTower.tower_members),
    )
    if not _is_admin(user):
        ids = _member_tower_ids(user, db_session)
        if not ids:
            return []
        q = q.filter(FileMonitorTower.id.in_(ids),
                     FileMonitorTower.is_active == sql_true())
    return q.order_by(FileMonitorTower.name).all()


def _tower_card(tower):
    """Landing-page summary for one tower. Counts only - nothing is probed."""
    active = [r for r in tower.reports if r.is_active]
    return {
        'tower': tower,
        'apps': len({(r.application_name or '').lower() for r in active}),
        'inbound': sum(1 for r in active if r.flow_type == FlowType.INBOUND),
        'outbound': sum(1 for r in active if r.flow_type == FlowType.OUTBOUND),
        'reports': len(active),
        'disabled': len(tower.reports) - len(active),
        'members': len(tower.tower_members),
    }


def _group_by_application(reports):
    """[report, ...] -> per-application cards carrying both flow directions."""
    apps = {}
    for report in reports:
        key = (report.application_name or '').lower()
        if key not in apps:
            apps[key] = {
                'name': report.application_name,
                'summary': report.short_summary,
                'inbound': None,
                'outbound': None,
            }
        if report.flow_type == FlowType.INBOUND:
            apps[key]['inbound'] = report
        elif report.flow_type == FlowType.OUTBOUND:
            apps[key]['outbound'] = report
        # The summary is an application-level idea; keep the first one set.
        if report.short_summary and not apps[key]['summary']:
            apps[key]['summary'] = report.short_summary
    return [apps[k] for k in sorted(apps)]


def _selectable_towers(db_session, keep_id=None):
    """Active towers offered in the report create / settings dropdowns.

    *keep_id* is the tower a report is ALREADY in. It is included even when
    deactivated, otherwise editing an unrelated setting on such a report would
    silently force the admin to move it to a different tower.
    """
    clause = FileMonitorTower.is_active == sql_true()
    if keep_id is not None:
        clause = or_(clause, FileMonitorTower.id == keep_id)
    return (db_session.query(FileMonitorTower)
            .filter(clause)
            .order_by(FileMonitorTower.name).all())


def _resolve_tower_choice(db_session, raw, keep_id=None):
    """Form value -> tower id, or raise ValueError.

    Empty is rejected: a report with no tower is invisible to every non
    administrator, which is never what someone filling in this form intends.
    *keep_id* mirrors _selectable_towers - staying in a deactivated tower is
    allowed, moving INTO one is not.
    """
    raw = (raw or '').strip()
    if not raw:
        raise ValueError('Application Tower is required - it decides who may '
                         'view and run this report')
    try:
        tower_id = int(raw)
    except (TypeError, ValueError):
        raise ValueError('Invalid Application Tower selected')
    if keep_id is not None and tower_id == keep_id:
        if db_session.query(FileMonitorTower.id).filter_by(id=tower_id).first():
            return tower_id
    tower = db_session.query(FileMonitorTower).filter_by(
        id=tower_id, is_active=True).first()
    if not tower:
        raise ValueError('The selected Application Tower no longer exists or is '
                         'deactivated')
    return tower.id


@file_monitor_bp.route('/')
@require_auth()
def index():
    """Landing page - the Application Towers this user is allowed to open."""
    user = get_current_user()

    db_session = get_db_session()
    try:
        towers = _visible_towers(user, db_session)
        cards = [_tower_card(t) for t in towers]

        # Reports that predate towers (or whose tower was cleared) are only
        # ever shown to administrators, who can attach them from settings.
        unassigned = 0
        if _is_admin(user):
            unassigned = db_session.query(FileMonitorReport).filter(
                FileMonitorReport.tower_id.is_(None),
                FileMonitorReport.is_active == sql_true()).count()

        return render_template('file_monitor/index.html',
                               user=user,
                               cards=cards,
                               unassigned=unassigned,
                               is_admin=_is_admin(user))
    finally:
        db_session.close()


@file_monitor_bp.route('/tower/<int:tower_id>')
@require_auth()
def tower_detail(tower_id):
    """The monitored applications of one tower."""
    user = get_current_user()

    db_session = get_db_session()
    try:
        if not is_tower_member(user, tower_id, db_session):
            flash('Access denied: you are not a member of this tower', 'error')
            return redirect(url_for('file_monitor.index'))

        tower = db_session.query(FileMonitorTower).filter_by(id=tower_id).first()
        if not tower:
            flash('Tower not found', 'error')
            return redirect(url_for('file_monitor.index'))

        reports = db_session.query(FileMonitorReport).filter_by(
            tower_id=tower_id, is_active=True).all()

        return render_template('file_monitor/tower_detail.html',
                               user=user,
                               tower=tower,
                               app_reports=_group_by_application(reports),
                               member_count=len(tower.tower_members),
                               is_admin=_is_admin(user))
    finally:
        db_session.close()


@file_monitor_bp.route('/tower/unassigned')
@require_auth('admin')
def unassigned_reports():
    """Reports that have no tower yet - administrators only.

    Rendered with the same template as a real tower so the upgrade path is
    obvious: open a report, pick its tower, and it leaves this bucket.
    """
    user = get_current_user()

    db_session = get_db_session()
    try:
        reports = db_session.query(FileMonitorReport).filter(
            FileMonitorReport.tower_id.is_(None),
            FileMonitorReport.is_active == sql_true()).all()

        return render_template('file_monitor/tower_detail.html',
                               user=user,
                               tower=None,
                               app_reports=_group_by_application(reports),
                               member_count=0,
                               is_admin=True)
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Tower management (administrators)
# ---------------------------------------------------------------------------

def _tower_name_taken(db_session, name, exclude_id=None):
    """Case-insensitive duplicate check. Two towers named "Billing" and
    "billing" would be indistinguishable on every screen."""
    q = db_session.query(FileMonitorTower.id).filter(
        func.lower(FileMonitorTower.name) == name.lower())
    if exclude_id is not None:
        q = q.filter(FileMonitorTower.id != exclude_id)
    return q.first() is not None


@file_monitor_bp.route('/tower/create', methods=['GET', 'POST'])
@require_auth('admin')
@csrf_protect
def create_tower():
    user = get_current_user()

    if request.method == 'POST':
        name = (request.form.get('tower_name') or '').strip()
        description = (request.form.get('description') or '').strip() or None
        emails = (request.form.get('email_addresses') or '').strip() or None

        db_session = get_db_session()
        try:
            if not name:
                flash('Tower name is required', 'error')
            elif _tower_name_taken(db_session, name):
                flash(f'A tower named "{name}" already exists', 'error')
            else:
                tower = FileMonitorTower(
                    name=name,
                    description=description,
                    email_addresses=emails,
                    created_by=user.id,
                )
                db_session.add(tower)
                db_session.commit()
                flash(f'Tower "{name}" created. Add members so they can open its '
                      f'reports.', 'success')
                return redirect(url_for('file_monitor.manage_tower_members',
                                        tower_id=tower.id))
        except Exception as e:
            db_session.rollback()
            logging.error(f"Error creating file-monitor tower: {str(e)}")
            flash('Error creating tower', 'error')
        finally:
            db_session.close()

    return render_template('file_monitor/create_tower.html', user=user)


@file_monitor_bp.route('/tower/<int:tower_id>/edit', methods=['GET', 'POST'])
@require_auth('admin')
@csrf_protect
def edit_tower(tower_id):
    user = get_current_user()

    db_session = get_db_session()
    try:
        tower = db_session.query(FileMonitorTower).filter_by(id=tower_id).first()
        if not tower:
            flash('Tower not found', 'error')
            return redirect(url_for('file_monitor.index'))

        if request.method == 'POST':
            name = (request.form.get('tower_name') or '').strip()
            try:
                if not name:
                    flash('Tower name is required', 'error')
                elif _tower_name_taken(db_session, name, exclude_id=tower.id):
                    flash(f'A tower named "{name}" already exists', 'error')
                else:
                    tower.name = name
                    tower.description = (request.form.get('description') or '').strip() or None
                    tower.email_addresses = (request.form.get('email_addresses') or '').strip() or None
                    tower.is_active = 'is_active' in request.form
                    db_session.commit()
                    flash('Tower updated', 'success')
                    return redirect(url_for('file_monitor.tower_detail', tower_id=tower.id))
            except Exception as e:
                db_session.rollback()
                logging.error(f"Error updating tower {tower_id}: {str(e)}")
                flash('Error updating tower', 'error')

        return render_template('file_monitor/edit_tower.html', user=user, tower=tower,
                               report_count=len(tower.reports))
    finally:
        db_session.close()


@file_monitor_bp.route('/tower/<int:tower_id>/delete', methods=['POST'])
@require_auth('admin')
@csrf_protect
def delete_tower(tower_id):
    """Delete an EMPTY tower.

    Deliberately refuses while reports are still attached. A report row holds
    the entire monitoring configuration - queries, hosts, encrypted
    credentials - so deleting a tower must never cascade into it. Move the
    reports to another tower, or delete them explicitly, first.
    """
    db_session = get_db_session()
    try:
        tower = db_session.query(FileMonitorTower).filter_by(id=tower_id).first()
        if not tower:
            flash('Tower not found', 'error')
            return redirect(url_for('file_monitor.index'))

        attached = db_session.query(FileMonitorReport).filter_by(
            tower_id=tower_id).count()
        if attached:
            flash(f'"{tower.name}" still has {attached} report(s). Move or delete '
                  f'them first - deleting a tower never deletes its monitoring '
                  f'configuration.', 'error')
            return redirect(url_for('file_monitor.tower_detail', tower_id=tower_id))

        name = tower.name
        # The member rows are purged EXPLICITLY rather than left to the FK
        # cascade. That cascade only fires when SQLite has PRAGMA foreign_keys
        # on, and an orphaned member row is not harmless: SQLite reuses the
        # rowid of a deleted tower, so the next tower created could inherit a
        # dead tower's member list and silently grant access.
        removed = db_session.query(FileMonitorTowerMember).filter_by(
            tower_id=tower.id).delete(synchronize_session=False)
        db_session.delete(tower)
        db_session.commit()
        logging.info('file_monitor: tower %s (%s) deleted with %d member row(s).',
                     tower_id, name, removed)
        flash(f'Tower "{name}" deleted', 'success')
    except Exception as e:
        db_session.rollback()
        logging.error(f"Error deleting tower {tower_id}: {str(e)}")
        flash('Error deleting tower', 'error')
    finally:
        db_session.close()

    return redirect(url_for('file_monitor.index'))


# ---------------------------------------------------------------------------
# Tower membership - this is what grants view + execute rights, so ONLY
# administrators may change it. Members can read the roster of their own
# towers (useful for "who else supports this?") but cannot add or remove
# anyone, which would otherwise let a member widen their own tower's access.
# ---------------------------------------------------------------------------

@file_monitor_bp.route('/tower/<int:tower_id>/members')
@require_auth()
def manage_tower_members(tower_id):
    user = get_current_user()

    db_session = get_db_session()
    try:
        if not is_tower_member(user, tower_id, db_session):
            flash('Access denied: you are not a member of this tower', 'error')
            return redirect(url_for('file_monitor.index'))

        tower = db_session.query(FileMonitorTower).filter_by(id=tower_id).first()
        if not tower:
            flash('Tower not found', 'error')
            return redirect(url_for('file_monitor.index'))

        members = db_session.query(FileMonitorTowerMember).filter_by(
            tower_id=tower_id).all()
        member_ids = [m.user_id for m in members]
        users_by_id = {
            u.id: u for u in db_session.query(User).filter(User.id.in_(member_ids)).all()
        } if member_ids else {}
        member_users = [{'member_id': m.id, 'user': users_by_id[m.user_id]}
                        for m in members if m.user_id in users_by_id]
        member_users.sort(key=lambda m: (m['user'].username or '').lower())

        # Only ACTIVE accounts are offered: a disabled (off-boarded) user keeps
        # their name on existing records but is never a new assignment target.
        # Members see a read-only roster, so the candidate list is not built
        # for them - it is neither rendered nor theirs to act on.
        available_users = []
        if _is_admin(user):
            taken = set(member_ids)
            available_users = [u for u in db_session.query(User)
                               .filter_by(is_active=True)
                               .order_by(User.username).all()
                               if u.id not in taken]

        return render_template('file_monitor/manage_tower_members.html',
                               user=user, tower=tower,
                               member_users=member_users,
                               available_users=available_users,
                               can_manage=_is_admin(user))
    finally:
        db_session.close()


@file_monitor_bp.route('/tower/<int:tower_id>/members/add', methods=['POST'])
@require_auth('admin')
@csrf_protect
def add_tower_member(tower_id):
    user = get_current_user()
    user_id_to_add = request.form.get('user_id')

    db_session = get_db_session()
    try:
        if not db_session.query(FileMonitorTower.id).filter_by(id=tower_id).first():
            flash('Tower not found', 'error')
            return redirect(url_for('file_monitor.index'))

        if not user_id_to_add:
            flash('Please select a user to add', 'error')
            return redirect(url_for('file_monitor.manage_tower_members', tower_id=tower_id))

        target = db_session.query(User).filter_by(id=user_id_to_add, is_active=True).first()
        if not target:
            flash('That user account no longer exists or has been disabled', 'error')
        elif db_session.query(FileMonitorTowerMember).filter_by(
                tower_id=tower_id, user_id=target.id).first():
            flash(f'{target.username} is already a member of this tower', 'warning')
        else:
            db_session.add(FileMonitorTowerMember(
                tower_id=tower_id, user_id=target.id, added_by=user.id))
            db_session.commit()
            logging.warning(
                'file_monitor: %s granted %s access to tower %s.',
                getattr(user, 'username', '?'), target.username, tower_id)
            flash(f'{target.username} added - they can now view and run the '
                  f'reports in this tower', 'success')
    except Exception as e:
        db_session.rollback()
        logging.error(f"Error adding member to tower {tower_id}: {str(e)}")
        flash('Error adding user to tower', 'error')
    finally:
        db_session.close()

    return redirect(url_for('file_monitor.manage_tower_members', tower_id=tower_id))


@file_monitor_bp.route('/tower/<int:tower_id>/members/<int:member_id>/remove', methods=['POST'])
@require_auth('admin')
@csrf_protect
def remove_tower_member(tower_id, member_id):
    user = get_current_user()

    db_session = get_db_session()
    try:
        member = db_session.query(FileMonitorTowerMember).filter_by(
            id=member_id, tower_id=tower_id).first()
        if not member:
            flash('Member not found', 'error')
        else:
            revoked_user_id = member.user_id
            db_session.delete(member)
            db_session.commit()
            logging.warning(
                'file_monitor: %s revoked user %s from tower %s.',
                getattr(user, 'username', '?'), revoked_user_id, tower_id)
            flash('User removed - they can no longer view or run the reports in '
                  'this tower', 'success')
    except Exception as e:
        db_session.rollback()
        logging.error(f"Error removing member {member_id} from tower {tower_id}: {str(e)}")
        flash('Error removing user from tower', 'error')
    finally:
        db_session.close()

    return redirect(url_for('file_monitor.manage_tower_members', tower_id=tower_id))


@file_monitor_bp.route('/reports')
def report_list():
    """List all reports for admin users"""
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('file_monitor.index'))
   
    db_session = get_db_session()
    try:
        # Disabled reports stay listed so they can be re-enabled; the tower
        # cards and alerting only ever consider active ones. joinedload keeps
        # the Tower column off the N+1 path.
        reports = db_session.query(FileMonitorReport).options(
            joinedload(FileMonitorReport.tower)
        ).order_by(
            FileMonitorReport.is_active.desc(),
            FileMonitorReport.application_name, FileMonitorReport.flow_type
        ).all()

        untowered = sum(1 for r in reports if r.tower_id is None)

        return render_template('file_monitor/report_list.html', user=user,
                               reports=reports, untowered=untowered)
    finally:
        db_session.close()

@file_monitor_bp.route('/create', methods=['GET', 'POST'])
@csrf_protect
def create_report():
    """Create new file monitor report"""
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('file_monitor.index'))

    if request.method == 'POST':
        # Acquired BEFORE the try block: the except/finally below reference
        # db_session, so acquiring it inside try would raise NameError there
        # if get_db_session() itself ever failed.
        db_session = get_db_session()
        try:
            app_name = (request.form.get('application_name') or '').strip()
            summary = request.form.get('short_summary')
            # Raises ValueError (handled below) when missing or stale. Both
            # flow reports created by this submission share the tower.
            tower_id = _resolve_tower_choice(db_session, request.form.get('tower_id'))
            alert_enabled = 'alert_enabled' in request.form
            alert_emails = (request.form.get('alert_emails') or '').strip() or None
            alert_grace = _parse_grace_days(request.form)

            # One submission configures up to TWO flows (inbound + outbound).
            # Each becomes its own report row, so dashboards, cards, alerting
            # and deletion keep working per-direction.
            selected_flows = []
            if 'configure_inbound' in request.form:
                selected_flows.append((FlowType.INBOUND, 'in__'))
            if 'configure_outbound' in request.form:
                selected_flows.append((FlowType.OUTBOUND, 'out__'))

            if not app_name or not selected_flows:
                flash('Application name and at least one flow (Inbound / Outbound) are required', 'error')
                return render_template('file_monitor/create_report.html', user=user,
                                       towers=_selectable_towers(db_session),
                                       prefill_app=app_name,
                                       prefill_tower=tower_id,
                                       prefill_flow='')

            created, skipped = [], []
            for flow_type, flow_prefix in selected_flows:
                existing = db_session.query(FileMonitorReport).filter_by(
                    application_name=app_name, flow_type=flow_type, is_active=True
                ).first()
                if existing:
                    skipped.append(flow_type.value)
                    continue

                report = FileMonitorReport(
                    application_name=app_name,
                    short_summary=summary,
                    flow_type=flow_type,
                    tower_id=tower_id,
                )
                _apply_system_fields(report, request.form, flow_prefix, 'source', flow_type.value)
                report.has_intermediate = f'{flow_prefix}has_intermediate' in request.form
                if report.has_intermediate:
                    _apply_system_fields(report, request.form, flow_prefix, 'intermediate', flow_type.value)
                _apply_system_fields(report, request.form, flow_prefix, 'target', flow_type.value)

                report.alert_enabled = alert_enabled
                report.alert_emails = alert_emails
                report.alert_grace_days = alert_grace
                # Per-flow: each direction gets its own report row, so the
                # toggle is read from that flow's section of the form.
                report.exclusion_apply_all = (
                    f'{flow_prefix}exclusion_apply_all' in request.form)

                db_session.add(report)
                created.append(flow_type.value)

            if created:
                db_session.commit()
                flash(f"{' and '.join(created)} report(s) created for {app_name}", 'success')
            if skipped:
                flash(f"{' and '.join(skipped)} report(s) already exist for {app_name} - not changed", 'warning')
            if created:
                return redirect(url_for('file_monitor.index'))

        except ValueError as e:
            # Mandatory-field validation: nothing is created for EITHER flow.
            db_session.rollback()
            flash(str(e), 'error')
        except Exception as e:
            db_session.rollback()
            logging.error(f"Error creating report: {str(e)}")
            flash('Error creating report', 'error')
        finally:
            db_session.close()

    db_session = get_db_session()
    try:
        return render_template(
            'file_monitor/create_report.html',
            user=user,
            towers=_selectable_towers(db_session),
            # The settings page links here as ?app=<name>&flow=<direction> to
            # add the counterpart flow; without these the prefill never fired.
            prefill_app=(request.args.get('app') or '').strip(),
            prefill_flow=(request.args.get('flow') or '').strip().lower(),
            prefill_tower=request.args.get('tower_id', type=int),
        )
    finally:
        db_session.close()

def _requested_date_range(args, warn=False):
    """Resolve (start_date, end_date) strings from the query string.

    Default window = last 1 day. Both values are parsed defensively (the
    dashboard is public, so a guest may pass anything) and the span is
    hard-capped at MAX_DATE_RANGE_DAYS to bound the load on the monitored
    production databases / SFTP servers. Shared by the dashboard and its
    paging / export endpoints so all three read exactly the same window - a
    mismatch there would page through a different data set than the page shows.
    """
    today = datetime.now()
    default_end = today.strftime('%Y-%m-%d')
    default_start = (today - timedelta(days=1)).strftime('%Y-%m-%d')

    def _parse_date(value, fallback):
        try:
            return datetime.strptime(value, '%Y-%m-%d')
        except (TypeError, ValueError):
            return datetime.strptime(fallback, '%Y-%m-%d')

    end_dt = _parse_date(args.get('end_date'), default_end)
    start_dt = _parse_date(args.get('start_date'), default_start)

    # Normalise ordering, then enforce the maximum window. A clamped window keeps
    # the most recent MAX_DATE_RANGE_DAYS days (inclusive) ending at end_date.
    if start_dt > end_dt:
        start_dt = end_dt
    if (end_dt - start_dt).days >= MAX_DATE_RANGE_DAYS:
        start_dt = end_dt - timedelta(days=MAX_DATE_RANGE_DAYS - 1)
        if warn:
            flash(f'Date range limited to the most recent {MAX_DATE_RANGE_DAYS} days.', 'warning')

    return start_dt.strftime('%Y-%m-%d'), end_dt.strftime('%Y-%m-%d')


def _report_date_formats(report):
    """The three per-system date formats, as get_file_flow_data expects them."""
    return (report.source_date_format or None,
            report.intermediate_date_format or None,
            report.target_date_format or None)


@file_monitor_bp.route('/dashboard/<int:report_id>')
@require_auth()
def dashboard(report_id):
    """Display - and thereby RUN - the dashboard for a specific report.

    Restricted to members of the owning tower. This is not a formality: the
    render below opens live connections to the monitored source, intermediate
    and target systems.
    """
    user = get_current_user()

    logging.info(f"Loading file-monitor dashboard for report_id={report_id}")

    start_date, end_date = _requested_date_range(request.args, warn=True)

    db_session = get_db_session()

    try:
        report = db_session.query(FileMonitorReport).filter_by(id=report_id, is_active=True).first()
        if not report:
            flash('Report not found', 'error')
            return redirect(url_for('file_monitor.index'))

        if not is_tower_member(user, report.tower_id, db_session):
            logging.warning(
                'file_monitor: %s was denied report %s (tower %s)',
                getattr(user, 'username', '?'), report_id, report.tower_id)
            flash('Access denied: you are not a member of the tower that owns '
                  'this report', 'error')
            return redirect(url_for('file_monitor.index'))
        s_date_format, i_date_format, t_date_format = _report_date_formats(report)

        # Get file flow data. probe_error distinguishes "the probe FAILED"
        # from "the probe ran and found nothing" - rendering zeros on a
        # failure would mislead operators into thinking no files are pending.
        metrics=None
        dataframes=None
        plots=None
        probe_error=None
        try:
            metrics, full_dataframes, plots = get_file_flow_data_cached(
                report, s_date_format, start_date, end_date, i_date_format, t_date_format)

            # Render only the FIRST page of each table. The frames themselves
            # stay whole in the cache so the paging endpoint and the CSV export
            # can serve the rest - capping in place is what used to make the
            # tabs (and the alert emails) see only 500 rows.
            dataframes = capped_view(full_dataframes, metrics)

            #source data metric
            total_source=metrics['total_source_records']
            pending_source=metrics['pending_at_source_count']
            pending_source_pct=metrics['pending_at_source_percent']
            # analyze_file_transfers nests the pending frame under
            # source_table['pending'] - there is no top-level 'pending_source'
            # key, so the previous lookup raised KeyError on every successful
            # fetch and silently blanked the whole dashboard.
            pending_source_df=dataframes['source_table']['pending']
            logging.debug(f"total_source: {total_source}, pending_source: {pending_source}")

        except Exception as e:
            logging.exception(f"Error getting flow data for report_id={report_id}: {e}")
            total_source=0
            pending_source=0
            pending_source_pct=0
            pending_source_df=None
            probe_error=str(e)


        return render_template('file_monitor/dashboard.html',
                             user=user,
                             report=report,
                             tower=report.tower,
                             metrics=metrics,
                             dataframes=dataframes,
                             plots=plots,
                             start_date=start_date,
                             end_date=end_date,
                             total_source=total_source,
                             pending_source=pending_source,
                             pending_source_pct=pending_source_pct,
                             pending_source_df=pending_source_df,
                             probe_error=probe_error
                             )
    finally:
        db_session.close()


# Rows a single export may write. The dashboard window is already capped at
# MAX_DATE_RANGE_DAYS, so this only guards a pathological day; the response
# says so explicitly rather than handing back a silently short file.
MAX_EXPORT_ROWS = int(os.environ.get('FM_MAX_EXPORT_ROWS', '200000'))


def _load_report_table(report_id, args):
    """(report, dataframe, error_response) for a table request.

    Resolves the report, enforces tower membership, re-uses the cached probe
    for the requested window and validates the table name against the
    whitelist. Every caller below shares this so paging, exporting and the
    dashboard can never disagree about which rows they are looking at - or
    about who is allowed to see them.
    """
    table = args.get('table', '')
    part = args.get('part') or None
    if table not in TABLE_PARTS:
        return None, None, (jsonify({'error': 'Unknown table'}), 400)

    start_date, end_date = _requested_date_range(args)

    db_session = get_db_session()
    try:
        report = db_session.query(FileMonitorReport).filter_by(
            id=report_id, is_active=True).first()
        if not report:
            return None, None, (jsonify({'error': 'Report not found'}), 404)

        if not is_tower_member(get_current_user(), report.tower_id, db_session):
            return None, None, (jsonify({'error': 'Access denied'}), 403)

        s_fmt, i_fmt, t_fmt = _report_date_formats(report)
        try:
            _metrics, dataframes, _plots = get_file_flow_data_cached(
                report, s_fmt, start_date, end_date, i_fmt, t_fmt)
        except Exception as e:
            logging.exception('FM table fetch failed for report_id=%s: %s', report_id, e)
            return None, None, (jsonify({'error': 'Could not read the monitored systems'}), 502)

        df = resolve_table(dataframes, table, part)
        if df is None:
            return None, None, (jsonify({'error': 'Unknown table'}), 400)
        return report, df, None
    finally:
        db_session.close()


@file_monitor_bp.route('/dashboard/<int:report_id>/table')
@require_auth()
def dashboard_table(report_id):
    """One page of a dashboard table, searched across the FULL data set.

    The page renders the first N rows for speed; this endpoint is how the rest
    of the data is reached. Search runs server-side over every row - the old
    in-browser filter could only ever match what had already been rendered,
    which is why searching a large day appeared to find nothing.
    """
    _report, df, error = _load_report_table(report_id, request.args)
    if error:
        return error

    columns, rows, meta = paginate_table(
        df,
        page=request.args.get('page', 1),
        per_page=request.args.get('per_page'),
        query=request.args.get('q', ''),
    )
    meta['columns'] = columns
    meta['rows'] = rows
    return jsonify(meta)


@file_monitor_bp.route('/dashboard/<int:report_id>/export')
@require_auth()
def dashboard_table_export(report_id):
    """The FULL table (honouring the current search) as a CSV download."""
    report, df, error = _load_report_table(report_id, request.args)
    if error:
        return error

    df = filter_table(df, request.args.get('q', ''))
    truncated = df is not None and len(df) > MAX_EXPORT_ROWS
    if truncated:
        df = df.head(MAX_EXPORT_ROWS)

    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator='\n')
    if df is not None and not df.empty:
        writer.writerow([str(c) for c in df.columns])
        for record in df.itertuples(index=False, name=None):
            writer.writerow(['' if v is None or v != v else v for v in record])
    if truncated:
        writer.writerow([f'-- truncated at {MAX_EXPORT_ROWS} rows --'])

    table = request.args.get('table', 'table')
    part = request.args.get('part') or 'all'
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    name = secure_filename(
        f"{report.application_name}_{table}_{part}_{stamp}.csv") or 'file_monitor.csv'

    return Response(
        buf.getvalue(),
        mimetype='text/csv',
        headers={'Content-Disposition': f'attachment; filename="{name}"'},
    )


# Connection strings carry credentials (ODBC PWD=, an Oracle easy-connect
# user/password, a URL userinfo). Driver errors routinely quote the string
# they failed on, so anything echoed back to the browser is scrubbed first.
_SECRET_IN_TEXT = re.compile(
    r'((?:PWD|PASSWORD|PASSWD|SECRET)\s*=\s*)([^;\'"\s]+)', re.IGNORECASE)


def _redact(text, limit=400):
    """Connection errors, minus anything that looks like a credential."""
    cleaned = _SECRET_IN_TEXT.sub(r'\1***', str(text or ''))
    # user:password@host in a DSN / URL.
    cleaned = re.sub(r'(//[^/:@\s]+):([^@/\s]+)@', r'\1:***@', cleaned)
    return cleaned[:limit]


@file_monitor_bp.route('/test-connectivity', methods=['POST'])
@csrf_protect
def test_connectivity_route():
    """Test connectivity for one system's configuration (admin only).

    This deliberately connects to a caller-supplied target - that is the whole
    point of a "test before you save" button, and an admin configuring a new
    flow needs to reach hosts that are not yet stored anywhere. So the target
    is AUDITED rather than restricted, and the driver's error text is scrubbed
    of credentials before it goes back to the browser.
    """
    user = get_current_user()
    if not user or user.role != 'admin':
        return jsonify({'success': False, 'message': 'Admin access required'})

    try:
        payload = request.get_json(silent=True) or {}
        system_type = payload.get('system_type')
        config = payload.get('config') or {}
        if not isinstance(config, dict):
            return jsonify({'success': False, 'message': 'Invalid configuration'}), 400

        # Audit trail: who asked this server to connect where. Never the
        # connection string itself, which carries the password.
        logging.info(
            'file_monitor: connectivity test by %s -> type=%s host=%s user=%s',
            getattr(user, 'username', '?'), system_type,
            config.get('hostname') or '(connection string)',
            config.get('username') or '?')

        result = test_connectivity(system_type, config)
        if isinstance(result, dict) and result.get('message'):
            result['message'] = _redact(result['message'])
        return jsonify(result)

    except Exception as e:
        logging.exception("Connectivity test error")
        return jsonify({'success': False,
                        'message': 'Connectivity test failed - see the application log.'})


def _update_system_fields(report, form, key_base, system):
    """Update one system's connection/server details in place (settings page).

    Unlike creation, a BLANK password field means KEEP the stored password -
    the form never echoes secrets back, so blank is 'unchanged', not 'empty'.
    Changing the system type is allowed; the form posts the fields of the
    currently selected type.
    """
    type_raw = form.get(f'{key_base}_system_type')
    if not type_raw:
        return  # section not posted - leave this system untouched

    def g(name, default=None):
        return form.get(f'{key_base}_{name}', default)

    system_type = SystemType(type_raw)
    setattr(report, f'{system}_system_type', system_type)
    setattr(report, f'{system}_name', g('name'))
    setattr(report, f'{system}_date_format', g('date_format'))

    if system_type in (SystemType.ORACLE, SystemType.MSSQL):
        setattr(report, f'{system}_connection_string', encrypt_password(g('connection_string', '')))
        setattr(report, f'{system}_username', g('username'))
        pw = g('password', '')
        if pw:
            setattr(report, f'{system}_password', encrypt_password(pw))
        setattr(report, f'{system}_sql_query', g('sql_query'))
        setattr(report, f'{system}_filename_column', g('filename_column'))
    elif system_type == SystemType.LOG:
        setattr(report, f'{system}_hostname', g('hostname'))
        setattr(report, f'{system}_path', g('path'))
        setattr(report, f'{system}_sftp_username', g('sftp_username'))
        pw = g('sftp_password', '')
        if pw:
            setattr(report, f'{system}_sftp_password', encrypt_password(pw))
        setattr(report, f'{system}_file_naming_convention', g('file_naming_convention'))
        setattr(report, f'{system}_extraction_pattern', g('extraction_pattern'))
        setattr(report, f'{system}_data_split', g('data_split'))
        setattr(report, f'{system}_data_fileName', g('data_fileName') or None)


@file_monitor_bp.route('/reports/<int:report_id>/toggle-active', methods=['POST'])
@csrf_protect
def toggle_report_active(report_id):
    """Disable a report (stops its dashboard card and alerting) or re-enable a
    previously disabled one. Re-enabling is blocked when another active report
    already covers the same application + flow."""
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('file_monitor.index'))

    db_session = get_db_session()
    try:
        report = db_session.query(FileMonitorReport).filter_by(id=report_id).first()
        if not report:
            flash('Report not found', 'error')
        elif report.is_active:
            report.is_active = False
            db_session.commit()
            flash(f'{report.application_name} ({report.flow_type.value}) disabled - '
                  f'dashboard hidden and alerting stopped', 'success')
        else:
            clash = db_session.query(FileMonitorReport).filter_by(
                application_name=report.application_name,
                flow_type=report.flow_type, is_active=True).first()
            if clash:
                flash('An active report already exists for this application and '
                      'flow type - disable it first', 'error')
            else:
                report.is_active = True
                db_session.commit()
                flash(f'{report.application_name} ({report.flow_type.value}) enabled', 'success')
    except Exception as e:
        db_session.rollback()
        logging.error(f"Error toggling report {report_id}: {str(e)}")
        flash('Error updating report status', 'error')
    finally:
        db_session.close()

    return redirect(url_for('file_monitor.report_list'))


@file_monitor_bp.route('/reports/<int:report_id>/settings', methods=['GET', 'POST'])
@csrf_protect
def report_settings(report_id):
    """Edit a report's runtime behaviour - summary, per-system named stats and
    exclusion rules, and pending-file alerting - WITHOUT recreating the
    report. Stats and exclusion needs change over time (new regions, new file
    types, new by-design skips), so they must be editable in place;
    connection details stay create-only.
    """
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('file_monitor.index'))

    db_session = get_db_session()
    try:
        report = db_session.query(FileMonitorReport).filter_by(
            id=report_id, is_active=True).first()
        if not report:
            flash('Report not found', 'error')
            return redirect(url_for('file_monitor.report_list'))

        systems = ['source'] + (['intermediate'] if report.has_intermediate else []) + ['target']

        if request.method == 'POST':
            try:
                report.short_summary = (request.form.get('short_summary') or '').strip() or None
                # Moving a report between towers moves its whole audience: the
                # old tower loses access the moment this commits.
                report.tower_id = _resolve_tower_choice(
                    db_session, request.form.get('tower_id'), keep_id=report.tower_id)
                report.alert_enabled = 'alert_enabled' in request.form
                report.alert_emails = (request.form.get('alert_emails') or '').strip() or None
                report.alert_grace_days = _parse_grace_days(request.form)
                report.exclusion_apply_all = 'exclusion_apply_all' in request.form

                # Connection / server details (blank password = keep current).
                for s in systems:
                    _update_system_fields(report, request.form, f'set_{s}', s)

                # The form shows the RESOLVED config (including entries
                # migrated from the legacy fixed stats columns and report-
                # level rules), so what comes back is the complete truth:
                # write the JSON configs and clear every legacy field so the
                # fallbacks can't resurrect deleted entries.
                for s in systems:
                    setattr(report, f'{s}_stats_config',
                            _stats_config_json(request.form, f'set_{s}'))
                    setattr(report, f'{s}_exclusion_config',
                            _exclusion_config_json(request.form, f'set_{s}'))
                    setattr(report, f'{s}_display_config',
                            _display_config_json(request.form, f'set_{s}'))
                    setattr(report, f'{s}_primary_stats_column', None)
                    setattr(report, f'{s}_secondary_stats_column', None)
                    setattr(report, f'{s}_stats_pattern', None)
                report.exclusion_rules = None
                report.exclude_data = None
                report.exclude_data1 = None

                # Mandatory config: filename location + at least one display
                # field per system. Checked after everything is applied so
                # the message reflects the final state of the form.
                for s in systems:
                    _validate_system_config(report, s)

                db_session.commit()
                # Drop the cached probe so the new query / exclusions / display
                # columns show on the next view instead of after the TTL.
                invalidate_flow_cache(report.id)
                flash('Report settings updated', 'success')
                return redirect(url_for('file_monitor.report_list'))
            except ValueError as e:
                db_session.rollback()
                flash(str(e), 'error')
            except Exception as e:
                db_session.rollback()
                logging.error(f"Error updating report settings: {str(e)}")
                flash('Error updating report settings', 'error')

        # Resolved per-system config for the form. Report-level rules (from
        # the earlier settings UI / legacy slots) apply to the source, so they
        # are shown - and on save persisted - as source exclusions.
        system_cfgs = []
        for s in systems:
            exclusions = parse_system_exclusions(report, s)
            if s == 'source':
                for r in parse_exclusion_rules(report):
                    exclusions.append({'name': r.get('label') or '',
                                       'ref': r.get('column') or '',
                                       'values': r.get('values', '')})
            stype = getattr(report, f'{s}_system_type', None)

            def rv(field):
                return getattr(report, f'{s}_{field}', None) or ''

            system_cfgs.append({
                'key': s,
                'label': s.capitalize(),
                'name': rv('name'),
                'type': stype.value if stype is not None else '',
                'is_log': bool(stype is not None and stype.value == 'log'),
                'date_format': rv('date_format'),
                # Secrets are never echoed back; the connection string is
                # shown so hosts/services can be corrected in place.
                'connection_string': decrypt_password(getattr(report, f'{s}_connection_string', None) or ''),
                'username': rv('username'),
                'sql_query': rv('sql_query'),
                'filename_column': rv('filename_column'),
                'hostname': rv('hostname'),
                'path': rv('path'),
                'sftp_username': rv('sftp_username'),
                'file_naming_convention': rv('file_naming_convention'),
                'extraction_pattern': rv('extraction_pattern'),
                'data_split': rv('data_split'),
                'data_fileName': rv('data_fileName'),
                'stats': parse_stats_config(report, s),
                'exclusions': exclusions,
                'display': parse_display_config(report, s),
            })

        # Counterpart flow for this application: link to it if it exists,
        # otherwise offer to add it (prefilled create form).
        other_flow = (FlowType.OUTBOUND if report.flow_type == FlowType.INBOUND
                      else FlowType.INBOUND)
        counterpart = db_session.query(FileMonitorReport).filter_by(
            application_name=report.application_name,
            flow_type=other_flow, is_active=True).first()

        return render_template('file_monitor/report_settings.html',
                               user=user, report=report, system_cfgs=system_cfgs,
                               towers=_selectable_towers(db_session,
                                                         keep_id=report.tower_id),
                               other_flow=other_flow.value, counterpart=counterpart)
    finally:
        db_session.close()


def purge_report_rows(db_session, report):
    """Delete every row this database holds for ONE report and return the
    per-table counts removed.

    Scope is deliberately narrow. A report row IS a single flow direction, so
    purging the Inbound report of an application never touches its Outbound
    report (they are separate rows with separate ids). The monitored files
    themselves live in the source / intermediate / target systems and are
    never written to - nothing here touches them.

    Caller commits; this only stages the deletes so the whole purge is one
    transaction.
    """
    removed = {
        'alert_log': db_session.query(FileMonitorAlertLog)
                     .filter_by(report_id=report.id)
                     .delete(synchronize_session=False),
    }
    db_session.delete(report)
    removed['report'] = 1
    return removed


@file_monitor_bp.route('/reports/<int:report_id>/delete', methods=['POST'])
@csrf_protect
def delete_report(report_id):
    """PERMANENTLY delete one report and all of its data (admin only).

    This is a hard delete and cannot be undone - unlike the Disable action,
    which keeps the row so it can be switched back on. The confirmation form
    must echo the application name back, so a mis-clicked trash icon cannot
    destroy a configuration on its own.
    """
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('file_monitor.index'))

    db_session = get_db_session()
    try:
        report = db_session.query(FileMonitorReport).filter_by(id=report_id).first()
        if not report:
            flash('Report not found', 'error')
            return redirect(url_for('file_monitor.report_list'))

        typed = (request.form.get('confirm_name') or '').strip()
        if typed.lower() != (report.application_name or '').strip().lower():
            flash('Delete cancelled - the typed application name did not match', 'error')
            return redirect(url_for('file_monitor.report_list'))

        label = f'{report.application_name} ({report.flow_type.value})'
        removed = purge_report_rows(db_session, report)
        db_session.commit()
        invalidate_flow_cache(report_id)
        logging.warning(
            f"file_monitor: report {report_id} ({label}) permanently deleted by "
            f"{getattr(user, 'username', '?')}; rows removed: {removed}")
        flash(f'{label} deleted permanently - configuration and '
              f'{removed["alert_log"]} alert-history row(s) removed. The other '
              f'flow direction for this application is unaffected.', 'success')
    except Exception as e:
        db_session.rollback()
        logging.error(f"Error deleting report {report_id}: {str(e)}")
        flash('Error deleting report', 'error')
    finally:
        db_session.close()

    return redirect(url_for('file_monitor.report_list'))


@file_monitor_bp.route('/about')
def about():
    """About page - explains the module to end users and the support team."""
    user = get_current_user()
    return render_template('file_monitor/about.html', user=user)


# ===========================================================================
# Flow Catalogue - searchable reference of DTN / MHHS market message flows
# (D0001, IF-026, ...) parsed from the Web Data Specification HTML kept
# under data/DTN_Flow.
# ===========================================================================

# Serialises the first-visit parse. Without it, several people opening the
# catalogue at once each start their own 12 MB parse in their own worker.
_catalogue_load_lock = threading.Lock()


def _ensure_catalogue_loaded(db_session):
    """Auto-load the catalogue from data/DTN_Flow on first visit.

    Returns the meta row (or None when no spec file exists yet). Parsing the
    12 MB spec takes a few seconds, but only ever happens once - afterwards
    everything is served from the database.
    """
    meta = db_session.query(DtnFlowCatalogueMeta).first()
    if meta:
        return meta
    spec_file = dtn_flow_parser.find_spec_file()
    if not spec_file:
        return None
    with _catalogue_load_lock:
        # Another request may have finished the load while we waited.
        meta = db_session.query(DtnFlowCatalogueMeta).first()
        if meta:
            return meta
        return _load_catalogue(db_session, spec_file)


def _load_catalogue(db_session, spec_file):
    try:
        dtn_flow_parser.load_spec_to_db(db_session, spec_file, loaded_by='auto-load')
        return db_session.query(DtnFlowCatalogueMeta).first()
    except Exception as e:
        db_session.rollback()
        logging.exception(f"Flow catalogue auto-load failed: {e}")
        flash('Could not load the flow specification file. Check the application log.', 'error')
        return None


@file_monitor_bp.route('/flow-catalogue')
@require_auth()
def flow_catalogue():
    """Search page: find a flow by catalogue reference (D0001, IF-026) or name."""
    user = get_current_user()
    q = (request.args.get('q') or '').strip()
    db_session = get_db_session()
    try:
        meta = _ensure_catalogue_loaded(db_session)

        matched_items = []
        if q:
            like = f"%{q}%"
            messages = db_session.query(DtnFlowMessage).filter(or_(
                DtnFlowMessage.catalogue_ref.ilike(like),
                DtnFlowMessage.mm_ref.ilike(like),
                DtnFlowMessage.name.ilike(like),
            )).order_by(DtnFlowMessage.catalogue_ref).all()

            # An exact catalogue/MM reference with a single hit goes straight
            # to the detail page - "D0001<enter>" should not need a second click.
            exact = [m for m in messages
                     if q.lower() in ((m.catalogue_ref or '').lower(), m.mm_ref.lower())]
            if len(exact) == 1:
                return redirect(url_for('file_monitor.flow_detail', mm_ref=exact[0].mm_ref))

            # Also surface matching data items (J0003, DI-063, "MPAN" ...) so
            # the search works for fields, not just flows.
            matched_items = db_session.query(DtnFlowDataItem).filter(or_(
                DtnFlowDataItem.catalogue_ref.ilike(like),
                DtnFlowDataItem.di_ref.ilike(like),
                DtnFlowDataItem.name.ilike(like),
            )).order_by(DtnFlowDataItem.di_ref).limit(50).all()
        else:
            messages = db_session.query(DtnFlowMessage).order_by(
                DtnFlowMessage.catalogue_ref).all()

        return render_template('file_monitor/flow_catalogue.html',
                               user=user, q=q, messages=messages,
                               matched_items=matched_items, meta=meta)
    finally:
        db_session.close()


@file_monitor_bp.route('/flow-catalogue/flow/<mm_ref>')
@require_auth()
def flow_detail(mm_ref):
    """Full picture of one flow: what it carries, who exchanges it, key fields."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        message = db_session.query(DtnFlowMessage).filter_by(mm_ref=mm_ref).first()
        if not message:
            flash(f'Flow {mm_ref} not found in the catalogue', 'error')
            return redirect(url_for('file_monitor.flow_catalogue'))

        variants = json.loads(message.scenario_variants or '[]')
        data_items = json.loads(message.data_items or '[]')
        structures = json.loads(message.structures or '[]')
        key_fields = json.loads(message.key_fields or '[]')
        key_refs = {k['di_ref'] for k in key_fields}

        # Enrich the item list with type/length/nullable from the data item
        # definitions so the table is meaningful on its own.
        refs = [d['di_ref'] for d in data_items if d.get('di_ref')]
        defs = {}
        if refs:
            for di in db_session.query(DtnFlowDataItem).filter(
                    DtnFlowDataItem.di_ref.in_(refs)).all():
                defs[di.di_ref] = di
        items_detail = []
        for d in data_items:
            di = defs.get(d.get('di_ref'))
            items_detail.append({
                'di_ref': d.get('di_ref', ''),
                'catalogue_ref': d.get('catalogue_ref', ''),
                'name': d.get('name', ''),
                'data_type': di.data_type if di else '',
                'data_type_format': di.data_type_format if di else '',
                'logical_length': di.logical_length if di else '',
                'nullable': di.nullable if di else '',
                'description': di.description if di else '',
                'has_enum': bool(di and di.enumeration and di.enumeration != '[]'),
                'is_key': d.get('di_ref') in key_refs,
            })

        # Routing summary for the "who exchanges this" insight.
        sources = sorted({v['source'] for v in variants if v.get('source')})
        targets = sorted({v['target'] for v in variants if v.get('target')})

        return render_template('file_monitor/flow_detail.html',
                               user=user, message=message, variants=variants,
                               items_detail=items_detail, structures=structures,
                               key_fields=key_fields, sources=sources,
                               targets=targets,
                               optionality_labels=dtn_flow_parser.OPTIONALITY_LABELS)
    finally:
        db_session.close()


@file_monitor_bp.route('/flow-catalogue/item/<di_ref>')
@require_auth()
def flow_item_detail(di_ref):
    """Data item (field) definition: type, length, valid values, where used."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        item = db_session.query(DtnFlowDataItem).filter_by(di_ref=di_ref).first()
        if not item:
            flash(f'Data item {di_ref} not found in the catalogue', 'error')
            return redirect(url_for('file_monitor.flow_catalogue'))

        enumeration = json.loads(item.enumeration or '[]')
        used_in_refs = json.loads(item.used_in or '[]')
        used_in = []
        if used_in_refs:
            used_in = db_session.query(DtnFlowMessage).filter(
                DtnFlowMessage.mm_ref.in_(used_in_refs)
            ).order_by(DtnFlowMessage.catalogue_ref).all()

        return render_template('file_monitor/flow_item_detail.html',
                               user=user, item=item, enumeration=enumeration,
                               used_in=used_in)
    finally:
        db_session.close()


@file_monitor_bp.route('/flow-catalogue/upload', methods=['POST'])
@csrf_protect
def flow_catalogue_upload():
    """Admin: upload a new spec HTML. The file is saved to data/DTN_Flow and
    loaded per the chosen mode - 'refresh' wipes and rebuilds the catalogue,
    'update' merges the file's flows in without truncating."""
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('file_monitor.flow_catalogue'))

    upload = request.files.get('spec_file')
    if not upload or not upload.filename:
        flash('Please choose a specification HTML file to upload', 'error')
        return redirect(url_for('file_monitor.flow_catalogue'))

    filename = secure_filename(upload.filename)
    if not filename.lower().endswith(('.html', '.htm')):
        flash('The specification must be an .html file', 'error')
        return redirect(url_for('file_monitor.flow_catalogue'))

    mode = request.form.get('mode', 'refresh')
    if mode not in dtn_flow_parser.LOAD_MODES:
        mode = 'refresh'

    os.makedirs(dtn_flow_parser.DTN_FLOW_DIR, exist_ok=True)
    path = os.path.join(dtn_flow_parser.DTN_FLOW_DIR, filename)
    upload.save(path)

    db_session = get_db_session()
    try:
        result = dtn_flow_parser.load_spec_to_db(db_session, path,
                                                 loaded_by=user.username, mode=mode)
        verb = 'replaced from' if mode == 'refresh' else 'updated from'
        flash(f"Flow catalogue {verb} {filename}: "
              f"{result['messages_added']} new flow(s) added, "
              f"{result['messages_updated']} updated - catalogue now holds "
              f"{result['message_count']} flows, {result['item_count']} data items "
              f"(spec version {result['version'] or 'unknown'})", 'success')
    except Exception as e:
        db_session.rollback()
        logging.exception(f"Flow catalogue upload failed: {e}")
        flash('The uploaded file could not be parsed as a Web Data Specification. '
              'The previous catalogue data was left unchanged.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('file_monitor.flow_catalogue'))


@file_monitor_bp.route('/flow-catalogue/reload', methods=['POST'])
@csrf_protect
def flow_catalogue_reload():
    """Admin: re-parse the newest spec file already on disk under data/DTN_Flow,
    honouring the same refresh/update mode toggle as the upload route."""
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('file_monitor.flow_catalogue'))

    spec_file = dtn_flow_parser.find_spec_file()
    if not spec_file:
        flash('No specification HTML file found under data/DTN_Flow', 'error')
        return redirect(url_for('file_monitor.flow_catalogue'))

    mode = request.form.get('mode', 'refresh')
    if mode not in dtn_flow_parser.LOAD_MODES:
        mode = 'refresh'

    db_session = get_db_session()
    try:
        result = dtn_flow_parser.load_spec_to_db(db_session, spec_file,
                                                 loaded_by=user.username, mode=mode)
        verb = 'reloaded from' if mode == 'refresh' else 'updated from'
        flash(f"Flow catalogue {verb} {os.path.basename(spec_file)}: "
              f"{result['messages_added']} new flow(s) added, "
              f"{result['messages_updated']} updated - catalogue now holds "
              f"{result['message_count']} flows, {result['item_count']} data items", 'success')
    except Exception as e:
        db_session.rollback()
        logging.exception(f"Flow catalogue reload failed: {e}")
        flash('Could not reload the specification file. Check the application log.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('file_monitor.flow_catalogue'))
