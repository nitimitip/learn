"""
scheduler.py - File Monitor pending-file alert scheduler.

Mirrors the to-do / certificate-monitor lifecycle: an in-process APScheduler
BackgroundScheduler with its OWN jobstore table (``apscheduler_jobs_fm``) so
it never loads or fires the health-check / MIMP / to-do jobs.

One daily cron job:

  * fm_pending_alert - every morning at FM_ALERT_HOUR:MINUTE (07:30 local by
    default, after overnight batch windows have closed). Probes each active
    alert-enabled report over a short trailing window and emails the report's
    recipients when files from previous days are still pending (or duplicate
    copies were lost in transit).

Deployment model (identical to the other schedulers):
  * The dedicated Windows service (health_monitor_app_sched.py) owns the
    schedule in production and calls init_file_monitor_alerting().
  * The in-process Flask scheduler may also start it, guarded by
    RUN_SCHEDULERS_IN_APP in main_app.py. The job runs with coalesce=True and
    max_instances=1, and the per-day FileMonitorAlertLog row makes the sweep
    idempotent, so a second runner is harmless.
"""

import logging
import os
import threading
from typing import Optional

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from tzlocal import get_localzone

from database import engine
from .alerts import run_pending_file_alerts

logger = logging.getLogger(__name__)

# Alert sweep time (local). Override with FM_ALERT_HOUR / FM_ALERT_MINUTE.
_ALERT_HOUR = int(os.environ.get('FM_ALERT_HOUR', '7'))
_ALERT_MINUTE = int(os.environ.get('FM_ALERT_MINUTE', '30'))

_JOBSTORE_TABLE = os.environ.get('FM_APSCHEDULER_TABLE', 'apscheduler_jobs_fm')
_ALERT_JOB = 'fm_pending_alert'

_init_lock = threading.Lock()
_scheduler: Optional[BackgroundScheduler] = None


def _alert_safe():
    """Scheduler entry point - never lets an exception kill the thread."""
    try:
        run_pending_file_alerts()
    except Exception:
        logger.exception('File Monitor alert sweep crashed (suppressed).')


def init_file_monitor_alerting() -> None:
    """Start the in-process file-monitor alert scheduler. Idempotent."""
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            logger.info('File Monitor alerting already running - skipping re-init.')
            return

        _scheduler = BackgroundScheduler(
            jobstores={'default': SQLAlchemyJobStore(engine=engine, tablename=_JOBSTORE_TABLE)},
            job_defaults={'coalesce': True, 'max_instances': 1, 'misfire_grace_time': 3600},
            timezone=get_localzone(),
        )
        _scheduler.add_job(
            func=_alert_safe,
            trigger=CronTrigger(hour=_ALERT_HOUR, minute=_ALERT_MINUTE),
            id=_ALERT_JOB,
            name=f'File Monitor pending-file alert (daily {_ALERT_HOUR:02d}:{_ALERT_MINUTE:02d})',
            replace_existing=True,
        )
        _scheduler.start()
        logger.info('File Monitor alerting started - daily sweep at %02d:%02d.',
                    _ALERT_HOUR, _ALERT_MINUTE)


def shutdown_file_monitor_alerting() -> None:
    """Cleanly stop the scheduler. Call from service teardown / atexit."""
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            _scheduler.shutdown(wait=False)
            logger.info('File Monitor alerting stopped.')
        _scheduler = None
