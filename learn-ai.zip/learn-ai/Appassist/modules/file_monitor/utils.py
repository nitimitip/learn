import os
import pandas as pd
from collections import OrderedDict
from datetime import date, datetime, timedelta
import logging
import json
import threading
import time
import warnings
from crypto_utils import encrypt_data, decrypt_data
import re
import plotly.graph_objects as go
import plotly.io as pio


# The Oracle (oracledb/cx_Oracle), SQL Server (pyodbc) and SSH/SFTP (paramiko)
# drivers are imported LAZILY, never at module load. Each depends on native
# libraries (the Oracle Instant Client / an ODBC driver / cryptography
# back-ends) that may be absent on a given host. Importing them at the top
# would make this whole module fail to import - which would break blueprint
# registration in main_app.py and stop the ENTIRE application from starting.
# Loading them only when a probe actually needs them keeps a missing driver a
# per-report problem instead of a site-wide outage. (The MIMP probes already
# follow this same pattern.)
def _import_oracle():
    # Prefers python-oracledb (auto thick/thin - thin mode needs no Oracle
    # Client install, avoiding DPI-1047); falls back to cx_Oracle.
    from oracle_client import get_oracle_driver
    return get_oracle_driver()


def _import_pyodbc():
    import pyodbc
    return pyodbc


def _import_paramiko():
    import paramiko
    return paramiko


# Learned SSH host keys are persisted here so that, after the first successful
# connection to a server, any later host-key change (a re-provisioned server -
# or a man-in-the-middle trying to capture the stored SFTP credentials) makes
# the connection FAIL instead of silently proceeding. Trust-on-first-use.
_KNOWN_HOSTS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    'data', 'sftp_known_hosts',
)


def _connect_ssh(hostname, username, password, timeout=10):
    """Open an SSH connection with host-key pinning (trust on first use).

    * Known keys are loaded from data/sftp_known_hosts; a key that no longer
      matches raises BadHostKeyException (paramiko enforces this regardless
      of the missing-key policy).
    * Unknown hosts are accepted on first contact and their key is saved --
      unless SFTP_STRICT_HOST_KEYS=1, in which case unknown hosts are
      rejected and the key must be added to the file out-of-band.
    """
    paramiko = _import_paramiko()
    ssh = paramiko.SSHClient()
    try:
        if os.path.exists(_KNOWN_HOSTS_PATH):
            ssh.load_host_keys(_KNOWN_HOSTS_PATH)
    except Exception as e:
        logging.warning(f"Could not load SFTP known-hosts file: {e}")
    if os.environ.get('SFTP_STRICT_HOST_KEYS') == '1':
        ssh.set_missing_host_key_policy(paramiko.RejectPolicy())
    else:
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    ssh.connect(hostname, username=username, password=password, timeout=timeout)

    # Keepalive so a silently dropped connection surfaces as an error instead
    # of a socket that blocks until the OS gives up.
    try:
        ssh.get_transport().set_keepalive(30)
    except Exception:
        pass

    # Persist any newly learned key so the pin applies from now on.
    try:
        os.makedirs(os.path.dirname(_KNOWN_HOSTS_PATH), exist_ok=True)
        ssh.save_host_keys(_KNOWN_HOSTS_PATH)
    except Exception as e:
        logging.warning(f"Could not save SFTP known-hosts file: {e}")
    return ssh


# How long (seconds) an individual SFTP operation may block. ssh.connect()'s
# timeout= bounds only the HANDSHAKE; once a session exists, paramiko's
# channel has no timeout of its own, so a server that accepts the connection
# and then stops responding mid-transfer would block the calling thread
# indefinitely - an IIS worker in the dashboard's case, the scheduler thread
# in the alert sweep's. Setting the channel timeout bounds every listdir and
# read that follows.
_SFTP_IO_TIMEOUT = int(os.environ.get('FM_SFTP_IO_TIMEOUT', '120'))


def _open_sftp(ssh):
    """Open an SFTP channel with a bounded per-operation timeout."""
    sftp = ssh.open_sftp()
    try:
        sftp.get_channel().settimeout(_SFTP_IO_TIMEOUT)
    except Exception:
        pass
    return sftp


def encrypt_password(password):
    """Encrypt password for storage"""
    if not password:
        return ''
    return encrypt_data(password)


def decrypt_password(encrypted_password):
    """Decrypt password for use"""
    if not encrypted_password:
        return ''
    return decrypt_data(encrypted_password)


def test_connectivity(system_type, config):
    """Test connectivity to a system"""
    try:
        if system_type in ['oracle', 'mssql']:
            return test_database_connectivity(system_type, config)
        elif system_type == 'log':
            return test_sftp_connectivity(config)
        else:
            return {'success': False, 'message': 'Unknown system type'}
    except Exception as e:
        logging.error(f"Connectivity test failed: {str(e)}")
        return {'success': False, 'message': str(e)}


def test_database_connectivity(system_type, config):
    """Test database connectivity"""
    connection_string = config.get('connection_string', '')
    username = config.get('username', '')
    password = config.get('password', '')
    # The probe statement is fixed server-side. This module must never run
    # caller-supplied SQL against a monitored production system - the real
    # data queries go through get_database_data(), which enforces read-only.
    test_query = 'SELECT 1 FROM DUAL' if system_type == 'oracle' else 'SELECT 1'

    conn = None
    try:
        if system_type == 'oracle':
            oracle = _import_oracle()
            # NOTE: cx_Oracle has no connect-level timeout argument - to
            # bound a connect to a dead host, put CONNECT_TIMEOUT in the
            # TNS/easy-connect string (python-oracledb honours it too).
            # call_timeout below bounds a slow/hung test QUERY once connected.
            # Keyword args are required: positional (user, password, dsn)
            # is cx_Oracle-only and breaks under python-oracledb.
            conn = oracle.connect(
                user=username, password=password, dsn=connection_string)
            try:
                conn.call_timeout = 15000  # ms
            except Exception:
                pass
            cursor = conn.cursor()
            cursor.execute(test_query)
            result = cursor.fetchone()
            cursor.close()

            return {'success': True, 'message': 'Oracle connection successful'}

        elif system_type == 'mssql':
            pyodbc = _import_pyodbc()
            # `timeout` bounds the LOGIN attempt so a wrong/dead host cannot pin
            # the worker at the OS TCP timeout; conn.timeout bounds the query.
            conn = pyodbc.connect(connection_string, timeout=15)
            try:
                conn.timeout = 15  # per-statement query timeout (s)
            except Exception:
                pass
            cursor = conn.cursor()
            cursor.execute(test_query)
            result = cursor.fetchone()
            cursor.close()

            return {'success': True, 'message': 'SQL Server connection successful'}

    except ImportError as e:
        return {'success': False, 'message': f'Database driver not available: {str(e)}'}
    except Exception as e:
        return {'success': False, 'message': f'Connection failed: {str(e)}'}
    finally:
        # Always release the connection, even when the test query raised.
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


def test_sftp_connectivity(config):
    """Test SFTP connectivity"""
    hostname = config.get('hostname', '')
    username = config.get('username', '')
    password = config.get('password', '')
    path = config.get('path', '/')

    ssh = None
    try:
        ssh = _connect_ssh(hostname, username, password, timeout=10)

        # Test SFTP
        sftp = _open_sftp(ssh)
        sftp.listdir(path)
        sftp.close()

        return {'success': True, 'message': 'SFTP connection successful'}

    except ImportError as e:
        return {'success': False, 'message': 'Paramiko library not available'}
    except Exception as e:
        return {'success': False, 'message': f'SFTP connection failed: {str(e)}'}
    finally:
        if ssh is not None:
            try:
                ssh.close()
            except Exception:
                pass


def parse_exclusion_rules(report):
    """Return the report's exclusion configuration as a list of rule dicts.

    Each rule: {'column': <name or '' for auto-detect>, 'values': 'v1,v2,*.usr',
    'label': <optional display name>}. The JSON exclusion_rules column is read
    first; the legacy exclude_data / exclude_data1 slots are appended as
    auto-detect rules so pre-existing reports keep excluding exactly as before.
    Malformed JSON is logged and skipped - configuration mistakes must never
    blank a production report.
    """
    rules = []
    raw = getattr(report, 'exclusion_rules', None)
    if raw:
        try:
            loaded = json.loads(raw)
            if isinstance(loaded, list):
                for r in loaded:
                    if isinstance(r, dict) and str(r.get('values') or '').strip():
                        rules.append({
                            'column': str(r.get('column') or '').strip(),
                            'values': str(r.get('values') or '').strip(),
                            'label': str(r.get('label') or '').strip(),
                        })
        except (ValueError, TypeError) as e:
            logging.warning(f"Ignoring malformed exclusion_rules JSON on report "
                            f"{getattr(report, 'id', '?')}: {e}")
    for legacy in (getattr(report, 'exclude_data', None),
                   getattr(report, 'exclude_data1', None)):
        if legacy and str(legacy).strip():
            rules.append({'column': '', 'values': str(legacy).strip(), 'label': ''})
    return rules


# Internal marker for NAMED stat columns. A configured stat "Flow Type" is
# carried through fetch/analysis as 'stat::Flow Type' so the analysis can
# discover stat columns without a hard-coded list; the marker is stripped
# before the frames reach the dashboard. The legacy fixed names
# primary_stat / secondary_stat are still recognised alongside.
_STAT_PREFIX = 'stat::'
_LEGACY_STAT_COLS = ('primary_stat', 'secondary_stat')


def _stat_columns(df):
    """Ordered list of stat columns present in *df* (marker + legacy names)."""
    if df is None:
        return []
    cols = [c for c in df.columns if str(c).startswith(_STAT_PREFIX)]
    cols += [c for c in _LEGACY_STAT_COLS if c in df.columns and c not in cols]
    return cols


def _stat_display(col):
    """Human name of a stat column ('stat::Flow Type' -> 'Flow Type')."""
    s = str(col)
    return s[len(_STAT_PREFIX):] if s.startswith(_STAT_PREFIX) else s


def _stat_plot_title(label, df_name):
    """Title spec for a stat distribution chart.

    Left-anchored at the very top of the container so it never collides with
    the stat selector, which is pinned to the top-RIGHT of the same margin.
    Returned as a dict (not a string) because the dropdown re-applies the
    title on every switch and must re-apply the position with it.
    """
    return dict(text=f'{_stat_display(label)} Distribution in {df_name}',
                x=0.01, xanchor='left', yref='container', y=0.96, yanchor='top')


def _load_json_list(raw, report_id, what):
    """Parse a JSON list column defensively; a config typo must never blank a
    live report. Returns [] on missing/malformed data."""
    if not raw:
        return []
    try:
        loaded = json.loads(raw)
        return loaded if isinstance(loaded, list) else []
    except (ValueError, TypeError) as e:
        logging.warning(f"Ignoring malformed {what} JSON on report {report_id}: {e}")
        return []


def parse_stats_config(report, system_prefix):
    """Named stats for one system: [{'name': 'Flow Type', 'ref': 'FLOW_TYPE'}].

    'ref' is a column name for oracle/mssql and a split position for log
    systems. When the JSON config is absent the legacy fixed fields (primary/
    secondary stats columns, *_stats_pattern) are translated so pre-existing
    reports keep charting exactly as before.
    """
    entries = []
    for e in _load_json_list(getattr(report, f'{system_prefix}_stats_config', None),
                             getattr(report, 'id', '?'), 'stats_config'):
        if not isinstance(e, dict):
            continue
        ref = str(e.get('ref') if e.get('ref') is not None else '').strip()
        if not ref:
            continue
        name = str(e.get('name') or '').strip() or ref
        entries.append({'name': name, 'ref': ref})
    if entries:
        return entries

    # Legacy fallback. Display names use the configured COLUMN NAME (what the
    # operator actually typed), never the internal primary/secondary label -
    # a graph titled 'FLOW_TYPE' means something, 'primary_stat' does not.
    system_type = getattr(report, f'{system_prefix}_system_type', None)
    if system_type is not None and system_type.value == 'log':
        pos = getattr(report, f'{system_prefix}_stats_pattern', None)
        if pos is not None and str(pos).strip() != '':
            entries.append({'name': 'Stat', 'ref': str(pos).strip()})
    else:
        for legacy_field in (f'{system_prefix}_primary_stats_column',
                             f'{system_prefix}_secondary_stats_column'):
            col = getattr(report, legacy_field, None)
            if col and str(col).strip():
                col = str(col).strip()
                entries.append({'name': col, 'ref': col})
    return entries


def parse_display_config(report, system_prefix):
    """Which fields the dashboard tables show for one system:
    [{'name': 'Region', 'ref': 'REGION'}]. 'ref' is a column name (db) or
    split position (log). Empty list = no selection = show every fetched
    column (legacy behaviour). File name and date are always shown."""
    entries = []
    for e in _load_json_list(getattr(report, f'{system_prefix}_display_config', None),
                             getattr(report, 'id', '?'), 'display_config'):
        if not isinstance(e, dict):
            continue
        ref = str(e.get('ref') if e.get('ref') is not None else '').strip()
        if not ref:
            continue
        name = str(e.get('name') or '').strip() or ref
        entries.append({'name': name, 'ref': ref})
    return entries


def _fig_to_html(fig):
    """Render a Plotly figure as an embeddable <div> for the dashboard.

    include_plotlyjs=False is deliberate and load-bearing. With the default
    (True), EVERY chart inlines its own ~4.8 MB copy of plotly.js: a dashboard
    with the trend line, the trend bar and three per-system stat charts shipped
    ~24 MB of HTML per page load. Locally that is merely slow; behind IIS /
    FastCGI the page did not finish, so the chart areas rendered as tall blank
    gaps. The library is loaded ONCE from static/js by the dashboard template
    (in <head>, because the snippet below calls Plotly.newPlot inline).
    """
    return pio.to_html(fig, full_html=False, include_plotlyjs=False,
                       config={'displaylogo': False, 'responsive': True})


# Rows rendered into a dashboard table in ONE page. The analysis, the metrics
# and the alert emails all run on the FULL data; only the HTML page is bounded,
# so a 100k-row day cannot balloon the response or hang the browser. The rest of
# the data is reachable through the dashboard's paging / search endpoint and the
# CSV export, both of which read the same full frames.
_MAX_TABLE_ROWS = int(os.environ.get('FM_MAX_TABLE_ROWS', '500'))

# Largest page a caller may request from the paging endpoint. per_page arrives
# straight off the query string, so without a ceiling ?per_page=10000000 would
# ask one response to carry the whole frame.
_MAX_PAGE_ROWS = int(os.environ.get('FM_MAX_PAGE_ROWS', '5000'))

# Ceiling on rows a single monitored-system query may pull into this process,
# and the chunk size used to count towards it. See get_database_data().
_MAX_QUERY_ROWS = int(os.environ.get('FM_MAX_QUERY_ROWS', '1000000'))
_DB_FETCH_CHUNK = int(os.environ.get('FM_DB_FETCH_CHUNK', '50000'))

# Every (table_key, part) pair the dashboard renders as a browsable table.
# Used by the paging endpoint to validate its arguments - a request may only
# name a table that actually exists, never an arbitrary attribute.
TABLE_PARTS = {
    'source_table': ('processed', 'pending', 'excluded'),
    'intermediate_table': ('processed', 'pending'),
    'target_table': ('processed',),
    'same_name_transfers': (),
}


def _apply_display_columns(report, dataframes):
    """Subset each system table to the configured display columns (file name
    and date are always kept). Mutates *dataframes* in place.

    Column selection is report configuration, not view state, so it is applied
    once during analysis - the paging endpoint and the CSV export then serve
    exactly the columns the dashboard shows.
    """
    for prefix, table_key in (('source', 'source_table'),
                              ('intermediate', 'intermediate_table'),
                              ('target', 'target_table')):
        tbl = dataframes.get(table_key)
        if not isinstance(tbl, dict):
            continue
        display_names = [c['name'] for c in parse_display_config(report, prefix)]
        if not display_names:
            continue
        for key, df in list(tbl.items()):
            if df is None or not hasattr(df, 'columns'):
                continue
            cols = [c for c in ('application_file', 'SENT_DATE') if c in df.columns]
            cols += [n for n in display_names if n in df.columns and n not in cols]
            if cols:
                tbl[key] = df[cols]


def table_row_counts(dataframes):
    """True row count of every browsable table, keyed '<table>.<part>'.

    Recorded BEFORE any row cap so the tab badges and section headers can show
    what the data actually holds. Rendering the length of a capped frame is
    what made the tabs report 500 on a 12,000-row day.
    """
    counts = {}
    for table_key, parts in TABLE_PARTS.items():
        if not parts:
            df = dataframes.get(table_key)
            if df is not None and hasattr(df, '__len__'):
                counts[table_key] = len(df)
            continue
        tbl = dataframes.get(table_key)
        if not isinstance(tbl, dict):
            continue
        for part in parts:
            df = tbl.get(part)
            if df is not None and hasattr(df, '__len__'):
                counts[f'{table_key}.{part}'] = len(df)
    return counts


def capped_view(dataframes, metrics=None, max_rows=None):
    """Return a NEW dataframes mapping holding at most *max_rows* rows per
    table, leaving the full frames untouched.

    Non-mutating on purpose: the full frames stay available for the paging
    endpoint, the CSV export and the alert sweep. Truncation is recorded in
    *metrics* so the dashboard can say 'showing first N of M'.
    """
    max_rows = _MAX_TABLE_ROWS if max_rows is None else max_rows
    view = {}
    truncated = {}
    for key, value in dataframes.items():
        if isinstance(value, dict):
            part_view = {}
            for part, df in value.items():
                if df is not None and hasattr(df, '__len__') and len(df) > max_rows:
                    truncated[f'{key}.{part}'] = len(df)
                    part_view[part] = df.head(max_rows)
                else:
                    part_view[part] = df
            view[key] = part_view
        elif value is not None and hasattr(value, '__len__') and len(value) > max_rows:
            truncated[key] = len(value)
            view[key] = value.head(max_rows)
        else:
            view[key] = value

    if metrics is not None:
        metrics['table_truncated'] = truncated
        metrics['max_table_rows'] = max_rows
    return view


def _apply_display_and_row_cap(report, metrics, dataframes):
    """Back-compat shim: display columns + an in-place row cap.

    Kept for callers that want a single already-bounded result. The dashboard
    no longer uses it - it caps a view copy so the full frames survive for
    paging and export.
    """
    _apply_display_columns(report, dataframes)
    metrics['table_row_counts'] = table_row_counts(dataframes)
    dataframes.update(capped_view(dataframes, metrics))


def filter_table(df, query):
    """Rows of *df* whose rendered text contains *query* (case-insensitive).

    Mirrors what the old in-browser filter did to the rendered rows, except it
    runs over the WHOLE frame - the browser only ever held the first page.
    """
    if df is None or not hasattr(df, 'empty') or df.empty:
        return df
    term = str(query or '').strip().lower()
    if not term:
        return df
    haystack = None
    for col in df.columns:
        col_text = df[col].astype(str).str.lower()
        haystack = col_text if haystack is None else haystack.str.cat(col_text, sep=' ')
    if haystack is None:
        return df
    return df[haystack.str.contains(term, regex=False, na=False)]


def paginate_table(df, page=1, per_page=None, query=''):
    """One page of *df* as JSON-ready primitives, after a full-frame search.

    Returns (columns, rows, meta) where meta carries the total, the filtered
    total and the resolved page - everything the dashboard needs to render
    'showing 501-1000 of 12,340'.
    """
    # per_page comes from the query string. int() on a non-numeric value used
    # to raise straight out of the endpoint as a 500, and an enormous value
    # was honoured verbatim - so both are handled here.
    if per_page is None:
        per_page = _MAX_TABLE_ROWS
    else:
        try:
            per_page = int(per_page)
        except (TypeError, ValueError):
            per_page = _MAX_TABLE_ROWS
        per_page = min(max(1, per_page), _MAX_PAGE_ROWS)
    total = 0 if df is None or not hasattr(df, '__len__') else len(df)

    filtered_df = filter_table(df, query)
    filtered = 0 if filtered_df is None or not hasattr(filtered_df, '__len__') else len(filtered_df)

    pages = max(1, -(-filtered // per_page))  # ceil
    try:
        page = int(page)
    except (TypeError, ValueError):
        page = 1
    page = min(max(1, page), pages)

    if filtered_df is None or filtered == 0:
        columns = list(df.columns) if df is not None and hasattr(df, 'columns') else []
        rows = []
        start = 0
    else:
        start = (page - 1) * per_page
        window = filtered_df.iloc[start:start + per_page]
        columns = list(window.columns)
        rows = [['' if pd.isna(v) else str(v) for v in rec]
                for rec in window.itertuples(index=False, name=None)]

    meta = {
        'total': total,
        'filtered': filtered,
        'page': page,
        'pages': pages,
        'per_page': per_page,
        'first_row': start + 1 if rows else 0,
        'last_row': start + len(rows),
    }
    return columns, rows, meta


def parse_system_exclusions(report, system_prefix):
    """Per-system exclusion rules: [{'name': 'Non-UK', 'ref': 'REGION', 'values': 'EU,IE'}].

    'ref' is a column name (db) or split position (log). Rows without values
    are dropped; a blank ref means auto-detect (db systems only).
    """
    entries = []
    for e in _load_json_list(getattr(report, f'{system_prefix}_exclusion_config', None),
                             getattr(report, 'id', '?'), 'exclusion_config'):
        if not isinstance(e, dict):
            continue
        values = str(e.get('values') or '').strip()
        if not values:
            continue
        ref = str(e.get('ref') if e.get('ref') is not None else '').strip()
        name = str(e.get('name') or '').strip() or (ref or 'Rule')
        entries.append({'name': name, 'ref': ref, 'values': values})
    return entries


def _build_value_condition(exclude_values):
    """Build a Series->bool-mask function for a mixed list of exclusion values.

    Unlike the old engine (where the FIRST value decided the match type for the
    whole list), every value is classified independently, so 'report.usr,tmp_*'
    excludes both the exact name and the prefix in one rule.
    """
    exact, prefixes, suffixes, contains = set(), [], [], []
    for v in exclude_values:
        if '*' not in v:
            exact.add(v)
        elif v.startswith('*') and v.endswith('*') and len(v) > 2:
            contains.append(v.strip('*'))
        elif v.startswith('*'):
            suffixes.append(v[1:])                    # *.usr -> suffix
        elif v.endswith('*'):
            prefixes.append(v[:-1])                   # tmp_* -> prefix
        else:
            logging.warning(f"Unsupported wildcard format '{v}' in exclusion; "
                            f"value skipped.")

    def _condition(series):
        s = series.astype(str)
        cond = pd.Series(False, index=s.index)
        if exact:
            cond |= s.isin(exact)
        if prefixes:
            cond |= s.str.startswith(tuple(prefixes))
        if suffixes:
            cond |= s.str.endswith(tuple(suffixes))
        if contains:
            cond |= s.str.contains('|'.join(re.escape(t) for t in contains),
                                   na=False, regex=True)
        return cond

    return _condition


def _apply_exclusion_rule(df, rule):
    """Split *df* into (kept, excluded, matched_column) for one exclusion rule.

    When the rule names a column it is resolved case-insensitively and ONLY
    that column is tested - a rule for REGION can never accidentally drop rows
    because a filename happens to contain the same token. A blank column keeps
    the legacy auto-detect behaviour. Non-fatal by design: an empty spec, a
    missing column, or zero matches exclude nothing rather than raising.
    """
    excluded = df.iloc[0:0].copy()  # empty frame with the same columns
    values_spec = (rule or {}).get('values')
    if not values_spec or df.empty:
        return df, excluded, None

    exclude_values = [v.strip() for v in str(values_spec).split(',') if v.strip()]
    if not exclude_values:
        return df, excluded, None

    _condition = _build_value_condition(exclude_values)

    configured_col = (rule or {}).get('column') or ''
    if configured_col:
        matched_column = _find_column(df, configured_col)
        if matched_column is None:
            logging.warning(
                f"Exclusion rule column '{configured_col}' not present in the data "
                f"(columns: {list(df.columns)}); rule skipped.")
            return df, excluded, None
    else:
        # Auto-detect: first column where any value matches.
        matched_column = None
        for col in df.columns:
            if _condition(df[col]).any():
                matched_column = col
                break
        if matched_column is None:
            logging.info(f"Exclusion values {exclude_values} matched no column; "
                         f"nothing excluded.")
            return df, excluded, None

    condition = _condition(df[matched_column])
    excluded = df[condition].copy()
    kept = df[~condition].copy()
    return kept, excluded, matched_column


def _backfill_stats_from_downstream(source_df, inter_df, target_df):
    """Enrich source rows with file-type / flow-type info held only downstream.

    Some sources record just the file NAME; segregation into file type / flow
    type happens at the intermediate or destination system. Stats are matched
    by NAME across systems (source 'Flow Type' <- downstream 'Flow Type'):
    every stat column any downstream system carries is a candidate, and each
    one the source lacks (absent or entirely null) is looked up by filename
    from the intermediate first (closer to source), then the target. Returns
    (source_df, {'Flow Type': 'intermediate', ...}) naming what was filled
    from where; empty dict means the source already had the info or nobody has
    it (in which case the dashboard falls back to count-only charts).
    """
    filled_from = {}
    if source_df is None or source_df.empty or 'application_file' not in source_df.columns:
        return source_df, filled_from

    candidates = []
    for df in (inter_df, target_df):
        for col in _stat_columns(df):
            if col not in candidates:
                candidates.append(col)

    for col in candidates:
        if col in source_df.columns and source_df[col].notna().any():
            continue  # source already has real values
        for system_name, df in (('intermediate', inter_df), ('target', target_df)):
            if (df is None or df.empty or col not in df.columns
                    or 'application_file' not in df.columns or not df[col].notna().any()):
                continue
            mapping = (df.dropna(subset=[col])
                         .drop_duplicates(subset='application_file')
                         .set_index('application_file')[col])
            values = source_df['application_file'].map(mapping)
            if values.notna().any():
                source_df[col] = values
                filled_from[_stat_display(col)] = system_name
                break
    return source_df, filled_from


def _excluded_file_names(df):
    """File names present in an excluded slice, as a set of strings."""
    if df is None or not hasattr(df, 'columns') or 'application_file' not in df.columns:
        return set()
    names = df['application_file'].dropna().astype(str)
    return set(names) - {''}


# Values a monitored system uses to say "no date". Compared lower-cased, after
# stripping, so a CHAR column padded with spaces is recognised too.
_NULLISH_DATES = ('', 'nat', 'nan', 'none', 'null', '<na>')

# Bucket for records whose date could not be read at all. It is a GROUPING KEY,
# not a label: the dashboard renders it as a dash, because operators reasonably
# read a literal "UnknownDate" in a Date column as a data-quality defect in the
# monitored system rather than as this module failing to parse it.
UNKNOWN_DATE_KEY = 'UnknownDate'


def _format_is_day_first(date_format):
    """True when the configured strftime format puts the DAY before the month.

    Used to keep the inference fallback in _parse_sent_date consistent with
    what the operator configured: without it '01-08-2026' falls back to
    pandas' month-first default and silently becomes 8 January.
    """
    if not date_format:
        return False
    d, m = date_format.find('%d'), date_format.find('%m')
    return d != -1 and m != -1 and d < m


def _parse_sent_date(values, date_format=None):
    """Parse a SENT_DATE column to datetimes, honouring the report's format.

    The monitored date column is very often a STRING in the format the operator
    picked on the report - that is exactly why {start_date}/{end_date} are
    rendered in that format before they go into the WHERE clause. Letting
    pandas guess instead produced two silent production failures:

      * 'ddmmyyyy'  ('01082026')  -> NaT for EVERY row, which surfaced as
        'UnknownDate' in the Same Name File tab and emptied the trend charts;
      * 'dd-mm-yyyy' / 'dd/mm/yyyy' ('01-08-2026') -> parsed MONTH-first, so
        the tab reported the wrong date and duplicate groups were mis-matched
        (01/08 collided with 08/01).

    Order of attempts, each one applied only to the values still unparsed:
      1. real date/datetime objects are taken as-is (never stringified and
         re-guessed - that is what turned a driver-native date into 8 January);
      2. the configured format;
      3. pandas inference, day-first when the configured format is day-first;
      4. the leading whitespace-delimited token, which recovers a date carrying
         a trailing time pandas cannot read - notably Oracle's default
         '01-AUG-26 10.30.00.000000 AM'.

    A value none of those recover stays NaT, so one bad row can no longer cost
    the whole column its dates.
    """
    if values is None:
        return pd.Series(dtype='datetime64[ns]')
    series = values if isinstance(values, pd.Series) else pd.Series(values)
    if series.empty:
        return pd.to_datetime(series, errors='coerce')
    if pd.api.types.is_datetime64_any_dtype(series):
        return series  # already parsed by the driver - nothing to guess

    parsed = pd.Series(pd.NaT, index=series.index, dtype='datetime64[ns]')

    def _fill(candidate):
        """Take *candidate* only where nothing has been parsed yet."""
        if isinstance(candidate.dtype, pd.DatetimeTZDtype):
            # A mixed object column can yield offset-aware values, which
            # cannot be written into a naive result (and raised TypeError,
            # failing the whole read). Keep the wall-clock reading the
            # monitored system displays and drop the offset - this module
            # only ever compares and groups by calendar date.
            candidate = candidate.dt.tz_localize(None)
        todo = parsed.isna() & candidate.notna()
        if todo.any():
            parsed.loc[todo] = candidate[todo]

    native = series.map(lambda v: isinstance(v, date))
    if native.any():
        _fill(pd.to_datetime(series[native], errors='coerce'))

    text = series.astype(str).str.strip().mask(native | series.isna())
    text = text.mask(text.str.lower().isin(_NULLISH_DATES))

    if date_format:
        try:
            _fill(pd.to_datetime(text, format=date_format, errors='coerce'))
        except (ValueError, TypeError):
            logging.warning("Ignoring unusable date format %r while parsing "
                            "SENT_DATE.", date_format)

    day_first = _format_is_day_first(date_format)
    with warnings.catch_warnings():
        # Inference on a mixed column is expected here and already handled
        # row by row; pandas' "could not infer format" warning is noise.
        warnings.simplefilter('ignore')
        todo = parsed.isna() & text.notna()
        if todo.any():
            _fill(pd.to_datetime(text[todo], errors='coerce', dayfirst=day_first))
        todo = parsed.isna() & text.notna()
        if todo.any():
            _fill(pd.to_datetime(text[todo].str.split().str[0],
                                 errors='coerce', dayfirst=day_first))
    return parsed


def analyze_file_transfers(source_df, target_df, inter_df=None, exclude_data=None,
                           exclude_data1=None, exclusion_rules=None,
                           inter_exclusions=None, target_exclusions=None,
                           date_range=None, apply_exclusions_to_all=False,
                           date_formats=None):
    # Defensive: upstream getters may return None on a hard failure. Coerce to
    # empty frames so the analysis degrades gracefully instead of crashing.
    if source_df is None:
        source_df = _empty_file_df()
    if target_df is None:
        target_df = _empty_file_df()

    # {'source'|'intermediate'|'target': strftime format}. Each system stamps
    # SENT_DATE in its OWN format, so every read below parses with that
    # system's configured format rather than letting pandas guess.
    date_formats = date_formats or {}

    metrics = {}
    dataframes = {}
    plots = {}
    df_exclude = pd.DataFrame()

    # Normalise exclusion configuration into one rule list. Callers may pass a
    # ready-made rule list (dynamic per-report rules) and/or the legacy fixed
    # specs - both work, in that order.
    rules = list(exclusion_rules or [])
    for spec in (exclude_data, exclude_data1):
        if spec and str(spec).strip():
            rules.append({'column': '', 'values': str(spec).strip(), 'label': ''})

    # Downstream (intermediate/target) exclusions run FIRST. Their job is
    # different from source exclusions: a shared staging folder or warehouse
    # table often carries OTHER applications' files, and those rows must be
    # dropped before matching or they create phantom matches / inflated
    # counts. They are noise removal, not "excluded by design".
    downstream_excl = []
    # File names any downstream rule dropped. Only collected (and only used)
    # when the cross-system option is on - see the propagation pass below.
    downstream_excluded_names = set()
    if inter_df is not None and inter_exclusions:
        for rule in inter_exclusions:
            inter_df, ex, matched = _apply_exclusion_rule(inter_df, rule)
            downstream_excluded_names |= _excluded_file_names(ex)
            downstream_excl.append({'system': 'intermediate',
                                    'label': rule.get('label') or 'Rule',
                                    'column': matched or rule.get('column') or 'auto',
                                    'count': len(ex)})
    if target_exclusions:
        for rule in target_exclusions:
            target_df, ex, matched = _apply_exclusion_rule(target_df, rule)
            downstream_excluded_names |= _excluded_file_names(ex)
            downstream_excl.append({'system': 'target',
                                    'label': rule.get('label') or 'Rule',
                                    'column': matched or rule.get('column') or 'auto',
                                    'count': len(ex)})
    # Bound to metrics by reference: the cross-system pass below appends to
    # this same list once the source rules have run.
    metrics['downstream_exclusions'] = downstream_excl

    # File-type / flow-type backfill: when the source only knows the filename,
    # borrow the classification from the intermediate/target (matched by name)
    # BEFORE plots and exclusions run - so type-based exclusion rules work even
    # for type-blind sources.
    source_df, stat_backfill = _backfill_stats_from_downstream(source_df, inter_df, target_df)
    metrics['stat_backfill'] = stat_backfill

    def generate_combined_stat_plot(df, df_name, top_n=20):
        data = []
        buttons = []

        # Every named stat the system carries gets its own distribution,
        # switchable via the dropdown; labels use the configured display name.
        for col in _stat_columns(df):
            if df[col].notna().any():
                label = _stat_display(col)
                value_counts = df[col].value_counts().nlargest(top_n).reset_index()
                value_counts.columns = ['stat_value', 'count']

                bar = go.Bar(
                    x=value_counts['stat_value'],
                    y=value_counts['count'],
                    name=label,
                    visible=False,
                    text=value_counts['count'],
                    textposition='outside',
                    hovertemplate='<b>%{x}</b><br>Count: %{y}',
                    # Opaque, and deliberately so. This was rgba(58,71,80,.6);
                    # #899196 is that exact colour composited over the white
                    # card, so nothing on screen moves - but a translucent bar
                    # lets the gridlines behind it, and the shadow the premium
                    # treatment casts, print straight through, which reads as
                    # haze rather than depth. See npg_module.css, THE FIGURES.
                    marker=dict(color='#899196')
                )
                data.append(bar)

                visibility = [False] * len(data)
                visibility[-1] = True

                # The title travels with the selection, so it must keep the
                # same anchored/positioned form as the initial layout below -
                # a bare string would reset it to Plotly's centred default and
                # slide it back under the dropdown on the first switch.
                buttons.append(dict(
                    label=label,
                    method='update',
                    args=[{'visible': visibility},
                          {'title': _stat_plot_title(label, df_name)}]
                ))

        if not data:
            return None

        data[0].visible = True

        # Title and stat selector share the top margin, so they are pinned to
        # OPPOSITE corners and different heights. Previously both sat centred
        # at the top (title default x=0.5, menu x=0.5/y=1.2) and the dropdown
        # covered the graph name.
        layout = go.Layout(
            title=_stat_plot_title(data[0].name, df_name),
            xaxis=dict(title='Stat Value', tickangle=-45),
            yaxis=dict(title='Count'),
            updatemenus=[{
                'buttons': buttons,
                'direction': 'down',
                'showactive': True,
                'x': 1.0,
                'y': 1.10,
                'xanchor': 'right',
                'yanchor': 'top',
                'pad': {'r': 2, 't': 2},
            }],
            height=500,
            template='plotly_white',
            # Geometry half of the premium chart treatment in npg_module.css
            # ("THE FIGURES"): the stylesheet lights and grounds each bar, this
            # rounds it, so a bar reads as an object rather than a painted
            # rectangle. Needs plotly >= 5.19 (pinned at 6.7.0).
            barcornerradius=3,
            bargap=0.34,
            # Deep enough for the title row PLUS the selector row beneath it.
            margin=dict(t=120)
        )

        fig = go.Figure(data=data, layout=layout)
        return _fig_to_html(fig)

    def generate_processed_records_grouped_bar(data_dict):
        combined_df = []

        for system_name, df in data_dict.items():
            if df is None or df.empty or 'SENT_DATE' not in df.columns:
                continue

            df = df.copy()
            df['SENT_DATE'] = _parse_sent_date(df['SENT_DATE'],
                                               date_formats.get(system_name))
            df = df.dropna(subset=['SENT_DATE'])

            if df.empty:
                continue

            df['date'] = df['SENT_DATE'].dt.date
            grouped = df.groupby('date').size().reset_index(name='count')
            grouped['system'] = system_name
            combined_df.append(grouped)

        if not combined_df:
            return None

        full_df = pd.concat(combined_df)

        data = []
        systems = full_df['system'].unique()
        # Opaque equivalents of the old rgba(...,0.7) fills, composited over
        # the white card - same colour on screen, but nothing prints through.
        # See the note on the stat plot above.
        colors = {'source': '#4DA3FF', 'intermediate': '#69C17D',
                  'target': '#E6727D'}

        for system in systems:
            df_sys = full_df[full_df['system'] == system]
            trace = go.Bar(
                x=df_sys['date'],
                y=df_sys['count'],
                name=system.capitalize(),
                marker_color=colors.get(system, 'gray'),
                hovertemplate="<b>%{x}</b><br>%{y} records<extra>%{fullData.name}</extra>"
            )
            data.append(trace)

        layout = go.Layout(
            barmode='group',
            title='Processed Records Per Day by System',
            xaxis=dict(title='Date'),
            yaxis=dict(title='Record Count'),
            template='plotly_white',
            height=500,
            # See the note on the stat plot above - same treatment, so the two
            # trend views do not read as two different products.
            barcornerradius=3,
            bargap=0.3,
            bargroupgap=0.08,
            margin=dict(t=80)
        )

        fig = go.Figure(data=data, layout=layout)
        return _fig_to_html(fig)

    def generate_processed_records_line(data_dict, hourly):
        """Per-system trend as a line chart. Buckets are hours when the view
        is a single day (hourly=True), calendar days otherwise. Returns None
        when no frame carries usable SENT_DATE values."""
        combined = []
        for system_name, df in data_dict.items():
            if df is None or df.empty or 'SENT_DATE' not in df.columns:
                continue
            df = df.copy()
            df['SENT_DATE'] = _parse_sent_date(df['SENT_DATE'],
                                               date_formats.get(system_name))
            df = df.dropna(subset=['SENT_DATE'])
            if df.empty:
                continue
            df['bucket'] = df['SENT_DATE'].dt.floor('h') if hourly else df['SENT_DATE'].dt.date
            grouped = df.groupby('bucket').size().reset_index(name='count')
            grouped['system'] = system_name
            combined.append(grouped)

        if not combined:
            return None

        full_df = pd.concat(combined)
        colors = {'source': 'rgba(0, 123, 255, 0.9)', 'intermediate': 'rgba(40, 167, 69, 0.9)',
                  'target': 'rgba(220, 53, 69, 0.9)'}

        data = []
        for system in full_df['system'].unique():
            df_sys = full_df[full_df['system'] == system].sort_values('bucket')
            data.append(go.Scatter(
                x=df_sys['bucket'],
                y=df_sys['count'],
                mode='lines+markers',
                name=system.capitalize(),
                line=dict(color=colors.get(system, 'gray'), width=2),
                marker=dict(size=7),
                hovertemplate="<b>%{x}</b><br>%{y} records<extra>%{fullData.name}</extra>",
            ))

        layout = go.Layout(
            title='Records Per Hour by System' if hourly else 'Records Per Day by System',
            xaxis=dict(title='Hour' if hourly else 'Date'),
            yaxis=dict(title='Record Count', rangemode='tozero'),
            template='plotly_white',
            height=500,
            margin=dict(t=80),
        )
        return _fig_to_html(go.Figure(data=data, layout=layout))

    def check_and_generate_plots(df, df_name):
        plot_html = generate_combined_stat_plot(df, df_name)
        if plot_html:
            plots[f'{df_name}_stat_dropdown_plot'] = plot_html

    # Generate stat plots
    check_and_generate_plots(source_df, 'source')
    check_and_generate_plots(target_df, 'target')
    if inter_df is not None and not inter_df.empty:
        check_and_generate_plots(inter_df, 'intermediate')

    # Source Stats
    total_source = len(source_df)

    # Exclusion logic (any number of independent rules)
    # Some file types are produced at the source but, by application design, are
    # never meant to reach the destination. They are filtered out of the transfer
    # tracking here and surfaced separately as "Excluded Files" rather than being
    # mis-counted as "pending at source". A per-rule breakdown is kept so the
    # dashboard can show WHY each slice was excluded.
    df_exclude = source_df.iloc[0:0].copy()  # empty, same columns as source
    exclusion_breakdown = []
    for idx, rule in enumerate(rules, start=1):
        source_df, ex, matched_column = _apply_exclusion_rule(source_df, rule)
        exclusion_breakdown.append({
            'label': rule.get('label') or f"Rule {idx}",
            'column': matched_column or rule.get('column') or 'auto',
            'values': rule.get('values', ''),
            'count': len(ex),
        })
        if not ex.empty:
            df_exclude = pd.concat([df_exclude, ex], ignore_index=True)

    # Cross-system propagation ("apply exclusions to all systems").
    #
    # A system frequently records only the FILE NAME while the attribute an
    # exclusion is written against (region, flow type, ...) lives on another
    # system, so a rule configured where the attribute exists silently misses
    # the name-only system - the same file shows as excluded on one side and
    # pending on the other. When enabled, the union of the file names excluded
    # ANYWHERE is excluded EVERYWHERE, matched by name. It runs after every
    # configured rule so the union is complete, and it only ever removes rows
    # some rule already excluded - never a name nobody excluded.
    metrics['cross_system_exclusions'] = None
    if apply_exclusions_to_all:
        excluded_names = _excluded_file_names(df_exclude) | downstream_excluded_names
        propagated = {'names': len(excluded_names), 'source': 0,
                      'intermediate': 0, 'target': 0}
        if excluded_names:
            if not source_df.empty and 'application_file' in source_df.columns:
                mask = source_df['application_file'].astype(str).isin(excluded_names)
                if mask.any():
                    extra = source_df[mask].copy()
                    source_df = source_df[~mask].copy()
                    df_exclude = pd.concat([df_exclude, extra], ignore_index=True)
                    propagated['source'] = len(extra)
                    exclusion_breakdown.append({
                        'label': 'Excluded on another system',
                        'column': 'application_file',
                        'values': f'{len(excluded_names)} file name(s) excluded elsewhere',
                        'count': len(extra),
                    })
            for system_name, df in (('intermediate', inter_df), ('target', target_df)):
                if df is None or df.empty or 'application_file' not in df.columns:
                    continue
                mask = df['application_file'].astype(str).isin(excluded_names)
                if not mask.any():
                    continue
                kept = df[~mask].copy()
                propagated[system_name] = int(mask.sum())
                if system_name == 'intermediate':
                    inter_df = kept
                else:
                    target_df = kept
                downstream_excl.append({
                    'system': system_name,
                    'label': 'Excluded on another system',
                    'column': 'application_file',
                    'count': propagated[system_name],
                })
        metrics['cross_system_exclusions'] = propagated

    metrics['exclusion_breakdown'] = exclusion_breakdown

    # Source counts, kept unambiguous so source vs destination never confuse
    #   total_source  = every record seen at the source
    #   excluded      = removed by design (never meant to reach the destination)
    #   eligible      = total - excluded = the files that SHOULD reach the destination
    # All transfer percentages below are measured against ELIGIBLE, not total, so a
    # large set of by-design exclusions can't drag the "delivered %" down.
    metrics['total_source_records'] = total_source
    metrics['excluded_source_records'] = len(df_exclude)
    eligible_source = len(source_df)  # source_df has already had exclusions removed
    metrics['eligible_source_records'] = eligible_source

    # --- DUPLICATE FILE DETECTION (date-aware grouping) ---
    # A "DB duplicate" is one file name recorded more than once on the SAME
    # source date. Grouping is date-aware; the delivery check below is NOT
    # (see the allocation loop) because a copy legitimately lands downstream
    # on a later date.
    #
    # "|||" is the separator so file names containing underscores never
    # corrupt the date portion when the composite key is split again.
    _SEP = "|||"

    def create_date_key(df, date_format=None):
        # Extract just the date string to prevent cross-day mismatch issues.
        # Parsing goes through _parse_sent_date so the SOURCE system's own
        # configured format is honoured - guessing here is what turned a
        # 'ddmmyyyy' column into UnknownDate for every row in production.
        # Anything genuinely unreadable still groups under UNKNOWN_DATE_KEY,
        # which the dashboard renders as a dash rather than the raw token.
        if not df.empty and 'SENT_DATE' in df.columns:
            date_str = (_parse_sent_date(df['SENT_DATE'], date_format)
                        .dt.date.fillna(UNKNOWN_DATE_KEY).astype(str))
            return date_str + _SEP + df['application_file'].astype(str)
        elif not df.empty:
            return UNKNOWN_DATE_KEY + _SEP + df['application_file'].astype(str)
        return pd.Series(dtype=str)

    source_df['file_date_key'] = create_date_key(
        source_df, date_formats.get('source'))

    # Count duplicates based on Date + Filename combination
    source_counts = source_df['file_date_key'].value_counts()
    same_name_files = source_counts[source_counts > 1]

    metrics['total_same_name_files'] = len(same_name_files)
    metrics['total_records_with_same_name'] = int(same_name_files.sum())
    # --------------------------------------------------

    # Core Tracking logic (Still matched on application_file to allow safe cross-day transfers)
    if inter_df is not None and not inter_df.empty:
        source_to_inter_mask = source_df['application_file'].isin(inter_df['application_file'])
    else:
        source_to_inter_mask = source_df['application_file'].isin(target_df['application_file'])

    df_source_processed = source_df[source_to_inter_mask]
    df_source_pending = source_df[~source_to_inter_mask]
    df_source_excluded = df_exclude

    dataframes['source_table'] = {
        'processed': df_source_processed,
        'pending': df_source_pending,
        'excluded': df_source_excluded
    }

    metrics['transferred_to_inter_count'] = len(df_source_processed)
    metrics['transferred_to_inter_percent'] = (len(df_source_processed) / eligible_source) * 100 if eligible_source > 0 else 0
    metrics['pending_at_source_count'] = len(df_source_pending)
    metrics['pending_at_source_percent'] = (len(df_source_pending) / eligible_source) * 100 if eligible_source > 0 else 0
    metrics['Excluded_file'] = len(df_source_excluded)

    if inter_df is not None and not inter_df.empty:
        inter_base = inter_df[inter_df['application_file'].isin(df_source_processed['application_file'])]

        inter_to_target_mask = inter_base['application_file'].isin(
            target_df['application_file']) if not target_df.empty else pd.Series([False] * len(inter_base))
        df_inter_processed = inter_base[inter_to_target_mask]
        df_inter_pending = inter_base[~inter_to_target_mask]
        df_inter_excluded = pd.DataFrame(columns=inter_df.columns)

        dataframes['intermediate_table'] = {
            'processed': df_inter_processed,
            'pending': df_inter_pending,
            'excluded': df_inter_excluded
        }

        inter_base_len = len(inter_base)
        metrics['transferred_to_target_count'] = len(df_inter_processed)
        metrics['transferred_to_target_percent'] = (
                                                           len(df_inter_processed) / inter_base_len) * 100 if inter_base_len > 0 else 0
        metrics['pending_at_inter_count'] = len(df_inter_pending)
        metrics['pending_at_inter_percent'] = (
                                                      len(df_inter_pending) / inter_base_len) * 100 if inter_base_len > 0 else 0
    else:
        df_inter_base = df_source_processed

        inter_to_target_mask = df_inter_base['application_file'].isin(
            target_df['application_file']) if not target_df.empty else pd.Series([False] * len(df_inter_base))
        df_target_processed = target_df[target_df['application_file'].isin(
            df_inter_base['application_file'])] if not target_df.empty else pd.DataFrame(columns=target_df.columns)

        base_len = len(df_inter_base)
        metrics['transferred_to_target_count'] = len(df_target_processed)
        metrics['transferred_to_target_percent'] = (len(df_target_processed) / base_len) * 100 if base_len > 0 else 0

        metrics['pending_at_inter_count'] = None
        metrics['pending_at_inter_percent'] = None

        dataframes['intermediate_table'] = {
            'processed': pd.DataFrame(columns=source_df.columns),
            'pending': pd.DataFrame(columns=source_df.columns),
            'excluded': pd.DataFrame(columns=source_df.columns)
        }

    if inter_df is not None and not inter_df.empty:
        base_target_files = dataframes['intermediate_table']['processed']['application_file']
    else:
        base_target_files = df_source_processed['application_file']

    if target_df.empty:
        df_target_filtered = pd.DataFrame(columns=target_df.columns)
    else:
        df_target_filtered = target_df[target_df['application_file'].isin(base_target_files)]

    dataframes['target_table'] = {
        'processed': df_target_filtered
    }

    # --- DUPLICATE DELIVERY CHECK ---
    # duplicateFileName_DB  : file names recorded more than once on the same source date.
    # MissingDuplicatefiles : the subset of those where FEWER copies reached the
    #                         downstream system than the source DB recorded
    #                         (a copy overwritten or silently dropped on the wire).
    #
    # Delivery is matched BY FILE NAME across the whole window, exactly like the
    # main transfer tracking above - never by source-date + name. A copy sent at
    # 23:50 is routinely picked up the next day (the destination read even extends
    # one day past the window for this reason), and each system stamps its own
    # SENT_DATE with its own semantics and its own date format. Keying the
    # delivery check on the SOURCE date meant those legitimate cross-day copies
    # matched nothing downstream, so every duplicate group was reported as
    # "SFTP Total Loss" even though the operator could see both copies had
    # arrived. Date-aware GROUPING is kept (that is what a DB duplicate means);
    # only the delivery lookup is name-based.
    #
    # A name can be duplicated on one date and also appear on other dates in the
    # window, so downstream copies are ALLOCATED to that name's source dates in
    # date order (earliest first). Allocation runs over every source date group
    # for the name - not just the duplicated ones - so a single-copy day cannot
    # have its delivery counted twice, and the per-group numbers always add up to
    # the name's window totals.
    def _name_counts(df):
        if df is None or df.empty or 'application_file' not in df.columns:
            return {}
        return df['application_file'].astype(str).value_counts().to_dict()

    has_inter = inter_df is not None and not inter_df.empty
    inter_name_counts = _name_counts(inter_df) if has_inter else {}
    target_name_counts = _name_counts(target_df)

    # Source copies per (name, date), for the names that have a duplicate group.
    duplicate_names = set()
    dup_keys = set()
    for file_date_key in same_name_files.index:
        # Split on the unambiguous "|||" separator introduced in create_date_key.
        # Filenames may contain underscores, so the old "_" separator was unsafe.
        try:
            _date_part, _file_name = file_date_key.split(_SEP, 1)
        except ValueError:
            _file_name = file_date_key
        duplicate_names.add(_file_name)
        dup_keys.add(file_date_key)

    source_date_groups = {}  # name -> [(date, copies), ...] sorted by date
    if duplicate_names:
        dup_rows = source_df[source_df['application_file'].astype(str).isin(duplicate_names)]
        for file_date_key, copies in dup_rows['file_date_key'].value_counts().items():
            try:
                date_part, file_name = file_date_key.split(_SEP, 1)
            except ValueError:
                date_part, file_name = UNKNOWN_DATE_KEY, file_date_key
            source_date_groups.setdefault(file_name, []).append(
                (date_part, int(copies), file_date_key))
    for groups in source_date_groups.values():
        groups.sort(key=lambda g: g[0])

    same_name_list = []
    for file_name, groups in source_date_groups.items():
        remaining_inter = int(inter_name_counts.get(file_name, 0))
        remaining_target = int(target_name_counts.get(file_name, 0))
        for date_part, source_count, file_date_key in groups:
            # Earliest source date is served first: a name's downstream copies
            # cannot be credited to two different source dates.
            inter_count = min(source_count, remaining_inter)
            remaining_inter -= inter_count
            target_count = min(source_count, remaining_target)
            remaining_target -= target_count

            if file_date_key not in dup_keys:
                continue  # single-copy day: consumed its share, not a duplicate

            # MissingDuplicatefiles: fewer copies forwarded than the DB recorded.
            # Measured at the intermediate hop when one exists (that is the SFTP
            # layer), at the target otherwise.
            downstream_count = inter_count if has_inter else target_count
            sftp_dropped_copies = max(0, source_count - downstream_count)

            same_name_list.append({
                'date': date_part,
                'file_name': file_name,
                'source_count': source_count,  # duplicateFileName_DB: copies in source DB
                'inter_count': inter_count,
                'target_count': target_count,
                'sftp_dropped_copies': sftp_dropped_copies,  # MissingDuplicatefiles: copies lost on wire
                'missing_in_transit': sftp_dropped_copies > 0,
            })

    same_name_df = pd.DataFrame(same_name_list)
    if not same_name_df.empty:
        same_name_df = same_name_df.sort_values(
            ['missing_in_transit', 'date', 'file_name'],
            ascending=[False, True, True]).reset_index(drop=True)
    dataframes['same_name_transfers'] = same_name_df

    # Expose both headline metrics to the dashboard
    # duplicateFileName_DB  -> total_same_name_files (already set above)
    # MissingDuplicatefiles -> count of duplicate groups where SFTP dropped >=1 copy
    metrics['missing_duplicate_files'] = (
        int(same_name_df['missing_in_transit'].sum()) if not same_name_df.empty else 0
    )
    metrics['total_sftp_dropped_copies'] = (
        int(same_name_df['sftp_dropped_copies'].sum()) if not same_name_df.empty else 0
    )

    # Cleanup before returning dataframes: drop the temporary composite key
    # and strip the internal 'stat::' marker so tables show the configured
    # display names ('Flow Type', not 'stat::Flow Type').
    for name, df_dict in dataframes.items():
        if name != 'same_name_transfers':
            for key, df in df_dict.items():
                if 'file_date_key' in df.columns:
                    df.drop(columns=['file_date_key'], inplace=True)
                stat_renames = {c: _stat_display(c) for c in df.columns
                                if str(c).startswith(_STAT_PREFIX)}
                if stat_renames:
                    df.rename(columns=stat_renames, inplace=True)

    # Generate the grouped bar chart for processed records
    processed_data = {
        'source': dataframes['source_table']['processed'],
        'intermediate': dataframes['intermediate_table']['processed'],
        'target': dataframes['target_table']['processed']
    }

    bar_plot = generate_processed_records_grouped_bar(processed_data)
    if bar_plot:
        plots['processed_records_grouped_bar'] = bar_plot

    # Line variant of the same trend (the dashboard shows it by default with a
    # Line/Bar toggle). A single-day view buckets by HOUR - that only carries
    # signal when SENT_DATE has a time component; date-only data collapses to
    # one point, which the dashboard notes.
    single_day = bool(date_range and date_range[0] == date_range[1])
    line_plot = generate_processed_records_line(processed_data, hourly=single_day)
    if line_plot:
        plots['processed_records_line'] = line_plot
    metrics['trend_is_hourly'] = single_day

    return metrics, dataframes, plots


def _system_exclusion_rules(report, system_prefix):
    """Build analysis-ready exclusion rules for one system.

    Returns (rules, aliases). For LOG systems each rule's value was extracted
    into a column named after the rule during parsing (see get_log_data), so
    the rule targets that column. For DB systems the rule targets the
    configured column, with the configured filename / stat names aliased to
    their canonical internal forms (application_file / stat::<Name>) because
    the frames were renamed during fetch.
    """
    system_type = getattr(report, f'{system_prefix}_system_type', None)
    is_log = system_type is not None and system_type.value == 'log'

    aliases = {}
    fname_col = getattr(report, f'{system_prefix}_filename_column', None)
    if fname_col and str(fname_col).strip():
        aliases[str(fname_col).strip().upper()] = 'application_file'
    for cfg in parse_stats_config(report, system_prefix):
        canonical = _STAT_PREFIX + cfg['name']
        aliases[str(cfg['ref']).strip().upper()] = canonical
        aliases[cfg['name'].strip().upper()] = canonical

    rules = []
    for cfg in parse_system_exclusions(report, system_prefix):
        if is_log:
            column = cfg['name'] if cfg['ref'] else ''
        else:
            column = aliases.get(cfg['ref'].upper(), cfg['ref']) if cfg['ref'] else ''
        rules.append({'column': column, 'values': cfg['values'], 'label': cfg['name']})
    return rules, aliases


def get_file_flow_data(report, s_date_format, start_date, end_date, i_date_format, t_date_format):
    """Get file flow data for a report with date format handling.

    Returns the FULL frames - no row cap. Callers that render HTML pass the
    result through capped_view(); the alert sweep and the CSV export need
    every row (a 500-row cap here silently truncated both).
    """
    try:
        # Get data from each system with the respective date format
        source_data = get_system_data(report, 'source', s_date_format, start_date, end_date)

        # source_data=None
        intermediate_data = None
        if report.has_intermediate:
            intermediate_data = get_system_data(report, 'intermediate', i_date_format, start_date, end_date)
        target_data = get_system_data(report, 'target', t_date_format, start_date, end_date)
        # target_data=None

        # Per-system exclusion rules. Source rules also absorb the
        # report-level rules (settings page / legacy exclude_data slots),
        # translating any configured column names to their canonical forms.
        source_rules, source_aliases = _system_exclusion_rules(report, 'source')
        for rule in parse_exclusion_rules(report):
            col = (rule.get('column') or '').strip()
            if col:
                rule['column'] = source_aliases.get(col.upper(), col)
            source_rules.append(rule)

        inter_rules = []
        if report.has_intermediate:
            inter_rules, _ = _system_exclusion_rules(report, 'intermediate')
        target_rules, _ = _system_exclusion_rules(report, 'target')

        metrics, dataframes, plots = analyze_file_transfers(
            source_data, target_data, intermediate_data,
            exclusion_rules=source_rules,
            inter_exclusions=inter_rules,
            target_exclusions=target_rules,
            date_range=(start_date, end_date),
            apply_exclusions_to_all=bool(getattr(report, 'exclusion_apply_all', False)),
            # Each system stamps SENT_DATE in its own configured format; the
            # analysis must parse with the same format it queried with.
            date_formats={'source': s_date_format,
                          'intermediate': i_date_format,
                          'target': t_date_format},
        )

        # View shaping: configured display columns only. Runs AFTER analysis so
        # counts/matching always use the full data. The row cap is deliberately
        # NOT applied here - see the docstring.
        _apply_display_columns(report, dataframes)
        metrics['table_row_counts'] = table_row_counts(dataframes)

        # Per-system probe failures. An unreadable system returned an EMPTY
        # frame (so the analysis above didn't crash), but every number that
        # involves it is now suspect - the alert sweep refuses to email and
        # the dashboard shows a warning instead of silently misleading zeros.
        probe_errors = {}
        for system_name, df in (('source', source_data),
                                ('intermediate', intermediate_data),
                                ('target', target_data)):
            err = getattr(df, 'attrs', {}).get('probe_error') if df is not None else None
            if err:
                probe_errors[system_name] = str(err)[:300]
        metrics['probe_errors'] = probe_errors

        return metrics, dataframes, plots

    except Exception as e:
        logging.error(f"Error getting file flow data: {str(e)}")
        raise


# --- Short-lived analysis cache -------------------------------------------
# One dashboard view costs a full read of the monitored production databases
# and an SFTP log scan. Paging, searching and exporting the tables must not
# re-run that on every click, so a probe result is held briefly and reused.
#
# Deliberately modest: entries are keyed by (report, window) with NO user
# component (the dashboard is public and shows the same figures to everyone),
# the store is bounded and time-boxed, and a miss simply re-probes. It is
# process-local - behind IIS/FastCGI each worker keeps its own copy, which
# costs an extra probe on a cold worker and nothing else.
# Kept small on purpose: an entry holds whole result frames, so the ceiling is
# a memory budget, not a hit-rate dial. Raise FM_FLOW_CACHE_MAX only if the
# host has the headroom for it.
_FLOW_CACHE_TTL = int(os.environ.get('FM_FLOW_CACHE_TTL', '180'))       # seconds
_FLOW_CACHE_MAX = int(os.environ.get('FM_FLOW_CACHE_MAX', '4'))         # entries
_flow_cache = OrderedDict()
_flow_cache_lock = threading.Lock()
# key -> Lock, so concurrent misses for the SAME key share one probe.
_flow_inflight = {}


def _flow_cache_key(report, start_date, end_date):
    # updated_at is part of the key so editing a report's query, exclusions or
    # display columns takes effect on the next view instead of after the TTL.
    return (getattr(report, 'id', None), start_date, end_date,
            str(getattr(report, 'updated_at', '')))


def get_file_flow_data_cached(report, s_date_format, start_date, end_date,
                              i_date_format, t_date_format, refresh=False):
    """get_file_flow_data() with a short reuse window.

    Returns the same (metrics, dataframes, plots) triple. The cached frames are
    treated as READ-ONLY by callers - the dashboard caps a view copy rather
    than truncating them in place.
    """
    key = _flow_cache_key(report, start_date, end_date)

    def _lookup():
        now = time.time()
        with _flow_cache_lock:
            # Drop anything stale first so an idle worker cannot hold frames
            # for hours.
            for stale in [k for k, (ts, _) in _flow_cache.items()
                          if now - ts > _FLOW_CACHE_TTL]:
                _flow_cache.pop(stale, None)
            hit = _flow_cache.get(key)
            if hit is not None:
                _flow_cache.move_to_end(key)
                return hit[1]
        return None

    if not refresh:
        cached = _lookup()
        if cached is not None:
            return cached

    # Single-flight. Without this, every concurrent request that misses runs
    # its OWN full probe: several people opening the same dashboard, or the
    # page plus its paging and export calls, would each open a fresh set of
    # connections to the monitored production systems at the same moment.
    # Only the first caller probes; the rest wait and take its result.
    with _flow_cache_lock:
        probe_lock = _flow_inflight.get(key)
        if probe_lock is None:
            probe_lock = _flow_inflight[key] = threading.Lock()

    with probe_lock:
        # The winner has filled the cache by the time a waiter gets here.
        if not refresh:
            cached = _lookup()
            if cached is not None:
                return cached

        result = get_file_flow_data(report, s_date_format, start_date, end_date,
                                    i_date_format, t_date_format)

        with _flow_cache_lock:
            _flow_cache[key] = (time.time(), result)
            _flow_cache.move_to_end(key)
            while len(_flow_cache) > _FLOW_CACHE_MAX:
                _flow_cache.popitem(last=False)
            _flow_inflight.pop(key, None)

    return result


def invalidate_flow_cache(report_id=None):
    """Forget cached probes for one report (or all of them).

    Called after a settings change so an operator never has to wait out the
    TTL to see the effect of an exclusion rule they just saved.
    """
    with _flow_cache_lock:
        if report_id is None:
            _flow_cache.clear()
            return
        for key in [k for k in _flow_cache if k[0] == report_id]:
            _flow_cache.pop(key, None)


def resolve_table(dataframes, table, part=None):
    """Look up one browsable table by name, or None when it does not exist.

    Names are validated against TABLE_PARTS so a request can never reach an
    arbitrary key of the analysis result.
    """
    if table not in TABLE_PARTS:
        return None
    parts = TABLE_PARTS[table]
    if not parts:
        return dataframes.get(table)
    if part not in parts:
        return None
    tbl = dataframes.get(table)
    if not isinstance(tbl, dict):
        return None
    return tbl.get(part)


def _empty_file_df(probe_error=None):
    """Empty frame carrying the canonical columns the analysis expects.

    ``probe_error`` marks the frame as "empty because the PROBE FAILED", not
    "empty because there were no files". The distinction is critical for
    alerting: an unreachable target must not make every source file look
    pending (a false alert), and an unreachable source must not look like a
    clean day (a false all-clear). get_file_flow_data lifts the marker into
    metrics['probe_errors'].
    """
    df = pd.DataFrame(columns=['application_file', 'SENT_DATE'])
    if probe_error:
        df.attrs['probe_error'] = str(probe_error)
    return df


def _find_column(df, configured_name):
    """Resolve a configured column name against the frame case-insensitively.

    Returns the ACTUAL column name in df, or None when the name is blank or
    absent. Oracle uppercases unquoted identifiers while SQL Server keeps the
    query's casing, so exact comparison breaks one backend or the other.
    """
    if not configured_name:
        return None
    target = str(configured_name).strip().upper()
    for col in df.columns:
        if str(col).strip().upper() == target:
            return col
    return None


def _shift_date(date_str, days):
    """Add *days* to a 'YYYY-MM-DD' string, returning the same format. Tolerant of bad input."""
    try:
        return (datetime.strptime(date_str, '%Y-%m-%d') + timedelta(days=days)).strftime('%Y-%m-%d')
    except (TypeError, ValueError):
        return date_str


def get_system_data(report, system_prefix, date_format, start_date, end_date):
    """Get data from a specific system (source, intermediate, or target) considering the date format"""
    system_type = getattr(report, f'{system_prefix}_system_type')
    if system_type is None:
        return _empty_file_df()

    # Files created late on the final day (e.g. 23:00) are routinely processed by a
    # DOWNSTREAM system on the *next* calendar day. So when reading an intermediate
    # or destination system we extend the window by one day. The source window is
    # left exactly as the user selected. Matching is by filename, so a wider
    # downstream window can only recover late arrivals - it never inflates the
    # source total.
    eff_end_date = end_date
    if system_prefix in ('intermediate', 'target'):
        eff_end_date = _shift_date(end_date, 1)

    # Compare on the enum *value* (lowercase). The previous check tested .name
    # ('ORACLE'/'MSSQL'/'LOG') against a lowercase 'mssql', so MSSQL systems
    # never matched and silently returned no data.
    if system_type.value in ('oracle', 'mssql'):
        return get_database_data(report, system_prefix, date_format, start_date, eff_end_date)
    elif system_type.value == 'log':
        return get_log_data(report, system_prefix, date_format, start_date, eff_end_date)
    else:
        return _empty_file_df()


# ---------------------------------------------------------------------------
# Read-only query guard
# ---------------------------------------------------------------------------
# This module's central promise is that it only ever READS the monitored
# production systems. The configured per-report SQL is the one place that
# promise can be broken, so it is checked before every execution.
#
# The previous check was "starts with SELECT or WITH, and contains no
# semicolon". That is not enough on SQL Server, where a common table
# expression may PREFIX a data-modifying statement:
#
#     WITH c AS (SELECT id FROM files WHERE id < 100) DELETE FROM c
#     WITH c AS (SELECT * FROM files) UPDATE c SET name = 'x'
#     WITH c AS (SELECT 1 a) INSERT INTO audit SELECT a FROM c
#
# All three start with WITH, contain no semicolon, and delete or rewrite
# production data. T-SQL's SELECT ... INTO also creates a table. So the guard
# now also refuses any DML/DDL keyword appearing as a bare word.
#
# Literals, comments and quoted identifiers are stripped before the keyword
# scan so ordinary data can never trip it: a query selecting WHERE
# action = 'DELETE', or a column called "UPDATE", still runs.

_SQL_FORBIDDEN = (
    'INSERT', 'UPDATE', 'DELETE', 'MERGE', 'UPSERT', 'REPLACE',
    'DROP', 'TRUNCATE', 'ALTER', 'CREATE', 'RENAME',
    'GRANT', 'REVOKE', 'COMMIT', 'ROLLBACK', 'SAVEPOINT',
    'EXEC', 'EXECUTE', 'CALL', 'DECLARE', 'SET',
    # T-SQL's SELECT ... INTO <new table> materialises a table.
    'INTO',
)

_SQL_FORBIDDEN_RE = re.compile(
    r'\b(?:' + '|'.join(_SQL_FORBIDDEN) + r')\b', re.IGNORECASE)


def _strip_sql_noise(sql):
    """Remove comments, string literals and quoted identifiers from *sql*.

    What is left is the statement's structure, which is the only part the
    keyword scan should look at. Each removed span becomes a space so tokens
    on either side cannot be glued into a new word.
    """
    out = []
    i, n = 0, len(sql)
    while i < n:
        ch = sql[i]
        nxt = sql[i + 1] if i + 1 < n else ''
        if ch == '-' and nxt == '-':                     # -- line comment
            j = sql.find('\n', i)
            i = n if j < 0 else j
            out.append(' ')
        elif ch == '/' and nxt == '*':                   # /* block comment */
            j = sql.find('*/', i + 2)
            i = n if j < 0 else j + 2
            out.append(' ')
        elif ch == "'":                                  # 'string literal'
            i += 1
            while i < n:
                if sql[i] == "'":
                    if i + 1 < n and sql[i + 1] == "'":   # '' escape
                        i += 2
                        continue
                    i += 1
                    break
                i += 1
            out.append(' ')
        elif ch == '"':                                  # "quoted identifier"
            j = sql.find('"', i + 1)
            i = n if j < 0 else j + 1
            out.append(' ')
        elif ch == '[':                                  # [bracketed identifier]
            j = sql.find(']', i + 1)
            i = n if j < 0 else j + 1
            out.append(' ')
        else:
            out.append(ch)
            i += 1
    return ''.join(out)


def is_read_only_query(query):
    """(ok, reason) - whether *query* is a single read-only statement.

    Refuses anything that is not one plain SELECT / WITH...SELECT, so a
    configuration mistake (or a tampered report row) can never modify data on
    a monitored production system.
    """
    q = (query or '').strip().rstrip(';').strip()
    if not q:
        return False, 'query is empty'

    bare = _strip_sql_noise(q)

    if ';' in bare:
        return False, 'query contains more than one statement'
    if not bare.strip().upper().startswith(('SELECT', 'WITH')):
        return False, 'query is not a SELECT'

    found = _SQL_FORBIDDEN_RE.search(bare)
    if found:
        return False, "query contains '%s', which can modify data" % found.group(0).upper()
    return True, ''


def get_database_data(report, system_prefix, date_format, start_date, end_date):
    """Get data from a database system with date format applied"""
    try:

        system_type = getattr(report, f'{system_prefix}_system_type')
        connection_string = decrypt_password(getattr(report, f'{system_prefix}_connection_string'))
        username = getattr(report, f'{system_prefix}_username')
        password = decrypt_password(getattr(report, f'{system_prefix}_password'))
        sql_query = getattr(report, f'{system_prefix}_sql_query')
        filename_column = getattr(report, f'{system_prefix}_filename_column')

        # Replace date placeholders in query using the provided date format
        start_date_formatted = datetime.strptime(start_date, '%Y-%m-%d').strftime(date_format)
        end_date_formatted = datetime.strptime(end_date, '%Y-%m-%d').strftime(date_format)

        query = sql_query.replace('{start_date}', start_date_formatted)
        query = query.replace('{end_date}', end_date_formatted)

        # Production-data guard: this module only ever READS the monitored
        # systems. See is_read_only_query() - it refuses anything that is not
        # a single plain SELECT, including the WITH-prefixed DELETE/UPDATE/
        # INSERT/MERGE forms SQL Server accepts, so a configuration mistake
        # can never modify production data.
        ok, why = is_read_only_query(query)
        if not ok:
            logging.error(
                f"Refusing query for {system_prefix} "
                f"(report {getattr(report, 'id', '?')}): {why}; returning no data.")
            return _empty_file_df(
                probe_error=f'configured query is not a read-only SELECT ({why})')
        query = query.strip().rstrip(';').strip()

        # Open, query, and ALWAYS release the connection - even if the query raises.
        # A read-only fetch with a hard timeout so a slow/locked query can never
        # hold a session open against the production database.
        conn = None
        try:
            if system_type.value == 'oracle':
                oracle = _import_oracle()
                conn = oracle.connect(
                    user=username, password=password, dsn=connection_string)
                try:
                    conn.call_timeout = 60000  # ms - abort runaway queries
                except Exception:
                    pass
            else:  # mssql
                pyodbc = _import_pyodbc()
                conn = pyodbc.connect(connection_string, timeout=15)  # login timeout (s)
                try:
                    conn.timeout = 60  # query timeout (s)
                except Exception:
                    pass

            # Bounded fetch. pd.read_sql() with no limit materialises the
            # WHOLE result set in the calling process - an IIS worker for a
            # dashboard view, the scheduler thread for the alert sweep - so a
            # mis-scoped query or an unusually large day could exhaust the
            # host's memory. Reading in chunks lets us stop at a ceiling.
            #
            # Exceeding the ceiling is reported as a PROBE FAILURE, never a
            # silent truncation: a short frame would make files that exist
            # downstream look pending and fire a false alert. That is the same
            # rule _empty_file_df(probe_error=...) exists for.
            frames, rows = [], 0
            for chunk in pd.read_sql(query, conn, chunksize=_DB_FETCH_CHUNK):
                rows += len(chunk)
                if rows > _MAX_QUERY_ROWS:
                    logging.error(
                        "%s query for report %s returned more than %d rows; "
                        "refusing to load it all into memory. Narrow the "
                        "query or raise FM_MAX_QUERY_ROWS.",
                        system_prefix, getattr(report, 'id', '?'),
                        _MAX_QUERY_ROWS)
                    return _empty_file_df(
                        probe_error='query returned more than %d rows '
                                    '(FM_MAX_QUERY_ROWS)' % _MAX_QUERY_ROWS)
                frames.append(chunk)
            df = (pd.concat(frames, ignore_index=True) if frames
                  else pd.DataFrame())
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

        # Apply exclusions if configured
        # excluded_column = getattr(report, f'{system_prefix}_excluded_column')

        # excluded_values_json = getattr(report, f'{system_prefix}_excluded_values')

        # if excluded_column and excluded_values_json and excluded_column in df.columns:
        #    try:
        #        excluded_column=excluded_column.upper()
        #        excluded_values = json.loads(excluded_values_json)
        #        df = df[~df[excluded_column].isin(excluded_values)]
        #    except:
        #        pass  # Continue without exclusions if JSON parsing fails

        # Column names are matched case-insensitively: Oracle returns them
        # uppercase, but SQL Server preserves the case written in the query,
        # so a hard .upper() comparison silently missed MSSQL columns.
        actual_filename_col = _find_column(df, filename_column)
        if actual_filename_col:
            df = df.rename(columns={actual_filename_col: 'application_file'})
        if 'application_file' not in df.columns:
            # Without a filename column every downstream match is meaningless
            # (NaN names stringify to 'nan' and cross-match between systems),
            # so fail loudly with an empty frame instead of fabricating data.
            logging.error(
                f"Configured filename column '{filename_column}' not found in "
                f"{system_prefix} query result (columns: {list(df.columns)}); "
                f"returning no data for this system."
            )
            return _empty_file_df(
                probe_error=f"filename column '{filename_column}' not found in query result")

        # The date column is matched case-insensitively for the same reason as
        # the filename column: Oracle returns identifiers uppercased, but SQL
        # Server preserves the casing written in the query, so a query
        # selecting 'sent_date' produced a frame the analysis could not see -
        # every duplicate group then grouped under UNKNOWN_DATE_KEY and the
        # trend charts came back empty.
        actual_date_col = _find_column(df, 'SENT_DATE')
        if actual_date_col and actual_date_col != 'SENT_DATE':
            df = df.rename(columns={actual_date_col: 'SENT_DATE'})

        # 'application_file' and 'SENT_DATE' are STRUCTURAL: the analysis
        # matches, groups and charts on those exact names. A stat or display
        # field configured against one of them used to rename it away, which
        # silently removed the file name or the date from the whole analysis.
        structural = ('application_file', 'SENT_DATE')

        # Rename each configured named stat column (case-insensitive) to its
        # internal 'stat::<Name>' form. parse_stats_config already translated
        # the legacy primary/secondary fields when no JSON config exists.
        for cfg in parse_stats_config(report, system_prefix):
            actual = _find_column(df, cfg['ref'])
            if actual in structural:
                # Give the stat its own copy rather than moving the column.
                df[_STAT_PREFIX + cfg['name']] = df[actual]
            elif actual:
                df = df.rename(columns={actual: _STAT_PREFIX + cfg['name']})
            else:
                logging.warning(
                    f"Stat '{cfg['name']}': column '{cfg['ref']}' not found in "
                    f"{system_prefix} query result; stat skipped.")

        # Display fields keep their query column but wear the configured
        # display name; the table subset happens post-analysis.
        for cfg in parse_display_config(report, system_prefix):
            actual = _find_column(df, cfg['ref'])
            if actual in structural:
                # File name and date are always shown anyway (see
                # apply_display_columns), so the label is simply ignored.
                continue
            if actual and actual != cfg['name']:
                df = df.rename(columns={actual: cfg['name']})

        return df

    except Exception as e:
        logging.error(f"Error getting database data: {str(e)}")
        # Return an empty frame (not None) so the analysis degrades gracefully
        # instead of crashing - but MARKED as a probe failure so alerting and
        # the dashboard never mistake "could not read" for "no files".
        return _empty_file_df(probe_error=str(e))


##def extract_data_from_content(line, pattern):
#   """
#   Extract data from a log file line based on the provided pattern.

#    Args:
#        line (str): The line of text to search through.
#        pattern (str): The regular expression pattern to use for extraction.
#
#    Returns:
#        str: The extracted data, or None if no match was found.
#    """
#    regex_pattern=re.escape(pattern).replace(r'\{data\}',r'([^/]+)')
#    match = re.search(regex_pattern, line)
#    #logging.error(f"pattern : {pattern}")
#    #logging.error(f"regex : {regex_pattern}")
#    #logging.error(f"line : {line}")
#    if match:
#        return match.group(1)  # Return the matched string (or adjust this based on how you want to extract it)
#    return None


def get_log_data(report, system_prefix, date_format, start_date, end_date):
    """Get data from log files via SFTP, applying date format for file extraction and dynamic extraction logic."""
    try:
        # Get configuration attributes from the report object
        hostname = getattr(report, f'{system_prefix}_hostname', None)
        path = getattr(report, f'{system_prefix}_path', None)
        username = getattr(report, f'{system_prefix}_sftp_username', None)
        password = decrypt_password(getattr(report, f'{system_prefix}_sftp_password', None))
        file_naming_convention = getattr(report, f'{system_prefix}_file_naming_convention', None)
        file_extract_pattern = getattr(report, f'{system_prefix}_extraction_pattern', None)
        split_pattern = getattr(report, f'{system_prefix}_data_split', None)
        filename_position = getattr(report, f'{system_prefix}_data_fileName', None)
        filename_position = int(filename_position) if filename_position is not None else None

        def _to_pos(value, what):
            try:
                return int(str(value).strip())
            except (TypeError, ValueError):
                logging.warning(f"{what}: '{value}' is not a valid split position; skipped.")
                return None

        # Extraction plan: every NAMED stat becomes a 'stat::<Name>' column,
        # and every exclusion rule's position is extracted into a column named
        # after the rule so the standard value matcher can run against it.
        # (parse_stats_config translates the legacy *_stats_pattern field to a
        # 'primary_stat' entry when no JSON config exists.)
        extra_cols = []  # (output_column, position); first definition of a column wins
        _seen_cols = set()

        def _add_extra(col, pos):
            if pos is not None and col not in _seen_cols:
                _seen_cols.add(col)
                extra_cols.append((col, pos))

        for cfg in parse_stats_config(report, system_prefix):
            _add_extra(_STAT_PREFIX + cfg['name'],
                       _to_pos(cfg['ref'], f"Stat '{cfg['name']}'"))
        for cfg in parse_system_exclusions(report, system_prefix):
            if not cfg['ref']:
                continue  # no position -> rule will auto-detect at analysis time
            _add_extra(cfg['name'], _to_pos(cfg['ref'], f"Exclusion '{cfg['name']}'"))
        for cfg in parse_display_config(report, system_prefix):
            _add_extra(cfg['name'], _to_pos(cfg['ref'], f"Display field '{cfg['name']}'"))

        # Validate required configurations
        if not all([hostname, path, username, password, file_naming_convention, file_extract_pattern, split_pattern]):
            logging.error("Missing required configuration for log extraction.")
            return _empty_file_df(probe_error='missing required SFTP/log configuration')

        # Connect to SFTP. The whole session is wrapped in try/finally so the SSH
        # and SFTP channels are ALWAYS released - even if a read fails mid-way -
        # and never left open against the production server.
        ssh = None
        sftp = None
        filenames, file_dates = [], []
        extra_values = {col: [] for col, _pos in extra_cols}
        try:
            ssh = _connect_ssh(hostname, username, password, timeout=10)
            sftp = _open_sftp(ssh)
            files = sftp.listdir(path)

            # The downstream end_date+1 is applied upstream in get_system_data, so the
            # window here is used verbatim (inclusive of end_date).
            current_date = datetime.strptime(start_date, '%Y-%m-%d')
            end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')

            # Process each day's logs
            while current_date <= end_date_obj:
                date_str = current_date.strftime(date_format)
                expected_filename_part = file_naming_convention.replace('{date}', date_str)

                for file in files:
                    if expected_filename_part in file:
                        try:
                            # Stream line-by-line rather than read().decode() the whole
                            # file into memory - keeps memory flat on large prod logs.
                            with sftp.open(f"{path}/{file}", "r") as f:
                                f.prefetch()
                                for raw in f:
                                    line = raw.decode('utf-8', 'replace') if isinstance(raw, (bytes, bytearray)) else raw
                                    if file_extract_pattern in line:
                                        record_split = line.strip().split(split_pattern)

                                        # Validate filename position
                                        if filename_position is not None and len(record_split) > filename_position:
                                            transfer_file = record_split[filename_position].strip()
                                        else:
                                            continue  # skip malformed line

                                        filenames.append(transfer_file)
                                        file_dates.append(current_date)
                                        # Extract every configured stat /
                                        # exclusion field at its position;
                                        # short lines yield None for that field.
                                        for col, pos in extra_cols:
                                            if len(record_split) > pos:
                                                extra_values[col].append(record_split[pos].strip())
                                            else:
                                                extra_values[col].append(None)
                        except Exception as e:
                            logging.error(f"Error processing file {file}: {str(e)}")
                            continue
                current_date += pd.Timedelta(days=1)
        finally:
            if sftp is not None:
                try:
                    sftp.close()
                except Exception:
                    pass
            if ssh is not None:
                try:
                    ssh.close()
                except Exception:
                    pass

        if not filenames:
            logging.warning("No matching data found in logs.")
            return pd.DataFrame(columns=['application_file', 'SENT_DATE']
                                        + [col for col, _pos in extra_cols])

        result = {
            'application_file': filenames,
            'SENT_DATE': file_dates,
        }
        result.update(extra_values)
        return pd.DataFrame(result)

    except Exception as e:
        logging.error(f"Error getting log data: {str(e)}")
        return _empty_file_df(probe_error=str(e))