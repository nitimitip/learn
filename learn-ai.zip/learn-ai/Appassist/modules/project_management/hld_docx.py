"""
Project HLD -> professional Northern Powergrid-branded Word (.docx) document.

Mirrors the supplied "NPg HLD Template" design in print form, upgraded to
industry document standards:

  * full-page branded cover (masthead, title panel, metadata grid,
    confidentiality panel) with no header/footer on the cover page
  * real Word heading styles (outline levels) - sections appear in Word's
    navigation pane and feed a genuine, hyperlinked Table of Contents field
    that refreshes its page numbers automatically when opened in Word
  * document-control page (version / reviewers / approval)
  * print-grade tables: full-width, padded cells, header row repeated on
    every page, rows kept whole across page breaks, neutral gridlines with
    a brand-red header band
  * running header plus a "Page X of Y" footer with the classification
  * document properties (title / subject / author) for File -> Info

Sections the user marked "Not Required" are still listed, but their body is
replaced by a professional "not applicable for <project>" note. Section
guidance/instruction text is never written to the document.

Brand: NPg AppAssist index-hero red #9F1C33 (the index page's brand red).
"""

from __future__ import annotations

import io
from datetime import datetime

from docx import Document
from docx.shared import Pt, RGBColor, Mm, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from .models import hld_default_intro, flatten_hld_tree

# Brand palette
# Brand red is the NPg AppAssist index hero red (#9F1C33 - the index page's
# `--brand` colour). The deeper shades are darker tints of the same hue, kept
# consistent with the brand.
# Palette matched to the supplied design ("IS High Level Design v2_2"):
#   Title  -> navy   #17365D      Heading 1 -> red  #C00000
#   Heading 2/3 -> blue #4F81BD    content-table header -> red #C00000 (white text)
#   front-matter table header -> grey #D9D9D9 (dark text)   zebra band -> #F2F2F2
RED       = RGBColor(0x9F, 0x1C, 0x33)   # AppAssist theme red - Heading 1 / table header
RED_DEEP  = RGBColor(0x7E, 0x16, 0x28)   # darker red - borders / accents
RED_DARK  = RGBColor(0x5F, 0x0F, 0x1E)
NAVY      = RGBColor(0x17, 0x36, 0x5D)   # Title / cover panel
BLUE      = RGBColor(0x4F, 0x81, 0xBD)   # sub-section headings
BLUE_DEEP = RGBColor(0x38, 0x5D, 0x8A)   # darker blue - sub-heading numbers
INK       = RGBColor(0x1B, 0x1B, 0x20)
BODY      = RGBColor(0x33, 0x33, 0x3B)
MUTED     = RGBColor(0x6B, 0x6B, 0x75)
WHITE     = RGBColor(0xFF, 0xFF, 0xFF)
ROSE      = RGBColor(0xE8, 0xB4, 0xBE)   # soft rose tint for text on the red panel

# Section heading palette - Heading 1 in the AppAssist theme red, Heading 2-3 blue
HEADING_NUM      = RGBColor(0x7E, 0x16, 0x28)   # top-level section number
SECTION_TITLE    = RGBColor(0x9F, 0x1C, 0x33)   # main section name (Heading 1 red)
SUBSECTION_TITLE = RGBColor(0x4F, 0x81, 0xBD)   # sub-section name (Heading 2/3 blue)

RED_HEX      = "9F1C33"   # content-table header fill (AppAssist theme red)
RED_DEEP_HEX = "7E1628"   # content-table header border
NAVY_HEX     = "17365D"   # cover title panel
GREY_HDR_HEX = "D9D9D9"   # front-matter / document-control table header fill
GREY_BRD_HEX = "BFBFBF"   # border around grey header cells
TINT_HEX     = "EEF1F6"   # intro / note panel background (light blue-grey)
QA_TINT_HEX  = "F8EFF2"   # questionnaire response cell (theme red, heavily tinted)
BAND_HEX     = "F2F2F2"   # zebra band for table rows (matches the design)
BORDER_HEX   = "D7DEE7"   # neutral hairline (header/footer separators)
GRID_HEX     = "C9CFD8"   # table gridlines (data cells)

SANS  = "Calibri"
SERIF = "Georgia"
MONO  = "Consolas"

# Document kinds sharing this renderer. Every visible label that names the
# document type comes from here; the layout, palette and structure are
# identical for all kinds (the BRD deliberately reuses the HLD theme).
DOC_KINDS = {
    'hld': {
        'noun':        'High-Level Design',
        'abbr':        'HLD',
        'header':      'High-Level Design (HLD)',
        'cover_sub':   'Solution Architecture',
        'cover_title': 'High Level Design',
    },
    'brd': {
        'noun':        'Business Requirements Document',
        'abbr':        'BRD',
        'header':      'Business Requirements Document (BRD)',
        'cover_sub':   'Business Analysis',
        'cover_title':  'Business Requirements Document',
    },
    'ssia': {
        'noun':        'System Security Impact Assessment',
        'abbr':        'SSIA',
        'header':      'System Security Impact Assessment (SSIA)',
        'cover_sub':   'Information Security Assurance',
        'cover_title': 'System Security Impact Assessment',
    },
}


# Low-level XML helpers
def _shade(cell, hex_color):
    """Apply a solid background fill to a table cell."""
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), hex_color)
    tcPr.append(shd)


def _para_shade(paragraph, hex_color):
    """Apply a background fill behind a paragraph."""
    pPr = paragraph._p.get_or_add_pPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), hex_color)
    pPr.append(shd)


def _set_cell_borders(cell, color=GRID_HEX, sz=4, edges=('top', 'left', 'bottom', 'right')):
    """Thin borders on the given sides of a cell."""
    tcPr = cell._tc.get_or_add_tcPr()
    borders = OxmlElement('w:tcBorders')
    for edge in edges:
        el = OxmlElement(f'w:{edge}')
        el.set(qn('w:val'), 'single')
        el.set(qn('w:sz'), str(sz))
        el.set(qn('w:space'), '0')
        el.set(qn('w:color'), color)
        borders.append(el)
    tcPr.append(borders)


def _left_bar(paragraph, hex_color=RED_HEX, sz=18):
    """A coloured left border on a paragraph (used for note panels)."""
    pPr = paragraph._p.get_or_add_pPr()
    pbdr = OxmlElement('w:pBdr')
    left = OxmlElement('w:left')
    left.set(qn('w:val'), 'single')
    left.set(qn('w:sz'), str(sz))
    left.set(qn('w:space'), '8')
    left.set(qn('w:color'), hex_color)
    pbdr.append(left)
    pPr.append(pbdr)


def _para_edge_border(paragraph, edge, hex_color=BORDER_HEX, sz=6):
    """Thin top/bottom border on a paragraph (rules and separators)."""
    pPr = paragraph._p.get_or_add_pPr()
    pbdr = OxmlElement('w:pBdr')
    e = OxmlElement(f'w:{edge}')
    e.set(qn('w:val'), 'single')
    e.set(qn('w:sz'), str(sz))
    e.set(qn('w:space'), '4')
    e.set(qn('w:color'), hex_color)
    pbdr.append(e)
    pPr.insert(0, pbdr)   # pBdr must precede spacing/ind/tabs in OOXML


def _table_layout(table, *, full_width=True, pad_v=60, pad_h=110):
    """Full-width table with comfortable cell padding (print-grade)."""
    tblPr = table._tbl.tblPr
    if full_width:
        w = OxmlElement('w:tblW')
        w.set(qn('w:type'), 'pct')
        w.set(qn('w:w'), '5000')        # 100 %
        tblPr.append(w)
    mar = OxmlElement('w:tblCellMar')
    for edge, val in (('top', pad_v), ('bottom', pad_v), ('left', pad_h), ('right', pad_h)):
        e = OxmlElement(f'w:{edge}')
        e.set(qn('w:w'), str(val))
        e.set(qn('w:type'), 'dxa')
        mar.append(e)
    tblPr.append(mar)


def _repeat_header_row(row):
    """Mark a table row as a header that repeats at the top of every page."""
    trPr = row._tr.get_or_add_trPr()
    el = OxmlElement('w:tblHeader')
    el.set(qn('w:val'), 'true')
    trPr.append(el)


def _keep_row_together(row):
    """Stop a table row from splitting across a page break."""
    trPr = row._tr.get_or_add_trPr()
    trPr.append(OxmlElement('w:cantSplit'))


def _field(paragraph, instr, *, color=MUTED, size=8, bold=False):
    """Insert a live Word field (PAGE, NUMPAGES, ...)."""
    run = paragraph.add_run()
    run.font.name = SANS
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    begin = OxmlElement('w:fldChar'); begin.set(qn('w:fldCharType'), 'begin')
    text = OxmlElement('w:instrText'); text.set(qn('xml:space'), 'preserve'); text.text = instr
    end = OxmlElement('w:fldChar'); end.set(qn('w:fldCharType'), 'end')
    run._r.append(begin)
    run._r.append(text)
    run._r.append(end)


def _enable_update_fields(doc):
    """Ask Word to refresh all fields (incl. the TOC) when the file opens."""
    try:
        settings = doc.settings.element
    except AttributeError:      # very old python-docx - degrade gracefully
        return
    el = OxmlElement('w:updateFields')
    el.set(qn('w:val'), 'true')
    settings.append(el)


# Text helpers
def _run(paragraph, text, *, size=10.5, bold=False, italic=False,
         color=BODY, font=SANS):
    r = paragraph.add_run(text)
    r.font.name = font
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.italic = italic
    r.font.color.rgb = color
    return r


def _heading(doc, number, title, depth=0):
    """
    Numbered heading whose weight tracks the tree depth:
      depth 0 -> top-level section (large)
      depth 1 -> sub-section
      depth 2+ -> sub-sub-section

    Headings carry the real Word 'Heading N' style so they hold proper
    outline levels - they appear in Word's navigation pane and feed the
    auto-updating Table of Contents field. All visible formatting is set
    explicitly on the runs/paragraph, overriding the built-in style look.
    """
    sizes = {0: 16, 1: 13, 2: 11.5}
    size = sizes.get(depth, 11)
    p = doc.add_paragraph(style=f'Heading {min(depth + 1, 4)}')
    pf = p.paragraph_format
    pf.space_before = Pt(14 if depth == 0 else 8)
    # No left indent at any depth - heading numbers sit flush with the body
    # text below them, so content never starts left of its heading number.
    pf.left_indent = Mm(0)
    pf.keep_with_next = True
    title_color = SECTION_TITLE if depth == 0 else SUBSECTION_TITLE
    num_color   = HEADING_NUM if depth == 0 else BLUE_DEEP
    _run(p, f"{number}   ", size=size, bold=True, color=num_color, font=SERIF)
    _run(p, title, size=size, bold=True, color=title_color)
    pf.space_after = Pt(6 if depth == 0 else 4)
    return p


def _body_indent(depth):
    """
    Left indent for a section's body content so it starts under its heading's
    title text (just past the heading number), one step deeper per level:

        3   Context
            body text...
        3.1   References
              body text...
    """
    return Mm(6 + depth * 4)


def _intro(doc, text, depth=0):
    """The section's 'brief description' - plain intro paragraph."""
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_before = Pt(2)
    pf.space_after = Pt(8)
    pf.left_indent = _body_indent(depth)
    pf.keep_with_next = True
    _run(p, text, size=10, color=INK)


def _not_applicable(doc, project_name, depth=0, kind=None):
    kind = kind or DOC_KINDS['hld']
    p = doc.add_paragraph()
    _para_shade(p, TINT_HEX)
    _left_bar(p, RED_HEX)
    p.paragraph_format.left_indent = _body_indent(depth)
    p.paragraph_format.space_after = Pt(8)
    _run(p, "Not applicable. ", size=10, bold=True, color=RED_DEEP)
    _run(p,
         f"This section has been assessed and is not applicable for "
         f"{project_name}. No further detail is required within the scope of "
         f"this {kind['noun']}.",
         size=10, italic=True, color=MUTED)


def _table_section(doc, section_data, columns):
    """Render a table-style section: red header row + zebra data rows."""
    n_cols = len(columns)
    rows = section_data['rows']
    table = doc.add_table(rows=1, cols=n_cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    _table_layout(table)

    # header - brand red band, repeated on every page the table spans
    _repeat_header_row(table.rows[0])
    _keep_row_together(table.rows[0])
    hdr = table.rows[0].cells
    for i, col in enumerate(columns):
        _shade(hdr[i], RED_HEX)
        _set_cell_borders(hdr[i], color=RED_DEEP_HEX)
        cell_p = hdr[i].paragraphs[0]
        cell_p.paragraph_format.space_after = Pt(0)
        _run(cell_p, col['name'], size=9, bold=True, color=WHITE)

    # data
    if not rows:
        r = table.add_row()
        _keep_row_together(r)
        rc = r.cells
        a = rc[0]
        if n_cols > 1:
            a = a.merge(rc[n_cols - 1])
        _set_cell_borders(a)
        _run(a.paragraphs[0], "No entries recorded.", size=9, italic=True, color=MUTED)
    else:
        for ri, row in enumerate(rows):
            tr = table.add_row()
            _keep_row_together(tr)
            cells = tr.cells
            banded = (ri % 2 == 1)
            for ci, col in enumerate(columns):
                cell = cells[ci]
                _set_cell_borders(cell)
                if banded:
                    _shade(cell, BAND_HEX)
                cp = cell.paragraphs[0]
                cp.paragraph_format.space_after = Pt(0)
                value = row.get(str(col['id']), '') or ''
                # Render multi-line cell content (e.g. service-level tier
                # characteristics) as separate lines within the same cell.
                lines = value.split('\n')
                for li, ln in enumerate(lines):
                    r = _run(cp, ln, size=9, color=BODY)
                    if li < len(lines) - 1:
                        r.add_break()
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def _qa_section(doc, section_data):
    """
    Render one questionnaire entry the way the SSIA pro-forma does.

    An accent banner spanning the full width carries "Question N: <question>",
    and directly beneath it each answer row puts a short response
    classification in a tinted left cell and the supporting detail on the
    right. There is no numbered heading and no column-header row: in this
    layout the question IS the heading, which is why these entries are also
    left out of the table of contents.
    """
    columns = section_data['columns']
    n_cols = max(2, len(columns))
    rows = section_data['rows']

    table = doc.add_table(rows=1, cols=n_cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    _table_layout(table)

    # Banner: one merged cell carrying the question.
    banner = table.rows[0].cells[0]
    if n_cols > 1:
        banner = banner.merge(table.rows[0].cells[n_cols - 1])
    _keep_row_together(table.rows[0])
    _shade(banner, RED_HEX)
    _set_cell_borders(banner, color=RED_DEEP_HEX)
    bp = banner.paragraphs[0]
    bp.paragraph_format.space_after = Pt(0)
    _run(bp, f"Question {section_data['q_number']}: ", size=9.5, bold=True, color=WHITE)
    _run(bp, section_data['title'], size=9.5, bold=True, color=WHITE)

    answers = rows or [{}]
    for row in answers:
        tr = table.add_row()
        _keep_row_together(tr)
        cells = tr.cells
        for ci in range(n_cols):
            cell = cells[ci]
            _set_cell_borders(cell)
            cp = cell.paragraphs[0]
            cp.paragraph_format.space_after = Pt(0)
            col = columns[ci] if ci < len(columns) else None
            value = (row.get(str(col['id']), '') if col else '') or ''
            if ci == 0:
                # Response classification - tinted, bold, in the accent colour.
                _shade(cell, QA_TINT_HEX)
                if not value:
                    _run(cp, "Not recorded", size=9, italic=True, color=MUTED)
                    continue
                style = dict(size=9, bold=True, color=RED_DEEP)
            else:
                style = dict(size=9, color=BODY)
            lines = value.split('\n')
            for li, ln in enumerate(lines):
                run = _run(cp, ln, **style)
                if li < len(lines) - 1:
                    run.add_break()

    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def _qa_not_required(doc, section_data, project_name):
    """
    A 'Not Required' questionnaire entry.

    It stays in the pro-forma layout rather than becoming a prose note,
    because a reader scanning the questionnaire must be able to see at a
    glance that the question was reached and answered, not skipped.
    """
    columns = section_data['columns']
    answer = {}
    if len(columns) >= 2:
        answer = {
            str(columns[0]['id']): 'Not Applicable',
            str(columns[1]['id']): (
                f'This question has been assessed and is not applicable for '
                f'{project_name}.'),
        }
    _qa_section(doc, dict(section_data, rows=[answer] if answer else []))


def _no_entries_note(doc, depth=0):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = _body_indent(depth)
    p.paragraph_format.space_after = Pt(8)
    _run(p, "No entries recorded.", size=9, italic=True, color=MUTED)


def _block_table(doc, title, columns, rows, depth):
    """A captioned sub-table inside a structured entry (red header, zebra)."""
    cap = doc.add_paragraph()
    cap.paragraph_format.space_before = Pt(4)
    cap.paragraph_format.space_after = Pt(2)
    cap.paragraph_format.left_indent = _body_indent(depth)
    cap.paragraph_format.keep_with_next = True
    _run(cap, title, size=9.5, bold=True, color=NAVY)

    table = doc.add_table(rows=1, cols=len(columns))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    _table_layout(table)
    _repeat_header_row(table.rows[0])
    _keep_row_together(table.rows[0])
    hdr = table.rows[0].cells
    for i, name in enumerate(columns):
        _shade(hdr[i], RED_HEX)
        _set_cell_borders(hdr[i], color=RED_DEEP_HEX)
        cp = hdr[i].paragraphs[0]
        cp.paragraph_format.space_after = Pt(0)
        _run(cp, name, size=9, bold=True, color=WHITE)
    for ri, row in enumerate(rows):
        tr = table.add_row()
        _keep_row_together(tr)
        cells = tr.cells
        banded = (ri % 2 == 1)
        for ci in range(len(columns)):
            cell = cells[ci]
            _set_cell_borders(cell)
            if banded:
                _shade(cell, BAND_HEX)
            cp = cell.paragraphs[0]
            cp.paragraph_format.space_after = Pt(0)
            value = row[ci] if ci < len(row) else ''
            lines = (value or '').split('\n')
            for li, ln in enumerate(lines):
                r = _run(cp, ln, size=9, color=BODY)
                if li < len(lines) - 1:
                    r.add_break()
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def _block_section(doc, section_data):
    """
    Render a structured-entries section: each entry becomes its own headed
    block ("BR-1   <title>") with labelled paragraph fields and, where the
    config defines them, captioned sub-tables (use-case flows etc.).
    """
    cfg = section_data['block']
    entries = section_data['blocks']
    depth = min(section_data['depth'] + 1, 3)
    if not entries:
        _no_entries_note(doc, section_data['depth'])
        return

    prefix = cfg.get('prefix') or 'ITEM'
    fields = cfg.get('fields') or []
    tables = cfg.get('tables') or []
    for i, entry in enumerate(entries, start=1):
        values = entry.get('fields') or {}
        title = (values.get('title') or '').strip() or cfg.get('item_label', '')
        _heading(doc, f'{prefix}-{i}', title, depth)
        for f in fields:
            key = f.get('key')
            if key == 'title':
                continue          # already shown in the entry heading
            value = (values.get(key) or '').strip()
            if not value:
                continue
            if f.get('type') == 'text':
                p = doc.add_paragraph()
                p.paragraph_format.left_indent = _body_indent(depth)
                p.paragraph_format.space_after = Pt(4)
                _run(p, f"{f.get('label', key)}:  ", size=10, bold=True, color=NAVY)
                _run(p, value, size=10, color=BODY)
            else:
                lbl = doc.add_paragraph()
                lbl.paragraph_format.left_indent = _body_indent(depth)
                lbl.paragraph_format.space_before = Pt(4)
                lbl.paragraph_format.space_after = Pt(1)
                lbl.paragraph_format.keep_with_next = True
                _run(lbl, f.get('label', key), size=9.5, bold=True, color=BLUE_DEEP)
                _narrative_section(doc, value, depth)
        entry_tables = entry.get('tables') or {}
        for t in tables:
            rows = entry_tables.get(t.get('key')) or []
            if rows:
                _block_table(doc, t.get('title', ''), t.get('columns') or [],
                             rows, depth)


def _narrative_section(doc, content, depth=0):
    if not content:
        return
    indent = _body_indent(depth)
    for block in content.split('\n'):
        block = block.strip()
        if not block:
            continue
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(4)
        if block.startswith(('- ', '* ', '* ')):
            p.style = doc.styles['List Bullet']
            _run(p, block[2:].strip(), size=10.5, color=BODY)
        else:
            _run(p, block, size=10.5, color=BODY)
        p.paragraph_format.left_indent = indent


# Cover page
def _panel_cell(doc):
    """A borderless 1x1 table used as a padded panel container."""
    t = doc.add_table(rows=1, cols=1)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    _table_layout(t, pad_v=220, pad_h=320)
    return t.rows[0].cells[0]


def _kv_table(doc, pairs, *, label_w=Mm(48), value_w=Mm(120)):
    """A borderless label/value grid with hairline separators between rows."""
    t = doc.add_table(rows=0, cols=2)
    _table_layout(t, pad_v=90, pad_h=40)
    for label, value in pairs:
        row = t.add_row()
        _keep_row_together(row)
        cells = row.cells
        cells[0].width = label_w
        cells[1].width = value_w
        # Grey-shaded label column with a full hairline grid - matches the
        # design's two-column front-matter tables.
        _shade(cells[0], GREY_HDR_HEX)
        _set_cell_borders(cells[0], color=GREY_BRD_HEX, sz=4)
        _set_cell_borders(cells[1], color=GREY_BRD_HEX, sz=4)
        kp = cells[0].paragraphs[0]
        kp.paragraph_format.space_after = Pt(0)
        _run(kp, label, size=9, bold=True, color=INK)
        vp = cells[1].paragraphs[0]
        vp.paragraph_format.space_after = Pt(0)
        _run(vp, value or "-", size=10.5, color=INK)
    return t


def _cover(doc, project_name, status_text=None, kind=None):
    kind = kind or DOC_KINDS['hld']
    # Masthead: brand wordmark | product line, with a hairline rule
    section = doc.sections[0]
    content_w = section.page_width - section.left_margin - section.right_margin
    mast = doc.add_paragraph()
    mast.paragraph_format.tab_stops.add_tab_stop(content_w, WD_TAB_ALIGNMENT.RIGHT)
    mast.paragraph_format.space_after = Pt(0)
    _run(mast, "NORTHERN POWERGRID", size=11, bold=True, color=RED, font=SERIF)
    _para_edge_border(mast, 'bottom', hex_color=RED_HEX, sz=10)

    sp = doc.add_paragraph()
    sp.paragraph_format.space_after = Pt(26)

    # Title panel: the design's four title lines, branded
    #   Information Systems / <System Name> / Solution Architecture / High Level Design
    cell = _panel_cell(doc)
    _shade(cell, RED_HEX)
    _set_cell_borders(cell, color=RED_DEEP_HEX, sz=8, edges=('bottom',))

    eyebrow = cell.paragraphs[0]
    eyebrow.alignment = WD_ALIGN_PARAGRAPH.CENTER
    eyebrow.paragraph_format.space_after = Pt(12)
    _run(eyebrow, "I N F O R M A T I O N   S Y S T E M S", size=9, bold=True, color=ROSE)

    tp = cell.add_paragraph()
    tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    tp.paragraph_format.space_after = Pt(12)
    _run(tp, project_name.upper(), size=28, bold=True, color=WHITE, font=SERIF)

    sub = cell.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub.paragraph_format.space_after = Pt(2)
    _run(sub, kind['cover_sub'], size=13, italic=True, color=ROSE, font=SERIF)
    sub2 = cell.add_paragraph()
    sub2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub2.paragraph_format.space_after = Pt(0)
    _run(sub2, kind['cover_title'], size=15, bold=True, color=WHITE, font=SERIF)

    sp = doc.add_paragraph()
    sp.paragraph_format.space_after = Pt(22)

    # Title-page metadata: Date / Version / Classification
    _kv_table(doc, [
        ("Date", datetime.now().strftime("%d %B %Y")),
        ("Version", ""),
        ("Classification", "Confidential - NPg Internal Use Only"),
    ])

    sp = doc.add_paragraph()
    sp.paragraph_format.space_after = Pt(14)

    # Document Control block (status / ownership / review cadence)
    lbl = doc.add_paragraph()
    lbl.paragraph_format.space_after = Pt(4)
    _run(lbl, "DOCUMENT CONTROL", size=9, bold=True, color=RED_DEEP)
    _para_edge_border(lbl, 'bottom', hex_color=BORDER_HEX)
    _kv_table(doc, [
        ("Document Status", status_text or ""),
        ("Author(s)", "Northern Powergrid - AppAssist"),
        ("Business Owner", "Northern Powergrid"),
        ("Document Location", ""),
        ("Document internal review", "1 year after initial publication"),
        ("Document external review", "3 years after publication"),
    ])

    sp = doc.add_paragraph()
    sp.paragraph_format.space_after = Pt(16)

    # Confidentiality panel
    conf = doc.add_paragraph()
    _para_shade(conf, TINT_HEX)
    _left_bar(conf, RED_HEX)
    conf.paragraph_format.left_indent = Mm(2)
    _run(conf, "CONFIDENTIAL  ", size=8, bold=True, color=RED_DEEP)
    _run(conf,
         "This document contains proprietary information of Northern Powergrid "
         "and is intended for internal use only. It must not be reproduced or "
         "distributed, in whole or in part, without prior written consent. "
         "Printed copies are only valid on the date they were printed.",
         size=8, color=MUTED)

    doc.add_page_break()


# Page header / footer
def _setup_page(doc, project_name, kind=None):
    kind = kind or DOC_KINDS['hld']
    """
    Medium page margins plus a running header/footer on every page except
    the cover:
      header -> project name (left) - document type (right)
      footer -> classification (left) - Page X of Y, Northern Powergrid (right)
    """
    section = doc.sections[0]
    section.top_margin    = Inches(1.0)
    section.bottom_margin = Inches(1.0)
    section.left_margin   = Inches(0.9)
    section.right_margin  = Inches(0.9)
    # "Medium, not wide" header/footer band - distance from the page edge.
    section.header_distance = Inches(0.4)
    section.footer_distance = Inches(0.4)
    # the cover page carries no header/footer
    section.different_first_page_header_footer = True

    content_w = section.page_width - section.left_margin - section.right_margin

    # Header: project name (left) | document type (right)
    header = section.header
    header.is_linked_to_previous = False
    hp = header.paragraphs[0]
    hp.text = ''
    hp.paragraph_format.tab_stops.add_tab_stop(content_w, WD_TAB_ALIGNMENT.RIGHT)
    _run(hp, project_name.upper(), size=8, bold=True, color=RED_DEEP)
    _run(hp, '\t', size=8)
    _run(hp, kind['header'], size=8, color=MUTED)
    _para_edge_border(hp, 'bottom')

    # Footer: classification (left) | Page X of Y - brand (right)
    footer = section.footer
    footer.is_linked_to_previous = False
    fp = footer.paragraphs[0]
    fp.text = ''
    fp.paragraph_format.tab_stops.add_tab_stop(content_w, WD_TAB_ALIGNMENT.RIGHT)
    _run(fp, 'Confidential - NPg Internal Use Only', size=8, color=MUTED)
    _run(fp, '\t', size=8)
    _run(fp, 'Page ', size=8, color=MUTED)
    _field(fp, 'PAGE')
    _run(fp, ' of ', size=8, color=MUTED)
    _field(fp, 'NUMPAGES')
    _run(fp, '   -   ', size=8, color=MUTED)
    _run(fp, 'Northern Powergrid', size=8, bold=True, color=RED_DEEP)
    _para_edge_border(fp, 'top')


# Document control (Version / Reviewers / Approval)
def _subhead(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.keep_with_next = True
    _run(p, text, size=12.5, bold=True, color=NAVY)


def _blank_table(doc, headers, n_rows=4, rows=None):
    """
    A bordered, grey-header document-control table. Rows supplied in `rows`
    (a list of value tuples, blanks allowed within a tuple) are pre-filled;
    `n_rows` further empty rows are then added for manual completion.
    """
    rows = rows or []
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    _table_layout(table)
    _repeat_header_row(table.rows[0])
    hdr = table.rows[0].cells
    for i, h in enumerate(headers):
        _shade(hdr[i], GREY_HDR_HEX)
        _set_cell_borders(hdr[i], color=GREY_BRD_HEX)
        cp = hdr[i].paragraphs[0]
        cp.paragraph_format.space_after = Pt(0)
        _run(cp, h, size=9, bold=True, color=INK)
    total = len(rows) + max(0, n_rows)
    for r in range(total):
        values = rows[r] if r < len(rows) else None
        row = table.add_row()
        _keep_row_together(row)
        cells = row.cells
        banded = (r % 2 == 1)
        for i in range(len(headers)):
            _set_cell_borders(cells[i])
            if banded:
                _shade(cells[i], BAND_HEX)
            cp = cells[i].paragraphs[0]
            cp.paragraph_format.space_before = Pt(3)
            cp.paragraph_format.space_after = Pt(3)
            text = str(values[i]) if values and i < len(values) and values[i] is not None else ''
            _run(cp, text, size=9, color=BODY)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def _page_title(doc, text):
    """Large serif page title with the brand-red rule (Doc Control / TOC)."""
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.keep_with_next = True
    _run(p, text, size=18, bold=True, color=INK, font=SERIF)
    _para_edge_border(p, 'bottom', hex_color=RED_HEX, sz=12)
    return p


def _control_note(doc, text):
    """A short muted note under a Document-Control sub-heading."""
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    _run(p, text, size=9, italic=True, color=MUTED)


def _doc_control(doc):
    """
    Document-control page mirroring the design's front matter: Revision History,
    Approved By, Distribution, Glossary, Related Documents and Appendices -
    rendered with the branded blank-table style for manual completion.
    """
    _page_title(doc, "Document Control")
    _control_note(doc, "Printed copies are only valid on the date they were printed.")

    today = datetime.now().strftime("%d %b %Y")
    _subhead(doc, "Revision History")
    _blank_table(doc, ["Version", "Author", "Summary of Changes", "Date"],
                 n_rows=3,
                 rows=[
                     ("0.1", "AppAssist", "Initial draft", today),
                     ("1.0", "", "First published version", ""),
                 ])

    _subhead(doc, "Approved By")
    _control_note(doc, "The individual who gave final approval of each published version of the document.")
    _blank_table(doc, ["Version", "Name", "Role / Job Title", "Date Approved"],
                 n_rows=1,
                 rows=[
                     ("", "", "Solution Architect", ""),
                     ("", "", "Design Authority", ""),
                     ("", "", "Security Architect", ""),
                     ("", "", "Business Owner", ""),
                 ])

    _subhead(doc, "Distribution")
    _control_note(doc, "The latest approved version of this document has been distributed to:")
    _blank_table(doc, ["Function", "Name", "Roles"],
                 n_rows=1,
                 rows=[
                     ("Solution Architecture", "", "Solution Architect"),
                     ("Infrastructure", "", "Infrastructure Lead"),
                     ("Information Security", "", "Security Architect"),
                     ("Project Management", "", "Project Manager"),
                     ("Application Support", "", "Application Owner"),
                 ])

    _subhead(doc, "Glossary")
    _blank_table(doc, ["Abbreviation / Acronym", "Definition"],
                 n_rows=2,
                 rows=[
                     ("HLD", "High Level Design"),
                     ("LLD", "Low Level Design"),
                     ("NPg", "Northern Powergrid"),
                     ("BHE", "Berkshire Hathaway Energy"),
                     ("SLA", "Service Level Agreement"),
                     ("DR", "Disaster Recovery"),
                     ("BCP", "Business Continuity Plan"),
                     ("RTO", "Recovery Time Objective"),
                     ("RPO", "Recovery Point Objective"),
                     ("RAID", "Risks, Assumptions, Issues and Dependencies"),
                     ("DPIA", "Data Protection Impact Assessment"),
                     ("ESB", "Enterprise Service Bus"),
                     ("SSO", "Single Sign-On"),
                     ("MFA", "Multi-Factor Authentication"),
                     ("PAM", "Privileged Access Management"),
                     ("PKI", "Public Key Infrastructure"),
                     ("SIEM", "Security Information and Event Management"),
                     ("SOC", "Security Operations Centre"),
                     ("SAN", "Storage Area Network"),
                     ("WAN", "Wide Area Network"),
                     ("LAN", "Local Area Network"),
                     ("CIS", "Center for Internet Security"),
                 ])

    _subhead(doc, "Related Documents")
    _control_note(doc, "Cite document name, location, author and version, and a URL where available.")
    _blank_table(doc, ["Title", "Purpose", "Version"], 3)

    _subhead(doc, "Appendices")
    _blank_table(doc, ["Title", "Purpose", "Version"], 3)

    doc.add_page_break()


def _doc_control_brd(doc):
    """
    BRD document-control page mirroring the supplied BRD template's front
    matter: Revision History, Reviewers, Approvals / Sign-off, Distribution
    List and Related Documents & References - rendered with the same branded
    blank-table style as the HLD.
    """
    _page_title(doc, "Document Control")
    _control_note(doc, "Baseline the version once approved; increment the major number on re-baselining.")

    today = datetime.now().strftime("%d %b %Y")
    _subhead(doc, "Revision History")
    _control_note(doc, "Log every change to this document.")
    _blank_table(doc, ["Version", "Date", "Author", "Change Description", "Status"],
                 n_rows=3,
                 rows=[
                     ("0.1", today, "AppAssist", "Initial draft", "Draft"),
                     ("1.0", "", "", "First approved baseline", ""),
                 ])

    _subhead(doc, "Reviewers")
    _control_note(doc, "List every stakeholder who reviewed the document prior to approval.")
    _blank_table(doc, ["Name", "Role / Title", "Department", "Date Reviewed"], 4)

    _subhead(doc, "Approvals / Sign-off")
    _control_note(doc, "Formal approval signifies acceptance of the requirements baseline. "
                       "Obtain sign-off from each accountable authority.")
    _blank_table(doc, ["Approver Name", "Role", "Signature", "Date"],
                 n_rows=1,
                 rows=[
                     ("", "Project Sponsor", "", ""),
                     ("", "Business Owner", "", ""),
                     ("", "Lead Business Analyst", "", ""),
                     ("", "Solution Architect", "", ""),
                 ])

    _subhead(doc, "Distribution List")
    _blank_table(doc, ["Name / Group", "Role", "Format (Soft/Hard)"],
                 n_rows=1,
                 rows=[
                     ("Business Sponsor", "Sponsor", "Soft"),
                     ("Business Analysis", "Business Analyst", "Soft"),
                     ("Solution Architecture", "Solution Architect", "Soft"),
                     ("Project Management", "Project Manager", "Soft"),
                 ])

    _subhead(doc, "Glossary")
    _blank_table(doc, ["Abbreviation / Acronym", "Definition"],
                 n_rows=2,
                 rows=[
                     ("BRD", "Business Requirements Document"),
                     ("BR", "Business Requirement"),
                     ("FR", "Functional Requirement"),
                     ("NFR", "Non-Functional Requirement"),
                     ("KPI", "Key Performance Indicator"),
                     ("MoSCoW", "Must / Should / Could / Won't prioritisation"),
                     ("RACI", "Responsible, Accountable, Consulted, Informed"),
                     ("RTM", "Requirements Traceability Matrix"),
                     ("UC", "Use Case"),
                     ("UAT", "User Acceptance Testing"),
                     ("SME", "Subject Matter Expert"),
                     ("NPV", "Net Present Value"),
                     ("ROI", "Return on Investment"),
                     ("BPMN", "Business Process Model and Notation"),
                     ("NPg", "Northern Powergrid"),
                 ])

    _subhead(doc, "Related Documents & References")
    _control_note(doc, "Cite document name, location, author and version, and a URL where available.")
    _blank_table(doc, ["Ref #", "Document Name", "Version", "Location / Link"], 3)

    doc.add_page_break()


def _doc_control_ssia(doc):
    """
    SSIA document-control page mirroring the security pro-forma's front matter:
    the governance header block, Revision History, Approved By, Distribution
    List, Glossary and Related Documents - rendered with the same branded
    blank-table style as the HLD and BRD.
    """
    _page_title(doc, "Document Control & Governance")
    _control_note(doc, "Printed copies are only valid on the date they were printed.")

    today = datetime.now().strftime("%d %b %Y")
    _subhead(doc, "Governance Header")
    _blank_table(doc, ["Field", "Details"],
                 n_rows=0,
                 rows=[
                     ("Document Status", "Draft"),
                     ("Product Reference", "System Security Impact Assessment"),
                     ("Data Classification", "INTERNAL"),
                     ("Author(s)", ""),
                     ("Document Owner", ""),
                     ("Document Location", ""),
                 ])

    _subhead(doc, "Revision History")
    _control_note(doc, "Log every change to this assessment.")
    _blank_table(doc, ["Version", "Summary of Changes", "Author", "Date"],
                 n_rows=3,
                 rows=[
                     ("0.1", "Initial SSIA draft", "", today),
                     ("1.0", "First approved baseline", "", ""),
                 ])

    _subhead(doc, "Approved By")
    _control_note(doc, "Approval is required before the solution progresses "
                       "through the gateway.")
    _blank_table(doc, ["Version", "Name", "Role / Job Title", "Date Approved"],
                 n_rows=1,
                 rows=[
                     ("", "", "IS Security Operations Manager", ""),
                     ("", "", "Security Architect", ""),
                     ("", "", "Solution Architect", ""),
                     ("", "", "Business Owner", ""),
                 ])

    _subhead(doc, "Distribution List")
    _control_note(doc, "This document has been distributed to the authorised "
                       "governance stakeholders below.")
    _blank_table(doc, ["Version", "Name", "Role / Job Title", "Date of Issue"],
                 n_rows=4)

    _subhead(doc, "Glossary")
    _blank_table(doc, ["Abbreviation / Acronym", "Definition"],
                 n_rows=2,
                 rows=[
                     ("SSIA", "System Security Impact Assessment"),
                     ("SIA", "Security Impact Assessment"),
                     ("DPIA", "Data Protection Impact Assessment"),
                     ("HLD", "High Level Design"),
                     ("AD", "Active Directory"),
                     ("SSO", "Single Sign-On"),
                     ("MFA", "Multi-Factor Authentication"),
                     ("SCIM", "System for Cross-domain Identity Management"),
                     ("RBAC", "Role-Based Access Control"),
                     ("PoF", "Power on Fusion (operational control system)"),
                     ("GDPR", "General Data Protection Regulation"),
                     ("LDAPS", "Lightweight Directory Access Protocol over SSL"),
                     ("TLS", "Transport Layer Security"),
                     ("SFTP", "SSH File Transfer Protocol"),
                     ("WAF", "Web Application Firewall"),
                     ("SIEM", "Security Information and Event Management"),
                     ("RTO", "Recovery Time Objective"),
                     ("RPO", "Recovery Point Objective"),
                     ("P1", "Priority 1 (business-critical) service"),
                     ("VPC", "Virtual Private Cloud"),
                 ])

    _subhead(doc, "Related Documents")
    _control_note(doc, "Cite document name, location, author and version, and a URL where available.")
    _blank_table(doc, ["Title", "Purpose", "Version"], 3)

    doc.add_page_break()


def _contents(doc, sections):
    """
    A real Word TOC field (hyperlinked, with page numbers) that Word refreshes
    automatically on open (see _enable_update_fields). The static section list
    is embedded as the field's cached result so the contents are still visible
    in viewers that never update fields; Word replaces it with the live TOC.
    """
    _page_title(doc, "Table of Contents")

    # field start:  { TOC \o "1-3" \h \z \u  ...cached result... }
    ps = doc.add_paragraph()
    ps.paragraph_format.space_after = Pt(0)
    rs = ps.add_run()
    begin = OxmlElement('w:fldChar')
    begin.set(qn('w:fldCharType'), 'begin')
    begin.set(qn('w:dirty'), 'true')
    instr = OxmlElement('w:instrText')
    instr.set(qn('xml:space'), 'preserve')
    instr.text = r' TOC \o "1-3" \h \z \u '
    sep = OxmlElement('w:fldChar')
    sep.set(qn('w:fldCharType'), 'separate')
    rs._r.append(begin)
    rs._r.append(instr)
    rs._r.append(sep)

    # cached result - replaced by the live, page-numbered TOC in Word
    for s in sections:
        if s['depth'] > 1 or s.get('qa'):
            continue   # two levels deep, and questionnaire entries never listed
        line = doc.add_paragraph()
        line.paragraph_format.space_after = Pt(2)
        line.paragraph_format.left_indent = Mm(s['depth'] * 5)
        bold = s['depth'] == 0
        _run(line, f"{s['number']}   ", size=10, bold=True, color=RED, font=MONO)
        _run(line, s['title'], size=10, bold=bold, color=INK if bold else BODY)
        if not s['is_required']:
            _run(line, "   (Not Required)", size=8, italic=True, color=MUTED)
    note = doc.add_paragraph()
    note.paragraph_format.space_before = Pt(6)
    _run(note, "Page numbers are inserted automatically when this document "
               "is opened in Microsoft Word.", size=8, italic=True, color=MUTED)

    # field end
    pe = doc.add_paragraph()
    pe.paragraph_format.space_after = Pt(0)
    re_ = pe.add_run()
    end = OxmlElement('w:fldChar')
    end.set(qn('w:fldCharType'), 'end')
    re_._r.append(end)

    doc.add_page_break()


def _ordered_item(node, *, is_required, short_description, content, rows,
                  blocks=None):
    """Normalise one section into the dict the renderer consumes."""
    ts = node['section']
    has_table = ts.has_table
    block = ts.block_conf()
    # A section whose PARENT declares the 'qa' layout is one entry of a
    # questionnaire: it renders as a banner carrying the question above its
    # answer, and is left out of the table of contents.
    parent = node.get('parent')
    is_qa = bool(parent is not None and getattr(parent, 'layout', None)
                 and parent.layout() == 'qa')
    intro = ''
    if (has_table or block) and not is_qa:
        intro = (short_description or '').strip() or hld_default_intro(ts.title)
    return {
        'number': node['number'],
        'q_number': node['number'].rsplit('.', 1)[-1],
        'qa': is_qa,
        'depth': node['depth'],
        'title': ts.title,
        'has_table': has_table,
        'columns': [{'id': c.id, 'name': c.name} for c in ts.ordered_columns()],
        'rows': rows,
        'block': block,
        'blocks': blocks or [],
        'intro': intro,
        'content': content or '',
        'is_required': is_required,
    }


def _assemble_document(project_name, ordered, status_text=None, doc_type='hld') -> bytes:
    """
    Assemble the .docx from a normalised, ordered section list. Shared by the
    stored-project path and the stateless guest path, for every document kind.

    Requirements honoured here:
      * Section guidance/instruction text is NEVER written to the document.
      * The "brief description" intro is rendered for TABLE sections only.
      * "Not Required" sections render a professional not-applicable note.
    """
    kind = DOC_KINDS.get(doc_type, DOC_KINDS['hld'])
    doc = Document()
    normal = doc.styles['Normal']
    normal.font.name = SANS
    normal.font.size = Pt(10.5)
    normal.font.color.rgb = BODY

    # File -> Info document properties
    props = doc.core_properties
    props.title = f"{kind['noun']} - {project_name}"
    props.subject = kind['header']
    props.author = "Northern Powergrid - AppAssist"
    props.category = kind['noun']

    _enable_update_fields(doc)
    _setup_page(doc, project_name, kind)
    _cover(doc, project_name, status_text, kind)
    if doc_type == 'brd':
        _doc_control_brd(doc)
    elif doc_type == 'ssia':
        _doc_control_ssia(doc)
    else:
        _doc_control(doc)
    _contents(doc, ordered)

    for s in ordered:
        if s.get('qa'):
            if s['is_required']:
                _qa_section(doc, s)
            else:
                _qa_not_required(doc, s, project_name)
            continue
        _heading(doc, s['number'], s['title'], s['depth'])
        if not s['is_required']:
            _not_applicable(doc, project_name, s['depth'], kind)
            continue
        if s.get('block'):
            if s['intro']:
                _intro(doc, s['intro'], s['depth'])
            _block_section(doc, s)
        elif s['has_table']:
            if s['intro']:
                _intro(doc, s['intro'], s['depth'])
            _table_section(doc, s, s['columns'])
        else:
            _narrative_section(doc, s['content'], s['depth'])

    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()


def build_hld_document(project, hld, template_sections) -> bytes:
    """
    Return the .docx bytes for a stored project's HLD.

    `template_sections` is the flat list of current master HLDTemplateSection
    rows (the tree is reconstructed here); `hld.sections` carry the project's
    filled-in content keyed by template_section_id.
    """
    by_tmpl = {ps.template_section_id: ps for ps in hld.sections}

    ordered = []
    for node in flatten_hld_tree(template_sections):
        ps = by_tmpl.get(node['section'].id)
        rows = [r.cell_map() for r in ps.ordered_rows()] if ps else []
        ordered.append(_ordered_item(
            node,
            is_required=bool(ps.is_required) if ps else True,
            short_description=ps.short_description if ps else '',
            content=ps.content if ps else '',
            rows=rows,
        ))

    status_text = project.status.value if project.status else None
    return _assemble_document(project.name, ordered, status_text)


def build_hld_document_from_payload(project_name, payload_sections, template_sections,
                                    doc_type='hld') -> bytes:
    """
    Return the .docx bytes for a GUEST document (HLD or BRD) - built entirely
    from posted data, with nothing read from or written to the database.

    `payload_sections` is a dict keyed by template_section_id (as str or int):
        { "<id>": {"is_required": bool, "short_description": str,
                   "content": str, "rows": [ {"<col_id>": value, ...}, ... ]} }
    Unknown keys and invalid column ids are ignored; the section structure and
    ordering always come from the trusted master template.
    """
    payload = {str(k): v for k, v in (payload_sections or {}).items()}

    ordered = []
    for node in flatten_hld_tree(template_sections):
        ts = node['section']
        data = payload.get(str(ts.id)) or {}
        valid_cols = {str(c.id) for c in ts.columns}
        rows = []
        if ts.has_table:
            for raw in (data.get('rows') or []):
                if not isinstance(raw, dict):
                    continue
                cells = {str(k): ('' if v is None else str(v))
                         for k, v in raw.items() if str(k) in valid_cols}
                if any((v or '').strip() for v in cells.values()):
                    rows.append(cells)
        blocks = _sanitise_blocks(ts.block_conf(), data.get('blocks'))
        ordered.append(_ordered_item(
            node,
            is_required=bool(data.get('is_required', True)),
            short_description=str(data.get('short_description') or ''),
            content=str(data.get('content') or ''),
            rows=rows,
            blocks=blocks,
        ))

    return _assemble_document(str(project_name), ordered, doc_type=doc_type)


def _sanitise_blocks(block_conf, raw_blocks):
    """
    Validate posted structured entries against the section's block config.
    Unknown field/table keys are dropped; rows are clipped to the configured
    column count; entries with no content at all are skipped.
    """
    if not block_conf or not isinstance(raw_blocks, list):
        return []
    field_keys = {f.get('key') for f in (block_conf.get('fields') or [])}
    table_cols = {t.get('key'): len(t.get('columns') or [])
                  for t in (block_conf.get('tables') or [])}
    entries = []
    for raw in raw_blocks:
        if not isinstance(raw, dict):
            continue
        raw_fields = raw.get('fields') or {}
        fields = {}
        if isinstance(raw_fields, dict):
            fields = {str(k): str(v) for k, v in raw_fields.items()
                      if str(k) in field_keys and str(v or '').strip()}
        tables = {}
        raw_tables = raw.get('tables') or {}
        if isinstance(raw_tables, dict):
            for key, n_cols in table_cols.items():
                rows = []
                for row in raw_tables.get(key) or []:
                    if not isinstance(row, list):
                        continue
                    cells = [str(c) if c is not None else '' for c in row[:n_cols]]
                    if any(c.strip() for c in cells):
                        cells += [''] * (n_cols - len(cells))
                        rows.append(cells)
                if rows:
                    tables[key] = rows
        if fields or tables:
            entries.append({'fields': fields, 'tables': tables})
    return entries
