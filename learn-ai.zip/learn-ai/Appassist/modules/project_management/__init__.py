from flask import Blueprint

project_management_bp = Blueprint('project_management', __name__)

from . import routes
