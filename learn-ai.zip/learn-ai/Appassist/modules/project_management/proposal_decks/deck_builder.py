"""
Template registry + the single entry point used by the routes:
``build_deck_html(template_id, payload) -> str``.
"""

from __future__ import annotations

from .render_common import Deck, wrap_document
from .templates_decks import npg, helix, meridian, apex

# Ordered registry - drives both the builder's template dropdown and dispatch.
# ONE form, four designs: every template consumes the same canonical 14-slide
# input set (see schema.SLIDES) and differs only in presentation & layout:
#   npg      - slate + crimson editorial annual-report on a white canvas
#   helix    - midnight-navy cards with a single azure accent, centred heroes
#   meridian - ivory + teal/gold left-rail consulting engagement, serif
#   apex     - serif-on-ivory boardroom paper with bronze hairlines
_MODULES = {
    'npg': npg,
    'helix': helix,
    'meridian': meridian,
    'apex': apex,
}

TEMPLATES = [
    {**m.META, 'id': key} for key, m in _MODULES.items()
]
TEMPLATE_IDS = list(_MODULES.keys())


def build_deck_html(template_id: str, payload) -> str:
    """Render the chosen template into a single self-contained HTML deck."""
    module = _MODULES.get(template_id, npg)
    deck = payload if isinstance(payload, Deck) else Deck(payload)
    slides_html = module.render(deck)
    cover_title = (deck.text('cover', 'title') or 'Proposal').replace('\n', ' ').strip()
    client = deck.m('client_name', '').strip()
    title = f'{cover_title} - {client}' if client else cover_title
    return wrap_document(title, module.CSS, slides_html, module.META.get('body_bg', '#0b0b0c'))
