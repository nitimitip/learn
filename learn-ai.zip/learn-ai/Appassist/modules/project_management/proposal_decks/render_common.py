"""
Shared helpers for the proposal-deck renderers: HTML escaping, input
normalisation, small text utilities, and the self-contained document wrapper
that inlines the <deck-stage> presentation engine.
"""

from __future__ import annotations

import html
import os
import re

from .schema import SLIDES, SLIDE_BY_KEY, META_FIELDS, default_data, slides_for

# render_common.py lives at <root>/modules/project_management/proposal_decks/
# - four levels up is the application root that holds static/.
_DECK_JS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))),
    'static', 'js', 'proposal', 'deck-stage.js',
)
_deck_js_cache = None


def deck_stage_js() -> str:
    """Read (and cache) the shared deck-stage.js engine for inlining."""
    global _deck_js_cache
    if _deck_js_cache is None:
        try:
            with open(_DECK_JS_PATH, 'r', encoding='utf-8') as fh:
                _deck_js_cache = fh.read()
        except OSError:
            _deck_js_cache = '/* deck-stage.js unavailable */'
    return _deck_js_cache


# --- text utilities --------------------------------------------------------

def esc(value) -> str:
    """HTML-escape a scalar (None -> '')."""
    if value is None:
        return ''
    return html.escape(str(value), quote=True)


def esc_br(value) -> str:
    """Escape and turn newlines into <br>."""
    return esc(value).replace('\n', '<br>')


def lines(value):
    """Split a textarea/list value into clean non-empty lines."""
    if isinstance(value, (list, tuple)):
        return [str(v).strip() for v in value if str(v).strip()]
    return [ln.strip() for ln in str(value or '').split('\n') if ln.strip()]


def parts(value, sep=','):
    """Split a delimited string (commas by default) into clean items."""
    return [p.strip() for p in str(value or '').replace('\n', sep).split(sep) if p.strip()]


def num(value, default=0.0):
    try:
        return float(str(value).strip())
    except (TypeError, ValueError):
        return default


# --- normalisation ---------------------------------------------------------

def coerce_deck(payload) -> dict:
    """
    Return a fully-formed deck dict the renderers can trust, merging posted
    data over the schema defaults and discarding anything malformed. The deck
    *structure* (which slides exist, which columns a table has) always comes
    from the trusted schema - never from the client.
    """
    payload = payload if isinstance(payload, dict) else {}
    template = str(payload.get('template') or 'npg')
    out = default_data(template)

    meta_in = payload.get('meta') if isinstance(payload.get('meta'), dict) else {}
    for f in META_FIELDS:
        if f['key'] in meta_in and meta_in[f['key']] is not None:
            out['meta'][f['key']] = str(meta_in[f['key']])

    slides_in = payload.get('slides') if isinstance(payload.get('slides'), dict) else {}
    for s in slides_for(template):
        sin = slides_in.get(s['key']) if isinstance(slides_in.get(s['key']), dict) else {}
        slot = out['slides'][s['key']]
        # required toggle (cover / thank-you are always on)
        if s.get('lockable', True):
            slot['enabled'] = bool(sin.get('enabled', True))
        else:
            slot['enabled'] = True
        fin = sin.get('fields') if isinstance(sin.get('fields'), dict) else {}
        for f in s['fields']:
            if f['key'] not in fin:
                continue
            slot['fields'][f['key']] = _coerce_field(f, fin[f['key']])
    return out


def _coerce_field(field, value):
    ftype = field['type']
    if ftype in ('text', 'textarea', 'select'):
        return '' if value is None else str(value)
    if ftype == 'list':
        if isinstance(value, list):
            return [str(v) for v in value]
        return lines(value)
    if ftype == 'table':
        cols = {c['key'] for c in field['columns']}
        rows = []
        if isinstance(value, list):
            for raw in value:
                if not isinstance(raw, dict):
                    continue
                row = {k: ('' if raw.get(k) is None else str(raw.get(k))) for k in cols}
                if any(v.strip() for v in row.values()):
                    rows.append(row)
        return rows
    return value


# --- accessors used by renderers -------------------------------------------

class Deck:
    """Thin convenience wrapper over a coerced deck dict."""

    def __init__(self, payload):
        self.data = coerce_deck(payload)
        self.meta = self.data['meta']
        self.template = self.data['template']

    def m(self, key, default=''):
        return self.meta.get(key, default)

    def has(self, slide_key):
        """Whether this deck's template includes the slide at all."""
        return slide_key in self.data['slides']

    def enabled(self, slide_key):
        slot = self.data['slides'].get(slide_key)
        return bool(slot and slot.get('enabled'))

    def f(self, slide_key, field_key, default=None):
        slot = self.data['slides'].get(slide_key)
        if not slot:
            return default
        return slot['fields'].get(field_key, default)

    def text(self, slide_key, field_key):
        return self.f(slide_key, field_key, '') or ''

    def list(self, slide_key, field_key):
        v = self.f(slide_key, field_key, [])
        return lines(v) if not isinstance(v, list) else [x for x in v if str(x).strip()]

    def table(self, slide_key, field_key):
        v = self.f(slide_key, field_key, [])
        return v if isinstance(v, list) else []


# --- gantt geometry (shared by all templates) ------------------------------

def gantt_unit(deck: Deck):
    """The roadmap axis unit as (prefix, word) - ('W', 'week') or ('M', 'month').

    Driven by the roadmap slide's free-text ``unit`` field so a deck can run a
    week-by-week programme without the axis claiming months. Anything that
    doesn't start with a "w" keeps the historical month behaviour.
    """
    raw = (deck.text('roadmap', 'unit') or '').strip().lower()
    return ('W', 'week') if raw.startswith('w') else ('M', 'month')


def gantt_geometry(deck: Deck):
    """
    Normalise roadmap phases into {name, left, width, milestone} percentages.
    Bars are clamped to the [0,100] track derived from total_months.
    """
    total = max(num(deck.text('roadmap', 'total_months'), 9), 1)
    out = []
    for row in deck.table('roadmap', 'phases'):
        start = max(num(row.get('start'), 0), 0)
        dur = max(num(row.get('duration'), 0), 0)
        left = min(start / total * 100, 100)
        width = max(min(dur / total * 100, 100 - left), 1.5)
        out.append({
            'name': row.get('name', ''),
            'left': round(left, 2),
            'width': round(width, 2),
            'end': round(min(left + width, 100), 2),
            'milestone': str(row.get('milestone', 'No')).strip().lower() in ('yes', 'true', '1'),
        })
    return out, total


# --- document wrapper ------------------------------------------------------

_SLIDE_RE = re.compile(r'^\s*<section', re.IGNORECASE)


def wrap_document(deck_title: str, css: str, slides_html: str,
                  body_bg: str = '#0b0b0c') -> str:
    """Assemble the final, self-contained presentation HTML."""
    # The engine's source contains the literal "</script>" in its usage docs;
    # left as-is it would prematurely close our inline <script> tag. Escape it.
    engine = deck_stage_js().replace('</script>', '<\\/script>')
    return (
        '<!DOCTYPE html>\n<html lang="en">\n<head>\n'
        '<meta charset="UTF-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
        f'<title>{esc(deck_title)}</title>\n'
        '<style>\ndeck-stage:not(:defined){visibility:hidden;}\n'
        f'html,body{{margin:0;background:{body_bg};}}\n'
        f'{css}\n</style>\n'
        '</head>\n'
        f'<body>\n<deck-stage width="1920" height="1080">\n{slides_html}\n</deck-stage>\n'
        f'<script>\n{engine}\n</script>\n'
        '</body>\n</html>\n'
    )


def skip_attr(enabled: bool) -> str:
    """`data-deck-skip` marks a slide so the engine drops it from nav + print."""
    return '' if enabled else ' data-deck-skip'


class _Positions(dict):
    """Slide-position map that tolerates keys outside the template's slide
    set (a renderer may emit a section for a slide its template dropped -
    that section carries data-deck-skip and is never shown)."""

    def __init__(self, total):
        super().__init__()
        self._total = total

    def __missing__(self, key):
        return ('--', self._total)


def footer_positions(deck: Deck):
    """
    Map each slide key to ('NN', 'TT') where TT is the count of *enabled*
    slides and NN is this slide's 1-based position among them. Disabled or
    unknown slides get ('--', TT) - they're hidden anyway. Only the deck
    template's own slide set is counted.
    """
    deck_slides = slides_for(deck.template)
    enabled_keys = [s['key'] for s in deck_slides if deck.enabled(s['key'])]
    total = f'{len(enabled_keys):02d}'
    pos = _Positions(total)
    n = 0
    for s in deck_slides:
        if deck.enabled(s['key']):
            n += 1
            pos[s['key']] = (f'{n:02d}', total)
        else:
            pos[s['key']] = ('--', total)
    return pos


def risk_class(prob: str) -> str:
    p = (prob or '').strip().lower()
    if p.startswith('h'):
        return 'r'
    if p.startswith('l'):
        return 'g'
    return 'a'
