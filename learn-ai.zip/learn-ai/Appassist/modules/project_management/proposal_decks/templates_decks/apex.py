"""
Apex - executive brief on ivory.

A bespoke renderer (shares no layout with the other templates): ivory paper,
near-black ink, Georgia serif display type, bronze hairline accents and zero
decoration - the language of a printed board paper.

Renders the full canonical 14-slide proposal set defined in schema.py.

Self-contained and fully offline - system font stack only.
"""

from __future__ import annotations

from ..render_common import (
    Deck, esc, esc_br, footer_positions, gantt_geometry, gantt_unit, skip_attr, risk_class,
)

META = {
    'id': 'apex',
    'name': 'Apex - Executive Brief',
    'tagline': 'The proposal as a serif-on-ivory boardroom paper - hairline rules, bronze accents, written for executives.',
    'body_bg': '#141414',
    'accent': '#A07E3B',
}

CSS = r"""
:root{
  --paper:#F7F6F2;--ink:#141414;--muted:#6F6C64;--line:#DDD9D0;--rule:#141414;
  --bronze:#A07E3B;--bronze-soft:rgba(160,126,59,.10);
  --green:#2D6A4F;--amber:#A07E3B;--red:#A03328;
  --serif:Georgia,'Times New Roman','Times',serif;
  --sans:'Segoe UI',system-ui,-apple-system,'Helvetica Neue',Arial,sans-serif;
  --mono:'Consolas','SFMono-Regular','Courier New',monospace;
  --pad:110px;
}
*{box-sizing:border-box;}
.slide.ax{display:flex;flex-direction:column;background:var(--paper);color:var(--ink);font-family:var(--sans);overflow:hidden;}
/* chrome: hairline masthead + colophon footer */
.ax-mast{flex:none;display:flex;align-items:baseline;justify-content:space-between;margin:54px var(--pad) 0;padding-bottom:18px;border-bottom:2px solid var(--rule);}
.ax-mast .wb{font-family:var(--serif);font-weight:700;font-size:21px;letter-spacing:.06em;}
.ax-mast .wb i{font-style:normal;color:var(--bronze);}
.ax-mast .sec{font-family:var(--mono);font-size:13.5px;letter-spacing:.26em;text-transform:uppercase;color:var(--muted);}
.ax-foot{flex:none;display:flex;align-items:center;justify-content:space-between;margin:0 var(--pad) 44px;padding-top:16px;border-top:1px solid var(--line);font-family:var(--mono);font-size:12.5px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);}
.ax-foot .pg{color:var(--ink);font-weight:700;}
.ax-body{flex:1;min-height:0;display:flex;flex-direction:column;padding:44px var(--pad);}
/* type */
.ax-kick{font-family:var(--mono);font-size:13.5px;font-weight:700;letter-spacing:.3em;text-transform:uppercase;color:var(--bronze);}
.ax-h{font-family:var(--serif);font-weight:700;letter-spacing:-.01em;line-height:1.08;margin:0;}
.ax-lead{font-family:var(--serif);font-size:25px;line-height:1.55;margin:0;}
.ax-note{font-size:16.5px;line-height:1.55;color:var(--muted);}
.bronze{color:var(--bronze);}
/* stats */
.ax-stat .v{font-family:var(--serif);font-weight:700;font-size:54px;letter-spacing:-.01em;line-height:1.05;}
.ax-stat .l{font-family:var(--mono);font-size:13px;letter-spacing:.2em;text-transform:uppercase;color:var(--muted);margin-top:10px;line-height:1.5;}
/* board table */
.bt{width:100%;border-collapse:collapse;}
.bt th{font-family:var(--mono);font-size:12.5px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:var(--muted);text-align:left;padding:0 22px 13px 0;border-bottom:2px solid var(--rule);}
.bt th:last-child{padding-right:0;}
.bt td{font-size:18px;line-height:1.5;padding:16px 22px 16px 0;border-bottom:1px solid var(--line);vertical-align:top;}
.bt td:last-child{padding-right:0;}
.bt td.it{font-family:var(--serif);font-weight:700;font-size:19.5px;}
.bt td.num{font-family:var(--mono);font-weight:700;}
.bt tr.total td{border-top:2px solid var(--rule);border-bottom:0;font-family:var(--serif);font-weight:700;font-size:22px;padding-top:20px;}
/* severity chips */
.sev{display:inline-flex;align-items:center;gap:9px;font-family:var(--mono);font-size:14.5px;font-weight:700;letter-spacing:.06em;}
.sev::before{content:"";width:11px;height:11px;border-radius:50%;background:var(--sv,var(--amber));}
.sev.r{--sv:var(--red);}.sev.a{--sv:var(--amber);}.sev.g{--sv:var(--green);}
/* em-dash editorial list */
.ctx{list-style:none;margin:0;padding:0;}
.ctx li{display:grid;grid-template-columns:44px 1fr;gap:6px;padding:16px 0;border-bottom:1px solid var(--line);font-size:18px;line-height:1.5;}
.ctx li::before{content:"-";color:var(--bronze);font-weight:700;}
.ctx li:first-child{padding-top:0;}
.ctx li b{font-family:var(--serif);font-size:19.5px;}
/* numbered serif list */
.nlist{list-style:none;margin:0;padding:0;}
.nlist li{display:grid;grid-template-columns:64px 1fr;gap:18px;padding:19px 0;border-bottom:1px solid var(--line);}
.nlist li:first-child{padding-top:0;}
.nlist .nn{font-family:var(--serif);font-weight:700;font-size:30px;color:var(--bronze);line-height:1.1;}
.nlist b{display:block;font-family:var(--serif);font-size:20px;margin-bottom:4px;}
.nlist span{display:block;font-size:16.5px;line-height:1.5;color:var(--muted);}
/* gantt (serif / bronze) */
.axg-head{display:grid;grid-template-columns:185px 1fr;gap:24px;font-family:var(--mono);font-size:12.5px;font-weight:700;letter-spacing:.12em;color:var(--muted);border-bottom:2px solid var(--rule);padding-bottom:11px;}
.axg-row{display:grid;grid-template-columns:185px 1fr;gap:24px;align-items:center;border-bottom:1px solid var(--line);}
.axg-row .gname{font-family:var(--serif);font-weight:700;font-size:19px;padding:15px 0;}
.axg-track{position:relative;height:42px;}
.axg-bar{position:absolute;top:9px;bottom:9px;background:var(--ink);}
.axg-bar.hot{background:var(--bronze);}
.axg-ms{position:absolute;top:50%;width:14px;height:14px;background:var(--bronze);transform:translate(-50%,-50%) rotate(45deg);border:2px solid var(--paper);box-shadow:0 0 0 1.5px var(--bronze);}
/* sign-off band */
.signoff{border-top:3px solid var(--rule);border-bottom:3px solid var(--rule);padding:30px 0;display:flex;align-items:center;gap:54px;}
.signoff .dt{font-family:var(--serif);font-weight:700;font-size:42px;letter-spacing:-.01em;}
/* split rule */
.vr{width:1px;align-self:stretch;background:var(--line);flex:none;}
/* bronze emphasis panel */
.bpanel{background:var(--ink);color:var(--paper);padding:36px 40px;}
.bpanel .bk{font-family:var(--mono);font-size:12.5px;font-weight:700;letter-spacing:.24em;text-transform:uppercase;color:var(--bronze);}
@media (prefers-reduced-motion:no-preference){
  [data-deck-active] .anim{animation:axin .55s cubic-bezier(.2,.7,.3,1) both;}
  [data-deck-active] .anim.d1{animation-delay:.07s;}[data-deck-active] .anim.d2{animation-delay:.14s;}
  [data-deck-active] .anim.d3{animation-delay:.21s;}
  @keyframes axin{from{opacity:0;transform:translateY(14px);}to{opacity:1;transform:none;}}
}
"""


def render(payload) -> str:
    deck = payload if isinstance(payload, Deck) else Deck(payload)
    pos = footer_positions(deck)
    letter, short = esc(deck.m('logo_letter')), esc(deck.m('brand_short'))

    from ..schema import SLIDE_BY_KEY

    def mast(key):
        meta = SLIDE_BY_KEY[key]
        return (f'<div class="ax-mast"><span class="wb"><i>{letter}</i>&nbsp;&nbsp;{short}</span>'
                f'<span class="sec">{esc(meta["eyebrow"])} - {esc(meta["title"])}</span></div>')

    def foot(key):
        n, t = pos[key]
        return (f'<div class="ax-foot"><span>{esc(deck.m("confidential"))}</span>'
                f'<span>{esc(deck.m("client_name"))}</span>'
                f'<span class="pg">{n} - {t}</span></div>')

    out = []

    # ---- 1 COVER ----
    out.append(f'''<section class="slide ax"{skip_attr(deck.enabled("cover"))} data-screen-label="01 Cover">
  <div class="ax-mast"><span class="wb" style="font-size:24px;"><i>{letter}</i>&nbsp;&nbsp;{short}</span>
    <span class="sec">Executive Briefing Paper</span></div>
  <div class="ax-body" style="justify-content:center;">
    <div class="ax-kick anim">Prepared for - {esc(deck.m("client_name"))}</div>
    <h1 class="ax-h anim d1" style="font-size:104px;max-width:1560px;margin:38px 0 36px;">{esc_br(deck.text("cover","title"))}</h1>
    <div class="anim d2" style="width:120px;height:3px;background:var(--bronze);margin-bottom:36px;"></div>
    <p class="ax-lead anim d2" style="max-width:1180px;color:var(--muted);">{esc(deck.text("cover","tagline"))}</p>
    <div class="anim d3" style="display:flex;gap:64px;margin-top:70px;font-family:var(--mono);font-size:14.5px;letter-spacing:.1em;color:var(--muted);">
      <span>PREPARED BY&nbsp;&nbsp;<b style="color:var(--ink);">{esc(deck.m("brand_name"))}</b></span>
      <span>DATE&nbsp;&nbsp;<b style="color:var(--ink);">{esc(deck.m("doc_date"))}</b></span>
      <span>VERSION&nbsp;&nbsp;<b style="color:var(--ink);">{esc(deck.m("doc_version"))}</b></span>
      <span style="color:var(--bronze);font-weight:700;">{esc(deck.m("confidential")).upper()}</span>
    </div>
  </div>
  <div class="ax-foot"><span>{esc(deck.m("brand_name"))}</span><span class="pg">Executive copy</span></div>
</section>''')

    # ---- 2 EXECUTIVE SUMMARY ----
    stats = ''.join(
        f'''<div class="ax-stat anim d{i+1}">
        <div class="v{" bronze" if i == 0 else ""}">{esc(r.get("metric"))}</div>
        <div class="l">{esc(r.get("heading"))}</div>
        <p class="ax-note" style="margin:10px 0 0;max-width:380px;">{esc(r.get("desc"))}</p></div>'''
        for i, r in enumerate(deck.table('exec', 'stats')[:3]))
    out.append(f'''<section class="slide ax"{skip_attr(deck.enabled("exec"))} data-screen-label="02 Executive Summary">
  {mast("exec")}
  <div class="ax-body">
    <div class="ax-kick anim">In one page</div>
    <h2 class="ax-h anim d1" style="font-size:52px;max-width:1560px;margin:28px 0 0;">{esc(deck.text("exec","lead"))}</h2>
    <div style="display:flex;gap:80px;flex:1;align-items:center;margin-top:24px;">{stats}</div>
  </div>
  {foot("exec")}
</section>''')

    # ---- 3 CHALLENGE ----
    pains = ''.join(
        f'<li><div><b>{esc(r.get("heading"))}</b><span style="display:block;font-family:var(--sans);font-size:16.5px;color:var(--muted);line-height:1.5;margin-top:4px;">{esc(r.get("detail"))}</span></div></li>'
        for r in deck.table('challenge', 'pains')[:5])
    impacts = ''.join(
        f'''<div style="padding:22px 0;border-top:1px solid rgba(255,255,255,.16);">
        <div style="font-family:var(--serif);font-weight:700;font-size:46px;color:var(--bronze);letter-spacing:-.01em;">{esc(r.get("metric"))}</div>
        <div style="font-size:16px;color:rgba(247,246,242,.72);margin-top:7px;line-height:1.4;">{esc(r.get("label"))}</div></div>'''
        for r in deck.table('challenge', 'impacts')[:4])
    out.append(f'''<section class="slide ax"{skip_attr(deck.enabled("challenge"))} data-screen-label="03 Business Challenge">
  {mast("challenge")}
  <div class="ax-body">
    <h2 class="ax-h anim" style="font-size:52px;margin-bottom:40px;">The business challenge</h2>
    <div style="display:flex;gap:70px;flex:1;align-items:stretch;">
      <div class="anim d1" style="flex:1.35;display:flex;flex-direction:column;justify-content:center;">
        <div class="ax-kick" style="margin-bottom:14px;">Current pain points</div>
        <ul class="ctx">{pains}</ul>
      </div>
      <div class="bpanel anim d2" style="flex:1;display:flex;flex-direction:column;justify-content:center;">
        <div class="bk" style="margin-bottom:4px;">Business impact</div>{impacts}
      </div>
    </div>
  </div>
  {foot("challenge")}
</section>''')

    # ---- 4 OPPORTUNITY / BUSINESS CASE ----
    drivers = ''.join(
        f'<li><div><b>{esc(r.get("driver"))}</b><span style="display:block;font-family:var(--sans);font-size:16.5px;color:var(--muted);line-height:1.5;margin-top:4px;">{esc(r.get("detail"))}</span></div></li>'
        for r in deck.table('opportunity', 'drivers')[:4])
    align = ''.join(
        f'<li style="display:flex;gap:14px;align-items:flex-start;padding:10px 0;border-bottom:1px solid var(--line);font-size:16.5px;line-height:1.5;">'
        f'<span style="color:var(--bronze);font-weight:700;flex:none;">OK</span> {esc(a)}</li>'
        for a in deck.list('opportunity', 'alignment')[:4])
    out.append(f'''<section class="slide ax"{skip_attr(deck.enabled("opportunity"))} data-screen-label="04 Opportunity">
  {mast("opportunity")}
  <div class="ax-body">
    <h2 class="ax-h anim" style="font-size:52px;margin-bottom:16px;">The case for acting now</h2>
    <p class="ax-lead anim d1" style="color:var(--muted);font-size:22px;max-width:1300px;margin-bottom:40px;">{esc(deck.text("opportunity","lead"))}</p>
    <div style="display:flex;gap:70px;flex:1;align-items:stretch;">
      <div class="anim d1" style="flex:1.25;display:flex;flex-direction:column;justify-content:center;">
        <div class="ax-kick" style="margin-bottom:14px;">Market &amp; internal drivers</div>
        <ul class="ctx">{drivers}</ul>
        <div class="ax-kick" style="margin:30px 0 8px;">Strategic alignment</div>
        <ul style="list-style:none;margin:0;padding:0;">{align}</ul>
      </div>
      <div class="vr"></div>
      <div class="anim d2" style="flex:1;display:flex;flex-direction:column;gap:26px;justify-content:center;">
        <div style="border:1px solid var(--line);border-top:5px solid var(--red);padding:28px 32px;">
          <div class="ax-kick" style="color:var(--red);margin-bottom:12px;">Cost of inaction</div>
          <p class="ax-note" style="margin:0;font-size:17.5px;">{esc(deck.text("opportunity","inaction"))}</p>
        </div>
        <div class="bpanel" style="border-top:5px solid var(--bronze);">
          <div class="bk" style="margin-bottom:12px;">Benefit of acting now</div>
          <p style="margin:0;font-size:17.5px;line-height:1.55;color:rgba(247,246,242,.78);">{esc(deck.text("opportunity","action"))}</p>
        </div>
      </div>
    </div>
  </div>
  {foot("opportunity")}
</section>''')

    # ---- 5 SOLUTION ----
    layers = deck.table('solution', 'arch_layers')[:5]
    lhtml = []
    for li, lr in enumerate(layers):
        nodes = ''.join(
            f'<div style="flex:1;border:1px solid {"var(--rule)" if li == 1 else "var(--line)"};{"background:var(--ink);color:var(--paper);" if li == 1 else ""}padding:14px 10px;text-align:center;font-family:var(--mono);font-size:13px;font-weight:600;">{esc(n.strip())}</div>'
            for n in str(lr.get('nodes', '')).split(',') if n.strip()) or '<div style="flex:1;"></div>'
        lhtml.append(f'''<div style="display:grid;grid-template-columns:130px 1fr;gap:18px;align-items:center;">
        <div style="font-family:var(--mono);font-size:12px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:var(--muted);text-align:right;">{esc(lr.get("layer"))}</div>
        <div style="display:flex;gap:12px;">{nodes}</div></div>''')
    smap = ''.join(
        f'''<div style="display:grid;grid-template-columns:1fr 44px 1.1fr;gap:14px;align-items:center;padding:15px 0;border-bottom:1px solid var(--line);">
        <span style="font-size:16.5px;color:var(--muted);">{esc(r.get("need"))}</span>
        <span style="color:var(--bronze);font-weight:700;font-size:19px;text-align:center;">-></span>
        <span style="font-family:var(--serif);font-size:17.5px;font-weight:700;">{esc(r.get("solution"))}</span></div>'''
        for r in deck.table('solution', 'solution_map')[:7])
    out.append(f'''<section class="slide ax"{skip_attr(deck.enabled("solution"))} data-screen-label="05 Proposed Solution">
  {mast("solution")}
  <div class="ax-body">
    <div class="anim" style="border-bottom:1px solid var(--line);padding-bottom:20px;margin-bottom:34px;">
      <h2 class="ax-h" style="font-size:46px;margin-bottom:14px;">The proposed solution</h2>
      <p class="ax-lead" style="color:var(--muted);font-size:21px;max-width:1400px;">{esc(deck.text("solution","lead"))}</p>
    </div>
    <div style="display:flex;gap:70px;flex:1;align-items:center;">
      <div class="anim d1" style="flex:1.2;display:flex;flex-direction:column;gap:14px;">
        <div class="ax-kick" style="margin-bottom:10px;">Target architecture</div>
        {''.join(lhtml)}
        <div style="font-family:var(--mono);font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);margin-top:6px;text-align:center;">{esc(deck.text("solution","arch_caption"))}</div>
      </div>
      <div class="vr"></div>
      <div class="anim d2" style="flex:1;">
        <div class="ax-kick" style="margin-bottom:12px;">Business need -> our solution</div>
        {smap}
      </div>
    </div>
  </div>
  {foot("solution")}
</section>''')

    # ---- 6 KEY BENEFITS ----
    bens = ''.join(
        f'''<div class="ax-stat anim d{min(i + 1, 3)}" style="border-top:2px solid var(--rule);padding-top:22px;">
        <div class="v bronze" style="font-size:46px;">{esc(r.get("metric"))}</div>
        <div style="font-family:var(--serif);font-weight:700;font-size:21px;margin-top:12px;">{esc(r.get("title"))}</div>
        <p class="ax-note" style="margin:8px 0 0;">{esc(r.get("desc"))}</p></div>'''
        for i, r in enumerate(deck.table('benefits', 'items')[:6]))
    out.append(f'''<section class="slide ax"{skip_attr(deck.enabled("benefits"))} data-screen-label="06 Key Benefits">
  {mast("benefits")}
  <div class="ax-body">
    <h2 class="ax-h anim" style="font-size:52px;margin-bottom:16px;">What you actually gain</h2>
    <p class="ax-lead anim d1" style="color:var(--muted);font-size:22px;max-width:1300px;margin-bottom:46px;">{esc(deck.text("benefits","lead"))}</p>
    <div style="flex:1;display:grid;grid-template-columns:repeat(3,1fr);gap:46px 64px;align-content:center;">{bens}</div>
  </div>
  {foot("benefits")}
</section>''')

    # ---- 7 APPROACH & METHODOLOGY ----
    methods = '&nbsp;&nbsp;-&nbsp;&nbsp;'.join(
        f'<span style="font-family:var(--mono);font-size:14.5px;font-weight:700;letter-spacing:.08em;">{esc(m)}</span>'
        for m in deck.list('approach', 'methodologies')[:6])
    phases = ''.join(
        f'''<li><span class="nn">{i+1:02d}</span><div><b>{esc(r.get("name"))}</b>
        <span>{esc(r.get("desc"))}</span></div></li>'''
        for i, r in enumerate(deck.table('approach', 'phases')[:6]))
    out.append(f'''<section class="slide ax"{skip_attr(deck.enabled("approach"))} data-screen-label="07 Approach">
  {mast("approach")}
  <div class="ax-body">
    <div class="anim" style="display:flex;align-items:baseline;gap:30px;border-bottom:1px solid var(--line);padding-bottom:20px;margin-bottom:16px;">
      <h2 class="ax-h" style="font-size:46px;flex:none;">How we'll make it happen</h2>
      <div style="margin-left:auto;color:var(--ink);">{methods}</div>
    </div>
    <p class="ax-lead anim d1" style="color:var(--muted);font-size:21px;max-width:1400px;margin-bottom:30px;">{esc(deck.text("approach","lead"))}</p>
    <div class="anim d1" style="flex:1;display:flex;flex-direction:column;justify-content:center;max-width:1400px;">
      <div class="ax-kick" style="margin-bottom:8px;">Phased plan</div>
      <ul class="nlist">{phases}</ul>
    </div>
    <div class="bpanel anim d2" style="margin-top:30px;">
      <div class="bk" style="margin-bottom:10px;">How we'll work with you</div>
      <p style="margin:0;font-size:17.5px;line-height:1.55;color:rgba(247,246,242,.78);">{esc(deck.text("approach","collaboration"))}</p>
    </div>
  </div>
  {foot("approach")}
</section>''')

    # ---- 8 ROADMAP ----
    bars, total = gantt_geometry(deck)
    unit_prefix, unit_word = gantt_unit(deck)
    months = max(int(round(total)), 1)
    shown = min(months, 18)
    grid_bg = f'background-image:repeating-linear-gradient(90deg,var(--line) 0,var(--line) 1px,transparent 1px,transparent {100/shown:.4f}%);'
    month_cells = ''.join(f'<div>{unit_prefix}{i+1}</div>' for i in range(shown))
    rows_html = ''.join(
        f'''<div class="axg-row"><div class="gname">{esc(b["name"])}</div>
        <div class="axg-track" style="{grid_bg}">
          <div class="axg-bar{" hot" if b["milestone"] else ""}" style="left:{b["left"]}%;width:{b["width"]}%;"></div>
          {f'<span class="axg-ms" style="left:{b["end"]}%;"></span>' if b["milestone"] else ''}
        </div></div>'''
        for b in bars)
    out.append(f'''<section class="slide ax"{skip_attr(deck.enabled("roadmap"))} data-screen-label="08 Roadmap">
  {mast("roadmap")}
  <div class="ax-body">
    <h2 class="ax-h anim" style="font-size:52px;margin-bottom:16px;">The programme, {unit_word} by {unit_word}</h2>
    <p class="ax-lead anim d1" style="color:var(--muted);font-size:22px;max-width:1300px;margin-bottom:42px;">{esc(deck.text("roadmap","lead"))}</p>
    <div class="anim d2" style="flex:1;display:flex;flex-direction:column;justify-content:center;">
      <div class="axg-head"><div style="text-transform:uppercase;">Phase</div><div style="display:grid;grid-template-columns:repeat({shown},1fr);">{month_cells}</div></div>
      {rows_html}
      <div style="display:flex;gap:30px;margin-top:24px;font-family:var(--mono);font-size:13.5px;color:var(--muted);">
        <span style="display:flex;align-items:center;gap:10px;"><span style="width:12px;height:12px;background:var(--bronze);transform:rotate(45deg);display:inline-block;"></span> Milestone gate</span>
      </div>
    </div>
  </div>
  {foot("roadmap")}
</section>''')

    # ---- 9 RISK ----
    rrows = ''.join(
        f'<tr><td class="it" style="font-size:19px;">{esc(r.get("risk"))}</td>'
        f'<td><span class="sev {risk_class(r.get("probability"))}">{esc(r.get("probability"))}</span></td>'
        f'<td style="color:var(--muted);">{esc(r.get("mitigation"))}</td></tr>'
        for r in deck.table('risk', 'risks')[:8])
    out.append(f'''<section class="slide ax"{skip_attr(deck.enabled("risk"))} data-screen-label="09 Risks & Mitigations">
  {mast("risk")}
  <div class="ax-body">
    <h2 class="ax-h anim" style="font-size:52px;margin-bottom:16px;">What could go wrong - and the plan for it</h2>
    <p class="ax-lead anim d1" style="color:var(--muted);font-size:22px;max-width:1300px;margin-bottom:40px;">{esc(deck.text("risk","lead"))}</p>
    <div class="anim d2" style="flex:1;display:flex;flex-direction:column;justify-content:center;">
      <table class="bt"><thead><tr><th style="width:28%;">Risk</th><th style="width:14%;">Probability</th><th>Mitigation</th></tr></thead><tbody>{rrows}</tbody></table>
      <div style="display:flex;gap:34px;margin-top:26px;">
        <span class="sev g">Low</span><span class="sev a">Medium</span><span class="sev r">High</span>
      </div>
    </div>
  </div>
  {foot("risk")}
</section>''')

    # ---- 10 TEAM ----
    members = ''.join(
        f'''<li><div><b>{esc(r.get("name"))} <span style="font-family:var(--mono);font-size:12.5px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--bronze);margin-left:12px;">{esc(r.get("role"))}</span></b>
        <span style="display:block;font-family:var(--sans);font-size:16px;color:var(--muted);line-height:1.5;margin-top:4px;">{esc(r.get("resp"))}</span></div></li>'''
        for r in deck.table('team', 'members')[:6])
    out.append(f'''<section class="slide ax"{skip_attr(deck.enabled("team"))} data-screen-label="10 Team">
  {mast("team")}
  <div class="ax-body">
    <h2 class="ax-h anim" style="font-size:52px;margin-bottom:16px;">Who is accountable</h2>
    <p class="ax-lead anim d1" style="color:var(--muted);font-size:22px;max-width:1300px;margin-bottom:40px;">{esc(deck.text("team","lead"))}</p>
    <div style="display:flex;gap:70px;flex:1;align-items:stretch;">
      <div class="bpanel anim d1" style="flex:0 0 430px;display:flex;flex-direction:column;justify-content:center;gap:16px;">
        <div class="bk">Engagement lead</div>
        <div style="font-family:var(--serif);font-weight:700;font-size:38px;">{esc(deck.text("team","lead_name"))}</div>
        <div style="font-family:var(--mono);font-size:13.5px;letter-spacing:.14em;text-transform:uppercase;color:var(--bronze);">{esc(deck.text("team","lead_title"))}</div>
        <p style="margin:0;font-size:17px;line-height:1.55;color:rgba(247,246,242,.74);">{esc(deck.text("team","lead_resp"))}</p>
      </div>
      <div class="anim d2" style="flex:1;display:flex;flex-direction:column;justify-content:center;">
        <div class="ax-kick" style="margin-bottom:10px;">Core delivery team</div>
        <ul class="ctx">{members}</ul>
      </div>
    </div>
  </div>
  {foot("team")}
</section>''')

    # ---- 11 INVESTMENT & ROI ----
    prows = ''.join(
        f'<tr><td class="num bronze">{esc(r.get("phase"))}</td><td class="it" style="font-size:19px;">{esc(r.get("deliverable"))}</td>'
        f'<td>{esc(r.get("duration"))}</td><td class="num" style="text-align:right;">{esc(r.get("investment"))}</td></tr>'
        for r in deck.table('pricing', 'phases')[:7])
    roi = ''.join(
        f'''<div style="flex:1;">
        <div style="font-family:var(--serif);font-weight:700;font-size:38px;letter-spacing:-.01em;color:var(--bronze);">{esc(r.get("value"))}</div>
        <div style="font-family:var(--mono);font-size:12.5px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:var(--ink);margin-top:8px;">{esc(r.get("label"))}</div>
        <div class="ax-note" style="font-size:14.5px;margin-top:4px;">{esc(r.get("note"))}</div></div>'''
        for r in deck.table('pricing', 'roi')[:3])
    out.append(f'''<section class="slide ax"{skip_attr(deck.enabled("pricing"))} data-screen-label="11 Investment & ROI">
  {mast("pricing")}
  <div class="ax-body">
    <h2 class="ax-h anim" style="font-size:52px;margin-bottom:40px;">The investment - and the return</h2>
    <div style="display:flex;gap:70px;flex:1;align-items:center;">
      <div class="anim d1" style="flex:1.55;">
        <table class="bt"><thead><tr><th>Phase</th><th>Deliverable</th><th>Duration</th><th style="text-align:right;">Investment</th></tr></thead>
        <tbody>{prows}
          <tr class="total"><td colspan="3">{esc(deck.text("pricing","total_label"))}</td>
          <td class="num" style="text-align:right;color:var(--bronze);font-size:24px;">{esc(deck.text("pricing","total_amount"))}</td></tr>
        </tbody></table>
        <div style="display:flex;gap:54px;border-top:2px solid var(--rule);margin-top:28px;padding-top:24px;">{roi}</div>
      </div>
      <div class="vr"></div>
      <div style="flex:1;display:flex;flex-direction:column;gap:26px;justify-content:center;">
        <div class="bpanel anim d2" style="border-top:5px solid var(--bronze);">
          <div class="bk" style="margin-bottom:12px;">Recommended</div>
          <div style="font-family:var(--serif);font-weight:700;font-size:25px;margin-bottom:10px;">{esc(deck.text("pricing","rec_name"))}</div>
          <p style="margin:0 0 16px;font-size:16.5px;line-height:1.5;color:rgba(247,246,242,.74);">{esc(deck.text("pricing","rec_desc"))}</p>
          <div style="font-family:var(--serif);font-weight:700;font-size:36px;color:var(--bronze);">{esc(deck.text("pricing","rec_price"))}</div>
        </div>
        <div class="anim d3" style="border:1px solid var(--line);border-top:5px solid var(--line);padding:26px 32px;">
          <div style="font-family:var(--serif);font-weight:700;font-size:20px;margin-bottom:8px;">Alternative: {esc(deck.text("pricing","alt_name"))}</div>
          <p class="ax-note" style="margin:0 0 12px;">{esc(deck.text("pricing","alt_desc"))}</p>
          <div style="font-family:var(--serif);font-weight:700;font-size:28px;">{esc(deck.text("pricing","alt_price"))}</div>
        </div>
      </div>
    </div>
  </div>
  {foot("pricing")}
</section>''')

    # ---- 12 KPIs ----
    krows = ''.join(
        f'<tr><td class="it" style="font-size:19px;">{esc(r.get("kpi"))}</td>'
        f'<td style="color:var(--muted);">{esc(r.get("baseline"))}</td>'
        f'<td class="num bronze">{esc(r.get("target"))}</td>'
        f'<td class="num">{esc(r.get("when"))}</td></tr>'
        for r in deck.table('kpis', 'rows')[:7])
    out.append(f'''<section class="slide ax"{skip_attr(deck.enabled("kpis"))} data-screen-label="12 Success Metrics">
  {mast("kpis")}
  <div class="ax-body">
    <h2 class="ax-h anim" style="font-size:52px;margin-bottom:16px;">What success looks like</h2>
    <p class="ax-lead anim d1" style="color:var(--muted);font-size:22px;max-width:1300px;margin-bottom:38px;">{esc(deck.text("kpis","lead"))}</p>
    <div class="anim d2" style="flex:1;display:flex;flex-direction:column;justify-content:center;">
      <table class="bt"><thead><tr><th style="width:36%;">KPI</th><th style="width:20%;">Baseline</th><th style="width:20%;">Target</th><th>Lands by</th></tr></thead>
      <tbody>{krows}</tbody></table>
    </div>
    <p class="ax-note anim d3" style="border-left:3px solid var(--bronze);padding-left:22px;margin:28px 0 0;max-width:1200px;">{esc(deck.text("kpis","cadence"))}</p>
  </div>
  {foot("kpis")}
</section>''')

    # ---- 13 NEXT STEPS ----
    steps = ''.join(
        f'''<li><span class="nn">{i+1:02d}</span><div><b>{esc(r.get("title"))}
        <span style="font-family:var(--mono);font-size:13px;font-weight:700;letter-spacing:.1em;color:var(--bronze);margin-left:14px;">{esc(r.get("when")).upper()}</span></b>
        <span>{esc(r.get("desc"))}</span></div></li>'''
        for i, r in enumerate(deck.table('nextsteps', 'steps')[:5]))
    out.append(f'''<section class="slide ax"{skip_attr(deck.enabled("nextsteps"))} data-screen-label="13 Next Steps">
  {mast("nextsteps")}
  <div class="ax-body">
    <h2 class="ax-h anim" style="font-size:52px;margin-bottom:40px;">From decision to delivery</h2>
    <div class="anim d1" style="flex:1;display:flex;flex-direction:column;justify-content:center;max-width:1400px;">
      <ul class="nlist">{steps}</ul>
    </div>
    <div class="signoff anim d2">
      <div>
        <div class="ax-kick" style="margin-bottom:10px;">{esc(deck.text("nextsteps","deadline_label"))}</div>
        <div class="dt">{esc(deck.text("nextsteps","deadline_date"))}</div>
        <p class="ax-note" style="margin:8px 0 0;">{esc(deck.text("nextsteps","deadline_note"))}</p>
      </div>
      <div class="vr" style="background:var(--rule);width:2px;"></div>
      <div>
        <div class="ax-kick" style="margin-bottom:10px;">Your point of contact</div>
        <div style="font-family:var(--serif);font-weight:700;font-size:26px;">{esc(deck.text("nextsteps","poc_name"))}</div>
        <p class="ax-note" style="margin:8px 0 0;font-family:var(--mono);font-size:15px;">{esc(deck.text("nextsteps","poc_email"))} - {esc(deck.text("nextsteps","poc_phone"))}</p>
      </div>
    </div>
  </div>
  {foot("nextsteps")}
</section>''')

    # ---- 14 THANK YOU ----
    out.append(f'''<section class="slide ax"{skip_attr(deck.enabled("thankyou"))} data-screen-label="14 Thank You">
  <div class="ax-mast"><span class="wb" style="font-size:24px;"><i>{letter}</i>&nbsp;&nbsp;{short}</span>
    <span class="sec">{esc(deck.m("doc_date"))} - {esc(deck.m("doc_version"))}</span></div>
  <div class="ax-body" style="justify-content:center;">
    <div class="ax-kick anim">With thanks</div>
    <h1 class="ax-h anim d1" style="font-size:124px;margin:34px 0 36px;">{esc(deck.text("thankyou","headline"))}</h1>
    <div class="anim d1" style="width:120px;height:3px;background:var(--bronze);margin-bottom:36px;"></div>
    <p class="ax-lead anim d2" style="max-width:1100px;color:var(--muted);margin-bottom:64px;">{esc(deck.text("thankyou","message"))}</p>
    <div class="anim d3" style="display:flex;gap:64px;font-family:var(--mono);font-size:15.5px;letter-spacing:.06em;">
      <span><span style="color:var(--muted);">EMAIL</span>&nbsp;&nbsp;{esc(deck.text("thankyou","email"))}</span>
      <span><span style="color:var(--muted);">PHONE</span>&nbsp;&nbsp;{esc(deck.text("thankyou","phone"))}</span>
      <span><span style="color:var(--muted);">WEB</span>&nbsp;&nbsp;{esc(deck.text("thankyou","web"))}</span>
    </div>
  </div>
  <div class="ax-foot"><span>{esc(deck.m("confidential"))}</span><span>{esc(deck.m("brand_name"))}</span><span class="pg">End</span></div>
</section>''')

    return '\n'.join(out)
