"""
Helix - midnight-navy tech pitch.

A bespoke renderer (shares no layout with the other templates): centred,
hero-led compositions on a calm midnight-navy canvas with quiet slate cards
and a single azure accent. Deliberately restrained for a dark theme - no
neon gradients, glow orbs or mesh overlays - so it reads as a professional
boardroom dark mode rather than a product-launch keynote.

Renders the full canonical 14-slide proposal set defined in schema.py.

Self-contained and fully offline - system font stack only.
"""

from __future__ import annotations

from ..render_common import (
    Deck, esc, esc_br, footer_positions, gantt_geometry, gantt_unit, skip_attr, risk_class,
)

META = {
    'id': 'helix',
    'name': 'Helix - Midnight Navy',
    'tagline': 'Centred, hero-led slides on a calm midnight-navy canvas - quiet slate cards, one azure accent. Modern & professional.',
    'body_bg': '#121C2E',
    'accent': '#5CA8E8',
}

CSS = r"""
:root{
  --bg:#152033;--surface:#1C2A40;--surface2:#21304A;
  --fg:#E9EEF6;--muted:#9DACC0;--line:rgba(255,255,255,.09);--bd:rgba(255,255,255,.13);
  --accent:#5CA8E8;--accent-soft:rgba(92,168,232,.13);
  --green:#4CC38A;--amber:#E2B35C;--red:#E07A78;
  --body:'Segoe UI',system-ui,-apple-system,'Helvetica Neue',Arial,sans-serif;
  --mono:'Consolas','SFMono-Regular','Courier New',monospace;
  --pad:96px;
}
*{box-sizing:border-box;}
.slide.hx{position:relative;display:flex;flex-direction:column;background:var(--bg);color:var(--fg);font-family:var(--body);overflow:hidden;}
/* floating chrome - no solid header bar */
.hx-top{position:relative;z-index:3;display:flex;align-items:center;justify-content:space-between;padding:44px var(--pad) 0;}
.hx-logo{display:flex;align-items:center;gap:13px;font-weight:700;font-size:19px;letter-spacing:.02em;}
.hx-logo .mk{width:36px;height:36px;border-radius:10px;background:var(--accent);display:grid;place-items:center;font-weight:800;font-size:17px;color:#0D1726;}
.hx-tag{font-family:var(--mono);font-size:13.5px;letter-spacing:.2em;text-transform:uppercase;color:var(--muted);display:flex;align-items:center;gap:14px;}
.hx-tag .ix{color:var(--accent);font-weight:700;}
.hx-foot{position:relative;z-index:3;display:flex;align-items:center;justify-content:space-between;padding:0 var(--pad) 36px;font-family:var(--mono);font-size:13px;letter-spacing:.1em;color:var(--muted);}
.hx-foot .pg b{color:var(--fg);}
.hx-body{position:relative;z-index:2;flex:1;min-height:0;display:flex;flex-direction:column;padding:38px var(--pad);}
/* type */
.hx-eyebrow{display:inline-flex;align-items:center;gap:12px;font-family:var(--mono);font-size:14px;letter-spacing:.26em;text-transform:uppercase;font-weight:700;color:var(--accent);}
.hx-h{font-weight:700;letter-spacing:-.02em;line-height:1.06;margin:0;}
.hx-lead{font-size:22px;line-height:1.55;color:var(--muted);margin:0;}
.acc{color:var(--accent);}
.hx-rule{width:72px;height:3px;background:var(--accent);border-radius:2px;margin:22px auto 0;}
/* cards */
.gcard{background:var(--surface);border:1px solid var(--bd);border-radius:14px;padding:32px 34px;}
.gcard.hl{border-top:3px solid var(--accent);}
.chip{display:inline-block;font-family:var(--mono);font-size:12.5px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;padding:6px 14px;border-radius:999px;border:1px solid var(--bd);color:var(--muted);background:var(--surface);}
.chip.hot{background:var(--accent);color:#0D1726;border-color:var(--accent);}
.fdot{width:44px;height:44px;border-radius:12px;background:var(--accent);display:grid;place-items:center;color:#0D1726;font-weight:800;font-size:19px;flex:none;}
.hx-grid{display:grid;gap:22px;}
/* table */
.gt{width:100%;border-collapse:collapse;}
.gt th{font-family:var(--mono);font-size:12.5px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:var(--muted);text-align:left;padding:0 18px 13px 0;border-bottom:1px solid var(--bd);}
.gt td{font-size:17px;line-height:1.5;padding:15px 18px 15px 0;border-bottom:1px solid var(--line);vertical-align:top;}
.gt td.it{font-weight:700;font-size:17.5px;}
.gt td.num{font-family:var(--mono);font-weight:700;}
.gt tr.total td{border-top:1px solid var(--bd);border-bottom:0;font-weight:800;font-size:20px;padding-top:18px;}
/* checklists */
.cklist{list-style:none;margin:0;padding:0;}
.cklist li{display:flex;gap:14px;align-items:flex-start;padding:12px 0;border-bottom:1px solid var(--line);font-size:17px;line-height:1.5;}
.cklist li::before{content:"OK";font-weight:800;color:var(--accent);flex:none;}
/* layer diagram */
.hx-layer{display:flex;align-items:stretch;gap:14px;}
.hx-layer .lname{flex:0 0 150px;display:flex;align-items:center;justify-content:flex-end;font-family:var(--mono);font-size:12.5px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);padding-right:8px;}
.hx-layer .lnodes{flex:1;display:flex;gap:12px;}
.hx-node{flex:1;display:grid;place-items:center;text-align:center;padding:15px 10px;border-radius:10px;background:var(--surface2);border:1px solid var(--bd);font-size:14.5px;font-weight:600;}
.hx-spine{width:3px;background:var(--accent);border-radius:2px;margin:0 auto;height:16px;opacity:.55;}
/* gantt */
.gxhead{display:grid;grid-template-columns:170px 1fr;gap:22px;font-family:var(--mono);font-size:12.5px;font-weight:700;letter-spacing:.1em;color:var(--muted);border-bottom:1px solid var(--bd);padding-bottom:10px;}
.gxrow{display:grid;grid-template-columns:170px 1fr;gap:22px;align-items:center;border-bottom:1px solid var(--line);}
.gxrow .gname{font-weight:700;font-size:17px;padding:15px 0;}
.gxtrack{position:relative;height:40px;}
.gxbar{position:absolute;top:8px;bottom:8px;border-radius:999px;background:rgba(255,255,255,.18);}
.gxbar.hot{background:var(--accent);}
.gxms{position:absolute;top:50%;width:15px;height:15px;border-radius:50%;background:var(--accent);transform:translate(-50%,-50%);border:3px solid var(--bg);box-shadow:0 0 0 1.5px var(--accent);}
/* people */
.ring{width:76px;height:76px;border-radius:50%;padding:3px;background:var(--accent);}
.ring .in{width:100%;height:100%;border-radius:50%;background:var(--surface2);display:grid;place-items:center;font-weight:800;font-size:24px;color:var(--fg);}
/* risk dots */
.hxdot{display:inline-flex;align-items:center;gap:9px;font-family:var(--mono);font-size:14px;font-weight:700;}
.hxdot::before{content:"";width:11px;height:11px;border-radius:50%;background:var(--dv,var(--amber));}
.hxdot.r{--dv:var(--red);}.hxdot.a{--dv:var(--amber);}.hxdot.g{--dv:var(--green);}
@media (prefers-reduced-motion:no-preference){
  [data-deck-active] .anim{animation:hxin .6s cubic-bezier(.2,.7,.3,1) both;}
  [data-deck-active] .anim.d1{animation-delay:.07s;}[data-deck-active] .anim.d2{animation-delay:.14s;}
  [data-deck-active] .anim.d3{animation-delay:.21s;}[data-deck-active] .anim.d4{animation-delay:.28s;}
  @keyframes hxin{from{opacity:0;transform:translateY(18px);}to{opacity:1;transform:none;}}
}
"""


def render(payload) -> str:
    deck = payload if isinstance(payload, Deck) else Deck(payload)
    pos = footer_positions(deck)
    letter, short = esc(deck.m('logo_letter')), esc(deck.m('brand_short'))

    from ..schema import SLIDE_BY_KEY

    def logo(size=36, font=19):
        return (f'<div class="hx-logo" style="font-size:{font}px;">'
                f'<span class="mk" style="width:{size}px;height:{size}px;">{letter}</span> {short}</div>')

    def top(key):
        meta = SLIDE_BY_KEY[key]
        n, _ = pos[key]
        return (f'<div class="hx-top">{logo()}'
                f'<div class="hx-tag"><span class="ix">{n}</span> {esc(meta["eyebrow"])} - {esc(meta["title"])}</div></div>')

    def foot(key):
        n, t = pos[key]
        return (f'<div class="hx-foot"><span>{esc(deck.m("confidential"))} - {esc(deck.m("client_name"))}</span>'
                f'<span class="pg"><b>{n}</b> / {t}</span></div>')

    def headline(small, big, lead=''):
        lead_html = f'<p class="hx-lead anim d1" style="max-width:1100px;margin:14px auto 0;">{esc(lead)}</p>' if lead else ''
        return (f'<div style="text-align:center;margin-bottom:36px;">'
                f'<div class="hx-eyebrow anim">{esc(small)}</div>'
                f'<h2 class="hx-h anim" style="font-size:52px;margin-top:14px;">{big}</h2>{lead_html}</div>')

    out = []

    # ---- 1 COVER ----
    out.append(f'''<section class="slide hx"{skip_attr(deck.enabled("cover"))} data-screen-label="01 Cover">
  <div class="hx-top">{logo(44, 23)}<div class="hx-tag">Technology Proposal</div></div>
  <div class="hx-body" style="justify-content:center;align-items:center;text-align:center;">
    <div class="anim"><span class="chip hot">Prepared for {esc(deck.m("client_name"))}</span></div>
    <h1 class="hx-h anim d1" style="font-size:96px;max-width:1500px;margin:36px 0 0;">{esc_br(deck.text("cover","title"))}</h1>
    <div class="hx-rule anim d1"></div>
    <p class="hx-lead anim d2" style="font-size:25px;max-width:1060px;margin-top:30px;">{esc(deck.text("cover","tagline"))}</p>
    <div class="anim d3" style="display:flex;gap:16px;margin-top:48px;">
      <span class="chip">{esc(deck.m("brand_name"))}</span>
      <span class="chip">{esc(deck.m("doc_date"))}</span>
      <span class="chip">{esc(deck.m("doc_version"))}</span>
    </div>
  </div>
  <div class="hx-foot"><span>{esc(deck.m("confidential"))}</span><span class="pg">{esc(deck.m("brand_name"))}</span></div>
</section>''')

    # ---- 2 EXECUTIVE SUMMARY ----
    kindcolor = {'problem': 'var(--red)', 'solution': 'var(--accent)', 'value': 'var(--green)'}
    stats = ''.join(
        f'''<div class="gcard anim d{i+2}" style="text-align:center;border-top:3px solid {kindcolor.get((r.get("kind") or "solution").strip().lower(), "var(--accent)")};">
        <div style="font-family:var(--mono);font-size:12.5px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:{kindcolor.get((r.get("kind") or "solution").strip().lower(), "var(--accent)")};">{esc(r.get("heading"))}</div>
        <div style="font-size:46px;font-weight:800;letter-spacing:-.02em;margin:14px 0 12px;">{esc(r.get("metric"))}</div>
        <p style="margin:0;font-size:16px;line-height:1.55;color:var(--muted);">{esc(r.get("desc"))}</p></div>'''
        for i, r in enumerate(deck.table('exec', 'stats')[:3]))
    out.append(f'''<section class="slide hx"{skip_attr(deck.enabled("exec"))} data-screen-label="02 Executive Summary">
  {top("exec")}
  <div class="hx-body" style="justify-content:center;">
    <div style="text-align:center;margin-bottom:50px;">
      <div class="hx-eyebrow anim">The story in 60 seconds</div>
      <p class="hx-lead anim d1" style="font-size:27px;color:var(--fg);max-width:1340px;margin:24px auto 0;">{esc(deck.text("exec","lead"))}</p>
    </div>
    <div class="hx-grid" style="grid-template-columns:repeat(3,1fr);max-width:1560px;width:100%;margin:0 auto;">{stats}</div>
  </div>
  {foot("exec")}
</section>''')

    # ---- 3 CURRENT STATE & PAIN POINTS ----
    pains = ''.join(
        f'''<div class="gcard anim d{i+1}" style="display:flex;gap:18px;align-items:flex-start;padding:24px 28px;">
        <div class="fdot">{i+1:02d}</div>
        <div><div style="font-size:19px;font-weight:700;margin-bottom:6px;">{esc(r.get("heading"))}</div>
        <p style="margin:0;font-size:15.5px;line-height:1.5;color:var(--muted);">{esc(r.get("detail"))}</p></div></div>'''
        for i, r in enumerate(deck.table('challenge', 'pains')[:5]))
    impacts = ''.join(
        f'''<div style="padding:20px 0;border-bottom:1px solid var(--line);">
        <div class="acc" style="font-size:42px;font-weight:800;letter-spacing:-.02em;">{esc(r.get("metric"))}</div>
        <div style="font-size:15.5px;color:var(--muted);margin-top:6px;line-height:1.4;">{esc(r.get("label"))}</div></div>'''
        for r in deck.table('challenge', 'impacts')[:4])
    out.append(f'''<section class="slide hx"{skip_attr(deck.enabled("challenge"))} data-screen-label="03 Current State">
  {top("challenge")}
  <div class="hx-body">
    {headline("Where things stand today", 'The <span class="acc">current state</span>')}
    <div style="display:flex;gap:40px;flex:1;align-items:stretch;max-width:1660px;width:100%;margin:0 auto;">
      <div style="flex:1.5;display:flex;flex-direction:column;gap:16px;justify-content:center;">{pains}</div>
      <div class="gcard hl anim d3" style="flex:0 0 430px;display:flex;flex-direction:column;justify-content:center;">
        <div class="hx-eyebrow" style="margin-bottom:6px;">Cost of doing nothing</div>{impacts}
      </div>
    </div>
  </div>
  {foot("challenge")}
</section>''')

    # ---- 4 OPPORTUNITY / BUSINESS CASE ----
    drivers = ''.join(
        f'''<div class="gcard anim d{i+1}" style="flex:1;">
        <div class="hx-eyebrow" style="font-size:12.5px;margin-bottom:12px;">Driver {i+1:02d}</div>
        <div style="font-size:19px;font-weight:700;margin-bottom:8px;">{esc(r.get("driver"))}</div>
        <p style="margin:0;font-size:15.5px;line-height:1.5;color:var(--muted);">{esc(r.get("detail"))}</p></div>'''
        for i, r in enumerate(deck.table('opportunity', 'drivers')[:4]))
    align_chips = ''.join(f'<span class="chip" style="color:var(--fg);">{esc(a)}</span>'
                          for a in deck.list('opportunity', 'alignment')[:4])
    out.append(f'''<section class="slide hx"{skip_attr(deck.enabled("opportunity"))} data-screen-label="04 Opportunity">
  {top("opportunity")}
  <div class="hx-body">
    {headline("Why now", 'The <span class="acc">opportunity</span>', deck.text("opportunity","lead"))}
    <div style="display:flex;gap:22px;max-width:1660px;width:100%;margin:0 auto 26px;">{drivers}</div>
    <div style="display:flex;gap:22px;max-width:1660px;width:100%;margin:0 auto;">
      <div class="gcard anim d3" style="flex:1;border-top:3px solid var(--red);">
        <div style="font-family:var(--mono);font-size:12.5px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:var(--red);margin-bottom:10px;">Cost of inaction</div>
        <p style="margin:0;font-size:16.5px;line-height:1.6;color:var(--muted);">{esc(deck.text("opportunity","inaction"))}</p>
      </div>
      <div class="gcard anim d4" style="flex:1;border-top:3px solid var(--green);">
        <div style="font-family:var(--mono);font-size:12.5px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:var(--green);margin-bottom:10px;">Benefit of acting now</div>
        <p style="margin:0;font-size:16.5px;line-height:1.6;color:var(--muted);">{esc(deck.text("opportunity","action"))}</p>
      </div>
    </div>
    <div class="anim d4" style="display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;margin:30px auto 0;max-width:1660px;">
      <span style="font-family:var(--mono);font-size:12.5px;letter-spacing:.16em;text-transform:uppercase;color:var(--muted);">Strategic alignment</span>{align_chips}
    </div>
  </div>
  {foot("opportunity")}
</section>''')

    # ---- 5 PROPOSED SOLUTION ----
    layers = deck.table('solution', 'arch_layers')[:5]
    lhtml = []
    for li, lr in enumerate(layers):
        nodes = ''.join(f'<div class="hx-node">{esc(n.strip())}</div>'
                        for n in str(lr.get('nodes', '')).split(',') if n.strip()) or '<div class="hx-node" style="opacity:.3;">-</div>'
        lhtml.append(f'<div class="hx-layer anim d{li+1}"><div class="lname">{esc(lr.get("layer"))}</div><div class="lnodes">{nodes}</div></div>')
        if li < len(layers) - 1:
            lhtml.append('<div class="hx-spine"></div>')
    smap = ''.join(
        f'''<div style="display:grid;grid-template-columns:1fr 34px 1.1fr;gap:14px;align-items:center;padding:14px 0;border-bottom:1px solid var(--line);">
        <span style="font-size:16px;color:var(--muted);">{esc(r.get("need"))}</span>
        <span class="acc" style="font-weight:800;font-size:19px;text-align:center;">-></span>
        <span style="font-size:16.5px;font-weight:700;">{esc(r.get("solution"))}</span></div>'''
        for r in deck.table('solution', 'solution_map')[:7])
    out.append(f'''<section class="slide hx"{skip_attr(deck.enabled("solution"))} data-screen-label="05 Proposed Solution">
  {top("solution")}
  <div class="hx-body">
    {headline("The recommendation", 'The proposed <span class="acc">solution</span>', deck.text("solution","lead"))}
    <div style="display:flex;gap:46px;flex:1;align-items:stretch;max-width:1700px;width:100%;margin:0 auto;">
      <div class="gcard anim d1" style="flex:1.2;display:flex;flex-direction:column;justify-content:center;gap:12px;">
        <div class="hx-eyebrow" style="margin-bottom:10px;">Target architecture</div>
        {''.join(lhtml)}
        <div style="text-align:center;font-family:var(--mono);font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);margin-top:10px;">{esc(deck.text("solution","arch_caption"))}</div>
      </div>
      <div class="anim d2" style="flex:1;display:flex;flex-direction:column;justify-content:center;">
        <div class="hx-eyebrow" style="margin-bottom:14px;">Pain point -> our solution</div>
        {smap}
      </div>
    </div>
  </div>
  {foot("solution")}
</section>''')

    # ---- 6 KEY BENEFITS ----
    bens = ''.join(
        f'''<div class="gcard anim d{min(i + 1, 4)}" style="text-align:center;padding:28px 26px;">
        <div class="acc" style="font-size:40px;font-weight:800;letter-spacing:-.02em;">{esc(r.get("metric"))}</div>
        <div style="font-size:18px;font-weight:700;margin:10px 0 8px;">{esc(r.get("title"))}</div>
        <p style="margin:0;font-size:14.5px;line-height:1.5;color:var(--muted);">{esc(r.get("desc"))}</p></div>'''
        for i, r in enumerate(deck.table('benefits', 'items')[:6]))
    out.append(f'''<section class="slide hx"{skip_attr(deck.enabled("benefits"))} data-screen-label="06 Key Benefits">
  {top("benefits")}
  <div class="hx-body">
    {headline("What you gain", 'Key <span class="acc">benefits</span>', deck.text("benefits","lead"))}
    <div class="hx-grid" style="grid-template-columns:repeat(3,1fr);flex:1;align-content:center;max-width:1660px;width:100%;margin:0 auto;">{bens}</div>
  </div>
  {foot("benefits")}
</section>''')

    # ---- 7 APPROACH & METHODOLOGY ----
    methods = ''.join(f'<span class="chip" style="color:var(--fg);">{esc(m)}</span>'
                      for m in deck.list('approach', 'methodologies')[:6])
    phases = ''.join(
        f'''<div class="anim d{i+1}" style="flex:1;text-align:center;">
        <div class="fdot" style="margin:0 auto 12px;">{i+1}</div>
        <div style="font-size:18px;font-weight:700;margin-bottom:4px;">{esc(r.get("name"))}</div>
        <div style="font-size:14.5px;color:var(--muted);line-height:1.4;">{esc(r.get("desc"))}</div></div>'''
        for i, r in enumerate(deck.table('approach', 'phases')[:6]))
    out.append(f'''<section class="slide hx"{skip_attr(deck.enabled("approach"))} data-screen-label="07 Approach">
  {top("approach")}
  <div class="hx-body">
    {headline("How we deliver", 'Approach &amp; <span class="acc">methodology</span>', deck.text("approach","lead"))}
    <div class="anim d1" style="display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;margin-bottom:38px;">{methods}</div>
    <div style="display:flex;gap:20px;max-width:1660px;width:100%;margin:0 auto 36px;">{phases}</div>
    <div class="gcard hl anim d4" style="max-width:1660px;width:100%;margin:0 auto;">
      <div class="hx-eyebrow" style="margin-bottom:10px;">How we'll work with you</div>
      <p style="margin:0;font-size:17px;line-height:1.6;color:var(--muted);">{esc(deck.text("approach","collaboration"))}</p>
    </div>
  </div>
  {foot("approach")}
</section>''')

    # ---- 8 ROADMAP & TIMELINE ----
    bars, total = gantt_geometry(deck)
    unit_prefix, unit_word = gantt_unit(deck)
    months = max(int(round(total)), 1)
    shown = min(months, 18)
    grid_bg = f'background-image:repeating-linear-gradient(90deg,var(--line) 0,var(--line) 1px,transparent 1px,transparent {100/shown:.4f}%);'
    month_cells = ''.join(f'<div>{unit_prefix}{i+1}</div>' for i in range(shown))
    rows_html = ''.join(
        f'''<div class="gxrow"><div class="gname">{esc(b["name"])}</div>
        <div class="gxtrack" style="{grid_bg}">
          <div class="gxbar{" hot" if b["milestone"] else ""}" style="left:{b["left"]}%;width:{b["width"]}%;"></div>
          {f'<span class="gxms" style="left:{b["end"]}%;"></span>' if b["milestone"] else ''}
        </div></div>'''
        for b in bars)
    out.append(f'''<section class="slide hx"{skip_attr(deck.enabled("roadmap"))} data-screen-label="08 Roadmap">
  {top("roadmap")}
  <div class="hx-body">
    {headline("Timeline", 'The <span class="acc">roadmap</span>', deck.text("roadmap","lead"))}
    <div class="gcard anim d2" style="flex:1;display:flex;flex-direction:column;justify-content:center;max-width:1700px;width:100%;margin:0 auto;">
      <div class="gxhead"><div>PHASE</div><div style="display:grid;grid-template-columns:repeat({shown},1fr);">{month_cells}</div></div>
      {rows_html}
      <div style="display:flex;gap:26px;margin-top:20px;font-family:var(--mono);font-size:13px;color:var(--muted);">
        <span style="display:flex;align-items:center;gap:10px;"><span style="width:13px;height:13px;border-radius:50%;background:var(--accent);display:inline-block;"></span> Milestone gate</span>
      </div>
    </div>
  </div>
  {foot("roadmap")}
</section>''')

    # ---- 9 RISKS & MITIGATIONS ----
    rrows = ''.join(
        f'<tr><td class="it">{esc(r.get("risk"))}</td>'
        f'<td><span class="hxdot {risk_class(r.get("probability"))}">{esc(r.get("probability"))}</span></td>'
        f'<td style="color:var(--muted);">{esc(r.get("mitigation"))}</td></tr>'
        for r in deck.table('risk', 'risks')[:8])
    out.append(f'''<section class="slide hx"{skip_attr(deck.enabled("risk"))} data-screen-label="09 Risks & Mitigations">
  {top("risk")}
  <div class="hx-body">
    {headline("Governance", 'Risks &amp; <span class="acc">mitigations</span>', deck.text("risk","lead"))}
    <div class="gcard anim d2" style="flex:1;display:flex;flex-direction:column;justify-content:center;max-width:1700px;width:100%;margin:0 auto;">
      <table class="gt"><thead><tr><th style="width:28%;">Risk</th><th style="width:14%;">Probability</th><th>Mitigation</th></tr></thead><tbody>{rrows}</tbody></table>
      <div style="display:flex;gap:28px;margin-top:20px;">
        <span class="hxdot g">Low</span><span class="hxdot a">Medium</span><span class="hxdot r">High</span>
      </div>
    </div>
  </div>
  {foot("risk")}
</section>''')

    # ---- 10 TEAM & CAPABILITIES ----
    members = ''.join(
        f'''<div class="gcard anim d{i+1}" style="text-align:center;padding:30px 22px;">
        <div class="ring" style="margin:0 auto 16px;"><div class="in">{esc((r.get("name") or "?").strip()[:1].upper())}</div></div>
        <div style="font-size:19px;font-weight:700;">{esc(r.get("name"))}</div>
        <div class="acc" style="font-family:var(--mono);font-size:12.5px;letter-spacing:.1em;text-transform:uppercase;margin:7px 0 10px;">{esc(r.get("role"))}</div>
        <p style="margin:0;font-size:14.5px;line-height:1.45;color:var(--muted);">{esc(r.get("resp"))}</p></div>'''
        for i, r in enumerate(deck.table('team', 'members')[:6]))
    out.append(f'''<section class="slide hx"{skip_attr(deck.enabled("team"))} data-screen-label="10 Team">
  {top("team")}
  <div class="hx-body">
    {headline("People", 'The <span class="acc">team</span>', deck.text("team","lead"))}
    <div style="display:flex;gap:36px;flex:1;align-items:stretch;max-width:1700px;width:100%;margin:0 auto;">
      <div class="gcard hl anim d1" style="flex:0 0 400px;display:flex;flex-direction:column;justify-content:center;text-align:center;">
        <div class="hx-eyebrow" style="margin-bottom:18px;">Engagement lead</div>
        <div class="ring" style="width:96px;height:96px;margin:0 auto 18px;"><div class="in" style="font-size:32px;">{esc((deck.text("team","lead_name") or "?").strip()[:1].upper())}</div></div>
        <div style="font-size:25px;font-weight:800;">{esc(deck.text("team","lead_name"))}</div>
        <div class="acc" style="font-family:var(--mono);font-size:13px;letter-spacing:.1em;text-transform:uppercase;margin:8px 0 14px;">{esc(deck.text("team","lead_title"))}</div>
        <p style="margin:0;font-size:15.5px;line-height:1.55;color:var(--muted);">{esc(deck.text("team","lead_resp"))}</p>
      </div>
      <div class="hx-grid" style="flex:1;grid-template-columns:repeat(2,1fr);align-content:center;">{members}</div>
    </div>
  </div>
  {foot("team")}
</section>''')

    # ---- 11 INVESTMENT & ROI ----
    prows = ''.join(
        f'<tr><td class="num acc">{esc(r.get("phase"))}</td><td class="it">{esc(r.get("deliverable"))}</td>'
        f'<td>{esc(r.get("duration"))}</td><td class="num" style="text-align:right;">{esc(r.get("investment"))}</td></tr>'
        for r in deck.table('pricing', 'phases')[:7])
    roi = ''.join(
        f'''<div style="flex:1;text-align:center;padding:0 14px;">
        <div class="acc" style="font-size:34px;font-weight:800;letter-spacing:-.02em;">{esc(r.get("value"))}</div>
        <div style="font-size:15px;font-weight:700;margin-top:6px;">{esc(r.get("label"))}</div>
        <div style="font-size:13px;color:var(--muted);margin-top:3px;">{esc(r.get("note"))}</div></div>'''
        for r in deck.table('pricing', 'roi')[:3])
    out.append(f'''<section class="slide hx"{skip_attr(deck.enabled("pricing"))} data-screen-label="11 Investment & ROI">
  {top("pricing")}
  <div class="hx-body">
    {headline("Investment", 'Investment &amp; <span class="acc">ROI</span>')}
    <div style="display:flex;gap:36px;flex:1;align-items:stretch;max-width:1700px;width:100%;margin:0 auto;">
      <div class="gcard anim d1" style="flex:1.5;display:flex;flex-direction:column;justify-content:center;">
        <table class="gt"><thead><tr><th>Phase</th><th>Deliverable</th><th>Duration</th><th style="text-align:right;">Investment</th></tr></thead>
        <tbody>{prows}
          <tr class="total"><td colspan="3">{esc(deck.text("pricing","total_label"))}</td><td class="acc" style="text-align:right;font-size:23px;">{esc(deck.text("pricing","total_amount"))}</td></tr>
        </tbody></table>
        <div style="display:flex;align-items:stretch;border-top:1px solid var(--bd);margin-top:22px;padding-top:22px;">{roi}</div>
      </div>
      <div style="flex:1;display:flex;flex-direction:column;gap:22px;justify-content:center;">
        <div class="gcard hl anim d2" style="position:relative;">
          <span class="chip hot" style="position:absolute;top:-15px;left:34px;">Recommended</span>
          <div style="font-size:23px;font-weight:800;margin:8px 0 10px;">{esc(deck.text("pricing","rec_name"))}</div>
          <p style="margin:0 0 16px;font-size:15.5px;line-height:1.55;color:var(--muted);">{esc(deck.text("pricing","rec_desc"))}</p>
          <div class="acc" style="font-size:36px;font-weight:800;letter-spacing:-.02em;">{esc(deck.text("pricing","rec_price"))}</div>
        </div>
        <div class="gcard anim d3">
          <div style="font-size:19px;font-weight:700;margin-bottom:8px;">Alternative: {esc(deck.text("pricing","alt_name"))}</div>
          <p style="margin:0 0 12px;font-size:15px;line-height:1.5;color:var(--muted);">{esc(deck.text("pricing","alt_desc"))}</p>
          <div style="font-size:26px;font-weight:800;">{esc(deck.text("pricing","alt_price"))}</div>
        </div>
      </div>
    </div>
  </div>
  {foot("pricing")}
</section>''')

    # ---- 12 SUCCESS METRICS & KPIs ----
    krows = ''.join(
        f'<tr><td class="it">{esc(r.get("kpi"))}</td>'
        f'<td style="color:var(--muted);">{esc(r.get("baseline"))}</td>'
        f'<td class="num acc">{esc(r.get("target"))}</td>'
        f'<td class="num">{esc(r.get("when"))}</td></tr>'
        for r in deck.table('kpis', 'rows')[:7])
    out.append(f'''<section class="slide hx"{skip_attr(deck.enabled("kpis"))} data-screen-label="12 Success Metrics">
  {top("kpis")}
  <div class="hx-body">
    {headline("Measurement", 'Success <span class="acc">metrics</span>', deck.text("kpis","lead"))}
    <div class="gcard anim d2" style="flex:1;display:flex;flex-direction:column;justify-content:center;max-width:1700px;width:100%;margin:0 auto;">
      <table class="gt"><thead><tr><th style="width:36%;">KPI</th><th style="width:20%;">Baseline</th><th style="width:20%;">Target</th><th>Lands by</th></tr></thead>
      <tbody>{krows}</tbody></table>
      <p style="margin:20px 0 0;font-size:15.5px;line-height:1.55;color:var(--muted);border-left:3px solid var(--accent);padding-left:18px;">{esc(deck.text("kpis","cadence"))}</p>
    </div>
  </div>
  {foot("kpis")}
</section>''')

    # ---- 13 NEXT STEPS ----
    steps = ''.join(
        f'''<div class="gcard anim d{i+1}" style="flex:1;">
        <div class="fdot" style="margin-bottom:16px;">{i+1:02d}</div>
        <div style="font-size:21px;font-weight:700;margin-bottom:8px;">{esc(r.get("title"))}</div>
        <p style="margin:0 0 14px;font-size:15.5px;line-height:1.5;color:var(--muted);">{esc(r.get("desc"))}</p>
        <span class="chip">{esc(r.get("when"))}</span></div>'''
        for i, r in enumerate(deck.table('nextsteps', 'steps')[:5]))
    out.append(f'''<section class="slide hx"{skip_attr(deck.enabled("nextsteps"))} data-screen-label="13 Next Steps">
  {top("nextsteps")}
  <div class="hx-body" style="justify-content:center;">
    {headline("Action", 'Next <span class="acc">steps</span>')}
    <div style="display:flex;gap:24px;max-width:1660px;width:100%;margin:0 auto 40px;">{steps}</div>
    <div class="gcard hl anim d4" style="display:flex;align-items:center;justify-content:space-between;gap:40px;max-width:1660px;width:100%;margin:0 auto;padding:28px 38px;">
      <div>
        <div style="font-family:var(--mono);font-size:13px;letter-spacing:.2em;text-transform:uppercase;color:var(--muted);">{esc(deck.text("nextsteps","deadline_label"))}</div>
        <div class="acc" style="font-size:32px;font-weight:800;margin-top:6px;">{esc(deck.text("nextsteps","deadline_date"))}</div>
        <div style="font-size:14.5px;color:var(--muted);margin-top:4px;">{esc(deck.text("nextsteps","deadline_note"))}</div>
      </div>
      <div style="display:flex;align-items:center;gap:20px;">
        <div class="ring" style="width:64px;height:64px;"><div class="in" style="font-size:21px;">{esc((deck.text("nextsteps","poc_name") or "?").strip()[:1].upper())}</div></div>
        <div>
          <div style="font-size:19px;font-weight:700;">{esc(deck.text("nextsteps","poc_name"))}</div>
          <div style="font-family:var(--mono);font-size:14px;color:var(--muted);margin-top:4px;">{esc(deck.text("nextsteps","poc_email"))} - {esc(deck.text("nextsteps","poc_phone"))}</div>
        </div>
      </div>
    </div>
  </div>
  {foot("nextsteps")}
</section>''')

    # ---- 14 THANK YOU / Q&A ----
    out.append(f'''<section class="slide hx"{skip_attr(deck.enabled("thankyou"))} data-screen-label="14 Thank You">
  <div class="hx-top">{logo(44, 23)}<div class="hx-tag">{esc(deck.m("doc_date"))} - {esc(deck.m("doc_version"))}</div></div>
  <div class="hx-body" style="justify-content:center;align-items:center;text-align:center;">
    <h1 class="hx-h anim" style="font-size:112px;margin:0;"><span class="acc">{esc(deck.text("thankyou","headline"))}</span></h1>
    <div class="hx-rule anim"></div>
    <p class="hx-lead anim d1" style="font-size:25px;max-width:980px;margin:30px 0 54px;">{esc(deck.text("thankyou","message"))}</p>
    <div class="anim d2" style="display:flex;gap:16px;">
      <span class="chip">{esc(deck.text("thankyou","email"))}</span>
      <span class="chip">{esc(deck.text("thankyou","phone"))}</span>
      <span class="chip">{esc(deck.text("thankyou","web"))}</span>
    </div>
  </div>
  <div class="hx-foot"><span>{esc(deck.m("confidential"))}</span><span class="pg">{esc(deck.m("brand_name"))}</span></div>
</section>''')

    return '\n'.join(out)
