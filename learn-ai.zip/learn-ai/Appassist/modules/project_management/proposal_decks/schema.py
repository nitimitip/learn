"""
Proposal-deck schema - the single source of truth shared by the builder form,
every template renderer, and the live overflow-warning logic.

ONE form, four designs: every template consumes the SAME canonical 14-slide
input set below (Title -> Executive Summary -> Current State -> Opportunity ->
Solution -> Benefits -> Approach -> Roadmap -> Risks -> Team -> Investment & ROI ->
KPIs -> Next Steps -> Thank You). What differs per template is purely the
presentation - each renders these slides through its own bespoke layout.

A deck's data has two parts:

    {
      "template": "npg",
      "meta":   { "<field_key>": <str>, ... },     # brand / dates / client
      "slides": {
          "<slide_key>": {
              "enabled": <bool>,                    # the per-slide Required toggle
              "fields":  { "<field_key>": <value> }
          }, ...
      }
    }

Field value shapes by ``type``:
    text / textarea / select   -> str
    list                       -> list[str]
    table                      -> list[dict]  (each row keyed by column ``key``)

``budget`` is a *recommended* maximum character count. It never blocks export;
the form shows an inline amber warning when a value runs long so the slide
stays inside its design bounds. For ``list`` fields the budget is per item;
for ``table`` fields each column carries its own budget.
"""

from __future__ import annotations


# --- compact field constructors -------------------------------------------

def _f(key, label, ftype, default, *, hint='', budget=0, max_items=0,
       columns=None, options=None, placeholder=''):
    return {
        'key': key, 'label': label, 'type': ftype, 'default': default,
        'hint': hint, 'budget': budget, 'max_items': max_items,
        'columns': columns or [], 'options': options or [],
        'placeholder': placeholder,
    }


def _c(key, label, *, budget=0, ftype='text', options=None):
    """A table column."""
    return {'key': key, 'label': label, 'budget': budget,
            'type': ftype, 'options': options or []}


# --- deck-level meta (brand chrome used on every slide) --------------------

META_FIELDS = [
    _f('brand_name', 'Your company name', 'text', 'Your Company Name',
       hint='Shown on the cover and the thank-you slide.', budget=40),
    _f('brand_short', 'Logo wordmark', 'text', 'BRAND',
       hint='Short brand mark shown in the header of every slide.', budget=14),
    _f('logo_letter', 'Logo monogram', 'text', 'B',
       hint='Single letter shown in the logo badge.', budget=2),
    _f('client_name', 'Client / prospect name', 'text', '[ Client Organization ]',
       hint='Who the proposal is prepared for.', budget=44),
    _f('doc_date', 'Date', 'text', 'June 2026', budget=18),
    _f('doc_version', 'Version', 'text', 'v1.0', budget=10),
    _f('confidential', 'Confidentiality label', 'text', 'Confidential', budget=20),
]


# --- the slide library ------------------------------------------------------
# The canonical proposal flow - every template renders ALL of these slides
# (the per-slide "Included" toggle remains the way to drop one from a deck):
#
#   01 cover        Title
#   02 exec         Executive Summary
#   03 challenge    Current State & Pain Points
#   04 opportunity  Opportunity / Business Case
#   05 solution     Proposed Solution
#   06 benefits     Key Benefits
#   07 approach     Approach & Methodology
#   08 roadmap      Roadmap & Timeline
#   09 risk         Risks & Mitigations
#   10 team         Team & Capabilities
#   11 pricing      Investment & ROI
#   12 kpis         Success Metrics / KPIs
#   13 nextsteps    Next Steps / Call to Action
#   14 thankyou     Thank You / Q&A
#
# slides_for(template) returns this same ordered set for every template.

SLIDES = [
    # 1 - COVER ------------------------------------------------------------
    {
        'key': 'cover', 'num': 1, 'eyebrow': 'Title',
        'title': 'Cover Slide',
        'desc': 'Hero opening with the proposal title, client, date and version.',
        'lockable': False,   # cover is always required
        'fields': [
            _f('title', 'Proposal title', 'textarea',
               'Enterprise Platform\nModernization Proposal',
               hint='Use a line break to control where the title wraps.', budget=64),
            _f('tagline', 'Tagline / summary line', 'textarea',
               'A phased program to consolidate legacy systems, accelerate delivery, '
               'and establish a secure, cloud-native foundation built to scale with your business.',
               budget=190),
        ],
    },
    # 2 - EXECUTIVE SUMMARY ------------------------------------------------
    {
        'key': 'exec', 'num': 2, 'eyebrow': 'Overview',
        'title': 'Executive Summary',
        'desc': 'The story in 60 seconds - a lead paragraph plus three stat boxes (problem, solution, value).',
        'fields': [
            _f('lead', 'Summary paragraph', 'textarea',
               'Your teams are constrained by aging infrastructure and fragmented tooling. '
               'We propose a 9-month modernization program that replaces the bottleneck with a '
               'secure, cloud-native platform - reducing operating cost while unlocking faster, safer delivery.',
               budget=320),
            _f('stats', 'Highlight stats', 'table', [
                {'kind': 'Problem',  'metric': '7+ yrs',      'heading': 'The Problem',
                 'desc': 'of accumulated technical debt across siloed legacy systems slowing every release.'},
                {'kind': 'Solution', 'metric': 'Cloud-native', 'heading': 'The Solution',
                 'desc': 'modular platform delivered in five managed phases with zero-downtime cutover.'},
                {'kind': 'Value',    'metric': '38%',          'heading': 'The Value',
                 'desc': 'projected reduction in run cost and a 3x increase in deployment frequency.'},
            ], max_items=3, columns=[
                _c('kind', 'Type', ftype='select', options=['Problem', 'Solution', 'Value']),
                _c('metric', 'Metric', budget=14),
                _c('heading', 'Heading', budget=22),
                _c('desc', 'Description', budget=120),
            ]),
        ],
    },
    # 3 - CURRENT STATE & PAIN POINTS ---------------------------------------
    {
        'key': 'challenge', 'num': 3, 'eyebrow': 'Context',
        'title': 'Current State & Pain Points',
        'desc': 'An honest look at today - pain points on one side, business impact of doing nothing on the other.',
        'fields': [
            _f('pains', 'Current pain points', 'table', [
                {'heading': 'Fragmented systems', 'detail': 'Six disconnected applications duplicate data and force manual reconciliation.'},
                {'heading': 'Slow release cycles', 'detail': 'Quarterly deployments and manual QA delay every product change.'},
                {'heading': 'Rising maintenance cost', 'detail': '68% of the IT budget is consumed keeping legacy systems alive.'},
                {'heading': 'Limited visibility', 'detail': 'No unified reporting; leadership decisions rely on stale spreadsheets.'},
            ], max_items=5, columns=[
                _c('heading', 'Pain point', budget=34),
                _c('detail', 'Detail', budget=120),
            ]),
            _f('impacts', 'Business impact of doing nothing', 'table', [
                {'metric': '~$1.4M', 'label': 'annual cost of redundant operations'},
                {'metric': '12 wk',  'label': 'average time-to-market per feature'},
                {'metric': '3.2%',   'label': 'monthly unplanned downtime exposure'},
                {'metric': '-24%',   'label': 'engineer productivity vs. industry peers'},
            ], max_items=4, columns=[
                _c('metric', 'Metric', budget=12),
                _c('label', 'Description', budget=56),
            ]),
        ],
    },
    # 4 - OPPORTUNITY / BUSINESS CASE ----------------------------------------
    {
        'key': 'opportunity', 'num': 4, 'eyebrow': 'Business Case',
        'title': 'Opportunity & Business Case',
        'desc': 'Why now - market drivers, cost of inaction vs. benefit of action, and strategic alignment.',
        'fields': [
            _f('lead', 'Intro line', 'textarea',
               'This isn\'t just a technical change - it\'s a business opportunity. The market is '
               'moving, and the gap between acting now and standing still widens every quarter.',
               budget=220),
            _f('drivers', 'Market & internal drivers', 'table', [
                {'driver': 'Industry shift to cloud', 'detail': '78% of peers now run core workloads on cloud platforms.'},
                {'driver': 'Competitor velocity',     'detail': 'Leading competitors release weekly; the market expects digital-first service.'},
                {'driver': 'Rising customer expectations', 'detail': 'Users now expect real-time, self-service experiences across channels.'},
            ], max_items=4, columns=[
                _c('driver', 'Driver / trend', budget=34),
                _c('detail', 'Why it matters', budget=110),
            ]),
            _f('inaction', 'Cost of inaction', 'textarea',
               'Run cost keeps compounding (~$1.4M/yr), release velocity stays flat, and the talent '
               'needed to maintain legacy stacks gets scarcer and more expensive every year.',
               budget=220),
            _f('action', 'Benefit of acting now', 'textarea',
               'A modern platform cuts run cost by ~38%, triples release frequency, and creates the '
               'foundation for new digital revenue streams within 12 months.',
               budget=220),
            _f('alignment', 'Strategic alignment', 'list', [
                'Supports the digital-first corporate strategy',
                'Enables the cost-reduction targets for FY27',
                'De-risks the legacy estate ahead of contract renewals',
                'Builds the platform future products depend on',
            ], hint='One alignment point per line.', budget=64, max_items=4),
        ],
    },
    # 5 - PROPOSED SOLUTION --------------------------------------------------
    {
        'key': 'solution', 'num': 5, 'eyebrow': 'Solution',
        'title': 'Proposed Solution',
        'desc': 'What we recommend - overview, target architecture, and a pain-point -> solution mapping.',
        'fields': [
            _f('lead', 'Solution overview', 'textarea',
               'A modular, cloud-native platform delivered in managed phases - engineered directly '
               'against the pain points on the previous slides, with zero-downtime cutover.',
               budget=220),
            _f('arch_layers', 'Target architecture (top to bottom)', 'table', [
                {'layer': 'Clients', 'nodes': 'Web / Mobile Clients'},
                {'layer': 'Edge',    'nodes': 'API Gateway & Auth'},
                {'layer': 'Services', 'nodes': 'Service A, Service B, Service C'},
                {'layer': 'Data',    'nodes': 'Managed Data & Event Layer'},
            ], max_items=5, columns=[
                _c('layer', 'Layer', budget=18),
                _c('nodes', 'Components (comma-separated)', budget=80),
            ]),
            _f('arch_caption', 'Architecture caption', 'text',
               'Reference architecture - replace with client-specific diagram', budget=64),
            _f('solution_map', 'Pain point -> solution mapping', 'table', [
                {'need': 'Fragmented data', 'solution': 'Unified service & event layer'},
                {'need': 'Slow releases',   'solution': 'Automated CI/CD pipelines'},
                {'need': 'Manual QA',       'solution': 'Test automation & gating'},
                {'need': 'Scaling limits',  'solution': 'Cloud-native autoscaling'},
                {'need': 'Poor visibility', 'solution': 'Centralized observability'},
            ], max_items=7, columns=[
                _c('need', 'Business Need', budget=40),
                _c('solution', 'Our Solution', budget=40),
            ]),
        ],
    },
    # 6 - KEY BENEFITS --------------------------------------------------------
    {
        'key': 'benefits', 'num': 6, 'eyebrow': 'Value',
        'title': 'Key Benefits',
        'desc': 'What the client actually gains - a scannable benefits grid with a headline metric each.',
        'fields': [
            _f('lead', 'Intro line', 'textarea',
               'What you actually gain - measurable improvements across performance, cost, '
               'experience, security and headroom for growth.',
               budget=200),
            _f('items', 'Benefits', 'table', [
                {'title': 'Faster performance',    'metric': '3x',     'desc': 'deployment frequency with automated pipelines and modern infrastructure.'},
                {'title': 'Lower run cost',        'metric': '-38%',   'desc': 'projected annual operating cost once legacy systems retire.'},
                {'title': 'Better user experience', 'metric': '< 2s',  'desc': 'page response across self-service journeys, on any device.'},
                {'title': 'Security & compliance', 'metric': '24x7',   'desc': 'continuous monitoring, encryption everywhere and audit-ready controls.'},
                {'title': 'Improved reliability',  'metric': '99.9%',  'desc': 'platform availability target with automated failover.'},
                {'title': 'Built for growth',      'metric': '10x',    'desc': 'capacity headroom through elastic, cloud-native scaling.'},
            ], max_items=6, columns=[
                _c('title', 'Benefit', budget=26),
                _c('metric', 'Headline metric', budget=10),
                _c('desc', 'Description', budget=90),
            ]),
        ],
    },
    # 7 - APPROACH & METHODOLOGY ----------------------------------------------
    {
        'key': 'approach', 'num': 7, 'eyebrow': 'Delivery',
        'title': 'Approach & Methodology',
        'desc': 'How we\'ll make it happen - methodology badges, a phased plan, and the collaboration model.',
        'fields': [
            _f('lead', 'Intro line', 'textarea',
               'A phased, low-risk delivery - iterative sprints inside clearly gated phases, '
               'with your teams embedded from day one.',
               budget=210),
            _f('methodologies', 'Methodology badges', 'list',
               ['Agile / Scrum', 'DevOps', 'CI / CD', 'Infrastructure as Code', 'Test Automation'],
               hint='One badge per line.', budget=26, max_items=6),
            _f('phases', 'Phased plan', 'table', [
                {'name': 'Foundation', 'desc': 'Cloud & pipeline setup'},
                {'name': 'Build',      'desc': 'Core services & data layer'},
                {'name': 'Integrate',  'desc': 'Systems & migration'},
                {'name': 'Launch',     'desc': 'UAT & go-live'},
            ], max_items=6, columns=[
                _c('name', 'Phase', budget=18),
                _c('desc', 'Description', budget=40),
            ]),
            _f('collaboration', 'How we\'ll work with you', 'textarea',
               'A joint delivery team - weekly demos, a shared backlog, named counterparts on both '
               'sides, and decisions logged in one place so nothing stalls between meetings.',
               budget=220),
        ],
    },
    # 8 - ROADMAP & TIMELINE --------------------------------------------------
    {
        'key': 'roadmap', 'num': 8, 'eyebrow': 'Timeline',
        'title': 'Roadmap & Timeline',
        'desc': 'A horizontal Gantt-style timeline. Set the unit (months or weeks); start/duration are counted in it. Mark milestone gates.',
        'fields': [
            _f('lead', 'Intro line', 'textarea',
               'A 9-month phased delivery with clear milestones and accent-marked go/no-go gates.',
               budget=170),
            _f('unit', 'Timeline unit', 'text', 'Months',
               hint='"Months" or "Weeks" - sets the axis labels (M1, M2... or W1, W2...) '
                    'and the unit the two columns below are counted in.', budget=10),
            _f('total_months', 'Total timeline (in the unit above)', 'text', '9',
               hint='Used to scale the Gantt bars.', budget=4),
            _f('phases', 'Phases', 'table', [
                {'name': 'Kickoff',     'start': '0',   'duration': '1',   'milestone': 'Yes'},
                {'name': 'Discovery',   'start': '0.7', 'duration': '2',   'milestone': 'No'},
                {'name': 'Development', 'start': '2.5', 'duration': '4',   'milestone': 'Yes'},
                {'name': 'UAT',         'start': '6.5', 'duration': '1.5', 'milestone': 'No'},
                {'name': 'Go-Live',     'start': '8',   'duration': '1',   'milestone': 'Yes'},
            ], max_items=7, columns=[
                _c('name', 'Phase', budget=18),
                _c('start', 'Start (unit)', budget=5, ftype='number'),
                _c('duration', 'Duration (units)', budget=5, ftype='number'),
                _c('milestone', 'Milestone gate', ftype='select', options=['Yes', 'No']),
            ]),
        ],
    },
    # 9 - RISKS & MITIGATIONS -------------------------------------------------
    {
        'key': 'risk', 'num': 9, 'eyebrow': 'Governance',
        'title': 'Risks & Mitigations',
        'desc': 'Risk / probability / mitigation table with red-amber-green indicators.',
        'fields': [
            _f('lead', 'Intro line', 'textarea',
               'Key delivery risks identified up front - each with a probability rating and a '
               'concrete mitigation, so there are no surprises during delivery.',
               budget=210),
            _f('risks', 'Risks', 'table', [
                {'risk': 'Data migration errors',        'probability': 'Medium', 'mitigation': 'Staged migration with reconciliation checks & rollback snapshots.'},
                {'risk': 'Scope creep',                  'probability': 'Medium', 'mitigation': 'Change-control board; fixed sprint backlog with formal sign-off.'},
                {'risk': 'Integration delays (3rd party)', 'probability': 'High', 'mitigation': 'Early API discovery, sandbox testing, contractual SLAs with vendors.'},
                {'risk': 'Key-person dependency',        'probability': 'Low',    'mitigation': 'Paired roles, documented runbooks, cross-training across the team.'},
                {'risk': 'Security vulnerability',       'probability': 'Medium', 'mitigation': 'Threat modeling, automated scanning, third-party pen-test pre go-live.'},
                {'risk': 'User adoption resistance',     'probability': 'Low',    'mitigation': 'Early demos, champion network, structured UAT & training.'},
            ], max_items=8, columns=[
                _c('risk', 'Risk', budget=40),
                _c('probability', 'Probability', ftype='select', options=['Low', 'Medium', 'High']),
                _c('mitigation', 'Mitigation', budget=110),
            ]),
        ],
    },
    # 10 - TEAM & CAPABILITIES --------------------------------------------------
    {
        'key': 'team', 'num': 10, 'eyebrow': 'People',
        'title': 'Team & Capabilities',
        'desc': 'An org chart: one engagement lead over a row of role cards.',
        'fields': [
            _f('lead', 'Intro line', 'textarea',
               'A senior, accountable team - one engagement lead supported by specialists '
               'across architecture, delivery, DevOps and quality assurance.',
               budget=210),
            _f('lead_name', 'Engagement lead - name', 'text', 'A. Rahman', budget=24),
            _f('lead_title', 'Engagement lead - title', 'text', 'Engagement Director', budget=30),
            _f('lead_resp', 'Engagement lead - responsibility', 'textarea',
               'Executive sponsor & delivery accountability', budget=80),
            _f('members', 'Key personnel', 'table', [
                {'name': 'M. Chen',   'role': 'Solution Architect',  'resp': 'Owns target architecture & technical standards.'},
                {'name': 'S. Okafor', 'role': 'Delivery Lead',       'resp': 'Runs sprints, scope & day-to-day delivery.'},
                {'name': 'L. Novak',  'role': 'DevOps Lead',         'resp': 'Cloud, CI/CD pipelines & reliability.'},
                {'name': 'P. Sharma', 'role': 'QA & Security Lead',  'resp': 'Test automation & security assurance.'},
            ], max_items=6, columns=[
                _c('name', 'Name', budget=20),
                _c('role', 'Role / Title', budget=28),
                _c('resp', 'Responsibility', budget=70),
            ]),
        ],
    },
    # 11 - INVESTMENT & ROI -----------------------------------------------------
    {
        'key': 'pricing', 'num': 11, 'eyebrow': 'Investment',
        'title': 'Investment & ROI',
        'desc': 'Pricing by phase, the return story (ROI, payback, cost of standing still), and engagement models.',
        'fields': [
            _f('phases', 'Pricing by phase', 'table', [
                {'phase': '01', 'deliverable': 'Foundation & setup',        'duration': '1.5 mo', 'investment': '$140,000'},
                {'phase': '02', 'deliverable': 'Core build',                'duration': '3.0 mo', 'investment': '$320,000'},
                {'phase': '03', 'deliverable': 'Integration & migration',   'duration': '2.5 mo', 'investment': '$245,000'},
                {'phase': '04', 'deliverable': 'UAT & launch',              'duration': '2.0 mo', 'investment': '$155,000'},
            ], max_items=7, columns=[
                _c('phase', 'Phase', budget=6),
                _c('deliverable', 'Deliverable', budget=40),
                _c('duration', 'Duration', budget=12),
                _c('investment', 'Investment', budget=16),
            ]),
            _f('total_label', 'Total label', 'text', 'Total Program', budget=24),
            _f('total_amount', 'Total amount', 'text', '$860,000', budget=16),
            _f('roi', 'Return on investment', 'table', [
                {'label': 'Projected ROI',          'value': '2.4x',     'note': 'over 3 years vs. program cost'},
                {'label': 'Payback period',         'value': '14 mo',    'note': 'from go-live'},
                {'label': 'Cost of standing still', 'value': '$1.4M/yr', 'note': 'current redundant operations'},
            ], max_items=3, columns=[
                _c('label', 'Measure', budget=26),
                _c('value', 'Value', budget=10),
                _c('note', 'Note', budget=40),
            ]),
            _f('rec_name', 'Recommended model - name', 'text', 'Fixed-Scope Engagement', budget=30),
            _f('rec_desc', 'Recommended model - description', 'textarea',
               'Milestone-based billing against a fixed scope and timeline. Predictable cost, shared delivery risk.',
               budget=140),
            _f('rec_price', 'Recommended model - price', 'text', '$860k / 9 mo', budget=20),
            _f('alt_name', 'Alternative model - name', 'text', 'Time & Materials', budget=30),
            _f('alt_desc', 'Alternative model - description', 'textarea',
               'Blended day rate for evolving scope.', budget=120),
            _f('alt_price', 'Alternative model - price', 'text', '$1,250 / day', budget=20),
        ],
    },
    # 12 - SUCCESS METRICS & KPIs -----------------------------------------------
    {
        'key': 'kpis', 'num': 12, 'eyebrow': 'Measurement',
        'title': 'Success Metrics & KPIs',
        'desc': 'A KPI scorecard - baseline, target and when each lands, plus the reporting cadence.',
        'fields': [
            _f('lead', 'Intro line', 'textarea',
               'Success is measured, not asserted - the metrics we commit to, the baseline '
               'we start from, and when each target lands.',
               budget=200),
            _f('rows', 'KPIs', 'table', [
                {'kpi': 'Deployment frequency',       'baseline': 'Quarterly', 'target': 'Weekly',   'when': 'Month 6'},
                {'kpi': 'Unplanned downtime',         'baseline': '3.2% / mo', 'target': '< 0.5%',   'when': 'Month 9'},
                {'kpi': 'Run cost (annualised)',      'baseline': '$2.3M',     'target': '$1.4M',    'when': 'Month 12'},
                {'kpi': 'Time-to-market per feature', 'baseline': '12 weeks',  'target': '3 weeks',  'when': 'Month 9'},
                {'kpi': 'Mean time to recovery',      'baseline': '4+ hours',  'target': '< 30 min', 'when': 'Month 6'},
            ], max_items=7, columns=[
                _c('kpi', 'KPI', budget=34),
                _c('baseline', 'Baseline', budget=12),
                _c('target', 'Target', budget=12),
                _c('when', 'By when', budget=10),
            ]),
            _f('cadence', 'Reporting cadence', 'textarea',
               'A monthly steering-committee scorecard tracks every KPI against target, '
               'with corrective actions owned and dated.',
               budget=150),
        ],
    },
    # 13 - NEXT STEPS / CTA -------------------------------------------------------
    {
        'key': 'nextsteps', 'num': 13, 'eyebrow': 'Action',
        'title': 'Next Steps',
        'desc': 'A 3-step action timeline, a highlighted sign-off deadline and a point-of-contact card.',
        'fields': [
            _f('steps', 'Action steps', 'table', [
                {'title': 'Proposal Review',   'desc': 'Align on scope, commercials & timeline with your stakeholders.', 'when': 'Week 1'},
                {'title': 'Sign-off & Kickoff', 'desc': 'Countersign the SOW and mobilize the delivery team.',          'when': 'Week 2'},
                {'title': 'Discovery Sprint',  'desc': 'Begin Phase 01 - environment setup & detailed planning.',       'when': 'Week 3'},
            ], max_items=5, columns=[
                _c('title', 'Step', budget=28),
                _c('desc', 'Description', budget=110),
                _c('when', 'When', budget=16),
            ]),
            _f('deadline_label', 'Deadline label', 'text', 'Sign-off deadline', budget=24),
            _f('deadline_date', 'Deadline date', 'text', 'July 15, 2026', budget=24),
            _f('deadline_note', 'Deadline note', 'text', 'To hold the proposed Q3 start date.', budget=60),
            _f('poc_name', 'Point of contact - name', 'text', 'A. Rahman', budget=24),
            _f('poc_email', 'Point of contact - email', 'text', 'a.rahman@yourcompany.com', budget=44),
            _f('poc_phone', 'Point of contact - phone', 'text', '+1 (555) 014-2200', budget=26),
        ],
    },
    # 14 - THANK YOU / Q&A --------------------------------------------------------
    {
        'key': 'thankyou', 'num': 14, 'eyebrow': 'Close',
        'title': 'Thank You / Q&A',
        'desc': 'Closing slide with contact details, an invitation for questions and the company logo.',
        'lockable': False,
        'fields': [
            _f('headline', 'Headline', 'text', 'Thank You', budget=24),
            _f('message', 'Closing message', 'textarea',
               "We're ready to partner with you on a secure, scalable platform built for the next decade. "
               'We look forward to your questions and feedback.',
               budget=200),
            _f('email', 'Email', 'text', 'hello@yourcompany.com', budget=40),
            _f('phone', 'Phone', 'text', '+1 (555) 014-2200', budget=26),
            _f('web', 'Website', 'text', 'yourcompany.com', budget=40),
        ],
    },
]

SLIDE_BY_KEY = {s['key']: s for s in SLIDES}


def slides_for(template='npg'):
    """The ordered slide list a template uses - the same canonical set for
    every template. (Kept as a function so callers don't care that the
    per-template trimming of earlier versions is gone.)"""
    return list(SLIDES)


# --- defaults --------------------------------------------------------------

def default_meta():
    return {f['key']: f['default'] for f in META_FIELDS}


def default_data(template='npg', include_all=False):
    """
    A complete, ready-to-render deck using the sample content above.
    ``include_all`` is retained for compatibility - every template now uses
    the full canonical slide set, so it has no extra effect.
    """
    slides = {}
    for s in SLIDES:
        slides[s['key']] = {
            'enabled': True,
            'fields': {f['key']: _clone(f['default']) for f in s['fields']},
        }
    return {'template': template, 'meta': default_meta(), 'slides': slides}


def _clone(value):
    if isinstance(value, list):
        return [dict(v) if isinstance(v, dict) else v for v in value]
    return value
