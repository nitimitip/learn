"""
Project Management Models
=========================
All SQLAlchemy ORM models for the project management module.

Cascade / delete semantics
--------------------------
Parent -> child cleanup is ORM-level, expressed via
``relationship(..., cascade="all, delete-orphan")`` on the parent side. The
foreign-key columns themselves declare NO database ``ondelete=`` action.

With ``PRAGMA foreign_keys=ON`` (SQLite, see database.py) and on SQL
Server / PostgreSQL, this means a *raw SQL* ``DELETE`` of a parent row is
RESTRICTed (blocked) while children exist - it does not cascade at the DB
level. Deletes MUST therefore go through the ORM session (``db.delete(obj)``),
which walks the relationships and removes children first. Do not add bulk
``DELETE FROM projects ...`` style statements; use the session so the cascade
runs. Child foreign-key columns are indexed (``index=True``) so both the
per-parent loads and the ORM cascade deletes stay fast as the tables grow.
"""

from sqlalchemy import (
    Column, Integer, String, DateTime, Text, ForeignKey, Enum, Boolean, Date,
    UniqueConstraint,
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship, backref
from database import Base
import enum
import json


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class ProjectStatus(enum.Enum):
    PLANNING    = "Planning"
    IN_PROGRESS = "In Progress"
    ON_HOLD     = "On Hold"
    COMPLETED   = "Completed"
    FAILED      = "Failed"
    CLOSED      = "Closed"


class TaskStatus(enum.Enum):
    NOT_STARTED = "Not Started"
    IN_PROGRESS = "In Progress"
    ON_HOLD     = "Hold"
    COMPLETED   = "Completed"


class MilestoneStatus(enum.Enum):
    NOT_STARTED = "Not Started"
    IN_PROGRESS = "In Progress"
    COMPLETED   = "Completed"


class RiskSeverity(enum.Enum):
    LOW      = "Low"
    MEDIUM   = "Medium"
    HIGH     = "High"
    CRITICAL = "Critical"


class RiskStatus(enum.Enum):
    OPEN     = "Open"
    MITIGATED = "Mitigated"
    CLOSED   = "Closed"


# 5x5 probability x impact scales (standard PMBOK-style risk matrix).
# Stored as 1-5 integers; labels back the dropdowns and the matrix axes.
RISK_PROBABILITY_LABELS = {
    1: 'Rare', 2: 'Unlikely', 3: 'Possible', 4: 'Likely', 5: 'Almost certain',
}
RISK_IMPACT_LABELS = {
    1: 'Negligible', 2: 'Minor', 3: 'Moderate', 4: 'Major', 5: 'Severe',
}


def risk_band(score: int) -> str:
    """Severity band for a PxI score (1-25)."""
    if score >= 15:
        return 'Critical'
    if score >= 10:
        return 'High'
    if score >= 5:
        return 'Medium'
    return 'Low'


# ---------------------------------------------------------------------------
# Go-Live plan - section identifiers and dropdown vocabularies
#
# The task-style sections (pre-requisite, production go-live, post go-live
# checks, failover/DR) all share one table, distinguished by `section`. The
# constant lists below back the dropdowns in the create/edit forms and are
# validated server-side in the routes, so we keep them as plain strings rather
# than DB enums (avoids enum-coercion failures on the multi-row form parsing
# and keeps additive changes migration-free).
# ---------------------------------------------------------------------------

# Task-style sections that share the common column set.
GOLIVE_TASK_SECTIONS = [
    ('prerequisite', 'Pre-requisite'),
    ('production',   'Production Go-Live'),
    ('post_golive',  'Post Go-Live Checks'),
    ('failover_dr',  'Failover / DR'),
]
GOLIVE_TASK_SECTION_KEYS  = [k for k, _ in GOLIVE_TASK_SECTIONS]
GOLIVE_SECTION_LABELS     = dict(GOLIVE_TASK_SECTIONS)
GOLIVE_SECTION_LABELS['external_connectivity'] = 'External Connectivity'
GOLIVE_SECTION_LABELS['contact_point']         = 'Contact Point'

# All six toggleable sections, in display order.
GOLIVE_ALL_SECTIONS = GOLIVE_TASK_SECTION_KEYS + ['external_connectivity', 'contact_point']

GOLIVE_DEPARTMENTS = [
    'Change Management',
    'Application Team',
    'Infra Team',
    'Security Team',
]

GOLIVE_TASK_STATUSES = [
    'Not Started',   # default
    'In Progress',
    'Completed',
    'Not Required',
    'Failed',
]

GOLIVE_CONNECTION_DIRECTIONS = [
    'Uni Direction',
    'Bi Direction',
]


# ---------------------------------------------------------------------------
# Task categories - centralised so forms and models stay in sync
# ---------------------------------------------------------------------------

# Task priorities, highest first. Stored as plain strings (like the Go-Live
# vocabularies) so adding a level never needs an enum migration; routes
# validate against this list and blank/legacy rows read as Medium.
TASK_PRIORITIES = ['Critical', 'High', 'Medium', 'Low']
TASK_PRIORITY_DEFAULT = 'Medium'

TASK_CATEGORIES = {
    "Development": [
        "Frontend", "Backend", "API Integration", "Database",
        "DevOps / CI-CD", "Testing / QA", "Security", "Performance",
    ],
    "Design": [
        "UI / UX", "Prototyping", "Branding", "Documentation",
    ],
    "Management": [
        "Planning", "Stakeholder Communication", "Risk Management",
        "Reporting", "Review / Approval",
    ],
    "Infrastructure": [
        "Cloud / Hosting", "Networking", "Monitoring", "Backup",
    ],
    "Other": ["General", "Research", "Training", "Support"],
}

# Predefined stakeholder roles (dropdown on the create/edit forms; a free-text
# custom role is always allowed alongside these).
STAKEHOLDER_ROLES = [
    'Project Manager', 'Business Sponsor', 'Business Owner',
    'Infrastructure Architect', 'Solution Architect',
    'IT Security Approver', 'Customer',
]

# Predefined team-member roles (dropdown on the create/edit forms; a free-text
# custom role is always allowed alongside these - same pattern as stakeholders).
TEAM_MEMBER_ROLES = [
    'Product Owner',
    'Scrum Master',
    'Development Team',
    'Subject Matter Expert (SME)',
    'Business Analyst',
    'Test Lead',
    'Tester / QA Engineer',
    'Technical Lead',
    'UI/UX Designer',
]

# Every team member MUST belong to one of these groups (picked when the member
# is added); the Team section displays the roster grouped by them.
TEAM_MEMBER_GROUPS = ['Lead', 'Engineer']

# Document groups: every document is filed under exactly one SDLC phase group
# (mandatory on upload); the Documents view lists them grouped in this order.
DOCUMENT_CATEGORIES = [
    "Planning",
    "Requirements & Analysis",
    "Design",
    "Development",
    "Testing",
    "Post-Deployment & Closure",
]

# Pre-existing documents (and SDLC phase templates) were filed under the old,
# finer-grained category names. Map each onto its phase group so legacy data
# keeps displaying - and SDLC document gates keep passing - after the rename.
LEGACY_DOCUMENT_CATEGORY_MAP = {
    'Project Charter':              'Planning',
    'Meeting Minutes':              'Planning',
    'Risk Register':                'Planning',
    'Contract / Agreement':         'Planning',
    'Invoice / Financial':          'Planning',
    'Requirements / Specification': 'Requirements & Analysis',
    'Architecture / Design':        'Design',
    'Technical Documentation':      'Development',
    'Change Request':               'Development',
    'Test Plan / Report':           'Testing',
    'Deliverable':                  'Post-Deployment & Closure',
}


def normalize_document_category(category):
    """Current group for a stored category ('' when it maps to none)."""
    if not category:
        return ''
    if category in DOCUMENT_CATEGORIES:
        return category
    return LEGACY_DOCUMENT_CATEGORY_MAP.get(category, '')


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class Project(Base):
    __tablename__ = 'projects'

    id             = Column(Integer, primary_key=True)
    name           = Column(String(200), nullable=False)
    goal_objective = Column(Text)
    description    = Column(Text)
    status         = Column(Enum(ProjectStatus), default=ProjectStatus.PLANNING, nullable=False)
    is_closed      = Column(Boolean, default=False)
    start_date     = Column(Date)                # added v4 - planned project window
    target_end_date = Column(Date)               # added v4 - planned delivery date
    # Status-report email: auto-send when a milestone turns Completed (default ON).
    auto_status_email = Column(Boolean, default=True, nullable=False)
    # Project type (v8): 'sdlc' follows the governed process below; 'simple'
    # is a lightweight infra-style project where the PM defines milestones,
    # deadlines and tasks manually and no SDLC process is attached.
    project_type           = Column(String(20), default='sdlc')
    # SDLC governance (v7). methodology is fixed at creation ('waterfall' /
    # 'agile'); legacy and SIMPLE projects keep NULL and simply have no
    # governed process. The questionnaire score and its recommendation are
    # kept for the audit trail; override_reason records why a PM chose
    # against the recommendation.
    methodology            = Column(String(20))
    sdlc_score             = Column(Integer)
    sdlc_recommended       = Column(String(20))
    sdlc_override_reason   = Column(Text)
    created_by     = Column(Integer, ForeignKey('users.id'), nullable=False, index=True)
    created_at     = Column(DateTime, default=func.now())
    updated_at     = Column(DateTime, default=func.now(), onupdate=func.now())

    # Relationships
    stakeholders = relationship("ProjectStakeholder", back_populates="project",
                                cascade="all, delete-orphan")
    # Always returned in planned order: by start date, falling back to the
    # mandatory end date when a milestone has no start date, then end date /
    # id as tie-breakers. This keeps every view (project page, edit form,
    # Excel export, Gantt) consistent - the list was previously in insertion
    # (id) order, which did not match the timeline.
    milestones   = relationship(
        "ProjectMilestone", back_populates="project",
        cascade="all, delete-orphan",
        order_by="func.coalesce(ProjectMilestone.start_date, "
                 "ProjectMilestone.end_date), ProjectMilestone.end_date, "
                 "ProjectMilestone.id")
    team_members = relationship("ProjectTeamMember",  back_populates="project",
                                cascade="all, delete-orphan")
    risk_logs    = relationship("ProjectRiskLog",     back_populates="project",
                                cascade="all, delete-orphan")
    documents    = relationship("ProjectDocument",    back_populates="project",
                                cascade="all, delete-orphan")
    activities   = relationship("ProjectActivity",    back_populates="project",
                                cascade="all, delete-orphan",
                                order_by="ProjectActivity.created_at.desc()")
    # Recipients of the project status-report email (managed by the project owner).
    status_recipients = relationship("ProjectStatusRecipient", back_populates="project",
                                     cascade="all, delete-orphan",
                                     order_by="ProjectStatusRecipient.id")
    # Plan baselines, newest first - [0] is the active one for variance.
    baselines = relationship("ProjectBaseline", back_populates="project",
                             cascade="all, delete-orphan",
                             order_by="ProjectBaseline.created_at.desc(), "
                                      "ProjectBaseline.id.desc()")
    # SDLC phases in process order (empty for legacy / ungoverned projects).
    sdlc_phases = relationship("ProjectSDLCPhase", back_populates="project",
                               cascade="all, delete-orphan",
                               order_by="ProjectSDLCPhase.position, ProjectSDLCPhase.id")
    # One project has at most one Go-Live plan (uselist=False enforces the 1:1).
    golive_plan  = relationship("GoLivePlan",         back_populates="project",
                                uselist=False, cascade="all, delete-orphan")
    # One project has at most one HLD document (uselist=False enforces the 1:1).
    hld          = relationship("ProjectHLD",         back_populates="project",
                                uselist=False, cascade="all, delete-orphan")

    # ------------------------------------------------------------------ helpers

    def get_all_tasks(self):
        """Return every task across all milestones."""
        tasks = []
        for milestone in self.milestones:
            tasks.extend(milestone.tasks)
        return tasks

    def get_completion_percentage(self):
        """
        Overall project completion: duration-weighted mean of each task's
        effective % complete. A 20-day task at 50% moves the number four
        times as much as a 5-day task at 50% - binary done/not-done counting
        made long-running work invisible until the very end.
        """
        all_tasks = self.get_all_tasks()
        if not all_tasks:
            return 0
        total_weight = sum(t.duration_days() for t in all_tasks)
        weighted = sum(t.duration_days() * t.effective_percent() for t in all_tasks)
        return int(weighted / total_weight)

    def closure_blockers(self):
        """
        Reasons the project cannot yet be closed. An empty list means it is
        ready to close.

        A project may only be closed when:
          * it has at least one task and every task is Completed,
          * no risk is still Open (each must be Mitigated or Closed), and
          * every Go-Live task is either Completed or Not Required.
        """
        reasons = []

        all_tasks = self.get_all_tasks()
        if not all_tasks:
            reasons.append('the project has no tasks')
        else:
            pending = [t for t in all_tasks if t.status != TaskStatus.COMPLETED]
            if pending:
                reasons.append(f'{len(pending)} task(s) are not Completed')

        open_risks = [r for r in self.risk_logs if r.status == RiskStatus.OPEN]
        if open_risks:
            reasons.append(f'{len(open_risks)} risk(s) are still Open')

        if self.golive_plan:
            gl_pending = [t for t in self.golive_plan.tasks
                          if t.status not in ('Completed', 'Not Required')]
            if gl_pending:
                reasons.append(
                    f'{len(gl_pending)} Go-Live task(s) are not Completed or Not Required')

        return reasons

    def can_be_closed(self):
        """True when every closure pre-condition is satisfied (see closure_blockers)."""
        return not self.closure_blockers()

    def update_status_based_on_tasks(self):
        """
        Derive the project's status from its tasks, mirroring the milestone
        rule (see ProjectMilestone.update_status_based_on_tasks). Without this,
        completing every task left the project stuck on its creation status
        (Planning) so the dashboard card, status chart and filters never showed
        it as Completed.

            every task completed         -> Completed
            some work started            -> In Progress
            nothing started / no tasks   -> Planning

        Deliberate, manual states (On Hold, Failed, Closed) are left untouched:
        a manager's explicit decision is never silently overwritten, and a
        formally closed project stays closed.
        """
        if self.status in (ProjectStatus.ON_HOLD, ProjectStatus.FAILED, ProjectStatus.CLOSED):
            return

        all_tasks = self.get_all_tasks()
        if not all_tasks:
            self.status = ProjectStatus.PLANNING
            return

        completed = [t for t in all_tasks if t.status == TaskStatus.COMPLETED]
        started   = [t for t in all_tasks
                     if t.status in (TaskStatus.IN_PROGRESS, TaskStatus.ON_HOLD, TaskStatus.COMPLETED)]

        if len(completed) == len(all_tasks):
            self.status = ProjectStatus.COMPLETED
        elif started:
            self.status = ProjectStatus.IN_PROGRESS
        else:
            self.status = ProjectStatus.PLANNING

    def get_overdue_tasks(self):
        return [t for t in self.get_all_tasks() if t.is_overdue()]

    def get_open_high_risks(self):
        """Open risks at High or Critical severity - the ones worth surfacing."""
        return [r for r in self.risk_logs
                if r.status == RiskStatus.OPEN
                and r.severity in (RiskSeverity.HIGH, RiskSeverity.CRITICAL)]

    def get_health_state(self):
        """
        RAG colour for the project as a whole, mirroring the milestone rule:

            'green'   - the project is Completed or Closed
            'red'     - the target end date has passed and it isn't finished,
                        OR there is at least one overdue task
            'amber'   - within 7 days of the target end date and not finished
            'neutral' - everything else (incl. no target date set)
        """
        from datetime import date, timedelta
        if self.status in (ProjectStatus.COMPLETED, ProjectStatus.CLOSED):
            return 'green'
        if self.get_overdue_tasks():
            return 'red'
        if not self.target_end_date:
            return 'neutral'
        today = date.today()
        if self.target_end_date < today:
            return 'red'
        if self.target_end_date <= today + timedelta(days=7):
            return 'amber'
        return 'neutral'


class ProjectStakeholder(Base):
    __tablename__ = 'project_stakeholders'

    id           = Column(Integer, primary_key=True)
    project_id   = Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    name         = Column(String(200), nullable=False)
    role         = Column(String(100))
    email        = Column(String(200))
    designation  = Column(String(200))

    project = relationship("Project", back_populates="stakeholders")


class ProjectStatusRecipient(Base):
    """One recipient of the project status-report email.

    A free-form name + email list, maintained by the project owner (the creating
    PM or an admin). Used both for the manual "Send status report" action and the
    auto-send when a milestone turns Completed.
    """
    __tablename__ = 'project_status_recipients'

    id         = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    name       = Column(String(200))
    email      = Column(String(200), nullable=False)
    created_at = Column(DateTime, default=func.now())

    project = relationship("Project", back_populates="status_recipients")


class ProjectMilestone(Base):
    __tablename__ = 'project_milestones'

    id          = Column(Integer, primary_key=True)
    project_id  = Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    name        = Column(String(200), nullable=False)
    description = Column(Text)
    start_date  = Column(Date)                # added v3 - task dates must fall within [start, end]
    end_date    = Column(Date, nullable=False)
    status      = Column(Enum(MilestoneStatus), default=MilestoneStatus.NOT_STARTED, nullable=False)
    created_at  = Column(DateTime, default=func.now())

    project = relationship("Project", back_populates="milestones")
    # Tasks are presented in date order (earliest start first, then deadline,
    # then insertion order) everywhere the relationship is iterated.
    tasks   = relationship("ProjectTask", back_populates="milestone",
                           cascade="all, delete-orphan",
                           order_by="ProjectTask.start_date, "
                                    "ProjectTask.end_date, ProjectTask.id")
    # SDLC stage assignments (v7): which process stages this milestone
    # realises. Deleting the milestone removes the links, leaving the stages
    # unassigned - which the Process tab flags (soft governance).
    sdlc_links = relationship("SDLCPhaseMilestone", back_populates="milestone",
                              cascade="all, delete-orphan")

    def update_status_based_on_tasks(self):
        """
        Derive milestone status from its task statuses.

        Rule (requirement 3): when EVERY task is completed the milestone is
        marked Completed; if any work has started it is In Progress; otherwise
        Not Started. A milestone with no tasks is left Not Started.
        """
        if not self.tasks:
            self.status = MilestoneStatus.NOT_STARTED
            return
        completed   = [t for t in self.tasks if t.status == TaskStatus.COMPLETED]
        in_progress = [t for t in self.tasks
                       if t.status in (TaskStatus.IN_PROGRESS, TaskStatus.ON_HOLD)]

        if len(completed) == len(self.tasks):
            self.status = MilestoneStatus.COMPLETED
        elif completed or in_progress:
            self.status = MilestoneStatus.IN_PROGRESS
        else:
            self.status = MilestoneStatus.NOT_STARTED

    def get_health_state(self):
        """
        Colour state for the milestone header (requirement 5):

            'green'   - status is Completed
            'red'     - deadline has passed and status is not Completed
            'amber'   - within 2 days of the deadline and not Completed
            'neutral' - everything else (incl. milestones with no deadline)
        """
        from datetime import date, timedelta
        if self.status == MilestoneStatus.COMPLETED:
            return 'green'
        if not self.end_date:
            return 'neutral'
        today = date.today()
        if self.end_date < today:
            return 'red'
        if self.end_date <= today + timedelta(days=2):
            return 'amber'
        return 'neutral'

    @property
    def completion_percentage(self):
        """Duration-weighted progress (mirrors Project.get_completion_percentage)."""
        if not self.tasks:
            return 0
        total_weight = sum(t.duration_days() for t in self.tasks)
        weighted = sum(t.duration_days() * t.effective_percent() for t in self.tasks)
        return int(weighted / total_weight)


class ProjectTeamMember(Base):
    __tablename__ = 'project_team_members'

    id         = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    user_id    = Column(Integer, ForeignKey('users.id'), nullable=False)
    role       = Column(String(100), nullable=False)
    # Mandatory grouping (TEAM_MEMBER_GROUPS: Lead / Engineer). Nullable at the
    # schema level so rosters saved before the field existed keep loading; the
    # Team card shows those legacy rows under "Unassigned".
    member_group = Column(String(20))
    added_at   = Column(DateTime, default=func.now())

    project = relationship("Project", back_populates="team_members")


class ProjectTask(Base):
    """
    A task belongs to a milestone.

    Fields added in v2:
        category     - top-level category (maps to TASK_CATEGORIES keys)
        sub_category - sub-category (maps to TASK_CATEGORIES values)
    """
    __tablename__ = 'project_tasks'

    id           = Column(Integer, primary_key=True)
    milestone_id = Column(Integer, ForeignKey('project_milestones.id'), nullable=False, index=True)
    name         = Column(String(200), nullable=False)
    description  = Column(Text)
    category     = Column(String(100))          # NEW - e.g. "Development"
    sub_category = Column(String(100))          # NEW - e.g. "Backend"
    priority     = Column(String(20), default='Medium')   # v5 - TASK_PRIORITIES
    # v6 - manual progress for open tasks. Status stays the source of truth at
    # the ends of the scale: Completed always reads 100, Not Started always 0
    # (see effective_percent), so this only matters for In Progress / Hold.
    percent_complete = Column(Integer, default=0)
    assigned_to  = Column(Integer, ForeignKey('users.id'), index=True)
    start_date   = Column(Date, nullable=False)
    end_date     = Column(Date, nullable=False)  # must be <= milestone.end_date (enforced in routes)
    status       = Column(Enum(TaskStatus), default=TaskStatus.NOT_STARTED, nullable=False)
    created_at   = Column(DateTime, default=func.now())
    updated_at   = Column(DateTime, default=func.now(), onupdate=func.now())

    milestone = relationship("ProjectMilestone", back_populates="tasks")
    notes     = relationship("TaskNote", back_populates="task", cascade="all, delete-orphan")
    # CPM dependency links. `predecessor_links` are the edges INTO this task
    # (rows where this task is the successor); `successor_links` the edges out.
    # Both cascade so deleting a task removes its edges from either end.
    predecessor_links = relationship(
        "TaskDependency", foreign_keys="TaskDependency.successor_id",
        back_populates="successor", cascade="all, delete-orphan")
    successor_links = relationship(
        "TaskDependency", foreign_keys="TaskDependency.predecessor_id",
        back_populates="predecessor", cascade="all, delete-orphan")

    def effective_percent(self) -> int:
        """Progress % with the status ends pinned: Completed=100, Not Started=0."""
        if self.status == TaskStatus.COMPLETED:
            return 100
        if self.status == TaskStatus.NOT_STARTED:
            return 0
        return max(0, min(100, self.percent_complete or 0))

    def duration_days(self) -> int:
        """Inclusive calendar-day duration; the weight for roll-up progress."""
        return max(1, (self.end_date - self.start_date).days + 1)

    def is_overdue(self):
        from datetime import date
        return self.end_date < date.today() and self.status != TaskStatus.COMPLETED

    def is_nearing_deadline(self, days_threshold=3):
        from datetime import date, timedelta
        return (
            self.end_date <= date.today() + timedelta(days=days_threshold)
            and self.end_date >= date.today()
            and self.status != TaskStatus.COMPLETED
        )


class TaskDependency(Base):
    """
    One directed CPM scheduling link between two tasks of the same project
    (cross-milestone links are allowed; cross-project links are not - the
    routes validate this, plus acyclicity, on save).

    dep_type is one of the four standard CPM link types (FS/SS/FF/SF, see
    cpm.DEPENDENCY_TYPE_LABELS); FS "predecessor finishes, then successor
    starts" is the default. lag_days may be negative (lead time).
    """
    __tablename__ = 'task_dependencies'
    __table_args__ = (
        UniqueConstraint('predecessor_id', 'successor_id',
                         name='uq_task_dependency_edge'),
    )

    id             = Column(Integer, primary_key=True)
    predecessor_id = Column(Integer, ForeignKey('project_tasks.id'), nullable=False, index=True)
    successor_id   = Column(Integer, ForeignKey('project_tasks.id'), nullable=False, index=True)
    dep_type       = Column(String(2), default='FS', nullable=False)
    lag_days       = Column(Integer, default=0, nullable=False)
    created_at     = Column(DateTime, default=func.now())

    predecessor = relationship("ProjectTask", foreign_keys=[predecessor_id],
                               back_populates="successor_links")
    successor   = relationship("ProjectTask", foreign_keys=[successor_id],
                               back_populates="predecessor_links")


class TaskNote(Base):
    __tablename__ = 'task_notes'

    id         = Column(Integer, primary_key=True)
    task_id    = Column(Integer, ForeignKey('project_tasks.id'), nullable=False, index=True)
    user_id    = Column(Integer, ForeignKey('users.id'), nullable=False)
    note       = Column(Text, nullable=False)
    created_at = Column(DateTime, default=func.now())

    task = relationship("ProjectTask", back_populates="notes")


class ProjectActivity(Base):
    """
    A lightweight audit trail entry. One row per meaningful change to a project
    (created / edited / status change / task & risk & document changes). Kept
    deliberately simple: a short `action` label plus an optional human-readable
    `detail`. `user_id` is nullable so system-generated entries are still valid.
    """
    __tablename__ = 'project_activities'

    id         = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    user_id    = Column(Integer, ForeignKey('users.id'))
    action     = Column(String(120), nullable=False)
    detail     = Column(Text)
    created_at = Column(DateTime, default=func.now())

    project = relationship("Project", back_populates="activities")


class ProjectBaseline(Base):
    """
    A frozen snapshot of the project plan (every milestone and task with its
    dates) taken at a point in time - typically at kickoff or a re-plan.

    The most recent baseline is the *active* one: the Plan tab's variance
    table and the Gantt's ghost bars compare the live plan against it. Older
    baselines are kept for history until the owner deletes them.

    Snapshot rows reference their live counterparts by plain integer id (no
    FK): a baseline must survive the later deletion of the task/milestone it
    captured - that deletion is exactly the drift it exists to reveal.
    """
    __tablename__ = 'project_baselines'

    id         = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    name       = Column(String(200), nullable=False)
    created_by = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=func.now())

    project    = relationship("Project", back_populates="baselines")
    milestones = relationship("BaselineMilestone", back_populates="baseline",
                              cascade="all, delete-orphan")
    tasks      = relationship("BaselineTask", back_populates="baseline",
                              cascade="all, delete-orphan")


class BaselineMilestone(Base):
    """One milestone as it stood when the baseline was taken."""
    __tablename__ = 'baseline_milestones'

    id           = Column(Integer, primary_key=True)
    baseline_id  = Column(Integer, ForeignKey('project_baselines.id'), nullable=False, index=True)
    milestone_id = Column(Integer)            # live row id at snapshot time (no FK)
    name         = Column(String(200), nullable=False)
    start_date   = Column(Date)
    end_date     = Column(Date, nullable=False)

    baseline = relationship("ProjectBaseline", back_populates="milestones")


class BaselineTask(Base):
    """One task as it stood when the baseline was taken."""
    __tablename__ = 'baseline_tasks'

    id             = Column(Integer, primary_key=True)
    baseline_id    = Column(Integer, ForeignKey('project_baselines.id'), nullable=False, index=True)
    task_id        = Column(Integer)          # live row id at snapshot time (no FK)
    name           = Column(String(200), nullable=False)
    milestone_name = Column(String(200))
    start_date     = Column(Date, nullable=False)
    end_date       = Column(Date, nullable=False)
    priority       = Column(String(20))
    status         = Column(String(40))       # status at snapshot time (label only)

    baseline = relationship("ProjectBaseline", back_populates="tasks")


class ProjectRiskLog(Base):
    __tablename__ = 'project_risk_logs'

    id         = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    name       = Column(String(200), nullable=False)
    summary    = Column(Text, nullable=False)
    severity   = Column(Enum(RiskSeverity), nullable=False)
    status     = Column(Enum(RiskStatus), default=RiskStatus.OPEN, nullable=False)   # NEW
    # v6 - probability x impact matrix fields. When both P and I are set the
    # severity is derived from the score band (risk_band); legacy rows keep
    # their manually chosen severity.
    probability = Column(Integer)                 # 1-5, RISK_PROBABILITY_LABELS
    impact      = Column(Integer)                 # 1-5, RISK_IMPACT_LABELS
    owner       = Column(String(200))
    mitigation  = Column(Text)
    due_date    = Column(Date)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    project = relationship("Project", back_populates="risk_logs")

    @property
    def score(self):
        """PxI (1-25), or None when the matrix fields aren't set."""
        if self.probability and self.impact:
            return self.probability * self.impact
        return None


class ProjectDocument(Base):
    """
    Field added in v2:
        category - document type (maps to DOCUMENT_CATEGORIES)
    """
    __tablename__ = 'project_documents'

    id           = Column(Integer, primary_key=True)
    project_id   = Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    category     = Column(String(100))           # NEW - e.g. "Technical Documentation"
    name         = Column(String(200), nullable=False)
    summary      = Column(Text)
    filename     = Column(String(255), nullable=False)
    is_sensitive = Column(Boolean, default=False, nullable=False)  # v3 - owner-only when True
    uploaded_by  = Column(Integer, ForeignKey('users.id'), nullable=False)
    uploaded_at  = Column(DateTime, default=func.now())

    project = relationship("Project", back_populates="documents")

    @property
    def display_group(self):
        """Phase group shown in the Documents view (legacy categories mapped)."""
        return normalize_document_category(self.category)


# ---------------------------------------------------------------------------
# SDLC process governance
#
# Two halves, mirroring the HLD master-template pattern:
#   1. SDLCPhaseTemplate - the admin-curated process definition: one ordered
#      list of phases per methodology (waterfall / agile), each with its exit
#      criteria, required document categories and default tasks. Seeded from
#      sdlc.DEFAULT_PHASES; admins tune it as the client's process matures.
#   2. ProjectSDLCPhase - a project's own copy of the phases, snapshotted at
#      creation time (so later template edits never rewrite a running
#      project's process). Each phase links to the milestone that realises it
#      by plain integer id (no FK - like the baseline snapshots, a phase must
#      survive its milestone's deletion: that deletion is exactly the drift
#      the soft-governance flags exist to reveal).
#
# Governance is SOFT: gates that are not met raise red flags on the project
# and the dashboard, but never block work.
# ---------------------------------------------------------------------------

def _parse_json_list(raw) -> list:
    import json
    try:
        data = json.loads(raw or '[]')
        return data if isinstance(data, list) else []
    except (ValueError, TypeError):
        return []


def _parse_task_specs(raw) -> list:
    """[(name, category, sub_category), ...] with malformed rows dropped."""
    out = []
    for row in _parse_json_list(raw):
        if isinstance(row, (list, tuple)) and row and str(row[0]).strip():
            name = str(row[0]).strip()
            cat  = str(row[1]).strip() if len(row) > 1 and row[1] else ''
            sub  = str(row[2]).strip() if len(row) > 2 and row[2] else ''
            out.append((name, cat, sub))
    return out


class SDLCPhaseTemplate(Base):
    """One phase of the master SDLC process for a methodology (admin-managed)."""
    __tablename__ = 'sdlc_phase_templates'

    id            = Column(Integer, primary_key=True)
    methodology   = Column(String(20), nullable=False)   # 'waterfall' / 'agile'
    position      = Column(Integer, nullable=False, default=0)
    name          = Column(String(200), nullable=False)
    description   = Column(Text)
    exit_criteria = Column(Text)                          # the gate, in words
    # JSON list of DOCUMENT_CATEGORIES values that must be uploaded before
    # the phase gate is considered met.
    doc_categories = Column(Text, default='[]')
    # JSON list of [name, category, sub_category] default tasks created with
    # each of the phase's milestones on new projects (and with each new
    # sprint, for repeatable phases).
    default_tasks  = Column(Text, default='[]')
    # Relative share of the project window this phase gets when the schedule
    # is auto-generated.
    weight        = Column(Integer, nullable=False, default=1)
    # Repeatable phases hold multiple milestones - agile sprints (Sprint 1,
    # 2, 3 ...) added on demand, each seeded with the default tasks.
    repeatable    = Column(Boolean, default=False, nullable=False)
    created_at    = Column(DateTime, default=func.now())
    updated_at    = Column(DateTime, default=func.now(), onupdate=func.now())

    def doc_category_list(self) -> list:
        return [str(c) for c in _parse_json_list(self.doc_categories)]

    def task_specs(self) -> list:
        return _parse_task_specs(self.default_tasks)


class ProjectSDLCPhase(Base):
    """
    One SDLC stage of a governed project (snapshot of the template row).

    The PM decides which stage falls under which milestone: the mapping lives
    in SDLCPhaseMilestone. A milestone may group SEVERAL stages (e.g. a
    'Design Doc' milestone holding Requirements + Design), and a repeatable
    stage (agile Sprint Cycles) may span several milestones - one per sprint.
    A stage with no milestone is 'unassigned' and flagged, never blocked.
    """
    __tablename__ = 'project_sdlc_phases'

    id             = Column(Integer, primary_key=True)
    project_id     = Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    position       = Column(Integer, nullable=False, default=0)
    name           = Column(String(200), nullable=False)
    description    = Column(Text)
    exit_criteria  = Column(Text)
    doc_categories = Column(Text, default='[]')     # JSON, as on the template
    default_tasks  = Column(Text, default='[]')     # JSON - seeds each new sprint
    repeatable     = Column(Boolean, default=False)
    # Optional structured gate; existing projects retain their recorded sign-offs.
    governance = Column(Text)
    governance_revision = Column(Integer, default=0)
    # Gate sign-off (soft governance - recorded, never enforced).
    signed_off_by  = Column(Integer, ForeignKey('users.id'))
    signed_off_at  = Column(DateTime)
    signoff_note   = Column(Text)
    created_at     = Column(DateTime, default=func.now())

    project = relationship("Project", back_populates="sdlc_phases")
    milestone_links = relationship("SDLCPhaseMilestone", back_populates="phase",
                                   cascade="all, delete-orphan")

    def doc_category_list(self) -> list:
        return [str(c) for c in _parse_json_list(self.doc_categories)]

    def task_specs(self) -> list:
        return _parse_task_specs(self.default_tasks)

    @property
    def is_signed_off(self) -> bool:
        return self.signed_off_at is not None


class SDLCPhaseMilestone(Base):
    """One stage -> milestone assignment (the PM's grouping decision)."""
    __tablename__ = 'sdlc_phase_milestones'
    __table_args__ = (
        UniqueConstraint('phase_id', 'milestone_id',
                         name='uq_sdlc_phase_milestone'),
    )

    id           = Column(Integer, primary_key=True)
    phase_id     = Column(Integer, ForeignKey('project_sdlc_phases.id'), nullable=False)
    milestone_id = Column(Integer, ForeignKey('project_milestones.id'), nullable=False, index=True)
    created_at   = Column(DateTime, default=func.now())

    phase     = relationship("ProjectSDLCPhase", back_populates="milestone_links")
    milestone = relationship("ProjectMilestone", back_populates="sdlc_links")


def _seed_sdlc_methodology(db_session, methodology, phases) -> None:
    import json
    for pos, p in enumerate(phases):
        db_session.add(SDLCPhaseTemplate(
            methodology=methodology, position=pos,
            name=p['name'], description=p['description'],
            exit_criteria=p['exit_criteria'],
            doc_categories=json.dumps(p['doc_categories']),
            default_tasks=json.dumps([list(t) for t in p['tasks']]),
            weight=p['weight'],
            repeatable=p.get('repeatable', False),
        ))


def ensure_sdlc_templates_seeded(db_session) -> None:
    """Seed the master SDLC phase templates from sdlc.DEFAULT_PHASES, once."""
    from .sdlc import DEFAULT_PHASES, LEGACY_TEMPLATE_SETS
    if db_session.query(SDLCPhaseTemplate).count():
        # Upgrade an UNTOUCHED legacy template (any earlier default stage
        # set) to the current defaults. Running projects are unaffected
        # (they hold snapshots); an admin-modified template - any change to
        # the stage names - is left alone.
        for methodology, legacy_sets in LEGACY_TEMPLATE_SETS.items():
            rows = (db_session.query(SDLCPhaseTemplate)
                    .filter_by(methodology=methodology)
                    .order_by(SDLCPhaseTemplate.position,
                              SDLCPhaseTemplate.id).all())
            if [r.name for r in rows] in legacy_sets:
                for r in rows:
                    db_session.delete(r)
                db_session.flush()
                _seed_sdlc_methodology(db_session, methodology,
                                       DEFAULT_PHASES[methodology])
                db_session.commit()
        # Already seeded - but a template table created before the repeatable
        # flag existed has it 0 everywhere (the additive column's default).
        # Idempotently mark the default repeatable phases by name so agile
        # sprints work without a reseed (which would discard admin edits).
        if not (db_session.query(SDLCPhaseTemplate)
                .filter_by(repeatable=True).count()):
            changed = False
            for methodology, phases in DEFAULT_PHASES.items():
                for p in phases:
                    if not p.get('repeatable'):
                        continue
                    row = (db_session.query(SDLCPhaseTemplate)
                           .filter_by(methodology=methodology, name=p['name'])
                           .first())
                    if row and not row.repeatable:
                        row.repeatable = True
                        changed = True
            if changed:
                db_session.commit()
        return
    for methodology, phases in DEFAULT_PHASES.items():
        _seed_sdlc_methodology(db_session, methodology, phases)
    db_session.commit()


# ---------------------------------------------------------------------------
# Go-Live plan
#
# A single Go-Live plan per project (1:1). Each of the six sections can be
# toggled on/off independently via the `enable_*` flags. The task-style
# sections (pre-requisite, production, post go-live, failover/DR) share one
# child table (GoLiveTask) keyed by `section`; External Connectivity and
# Contact Point have their own child tables because their columns differ.
# ---------------------------------------------------------------------------

class GoLivePlan(Base):
    __tablename__ = 'golive_plans'

    id         = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=False, unique=True)

    # Per-section toggles - only enabled sections appear in the plan/export.
    enable_prerequisite          = Column(Boolean, default=False, nullable=False)
    enable_production            = Column(Boolean, default=False, nullable=False)
    enable_post_golive           = Column(Boolean, default=False, nullable=False)
    enable_failover_dr           = Column(Boolean, default=False, nullable=False)
    enable_external_connectivity = Column(Boolean, default=False, nullable=False)
    enable_contact_point         = Column(Boolean, default=False, nullable=False)

    created_by = Column(Integer, ForeignKey('users.id'), nullable=False)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    project       = relationship("Project", back_populates="golive_plan")
    tasks         = relationship("GoLiveTask",         back_populates="plan",
                                 cascade="all, delete-orphan")
    connectivities = relationship("GoLiveConnectivity", back_populates="plan",
                                  cascade="all, delete-orphan")
    contacts      = relationship("GoLiveContact",      back_populates="plan",
                                 cascade="all, delete-orphan")

    def is_section_enabled(self, section_key: str) -> bool:
        return bool(getattr(self, f'enable_{section_key}', False))

    def tasks_for(self, section_key: str):
        """Return this plan's tasks for one task-style section, in entry order."""
        return [t for t in sorted(self.tasks, key=lambda x: (x.sort_order, x.id))
                if t.section == section_key]

    def tasks_for_display(self, section_key: str):
        """
        Tasks for one task-style section ordered by their start date/time,
        ascending - undated rows sort last. Used for the read-only project view
        so each section reads chronologically.
        """
        import datetime as _dt
        far = _dt.datetime.max
        return sorted(
            (t for t in self.tasks if t.section == section_key),
            key=lambda t: (t.start_datetime or far, t.sort_order, t.id),
        )


class GoLiveTask(Base):
    """
    A row in one of the task-style Go-Live sections. `section` is one of
    GOLIVE_TASK_SECTION_KEYS (prerequisite / production / post_golive /
    failover_dr). All four share these common columns.
    """
    __tablename__ = 'golive_tasks'

    id             = Column(Integer, primary_key=True)
    plan_id        = Column(Integer, ForeignKey('golive_plans.id'), nullable=False, index=True)
    section        = Column(String(40), nullable=False)
    task           = Column(String(300), nullable=False)
    description    = Column(Text)
    server_host    = Column(String(300))
    department     = Column(String(100))
    team           = Column(String(150))
    start_datetime = Column(DateTime)
    end_datetime   = Column(DateTime)
    status         = Column(String(40), default='Not Started', nullable=False)
    sort_order     = Column(Integer, default=0)

    plan = relationship("GoLivePlan", back_populates="tasks")


class GoLiveConnectivity(Base):
    """External Connectivity section - source/destination host routing."""
    __tablename__ = 'golive_connectivities'

    id               = Column(Integer, primary_key=True)
    plan_id          = Column(Integer, ForeignKey('golive_plans.id'), nullable=False, index=True)
    source_host      = Column(String(300))
    destination_host = Column(String(300))
    port             = Column(String(100))
    direction        = Column(String(40))
    description      = Column(Text)
    sort_order       = Column(Integer, default=0)

    plan = relationship("GoLivePlan", back_populates="connectivities")


class GoLiveContact(Base):
    """Contact Point section - who to reach during the go-live window."""
    __tablename__ = 'golive_contacts'

    id             = Column(Integer, primary_key=True)
    plan_id        = Column(Integer, ForeignKey('golive_plans.id'), nullable=False, index=True)
    department     = Column(String(100))
    team           = Column(String(150))
    email          = Column(String(200))
    contact_number = Column(String(60))
    sort_order     = Column(Integer, default=0)

    plan = relationship("GoLivePlan", back_populates="contacts")


# ---------------------------------------------------------------------------
# HLD (High-Level Design) Template
#
# Two halves:
#   1. A single, global *master template* that an admin curates - a TREE of
#      sections and sub-sections (self-referential via `parent_id`), each either
#      a narrative block or a table (with admin-defined columns). Numbering is
#      derived from the tree: top-level sections are 1, 2, 3...; their children are
#      2.1, 2.2...; grandchildren 2.3.1... HLDTemplateSection / HLDTemplateColumn.
#   2. A *per-project HLD* (1:1 with a project, mirroring GoLivePlan) that any
#      project member fills in against the current master template. Each project
#      section can be toggled Required / Not Required, carries (for table
#      sections only) a short intro "brief description", and any number of data
#      rows. ProjectHLD / ProjectHLDSection / ProjectHLDRow below.
#
# A project section is bound to a master section by `template_section_id`, so the
# master template can evolve without rewriting existing HLDs: missing project
# sections are created lazily, and project sections whose master section was
# removed are simply not displayed/exported.
# ---------------------------------------------------------------------------

# Default "brief description" prefix used when a user leaves a table section's
# intro blank (requirement: tables start with a short description, defaulted).
def hld_default_intro(title: str) -> str:
    title = (title or 'this section').strip()
    return f'Below is the brief description of {title}.'


class HLDTemplateSection(Base):
    """
    One node in a global master document template tree (admin-managed).

    The same table drives every builder document kind: `doc_type` discriminates
    the trees ('hld' = High-Level Design, 'brd' = Business Requirements
    Document, 'ssia' = System Security Impact Assessment). A section and its
    children always share the same doc_type.
    """
    __tablename__ = 'hld_template_sections'

    id          = Column(Integer, primary_key=True)
    doc_type    = Column(String(10), nullable=False, default='hld')
    parent_id   = Column(Integer, ForeignKey('hld_template_sections.id'), index=True)  # None = top level
    position    = Column(Integer, nullable=False, default=0)   # 0-based order *among siblings*
    title       = Column(String(255), nullable=False)
    description = Column(Text)                                  # guidance (editor only - never exported)
    has_table   = Column(Boolean, default=False, nullable=False)
    # "Structured entries" sections (e.g. BRD detailed requirement specs, use
    # cases): a JSON config describing repeating entry blocks - an id prefix
    # ("BR" -> BR-1, BR-2 ...), the per-entry fields, and any per-entry
    # sub-tables. NULL for plain narrative / table sections.
    block_config = Column(Text)
    created_at  = Column(DateTime, default=func.now())
    updated_at  = Column(DateTime, default=func.now(), onupdate=func.now())

    columns = relationship(
        "HLDTemplateColumn", back_populates="section",
        cascade="all, delete-orphan", order_by="HLDTemplateColumn.sort_order",
    )
    children = relationship(
        "HLDTemplateSection",
        backref=backref("parent", remote_side=[id]),
        cascade="all, delete-orphan",
        order_by="HLDTemplateSection.position",
    )

    def ordered_columns(self):
        return sorted(self.columns, key=lambda c: (c.sort_order, c.id))

    def _config(self):
        """The raw parsed block_config dict, or None."""
        if not self.block_config:
            return None
        try:
            data = json.loads(self.block_config)
        except (ValueError, TypeError):
            return None
        return data if isinstance(data, dict) else None

    def block_conf(self):
        """Parsed structured-entries config, or None for normal sections."""
        data = self._config()
        return data if data and data.get('fields') else None

    def layout(self):
        """
        The render layout this section imposes on its CHILDREN, or None.

        'qa' - the SSIA questionnaire layout: a child renders as a banner
        carrying the question, directly above its answer, instead of as a
        numbered heading with a column-headed table. Declaring it on the PARENT
        is deliberate: a question an administrator adds later inherits the
        layout automatically, so the questionnaire cannot end up half-styled.
        """
        data = self._config()
        return data.get('layout') if data else None


def flatten_hld_tree(sections):
    """
    Given a flat list of *all* HLDTemplateSection rows, return them in document
    order as dicts: {'section', 'parent' (or None), 'number' ('2.3.1'),
    'depth' (0-based)}.
    """
    by_parent = {}
    for s in sections:
        by_parent.setdefault(s.parent_id, []).append(s)
    for kids in by_parent.values():
        kids.sort(key=lambda x: (x.position, x.id))

    out = []

    def walk(parent_id, prefix, depth, parent):
        for idx, s in enumerate(by_parent.get(parent_id, []), start=1):
            number = f"{prefix}{idx}" if not prefix else f"{prefix}.{idx}"
            out.append({'section': s, 'parent': parent,
                        'number': number, 'depth': depth})
            walk(s.id, number, depth + 1, s)

    walk(None, "", 0, None)
    return out


class HLDTemplateColumn(Base):
    """A column belonging to a table-style master section."""
    __tablename__ = 'hld_template_columns'

    id         = Column(Integer, primary_key=True)
    section_id = Column(Integer, ForeignKey('hld_template_sections.id'), nullable=False, index=True)
    name       = Column(String(200), nullable=False)
    sort_order = Column(Integer, default=0)

    section = relationship("HLDTemplateSection", back_populates="columns")


class ProjectHLD(Base):
    """A project's single High-Level Design document (1:1 with Project)."""
    __tablename__ = 'project_hlds'

    id         = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=False, unique=True)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=False)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    project  = relationship("Project", back_populates="hld")
    sections = relationship(
        "ProjectHLDSection", back_populates="hld",
        cascade="all, delete-orphan",
    )


class ProjectHLDSection(Base):
    """
    A project's filled-in content for one master section.

    `is_required` True  -> the section is included and the user fills its form.
    `is_required` False -> "Not Required": the form is hidden and the export
    renders a professional "not applicable" note instead.
    """
    __tablename__ = 'project_hld_sections'

    id                  = Column(Integer, primary_key=True)
    hld_id              = Column(Integer, ForeignKey('project_hlds.id'), nullable=False, index=True)
    template_section_id = Column(Integer, ForeignKey('hld_template_sections.id'), nullable=False, index=True)
    is_required         = Column(Boolean, default=True, nullable=False)
    short_description   = Column(Text)     # the table/section intro "brief description"
    content             = Column(Text)     # narrative body (non-table sections)
    updated_at          = Column(DateTime, default=func.now(), onupdate=func.now())

    hld              = relationship("ProjectHLD", back_populates="sections")
    template_section = relationship("HLDTemplateSection")
    rows             = relationship(
        "ProjectHLDRow", back_populates="section",
        cascade="all, delete-orphan", order_by="ProjectHLDRow.sort_order",
    )

    def ordered_rows(self):
        return sorted(self.rows, key=lambda r: (r.sort_order, r.id))


class ProjectHLDRow(Base):
    """
    One data row inside a table-style project section. Because the columns are
    admin-defined (and can change), each row stores its cell values as a JSON
    object keyed by the master column id, e.g. {"12": "value", "13": "..."}.
    """
    __tablename__ = 'project_hld_rows'

    id         = Column(Integer, primary_key=True)
    section_id = Column(Integer, ForeignKey('project_hld_sections.id'), nullable=False, index=True)
    cells      = Column(Text, default='{}')   # JSON: {column_id: value}
    sort_order = Column(Integer, default=0)

    section = relationship("ProjectHLDSection", back_populates="rows")

    def cell_map(self) -> dict:
        import json
        try:
            data = json.loads(self.cells or '{}')
            return {str(k): v for k, v in data.items()} if isinstance(data, dict) else {}
        except (ValueError, TypeError):
            return {}


# Master-template seed: the NPg Enterprise Solution Design (HLD) structure,
# faithfully mirroring the supplied design's section / sub-section hierarchy.
# Each node: {"title", "guide", "cols" (table columns or None), "children"}.
# `guide` is admin/editor guidance only - it is never written to the export.
def _n(title, guide=None, cols=None, children=None, block=None):
    return {"title": title, "guide": guide, "cols": cols,
            "children": children or [], "block": block}


# Reference content for the Target Service Level section - the three standard NPg
# tiers from the design. Used BOTH as the section's instruction note (shown in
# the editor) and to pre-fill the section's table rows in a new HLD. Multi-line
# characteristics are newline-separated.
HLD_SERVICE_LEVEL_TITLE = "Target Service Level"

HLD_SERVICE_LEVEL_ROWS = [
    ("Gold",
     "Services provided all day, every day\n"
     "99.99% availability\n"
     "Back on-line within 30 minutes of a failure\n"
     "No more than one unplanned outage per year\n"
     "Dual site resilience"),
    ("Silver",
     "08:00 to 17:30 Mon - Fri, excluding Public Holidays\n"
     "99.95% availability\n"
     "Back on-line within 2 hours of a failure\n"
     "Disaster recovery within 3 days of a failure\n"
     "6 months mean time between failures (MTBF)\n"
     "Resilient within a single data centre"),
    ("Bronze",
     "08:00 to 17:30 Mon - Fri, excluding Public Holidays"),
]


def _service_level_guidance() -> str:
    """Multi-line instruction note listing the standard service tiers."""
    lines = ["Record the agreed service level for this solution and its characteristics. "
             "Standard NPg service tiers (keep the applicable one and delete the rest):"]
    for level, chars in HLD_SERVICE_LEVEL_ROWS:
        lines.append("")
        lines.append(level)
        for ch in chars.split("\n"):
            lines.append("* " + ch)
    return "\n".join(lines)


# Section / sub-section hierarchy faithfully mirroring the supplied design,
# "IS High Level Design v2_2" - the numbered body sections, their order, and the
# tables (with the design's column headers) are reproduced here. Front-matter
# (cover, document control, table of contents) is produced by the .docx renderer.
HLD_DEFAULT_TEMPLATE = [
    _n("Executive Summary",
       "Maximum of one page (two if summary graphics are included). Short sentences, "
       "extensive use of bullet points - the 'elevator pitch' any stakeholder can "
       "understand without the detail. Include a target solution overview diagram if it aids clarity."),
    _n("Context",
       "Contextual information relevant to the solution. Outline the requirement or "
       "business ask, and the principles considered for the design."),
    _n("Introduction",
       "Sets out the broad boundaries of the solution at a conceptual level. Where a "
       "sub-section does not apply, keep the heading and state why it does not apply, so "
       "the content template does not reduce over time.",
       children=[
           _n("Purpose",
              "State the purpose of the document - a common understanding of the technical "
              "architecture of the solution, its intended audience and what it must achieve."),
           _n("References",
              "Cite document name, location, author and version, and a URL where available.",
              cols=["ID", "Title", "Document Details"]),
       ]),
    _n("Scope",
       "The areas this project covers and does not cover, and the outcomes it delivers.",
       children=[
           _n("In Scope",
              "Outline the areas this project covers. Highlight which components are new "
              "and which are re-used; a simple context diagram helps."),
           _n("Out of Scope",
              "Identify what is out of scope and, where known, the project/workstream it "
              "is in scope of and whether it was considered as part of this design."),
           _n("Outcomes",
              "A bulleted list of outcomes the solution will provide - the basis for "
              "stakeholders to agree the solution gives them what they requested.",
              children=[
                  _n("Non-Functional Requirements",
                     "Non-functional requirements identified as architecturally significant "
                     "in delivering the outcomes.",
                     cols=["ID", "Non-Functional Requirement", "Solution Alignment"]),
                  _n("Functional Requirements",
                     "Functional requirements identified as architecturally significant in "
                     "delivering the outcomes; note in 'Solution Alignment' the section that meets each.",
                     cols=["ID", "Functional Requirement", "Solution Alignment"]),
                  _n("Business or Client Problem",
                     "The business need being addressed, described through business use "
                     "cases and user stories."),
                  _n("Stakeholder Obligations",
                     "Actions stakeholders must carry out that are obligations key to the "
                     "delivery of the outcomes (not engagement obligations)."),
                  _n("Target Service Level",
                     _service_level_guidance(),
                     cols=["Service Level", "Characteristics"]),
              ]),
       ]),
    _n("Architectural Solution Design Overview",
       "The baseline and target technology architecture, the key design decisions and "
       "the patterns and integrations used within the solution.",
       children=[
           _n("Baseline Technology Architecture",
              "Include only where needed to inform key decisions - the foundation the "
              "solution will be built upon and the existing standards it must align with."),
           _n("Target Technology Architecture",
              "All aspects of the target (to-be) architecture, with a high-level logical "
              "diagram of the end state plus diagrams for any significant transition states.",
              children=[
                  _n("Host Components",
                     "Standard (S/M/L) server sizing, existing vs new hardware, deployment "
                     "locations and capacity requirements."),
                  _n("Application Components",
                     "Application tiers (client/web/application/database), the technologies "
                     "and versions proposed, and their vendor support status."),
                  _n("Database Components",
                     "Expected data volumes, likely SAN storage needs and any Enterprise "
                     "Service Bus functions."),
                  _n("Storage Components",
                     "1 / 3 / 5 year storage growth forecast for environment management, "
                     "placement and costing.",
                     cols=["Storage Type", "1 Year (GB)", "3 Year (GB)", "5 Year (GB)"]),
                  _n("Middleware Components",
                     "Any middleware required (e.g. Apache Tomcat, WebLogic, MuleSoft, JBoss, ActiveMQ)."),
                  _n("Network Integration",
                     "Network impact, changed traffic patterns across WAN/LAN, encryption "
                     "used and bandwidth impact. Include the data flow table.",
                     cols=["Source System (Zone)", "Destination System (Zone)", "Data Description",
                           "Protocol / Port", "Security Controls"]),
                  _n("Integration, Interface and Co-Existence",
                     "Test/dev environments, the interfaces required (including to/from "
                     "external organisations) and their nature (real-time, batch, read-only)."),
                  _n("Backup and Recovery",
                     "Which components require backups, how they are performed and any "
                     "volumetric issues."),
                  _n("DR and BCP",
                     "Disaster Recovery and Business Continuity approach, including how the "
                     "solution meets the designated RTO and RPO and any testing obligations."),
                  _n("As is:",
                     "How the service currently operates, to understand and compare against "
                     "the existing environment."),
                  _n("To-Be Conceptual Architecture",
                     "A conceptual view using objects familiar to the business; bring all "
                     "elements together into as-is and to-be diagrams."),
                  _n("Process View",
                     "Business process changes - the main process categories, the steps in "
                     "each process and the role that carries out each step."),
              ]),
           _n("Architecture and Solution Design Decisions",
              "Decisions that impact the overall solution and that might not adhere to "
              "standard patterns and integrations.",
              cols=["ID", "Agreed Date", "Decision and Rationale"]),
           _n("Architecture Patterns and Integration Requirements",
              "Proposed patterns and integrations used within the solution.",
              cols=["ID", "Title Ref", "Pattern & Integration Description"]),
       ]),
    _n("Business Architecture",
       "Each business role within the solution, plus any location or organisational "
       "changes and the impact to the overall business models."),
    _n("Security and Compliance",
       "Mandatory section - complete all sub-sections. Where a sub-section is not "
       "applicable, denote it N/A. Refer to BHE Security Policies & NPg Baseline Security Controls.",
       children=[
           _n("Data Security",
              "Technical controls covering data integrity, content filtering, encryption "
              "and anonymisation, and the controls the DPIA requires for moving data "
              "between trust zones.",
              children=[
                  _n("Data Classification", "How data is classified, tagged, tracked and stored."),
                  _n("Data Encryption (In Transit & At Rest)",
                     "Encryption ciphers, bit depth and protocols for data at rest and in "
                     "transit, where they are controlled from, and related cryptography (PKI, self-certs)."),
              ]),
           _n("Data Governance", "Lifecycle management, ownership, quality and retention."),
           _n("Identity and Access Management Controls", "SSO, MFA, PAM and access routing."),
           _n("User Roles", "Application user roles and their permissions."),
           _n("Privileged System Roles", "Administrative roles under least-privilege principles."),
           _n("Monitoring, Logging & Auditing", "Event capture, logging and SIEM integration."),
           _n("Security Hardening", "Hardening against corporate rules and CIS Benchmarks."),
           _n("Secrets Management", "Credential, token and key storage."),
           _n("Firewall & Network Security", "Boundary controls and intrusion detection."),
           _n("Compliance Requirements", "Alignment with baseline security checklists and policies."),
           _n("Security Testing", "Vulnerability scanning and SAST/DAST."),
           _n("Risk Management", "Security risks, their categories and the controls applied."),
           _n("Security Operations", "Operating model and SOC integration."),
       ]),
    _n("Implementation View",
       "How the solution will be delivered - the high-level activities and the "
       "organisation teams responsible for each.",
       cols=["High-Level Activity", "Organisation Team 1", "Organisation Team 2",
             "Organisation Team 3", "Organisation Team 4"]),
    _n("Decommissioning",
       "How legacy components and data stores will be retired and securely sanitised once live."),
    _n("Support",
       "The support model for the solution and the responsibilities of each support team.",
       cols=["Responsibility", "Support Team 1", "Support Team 2", "Support Team 3"]),
    _n("Risk, Assumptions, Issues and Dependencies",
       "The project RAID position for this design.",
       children=[
           _n("Risks", "Risks as IF/THEN statements with mitigation, likelihood, impact and owner.",
              cols=["ID", "Risk (If, then statement)", "Mitigation (How will the risk be managed)",
                    "Likelihood (Hi/Med/Low)", "Impact (Hi/Med/Low)", "Owner"]),
           _n("Assumptions", "Assumptions made, their origination and owner.",
              cols=["ID", "Assumption", "Origination", "Owner"]),
           _n("Issues", "Current issues, their origination and owner.",
              cols=["ID", "Issue", "Origination", "Owner"]),
           _n("Dependencies", "Dependencies the delivery relies upon and their owners.",
              cols=["ID", "Dependencies", "Owner"]),
           _n("Constraints", "Known constraints that influence the design decisions.",
              cols=["ID", "Constraint", "Solution Impact"]),
       ]),
]


# Structured-entries ("block") configs for the BRD sections whose content is
# too rich for a table: each entry is a full paragraph block (BR-1, BR-2, ...)
# added via an Add button in the builder. Field types: 'text' renders inline
# ("Label: value"), 'textarea' renders a label line + paragraphs.
def _spec_block(prefix, item_label, description_placeholder):
    return {
        "prefix": prefix,
        "item_label": item_label,
        "fields": [
            {"key": "title", "label": "Requirement Title", "type": "text",
             "placeholder": "Short, unique requirement title"},
            {"key": "priority", "label": "Priority (MoSCoW)", "type": "text",
             "placeholder": "Must / Should / Could / Won't"},
            {"key": "description", "label": "Description", "type": "textarea",
             "placeholder": description_placeholder},
            {"key": "rationale", "label": "Business Rationale / Justification",
             "type": "textarea",
             "placeholder": "Why this is needed; the value or problem it addresses."},
            {"key": "detail", "label": "Detailed Requirement / Expected Outcome",
             "type": "textarea",
             "placeholder": "Elaborate the specifics: scope, conditions, business rules "
                            "involved, volumes, and any edge cases."},
            {"key": "dependencies", "label": "Dependencies / Related Requirements",
             "type": "textarea",
             "placeholder": "Related IDs, upstream/downstream dependencies, or assumptions."},
        ],
        "tables": [],
    }


BRD_BR_BLOCK = _spec_block(
    "BR", "Business Requirement",
    "Describe the business need in full - the capability required, the context, "
    "who is affected, and the desired outcome.")

BRD_FR_BLOCK = _spec_block(
    "FR", "Functional Requirement",
    "State the functional requirement: 'The system shall ...'. Include actor, "
    "action, and triggering condition.")

BRD_UC_BLOCK = {
    "prefix": "UC",
    "item_label": "Use Case",
    "fields": [
        {"key": "title", "label": "Use Case Name", "type": "text",
         "placeholder": "e.g. Customer registers for the portal"},
        {"key": "actor", "label": "Primary Actor", "type": "text",
         "placeholder": "Who initiates this use case"},
        {"key": "goal", "label": "Goal / Description", "type": "textarea",
         "placeholder": "What the actor is trying to achieve and why."},
        {"key": "priority", "label": "Priority", "type": "text",
         "placeholder": "Must / Should / Could / Won't"},
    ],
    "tables": [
        {"key": "data_fields", "title": "Data Fields",
         "columns": ["Field", "Description"]},
        {"key": "main_flow", "title": "Main (Happy-Path) Flow",
         "columns": ["Step No", "Actor Action", "System Response"]},
        {"key": "alt_flows", "title": "Alternate / Exception Flows",
         "columns": ["Ref No", "Condition", "Alternate Behaviour"]},
    ],
}


# Section / sub-section hierarchy faithfully mirroring the supplied
# "BRD_Template.docx" - the numbered body sections, their order, and the
# tables (with the template's column headers) are reproduced here. Front
# matter (cover, document control - revision history / reviewers / approvals /
# distribution / related documents - and table of contents) is produced by the
# .docx renderer, exactly as for the HLD.
BRD_DEFAULT_TEMPLATE = [
    _n("Executive Summary",
       "A concise, executive-level narrative (about one page). Summarise the business "
       "problem, the proposed solution, the expected value, and the ask. Written last, read first.",
       children=[
           _n("Key Points at a Glance",
              "One-line summaries of the essentials: problem, solution, sponsor, "
              "budget range, target date, expected benefit.",
              cols=["Aspect", "Summary"]),
       ]),
    _n("Introduction",
       children=[
           _n("Purpose of this Document",
              "State why this BRD exists and who should use it."),
           _n("Business Objectives",
              "Objectives should be SMART - Specific, Measurable, Achievable, Relevant, Time-bound.",
              cols=["ID", "Business Objective", "Success Measure / KPI", "Target"]),
           _n("Project Background & Context",
              "Explain the drivers behind the initiative - market, regulatory, operational, strategic."),
           _n("Scope",
              "The boundaries of the initiative - what is included and what is deliberately excluded.",
              children=[
                  _n("In Scope",
                     "List every item the initiative will deliver or change.",
                     cols=["#", "In-Scope Item", "Description / Notes"]),
                  _n("Out of Scope",
                     "Identify what is excluded and why, to manage expectations.",
                     cols=["#", "Out-of-Scope Item", "Rationale"]),
              ]),
           _n("Definitions, Acronyms & Abbreviations",
              "Define every term or acronym a reader outside the project team may not know.",
              cols=["Term / Acronym", "Definition"]),
       ]),
    _n("Stakeholder Analysis",
       "Identify everyone affected by, or influencing, the initiative. Use the "
       "Influence/Interest rating to prioritise engagement.",
       cols=["Stakeholder / Group", "Role", "Responsibility / Interest", "Influence", "Interest"],
       children=[
           _n("RACI Matrix",
              "R = Responsible - A = Accountable - C = Consulted - I = Informed. "
              "Exactly one 'A' per activity.",
              cols=["Activity / Deliverable", "Sponsor", "BA", "Dev Lead", "QA"]),
       ]),
    _n("Current State & Future State",
       children=[
           _n("Current State (As-Is)",
              "Describe how the process/system operates today, including pain points. "
              "Reference or embed the As-Is process map.",
              children=[
                  _n("Pain Points & Opportunities",
                     "The specific problems in the current state and their business impact.",
                     cols=["ID", "Pain Point", "Impact", "Severity"]),
              ]),
           _n("Future State (To-Be)",
              "Describe the desired end-state after the solution is delivered. "
              "Reference or embed the To-Be process map."),
       ]),
    _n("Business Requirements",
       "High-level requirements expressing WHAT the business needs (not how). Each must be "
       "uniquely identifiable, atomic, and testable. Priority uses MoSCoW: Must / Should / Could / Won't.",
       children=[
           _n("Business Requirements Register (Summary)",
              "At-a-glance list of all business requirements for traceability.",
              cols=["Req ID", "Requirement Statement (summary)", "Priority", "Objective Ref", "Source"]),
           _n("Detailed Business Requirement Specifications",
              "One full specification block per business requirement - use Add to "
              "create BR-1, BR-2, ... Each block gives room for the complete narrative: "
              "description, rationale, expected outcome and dependencies.",
              block=BRD_BR_BLOCK),
       ]),
    _n("Functional Requirements",
       "Specific system behaviours that satisfy the business requirements. "
       "Trace each back to a BR-ID.",
       children=[
           _n("Functional Requirements Register (Summary)",
              "At-a-glance list of all functional requirements for traceability.",
              cols=["FR ID", "Functional Requirement (summary)", "Priority", "Traces to BR", "Acceptance Ref"]),
           _n("Detailed Functional Requirement Specifications",
              "One full specification block per functional requirement - use Add to "
              "create FR-1, FR-2, ... State each as 'The system shall ...' with actor, "
              "action and triggering condition.",
              block=BRD_FR_BLOCK),
       ]),
    _n("Non-Functional Requirements (NFRs)",
       "Quality attributes and constraints - HOW WELL the system must perform. "
       "Make every NFR measurable.",
       cols=["NFR ID", "Category", "Requirement (measurable)", "Priority"]),
    _n("Use Cases & Scenarios",
       "Document each significant interaction between an actor and the system - "
       "use Add to create UC-1, UC-2, ... Each use case carries its actor, goal and "
       "priority plus its data fields, main flow and alternate/exception flows.",
       block=BRD_UC_BLOCK),
    _n("Business Rules",
       "Constraints and policies the solution must enforce, independent of any specific requirement.",
       cols=["Rule ID", "Business Rule", "Type", "Ref FR"]),
    _n("Data Requirements",
       children=[
           _n("Data Dictionary",
              "Define each key data element the solution captures, stores, or processes.",
              cols=["Field Name", "Description", "Type", "Mandatory", "Validation / Format"]),
           _n("Data Migration & Integration",
              "Data moving between systems - one row per source-to-target flow.",
              cols=["Source", "Target", "Data / Object", "Method"]),
       ]),
    _n("Assumptions, Constraints & Dependencies",
       children=[
           _n("Assumptions",
              "What is being taken as true, and the impact if it turns out to be false.",
              cols=["ID", "Assumption", "Impact if False"]),
           _n("Constraints",
              "Fixed limitations the solution must work within (budget, time, technology, regulation).",
              cols=["ID", "Constraint", "Type"]),
           _n("Dependencies",
              "External deliverables or decisions this initiative relies upon.",
              cols=["ID", "Dependency", "Owner", "Needed By"]),
       ]),
    _n("Risk Assessment",
       "Probability x Impact drives the rating. Assign an owner and mitigation "
       "to every High/Medium risk.",
       cols=["ID", "Risk Description", "Probability", "Impact", "Mitigation / Response", "Owner"]),
    _n("Cost-Benefit Analysis",
       "Summarise the financial justification. Detailed models may be attached as an appendix.",
       cols=["Category", "Year 1", "Year 2", "Year 3"],
       children=[
           _n("Financial Metrics",
              "Headline financial measures, e.g. NPV, ROI, payback period.",
              cols=["Metric", "Value"]),
       ]),
    _n("Acceptance Criteria",
       "Define the objective conditions under which the business will accept the delivered "
       "solution. Ideally in Given / When / Then form.",
       cols=["AC ID", "Acceptance Criterion (Given / When / Then)", "Ref FR"]),
    _n("Requirements Traceability Matrix (RTM)",
       "Traces every requirement from business objective through to test coverage, "
       "ensuring nothing is lost or gold-plated.",
       cols=["Objective", "Business Req", "Functional Req", "Use Case", "Acceptance", "Test Case"]),
    _n("Appendices",
       children=[
           _n("Process Flow Diagrams",
              "Insert or link As-Is / To-Be process maps, swimlane diagrams, or BPMN models."),
           _n("Wireframes / Mock-ups",
              "Insert or link UI wireframes and screen mock-ups."),
           _n("Supporting Analysis",
              "Insert or link detailed financial models, survey data, or research."),
           _n("Open Issues / Parking Lot",
              "Unresolved questions to be settled before or during delivery.",
              cols=["ID", "Open Issue / Question", "Owner", "Status"]),
       ]),
]


# ===========================================================================
# SSIA - System Security Impact Assessment
#
# The third builder document kind, sharing the same HLDTemplateSection engine
# as the HLD and the BRD. The section order, the table column headers and the
# question wording reproduce the corporate SSIA pro-forma: the initial
# screening checklist that decides whether a full assessment is needed, the
# detailed assessment, the questionnaire, the governance review, the appendix
# and sign-off.
#
# Section 1 of the pro-forma (Document Control & Governance) is front matter
# and is produced by the .docx renderer, exactly as for the HLD and the BRD,
# so the numbered body below starts at the screening checklist.
#
# Every screening question and every detailed question is a first-class
# template node (a pre-filled table row and a sub-section respectively), so an
# administrator adds, edits, re-orders and removes questions through exactly
# the same template manager used for the HLD and the BRD - no code change.
# ===========================================================================

SSIA_SCREENING_TITLE = "Screening Questions"
SSIA_QUESTIONS_TITLE = "Detailed Security Impact Assessment Questions"

# The questionnaire layout, declared on the PARENT of the detailed questions.
# Each child then renders the way the pro-forma does - an accent banner
# carrying "Question N: <question>" directly above a two-cell answer
# (a short response classification, then the detail) - rather than as a
# numbered heading above a column-headed table.
SSIA_QA_LAYOUT = {"layout": "qa"}

# The two columns of every question's answer block.
SSIA_ANSWER_COLUMNS = ["Response", "Details / Security Controls in Place"]

# The standard screening questionnaire. Answering "Yes" to any one of these is
# an indication that a full SSIA is required. Pre-filled into the builder's
# screening table with the responses left blank for the author - see
# GUEST_PREFILL_ROWS.
SSIA_SCREENING_QUESTIONS = [
    "Does the solution access the operational control system (PoF) environment?",
    "Does the solution access the Smart Metering environment?",
    "Is the solution 'cloud' based?",
    "Will the solution process any sensitive, personal, personnel or financial data?",
    "Will the solution be required to accept incoming connections from the Internet?",
    "Will the solution require an outbound connection to the Internet?",
    "Will the solution be available to 3rd parties?",
    "Will the solution require users to authenticate?",
    "Will the solution integrate with Active Directory?",
    "Will the solution require any data exchange with the operational control "
    "system, Smart Metering, or non-corporate networks?",
    "Will the service be a P1 service?",
    "Will the service interact with regulatory requirement data feeds?",
    "Will the service provide a regulatory requirement?",
    "Is all authentication and cross-network-boundary traffic encrypted?",
    "Is data encrypted at rest?",
    "Can we carry out an audit of the 3rd party for IT security processes and "
    "principles?",
    "Is there an agreed process the supplier follows should there be a security "
    "incident?",
    "Has a penetration test been performed on the solution?",
]

# One sub-section per detailed assessment question, in the same order as the
# screening list above. The title IS the question, because section guidance is
# editor-only and never exported - the finished document must show the
# question above its answer.
SSIA_DETAIL_QUESTIONS = [
    ("Describe the security controls in place for connections to the operational "
     "control system (PoF) environment",
     "If there is no connectivity, respond 'Not Applicable' and say why. Otherwise "
     "describe the boundary, the protocol, the authentication and the monitoring."),
    ("Describe the security controls in place for connections to the Smart "
     "Metering environment",
     "Cover the interface, the data crossing it, and the controls protecting it."),
    ("Detail the 'Cloud' solution",
     "Name the provider, region, tenancy model and service type, and the controls "
     "applied to identity, network, data and logging. Respond 'Not Applicable' for "
     "an on-premise solution."),
    ("Describe the personal or financial data being processed. Confirm that a DPIA "
     "has been completed and provide the reference",
     "Identify the data categories, the lawful basis, the retention period, and "
     "the Data Protection Impact Assessment reference (or why one is not "
     "required)."),
    ("Detail the security controls in place for the solution to accept incoming "
     "connections from the Internet",
     "Describe the perimeter: firewall, reverse proxy, WAF, TLS termination, "
     "authentication and rate limiting."),
    ("Detail the security controls in place for the solution to make outbound "
     "connections to the Internet",
     "Describe egress control: proxy, allow-list, inspection and logging."),
    ("Detail the 3rd parties who will use this solution",
     "Name each party, what they access, how access is granted and revoked, and "
     "the contractual security obligations that apply."),
    ("Detail how the users will authenticate",
     "Describe the identity source, credential type, multi-factor position, "
     "session handling and the role-based access model."),
    ("Detail how the solution will integrate with Active Directory",
     "Describe the integration method, the protocol and port, encryption in "
     "transit, the service accounts used, and group-to-role mapping."),
    ("Detail the security controls in place for the solution to exchange data "
     "with other systems",
     "For each interface state the direction, transport, encryption, "
     "authentication and integrity checks."),
    ("If the system is classified as P1, detail the security controls which will "
     "enable resilience",
     "Cover high availability, failover, backup and restore, RTO and RPO, and the "
     "disaster-recovery position."),
    ("Describe how the interaction with the regulatory requirements and data "
     "feeds will be protected",
     "Identify each regulated feed, the boundary it crosses, and the controls "
     "protecting confidentiality, integrity and availability."),
    ("Provide details of the regulation this solution must comply with",
     "List the applicable regulation and standards, and how compliance is "
     "evidenced."),
    ("Provide details on how authentication and cross boundary traffic is "
     "encrypted",
     "State the protocols, versions, cipher policy and certificate management for "
     "every boundary crossed."),
    ("Provide details on how data is encrypted at rest",
     "Cover the database, the file store and backup media, the mechanism used, "
     "and key management. Where encryption at rest is not applied, state the "
     "compensating controls."),
    ("Provide the process which will allow an audit of the supplier on IT "
     "security processes and principles, or the most recent information security "
     "audit report",
     "State the audit right, its frequency, and reference the most recent "
     "information security audit report or certification."),
    ("Provide the process the supplier will follow should there be a security "
     "incident, detailing the notification and engagement",
     "Cover detection, the notification timescale, the escalation path and the "
     "post-incident review commitment."),
    ("Provide the appropriate output from the most recent penetration test",
     "Reference the test scope, date and tester, the findings by severity, and "
     "the remediation status of each."),
]


def _ssia_question_nodes():
    """The detailed questionnaire as template sub-sections, in order."""
    return [_n(title, guide, cols=list(SSIA_ANSWER_COLUMNS))
            for title, guide in SSIA_DETAIL_QUESTIONS]


# Fixed first-column labels for the pro-forma's field/value tables. The author
# fills the value column only; the labels are pre-filled by the builder so the
# document keeps the pro-forma's row order and wording (see GUEST_PREFILL_ROWS).
SSIA_SCREENING_OWNERSHIP_FIELDS = [
    "Name of Programme / Project / Policy",
    "Individual completing SIA screening (name)",
    "Individual completing SIA screening (role)",
    "Date Completed",
    "Authorised by",
]

SSIA_ASSESSMENT_OWNERSHIP_FIELDS = [
    "Name of Project / Programme",
    "Name",
    "Role",
    "Section",
    "Contact Details",
]

SSIA_DEPLOYMENT_FIELDS = [
    "Scope",
    "Business Areas",
    "Workstream",
    "Total User Base",
    "Data",
    "Integrations",
]

SSIA_ENVIRONMENT_ROWS = [
    "Non-Production",
    "Production",
]

SSIA_GOVERNANCE_QUESTIONS = [
    "What changes have been made or recommended as a result of the SSIA process?",
    "At which key milestones in the project's lifecycle will the SSIA be revisited?",
]

SSIA_APPENDIX_FIELDS = [
    "High Level Design (HLD)",
    "Network Details",
    "DPIA Reference",
]

SSIA_SIGNOFF_FIELDS = [
    "Person completing SSIA - Signature",
    "Name (in capitals)",
    "Updated By",
    "Approval Signature",
    "Name (in capitals)",
]


# Section / sub-section hierarchy for the SSIA, mirroring the pro-forma.
SSIA_DEFAULT_TEMPLATE = [
    _n("System Security Impact Assessment Initial Screening Checklist",
       "This checklist is used by any programme, project, policy or technical "
       "development that will touch on security issues. Answering 'Yes' to any of "
       "these questions is an indication that a full SSIA is required; answers can "
       "be expanded as the project develops.",
       children=[
           _n("Screening Ownership",
              "Who completed the screening, in what role, and who authorised it. "
              "The field labels are pre-filled - complete the Details column.",
              cols=["Field", "Details"]),
           _n(SSIA_SCREENING_TITLE,
              "Answer every question Yes / No / N/A and justify each answer in the "
              "comments. The standard question set is pre-filled - add a row for "
              "any additional screening question that applies.",
              cols=["No.", "Screening Question", "Yes", "No", "N/A",
                    "Comments / Notes"]),
           _n("Reasons SSIA Is / Is Not Required",
              "State plainly whether a full SSIA is required and which 'Yes' "
              "answers drove that outcome. Where no assessment is required, "
              "justify it."),
       ]),
    _n("System Security Impact Assessment (SSIA) Detailed Assessment",
       "The full detailed security impact assessment: the project parameters, the "
       "architectural objectives, and the specific security controls evaluated.",
       children=[
           _n("Assessment Ownership",
              "Who carried out the detailed assessment, and how to reach them. The "
              "field labels are pre-filled - complete the Details column.",
              cols=["Field", "Details"]),
           _n("Project Aim & Strategic Context",
              "Explain what the project aims to achieve, the benefits to the "
              "business, to individuals and to other parties, and the security, "
              "governance and audit requirements it must continue to meet."),
           _n("Architecture Evolution (AS-IS vs TO-BE)",
              "The current position against the proposed position, so a reviewer "
              "can see exactly what changes.",
              cols=["Current State (AS-IS)", "Proposed State (TO-BE)"]),
           _n("Application Deployment Summary",
              "Scope, business areas, workstream, user base, data and "
              "integrations. The field labels are pre-filled - complete the "
              "Details column.",
              cols=["Deployment Field", "Details"]),
           _n("Application Environments & URLs",
              "Every environment the solution is deployed into, its address, and "
              "who can reach it.",
              cols=["Environment", "URL / Endpoint", "Hosting / Access Scope"]),
       ]),
    _n(SSIA_QUESTIONS_TITLE,
       "Answer every question below. Where a question does not apply, respond "
       "'Not Applicable' and state why - a blank answer is not an assessment.",
       block=SSIA_QA_LAYOUT,
       children=_ssia_question_nodes()),
    _n("SSIA Governance Overview",
       "The governance review. The review questions are pre-filled - complete the "
       "Details / Recommendation column.",
       cols=["Governance Review Question", "Details / Recommendation"]),
    _n("Appendix & Reference Materials",
       "Cite every supporting document by name, version and location, so the "
       "assessment can be re-created by someone else.",
       cols=["Field / Reference Document", "Details & File Location"]),
    _n("Authorisation & Sign-Off",
       "Approval is required by the IT Security Architect prior to gateway "
       "progression.",
       cols=["Role / Sign-Off Field", "Name / Signature", "Date"]),
]


# Table rows pre-filled into the stateless guest builder, keyed by
# (doc_type, section title). Bound positionally to whatever columns the
# section carries at the time, so editing the master template cannot break
# them: a short row leaves the remaining columns blank for the author.
#
# Two kinds of prefill live here, and both exist for the same reason - the
# pro-forma fixes this text, so retyping it is how a document drifts:
#   * questionnaires  - the screening questions, numbered.
#   * first-column labels - the field/value tables whose left-hand column is
#     part of the form rather than something the author invents.
GUEST_PREFILL_ROWS = {
    ('hld', HLD_SERVICE_LEVEL_TITLE): [list(r) for r in HLD_SERVICE_LEVEL_ROWS],
    ('ssia', SSIA_SCREENING_TITLE): [
        [str(i), question]
        for i, question in enumerate(SSIA_SCREENING_QUESTIONS, 1)
    ],
    ('ssia', 'Screening Ownership'): [
        [field] for field in SSIA_SCREENING_OWNERSHIP_FIELDS],
    ('ssia', 'Assessment Ownership'): [
        [field] for field in SSIA_ASSESSMENT_OWNERSHIP_FIELDS],
    ('ssia', 'Application Deployment Summary'): [
        [field] for field in SSIA_DEPLOYMENT_FIELDS],
    ('ssia', 'Application Environments & URLs'): [
        [environment] for environment in SSIA_ENVIRONMENT_ROWS],
    ('ssia', 'SSIA Governance Overview'): [
        [question] for question in SSIA_GOVERNANCE_QUESTIONS],
    ('ssia', 'Appendix & Reference Materials'): [
        [field] for field in SSIA_APPENDIX_FIELDS],
    ('ssia', 'Authorisation & Sign-Off'): [
        [field] for field in SSIA_SIGNOFF_FIELDS],
}


# Default hierarchy per document kind, consumed by the seeders and reseeder.
DEFAULT_TEMPLATES = {
    'hld':  HLD_DEFAULT_TEMPLATE,
    'brd':  BRD_DEFAULT_TEMPLATE,
    'ssia': SSIA_DEFAULT_TEMPLATE,
}


def _seed_hld_nodes(db_session, nodes, parent_id, doc_type='hld'):
    for pos, node in enumerate(nodes):
        cols = node.get("cols")
        block = node.get("block")
        section = HLDTemplateSection(
            doc_type=doc_type, parent_id=parent_id, position=pos,
            title=node["title"], description=node.get("guide"),
            has_table=bool(cols),
            block_config=json.dumps(block) if block else None,
        )
        db_session.add(section)
        db_session.flush()
        for ci, col_name in enumerate(cols or []):
            db_session.add(HLDTemplateColumn(
                section_id=section.id, name=col_name, sort_order=ci))
        if node.get("children"):
            _seed_hld_nodes(db_session, node["children"], section.id, doc_type)


def ensure_hld_template_seeded(db_session) -> None:
    """Populate the master HLD template with the default NPg hierarchy, once."""
    if db_session.query(HLDTemplateSection).filter_by(doc_type='hld').count():
        return
    _seed_hld_nodes(db_session, HLD_DEFAULT_TEMPLATE, None, 'hld')
    db_session.commit()


def ensure_brd_template_seeded(db_session) -> None:
    """Populate the master BRD template with the default hierarchy, once."""
    if not db_session.query(HLDTemplateSection).filter_by(doc_type='brd').count():
        _seed_hld_nodes(db_session, BRD_DEFAULT_TEMPLATE, None, 'brd')
        db_session.commit()
        return
    # One-time upgrade: the first BRD seed modelled the detailed-spec sections
    # as wide tables; they are now structured entry blocks (BR-n / FR-n / UC-n).
    # An old-shape marker (the detailed-BR section still being a table) triggers
    # a reseed - safe because the BRD is guest-only, so no user content is
    # stored server-side against these sections.
    old_shape = (db_session.query(HLDTemplateSection)
                 .filter_by(doc_type='brd',
                            title='Detailed Business Requirement Specifications',
                            has_table=True)
                 .first())
    if old_shape is not None:
        reseed_hld_template(db_session, 'brd')


def ensure_ssia_template_seeded(db_session) -> None:
    """Populate the master SSIA template with the default hierarchy, once."""
    if not db_session.query(HLDTemplateSection).filter_by(doc_type='ssia').count():
        _seed_hld_nodes(db_session, SSIA_DEFAULT_TEMPLATE, None, 'ssia')
        db_session.commit()
        return
    # One-time upgrade, mirroring the BRD's: the first SSIA seed used invented
    # section names and rendered the questionnaire as ordinary narrative
    # sub-sections. The template now follows the pro-forma, so an old-shape
    # marker (a section the pro-forma does not have) triggers a reseed - safe
    # because the SSIA is guest-only, so no user content is stored server-side
    # against these sections.
    old_shape = (db_session.query(HLDTemplateSection)
                 .filter_by(doc_type='ssia',
                            title='Introduction & Assessment Context')
                 .first())
    if old_shape is not None:
        reseed_hld_template(db_session, 'ssia')


def reseed_hld_template(db_session, doc_type='hld') -> None:
    """
    Wipe and rebuild one document type's master template from its default
    hierarchy (dev/admin). Deletes in FK-safe order: project content first,
    then columns, then the section tree leaf-first (so the self-referential
    parent_id FK is respected).
    """
    sections = db_session.query(HLDTemplateSection).filter_by(doc_type=doc_type).all()
    section_ids = [s.id for s in sections]
    if section_ids:
        doomed_ps = db_session.query(ProjectHLDSection.id).filter(
            ProjectHLDSection.template_section_id.in_(section_ids)
        ).scalar_subquery()
        db_session.query(ProjectHLDRow).filter(
            ProjectHLDRow.section_id.in_(doomed_ps)
        ).delete(synchronize_session=False)
        db_session.query(ProjectHLDSection).filter(
            ProjectHLDSection.template_section_id.in_(section_ids)
        ).delete(synchronize_session=False)
        db_session.flush()
        # Delete deepest sections first (the ORM cascade removes each
        # section's columns with it).
        for node in reversed(flatten_hld_tree(sections)):
            db_session.delete(node['section'])
        db_session.flush()
    default = DEFAULT_TEMPLATES.get(doc_type, HLD_DEFAULT_TEMPLATE)
    _seed_hld_nodes(db_session, default, None, doc_type)
    db_session.commit()


def resequence_hld_template(db_session, doc_type='hld') -> None:
    """
    Renumber each sibling group of one document type to a contiguous 0..N-1
    order after add/remove. Scoped by doc_type because top-level sections of
    different document kinds share parent_id = None.
    """
    sections = (db_session.query(HLDTemplateSection)
                .filter_by(doc_type=doc_type)
                .order_by(HLDTemplateSection.position, HLDTemplateSection.id)
                .all())
    by_parent = {}
    for s in sections:
        by_parent.setdefault(s.parent_id, []).append(s)
    for siblings in by_parent.values():
        for idx, section in enumerate(siblings):
            if section.position != idx:
                section.position = idx


# ---------------------------------------------------------------------------
# Reference content pre-filled into a new HLD.
#
# The "Target Service Level" section is a table (Service Level | Characteristics)
# seeded with the three standard NPg service tiers from the design. The same
# tiers also form the section's instruction note. (Tier data + the note builder
# are defined above, next to HLD_DEFAULT_TEMPLATE.)
# ---------------------------------------------------------------------------

def _service_level_section(db_session):
    """The master 'Target Service Level' table section, or None."""
    return (db_session.query(HLDTemplateSection)
            .filter_by(doc_type='hld', title=HLD_SERVICE_LEVEL_TITLE, has_table=True)
            .first())


def ensure_service_level_is_table(db_session) -> None:
    """
    Idempotently make the existing 'Target Service Level' section a table with
    the Service Level / Characteristics columns. Lets an already-seeded template
    pick up the change without a full reseed (which would discard admin edits).
    """
    sec = (db_session.query(HLDTemplateSection)
           .filter_by(doc_type='hld', title=HLD_SERVICE_LEVEL_TITLE).first())
    if not sec:
        return
    changed = False
    if not sec.has_table:
        sec.has_table = True
        changed = True
    existing = {c.name for c in sec.columns}
    for ci, name in enumerate(["Service Level", "Characteristics"]):
        if name not in existing:
            db_session.add(HLDTemplateColumn(section_id=sec.id, name=name, sort_order=ci))
            changed = True
    # Refresh the instruction note so the service tiers are visible in the editor.
    note = _service_level_guidance()
    if sec.description != note:
        sec.description = note
        changed = True
    if changed:
        db_session.commit()


def seed_hld_default_content(db_session, hld) -> None:
    """Pre-fill reference content (the service-level tiers) for a brand-new HLD."""
    import json
    sec = _service_level_section(db_session)
    if not sec:
        return
    cols = sec.ordered_columns()
    if len(cols) < 2:
        return
    level_col, char_col = cols[0].id, cols[1].id
    ps = ProjectHLDSection(hld_id=hld.id, template_section_id=sec.id, is_required=True)
    db_session.add(ps)
    db_session.flush()
    for i, (level, chars) in enumerate(HLD_SERVICE_LEVEL_ROWS):
        db_session.add(ProjectHLDRow(
            section_id=ps.id,
            cells=json.dumps({str(level_col): level, str(char_col): chars}),
            sort_order=i,
        ))


# ===========================================================================
# Effort Estimate  -  admin-controlled "core" resource defaults
# ===========================================================================
#
# Only the predefined resource list and its per-person-day rates live in the
# database (the master "core" dataset, editable by admins). A user's estimate -
# the weeks, the per-week effort cells, any rate overrides and the task plan -
# is a working copy that lives only in the browser tab and is never persisted,
# so nothing a user does can mutate these core defaults.

EFFORT_LOCATIONS = ('Onshore', 'Offshore')

# Predefined IT roles, ordered along a typical delivery lifecycle (initiation ->
# requirements -> design -> build -> infrastructure -> security -> test). The order
# here drives the default `lifecycle_order` assigned at seeding time. Rates are
# indicative per-person-day defaults; admins are expected to tune them.
#   (role, onshore_rate, offshore_rate)
EFFORT_PREDEFINED_RESOURCES = (
    ('Project Manager',         800, 350),
    ('Business Analyst (BA)',   700, 300),
    ('Solution Architect',      950, 450),
    ('Application SME',         750, 320),
    ('Developer',               650, 250),
    ('DevOps Engineer',         700, 300),
    ('Unix/Infra SME',          700, 300),
    ('Windows Infra SME',       700, 300),
    ('Network SME',             720, 310),
    ('Infra DBA',               720, 320),
    ('Security SME',            800, 360),
    ('Test Manager',            700, 300),
    ('Tester',                  550, 220),
)


class EffortResourceDefault(Base):
    """
    One predefined resource (role x location) with its admin-set default rate.

    These rows are the master "core" dataset for the Effort Estimate module:
    admins manage the list and the per-person-day rates here, and they become
    the starting point whenever a user adds a resource to their (non-persisted)
    estimate. User edits never touch this table.
    """
    __tablename__ = 'effort_resource_defaults'

    id              = Column(Integer, primary_key=True)
    location        = Column(String(20), nullable=False)    # Onshore / Offshore
    role            = Column(String(120), nullable=False)
    default_rate    = Column(Integer, nullable=False, default=0)  # per person-day
    lifecycle_order = Column(Integer, nullable=False, default=0)  # delivery-phase order
    created_at      = Column(DateTime, default=func.now())
    updated_at      = Column(DateTime, default=func.now(), onupdate=func.now())

    def to_dict(self) -> dict:
        return {
            'id': self.id,
            'location': self.location,
            'role': self.role,
            'rate': self.default_rate,
            'order': self.lifecycle_order,
        }


def ensure_effort_defaults_seeded(db_session) -> None:
    """Seed the predefined resource defaults once (idempotent)."""
    if db_session.query(EffortResourceDefault).first():
        return
    for order, (role, onshore, offshore) in enumerate(EFFORT_PREDEFINED_RESOURCES):
        db_session.add(EffortResourceDefault(
            location='Onshore', role=role, default_rate=onshore, lifecycle_order=order))
        db_session.add(EffortResourceDefault(
            location='Offshore', role=role, default_rate=offshore, lifecycle_order=order))
    db_session.commit()


def load_effort_defaults(db_session) -> list:
    """Return all core resource defaults ordered by lifecycle then location."""
    ensure_effort_defaults_seeded(db_session)
    rows = (db_session.query(EffortResourceDefault)
            .order_by(EffortResourceDefault.lifecycle_order,
                      EffortResourceDefault.location,
                      EffortResourceDefault.id)
            .all())
    return [r.to_dict() for r in rows]