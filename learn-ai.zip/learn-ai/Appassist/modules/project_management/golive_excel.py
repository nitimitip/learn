"""
Go-Live plan -> professional multi-sheet Excel workbook.

Sheet 1 ("Project Overview") carries the project description and plan metadata;
each enabled section is then written to its own worksheet (Pre-requisite,
Production Go-Live, Post Go-Live Checks, Failover / DR, External Connectivity,
Contact Point). Styling uses the NPG (Northern Powergrid) red brand palette so
the file reads as a deliverable from the same system rather than a raw dump.
"""

from __future__ import annotations

import io
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .models import (
    GOLIVE_TASK_SECTIONS,
    GOLIVE_SECTION_LABELS,
)

# Brand palette - NPG (Northern Powergrid) red
NAVY        = "AB1236"   # NPG red - title bands
NAVY_MID    = "7E0D27"   # darker NPG red - subtitles & field labels
ACCENT      = "AB1236"
HEAD_BG     = "AB1236"
SUBHEAD_BG  = "7E0D27"   # darker NPG red - column-header rows
BAND        = "F1F5F9"
BORDER_CLR  = "D7DEE7"
TEXT        = "1D293D"
MUTED       = "6B7280"

# Status -> fill colour for the Status cell.
STATUS_FILL = {
    "Not Started":  ("E2E8F0", "1D293D"),
    "In Progress":  ("DBEAFE", "1E40AF"),
    "Completed":    ("DCFCE7", "166534"),
    "Not Required": ("F1F5F9", "6B7280"),
    "Failed":       ("FEE2E2", "991B1B"),
}

THIN = Side(style="thin", color=BORDER_CLR)
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT   = Alignment(horizontal="left", vertical="center", wrap_text=True)
LEFT_TOP = Alignment(horizontal="left", vertical="top", wrap_text=True)


def _fmt_dt(value) -> str:
    if not value:
        return ""
    if isinstance(value, datetime):
        return value.strftime("%d %b %Y %H:%M")
    return str(value)


def _title_band(ws, title, subtitle, ncols):
    """Dark title band across the first `ncols` columns. Returns next free row."""
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    c = ws.cell(row=1, column=1, value=title)
    c.font = Font(name="Calibri", size=15, bold=True, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=NAVY)
    c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[1].height = 30

    if subtitle:
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
        s = ws.cell(row=2, column=1, value=subtitle)
        s.font = Font(name="Calibri", size=10, italic=True, color="FFFFFF")
        s.fill = PatternFill("solid", fgColor=NAVY_MID)
        s.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        ws.row_dimensions[2].height = 20
        return 4
    return 3


def _write_header_row(ws, row, headers):
    for col, label in enumerate(headers, start=1):
        cell = ws.cell(row=row, column=col, value=label)
        cell.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=SUBHEAD_BG)
        cell.alignment = CENTER
        cell.border = BORDER
    ws.row_dimensions[row].height = 26


def _style_body_cell(cell, banded):
    cell.font = Font(name="Calibri", size=10, color=TEXT)
    cell.alignment = LEFT_TOP
    cell.border = BORDER
    if banded:
        cell.fill = PatternFill("solid", fgColor=BAND)


def _autosize(ws, widths):
    for idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width


def _empty_note(ws, row, ncols, text="No entries recorded for this section."):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=text)
    c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
    c.alignment = CENTER
    ws.row_dimensions[row].height = 24


# Overview sheet
def _build_overview(ws, project, plan, enabled_labels):
    _autosize(ws, [26, 90])
    row = _title_band(ws, f"Go-Live Plan - {project.name}", "Project Overview", 2)

    def field(label, value):
        nonlocal row
        lc = ws.cell(row=row, column=1, value=label)
        lc.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        lc.fill = PatternFill("solid", fgColor=NAVY_MID)
        lc.alignment = LEFT_TOP
        lc.border = BORDER
        vc = ws.cell(row=row, column=2, value=value if value not in (None, "") else "-")
        vc.font = Font(name="Calibri", size=10, color=TEXT)
        vc.alignment = LEFT_TOP
        vc.border = BORDER
        ws.row_dimensions[row].height = 22
        row += 1

    field("Project Name", project.name)
    field("Status", project.status.value if project.status else "")
    field("Goal / Objective", project.goal_objective or "")
    field("Description", project.description or "")
    field("Start Date", project.start_date.strftime("%d %b %Y") if project.start_date else "")
    field("Target End Date", project.target_end_date.strftime("%d %b %Y") if project.target_end_date else "")
    field("Plan Sections Included", ", ".join(enabled_labels) or "None enabled")
    field("Generated", datetime.now().strftime("%d %b %Y %H:%M"))


# Task-style section sheet
def _build_task_sheet(ws, label, tasks):
    headers = ["#", "Task", "Task Description", "Server / Host", "Department",
               "Team", "Start Date/Time", "End Date/Time", "Status"]
    _autosize(ws, [5, 28, 40, 22, 20, 18, 20, 20, 15])
    row = _title_band(ws, label, "Production Go-Live Plan", len(headers))
    _write_header_row(ws, row, headers)
    row += 1

    if not tasks:
        _empty_note(ws, row, len(headers))
        return

    for i, t in enumerate(tasks, start=1):
        banded = (i % 2 == 0)
        values = [
            i, t.task or "", t.description or "", t.server_host or "",
            t.department or "", t.team or "",
            _fmt_dt(t.start_datetime), _fmt_dt(t.end_datetime), t.status or "",
        ]
        for col, val in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=val)
            _style_body_cell(cell, banded)
            if col == 1:
                cell.alignment = CENTER
        # Status colour chip
        status_cell = ws.cell(row=row, column=len(headers))
        fill, font_clr = STATUS_FILL.get(t.status or "", (None, TEXT))
        if fill:
            status_cell.fill = PatternFill("solid", fgColor=fill)
            status_cell.font = Font(name="Calibri", size=10, bold=True, color=font_clr)
            status_cell.alignment = CENTER
        row += 1


def _build_connectivity_sheet(ws, items):
    headers = ["#", "Source Host", "Destination Host", "Port",
               "Connection Direction", "Description"]
    _autosize(ws, [5, 26, 26, 12, 22, 44])
    row = _title_band(ws, GOLIVE_SECTION_LABELS["external_connectivity"],
                      "Network connectivity required for go-live", len(headers))
    _write_header_row(ws, row, headers)
    row += 1

    if not items:
        _empty_note(ws, row, len(headers))
        return

    for i, c in enumerate(items, start=1):
        banded = (i % 2 == 0)
        values = [i, c.source_host or "", c.destination_host or "", c.port or "",
                  c.direction or "", c.description or ""]
        for col, val in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=val)
            _style_body_cell(cell, banded)
            if col == 1:
                cell.alignment = CENTER
        row += 1


def _build_contact_sheet(ws, contacts):
    headers = ["#", "Department", "Team", "Email", "Contact Number"]
    _autosize(ws, [5, 24, 24, 34, 22])
    row = _title_band(ws, GOLIVE_SECTION_LABELS["contact_point"],
                      "Escalation & contact points", len(headers))
    _write_header_row(ws, row, headers)
    row += 1

    if not contacts:
        _empty_note(ws, row, len(headers))
        return

    for i, ct in enumerate(contacts, start=1):
        banded = (i % 2 == 0)
        values = [i, ct.department or "", ct.team or "", ct.email or "", ct.contact_number or ""]
        for col, val in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=val)
            _style_body_cell(cell, banded)
            if col == 1:
                cell.alignment = CENTER
        row += 1


def _safe_sheet_title(title: str) -> str:
    """Excel sheet titles <=31 chars and free of : \\ / ? * [ ]."""
    for ch in ':\\/?*[]':
        title = title.replace(ch, ' ')
    return title.strip()[:31] or "Sheet"


def build_golive_workbook(project, plan) -> bytes:
    """Return the .xlsx bytes for a project's Go-Live plan."""
    wb = Workbook()

    # Which sections are enabled -> human labels for the overview sheet.
    enabled_labels = []
    for key in ['prerequisite', 'production', 'post_golive', 'failover_dr',
                'external_connectivity', 'contact_point']:
        if plan.is_section_enabled(key):
            enabled_labels.append(GOLIVE_SECTION_LABELS[key])

    overview = wb.active
    overview.title = "Project Overview"
    overview.sheet_view.showGridLines = False
    _build_overview(overview, project, plan, enabled_labels)

    # Task-style sections (in fixed order).
    for key, label in GOLIVE_TASK_SECTIONS:
        if not plan.is_section_enabled(key):
            continue
        ws = wb.create_sheet(_safe_sheet_title(label))
        ws.sheet_view.showGridLines = False
        # tasks_for_display (not tasks_for) so the sheet reads chronologically
        # by start date/time - the same order the project page shows - instead
        # of the order the rows happened to be typed in.
        _build_task_sheet(ws, label, plan.tasks_for_display(key))

    if plan.is_section_enabled('external_connectivity'):
        ws = wb.create_sheet(_safe_sheet_title("External Connectivity"))
        ws.sheet_view.showGridLines = False
        items = sorted(plan.connectivities, key=lambda x: (x.sort_order, x.id))
        _build_connectivity_sheet(ws, items)

    if plan.is_section_enabled('contact_point'):
        ws = wb.create_sheet(_safe_sheet_title("Contact Point"))
        ws.sheet_view.showGridLines = False
        contacts = sorted(plan.contacts, key=lambda x: (x.sort_order, x.id))
        _build_contact_sheet(ws, contacts)

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()
