"""
Effort Estimate -> professional Excel (.xlsx) workbook.

The user's estimate is a *working copy* held in the browser; on export the page
POSTs that copy as JSON and this module renders it with openpyxl onto a SINGLE
worksheet:

* the resource x week matrix (each resource's Total PDs = # Resources x
  sum weekly effort, and Cost = Total PDs x Rate, a totals row and a grand
  total), with rows colour-
  coded by location - Onshore (blue) vs Offshore (red); then
* the high-level Task / Sub-Task timeline directly below, colour-coded Task
  (green) vs Sub-task (amber). Its week columns line up under the matrix weeks.

The two sections deliberately use different colour families so a colour never
means two different things on the same sheet. Styling otherwise mirrors
golive_excel.py so the file reads as a deliverable from the same system.
"""

from __future__ import annotations

import io
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

# Brand palette - NPG (Northern Powergrid) red
NAVY        = "AB1236"   # title bands
NAVY_MID    = "7E0D27"   # subtitles & section bands
SUBHEAD_BG  = "7E0D27"   # column-header rows
TOTAL_BG    = "FCE7EC"   # soft red wash for the totals row
GRAND_BG    = "AB1236"   # grand-total band
BORDER_CLR  = "D7DEE7"
TEXT        = "1D293D"
MUTED       = "6B7280"

# Location colour coding (resource matrix) - blue vs red
ONSHORE_FILL   = "EAF1FB"   # soft blue row tint
ONSHORE_TAG    = "2F6DB5"   # blue chip
OFFSHORE_FILL  = "FCEDF1"   # soft red row tint
OFFSHORE_TAG   = "AB1236"   # red chip

# Task colour coding (task plan) - green vs amber (distinct families)
TASK_FILL      = "E3F2E8"   # light green - main-task label band
TASK_RUN       = "2E7D46"   # green - a main-task "running" week
SUBTASK_FILL   = "FBF0DD"   # light amber - sub-task label band
SUBTASK_RUN    = "C77700"   # amber - a sub-task "running" week

THIN = Side(style="thin", color=BORDER_CLR)
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT   = Alignment(horizontal="left", vertical="center", wrap_text=True)
RIGHT  = Alignment(horizontal="right", vertical="center")

MONEY_FMT = '#,##0'


def _num(value, default=0.0):
    try:
        if value in (None, ""):
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _title_band(ws, row, title, subtitle, ncols):
    """Two-row dark title band. Returns the next free row."""
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=title)
    c.font = Font(name="Calibri", size=15, bold=True, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=NAVY)
    c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row].height = 30

    ws.merge_cells(start_row=row + 1, start_column=1, end_row=row + 1, end_column=ncols)
    s = ws.cell(row=row + 1, column=1, value=subtitle)
    s.font = Font(name="Calibri", size=10, italic=True, color="FFFFFF")
    s.fill = PatternFill("solid", fgColor=NAVY_MID)
    s.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row + 1].height = 20
    return row + 2


def _section_band(ws, row, text, ncols):
    """Single-row section header band. Returns the next free row."""
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=text)
    c.font = Font(name="Calibri", size=12, bold=True, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=NAVY_MID)
    c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row].height = 24
    return row + 1


def _legend(ws, row, items):
    """Write a small swatch/label legend across the row. Returns next free row."""
    col = 1
    for fill, label in items:
        sw = ws.cell(row=row, column=col)
        sw.fill = PatternFill("solid", fgColor=fill)
        sw.border = BORDER
        lb = ws.cell(row=row, column=col + 1, value=label)
        lb.font = Font(name="Calibri", size=9, color=MUTED)
        lb.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        col += 2
    ws.row_dimensions[row].height = 15
    return row + 1


def _header_cell(ws, row, col, label):
    cell = ws.cell(row=row, column=col, value=label)
    cell.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
    cell.fill = PatternFill("solid", fgColor=SUBHEAD_BG)
    cell.alignment = CENTER
    cell.border = BORDER
    return cell


def _build_matrix(ws, start_row, weeks, resources, ncols):
    """Resource x week effort matrix with per-row totals, a totals row and a
    grand-total band. Rows are tinted by Onshore/Offshore. Returns next row."""
    nweeks = len(weeks)
    total_col = 5 + nweeks      # Total PDs
    cost_col = 6 + nweeks       # Cost

    row = _legend(ws, start_row, [(ONSHORE_TAG, "Onshore"), (OFFSHORE_TAG, "Offshore")])

    header_row = row
    headers = ["Location", "Role", "# Resources", "Rate / PD"] + list(weeks) + ["Total PDs", "Cost"]
    for col, label in enumerate(headers, start=1):
        _header_cell(ws, header_row, col, label)
    ws.row_dimensions[header_row].height = 26
    row += 1

    grand_pds = 0.0
    grand_cost = 0.0
    week_totals = [0.0] * nweeks

    if not resources:
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
        c = ws.cell(row=row, column=1, value="No resources added to this estimate.")
        c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
        c.alignment = CENTER
        ws.row_dimensions[row].height = 24
        row += 1
    else:
        for res in resources:
            location = res.get('location', '')
            is_off = (location == 'Offshore')
            row_fill = OFFSHORE_FILL if is_off else ONSHORE_FILL
            tag_fill = OFFSHORE_TAG if is_off else ONSHORE_TAG

            rate = _num(res.get('rate'))
            count = max(1, int(_num(res.get('count'), 1)))   # of people, default 1
            efforts = res.get('efforts') or []
            efforts = [_num(efforts[w]) if w < len(efforts) else 0.0 for w in range(nweeks)]
            total_pds = count * sum(efforts)
            cost = total_pds * rate
            grand_pds += total_pds
            grand_cost += cost
            for w in range(nweeks):
                week_totals[w] += efforts[w] * count

            values = [location, res.get('role', ''), count, rate] + efforts + [total_pds, cost]
            for col, val in enumerate(values, start=1):
                cell = ws.cell(row=row, column=col, value=val)
                cell.border = BORDER
                cell.fill = PatternFill("solid", fgColor=row_fill)
                cell.font = Font(name="Calibri", size=10, color=TEXT)
                cell.alignment = LEFT if col <= 2 else RIGHT
                if col == 4 or col == cost_col:
                    cell.number_format = MONEY_FMT
            # Location chip - strong fill, white bold
            loc_cell = ws.cell(row=row, column=1)
            loc_cell.fill = PatternFill("solid", fgColor=tag_fill)
            loc_cell.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
            loc_cell.alignment = Alignment(horizontal="center", vertical="center")
            # Emphasise Total PDs / Cost
            ws.cell(row=row, column=total_col).font = Font(name="Calibri", size=10, bold=True, color=TEXT)
            ws.cell(row=row, column=cost_col).font = Font(name="Calibri", size=10, bold=True, color=NAVY_MID)
            ws.row_dimensions[row].height = 20
            row += 1

        # Totals row - per-week subtotals + grand PDs
        total_values = ["", "Totals", "", ""] + week_totals + [grand_pds, ""]
        for col, val in enumerate(total_values, start=1):
            cell = ws.cell(row=row, column=col, value=val if val != "" else None)
            cell.border = BORDER
            cell.fill = PatternFill("solid", fgColor=TOTAL_BG)
            cell.font = Font(name="Calibri", size=10, bold=True, color=NAVY_MID)
            cell.alignment = LEFT if col == 2 else RIGHT
        ws.row_dimensions[row].height = 22
        row += 1

    # Grand-total band
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=total_col - 1)
    g = ws.cell(row=row, column=1, value="GRAND TOTAL")
    g.font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    g.fill = PatternFill("solid", fgColor=GRAND_BG)
    g.alignment = Alignment(horizontal="right", vertical="center", indent=1)
    pc = ws.cell(row=row, column=total_col, value=grand_pds)
    pc.font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    pc.fill = PatternFill("solid", fgColor=GRAND_BG)
    pc.alignment = CENTER
    pc.border = BORDER
    cc = ws.cell(row=row, column=cost_col, value=grand_cost)
    cc.font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    cc.fill = PatternFill("solid", fgColor=GRAND_BG)
    cc.alignment = RIGHT
    cc.number_format = MONEY_FMT
    cc.border = BORDER
    ws.row_dimensions[row].height = 26

    return header_row, row + 1


def _build_task_plan(ws, start_row, weeks, tasks, ncols):
    """High-level Task / Sub-Task timeline. The label spans the first four
    columns so the week cells line up beneath the matrix weeks. Rows are tinted
    Task (green) vs Sub-task (amber). Returns next row."""
    nweeks = len(weeks)

    row = _legend(ws, start_row, [(TASK_RUN, "Task"), (SUBTASK_RUN, "Sub-task")])

    # Header - "Task / Sub-Task" across cols 1-4, then the week columns.
    header_row = row
    ws.merge_cells(start_row=header_row, start_column=1, end_row=header_row, end_column=4)
    for col in range(1, 5):
        _header_cell(ws, header_row, col, "Task / Sub-Task" if col == 1 else None)
    for i, w in enumerate(weeks):
        _header_cell(ws, header_row, 5 + i, w)
    for col in range(5 + nweeks, ncols + 1):     # trailing columns kept in-band
        _header_cell(ws, header_row, col, None)
    ws.row_dimensions[header_row].height = 26
    row += 1

    if not tasks:
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
        c = ws.cell(row=row, column=1, value="No tasks planned.")
        c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
        c.alignment = CENTER
        ws.row_dimensions[row].height = 24
        return row + 1

    for task in tasks:
        is_sub = bool(task.get('is_subtask'))
        label_fill = SUBTASK_FILL if is_sub else TASK_FILL
        run_fill = SUBTASK_RUN if is_sub else TASK_RUN
        name = task.get('name', '')
        label = ("      * " + name) if is_sub else name

        # Label across cols 1-4
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
        for col in range(1, 5):
            cell = ws.cell(row=row, column=col)
            cell.border = BORDER
            cell.fill = PatternFill("solid", fgColor=label_fill)
        nc = ws.cell(row=row, column=1, value=label)
        nc.font = Font(name="Calibri", size=10, bold=not is_sub, color=TEXT)
        nc.alignment = LEFT

        run_weeks = task.get('weeks') or []
        for w in range(nweeks):
            cell = ws.cell(row=row, column=5 + w)
            cell.border = BORDER
            cell.alignment = CENTER
            running = w < len(run_weeks) and bool(run_weeks[w])
            cell.fill = PatternFill("solid", fgColor=run_fill if running else label_fill)
        # trailing cols (under Total/Cost) kept tinted for continuity
        for col in range(5 + nweeks, ncols + 1):
            cell = ws.cell(row=row, column=col)
            cell.border = BORDER
            cell.fill = PatternFill("solid", fgColor=label_fill)
        ws.row_dimensions[row].height = 20
        row += 1

    return row


def build_effort_workbook(payload: dict) -> io.BytesIO:
    """
    Build the single-sheet .xlsx from the posted working-copy payload:

        {
          "project_name": str,
          "weeks": ["Week 1", ...],
          "resources": [{"location","role","count","rate","efforts":[...]}],
          "tasks": [{"name","is_subtask","weeks":[bool,...]}]
        }

    Returns a BytesIO positioned at 0, ready to stream.
    """
    weeks = payload.get('weeks') or []
    resources = payload.get('resources') or []
    tasks = payload.get('tasks') or []
    nweeks = len(weeks)
    ncols = 6 + nweeks                       # Location, Role, # Resources, Rate, weeks..., Total, Cost
    project = (payload.get('project_name') or '').strip() or "Untitled estimate"

    wb = Workbook()
    ws = wb.active
    ws.title = "Effort Estimate"

    row = _title_band(ws, 1, "Effort Estimate - %s" % project,
                      "Resource effort matrix (person-days) & cost", ncols)
    header_row, row = _build_matrix(ws, row, weeks, resources, ncols)

    row += 5                                 # 5-row gap between the two sections
    row = _section_band(ws, row, "Task / Sub-Task Plan", ncols)
    _build_task_plan(ws, row, weeks, tasks, ncols)

    # Column widths shared by both sections (weeks align vertically).
    widths = [12, 26, 12, 11] + [9] * nweeks + [11, 14]
    for idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width

    # Keep the matrix header + the Location/Role/# Resources/Rate columns in view.
    ws.freeze_panes = ws.cell(row=header_row + 1, column=5)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def export_filename(project_name: str | None) -> str:
    base = (project_name or "Effort Estimate").strip() or "Effort Estimate"
    safe = "".join(ch if ch.isalnum() or ch in " -_" else "_" for ch in base).strip()
    stamp = datetime.now().strftime("%Y%m%d")
    return f"{safe} - Effort Estimate {stamp}.xlsx"
