"""
Project Planning -> professional Excel (.xlsx) workbook.

The plan is a *working copy* held only in the browser tab (nothing is ever
persisted server-side); on download the page POSTs that copy as JSON and this
module renders it with openpyxl onto a single worksheet:

* a meta header (project name + description), then
* a Gantt-style schedule grid whose first column carries the
  Milestone -> Task -> Sub-task hierarchy (indented + colour-coded by level) and
  whose remaining columns are the user-defined time periods (Day 1..., Week 1...,
  or running dd-mm-yyyy dates). A ticked period is rendered as a filled bar.

Styling mirrors effort_excel.py / golive_excel.py so the file reads as a
deliverable from the same system.
"""

from __future__ import annotations

import io
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

# Brand palette - NPG (Northern Powergrid) red
NAVY        = "AB1236"   # title band
NAVY_MID    = "7E0D27"   # subtitle / section band
SUBHEAD_BG  = "7E0D27"   # column-header row
BORDER_CLR  = "D7DEE7"
TEXT        = "1D293D"
MUTED       = "6B7280"

# Hierarchy colour coding - milestone / task / sub-task
MILESTONE_FILL = "D9E2F3"   # label band - blue
MILESTONE_RUN  = "2F5597"   # filled bar - blue
TASK_FILL      = "E3F2E8"   # label band - green
TASK_RUN       = "2E7D46"   # filled bar - green
SUBTASK_FILL   = "FBF0DD"   # label band - amber
SUBTASK_RUN    = "C77700"   # filled bar - amber

LEVEL_STYLE = {
    'milestone': (MILESTONE_FILL, MILESTONE_RUN, "Milestone"),
    'task':      (TASK_FILL,      TASK_RUN,      "Task"),
    'subtask':   (SUBTASK_FILL,   SUBTASK_RUN,   "Sub-task"),
}
LEVEL_INDENT = {'milestone': "", 'task': "    ", 'subtask': "        * "}

THIN = Side(style="thin", color=BORDER_CLR)
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT   = Alignment(horizontal="left", vertical="center", wrap_text=True)


def _title_band(ws, row, title, subtitle, ncols):
    """Two-row dark title band. Returns the next free row."""
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=title)
    c.font = Font(name="Calibri", size=15, bold=True, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=NAVY)
    c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row].height = 30

    ws.merge_cells(start_row=row + 1, start_column=1, end_row=row + 1, end_column=ncols)
    s = ws.cell(row=row + 1, column=1, value=subtitle)
    s.font = Font(name="Calibri", size=10, italic=True, color="FFFFFF")
    s.fill = PatternFill("solid", fgColor=NAVY_MID)
    s.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row + 1].height = 20
    return row + 2


def _meta_row(ws, row, label, value, ncols):
    """A 'Label: value' row - label in col 1, value merged across the rest."""
    lc = ws.cell(row=row, column=1, value=label)
    lc.font = Font(name="Calibri", size=10, bold=True, color=NAVY_MID)
    lc.alignment = Alignment(horizontal="left", vertical="top", indent=1)
    lc.border = BORDER

    ws.merge_cells(start_row=row, start_column=2, end_row=row, end_column=ncols)
    vc = ws.cell(row=row, column=2, value=value or "-")
    vc.font = Font(name="Calibri", size=10, color=TEXT)
    vc.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True, indent=1)
    for col in range(2, ncols + 1):
        ws.cell(row=row, column=col).border = BORDER
    return row + 1


def _section_band(ws, row, text, ncols):
    """Single-row section header band. Returns the next free row."""
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=text)
    c.font = Font(name="Calibri", size=12, bold=True, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=NAVY_MID)
    c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row].height = 24
    return row + 1


def _legend(ws, row, items):
    """Write a small swatch/label legend across the row. Returns next free row."""
    col = 1
    for fill, label in items:
        sw = ws.cell(row=row, column=col)
        sw.fill = PatternFill("solid", fgColor=fill)
        sw.border = BORDER
        lb = ws.cell(row=row, column=col + 1, value=label)
        lb.font = Font(name="Calibri", size=9, color=MUTED)
        lb.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        col += 2
    ws.row_dimensions[row].height = 15
    return row + 1


def _header_cell(ws, row, col, label):
    cell = ws.cell(row=row, column=col, value=label)
    cell.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
    cell.fill = PatternFill("solid", fgColor=SUBHEAD_BG)
    cell.alignment = CENTER
    cell.border = BORDER
    return cell


def _build_grid(ws, start_row, columns, rows, ncols):
    """Hierarchy x time-period schedule grid. The label spans the first two
    columns; period cells follow. Rows are tinted by level and a ticked period
    is a filled bar. Returns the next free row."""
    ncolumns = len(columns)

    row = _legend(ws, start_row, [(MILESTONE_RUN, "Milestone"),
                                  (TASK_RUN, "Task"),
                                  (SUBTASK_RUN, "Sub-task")])

    # Header - "Milestone / Task / Sub-Task" across cols 1-2, then periods.
    header_row = row
    ws.merge_cells(start_row=header_row, start_column=1, end_row=header_row, end_column=2)
    _header_cell(ws, header_row, 1, "Milestone / Task / Sub-Task")
    _header_cell(ws, header_row, 2, None)
    for i, label in enumerate(columns):
        _header_cell(ws, header_row, 3 + i, label)
    ws.row_dimensions[header_row].height = 28
    row += 1

    if not rows:
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
        c = ws.cell(row=row, column=1, value="No milestones planned.")
        c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
        c.alignment = CENTER
        ws.row_dimensions[row].height = 24
        return row + 1

    for item in rows:
        level = item.get('level', 'task')
        label_fill, run_fill, _ = LEVEL_STYLE.get(level, LEVEL_STYLE['task'])
        name = (item.get('name') or '').strip() or "(untitled)"
        label = LEVEL_INDENT.get(level, "") + name

        # Label across cols 1-2
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=2)
        for col in (1, 2):
            cell = ws.cell(row=row, column=col)
            cell.border = BORDER
            cell.fill = PatternFill("solid", fgColor=label_fill)
        nc = ws.cell(row=row, column=1, value=label)
        nc.font = Font(name="Calibri", size=10, bold=(level != 'subtask'), color=TEXT)
        nc.alignment = LEFT

        marks = item.get('marks') or []
        for i in range(ncolumns):
            cell = ws.cell(row=row, column=3 + i)
            cell.border = BORDER
            cell.alignment = CENTER
            on = i < len(marks) and bool(marks[i])
            cell.fill = PatternFill("solid", fgColor=run_fill if on else label_fill)
        ws.row_dimensions[row].height = 20
        row += 1

    return row


def build_plan_workbook(payload: dict) -> io.BytesIO:
    """
    Build the single-sheet .xlsx from the posted working-copy payload:

        {
          "project_name": str,
          "description": str,
          "timeframe": str,                 # "Day-based" / "Week-based" / "Date"
          "columns": ["Day 1", ...],
          "rows": [{"level","name","marks":[bool,...]}]
        }

    Returns a BytesIO positioned at 0, ready to stream.
    """
    columns = payload.get('columns') or []
    rows = payload.get('rows') or []
    ncolumns = len(columns)
    ncols = max(3, 2 + ncolumns)            # label (2 cols) + periods
    project = (payload.get('project_name') or '').strip() or "Untitled plan"
    description = (payload.get('description') or '').strip()
    timeframe = (payload.get('timeframe') or '').strip()

    wb = Workbook()
    ws = wb.active
    ws.title = "Project Plan"

    row = _title_band(ws, 1, "Project Plan - %s" % project,
                      "High-level milestone, task & sub-task schedule", ncols)

    row = _meta_row(ws, row, "Project", project, ncols)
    if description:
        row = _meta_row(ws, row, "Description", description, ncols)
    if timeframe:
        row = _meta_row(ws, row, "Time frame", timeframe, ncols)
    row = _meta_row(ws, row, "Generated", datetime.now().strftime("%d-%m-%Y %H:%M"), ncols)

    row += 2
    row = _section_band(ws, row, "Schedule", ncols)
    _build_grid(ws, row, columns, rows, ncols)

    # Column widths - wide label columns, even period columns.
    ws.column_dimensions[get_column_letter(1)].width = 30
    ws.column_dimensions[get_column_letter(2)].width = 6
    for i in range(ncolumns):
        ws.column_dimensions[get_column_letter(3 + i)].width = 11

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def plan_export_filename(project_name: str | None) -> str:
    base = (project_name or "Project Plan").strip() or "Project Plan"
    safe = "".join(ch if ch.isalnum() or ch in " -_" else "_" for ch in base).strip()
    stamp = datetime.now().strftime("%Y%m%d")
    return f"{safe} - Project Plan {stamp}.xlsx"
