"""Structured SDLC gate policy, independent of Flask and database sessions."""
import hashlib
import json
from datetime import date


def load_gate(phase):
    raw = getattr(phase, 'governance', None)
    return json.loads(raw) if raw else {}


def evidence_stamp(doc):
    # Uploads replace the stored filename; bind evidence to that upload, not its label.
    return hashlib.sha256(json.dumps([doc.id, doc.filename, str(doc.uploaded_at), doc.category, bool(doc.is_sensitive)], ensure_ascii=True).encode()).hexdigest()


def gate_fingerprint(phase, milestones, documents, gate):
    selected = {item.get('document_id') for item in gate.get('items', [])}
    snapshot = {
        'criteria': phase.exit_criteria,
        'categories': phase.doc_category_list(),
        'owner': gate.get('owner_id'), 'reviewer': gate.get('reviewer_id'),
        'due': gate.get('due'), 'items': gate.get('items', []),
        'milestones': sorted((m.id, str(m.start_date), str(m.end_date)) for m in milestones),
        'tasks': sorted((t.id, t.name, str(t.start_date), str(t.end_date), t.status.value)
                        for m in milestones for t in m.tasks),
        'evidence': sorted((d.id, evidence_stamp(d)) for d in documents if d.id in selected),
    }
    return hashlib.sha256(json.dumps(snapshot, sort_keys=True, ensure_ascii=True).encode()).hexdigest()


def gate_view(phase, milestones, documents, eligible_ids, reviewer_ids, today=None):
    gate = load_gate(phase)
    if not gate:
        return {'enabled': False, 'label': 'Standard gate', 'blockers': [], 'items': [],
                'next_action': 'Assign an owner and reviewer, then define the exit checklist.'}
    today = today or date.today()
    docs = {d.id: d for d in documents}
    blockers = []
    if gate.get('owner_id') not in eligible_ids:
        blockers.append('Assign a current project member as stage owner.')
    if gate.get('reviewer_id') not in reviewer_ids:
        blockers.append('Assign a project lead or project manager as reviewer.')
    if not gate.get('due'):
        blockers.append('Set a target review date.')
    items = []
    for item in gate.get('items', []):
        doc = docs.get(item.get('document_id'))
        valid = bool(doc and not doc.is_sensitive and item.get('stamp') == evidence_stamp(doc))
        items.append(dict(item, evidence_valid=valid))
        if not item.get('done') or not valid:
            blockers.append('Complete checklist and link current evidence: ' + item['label'])
    if not items:
        blockers.append('Add at least one exit criterion.')
    fingerprint = gate_fingerprint(phase, milestones, documents, gate)
    stale = gate.get('status') in ('review', 'approved') and gate.get('fingerprint') != fingerprint
    status = 'changes' if stale else gate.get('status', 'draft')
    if stale:
        blockers.insert(0, 'Schedule or evidence changed. Update the checklist and submit for review again.')
    labels = {'draft': 'In progress', 'review': 'Awaiting review', 'approved': 'Approved', 'changes': 'Changes requested'}
    return dict(gate, enabled=True, items=items, blockers=blockers, stale=stale,
                status=status, label=labels.get(status, 'In progress'), fingerprint_now=fingerprint,
                overdue=bool(gate.get('due') and gate['due'] < today.isoformat() and status != 'approved'),
                next_action=(blockers[0] if blockers else 'Reviewer to approve or request changes.' if status == 'review'
                             else 'Gate approved.' if status == 'approved' else 'Submit the completed stage for review.'))
