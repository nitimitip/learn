"""
Critical Path Method (CPM) engine
=================================

Pure-Python scheduling maths for the project-management module: forward /
backward pass over the task dependency network, total & free float, critical
path extraction, dependency-vs-entered-date conflict detection, and a layered
layout for the Activity-on-Node network diagram.

Deliberately free of Flask / SQLAlchemy imports so it can be unit-tested in
isolation - callers adapt ORM rows into the plain dicts described below.

Scheduling model
----------------
Tasks in this app carry *manually entered* start/end dates rather than pure
durations, so the engine runs a hybrid schedule (the approach Smartsheet and
MS Project's "Start No Earlier Than" constraint use):

* Each task's entered start date becomes an SNET constraint - the computed
  Early Start can never be before it.
* Dependencies then push tasks later as required. All four standard link
  types are supported (FS / SS / FF / SF), each with an integer lag in days.
* The computed schedule therefore always satisfies every dependency; where
  the *entered* dates violate a dependency, that surfaces as a warning
  instead (see `date_conflicts` in the result), never as negative float.

Time is measured in integer day offsets from the earliest entered start date
(the anchor). A task spans the half-open interval [ES, EF) with
EF = ES + duration, where duration counts inclusive calendar days
((end - start) + 1). So an FS successor with zero lag starts the day *after*
its predecessor's end date - matching how the entered dates are used
elsewhere in the module (both endpoints inclusive).
"""

from datetime import date, timedelta


# The four standard dependency types. FS is the default everywhere.
DEPENDENCY_TYPE_LABELS = {
    'FS': 'Finish -> Start',
    'SS': 'Start -> Start',
    'FF': 'Finish -> Finish',
    'SF': 'Start -> Finish',
}
DEPENDENCY_TYPES = tuple(DEPENDENCY_TYPE_LABELS)

# Sanity bound for user-supplied lags (days, either direction).
MAX_LAG_DAYS = 365


# ---------------------------------------------------------------------------
# Graph helpers
# ---------------------------------------------------------------------------

def find_cycle(edges):
    """
    Detect a cycle in a directed graph given as (predecessor, successor)
    pairs. Returns the node ids forming one cycle (in walk order, first node
    repeated implicitly), or None when the graph is a DAG.

    Iterative DFS with the classic white/grey/black colouring, so a long
    dependency chain can't blow the recursion limit.
    """
    adjacency = {}
    for pred, succ in edges:
        adjacency.setdefault(pred, []).append(succ)
        adjacency.setdefault(succ, [])

    WHITE, GREY, BLACK = 0, 1, 2
    colour = {n: WHITE for n in adjacency}

    for root in adjacency:
        if colour[root] != WHITE:
            continue
        # Stack of (node, iterator over its successors); path mirrors the stack.
        stack = [(root, iter(adjacency[root]))]
        path = [root]
        colour[root] = GREY
        while stack:
            node, successors = stack[-1]
            advanced = False
            for nxt in successors:
                if colour[nxt] == GREY:
                    # Found a back edge - slice the current path into a cycle.
                    return path[path.index(nxt):]
                if colour[nxt] == WHITE:
                    colour[nxt] = GREY
                    stack.append((nxt, iter(adjacency[nxt])))
                    path.append(nxt)
                    advanced = True
                    break
            if not advanced:
                colour[node] = BLACK
                stack.pop()
                path.pop()
    return None


def _topological_order(task_ids, edges):
    """Kahn's algorithm. Returns the ids in dependency order, or None on a cycle."""
    indegree = {t: 0 for t in task_ids}
    outgoing = {t: [] for t in task_ids}
    for pred, succ in edges:
        if pred in indegree and succ in indegree:
            outgoing[pred].append(succ)
            indegree[succ] += 1

    queue = sorted(t for t, deg in indegree.items() if deg == 0)
    order = []
    while queue:
        node = queue.pop(0)
        order.append(node)
        for nxt in outgoing[node]:
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                queue.append(nxt)
    if len(order) != len(task_ids):
        return None
    return order


# ---------------------------------------------------------------------------
# Core CPM computation
# ---------------------------------------------------------------------------

def _forward_constraint(dep_type, pred_es, pred_ef, lag, succ_duration):
    """Minimum Early Start the dependency imposes on the successor."""
    if dep_type == 'FS':
        return pred_ef + lag
    if dep_type == 'SS':
        return pred_es + lag
    if dep_type == 'FF':
        return pred_ef + lag - succ_duration
    if dep_type == 'SF':
        return pred_es + lag - succ_duration
    raise ValueError(f'Unknown dependency type: {dep_type}')


def _backward_constraint(dep_type, succ_ls, succ_lf, lag, pred_duration):
    """Maximum Late Finish the dependency imposes on the predecessor."""
    if dep_type == 'FS':
        return succ_ls - lag
    if dep_type == 'SS':
        return succ_ls - lag + pred_duration
    if dep_type == 'FF':
        return succ_lf - lag
    if dep_type == 'SF':
        return succ_lf - lag + pred_duration
    raise ValueError(f'Unknown dependency type: {dep_type}')


def _constraint_slack(dep_type, pred_es, pred_ef, succ_es, succ_ef, lag):
    """
    Spare days in one dependency given both tasks' (start, finish) offsets.
    0 = the link is exactly tight; negative = the link is violated.
    """
    if dep_type == 'FS':
        return succ_es - (pred_ef + lag)
    if dep_type == 'SS':
        return succ_es - (pred_es + lag)
    if dep_type == 'FF':
        return succ_ef - (pred_ef + lag)
    if dep_type == 'SF':
        return succ_ef - (pred_es + lag)
    raise ValueError(f'Unknown dependency type: {dep_type}')


def compute_cpm(tasks, dependencies):
    """
    Run the full CPM pass.

    tasks        - list of dicts: {'id', 'name', 'start': date, 'end': date}
                   (extra keys are ignored). Entered dates are inclusive.
    dependencies - list of dicts:
                   {'predecessor_id', 'successor_id', 'type': 'FS'|'SS'|'FF'|'SF',
                    'lag': int days}
                   Links referencing unknown task ids are ignored.

    Returns a dict:
        {
          'ok': True,
          'anchor': date,                # offset 0 == this calendar date
          'project_duration': int,       # computed, in days
          'project_end_date': date,      # computed finish (inclusive)
          'tasks': {task_id: {
              'es', 'ef', 'ls', 'lf': int offsets,
              'total_float', 'free_float': int days,
              'is_critical': bool,
              'es_date', 'ef_date', 'ls_date', 'lf_date': date,
          }},
          'critical_path': [task_id, ...]   # critical tasks ordered by ES
          'critical_edges': [(pred_id, succ_id), ...]  # tight links on it
          'date_conflicts': [ {predecessor_id, successor_id, type, lag,
                               days_violated, message}, ... ]
        }
    or {'ok': False, 'error': 'cycle', 'cycle': [...]} when the dependency
    graph is not a DAG (save-time validation should prevent this).
    """
    task_list = [t for t in tasks if t.get('start') and t.get('end')]
    if not task_list:
        return {'ok': False, 'error': 'no_tasks'}

    ids = [t['id'] for t in task_list]
    id_set = set(ids)
    deps = [d for d in dependencies
            if d['predecessor_id'] in id_set and d['successor_id'] in id_set
            and d['predecessor_id'] != d['successor_id']]

    edges = [(d['predecessor_id'], d['successor_id']) for d in deps]
    cycle = find_cycle(edges)
    if cycle:
        return {'ok': False, 'error': 'cycle', 'cycle': cycle}

    order = _topological_order(ids, edges)
    if order is None:                      # defensive; find_cycle should catch it
        return {'ok': False, 'error': 'cycle', 'cycle': []}

    anchor = min(t['start'] for t in task_list)
    duration = {}
    snet = {}
    name_of = {}
    for t in task_list:
        d = (t['end'] - t['start']).days + 1
        duration[t['id']] = max(1, d)
        snet[t['id']] = (t['start'] - anchor).days
        name_of[t['id']] = t.get('name', f'Task {t["id"]}')

    deps_into = {}
    deps_out = {}
    for d in deps:
        deps_into.setdefault(d['successor_id'], []).append(d)
        deps_out.setdefault(d['predecessor_id'], []).append(d)

    # Forward pass - entered start acts as a Start-No-Earlier-Than constraint.
    es, ef = {}, {}
    for tid in order:
        start = snet[tid]
        for d in deps_into.get(tid, []):
            p = d['predecessor_id']
            start = max(start, _forward_constraint(
                d['type'], es[p], ef[p], d['lag'], duration[tid]))
        es[tid] = start
        ef[tid] = start + duration[tid]

    project_end = max(ef.values())

    # Backward pass.
    ls, lf = {}, {}
    for tid in reversed(order):
        finish = project_end
        for d in deps_out.get(tid, []):
            s = d['successor_id']
            finish = min(finish, _backward_constraint(
                d['type'], ls[s], lf[s], d['lag'], duration[tid]))
        lf[tid] = finish
        ls[tid] = finish - duration[tid]

    # Floats + criticality.
    result_tasks = {}
    for tid in ids:
        total_float = ls[tid] - es[tid]

        out = deps_out.get(tid, [])
        if out:
            free_float = min(
                _constraint_slack(d['type'], es[tid], ef[tid],
                                  es[d['successor_id']], ef[d['successor_id']],
                                  d['lag'])
                for d in out)
        else:
            free_float = project_end - ef[tid]

        result_tasks[tid] = {
            'es': es[tid], 'ef': ef[tid], 'ls': ls[tid], 'lf': lf[tid],
            'duration': duration[tid],
            'total_float': total_float,
            'free_float': free_float,
            'is_critical': total_float == 0,
            'es_date': anchor + timedelta(days=es[tid]),
            'ef_date': anchor + timedelta(days=ef[tid] - 1),
            'ls_date': anchor + timedelta(days=ls[tid]),
            'lf_date': anchor + timedelta(days=lf[tid] - 1),
        }

    critical_path = sorted(
        (tid for tid in ids if result_tasks[tid]['is_critical']),
        key=lambda tid: (es[tid], ef[tid], tid))

    critical_edges = [
        (d['predecessor_id'], d['successor_id']) for d in deps
        if result_tasks[d['predecessor_id']]['is_critical']
        and result_tasks[d['successor_id']]['is_critical']
        and _constraint_slack(d['type'],
                              es[d['predecessor_id']], ef[d['predecessor_id']],
                              es[d['successor_id']], ef[d['successor_id']],
                              d['lag']) == 0
    ]

    # Entered-date conflicts: evaluate each link against the dates the user
    # actually typed in (offsets snet / snet+duration), not the computed ones.
    date_conflicts = []
    for d in deps:
        p, s = d['predecessor_id'], d['successor_id']
        slack = _constraint_slack(
            d['type'], snet[p], snet[p] + duration[p],
            snet[s], snet[s] + duration[s], d['lag'])
        if slack < 0:
            lag_note = f' + {d["lag"]}d lag' if d['lag'] else ''
            date_conflicts.append({
                'predecessor_id': p,
                'successor_id': s,
                'type': d['type'],
                'lag': d['lag'],
                'days_violated': -slack,
                'message': (
                    f'"{name_of[s]}" is scheduled {-slack} day(s) too early for its '
                    f'{DEPENDENCY_TYPE_LABELS[d["type"]]}{lag_note} link from '
                    f'"{name_of[p]}".'
                ),
            })

    return {
        'ok': True,
        'anchor': anchor,
        'project_duration': project_end - min(es[tid] for tid in ids),
        'project_end_date': anchor + timedelta(days=project_end - 1),
        'tasks': result_tasks,
        'critical_path': critical_path,
        'critical_edges': critical_edges,
        'date_conflicts': date_conflicts,
    }


# ---------------------------------------------------------------------------
# Network-diagram layout (Activity-on-Node)
# ---------------------------------------------------------------------------

def layout_network(cpm_result, dependencies):
    """
    Layered left-to-right layout for the AON diagram. Only tasks that take
    part in at least one dependency are included - isolated tasks would just
    clutter the picture (the Gantt already shows them).

    Returns {'nodes': {task_id: {'layer': int, 'row': int}}, 'layer_count': int}.
    """
    if not cpm_result.get('ok'):
        return {'nodes': {}, 'layer_count': 0}

    tasks = cpm_result['tasks']
    involved = set()
    edges = []
    for d in dependencies:
        p, s = d['predecessor_id'], d['successor_id']
        if p in tasks and s in tasks and p != s:
            involved.add(p)
            involved.add(s)
            edges.append((p, s))

    if not involved:
        return {'nodes': {}, 'layer_count': 0}

    order = _topological_order(list(involved), edges)
    if order is None:
        return {'nodes': {}, 'layer_count': 0}

    preds = {}
    for p, s in edges:
        preds.setdefault(s, []).append(p)

    # Layer = longest dependency path from any source node.
    layer = {}
    for tid in order:
        layer[tid] = max((layer[p] + 1 for p in preds.get(tid, [])), default=0)

    # Row within a layer: order by computed Early Start, then id, for a
    # stable, roughly-chronological vertical arrangement.
    nodes = {}
    by_layer = {}
    for tid in involved:
        by_layer.setdefault(layer[tid], []).append(tid)
    for lyr, members in by_layer.items():
        members.sort(key=lambda tid: (tasks[tid]['es'], tid))
        for row, tid in enumerate(members):
            nodes[tid] = {'layer': lyr, 'row': row}

    return {'nodes': nodes, 'layer_count': max(by_layer) + 1}
