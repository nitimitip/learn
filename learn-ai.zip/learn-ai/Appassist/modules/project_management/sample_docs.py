"""
Reference sample documents for the HLD, BRD and SSIA builders.

The builder pages offer a "Sample" download so a first-time user can see a
fully worked, professional document before writing their own. The sample
subject is App Assist itself - the platform the builder lives in - so the
content is real, verifiable and needs no invented business.

How it works
------------
The content below is keyed by SECTION TITLE (normalised), not by database id,
because the master template is admin-editable and its ids differ per install.
`build_sample_payload()` walks the live template tree and maps each section to
its sample entry, producing exactly the payload shape the stateless guest
export already consumes:

    {"<template_section_id>": {"is_required": bool,
                              "short_description": str,
                              "content": str,
                              "rows": [{"<column_id>": value, ...}, ...],
                              "blocks": [{"fields": {...}, "tables": {...}}]}}

Table rows are written POSITIONALLY here (a tuple per row, one value per
template column) and bound to the live column ids at build time; a row longer
than the current column list is clipped and a shorter one is padded, so an
admin editing the template can never break the sample.

Sections with no sample entry render as an empty (but still numbered) section,
so the sample degrades gracefully if the template grows.

Content conventions: a line starting with "- " becomes a bullet in the .docx;
"\n" inside a table cell becomes a line break within that cell.
"""

import re


SAMPLE_PROJECT_NAME = 'App Assist'


def _key(title):
    """Normalise a section title into a lookup key."""
    return re.sub(r'\s+', ' ', (title or '').strip().rstrip(':')).lower()


# ===========================================================================
# HLD - App Assist High-Level Design
# ===========================================================================

SAMPLE_HLD = {

    _key('Executive Summary'): {'content': """
App Assist is an on-premise, browser-based platform that consolidates the tools an IT operations and delivery team uses every day into a single, role-secured web application. It replaces a scatter of spreadsheets, desktop scripts and mailboxes with one governed workspace.
- One application, fourteen modules. Project Management, Application Support, Application Health Check, File Monitor, MIMP Report, ServiceNow Analysis, Code Sentinel, Security (Certificates), Utility Tools, My To-Do, Activity Tracker, Resource Utilization, Resource Tracker and User Profile - all served under a common launcher, sign-in and design system.
- Delivery. Projects are planned under soft SDLC governance (Waterfall or Agile chosen by questionnaire), with milestones, critical-path scheduling, a Kanban board, baselines, a risk matrix, document control and professional Word and Excel exports.
- Monitoring. Scheduled URL, server and database health checks, expected-file-arrival checks, certificate-expiry tracking and live major-incident status, each with e-mail alerting.
- Assurance and analytics. An offline static-analysis platform (Code Sentinel) scans delivered code against 160+ rules across 24 languages, and offline machine learning summarises exported service-desk tickets. Neither sends data off the estate.
- Workforce. A single Workforce hub gives every user a weekly timesheet and gives managers utilisation dashboards and time-and-materials allocation tracking derived from real project tasks.
- Deployment. A single Flask WSGI application hosted on Windows IIS through wfastcgi, backed by SQLAlchemy (SQLite for a standalone install, SQL Server or PostgreSQL for production), with every scheduled job owned by one dedicated Windows service so nothing double-fires.
The solution targets a small operations team on the corporate LAN: TLS only, session-based authentication with role-based access control, encrypted storage of all integration credentials, and no dependency on any external cloud service.
"""},

    _key('Context'): {'content': """
The operations team relied on disconnected artefacts: project trackers in spreadsheets, monitoring scripts on individual desktops, incident status circulated by e-mail, timesheets kept privately, and application knowledge held in people's heads. The result was duplicated effort, inconsistent formats, single points of knowledge and no shared audit trail.
App Assist was built to bring those workflows under one roof with a consistent, professional interface and a common security model. The design principles applied were:
- On-premise and self-contained. No SaaS dependency. Every capability, including machine learning and static analysis, runs on the corporate network; sensitive data never leaves the estate.
- One codebase, modular by blueprint. Each capability is a Flask blueprint under modules/, sharing the same authentication, database, CSRF, theming and launcher, so adding a capability is additive and low-risk.
- Automation without duplication. All scheduled work runs in exactly one place - a Windows service - never inside the multi-worker web tier.
- Preserve history. People and projects change; the records they touched must remain intact and attributable. Off-boarding disables an account rather than deleting it.
- Progressive disclosure. Anonymous visitors get safe, no-storage tools; authenticated users get exactly what their role allows.
"""},

    _key('Introduction'): {'content': """
This section sets the boundaries of the solution at a conceptual level: what the document is for, who it is written for, and the material it draws upon. Where a sub-section does not apply it is retained and marked accordingly, so the content template does not erode over time.
"""},

    _key('Purpose'): {'content': """
This document describes the technical architecture of App Assist: its components, how they are deployed and integrated, and the security and operational model that governs them. It establishes a common understanding of the solution between architecture, engineering, security and the support team, and states what the solution must achieve to be accepted.
Intended audience: Solution and Infrastructure Architects, the Platform Engineering team, IT Security, and the Application Support team that operates the platform day to day.
"""},

    _key('References'): {
        'intro': 'The following documents were used in preparing this design and should be read alongside it.',
        'rows': [
            ('R1', 'App Assist - User Guide',
             'docs/USER_GUIDE_AppAssist.md, Platform Engineering, v1.0'),
            ('R2', 'App Assist - Operations Manual',
             'docs/OPS_MANUAL_AppAssist.md, Platform Engineering, v1.0'),
            ('R3', 'App Assist - Business Requirements Document',
             'Business Analysis, v1.0 (companion to this design)'),
            ('R4', 'IIS hosting configuration',
             'web.config, project root - FastCGI handler, TLS rewrite, security headers'),
            ('R5', 'Python dependency manifest',
             'requirements.txt, project root - pinned runtime dependencies'),
            ('R6', 'Scheduler Windows service',
             'health_monitor_app_sched.py, project root - sole owner of scheduled jobs'),
            ('R7', 'Relational migration utility',
             'migrate_sqlite_to_mssql.py, project root - SQLite to SQL Server cut-over'),
            ('R8', 'Code Sentinel rule and roadmap documentation',
             'docs/code_sentinel_tier1_plan.md and docs/code_sentinel_architecture_roadmap.md'),
        ]},

    _key('Scope'): {'content': """
This section states what the design covers, what it deliberately excludes, and the outcomes the solution must deliver. Scope is drawn at the platform boundary: App Assist and the services it owns are in scope; the systems it observes are not.
"""},

    _key('In Scope'): {'content': """
- The App Assist Flask web application and all fourteen functional modules registered as blueprints.
- Shared platform services: authentication and session management, role-based access control, CSRF protection, secret encryption, upload handling, document version control, logging, error handling and the module launcher.
- The persistence layer (SQLAlchemy ORM; SQLite by default, SQL Server or PostgreSQL for production) together with its idempotent schema creation and additive column migration mechanism.
- The dedicated Windows scheduler service that owns every background job - health sweeps, major-incident monitoring, certificate expiry, to-do digests, open-incident summaries and file-monitor alerting - plus the retention purges that bound data growth.
- IIS and wfastcgi hosting, TLS termination, request filtering and security response headers.
- Outbound integrations consumed by the modules: Oracle, SQL Server, SSH, Windows Remote Management, HTTP(S) with optional NTLM, and SMTP.
- Document generation: Word (HLD, BRD, project documents), Excel (planning, effort, go-live, utilisation, ticket analysis) and PDF (Code Sentinel and support profiles).
New components are the App Assist application, its database schema, the Code Sentinel analysis engine and the scheduler service. Re-used components are the existing IIS hosts, the SMTP relay, Active Directory service accounts, and the Oracle and SQL Server instances that are monitored.
"""},

    _key('Out of Scope'): {'content': """
- The service-desk platform itself. App Assist consumes exported incident and request spreadsheets and analyses them offline; it does not integrate with a live service-desk API. In scope of the service management platform team.
- The target applications, servers and databases that are monitored. App Assist observes them; it does not manage their configuration or lifecycle.
- Corporate identity provider federation. App Assist uses local application accounts; single sign-on and multi-factor authentication are a dependency on the identity team, recorded in the RAID section, and were considered but deferred for this release.
- Network, firewall and TLS certificate provisioning for the IIS host. Delivered by Infrastructure; this design states the requirement only.
- Remediation of defects that Code Sentinel reports. The platform detects and tracks; fixing belongs to the owning delivery team.
"""},

    _key('Outcomes'): {'content': """
- A single, access-controlled workspace that replaces disparate spreadsheets, desktop scripts and mail threads.
- Automated scheduled monitoring with proactive e-mail alerting, so failures are noticed before users report them.
- Governed project delivery in which progress, status and documentation are maintained as a by-product of doing the work rather than as a separate reporting exercise.
- Objective assurance over delivered code through repeatable, offline static analysis with a pass/fail quality gate.
- Preserved, attributable history across staff changes and re-organisations.
- A deployment that runs entirely inside the corporate network with no external dependency and no data egress.
"""},

    _key('Non-Functional Requirements'): {
        'intro': 'The non-functional requirements below were identified as architecturally significant; each is mapped to the design element that satisfies it.',
        'rows': [
            ('NFR1', 'Availability appropriate to internal business-hours use',
             'IIS Application Initialization warm-up plus a /health endpoint; Service Control Manager auto-restart of the scheduler service; stateless web workers that can be recycled without session loss'),
            ('NFR2', 'Concurrency for a small team with occasional long-running operations',
             'IIS FastCGI pool sized at 8 instances; requestTimeout raised to 600s for analysis and report generation; bounded database connection pool; long scans run as background jobs, not inside the request'),
            ('NFR3', 'Confidentiality of credentials and operational data',
             'Fernet-encrypted secrets at rest (crypto_utils); TLS-only transport; hardened session cookies; role-based authorisation on every state-changing endpoint'),
            ('NFR4', 'Integrity and auditability of records',
             'Per-project activity log; CSRF tokens on all mutating requests; server-side validation; foreign-key-enforced referential integrity; document version trail retaining the last four versions'),
            ('NFR5', 'No loss of history when people leave',
             'Users are disabled, never deleted; hard delete is blocked by foreign keys while the user is referenced; name-map lookups deliberately ignore the active flag'),
            ('NFR6', 'Maintainability and low-risk change',
             'Modular blueprints; idempotent init_db(); additive-only column migrations; pytest suites covering platform and module logic'),
            ('NFR7', 'Bounded and scalable storage',
             'Pluggable DATABASE_URL (SQLite to SQL Server or PostgreSQL); retention purges on monitoring history and timesheet rows; rotating capped log files'),
            ('NFR8', 'Consistent, learnable user experience',
             'A single shared design system, responsive layout, one launcher, and in-app About and help pages per module'),
            ('NFR9', 'Portability of runtime',
             'Source targets a current Python release with a maintained 3.9 compatibility overlay guarded by an automated test, so the platform can run on the older interpreter present on some hosts'),
        ]},

    _key('Functional Requirements'): {
        'intro': 'The architecturally significant functional requirements and the module or service that delivers each.',
        'rows': [
            ('FR1', 'Plan and track delivery work end to end',
             'Project Management module: SDLC governance, milestones, tasks, critical-path method, Kanban, baselines, risk matrix and portfolio views'),
            ('FR2', 'Author governed design and requirements documents',
             'Project Management document builders: admin-curated HLD and BRD master templates rendered to Word, with per-project and stateless guest authoring'),
            ('FR3', 'Monitor application, server and database health on a schedule and alert on failure',
             'Application Health Check module plus the scheduler service'),
            ('FR4', 'Confirm that expected file transfers arrived and alert on misses',
             'File Monitor module plus the scheduler service'),
            ('FR5', 'Publish live application status during a major incident or severe weather',
             'MIMP Report module'),
            ('FR6', 'Analyse exported service-desk tickets offline and summarise for management',
             'ServiceNow Analysis module: incident and service-request sub-reports, consolidated e-mail and multi-sheet Excel'),
            ('FR7', 'Maintain an application system of record for support and on-call',
             'Application Support module: tower and application profiles, live estate architecture view, Excel and PDF exports, wildcard search'),
            ('FR8', 'Detect security and quality defects in delivered source code',
             'Code Sentinel module: background scans of zip, path or git sources, triage workflow, quality gate, SARIF and report exports, CI ingest API'),
            ('FR9', 'Track the certificate inventory and warn before expiry',
             'Security module plus the scheduler service'),
            ('FR10', 'Record time worked and report on workforce utilisation',
             'Activity Tracker, Resource Utilization and the Resource Tracker hub, with allocations derived from project tasks'),
            ('FR11', 'Provide self-service operational utilities',
             'Utility module: file search, compare, split and de-duplicate, data scrambling, server register and encoder tools'),
            ('FR12', 'Give each user a private task list with a daily digest',
             'My To-Do module plus the scheduler service'),
            ('FR13', 'Administer accounts, roles and profile data with self-service password reset',
             'Platform authentication services and the User Profile module'),
        ]},

    _key('Business or Client Problem'): {'content': """
Operations engineers, project managers and incident managers need shared, reliable tooling that reflects reality without manual re-keying. The business need is expressed through the following use cases and user stories.
- As an incident manager, I need one live view of which business-critical applications are healthy, degraded or down, so that I can brief stakeholders without telephoning individual engineers.
- As a project manager, I need progress, status and the critical path to update themselves from the work my team records, so that the reports I circulate are trustworthy.
- As a support engineer on call, I need every fact about an application - servers, support teams, scheduled jobs, interfaces and dependencies - in one profile, so that diagnosis is not guesswork at 03:00.
- As a delivery lead, I need an objective, repeatable assurance check on the code we are about to release, so that quality is a gate rather than an opinion.
- As a resource manager, I need utilisation and time-and-materials consumption derived from actual timesheets and actual task allocations, so that commercial reporting is defensible.
- As an engineer, I need to be told when a scheduled file did not arrive or a certificate is about to expire, rather than discovering it from a user.
"""},

    _key('Stakeholder Obligations'): {'content': """
- Infrastructure provides the Windows and IIS host, the TLS certificate, the service accounts, and network reachability to every monitored target and to the SMTP relay.
- IT Security approves the baseline control set and reviews the secret-management and access model before go-live.
- Application owners supply and maintain the inventory data - applications, servers, certificates, file flows and interfaces - and keep support-tower membership current.
- The database team provisions the production relational database and owns its backup, restore and tuning.
- Administrators off-board leavers by disabling rather than deleting accounts, and own the shared master templates for HLD, BRD, SDLC stages and effort defaults.
- Delivery teams triage the findings Code Sentinel raises against their projects and keep the quality gate green.
"""},

    _key('Target Service Level'): {
        'intro': 'The agreed service level for the solution and the characteristics that follow from it.',
        'rows': [
            ('Bronze (agreed for this solution)',
             '08:00 to 17:30 Mon - Fri, excluding Public Holidays\n'
             'Internal productivity and monitoring tool for a single team\n'
             'Best-effort recovery within business hours\n'
             'Scheduled sweeps on a 30-minute cadence\n'
             'Monitoring history retained short-term (default 5 days) then purged'),
            ('Data protection commitments',
             'Daily database backup, retained per the Operations Manual\n'
             'Integration credentials encrypted at rest\n'
             'No data egress outside the corporate network'),
            ('Escalation',
             'Platform Engineering during business hours\n'
             'No 24x7 on-call cover is designed at this tier'),
        ]},

    _key('Architectural Solution Design Overview'): {'content': """
App Assist is a modular monolith: a single Flask WSGI application composed of fourteen blueprints, hosted by IIS through wfastcgi, backed by a SQLAlchemy-managed relational database, with a separate Windows service running every scheduled job. This section describes the baseline it builds on, the target end state, the decisions taken and the patterns applied.
"""},

    _key('Baseline Technology Architecture'): {'content': """
The organisation operates a Windows Server estate with IIS, an SMTP relay, Active Directory, and Oracle and SQL Server database instances; Python is available on the application hosts. App Assist is deliberately designed to sit inside those standards rather than introduce new ones: it hosts under IIS through wfastcgi, uses the existing SMTP relay for all outbound mail, connects to the existing database instances with least-privilege service accounts, and authenticates against its own local accounts pending identity-provider integration.
The existing foundation the solution must align with therefore comprises: Windows Server and IIS hosting, an Active Directory domain, the corporate SMTP relay, Oracle and SQL Server database services, and corporate baseline security controls for TLS, hardening and secret handling.
"""},

    _key('Target Technology Architecture'): {'content': """
The target end state is one internal web portal serving all fourteen capabilities, one relational database, and one scheduler service.
Logical end state, browser to back end:
- Browser on the corporate LAN reaches IIS over HTTPS on 443 only; HTTP is rewritten to HTTPS, HSTS is asserted, security response headers are applied, and request filtering hides configuration, database and source files.
- IIS passes the request over a named pipe to the wfastcgi handler, which hosts the Flask callable main_app.app in a bounded worker pool. Each worker carries the shared platform services (authentication, role checks, CSRF, secret encryption, uploads, versioning, logging, error handling) and the fourteen blueprints.
- Workers reach the relational database exclusively through the SQLAlchemy ORM using per-request sessions from a bounded pool.
- A separate Windows service, running under the Service Control Manager, hosts APScheduler and owns every scheduled job and retention purge. It shares the same database and the same models but never serves HTTP.
- Outbound, both the workers and the service reach monitored targets over HTTP(S) with optional NTLM, SSH, Windows Remote Management, Oracle and SQL Server client protocols, and the SMTP relay.
No transition state is required: the solution is additive and the superseded spreadsheets and desktop scripts are simply withdrawn once their equivalent module is in use.
"""},

    _key('Host Components'): {'content': """
- A single Windows Server host running IIS is sufficient for the expected load; standard small (S) server sizing applies. No new hardware is mandated - the platform is deployed onto an existing host in the estate.
- The web tier is stateless: session state is carried in a signed cookie and all durable state is in the database, so the host can be rebuilt from a code checkout plus configuration and a data restore.
- The scheduler service runs as a Windows service on the same host under a dedicated account. It can be relocated to its own host later without code change, since it shares only the database.
- Capacity requirement is modest: two vCPU and 8 GB of memory comfortably covers the web worker pool, the scheduler and the peak demand of a static-analysis scan or a machine-learning summarisation run.
"""},

    _key('Application Components'): {'content': """
- Client tier: a modern corporate browser. The interface is server-rendered Jinja2 with a shared CSS design system and progressive enhancement; charts and Gantt views use Plotly. There is no single-page-application framework and no client-side build step.
- Web and application tier: Flask on Werkzeug, hosted by wfastcgi under IIS. Fourteen blueprints are registered under distinct URL prefixes: /project-management, /application-support, /mimp-report, /utility, /service-now-analysis, /file-monitor, /application-health-check, /security, /todo, /profile, /activity-tracker, /resource-utilization, /resource-tracker and /code-sentinel.
- Analysis tier (in-process): the Code Sentinel engine performs rule, abstract-syntax-tree and taint analysis, optionally using parse-tree grammars where the grammar packages are installed; the ticket-analysis module uses classical machine-learning and sentence-embedding libraries. Both are optional-dependency tolerant and degrade to reduced capability rather than failing.
- Data and ORM tier: SQLAlchemy 2.0 declarative models with per-request sessions.
- All third-party components are current, vendor-supported releases pinned in requirements.txt; optional analysis grammars are declared separately so a minimal install remains possible.
"""},

    _key('Database Components'): {'content': """
- The logical schema is defined by the ORM models in the application root and in each module. init_db() creates any missing tables and then applies additive column migrations that are dialect-aware for SQLite, PostgreSQL and SQL Server. The operation is idempotent and therefore safe to run in every worker at start-up.
- The default persistence for a standalone install is a single SQLite file with write-ahead logging, a 30-second busy timeout, foreign keys enforced and synchronous set to NORMAL.
- For multi-worker production, DATABASE_URL points at SQL Server through pyodbc with fast_executemany, or at PostgreSQL. The pool is bounded at size 10 with overflow 20, a 300-second recycle and pre-ping enabled.
- Expected data volumes are modest: project, inventory and configuration data measured in tens of megabytes; monitoring execution history and scan findings are the only fast-growing tables and both are capped by retention purges.
- A one-off migration utility copies every row from SQLite to SQL Server in foreign-key-safe order, preserving primary keys so that existing references remain valid.
- No Enterprise Service Bus function is required; the platform performs no message brokering.
"""},

    _key('Storage Components'): {
        'intro': 'Indicative storage growth used for environment sizing, placement and costing. Figures assume a single team and are to be revised against actual document and scan volumes after the first year.',
        'rows': [
            ('Relational database (projects, inventory, configuration, purged history)', '2', '5', '10'),
            ('Uploaded documents and attachments (secure_uploads/, uploads/)', '5', '15', '30'),
            ('Code Sentinel workspaces, scan artefacts and generated reports', '4', '10', '18'),
            ('Application, scheduler and wfastcgi logs (rotating, capped)', '1', '1', '1'),
            ('Database backups retained on host before archive', '6', '15', '25'),
        ]},

    _key('Middleware Components'): {'content': """
No application-server middleware is required: there is no Tomcat, WebLogic, JBoss, MuleSoft or ActiveMQ component in this solution. The only middleware in the strict sense is IIS with the wfastcgi bridge translating HTTP to the Python WSGI callable, and APScheduler acting as the in-process job scheduler inside the Windows service. Both are declared dependencies of the deployment rather than separately administered platforms.
"""},

    _key('Network Integration'): {
        'intro': 'All traffic is intra-LAN and TLS-terminated at IIS. The table records each data flow, its protocol and the controls applied. There is no change to WAN traffic patterns and no measurable bandwidth impact at the expected volumes.',
        'rows': [
            ('Browser (Corporate LAN)', 'App Assist / IIS (Application zone)',
             'User interactions, form posts, document and spreadsheet uploads',
             'HTTPS / 443',
             'TLS with HSTS; HttpOnly and SameSite session cookie; CSRF token on every state change; request filtering'),
            ('App Assist workers (Application zone)', 'Monitored web applications (LAN)',
             'URL availability and response-time probes',
             'HTTP(S) / 80, 443',
             'Optional NTLM service-account authentication; bounded timeouts; read-only requests'),
            ('Scheduler service (Application zone)', 'Monitored servers (LAN)',
             'Read-only server health commands (disk, service and process state)',
             'SSH / 22 and WinRM / 5985-5986',
             'Key or credential authentication with encrypted stored credentials; command timeout; least-privilege account'),
            ('Scheduler and workers (Application zone)', 'Oracle and SQL Server instances (Data zone)',
             'Health probe queries and the application database connection',
             'Oracle 1521 / TDS 1433',
             'Least-privilege service accounts; encrypted stored credentials; read-only probe queries; connections always closed'),
            ('Scheduler and workers (Application zone)', 'SMTP relay (Infrastructure zone)',
             'Alerts, digests, management summaries and password-reset mail',
             'SMTP / 25 or 587',
             'Relay allow-listing by source host; no external recipients'),
            ('File Monitor (Application zone)', 'File transfer endpoints (LAN)',
             'Directory listings confirming expected file arrival',
             'SMB / 445 and SFTP / 22',
             'Least-privilege share and SFTP accounts; read-only listing, never file content'),
            ('Administrator (Corporate LAN)', 'App Assist / IIS (Application zone)',
             'Service-desk export upload and source archive upload for analysis',
             'HTTPS / 443',
             'Per-module upload size limits; secure filename handling; server-side type validation; offline processing only'),
        ]},

    _key('Integration, Interface and Co-Existence'): {'content': """
- Service-desk platform (batch, file-based). Users upload exported incident and service-request spreadsheets; all analysis is performed offline in the application. There is no live API coupling, so App Assist co-exists with the service-desk platform without becoming dependent on its availability or release cycle.
- Monitoring targets (real-time probes, read-only). URL, server and database checks execute on a schedule and never modify the target. Probe connections are explicitly closed and probe queries are restricted to a safe, non-mutating statement set.
- File flows (batch, read-only). Local path, network share, SFTP and database sources are polled to confirm that an expected file arrived within its window.
- Source repositories (batch, pull). Code Sentinel accepts an uploaded archive, a server path or a git clone; it reads source only and writes nothing back.
- SMTP (real-time, outbound). All alerting, digests, management summaries and password resets.
- Continuous integration (inbound API). A CI pipeline can post scan results to the ingest endpoint so that pipeline findings appear alongside interactive scans.
Development and test environments run the same code against a separate database, typically SQLite, and share no state with production.
"""},

    _key('Backup and Recovery'): {'content': """
- Database. The primary recovery asset. On SQL Server or PostgreSQL, native platform backup applies with the standard corporate schedule. For a SQLite install, the database file together with its write-ahead log and shared-memory files must be copied with the application and scheduler briefly quiesced.
- Uploaded content. The secure_uploads/ and uploads/ trees hold project documents, certificate spreadsheets and analysis inputs, and must be backed up on the same cadence as the database to keep references consistent.
- Configuration. The .env file (which holds the session secret, the encryption key and integration credentials) and web.config must be backed up securely and separately from the data, since the encryption key is required to read the encrypted credentials back.
- Code. Restored from version control. There is no build step, so recovery is a checkout plus dependency install.
- Volumetrics are small enough that a full daily backup is appropriate; no incremental strategy is required.
"""},

    _key('DR and BCP'): {'content': """
App Assist is an internal productivity and monitoring platform, not a customer-facing system, and its agreed service level is business-hours best-effort. Recovery is by rebuild: provision a Windows and IIS host, restore code, configuration and the latest database and file backup, re-register the FastCGI handler, and reinstall and start the scheduler service.
Indicative recovery time objective is measured in hours and the recovery point objective is the last daily backup, consistent with the Bronze service level recorded above. No hot standby, clustering or cross-site resilience is designed at this tier; if the business later requires continuous availability, the stateless web tier can be load-balanced across two hosts against a shared database with no application change, and the scheduler service remains single-instance by design.
Recovery is to be tested annually as part of the platform's operational review; the test obligation sits with Platform Engineering.
"""},

    _key('As is'): {'content': """
The same outcomes are achieved today through standalone spreadsheets, scripts held on individual desktops and e-mail threads. There is no shared datastore, no single owner for scheduled automation, no common access control, and history is lost when staff change roles. Monitoring exists only where an individual engineer created and maintained a script, and its failure is silent. Code assurance is performed by ad-hoc review with no recorded result.
"""},

    _key('To-Be Conceptual Architecture'): {'content': """
Expressed in business terms, the target is one internal portal where a signed-in person selects the capability they need and works in a consistent, secured workspace; where automation runs quietly in the background and contacts people only when action is required; and where every record is retained and attributable to the person who created it.
Conceptually the solution comprises four objects the business already recognises: the Workspace (what a person can see and do, set by their role), the Register (the shared record of applications, projects, certificates and file flows), the Watcher (the automation that checks things on a schedule and raises alerts) and the Report (the professional document or spreadsheet produced from the register on demand). Every module is an instance of that same pattern.
"""},

    _key('Process View'): {'content': """
- Delivery process (Project Management). A short questionnaire recommends a delivery method; the chosen method's stages become milestones; work is executed as tasks with critical-path scheduling and a Kanban board; a team Lead signs off each stage gate by name; a Go-Live runbook is produced; the project is closed and baselined. Roles: Project Manager owns the project, Team Lead signs off gates, Team Member executes tasks, Administrator owns the master templates.
- Monitoring process. An administrator registers the target and its schedule; the scheduler service sweeps on cadence; results are stored and charted; a failure or missed arrival raises an e-mail alert to the owning team; history is purged on retention.
- Assurance process. A delivery team submits a source archive, path or repository; the scan runs in the background; findings are triaged as confirmed, false positive or accepted risk; the quality gate reports pass or fail; the result is exported for the release record.
- Workforce process. Every user records hours weekly; a project task allocation acts as the time-and-materials contract; utilisation and consumption are derived from the two together, with no separate re-keying.
- Off-boarding process. An administrator disables the leaver's account; login is blocked immediately; the person's name is preserved on every historical record; they are no longer offered for new assignment.
"""},

    _key('Architecture and Solution Design Decisions'): {
        'intro': 'Decisions that shape the overall solution, including those that depart from a standard pattern.',
        'rows': [
            ('D1', 'Agreed at design baseline',
             'Modular monolith rather than microservices. One deployable artefact matches the size of the owning team and allows every module to share authentication, database, theming and the launcher. Adding a capability is additive and carries no orchestration cost. Revisit only if module ownership fragments across teams.'),
            ('D2', 'Agreed at design baseline',
             'IIS with wfastcgi hosting rather than a self-hosted WSGI server. Aligns with the Windows estate and existing operational skills, and introduces no new runtime platform to support.'),
            ('D3', 'Agreed at design baseline',
             'Pluggable DATABASE_URL. SQLite gives a zero-setup standalone install for evaluation and development; SQL Server or PostgreSQL is mandatory for multi-worker production because SQLite serialises writes across processes.'),
            ('D4', 'Agreed at design baseline',
             'A single scheduler owner. All scheduled work runs in one Windows service and RUN_SCHEDULERS_IN_APP is false in the web tier, because an in-process scheduler in a multi-worker FastCGI pool would fire every job once per worker, producing duplicate alerts and duplicate writes.'),
            ('D5', 'Agreed at design baseline',
             'Users are disabled rather than deleted, and foreign keys block a hard delete while the user is still referenced. This preserves attributable history through staff changes; name-map lookups deliberately do not filter on the active flag so historical records keep their names.'),
            ('D6', 'Agreed at design baseline',
             'Ticket analysis is offline and file-based rather than API-integrated. Keeps all ticket text on the estate, removes any runtime dependency on service-desk availability, and avoids credential exchange between platforms.'),
            ('D7', 'Agreed at design baseline',
             'Integration credentials are encrypted with Fernet and the decryption path falls back across legacy keys. Rotation of the encryption key or session secret therefore does not render stored credentials unreadable, which was assessed as the highest-consequence operational failure mode.'),
            ('D8', 'Agreed at design baseline',
             'Migrations are additive only at runtime: create-if-missing plus add-column. The application never performs a destructive ALTER at start-up, so an upgrade cannot lose data and a rollback is a code rollback.'),
            ('D9', 'Agreed at design baseline',
             'Static analysis is embedded in the platform rather than consumed as a service. Source code never leaves the estate, the rule set is version-controlled with the application, and scans work with no internet access.'),
            ('D10', 'Agreed at design baseline',
             'Long-running operations execute as background jobs with a persisted job row, never inside the HTTP request. Avoids FastCGI request timeouts and leaves an auditable record of every run.'),
        ]},

    _key('Architecture Patterns and Integration Requirements'): {
        'intro': 'The patterns applied across the solution and the integration style each implies.',
        'rows': [
            ('P1', 'Modular monolith',
             'One WSGI application; each capability is a Flask blueprint with its own models, routes and templates, consuming shared platform services. Module boundaries are enforced by convention and by URL prefix.'),
            ('P2', 'Server-rendered multi-page application',
             'Jinja2 templates with a shared design system and progressive enhancement; charting by Plotly. No client-side framework, no build pipeline, no client-side state to secure.'),
            ('P3', 'Scheduled worker',
             'APScheduler jobs hosted in one dedicated Windows service, with idempotent sweeps and retention purges. Exactly-once execution is guaranteed by having exactly one scheduler process.'),
            ('P4', 'Repository and ORM',
             'SQLAlchemy declarative models with per-request sessions, bounded pooling, and additive schema evolution at start-up.'),
            ('P5', 'Session authentication with role-based access control',
             'Signed session cookie; role and membership checks applied at the endpoint, not only in the user interface; ownership enforced on every per-item route.'),
            ('P6', 'Secrets at rest',
             'Symmetric Fernet encryption through a shared crypto helper, with a derived-key fallback so credentials survive key rotation. No credential is ever written in plaintext.'),
            ('P7', 'Batch file ingestion',
             'Scoped upload limits, secure filename handling, server-side validation, and processing entirely offline: ticket exports, certificate spreadsheets, source archives and file-split inputs.'),
            ('P8', 'Fan-out alerting',
             'Threshold, failure and missed-arrival events raise e-mail through the relay; digests aggregate to avoid alert fatigue; templates share one theme module so every message looks the same.'),
            ('P9', 'Background job with persisted state',
             'A job row records queued, running, complete or failed with timestamps, so a worker recycle cannot strand a long operation invisibly and progress can be polled.'),
            ('P10', 'Document generation from a curated template',
             'An administrator curates a master template tree; the renderer produces a professional Word or Excel document from it, keeping structure governed centrally while content stays with the author.'),
        ]},

    _key('Business Architecture'): {'content': """
App Assist serves the IT operations and delivery function. The business roles that interact with the solution are:
- Project Manager. Plans and runs delivery projects, owns the projects they create, and reports on portfolio status.
- Team Lead. Executes work and is accountable for signing off SDLC stage gates by name.
- Team Member. Executes tasks, uploads documents, records risks and logs time against the tasks assigned to them.
- Incident Manager. Publishes and consumes live application status during a major incident or severe-weather event.
- Application Support and on-call engineers. Maintain the application system of record and consume health, file-monitor and support data.
- Security team. Owns the certificate inventory and its expiry alerting, and reviews static-analysis findings that carry a security category.
- Resource Manager. Reviews utilisation and time-and-materials consumption across the workforce.
- Administrator. Manages user accounts, shared master templates and platform configuration.
No location change and no organisational restructure is introduced by this solution; App Assist digitises responsibilities that already exist and places them in one workspace. The impact on the operating model is limited to standardisation: consistent formats, a shared audit trail, automated alerting, and reporting derived from recorded work rather than compiled by hand.
"""},

    _key('Security and Compliance'): {'content': """
This section is mandatory and every sub-section is completed. The controls described align to the corporate baseline security control set: transport encryption, encrypted secrets at rest, least-privilege access, an audit trail, and no data egress from the estate.
"""},

    _key('Data Security'): {'content': """
Technical controls cover the integrity, confidentiality and movement of data held by the platform. Content filtering is not applicable because the platform accepts structured operational data and source archives from authenticated internal users only, all of which are processed offline and never republished externally. No data is moved between trust zones beyond the flows recorded in the Network Integration section, all of which remain inside the corporate network; consequently no data protection impact assessment control for cross-zone transfer applies.
"""},

    _key('Data Classification'): {'content': """
All data held is classified Internal. It comprises project and operational records, application and server inventory, monitoring results, timesheet entries, static-analysis findings and stored integration credentials. No customer personal data and no payment data is processed. Uploaded service-desk exports may contain internal ticket narrative and are processed offline only. Project documents may additionally be flagged sensitive, which restricts their visibility to the project owner. Data is tagged by module and by owning project or application, tracked through the activity log, and stored only in the relational database and the two controlled upload directories.
"""},

    _key('Data Encryption (In Transit & At Rest)'): {'content': """
- In transit. HTTPS only on port 443; plain HTTP is rewritten to HTTPS at IIS; HSTS is asserted with a one-year max-age including subdomains. Outbound integration traffic uses the transport security native to each protocol: SSH, WinRM over HTTPS where enabled, and encrypted database client connections.
- At rest, secrets. Every integration credential - monitor passwords, database connection strings and vault entries - is encrypted with Fernet, which is AES-128 in CBC mode with an HMAC-SHA256 authentication tag. The key is supplied by the ENCRYPTION_KEY environment variable or, if absent, derived from the session secret using PBKDF2-HMAC-SHA256. Decryption attempts current and legacy keys in turn so a rotation does not orphan stored credentials.
- At rest, general data. Provided by the database platform and host disk controls; application-layer field encryption is deliberately scoped to credentials, where the consequence of disclosure is highest.
- Cryptography is controlled from the application configuration; no public key infrastructure or self-signed certificate is issued by the platform itself. The TLS certificate presented by IIS is issued and managed by Infrastructure.
"""},

    _key('Data Governance'): {'content': """
Records are retained and remain attributable. Users are disabled rather than deleted so historical attribution survives off-boarding. Monitoring execution history is purged on a retention schedule and timesheet rows older than a year are purged opportunistically, bounding growth without operator intervention. Project documents keep a version trail of the last four versions, with edit-in-place replacing the previous delete-and-recreate behaviour so links remain stable.
Ownership is explicit: application owners own inventory data, project managers own project data, the security team owns the certificate register, and administrators own the shared master templates. Data quality is enforced by server-side validation, by database foreign keys, and by type-ahead pickers that bind free text to existing records where a relationship exists.
"""},

    _key('Identity and Access Management Controls'): {'content': """
Authentication uses local application accounts with salted, hashed passwords stored using the platform's strong default hashing algorithm. Sessions are carried in a signed cookie marked HttpOnly with SameSite set to Lax, optionally Secure, and expire after eight hours. Self-service password reset issues a strong temporary password by e-mail and is written to avoid account enumeration - the response is identical whether or not the address is known.
Single sign-on, multi-factor authentication and privileged access management integration are not implemented in this release. Access routing is direct: users reach the platform over the LAN and authenticate at the application. Integration with the corporate identity provider is recorded as a dependency in the RAID section and would deliver both SSO and MFA in a single change.
"""},

    _key('User Roles'): {'content': """
- Administrator. Administers shared setup - master document templates, SDLC stages, effort defaults - manages user accounts and sub-group values, and may delete any project. Holds full read access. Deliberately cannot create or edit projects, which keeps administration and authorship separate.
- Project Manager. Creates and fully controls the projects they own, collaborates on projects they are a member of, and reads the utilisation dashboards and time-and-materials register.
- Team Member. Manages tasks, uploads documents and records risks on projects they belong to. Members in the Lead group additionally sign off SDLC stage gates.
- Security team member. Adds, edits and removes certificate records and administers expiry alerting. Membership is explicit; administrators hold this access implicitly.
- Every signed-in user. Own timesheet, own to-do list, own profile, the People Explorer, and read access to the shared registers.
- Visitor (anonymous). A read-only project list plus the stateless tools that store nothing: the HLD and BRD builders, the proposal deck builder and the architect diagram.
"""},

    _key('Privileged System Roles'): {'content': """
The Administrator role is the application's privileged role and is intentionally narrowed - administration and deletion, but not project authorship - so that the blast radius of a compromised administrator account is bounded. Security-team membership is a second, narrow privilege scoped to the certificate register only.
At operating-system level, the IIS application pool identity and the scheduler service account are distinct, each granted only the file-system, database and network rights its function requires. Neither is a domain administrator. Both are managed by Infrastructure under the corporate least-privilege standard, and their credentials are rotated on the standard service-account cycle.
"""},

    _key('Monitoring, Logging & Auditing'): {'content': """
- Application events are written by a rotating file handler capped at 10 MB per file with five generations retained. The wfastcgi start-up log captures import and hosting failures, and the scheduler service writes boot breadcrumbs plus a periodic heartbeat so a silent scheduler is detectable.
- An in-application activity log records meaningful changes per project - creation, edit, status change, task and risk changes, document upload and gate sign-off - each with the acting user and a timestamp.
- Authentication events, background job transitions and scan lifecycle events are logged with correlation to the initiating user.
- Security information and event management forwarding is not performed by the application. Operating-system, IIS and application logs are available on disk for collection by the estate's existing forwarding agents, which Infrastructure configures.
"""},

    _key('Security Hardening'): {'content': """
- Web tier. Security response headers are applied at IIS: HSTS, X-Content-Type-Options set to nosniff, X-Frame-Options set to SAMEORIGIN and a Referrer-Policy. Request filtering hides the logs, data and virtual-environment directories and refuses to serve .env, database and source files. The FastCGI file-change watcher is disabled so that legitimate file uploads cannot recycle a worker mid-request.
- Application tier. CSRF tokens protect every state-changing request; uploaded filenames are sanitised; upload size limits are applied globally and tightened per module; global error handlers return generic pages so no exception text or stack trace reaches the browser; and the application refuses to start in production without an explicit session secret rather than falling back to a default.
- Probe safety. Monitoring probes are read-only, subject to command and query timeouts, and always close their connections; the database test query is restricted to a safe statement set.
- Host hardening against the corporate rule set and the relevant CIS benchmarks is delivered by Infrastructure as part of the standard server build.
"""},

    _key('Secrets Management'): {'content': """
No credential is stored in plaintext. Integration credentials are encrypted with Fernet in the database, and a one-off sweep utility exists to encrypt any legacy plaintext value found during upgrade. Platform secrets - the session secret, the encryption key, and database and SMTP credentials - are held in the .env file, which IIS request filtering refuses to serve, or in operating-system and IIS environment variables, which take precedence over the file.
Keys and tokens used by the module-level secret vault are stored as encrypted tokens and resolved at use time, never logged and never rendered back to the browser. Adoption of a corporate managed secret store is identified as a future enhancement; the existing crypto helper is the single integration point that such a change would touch.
"""},

    _key('Firewall & Network Security'): {'content': """
The platform is reachable only from inside the corporate network; there is no inbound path from outside. Boundary controls - host firewall policy, network segmentation between the application and data zones, and intrusion detection - are provided and operated by Infrastructure.
The solution requires outbound reachability from the application zone to the monitored targets, the database instances, the file-transfer endpoints and the SMTP relay, as itemised in the Network Integration section. Those are the only egress rules required; no internet egress is needed at run time, and the platform is designed to operate correctly on a host with no internet access.
"""},

    _key('Compliance Requirements'): {'content': """
The design aligns to the corporate baseline security control set: TLS-only transport, encrypted secrets at rest, least-privilege roles, an audit trail of material change, and no data egress from the estate. The baseline security checklist is to be completed and signed off by IT Security as an implementation obligation, and is recorded in the approvals table of this document. No sector-specific regulatory regime applies, since the platform processes no personal, financial or customer data.
"""},

    _key('Security Testing'): {'content': """
Automated unit and integration tests run under pytest and cover platform behaviour and module logic, including a guard test that keeps the compatibility overlay synchronised with the main source tree.
Static application security testing is performed by the platform's own Code Sentinel engine, which the delivery team runs against the App Assist source itself as part of the release process; findings are triaged and the quality gate must be green before release. Dependency and dynamic testing against the deployed instance is performed by the security team's pipeline on the standard cycle, and penetration testing is scheduled in line with the corporate policy for internal applications.
"""},

    _key('Risk Management'): {'content': """
The principal security risks and their controls are:
- Credential theft or disclosure. Controlled by Fernet encryption at rest, least-privilege service accounts, and the absence of any plaintext credential in configuration or logs. Category: confidentiality. Residual risk: low.
- Session hijacking. Controlled by TLS-only transport, HttpOnly and SameSite cookie attributes and a short session lifetime. Category: authentication. Residual risk: low.
- Cross-site request forgery. Controlled by per-session tokens on every state-changing request. Category: integrity. Residual risk: low.
- Unauthorised access to another user's data. Controlled by role checks and per-item ownership enforcement on every route, not merely by hiding user-interface elements. Category: authorisation. Residual risk: low.
- Data leakage through uploads. Controlled by size limits, server-side validation, offline processing and the absence of any outbound path to the internet. Category: confidentiality. Residual risk: low.
- Absence of multi-factor authentication. Partially controlled by strong password hashing, session hardening and LAN-only reachability. Category: authentication. Residual risk: medium, accepted pending identity-provider integration.
"""},

    _key('Security Operations'): {'content': """
Day-to-day security operation sits with the platform and support teams: user lifecycle management including prompt disablement of leavers, secret rotation supported by the fallback decryption path, review of authentication and error logs, and timely dependency patching driven by the pinned manifest.
Security incidents affecting the platform follow the corporate incident process and are escalated to the security operations function; the platform contributes evidence through its application and activity logs. There is no dedicated security operations centre integration built into the application - log forwarding from the host is the agreed integration point.
"""},

    _key('Implementation View'): {
        'intro': 'The high-level delivery activities and the teams responsible for each.',
        'rows': [
            ('Provision the Windows and IIS host, TLS certificate and service accounts',
             'Infrastructure', 'Security', 'Platform Engineering', '-'),
            ('Install the Python runtime, database drivers and pinned dependencies',
             'Platform Engineering', 'Infrastructure', '-', '-'),
            ('Deploy the application code and configure web.config and the FastCGI registration',
             'Platform Engineering', 'Infrastructure', '-', '-'),
            ('Provision the production relational database and run the migration utility',
             'Platform Engineering', 'Database Team', '-', '-'),
            ('Populate environment configuration and encrypted secrets',
             'Platform Engineering', 'Security', '-', '-'),
            ('Install, configure and start the scheduler Windows service',
             'Platform Engineering', 'Infrastructure', '-', '-'),
            ('Complete the baseline security checklist and obtain sign-off',
             'Security', 'Platform Engineering', '-', '-'),
            ('Seed users, roles, support towers and master templates',
             'Application Support', 'Platform Engineering', 'Business Owner', '-'),
            ('Register monitoring targets, file flows and the certificate inventory',
             'Application Support', 'Application Owners', 'Security', 'Infrastructure'),
            ('Conduct user acceptance testing and training',
             'Business Owner', 'Application Support', 'Platform Engineering', '-'),
            ('Go live and hand over to support',
             'Platform Engineering', 'Application Support', 'Infrastructure', 'Security'),
        ]},

    _key('Decommissioning'): {'content': """
On retirement of the platform, quiesce and remove the IIS site and the FastCGI registration, then stop and uninstall the scheduler Windows service so that no further outbound probing or alerting occurs.
Export and retain any records required for audit - project history, gate sign-offs, certificate inventory and scan results - into the successor system or the records archive before removing data. Then securely sanitise the relational database and the secure_uploads/ and uploads/ directories, which may hold sensitive project documents and encrypted credentials, and remove the .env file and any backup copies of it, since it holds the key that would otherwise make retained encrypted backups readable.
The legacy artefacts this platform supersedes - the spreadsheets and desktop monitoring scripts - are archived and withdrawn at go-live rather than migrated; there is no legacy data store to retire beyond those files.
"""},

    _key('Support'): {
        'intro': 'The support model for the solution and the responsibilities of each team. The Operations Manual holds the detailed procedures.',
        'rows': [
            ('Application code, releases and upgrades', 'Platform Engineering', '-', '-'),
            ('IIS host, TLS certificate and operating-system patching', 'Infrastructure', 'Platform Engineering', '-'),
            ('Database backup, restore, tuning and capacity', 'Database Team', 'Platform Engineering', '-'),
            ('Scheduler service health and alert delivery', 'Platform Engineering', 'Application Support', '-'),
            ('Monitoring target and file-flow configuration', 'Application Support', 'Application Owners', 'Platform Engineering'),
            ('Certificate register and expiry alerting', 'Security', 'Application Support', '-'),
            ('User administration, roles and off-boarding', 'Application Support', 'Platform Engineering', '-'),
            ('Static-analysis findings and quality gate', 'Delivery Teams', 'Security', 'Platform Engineering'),
            ('Security review and incident response', 'Security', 'Platform Engineering', 'Infrastructure'),
            ('First-line user queries and how-to support', 'Application Support', '-', '-'),
        ]},

    _key('Risk, Assumptions, Issues and Dependencies'): {'content': """
The RAID position for this design is recorded below. Items are reviewed at each design authority checkpoint and closed items are retained for the audit trail rather than deleted.
"""},

    _key('Risks'): {
        'intro': 'Risks identified for this design, with the mitigation, current assessment and owner for each.',
        'rows': [
            ('RK1',
             'If SQLite is retained under a multi-worker IIS deployment, then concurrent writes will produce database-locked errors and lost updates',
             'Make SQL Server or PostgreSQL mandatory for production and provide the migration utility; write-ahead logging and a busy timeout are a development stopgap only',
             'Med', 'Hi', 'Platform Engineering'),
            ('RK2',
             'If the scheduler is enabled inside the web tier as well as the service, then every job fires once per worker, producing duplicate alerts and duplicate writes',
             'RUN_SCHEDULERS_IN_APP is false in the web tier by default and is verified at deployment; the service is the documented sole owner of the schedule',
             'Low', 'Hi', 'Platform Engineering'),
            ('RK3',
             'If multi-factor authentication and single sign-on remain absent, then account compromise risk is higher than for federated corporate applications',
             'Strong password hashing, hardened sessions, LAN-only reachability and short session lifetime; identity-provider integration planned as a follow-on change',
             'Med', 'Med', 'Security'),
            ('RK4',
             'If the session secret or encryption key is changed without the fallback path, then every stored integration credential becomes unreadable',
             'Fallback decryption across legacy keys; documented rotation procedure; keys backed up separately from the data they protect',
             'Low', 'Hi', 'Platform Engineering'),
            ('RK5',
             'If backups are not taken or not tested, then a host or database failure loses project, inventory and monitoring history',
             'Documented daily backup of database, uploads and configuration; annual restore test as part of the operational review',
             'Med', 'Hi', 'Database Team'),
            ('RK6',
             'If the compatibility overlay for the older interpreter drifts from the main source tree, then a production host silently runs stale code',
             'An automated test compares the overlay against the source tree and fails the build on drift; the overlay is deliberately kept to a minimal file count',
             'Low', 'Hi', 'Platform Engineering'),
            ('RK7',
             'If a very large service-desk export or source archive is uploaded, then the request is rejected or the worker times out',
             'Per-module upload limits documented; long operations run as background jobs with persisted state; the FastCGI request timeout is raised for analysis endpoints',
             'Low', 'Low', 'Platform Engineering'),
            ('RK8',
             'If monitored targets change credentials without notice, then probes fail and generate false alerts that erode trust in the alerting',
             'Probe failures are distinguished from target failures in the alert text; credential ownership sits with the application owners and is reviewed at each service review',
             'Med', 'Med', 'Application Support'),
        ]},

    _key('Assumptions'): {
        'intro': 'Assumptions made in producing this design. Each is to be confirmed before the design is baselined.',
        'rows': [
            ('AS1', 'Users access the platform only from the corporate network over TLS', 'Design workshop', 'Infrastructure'),
            ('AS2', 'An SMTP relay is reachable from the application host and permits relay from it', 'Design workshop', 'Infrastructure'),
            ('AS3', 'Monitored URLs, servers and databases are reachable from the host using least-privilege service accounts supplied by their owners', 'Design workshop', 'Application Owners'),
            ('AS4', 'A supported Python runtime and the required Oracle and ODBC drivers are installed on the host', 'Design workshop', 'Platform Engineering'),
            ('AS5', 'The active user population remains a single small team working business hours', 'Business Owner', 'Business Owner'),
            ('AS6', 'Service-desk data will continue to be available as a spreadsheet export in a stable column format', 'Design workshop', 'Service Management'),
            ('AS7', 'Source code submitted for analysis is owned by the organisation and may be stored on the application host for the duration of a scan', 'Security review', 'Security'),
        ]},

    _key('Issues'): {
        'intro': 'Issues open at the time of writing.',
        'rows': [
            ('IS1', 'No single sign-on or multi-factor authentication is implemented in this release', 'Security review', 'Security'),
            ('IS2', 'Formal recovery time and recovery point objectives are not yet ratified with the business owner', 'Design review', 'Business Owner'),
            ('IS3', 'Log forwarding to the security information and event management platform is not yet configured for this host', 'Security review', 'Infrastructure'),
            ('IS4', 'Production database platform selection between SQL Server and PostgreSQL is not yet confirmed', 'Design review', 'Database Team'),
        ]},

    _key('Dependencies'): {
        'intro': 'External deliverables and decisions on which this design depends.',
        'rows': [
            ('DP1', 'Windows host with IIS, the FastCGI handler, a supported Python runtime and database drivers', 'Infrastructure'),
            ('DP2', 'Production relational database instance provisioned and backed up', 'Database Team'),
            ('DP3', 'SMTP relay permission for alerting, digests and password reset', 'Infrastructure'),
            ('DP4', 'Service accounts and credentials for every monitored target', 'Application Owners'),
            ('DP5', 'TLS certificate issued for the application host name', 'Infrastructure'),
            ('DP6', 'Corporate identity provider integration for future single sign-on and multi-factor authentication', 'Security and Identity'),
            ('DP7', 'Baseline security checklist completion and sign-off', 'Security'),
        ]},

    _key('Constraints'): {
        'intro': 'Known constraints that shaped the design decisions recorded above.',
        'rows': [
            ('CN1', 'Hosting is Windows and IIS only',
             'The solution uses the FastCGI bridge and a Windows service for scheduling; no Linux or container deployment path is designed'),
            ('CN2', 'The solution must remain on-premise with no cloud or software-as-a-service dependency',
             'Ticket analysis is offline and file-based; machine learning and static analysis run locally; the platform must function with no internet egress'),
            ('CN3', 'The agreed service level is business-hours best-effort',
             'No high availability, clustering or hot standby is designed; recovery is by rebuild and restore'),
            ('CN4', 'SQLite provides single-writer semantics only',
             'Production must move to a server database using the supplied migration utility before multi-worker hosting is enabled'),
            ('CN5', 'Some target hosts run an older Python interpreter than the source targets',
             'A minimal, test-guarded compatibility overlay is maintained and new code must remain compatible with it'),
            ('CN6', 'The platform is delivered and maintained by a small team',
             'Favours a modular monolith, shared platform services and generated documentation over an architecture that would require dedicated per-service ownership'),
        ]},
}


# ===========================================================================
# BRD - App Assist Business Requirements Document
# ===========================================================================

SAMPLE_BRD = {

    _key('Executive Summary'): {'content': """
The IT operations and delivery function runs on tooling it assembled for itself: project trackers in spreadsheets, monitoring scripts on individual desktops, incident status circulated by e-mail, timesheets kept privately, and application knowledge held in people's heads. The cost is duplicated effort, inconsistent reporting, single points of knowledge, and no shared audit trail.
App Assist is the proposed response: a single, on-premise, role-secured web platform that consolidates fourteen operational capabilities into one workspace - delivery management, application support records, health and file monitoring, incident status, service-desk analytics, code assurance, certificate tracking, workforce time and utilisation, and a set of self-service utilities.
The value is threefold. First, effort recovered: reporting, status collation and routine checking become by-products of the work rather than separate tasks. Second, risk reduced: monitoring, certificate expiry and code assurance move from individual initiative to scheduled, alerted, auditable process. Third, knowledge retained: records stay attributable and complete when people change roles.
The ask is approval of the requirements baseline in this document, confirmation of the sponsoring budget for the delivery window, and the stakeholder commitments recorded in the assumptions and dependencies sections - principally infrastructure provision, security sign-off and the nomination of data owners.
"""},

    _key('Key Points at a Glance'): {
        'intro': 'The essentials of this initiative in one view.',
        'rows': [
            ('Business problem',
             'Operational work is spread across spreadsheets, desktop scripts and mailboxes, with no shared record, no consistent reporting and no owner for automation'),
            ('Proposed solution',
             'App Assist: one on-premise, role-secured web platform consolidating fourteen operational capabilities behind a single sign-in and design system'),
            ('Sponsor',
             'Head of IT Operations, supported by the Delivery Manager as business owner'),
            ('Primary beneficiaries',
             'Project managers, application support and on-call engineers, incident managers, the security team and resource managers'),
            ('Budget range',
             'Internal delivery effort only; no licence cost, no cloud subscription and no new hardware required'),
            ('Target date',
             'Baseline approved, delivered incrementally by module with the core platform and delivery management first'),
            ('Expected benefit',
             'Recovered reporting effort, earlier detection of monitoring and certificate failures, an auditable delivery record and defensible utilisation reporting'),
            ('Key constraint',
             'On-premise only, hosted on the existing Windows and IIS estate, with no data leaving the corporate network'),
        ]},

    _key('Introduction'): {'content': """
This section states why this document exists, the objectives the initiative must meet, the background that prompted it, the boundaries of what is being asked for, and the vocabulary used throughout.
"""},

    _key('Purpose of this Document'): {'content': """
This Business Requirements Document defines what the business needs from App Assist and why, expressed independently of how it will be built. It is the agreed requirements baseline: everything delivered is traceable to a requirement recorded here, and anything not recorded here is out of scope until the baseline is formally changed.
It should be used by the sponsor and business owner to confirm that the right problem is being solved; by business analysis and architecture as the source for the solution design; by delivery to plan and estimate; and by test to derive acceptance coverage. The companion High-Level Design describes how these requirements are met technically.
"""},

    _key('Business Objectives'): {
        'intro': 'The measurable objectives this initiative must achieve. Each is specific, measurable, achievable, relevant and time-bound.',
        'rows': [
            ('OBJ-1', 'Consolidate operational tooling into a single access-controlled workspace',
             'Number of separate spreadsheets and desktop scripts still in routine use',
             'All fourteen target capabilities available in one platform; routine use of superseded artefacts ceased within one quarter of each module going live'),
            ('OBJ-2', 'Detect monitoring and infrastructure failures before users report them',
             'Proportion of health, file-arrival and certificate-expiry failures first raised by an automated alert rather than by a user',
             'At least 90 percent of such failures alerted automatically'),
            ('OBJ-3', 'Make delivery reporting a by-product of the work rather than a separate exercise',
             'Manual effort spent per reporting cycle compiling project status',
             'Status, progress and critical path derived from recorded work, with no manual re-keying'),
            ('OBJ-4', 'Establish objective, repeatable assurance over delivered code',
             'Proportion of releases with a recorded static-analysis result and a green quality gate',
             'Every release carries a recorded scan result before go-live'),
            ('OBJ-5', 'Produce defensible workforce utilisation and time-and-materials reporting',
             'Proportion of utilisation figures derived from recorded timesheets and task allocations rather than estimates',
             'All reported utilisation derived from recorded data, with a visible compliance signal for missing entries'),
            ('OBJ-6', 'Retain complete and attributable operational history through staff change',
             'Number of historical records losing attribution after an off-boarding',
             'Zero; disabling an account preserves the person on every record they touched'),
            ('OBJ-7', 'Keep all operational and ticket data inside the corporate network',
             'Volume of operational data transmitted to any external service',
             'Zero; the platform must function with no internet egress'),
        ]},

    _key('Project Background & Context'): {'content': """
The operations and delivery function grew its tooling organically. Each capability was created by whoever needed it, in whatever tool was to hand, and remained in that person's care. That worked while the team was small and stable, and stopped working as the estate, the delivery workload and the compliance expectations grew.
Three drivers made change necessary. Operationally, monitoring depended on individual initiative: where an engineer had written a script it ran, where they had not, failures were discovered by users, and when they moved on the script was orphaned. Governance-wise, delivery reporting was compiled by hand from several sources, which made it slow, inconsistent and difficult to trust, and stage governance left no durable record of who approved what. Commercially, utilisation and time-and-materials consumption were estimated rather than derived, which is not defensible in a client or audit conversation.
A strategic constraint shaped the response: the organisation requires operational and ticket data to remain on the corporate network, which rules out the software-as-a-service products that would otherwise cover parts of this ground and makes an internally built, on-premise platform the appropriate answer.
"""},

    _key('Scope'): {'content': """
This section records what the initiative will deliver and what it deliberately will not, so that expectations are set before design begins. Anything not listed as in scope requires a formal change to this baseline.
"""},

    _key('In Scope'): {
        'intro': 'Every capability this initiative will deliver or change.',
        'rows': [
            ('1', 'Core platform',
             'Single sign-in, role-based access, module launcher, shared design system, user profiles and self-service password reset'),
            ('2', 'Project and delivery management',
             'Projects, SDLC governance by questionnaire, milestones, tasks, critical-path scheduling, Kanban, baselines, risk matrix, workload and portfolio views'),
            ('3', 'Governed document production',
             'Administrator-curated master templates producing professional Word documents, including this document type and the High-Level Design, plus planning, effort, go-live and status exports'),
            ('4', 'Application support system of record',
             'Support towers, application profiles, server and interface records, live estate architecture view, wildcard search and profile exports'),
            ('5', 'Health monitoring',
             'Scheduled URL, server and database checks with history, charting and e-mail alerting'),
            ('6', 'File transfer monitoring',
             'Expected-arrival checks across path, share, SFTP and database sources, exclusion rules and pending-file alerting'),
            ('7', 'Major incident status',
             'Live application status publication during a major incident or severe-weather event'),
            ('8', 'Service-desk analytics',
             'Offline analysis of exported incidents and service requests, with management summary e-mail and multi-sheet spreadsheet output'),
            ('9', 'Code assurance',
             'Static analysis of delivered source with triage workflow, quality gate, report and interchange-format exports and a pipeline ingest interface'),
            ('10', 'Certificate management',
             'Certificate inventory with ownership, expiry tracking and scheduled expiry alerting'),
            ('11', 'Workforce time and utilisation',
             'Personal weekly timesheet, people explorer, utilisation dashboards, time-and-materials allocation register and spreadsheet reporting'),
            ('12', 'Personal productivity',
             'Private to-do list with a daily digest'),
            ('13', 'Operational utilities',
             'File search, compare, split and de-duplicate, data scrambling, server register and encoding tools'),
            ('14', 'Alerting and notification',
             'Consistent, themed e-mail for every alert, digest and management summary'),
        ]},

    _key('Out of Scope'): {
        'intro': 'Explicitly excluded from this initiative, with the reason for exclusion.',
        'rows': [
            ('1', 'Live integration with the service-desk platform',
             'The organisation requires ticket data to stay on the estate and the service-desk release cycle is outside this team\'s control; exported files meet the analytical need without creating a runtime dependency'),
            ('2', 'Managing the configuration of monitored applications, servers and databases',
             'Those systems are owned by their application and infrastructure teams; this initiative observes and reports only'),
            ('3', 'Single sign-on and multi-factor authentication',
             'Dependent on the corporate identity provider programme; the platform will use local accounts in this release and integrate later'),
            ('4', 'Provision of host infrastructure, network, firewall rules and TLS certificates',
             'Delivered by Infrastructure under existing standards; this initiative states the requirement only'),
            ('5', 'Remediation of the defects that code analysis reports',
             'Detection and tracking are in scope; fixing belongs to the team that owns the code'),
            ('6', 'Financial systems integration for time-and-materials billing',
             'Utilisation and consumption data will be exported for the finance process rather than posted into finance systems'),
            ('7', 'Mobile applications and access from outside the corporate network',
             'The user population works on the corporate network; remote access is a separate infrastructure decision'),
        ]},

    _key('Definitions, Acronyms & Abbreviations'): {
        'intro': 'Terms used in this document that a reader outside the project team may not know.',
        'rows': [
            ('BAU', 'Business as usual: ongoing operational work as distinct from project work'),
            ('Critical path', 'The longest dependent sequence of tasks; any delay on it delays the project end date'),
            ('Gate', 'A formal checkpoint at the end of a delivery stage, requiring named sign-off before the next stage starts'),
            ('MoSCoW', 'Prioritisation scheme: Must have, Should have, Could have, Will not have this time'),
            ('On-call', 'The rota under which an engineer responds to out-of-hours incidents'),
            ('Quality gate', 'A pass or fail threshold applied to code-analysis results before a release proceeds'),
            ('RACI', 'Responsibility model: Responsible, Accountable, Consulted, Informed'),
            ('SDLC', 'Software Development Life Cycle: the sequence of stages a delivery follows'),
            ('Static analysis', 'Automated inspection of source code for defects without executing it'),
            ('Support tower', 'A grouping of applications under one support team'),
            ('T&M', 'Time and materials: a commercial model charging for effort actually expended'),
            ('Utilisation', 'The proportion of a person\'s available capacity accounted for by recorded work'),
        ]},

    _key('Stakeholder Analysis'): {
        'intro': 'Everyone affected by, or influencing, this initiative. Influence and interest ratings drive the engagement approach.',
        'rows': [
            ('Head of IT Operations', 'Project Sponsor',
             'Funds and mandates the initiative; owns the benefits case and resolves cross-team blockers',
             'High', 'High'),
            ('Delivery Manager', 'Business Owner',
             'Owns the requirements baseline, prioritises the backlog and accepts each delivered module',
             'High', 'High'),
            ('Project Managers', 'Primary user group',
             'Plan and report delivery; the largest single beneficiary of the delivery management capability',
             'Medium', 'High'),
            ('Application Support engineers', 'Primary user group',
             'Maintain the system of record and consume monitoring and support data, including on call',
             'Medium', 'High'),
            ('Incident Managers', 'Primary user group',
             'Publish and consume live application status during major incidents',
             'Medium', 'High'),
            ('Security team', 'Governance and user group',
             'Approves the control baseline, owns the certificate register and reviews security findings',
             'High', 'Medium'),
            ('Infrastructure team', 'Enabler',
             'Provides hosting, certificates, service accounts and network reachability',
             'High', 'Medium'),
            ('Database team', 'Enabler',
             'Provisions and operates the production database and its backups',
             'Medium', 'Medium'),
            ('Resource Managers', 'Secondary user group',
             'Consume utilisation and time-and-materials reporting for commercial and capacity decisions',
             'Medium', 'High'),
            ('Delivery teams', 'Secondary user group',
             'Submit code for analysis and triage the findings raised against their projects',
             'Low', 'Medium'),
            ('All staff in the function', 'End users',
             'Record time, keep a personal task list and maintain their own profile',
             'Low', 'Medium'),
            ('Platform Engineering', 'Delivery team',
             'Builds, deploys and maintains the platform',
             'Medium', 'High'),
        ]},

    _key('RACI Matrix'): {
        'intro': 'Responsibility assignment for the principal deliverables. Exactly one accountable party per activity.',
        'rows': [
            ('Approve the requirements baseline', 'A', 'R', 'C', 'I'),
            ('Prioritise the requirement backlog', 'A', 'R', 'C', 'I'),
            ('Produce the High-Level Design', 'I', 'C', 'A/R', 'C'),
            ('Build and unit test each module', 'I', 'C', 'A/R', 'C'),
            ('Approve the security control baseline', 'I', 'C', 'C', 'I'),
            ('Define acceptance criteria and test coverage', 'I', 'A/R', 'C', 'C'),
            ('Execute user acceptance testing', 'A', 'R', 'C', 'R'),
            ('Approve go-live for each module', 'A', 'R', 'C', 'C'),
            ('Migrate data from superseded spreadsheets', 'I', 'C', 'R', 'A'),
            ('Train users and publish guidance', 'I', 'A/R', 'C', 'I'),
            ('Operate and support the platform after go-live', 'A', 'I', 'R', 'C'),
        ]},

    _key('Current State & Future State'): {'content': """
This section contrasts how the function operates today with how it will operate once the initiative is delivered, and records the specific problems the change must resolve.
"""},

    _key('Current State (As-Is)'): {'content': """
Work is spread across tools that do not talk to each other.
- Delivery. Each project manager maintains their own spreadsheet plan. Status for the monthly report is compiled by hand from those plans, e-mail threads and conversations. Stage approvals happen in meetings and are minuted, if at all, outside any system.
- Monitoring. Health checks exist where an individual engineer wrote a script and scheduled it on their own machine or a shared server. Coverage is uneven, failures of the script itself are silent, and the checks are orphaned when the author changes role. Expected file transfers are confirmed by someone remembering to look.
- Incident communication. During a major incident, application status is gathered by telephone and circulated by e-mail, and is out of date by the time it is read.
- Support knowledge. Facts about an application - which servers, which support team, which interfaces, which jobs - live in several places and in people's memories, which is felt most acutely on call.
- Assurance. Code review is ad hoc and its outcome is not recorded, so there is no evidence that a release was checked.
- Certificates. Expiry is tracked on a spreadsheet reviewed when someone remembers, and expiries have been discovered by outage.
- Time and utilisation. Hours are recorded privately if at all, and utilisation is estimated for reporting rather than derived.
The As-Is process map for the delivery and monitoring flows is held with the business analysis pack and referenced in the appendices.
"""},

    _key('Pain Points & Opportunities'): {
        'intro': 'The specific problems in the current state, their business impact and severity.',
        'rows': [
            ('PP1', 'Monitoring coverage depends on individual initiative and is silently lost when people move on',
             'Failures reach users before they reach the team; repeated avoidable incidents', 'High'),
            ('PP2', 'Delivery status is compiled by hand from several sources',
             'Slow, inconsistent and mistrusted reporting; effort diverted from delivery', 'High'),
            ('PP3', 'Stage approvals leave no durable, attributable record',
             'Governance cannot be evidenced at audit; disputes over what was agreed', 'Medium'),
            ('PP4', 'Application knowledge is fragmented and partly undocumented',
             'Slow diagnosis on call; heavy dependence on specific individuals', 'High'),
            ('PP5', 'Certificate expiry is tracked manually and reviewed irregularly',
             'Outages caused by expired certificates that were entirely foreseeable', 'High'),
            ('PP6', 'Expected file transfers are confirmed only when someone thinks to check',
             'Downstream processing runs on stale or missing data before anyone notices', 'Medium'),
            ('PP7', 'Code assurance is inconsistent and its outcome is not recorded',
             'No evidence of pre-release checking; defects reach production that analysis would have caught', 'Medium'),
            ('PP8', 'Utilisation and time-and-materials consumption are estimated, not derived',
             'Commercial and capacity decisions rest on figures that cannot be defended', 'High'),
            ('PP9', 'Records lose attribution when staff leave',
             'History becomes unusable for audit and for learning', 'Medium'),
            ('PP10', 'Ticket volumes are analysed manually when they are analysed at all',
             'Trends and recurring causes are missed; management reporting is reactive', 'Medium'),
        ]},

    _key('Future State (To-Be)'): {'content': """
Once delivered, a member of the function signs in once and works in a single, consistent workspace scoped to their role.
- Delivery is planned in the platform. Choosing a method drives the stage structure; tasks carry dependencies so progress, status and the critical path are calculated rather than compiled; a named lead signs off each gate and that record is permanent; and the monthly report is an export rather than an exercise.
- Monitoring is a registered service, not a personal script. Targets are configured once, swept on a schedule by a single owner, charted with history, and alerted by e-mail on failure or missed arrival. Coverage survives staff change because it belongs to the platform.
- Application knowledge is a maintained record. One profile per application carries its servers, support teams, interfaces and dependencies, is searchable, exports to Word and PDF, and drives a live architecture view of the estate.
- Assurance is a gate. Source is scanned on submission and in the pipeline, findings are triaged with an audit trail, and the release record carries the result.
- Certificates and file flows are watched automatically and warn ahead of the event.
- Time is recorded weekly by everyone, task allocations act as the time-and-materials contract, and utilisation is derived from both with a visible signal where entries are missing.
- Every record stays attributable through staff change, because leavers are disabled rather than removed.
The To-Be process map is held with the business analysis pack and referenced in the appendices.
"""},

    _key('Business Requirements'): {'content': """
The requirements below state what the business needs, not how it will be built. Each is uniquely identified, atomic and testable, and is prioritised using MoSCoW. The register gives the at-a-glance view; the specifications that follow give the full narrative for each.
"""},

    _key('Business Requirements Register (Summary)'): {
        'intro': 'All business requirements at a glance, for traceability.',
        'rows': [
            ('BR-1', 'Provide a single, role-secured workspace for all operational tooling', 'Must', 'OBJ-1', 'Sponsor and design workshop'),
            ('BR-2', 'Plan, govern and report delivery work within the platform', 'Must', 'OBJ-3', 'Project Managers'),
            ('BR-3', 'Monitor application, server, database and file-transfer health on a schedule and alert on failure', 'Must', 'OBJ-2', 'Application Support'),
            ('BR-4', 'Maintain an authoritative application system of record for support and on-call', 'Must', 'OBJ-1', 'Application Support'),
            ('BR-5', 'Track certificates and warn before expiry', 'Must', 'OBJ-2', 'Security team'),
            ('BR-6', 'Provide objective, recorded assurance over delivered source code', 'Should', 'OBJ-4', 'Delivery Manager'),
            ('BR-7', 'Record time worked and derive workforce utilisation and time-and-materials consumption', 'Must', 'OBJ-5', 'Resource Managers'),
            ('BR-8', 'Publish live application status during a major incident', 'Should', 'OBJ-2', 'Incident Managers'),
            ('BR-9', 'Analyse exported service-desk tickets and summarise them for management', 'Should', 'OBJ-3', 'Head of IT Operations'),
            ('BR-10', 'Produce professional, consistently formatted documents and reports from platform data', 'Must', 'OBJ-3', 'Project Managers'),
            ('BR-11', 'Preserve complete, attributable history through staff change', 'Must', 'OBJ-6', 'Business Owner'),
            ('BR-12', 'Keep all operational data on the corporate network', 'Must', 'OBJ-7', 'Security team'),
            ('BR-13', 'Provide self-service operational utilities to reduce ad-hoc scripting', 'Could', 'OBJ-1', 'Application Support'),
        ]},

    _key('Detailed Business Requirement Specifications'): {
        'intro': 'The full specification for each business requirement recorded in the register above.',
        'blocks': [
            {'fields': {
                'title': 'Single role-secured workspace for operational tooling',
                'priority': 'Must',
                'description': 'The business requires one internal web platform through which every member of the operations and delivery function reaches the tooling they need, with a single sign-in and a consistent interface, rather than moving between spreadsheets, desktop scripts and mailboxes.',
                'rationale': 'Fragmented tooling is the root cause of most pain points recorded in this document: it prevents shared records, prevents consistent reporting, and makes ownership of any given capability ambiguous. Consolidation is the precondition for the other requirements to deliver value.',
                'detail': 'The platform must present a launcher listing the capabilities available to the signed-in user, and hide those their role does not permit. Access must be governed by role, with at minimum an administrator role, a project manager role and a general user role, plus explicit membership for the security function. Authorisation must be enforced when the request is handled, not only by hiding interface elements. Anonymous visitors may reach a defined set of read-only or storage-free tools and nothing else. A user must be able to maintain their own profile and reset their own password without administrator involvement.',
                'dependencies': 'Precondition for BR-2 through BR-13. Depends on infrastructure provision of the host and certificate. Related to BR-11 for the account lifecycle rules.',
            }},
            {'fields': {
                'title': 'Plan, govern and report delivery work within the platform',
                'priority': 'Must',
                'description': 'Project managers require the platform to hold the delivery plan, so that progress, status, the critical path and stage governance are derived from recorded work rather than compiled by hand for each reporting cycle.',
                'rationale': 'Manual compilation is slow, inconsistent and mistrusted, and stage approvals currently leave no durable record. Deriving reporting from the plan removes the effort and makes the output defensible at audit.',
                'detail': 'A project must carry its stages, milestones and tasks, with dependencies between tasks so that the critical path and forecast completion are calculated. The delivery method must be established at project creation by a short questionnaire, and the applicable stages must be selectable so that a simple piece of work is not forced through full governance. A named lead must sign off each stage gate, and that sign-off must be permanently recorded with the person and the date. The plan must be viewable as a list, a board and a schedule, and must support baselining so that variance against the original plan is visible. Risks must be recordable against the project with likelihood and impact. Project membership must control who can edit.',
                'dependencies': 'Depends on BR-1 for roles and membership, and on BR-10 for the exported reports. Feeds BR-7, because a task allocation is the time-and-materials contract.',
            }},
            {'fields': {
                'title': 'Scheduled monitoring of applications, servers, databases and file transfers',
                'priority': 'Must',
                'description': 'The business requires the platform to check the health of registered applications, servers and databases, and the arrival of expected file transfers, on an automatic schedule, and to alert the responsible team by e-mail when a check fails or an expected file does not arrive.',
                'rationale': 'Monitoring currently depends on individual initiative and is silently lost when people change role, so failures reach users before they reach the team. Making monitoring a registered service of the platform gives it continuity, coverage and an owner.',
                'detail': 'A target must be registered once with its type, connection details, schedule and owning team, and thereafter checked automatically without further intervention. Checks must be read-only and must never modify the target. Results must be retained with history so that trends and repeat failures are visible, and history must be purged automatically so that storage does not grow without bound. Failure must raise an e-mail to the owning team, and the message must distinguish a genuine target failure from a failure of the check itself. For file transfers, the business must be able to define the expected arrival window and to exclude known non-arrivals through a maintained rule set rather than by disabling the check. Every scheduled job must run exactly once regardless of how the platform is hosted.',
                'dependencies': 'Depends on infrastructure reachability and on service accounts supplied by application owners. Related to BR-5, which applies the same alerting principle to certificates.',
            }},
            {'fields': {
                'title': 'Authoritative application system of record',
                'priority': 'Must',
                'description': 'Support and on-call engineers require one authoritative record per application, holding its servers, support teams, interfaces, dependencies and operational facts, searchable and exportable.',
                'rationale': 'Application knowledge is currently fragmented and partly undocumented, which slows diagnosis at the worst possible moment and creates heavy dependence on specific individuals.',
                'detail': 'Applications must be grouped into support towers with an owning team. A profile must record the application description, its servers with location and operating system, its support contacts, its external interfaces and its dependencies. Data entry must offer type-ahead selection from existing records so that free text does not fragment the register. The record must be searchable by partial term across applications, servers and teams. A profile and a tower must both be exportable as a formatted document and spreadsheet for offline and audit use. The platform must derive a visual architecture view of the estate from the recorded interfaces, so the picture is generated from the record rather than drawn separately and allowed to drift.',
                'dependencies': 'Depends on application owners supplying and maintaining the data, recorded as an assumption. Related to BR-3, which monitors the same estate, and BR-10 for exports.',
            }},
            {'fields': {
                'title': 'Certificate inventory with expiry warning',
                'priority': 'Must',
                'description': 'The security function requires a maintained inventory of certificates with their owner and expiry date, and automatic warning in advance of expiry.',
                'rationale': 'Certificate expiry has caused outages that were entirely foreseeable. A manually reviewed spreadsheet has repeatedly failed to prevent them because review depends on someone remembering.',
                'detail': 'A certificate record must carry its subject, the system it serves, its owner, its issuer and its expiry date, and must be maintainable individually or by bulk spreadsheet upload. Certificates must be listed with clear visual indication of those expiring soon or already expired. The platform must send scheduled advance warning to the owning contacts, at a lead time the security team can configure. Maintenance rights must be limited to nominated security-team members and administrators, while read access may be broader so that application teams can see the position for their own systems.',
                'dependencies': 'Depends on BR-1 for the security-team membership mechanism and on the mail relay. Shares the alerting approach of BR-3.',
            }},
            {'fields': {
                'title': 'Objective, recorded assurance over delivered source code',
                'priority': 'Should',
                'description': 'Delivery management requires an automated, repeatable inspection of source code before release, with findings recorded, triaged and summarised as a pass or fail result attached to the release record.',
                'rationale': 'Code review is currently ad hoc and its outcome is not recorded, so there is no evidence that a release was checked and defects reach production that inspection would have caught. An objective gate replaces opinion with evidence.',
                'detail': 'A team must be able to submit source as an uploaded archive, a path on the estate or a repository reference, and receive a report of findings by severity and category. Findings must be triageable as confirmed, false positive or accepted risk, with the decision, the person and the date retained so that the same finding is not re-argued at every scan. The platform must express an overall pass or fail against a configurable threshold. Results must be exportable in a standard interchange format so that they can be consumed by other tools, and in a readable report for the release record. A build pipeline must be able to submit results through an interface so that pipeline and interactive findings appear together. Analysis must run entirely on the estate with no requirement for internet access.',
                'dependencies': 'Depends on BR-12 for the on-premise constraint. Remediation of findings is out of scope and belongs to the owning delivery team.',
            }},
            {'fields': {
                'title': 'Time recording with derived utilisation and time-and-materials consumption',
                'priority': 'Must',
                'description': 'The business requires every member of the function to record time weekly, and requires utilisation and time-and-materials consumption to be derived from that record together with the project task allocations, rather than estimated.',
                'rationale': 'Utilisation is currently estimated for reporting, which cannot be defended in a client or audit conversation, and capacity decisions rest on the same weak figures.',
                'detail': 'Each user must have a private weekly timesheet, entered against a standard working day, with their own entries visible only to them. Managers must see aggregated figures rather than individual narrative. Utilisation must be calculated from recorded time against available capacity, and capacity must account for public holidays and recorded leave so the figure is honest. Where entries are missing, the platform must show a compliance signal rather than silently understating utilisation. The time-and-materials contract must be the project task allocation - planned working days converted to hours - and consumption must be the hours logged against that task, with work continuing beyond the allocation clearly identified as extended. Utilisation and allocation data must be exportable as a formatted spreadsheet for the commercial process.',
                'dependencies': 'Depends on BR-2, since allocations originate as project tasks, and on BR-1 for the visibility rules. Feeds the finance process by export only; see the out-of-scope list.',
            }},
            {'fields': {
                'title': 'Live application status during a major incident',
                'priority': 'Should',
                'description': 'Incident managers require a single live view of which business-critical applications are healthy, degraded or unavailable during a major incident or severe-weather event, maintainable in real time and visible to all responders.',
                'rationale': 'Status is currently gathered by telephone and circulated by e-mail, so it is stale by the time it is read and every stakeholder receives a different version.',
                'detail': 'The platform must present the business-critical application list with a current status that a nominated responder can update immediately as the situation changes. The view must be readable at a glance by stakeholders who are not operating the incident, and must show when each status was last updated so that its currency is obvious. Status history for the event must be retained for the post-incident review.',
                'dependencies': 'Depends on BR-4 for the application list. Related to BR-3, whose automated results inform but do not replace the responder\'s assessment.',
            }},
            {'fields': {
                'title': 'Analysis and management summary of service-desk tickets',
                'priority': 'Should',
                'description': 'Management requires exported service-desk incident and request data to be analysed within the platform and summarised into a consolidated report and e-mail, without the data leaving the estate.',
                'rationale': 'Ticket volumes are analysed manually when they are analysed at all, so recurring causes and trends are missed and management reporting stays reactive.',
                'detail': 'A user must be able to upload an export and receive analysis grouped by the dimensions management reports on, with incidents and service requests treated as distinct report types because their shape and their meaning differ. The output must be available both as an on-screen summary and as a consolidated e-mail with a multi-sheet spreadsheet attached, suitable for circulation without further editing. Analysis must run offline within the platform; no ticket text may be transmitted to any external service.',
                'dependencies': 'Depends on the service desk continuing to provide a stable export format, recorded as an assumption. Depends on BR-12.',
            }},
            {'fields': {
                'title': 'Professional document and report production from platform data',
                'priority': 'Must',
                'description': 'The business requires the platform to produce professional, consistently formatted documents and spreadsheets from the data it holds, using templates that an administrator curates centrally.',
                'rationale': 'Documents produced independently vary in structure and quality, and governance erodes as sections are dropped. Central template curation keeps the structure governed while the content stays with the author.',
                'detail': 'An administrator must be able to maintain the master structure of each document type as an ordered, hierarchical template, including table structures. Authors must fill that structure without being able to alter it, and must be able to mark a section not applicable rather than delete it, so that the template does not erode over time. Output must be a properly formatted Word document with a cover, document control, a navigable contents list, running header and footer, and print-grade tables. The same principle applies to spreadsheet outputs for planning, effort, go-live and utilisation reporting. A first-time author must be able to obtain a fully worked sample document to see what good looks like before starting.',
                'dependencies': 'Depends on BR-1 for the administrator role. Applies to the outputs of BR-2, BR-4, BR-7 and BR-9.',
            }},
            {'fields': {
                'title': 'Preserved, attributable history through staff change',
                'priority': 'Must',
                'description': 'The business requires that when a person leaves or changes role, every record they created or acted upon retains their name and remains complete, while their access is removed immediately.',
                'rationale': 'History currently loses attribution when staff leave, which makes it unusable for audit and for organisational learning, and undermines the value of every other record the platform holds.',
                'detail': 'Off-boarding must disable the account so that sign-in is refused immediately and the person is no longer offered for new assignment, while their name continues to appear on historical records. Permanent deletion must be refused while the person is still referenced by any record. Material changes must be logged with the acting person and the time, so that the history is not only preserved but explicable. Documents must retain a version trail so that a superseded version can be recovered.',
                'dependencies': 'Cross-cutting; applies to every module. Depends on BR-1 for the account lifecycle.',
            }},
            {'fields': {
                'title': 'All operational data retained on the corporate network',
                'priority': 'Must',
                'description': 'The business requires that no operational, ticket, source-code or personal data held by the platform is transmitted to any service outside the corporate network, and that the platform functions correctly on a host with no internet access.',
                'rationale': 'This is a standing organisational constraint. It also determines the shape of several other requirements, since it rules out the external services that would otherwise cover parts of this ground.',
                'detail': 'All processing, including analytical and code-inspection workloads, must execute on the estate. The platform must have no runtime dependency on an external service, and must not degrade or fail when internet access is unavailable. Any future proposal to introduce an external dependency must be raised as a formal change to this baseline and approved by the security function.',
                'dependencies': 'Constrains BR-6 and BR-9 in particular. Aligns to the corporate security policy.',
            }},
            {'fields': {
                'title': 'Self-service operational utilities',
                'priority': 'Could',
                'description': 'Support engineers require a set of common file and data utilities within the platform so that routine tasks do not require ad-hoc scripts written and held on individual desktops.',
                'rationale': 'Ad-hoc scripts are the same problem as ad-hoc monitoring in a smaller form: unowned, undocumented and lost when their author moves on.',
                'detail': 'The utilities must cover, at minimum, searching for content across a set of files, comparing two files, splitting a large file, removing duplicate rows, obscuring sensitive values in a data extract for use in a lower environment, and maintaining a register of servers. Each must be usable without scripting knowledge and must apply the same access control and file-size limits as the rest of the platform.',
                'dependencies': 'Depends on BR-1. Lowest priority in this baseline; may be deferred without affecting the other requirements.',
            }},
        ]},

    _key('Functional Requirements'): {'content': """
The functional requirements below state the system behaviours that satisfy the business requirements. Each traces back to a business requirement and forward to an acceptance criterion.
"""},

    _key('Functional Requirements Register (Summary)'): {
        'intro': 'All functional requirements at a glance, for traceability. Each is specified in full in the section that follows, in the same order and under the same identifier.',
        'rows': [
            ('FR-1', 'Authenticate a user and present a launcher scoped to their role', 'Must', 'BR-1', 'AC-1'),
            ('FR-2', 'Enforce authorisation server-side on every state-changing request', 'Must', 'BR-1, BR-11', 'AC-2'),
            ('FR-3', 'Calculate the critical path and forecast completion from task dependencies', 'Must', 'BR-2', 'AC-3'),
            ('FR-4', 'Record a named stage-gate sign-off that cannot later be altered anonymously', 'Must', 'BR-2', 'AC-4'),
            ('FR-5', 'Execute registered checks on schedule, exactly once, and store the result', 'Must', 'BR-3', 'AC-5'),
            ('FR-6', 'Alert the owning team on check failure, missed file arrival and approaching certificate expiry', 'Must', 'BR-3, BR-5', 'AC-6'),
            ('FR-7', 'Maintain, search and export the application system of record', 'Must', 'BR-4', 'AC-7'),
            ('FR-8', 'Generate the estate architecture view from recorded interfaces', 'Should', 'BR-4', 'AC-8'),
            ('FR-9', 'Publish and update live application status during a major incident', 'Should', 'BR-8', 'AC-9'),
            ('FR-10', 'Analyse an uploaded ticket export into a summary and distributable spreadsheet', 'Should', 'BR-9', 'AC-10'),
            ('FR-11', 'Scan submitted source, retain triage decisions and express a quality gate', 'Should', 'BR-6', 'AC-11'),
            ('FR-12', 'Record weekly time privately and derive utilisation against leave-aware capacity', 'Must', 'BR-7', 'AC-12'),
            ('FR-13', 'Consume a task allocation as the time-and-materials contract and flag extended work', 'Must', 'BR-7, BR-2', 'AC-13'),
            ('FR-14', 'Render a governed template to a formatted Word document and provide a worked sample', 'Must', 'BR-10', 'AC-14'),
            ('FR-15', 'Disable a user while preserving attribution, and refuse deletion while referenced', 'Must', 'BR-11', 'AC-15'),
            ('FR-16', 'Encrypt every stored credential and operate with no external dependency', 'Must', 'BR-12', 'AC-16'),
            ('FR-17', 'Run long operations as background jobs with observable state', 'Should', 'BR-6, BR-9', 'AC-17'),
            ('FR-18', 'Purge monitoring and timesheet history beyond the retention period automatically', 'Should', 'BR-3, BR-11', 'AC-18'),
        ]},

    _key('Detailed Functional Requirement Specifications'): {
        'intro': 'The full specification for each functional requirement, numbered to match the register above.',
        'blocks': [
            {'fields': {
                'title': 'Authenticate a user and present a launcher scoped to their role',
                'priority': 'Must',
                'description': 'The system shall authenticate a user against their account credentials, establish a session carrying their role and group membership, and present a launcher showing only the capabilities that role permits.',
                'rationale': 'A single, consistent entry point is what makes consolidation visible to the user; showing capabilities they cannot use produces confusion and support calls.',
                'detail': 'Sign-in shall accept a username and password, compare against a stored salted hash, and refuse a disabled account. On success the system shall establish a session with a bounded lifetime and present the launcher. Capabilities the user\'s role does not permit shall not be listed. A user shall be able to reset their own password without administrator involvement, receiving a strong temporary credential by e-mail; the response shall be identical whether or not the address is recognised, so that the mechanism cannot be used to discover valid accounts. Anonymous visitors shall reach only the defined read-only and storage-free tools.',
                'dependencies': 'Traces to BR-1. Precondition for every other functional requirement. Depends on the mail relay for password reset.',
            }},
            {'fields': {
                'title': 'Enforce authorisation server-side on every state-changing request',
                'priority': 'Must',
                'description': 'The system shall evaluate the signed-in user\'s role, project membership and record ownership when a state-changing request is handled, and shall refuse the request if any check fails, irrespective of what the user interface offered.',
                'rationale': 'Hiding a control in the interface is a usability measure, not a security control. A request crafted directly against the endpoint must be refused on the same basis, or the role model is decorative.',
                'detail': 'On receipt of a create, update or delete request, the system shall identify the acting user from the session, resolve their role and their membership of the affected project or group, and confirm ownership for any per-item route. Where the check fails the system shall refuse the request and record the refusal, and shall not disclose whether the target record exists. The rule applies to every module without exception, including routes reachable by anonymous visitors, which shall be limited to reads and to tools that store nothing.',
                'dependencies': 'Traces to BR-1 and BR-11. Precondition for every other functional requirement that modifies data.',
            }},
            {'fields': {
                'title': 'Calculate the critical path and forecast completion from task dependencies',
                'priority': 'Must',
                'description': 'The system shall calculate, from the recorded tasks and their dependencies, the earliest and latest start and finish for each task, the resulting float, the critical path, and the forecast project completion date, and shall recalculate whenever a task or dependency changes.',
                'rationale': 'Deriving the schedule is the mechanism by which reporting becomes a by-product of the work rather than a separate exercise, which is the point of BR-2.',
                'detail': 'The calculation shall use the recorded durations, dependencies and calendar. Tasks with zero float shall be identified as critical and shown distinctly. Where a dependency cycle is recorded the system shall report the cycle rather than fail silently or loop. Progress recorded against a task shall feed the project percentage complete. Where a baseline exists, variance between the current and baselined dates shall be shown. Recalculation shall be immediate on change, so that a user never sees a schedule inconsistent with the tasks in front of them.',
                'dependencies': 'Traces to BR-2. Feeds FR-17, since a task allocation is the time-and-materials contract.',
            }},
            {'fields': {
                'title': 'Record a named stage-gate sign-off that cannot later be altered anonymously',
                'priority': 'Must',
                'description': 'The system shall allow a nominated lead of a project to sign off the gate at the end of a delivery stage, and shall record that sign-off permanently with the person, the stage and the date.',
                'rationale': 'Stage approvals currently happen in meetings and leave no durable record, so governance cannot be evidenced at audit and there are recurring disputes over what was agreed and by whom.',
                'detail': 'Only a member of the project holding the lead role shall be able to sign off a gate; the system shall refuse the action for any other user. Once recorded, the sign-off shall show the person\'s name, the stage and the date, and shall not be editable in a way that loses the original attribution. Where a stage has not been signed off, the system shall show the gate as outstanding rather than silently allowing the project to be reported complete. A departed lead\'s recorded sign-off shall continue to display their name, while their disabled account can no longer sign off anything further.',
                'dependencies': 'Traces to BR-2. Depends on FR-2 for the membership and role check, and on FR-15 for the attribution rule.',
            }},
            {'fields': {
                'title': 'Execute registered checks on schedule, exactly once, and store the result',
                'priority': 'Must',
                'description': 'The system shall execute each registered health and file-arrival check at its configured interval, store the outcome with a timestamp and the response detail, and shall guarantee that each scheduled execution occurs exactly once regardless of how many web workers are running.',
                'rationale': 'Duplicate execution produces duplicate alerts and duplicate history, which erodes trust in the alerting faster than missing a check would. Exactly-once execution is therefore a requirement, not an implementation detail.',
                'detail': 'Checks shall be read-only against the target and shall apply a bounded timeout so that an unresponsive target cannot block the sweep. Connections opened for a check shall always be closed. The outcome shall distinguish success, target failure and check failure, so that a credential or reachability problem in the platform is not reported as an outage of the target. For expected file transfers, the check shall confirm arrival within the defined window and shall honour the maintained exclusion rules rather than requiring the check to be switched off. Results shall be retained as history for trend display. Scheduling shall be owned by exactly one process.',
                'dependencies': 'Traces to BR-3. Feeds FR-6 for alerting and FR-18 for purging.',
            }},
            {'fields': {
                'title': 'Alert the owning team on check failure, missed file arrival and approaching certificate expiry',
                'priority': 'Must',
                'description': 'The system shall send an e-mail to the team that owns the affected item when a check fails, when an expected file does not arrive within its window, or when a certificate reaches its configured warning lead time.',
                'rationale': 'Detection has no value unless it reaches a person who can act. Reaching the owning team rather than a general mailbox is what turns a detected failure into a resolved one.',
                'detail': 'The message shall identify the affected target or certificate, the nature and time of the event, and the owning team, and shall state clearly whether the target failed or the check itself failed, so that a platform credential problem is not investigated as an application outage. Certificate warnings shall be sent at a lead time the security team can configure. Where several related events occur together, the system shall aggregate them into a digest rather than sending one message per event, so that a broad failure does not produce alert fatigue. All messages shall use a single consistent format across every module.',
                'dependencies': 'Traces to BR-3 and BR-5. Depends on FR-5 for the detection and on relay availability, recorded as assumption A-2.',
            }},
            {'fields': {
                'title': 'Maintain, search and export the application system of record',
                'priority': 'Must',
                'description': 'The system shall hold one authoritative record per application, covering its servers, support tower, contacts, interfaces and dependencies, and shall make that record searchable by partial term and exportable as a formatted document and spreadsheet.',
                'rationale': 'On call, the cost of fragmented application knowledge is measured in minutes of outage. A single searchable record removes the dependence on reaching a specific individual.',
                'detail': 'Applications shall be grouped into support towers, each with an owning team. Data entry shall offer type-ahead selection from existing servers, teams and users, with related fields such as location and operating system completed automatically, so that free text does not fragment the register. Search shall accept a partial term and return matching applications, servers and teams. A profile and a whole tower shall each be exportable as a formatted document and spreadsheet for offline and audit use. Records shall retain their contributors so that data ownership is visible.',
                'dependencies': 'Traces to BR-4. Depends on application owners maintaining the data, recorded as assumption A-3. Feeds FR-8.',
            }},
            {'fields': {
                'title': 'Generate the estate architecture view from recorded interfaces',
                'priority': 'Should',
                'description': 'The system shall derive and display a visual view of the application estate from the interfaces recorded against applications, and shall make that view available for download.',
                'rationale': 'A separately drawn architecture diagram drifts from reality the moment it is saved. Generating the view from the register guarantees that what is shown is what is recorded.',
                'detail': 'The view shall show applications as nodes and recorded interfaces as connections between them, including connections to named external parties. It shall be regenerated on demand from current data rather than stored as a picture, so that adding an interface to a profile is immediately reflected. The view shall be downloadable in a form suitable for inclusion in a document or presentation. Where an application has no recorded interfaces it shall still appear, so that gaps in the register are visible rather than hidden.',
                'dependencies': 'Traces to BR-4. Depends entirely on FR-7 for its data; the view has no separate data entry.',
            }},
            {'fields': {
                'title': 'Publish and update live application status during a major incident',
                'priority': 'Should',
                'description': 'The system shall present the business-critical application list with a current status that a nominated responder can update immediately, showing every viewer the same position together with the time each status was set.',
                'rationale': 'Status gathered by telephone and circulated by e-mail is stale on arrival and produces a different version for every recipient, which is precisely the wrong condition during a major incident.',
                'detail': 'A responder shall be able to set an application\'s status from a defined set covering at least healthy, degraded and unavailable, with an optional note. The view shall be readable at a glance by stakeholders who are not operating the incident, and shall display when each status was last set so that its currency is self-evident. Status changes during the event shall be retained for the post-incident review. Setting status shall be restricted to nominated responders while viewing shall be open to all signed-in users.',
                'dependencies': 'Traces to BR-8. Depends on FR-7 for the application list. Informed by, but not driven by, the automated results of FR-5.',
            }},
            {'fields': {
                'title': 'Analyse an uploaded ticket export into a summary and distributable spreadsheet',
                'priority': 'Should',
                'description': 'The system shall accept an exported service-desk extract, analyse it offline, and produce both an on-screen summary and a multi-sheet spreadsheet suitable for circulation by e-mail without further editing.',
                'rationale': 'Manual analysis is done rarely and inconsistently, so recurring causes go unnoticed and management reporting stays reactive rather than directed.',
                'detail': 'The system shall accept the extract as an uploaded file within the configured size limit and validate its structure before processing, reporting a clear error where the format is not recognised. Incidents and service requests shall be treated as distinct report types, because their shape and their management meaning differ. Output shall include volume and trend by the dimensions management reports on, and shall be available as a consolidated e-mail with the spreadsheet attached. No ticket text shall be transmitted to any service outside the corporate network.',
                'dependencies': 'Traces to BR-9. Depends on a stable export format, recorded as assumption A-4, and on FR-16 for the residency constraint. Uses FR-17 for execution.',
            }},
            {'fields': {
                'title': 'Scan submitted source, retain triage decisions and express a quality gate',
                'priority': 'Should',
                'description': 'The system shall analyse source submitted as an archive, a path or a repository reference, report findings by severity and category with file and line references, retain the triage decision recorded against each finding, and express an overall pass or fail against a configurable threshold.',
                'rationale': 'Assurance only changes behaviour when it produces a decision. Persisting triage is what makes repeat scanning affordable, and a stated gate is what makes the result actionable at release.',
                'detail': 'Findings shall carry the rule, severity, category, file and line. A finding triaged as a false positive or an accepted risk shall not be re-raised for triage on a subsequent scan of the same code, and each decision shall retain the person and date. The gate shall compare the outstanding confirmed findings against a threshold configurable per project and state pass or fail. Results shall be exportable both as a readable report for the release record and in a standard interchange format for consumption by other tooling. Where only reduced analysis is available for a submitted language, the system shall state the reduced coverage rather than present a clean result. A build pipeline shall be able to submit results through an interface so that pipeline and interactive findings appear together.',
                'dependencies': 'Traces to BR-6. Uses FR-17 for execution and depends on FR-16 for on-premise operation. Remediation is out of scope.',
            }},
            {'fields': {
                'title': 'Record weekly time privately and derive utilisation against leave-aware capacity',
                'priority': 'Must',
                'description': 'The system shall calculate utilisation as recorded hours against available capacity, where capacity accounts for the standard working day, public holidays and recorded leave, and shall display a compliance indicator where expected time entries are missing.',
                'rationale': 'Utilisation calculated against a naive calendar overstates available capacity and understates utilisation, producing figures that cannot be defended. Showing missing entries separately prevents an incomplete timesheet being read as low utilisation.',
                'detail': 'The system shall compute capacity from the configured standard day, the holiday calendar and recorded leave for the period. Utilisation shall be presented for an individual, a team and the whole function, with drill-down between them. Where a user has not recorded time for a period, the system shall show that as a compliance gap rather than silently treating it as zero utilisation. Individual timesheet narrative shall remain private to the entering user; managers shall see aggregated figures only. The result shall be exportable as a formatted spreadsheet with the data-quality position visible in the export.',
                'dependencies': 'Traces to BR-7. Depends on the holiday calendar and workforce settings being maintained by an administrator.',
            }},
            {'fields': {
                'title': 'Consume a task allocation as the time-and-materials contract and flag extended work',
                'priority': 'Must',
                'description': 'The system shall treat a project task allocation as the time-and-materials commitment, consume it with the hours logged against that task, and identify clearly where work continues beyond the allocated volume.',
                'rationale': 'Maintaining a separate commercial allocation alongside the project plan guarantees the two will diverge. Deriving the commitment from the plan itself is the only way to keep the commercial position honest without re-keying.',
                'detail': 'The allocation shall be derived from the task\'s planned working days converted at the standard working day, requiring no separate entry. Consumption shall be the hours recorded in the timesheet against that task. The register shall show, per allocation, the committed volume, the consumed volume and the remainder, and shall mark as extended any work continuing after the allocation is exhausted rather than silently absorbing it. Managers shall see the register across the projects they are entitled to view; the underlying individual timesheet narrative shall remain private. The register shall be exportable as a formatted spreadsheet for the commercial process.',
                'dependencies': 'Traces to BR-7 and BR-2. Depends on FR-3 for the task plan and FR-12 for the recorded hours.',
            }},
            {'fields': {
                'title': 'Render a governed template to a formatted Word document and provide a worked sample',
                'priority': 'Must',
                'description': 'The system shall render the administrator-curated master template, together with the author\'s content, into a formatted Word document containing a cover page, document control, a navigable contents list, running header and footer, and print-grade tables.',
                'rationale': 'A generated document that requires manual reformatting before it can be circulated does not remove the effort it was intended to remove.',
                'detail': 'The system shall reproduce the template hierarchy with correct numbering to the depth the template defines, and shall use real heading styles so the document is navigable and its contents list can refresh. Sections the author marks not applicable shall remain in the document with a stated non-applicability note, so that the structure is preserved. Template guidance text shall never appear in the output. Tables shall repeat their header row across pages and shall not split a row across a page break. The file shall carry document properties identifying its type and subject. For each document type the system shall additionally offer a complete worked sample, rendered through this same path so that it cannot diverge from the live template, allowing a first-time author to see the finished article before starting.',
                'dependencies': 'Traces to BR-10. Applies to the exports of FR-3, FR-7, FR-10 and FR-12.',
            }},
            {'fields': {
                'title': 'Disable a user while preserving attribution, and refuse deletion while referenced',
                'priority': 'Must',
                'description': 'The system shall allow an administrator to disable a user account such that sign-in is refused immediately and the person is no longer offered for new assignment, while their name continues to be displayed on every record they created or acted upon.',
                'rationale': 'Removing a person from historical records to remove their access destroys the audit trail. Separating access from attribution is the only way to satisfy both needs.',
                'detail': 'On disablement the system shall refuse subsequent authentication and shall exclude the user from assignment and membership pickers. Lookups that resolve a stored user reference to a display name shall not filter on the active flag, so historical records keep their names. Re-enablement shall restore access without any loss of history. The system shall refuse permanent deletion while the user remains referenced by any record, and shall state the reason for the refusal rather than failing obscurely.',
                'dependencies': 'Traces to BR-11. Interacts with every module that stores a user reference.',
            }},
            {'fields': {
                'title': 'Encrypt every stored credential and operate with no external dependency',
                'priority': 'Must',
                'description': 'The system shall encrypt every integration credential before persisting it, and shall function correctly and completely on a host with no access to any network outside the corporate estate.',
                'rationale': 'Both are standing organisational constraints rather than preferences, and both shape what the rest of the platform is permitted to do, so they are stated as a requirement and tested as one.',
                'detail': 'No credential shall be written in a form readable without the platform encryption key, and none shall appear in a log, an error message or a page rendered back to the browser. Rotation of the encryption key shall not render previously stored credentials unreadable. Every capability, including analytical and code-inspection workloads, shall execute on the estate; the system shall have no runtime dependency on an external service and shall neither fail nor silently degrade when external access is unavailable. Any future proposal to introduce an external dependency shall require a formal change to this baseline.',
                'dependencies': 'Traces to BR-12. Constrains FR-10 and FR-11 in particular. Aligns to constraints C-1 and C-5.',
            }},
            {'fields': {
                'title': 'Run long operations as background jobs with observable state',
                'priority': 'Should',
                'description': 'The system shall execute operations that may exceed a normal request duration - source-code scans, ticket analysis and large report generation - as background jobs with a persisted state record, and shall allow the requesting user to observe progress and retrieve the result when complete.',
                'rationale': 'Performing long work inside the request produces timeouts and, worse, silently stranded work whose state is unknown. A persisted job record makes the outcome observable and recoverable.',
                'detail': 'On submission the system shall create a job record in a queued state and return control to the user immediately. The job shall transition through running to complete or failed, each transition recorded with a timestamp, and a failure shall retain the reason. The user shall be able to see the current state without re-submitting. A restart of the hosting process shall not leave a job appearing to run indefinitely with no way to establish its true state.',
                'dependencies': 'Traces to BR-6 and BR-9. Depends on the scheduling and hosting model described in the High-Level Design.',
            }},
            {'fields': {
                'title': 'Purge monitoring and timesheet history beyond the retention period automatically',
                'priority': 'Should',
                'description': 'The system shall remove monitoring execution history and aged timesheet records once they pass their configured retention period, without requiring any operator action.',
                'rationale': 'Monitoring history and analysis results are the only fast-growing data the platform holds. Bounding them automatically is what allows the storage forecast to hold without an ongoing administrative task that would eventually be forgotten.',
                'detail': 'Retention periods shall be configurable per data type and shall apply to monitoring execution history and to timesheet records beyond the reporting horizon. The purge shall run on a schedule as part of the same single-owner scheduling model as the checks themselves, and shall be idempotent so that an interrupted run may be repeated safely. Records still required for an open reporting period or an unresolved investigation shall not be purged. The purge shall log what it removed so that a subsequent question about missing history has an answer.',
                'dependencies': 'Traces to BR-3 and BR-11. Depends on FR-5 for the scheduling model, and on open issue OI-3 for the agreed periods.',
            }},
        ]},

    _key('Non-Functional Requirements (NFRs)'): {
        'intro': 'Quality attributes and constraints stating how well the solution must perform. Each is expressed measurably.',
        'rows': [
            ('NFR-1', 'Availability', 'Available during business hours, 08:00 to 17:30 Monday to Friday excluding public holidays, with best-effort recovery within the same working day', 'Must'),
            ('NFR-2', 'Performance', 'An interactive page returns within 3 seconds at the expected concurrent load; operations that cannot meet this run as background jobs', 'Must'),
            ('NFR-3', 'Capacity', 'Supports the full function as registered users with up to 10 concurrent active sessions without degradation', 'Must'),
            ('NFR-4', 'Security - transport', 'All access over TLS; plain HTTP requests redirected; no unencrypted path to the application', 'Must'),
            ('NFR-5', 'Security - credentials', 'No integration credential stored in a form that is readable without the platform encryption key', 'Must'),
            ('NFR-6', 'Security - authorisation', 'Every state-changing request authorised server-side; no capability reachable by bypassing the interface', 'Must'),
            ('NFR-7', 'Auditability', 'Material changes recorded with the acting person and timestamp, retained for the life of the record', 'Must'),
            ('NFR-8', 'Data residency', 'No operational, ticket, source or personal data transmitted outside the corporate network', 'Must'),
            ('NFR-9', 'Recoverability', 'Full restore from backup within one working day; recovery point no worse than the previous daily backup', 'Must'),
            ('NFR-10', 'Storage growth', 'Growth bounded by automatic retention purges so that no operator action is needed to keep storage within the sizing forecast', 'Should'),
            ('NFR-11', 'Usability', 'A user familiar with one module can complete a basic task in another without training, through a consistent layout and navigation', 'Should'),
            ('NFR-12', 'Accessibility', 'Legible at standard corporate display settings, keyboard navigable, and not dependent on colour alone to convey status', 'Should'),
            ('NFR-13', 'Maintainability', 'A new capability can be added as a self-contained module without modifying existing modules', 'Should'),
            ('NFR-14', 'Portability', 'Runs on the interpreter version present on the target estate, verified by an automated check', 'Must'),
            ('NFR-15', 'Supportability', 'Failures produce a logged, correlatable diagnostic without exposing internal detail to the user', 'Must'),
        ]},

    _key('Use Cases & Scenarios'): {
        'intro': 'The significant interactions between an actor and the system, with their data, main flow and exception behaviour.',
        'blocks': [
            {'fields': {
                'title': 'Project manager plans and governs a delivery project',
                'actor': 'Project Manager',
                'goal': 'Create a project, establish its governance and plan, and have status and the critical path maintained automatically thereafter, so that reporting requires no separate compilation.',
                'priority': 'Must',
             },
             'tables': {
                'data_fields': [
                    ['Project name', 'Unique name identifying the delivery'],
                    ['Project type', 'Governed delivery or simple work, determining whether stage governance applies'],
                    ['Delivery method', 'Waterfall or Agile, recommended by the questionnaire and confirmed by the manager'],
                    ['Applicable stages', 'The subset of method stages that apply to this delivery; at least one required'],
                    ['Team members and roles', 'The people who may edit, and which of them are leads able to sign off gates'],
                    ['Tasks', 'Name, owner, planned start and finish, duration and dependencies'],
                    ['Milestones', 'Generated from the applicable stages, plus any added manually'],
                    ['Baseline', 'A captured snapshot of the plan against which variance is reported'],
                ],
                'main_flow': [
                    ['1', 'Selects create project and enters the name and description', 'Presents the project type choice and the governance questionnaire'],
                    ['2', 'Answers the questionnaire and confirms the recommended method', 'Recommends Waterfall or Agile and presents the applicable-stage picker with all stages selected'],
                    ['3', 'Confirms the applicable stages and adds team members with their roles', 'Creates the project, generates a milestone per applicable stage and records the manager as owner'],
                    ['4', 'Adds tasks with owners, durations and dependencies', 'Calculates the critical path, float and forecast completion, and updates the board and schedule views'],
                    ['5', 'Baselines the plan once agreed', 'Captures the baseline snapshot and begins reporting variance against it'],
                    ['6', 'Team members progress their tasks during delivery', 'Recalculates progress, status and the critical path, and records each change in the activity log'],
                    ['7', 'At the end of a stage, asks the named lead to sign off the gate', 'Records the sign-off with the person and date, and marks the gate satisfied'],
                    ['8', 'Exports the status report for the reporting cycle', 'Produces the formatted document and spreadsheet from current project data'],
                ],
                'alt_flows': [
                    ['A1', 'The manager selects simple work rather than governed delivery at step 1', 'Stage governance is not applied; the manager defines milestones and tasks manually and no gates are required'],
                    ['A2', 'A dependency cycle is recorded at step 4', 'The system reports the cycle and identifies the tasks involved; the schedule is not recalculated until the cycle is removed'],
                    ['A3', 'A non-member attempts to edit the project', 'The request is refused server-side and the refusal is logged; the interface offers read-only access'],
                    ['A4', 'The lead who should sign off a gate has left the organisation', 'The disabled account cannot sign off; the manager nominates a current lead, and the prior history retains the departed person\'s name'],
                    ['A5', 'The plan changes materially after baselining', 'Variance against the baseline is reported; a re-baseline is a deliberate action that retains the previous baseline for comparison'],
                ],
             }},
            {'fields': {
                'title': 'Support engineer investigates an alerted health-check failure',
                'actor': 'Application Support engineer',
                'goal': 'Move from an alert e-mail to an informed diagnosis, establishing what failed, since when, what else it affects and who owns it, without telephoning colleagues.',
                'priority': 'Must',
             },
             'tables': {
                'data_fields': [
                    ['Alert message', 'The target, the check type, the failure detail and the time of failure'],
                    ['Check history', 'Previous results for the same target, showing whether this is new or recurring'],
                    ['Application profile', 'The application the target belongs to, its servers, interfaces and dependencies'],
                    ['Support tower', 'The team that owns the application and its contacts'],
                    ['Related monitoring', 'Other checks and expected file arrivals for the same application'],
                ],
                'main_flow': [
                    ['1', 'Receives the alert e-mail and opens the platform', 'Presents the health dashboard with the failing target highlighted'],
                    ['2', 'Opens the failing check', 'Shows the failure detail, distinguishing a target failure from a check failure, and the history for the target'],
                    ['3', 'Reviews the history to establish whether the failure is new or recurring', 'Charts previous results over the retained period'],
                    ['4', 'Opens the application profile from the target', 'Shows the servers, support tower, interfaces and dependencies for that application'],
                    ['5', 'Checks related monitoring and expected file arrivals for the same application', 'Shows the current state of the related checks so the blast radius is visible'],
                    ['6', 'Contacts the owning team recorded on the profile and records the outcome', 'Retains the profile contact detail and the check history for the post-incident review'],
                ],
                'alt_flows': [
                    ['A1', 'The failure detail indicates a credential or reachability problem in the platform, not the target', 'The result is classified as a check failure; the engineer corrects the stored credential rather than raising an incident against the application'],
                    ['A2', 'The application has no profile in the register', 'The engineer creates the profile using type-ahead selection for servers and teams, so that the next investigation is faster'],
                    ['A3', 'The check has been failing for an accepted reason', 'The engineer records an exclusion rule so the alert stops without disabling the check entirely'],
                    ['A4', 'Multiple applications are failing simultaneously', 'The engineer escalates to the incident manager, who publishes live status for the affected applications'],
                ],
             }},
            {'fields': {
                'title': 'Delivery lead obtains assurance over a release',
                'actor': 'Delivery Lead',
                'goal': 'Obtain an objective, recorded quality and security assessment of the code about to be released, and attach the result to the release record.',
                'priority': 'Should',
             },
             'tables': {
                'data_fields': [
                    ['Submission', 'The source archive, path or repository reference being assessed'],
                    ['Project', 'The project the submission belongs to, so that results accumulate over time'],
                    ['Findings', 'Rule, severity, category, file and line for each issue detected'],
                    ['Triage decision', 'Confirmed, false positive or accepted risk, with the person and date'],
                    ['Gate result', 'The overall pass or fail against the configured threshold'],
                ],
                'main_flow': [
                    ['1', 'Submits the source for the release', 'Creates a background job in a queued state and returns control immediately'],
                    ['2', 'Observes the job progressing', 'Reports the job as running and then complete, with the duration recorded'],
                    ['3', 'Reviews the findings by severity and category', 'Presents the findings with file and line references and prior triage decisions already applied'],
                    ['4', 'Triages the new findings as confirmed, false positive or accepted risk', 'Retains each decision with the person and date so the finding is not re-raised at the next scan'],
                    ['5', 'Reads the overall gate result', 'Reports pass or fail against the configured threshold for the project'],
                    ['6', 'Exports the report for the release record', 'Produces the readable report and the standard interchange format'],
                ],
                'alt_flows': [
                    ['A1', 'The gate fails', 'The release does not proceed; confirmed findings are raised as work for the owning team and the scan is repeated after remediation'],
                    ['A2', 'The scan fails part-way through', 'The job is recorded as failed with the reason retained; no partial result is presented as complete'],
                    ['A3', 'The submission uses a language for which only reduced analysis is available', 'The scan completes with the reduced rule set and states the reduced coverage, rather than reporting a clean result'],
                    ['A4', 'The result arrives from the build pipeline rather than an interactive submission', 'The findings are recorded against the same project and appear alongside interactive results'],
                ],
             }},
        ]},

    _key('Business Rules'): {
        'intro': 'Constraints and policies the solution must enforce, independent of any single requirement.',
        'rows': [
            ('BRU-1', 'A user account is disabled, never deleted, when a person leaves; permanent deletion is refused while the account remains referenced', 'Data retention', 'FR-15'),
            ('BRU-2', 'A displayed name on a historical record is resolved regardless of whether the account is active', 'Data integrity', 'FR-15'),
            ('BRU-3', 'Exactly one person is accountable for each stage gate, and that sign-off is recorded by name and date', 'Governance', 'FR-4'),
            ('BRU-4', 'A governed project must have at least one applicable delivery stage selected', 'Governance', 'FR-3'),
            ('BRU-5', 'Timesheet narrative is visible only to the person who entered it; managers see aggregates only', 'Privacy', 'FR-12'),
            ('BRU-6', 'A standard working day is eight hours for capacity and allocation purposes', 'Commercial', 'FR-12, FR-13'),
            ('BRU-7', 'Work recorded against a task beyond its planned allocation is classified as extended, not absorbed silently', 'Commercial', 'FR-13'),
            ('BRU-8', 'Monitoring checks are read-only and must never modify the target system', 'Operational safety', 'FR-5'),
            ('BRU-9', 'A scheduled job executes exactly once per scheduled occurrence, regardless of hosting topology', 'Operational safety', 'FR-5, FR-18'),
            ('BRU-10', 'No credential is stored in a readable form; encryption is applied before persistence', 'Security', 'FR-16'),
            ('BRU-11', 'No operational, ticket or source data is transmitted outside the corporate network', 'Security', 'FR-16'),
            ('BRU-12', 'A document section may be marked not applicable but may not be removed from a governed template by its author', 'Governance', 'FR-14'),
            ('BRU-13', 'A triage decision recorded against a finding persists across subsequent scans of the same code', 'Assurance', 'FR-11'),
            ('BRU-14', 'Monitoring history and timesheet records beyond their retention period are purged automatically', 'Data retention', 'FR-18'),
        ]},

    _key('Data Requirements'): {'content': """
This section defines the key data the solution captures and the data movement it requires. Volumes are modest throughout; the significant requirements concern ownership, quality and retention rather than scale.
"""},

    _key('Data Dictionary'): {
        'intro': 'The principal data elements the solution captures, stores or processes.',
        'rows': [
            ('User', 'A person who can sign in, with their role, group, sub-group and team', 'Record', 'Yes', 'Unique username and e-mail address; role from the defined set; active flag'),
            ('Project', 'A unit of delivery work with an owner, type, method and applicable stages', 'Record', 'Yes', 'Unique name; owner must be an active project manager; at least one applicable stage when governed'),
            ('Task', 'A unit of work within a project, with owner, dates, duration and dependencies', 'Record', 'Yes', 'Planned finish on or after planned start; dependencies must not form a cycle'),
            ('Milestone', 'A dated checkpoint, generated from a stage or added manually', 'Record', 'Yes', 'Date within the project window'),
            ('Gate sign-off', 'The named approval of a completed stage', 'Record', 'No', 'Signed by a lead member of the project; person and date immutable once recorded'),
            ('Application', 'An application in the estate, with its description and criticality', 'Record', 'Yes', 'Unique name within its support tower'),
            ('Server', 'A host supporting an application, with location and operating system', 'Record', 'Yes', 'Host name unique; location and operating system from the maintained lists'),
            ('Support tower', 'A grouping of applications under one support team', 'Record', 'Yes', 'Unique name; must have an owning team'),
            ('Interface', 'A recorded connection between two applications or to an external party', 'Record', 'No', 'Source and target must both be recorded applications or a named external party'),
            ('Monitoring target', 'A registered check with its type, connection detail and schedule', 'Record', 'Yes', 'Type from the defined set; schedule interval within the permitted range; credentials stored encrypted'),
            ('Check result', 'The outcome of one execution of a check', 'Record', 'Yes', 'Outcome from success, target failure or check failure; timestamped; purged on retention'),
            ('Expected file', 'A file transfer expected within a defined window', 'Record', 'Yes', 'Source and arrival window required; exclusion rules maintained separately'),
            ('Certificate', 'A certificate with its subject, system, owner, issuer and expiry', 'Record', 'Yes', 'Expiry date required; owner must be a current contact'),
            ('Timesheet entry', 'Hours recorded by a user for a day against an activity or task', 'Numeric', 'Yes', 'Hours greater than zero and not exceeding a daily maximum; date within the open period'),
            ('Allocation', 'The planned effort for a task, acting as the time-and-materials contract', 'Numeric', 'Yes', 'Derived from planned working days multiplied by the standard day'),
            ('Scan', 'One execution of source analysis against a project', 'Record', 'Yes', 'State from queued, running, complete or failed; numbered sequentially within its project'),
            ('Finding', 'One issue detected by analysis, with rule, severity, file and line', 'Record', 'Yes', 'Severity from the defined scale; triage decision optional but retained once set'),
            ('Document', 'A file attached to a project or application, with its version trail', 'File', 'No', 'Permitted type and size; sensitive flag restricts visibility to the owner'),
            ('Activity log entry', 'A record of a material change, with actor and timestamp', 'Record', 'Yes', 'Actor resolved regardless of account state; never edited after creation'),
        ]},

    _key('Data Migration & Integration'): {
        'intro': 'Data movement required by the initiative, one row per source-to-target flow.',
        'rows': [
            ('Existing project spreadsheets', 'Project, task and milestone records', 'Open project plans at go-live', 'Manual re-entry by the owning project manager; historical closed projects are archived rather than migrated'),
            ('Existing application inventory spreadsheets', 'Application, server and tower records', 'Application system of record', 'Bulk spreadsheet import followed by owner verification'),
            ('Existing certificate spreadsheet', 'Certificate records', 'Certificate inventory', 'Bulk spreadsheet upload by the security team, replacing the manual register'),
            ('Service-desk platform', 'Incident and service-request extracts', 'Ticket analysis', 'Periodic user-initiated export and upload; no live interface'),
            ('Source repositories and build pipeline', 'Source code and pipeline scan results', 'Code assurance', 'Archive upload, path reference or repository clone; pipeline results posted to the ingest interface'),
            ('Standalone evaluation database', 'All platform records', 'Production database', 'One-off migration preserving keys and referential integrity, run once at production cut-over'),
            ('Utilisation and allocation data', 'Formatted spreadsheet', 'Finance and commercial reporting process', 'Scheduled export; no direct posting into finance systems'),
            ('Monitoring and timesheet history', 'Aged records', 'Deletion', 'Automatic purge beyond the configured retention period'),
        ]},

    _key('Assumptions, Constraints & Dependencies'): {'content': """
The following were taken as true, imposed as fixed, or identified as external to this initiative at the time the baseline was set. Each is to be confirmed before delivery commences and reviewed at each checkpoint.
"""},

    _key('Assumptions'): {
        'intro': 'What has been taken as true in setting this baseline, and the impact if it proves otherwise.',
        'rows': [
            ('A-1', 'Users access the platform from the corporate network only', 'Remote access would require an infrastructure change and a reassessment of the authentication controls before go-live'),
            ('A-2', 'An SMTP relay is available and permits relay from the application host', 'All alerting, digests and password reset would be unavailable, removing the benefit behind OBJ-2'),
            ('A-3', 'Application owners will supply and maintain inventory data for their systems', 'The system of record would be incomplete and BR-4 would not deliver its benefit; monitoring coverage would have gaps'),
            ('A-4', 'The service desk continues to provide extracts in a stable column format', 'Ticket analysis would require rework each time the format changes, reducing the value of BR-9'),
            ('A-5', 'The active user population remains a single team working business hours', 'A larger or 24x7 population would change the availability requirement and the hosting topology'),
            ('A-6', 'Existing host capacity is sufficient; no new hardware is required', 'A hardware request would extend the delivery timeline and introduce cost not currently in the case'),
            ('A-7', 'Source code submitted for analysis may be held on the application host for the duration of a scan', 'Code assurance could not be delivered on premise in its proposed form and BR-6 would need to be re-specified'),
            ('A-8', 'Superseded spreadsheets can be withdrawn once the equivalent module is live', 'Parallel running would continue indefinitely and the effort benefit behind OBJ-1 would not be realised'),
        ]},

    _key('Constraints'): {
        'intro': 'Fixed limitations within which the solution must be delivered.',
        'rows': [
            ('C-1', 'The solution must be on-premise; no cloud or software-as-a-service component is permitted', 'Regulatory and policy'),
            ('C-2', 'Hosting must use the existing Windows and IIS estate', 'Technology'),
            ('C-3', 'Delivery is by the existing internal team within its current capacity; no additional headcount', 'Resource'),
            ('C-4', 'No licence or subscription cost may be incurred', 'Budget'),
            ('C-5', 'The platform must function on a host with no internet access', 'Technology and security'),
            ('C-6', 'The service level is business hours; no 24x7 support commitment is made', 'Operational'),
            ('C-7', 'Some target hosts run an older runtime version than the development environment', 'Technology'),
            ('C-8', 'Single sign-on cannot be delivered until the identity provider programme completes', 'Time and external dependency'),
        ]},

    _key('Dependencies'): {
        'intro': 'External deliverables and decisions this initiative relies upon.',
        'rows': [
            ('D-1', 'Windows host with IIS, the runtime and database drivers installed', 'Infrastructure', 'Before development environment sign-off'),
            ('D-2', 'TLS certificate issued for the application host name', 'Infrastructure', 'Before first deployment to a shared environment'),
            ('D-3', 'Production relational database instance provisioned with backup in place', 'Database team', 'Before production cut-over'),
            ('D-4', 'SMTP relay permission from the application host', 'Infrastructure', 'Before monitoring go-live'),
            ('D-5', 'Service accounts and credentials for every monitored target', 'Application owners', 'Before each monitoring target is registered'),
            ('D-6', 'Security control baseline reviewed and signed off', 'Security team', 'Before production go-live'),
            ('D-7', 'Nomination of data owners for the application, certificate and file-flow registers', 'Business owner', 'Before the corresponding module goes live'),
            ('D-8', 'Corporate identity provider integration for single sign-on and multi-factor authentication', 'Security and identity', 'Future release; not required for this baseline'),
        ]},

    _key('Risk Assessment'): {
        'intro': 'Risks to the delivery and adoption of this initiative. Every high and medium risk carries an owner and a response.',
        'rows': [
            ('R-1', 'Users continue using existing spreadsheets in parallel, so the effort benefit is not realised',
             'High', 'High',
             'Withdraw the superseded artefact as each module goes live; sponsor mandates use; measure residual usage at each checkpoint',
             'Business Owner'),
            ('R-2', 'Inventory data is not supplied or maintained by application owners, leaving the system of record incomplete',
             'Medium', 'High',
             'Name a data owner per tower before go-live; seed from existing spreadsheets; report completeness on the dashboard so gaps are visible',
             'Application Support'),
            ('R-3', 'Delivery capacity is diverted to operational demand, extending the timeline',
             'High', 'Medium',
             'Deliver incrementally by module so that value lands early; agree protected capacity with the sponsor at each planning cycle',
             'Delivery Manager'),
            ('R-4', 'Security sign-off is not obtained in time for production go-live',
             'Medium', 'High',
             'Engage the security team at design stage rather than at the end; complete the baseline checklist alongside development',
             'Security team'),
            ('R-5', 'Alert volume causes fatigue and alerts are ignored',
             'Medium', 'High',
             'Distinguish check failures from target failures; provide exclusion rules rather than requiring checks to be disabled; aggregate into digests',
             'Application Support'),
            ('R-6', 'Timesheet compliance is poor, undermining utilisation reporting',
             'High', 'Medium',
             'Show compliance as a distinct signal rather than as low utilisation; keep entry quick; sponsor sets the expectation',
             'Resource Managers'),
            ('R-7', 'Infrastructure dependencies are delivered late, delaying environments',
             'Medium', 'Medium',
             'Raise requests at baseline approval; track as named dependencies with agreed need-by dates',
             'Platform Engineering'),
            ('R-8', 'Static-analysis findings overwhelm teams on first use and the gate is bypassed',
             'Medium', 'Medium',
             'Baseline existing findings on first scan and gate on new findings; triage decisions persist so effort is not repeated',
             'Delivery Manager'),
            ('R-9', 'The absence of single sign-on is treated as a blocker by the security review',
             'Low', 'High',
             'Agree the compensating controls and the interim position with security before build; record identity-provider integration as a committed follow-on',
             'Security team'),
            ('R-10', 'Key knowledge concentrates in the small delivery team',
             'Medium', 'Medium',
             'Maintain the design, user and operations documentation as deliverables rather than afterthoughts; pair on each module',
             'Platform Engineering'),
        ]},

    _key('Cost-Benefit Analysis'): {
        'intro': 'Indicative financial position over three years. Costs are internal effort only; there is no licence, subscription or hardware cost. Figures are indicative and to be confirmed with finance.',
        'rows': [
            ('Build effort (internal delivery)', 'High', 'Low', 'Low'),
            ('Operate and support effort (internal)', 'Low', 'Low', 'Low'),
            ('Software licence and subscription cost', 'Nil', 'Nil', 'Nil'),
            ('Hardware and hosting (existing estate)', 'Nil', 'Nil', 'Nil'),
            ('Benefit - reporting and status compilation effort recovered', 'Partial', 'Full', 'Full'),
            ('Benefit - incidents avoided through earlier detection', 'Partial', 'Full', 'Full'),
            ('Benefit - defensible utilisation and commercial reporting', 'Partial', 'Full', 'Full'),
            ('Benefit - audit and governance evidence produced as a by-product', 'Partial', 'Full', 'Full'),
        ]},

    _key('Financial Metrics'): {
        'intro': 'Headline financial measures for the initiative.',
        'rows': [
            ('Total cost of ownership over three years', 'Internal delivery and support effort only; no external spend'),
            ('Payback period', 'Expected within the second year, driven by recovered reporting effort and avoided incidents'),
            ('Return on investment', 'To be confirmed by finance once effort baselines are agreed'),
            ('Net present value', 'To be confirmed by finance; benefit is predominantly effort recovery and risk reduction rather than revenue'),
            ('Cost avoidance', 'Equivalent commercial tooling for delivery management, monitoring and code analysis, which the on-premise constraint rules out in any case'),
            ('Principal financial risk', 'Delivery capacity diverted to operational demand, extending the payback period'),
        ]},

    _key('Acceptance Criteria'): {
        'intro': 'The objective conditions under which the business will accept the delivered solution, expressed in Given, When, Then form. Each acceptance criterion corresponds to the functional requirement of the same number.',
        'rows': [
            ('AC-1', 'Given a registered user with a defined role, when they sign in, then they reach the launcher and see only the capabilities their role permits', 'FR-1'),
            ('AC-2', 'Given a user without rights to a record, when they submit a change request directly to the endpoint, then the request is refused and the refusal is logged', 'FR-2'),
            ('AC-3', 'Given a project with dependent tasks, when a task duration changes, then the critical path and forecast completion are recalculated and shown without manual action', 'FR-3'),
            ('AC-4', 'Given a completed stage, when a named lead signs off the gate, then the sign-off is recorded with the person and date and cannot be altered anonymously', 'FR-4'),
            ('AC-5', 'Given a registered check, when its schedule elapses, then exactly one execution occurs and its result is stored with a timestamp', 'FR-5'),
            ('AC-6', 'Given a check that fails or a certificate reaching its warning lead time, when the event is recorded, then an e-mail reaches the owning team stating whether the target or the check failed', 'FR-6'),
            ('AC-7', 'Given a partial search term, when a user searches the register, then matching applications, servers and teams are returned and a profile can be exported', 'FR-7'),
            ('AC-8', 'Given recorded interfaces, when a user opens the architecture view, then the diagram is generated from those records rather than from a separately maintained drawing', 'FR-8'),
            ('AC-9', 'Given a major incident, when a responder updates an application status, then all viewers see the new status with the time it was set', 'FR-9'),
            ('AC-10', 'Given an uploaded ticket export, when analysis completes, then an on-screen summary and a multi-sheet spreadsheet are produced and can be circulated by e-mail', 'FR-10'),
            ('AC-11', 'Given submitted source, when the scan completes, then findings are listed by severity with file and line, prior triage decisions are not re-raised, and a pass or fail result is stated', 'FR-11'),
            ('AC-12', 'Given a period containing a public holiday and recorded leave, when utilisation is calculated, then capacity excludes both, missing entries show as a compliance gap, and no other user sees the entry narrative', 'FR-12'),
            ('AC-13', 'Given hours logged against a task beyond its allocation, when the allocation register is viewed, then the excess is identified as extended work', 'FR-13'),
            ('AC-14', 'Given a completed document, when it is exported, then the Word file contains a cover, document control, a navigable contents list, running header and footer and no template guidance text; and a worked sample of that document type can be downloaded', 'FR-14'),
            ('AC-15', 'Given a disabled user, when a historical record they created is viewed, then their name is still displayed, sign-in is refused, and permanent deletion is refused with the reason stated', 'FR-15'),
            ('AC-16', 'Given a stored credential, when the database is inspected directly, then the value is not readable without the platform encryption key; and given a host with no internet access, when any module is exercised, then it functions without error or degraded result', 'FR-16'),
            ('AC-17', 'Given a long-running operation, when it is submitted, then control returns immediately and its state can be observed through to completion or failure', 'FR-17'),
            ('AC-18', 'Given history beyond the retention period, when the purge runs, then those records are removed without operator action and the removal is logged', 'FR-18'),
        ]},

    _key('Requirements Traceability Matrix (RTM)'): {
        'intro': 'Traces each requirement from business objective through to test coverage, confirming that nothing is lost and nothing is delivered that was not asked for.',
        'rows': [
            ('OBJ-1', 'BR-1', 'FR-1, FR-2', 'UC-1, UC-2, UC-3', 'AC-1, AC-2', 'TC-001 to TC-012'),
            ('OBJ-3', 'BR-2', 'FR-3, FR-4, FR-13', 'UC-1', 'AC-3, AC-4, AC-13', 'TC-020 to TC-038'),
            ('OBJ-2', 'BR-3', 'FR-5, FR-6, FR-18', 'UC-2', 'AC-5, AC-6, AC-18', 'TC-040 to TC-058'),
            ('OBJ-1', 'BR-4', 'FR-7, FR-8', 'UC-2', 'AC-7, AC-8', 'TC-060 to TC-072'),
            ('OBJ-2', 'BR-5', 'FR-6', 'UC-2', 'AC-6', 'TC-080 to TC-088'),
            ('OBJ-4', 'BR-6', 'FR-11, FR-17', 'UC-3', 'AC-11, AC-17', 'TC-090 to TC-110'),
            ('OBJ-5', 'BR-7', 'FR-12, FR-13', 'UC-1', 'AC-12, AC-13', 'TC-120 to TC-138'),
            ('OBJ-2', 'BR-8', 'FR-9', 'UC-2', 'AC-9', 'TC-140 to TC-146'),
            ('OBJ-3', 'BR-9', 'FR-10, FR-17', 'UC-3', 'AC-10, AC-17', 'TC-150 to TC-160'),
            ('OBJ-3', 'BR-10', 'FR-14', 'UC-1', 'AC-14', 'TC-170 to TC-182'),
            ('OBJ-6', 'BR-11', 'FR-15, FR-2, FR-18', 'UC-1', 'AC-15, AC-2, AC-18', 'TC-190 to TC-200'),
            ('OBJ-7', 'BR-12', 'FR-16', 'UC-3', 'AC-16', 'TC-210 to TC-220'),
            ('OBJ-1', 'BR-13', 'FR-2', 'UC-2', 'AC-2', 'TC-230 to TC-238'),
        ]},

    _key('Appendices'): {'content': """
Supporting material referenced from the body of this document. Each item is held with the business analysis pack and is available to reviewers on request.
"""},

    _key('Process Flow Diagrams'): {'content': """
The following process maps support the current-state and future-state analysis in this document and should be read alongside it.
- As-Is delivery process: plan creation, manual status compilation and stage approval outside any system.
- To-Be delivery process: questionnaire to method, stages to milestones, task execution with derived critical path, named gate sign-off, exported reporting.
- As-Is monitoring process: individually authored scripts, uneven coverage and silent failure.
- To-Be monitoring process: target registration, scheduled sweep by a single owner, result storage, alerting and retention purge.
- To-Be incident status process: responder updates status, stakeholders consume the live view, history retained for post-incident review.
- To-Be workforce process: weekly time entry, allocation as contract, derived utilisation with a compliance signal.
Diagrams are maintained in the business analysis pack; the platform additionally generates the estate architecture view directly from recorded interfaces, so that view is not duplicated here.
"""},

    _key('Wireframes / Mock-ups'): {'content': """
Interface concepts prepared during requirements elaboration, all subject to design refinement and not themselves part of the requirements baseline.
- Launcher: capability tiles filtered by the signed-in user's role.
- Project workspace: tabbed layout across plan, board, schedule, risks, documents and activity.
- Health dashboard: target list with status, last-checked time and trend, with drill-down to history.
- Application profile: one page carrying servers, support tower, interfaces and dependencies, with export actions.
- Utilisation dashboard: drill-down from function to team to individual, with the compliance signal shown separately from utilisation.
- Document builder: the governed section tree on the left with the authoring pane on the right, and required or not-applicable toggles per section.
"""},

    _key('Supporting Analysis'): {'content': """
- Effort baseline supporting the cost-benefit position, prepared with the delivery team and pending finance confirmation.
- Current-state tooling inventory: the spreadsheets, scripts and mailboxes in routine use at baseline, with their owners, used to size the consolidation scope and to plan withdrawal.
- Incident sample analysis: a review of incidents over the preceding period that automated monitoring or certificate warning would plausibly have prevented, supporting objective OBJ-2.
- Reporting effort study: measured time spent compiling delivery status per reporting cycle, supporting objective OBJ-3.
- Options appraisal: commercial and software-as-a-service alternatives assessed and discounted against the on-premise constraint recorded as C-1.
"""},

    _key('Open Issues / Parking Lot'): {
        'intro': 'Unresolved questions to be settled before or during delivery. Each carries an owner and a current status.',
        'rows': [
            ('OI-1', 'Confirm the production database platform between SQL Server and PostgreSQL', 'Database team', 'Open'),
            ('OI-2', 'Ratify formal recovery time and recovery point objectives with the business owner', 'Business Owner', 'Open'),
            ('OI-3', 'Agree the retention period for monitoring history and analysis findings', 'Application Support', 'Open'),
            ('OI-4', 'Confirm the quality-gate threshold and whether existing findings are baselined on first scan', 'Delivery Manager', 'Open'),
            ('OI-5', 'Agree the certificate expiry warning lead time and the escalation path', 'Security team', 'Open'),
            ('OI-6', 'Determine whether utilisation reporting is exported to finance or consumed in the platform only', 'Resource Managers', 'Open'),
            ('OI-7', 'Confirm the sequence in which modules are delivered and superseded artefacts withdrawn', 'Business Owner', 'Open'),
            ('OI-8', 'Establish the timeline for identity provider integration and the interim security position', 'Security and identity', 'Deferred to a future release'),
        ]},
}




# ===========================================================================
# SSIA - App Assist System Security Impact Assessment
#
# The screening answers and the questionnaire answers describe ONE consistent
# security position (on-premise, corporate LAN only, no cloud, no Internet
# exposure, personnel data processed, local session authentication). Keep them
# in step - an assessment that contradicts itself is the one defect a
# reference document must never demonstrate.
#
# Each questionnaire entry is a single table ROW, not narrative: the pro-forma
# renders it as a response classification beside the supporting detail, and
# the sample has to go through the same shape to be a faithful example.
# ===========================================================================

def _answer(response, detail):
    """One questionnaire entry: a response classification and its detail."""
    return {'rows': [(response, detail)]}


SAMPLE_SSIA = {

    # -- 1. Initial screening checklist ------------------------------------
    _key('System Security Impact Assessment Initial Screening Checklist'): {'content': """
This screening was completed against the App Assist design at the point the platform entered build. App Assist is an on-premise, browser-based platform that consolidates the tools an IT operations and delivery team uses every day - project management, application support records, health and file monitoring, service-desk analysis, static code analysis, certificate tracking and workforce timesheets - into a single, role-secured web application hosted on the corporate network.
Every answer below is justified in the comments column, and the outcome is stated immediately after the table. The screening is re-run whenever a new module is added, because a module can change the data held or the systems reached even when the hosting model does not.
"""},

    _key('Screening Ownership'): {
        'intro': 'The screening was completed and authorised as follows.',
        'rows': [
            ('Name of Programme / Project / Policy', 'App Assist - IT Operations Delivery Platform'),
            ('Individual completing SIA screening (name)', 'Delivery Lead, Platform Engineering'),
            ('Individual completing SIA screening (role)', 'Solution Architect'),
            ('Date Completed', 'Completed at the design gate, before build sign-off'),
            ('Authorised by', 'IS Security Operations Manager'),
        ]},

    _key('Screening Questions'): {
        'intro': "This checklist should be used by programmes, projects, policy or "
                 "technical development that will touch on security issues. Answering "
                 "'Yes' to any of these questions is an indication that a full SSIA is "
                 "required.",
        'rows': [
            ('1', 'Does the solution access the operational control system (PoF) environment?',
             '', 'N', '', 'No interface connectivity of any kind.'),
            ('2', 'Does the solution access the Smart Metering environment?',
             '', 'N', '', 'No connection, direct or indirect.'),
            ('3', "Is the solution 'cloud' based?",
             '', 'N', '', 'Hosted on-premise on a corporate Windows server.'),
            ('4', 'Will the solution process any sensitive, personal, personnel or financial data?',
             'Y', '', '', 'Personnel data: user accounts, weekly timesheets, leave and utilisation records.'),
            ('5', 'Will the solution be required to accept incoming connections from the Internet?',
             '', 'N', '', 'Reachable from the corporate network only; not published externally.'),
            ('6', 'Will the solution require an outbound connection to the Internet?',
             '', 'N', '', 'No outbound Internet route; all analysis runs offline on the estate.'),
            ('7', 'Will the solution be available to 3rd parties?',
             '', 'N', '', 'Internal use only; no supplier or partner accounts.'),
            ('8', 'Will the solution require users to authenticate?',
             'Y', '', '', 'Yes. Local account sign-in with role-based access control.'),
            ('9', 'Will the solution integrate with Active Directory?',
             '', 'N', '', 'Not in this release; directory integration is a planned future change.'),
            ('10', 'Will the solution require any data exchange with the operational control system, Smart Metering, or non-corporate networks?',
             '', 'N', '', 'All integrations stay within the corporate network.'),
            ('11', 'Will the service be a P1 service?',
             '', 'N', '', 'Internal productivity platform; no operational dependency on it.'),
            ('12', 'Will the service interact with regulatory requirement data feeds?',
             '', 'N', '', 'No regulated feed is consumed or produced.'),
            ('13', 'Will the service provide a regulatory requirement?',
             '', 'N', '', 'The platform supports internal governance, not a regulatory obligation.'),
            ('14', 'Is all authentication and cross-network-boundary traffic encrypted?',
             'Y', '', '', 'TLS for the browser session; encrypted channels to every integration.'),
            ('15', 'Is data encrypted at rest?',
             '', 'N', '', 'Volume-level encryption not applied; integration credentials are encrypted at application level.'),
            ('16', 'Can we carry out an audit of the 3rd party for IT security processes and principles?',
             '', '', 'N/A', 'Built and supported in-house; no third-party supplier involved.'),
            ('17', 'Is there an agreed process the supplier follows should there be a security incident?',
             '', '', 'N/A', 'In-house platform; the corporate incident process applies directly.'),
            ('18', 'Has a penetration test been performed on the solution?',
             '', 'N', '', 'Scheduled before the production deployment gate.'),
        ]},

    _key('Reasons SSIA Is / Is Not Required'): {'content': """
A full System Security Impact Assessment is required. Two screening answers drive that outcome:
- Question 4 - the platform processes personnel data: user accounts, weekly timesheets, leave records and derived utilisation reporting.
- Question 8 - the platform authenticates its users and enforces role-based access control, so the identity and session model is itself a security control that must be assessed.
Questions 14 and 15 do not by themselves require an assessment, but they are answered in full below because the encryption position - encrypted in transit, not encrypted at rest - is the main residual item put to the approver.
"""},

    # -- 2. Detailed assessment --------------------------------------------
    _key('System Security Impact Assessment (SSIA) Detailed Assessment'): {'content': """
App Assist is a single web application, modular by design: each capability is an independent module mounted under one launcher, sharing one sign-in, one database connection layer and one design system. That structure keeps the security surface constant as capabilities are added, because a new module inherits the existing authentication, authorisation and audit behaviour rather than introducing its own.
The sections below set out who assessed the solution, what it is for, how the architecture changes, and where it is deployed.
"""},

    _key('Assessment Ownership'): {
        'intro': 'The detailed assessment was carried out by the following individual.',
        'rows': [
            ('Name of Project / Programme', 'App Assist - IT Operations Delivery Platform'),
            ('Name', 'Solution Architect, Platform Engineering'),
            ('Role', 'Security Architect'),
            ('Section', 'IT Services - Platform Engineering'),
            ('Contact Details', 'Via the Platform Engineering team mailbox'),
        ]},

    _key('Project Aim & Strategic Context'): {'content': """
The operations team relied on disconnected artefacts: project trackers in spreadsheets, monitoring scripts on individual desktops, incident status circulated by e-mail, timesheets kept privately, and application knowledge held in people's heads. The result was duplicated effort, inconsistent formats, single points of knowledge and no shared audit trail.
The purpose of this document is to seek security approval to deploy App Assist onto the corporate estate, bringing those workflows under one roof with a consistent interface and a single security model. The benefits sought are:
- To the business - one governed record of delivery, support and monitoring activity, with a shared audit trail and consistent, exportable reporting.
- To individuals - one place to sign in, one place to record work, and no need to hold operational knowledge personally.
- To Information Security - a single, assessable application boundary in place of an unmanaged spread of desktop scripts and local spreadsheets holding the same data.
The platform is deliberately self-contained: every capability, including the static code analysis and the offline machine learning used to summarise exported service-desk tickets, runs on the corporate network. No data leaves the estate, and there is no dependency on any external service. These changes are implemented while continuing to meet the organisation's security, governance and audit requirements for internal users and system administrators.
"""},

    _key('Architecture Evolution (AS-IS vs TO-BE)'): {
        'intro': 'The change this assessment covers, stated as the current position against the proposed position.',
        'rows': [
            ('Delivery, support and monitoring records held in shared spreadsheets with no access control and no audit trail.',
             'One role-secured web application; every record attributable to a named account and retained on change.'),
            ('Monitoring and alerting scripts run from individual desktops under personal credentials.',
             'All scheduled work runs in exactly one place - a dedicated service account on the application server - never in the web tier.'),
            ('Integration credentials embedded in scripts and spreadsheets in clear text.',
             'Every integration credential encrypted at application level; no plain-text password is written to the database or to disk.'),
            ('Timesheet and utilisation data held privately by individuals and by line managers.',
             'Timesheets recorded in the platform, visible to the individual and to their manager under role-based access control.'),
            ('No single boundary to assess: the same data spread across desktops, mailboxes and file shares.',
             'One application boundary, reachable over TLS from the corporate network only, assessable as a unit.'),
        ]},

    _key('Application Deployment Summary'): {
        'intro': 'The deployment this assessment covers.',
        'rows': [
            ('Scope', 'Deploy the App Assist platform and its scheduled-job service onto a corporate Windows server, replacing the spreadsheets, desktop scripts and mailbox workflows currently used by the operations team.'),
            ('Business Areas', 'IT Delivery, Application Support, Infrastructure, Information Security, Resource Management.'),
            ('Workstream', 'IT Operations tooling consolidation.'),
            ('Total User Base', 'Internal operations and delivery staff only. Role-based access control applied: administrator, project manager, support member and standard member, with guest tools open without an account.'),
            ('Data', 'Project and task records, application support profiles, monitoring results, exported service-desk extracts, certificate inventory, uploaded documents, weekly timesheets and leave records, and the user directory.'),
            ('Integrations', 'Monitored databases (read-only), monitored servers over SSH (read-only command probes), monitored URLs over HTTPS, and the corporate SMTP relay for alerting.'),
        ]},

    _key('Application Environments & URLs'): {
        'intro': 'Every environment the platform is deployed into.',
        'rows': [
            ('Non-Production', 'https://appassist-test.internal', 'On-premise Windows server; delivery team and nominated testers only.'),
            ('Production', 'https://appassist.internal', 'On-premise Windows server (IIS); authenticated internal users, by role.'),
        ]},

    # -- 3. The questionnaire ----------------------------------------------
    _key('Detailed Security Impact Assessment Questions'): {'content': """
Each question below is answered against the App Assist design as assessed. Where a question does not apply, the response says so explicitly and the detail states why, so a reviewer can tell the difference between a control that is absent and a control that is not relevant.
The answers are consistent with the screening table above; where the two would differ, the detailed answer governs and the screening is re-run.
"""},

    _key('Describe the security controls in place for connections to the operational '
         'control system (PoF) environment'): _answer(
        'Not Applicable',
        'App Assist has no interface, route or credential to the operational control '
        'system environment, and none is planned. The platform sits entirely within '
        'the corporate network and its integrations are limited to corporate '
        'databases, corporate servers and the corporate mail relay.'),

    _key('Describe the security controls in place for connections to the Smart '
         'Metering environment'): _answer(
        'Not Applicable',
        'There is no connection, direct or indirect, between App Assist and the Smart '
        'Metering environment. No metering data is held, processed or transported by '
        'the platform, and no monitoring probe is configured against a metering host.'),

    _key("Detail the 'Cloud' solution"): _answer(
        'Not Applicable',
        'App Assist is an on-premise solution. The web tier runs on a corporate '
        'Windows server under IIS, the database is hosted on corporate '
        'infrastructure, and the scheduled-job service runs on the same server under '
        'a dedicated service account.\n'
        'This is a design constraint rather than an accident of deployment: the '
        "platform's static code analysis and its offline summarisation of exported "
        'service-desk tickets were built to run on the estate precisely so that '
        'source code and ticket content are never sent to an external service.'),

    _key('Describe the personal or financial data being processed. Confirm that a DPIA '
         'has been completed and provide the reference'): _answer(
        'Personnel Data - No Financial Data',
        'The platform processes personnel data, not customer or financial data:\n'
        'User directory - name, work e-mail address, role, group, sub-group and team, '
        'plus a salted one-way password hash.\n'
        'Workforce records - weekly timesheets, leave records, task allocations and '
        'the utilisation reporting derived from them.\n'
        'Activity records - who created or changed a project, support profile, '
        'monitoring configuration or document, and when.\n'
        'The lawful basis is the legitimate interest of the employer in managing '
        'delivery work and resource allocation. Records are retained for the life of '
        'the platform because they form the delivery audit trail; leavers are '
        'disabled rather than deleted, so historical records stay attributable '
        'without the account remaining usable. A Data Protection Impact Assessment '
        'has been raised for the workforce records and its reference is recorded in '
        'the appendix.'),

    _key('Detail the security controls in place for the solution to accept incoming '
         'connections from the Internet'): _answer(
        'Not Applicable',
        'The platform accepts no inbound connection from the Internet. It is '
        'published on the internal network only, is not registered in external DNS, '
        'and is not exposed through any reverse proxy or gateway that faces the '
        'Internet. The server holds no public address and the site binding accepts '
        'connections on the internal interface only.'),

    _key('Detail the security controls in place for the solution to make outbound '
         'connections to the Internet'): _answer(
        'Not Applicable',
        'The platform makes no outbound connection to the Internet. Its dependencies '
        'are vendored and installed at deployment time rather than fetched at run '
        'time, and every analysis capability executes locally against data already on '
        'the estate. The absence of an egress route is itself a control: it removes '
        'the exfiltration path a compromised application would otherwise have.'),

    _key('Detail the 3rd parties who will use this solution'): _answer(
        'Not Applicable',
        'There are no third-party users and no third-party support arrangement. The '
        'platform is built and supported in-house, and every account belongs to a '
        'member of internal staff. No supplier account, integration key or '
        'remote-support path exists.'),

    _key('Detail how the users will authenticate'): _answer(
        'Authentication Controls',
        'Users authenticate with a username and password held in the platform\'s own '
        'user directory. Passwords are stored as salted one-way hashes and are never '
        'recoverable, logged or e-mailed.\n'
        'Sessions are server-side and carry a signed cookie marked secure and '
        'HTTP-only; every state-changing request carries a cross-site request forgery '
        'token.\n'
        'Access is role-based: administrator, project manager, support member and '
        'standard member each see only the modules and actions their role allows, and '
        'the check is enforced on the server for every request, not only in the '
        'interface.\n'
        'Leavers are disabled rather than deleted, so a disabled account cannot sign '
        'in but the records it created remain attributable. Multi-factor '
        'authentication is not applied in this release and is expected to arrive with '
        'directory integration.'),

    _key('Detail how the solution will integrate with Active Directory'): _answer(
        'Not Applicable In This Release',
        'The platform maintains its own user directory and does not integrate with '
        'Active Directory today. Directory integration is the intended target state '
        'and the design keeps the path open: authentication is isolated behind a '
        'single sign-in component, roles are already modelled as groups, and no '
        'module reads credentials directly.\n'
        'When integration is delivered it will be assessed as a change to this '
        'document, covering the protocol and port, encryption in transit, the service '
        'account used, and the mapping from directory groups to platform roles. Until '
        'then the compensating controls are the local password policy, role-based '
        'access control, and the removal of access on off-boarding.'),

    _key('Detail the security controls in place for the solution to exchange data '
         'with other systems'): _answer(
        'Data Exchange & Encryption',
        'All exchanges stay within the corporate network, and every one of them is '
        'outbound and read-only.\n'
        'Monitored databases - a connection is opened with a stored, encrypted '
        'credential, a bounded read-only probe is run, and the connection is closed '
        'immediately. No write is ever issued.\n'
        'Monitored servers - probes run over SSH with an enforced command timeout, '
        'and the command set is restricted to read-only status checks.\n'
        'Monitored URLs - checked over HTTPS with certificate validation and a '
        'response timeout; the response is closed without being retained.\n'
        'Alerting - sent through the corporate SMTP relay to named internal '
        'recipients; content is limited to status and counts and never carries a '
        'credential.\n'
        'Uploads - stored outside the web root and served only through an authorised '
        'download route that checks the caller\'s role.'),

    _key('If the system is classified as P1, detail the security controls which will '
         'enable resilience'): _answer(
        'Not Applicable - Not a P1 Service',
        'The platform supports internal delivery and operations work; no operational '
        'or customer-facing process depends on its availability, and an outage delays '
        'reporting rather than stopping work.\n'
        'Proportionate resilience is nonetheless applied: the database is backed up '
        'on the corporate backup schedule, the application is redeployed from source '
        'control rather than repaired in place, and all scheduled work is owned by a '
        'single service so a restart cannot cause duplicate alerting or duplicate '
        'records.'),

    _key('Describe how the interaction with the regulatory requirements and data '
         'feeds will be protected'): _answer(
        'Not Applicable',
        'The platform consumes no regulated data feed and produces no regulated '
        'submission. Its inputs are internal delivery records, internal monitoring '
        'results and internally exported service-desk extracts, and its outputs are '
        'internal reports and e-mail alerts. Where a monitored system is itself '
        'subject to regulation, the platform observes only that system\'s '
        'availability status; it holds none of the regulated content.'),

    _key('Provide details of the regulation this solution must comply with'): _answer(
        'Data Protection & Internal Policy',
        'The platform holds personnel data, so data protection legislation applies to '
        'the workforce and user-directory records described above. Compliance is '
        'evidenced by the Data Protection Impact Assessment raised for those records, '
        'by the retention position stated in this assessment, and by the role-based '
        'access control that limits timesheet and utilisation visibility to the '
        'individual and their manager.\n'
        'Beyond data protection the platform must meet internal information security '
        'policy - authentication, access control, credential handling and secure '
        'deployment - rather than any external regulatory obligation, because it '
        'neither provides nor supports a regulated service.'),

    _key('Provide details on how authentication and cross boundary traffic is '
         'encrypted'): _answer(
        'Encryption In Transit',
        'Every network path the platform uses is encrypted.\n'
        'Browser to application - TLS only, with the plain-text port redirected. '
        'Session cookies are marked secure, so they cannot be sent over an '
        'unencrypted connection.\n'
        'Application to monitored databases - encrypted client connections using the '
        "vendor driver's transport security.\n"
        'Application to monitored servers - SSH, with host key verification.\n'
        'Application to monitored URLs - HTTPS with certificate validation; an '
        'expiring or invalid certificate is itself reported as a monitoring finding.\n'
        "Certificates are tracked in the platform's own certificate register, which "
        'raises an expiry alert ahead of renewal, so an expired certificate is a '
        'scheduled event rather than an incident.'),

    _key('Provide details on how data is encrypted at rest'): _answer(
        'Application-Level Only',
        'Volume-level encryption at rest is not applied to the application database '
        'in this release. The database file and the upload store sit on the server\'s '
        'local storage, protected by the physical security of the data centre and by '
        'file-system permissions that grant access to the application service account '
        'only.\n'
        'Two application-level controls narrow the exposure that leaves. Every '
        'integration credential is encrypted with a key held outside the database and '
        'is decrypted only in memory at the point of use, so a copy of the database '
        'alone yields no usable password; and user passwords are stored as salted '
        'one-way hashes and cannot be reversed.\n'
        'The absence of volume-level encryption is carried as a residual risk with an '
        'owner and a target date, because the personnel data described above would '
        'otherwise be readable from a stolen backup or a copied database file.'),

    _key('Provide the process which will allow an audit of the supplier on IT '
         'security processes and principles, or the most recent information security '
         'audit report'): _answer(
        'Not Applicable - No Supplier',
        'The platform is developed and supported in-house, so the assurance normally '
        'obtained by auditing a supplier is obtained directly from the internal '
        'engineering process. That process is evidenced by the change record for each '
        "release, by the platform's own static code analysis run over its source "
        'before deployment, and by this assessment being re-run whenever a new module '
        'changes the data held or the systems reached.'),

    _key('Provide the process the supplier will follow should there be a security '
         'incident, detailing the notification and engagement'): _answer(
        'Internal Incident Management',
        'The corporate security incident process applies directly, without a third '
        'party in the path. A suspected incident involving the platform is raised to '
        'IS Security Operations by the Application Owner on detection.\n'
        'The platform supports that process rather than replacing it: sign-in '
        'attempts and state-changing actions are attributable to a named account, the '
        'application log is retained on the server, and administrator actions on '
        'accounts and integration credentials are recorded. Post-incident review is '
        'carried out under the corporate process.'),

    _key('Provide the appropriate output from the most recent penetration test'): _answer(
        'Scheduled - Not Yet Performed',
        'A test is scheduled before the production deployment gate, scoped to the '
        'authenticated web application, the session and role model, the upload and '
        'download routes, and the administrative interfaces.\n'
        'Pending that test the platform has been reviewed against a written internal '
        'security review covering credential handling, injection, cross-site '
        'scripting and access control on document download, and the findings were '
        'remediated before this assessment was raised. The penetration-test output '
        'and the remediation status of each finding will be attached to this '
        'document, and approval is sought on the basis that deployment does not '
        'proceed until they are.'),

    # -- 4-6. Governance, appendix, sign-off -------------------------------
    _key('SSIA Governance Overview'): {
        'intro': 'The governance review for this assessment.',
        'rows': [
            ('What changes have been made or recommended as a result of the SSIA process?',
             'Three changes were made. Integration passwords were being stored in '
             'recoverable form and are now encrypted at application level, with a '
             'one-off sweep re-encrypting the records already held. One module served '
             'uploaded files without checking the caller; every download route now '
             "enforces the caller's role. Alerting had been able to run in more than "
             'one place; all scheduled work now runs in exactly one service.\n'
             'Two recommendations remain open: volume-level encryption at rest, and '
             'multi-factor authentication delivered alongside directory integration.'),
            ("At which key milestones in the project's lifecycle will the SSIA be revisited?",
             'This will be revisited in accordance with the IT Gateway process: '
             'before the production deployment gate, to confirm the penetration-test '
             'output; whenever a new module is added, because a module can change the '
             'data held or the systems reached; when directory integration is '
             'delivered; and annually thereafter, or immediately on any change to the '
             'hosting model, the network exposure or the classification of the data '
             'held.'),
        ]},

    _key('Appendix & Reference Materials'): {
        'intro': 'The supporting material this assessment relies upon.',
        'rows': [
            ('High Level Design (HLD)', 'Platform architecture, deployment topology and integration detail; held in the project design folder.'),
            ('Network Details', 'Internal hosting topology for the application server and the database host.'),
            ('DPIA Reference', 'Raised for the workforce and user-directory records; reference recorded on completion.'),
            ('Static Code Analysis Report', 'Produced by the platform against its own source before each release.'),
            ('Internal Security Review', 'Written review of credential handling, injection, cross-site scripting and download authorisation, with the remediation record.'),
            ('Penetration Test Report', 'To be attached before the production deployment gate.'),
        ]},

    _key('Authorisation & Sign-Off'): {
        'intro': 'Approval is required by the IT Security Architect prior to gateway progression.',
        'rows': [
            ('Person completing SSIA - Signature', 'Solution Architect, Platform Engineering', 'Signed at the design gate'),
            ('Name (in capitals)', 'SOLUTION ARCHITECT', ''),
            ('Updated By', 'Solution Architect, Platform Engineering', 'Updated at the design gate'),
            ('Approval Signature', 'IS Security Operations Manager', 'Pending'),
            ('Name (in capitals)', 'IS SECURITY OPERATIONS MANAGER', ''),
        ]},
}


SAMPLE_CONTENT = {'hld': SAMPLE_HLD, 'brd': SAMPLE_BRD, 'ssia': SAMPLE_SSIA}


# ---------------------------------------------------------------------------
# Payload assembly
# ---------------------------------------------------------------------------

def _rows_for(section, raw_rows):
    """
    Bind positional sample rows to the section's live column ids.

    A row longer than the current column list is clipped and a shorter one is
    padded, so editing the master template can never break the sample.
    """
    columns = section.ordered_columns()
    rows = []
    for raw in raw_rows or []:
        cells = {}
        for idx, column in enumerate(columns):
            value = raw[idx] if idx < len(raw) else ''
            cells[str(column.id)] = '' if value is None else str(value)
        if any(v.strip() for v in cells.values()):
            rows.append(cells)
    return rows


def _blocks_for(raw_blocks):
    """Normalise sample structured entries into the export payload shape."""
    blocks = []
    for raw in raw_blocks or []:
        blocks.append({
            'fields': {k: str(v) for k, v in (raw.get('fields') or {}).items()},
            'tables': {k: [list(row) for row in rows]
                       for k, rows in (raw.get('tables') or {}).items()},
        })
    return blocks


def build_sample_payload(template_sections, doc_type='hld'):
    """
    Build the guest-export payload for the built-in sample document.

    `template_sections` is the flat list of live HLDTemplateSection rows for
    `doc_type`. Returns the same {section_id: {...}} structure the interactive
    builder posts, so the sample renders through exactly the same code path as
    a user-authored document.
    """
    content = SAMPLE_CONTENT.get(doc_type, {})
    payload = {}
    for section in template_sections:
        entry = content.get(_key(section.title))
        if entry is None:
            # Section added to the template since the sample was written: keep
            # it in the document (numbered, required) but leave it empty.
            payload[str(section.id)] = {
                'is_required': True, 'short_description': '',
                'content': '', 'rows': [], 'blocks': [],
            }
            continue
        payload[str(section.id)] = {
            'is_required': True,
            'short_description': entry.get('intro', ''),
            'content': (entry.get('content') or '').strip(),
            'rows': _rows_for(section, entry.get('rows')),
            'blocks': _blocks_for(entry.get('blocks')),
        }
    return payload
