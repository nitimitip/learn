"""
SDLC process governance
=======================

Pure logic for the SDLC (Software Development Life Cycle) process layer:

* the delivery-method questionnaire and its Waterfall/Agile recommendation,
* the default phase definitions for both methodologies (the seed for the
  admin-editable templates in the database),
* the schedule-window splitter that turns a project window into per-phase
  milestone windows, and
* the soft-governance gate evaluation - each phase's state plus the red
  flags shown on the project and dashboard. Flags never block work; they
  surface where the defined process is not being followed.

Everything here operates on plain values / lightweight dicts so it is unit
testable without a database (mirrors cpm.py).
"""

from datetime import date, timedelta


# ---------------------------------------------------------------------------
# Methodologies
# ---------------------------------------------------------------------------

METHODOLOGIES = ['waterfall', 'agile']

METHODOLOGY_LABELS = {
    'waterfall': 'Waterfall',
    'agile':     'Agile',
}


# ---------------------------------------------------------------------------
# Delivery-method questionnaire
#
# Each option carries a 0-2 score toward *Agile fit*; the total across the
# five questions (0-10) drives the recommendation. Low scores mean the
# classic Waterfall preconditions hold (stable requirements, single formal
# delivery, heavy compliance); high scores mean iterative delivery suits the
# project better. The threshold sits at the midpoint.
# ---------------------------------------------------------------------------

SDLC_QUESTIONS = [
    {
        'key': 'requirements',
        'question': 'How well defined and stable are the requirements?',
        'options': [
            ('Fully defined and stable', 0),
            ('Mostly defined, some change expected', 1),
            ('Evolving or unclear', 2),
        ],
    },
    {
        'key': 'delivery',
        'question': 'How should the client receive the solution?',
        'options': [
            ('One final delivery at the end', 0),
            ('A few staged releases', 1),
            ('Frequent incremental releases', 2),
        ],
    },
    {
        'key': 'scope',
        'question': 'How likely is the scope to change during delivery?',
        'options': [
            ('Unlikely - fixed scope', 0),
            ('Possible', 1),
            ('Very likely', 2),
        ],
    },
    {
        'key': 'stakeholders',
        'question': 'How available are business stakeholders for regular feedback?',
        'options': [
            ('Limited - formal sign-offs only', 0),
            ('Periodic reviews', 1),
            ('Continuously available', 2),
        ],
    },
    {
        'key': 'compliance',
        'question': 'How heavy is the regulatory / compliance / audit burden?',
        'options': [
            ('Heavy - formal stage documentation required', 0),
            ('Moderate', 1),
            ('Light', 2),
        ],
    },
]

SDLC_SCORE_MAX = sum(max(pts for _, pts in q['options']) for q in SDLC_QUESTIONS)

# Total agile-fit score at or above this recommends Agile.
SDLC_AGILE_THRESHOLD = 5


def score_answers(answers: dict) -> int:
    """
    Total agile-fit score for questionnaire answers.

    `answers` maps question key -> selected option index (int or numeric
    string). Missing or invalid answers score 0 (the conservative,
    waterfall-leaning end), so a partially answered form still yields a
    deterministic recommendation.
    """
    total = 0
    for q in SDLC_QUESTIONS:
        raw = answers.get(q['key'])
        try:
            idx = int(raw)
        except (TypeError, ValueError):
            continue
        if 0 <= idx < len(q['options']):
            total += q['options'][idx][1]
    return total


def recommend_methodology(score: int) -> str:
    """Waterfall for low agile-fit scores, Agile at/above the threshold."""
    return 'agile' if score >= SDLC_AGILE_THRESHOLD else 'waterfall'


# ---------------------------------------------------------------------------
# Default phase definitions (seed data for the admin-editable templates)
#
# Each phase: name, description, exit_criteria (the gate, in words),
# doc_categories (DOCUMENT_CATEGORIES values that must be uploaded before the
# gate is considered met), tasks (default tasks auto-created with the phase's
# milestone) and weight (relative share of the project window).
# ---------------------------------------------------------------------------

def _phase(name, description, exit_criteria, doc_categories, tasks, weight,
           repeatable=False):
    return {
        'name': name,
        'description': description,
        'exit_criteria': exit_criteria,
        'doc_categories': doc_categories,
        'tasks': tasks,           # list of (task name, category, sub_category)
        'weight': weight,
        # A repeatable phase holds MULTIPLE milestones (agile sprints): each
        # "Sprint N" milestone is created on demand, seeded with the phase's
        # default (ceremony) tasks. Non-repeatable phases get exactly one.
        'repeatable': repeatable,
    }


DEFAULT_PHASES = {
    'waterfall': [
        _phase('Initiation & Planning',
               'Define the project scope, objectives, stakeholders and plan.',
               'Project charter uploaded and the plan agreed with stakeholders.',
               ['Planning'],
               [('Define scope & objectives', 'Management', 'Planning'),
                ('Identify stakeholders & team', 'Management', 'Stakeholder Communication'),
                ('Project kickoff', 'Management', 'Planning')],
               1),
        _phase('Requirements',
               'Gather, document and agree the business and technical requirements.',
               'Requirements specification uploaded and signed off by the business.',
               ['Requirements & Analysis'],
               [('Gather business requirements', 'Management', 'Planning'),
                ('Document functional & non-functional requirements', 'Design', 'Documentation'),
                ('Requirements review & sign-off', 'Management', 'Review / Approval')],
               2),
        _phase('Design',
               'Produce the high-level and detailed design for the agreed requirements.',
               'Architecture / design document (HLD) uploaded and design review held.',
               ['Design'],
               [('Prepare high-level design (HLD)', 'Design', 'Documentation'),
                ('Prepare detailed design', 'Design', 'Documentation'),
                ('Design review & sign-off', 'Management', 'Review / Approval')],
               2),
        _phase('Build',
               'Develop the solution to the approved design.',
               'All build tasks complete with code reviewed and unit tested.',
               [],
               [('Development', 'Development', 'Backend'),
                ('Code review', 'Development', 'Testing / QA'),
                ('Unit testing', 'Development', 'Testing / QA')],
               3),
        _phase('Testing',
               'System and integration testing against the requirements.',
               'Test plan/report uploaded; all planned tests executed and defects closed.',
               ['Testing'],
               [('Prepare test plan', 'Development', 'Testing / QA'),
                ('System & integration testing', 'Development', 'Testing / QA'),
                ('Defect fixing & retest', 'Development', 'Testing / QA')],
               2),
        _phase('UAT',
               'Business users validate the solution end to end.',
               'UAT executed by the business and formally signed off.',
               [],
               [('UAT execution', 'Development', 'Testing / QA'),
                ('UAT sign-off', 'Management', 'Review / Approval')],
               1),
        _phase('Deployment / Go-Live',
               'Deploy the solution to production and verify it.',
               'Go-Live plan prepared, production deployment done and verified.',
               [],
               [('Prepare go-live plan', 'Management', 'Planning'),
                ('Production deployment', 'Infrastructure', 'Cloud / Hosting'),
                ('Post go-live checks', 'Development', 'Testing / QA')],
               1),
        _phase('Hypercare / Warranty Support',
               'Stabilisation window immediately after go-live: heightened '
               'support, fast defect turnaround, then handover to BAU support.',
               'Hypercare window completed with production stable and support '
               'transitioned to the BAU team.',
               [],
               [('Hypercare support & monitoring', 'Other', 'Support'),
                ('Defect triage & fixes', 'Development', 'Testing / QA'),
                ('Transition to BAU support', 'Other', 'Support')],
               1),
        _phase('Closure',
               'Hand the solution to support and formally close the project.',
               'Deliverables handed over, lessons learned held, closure signed off.',
               ['Post-Deployment & Closure'],
               [('Handover to support', 'Other', 'Support'),
                ('Lessons learned session', 'Management', 'Review / Approval'),
                ('Project closure sign-off', 'Management', 'Review / Approval')],
               1),
    ],
    # Standard Scrum shape - three stages only. Releases are NOT a separate
    # phase: every sprint delivers a potentially shippable increment, so
    # 'Release to production' is one of the sprint's own tasks (Sprint 1 can
    # be live before Sprint 2 starts, with nothing special to model). A
    # separate hardening phase is a recognised anti-pattern and is gone -
    # testing lives inside each sprint.
    'agile': [
        _phase('Discovery & Backlog',
               'Establish the product vision, initial backlog and release plan.',
               'Backlog / requirements document uploaded and release plan agreed.',
               ['Requirements & Analysis'],
               [('Define product vision & goals', 'Management', 'Planning'),
                ('Build initial product backlog', 'Management', 'Planning'),
                ('Release planning', 'Management', 'Planning')],
               1),
        _phase('Sprint Cycles',
               'Iterative delivery. Add one sprint per iteration (Sprint 1, 2, '
               '3 ...); every sprint runs the full loop - plan, build & test, '
               'review, release to production, retrospect - so each increment '
               'is shippable on its own.',
               'All planned sprints delivered; each increment released to '
               'production and verified, with reviews and retrospectives held.',
               [],
               [('Sprint planning', 'Management', 'Planning'),
                ('Sprint development & testing', 'Development', 'Backend'),
                ('Sprint review / demo', 'Management', 'Stakeholder Communication'),
                ('Release to production', 'Infrastructure', 'Cloud / Hosting'),
                ('Sprint retrospective', 'Management', 'Review / Approval')],
               5,
               repeatable=True),
        _phase('Hypercare & Transition',
               'Post final-release stabilisation: heightened support, knowledge '
               'transfer and handover to BAU support.',
               'Production stable after the last release; knowledge transferred '
               'and support transitioned to the BAU team.',
               [],
               [('Hypercare support & monitoring', 'Other', 'Support'),
                ('Knowledge transfer', 'Other', 'Training'),
                ('Transition to BAU support', 'Other', 'Support')],
               1),
        _phase('Closure',
               'Hand over to support and close with a final retrospective.',
               'Deliverables handed over, final retrospective held, closure signed off.',
               ['Post-Deployment & Closure'],
               [('Handover to support', 'Other', 'Support'),
                ('Final retrospective', 'Management', 'Review / Approval'),
                ('Closure sign-off', 'Management', 'Review / Approval')],
               1),
    ],
}

# Earlier default sets, per methodology. Used only to recognise an UNTOUCHED
# legacy template and upgrade it in place to the current defaults; any
# admin-modified template (any stage renamed/added/removed) is left alone.
LEGACY_TEMPLATE_SETS = {
    'agile': [
        ['Discovery & Backlog', 'Sprint Cycles', 'Hardening & UAT',
         'Release / Go-Live', 'Closure & Retrospective'],
        ['Discovery & Backlog', 'Sprint Cycles', 'Closure'],
    ],
    'waterfall': [
        ['Initiation & Planning', 'Requirements', 'Design', 'Build',
         'Testing', 'UAT', 'Deployment / Go-Live', 'Closure'],
    ],
}


# ---------------------------------------------------------------------------
# Schedule-window splitter
# ---------------------------------------------------------------------------

def split_window(start: date, end: date, weights: list) -> list:
    """
    Split the inclusive [start, end] window into len(weights) consecutive
    sub-windows whose lengths are proportional to the weights, each at least
    one day. Returns [(start, end), ...] in order.

    Cumulative rounding keeps the total exact: the last window always ends on
    `end`. When the window has fewer days than phases, later windows collapse
    onto the final day rather than overflowing past `end`.
    """
    if not weights or end < start:
        return []
    total_days = (end - start).days + 1
    total_weight = sum(w if w and w > 0 else 1 for w in weights)
    norm = [w if w and w > 0 else 1 for w in weights]

    windows = []
    cursor = start
    consumed = 0.0
    for i, w in enumerate(norm):
        if i == len(norm) - 1:
            phase_end = end
        else:
            consumed += total_days * (w / total_weight)
            # At least one day per phase, never past the final day.
            phase_end = start + timedelta(days=max(int(round(consumed)) - 1, 0))
            if phase_end < cursor:
                phase_end = cursor
            if phase_end > end:
                phase_end = end
        windows.append((cursor, phase_end))
        cursor = min(phase_end + timedelta(days=1), end)
    return windows


# ---------------------------------------------------------------------------
# Soft-governance gate evaluation
#
# `evaluate_phases` takes lightweight per-phase dicts (built by the routes
# from the ORM objects, or by tests directly):
#
#     {
#       'name':           str,
#       'signed_off':     bool,
#       'doc_categories': [str, ...],   # required document categories
#       'repeatable':     bool,         # OPTIONAL - iterative stage (sprints /
#                                       # per-increment releases). Its gate only
#                                       # closes once ALL increments are done, so
#                                       # it never blocks downstream stages
#                                       # increment-by-increment: Sprint 1 can go
#                                       # live before Sprint 2 starts without an
#                                       # out-of-order flag.
#       'milestone_ids':  [int, ...],   # OPTIONAL - identities of the phase's
#                                       # milestones; phases sharing a milestone
#                                       # (PM grouped them) never raise the
#                                       # out-of-order flag against each other
#       'milestone': None | {           # the AGGREGATE across the phase's
#           'end_date':    date | None, # milestone(s); None = unassigned
#           'tasks_total': int,
#           'tasks_done':  int,
#           'tasks_started': int,       # done + in progress + on hold
#       },
#     }
#
# and returns the same dicts enriched with:
#     docs_missing   - required categories absent from `present_doc_categories`
#     tasks_complete - every milestone task done (vacuously True with no tasks)
#     started        - any work begun in the phase
#     gate_passed    - tasks complete AND docs present AND signed off
#     state          - 'passed' | 'ready' | 'active' | 'pending' | 'unplanned'
#     flags          - red-flag strings for THIS phase (soft governance)
# ---------------------------------------------------------------------------

def evaluate_phases(phases: list, present_doc_categories, today: date = None) -> list:
    today = today or date.today()
    present = set(present_doc_categories or [])

    results = []
    for p in phases:
        ms = p.get('milestone')
        docs_missing = [c for c in (p.get('doc_categories') or []) if c not in present]
        tasks_complete = bool(ms) and ms['tasks_total'] > 0 and ms['tasks_done'] == ms['tasks_total']
        if ms and ms['tasks_total'] == 0:
            tasks_complete = True          # nothing planned inside the phase yet
        started = bool(ms) and ms['tasks_started'] > 0
        gate_passed = (ms is not None and tasks_complete
                       and not docs_missing and p.get('signed_off', False))
        results.append(dict(p, docs_missing=docs_missing,
                            tasks_complete=tasks_complete, started=started,
                            gate_passed=gate_passed, flags=[]))

    # Per-phase red flags. Soft governance: informational only, never blocking.
    first_unpassed = next((i for i, r in enumerate(results) if not r['gate_passed']), None)
    for i, r in enumerate(results):
        ms = r.get('milestone')

        if ms is None:
            r['flags'].append(
                'This stage is not assigned to any milestone (or its milestone '
                'was deleted), so it cannot be tracked against the schedule.')

        # Work started here while an earlier phase gate is still open.
        # Two deliberate exemptions:
        #   * phases the PM grouped into the SAME milestone share their work,
        #     so they are never out-of-order relative to each other;
        #   * an ITERATIVE earlier stage (sprints, per-increment releases)
        #     only closes its gate after the LAST increment - downstream work
        #     on already-shipped increments (Sprint 1 goes live, then Sprint 2
        #     starts) is the normal continuous-delivery rhythm, not a
        #     violation.
        if r['started'] and first_unpassed is not None and i > first_unpassed:
            earlier = results[first_unpassed]
            shared = (set(r.get('milestone_ids') or ())
                      & set(earlier.get('milestone_ids') or ()))
            if not shared and not earlier.get('repeatable'):
                r['flags'].append(
                    f"Work has started in this stage but the earlier "
                    f"'{earlier['name']}' stage has not passed its gate.")

        # Phase window has ended without the gate passing.
        if ms and ms.get('end_date') and ms['end_date'] < today and not r['gate_passed']:
            r['flags'].append(
                f"The phase window ended on {ms['end_date']:%d %b %Y} but its "
                f"gate has not been passed.")

        # Work finished but the required deliverable was never uploaded.
        if ms and r['tasks_complete'] and ms['tasks_total'] > 0 and r['docs_missing']:
            r['flags'].append(
                'All phase tasks are complete but required document(s) are '
                'missing: ' + ', '.join(r['docs_missing']) + '.')

    # State labels for the pipeline UI. Several stages may be 'active' at
    # once in an interleaved delivery (Sprint 2 running while Release is
    # mid-deployment) - any stage with work underway shows as active, plus
    # the first open stage even before its work starts.
    active_assigned = False
    for r in results:
        if r['gate_passed']:
            r['state'] = 'passed'
        elif r.get('milestone') is None:
            r['state'] = 'unplanned'
        elif r['tasks_complete'] and not r['docs_missing'] and not r.get('signed_off'):
            r['state'] = 'ready'            # everything done - awaiting sign-off
        elif r['started'] or not active_assigned:
            r['state'] = 'active'
            active_assigned = True
        else:
            r['state'] = 'pending'

    return results


def collect_flags(states: list) -> list:
    """Flatten per-phase flags to [{'phase': name, 'message': str}, ...]."""
    out = []
    for r in states:
        for msg in r.get('flags', ()):
            out.append({'phase': r['name'], 'message': msg})
    return out
