"""
cert_monitor.py - Certificate expiry alert scheduler.

Mirrors the lifecycle of the Application Health Check scheduler but is far
simpler: a SINGLE daily cron job that calls run_certificate_expiry_check().
The once-per-day cadence is enforced per-certificate inside
run_certificate_expiry_check (via the last_alert_sent column), so the daily run
re-alerts every day until a certificate is renewed, and is idempotent if it
happens to fire more than once in a day.

Deployment model (same as the health check):
  * The dedicated Windows service (health_monitor_app_sched.py) owns the
    schedule in production and calls init_certificate_monitoring().
  * The in-process Flask scheduler may also start it (guarded by
    RUN_SCHEDULERS_IN_APP in main_app.py). The daily
    cron + the per-row cadence guard make a second runner harmless.

Its jobstore table (apscheduler_jobs_cert) is separate from the health-check
and MIMP jobstores so the three schedulers never load each other's jobs.
"""

import logging
import os
import threading
from typing import Optional

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from tzlocal import get_localzone

from database import engine
from .utils import run_certificate_expiry_check

logger = logging.getLogger(__name__)

# Daily run time (local). Override with CERT_ALERT_HOUR / CERT_ALERT_MINUTE.
_RUN_HOUR = int(os.environ.get('CERT_ALERT_HOUR', '8'))
_RUN_MINUTE = int(os.environ.get('CERT_ALERT_MINUTE', '0'))
_JOBSTORE_TABLE = os.environ.get('CERT_APSCHEDULER_TABLE', 'apscheduler_jobs_cert')
_ALERT_JOB = 'certificate_expiry_alert'

_init_lock = threading.Lock()
_scheduler: Optional[BackgroundScheduler] = None


def _run_safe():
    """Scheduler entry point - never lets an exception kill the thread."""
    try:
        run_certificate_expiry_check()
    except Exception:
        logger.exception("Certificate expiry sweep crashed (suppressed).")


def init_certificate_monitoring() -> None:
    """Start the in-process certificate-alert scheduler. Idempotent."""
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            logger.info("Certificate monitoring already running - skipping re-init.")
            return

        _scheduler = BackgroundScheduler(
            jobstores={'default': SQLAlchemyJobStore(engine=engine, tablename=_JOBSTORE_TABLE)},
            job_defaults={'coalesce': True, 'max_instances': 1, 'misfire_grace_time': 3600},
            timezone=get_localzone(),
        )
        _scheduler.add_job(
            func=_run_safe,
            trigger=CronTrigger(hour=_RUN_HOUR, minute=_RUN_MINUTE),
            id=_ALERT_JOB,
            name=f'Certificate expiry alert (daily {_RUN_HOUR:02d}:{_RUN_MINUTE:02d})',
            replace_existing=True,
        )
        _scheduler.start()
        logger.info("Certificate monitoring started - daily alert at %02d:%02d.",
                    _RUN_HOUR, _RUN_MINUTE)


def shutdown_certificate_monitoring() -> None:
    """Cleanly stop the scheduler. Call from service teardown / atexit."""
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            _scheduler.shutdown(wait=False)
            logger.info("Certificate monitoring stopped.")
        _scheduler = None
