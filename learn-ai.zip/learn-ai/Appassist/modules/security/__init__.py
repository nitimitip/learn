from .routes import security_bp

__all__ = ['security_bp']
