"""
utils.py - Security / Certificate Report helpers.

Two responsibilities:

  1. Excel ingest - parse the Certificate Tracker spreadsheet and REPLACE the
     whole inventory (truncate + reload) inside a single transaction so a bad
     file never leaves the table half-populated.

  2. Expiry alerting - two-tier, once per day, repeating every day until the
     certificate is renewed:
       * within 60 days - warn the owning team (the per-row Email) plus the
         security-team distribution list;
       * within 30 days - same recipients, with the owning team's manager(s)
         (configured per-Owner in the admin console, or mapped to 'All' teams)
         copied on the notice.
     SMTP config comes from the same env vars the rest of the app uses.
"""

import logging
import os
import re
import smtplib
from datetime import date, datetime, time, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from markupsafe import escape
from sqlalchemy import or_

from database import get_db_session
from .models import (
    CertificateRecord, CertificateConfig, CertificateTeamManager, ALL_TEAMS_KEY,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# SMTP config (shared convention with the health-check module)
# ---------------------------------------------------------------------------
_SMTP_SERVER = os.environ.get('SMTP_SERVER', 'mail1.northernpowergrid.com')
_SMTP_PORT = int(os.environ.get('SMTP_PORT', '25'))
_EMAIL_FROM = os.environ.get('EMAIL_FROM', 'NPgAppAssist@northernpowergrid.com')

# Two-tier alerting window (overridable via env). Re-alerts fire once per
# calendar day and keep firing every day until the certificate is renewed and
# drops out of the threshold window.
#   * WARNING tier  (<= 60 days) - owning team Email + security distribution.
#   * CRITICAL tier (<= 30 days) - same recipients, plus the owning team's
#     manager(s) copied in (see security_team_managers).
# CERT_ALERT_THRESHOLD_DAYS is honoured as a legacy override of the warn tier.
ALERT_WARN_THRESHOLD_DAYS = int(
    os.environ.get('CERT_ALERT_WARN_DAYS',
                   os.environ.get('CERT_ALERT_THRESHOLD_DAYS', '60')))
ALERT_MANAGER_THRESHOLD_DAYS = int(os.environ.get('CERT_ALERT_MANAGER_DAYS', '30'))

# Recipients are split on any of these separators (comma / semicolon / newline).
_EMAIL_SPLIT_RE = re.compile(r'[;,\n\r]+')
_EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


# ---------------------------------------------------------------------------
# Header mapping - maps normalised spreadsheet headers to model attributes.
# Normalisation = lowercase, strip, collapse internal whitespace.
# ---------------------------------------------------------------------------
_HEADER_MAP = {
    # 's.no' / 'sno' / 'serial' are intentionally NOT mapped - the sequence
    # number is auto-generated (1..N in file order) and re-numbered on delete,
    # so whatever the spreadsheet says is ignored.
    'certificate name': 'certificate_name', 'cert name': 'certificate_name', 'name': 'certificate_name',
    'type': 'cert_type', 'certificate type': 'cert_type',
    'hostname': 'hostname', 'host name': 'hostname', 'host': 'hostname',
    'environment': 'environment', 'env': 'environment',
    'application': 'application', 'app': 'application',
    'certificate enrollment date': 'enrollment_date', 'enrollment date': 'enrollment_date',
    'issued on': 'enrollment_date', 'issue date': 'enrollment_date',
    'validity (years)': 'validity_years', 'validity': 'validity_years', 'validity years': 'validity_years',
    'certificate expiry date': 'expiry_date', 'expiry date': 'expiry_date',
    'expiry': 'expiry_date', 'valid to': 'expiry_date', 'expiration date': 'expiry_date',
    'owner': 'owner', 'owner team': 'owner', 'team': 'owner',
    'email': 'email', 'email address': 'email', 'team email': 'email',
    'certificate category': 'category', 'category': 'category',
    # 'days left' is intentionally ignored - it is derived from expiry_date.
}

_DATE_FIELDS = {'enrollment_date', 'expiry_date'}
_INT_FIELDS = set()   # s_no is auto-generated, never parsed from the sheet
_FLOAT_FIELDS = {'validity_years'}


def _norm_header(value) -> str:
    return re.sub(r'\s+', ' ', str(value or '').strip().lower())


def _coerce_date(value):
    if value in (None, ''):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value).strip()
    for fmt in ('%Y-%m-%d', '%d-%m-%Y', '%d/%m/%Y', '%m/%d/%Y', '%d-%b-%Y', '%d %b %Y', '%Y/%m/%d'):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    logger.warning("Could not parse certificate date value: %r", value)
    return None


def _coerce_int(value):
    if value in (None, ''):
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def _coerce_float(value):
    if value in (None, ''):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def parse_certificate_workbook(filepath):
    """Read the workbook and return (records, warnings).

    `records` is a list of dicts keyed by CertificateRecord attribute names.
    Raises ValueError if the sheet has no recognisable header row.
    """
    import openpyxl

    wb = openpyxl.load_workbook(filepath, read_only=True, data_only=True)
    ws = wb.active
    rows = ws.iter_rows(values_only=True)

    try:
        header_row = next(rows)
    except StopIteration:
        raise ValueError('The uploaded file is empty.')

    col_map = {}   # column index -> model attribute
    for idx, header in enumerate(header_row):
        attr = _HEADER_MAP.get(_norm_header(header))
        if attr:
            col_map[idx] = attr

    if 'certificate_name' not in col_map.values() or 'expiry_date' not in col_map.values():
        raise ValueError(
            "Could not find the required columns. The sheet must contain at "
            "least 'Certificate Name' and 'Certificate Expiry Date'."
        )

    records = []
    warnings = []
    for row_no, row in enumerate(rows, start=2):
        if row is None or all(c in (None, '') for c in row):
            continue
        rec = {}
        for idx, attr in col_map.items():
            value = row[idx] if idx < len(row) else None
            if attr in _DATE_FIELDS:
                rec[attr] = _coerce_date(value)
            elif attr in _INT_FIELDS:
                rec[attr] = _coerce_int(value)
            elif attr in _FLOAT_FIELDS:
                rec[attr] = _coerce_float(value)
            else:
                rec[attr] = None if value is None else str(value).strip()
        if not rec.get('certificate_name'):
            continue
        if not rec.get('expiry_date'):
            warnings.append(f"Row {row_no} ('{rec.get('certificate_name')}') has no valid expiry date.")
        records.append(rec)

    wb.close()
    return records, warnings


# ---------------------------------------------------------------------------
# User-driven column mapping
#
# Spreadsheets in the wild rarely match a fixed template, so rather than fail
# (or silently drop columns) when a header differs, we let the uploader map
# each database field to whichever spreadsheet column holds it. The mapping is
# index-based (column position), which is robust even when two columns share a
# header name.
# ---------------------------------------------------------------------------

# (attr, display label, required). Order drives the mapping form.
# S.No is absent on purpose: it is auto-generated on load (1..N in file order)
# and re-numbered whenever a record is deleted, so it is never mapped.
MODEL_FIELDS = [
    ('certificate_name', 'Certificate Name',            True),
    ('cert_type',        'Type',                        False),
    ('hostname',         'Hostname',                    False),
    ('environment',      'Environment',                 False),
    ('application',      'Application',                  False),
    ('enrollment_date',  'Certificate Enrollment Date', False),
    ('validity_years',   'Validity (Years)',            False),
    ('expiry_date',      'Certificate Expiry Date',     True),
    ('owner',            'Owner',                       False),
    ('email',            'Email',                       False),
    ('category',         'Certificate Category',        False),
]

_PREVIEW_ROWS = 5


def _label_headers(header_row):
    """Stringify a header row into stable display labels (blank -> 'Column N')."""
    labels = []
    for i, h in enumerate(header_row or []):
        text = '' if h is None else str(h).strip()
        labels.append(text if text else f'Column {i + 1}')
    return labels


def read_headers(filepath):
    """Return (headers, preview_rows) for the active sheet.

    headers      : list of display labels, indexed by column position.
    preview_rows : up to _PREVIEW_ROWS data rows (each a list of cell strings).
    Raises ValueError on an empty sheet.
    """
    import openpyxl

    wb = openpyxl.load_workbook(filepath, read_only=True, data_only=True)
    try:
        ws = wb.active
        rows = ws.iter_rows(values_only=True)
        try:
            header_row = next(rows)
        except StopIteration:
            raise ValueError('The uploaded file is empty.')
        headers = _label_headers(header_row)
        ncols = len(headers)
        preview = []
        for row in rows:
            if len(preview) >= _PREVIEW_ROWS:
                break
            if row is None or all(c in (None, '') for c in row):
                continue
            cells = []
            for i in range(ncols):
                v = row[i] if i < len(row) else None
                if isinstance(v, (datetime, date)):
                    v = v.strftime('%Y-%m-%d')
                cells.append('' if v is None else str(v))
            preview.append(cells)
        return headers, preview
    finally:
        wb.close()


def suggest_mapping(headers):
    """Best-guess {attr: column_index or None} from header names."""
    by_attr = {}
    for idx, header in enumerate(headers):
        attr = _HEADER_MAP.get(_norm_header(header))
        if attr and attr not in by_attr:
            by_attr[attr] = idx
    return {attr: by_attr.get(attr) for attr, _label, _req in MODEL_FIELDS}


def _coerce_for(attr, value):
    if attr in _DATE_FIELDS:
        return _coerce_date(value)
    if attr in _INT_FIELDS:
        return _coerce_int(value)
    if attr in _FLOAT_FIELDS:
        return _coerce_float(value)
    return None if value in (None, '') else str(value).strip()


def parse_with_mapping(filepath, mapping):
    """Parse the workbook using an explicit {attr: column_index} mapping.

    `mapping` values are column indices (ints); a missing/None value means the
    field is left blank. Returns (records, warnings). Raises ValueError if a
    required field (Certificate Name / Expiry Date) is not mapped.
    """
    import openpyxl

    active = {attr: idx for attr, idx in mapping.items() if idx is not None}
    for attr, label, required in MODEL_FIELDS:
        if required and attr not in active:
            raise ValueError(f"'{label}' must be mapped to a column.")

    wb = openpyxl.load_workbook(filepath, read_only=True, data_only=True)
    records, warnings = [], []
    try:
        ws = wb.active
        rows = ws.iter_rows(values_only=True)
        try:
            next(rows)  # skip header
        except StopIteration:
            raise ValueError('The uploaded file is empty.')
        for row_no, row in enumerate(rows, start=2):
            if row is None or all(c in (None, '') for c in row):
                continue
            rec = {}
            for attr, idx in active.items():
                value = row[idx] if idx < len(row) else None
                rec[attr] = _coerce_for(attr, value)
            if not rec.get('certificate_name'):
                continue
            if not rec.get('expiry_date'):
                warnings.append(f"Row {row_no} ('{rec.get('certificate_name')}') has no valid expiry date.")
            records.append(rec)
    finally:
        wb.close()
    return records, warnings


def replace_certificates(db_session, records):
    """Truncate the inventory and insert the parsed rows in one transaction.

    The sequence number is auto-generated here (1..N in file order) - any
    S.No column in the spreadsheet is ignored. Returns the number of rows
    inserted. Re-raises on failure after rolling back, so the caller keeps
    the previous data intact.
    """
    try:
        db_session.query(CertificateRecord).delete()
        for seq, rec in enumerate(records, start=1):
            rec.pop('s_no', None)
            db_session.add(CertificateRecord(s_no=seq, **rec))
        db_session.commit()
        logger.info("Certificate inventory replaced - %d row(s) loaded.", len(records))
        return len(records)
    except Exception:
        db_session.rollback()
        logger.exception("Failed to replace certificate inventory.")
        raise


def resequence_certificates(db_session, commit=True):
    """Re-number the inventory's S.No to a contiguous 1..N.

    Ordering is stable: existing s_no order is preserved (rows with no s_no
    sort last, then by id), so deleting row 3 of 10 simply shifts 4..10 up
    by one. Returns the number of rows whose s_no changed. Commits unless
    commit=False (caller owns the transaction).
    """
    certs = db_session.query(CertificateRecord).all()
    certs.sort(key=lambda c: (c.s_no is None, c.s_no if c.s_no is not None else 0, c.id))
    changed = 0
    for seq, cert in enumerate(certs, start=1):
        if cert.s_no != seq:
            cert.s_no = seq
            changed += 1
    if changed and commit:
        db_session.commit()
    return changed


# ---------------------------------------------------------------------------
# Email helpers
# ---------------------------------------------------------------------------

def parse_email_list(raw):
    """Split a separator-delimited string into a de-duplicated list of valid
    email addresses (order preserved)."""
    if not raw:
        return []
    seen, out = set(), []
    for piece in _EMAIL_SPLIT_RE.split(raw):
        addr = piece.strip()
        if addr and _EMAIL_RE.match(addr) and addr.lower() not in seen:
            seen.add(addr.lower())
            out.append(addr)
    return out


def get_alert_distribution(db_session):
    """The security-team distribution list configured in the admin console."""
    cfg = db_session.query(CertificateConfig).first()
    return parse_email_list(cfg.alert_emails if cfg else '')


def get_team_managers(db_session):
    """Load the team -> manager mapping configured in the admin console.

    Returns (per_team, all_teams): per_team maps the lower-cased Owner name to
    its manager email list; all_teams is the list of managers mapped to the
    'All' entry, copied on every team's critical alerts.
    """
    per_team, all_teams = {}, []
    for row in db_session.query(CertificateTeamManager).all():
        emails = parse_email_list(row.manager_emails)
        if not emails:
            continue
        if row.team == ALL_TEAMS_KEY:
            all_teams.extend(emails)
            continue
        key = (row.team or '').strip().lower()
        if key:
            per_team.setdefault(key, []).extend(emails)
    return per_team, all_teams


def managers_for_owner(owner, per_team, all_teams):
    """Manager emails for a certificate's owning team (Owner matched
    case-insensitively), plus any 'All'-teams managers. De-duplicated,
    order preserved. Empty list when no manager is configured."""
    key = (owner or '').strip().lower()
    combined = list(per_team.get(key, [])) + list(all_teams)
    seen = set()
    return [m for m in combined if not (m.lower() in seen or seen.add(m.lower()))]


# Shared NPG email theme (hero/footer/badges + palette).
from email_theme import (
    hero_rows, footer_rows, badge,
    NPG_RED as _NPG_RED, NPG_DARK as _NPG_DARK, NPG_LIGHT as _NPG_LIGHT,
    NPG_BORDER as _NPG_BORDER, NPG_TEXT_MUTED as _NPG_MUTED, CHIP_BG as _CHIP_BG,
    FONT as _FONT, callout, tone,
)


def _status_tone(status):
    """The shared email tone for an expiry bucket (email_theme.TONES), so the
    hero chip and the state block are never two different reds."""
    return {'expired': 'stop', 'critical': 'stop', 'warning': 'warn'}.get(
        status, 'ok')


def _build_alert_email_html(cert, managers_copied=False):
    """Outlook-safe HTML alert for a single expiring certificate.

    The action-required wording adapts to the alert tier (expired / critical
    <=30d / warning <=60d), and notes when the owning team's manager(s) have
    been copied on the notice. Header/footer come from the shared NPG email
    theme (email_theme.py) so every App Assist email looks the same.
    """
    tone_name = _status_tone(cert.status)
    pal = tone(tone_name)
    days = cert.days_left
    if days is not None and days < 0:
        headline = f"EXPIRED {abs(days)} day(s) ago"
    else:
        headline = f"Expires in {days} day(s)"

    if days is not None and days < 0:
        action = ('This certificate has expired. Please raise an emergency renewal '
                  'request with the security team immediately to restore service assurance.')
    elif days is not None and days <= ALERT_MANAGER_THRESHOLD_DAYS:
        action = (f'This certificate is within the {ALERT_MANAGER_THRESHOLD_DAYS}-day '
                  f'critical window. Please raise a renewal request with the security '
                  f'team immediately to avoid service disruption.')
        if managers_copied:
            action += (' The owning team\'s manager(s) have been copied on this '
                       'notice for visibility.')
    else:
        action = (f'This certificate falls due within the next '
                  f'{ALERT_WARN_THRESHOLD_DAYS} days. Please plan the renewal now and '
                  f'raise a request with the security team ahead of the expiry date.')

    def cell(label, value, last=False):
        # No horizontal inset on the outer edges: the label column starts on
        # the card gutter, so this table lines up with the block above it
        # rather than floating 14px to its right. The final row drops its
        # rule - it would sit a few pixels above the footer's own.
        rule = '' if last else f'border-bottom:1px solid {_NPG_LIGHT};'
        return (
            f'<tr>'
            f'<td width="34%" valign="top" style="padding:9px 18px 9px 0;font-family:{_FONT};'
            f'font-size:13px;color:{_NPG_MUTED};{rule}'
            f'mso-line-height-rule:exactly;line-height:19px;white-space:nowrap;">{escape(label)}</td>'
            f'<td style="padding:9px 0;font-family:{_FONT};font-size:13px;'
            f'color:{_NPG_DARK};{rule}font-weight:bold;'
            f'mso-line-height-rule:exactly;line-height:19px;">{escape(value)}</td>'
            f'</tr>'
        )

    rows = ''.join([
        cell('Certificate', cert.certificate_name or '-'),
        cell('Type', cert.cert_type or '-'),
        cell('Hostname', cert.hostname or '-'),
        cell('Environment', cert.environment or '-'),
        cell('Application', cert.application or '-'),
        cell('Owner', cert.owner or '-'),
        cell('Expiry Date', cert.expiry_date.strftime('%d %b %Y') if cert.expiry_date else '-'),
        cell('Category', cert.category or '-', last=True),
    ])

    # Hero chips: expiry state (tier-coloured) + environment + expiry date.
    state_label = (f'EXPIRED {abs(days)}D AGO' if days is not None and days < 0
                   else f'EXPIRES IN {days}D' if days is not None else 'NO EXPIRY DATE')
    chips = [badge(pal['bg'], pal['fg'], escape(state_label))]
    if cert.environment:
        chips.append(badge(_CHIP_BG, '#FFFFFF', escape(str(cert.environment).upper())))
    if cert.expiry_date:
        chips.append(badge(_CHIP_BG, '#FFFFFF', cert.expiry_date.strftime('%d %b %Y').upper()))

    name_esc = escape(cert.certificate_name or 'Certificate')
    state_block = callout(tone_name, escape(headline), escape(action))
    hero = hero_rows('NPG APP ASSIST &middot; CERTIFICATE EXPIRY ALERT', name_esc, chips)
    footer = footer_rows('Security &middot; Certificate Monitoring')

    return f"""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>NPG App Assist &mdash; Certificate expiry alert</title>
  <!--[if mso]>
  <xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch><o:AllowPNG/></o:OfficeDocumentSettings></xml>
  <style type="text/css">table {{border-collapse:collapse;}} td {{mso-line-height-rule:exactly;}}</style>
  <![endif]-->
  <style type="text/css">
    body, table, td {{ -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }}
    table {{ border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }}
    a {{ color:{_NPG_RED}; text-decoration:none; }}
    @media only screen and (max-width:620px) {{
      .container {{ width:100% !important; }}
      .px-32 {{ padding-left:18px !important; padding-right:18px !important; }}
    }}
  </style>
</head>
<body style="margin:0;padding:0;background-color:{_NPG_LIGHT};font-family:{_FONT};">
<div style="display:none;font-size:1px;color:{_NPG_LIGHT};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
Certificate expiry alert &mdash; {name_esc} &mdash; {escape(headline)}
</div>

<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="{_NPG_LIGHT}" style="background-color:{_NPG_LIGHT};">
  <tr><td align="center" style="padding:34px 16px 40px 16px;">
    <!--[if mso]><table role="presentation" align="center" cellpadding="0" cellspacing="0" border="0" width="600"><tr><td><![endif]-->
    <table role="presentation" class="container" cellpadding="0" cellspacing="0" border="0" width="600"
           style="width:600px;max-width:600px;background-color:#FFFFFF;border:1px solid {_NPG_BORDER};border-bottom-color:#C6D0DE;border-collapse:separate;border-spacing:0;border-radius:14px;">

      {hero}

      <!-- State: what it is, and what to do about it - one block, not two -->
      <tr><td class="px-32" style="padding:22px 32px 0 32px;">{state_block}</td></tr>

      <!-- Certificate details -->
      <tr><td class="px-32" style="padding:16px 32px 26px 32px;">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">{rows}</table>
      </td></tr>

      {footer}

    </table>
    <!--[if mso]></td></tr></table><![endif]-->
  </td></tr>
</table>
</body>
</html>"""


def _send_email(subject, recipients, html_body, cc=None):
    msg = MIMEMultipart()
    msg['From'] = _EMAIL_FROM
    msg['To'] = ', '.join(recipients)
    if cc:
        msg['Cc'] = ', '.join(cc)
    msg['Subject'] = subject
    msg.attach(MIMEText(html_body, 'html'))
    # send_message() derives the envelope from To + Cc, so CC'd managers
    # receive the mail without any extra plumbing.
    with smtplib.SMTP(_SMTP_SERVER, _SMTP_PORT, timeout=30) as server:
        server.send_message(msg)


def run_certificate_expiry_check(threshold_days=None):
    """Email an alert for every certificate expiring within `threshold_days`
    (default: the 60-day warning tier).

    Cadence: a certificate is re-alerted once per calendar day and keeps being
    alerted every day until it is renewed (i.e. its expiry moves out of the
    threshold window). Tracked per-row via last_alert_sent.

    Recipients per certificate = the row's own Email field PLUS the security-team
    distribution list from the admin console. Once a certificate is inside the
    critical window (<= ALERT_MANAGER_THRESHOLD_DAYS days), the owning team's
    manager(s) - matched case-insensitively on the Owner column, plus any
    managers mapped to 'All' teams - are copied on the notice. When no manager
    is configured for the team, the alert still goes to the team Email and the
    distribution list exactly as in the warning tier. Certificates with no
    resolvable recipient at all are skipped (logged).

    Returns a stats dict. Safe to call from a scheduler - never raises.
    """
    threshold_days = ALERT_WARN_THRESHOLD_DAYS if threshold_days is None else threshold_days

    stats = {'considered': 0, 'sent': 0, 'with_managers': 0,
             'skipped_cadence': 0, 'skipped_no_recipient': 0, 'failed': 0}
    now = datetime.now()
    cutoff = date.today() + timedelta(days=threshold_days)
    # Re-alert once per calendar day: the cutoff is today's midnight, so a
    # certificate already alerted today is skipped while one last alerted on any
    # previous day is re-alerted. Anchoring to midnight (rather than a rolling
    # 24h window) makes this immune to run-time jitter - a daily 08:00 job whose
    # previous send was stamped a few seconds past 08:00 would otherwise fall
    # short of a strict 24h window and skip every other day.
    cadence_cutoff = datetime.combine(date.today(), time.min)

    db_session = get_db_session()
    try:
        distribution = get_alert_distribution(db_session)
        per_team_managers, all_team_managers = get_team_managers(db_session)
        candidate_ids = [
            row[0] for row in (
                db_session.query(CertificateRecord.id)
                .filter(CertificateRecord.expiry_date.isnot(None))
                .filter(CertificateRecord.expiry_date <= cutoff)
                .order_by(CertificateRecord.expiry_date.asc())
                .all()
            )
        ]
        for cid in candidate_ids:
            cert = db_session.query(CertificateRecord).filter_by(id=cid).first()
            if cert is None:
                continue   # deleted (e.g. mid-upload) since we listed candidates
            stats['considered'] += 1
            previous_sent = cert.last_alert_sent

            # ----- Atomic cross-process claim --------------------------------
            # A single conditional UPDATE reserves this certificate for alerting
            # by stamping last_alert_sent=now, but ONLY if it is still NULL or
            # older than the cadence window. Whichever process (Windows service
            # or an IIS worker) lands the UPDATE first gets rows==1 and owns the
            # send; any other process gets rows==0 and skips. This makes the
            # alert at-most-once even if two schedulers run simultaneously.
            rows = (
                db_session.query(CertificateRecord)
                .filter(
                    CertificateRecord.id == cid,
                    or_(
                        CertificateRecord.last_alert_sent.is_(None),
                        CertificateRecord.last_alert_sent <= cadence_cutoff,
                    ),
                )
                .update({'last_alert_sent': now}, synchronize_session=False)
            )
            db_session.commit()
            if rows == 0:
                stats['skipped_cadence'] += 1
                continue

            recipients = parse_email_list(cert.email) + distribution
            # de-dup while preserving order
            seen = set()
            recipients = [r for r in recipients if not (r.lower() in seen or seen.add(r.lower()))]
            if not recipients:
                stats['skipped_no_recipient'] += 1
                logger.warning("No recipient for expiring certificate '%s' - releasing claim.",
                               cert.certificate_name)
                _release_alert_claim(db_session, cid, now, previous_sent)
                continue

            days = cert.days_left
            # Critical tier - copy the owning team's manager(s). Managers
            # already present in To (e.g. also the team Email) are not
            # duplicated on Cc. No managers configured -> warning-tier
            # recipients only, exactly as before.
            cc = []
            if days is not None and days <= ALERT_MANAGER_THRESHOLD_DAYS:
                cc = [m for m in managers_for_owner(cert.owner, per_team_managers,
                                                    all_team_managers)
                      if m.lower() not in seen]

            state = 'EXPIRED' if (days is not None and days < 0) else f'EXPIRES IN {days}d'
            subject = f"[CERT {state}] {cert.certificate_name} ({cert.environment or 'n/a'})"
            try:
                _send_email(subject, recipients,
                            _build_alert_email_html(cert, managers_copied=bool(cc)),
                            cc=cc)
                stats['sent'] += 1
                if cc:
                    stats['with_managers'] += 1
                logger.info("Certificate expiry alert sent for '%s' to %d recipient(s)"
                            " (%d manager(s) copied).",
                            cert.certificate_name, len(recipients), len(cc))
            except Exception:
                # Send failed - give the claim back so the next run can retry
                # instead of silently burning the cadence window.
                stats['failed'] += 1
                logger.exception("Failed to send expiry alert for '%s'.", cert.certificate_name)
                _release_alert_claim(db_session, cid, now, previous_sent)
    except Exception:
        logger.exception("Certificate expiry check crashed.")
    finally:
        db_session.close()

    logger.info("Certificate expiry check complete: %s", stats)
    return stats


def _release_alert_claim(db_session, cert_id, claimed_at, previous_sent):
    """Revert an alert claim (set last_alert_sent back to its prior value).

    Conditioned on last_alert_sent still equalling our claim stamp, so we never
    clobber a fresh claim made by another process. Best-effort; never raises.
    """
    try:
        db_session.query(CertificateRecord).filter(
            CertificateRecord.id == cert_id,
            CertificateRecord.last_alert_sent == claimed_at,
        ).update({'last_alert_sent': previous_sent}, synchronize_session=False)
        db_session.commit()
    except Exception:
        logger.exception("Failed to release alert claim for certificate id=%s.", cert_id)
        try:
            db_session.rollback()
        except Exception:
            pass
