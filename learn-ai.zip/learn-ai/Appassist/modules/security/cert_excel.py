"""
cert_excel.py - Certificate Report -> professional two-sheet Excel workbook.

Produces a single .xlsx with:
    1. Report     - the dashboard in spreadsheet form: summary KPIs, plain-language
                    insights, status / expiry-timeline breakdowns, breakdowns by
                    type / environment / category, and the "needs attention" list.
    2. Inventory  - the full certificate inventory, one row per certificate, with a
                    colour-coded status chip, banded rows and an auto-filter.

Styling reuses the NPG (Northern Powergrid) red brand palette so the file reads as
a deliverable from the same system as the project-management exports.
"""

from __future__ import annotations

import io
from datetime import date, datetime

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

# Brand palette - NPG red
BRAND    = "AB1236"   # title bands
BRAND_DK = "7E0D27"   # subtitles & column-header rows
BAND     = "F1F5F9"   # zebra banding
BORDER   = "D7DEE7"
TEXT     = "1D293D"
MUTED    = "6B7280"
SECTION  = "E8EDF3"   # section sub-header fill

# Certificate status -> (fill, font) chip colours - mirrors the web UI pills.
STATUS_FILL = {
    "valid":    ("DCFCE7", "166534"),
    "warning":  ("FEF3C7", "92400E"),
    "critical": ("FEE2E2", "AB1236"),
    "expired":  ("FECACA", "7F1D1D"),
    "unknown":  ("E2E8F0", "1D293D"),
}

# Insight tone -> (fill, font) for the report sheet.
TONE_FILL = {
    "danger":  ("FEE2E2", "991B1B"),
    "warning": ("FEF3C7", "92400E"),
    "success": ("DCFCE7", "166534"),
    "info":    ("E0F2FE", "075985"),
}

_THIN = Side(style="thin", color=BORDER)
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

CENTER   = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT     = Alignment(horizontal="left", vertical="center", wrap_text=True)
LEFT_TOP = Alignment(horizontal="left", vertical="top", wrap_text=True)


def _fmt_date(value) -> str:
    if not value:
        return ""
    if isinstance(value, (date, datetime)):
        return value.strftime("%d %b %Y")
    return str(value)


def _title_band(ws, title, subtitle, ncols):
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    c = ws.cell(row=1, column=1, value=title)
    c.font = Font(name="Calibri", size=15, bold=True, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=BRAND)
    c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[1].height = 30

    if subtitle:
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
        s = ws.cell(row=2, column=1, value=subtitle)
        s.font = Font(name="Calibri", size=10, italic=True, color="FFFFFF")
        s.fill = PatternFill("solid", fgColor=BRAND_DK)
        s.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        ws.row_dimensions[2].height = 20
        return 4
    return 3


def _section(ws, row, label, ncols):
    """A merged sub-header band inside a sheet; returns the next row."""
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=label)
    c.font = Font(name="Calibri", size=11, bold=True, color=BRAND)
    c.fill = PatternFill("solid", fgColor=SECTION)
    c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    for col in range(1, ncols + 1):
        ws.cell(row=row, column=col).border = _BORDER
    ws.row_dimensions[row].height = 22
    return row + 1


def _header_row(ws, row, headers):
    for col, label in enumerate(headers, start=1):
        cell = ws.cell(row=row, column=col, value=label)
        cell.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=BRAND_DK)
        cell.alignment = CENTER
        cell.border = _BORDER
    ws.row_dimensions[row].height = 24


def _autosize(ws, widths):
    for idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width


def _style_cell(cell, banded=False, center=False):
    cell.font = Font(name="Calibri", size=10, color=TEXT)
    cell.alignment = CENTER if center else LEFT_TOP
    cell.border = _BORDER
    if banded:
        cell.fill = PatternFill("solid", fgColor=BAND)


def _status_chip(cell, status):
    fill, font_clr = STATUS_FILL.get(status, STATUS_FILL["unknown"])
    cell.fill = PatternFill("solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=10, bold=True, color=font_clr)
    cell.alignment = CENTER
    cell.border = _BORDER


def _kv_table(ws, row, pairs):
    """A two-column label/value table; values may carry a status key for tint."""
    for i, (label, value, key) in enumerate(pairs):
        banded = (i % 2 == 1)
        lc = ws.cell(row=row, column=1, value=label)
        lc.font = Font(name="Calibri", size=10, bold=True, color=TEXT)
        lc.alignment = LEFT
        lc.border = _BORDER
        if banded:
            lc.fill = PatternFill("solid", fgColor=BAND)
        vc = ws.cell(row=row, column=2, value=value)
        if key and key in STATUS_FILL:
            _status_chip(vc, key)
        else:
            vc.font = Font(name="Calibri", size=10, color=TEXT)
            vc.alignment = CENTER
            vc.border = _BORDER
            if banded:
                vc.fill = PatternFill("solid", fgColor=BAND)
        ws.row_dimensions[row].height = 20
        row += 1
    return row


# Sheet 1: Report
def _build_report(ws, data, meta):
    NC = 2
    _autosize(ws, [40, 60])
    sub = f"Generated {meta.get('generated', '')}"
    if meta.get("generated_by"):
        sub += f" by {meta['generated_by']}"
    row = _title_band(ws, "Certificate Report - Infrastructure Security", sub, NC)

    # Summary KPIs
    row = _section(ws, row, "Summary", NC)
    row = _kv_table(ws, row, [
        ("Total certificates tracked", data["total"], None),
        ("Valid (90+ days)", data["valid"], "valid"),
        ("Expiring (31-90 days)", data["warning"], "warning"),
        ("Critical (<=30 days)", data["critical"], "critical"),
        ("Expired", data["expired"], "expired"),
    ])
    row += 1

    # Insights
    if data.get("insights"):
        row = _section(ws, row, "Insights", NC)
        for tone, text in data["insights"]:
            ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=NC)
            c = ws.cell(row=row, column=1, value=text)
            fill, font_clr = TONE_FILL.get(tone, TONE_FILL["info"])
            c.fill = PatternFill("solid", fgColor=fill)
            c.font = Font(name="Calibri", size=10, color=font_clr)
            c.alignment = LEFT
            for col in range(1, NC + 1):
                ws.cell(row=row, column=col).border = _BORDER
            ws.row_dimensions[row].height = 30
            row += 1
        row += 1

    # Breakdown tables (label, count)
    def breakdown(title, mapping):
        nonlocal row
        row = _section(ws, row, title, NC)
        _header_row(ws, row, [title.split(" by ")[-1] if " by " in title else "Bucket", "Count"])
        row += 1
        items = mapping.items() if hasattr(mapping, "items") else mapping
        for i, (label, count) in enumerate(items):
            banded = (i % 2 == 1)
            lc = ws.cell(row=row, column=1, value=label)
            _style_cell(lc, banded)
            cc = ws.cell(row=row, column=2, value=count)
            _style_cell(cc, banded, center=True)
            row += 1
        row += 1

    breakdown("Expiry Timeline", data["horizon"])
    breakdown("By Type", data["by_type"])
    breakdown("By Environment", data["by_env"])
    breakdown("By Category", data["by_category"])

    # Needs Attention (<=30 days)
    row = _section(ws, row, f"Needs Attention (<=30 days) - {len(data['attention'])}", NC)
    if data["attention"]:
        # Re-purpose the two columns into a compact table via merge-free layout
        headers = ["Certificate", "Environment", "Expiry", "Days Left", "Status"]
        # Widen for this block by writing across 5 columns.
        _autosize(ws, [40, 22, 16, 12, 14])
        _header_row(ws, row, headers)
        row += 1
        for i, c in enumerate(data["attention"]):
            banded = (i % 2 == 1)
            values = [
                c.certificate_name, c.environment or "-",
                _fmt_date(c.expiry_date),
                c.days_left if c.days_left is not None else "-",
            ]
            for col, val in enumerate(values, start=1):
                _style_cell(ws.cell(row=row, column=col, value=val), banded,
                            center=(col in (3, 4)))
            _status_chip(ws.cell(row=row, column=5, value=c.status.upper()), c.status)
            row += 1
    else:
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=NC)
        c = ws.cell(row=row, column=1,
                    value="No certificates are expired or expiring within 30 days.")
        c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
        c.alignment = LEFT


# Sheet 2: Inventory
def _build_inventory(ws, certs):
    headers = ["S.No", "Certificate Name", "Type", "Hostname", "Environment",
               "Application", "Enrolled", "Validity (Yrs)", "Expiry",
               "Days Left", "Owner", "Email", "Category", "Status"]
    _autosize(ws, [7, 34, 16, 30, 16, 22, 14, 13, 14, 11, 22, 28, 16, 12])
    row = _title_band(ws, "Certificate Inventory",
                      f"{len(certs)} certificate(s) - full estate", len(headers))
    _header_row(ws, row, headers)
    ws.freeze_panes = ws.cell(row=row + 1, column=1)
    ws.auto_filter.ref = f"A{row}:{get_column_letter(len(headers))}{row}"
    header_row = row
    row += 1

    if not certs:
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=len(headers))
        c = ws.cell(row=row, column=1, value="No certificate records loaded.")
        c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
        c.alignment = CENTER
        return

    center_cols = {1, 7, 8, 9, 10, 14}
    for i, c in enumerate(certs):
        banded = (i % 2 == 1)
        values = [
            c.s_no if c.s_no is not None else "",
            c.certificate_name or "", c.cert_type or "-", c.hostname or "-",
            c.environment or "-", c.application or "-",
            _fmt_date(c.enrollment_date),
            c.validity_years if c.validity_years is not None else "-",
            _fmt_date(c.expiry_date),
            c.days_left if c.days_left is not None else "-",
            c.owner or "-", c.email or "-", c.category or "-",
        ]
        for col, val in enumerate(values, start=1):
            _style_cell(ws.cell(row=row, column=col, value=val), banded,
                        center=(col in center_cols))
        _status_chip(ws.cell(row=row, column=14, value=c.status.upper()), c.status)
        row += 1


def build_certificate_workbook(report_data, certs, meta) -> bytes:
    """Return the .xlsx bytes for the certificate report + inventory.

    `report_data` is the aggregate dict (see security.routes._compute_report_data),
    `certs` the ordered CertificateRecord list, `meta` carries generation context.
    """
    wb = Workbook()

    report = wb.active
    report.title = "Report"
    report.sheet_view.showGridLines = False
    _build_report(report, report_data, meta)

    inventory = wb.create_sheet("Inventory")
    inventory.sheet_view.showGridLines = False
    _build_inventory(inventory, certs)

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()
