"""
models.py - Infrastructure / Security module.

Four tables:

  * security_group_members        - who belongs to the Security team. Only an
                                    admin can add/remove members (see routes).
                                    A user's application role (admin /
                                    project_manager / team_member) is left
                                    untouched, so security-team access is an
                                    independent grant.
  * security_certificates         - the certificate inventory. The whole table
                                    is REPLACED on every Excel upload (truncate
                                    + reload), and is otherwise edited row-by-row
                                    by security-team members.
  * security_certificate_config   - single-row config holding the alert
                                    distribution list (the security-team emails
                                    added in the admin console).
  * security_team_managers        - manager email(s) per owning team (the
                                    inventory's Owner column). Managers are
                                    copied on expiry alerts once a certificate
                                    is inside the critical (30-day) window.

Schema mirrors the columns of the Certificate Tracker spreadsheet:
  S.No, Certificate Name, Type, Hostname, Environment, Application,
  Certificate Enrollment Date, Validity (Years), Certificate Expiry Date,
  Days Left, Owner, Email, Certificate Category.

`Days Left` and `status` are NOT stored - they are derived from
`expiry_date` so they can never go stale relative to the current date.
"""

from datetime import date

from sqlalchemy import (
    Column, Integer, String, DateTime, Date, Text, Float, ForeignKey,
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from database import Base


class SecurityGroupMember(Base):
    __tablename__ = 'security_group_members'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False, unique=True)
    added_by = Column(Integer, ForeignKey('users.id'))
    added_at = Column(DateTime, default=func.now())

    user = relationship('User', foreign_keys=[user_id])

    def __repr__(self):
        return f'<SecurityGroupMember user_id={self.user_id}>'


class CertificateRecord(Base):
    __tablename__ = 'security_certificates'

    id = Column(Integer, primary_key=True)
    # Auto-managed display sequence (1..N): assigned on upload/add, re-numbered
    # on delete (see utils.resequence_certificates). Never taken from the Excel.
    s_no = Column(Integer)
    certificate_name = Column(String(300))
    cert_type = Column(String(100))            # SSL / Root / Intermediate / Client Auth ...
    hostname = Column(String(500))             # may be a comma-separated list
    environment = Column(String(100))          # Prod / UAT / DR / Test ...
    application = Column(String(200))
    enrollment_date = Column(Date)
    validity_years = Column(Float)
    expiry_date = Column(Date)
    owner = Column(String(200))                # owning team name
    email = Column(String(500))               # owning team email(s)
    category = Column(String(100))             # Internal / External ...

    # Stamp of the last expiry-alert email sent for this certificate, used to
    # enforce the once-per-day cadence in the scheduler (re-alerts fire daily
    # until the certificate is renewed).
    last_alert_sent = Column(DateTime)

    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    @property
    def days_left(self):
        """Whole days until expiry (negative if already expired)."""
        if not self.expiry_date:
            return None
        return (self.expiry_date - date.today()).days

    @property
    def status(self):
        """Derived health bucket used for colour-coding everywhere."""
        d = self.days_left
        if d is None:
            return 'unknown'
        if d < 0:
            return 'expired'
        if d <= 30:
            return 'critical'
        if d <= 90:
            return 'warning'
        return 'valid'

    def __repr__(self):
        return f'<CertificateRecord {self.certificate_name} ({self.expiry_date})>'


class CertificateConfig(Base):
    """Single-row table holding the security-team alert distribution list."""
    __tablename__ = 'security_certificate_config'

    id = Column(Integer, primary_key=True)
    alert_emails = Column(Text)   # separator-delimited list entered in the admin console
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    updated_by = Column(String(100))

    def __repr__(self):
        return f'<CertificateConfig id={self.id}>'


# Sentinel stored in CertificateTeamManager.team meaning "every team": a
# manager mapped to it is copied on the critical alerts of ALL teams.
ALL_TEAMS_KEY = '*'


class CertificateTeamManager(Base):
    """Manager email(s) for an owning team, maintained in the admin console.

    `team` holds an Owner value from the certificate inventory (matched
    case-insensitively at alert time, so 'Network' and 'NETWORK' are the same
    team), or the ALL_TEAMS_KEY sentinel meaning the manager(s) are copied on
    every team's critical alerts. One row per team; `manager_emails` is a
    separator-delimited list, so a team can have several managers.
    """
    __tablename__ = 'security_team_managers'

    id = Column(Integer, primary_key=True)
    team = Column(String(200), nullable=False)
    manager_emails = Column(Text)
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    updated_by = Column(String(100))

    def __repr__(self):
        return f'<CertificateTeamManager team={self.team!r}>'
