"""
routes.py - Infrastructure / Security module (Certificate Report).

Access model
------------
  * Dashboard (insights)            - everyone, including guests (read-only).
  * Certificate table view          - everyone can view; only security-team
                                      members (and admins) can add/edit/delete
                                      or upload a replacement spreadsheet.
  * Admin console (upload + emails) - security-team members and admins.
  * Manage members                  - admins only.

"Security-team member" = the user's id is in security_group_members, OR the
user is an application admin (admins implicitly have access).
"""

import logging
import os
import re
import secrets
import time
from collections import Counter, OrderedDict
from datetime import date, datetime

from flask import (
    Blueprint, render_template, request, redirect, url_for, flash, jsonify,
    Response,
)
from sqlalchemy import func
from werkzeug.utils import secure_filename

from auth import get_current_user
from csrf_utils import csrf_protect
from database import get_db_session
from models import User
from .models import (
    SecurityGroupMember, CertificateRecord, CertificateConfig,
    CertificateTeamManager, ALL_TEAMS_KEY,
)
from .cert_excel import build_certificate_workbook
from .utils import (
    replace_certificates, resequence_certificates, parse_email_list,
    run_certificate_expiry_check,
    read_headers, suggest_mapping, parse_with_mapping, MODEL_FIELDS,
    ALERT_WARN_THRESHOLD_DAYS, ALERT_MANAGER_THRESHOLD_DAYS,
)

logger = logging.getLogger(__name__)

security_bp = Blueprint('security', __name__, template_folder='templates')

_ALLOWED_EXT = ('.xlsx', '.xlsm', '.xls')

# Editable fields shared by the add/edit forms (attr -> human label).
# S.No is deliberately absent: the sequence number is auto-generated (next
# free number on add, 1..N in file order on upload) and re-numbered on delete.
_FORM_FIELDS = OrderedDict([
    ('certificate_name', 'Certificate Name'),
    ('cert_type', 'Type'),
    ('hostname', 'Hostname'),
    ('environment', 'Environment'),
    ('application', 'Application'),
    ('enrollment_date', 'Certificate Enrollment Date'),
    ('validity_years', 'Validity (Years)'),
    ('expiry_date', 'Certificate Expiry Date'),
    ('owner', 'Owner'),
    ('email', 'Email'),
    ('category', 'Certificate Category'),
])


# ---------------------------------------------------------------------------
# Access helpers
# ---------------------------------------------------------------------------

def _is_member(db_session, user):
    """True if the user is an admin or a security-group member."""
    if not user:
        return False
    if user.role == 'admin':
        return True
    return (
        db_session.query(SecurityGroupMember)
        .filter_by(user_id=user.id)
        .first() is not None
    )


def _form_value(attr):
    """Read + coerce a form field for the add/edit routes."""
    from .utils import _coerce_date, _coerce_float
    raw = request.form.get(attr, '').strip()
    if attr in ('enrollment_date', 'expiry_date'):
        return _coerce_date(raw)
    if attr == 'validity_years':
        return _coerce_float(raw)
    return raw or None


# ---------------------------------------------------------------------------
# Landing + dashboard
# ---------------------------------------------------------------------------

@security_bp.route('/')
def index():
    return redirect(url_for('security.certificate_report'))


def _compute_report_data(certs):
    """Roll the certificate list up into the dashboard aggregates.

    Shared by the on-screen report and the Excel export so the two can never
    drift. Returns a dict of counts, breakdowns, the expiry timeline, the
    "needs attention" subset and the plain-language insights.
    """
    total = len(certs)
    buckets = Counter(c.status for c in certs)
    expired = buckets.get('expired', 0)
    critical = buckets.get('critical', 0)   # <= 30 days
    warning = buckets.get('warning', 0)      # 31-90 days
    valid = buckets.get('valid', 0)

    by_type = Counter((c.cert_type or 'Unknown') for c in certs)
    by_env = Counter((c.environment or 'Unknown') for c in certs)
    by_category = Counter((c.category or 'Unknown') for c in certs)

    # Expiry timeline: how many certs fall due in each horizon bucket.
    horizon = OrderedDict([
        ('Expired', 0), ('0-30 days', 0), ('31-60 days', 0),
        ('61-90 days', 0), ('91-180 days', 0), ('180+ days', 0),
    ])
    for c in certs:
        d = c.days_left
        if d is None:
            continue
        if d < 0:
            horizon['Expired'] += 1
        elif d <= 30:
            horizon['0-30 days'] += 1
        elif d <= 60:
            horizon['31-60 days'] += 1
        elif d <= 90:
            horizon['61-90 days'] += 1
        elif d <= 180:
            horizon['91-180 days'] += 1
        else:
            horizon['180+ days'] += 1

    # Soonest-expiring (and already-expired) certificates for the table.
    # Sorted here because the inventory itself is ordered by S.No, not expiry.
    attention = sorted(
        (c for c in certs if c.days_left is not None and c.days_left <= 30),
        key=lambda c: c.days_left,
    )

    # Professional, plain-language insights derived from the data.
    insights = _build_insights(total, expired, critical, warning, by_env, by_type, attention)

    return {
        'total': total, 'expired': expired, 'critical': critical,
        'warning': warning, 'valid': valid,
        'by_type': by_type, 'by_env': by_env, 'by_category': by_category,
        'horizon': horizon, 'attention': attention, 'insights': insights,
    }


def _load_inventory(db_session):
    """Inventory in S.No order, self-healing the sequence first.

    Legacy rows loaded before auto-sequencing may carry missing or duplicate
    numbers - detect that and re-number once, so the page and the Excel
    export always show a clean contiguous 1..N.
    """
    certs = db_session.query(CertificateRecord).all()
    nums = [c.s_no for c in certs]
    if certs and (None in nums or len(set(nums)) != len(nums)):
        try:
            resequence_certificates(db_session)
        except Exception:
            db_session.rollback()
            logger.exception('Failed to self-heal certificate sequence numbers')
    certs.sort(key=lambda c: (c.s_no is None, c.s_no if c.s_no is not None else 0, c.id))
    return certs


@security_bp.route('/certificates')
def certificate_report():
    """Certificate Report - a single page combining the interactive insight
    dashboard (Overview tab) and the full inventory table (Inventory tab).
    Public (guests welcome); editing is gated to security-team members."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        is_member = _is_member(db_session, user)
        certs = _load_inventory(db_session)

        data = _compute_report_data(certs)
        total = data['total']
        expired, critical = data['expired'], data['critical']
        warning, valid = data['warning'], data['valid']
        by_type, by_env, by_category = data['by_type'], data['by_env'], data['by_category']
        horizon, attention, insights = data['horizon'], data['attention'], data['insights']

        charts = {
            'status': {
                'labels': ['Valid', 'Expiring (31-90d)', 'Critical (<=30d)', 'Expired'],
                'values': [valid, warning, critical, expired],
                'colors': ['#16A34A', '#F59E0B', '#AB1236', '#7F1D1D'],
            },
            'type': {'labels': list(by_type.keys()), 'values': list(by_type.values())},
            'environment': {'labels': list(by_env.keys()), 'values': list(by_env.values())},
            'category': {'labels': list(by_category.keys()), 'values': list(by_category.values())},
            'horizon': {'labels': list(horizon.keys()), 'values': list(horizon.values())},
        }

        # The full inventory table is restricted to security-team members. The
        # Overview tab (aggregate counts, charts, the short "needs attention"
        # list) stays public, so the aggregates above are still computed from
        # every record - but the row-level inventory is only handed to members.
        inventory = certs if is_member else []

        return render_template(
            'security/certificate_report.html',
            user=user, is_member=is_member, certs=inventory,
            total=total, expired=expired, critical=critical,
            warning=warning, valid=valid,
            attention=attention, insights=insights, charts=charts,
        )
    finally:
        db_session.close()


@security_bp.route('/certificates/export.xlsx')
def export_report():
    """Download the certificate report + full inventory as a styled .xlsx.

    The workbook bundles the inventory, so it is restricted to security-team
    members (matching the Inventory tab access on the report page)."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        if not _is_member(db_session, user):
            flash('Security-team access required', 'error')
            return redirect(url_for('security.certificate_report'))

        certs = _load_inventory(db_session)
        report_data = _compute_report_data(certs)
        meta = {
            'generated': datetime.now().strftime('%d %b %Y %H:%M'),
            'generated_by': user.username if user else None,
        }
        xlsx = build_certificate_workbook(report_data, certs, meta)
    finally:
        db_session.close()

    filename = f"certificate-report-{date.today():%Y%m%d}.xlsx"
    return Response(
        xlsx,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        headers={'Content-Disposition': f'attachment; filename="{filename}"'},
    )


def _build_insights(total, expired, critical, warning, by_env, by_type, attention):
    """Return a list of (tone, text) insight tuples for the dashboard panel."""
    out = []
    if total == 0:
        out.append(('info', 'No certificates have been loaded yet. A security-team '
                            'member can upload the Certificate Tracker spreadsheet '
                            'from the Admin Console.'))
        return out

    if expired:
        out.append(('danger', f'{expired} certificate(s) have already expired and '
                              f'require immediate renewal to avoid service disruption.'))
    if critical:
        out.append(('warning', f'{critical} certificate(s) expire within the next 30 days. '
                               f'Raise renewal requests with the security team now.'))
    if not expired and not critical:
        out.append(('success', 'No certificates are expired or expiring within 30 days. '
                               'The estate is currently in good standing.'))
    if warning:
        out.append(('info', f'{warning} certificate(s) fall due in the next 31-90 days - '
                            f'a good window to plan renewals ahead of time.'))

    # Most-exposed environment among items needing attention.
    if attention:
        env_counts = Counter((c.environment or 'Unknown') for c in attention)
        top_env, top_n = env_counts.most_common(1)[0]
        out.append(('warning', f'The "{top_env}" environment carries the most near-term '
                               f'exposure with {top_n} certificate(s) due within 30 days.'))

    healthy_pct = round(100 * (total - expired - critical) / total) if total else 0
    out.append(('info', f'{healthy_pct}% of the {total} tracked certificate(s) are clear of '
                        f'the 30-day risk window.'))
    return out


# ---------------------------------------------------------------------------
# Record editing (members)
# ---------------------------------------------------------------------------

@security_bp.route('/certificates/record/add', methods=['GET', 'POST'])
@csrf_protect
def add_record():
    user = get_current_user()
    db_session = get_db_session()
    try:
        if not _is_member(db_session, user):
            flash('Security-team access required', 'error')
            return redirect(url_for('security.certificate_report'))

        if request.method == 'POST':
            data = {attr: _form_value(attr) for attr in _FORM_FIELDS}
            if not data.get('certificate_name'):
                flash('Certificate Name is required', 'error')
                return render_template('security/record_form.html', user=user,
                                       fields=_FORM_FIELDS, record=None, mode='add')
            try:
                # Auto-assign the next sequence number (S.No is not on the form).
                max_no = db_session.query(func.max(CertificateRecord.s_no)).scalar() or 0
                db_session.add(CertificateRecord(s_no=max_no + 1, **data))
                db_session.commit()
                flash('Certificate record added', 'success')
                return redirect(url_for('security.certificate_report'))
            except Exception:
                db_session.rollback()
                logger.exception('Error adding certificate record')
                flash('Error adding record', 'error')

        return render_template('security/record_form.html', user=user,
                               fields=_FORM_FIELDS, record=None, mode='add')
    finally:
        db_session.close()


@security_bp.route('/certificates/record/<int:record_id>/edit', methods=['GET', 'POST'])
@csrf_protect
def edit_record(record_id):
    user = get_current_user()
    db_session = get_db_session()
    try:
        if not _is_member(db_session, user):
            flash('Security-team access required', 'error')
            return redirect(url_for('security.certificate_report'))

        record = db_session.query(CertificateRecord).filter_by(id=record_id).first()
        if not record:
            flash('Record not found', 'error')
            return redirect(url_for('security.certificate_report'))

        if request.method == 'POST':
            if not request.form.get('certificate_name', '').strip():
                flash('Certificate Name is required', 'error')
                return render_template('security/record_form.html', user=user,
                                       fields=_FORM_FIELDS, record=record, mode='edit')
            try:
                for attr in _FORM_FIELDS:
                    setattr(record, attr, _form_value(attr))
                db_session.commit()
                flash('Certificate record updated', 'success')
                return redirect(url_for('security.certificate_report'))
            except Exception:
                db_session.rollback()
                logger.exception('Error updating certificate record %s', record_id)
                flash('Error updating record', 'error')

        return render_template('security/record_form.html', user=user,
                               fields=_FORM_FIELDS, record=record, mode='edit')
    finally:
        db_session.close()


@security_bp.route('/certificates/record/<int:record_id>/delete', methods=['POST'])
@csrf_protect
def delete_record(record_id):
    user = get_current_user()
    db_session = get_db_session()
    try:
        if not _is_member(db_session, user):
            flash('Security-team access required', 'error')
            return redirect(url_for('security.certificate_report'))
        record = db_session.query(CertificateRecord).filter_by(id=record_id).first()
        if record:
            db_session.delete(record)
            db_session.flush()
            # Close the gap: remaining records are re-numbered 1..N in the
            # same delete transaction, so S.No never shows a hole.
            resequence_certificates(db_session, commit=False)
            db_session.commit()
            flash('Certificate record deleted', 'success')
        else:
            flash('Record not found', 'error')
    except Exception:
        db_session.rollback()
        logger.exception('Error deleting certificate record %s', record_id)
        flash('Error deleting record', 'error')
    finally:
        db_session.close()
    return redirect(url_for('security.certificate_report'))


# ---------------------------------------------------------------------------
# Admin console - upload spreadsheet + alert distribution list (members)
# ---------------------------------------------------------------------------

def _distinct_owners(db_session):
    """Distinct Owner values from the inventory, de-duplicated
    case-insensitively (first-seen casing wins), sorted for display."""
    rows = (
        db_session.query(CertificateRecord.owner)
        .filter(CertificateRecord.owner.isnot(None))
        .distinct()
        .all()
    )
    seen = {}
    for (owner,) in rows:
        name = (owner or '').strip()
        key = name.lower()
        if name and key not in seen:
            seen[key] = name
    return sorted(seen.values(), key=str.lower)


@security_bp.route('/admin')
def admin_console():
    user = get_current_user()
    db_session = get_db_session()
    try:
        if not _is_member(db_session, user):
            flash('Security-team access required', 'error')
            return redirect(url_for('security.certificate_report'))
        cfg = db_session.query(CertificateConfig).first()
        cert_count = db_session.query(CertificateRecord).count()
        alert_emails = cfg.alert_emails if cfg else ''
        managers = (
            db_session.query(CertificateTeamManager)
            .order_by(CertificateTeamManager.team.asc())
            .all()
        )
        owners = _distinct_owners(db_session)
        return render_template('security/admin_console.html', user=user,
                               alert_emails=alert_emails, cert_count=cert_count,
                               managers=managers, owners=owners,
                               all_teams_key=ALL_TEAMS_KEY,
                               warn_days=ALERT_WARN_THRESHOLD_DAYS,
                               manager_days=ALERT_MANAGER_THRESHOLD_DAYS)
    finally:
        db_session.close()


def _upload_dir():
    base = os.environ.get('UPLOAD_DIR') or os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'uploads'
    )
    os.makedirs(base, exist_ok=True)
    return base

# Staged uploads waiting for the user to confirm a column mapping. Files older
# than this are purged on each new upload so abandoned staging files don't pile
# up in the uploads directory.
_STAGE_PREFIX = 'cert_stage_'
_STAGE_MAX_AGE_SEC = 3600
# Token = the random hex stem of a staged file; validated before any disk read.
_TOKEN_RE = re.compile(r'^[0-9a-f]{32}$')


def _purge_stale_staged(upload_dir):
    now = time.time()
    try:
        for name in os.listdir(upload_dir):
            if name.startswith(_STAGE_PREFIX):
                p = os.path.join(upload_dir, name)
                try:
                    if now - os.path.getmtime(p) > _STAGE_MAX_AGE_SEC:
                        os.remove(p)
                except OSError:
                    pass
    except OSError:
        pass


def _staged_path(upload_dir, token, ext):
    """Resolve a staged file path from a validated token, guarding traversal."""
    if not _TOKEN_RE.match(token or '') or ext not in _ALLOWED_EXT:
        return None
    path = os.path.join(upload_dir, f'{_STAGE_PREFIX}{token}{ext}')
    # Defence in depth: the resolved path must stay inside the uploads dir.
    if os.path.dirname(os.path.abspath(path)) != os.path.abspath(upload_dir):
        return None
    return path


@security_bp.route('/admin/upload', methods=['POST'])
@csrf_protect
def upload():
    """Step 1 - stage the file and show the column-mapping screen."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        if not _is_member(db_session, user):
            flash('Security-team access required', 'error')
            return redirect(url_for('security.certificate_report'))
    finally:
        db_session.close()

    upload_file = request.files.get('cert_file')
    if not upload_file or not upload_file.filename:
        flash('Please choose an Excel file to upload', 'error')
        return redirect(url_for('security.admin_console'))

    filename = secure_filename(upload_file.filename)
    ext = os.path.splitext(filename)[1].lower()
    if ext not in _ALLOWED_EXT:
        flash('The file must be an Excel workbook (.xlsx / .xls)', 'error')
        return redirect(url_for('security.admin_console'))

    upload_dir = _upload_dir()
    _purge_stale_staged(upload_dir)
    token = secrets.token_hex(16)
    path = os.path.join(upload_dir, f'{_STAGE_PREFIX}{token}{ext}')
    upload_file.save(path)

    try:
        headers, preview = read_headers(path)
    except ValueError as ve:
        try:
            os.remove(path)
        except OSError:
            pass
        flash(str(ve), 'error')
        return redirect(url_for('security.admin_console'))
    except Exception:
        logger.exception('Failed to read uploaded workbook headers')
        try:
            os.remove(path)
        except OSError:
            pass
        flash('The file could not be read as an Excel workbook.', 'error')
        return redirect(url_for('security.admin_console'))

    suggestion = suggest_mapping(headers)
    return render_template('security/map_columns.html', user=user,
                           fields=MODEL_FIELDS, headers=headers, preview=preview,
                           suggestion=suggestion, token=token, ext=ext,
                           original_name=filename)


@security_bp.route('/admin/upload/commit', methods=['POST'])
@csrf_protect
def upload_commit():
    """Step 2 - ingest the staged file using the chosen column mapping."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        if not _is_member(db_session, user):
            flash('Security-team access required', 'error')
            return redirect(url_for('security.certificate_report'))

        upload_dir = _upload_dir()
        token = request.form.get('token', '')
        ext = request.form.get('ext', '')
        path = _staged_path(upload_dir, token, ext)
        if not path or not os.path.isfile(path):
            flash('Your upload session expired. Please upload the file again.', 'error')
            return redirect(url_for('security.admin_console'))

        # Build {attr: column_index} from the submitted selects.
        mapping = {}
        for attr, _label, _req in MODEL_FIELDS:
            raw = request.form.get(f'map_{attr}', '')
            mapping[attr] = int(raw) if raw.isdigit() else None

        try:
            records, warnings = parse_with_mapping(path, mapping)
            count = replace_certificates(db_session, records)
            msg = f'Inventory replaced - {count} certificate(s) loaded.'
            if warnings:
                msg += f' {len(warnings)} row(s) had no valid expiry date (see logs).'
                for w in warnings[:10]:
                    logger.warning('Cert upload: %s', w)
            flash(msg, 'success')
        except ValueError as ve:
            flash(str(ve), 'error')
        except Exception:
            logger.exception('Certificate upload failed')
            flash('The file could not be processed. Previous data was left unchanged.', 'error')
        finally:
            try:
                os.remove(path)
            except OSError:
                pass

        return redirect(url_for('security.admin_console'))
    finally:
        db_session.close()


@security_bp.route('/admin/emails', methods=['POST'])
@csrf_protect
def save_emails():
    user = get_current_user()
    db_session = get_db_session()
    try:
        if not _is_member(db_session, user):
            flash('Security-team access required', 'error')
            return redirect(url_for('security.certificate_report'))

        raw = request.form.get('alert_emails', '')
        valid = parse_email_list(raw)
        normalized = ', '.join(valid)

        cfg = db_session.query(CertificateConfig).first()
        if not cfg:
            cfg = CertificateConfig()
            db_session.add(cfg)
        cfg.alert_emails = normalized
        cfg.updated_by = user.username
        db_session.commit()
        flash(f'Saved {len(valid)} alert recipient(s).', 'success')
        return redirect(url_for('security.admin_console'))
    except Exception:
        db_session.rollback()
        logger.exception('Error saving alert emails')
        flash('Error saving alert recipients', 'error')
        return redirect(url_for('security.admin_console'))
    finally:
        db_session.close()


@security_bp.route('/admin/managers/save', methods=['POST'])
@csrf_protect
def save_manager():
    """Add or update the manager email(s) for a team (or for All teams).

    The team select is populated from the inventory's distinct Owner values;
    submissions are re-validated against those values case-insensitively, and
    one row is kept per team (saving an already-mapped team updates it)."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        if not _is_member(db_session, user):
            flash('Security-team access required', 'error')
            return redirect(url_for('security.certificate_report'))

        team = request.form.get('team', '').strip()
        emails = parse_email_list(request.form.get('manager_emails', ''))
        if not team:
            flash('Please select a team', 'error')
            return redirect(url_for('security.admin_console'))
        if not emails:
            flash('Please enter at least one valid manager email address', 'error')
            return redirect(url_for('security.admin_console'))

        if team != ALL_TEAMS_KEY:
            canonical = {o.lower(): o for o in _distinct_owners(db_session)}
            match = canonical.get(team.lower())
            if not match:
                flash('Unknown team - please pick one from the Owner list', 'error')
                return redirect(url_for('security.admin_console'))
            team = match

        existing = next(
            (m for m in db_session.query(CertificateTeamManager).all()
             if (m.team or '').strip().lower() == team.lower()),
            None,
        )
        if existing:
            existing.team = team
            existing.manager_emails = ', '.join(emails)
            existing.updated_by = user.username
            verb = 'updated'
        else:
            db_session.add(CertificateTeamManager(
                team=team, manager_emails=', '.join(emails),
                updated_by=user.username))
            verb = 'added'
        db_session.commit()
        label = 'All Teams' if team == ALL_TEAMS_KEY else team
        flash(f"Manager mapping for '{label}' {verb} - {len(emails)} email(s).", 'success')
    except Exception:
        db_session.rollback()
        logger.exception('Error saving team manager mapping')
        flash('Error saving manager mapping', 'error')
    finally:
        db_session.close()
    return redirect(url_for('security.admin_console'))


@security_bp.route('/admin/managers/<int:manager_id>/delete', methods=['POST'])
@csrf_protect
def delete_manager(manager_id):
    user = get_current_user()
    db_session = get_db_session()
    try:
        if not _is_member(db_session, user):
            flash('Security-team access required', 'error')
            return redirect(url_for('security.certificate_report'))
        row = db_session.query(CertificateTeamManager).filter_by(id=manager_id).first()
        if row:
            db_session.delete(row)
            db_session.commit()
            flash('Manager mapping removed', 'success')
        else:
            flash('Manager mapping not found', 'error')
    except Exception:
        db_session.rollback()
        logger.exception('Error deleting team manager mapping %s', manager_id)
        flash('Error removing manager mapping', 'error')
    finally:
        db_session.close()
    return redirect(url_for('security.admin_console'))


@security_bp.route('/admin/run-alerts', methods=['POST'])
@csrf_protect
def run_alerts_now():
    """Manually trigger the expiry alert sweep (members)."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        if not _is_member(db_session, user):
            flash('Security-team access required', 'error')
            return redirect(url_for('security.certificate_report'))
    finally:
        db_session.close()

    stats = run_certificate_expiry_check()
    flash(f"Expiry check complete - {stats['sent']} alert(s) sent "
          f"({stats['with_managers']} with managers copied), "
          f"{stats['skipped_cadence']} within cadence window, "
          f"{stats['skipped_no_recipient']} without a recipient.", 'info')
    return redirect(url_for('security.admin_console'))


# ---------------------------------------------------------------------------
# Group membership - admin only
# ---------------------------------------------------------------------------

@security_bp.route('/members')
def manage_members():
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('security.certificate_report'))

    db_session = get_db_session()
    try:
        members = db_session.query(SecurityGroupMember).all()
        member_user_ids = {m.user_id for m in members}
        users_by_id = {
            u.id: u for u in db_session.query(User)
            .filter(User.id.in_(member_user_ids)).all()
        } if member_user_ids else {}
        member_rows = []
        for m in members:
            u = users_by_id.get(m.user_id)
            if u:
                member_rows.append({'member_id': m.id, 'user': u})
        available_q = db_session.query(User).filter(User.is_active == True)
        if member_user_ids:
            available_q = available_q.filter(~User.id.in_(member_user_ids))
        available_users = available_q.order_by(User.username).all()
        return render_template('security/manage_members.html', user=user,
                               member_rows=member_rows, available_users=available_users)
    finally:
        db_session.close()


@security_bp.route('/members/add', methods=['POST'])
@csrf_protect
def add_member():
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('security.certificate_report'))

    db_session = get_db_session()
    try:
        target_id = request.form.get('user_id')
        if not target_id:
            flash('Please select a user', 'error')
            return redirect(url_for('security.manage_members'))
        existing = db_session.query(SecurityGroupMember).filter_by(user_id=target_id).first()
        if existing:
            flash('User is already a member of the security group', 'warning')
            return redirect(url_for('security.manage_members'))
        db_session.add(SecurityGroupMember(user_id=int(target_id), added_by=user.id))
        db_session.commit()
        flash('User added to the security group', 'success')
    except Exception:
        db_session.rollback()
        logger.exception('Error adding security group member')
        flash('Error adding member', 'error')
    finally:
        db_session.close()
    return redirect(url_for('security.manage_members'))


@security_bp.route('/members/<int:member_id>/remove', methods=['POST'])
@csrf_protect
def remove_member(member_id):
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('security.certificate_report'))

    db_session = get_db_session()
    try:
        member = db_session.query(SecurityGroupMember).filter_by(id=member_id).first()
        if member:
            db_session.delete(member)
            db_session.commit()
            flash('User removed from the security group', 'success')
        else:
            flash('Member not found', 'error')
    except Exception:
        db_session.rollback()
        logger.exception('Error removing security group member %s', member_id)
        flash('Error removing member', 'error')
    finally:
        db_session.close()
    return redirect(url_for('security.manage_members'))


@security_bp.route('/about')
def about():
    user = get_current_user()
    db_session = get_db_session()
    try:
        is_member = _is_member(db_session, user)
    finally:
        db_session.close()
    return render_template('security/about.html', user=user, is_member=is_member)
