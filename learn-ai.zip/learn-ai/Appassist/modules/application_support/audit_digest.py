"""
audit_digest.py - Application Support audit-trail business logic invoked by
the scheduler.

Two jobs:

  1. run_audit_digests()        - once every night, email each tower's LEADS
                                  everything recorded against their tower in
                                  the audit log since the previous digest. A
                                  tower with no changes gets NO email.
  2. run_audit_retention_purge() - once daily, permanently delete audit-log
                                  entries older than the retention window
                                  (12 months by default).

Both open their own DB session and never raise out of the per-tower loop, so
one bad row or recipient cannot abort the whole sweep - the same resilience
pattern the to-do / certificate / health-check sweeps use.

THE WINDOW. Each digest reports the slice of the audit trail between the last
digest's window_end and now. That chain lives in app_support_audit_digest_log
(see models.AuditDigestLog) and exists so a night the scheduler was down is
picked up by the following night instead of being silently dropped. A run that
finds nothing still records its window - the row is the receipt that the slice
was examined, not that an email went out. The look-back is capped
(AUDIT_DIGEST_MAX_LOOKBACK_DAYS) so a service that was off for a month does
not produce one enormous catch-up email.

TOWER MATCHING. audit_logs.tower_name is free text written by
routes.log_audit. It is matched case-insensitively against the active towers'
names. Entries whose tower_name matches no tower - the module logs
'Administration' for admin-wide catalog changes, and 'Unknown' when it cannot
resolve one - belong to no tower and are therefore reported to nobody here;
they remain visible on the Audit Log screen.
"""

import logging
import os
from calendar import monthrange
from datetime import date, datetime, timedelta

# `col == sql_true()` rather than `col.is_(True)`: SQLAlchemy renders the
# latter as `col IS 1`, which SQLite accepts and SQL SERVER REJECTS - T-SQL
# allows IS only with NULL. Both dialects compile `== true()` to `col = 1`,
# so this form is the one that survives DATABASE_URL pointing at MSSQL.
from sqlalchemy import true as sql_true
from sqlalchemy.exc import IntegrityError

from database import get_db_session
from models import User
from .models import AppSupportTower, TowerMember, AuditLog, AuditDigestLog
from .audit_email import send_audit_digest

logger = logging.getLogger(__name__)


# How far back a catch-up digest may reach when previous runs were missed.
MAX_LOOKBACK_DAYS = int(os.environ.get('AUDIT_DIGEST_MAX_LOOKBACK_DAYS', '7'))

# How many months an audit entry is kept before the purge removes it.
# Twelve months = the "delete data which is a year old" requirement; kept as
# an env override so a longer retention can be set without a code change.
RETENTION_MONTHS = int(os.environ.get('AUDIT_RETENTION_MONTHS', '12'))

# How many days of digest-receipt rows to keep. The MOST RECENT row per tower
# is always kept regardless of age - it is what anchors the next window - so
# this only trims the history behind it.
_DIGEST_LOG_KEEP_DAYS = int(os.environ.get('AUDIT_DIGEST_LOG_KEEP_DAYS', '90'))


# ---------------------------------------------------------------------------
# Nightly digest sweep
# ---------------------------------------------------------------------------
def run_audit_digests(run_at: datetime = None) -> dict:
    """Email every tower's leads their overnight audit summary.

    Returns a small stats dict for the caller / logs. Never raises.

    quiet   towers that had no changes in the window (no email, by design)
    sent    towers whose leads were emailed
    skipped towers already digested today by another process, or with no
            lead who has an email address
    failed  towers whose digest could not be built or sent
    """
    run_at = run_at or datetime.now()
    run_date = run_at.date()
    db = get_db_session()
    sent = quiet = skipped = failed = 0
    try:
        towers = (
            db.query(AppSupportTower)
            .filter(AppSupportTower.is_active == sql_true())
            .order_by(AppSupportTower.tower_name)
            .all()
        )
        if not towers:
            logger.info('Audit digest: no active towers.')
            return {'sent': 0, 'quiet': 0, 'skipped': 0, 'failed': 0}

        # Every tower's window, then ONE pass over the audit trail covering
        # the widest of them. The alternative - a query per tower keyed on
        # lower(tower_name) - is not sargable on any backend, so it degrades
        # into one full scan of a year-deep table PER TOWER every night.
        windows = {t.id: _window_start(db, t.id, run_at) for t in towers}
        earliest = min(windows.values()) if windows else run_at
        by_name = _entries_by_tower(db, earliest, run_at)

        for tower in towers:
            try:
                outcome = _digest_one_tower(db, tower, windows[tower.id],
                                            by_name, run_at, run_date)
            except Exception:
                db.rollback()
                outcome = 'failed'
                logger.exception('Audit digest failed for tower "%s".',
                                 tower.tower_name)
            if outcome == 'sent':
                sent += 1
            elif outcome == 'quiet':
                quiet += 1
            elif outcome == 'skipped':
                skipped += 1
            else:
                failed += 1

        logger.info('Audit digest complete: %d sent, %d quiet (no changes), '
                    '%d skipped, %d failed (of %d active tower(s)).',
                    sent, quiet, skipped, failed, len(towers))
        return {'sent': sent, 'quiet': quiet, 'skipped': skipped,
                'failed': failed}
    finally:
        db.close()


def _digest_one_tower(db, tower, window_start: datetime, by_name: dict,
                      run_at: datetime, run_date: date) -> str:
    """Build and send one tower's digest. Returns 'sent' / 'quiet' /
    'skipped' / 'failed'."""
    entries = _slice_for(by_name, tower.tower_name, window_start)
    if not entries:
        # Nothing changed -> no email. The receipt is still written so the
        # window chain stays unbroken and tomorrow does not re-scan today.
        _claim(db, tower.id, run_date, window_start, run_at,
               entry_count=0, recipient_count=0)
        return 'quiet'

    leads = _lead_users(db, tower.id)
    if not leads:
        logger.warning('Tower "%s" has %d audit change(s) but no active lead '
                       'with an email address - nobody to tell.',
                       tower.tower_name, len(entries))
        _claim(db, tower.id, run_date, window_start, run_at,
               entry_count=len(entries), recipient_count=0)
        return 'skipped'

    # Cross-process idempotency: claim tonight's digest for this tower BEFORE
    # sending. A second runner (an IIS worker that also started a scheduler)
    # loses the claim and skips, so the leads get at most one email a night.
    receipt = _claim(db, tower.id, run_date, window_start, run_at,
                     entry_count=len(entries), recipient_count=len(leads))
    if receipt is None:
        return 'skipped'

    if send_audit_digest(tower.tower_name, leads, entries,
                         window_start, run_at):
        receipt.sent = True
        db.commit()
        return 'sent'

    # The send failed. Drop the receipt so this window is NOT treated as
    # reported - the next run's window_start falls back to the previous
    # successful boundary and re-covers these changes rather than losing them
    # to a transient SMTP error.
    db.delete(receipt)
    db.commit()
    return 'failed'


def _window_start(db, tower_id: int, run_at: datetime) -> datetime:
    """Where this tower's window begins: the end of its last recorded window,
    clamped to the maximum look-back. Falls back to 24 hours for a tower that
    has never been digested."""
    floor = run_at - timedelta(days=MAX_LOOKBACK_DAYS)
    last = (
        db.query(AuditDigestLog)
        .filter(AuditDigestLog.tower_id == tower_id)
        .order_by(AuditDigestLog.window_end.desc())
        .first()
    )
    start = last.window_end if last else run_at - timedelta(days=1)
    return max(start, floor)


def _entries_by_tower(db, earliest: datetime, window_end: datetime) -> dict:
    """Every audit entry in [earliest, window_end), bucketed by tower name.

    ONE time-bounded query for the whole sweep. The timestamp range is the
    selective predicate; the tower is resolved afterwards, in Python, keyed on
    the LOWER-CASED name. That indirection is deliberate: audit_logs.tower_name
    is a free-text copy taken at write time rather than a foreign key, so the
    match has to be case-insensitive - and pushing lower() into the WHERE
    clause would make the query non-sargable on every backend.

    Entries whose tower_name matches no active tower (the module writes
    'Administration' for admin-wide catalog changes, 'Unknown' when it cannot
    resolve one) simply end up in a bucket nobody reads.
    """
    rows = (
        db.query(AuditLog)
        .filter(
            AuditLog.timestamp >= earliest,
            AuditLog.timestamp < window_end,
        )
        .order_by(AuditLog.timestamp.desc())
        .all()
    )
    buckets = {}
    for row in rows:
        key = (row.tower_name or '').strip().lower()
        buckets.setdefault(key, []).append(row)
    return buckets


def _slice_for(by_name: dict, tower_name: str, window_start: datetime) -> list:
    """One tower's entries from *window_start* onwards, newest first.

    Each tower carries its own window start (a tower whose digest failed last
    night reaches further back than one whose succeeded), so the shared bulk
    load is trimmed per tower here rather than in SQL.
    """
    name = (tower_name or '').strip().lower()
    if not name:
        return []
    return [e for e in by_name.get(name, ())
            if e.timestamp is not None and e.timestamp >= window_start]


def _lead_users(db, tower_id: int) -> list:
    """The tower's leads - active users, with an email address, flagged
    is_lead on tower_members. TowerMember.is_lead is the truth; the tower's
    `tower_lead` text is only the denormalised display copy."""
    return (
        db.query(User)
        .join(TowerMember, TowerMember.user_id == User.id)
        .filter(
            TowerMember.tower_id == tower_id,
            TowerMember.is_lead == sql_true(),
            User.is_active == sql_true(),
            User.email.isnot(None),
            User.email != '',
        )
        .order_by(User.firstname, User.lastname)
        .all()
    )


def _claim(db, tower_id: int, run_date: date, window_start: datetime,
           window_end: datetime, entry_count: int, recipient_count: int):
    """Atomically claim tonight's digest for *tower_id*.

    Returns the persisted AuditDigestLog row if THIS caller won the claim, or
    None if another process already holds it - in which case that other run
    has already recorded this window, so losing is never an error. Cross-
    process safe via the UNIQUE (tower_id, run_date) constraint.
    """
    receipt = AuditDigestLog(
        tower_id=tower_id, run_date=run_date,
        window_start=window_start, window_end=window_end,
        entry_count=entry_count, recipient_count=recipient_count,
        sent=False,
    )
    db.add(receipt)
    try:
        db.commit()
        return receipt
    except IntegrityError:
        db.rollback()
        return None


def send_digest_for_tower(tower_id: int, run_at: datetime = None) -> bool:
    """Send a tower's digest on demand, ignoring the nightly claim.

    Used for a manual "send it now" / smoke test. Returns True if an email
    went out. Unlike the sweep this does NOT write a receipt, so it neither
    consumes nor advances the tower's window.
    """
    run_at = run_at or datetime.now()
    db = get_db_session()
    try:
        tower = db.query(AppSupportTower).filter_by(id=tower_id).first()
        if not tower:
            return False
        window_start = _window_start(db, tower.id, run_at)
        entries = _slice_for(_entries_by_tower(db, window_start, run_at),
                             tower.tower_name, window_start)
        leads = _lead_users(db, tower.id)
        if not entries or not leads:
            return False
        return send_audit_digest(tower.tower_name, leads, entries,
                                 window_start, run_at)
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Retention purge
# ---------------------------------------------------------------------------
def _subtract_months(when: datetime, months: int) -> datetime:
    """Return *when* shifted back by *months* calendar months.

    Calendar-accurate (not a 30-day approximation): subtracting 12 months from
    29 Feb 2028 yields 28 Feb 2027 rather than an invalid date. Keeps the
    time-of-day component.
    """
    month_index = when.month - 1 - months
    year = when.year + month_index // 12
    month = month_index % 12 + 1
    day = min(when.day, monthrange(year, month)[1])
    return when.replace(year=year, month=month, day=day)


def run_audit_retention_purge(months: int = None) -> int:
    """Delete audit-log entries older than the retention window (a year by
    default). Returns the number of rows removed. Never raises."""
    months = RETENTION_MONTHS if months is None else months
    cutoff = _subtract_months(datetime.now(), months)
    db = get_db_session()
    try:
        deleted = (
            db.query(AuditLog)
            .filter(AuditLog.timestamp < cutoff)
            .delete(synchronize_session=False)
        )
        receipts_deleted = _prune_digest_log(db)
        db.commit()
        if deleted:
            logger.info('Audit retention purge: deleted %d audit entr%s older '
                        'than %d months (before %s).',
                        deleted, 'ies' if deleted != 1 else 'y', months,
                        cutoff.strftime('%Y-%m-%d'))
        else:
            logger.info('Audit retention purge: nothing older than %d months.',
                        months)
        if receipts_deleted:
            logger.info('Audit retention purge: pruned %d stale digest '
                        'receipt(s).', receipts_deleted)
        return deleted
    except Exception:
        db.rollback()
        logger.exception('Audit retention purge failed (suppressed).')
        return 0
    finally:
        db.close()


def _prune_digest_log(db) -> int:
    """Trim old digest receipts, ALWAYS keeping each tower's ANCHOR row.

    The anchor is whichever receipt `_window_start` would read - the one with
    the greatest window_end - and it must survive at any age, because deleting
    it resets that tower's window to the 24-hour default and re-reports
    changes it has already sent.

    Anchor by window_end, NOT by max(id). The two agree while receipts are
    written in chronological order, which is the only way the sweep writes
    them - but a backfilled or repaired row breaks that tie silently, and the
    failure mode is a tower's whole history being re-emailed. Reading the same
    column the window chain reads costs one small scan and cannot drift.
    """
    cutoff = date.today() - timedelta(days=_DIGEST_LOG_KEEP_DAYS)
    anchors = {}
    for row_id, tower_id, window_end in db.query(
            AuditDigestLog.id, AuditDigestLog.tower_id,
            AuditDigestLog.window_end).all():
        best = anchors.get(tower_id)
        if best is None or (window_end, row_id) > (best[1], best[0]):
            anchors[tower_id] = (row_id, window_end)

    query = db.query(AuditDigestLog).filter(AuditDigestLog.run_date < cutoff)
    keep_ids = [row_id for row_id, _ in anchors.values()]
    if keep_ids:
        query = query.filter(AuditDigestLog.id.notin_(keep_ids))
    return query.delete(synchronize_session=False)
