"""
audit_email.py - the nightly "what changed on your tower" digest email.

Sent to a tower's LEADS once a night, listing every audit-log entry recorded
against that tower since the previous digest. If nothing was recorded, no
email is built at all - see audit_digest.py, which never calls in here with an
empty list.

Design language and Outlook-safety rules are the same as the to-do / MIMP /
health-check emails so this reads as a sibling product:

  * 100% nested <table> layout - no <div>s for structure.
  * State is a tint fill plus a hairline on ALL FOUR sides - never a coloured
    stripe down one edge.
  * Operation pills are tiny <table>s, not inline-block spans.
  * Labels are PRE-UPPERCASED in Python (the Word engine behind desktop
    Outlook ignores text-transform).
  * Solid colours only; a bgcolor attribute accompanies every
    background-color.
  * A multipart/alternative plain-text part is included for deliverability.

The body mirrors the Audit Log screen (templates/application_support/
audit_logs.html) column for column - timestamp, user, module, operation,
details - because a lead who clicks through should recognise what they read
in the email.
"""

from __future__ import annotations

import logging
import os
import smtplib
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

logger = logging.getLogger(__name__)


# SMTP (shared convention with the rest of the app)
_SMTP_SERVER = os.environ.get('SMTP_SERVER', 'mail1.northernpowergrid.com')
_SMTP_PORT = int(os.environ.get('SMTP_PORT', '25'))
_EMAIL_FROM = os.environ.get('EMAIL_FROM', 'NPgAppAssist@northernpowergrid.com')

# Optional absolute base URL for the "open the audit log" deep link, e.g.
# https://appassist.northernpowergrid.com. Left blank the email simply omits
# the link - a relative URL is useless in a mail client. The module-scoped
# name matches ROTA_APP_BASE_URL's convention; the bare APP_BASE_URL is
# honoured as a fallback so one site-wide setting serves both.
_APP_BASE_URL = (os.environ.get('APPSUPPORT_APP_BASE_URL')
                 or os.environ.get('APP_BASE_URL')
                 or '').strip().rstrip('/')

# Hard cap on how many rows are itemised. Beyond this the email states the
# overflow and points at the screen rather than shipping a thousand-row table
# that Outlook will truncate anyway.
_MAX_ROWS = int(os.environ.get('APPSUPPORT_AUDIT_DIGEST_MAX_ROWS', '150'))


# NPG palette and building blocks - imported from the shared email theme so a
# colour is defined ONCE for the whole application (email_theme.py).
from email_theme import (                             # noqa: E402
    NPG_RED as _NPG_RED, NPG_LIGHT as _NPG_LIGHT, NPG_BORDER as _NPG_BORDER,
    NPG_TEXT as _NPG_TEXT, NPG_TEXT_MUTED as _NPG_TEXT_MUTED,
    NPG_INK as _NPG_INK, CHIP_BG as _CHIP_BG, FONT as _FONT,
    badge as _badge, hero_rows, footer_rows, stat_tile, callout,
)


# Operation palettes. INSERT / UPDATE / DELETE carry the same meaning - and
# the same three tones - as the badges on the Audit Log screen. Anything else
# the module logs (REVEAL, EXPORT) falls back to neutral rather than being
# dressed up as a change it is not.
_OPERATION = {
    'INSERT': {'bg': '#E7F5EF', 'fg': '#0B5B41', 'border': '#BFE3D5', 'label': 'INSERT'},
    'UPDATE': {'bg': '#FDF2E4', 'fg': '#8A4308', 'border': '#F0D7B2', 'label': 'UPDATE'},
    'DELETE': {'bg': '#FDEEED', 'fg': '#8F1C13', 'border': '#F3C9C6', 'label': 'DELETE'},
}
_OPERATION_FALLBACK = {'bg': '#F2F5FA', 'fg': _NPG_INK, 'border': _NPG_BORDER}


def _op_palette(operation: str) -> dict:
    pal = _OPERATION.get((operation or '').upper())
    if pal:
        return pal
    fallback = dict(_OPERATION_FALLBACK)
    fallback['label'] = (operation or 'OTHER').upper()
    return fallback


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def send_audit_digest(tower_name: str, recipients: list, entries: list,
                      window_start: datetime, window_end: datetime) -> bool:
    """Email the tower's leads everything recorded on their tower in the window.

    *entries* are AuditLog rows, newest first. *recipients* are the lead User
    rows. Returns True if an email was sent, False otherwise (no recipients,
    no entries, or an SMTP failure). SMTP errors are logged and swallowed so a
    single bad tower cannot abort the whole nightly sweep - the caller treats
    False as "not reported" and re-covers the window tomorrow.
    """
    addresses = [u.email for u in recipients if getattr(u, 'email', None)]
    if not addresses:
        logger.warning('Tower "%s" has no lead email addresses - skipping '
                       'audit digest.', tower_name)
        return False
    if not entries:
        # Defensive only: the sweep already skips quiet towers, and "no
        # changes, no mail" is the stated behaviour.
        return False

    counts = _count_operations(entries)
    total = len(entries)

    try:
        msg = MIMEMultipart('alternative')
        bits = [f'{total} change{"s" if total != 1 else ""}']
        if counts['DELETE']:
            bits.append(f'{counts["DELETE"]} deleted')
        msg['Subject'] = (
            f'[App Assist] {tower_name} - audit summary: {", ".join(bits)}  |  '
            f'{window_end.strftime("%d %b %Y")}'
        )
        msg['From'] = _EMAIL_FROM
        msg['To'] = ', '.join(addresses)
        # A deletion on a supported application is worth surfacing at the top
        # of an inbox; a routine edit is not.
        msg['X-Priority'] = '2' if counts['DELETE'] else '3'

        msg.attach(MIMEText(
            _build_text(tower_name, entries, counts, window_start, window_end),
            'plain', 'utf-8'))
        msg.attach(MIMEText(
            _build_html(tower_name, entries, counts, window_start, window_end),
            'html', 'utf-8'))

        with smtplib.SMTP(_SMTP_SERVER, _SMTP_PORT, timeout=30) as server:
            server.send_message(msg)

        logger.info('Audit digest sent for tower "%s" to %d lead(s) '
                    '(%d change(s): %d insert, %d update, %d delete).',
                    tower_name, len(addresses), total, counts['INSERT'],
                    counts['UPDATE'], counts['DELETE'])
        return True

    except smtplib.SMTPException as exc:
        logger.error('SMTP error sending audit digest for tower "%s" to %s: %s',
                     tower_name, ', '.join(addresses), exc)
        return False
    except Exception:
        logger.exception('Unexpected error sending audit digest for tower "%s".',
                         tower_name)
        return False


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------
def _count_operations(entries: list) -> dict:
    counts = {'INSERT': 0, 'UPDATE': 0, 'DELETE': 0, 'OTHER': 0}
    for e in entries:
        key = (e.operation or '').upper()
        counts[key if key in counts else 'OTHER'] += 1
    return counts


def _count_by(entries: list, attr: str) -> list:
    """(value, count) pairs ordered by count desc, then value - used for the
    'who' and 'where' summaries above the detail table."""
    tally = {}
    for e in entries:
        value = (getattr(e, attr, None) or 'Unknown').strip() or 'Unknown'
        tally[value] = tally.get(value, 0) + 1
    return sorted(tally.items(), key=lambda kv: (-kv[1], kv[0].lower()))


# ---------------------------------------------------------------------------
# Outlook-safe building blocks
# ---------------------------------------------------------------------------
def _summary_chips(pairs: list, limit: int = 6) -> str:
    """A run of 'name x3' chips. Long tails collapse into '+N more' rather
    than wrapping into a wall of pills."""
    if not pairs:
        return ''
    shown = pairs[:limit]
    cells = ''.join(
        f'<td style="padding:0 6px 6px 0;">'
        f'{_badge("#F2F5FA", _NPG_INK, _esc(name).upper() + " &middot; " + str(n), _NPG_BORDER)}'
        f'</td>'
        for name, n in shown
    )
    if len(pairs) > limit:
        cells += (
            f'<td style="padding:0 6px 6px 0;font-family:{_FONT};font-size:11px;'
            f'color:{_NPG_TEXT_MUTED};mso-line-height-rule:exactly;line-height:25px;">'
            f'+{len(pairs) - limit} more</td>'
        )
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0">'
        f'<tr>{cells}</tr></table>'
    )


def _op_pill(operation: str) -> str:
    pal = _op_palette(operation)
    return _badge(pal['bg'], pal['fg'], pal['label'], pal['border'])


# Column widths. DETAILS carries the sentence; the other four carry a stamp,
# a name, a label and a pill. Left to itself the engine divides the 536px
# evenly and the one column anyone actually reads ends up four words wide.
# ACTION rather than OPERATION as the heading for the same reason - the longer
# word needs more column than the pills underneath it do.
_COLUMNS = (
    ('WHEN', '14%'), ('WHO', '21%'), ('SECTION', '14%'),
    ('ACTION', '17%'), ('DETAILS', '34%'),
)

# Only the two free-text columns may break inside a word. Applying it to all
# five splits "Application" and rips the operation pills in half.
_BREAK = 'word-break:break-word;'


def _entry_row(entry, striped: bool) -> str:
    """One audit entry as a table row - the same five columns the Audit Log
    screen shows, minus the tower (every row in this email is that tower)."""
    bg = '#FBFCFE' if striped else '#FFFFFF'
    stamp = entry.timestamp.strftime('%d %b %H:%M') if entry.timestamp else '-'
    details = (_esc(entry.details) if entry.details
               else f'<span style="color:{_NPG_TEXT_MUTED};">-</span>')
    who_html = _esc(entry.user_name or 'Unknown')
    if entry.email:
        who_html += (
            f'<br><span style="font-size:11px;color:{_NPG_TEXT_MUTED};">'
            f'{_esc(entry.email)}</span>'
        )
    cell = (f'padding:10px 10px;border-bottom:1px solid {_NPG_BORDER};'
            f'font-family:{_FONT};font-size:12.5px;color:{_NPG_TEXT};'
            f'mso-line-height-rule:exactly;line-height:17px;vertical-align:top;')
    return (
        f'<tr bgcolor="{bg}">'
        f'<td style="{cell}white-space:nowrap;color:{_NPG_TEXT_MUTED};">{stamp}</td>'
        f'<td style="{cell}{_BREAK}">{who_html}</td>'
        f'<td style="{cell}">{_esc(entry.module or "-")}</td>'
        f'<td style="{cell}white-space:nowrap;">{_op_pill(entry.operation)}</td>'
        f'<td style="{cell}{_BREAK}">{details}</td>'
        f'</tr>'
    )


def _entry_table(entries: list) -> str:
    head_cell = (f'padding:9px 10px;font-family:{_FONT};font-size:10.5px;'
                 f'font-weight:bold;color:{_NPG_TEXT_MUTED};letter-spacing:1.2px;'
                 f'mso-line-height-rule:exactly;line-height:14px;'
                 f'white-space:nowrap;border-bottom:1px solid {_NPG_BORDER};')
    rows = ''.join(_entry_row(e, i % 2 == 1) for i, e in enumerate(entries))
    # The percentages are on the HEADER cells only - the Word engine takes its
    # column widths from the first row and ignores them everywhere else.
    head_html = ''.join(
        f'<td width="{w}" style="{head_cell}width:{w};">{label}</td>'
        for label, w in _COLUMNS
    )
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
        f'style="table-layout:fixed;border:1px solid {_NPG_BORDER};'
        f'border-collapse:separate;border-spacing:0;'
        f'border-radius:10px;overflow:hidden;">'
        f'<tr bgcolor="#F2F5FA">{head_html}</tr>'
        f'{rows}'
        f'</table>'
    )


# ---------------------------------------------------------------------------
# HTML composition
# ---------------------------------------------------------------------------
def _window_phrase(window_start: datetime, window_end: datetime) -> str:
    """'since 23:00 yesterday' reads better than two timestamps, but a
    catch-up run covering several days has to say so plainly."""
    span_hours = max((window_end - window_start).total_seconds() / 3600.0, 0)
    if span_hours <= 25:
        return (f'{window_start.strftime("%d %b %H:%M")} to '
                f'{window_end.strftime("%d %b %H:%M")}')
    days = int(round(span_hours / 24.0))
    return (f'{window_start.strftime("%d %b %H:%M")} to '
            f'{window_end.strftime("%d %b %H:%M")} - {days} days, '
            f'catching up after a missed run')


def _build_html(tower_name: str, entries: list, counts: dict,
                window_start: datetime, window_end: datetime) -> str:
    total = len(entries)
    shown = entries[:_MAX_ROWS]
    overflow = total - len(shown)
    tower = _esc(tower_name)
    window = _esc(_window_phrase(window_start, window_end))

    # The opening line. Deletions change what a lead should do about this
    # email, so they lead the sentence when there are any.
    if counts['DELETE']:
        note_tone, note_title = 'stop', 'Something was deleted'
        note_body = (
            f'<strong>{counts["DELETE"]}</strong> record'
            f'{"s were" if counts["DELETE"] != 1 else " was"} deleted on '
            f'<strong>{tower}</strong> in this window, alongside '
            f'{counts["INSERT"]} addition{"s" if counts["INSERT"] != 1 else ""} '
            f'and {counts["UPDATE"]} edit{"s" if counts["UPDATE"] != 1 else ""}. '
            f'The full list is below - please confirm each deletion was intended.'
        )
    else:
        note_tone, note_title = 'info', 'Your tower changed overnight'
        note_body = (
            f'<strong>{total}</strong> change{"s were" if total != 1 else " was"} '
            f'recorded on <strong>{tower}</strong> - '
            f'{counts["INSERT"]} addition{"s" if counts["INSERT"] != 1 else ""} and '
            f'{counts["UPDATE"]} edit{"s" if counts["UPDATE"] != 1 else ""}, '
            f'with nothing deleted. Here is everything, exactly as the audit '
            f'log records it.'
        )

    overflow_html = ''
    if overflow > 0:
        overflow_html = (
            f'<tr><td style="padding-top:12px;font-family:{_FONT};font-size:12px;'
            f'color:{_NPG_TEXT_MUTED};mso-line-height-rule:exactly;line-height:18px;">'
            f'Showing the {len(shown)} most recent of {total} changes. '
            f'The remaining {overflow} are on the Audit Log screen in App Assist.'
            f'</td></tr>'
        )

    link_html = ''
    if _APP_BASE_URL:
        href = (f'{_APP_BASE_URL}/application-support/audit-logs'
                f'?tower_name={_url_q(tower_name)}')
        link_html = (
            f'<tr><td style="padding-top:16px;font-family:{_FONT};font-size:12.5px;'
            f'mso-line-height-rule:exactly;line-height:18px;">'
            f'<a href="{href}" style="color:{_NPG_RED};font-weight:bold;'
            f'text-decoration:none;">Open the full audit log for {tower}</a>'
            f'</td></tr>'
        )

    people = _summary_chips(_count_by(entries, 'user_name'))
    sections = _summary_chips(_count_by(entries, 'module'))

    hero = hero_rows(
        'NPG APP ASSIST &middot; APPLICATION SUPPORT',
        f'{tower} - overnight audit summary',
        [
            _badge(_CHIP_BG, '#FFFFFF', f'{total} CHANGE{"S" if total != 1 else ""}'),
            _badge(_CHIP_BG, '#FFFFFF', window_end.strftime('%d %b %Y').upper()),
        ],
    )
    footer = footer_rows('Application Support')

    return f"""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>NPG App Assist &mdash; {tower} audit summary</title>
  <!--[if mso]>
  <xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch><o:AllowPNG/></o:OfficeDocumentSettings></xml>
  <style type="text/css">table {{border-collapse:collapse;}} td {{mso-line-height-rule:exactly;}}</style>
  <![endif]-->
  <style type="text/css">
    body, table, td {{ -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }}
    table {{ border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }}
    a {{ color:{_NPG_RED}; text-decoration:none; }}
    @media only screen and (max-width:620px) {{
      .container {{ width:100% !important; }}
      .px-32 {{ padding-left:18px !important; padding-right:18px !important; }}
      .stat-cell {{ display:block !important; width:100% !important; padding:0 0 6px 0 !important; }}
    }}
  </style>
</head>
<body style="margin:0;padding:0;background-color:{_NPG_LIGHT};font-family:{_FONT};">
<div style="display:none;font-size:1px;color:{_NPG_LIGHT};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
{tower} audit summary &mdash; {total} change(s): {counts['INSERT']} added, {counts['UPDATE']} edited, {counts['DELETE']} deleted
</div>

<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="{_NPG_LIGHT}" style="background-color:{_NPG_LIGHT};">
  <tr><td align="center" style="padding:34px 16px 40px 16px;">
    <!--[if mso]><table role="presentation" align="center" cellpadding="0" cellspacing="0" border="0" width="600"><tr><td><![endif]-->
    <table role="presentation" class="container" cellpadding="0" cellspacing="0" border="0" width="600"
           style="width:600px;max-width:600px;background-color:#FFFFFF;border:1px solid {_NPG_BORDER};border-bottom-color:#C6D0DE;border-collapse:separate;border-spacing:0;border-radius:14px;">

      <!-- Header (shared NPG theme: flat maroon masthead) -->
      {hero}

      <!-- Opening note -->
      <tr><td class="px-32" style="padding:24px 32px 0 32px;">
        {callout(note_tone, note_title, note_body)}
      </td></tr>

      <!-- Stat strip -->
      <tr><td class="px-32" style="padding:20px 32px 0 32px;">
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
          <td class="stat-cell" width="33%" valign="top" style="padding-right:6px;">
            {stat_tile(counts['INSERT'], 'Added', 'ok')}</td>
          <td class="stat-cell" width="34%" valign="top" style="padding:0 3px;">
            {stat_tile(counts['UPDATE'], 'Edited', 'warn')}</td>
          <td class="stat-cell" width="33%" valign="top" style="padding-left:6px;">
            {stat_tile(counts['DELETE'], 'Deleted', 'stop')}</td>
        </tr></table>
      </td></tr>

      <!-- Who and where -->
      <tr><td class="px-32" style="padding:22px 32px 0 32px;">
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
          <tr><td style="font-family:{_FONT};font-size:10.5px;font-weight:bold;
                     color:{_NPG_TEXT_MUTED};letter-spacing:1.5px;
                     mso-line-height-rule:exactly;line-height:15px;padding-bottom:8px;">WHO MADE THEM</td></tr>
          <tr><td>{people}</td></tr>
          <tr><td style="font-family:{_FONT};font-size:10.5px;font-weight:bold;
                     color:{_NPG_TEXT_MUTED};letter-spacing:1.5px;
                     mso-line-height-rule:exactly;line-height:15px;padding:10px 0 8px 0;">WHERE</td></tr>
          <tr><td>{sections}</td></tr>
        </table>
      </td></tr>

      <!-- Detail table -->
      <tr><td class="px-32" style="padding:22px 32px 26px 32px;">
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
          <tr><td style="font-family:{_FONT};font-size:10.5px;font-weight:bold;
                     color:{_NPG_TEXT_MUTED};letter-spacing:1.5px;
                     mso-line-height-rule:exactly;line-height:15px;padding-bottom:4px;">EVERY CHANGE</td></tr>
          <tr><td style="font-family:{_FONT};font-size:12px;color:{_NPG_TEXT_MUTED};
                     mso-line-height-rule:exactly;line-height:18px;padding-bottom:12px;">{window}</td></tr>
          <tr><td>{_entry_table(shown)}</td></tr>
          {overflow_html}
          {link_html}
          <tr><td style="padding-top:16px;border-top:1px solid {_NPG_LIGHT};">
            <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
              <tr><td style="padding-top:12px;font-family:{_FONT};font-size:12px;
                         color:{_NPG_TEXT_MUTED};mso-line-height-rule:exactly;line-height:18px;">
                You receive this because you are a lead on {tower}. It is sent only on
                nights when something actually changed - a quiet night means no email.
              </td></tr>
            </table>
          </td></tr>
        </table>
      </td></tr>

      <!-- Footer (shared NPG theme) -->
      {footer}

    </table>
    <!--[if mso]></td></tr></table><![endif]-->
  </td></tr>
</table>
</body>
</html>"""


# ---------------------------------------------------------------------------
# Plain-text alternative
# ---------------------------------------------------------------------------
def _build_text(tower_name: str, entries: list, counts: dict,
                window_start: datetime, window_end: datetime) -> str:
    total = len(entries)
    shown = entries[:_MAX_ROWS]
    lines = [
        f'NPG APP ASSIST - {tower_name.upper()} - OVERNIGHT AUDIT SUMMARY',
        '=' * 60,
        _window_phrase(window_start, window_end),
        '',
        f'{total} change(s): {counts["INSERT"]} added, {counts["UPDATE"]} edited, '
        f'{counts["DELETE"]} deleted.',
    ]
    if counts['OTHER']:
        lines.append(f'{counts["OTHER"]} other recorded action(s).')
    lines.append('')

    lines.append('WHO MADE THEM')
    lines.append('-' * 60)
    for name, n in _count_by(entries, 'user_name')[:10]:
        lines.append(f'  {name} - {n}')
    lines.append('')

    lines.append('EVERY CHANGE')
    lines.append('-' * 60)
    for e in shown:
        stamp = e.timestamp.strftime('%d %b %H:%M') if e.timestamp else '-'
        lines.append(f'  [{stamp}] {(e.operation or "").upper()} - {e.module or "-"}')
        lines.append(f'         by {e.user_name or "Unknown"}'
                     + (f' ({e.email})' if e.email else ''))
        if e.details:
            lines.append(f'         {e.details}')
    if total > len(shown):
        lines.append('')
        lines.append(f'  ... and {total - len(shown)} more on the Audit Log screen.')
    lines.append('')
    if _APP_BASE_URL:
        lines.append(f'{_APP_BASE_URL}/application-support/audit-logs'
                     f'?tower_name={_url_q(tower_name)}')
        lines.append('')
    lines.append(f'You receive this because you are a lead on {tower_name}.')
    lines.append('Sent only on nights when something changed.')
    lines.append('NPG App Assist - Application Support - Generated automatically - Do not reply')
    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _esc(text) -> str:
    if text is None:
        return ''
    return (str(text)
            .replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;'))


def _url_q(text) -> str:
    """Percent-encode a tower name for the audit-log deep link. The value goes
    into a query string, so quote_plus (spaces as +) is the right encoder, and
    the result is then HTML-escaped by virtue of containing no unsafe
    characters."""
    from urllib.parse import quote_plus
    return quote_plus(str(text or ''))
