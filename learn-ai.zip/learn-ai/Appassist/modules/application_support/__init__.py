from flask import Blueprint

application_support_bp = Blueprint('application_support', __name__)

from . import routes
