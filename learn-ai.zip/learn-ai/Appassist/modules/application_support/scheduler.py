"""
scheduler.py - Application Support background scheduler.

Mirrors the to-do / certificate-monitor lifecycle: an in-process APScheduler
BackgroundScheduler running TWO daily cron jobs, with its OWN jobstore table
(``apscheduler_jobs_app_support``) so it never loads or fires the health-check
/ MIMP / to-do jobs.

  * app_support_audit_digest - every night at APPSUPPORT_AUDIT_DIGEST_HOUR:
                               MINUTE (23:00 local by default). Emails each
                               tower's leads every audit-log entry recorded
                               against their tower since the previous run.
                               A tower with nothing to report gets no email.
  * app_support_audit_purge  - daily at APPSUPPORT_AUDIT_PURGE_HOUR:MINUTE
                               (03:10 local by default). Deletes audit-log
                               entries older than the retention window
                               (12 months).

The purge runs AFTER the digest, not before, and hours apart from it: a purge
that ran first could in principle delete an entry on the same night it was
meant to be reported. Twelve months makes that impossible in practice, but the
ordering is free and the invariant is worth keeping.

Deployment model (identical to the other schedulers):
  * The dedicated Windows service (health_monitor_app_sched.py) owns the
    schedule in production and calls init_app_support_monitoring().
  * The in-process Flask scheduler may also start it, guarded by
    RUN_SCHEDULERS_IN_APP in main_app.py. Both jobs are daily cron jobs with
    coalesce=True and max_instances=1, and the digest additionally claims each
    (tower, night) through a UNIQUE row in app_support_audit_digest_log before
    sending, so a second runner cannot duplicate an email.
"""

import logging
import os
import threading
from typing import Optional

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from tzlocal import get_localzone

from database import engine
from .audit_digest import run_audit_digests, run_audit_retention_purge

logger = logging.getLogger(__name__)

# Nightly digest time (local). 23:00 is the requirement; overridable with
# APPSUPPORT_AUDIT_DIGEST_HOUR / _MINUTE.
_DIGEST_HOUR = int(os.environ.get('APPSUPPORT_AUDIT_DIGEST_HOUR', '23'))
_DIGEST_MINUTE = int(os.environ.get('APPSUPPORT_AUDIT_DIGEST_MINUTE', '0'))

# Retention purge time (local). Kept well clear of the digest and off the top
# of the hour so the two never contend for the SQLite write lock.
_PURGE_HOUR = int(os.environ.get('APPSUPPORT_AUDIT_PURGE_HOUR', '3'))
_PURGE_MINUTE = int(os.environ.get('APPSUPPORT_AUDIT_PURGE_MINUTE', '10'))

_JOBSTORE_TABLE = os.environ.get('APPSUPPORT_APSCHEDULER_TABLE',
                                 'apscheduler_jobs_app_support')
_DIGEST_JOB = 'app_support_audit_digest'
_PURGE_JOB = 'app_support_audit_purge'

_init_lock = threading.Lock()
_scheduler: Optional[BackgroundScheduler] = None


def _digest_safe():
    """Scheduler entry point - never lets an exception kill the thread."""
    try:
        run_audit_digests()
    except Exception:
        logger.exception('Application Support audit digest crashed (suppressed).')


def _purge_safe():
    try:
        run_audit_retention_purge()
    except Exception:
        logger.exception('Application Support audit purge crashed (suppressed).')


def init_app_support_monitoring() -> None:
    """Start the in-process Application Support scheduler. Idempotent."""
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            logger.info('Application Support monitoring already running - '
                        'skipping re-init.')
            return

        _scheduler = BackgroundScheduler(
            jobstores={'default': SQLAlchemyJobStore(engine=engine,
                                                     tablename=_JOBSTORE_TABLE)},
            job_defaults={'coalesce': True, 'max_instances': 1,
                          'misfire_grace_time': 3600},
            timezone=get_localzone(),
        )
        _scheduler.add_job(
            func=_digest_safe,
            trigger=CronTrigger(hour=_DIGEST_HOUR, minute=_DIGEST_MINUTE),
            id=_DIGEST_JOB,
            name=f'Application Support audit digest (daily '
                 f'{_DIGEST_HOUR:02d}:{_DIGEST_MINUTE:02d})',
            replace_existing=True,
        )
        _scheduler.add_job(
            func=_purge_safe,
            trigger=CronTrigger(hour=_PURGE_HOUR, minute=_PURGE_MINUTE),
            id=_PURGE_JOB,
            name=f'Application Support audit retention purge (daily '
                 f'{_PURGE_HOUR:02d}:{_PURGE_MINUTE:02d})',
            replace_existing=True,
        )
        _scheduler.start()
        logger.info('Application Support monitoring started - audit digest at '
                    '%02d:%02d, retention purge at %02d:%02d.',
                    _DIGEST_HOUR, _DIGEST_MINUTE, _PURGE_HOUR, _PURGE_MINUTE)


def shutdown_app_support_monitoring() -> None:
    """Cleanly stop the scheduler. Call from service teardown / atexit."""
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            _scheduler.shutdown(wait=False)
            logger.info('Application Support monitoring stopped.')
        _scheduler = None
