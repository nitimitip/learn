"""One-time backfill of the tower lead flag from the old free-text field.

Before tower leads became people, ``app_support_towers.tower_lead`` held a
typed name ("John Smith"). It is now the denormalised display copy of the
``is_lead`` flags on ``tower_members`` - and the very first save of a tower on
the new Edit Tower page recomputes it from those flags. Without this backfill
that save would silently blank a name nobody had asked to remove.

So, once, for every tower that still has text but no flagged lead: match the
text against the tower's own members by full name, then username, then email
local part, case-insensitively, and flag whoever matches.

Deliberately conservative:

  * only the tower's EXISTING members are considered - a lead is always a
    member, and enrolling someone new is a membership decision, not a
    migration's to make;
  * a name that matches nobody is LEFT AS TEXT. The tower keeps reading
    correctly everywhere, and the Edit Tower page shows the unmatched name so
    an admin can add that person as a member and pick them properly;
  * it never clears or rewrites text, so re-running it changes nothing.

Runs at start-up, after init_db(), alongside the other idempotent bootstraps.
"""

import logging

from sqlalchemy import inspect

from models import User
from .models import AppSupportTower, TowerMember

logger = logging.getLogger(__name__)

# Comma / semicolon / newline, the same separators AppSupportTower splits on -
# a legacy field occasionally held two names already.
from .models import _SEPARATORS


def _candidate_keys(user):
    """Every spelling of a person we are willing to match a typed name to."""
    keys = set()
    full = f"{user.firstname or ''} {user.lastname or ''}".strip()
    if full:
        keys.add(full.lower())
        # "Smith John" - the other order people type.
        keys.add(f"{user.lastname or ''} {user.firstname or ''}".strip().lower())
    if user.username:
        keys.add(user.username.strip().lower())
    if user.email:
        keys.add(user.email.strip().lower())
        keys.add(user.email.split('@')[0].strip().lower())
    return {k for k in keys if k}


def backfill_tower_leads(db_session):
    """Flag the members named by a tower's legacy tower_lead text.

    Returns (towers_updated, names_unmatched). Safe to call on every start-up.
    """
    engine = db_session.get_bind()
    columns = {c['name'] for c in inspect(engine).get_columns('tower_members')}
    if 'is_lead' not in columns:          # migration has not run yet
        return 0, 0

    towers = (db_session.query(AppSupportTower)
              .filter(AppSupportTower.tower_lead.isnot(None),
                      AppSupportTower.tower_lead != '')
              .all())

    updated = unmatched = 0
    for tower in towers:
        rows = (db_session.query(TowerMember, User)
                .join(User, User.id == TowerMember.user_id)
                .filter(TowerMember.tower_id == tower.id)
                .all())
        if not rows:
            unmatched += 1
            continue
        if any(m.is_lead for m, _ in rows):
            continue                      # already migrated, or already set

        wanted = {p.strip().lower() for p in _SEPARATORS.split(tower.tower_lead)
                  if p.strip()}
        matched_names = []
        for member, person in rows:
            if _candidate_keys(person) & wanted:
                member.is_lead = True
                full = f"{person.firstname or ''} {person.lastname or ''}".strip()
                matched_names.append(full or person.username)

        if matched_names:
            tower.tower_lead = ', '.join(sorted(matched_names))
            updated += 1
        else:
            unmatched += 1

    if updated:
        db_session.commit()
        logger.info("Tower lead backfill: flagged leads on %s tower(s).", updated)
    if unmatched:
        logger.info(
            "Tower lead backfill: %s tower(s) name a lead who is not one of "
            "their members - the name is kept as text until an admin adds "
            "that person and picks them on the Edit Tower page.", unmatched)
    return updated, unmatched
