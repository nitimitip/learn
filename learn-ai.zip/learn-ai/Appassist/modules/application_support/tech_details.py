"""
The Technical Details tab: compliance rules and persistence.

Two concerns live here. The RULES that govern a compliance answer - which
statuses may carry dates, what a "vendor product" answer means, how a set of
answers rolls up into a score - are plain functions over plain values, so
they can be unit-tested without a database session. Everything below them
talks to the database and keeps routes.py thin.

There is deliberately NO SEED DATA. The Technology Catalog and the Standards
Checklist are reference lists an organisation already keeps in a
spreadsheet, so they are loaded from Excel on the two admin screens (see
bulk_import.py) rather than shipped as a Python list nobody can edit. A
fresh installation therefore starts with both lists EMPTY and the admin
loads the workbook; that is the intended first-run step, not a defect.
tools/build_reference_workbook.py builds the starting workbook.

Python 3.9 compatible on purpose - production runs 3.9.
"""

from datetime import date, datetime

# `col == sql_true()` rather than `col.is_(True)`: SQLAlchemy renders
# the latter as `col IS 1`, which SQLite accepts and SQL SERVER REJECTS
# - T-SQL allows IS only with NULL. Both compile `== true()` to `= 1`.
from sqlalchemy import func, or_, true as sql_true

from .models import (
    TechCatalog, ApplicationTechStack, StandardChecklistItem,
    ApplicationStandardCompliance, TECH_CATEGORIES,
)

# ---------------------------------------------------------------------------
# Status vocabulary
# ---------------------------------------------------------------------------

STATUS_COMPLIANT = 'Compliant'
STATUS_NON_COMPLIANT = 'Non Compliant'
STATUS_NOT_STARTED = 'Not Started'
STATUS_IN_PROGRESS = 'In Progress'
STATUS_VENDOR = 'Vendor Product Compliant'

STATUSES = (
    STATUS_COMPLIANT,
    STATUS_NON_COMPLIANT,
    STATUS_NOT_STARTED,
    STATUS_IN_PROGRESS,
    STATUS_VENDOR,
)

# Start/end date are a REMEDIATION PLAN, so they only make sense while the
# work is still outstanding. Any other status clears them.
DATE_STATUSES = (STATUS_NOT_STARTED, STATUS_IN_PROGRESS)

# Statuses that count as "met" when scoring an application. A vendor product
# counts: the control is satisfied, just not by us.
PASS_STATUSES = (STATUS_COMPLIANT, STATUS_VENDOR)

# Badge class per status, used by the templates.
STATUS_BADGE = {
    STATUS_COMPLIANT: 'badge-success',
    STATUS_NON_COMPLIANT: 'badge-critical',
    STATUS_NOT_STARTED: 'badge-neutral',
    STATUS_IN_PROGRESS: 'badge-warning',
    STATUS_VENDOR: 'badge-info',
}

# Pre-filled when the answer is "Vendor Product Compliant" and the assessor
# left the comment empty. Plain ASCII - production is a cp1252 console.
VENDOR_COMMENT = (
    'Vendor-supplied product. The support team has no access to the vendor '
    'code base, so this control cannot be evidenced by us; compliance is '
    'owned and attested by the vendor under the product contract.'
)


def dates_allowed(status):
    """True when a status may carry a start/end remediation date."""
    return status in DATE_STATUSES


def resolve_comment(status, comment):
    """Comment to persist: vendor boilerplate fills an empty vendor answer."""
    text = (comment or '').strip()
    if status == STATUS_VENDOR and not text:
        return VENDOR_COMMENT
    return text or None


def parse_date(value):
    """'YYYY-MM-DD' (or a date/datetime) -> date, or None. Never raises."""
    if not value:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    try:
        return datetime.strptime(str(value).strip(), '%Y-%m-%d').date()
    except (ValueError, TypeError):
        return None


def clean_entry(status, start_date=None, end_date=None, comment=None):
    """
    Normalise one submitted answer into what should be stored.

    Returns (entry, error). ``entry`` is None when the status is empty -
    meaning "no answer recorded", which is not an error. ``error`` is a
    message string when the answer is unusable.

    The date clearing here is the SERVER-SIDE half of the rule the form also
    enforces in the browser: a status that is not a planning status must not
    keep stale dates, whatever the posted form happened to contain.
    """
    status = (status or '').strip()
    if not status:
        return None, None
    if status not in STATUSES:
        return None, 'Unknown status: {0}'.format(status)

    start = parse_date(start_date)
    end = parse_date(end_date)
    if not dates_allowed(status):
        start = None
        end = None
    if start and end and end < start:
        return None, 'End date cannot be earlier than the start date.'

    return {
        'status': status,
        'start_date': start,
        'end_date': end,
        'comment': resolve_comment(status, comment),
    }, None


def scope_key(scope, catalog_id=None):
    """
    Stable key tying a checklist section to the thing that reveals it.

    'general' is always present; every other section is keyed by its catalog
    row id, so renaming a catalog entry never orphans its checklist.
    """
    if scope == 'general':
        return 'general'
    return '{0}:{1}'.format(scope, catalog_id)


def active_scope_keys(stack_rows_):
    """
    Section keys visible for an application, given its selected stack.

    ``stack_rows_`` is any iterable of objects (or dicts) carrying
    ``category`` and ``catalog_id``. A row typed in free-hand with no
    catalog link simply contributes no checklist section - there is nothing
    to attach.
    """
    keys = set(['general'])
    for row in stack_rows_:
        if isinstance(row, dict):
            category = row.get('category')
            catalog_id = row.get('catalog_id')
        else:
            category = getattr(row, 'category', None)
            catalog_id = getattr(row, 'catalog_id', None)
        if category and catalog_id:
            keys.add(scope_key(category, catalog_id))
    return keys


def compliance_summary(entries):
    """
    Roll a list of stored answers up into headline numbers.

    ``entries`` carry a ``status``. Every row passed in counts as answered,
    so callers pass only the rows that are currently in scope.
    """
    counts = dict((s, 0) for s in STATUSES)
    for entry in entries:
        if isinstance(entry, dict):
            status = entry.get('status')
        else:
            status = getattr(entry, 'status', None)
        if status in counts:
            counts[status] += 1
    answered = sum(counts.values())
    met = sum(counts[s] for s in PASS_STATUSES)
    return {
        'counts': counts,
        'answered': answered,
        'met': met,
        'percent': int(round(100.0 * met / answered)) if answered else 0,
    }


# ---------------------------------------------------------------------------
# Reference-data identity
# ---------------------------------------------------------------------------

def match_key(value):
    """
    The key a catalog or checklist name is MATCHED on, never displayed by.

    Casing, leading/trailing space and however many spaces somebody left
    between two words are all typing accidents, not different technologies.
    Folding them here is what makes a repeated bulk load an update rather
    than a second copy: "Oracle Database", "oracle database" and
    "Oracle  Database" are one entry, and the spelling already stored is the
    one that stays.
    """
    return ' '.join((value or '').split()).lower()


# Display metadata per catalog category: (singular label, plural label, icon).
CATEGORY_META = {
    'os': ('Operating System', 'Operating Systems', 'fa-desktop'),
    'database': ('Database', 'Databases', 'fa-database'),
    'tool': ('Tool / Product', 'Tools & Products', 'fa-toolbox'),
    'language': ('Programming Language', 'Programming Languages', 'fa-code'),
}

# Form field prefix per category, so the templates and the parser agree in
# one place instead of two.
CATEGORY_FIELD = {
    'os': 'os',
    'database': 'db',
    'tool': 'tool',
    'language': 'lang',
}


# ---------------------------------------------------------------------------
# Catalog
# ---------------------------------------------------------------------------

def catalog_options(db_session, include_inactive=False):
    """{category: [TechCatalog, ...]} ordered by sort_order then name."""
    query = db_session.query(TechCatalog)
    if not include_inactive:
        query = query.filter(TechCatalog.is_active == sql_true())
    rows = query.order_by(TechCatalog.sort_order, TechCatalog.name).all()
    grouped = dict((category, []) for category in TECH_CATEGORIES)
    for row in rows:
        grouped.setdefault(row.category, []).append(row)
    return grouped


def catalog_index(db_session):
    """
    {(category, match_key(name)): TechCatalog} over the WHOLE catalog.

    One entry per key even when history has left two rows that fold to the
    same name: the lowest id wins, so every later load keeps converging on
    the same row instead of adding another. Retired entries are indexed too -
    a load must UPDATE the retired "Oracle Database" rather than add a second
    one beside it and leave the estate pointing at the wrong row.
    """
    index = {}
    for entry in (db_session.query(TechCatalog)
                  .order_by(TechCatalog.id).all()):
        index.setdefault((entry.category, match_key(entry.name)), entry)
    return index


def find_catalog_entry(db_session, category, name):
    """The catalog entry a category/name pair refers to, or None."""
    return catalog_index(db_session).get((category, match_key(name)))


def checklist_index(db_session):
    """{(scope, catalog_id, match_key(name)): StandardChecklistItem}.

    Same convergence rule as catalog_index() - lowest id wins a fold.
    """
    index = {}
    for item in (db_session.query(StandardChecklistItem)
                 .order_by(StandardChecklistItem.id).all()):
        index.setdefault((item.scope, item.catalog_id, match_key(item.name)),
                         item)
    return index


def recarry_stack_descriptions(db_session, catalog_id, previous, new):
    """
    Move the application rows that still hold a catalog entry's OLD wording.

    A catalog entry's description is the house wording the Technical Details
    form pre-fills into an application's technology row, so re-wording the
    entry has to reach the rows that copied it - otherwise a typo stays
    frozen in every application that took it. Only rows matching ``previous``
    verbatim are carried: those provably never diverged. A row somebody has
    written over keeps exactly what they typed.

    With no previous wording there is no old text to match on, so a re-word
    carries nothing - filling in the rows that are BLANK is a separate job,
    and a separate function: see fill_blank_stack_descriptions(). Returns the
    number of rows moved.
    """
    if not previous:
        return 0
    return (db_session.query(ApplicationTechStack)
            .filter(ApplicationTechStack.catalog_id == catalog_id,
                    ApplicationTechStack.description == previous)
            .update({'description': new or None}, synchronize_session=False))


def fill_blank_stack_descriptions(db_session, catalog_id, new):
    """
    Give the catalog entry's wording to the application rows that have none.

    The form pre-fills a technology's house wording as soon as it is picked,
    so a blank row is one saved BEFORE that entry had any wording to give -
    which is every row recorded while the catalog carried names only. Those
    rows provably never diverged from the catalog: there was nothing to
    diverge from. Filling them cannot overwrite anything a team typed, which
    is exactly why this is safe to do and why it is kept apart from the
    re-word carry above, where the whole question is whether the row still
    matches.

    Rows that are blank because somebody deliberately cleared the field are
    indistinguishable from rows that were never filled, and both read better
    with the house wording than with nothing at all.

    Returns the number of rows filled; 0 when there is no wording to give.
    """
    if not (new or '').strip():
        return 0
    return (db_session.query(ApplicationTechStack)
            .filter(ApplicationTechStack.catalog_id == catalog_id,
                    or_(ApplicationTechStack.description.is_(None),
                        ApplicationTechStack.description == ''))
            .update({'description': new}, synchronize_session=False))


def catalog_in_use(db_session, catalog_id):
    """(stack_rows, checklist_items) referencing a catalog entry."""
    stack_rows = (db_session.query(func.count(ApplicationTechStack.id))
                  .filter_by(catalog_id=catalog_id).scalar() or 0)
    items = (db_session.query(func.count(StandardChecklistItem.id))
             .filter_by(catalog_id=catalog_id).scalar() or 0)
    return stack_rows, items


def checklist_in_use(db_session, checklist_id):
    """How many applications have answered a checklist item."""
    return (db_session.query(func.count(ApplicationStandardCompliance.id))
            .filter_by(checklist_id=checklist_id).scalar() or 0)


# ---------------------------------------------------------------------------
# Application technology stack
# ---------------------------------------------------------------------------

def load_stack(db_session, application_id):
    """{category: [ApplicationTechStack, ...]} for one application."""
    rows = (db_session.query(ApplicationTechStack)
            .filter_by(application_id=application_id)
            .order_by(ApplicationTechStack.id).all())
    grouped = dict((category, []) for category in TECH_CATEGORIES)
    for row in rows:
        grouped.setdefault(row.category, []).append(row)
    return grouped


def stack_rows(db_session, application_id):
    """Flat list of every stack row for one application."""
    return (db_session.query(ApplicationTechStack)
            .filter_by(application_id=application_id)
            .order_by(ApplicationTechStack.category,
                      ApplicationTechStack.id).all())


def parse_stack(form, catalog_lookup):
    """
    Turn the posted repeat-rows into [{category, catalog_id, item_name, ...}].

    ``catalog_lookup`` is {catalog_id: TechCatalog}. A row whose dropdown was
    left empty is dropped - that is how a user deletes a row without the
    remove button. An id that is not in the lookup is dropped too, rather
    than trusted: the id comes from the browser.

    A blank Description falls back to the catalog entry's own description,
    which is what the form pre-fills as soon as a technology is picked. The
    fallback is what makes that hold with JavaScript off, and it is only a
    fallback - wording the user typed is stored exactly as posted.
    """
    parsed = []
    for category in TECH_CATEGORIES:
        prefix = CATEGORY_FIELD[category]
        ids = form.getlist('{0}_item[]'.format(prefix))
        versions = form.getlist('{0}_version[]'.format(prefix))
        descriptions = form.getlist('{0}_description[]'.format(prefix))
        for index, raw_id in enumerate(ids):
            raw_id = (raw_id or '').strip()
            if not raw_id:
                continue
            try:
                catalog_id = int(raw_id)
            except (TypeError, ValueError):
                continue
            entry = catalog_lookup.get(catalog_id)
            if entry is None or entry.category != category:
                continue
            version = versions[index].strip() if index < len(versions) else ''
            description = (descriptions[index].strip()
                           if index < len(descriptions) else '')
            if not description:
                description = (entry.description or '').strip()
            parsed.append({
                'category': category,
                'catalog_id': catalog_id,
                'item_name': entry.name,
                'version': version or None,
                'description': description or None,
            })
    return parsed


def save_stack(db_session, application_id, rows):
    """
    Replace an application's stack with ``rows``.

    Replace-all matches how the rest of this module already saves its
    repeat-row sections (see _add_application_related_data in routes.py) and
    keeps the "same technology twice at different versions" case working
    without a synthetic key.
    """
    (db_session.query(ApplicationTechStack)
     .filter_by(application_id=application_id).delete())
    for row in rows:
        db_session.add(ApplicationTechStack(application_id=application_id,
                                            **row))


# ---------------------------------------------------------------------------
# Standards checklist
# ---------------------------------------------------------------------------

def load_compliance(db_session, application_id):
    """{checklist_id: ApplicationStandardCompliance} for one application."""
    rows = (db_session.query(ApplicationStandardCompliance)
            .filter_by(application_id=application_id).all())
    return dict((row.checklist_id, row) for row in rows)


def build_sections(db_session, stack, compliance, include_all=False):
    """
    Ordered checklist sections for the view and edit screens.

    ``stack`` is the flat stack-row list; ``compliance`` the map from
    load_compliance(). With ``include_all`` the result carries EVERY section
    the catalog knows about, each flagged ``active``, so the edit form can
    reveal one the instant its technology is picked without a round trip.
    Without it only the active sections come back.

    Each section is a plain dict so the templates never touch the ORM.
    """
    active_keys = active_scope_keys(stack)

    items = (db_session.query(StandardChecklistItem)
             .filter(StandardChecklistItem.is_active == sql_true())
             .order_by(StandardChecklistItem.sort_order,
                       StandardChecklistItem.id).all())

    catalog = dict((row.id, row) for row in db_session.query(TechCatalog).all())

    # Name shown for a technology section: the stack row's own name wins, so
    # a section stays labelled the way the application recorded it.
    stack_names = {}
    for row in stack:
        if row.catalog_id:
            stack_names[scope_key(row.category, row.catalog_id)] = row.item_name

    buckets = {}
    order = []
    for item in items:
        key = scope_key(item.scope, item.catalog_id)
        is_active = key in active_keys
        if not is_active and not include_all:
            continue
        if key not in buckets:
            if item.scope == 'general':
                title = 'General'
                subtitle = 'Applies to every application'
                icon = 'fa-shield-halved'
            else:
                entry = catalog.get(item.catalog_id)
                if entry is None:
                    continue
                title = stack_names.get(key, entry.name)
                subtitle = CATEGORY_META.get(item.scope, ('', '', ''))[0]
                icon = CATEGORY_META.get(item.scope, ('', '', 'fa-list'))[2]
            buckets[key] = {
                'key': key,
                'scope': item.scope,
                'catalog_id': item.catalog_id,
                'title': title,
                'subtitle': subtitle,
                'icon': icon,
                'active': is_active,
                'items': [],
            }
            order.append(key)
        buckets[key]['items'].append({
            'item': item,
            'entry': compliance.get(item.id),
        })

    sections = []
    for key in order:
        section = buckets[key]
        section['summary'] = compliance_summary(
            [row['entry'] for row in section['items'] if row['entry']])
        sections.append(section)

    # General first, then the technology sections grouped by category in the
    # same order they appear on the form.
    category_rank = dict((category, index + 1)
                         for index, category in enumerate(TECH_CATEGORIES))
    sections.sort(key=lambda s: (0 if s['scope'] == 'general' else
                                 category_rank.get(s['scope'], 99),
                                 s['title'].lower()))
    return sections


def overall_summary(sections):
    """Headline compliance numbers across the ACTIVE sections only."""
    entries = []
    total_items = 0
    for section in sections:
        if not section['active']:
            continue
        total_items += len(section['items'])
        entries.extend([row['entry'] for row in section['items'] if row['entry']])
    summary = compliance_summary(entries)
    summary['total'] = total_items
    summary['unanswered'] = total_items - summary['answered']
    return summary


def save_compliance(db_session, application_id, form, sections, user_id):
    """
    Upsert the posted answers for every item in an ACTIVE section.

    Items in inactive sections are ignored, so a hidden section's inputs -
    which the browser still submits - can never write. Existing answers for a
    technology that has just been removed are left in place: re-adding the
    technology brings the assessment back rather than starting from blank.

    Returns (saved_count, errors).
    """
    errors = []
    saved = 0
    existing = load_compliance(db_session, application_id)

    for section in sections:
        if not section['active']:
            continue
        for row in section['items']:
            item = row['item']
            entry, error = clean_entry(
                form.get('std_status_{0}'.format(item.id)),
                form.get('std_start_{0}'.format(item.id)),
                form.get('std_end_{0}'.format(item.id)),
                form.get('std_comment_{0}'.format(item.id)),
            )
            if error:
                errors.append('{0}: {1}'.format(item.name, error))
                continue

            current = existing.get(item.id)
            if entry is None:
                # Answer cleared back to "not recorded".
                if current is not None:
                    db_session.delete(current)
                continue

            if current is None:
                current = ApplicationStandardCompliance(
                    application_id=application_id, checklist_id=item.id)
                db_session.add(current)
            current.status = entry['status']
            current.start_date = entry['start_date']
            current.end_date = entry['end_date']
            current.comment = entry['comment']
            current.updated_by = user_id
            current.updated_at = datetime.now()
            saved += 1

    return saved, errors


def delete_for_application(db_session, application_id):
    """Remove an application's stack and compliance rows."""
    (db_session.query(ApplicationTechStack)
     .filter_by(application_id=application_id).delete())
    (db_session.query(ApplicationStandardCompliance)
     .filter_by(application_id=application_id).delete())
