"""
Bulk load the Technology Catalog and the Standards Checklist from Excel.

The two admin screens each maintain a reference list that an organisation
usually already keeps in a spreadsheet, so this module lets one be uploaded
whole instead of typed in a row at a time. It is deliberately narrow:

  * UPSERT ONLY, NEVER DELETE. A row in the file is matched to an existing
    entry on its natural key and updated, or inserted if there is no match.
    An entry the file does NOT mention is left completely alone. Deleting a
    catalog entry would strip the technology from every application that
    records it, and deleting a checklist item would orphan the answers
    applications have given - so the file cannot do either. Retire on the
    screen instead, or set Active to No.

  * ALL OR NOTHING. Every row is validated before anything is written. One
    bad row rejects the whole file with a per-row report, so an admin never
    has to work out which half of a 200-row load went in.

  * A COLUMN THAT IS NOT IN THE FILE IS NOT AN INSTRUCTION. Leaving out the
    Description column means "do not touch descriptions", not "blank them
    all". Only a column that is actually present can change anything.

  * THE SAME FILE LOADED TWICE CHANGES NOTHING THE SECOND TIME. A row is
    identified by its natural key - (category, name) for a technology,
    (scope, technology, practice) for a practice - folded through
    tech_details.match_key(), so capitals, leading and trailing space and a
    double space between two words are all the same entry. Re-uploading a
    workbook, or uploading a lightly retyped copy of one, updates what is
    there; it never lays down a second copy. Where an older load has already
    left two rows that fold together, the oldest wins every time, so repeat
    loads converge on one row instead of picking a different one each run.

  * THE NAME OF AN EXISTING ENTRY IS NEVER REWRITTEN. Matching ignores the
    typing accidents above, but the stored spelling stays as it is:
    application rows denormalise item_name when they are saved and are
    displayed by it, so a rename here would leave the estate half-renamed.

  * ORDER AND ACTIVE STATE ARE NOT THE FILE'S BUSINESS. The file carries
    what a technology or a practice IS, nothing about how it is presented.
    A new row lands at the end of its group in the order the file lists it,
    and starts active; an existing row keeps the position and the state the
    screen gave it. Retiring is a decision, made with the Retire button, not
    something a spreadsheet should be able to do in passing. Both columns
    are simply ignored if an older file still carries them.

Re-wording a catalog entry carries the application rows that still hold the
previous wording verbatim, exactly as the inline edit on the admin screen
does - both go through tech_details.recarry_stack_descriptions().

Python 3.9 compatible on purpose - production runs 3.9.
"""

from datetime import datetime
from io import BytesIO

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from .models import (
    StandardChecklistItem, TechCatalog, CHECKLIST_SCOPES, TECH_CATEGORIES,
)
from . import tech_details

# Brand palette - the same NPg red the profile exports use, so a downloaded
# template looks like the rest of the module's workbooks.
BRAND_DK = "7E0D27"
BAND = "F1F5F9"
BORDER_INK = "1D293D"

CATALOG_SHEET = 'Technology Catalog'
CHECKLIST_SHEET = 'Standards Checklist'
NOTES_SHEET = 'How To Use'

# (header, required, width). The header names are what an admin sees on the
# screen, so the file reads the way the page does.
CATALOG_COLUMNS = (
    ('Category', True, 22),
    ('Name', True, 34),
    ('Description', False, 70),
)
CHECKLIST_COLUMNS = (
    ('Applies To', True, 22),
    ('Technology', False, 28),
    ('Practice', True, 46),
    ('Description', False, 70),
)

GENERAL_LABEL = 'General'

# Only the first few errors are worth reading; the rest are usually the same
# mistake repeated down the column.
MAX_REPORTED_ERRORS = 50


# ---------------------------------------------------------------------------
# Cell readers
# ---------------------------------------------------------------------------

def _text(value):
    """Trimmed text for a cell. 10.0 reads back as "10", not "10.0"."""
    if value is None:
        return ''
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    if isinstance(value, datetime):
        return value.strftime('%Y-%m-%d')
    return str(value).strip()


def _norm_header(value):
    """Header text reduced to what identifies the column.

    The template marks a required column with a trailing asterisk, so
    "Category *" and "category" have to land on the same column - the file
    coming back is the one that was handed out.
    """
    return _text(value).rstrip('*').strip().lower()


def category_aliases():
    """Every spelling of a category an admin might type -> the stored key.

    The screen calls them "Databases" and the database calls them
    "database"; a file written by hand will use whichever the author saw.
    """
    aliases = {}
    for key in TECH_CATEGORIES:
        singular, plural, _icon = tech_details.CATEGORY_META[key]
        aliases[key] = key
        aliases[singular.lower()] = key
        aliases[plural.lower()] = key
    return aliases


def scope_aliases():
    """As category_aliases(), plus 'general' for the checklist's Applies To."""
    aliases = category_aliases()
    aliases[GENERAL_LABEL.lower()] = 'general'
    return aliases


# ---------------------------------------------------------------------------
# Reading a workbook
# ---------------------------------------------------------------------------

class ImportError_(Exception):
    """The file could not be read far enough to report per-row errors."""


def _pick_sheet(workbook, preferred):
    """The sheet named ``preferred`` if the file has one, else the first.

    That way the two-sheet template downloaded from either screen can be
    uploaded to either screen, and a plain single-sheet file written from
    scratch still works.
    """
    for name in workbook.sheetnames:
        if name.strip().lower() == preferred.lower():
            return workbook[name]
    return workbook[workbook.sheetnames[0]]


def _header_index(sheet, columns):
    """
    ({header: column index}, errors) from row 1, matched case-insensitively.

    Columns the file does not carry are simply absent from the map, which is
    how "do not touch this field" is expressed.
    """
    headers = {}
    for row in sheet.iter_rows(min_row=1, max_row=1, values_only=True):
        for index, value in enumerate(row):
            text = _norm_header(value)
            if text:
                headers.setdefault(text, index)
        break

    index_map, errors = {}, []
    for header, required, _width in columns:
        position = headers.get(_norm_header(header))
        if position is None:
            if required:
                errors.append('Missing required column "{0}".'.format(header))
            continue
        index_map[header] = position
    return index_map, errors


def _cell(row, index_map, header):
    position = index_map.get(header)
    if position is None or position >= len(row):
        return None
    return row[position]


def _load(stream, preferred_sheet, columns):
    """(sheet rows, header map, errors). Raises ImportError_ if unreadable."""
    try:
        workbook = load_workbook(stream, data_only=True, read_only=True)
    except Exception as exc:
        raise ImportError_(
            'That file could not be read as an Excel workbook ({0}). Save it '
            'as .xlsx and try again.'.format(exc))
    try:
        if not workbook.sheetnames:
            raise ImportError_('That workbook has no sheets.')
        sheet = _pick_sheet(workbook, preferred_sheet)
        index_map, errors = _header_index(sheet, columns)
        if errors:
            return [], index_map, errors
        rows = [(number, row) for number, row
                in enumerate(sheet.iter_rows(min_row=2, values_only=True),
                             start=2)
                if any(_text(value) for value in row)]
        return rows, index_map, []
    finally:
        workbook.close()


# ---------------------------------------------------------------------------
# Technology Catalog
# ---------------------------------------------------------------------------

def parse_catalog(stream):
    """
    (rows, errors) for the Technology Catalog sheet.

    Each row is {'category', 'name', 'description', 'sort_order', 'active',
    'row'}; a field the file has no column for is absent from the dict, so
    the apply step can tell "blank it" from "do not touch it".
    """
    rows, index_map, errors = _load(stream, CATALOG_SHEET, CATALOG_COLUMNS)
    if errors:
        return [], errors

    aliases = category_aliases()
    parsed, seen = [], {}
    for number, raw in rows:
        entry = {'row': number}
        problems = []

        category_text = _text(_cell(raw, index_map, 'Category'))
        category = aliases.get(category_text.lower())
        if not category:
            problems.append(
                'Category "{0}" is not one of {1}.'.format(
                    category_text or '(blank)', _category_help()))
        entry['category'] = category

        name = _text(_cell(raw, index_map, 'Name'))
        if not name:
            problems.append('Name is required.')
        entry['name'] = name

        if 'Description' in index_map:
            entry['description'] = _text(_cell(raw, index_map, 'Description'))

        if category and name:
            key = (category, tech_details.match_key(name))
            if key in seen:
                problems.append(
                    '"{0}" appears twice in this file (also row {1}).'.format(
                        name, seen[key]))
            else:
                seen[key] = number

        if problems:
            errors.extend('Row {0}: {1}'.format(number, p) for p in problems)
        else:
            parsed.append(entry)

    return parsed, errors


def _category_help():
    labels = []
    for key in TECH_CATEGORIES:
        labels.append(tech_details.CATEGORY_META[key][1])
    return ', '.join(labels)


def apply_catalog(db_session, rows, user_id=None, commit=True):
    """
    Upsert every parsed catalog row. Returns a counts dict.

    ``recarried`` counts the application technology rows whose Description
    moved with a re-worded catalog entry - see the module docstring - plus
    the blank rows that took the wording for the first time. A row recorded
    before its technology had any house wording has nothing in that field;
    giving it the wording cannot overwrite anything anybody typed, so the
    load fills it. See tech_details.fill_blank_stack_descriptions().
    """
    existing = tech_details.catalog_index(db_session)

    result = {'created': 0, 'updated': 0, 'unchanged': 0, 'recarried': 0}
    next_order = {}

    for row in rows:
        key = (row['category'], tech_details.match_key(row['name']))
        entry = existing.get(key)

        if entry is None:
            entry = TechCatalog(
                category=row['category'], name=row['name'],
                description=row.get('description') or None,
                sort_order=_next_sort_order(
                    db_session, next_order, key[0], TechCatalog,
                    TechCatalog.category == row['category']),
                is_active=True,
                created_by=user_id)
            db_session.add(entry)
            db_session.flush()
            existing[key] = entry
            result['created'] += 1
            continue

        # Description is the ONLY thing a file may change on an entry that
        # already exists. The stored name, its position and whether it is
        # retired all belong to the screen - see the docstring.
        changed = False
        if 'description' in row:
            previous = (entry.description or '').strip()
            new = row['description']
            if previous != new:
                entry.description = new or None
                result['recarried'] += tech_details.recarry_stack_descriptions(
                    db_session, entry.id, previous, new)
                changed = True
            # Even where the wording did not change, an application row
            # saved before it existed is still blank.
            result['recarried'] += tech_details.fill_blank_stack_descriptions(
                db_session, entry.id, new)

        result['updated' if changed else 'unchanged'] += 1

    if commit:
        db_session.commit()
    return result


# ---------------------------------------------------------------------------
# Standards Checklist
# ---------------------------------------------------------------------------

def parse_checklist(stream, db_session):
    """
    (rows, errors) for the Standards Checklist sheet.

    The technology named on a row must ALREADY be in the catalog. Creating
    it here would let a typo silently mint a whole new technology section
    that no application can ever reach, so it is an error with a pointer to
    the catalog screen instead.
    """
    rows, index_map, errors = _load(stream, CHECKLIST_SHEET, CHECKLIST_COLUMNS)
    if errors:
        return [], errors

    aliases = scope_aliases()
    catalog = tech_details.catalog_index(db_session)

    parsed, seen = [], {}
    for number, raw in rows:
        entry = {'row': number}
        problems = []

        scope_text = _text(_cell(raw, index_map, 'Applies To'))
        scope = aliases.get(scope_text.lower())
        if scope not in CHECKLIST_SCOPES:
            problems.append(
                'Applies To "{0}" is not one of {1}, {2}.'.format(
                    scope_text or '(blank)', GENERAL_LABEL, _category_help()))
            scope = None
        entry['scope'] = scope

        technology = _text(_cell(raw, index_map, 'Technology'))
        catalog_entry = None
        if scope == 'general':
            if technology:
                problems.append(
                    'A General practice must leave Technology blank.')
        elif scope:
            if not technology:
                problems.append(
                    'Technology is required unless Applies To is '
                    '{0}.'.format(GENERAL_LABEL))
            else:
                catalog_entry = catalog.get(
                    (scope, tech_details.match_key(technology)))
                if catalog_entry is None:
                    problems.append(
                        '"{0}" is not in the Technology Catalog under {1}. '
                        'Add it there first.'.format(
                            technology,
                            tech_details.CATEGORY_META[scope][1]))
        entry['catalog_id'] = catalog_entry.id if catalog_entry else None

        name = _text(_cell(raw, index_map, 'Practice'))
        if not name:
            problems.append('Practice is required.')
        entry['name'] = name

        if 'Description' in index_map:
            entry['description'] = _text(_cell(raw, index_map, 'Description'))

        if scope and name and not problems:
            key = (scope, entry['catalog_id'], tech_details.match_key(name))
            if key in seen:
                problems.append(
                    '"{0}" appears twice in this file (also row {1}).'.format(
                        name, seen[key]))
            else:
                seen[key] = number

        if problems:
            errors.extend('Row {0}: {1}'.format(number, p) for p in problems)
        else:
            parsed.append(entry)

    return parsed, errors


def apply_checklist(db_session, rows, user_id=None, commit=True):
    """Upsert every parsed checklist row. Returns a counts dict."""
    existing = tech_details.checklist_index(db_session)

    result = {'created': 0, 'updated': 0, 'unchanged': 0}
    next_order = {}
    now = datetime.now()

    for row in rows:
        key = (row['scope'], row['catalog_id'],
               tech_details.match_key(row['name']))
        item = existing.get(key)

        if item is None:
            item = StandardChecklistItem(
                scope=row['scope'], catalog_id=row['catalog_id'],
                name=row['name'], description=row.get('description') or None,
                sort_order=_next_sort_order(
                    db_session, next_order, key[:2], StandardChecklistItem,
                    StandardChecklistItem.scope == row['scope'],
                    StandardChecklistItem.catalog_id == row['catalog_id']),
                is_active=True,
                # Authored here, not shipped with the standard, so a re-seed
                # never resurrects one an admin later deletes.
                is_seeded=False,
                created_by=user_id, updated_by=user_id)
            db_session.add(item)
            db_session.flush()
            existing[key] = item
            result['created'] += 1
            continue

        # As with the catalog, the description is all a file may touch.
        changed = False
        if 'description' in row:
            new = row['description']
            if (item.description or '').strip() != new:
                item.description = new or None
                changed = True

        if changed:
            item.updated_by = user_id
            item.updated_at = now
        result['updated' if changed else 'unchanged'] += 1

    if commit:
        db_session.commit()
    return result


def _next_sort_order(db_session, cache, key, model, *filters):
    """The next slot in a group, stepping 10 at a time.

    A file that leaves Sort Order blank lands in the order its rows are
    written, after whatever is already there - which is what somebody
    pasting a list from a standards document expects.
    """
    if key not in cache:
        query = db_session.query(model.sort_order)
        for condition in filters:
            query = query.filter(condition)
        highest = max([row[0] or 0 for row in query.all()] or [0])
        cache[key] = highest
    cache[key] += 10
    return cache[key]


# ---------------------------------------------------------------------------
# The template / round-trip workbook
# ---------------------------------------------------------------------------

def _write_header(sheet, columns):
    for index, (header, required, width) in enumerate(columns, start=1):
        cell = sheet.cell(row=1, column=index,
                          value=header + (' *' if required else ''))
        cell.font = Font(bold=True, color='FFFFFF', size=10)
        cell.fill = PatternFill('solid', fgColor=BRAND_DK)
        cell.alignment = Alignment(vertical='center', horizontal='left')
        sheet.column_dimensions[get_column_letter(index)].width = width
    sheet.row_dimensions[1].height = 22
    sheet.freeze_panes = 'A2'


def _add_dropdown(sheet, column_index, values, rows=400):
    """A picker on a whole column, so most typos never reach the parser."""
    validation = DataValidation(
        type='list', formula1='"{0}"'.format(','.join(values)), allow_blank=True)
    sheet.add_data_validation(validation)
    letter = get_column_letter(column_index)
    validation.add('{0}2:{0}{1}'.format(letter, rows + 1))


def build_workbook(db_session):
    """
    The upload template, pre-filled with everything currently recorded.

    Downloading it, editing in Excel and uploading it back is the round
    trip; a brand new list can equally be typed into an empty copy. Both
    sheets are in the one file, and either screen accepts it - each applies
    only its own sheet.
    """
    workbook = Workbook()

    catalog_sheet = workbook.active
    catalog_sheet.title = CATALOG_SHEET
    _write_header(catalog_sheet, CATALOG_COLUMNS)
    category_labels = [tech_details.CATEGORY_META[key][1]
                       for key in TECH_CATEGORIES]
    _add_dropdown(catalog_sheet, 1, category_labels)

    # Retired entries are written out too - leaving them out would read as
    # "this is the whole catalog" and invite somebody to re-add one by hand.
    catalog = tech_details.catalog_options(db_session, include_inactive=True)
    row_number = 2
    for category in TECH_CATEGORIES:
        for entry in catalog.get(category, []):
            catalog_sheet.cell(row=row_number, column=1,
                               value=tech_details.CATEGORY_META[category][1])
            catalog_sheet.cell(row=row_number, column=2, value=entry.name)
            catalog_sheet.cell(row=row_number, column=3,
                               value=entry.description or '')
            row_number += 1

    checklist_sheet = workbook.create_sheet(CHECKLIST_SHEET)
    _write_header(checklist_sheet, CHECKLIST_COLUMNS)
    _add_dropdown(checklist_sheet, 1, [GENERAL_LABEL] + category_labels)

    by_id = dict((entry.id, entry)
                 for rows in catalog.values() for entry in rows)
    items = (db_session.query(StandardChecklistItem)
             .order_by(StandardChecklistItem.scope,
                       StandardChecklistItem.catalog_id,
                       StandardChecklistItem.sort_order,
                       StandardChecklistItem.id).all())
    row_number = 2
    for item in items:
        entry = by_id.get(item.catalog_id) if item.catalog_id else None
        if item.scope != 'general' and entry is None:
            continue
        checklist_sheet.cell(
            row=row_number, column=1,
            value=(GENERAL_LABEL if item.scope == 'general'
                   else tech_details.CATEGORY_META[item.scope][1]))
        checklist_sheet.cell(row=row_number, column=2,
                             value=entry.name if entry else '')
        checklist_sheet.cell(row=row_number, column=3, value=item.name)
        checklist_sheet.cell(row=row_number, column=4,
                             value=item.description or '')
        row_number += 1

    _write_notes(workbook.create_sheet(NOTES_SHEET))

    for sheet in (catalog_sheet, checklist_sheet):
        for row in sheet.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical='top', wrap_text=True)

    stream = BytesIO()
    workbook.save(stream)
    return stream.getvalue()


NOTES = (
    ('What this file does',
     'Each sheet is uploaded on its own admin screen: "{0}" on the Technical '
     'Catalog page, "{1}" on the Standards Checklist page. The same file '
     'works on both - each screen reads only its own sheet.'.format(
         CATALOG_SHEET, CHECKLIST_SHEET)),
    ('Nothing is ever deleted',
     'A row is matched to an existing entry and updated, or added if there is '
     'no match. An entry this file does not mention is left alone, and '
     'deleting a row here does nothing at all. To stop using one, press '
     'Retire on the screen.'),
    ('Only the description can change',
     'On an entry that already exists, Description is the one thing this file '
     'can alter. Where it sits in the list, and whether it is retired, belong '
     'to the screen - a new row simply lands at the end of its group, in the '
     'order it appears here, and starts active.'),
    ('One bad row rejects the file',
     'Every row is checked before anything is saved, and the screen lists the '
     'problems by row number. Fix them and upload again; a partial load never '
     'happens.'),
    ('Leaving a column out',
     'A column that is not in the sheet is not touched at all. Delete the '
     'Description column and no description changes; leave a Description cell '
     'blank and that entry\'s description is cleared.'),
    ('Names are matched, not rewritten',
     'Matching ignores capitals, but the spelling already stored is kept. To '
     'rename something, retire it on the screen and add the new name.'),
    ('Re-wording a technology',
     'A technology\'s Description is the wording pre-filled into every '
     'application\'s Technical Details tab. Changing it here also re-words the '
     'application rows that still carry the old wording; one a team has '
     'written over keeps what they typed.'),
    ('Technology must already exist',
     'A checklist row naming a technology that is not in the catalog is an '
     'error, so a typo cannot mint a section no application can reach. Load '
     'the catalog sheet first.'),
)


def _write_notes(sheet):
    sheet.column_dimensions['A'].width = 30
    sheet.column_dimensions['B'].width = 96

    title = sheet.cell(row=1, column=1, value='How to use this workbook')
    title.font = Font(bold=True, size=13, color=BRAND_DK)
    sheet.cell(row=1, column=2, value='')

    row_number = 3
    for heading, body in NOTES:
        head = sheet.cell(row=row_number, column=1, value=heading)
        head.font = Font(bold=True, size=10, color=BORDER_INK)
        head.alignment = Alignment(vertical='top', wrap_text=True)
        text = sheet.cell(row=row_number, column=2, value=body)
        text.alignment = Alignment(vertical='top', wrap_text=True)
        if row_number % 2:
            for column in (1, 2):
                sheet.cell(row=row_number, column=column).fill = PatternFill(
                    'solid', fgColor=BAND)
        sheet.row_dimensions[row_number].height = 34
        row_number += 1
