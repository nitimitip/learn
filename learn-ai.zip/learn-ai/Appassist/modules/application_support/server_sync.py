"""
Keeps an application's Server Details in step with the Utility module's
server estate (the ``server_data`` table behind Utility > Server Search).

The estate list is the system of record for a server's Location, Operating
System and Environment; Application Support only records WHICH servers an
application runs on. So the same three values are derived from the estate in
two places, and both go through this module:

  * the type-ahead on the add / edit application forms, which auto-fills the
    row the moment a known server name is picked, and
  * the re-sync that runs after the estate is re-imported, which refreshes
    every already-saved row.

A Server Details row whose hostname is NOT in the estate is left exactly as
it is. That is how external / third-party servers - which never appear in the
estate file - keep the details somebody typed by hand.

Python 3.9 compatible on purpose - production runs 3.9.
"""

from modules.utility.servers_models import ServerData

from .models import ServerDetails

# Environment is recorded as "<Environment> : <Application Name>" so the row
# says both WHICH tier the server is and WHAT the estate believes runs on it.
ENVIRONMENT_SEPARATOR = ' : '


def norm_hostname(name):
    """Lower-cased, trimmed, FQDN-stripped hostname - the same join rule as
    tools/export_infrastructure_report.py uses against server_data."""
    return (name or '').strip().lower().split('.')[0]


def os_label(os_name, os_version):
    """"Windows Server 2019" from the estate's two separate columns."""
    return ' '.join(part for part in ((os_name or '').strip(),
                                      (os_version or '').strip()) if part)


def environment_label(environment, application_name):
    """"PROD : SAP ECC" - either half is dropped when the estate is silent
    about it, so a half-populated row never reads as " : SAP ECC"."""
    return ENVIRONMENT_SEPARATOR.join(
        part for part in ((environment or '').strip(),
                          (application_name or '').strip()) if part)


def estate_entry(server):
    """The four values a Server Details row takes from one estate record."""
    return {
        'name': (server.server_name or '').strip(),
        'location': (server.location or '').strip(),
        'os': os_label(server.OS, server.os_version),
        'environment': environment_label(server.environment,
                                         server.application_name),
    }


def estate_index(db_session):
    """{normalised hostname: estate_entry} for the whole estate.

    The estate routinely carries the same host more than once (one row per
    installed product, say); the first row wins, which is the same rule the
    type-ahead already applies.
    """
    index = {}
    rows = (db_session.query(ServerData)
            .filter(ServerData.server_name.isnot(None))
            .order_by(ServerData.id).all())
    for server in rows:
        key = norm_hostname(server.server_name)
        if key:
            index.setdefault(key, estate_entry(server))
    return index


def sync_server_details(db_session, commit=True):
    """
    Refresh every saved Server Details row that names a server in the estate.

    Called after the estate is re-imported, and from the manual re-sync
    button next to it. Returns
    ``{'matched': n, 'updated': n, 'external': n}`` where ``external``
    counts the rows the estate does not know about - left untouched on
    purpose, see the module docstring.
    """
    index = estate_index(db_session)
    matched = updated = external = 0

    for row in db_session.query(ServerDetails).all():
        entry = index.get(norm_hostname(row.server_name))
        if entry is None:
            external += 1
            continue
        matched += 1
        changed = False
        for attribute, key in (('location', 'location'),
                               ('operating_system', 'os'),
                               ('environment_description', 'environment')):
            value = entry[key]
            # An estate with nothing to say about a field does not blank out
            # what the application already recorded.
            if not value or (getattr(row, attribute) or '') == value:
                continue
            setattr(row, attribute, value)
            changed = True
        if changed:
            updated += 1

    if updated and commit:
        db_session.commit()
    return {'matched': matched, 'updated': updated, 'external': external}
