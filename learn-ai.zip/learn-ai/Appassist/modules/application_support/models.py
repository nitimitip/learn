from sqlalchemy import (Column, Integer, String, DateTime, Date, Text, Boolean,
                        ForeignKey, Enum, UniqueConstraint)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base
import enum
import re

# Comma, semicolon or newline - a pasted list of group names works
# whichever separator it arrived with.
_SEPARATORS = re.compile('[,;\r\n]+')

# Enums for specific field types
class BusinessCriticality(enum.Enum):
    BC1 = "BC1"
    BC2 = "BC2"
    BC3 = "BC3"

class FlowDirection(enum.Enum):
    INBOUND = "Inbound"
    OUTBOUND = "Outbound"
    BIDIRECTIONAL ="Bi-Directional Flow"

class TeamRole(enum.Enum):
    PRIMARY_OWNER = "Primary Owner"
    TEAM_MEMBER = "Team Member"

class UserRole(enum.Enum):
    OWNER = "Owner"
    TEAM_MEMBER = "Team Member"

class EnvironmentType(enum.Enum):
    PROD = "Prod"
    NON_PROD = "Non-Prod"

class CredentialType(enum.Enum):
    URL = "URL"
    SERVER = "Server"
    DATABASE = "Database"

# Tower Cards (Admin-only management)
class AppSupportTower(Base):
    __tablename__ = 'app_support_towers'
    
    id = Column(Integer, primary_key=True)
    tower_name = Column(String(255), nullable=False)
    short_summary = Column(Text)
    tower_lead = Column(String(255))
    # ServiceNow assignment groups this tower answers for, comma separated
    # (admin managed). The Tower Summary Status report reads the ServiceNow
    # workload table and keeps only the tickets whose `assignment_group`
    # matches one of these names - a free-text list rather than a lookup
    # because the ServiceNow group names are owned by ServiceNow, not by
    # this application, and a tower routinely answers for several of them.
    tower_group_names = Column(Text)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())
    created_by = Column(Integer, ForeignKey('users.id'))
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    updated_by = Column(Integer, ForeignKey('users.id'))
    
    # Relationships
    applications = relationship("ApplicationDetails", back_populates="tower")
    tower_members = relationship("TowerMember", back_populates="tower")
    secret_vault_entries = relationship("SecretVaultEntry", back_populates="tower")
    
    
    def get_bc_counts(self):
        """Get count of applications by business criticality"""
        bc1_count = len([app for app in self.applications if app.business_criticality == 'BC1'])
        bc2_count = len([app for app in self.applications if app.business_criticality == 'BC2'])
        bc3_count = len([app for app in self.applications if app.business_criticality == 'BC3'])
        return bc1_count, bc2_count, bc3_count
   
    def get_total_app_count(self):
        """Get total application count"""
        return len(self.applications)

    def group_name_list(self):
        """The configured ServiceNow assignment groups, cleaned up.

        Split on comma / semicolon / newline so a pasted list works
        whichever separator it arrived with, trimmed, blanks dropped, and
        de-duplicated case-insensitively while keeping the admin's own
        spelling for display.
        """
        raw = self.tower_group_names or ''
        names, seen = [], set()
        for part in _SEPARATORS.split(raw):
            name = part.strip()
            if not name or name.lower() in seen:
                continue
            seen.add(name.lower())
            names.append(name)
        return names

    def lead_name_list(self):
        """The tower's lead names, as a list.

        ``tower_lead`` is the denormalised display copy of the ``is_lead``
        flags on tower_members (see routes._sync_tower_lead); the flags are
        the truth, this is what the read-only views render.
        """
        raw = self.tower_lead or ''
        names, seen = [], set()
        for part in _SEPARATORS.split(raw):
            name = part.strip()
            if not name or name.lower() in seen:
                continue
            seen.add(name.lower())
            names.append(name)
        return names

# Tower Members (for access control)
class TowerMember(Base):
    __tablename__ = 'tower_members'
    
    id = Column(Integer, primary_key=True)
    tower_id = Column(Integer, ForeignKey('app_support_towers.id'), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    added_at = Column(DateTime, default=func.now())
    added_by = Column(Integer, ForeignKey('users.id'))
    # Secret Vault write access: admin grants this per member. Members with
    # this flag can add/update/delete vault credentials; others view only.
    can_manage_secrets = Column(Boolean, default=False)
    # Tower lead. A lead is always a member of the tower - the lead list is
    # picked FROM these rows rather than typed free-hand - and a tower may
    # have several. Leads can add and remove members of their own tower;
    # who is a lead stays an admin decision.
    is_lead = Column(Boolean, default=False)

    # Relationships
    tower = relationship("AppSupportTower", back_populates="tower_members")

# ---------------------------------------------------------------------------
# Application Category
#
# The business area an application serves - Finance, Registration, CRM and so
# on. Admin-managed rather than an Enum precisely because the list changes
# with the organisation, and the same reasoning that made the technical
# catalog a table applies here (see TechCatalog below).
#
# Retire, do not delete: a category any application still records is
# de-activated so it drops out of the dropdown while the applications that
# reference it keep reading correctly.
# ---------------------------------------------------------------------------
class ApplicationCategory(Base):
    __tablename__ = 'app_categories'

    id = Column(Integer, primary_key=True)
    name = Column(String(150), nullable=False)
    description = Column(Text)
    sort_order = Column(Integer, default=100)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())
    created_by = Column(Integer, ForeignKey('users.id'))
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    updated_by = Column(Integer, ForeignKey('users.id'))

    applications = relationship("ApplicationDetails", back_populates="category")


# Main Application Details
class ApplicationDetails(Base):
    __tablename__ = 'application_details'
    
    id = Column(Integer, primary_key=True)
    tower_id = Column(Integer, ForeignKey('app_support_towers.id'), nullable=False)
    
    # Basic Details
    application_name = Column(String(255), nullable=False)
    business_criticality = Column(Enum(BusinessCriticality), nullable=False)
    # Nullable on purpose: every application that existed before categories
    # were introduced has none, and an unset category must never block a save.
    category_id = Column(Integer, ForeignKey('app_categories.id'), index=True)
    application_summary = Column(Text)
    
    # Technical Details
    accessibility = Column(Text)
    
    # Audit fields
    created_at = Column(DateTime, default=func.now())
    created_by = Column(Integer, ForeignKey('users.id'))
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    updated_by = Column(Integer, ForeignKey('users.id'))
    is_active = Column(Boolean, default=True)
    
    # Relationships
    tower = relationship("AppSupportTower", back_populates="applications")
    category = relationship("ApplicationCategory", back_populates="applications")
    server_details = relationship("ServerDetails", back_populates="application")
    support_team = relationship("SupportTeam", back_populates="application")
    business_users = relationship("BusinessUsers", back_populates="application")
    vendor_details = relationship("VendorDetails", back_populates="application")
    external_interfaces = relationship("ExternalInterfaces", back_populates="application")
    individual_jobs = relationship("IndividualJobs", back_populates="application")
    suite_jobs = relationship("SuiteJobs", back_populates="application")
    file_inventory = relationship("FileInventory", back_populates="application")
    tasks = relationship("ApplicationTask", back_populates="application")
    critical_issues = relationship("CriticalIssue", back_populates="application")

# Server Details Table
class ServerDetails(Base):
    __tablename__ = 'server_details'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application_details.id'), nullable=False)
    server_name = Column(String(255), nullable=False)
    location = Column(String(255))
    operating_system = Column(String(255))
    environment_description = Column(Text)
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    application = relationship("ApplicationDetails", back_populates="server_details")

# Support Team Table
class SupportTeam(Base):
    __tablename__ = 'support_team'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application_details.id'), nullable=False)
    member_name = Column(String(255), nullable=False)
    role = Column(Enum(TeamRole), nullable=False)
    email = Column(String(255))
    # Where the row came from. NULL (the default, and every pre-existing row)
    # means somebody typed it on the application's own record. 'assignment'
    # means the tower lead put it there from the Tower Summary grid - those
    # rows are rebuilt from ApplicationAssignment on every save and are NOT
    # editable on the application form, so the two never fight over a name.
    source = Column(String(16))
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    application = relationship("ApplicationDetails", back_populates="support_team")

# ---------------------------------------------------------------------------
# Application Assignment
#
# The tower lead's allocation: who supports which application, and at what
# level of cover. One row is one cell of the Tower Summary assignment grid -
# a team member, a slot (Primary 1..n / Secondary 1..n) and the application
# put in that slot.
#
# Deliberately NOT the same thing as SupportTeam. SupportTeam records the
# names an application's OWN record claims, typed per application by whoever
# edits it. This table is the tower-level allocation the lead makes in one
# place, and it is what the coverage counts are read from - so an application
# nobody has been given still reports as uncovered even when its record names
# a handful of people.
# ---------------------------------------------------------------------------
class ApplicationAssignment(Base):
    __tablename__ = 'app_support_assignments'

    id = Column(Integer, primary_key=True)
    tower_id = Column(Integer, ForeignKey('app_support_towers.id'),
                      nullable=False, index=True)
    application_id = Column(Integer, ForeignKey('application_details.id'),
                            nullable=False, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False,
                     index=True)
    # 'primary' or 'secondary'. Plain text rather than an Enum so adding a
    # third level of cover later is a data change, not a migration.
    assignment_type = Column(String(16), nullable=False)
    slot_index = Column(Integer, nullable=False, default=1)
    assigned_at = Column(DateTime, default=func.now())
    assigned_by = Column(Integer, ForeignKey('users.id'))

    # One application per cell: a member's "Primary 2" in a given tower is a
    # single slot, so re-saving the grid updates rather than accumulates.
    __table_args__ = (
        UniqueConstraint('tower_id', 'user_id', 'assignment_type',
                         'slot_index', name='uq_app_assignment_cell'),
    )

    application = relationship("ApplicationDetails")


# Business Users Table
class BusinessUsers(Base):
    __tablename__ = 'business_users'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application_details.id'), nullable=False)
    user_name = Column(String(255), nullable=False)
    role = Column(Enum(UserRole), nullable=False)
    email = Column(String(255))
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    application = relationship("ApplicationDetails", back_populates="business_users")

# Vendor Details Table
class VendorDetails(Base):
    __tablename__ = 'vendor_details'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application_details.id'), nullable=False)
    vendor_name = Column(String(255), nullable=False)
    email = Column(String(255))
    is_bespoke = Column(Boolean, default=False)  # True if "Bespoke Application"
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    application = relationship("ApplicationDetails", back_populates="vendor_details")

# External Interfaces Table
class ExternalInterfaces(Base):
    __tablename__ = 'external_interfaces'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application_details.id'), nullable=False)
    interface_name = Column(String(255), nullable=False)
    flow_direction = Column(Enum(FlowDirection), nullable=False)
    connectivity_type = Column(String(255))
    external_server = Column(String(255))
    description = Column(Text)
    contact = Column(String(255))
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    application = relationship("ApplicationDetails", back_populates="external_interfaces")

# Individual Jobs Table
class IndividualJobs(Base):
    __tablename__ = 'individual_jobs'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application_details.id'), nullable=False)
    job_name = Column(String(255), nullable=False)
    frequency = Column(String(255))
    short_description = Column(Text)
    full_description = Column(Text)
    user_profile = Column(String(255))
    prerequisites = Column(Text)
    script = Column(Text)
    failure_checks = Column(Text)
    manual_execution_steps = Column(Text)
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    application = relationship("ApplicationDetails", back_populates="individual_jobs")

# Suite Jobs Table
class SuiteJobs(Base):
    __tablename__ = 'suite_jobs'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application_details.id'), nullable=False)
    suite_name = Column(String(255), nullable=False)
    job_name = Column(String(255), nullable=False)
    frequency = Column(String(255))
    short_description = Column(Text)
    full_description = Column(Text)
    user_profile = Column(String(255))
    prerequisites = Column(Text)
    script = Column(Text)
    failure_checks = Column(Text)
    manual_execution_steps = Column(Text)
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    application = relationship("ApplicationDetails", back_populates="suite_jobs")

# File/Inventory Management Table
class FileInventory(Base):
    __tablename__ = 'file_inventory'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application_details.id'), nullable=False)
    file_name = Column(String(255), nullable=False)
    description = Column(Text)
    file_path = Column(String(500))  # Path to uploaded file
    uploaded_at = Column(DateTime, default=func.now())
    uploaded_by = Column(Integer, ForeignKey('users.id'))
    
    # Relationships
    application = relationship("ApplicationDetails", back_populates="file_inventory")

# Application Tasks (Card-Based)
class ApplicationTask(Base):
    __tablename__ = 'application_tasks'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application_details.id'), nullable=False)
    task_name = Column(String(255), nullable=False)
    description = Column(Text)
    steps = Column(Text)
    created_at = Column(DateTime, default=func.now())
    created_by = Column(Integer, ForeignKey('users.id'))
    updated_at = Column(DateTime)
    updated_by = Column(Integer, ForeignKey('users.id'))
    
    # Relationships
    application = relationship("ApplicationDetails", back_populates="tasks")

# Critical Issues (Card-Based)
class CriticalIssue(Base):
    __tablename__ = 'critical_issues'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application_details.id'), nullable=False)
    issue_name = Column(String(255), nullable=False)
    problem_description = Column(Text)
    solution_steps = Column(Text)
    created_at = Column(DateTime, default=func.now())
    created_by = Column(Integer, ForeignKey('users.id'))
    updated_at = Column(DateTime)
    updated_by = Column(Integer, ForeignKey('users.id'))
    
    # Relationships
    application = relationship("ApplicationDetails", back_populates="critical_issues")
    

# Secret Vault (tower-scoped credential store)
# Visible/accessible to tower members ONLY - not even admins. Passwords are
# stored Fernet-encrypted (see crypto_utils) and only decrypted on an explicit
# "reveal" request by a tower member.
class SecretVaultEntry(Base):
    __tablename__ = 'secret_vault_entries'

    id = Column(Integer, primary_key=True)
    tower_id = Column(Integer, ForeignKey('app_support_towers.id'), nullable=False)
    environment = Column(Enum(EnvironmentType), nullable=False)
    application_name = Column(String(255), nullable=False)
    credential_type = Column(Enum(CredentialType), nullable=False)
    # The thing the credential belongs to: a URL, a server name, or a database name
    resource = Column(String(500), nullable=False)
    username = Column(String(255), nullable=False)
    password_encrypted = Column(Text, nullable=False)
    created_at = Column(DateTime, default=func.now())
    created_by = Column(Integer, ForeignKey('users.id'))
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    updated_by = Column(Integer, ForeignKey('users.id'))

    # Relationships
    tower = relationship("AppSupportTower", back_populates="secret_vault_entries")


# Audit Log Table
class AuditLog(Base):
    __tablename__ = 'audit_logs'
    
    id = Column(Integer, primary_key=True)
    user_name = Column(String(255), nullable=False)
    email = Column(String(255), nullable=False)
    tower_name = Column(String(255), nullable=False)
    module = Column(String(100), nullable=False)  # e.g., 'Application', 'Tower', 'Job', etc.
    operation = Column(String(50), nullable=False)  # 'INSERT', 'UPDATE', 'DELETE'
    details = Column(Text)  # Additional details about the operation
    timestamp = Column(DateTime, default=func.now(), nullable=False)


# ---------------------------------------------------------------------------
# Audit digest log
#
# One row per (tower, day) on which the nightly "what changed on your tower"
# digest ran. It does two jobs at once:
#
#   1. CROSS-PROCESS IDEMPOTENCY. Before building an email the sweep
#      atomically INSERTs a row for (tower_id, run_date); the UNIQUE
#      constraint means a SECOND runner (an IIS worker that also started a
#      scheduler, say) gets an IntegrityError and skips - so a tower's leads
#      receive at most ONE digest per day however many processes sweep.
#      Same guard as todo_digest_log.
#
#   2. THE WINDOW CHAIN. window_start / window_end record exactly which slice
#      of the audit trail was reported. The next run starts where the last
#      one ended, so a night the service was down is picked up by the
#      following night rather than silently dropped. A run that found nothing
#      still writes its row (sent=False, entry_count=0) precisely so the chain
#      stays unbroken - the row is the receipt that the window was examined,
#      not that an email went out.
#
# A row is DELETED again if the email could not be sent, so the unreported
# window is re-covered by the next run instead of being lost to a transient
# SMTP failure.
# ---------------------------------------------------------------------------
class AuditDigestLog(Base):
    __tablename__ = 'app_support_audit_digest_log'

    id = Column(Integer, primary_key=True)
    tower_id = Column(Integer, ForeignKey('app_support_towers.id'), nullable=False)
    run_date = Column(Date, nullable=False)
    window_start = Column(DateTime, nullable=False)
    window_end = Column(DateTime, nullable=False)
    # How many audit entries the window held, and whether an email went out.
    # entry_count 0 with sent False is the normal "nothing changed" night.
    entry_count = Column(Integer, default=0)
    recipient_count = Column(Integer, default=0)
    sent = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())

    __table_args__ = (
        UniqueConstraint('tower_id', 'run_date',
                         name='uq_audit_digest_tower_date'),
    )

    def __repr__(self):
        return f'<AuditDigestLog tower={self.tower_id} {self.run_date}>'



# ---------------------------------------------------------------------------
# Technical Details
#
# Four tables back the "Technical Details" tab and its admin screens:
#
#   app_tech_catalog       admin-curated dropdown values (OS / database /
#                          tool / programming language)
#   app_tech_stack         what a given application actually runs, one row
#                          per OS, database, tool or language
#   app_standard_items     the standards checklist master - "general" items
#                          plus items attached to one catalog entry
#   app_standard_compliance  an application's answer for one checklist item
#
# The stack row keeps a denormalised item_name alongside catalog_id so a
# catalog entry that is later renamed or retired never blanks out history.
# ---------------------------------------------------------------------------

# Catalog categories. Kept as plain strings (not an Enum) because admins add
# and remove VALUES constantly; only the four CATEGORIES are fixed.
TECH_CATEGORIES = ('os', 'database', 'tool', 'language')

# Checklist scopes: 'general' items apply to every application; the other
# four attach to a catalog entry and surface only when that entry is selected.
CHECKLIST_SCOPES = ('general',) + TECH_CATEGORIES


class TechCatalog(Base):
    """Admin-managed dropdown values for the Technical Details tab."""
    __tablename__ = 'app_tech_catalog'

    id = Column(Integer, primary_key=True)
    # One of TECH_CATEGORIES
    category = Column(String(20), nullable=False, index=True)
    name = Column(String(150), nullable=False)
    description = Column(Text)
    sort_order = Column(Integer, default=100)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())
    created_by = Column(Integer, ForeignKey('users.id'))

    checklist_items = relationship("StandardChecklistItem",
                                   back_populates="catalog_entry")


class ApplicationTechStack(Base):
    """One technology an application runs: OS, database, tool or language."""
    __tablename__ = 'app_tech_stack'

    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application_details.id'),
                            nullable=False, index=True)
    category = Column(String(20), nullable=False)
    # Nullable on purpose: a catalog entry may be retired later, and the row
    # must survive that. item_name is the value shown everywhere.
    catalog_id = Column(Integer, ForeignKey('app_tech_catalog.id'))
    item_name = Column(String(150), nullable=False)
    version = Column(String(100))
    description = Column(Text)
    created_at = Column(DateTime, default=func.now())

    catalog_entry = relationship("TechCatalog")


class StandardChecklistItem(Base):
    """A standards-practice question, either general or technology-scoped."""
    __tablename__ = 'app_standard_items'

    id = Column(Integer, primary_key=True)
    # 'general' or one of TECH_CATEGORIES
    scope = Column(String(20), nullable=False, index=True)
    # NULL for 'general' items; otherwise the catalog entry it belongs to
    catalog_id = Column(Integer, ForeignKey('app_tech_catalog.id'), index=True)
    name = Column(String(300), nullable=False)
    description = Column(Text)
    sort_order = Column(Integer, default=100)
    is_active = Column(Boolean, default=True)
    # Historic flag from when the checklist shipped as a Python seed list.
    # Nothing sets it True any more - the checklist is loaded from Excel -
    # but the column stays so rows written by the old seeder keep the
    # provenance they were saved with.
    is_seeded = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())
    created_by = Column(Integer, ForeignKey('users.id'))
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    updated_by = Column(Integer, ForeignKey('users.id'))

    catalog_entry = relationship("TechCatalog",
                                 back_populates="checklist_items")


class ApplicationStandardCompliance(Base):
    """An application's recorded position on one checklist item."""
    __tablename__ = 'app_standard_compliance'

    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application_details.id'),
                            nullable=False, index=True)
    checklist_id = Column(Integer, ForeignKey('app_standard_items.id'),
                          nullable=False, index=True)
    # One of tech_details.STATUSES
    status = Column(String(40), nullable=False)
    # Only meaningful for the planning statuses - see
    # tech_details.dates_allowed()
    start_date = Column(Date)
    end_date = Column(Date)
    comment = Column(Text)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    updated_by = Column(Integer, ForeignKey('users.id'))

    checklist_item = relationship("StandardChecklistItem")
