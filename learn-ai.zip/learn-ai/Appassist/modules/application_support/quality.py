"""
Documentation quality metric for Application Support.

Two scorecards, deliberately kept apart because two different people own
them:

  * TOWER PROFILE  - the tower card itself (summary, lead, members, whether
    any application has been registered at all). Owned by the tower lead.
  * APPLICATION RECORD - the sections a support team is expected to fill in
    for every application they run. Owned by the support team.

The metric exists because records were being created with a one-line summary
and nothing else. It therefore refuses to reward text that is technically
non-empty but says nothing: a placeholder ("NA", "TBD", "-") scores zero and
a single short line scores a fraction, not a pass.

WHAT COUNTS AND WHAT DOES NOT
-----------------------------
Scored (an application is not properly documented without them):

    Application summary, business criticality, accessibility,
    server details, support team, business users, vendor details,
    technology stack.

NOT scored, by design - these depend on what the application actually is,
so their absence is not a defect:

    individual jobs, suite jobs, external interfaces, tasks,
    critical issues, uploaded files, standards checklist answers.

They are reported as INFORMATIONAL coverage only, never as a gap and never
in the percentage.

The score is a weighted percentage over the scored checks. Each check earns
partial credit, so a team that has recorded servers but not their operating
systems sees the difference from a team that recorded nothing. Every check
that is short of complete carries a plain-English gap message - the number
on its own never told anybody what to go and fix.

The pass bar is 100% for every business criticality (see TARGET_BY_BC).
Grades follow the business scale: 30 Poor, 50 Average, 80 Good, 90 Very
Good, 100 Excellent - so "Excellent" means finished, not nearly finished.

Nothing here is enforcement. Saving an incomplete record is still allowed;
the module measures and nudges, because a hard block on a form this large
just teaches people to type "NA" faster.

The rules half of this module (everything above the PERSISTENCE banner)
issues no queries and needs no session: it grades whatever objects it is
handed, so it can be unit-tested on plain stand-ins the way
tests/test_app_quality.py does. Only the loaders below the banner touch the
database.

Python 3.9 compatible on purpose - production runs 3.9.
"""

# `col == sql_true()` rather than `col.is_(True)`: SQLAlchemy renders
# the latter as `col IS 1`, which SQLite accepts and SQL SERVER REJECTS
# - T-SQL allows IS only with NULL. Both compile `== true()` to `= 1`.
from sqlalchemy import true as sql_true
from .models import (
    ApplicationDetails, ServerDetails, SupportTeam, BusinessUsers,
    VendorDetails, ApplicationTechStack,
)

# ---------------------------------------------------------------------------
# Vocabulary and thresholds
# ---------------------------------------------------------------------------

STATUS_COMPLETE = 'complete'
STATUS_PARTIAL = 'partial'
STATUS_MISSING = 'missing'

# A check has to be at least this good to read as "complete". Below it the
# check is partial, and only a ratio of exactly zero reads as missing.
COMPLETE_AT = 0.85

# Grade bands: (minimum percent, label, badge class, tone). Tone names the
# CSS colour variable every score display uses.
#
# The scale is the one the business set: 30 Poor, 50 Average, 80 Good,
# 90 Very Good, 100 Excellent. Only a perfect record is Excellent, which is
# the point - the target below is 100% for every application.
#
# A sixth band sits under 30. The business scale starts at Poor, but a
# record scoring 11% is not the same thing as one scoring 45% and calling
# both "Poor" hides the ones that have effectively never been filled in.
GRADE_BANDS = (
    (100, 'Excellent', 'badge-excellent', 'excellent'),
    (90, 'Very Good', 'badge-success', 'success'),
    (80, 'Good', 'badge-info', 'info'),
    (50, 'Average', 'badge-warning', 'warning'),
    (30, 'Poor', 'badge-critical', 'critical'),
    (0, 'Critical', 'badge-severe', 'severe'),
)

# Icon per grade, so a verdict reads at a glance without reading the number.
GRADE_ICONS = {
    'Excellent': 'fa-circle-check',
    'Very Good': 'fa-thumbs-up',
    'Good': 'fa-arrow-trend-up',
    'Average': 'fa-circle-exclamation',
    'Poor': 'fa-triangle-exclamation',
    'Critical': 'fa-circle-xmark',
}

# The bar a record has to clear to be considered adequate. Every business
# criticality carries the same 100% target: a documentation record is not
# "nearly right" - either the sections a support team needs at 3am are
# filled in or they are not. The mapping is kept (rather than collapsed to
# one constant) because the exports and the screens print the pass mark per
# BC, and because a future policy change is then a one-line edit here.
TARGET_BY_BC = {
    'BC1': 100,
    'BC2': 100,
    'BC3': 100,
}
DEFAULT_TARGET = 100

# Anything under this is called out as at risk on the dashboards, whatever
# the application's own target is.
AT_RISK_BELOW = 50

# Text that is present but says nothing. Compared lower-cased with
# surrounding punctuation stripped, so "N/A." and "-na-" are both caught.
PLACEHOLDER_TEXT = frozenset((
    'na', 'n/a', 'nil', 'none', 'no', 'yes', 'null', 'tbd', 'tba', 'todo',
    'to be updated', 'to be filled', 'not applicable', 'not available',
    'not known', 'unknown', 'pending', 'test', 'testing', 'dummy', 'sample',
    'xxx', 'xx', 'abc', 'asdf', 'same', 'same as above', 'refer above',
    'as above', 'nothing', 'blank', 'empty', 'update later',
))

# Free-text depth thresholds, per field: (good_chars, good_words, min_chars).
# "Good" is a real paragraph; "min" separates a usable sentence from the
# one-liner this metric was built to catch.
SUMMARY_DEPTH = (140, 22, 45)
ACCESSIBILITY_DEPTH = (90, 14, 30)
TOWER_SUMMARY_DEPTH = (110, 16, 35)

# Section labels used on the application scorecard.
SECTION_BASIC = 'Basic Details'
SECTION_INFRA = 'Infrastructure'
SECTION_PEOPLE = 'People'
SECTION_TECH = 'Technology'

# Scored application checks: (key, label, section, weight, icon). Weights add
# up to 100 so the percentage needs no normalising and stays readable.
APPLICATION_CHECKS = (
    ('summary', 'Application Summary', SECTION_BASIC, 15, 'fa-align-left'),
    ('criticality', 'Business Criticality', SECTION_BASIC, 5, 'fa-gauge-high'),
    ('accessibility', 'Accessibility', SECTION_BASIC, 10, 'fa-shield-halved'),
    ('servers', 'Server Details', SECTION_INFRA, 20, 'fa-server'),
    ('support_team', 'Support Team', SECTION_PEOPLE, 20, 'fa-users'),
    ('business_users', 'Business Users', SECTION_PEOPLE, 10, 'fa-briefcase'),
    ('vendor', 'Vendor Details', SECTION_PEOPLE, 10, 'fa-building'),
    ('tech_stack', 'Technology Stack', SECTION_TECH, 10, 'fa-microchip'),
)

# Scored tower checks, same shape.
TOWER_CHECKS = (
    ('summary', 'Tower Summary', 30, 'fa-align-left'),
    ('lead', 'Tower Lead', 20, 'fa-user-tie'),
    ('members', 'Tower Members', 25, 'fa-users'),
    ('applications', 'Applications Registered', 25, 'fa-cubes'),
)

# Sections that are genuinely optional. Reported as coverage, never scored.
# (key, label, icon)
OPTIONAL_SECTIONS = (
    ('jobs', 'Jobs', 'fa-play'),
    ('interfaces', 'External Interfaces', 'fa-link'),
    ('tasks', 'Tasks', 'fa-tasks'),
    ('issues', 'Critical Issues', 'fa-triangle-exclamation'),
    ('files', 'Files', 'fa-file'),
)


# ---------------------------------------------------------------------------
# Text rules
# ---------------------------------------------------------------------------

def _clean(value):
    """Trim a possibly-None field down to a plain string."""
    if value is None:
        return ''
    return str(value).strip()


def is_placeholder(value):
    """True when text is present but carries no information."""
    text = _clean(value).lower()
    # Strip the punctuation people wrap a placeholder in - "-", "N/A.",
    # "<TBD>" - which also reduces a field holding nothing but "???" to the
    # empty string.
    text = text.strip(' \t\r\n.-_*:;,?!<>()[]"\'/')
    if not text:
        return True
    return text in PLACEHOLDER_TEXT


def has_value(value):
    """True when a field carries something a reader could use."""
    return bool(_clean(value)) and not is_placeholder(value)


def text_ratio(value, depth):
    """
    Grade a free-text field from 0.0 to 1.0 against a depth threshold.

    Four outcomes rather than a smooth curve, because the result is shown to
    the person who wrote the text and has to be explainable:

        1.0  a real description  - meets both the character and word target
        0.7  usable but thin     - past the minimum, short of the target
        0.4  a one-liner         - present, below the minimum
        0.0  empty or placeholder
    """
    good_chars, good_words, min_chars = depth
    text = _clean(value)
    if not text or is_placeholder(text):
        return 0.0
    chars = len(text)
    words = len(text.split())
    if chars >= good_chars and words >= good_words:
        return 1.0
    if chars >= min_chars and words >= max(3, good_words // 2):
        return 0.7
    return 0.4


def text_detail(ratio, value):
    """Plain-English wording for a graded free-text field."""
    if ratio >= 1.0:
        return '{0} words recorded'.format(len(_clean(value).split()))
    if ratio > 0.5:
        return 'Recorded, but shorter than the expected level of detail'
    if ratio > 0:
        return 'One line only - not enough for someone new to the application'
    if _clean(value):
        return 'Placeholder text ("{0}") - counts as not filled'.format(
            _clean(value)[:20])
    return 'Not filled in'


# ---------------------------------------------------------------------------
# Row rules
# ---------------------------------------------------------------------------

def field_ratio(rows, fields):
    """Fraction of the required per-row fields across ``rows`` that are filled."""
    if not rows:
        return 0.0
    total = len(rows) * len(fields)
    if not total:
        return 1.0
    filled = 0
    for row in rows:
        for field in fields:
            if has_value(getattr(row, field, None)):
                filled += 1
    return float(filled) / total


def _rows_ratio(rows, fields, floor=0.4):
    """
    Credit for a repeat-row section: ``floor`` for having recorded anything
    at all, the rest earned by filling the detail fields in.

    Recording three servers by name is real progress over recording none, so
    it should not score the same as an empty section - but it is not a
    complete infrastructure record either, so it cannot score full marks.
    """
    if not rows:
        return 0.0
    return floor + (1.0 - floor) * field_ratio(rows, fields)


def _has_role(rows, attribute, wanted):
    """True when at least one row carries the wanted role value."""
    for row in rows:
        role = getattr(row, attribute, None)
        value = getattr(role, 'value', role)
        if value == wanted:
            return True
    return False


def _count_word(count, singular, plural=None):
    """'1 server' / '3 servers', so messages read naturally."""
    if plural is None:
        plural = singular + 's'
    return '{0} {1}'.format(count, singular if count == 1 else plural)


# ---------------------------------------------------------------------------
# Grading
# ---------------------------------------------------------------------------

def grade_for(percent):
    """(label, badge class, tone) for a percentage."""
    for minimum, label, badge, tone in GRADE_BANDS:
        if percent >= minimum:
            return label, badge, tone
    # Unreachable - the last band starts at 0 - but never return None.
    return GRADE_BANDS[-1][1], GRADE_BANDS[-1][2], GRADE_BANDS[-1][3]


def grade_icon(label):
    """Font Awesome icon name for a grade label."""
    return GRADE_ICONS.get(label, 'fa-circle-info')


def grade_scale():
    """
    The scale as display rows, best band first.

    Screens print the legend from this rather than repeating the numbers in
    a template, so the band a score falls in and the band the legend shows
    can never drift apart.
    """
    rows = []
    bands = list(GRADE_BANDS)
    for index, (minimum, label, badge, tone) in enumerate(bands):
        upper = bands[index - 1][0] - 1 if index else minimum
        if index == 0:
            caption = '{0}%'.format(minimum)
        else:
            caption = '{0}-{1}%'.format(minimum, upper)
        rows.append({
            'min': minimum, 'max': upper, 'label': label,
            'badge': badge, 'tone': tone, 'range': caption,
            'icon': grade_icon(label),
        })
    return rows


def status_for(ratio):
    """Which of the three statuses a 0..1 ratio reads as."""
    if ratio >= COMPLETE_AT:
        return STATUS_COMPLETE
    if ratio > 0:
        return STATUS_PARTIAL
    return STATUS_MISSING


def target_for(bc_name):
    """The percentage this business criticality is expected to clear."""
    return TARGET_BY_BC.get(bc_name, DEFAULT_TARGET)


def criticality_name(app):
    """'BC1' whether business_criticality is an Enum, a string or unset."""
    value = getattr(app, 'business_criticality', None)
    if value is None:
        return ''
    return _clean(getattr(value, 'name', None) or getattr(value, 'value', None)
                  or value)


def _check(key, label, section, weight, icon, ratio, detail, gap=None):
    """One scored line on a scorecard."""
    ratio = max(0.0, min(1.0, ratio))
    status = status_for(ratio)
    return {
        'key': key,
        'label': label,
        'section': section,
        'icon': icon,
        'weight': weight,
        'ratio': ratio,
        'percent': int(round(ratio * 100)),
        'score': round(weight * ratio, 2),
        'status': status,
        'detail': detail,
        # A complete check has nothing outstanding, whatever was passed in.
        'gap': None if status == STATUS_COMPLETE else gap,
    }


def _scorecard(checks, optional=None):
    """Roll graded checks up into the shape every template consumes."""
    weight_total = sum(check['weight'] for check in checks)
    earned = sum(check['score'] for check in checks)
    percent = int(round(100.0 * earned / weight_total)) if weight_total else 0
    label, badge, tone = grade_for(percent)
    counts = {STATUS_COMPLETE: 0, STATUS_PARTIAL: 0, STATUS_MISSING: 0}
    for check in checks:
        counts[check['status']] += 1
    return {
        'percent': percent,
        'grade': label,
        'badge': badge,
        'tone': tone,
        'checks': checks,
        'complete': counts[STATUS_COMPLETE],
        'partial': counts[STATUS_PARTIAL],
        'missing': counts[STATUS_MISSING],
        'total_checks': len(checks),
        'gaps': [check['gap'] for check in checks if check['gap']],
        'optional': optional or [],
    }


# ---------------------------------------------------------------------------
# Application scorecard
# ---------------------------------------------------------------------------

def empty_related():
    """The related-row bundle score_application() expects, with nothing in it."""
    return {
        'servers': [],
        'support_team': [],
        'business_users': [],
        'vendors': [],
        'tech_stack': [],
    }


def score_application(app, related, optional_counts=None):
    """
    Grade one application record.

    ``related`` is the bundle from empty_related() - lists of the already
    loaded child rows, so this function issues no queries and can be tested
    on plain objects. ``optional_counts`` is {key: count} for the sections in
    OPTIONAL_SECTIONS; it is reported, never scored.
    """
    related = dict(empty_related(), **(related or {}))
    weights = dict((key, (label, section, weight, icon))
                   for key, label, section, weight, icon in APPLICATION_CHECKS)
    checks = []

    def add(key, ratio, detail, gap=None):
        label, section, weight, icon = weights[key]
        checks.append(_check(key, label, section, weight, icon,
                             ratio, detail, gap))

    # --- Basic details ---------------------------------------------------
    summary = getattr(app, 'application_summary', '')
    ratio = text_ratio(summary, SUMMARY_DEPTH)
    add('summary', ratio, text_detail(ratio, summary),
        'Describe what the application does, who uses it and what it talks '
        'to - at least a short paragraph.')

    bc = criticality_name(app)
    add('criticality', 1.0 if bc else 0.0,
        bc or 'Not set',
        'Set the business criticality.')

    accessibility = getattr(app, 'accessibility', '')
    ratio = text_ratio(accessibility, ACCESSIBILITY_DEPTH)
    add('accessibility', ratio, text_detail(ratio, accessibility),
        'Record how the application is reached - URLs, clients, VPN or '
        'network requirements and who can get access.')

    # --- Infrastructure --------------------------------------------------
    servers = related['servers']
    ratio = _rows_ratio(servers,
                        ('location', 'operating_system',
                         'environment_description'))
    if not servers:
        detail = 'No server recorded'
        gap = ('Add the servers this application runs on, with location, '
               'operating system and environment.')
    else:
        detail = '{0} recorded, {1}% of server detail filled'.format(
            _count_word(len(servers), 'server'),
            int(round(field_ratio(servers,
                                  ('location', 'operating_system',
                                   'environment_description')) * 100)))
        gap = ('Complete location, operating system and environment '
               'description for every server.')
    add('servers', ratio, detail, gap)

    # --- People ----------------------------------------------------------
    support = related['support_team']
    ratio = _rows_ratio(support, ('email',))
    has_owner = _has_role(support, 'role', 'Primary Owner')
    if support and not has_owner:
        # A team with nobody named as owner has no escalation point, which
        # is the single most expensive gap on this list at 3am.
        ratio = min(ratio, 0.6)
    if not support:
        detail = 'No support team member recorded'
        gap = 'Add the support team, naming one Primary Owner.'
    elif not has_owner:
        detail = '{0}, no Primary Owner named'.format(
            _count_word(len(support), 'member'))
        gap = 'Name one support team member as the Primary Owner.'
    else:
        detail = '{0}, Primary Owner named'.format(
            _count_word(len(support), 'member'))
        gap = 'Add the email address for every support team member.'
    add('support_team', ratio, detail, gap)

    business = related['business_users']
    ratio = _rows_ratio(business, ('email',))
    has_business_owner = _has_role(business, 'role', 'Owner')
    if business and not has_business_owner:
        ratio = min(ratio, 0.6)
    if not business:
        detail = 'No business user recorded'
        gap = 'Add the business stakeholders, naming one Owner.'
    elif not has_business_owner:
        detail = '{0}, no Owner named'.format(
            _count_word(len(business), 'stakeholder'))
        gap = 'Name one business user as the Owner.'
    else:
        detail = '{0}, Owner named'.format(
            _count_word(len(business), 'stakeholder'))
        gap = 'Add the email address for every business user.'
    add('business_users', ratio, detail, gap)

    vendors = related['vendors']
    if not vendors:
        ratio = 0.0
        detail = 'No vendor recorded and not marked bespoke'
        gap = ('Record the vendor, or add the entry marked "Bespoke '
               'Application" if it was built in house.')
    else:
        # A bespoke entry needs no vendor contact; a vendor product does.
        contactable = 0
        for row in vendors:
            if getattr(row, 'is_bespoke', False) or has_value(
                    getattr(row, 'email', None)):
                contactable += 1
        ratio = 0.4 + 0.6 * (float(contactable) / len(vendors))
        detail = '{0} recorded'.format(_count_word(len(vendors), 'entry',
                                                   'entries'))
        gap = 'Add a contact email for every vendor that is not bespoke.'
    add('vendor', ratio, detail, gap)

    # --- Technology ------------------------------------------------------
    stack = related['tech_stack']
    categories = set(_clean(getattr(row, 'category', '')) for row in stack)
    has_os = 'os' in categories
    has_build = bool(categories & set(('tool', 'language')))
    # A database is not universal, so it is not required - but the operating
    # system and what the application is built with always exist.
    ratio = (int(has_os) + int(has_build)) / 2.0
    if not stack:
        detail = 'No technology recorded'
        gap = ('Record the technology stack on the Technical Details tab - '
               'operating system plus the tools or languages used.')
    else:
        detail = '{0} recorded'.format(_count_word(len(stack), 'entry',
                                                   'entries'))
        missing_parts = []
        if not has_os:
            missing_parts.append('operating system')
        if not has_build:
            missing_parts.append('tool or programming language')
        gap = ('Add the {0} on the Technical Details tab.'
               .format(' and '.join(missing_parts))
               if missing_parts else None)
    add('tech_stack', ratio, detail, gap)

    optional = []
    counts = optional_counts or {}
    for key, label, icon in OPTIONAL_SECTIONS:
        count = int(counts.get(key, 0) or 0)
        optional.append({'key': key, 'label': label, 'icon': icon,
                         'count': count, 'recorded': count > 0})

    card = _scorecard(checks, optional)
    card['criticality'] = bc
    card['target'] = target_for(bc)
    card['meets_target'] = card['percent'] >= card['target']
    card['at_risk'] = card['percent'] < AT_RISK_BELOW
    return card


# ---------------------------------------------------------------------------
# Tower scorecard
# ---------------------------------------------------------------------------

def score_tower(tower, member_count, application_count):
    """Grade a tower's own profile card - not the applications inside it."""
    weights = dict((key, (label, weight, icon))
                   for key, label, weight, icon in TOWER_CHECKS)
    checks = []

    def add(key, ratio, detail, gap=None):
        label, weight, icon = weights[key]
        checks.append(_check(key, label, 'Tower Profile', weight, icon,
                             ratio, detail, gap))

    summary = getattr(tower, 'short_summary', '')
    ratio = text_ratio(summary, TOWER_SUMMARY_DEPTH)
    add('summary', ratio, text_detail(ratio, summary),
        'Describe what this tower is responsible for, in a short paragraph.')

    lead = getattr(tower, 'tower_lead', '')
    add('lead', 1.0 if has_value(lead) else 0.0,
        _clean(lead) or 'Not named',
        'Name the tower lead.')

    member_count = int(member_count or 0)
    # One member is a single point of failure for the whole tower record, so
    # it earns partial credit only.
    ratio = 1.0 if member_count >= 2 else (0.5 if member_count == 1 else 0.0)
    add('members', ratio, _count_word(member_count, 'member'),
        'Add at least two tower members so the tower is not held by one person.')

    application_count = int(application_count or 0)
    add('applications', 1.0 if application_count else 0.0,
        _count_word(application_count, 'application'),
        'Register the applications this tower supports.')

    return _scorecard(checks)


# ---------------------------------------------------------------------------
# Roll-ups
# ---------------------------------------------------------------------------

def rollup(scorecards):
    """
    Average a set of application scorecards into one headline.

    An empty set scores 0 with a count of 0 rather than dividing by zero -
    "no applications" is not "perfectly documented".
    """
    cards = list(scorecards or [])
    count = len(cards)
    if not count:
        label, badge, tone = grade_for(0)
        return {
            'count': 0, 'percent': 0, 'grade': label, 'badge': badge,
            'tone': tone, 'at_risk': 0, 'below_target': 0, 'meets_target': 0,
            'bands': dict((band[1], 0) for band in GRADE_BANDS),
        }
    percent = int(round(sum(card['percent'] for card in cards) / float(count)))
    label, badge, tone = grade_for(percent)
    bands = dict((band[1], 0) for band in GRADE_BANDS)
    for card in cards:
        bands[card['grade']] += 1
    return {
        'count': count,
        'percent': percent,
        'grade': label,
        'badge': badge,
        'tone': tone,
        'at_risk': sum(1 for card in cards if card.get('at_risk')),
        'below_target': sum(1 for card in cards
                            if not card.get('meets_target', True)),
        'meets_target': sum(1 for card in cards
                            if card.get('meets_target', False)),
        'bands': bands,
    }


def tower_verdict(profile, records):
    """
    One headline judgment over a tower's two scorecards.

    A tower is documented only when BOTH halves are. A well-written tower
    profile in front of thin application records still leaves the person
    picking up a P1 at 3am with nothing, so the verdict follows the WEAKER
    of the two rather than their average - an average lets a good profile
    hide an undocumented estate, which is exactly the failure this metric
    was built to surface.

    Returns the same percent / grade / badge / tone shape every other
    scorecard carries, so the display macros need no special case, plus the
    wording that explains the call.
    """
    profile = profile or {}
    records = records or {}
    profile_percent = int(profile.get('percent', 0) or 0)
    records_percent = int(records.get('percent', 0) or 0)
    app_count = int(records.get('count', 0) or 0)

    if not app_count:
        # No applications registered: there are no records to grade, so
        # grading them 0% and calling the tower Critical would be scoring
        # the same missing fact twice (the tower profile already loses its
        # "Applications Registered" check). Judge the profile alone and say
        # plainly what is blocking a real verdict.
        percent = profile_percent
        weakest = 'Tower profile'
        headline = 'No applications registered'
        detail = ('Only the tower profile can be graded until the '
                  'applications this tower supports are registered.')
    else:
        percent = min(profile_percent, records_percent)
        if records_percent < profile_percent:
            weakest = 'Application records'
        elif profile_percent < records_percent:
            weakest = 'Tower profile'
        else:
            weakest = 'Both equally'
        headline = None
        detail = None

    label, badge, tone = grade_for(percent)
    target = DEFAULT_TARGET
    shortfall = max(0, target - percent)

    if headline is None:
        if percent >= target:
            headline = 'Fully documented'
            detail = ('Tower profile and all {0} application record{1} are '
                      'complete.'.format(app_count,
                                         '' if app_count == 1 else 's'))
        else:
            headline = '{0} points short of the {1}% target'.format(
                shortfall, target)
            detail = '{0} is the weaker half at {1}%.'.format(
                weakest, records_percent if weakest == 'Application records'
                else profile_percent)

    return {
        'percent': percent,
        'grade': label,
        'badge': badge,
        'tone': tone,
        'icon': grade_icon(label),
        'headline': headline,
        'detail': detail,
        'weakest': weakest,
        'target': target,
        'shortfall': shortfall,
        'meets_target': percent >= target,
        'profile_percent': profile_percent,
        'records_percent': records_percent,
        'app_count': app_count,
        'below_target': int(records.get('below_target', 0) or 0),
        'meets_count': int(records.get('meets_target', 0) or 0),
        'at_risk': int(records.get('at_risk', 0) or 0),
    }


def worst_checks(scorecards, limit=None):
    """
    Which checks are most often short across a set of applications.

    Answers "what is the estate as a whole not filling in", which is a very
    different question from any single application's gaps and the one that
    decides where to spend a documentation drive.
    """
    tally = {}
    for card in scorecards or []:
        for check in card['checks']:
            row = tally.get(check['key'])
            if row is None:
                row = tally[check['key']] = {
                    'key': check['key'], 'label': check['label'],
                    'icon': check['icon'], 'section': check['section'],
                    'missing': 0, 'partial': 0, 'complete': 0, 'total': 0,
                }
            row[check['status']] += 1
            row['total'] += 1
    rows = list(tally.values())
    for row in rows:
        outstanding = row['missing'] + row['partial']
        row['outstanding'] = outstanding
        row['percent_outstanding'] = (
            int(round(100.0 * outstanding / row['total'])) if row['total'] else 0)
    # Worst first: most missing, then most partial, then alphabetical so the
    # order is stable when two checks tie.
    rows.sort(key=lambda r: (-r['missing'], -r['partial'], r['label']))
    if limit:
        rows = rows[:limit]
    return rows


# ---------------------------------------------------------------------------
# PERSISTENCE
#
# Everything below talks to the database. The bulk loaders exist because the
# dashboards score every application in the estate at once, and a per-row
# lazy load would turn that into hundreds of queries.
# ---------------------------------------------------------------------------

# SQL Server caps a statement at 2100 parameters, so an IN clause over every
# application id in a large estate has to be chunked.
_IN_CHUNK = 500


def _rows_by_application(db_session, model, application_ids):
    """{application_id: [row, ...]} for one child table, in chunked queries."""
    grouped = dict((app_id, []) for app_id in application_ids)
    ids = list(application_ids)
    for start in range(0, len(ids), _IN_CHUNK):
        chunk = ids[start:start + _IN_CHUNK]
        if not chunk:
            continue
        rows = (db_session.query(model)
                .filter(model.application_id.in_(chunk)).all())
        for row in rows:
            grouped.setdefault(row.application_id, []).append(row)
    return grouped


def load_related(db_session, application_ids):
    """
    {application_id: related bundle} for the scored child tables.

    Five queries per chunk regardless of how many applications are asked
    for, so scoring a whole tower - or the whole estate - stays cheap.
    """
    ids = [int(app_id) for app_id in application_ids]
    bundles = dict((app_id, empty_related()) for app_id in ids)
    if not ids:
        return bundles
    sources = (
        ('servers', ServerDetails),
        ('support_team', SupportTeam),
        ('business_users', BusinessUsers),
        ('vendors', VendorDetails),
        ('tech_stack', ApplicationTechStack),
    )
    for key, model in sources:
        for app_id, rows in _rows_by_application(db_session, model, ids).items():
            if app_id in bundles:
                bundles[app_id][key] = rows
    return bundles


def score_applications(db_session, applications):
    """{application_id: scorecard} for a list of ApplicationDetails rows."""
    apps = list(applications or [])
    bundles = load_related(db_session, [app.id for app in apps])
    return dict((app.id, score_application(app, bundles.get(app.id)))
                for app in apps)


def tower_applications(db_session, tower_ids=None):
    """
    {tower_id: [ApplicationDetails, ...]} for the active applications.

    Without ``tower_ids`` every active application in the estate comes back,
    which is what the estate-wide quality dashboard needs.
    """
    query = (db_session.query(ApplicationDetails)
             .filter(ApplicationDetails.is_active == sql_true()))
    if tower_ids is not None:
        ids = list(tower_ids)
        if not ids:
            return {}
        query = query.filter(ApplicationDetails.tower_id.in_(ids))
    grouped = {}
    for app in query.order_by(ApplicationDetails.application_name).all():
        grouped.setdefault(app.tower_id, []).append(app)
    return grouped
