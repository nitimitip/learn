"""
Application Support -> professional Excel / PDF downloads.

Two document families:

* Tower profile      - tower summary (name, lead, description, KPIs) followed
                       by the applications grouped by business criticality
                       (BC1 / BC2 / BC3) with name + description.
* Application profile - every piece of information held about one
                       application: overview, support team, business users,
                       vendors, servers, external interfaces, jobs, tasks,
                       critical issues and the file inventory.

Both are produced in Excel (openpyxl) and PDF (reportlab) using the same
NPG (Northern Powergrid) red brand palette as the Project Management
exports, so every download reads as a deliverable from one system.
"""

from __future__ import annotations

import io
import re
from datetime import date, datetime
from xml.sax.saxutils import escape

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.page import PageMargins
from openpyxl.worksheet.properties import PageSetupProperties

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (
    Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer,
    Table, TableStyle,
)

from . import categories, quality, support_summary

# Brand palette - NPG red (mirrors project_management/project_excel.py).
BRAND    = "AB1236"   # title bands & section headers
BRAND_DK = "7E0D27"   # subtitles & column-header rows
BAND     = "F1F5F9"
BORDER   = "D7DEE7"
TEXT     = "1D293D"
MUTED    = "6B7280"

# Business criticality -> (fill, font, label) chip colours.
BC_META = {
    "BC1": ("FEE2E2", "991B1B", "Business Critical - Tier 1"),
    "BC2": ("FEF3C7", "92400E", "High Priority - Tier 2"),
    "BC3": ("DCFCE7", "166534", "Normal Priority - Tier 3"),
}

# Standards-compliance status -> (fill, font) chip colours. Mirrors the
# badge classes the Technical Details tab uses on screen, so a printed
# profile reads the same way as the page it came from.
STATUS_META = {
    "Compliant":                ("DCFCE7", "166534"),
    "Non Compliant":            ("FEE2E2", "991B1B"),
    "Not Started":              ("E2E8F0", "334155"),
    "In Progress":              ("FEF3C7", "92400E"),
    "Vendor Product Compliant": ("DBEAFE", "1E40AF"),
    "Not assessed":             ("F1F5F9", "6B7280"),
}

# Documentation-quality grade -> (fill, font) chip colours, and the same
# for a section's status. Mirrors the badge classes the Data Quality screens
# use, so the workbook reads exactly like the page it came from.
# Six bands, matching quality.GRADE_BANDS: 100 Excellent, 90 Very Good,
# 80 Good, 50 Average, 30 Poor, under 30 Critical.
QUALITY_GRADE_META = {
    "Excellent": ("BBF7D0", "14532D"),
    "Very Good": ("DCFCE7", "166534"),
    "Good":      ("DBEAFE", "1E40AF"),
    "Average":   ("FEF3C7", "92400E"),
    "Poor":      ("FEE2E2", "991B1B"),
    "Critical":  ("FECACA", "7F1D1D"),
}

QUALITY_STATUS_META = {
    "Complete": ("DCFCE7", "166534"),
    "Partial":  ("FEF3C7", "92400E"),
    "Missing":  ("FEE2E2", "991B1B"),
}

# "Does this record clear the pass mark for its business criticality?"
TARGET_META = {
    "Yes": ("DCFCE7", "166534"),
    "No":  ("FEE2E2", "991B1B"),
}

# Workload band -> (fill, font) chip colours, mirroring the badge classes
# support_summary.LOAD_META paints on screen.
LOAD_CHIP = {
    "Overloaded":   ("FEE2E2", "991B1B"),
    "Balanced":     ("DCFCE7", "166534"),
    "Under-loaded": ("FEF3C7", "92400E"),
    "No workload":  ("F1F5F9", "6B7280"),
}

# Recommendation severity -> (fill, font).
SEVERITY_CHIP = {
    "Critical": ("FEE2E2", "991B1B"),
    "Action":   ("FEF3C7", "92400E"),
    "Note":     ("DBEAFE", "1E40AF"),
}

_THIN = Side(style="thin", color=BORDER)
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

CENTER   = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT_TOP = Alignment(horizontal="left", vertical="top", wrap_text=True)


def safe_filename(name: str) -> str:
    """A download-safe file stem: letters/digits/dash/underscore only."""
    stem = re.sub(r'[^A-Za-z0-9]+', '_', (name or 'export')).strip('_')
    return stem or 'export'


def _fmt_date(value) -> str:
    if not value:
        return ""
    if isinstance(value, (date, datetime)):
        return value.strftime("%d %b %Y")
    return str(value)


def _fmt_datetime(value) -> str:
    if not value:
        return ""
    if isinstance(value, datetime):
        return value.strftime("%d %b %Y %H:%M")
    return _fmt_date(value)


# ---------------------------------------------------------------------------
# Technical Details shaping
#
# One place builds the rows, so the workbook and the PDF can never drift
# apart on what a technology row or a standards answer contains.
# ---------------------------------------------------------------------------

#: Stack categories in the order the Technical Details tab shows them.
TECH_CATEGORIES = (
    ("os", "Operating Systems", "Operating System"),
    ("database", "Databases", "Database"),
    ("tool", "Tools & Products", "Tool / Product"),
    ("language", "Programming Languages", "Programming Language"),
)


def _tech_rows(stack, category):
    """[#, Item, Version, Description] for one stack category."""
    return [[i, r.item_name, r.version, r.description]
            for i, r in enumerate((stack or {}).get(category) or [], start=1)]


def _standard_rows(section):
    """
    [#, Practice, Description, Status, Start, Target End, Comment] rows.

    An item with no answer is reported as "Not assessed" rather than dropped:
    the gaps in an assessment are the part a reviewer most needs to see.
    """
    rows = []
    for i, row in enumerate(section.get("items") or [], start=1):
        item = row.get("item")
        entry = row.get("entry")
        rows.append([
            i,
            getattr(item, "name", "") or "",
            getattr(item, "description", "") or "",
            entry.status if entry else "Not assessed",
            _fmt_date(entry.start_date) if entry else "",
            _fmt_date(entry.end_date) if entry else "",
            (entry.comment if entry else "") or "",
        ])
    return rows


def _standard_heading(section):
    """'Python - Programming Language' / 'General - Applies to ...'."""
    title = section.get("title") or ""
    subtitle = section.get("subtitle") or ""
    return f"{title} - {subtitle}" if subtitle else title


def _standard_headline(summary):
    """One-line compliance statement for the top of the standards section."""
    summary = summary or {}
    total = summary.get("total", 0)
    answered = summary.get("answered", 0)
    if not total:
        return ("No standards checklist applies yet - record an operating "
                "system, database, tool or programming language first.")
    return (f"{summary.get('met', 0)} of {answered} assessed control(s) met "
            f"({summary.get('percent', 0)}%) - {answered} of {total} practice(s) "
            f"assessed, {summary.get('unanswered', 0)} still to assess.")


# ---------------------------------------------------------------------------
# Excel helpers (same visual language as the Project Management workbook)
# ---------------------------------------------------------------------------

def _autosize(ws, widths):
    for idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width


def _title_band(ws, title, subtitle, ncols) -> int:
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    c = ws.cell(row=1, column=1, value=title)
    c.font = Font(name="Calibri", size=15, bold=True, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=BRAND)
    c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[1].height = 30

    if subtitle:
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
        s = ws.cell(row=2, column=1, value=subtitle)
        s.font = Font(name="Calibri", size=10, italic=True, color="FFFFFF")
        s.fill = PatternFill("solid", fgColor=BRAND_DK)
        s.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        ws.row_dimensions[2].height = 20
        return 4
    return 3


def _section_band(ws, row, label, ncols) -> int:
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    h = ws.cell(row=row, column=1, value=label)
    h.font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    h.fill = PatternFill("solid", fgColor=BRAND)
    h.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row].height = 22
    return row + 1


def _header_row(ws, row, headers):
    for col, label in enumerate(headers, start=1):
        cell = ws.cell(row=row, column=col, value=label)
        cell.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=BRAND_DK)
        cell.alignment = CENTER
        cell.border = _BORDER
    ws.row_dimensions[row].height = 24


def _style_cell(cell, banded=False, center=False):
    cell.font = Font(name="Calibri", size=10, color=TEXT)
    cell.alignment = CENTER if center else LEFT_TOP
    cell.border = _BORDER
    if banded:
        cell.fill = PatternFill("solid", fgColor=BAND)


def _chip(cell, fill, font_clr):
    cell.fill = PatternFill("solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=10, bold=True, color=font_clr)
    cell.alignment = CENTER
    cell.border = _BORDER


def _empty_row(ws, row, ncols, message) -> int:
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=message)
    c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
    c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    return row + 1


def _field(ws, row, label, value, ncols=2):
    """Label/value pair row used on overview sheets."""
    lc = ws.cell(row=row, column=1, value=label)
    lc.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
    lc.fill = PatternFill("solid", fgColor=BRAND_DK)
    lc.alignment = LEFT_TOP
    lc.border = _BORDER
    if ncols > 2:
        ws.merge_cells(start_row=row, start_column=2, end_row=row, end_column=ncols)
    vc = ws.cell(row=row, column=2, value=value if value not in (None, "") else "-")
    vc.font = Font(name="Calibri", size=10, color=TEXT)
    vc.alignment = LEFT_TOP
    vc.border = _BORDER
    for col in range(3, ncols + 1):
        ws.cell(row=row, column=col).border = _BORDER
    ws.row_dimensions[row].height = max(
        20, 14 * (1 + str(value or '').count('\n')))
    return row + 1


def _table_section(ws, row, title, headers, rows, ncols, empty_msg,
                   center_cols=(), chip_col=None, chip_map=None,
                   chip_cols=None):
    """
    Section band + column headers + banded data rows; returns next row.

    ``chip_col`` (1-based) paints that column as a status chip using
    ``chip_map`` = {value: (fill, font)}, so a status column reads like the
    coloured badge it is on screen rather than as plain text.

    ``chip_cols`` = {column: chip_map} does the same for SEVERAL columns at
    once, which the quality matrix needs - it carries one status column per
    scored section. A value with no entry in its map falls back to a normal
    cell rather than being dropped.
    """
    row = _section_band(ws, row, title, ncols)
    _header_row(ws, row, headers)
    row += 1
    if not rows:
        return _empty_row(ws, row, ncols, empty_msg) + 1
    chips = dict(chip_cols or {})
    if chip_col:
        chips[chip_col] = chip_map or {}
    for i, values in enumerate(rows, start=1):
        banded = (i % 2 == 0)
        for col, val in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col,
                           value=val if val not in (None, "") else "-")
            paint = chips.get(col, {}).get(val)
            if paint:
                fill, font_clr = paint
                _chip(cell, fill, font_clr)
            else:
                _style_cell(cell, banded, center=(col in center_cols))
        row += 1
    return row + 1


def _print_setup(ws, orientation="landscape", repeat_rows=None):
    ws.page_setup.orientation = orientation
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    ws.page_margins = PageMargins(left=0.4, right=0.4, top=0.5, bottom=0.55,
                                  header=0.2, footer=0.25)
    if repeat_rows:
        ws.print_title_rows = repeat_rows
    ws.oddFooter.left.text = "NPg AppAssist - Application Support"
    ws.oddFooter.left.size = 8
    ws.oddFooter.left.color = MUTED
    ws.oddFooter.right.text = "Page &P of &N"
    ws.oddFooter.right.size = 8
    ws.oddFooter.right.color = MUTED


# ---------------------------------------------------------------------------
# Tower profile - Excel
# ---------------------------------------------------------------------------

def build_tower_workbook(tower, apps_by_bc, member_count, generated_by) -> bytes:
    """`apps_by_bc` is {'BC1': [app, ...], 'BC2': [...], 'BC3': [...]}."""
    wb = Workbook()

    # Sheet 1 - Tower Summary
    ws = wb.active
    ws.title = "Tower Summary"
    ws.sheet_view.showGridLines = False
    _autosize(ws, [26, 88])
    row = _title_band(ws, f"Tower Profile - {tower.tower_name}",
                      "Application Support - Tower Summary", 2)
    row = _field(ws, row, "Tower Name", tower.tower_name)
    row = _field(ws, row, "Tower Lead", tower.tower_lead or "")
    row = _field(ws, row, "Summary", tower.short_summary or "")
    row += 1

    total_apps = sum(len(v) for v in apps_by_bc.values())
    row = _section_band(ws, row, "At a glance", 2)
    row = _field(ws, row, "Total Applications", total_apps)
    for bc in ("BC1", "BC2", "BC3"):
        fill, font_clr, label = BC_META[bc]
        lc = ws.cell(row=row, column=1, value=f"{bc} - {label}")
        lc.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        lc.fill = PatternFill("solid", fgColor=BRAND_DK)
        lc.alignment = LEFT_TOP
        lc.border = _BORDER
        vc = ws.cell(row=row, column=2, value=len(apps_by_bc.get(bc, [])))
        _chip(vc, fill, font_clr)
        vc.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        ws.row_dimensions[row].height = 20
        row += 1
    row = _field(ws, row, "Tower Members", member_count)
    row += 1
    row = _field(ws, row, "Generated", datetime.now().strftime("%d %b %Y %H:%M"))
    _field(ws, row, "Generated by", generated_by or "-")
    _print_setup(ws, orientation="portrait")

    # Sheet 2 - Applications grouped by business criticality
    ws2 = wb.create_sheet("Applications")
    ws2.sheet_view.showGridLines = False
    ncols = 4
    _autosize(ws2, [5, 34, 26, 78])
    row = _title_band(ws2, "Applications by Business Criticality",
                      f"Tower: {tower.tower_name} - {total_apps} application(s)",
                      ncols)
    for bc in ("BC1", "BC2", "BC3"):
        fill, font_clr, label = BC_META[bc]
        apps = apps_by_bc.get(bc, [])
        row = _section_band(ws2, row, f"{bc} - {label} - {len(apps)} application(s)",
                            ncols)
        _header_row(ws2, row, ["#", "Application", "Category", "Description"])
        row += 1
        if not apps:
            row = _empty_row(ws2, row, ncols,
                             f"No {bc} applications in this tower.") + 1
            continue
        for i, app in enumerate(apps, start=1):
            banded = (i % 2 == 0)
            values = [i, app.application_name,
                      categories.category_name(app) or "Uncategorised",
                      app.application_summary or ""]
            for col, val in enumerate(values, start=1):
                cell = ws2.cell(row=row, column=col,
                                value=val if val not in (None, "") else "-")
                _style_cell(cell, banded, center=(col == 1))
            _chip(ws2.cell(row=row, column=1), fill, font_clr)
            ws2.cell(row=row, column=1, value=i)
            row += 1
        row += 1
    _print_setup(ws2, repeat_rows="1:2")

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()


# ---------------------------------------------------------------------------
# Application profile - Excel
# ---------------------------------------------------------------------------

def build_application_workbook(app, data, generated_by) -> bytes:
    """
    `data` carries the related record lists:
        servers, support_team, business_users, vendors, interfaces,
        individual_jobs, suite_jobs, files, tasks, critical_issues
    plus 'created_by_name' / 'updated_by_name', and the Technical Details
    tab's 'tech_stack' (category -> rows), 'std_sections' and 'std_summary'.
    """
    wb = Workbook()
    bc = app.business_criticality.value

    # Sheet 1 - Overview
    ws = wb.active
    ws.title = "Overview"
    ws.sheet_view.showGridLines = False
    _autosize(ws, [26, 88])
    row = _title_band(ws, f"Application Profile - {app.application_name}",
                      f"Tower: {app.tower.tower_name if app.tower else '-'} - "
                      f"Application Support", 2)
    row = _field(ws, row, "Application Name", app.application_name)

    lc = ws.cell(row=row, column=1, value="Business Criticality")
    lc.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
    lc.fill = PatternFill("solid", fgColor=BRAND_DK)
    lc.alignment = LEFT_TOP
    lc.border = _BORDER
    fill, font_clr, label = BC_META.get(bc, ("E2E8F0", TEXT, bc))
    vc = ws.cell(row=row, column=2, value=f"{bc} - {label}")
    _chip(vc, fill, font_clr)
    vc.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    row += 1

    row = _field(ws, row, "Category",
                 categories.category_name(app) or "Uncategorised")
    row = _field(ws, row, "Tower", app.tower.tower_name if app.tower else "")
    row = _field(ws, row, "Tower Lead",
                 app.tower.tower_lead if app.tower else "")
    row = _field(ws, row, "Description / Summary", app.application_summary or "")
    row = _field(ws, row, "Accessibility", app.accessibility or "")
    row = _field(ws, row, "Created",
                 f"{data.get('created_by_name') or '-'} - {_fmt_date(app.created_at)}")
    row = _field(ws, row, "Last Updated",
                 f"{data.get('updated_by_name') or '-'} - {_fmt_date(app.updated_at)}")
    row += 1

    row = _section_band(ws, row, "Record counts", 2)
    for label_, key in (("Servers", "servers"),
                        ("Support Team Members", "support_team"),
                        ("Business Users", "business_users"),
                        ("Vendors", "vendors"),
                        ("External Interfaces", "interfaces"),
                        ("Individual Jobs", "individual_jobs"),
                        ("Suite Jobs", "suite_jobs"),
                        ("Tasks", "tasks"),
                        ("Critical Issues", "critical_issues"),
                        ("Files on Record", "files")):
        row = _field(ws, row, label_, len(data.get(key) or []))
    stack = data.get("tech_stack") or {}
    for key, plural, _singular in TECH_CATEGORIES:
        row = _field(ws, row, plural, len(stack.get(key) or []))
    std_summary = data.get("std_summary") or {}
    row = _field(ws, row, "Standards Practices Assessed",
                 f"{std_summary.get('answered', 0)} of "
                 f"{std_summary.get('total', 0)}")
    row = _field(ws, row, "Standards Compliance",
                 f"{std_summary.get('percent', 0)}% of assessed controls met")
    row += 1
    row = _field(ws, row, "Generated", datetime.now().strftime("%d %b %Y %H:%M"))
    _field(ws, row, "Generated by", generated_by or "-")
    _print_setup(ws, orientation="portrait")

    # Sheet 2 - People & Vendors
    ws2 = wb.create_sheet("People & Vendors")
    ws2.sheet_view.showGridLines = False
    ncols = 4
    _autosize(ws2, [5, 34, 26, 44])
    row = _title_band(ws2, "People & Vendors", app.application_name, ncols)
    row = _table_section(
        ws2, row, "Support Team", ["#", "Member", "Role", "Email"],
        [[i, m.member_name, m.role.value if m.role else "", m.email]
         for i, m in enumerate(data.get("support_team") or [], start=1)],
        ncols, "No support team members recorded.", center_cols=(1,))
    row = _table_section(
        ws2, row, "Business Users", ["#", "User", "Role", "Email"],
        [[i, u.user_name, u.role.value if u.role else "", u.email]
         for i, u in enumerate(data.get("business_users") or [], start=1)],
        ncols, "No business users recorded.", center_cols=(1,))
    _table_section(
        ws2, row, "Vendor Details", ["#", "Vendor", "Type", "Email"],
        [[i, v.vendor_name,
          "Bespoke Application" if v.is_bespoke else "Vendor Product", v.email]
         for i, v in enumerate(data.get("vendors") or [], start=1)],
        ncols, "No vendors recorded.", center_cols=(1,))
    _print_setup(ws2, orientation="portrait", repeat_rows="1:2")

    # Sheet 3 - Infrastructure & Interfaces
    ws3 = wb.create_sheet("Infrastructure")
    ws3.sheet_view.showGridLines = False
    ncols = 7
    _autosize(ws3, [5, 26, 18, 18, 30, 30, 22])
    row = _title_band(ws3, "Infrastructure & Interfaces",
                      app.application_name, ncols)
    row = _table_section(
        ws3, row, "Server Details",
        ["#", "Server", "Location", "Operating System",
         "Environment Description"],
        [[i, s.server_name, s.location, s.operating_system,
          s.environment_description]
         for i, s in enumerate(data.get("servers") or [], start=1)],
        ncols, "No servers recorded.", center_cols=(1,))
    _table_section(
        ws3, row, "External Interfaces",
        ["#", "Interface", "Flow Direction", "Connectivity",
         "External Server", "Description", "Contact"],
        [[i, x.interface_name,
          x.flow_direction.value if x.flow_direction else "",
          x.connectivity_type, x.external_server, x.description, x.contact]
         for i, x in enumerate(data.get("interfaces") or [], start=1)],
        ncols, "No external interfaces recorded.", center_cols=(1, 3))
    _print_setup(ws3, repeat_rows="1:2")

    # Sheet 4 - Jobs
    ws4 = wb.create_sheet("Jobs")
    ws4.sheet_view.showGridLines = False
    ncols = 10
    _autosize(ws4, [5, 24, 14, 26, 34, 16, 24, 28, 24, 28])
    row = _title_band(ws4, "Batch & Scheduled Jobs", app.application_name, ncols)
    job_headers = ["#", "Job", "Frequency", "Short Description",
                   "Full Description", "User Profile", "Prerequisites",
                   "Script", "Failure Checks", "Manual Execution Steps"]
    row = _table_section(
        ws4, row, "Individual Jobs", job_headers,
        [[i, j.job_name, j.frequency, j.short_description, j.full_description,
          j.user_profile, j.prerequisites, j.script, j.failure_checks,
          j.manual_execution_steps]
         for i, j in enumerate(data.get("individual_jobs") or [], start=1)],
        ncols, "No individual jobs recorded.", center_cols=(1,))
    suite_headers = ["#", "Suite - Job", "Frequency", "Short Description",
                     "Full Description", "User Profile", "Prerequisites",
                     "Script", "Failure Checks", "Manual Execution Steps"]
    _table_section(
        ws4, row, "Suite Jobs", suite_headers,
        [[i, f"{j.suite_name} - {j.job_name}", j.frequency,
          j.short_description, j.full_description, j.user_profile,
          j.prerequisites, j.script, j.failure_checks,
          j.manual_execution_steps]
         for i, j in enumerate(data.get("suite_jobs") or [], start=1)],
        ncols, "No suite jobs recorded.", center_cols=(1,))
    _print_setup(ws4, repeat_rows="1:2")

    # Sheet 5 - Tasks & Critical Issues
    ws5 = wb.create_sheet("Tasks & Issues")
    ws5.sheet_view.showGridLines = False
    ncols = 5
    _autosize(ws5, [5, 30, 42, 42, 16])
    row = _title_band(ws5, "Tasks & Critical Issues", app.application_name, ncols)
    row = _table_section(
        ws5, row, "Application Tasks",
        ["#", "Task", "Description", "Steps", "Created"],
        [[i, t.task_name, t.description, t.steps, _fmt_date(t.created_at)]
         for i, t in enumerate(data.get("tasks") or [], start=1)],
        ncols, "No tasks recorded.", center_cols=(1, 5))
    _table_section(
        ws5, row, "Critical Issues",
        ["#", "Issue", "Problem Description", "Solution Steps", "Created"],
        [[i, c.issue_name, c.problem_description, c.solution_steps,
          _fmt_date(c.created_at)]
         for i, c in enumerate(data.get("critical_issues") or [], start=1)],
        ncols, "No critical issues recorded.", center_cols=(1, 5))
    _print_setup(ws5, repeat_rows="1:2")

    # Sheet 6 - File inventory
    ws6 = wb.create_sheet("Files")
    ws6.sheet_view.showGridLines = False
    ncols = 4
    _autosize(ws6, [5, 40, 56, 18])
    row = _title_band(ws6, "File Inventory", app.application_name, ncols)
    _table_section(
        ws6, row, "Files on Record",
        ["#", "File", "Description", "Uploaded"],
        [[i, f.file_name, f.description, _fmt_date(f.uploaded_at)]
         for i, f in enumerate(data.get("files") or [], start=1)],
        ncols, "No files uploaded for this application.", center_cols=(1, 4))
    _print_setup(ws6, orientation="portrait", repeat_rows="1:2")

    # Sheet 7 - Technical Details (the recorded stack)
    ws7 = wb.create_sheet("Technical Details")
    ws7.sheet_view.showGridLines = False
    ncols = 4
    _autosize(ws7, [5, 36, 18, 62])
    row = _title_band(ws7, "Technical Details", app.application_name, ncols)
    stack = data.get("tech_stack") or {}
    for key, plural, singular in TECH_CATEGORIES:
        row = _table_section(
            ws7, row, plural, ["#", singular, "Version", "Description"],
            _tech_rows(stack, key), ncols,
            f"No {plural.lower()} recorded.", center_cols=(1,))
    _print_setup(ws7, orientation="portrait", repeat_rows="1:2")

    # Sheet 8 - Application standard practices
    ws8 = wb.create_sheet("Standard Practices")
    ws8.sheet_view.showGridLines = False
    ncols = 7
    _autosize(ws8, [5, 32, 54, 24, 15, 17, 42])
    row = _title_band(ws8, "Application Standard Practices",
                      app.application_name, ncols)
    row = _section_band(ws8, row, "Compliance Summary", ncols)
    row = _empty_row(ws8, row,
                     ncols, _standard_headline(data.get("std_summary"))) + 1
    std_headers = ["#", "Practice", "Description", "Status", "Start Date",
                   "Target End Date", "Comment"]
    sections = data.get("std_sections") or []
    if not sections:
        row = _table_section(
            ws8, row, "Standards Checklist", std_headers, [], ncols,
            "No standards checklist applies to this application yet.",
            center_cols=(1,))
    for section in sections:
        row = _table_section(
            ws8, row, _standard_heading(section), std_headers,
            _standard_rows(section), ncols,
            "No practices defined for this section.",
            center_cols=(1, 5, 6), chip_col=4, chip_map=STATUS_META)
    _print_setup(ws8, repeat_rows="1:2")

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()


# ---------------------------------------------------------------------------
# Documentation quality report - Excel
#
# Same visual language as the Application Profile workbook: brand title
# band, section bands, banded tables, and a coloured chip for anything that
# is a badge on screen. Five sheets, because a documentation drive needs
# different cuts of the same scoring run:
#
#   Quality Summary      the headline, the grade spread and the scoring rules
#   Tower Scoreboard     who owns the weakest records
#   Application Records  one line per application, worst first
#   Section Detail       the status matrix - which section is short, per app
#   Estate Gaps          which sections the estate as a whole is neglecting
# ---------------------------------------------------------------------------

#: BC_META reduced to the (fill, font) pairs the chip columns expect.
BC_CHIP = dict((code, (fill, font_clr))
               for code, (fill, font_clr, _label) in BC_META.items())


def _scored_label(estate) -> str:
    """'12 applications' - the count the report was run over."""
    count = (estate or {}).get("count", 0)
    return "{0} application{1}".format(count, "" if count == 1 else "s")


def _chip_field(ws, row, label, value, fill, font_clr) -> int:
    """A _field row whose value is painted as a chip rather than plain text."""
    lc = ws.cell(row=row, column=1, value=label)
    lc.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
    lc.fill = PatternFill("solid", fgColor=BRAND_DK)
    lc.alignment = LEFT_TOP
    lc.border = _BORDER
    vc = ws.cell(row=row, column=2, value=value)
    _chip(vc, fill, font_clr)
    vc.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row].height = 20
    return row + 1


def build_quality_workbook(scope, estate, tower_rows, app_rows, gap_rows,
                           generated_by) -> bytes:
    """
    Documentation quality report.

    ``scope``       the tower name, or 'All Towers'.
    ``estate``      quality.rollup() over every scored application.
    ``tower_rows``  [{'tower': ORM, 'profile': card, 'records': rollup}]
    ``app_rows``    [{'app': ORM, 'tower': ORM, 'card': card}]
    ``gap_rows``    quality.worst_checks() output.

    Rows arrive in the order the screen shows them - weakest documented
    first - and are written in that order, so the workbook and the page
    always agree on the priority list.
    """
    wb = Workbook()
    grade_meta = QUALITY_GRADE_META
    checks = quality.APPLICATION_CHECKS

    # --- Sheet 1: Quality Summary ----------------------------------------
    ws = wb.active
    ws.title = "Quality Summary"
    ws.sheet_view.showGridLines = False
    _autosize(ws, [34, 80])
    row = _title_band(ws, "Documentation Quality - {0}".format(scope),
                      "Application Support - Data Quality Report", 2)
    row = _field(ws, row, "Scope", scope)
    row = _field(ws, row, "Applications Scored", _scored_label(estate))

    fill, font_clr = grade_meta.get(estate.get("grade"), ("E2E8F0", TEXT))
    row = _chip_field(ws, row, "Overall Score",
                      "{0}% - {1}".format(estate.get("percent", 0),
                                          estate.get("grade", "-")),
                      fill, font_clr)
    row = _field(ws, row, "At Target", estate.get("meets_target", 0))
    row = _field(ws, row, "Below Target", estate.get("below_target", 0))
    row = _field(ws, row, "Critically Thin (under {0}%)".format(
        quality.AT_RISK_BELOW), estate.get("at_risk", 0))
    row += 1

    row = _section_band(ws, row, "Grade distribution", 2)
    for band, count in (estate.get("bands") or {}).items():
        fill, font_clr = grade_meta.get(band, ("E2E8F0", TEXT))
        row = _chip_field(ws, row, band, count, fill, font_clr)
    row += 1

    row = _section_band(ws, row, "How the score is calculated", 2)
    for _key, label, section, weight, _icon in checks:
        row = _field(ws, row, label, "{0} points - {1}".format(weight, section))
    row = _field(ws, row, "Total", "100 points")
    row += 1
    for bc_code, target in quality.TARGET_BY_BC.items():
        row = _field(ws, row, "Pass mark - {0}".format(bc_code),
                     "{0}%".format(target))
    row += 1
    row = _field(ws, row, "Not scored",
                 ", ".join(label for _k, label, _i in quality.OPTIONAL_SECTIONS)
                 + " - these depend on what the application is, so their "
                   "absence is not a defect.")
    row = _field(ws, row, "Scoring rules",
                 "Placeholder text (NA, TBD, -) counts as not filled. A "
                 "single short line scores a fraction, not a pass. Sections "
                 "earn partial credit. A support team with no Primary Owner, "
                 "or business users with no Owner, cannot score complete.")
    row += 1
    row = _field(ws, row, "Generated",
                 datetime.now().strftime("%d %b %Y %H:%M"))
    _field(ws, row, "Generated by", generated_by or "-")
    _print_setup(ws, orientation="portrait")

    # --- Sheet 2: Tower Scoreboard ---------------------------------------
    ws2 = wb.create_sheet("Tower Scoreboard")
    ws2.sheet_view.showGridLines = False
    ncols = 10
    _autosize(ws2, [5, 30, 22, 8, 15, 14, 13, 14, 13, 62])
    row = _title_band(ws2, "Tower Scoreboard",
                      "{0} - weakest documented first".format(scope), ncols)
    rows = []
    for i, entry in enumerate(tower_rows or [], start=1):
        profile, records = entry["profile"], entry["records"]
        rows.append([
            i,
            entry["tower"].tower_name,
            entry["tower"].tower_lead or "",
            records.get("count", 0),
            "{0}%".format(profile["percent"]),
            profile["grade"],
            "{0}%".format(records["percent"]),
            records["grade"],
            records.get("below_target", 0),
            "\n".join(profile["gaps"]),
        ])
    _table_section(
        ws2, row, "Towers",
        ["#", "Tower", "Tower Lead", "Apps", "Tower Profile", "Profile Grade",
         "Records", "Records Grade", "Below Target",
         "Outstanding on the Tower Card"],
        rows, ncols, "No towers to report on.",
        center_cols=(1, 4, 5, 7, 9),
        chip_cols={6: grade_meta, 8: grade_meta})
    _print_setup(ws2, repeat_rows="1:2")

    # --- Sheet 3: Application Records ------------------------------------
    ws3 = wb.create_sheet("Application Records")
    ws3.sheet_view.showGridLines = False
    ncols = 12
    _autosize(ws3, [5, 24, 32, 8, 11, 12, 10, 14, 11, 10, 10, 70])
    row = _title_band(ws3, "Application Records",
                      "{0} - weakest documented first".format(scope), ncols)
    rows = []
    for i, entry in enumerate(app_rows or [], start=1):
        card = entry["card"]
        rows.append([
            i,
            entry["tower"].tower_name if entry.get("tower") else "",
            entry["app"].application_name,
            card["criticality"],
            "{0}%".format(card["percent"]),
            card["grade"],
            "{0}%".format(card["target"]),
            "Yes" if card["meets_target"] else "No",
            card["complete"],
            card["partial"],
            card["missing"],
            "\n".join(card["gaps"]),
        ])
    _table_section(
        ws3, row, "Records",
        ["#", "Tower", "Application", "BC", "Quality", "Grade", "Target",
         "Meets Target", "Complete", "Partial", "Missing",
         "Outstanding Actions"],
        rows, ncols, "No application records to score.",
        center_cols=(1, 5, 7, 9, 10, 11),
        chip_cols={4: BC_CHIP, 6: grade_meta, 8: TARGET_META})
    _print_setup(ws3, repeat_rows="1:2")

    # --- Sheet 4: Section Detail (the status matrix) ----------------------
    ws4 = wb.create_sheet("Section Detail")
    ws4.sheet_view.showGridLines = False
    ncols = 3 + len(checks)
    _autosize(ws4, [5, 24, 32] + [17] * len(checks))
    row = _title_band(
        ws4, "Section Detail",
        "{0} - which section is short, per application".format(scope), ncols)
    rows = []
    for i, entry in enumerate(app_rows or [], start=1):
        by_key = dict((check["key"], check) for check in entry["card"]["checks"])
        line = [i,
                entry["tower"].tower_name if entry.get("tower") else "",
                entry["app"].application_name]
        for key, _label, _section, _weight, _icon in checks:
            check = by_key.get(key)
            line.append(check["status"].title() if check else "")
        rows.append(line)
    _table_section(
        ws4, row, "Scored Sections",
        ["#", "Tower", "Application"] + [label for _k, label, _s, _w, _i
                                         in checks],
        rows, ncols, "No application records to score.",
        center_cols=(1,),
        chip_cols=dict((col, QUALITY_STATUS_META)
                       for col in range(4, ncols + 1)))
    _print_setup(ws4, repeat_rows="1:2")

    # --- Sheet 5: Estate Gaps --------------------------------------------
    ws5 = wb.create_sheet("Estate Gaps")
    ws5.sheet_view.showGridLines = False
    ncols = 8
    _autosize(ws5, [5, 30, 20, 10, 12, 10, 10, 18])
    row = _title_band(ws5, "Most Neglected Sections",
                      "{0} - across {1}".format(scope, _scored_label(estate)),
                      ncols)
    weight_by_key = dict((key, weight)
                         for key, _l, _s, weight, _i in checks)
    rows = [[i, entry["label"], entry["section"],
             weight_by_key.get(entry["key"], ""),
             entry["complete"], entry["partial"], entry["missing"],
             "{0}%".format(entry["percent_outstanding"])]
            for i, entry in enumerate(gap_rows or [], start=1)]
    _table_section(
        ws5, row, "Sections",
        ["#", "Section", "Area", "Weight", "Complete", "Partial", "Missing",
         "Outstanding"],
        rows, ncols, "No application records to score.",
        center_cols=(1, 4, 5, 6, 7, 8))
    _print_setup(ws5, orientation="portrait", repeat_rows="1:2")

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()


# ---------------------------------------------------------------------------
# Tower Summary Status - Excel
#
# Five sheets, in the order the screen reads: the headline, the
# application-wise ticket detail, the workload distribution, the proposed
# moves, and the recommendations. Built from the SAME report dict the page
# renders (support_summary.build_tower_report), so a circulated workbook can
# never quote a different number than the page it came from.
# ---------------------------------------------------------------------------

def _pcounts(counts):
    """P1..P4 in a fixed order, whatever the dict's insertion order."""
    return [counts.get(code, 0) for code in support_summary.TICKET_PRIORITIES]


def build_support_summary_workbook(report, generated_by) -> bytes:
    """The Tower Summary Status report as a workbook."""
    tower = report["tower"]
    totals = report["totals"]
    balance = report["balance"]
    verdict = report["verdict"]
    unattributed = report["unattributed"]
    cfg = report["config"]
    scope = tower.tower_name

    wb = Workbook()

    # --- Sheet 1: Summary -------------------------------------------------
    ws = wb.active
    ws.title = "Summary"
    ws.sheet_view.showGridLines = False
    _autosize(ws, [34, 84])
    row = _title_band(ws, "Tower Summary Status - {0}".format(scope),
                      "Application Support - ServiceNow demand and workload "
                      "distribution", 2)
    row = _field(ws, row, "Tower", scope)
    row = _field(ws, row, "Tower Lead", tower.tower_lead or "-")
    row = _field(ws, row, "ServiceNow Assignment Group(s)",
                 ", ".join(report["group_names"])
                 or "NOT CONFIGURED - no tickets can be matched to this tower")
    row = _field(ws, row, "Ticket Window",
                 "Last {0} days{1}".format(
                     report["window_days"],
                     " ({0} to {1})".format(_fmt_date(report["data_from"]),
                                            _fmt_date(report["data_to"]))
                     if report["data_from"] else " - no dated tickets matched"))
    row += 1

    row = _section_band(ws, row, "Demand", 2)
    row = _field(ws, row, "Incidents", totals["incidents"])
    row = _field(ws, row, "Service Requests", totals["service_requests"])
    row = _field(ws, row, "Tickets Matched (total)", totals["tickets"])
    for code, count in zip(support_summary.TICKET_PRIORITIES,
                           _pcounts(totals["priority_counts"])):
        row = _field(ws, row, "Priority {0}".format(code), count)
    row = _field(ws, row, "Named No Application", unattributed["tickets"])
    row += 1

    row = _section_band(ws, row, "Coverage", 2)
    row = _field(ws, row, "Applications", totals["applications"])
    row = _field(ws, row, "With a Primary Owner", totals["owned_applications"])
    row = _field(ws, row, "Team Members (support teams)",
                 totals["team_members"])
    row = _field(ws, row, "App Assist Tower Members (access only)",
                 report["access_members"])
    row += 1

    row = _section_band(ws, row, "Distribution", 2)
    row = _chip_field(ws, row, "Verdict", verdict["label"],
                      *LOAD_CHIP.get(
                          "Overloaded" if verdict["key"] == "imbalanced"
                          else ("Under-loaded" if verdict["key"] == "watch"
                                else ("Balanced" if verdict["key"] == "balanced"
                                      else "No workload")),
                          ("F1F5F9", "6B7280")))
    row = _field(ws, row, "Finding", verdict["headline"])
    row = _field(ws, row, "Detail", verdict["detail"])
    row = _field(ws, row, "Total Weight Carried", balance["total_weight"])
    row = _field(ws, row, "Team Average", balance["average"])
    row = _field(ws, row, "Overload Ceiling",
                 "{0} ({1}% of average)".format(balance["ceiling"],
                                                balance["threshold_percent"]))
    row = _field(ws, row, "Fair-share Floor", balance["floor"])
    row = _field(ws, row, "Heaviest / Lightest",
                 "{0} / {1}{2}".format(
                     balance["heaviest"], balance["lightest"],
                     " ({0}x spread)".format(balance["spread"])
                     if balance["spread"] else ""))
    row = _field(ws, row, "Overloaded",
                 ", ".join(m["name"] for m in balance["overloaded"]) or "none")
    row = _field(ws, row, "Under-loaded",
                 ", ".join(m["name"] for m in balance["underloaded"]) or "none")
    row += 1

    # The structural rules. Reported next to the weights because the verdict
    # needs both: an evenly weighted team whose applications each rest on one
    # person is not a balanced tower.
    rules = report["rules"]
    row = _section_band(ws, row, "Distribution Rules", 2)
    if not rules["assessable"]:
        row = _field(ws, row, "Status",
                     "Not assessable - no application in this tower names a "
                     "primary owner, so there is no ownership model to judge.")
    else:
        row = _field(ws, row, "Rules Met",
                     "{0} of {1}".format(rules["met"], rules["total"]))
        for key in rules["order"]:
            rule = rules[key]
            row = _chip_field(
                ws, row, rule["title"], "Met" if rule["ok"] else "Not met",
                *(("DCFCE7", "15803D") if rule["ok"]
                  else (("FEF3C7", "B45309") if rule["tone"] == "warning"
                        else ("FEE2E2", "B91C1C"))))
        spread = rules["equal_spread"]
        row = _field(ws, row, "Fair Share",
                     "{0} application(s) each across {1} member(s); the band "
                     "a whole-application split allows is {2} to {3}, and the "
                     "team runs from {4} to {5}.".format(
                         spread["fair_share"], spread["members"],
                         spread["low"], spread["high"], spread["least"],
                         spread["most"]))
        row = _field(ws, row, "Applications With No Backup",
                     ", ".join(rules["backup_cover"]["missing"]) or "none")
        row = _field(ws, row, "Backed Up By A Non-Owner",
                     ", ".join(
                         "{0} ({1})".format(entry["application"],
                                            ", ".join(entry["backups"]))
                         for entry in rules["backup_is_owner"]["offenders"])
                     or "none")
        row = _field(ws, row, "Members Owning Nothing",
                     ", ".join(rules["everyone_owns"]["members"])
                     or ("none" if rules["everyone_owns"]["enforced"]
                         else "not enforced - fewer applications than members"))
    row += 1

    row = _section_band(ws, row, "How the numbers are built", 2)
    row = _field(ws, row, "Ticket to tower",
                 "The ticket's ServiceNow assignment group matches one of the "
                 "tower group names above.")
    row = _field(ws, row, "Ticket to application",
                 "The application name appears in the ticket's short "
                 "description. Where two names appear, the longer (more "
                 "specific) one wins. Unmatched tickets are reported as "
                 "Unattributed and carry no weight.")
    row = _field(ws, row, "Weight",
                 "(priority score x {0}) + effort, where effort = "
                 "(incidents x {1} + service requests x {2}) x support "
                 "factor. Priority and effort are ADDED, so a vendor-supported "
                 "tier one system still carries its "
                 "responsibility.".format(cfg["priority_coeff"],
                                          cfg["incident_effort_points"],
                                          cfg["sr_effort_points"]))
    row = _field(ws, row, "Support factor",
                 "Vendor {0} / Hybrid {1} / Bespoke {2} - a vendor carries "
                 "the technical depth, a bespoke application has no safety "
                 "net.".format(cfg["vendor_support_factor"],
                               cfg["hybrid_support_factor"],
                               cfg["bespoke_support_factor"]))
    row = _field(ws, row, "Application priority",
                 "Taken from business criticality: BC1 -> P1, BC2 -> P2, "
                 "BC3 -> P3. The ticket-level ServiceNow priorities are "
                 "reported separately as the P1-P4 mix.")
    row = _field(ws, row, "BAU reserve",
                 "{0}% of each person's capacity is reserved for changes, "
                 "adhoc requests and patching. The weights cover incidents "
                 "and service requests only.".format(
                     int(round(cfg["bau_reserve_percent"] * 100))))
    row = _field(ws, row, "Buddy load",
                 "A team member who is not the primary owner carries {0}% of "
                 "the application weight.".format(
                     int(round(cfg["buddy_load_factor"] * 100))))
    row = _field(ws, row, "Distribution rules",
                 "Four structural conditions judged alongside the weights: "
                 "applications spread equally by count; every owned "
                 "application has a backup; that backup is a primary owner "
                 "in their own right; and every support member owns a set of "
                 "their own. A tower that breaks one is never reported as "
                 "Balanced. The first and last are only enforced where there "
                 "are enough applications for everybody to hold one.")
    row += 1
    row = _field(ws, row, "Generated",
                 datetime.now().strftime("%d %b %Y %H:%M"))
    _field(ws, row, "Generated by", generated_by or "-")
    _print_setup(ws, orientation="portrait")

    # --- Sheet 2: Application Detail --------------------------------------
    ws2 = wb.create_sheet("Application Detail")
    ws2.sheet_view.showGridLines = False
    ncols = 13
    _autosize(ws2, [5, 30, 12, 13, 11, 13, 7, 7, 7, 7, 24, 24, 10])
    row = _title_band(ws2, "Application Detail",
                      "{0} - heaviest workload first".format(scope), ncols)
    rows = []
    for i, entry in enumerate(report["app_rows"], start=1):
        rows.append([i, entry["name"], entry["criticality"],
                     entry["support_type"], entry["incidents"],
                     entry["service_requests"]]
                    + _pcounts(entry["priority_counts"])
                    + [entry["owner"] or "NO OWNER",
                       ", ".join(entry["backup"]) or "SINGLE COVER",
                       entry["weight"]])
    if unattributed["tickets"]:
        rows.append(["", "Unattributed", "-", "no application named",
                     unattributed["incidents"],
                     unattributed["service_requests"]]
                    + _pcounts(unattributed["priority_counts"])
                    + ["-", "-", "-"])
    row = _table_section(
        ws2, row, "Applications",
        ["#", "Application", "Criticality", "Support Type", "Incidents",
         "Service Requests", "P1", "P2", "P3", "P4", "Primary Owner",
         "Buddy", "Weight"],
        rows, ncols, "No applications registered in this tower.",
        center_cols=(1, 5, 6, 7, 8, 9, 10, 13), chip_col=3, chip_map=BC_CHIP)

    if unattributed["samples"]:
        _table_section(
            ws2, row, "Unattributed ticket examples",
            ["#", "Short description"],
            [[i, text] for i, text in enumerate(unattributed["samples"],
                                                start=1)],
            ncols,
            "None.", center_cols=(1,))
    _print_setup(ws2, repeat_rows="1:2")

    # --- Sheet 3: Workload Distribution -----------------------------------
    ws3 = wb.create_sheet("Workload Distribution")
    ws3.sheet_view.showGridLines = False
    ncols = 12
    _autosize(ws3, [5, 26, 8, 16, 11, 10, 11, 14, 11, 11, 11, 44])
    row = _title_band(
        ws3, "Workload Distribution",
        "{0} - average {1}, ceiling {2}, floor {3} weight units".format(
            scope, balance["average"], balance["ceiling"], balance["floor"]),
        ncols)
    rows = [[i, entry["name"], entry["app_count"], entry["count_label"],
             entry["weight"], entry["buddy_load"], entry["total_load"],
             "{0}%".format(entry["percent_of_average"]),
             entry["band_label"], entry["headroom"],
             entry["tickets_handled"], ", ".join(entry["owns"]) or "backup only"]
            for i, entry in enumerate(report["member_rows"], start=1)]
    row = _table_section(
        ws3, row, "Load per team member",
        ["#", "Team Member", "Apps", "Fair Share", "Owned Weight",
         "Buddy Load", "Total Load", "% of Average", "Status",
         "Margin to relative ceiling", "Tickets Worked", "Applications Owned"],
        rows, ncols,
        "No support team is recorded on any application in this tower.",
        center_cols=(1, 3, 4, 5, 6, 7, 8, 10, 11), chip_col=9,
        chip_map=LOAD_CHIP)

    if report["unlisted_workers"]:
        _table_section(
            ws3, row, "Working tickets but not on a support team",
            ["#", "Name", "Tickets Worked", "Incidents", "Service Requests"],
            [[i, entry["name"], entry["tickets"], entry["incidents"],
              entry["service_requests"]]
             for i, entry in enumerate(report["unlisted_workers"], start=1)],
            ncols, "None.", center_cols=(1, 3, 4, 5))
    _print_setup(ws3, repeat_rows="1:2")

    # --- Sheet 4: Coverage & Equal Spread Plan ----------------------------
    ws_plan = wb.create_sheet("Coverage Plan")
    ws_plan.sheet_view.showGridLines = False
    ncols = 7
    _autosize(ws_plan, [5, 26, 12, 26, 20, 20, 62])
    row = _title_band(
        ws_plan, "Coverage & Equal Spread Plan",
        "{0} - what it would take to satisfy the four distribution rules, "
        "assuming the Proposed Moves sheet is applied first".format(scope),
        ncols)
    _table_section(
        ws_plan, row, "Proposed assignments",
        ["#", "Rule", "Action", "Application", "Primary Owner", "Assign",
         "Why"],
        [[i, rules[action["rule"]]["title"],
          "Hand over" if action["kind"] == "ownership" else "Add backup",
          action["application"], action["from"], action["to"],
          action["reason"]]
         for i, action in enumerate(report["coverage_actions"], start=1)],
        ncols,
        "Nothing to propose - the four distribution rules are met."
        if rules.get("ok") else
        "No assignment could be proposed under the recorded ownership. "
        "Review the rules on the Summary sheet before deciding staffing.",
        center_cols=(1, 3))
    _print_setup(ws_plan, repeat_rows="1:2")

    # --- Sheet 5: Proposed Moves ------------------------------------------
    ws4 = wb.create_sheet("Proposed Moves")
    ws4.sheet_view.showGridLines = False
    ncols = 7
    _autosize(ws4, [5, 28, 22, 22, 10, 12, 62])
    row = _title_band(ws4, "Proposed Moves",
                      "{0} - overload relief only; the coverage plan is on "
                      "its own sheet".format(scope), ncols)
    _table_section(
        ws4, row, "Suggested ownership handovers",
        ["#", "Application", "From", "To", "Weight", "Disruption",
         "Why this one"],
        [[i, move["application"], move["from"], move["to"], move["weight"],
          move["disruption_cost"], move["reason"]]
         for i, move in enumerate(report["moves"], start=1)],
        ncols,
        "No moves proposed - nobody is above the overload ceiling."
        if not balance["overloaded"] else
        "No eligible move found under the recorded load and skill assumptions. "
        "Review evidence, skills and cover before making staffing decisions.",
        center_cols=(1, 5, 6))
    _print_setup(ws4, repeat_rows="1:2")

    # --- Sheet 6: Recommendations -----------------------------------------
    ws5 = wb.create_sheet("Recommendations")
    ws5.sheet_view.showGridLines = False
    ncols = 6
    _autosize(ws5, [5, 12, 16, 40, 62, 52])
    row = _title_band(ws5, "Recommendations",
                      "{0} - most severe first".format(scope), ncols)
    _table_section(
        ws5, row, "Findings",
        ["#", "Severity", "Area", "Finding", "Detail", "Action"],
        [[i, rec["severity_label"], rec["area"], rec["title"], rec["detail"],
          rec["action"]]
         for i, rec in enumerate(report["recommendations"], start=1)],
        ncols, "No findings.", center_cols=(1,), chip_col=2,
        chip_map=SEVERITY_CHIP)
    _print_setup(ws5, repeat_rows="1:2")

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()


# ---------------------------------------------------------------------------
# PDF scaffolding (reportlab)
# ---------------------------------------------------------------------------

_PDF_BRAND    = colors.HexColor("#AB1236")
_PDF_BRAND_DK = colors.HexColor("#7E0D27")
_PDF_BAND     = colors.HexColor("#F1F5F9")
_PDF_BORDER   = colors.HexColor("#D7DEE7")
_PDF_TEXT     = colors.HexColor("#1D293D")
_PDF_MUTED    = colors.HexColor("#6B7280")

_P_BODY = ParagraphStyle("body", fontName="Helvetica", fontSize=8.5,
                         leading=11.5, textColor=_PDF_TEXT)
_P_BODY_B = ParagraphStyle("body-b", parent=_P_BODY, fontName="Helvetica-Bold")
_P_HEAD = ParagraphStyle("head", fontName="Helvetica-Bold", fontSize=8.5,
                         leading=11, textColor=colors.white)
_P_TITLE = ParagraphStyle("title", fontName="Helvetica-Bold", fontSize=15,
                          leading=19, textColor=colors.white)
_P_SUB = ParagraphStyle("sub", fontName="Helvetica-Oblique", fontSize=9,
                        leading=12, textColor=colors.white)
_P_SECTION = ParagraphStyle("section", fontName="Helvetica-Bold", fontSize=10.5,
                            leading=13, textColor=colors.white)
_P_EMPTY = ParagraphStyle("empty", fontName="Helvetica-Oblique", fontSize=8.5,
                          leading=11, textColor=_PDF_MUTED)


def _p(text, style=_P_BODY):
    if text in (None, ""):
        text = "-"
    safe = escape(str(text)).replace("\r\n", "\n").replace("\n", "<br/>")
    return Paragraph(safe, style)


def _pdf_title(title, subtitle, width):
    """Brand title band, mirroring the Excel exports."""
    t = Table([[_p(title, _P_TITLE)], [_p(subtitle, _P_SUB)]],
              colWidths=[width])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, 0), _PDF_BRAND),
        ("BACKGROUND", (0, 1), (0, 1), _PDF_BRAND_DK),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (0, 0), 8),
        ("BOTTOMPADDING", (0, 0), (0, 0), 6),
        ("TOPPADDING", (0, 1), (0, 1), 4),
        ("BOTTOMPADDING", (0, 1), (0, 1), 5),
    ]))
    return t


def _pdf_section(label, width):
    t = Table([[_p(label, _P_SECTION)]], colWidths=[width])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), _PDF_BRAND),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return [Spacer(0, 10), t, Spacer(0, 4)]


#: A sub-heading inside a section: the brand rule without the brand band.
#: A section bar is a reversed-out block, and a report that uses one every
#: three tables reads as a stack of headings rather than as a document.
_P_SUBHEAD = ParagraphStyle("subhead", fontName="Helvetica-Bold", fontSize=9,
                            leading=12, textColor=_PDF_BRAND_DK,
                            spaceBefore=0, spaceAfter=0)


def _pdf_sub(label, width):
    """A sub-heading under a section bar, ruled rather than filled."""
    t = Table([[_p(label, _P_SUBHEAD)]], colWidths=[width])
    t.setStyle(TableStyle([
        ("LINEBELOW", (0, 0), (-1, -1), 0.75, _PDF_BRAND),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    return [Spacer(0, 8), t, Spacer(0, 4)]


def _pdf_table(headers, rows, col_widths, empty_msg):
    """Column-header + banded data table; falls back to an 'empty' note."""
    if not rows:
        t = Table([[_p(empty_msg, _P_EMPTY)]], colWidths=[sum(col_widths)])
        t.setStyle(TableStyle([
            ("BOX", (0, 0), (-1, -1), 0.5, _PDF_BORDER),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ]))
        return [t]
    body = [[_p(h, _P_HEAD) for h in headers]]
    for values in rows:
        body.append([_p(v) for v in values])
    # splitInRow: an application can carry a single description / set of steps
    # that is many pages long. A table row cannot be broken across pages by
    # default, so ONE such cell made the whole row taller than a page and
    # reportlab aborted the build with LayoutError ("too large on page N in
    # frame 'normal'") - the download 500'd. With splitInRow the row is broken
    # mid-cell and the text simply continues on the next page.
    t = Table(body, colWidths=col_widths, repeatRows=1, splitInRow=1)
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), _PDF_BRAND_DK),
        ("GRID", (0, 0), (-1, -1), 0.5, _PDF_BORDER),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]
    for i in range(2, len(body), 2):
        style.append(("BACKGROUND", (0, i), (-1, i), _PDF_BAND))
    t.setStyle(TableStyle(style))
    return [t]


def _pdf_note(text, width):
    """A single bordered line - the PDF twin of the Excel _empty_row band."""
    t = Table([[_p(text, _P_BODY)]], colWidths=[width])
    t.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.5, _PDF_BORDER),
        ("BACKGROUND", (0, 0), (-1, -1), _PDF_BAND),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return [t]


def _pdf_status_table(headers, rows, col_widths, empty_msg, status_col,
                      meta=None):
    """
    _pdf_table with one column painted as a status chip.

    ``status_col`` is 0-based. Colours come from STATUS_META by default, so a
    printed profile reads the same way as the Technical Details tab it came
    from; ``meta`` overrides that palette for documents with their own chip
    vocabulary (the architecture report's severities).
    """
    meta = STATUS_META if meta is None else meta
    flowables = _pdf_table(headers, rows, col_widths, empty_msg)
    if not rows:
        return flowables
    table = flowables[0]
    extra = []
    for index, values in enumerate(rows, start=1):   # +1 for the header row
        chip = meta.get(values[status_col])
        if not chip:
            continue
        fill, font_clr = chip
        extra.append(("BACKGROUND", (status_col, index), (status_col, index),
                      colors.HexColor("#" + fill)))
        extra.append(("TEXTCOLOR", (status_col, index), (status_col, index),
                      colors.HexColor("#" + font_clr)))
    if extra:
        table.setStyle(TableStyle(extra))
    return flowables


def _pdf_fields(pairs, width):
    """Label/value block (the PDF twin of the Excel overview sheet)."""
    label_w = width * 0.28
    body = [[_p(label, _P_HEAD), _p(value)] for label, value in pairs]
    # splitInRow - the summary / accessibility values are free text and can run
    # past a full page on their own (see _pdf_table).
    t = Table(body, colWidths=[label_w, width - label_w], splitInRow=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), _PDF_BRAND_DK),
        ("GRID", (0, 0), (-1, -1), 0.5, _PDF_BORDER),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return [t]


def _pdf_footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(_PDF_BORDER)
    canvas.setLineWidth(0.5)
    canvas.line(doc.leftMargin, 12 * mm,
                doc.pagesize[0] - doc.rightMargin, 12 * mm)
    canvas.setFont("Helvetica", 7.5)
    canvas.setFillColor(_PDF_MUTED)
    canvas.drawString(doc.leftMargin, 8.5 * mm,
                      "NPg AppAssist - Application Support")
    canvas.drawRightString(doc.pagesize[0] - doc.rightMargin, 8.5 * mm,
                           f"Page {canvas.getPageNumber()}")
    canvas.restoreState()


_PDF_MARGIN = 14 * mm

#: SimpleDocTemplate pads its frame by 6pt on each side, so a flowable actually
#: gets 12pt LESS than (page width - margins). Tables were being built at the
#: full margin width and so overflowed their frame on every export; reportlab
#: reports exactly that in the LayoutError - a 515.9pt table in a 503.9pt frame.
#: Overflow alone is survivable, but it eats into the slack reportlab needs when
#: deciding whether a row fits, so it made the oversized-row failure likelier.
_PDF_FRAME_PAD = 6


def _pdf_document(story, title, pagesize=A4) -> bytes:
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=pagesize,
        leftMargin=_PDF_MARGIN, rightMargin=_PDF_MARGIN,
        topMargin=12 * mm, bottomMargin=18 * mm,
        title=title, author="NPg AppAssist",
    )
    doc.build(story, onFirstPage=_pdf_footer, onLaterPages=_pdf_footer)
    buffer.seek(0)
    return buffer.getvalue()


def _pdf_content_width(pagesize=A4) -> float:
    return pagesize[0] - 2 * _PDF_MARGIN - 2 * _PDF_FRAME_PAD


def _pdf_content_height(pagesize=A4) -> float:
    """Usable height inside the frame - what a full-page flowable may claim."""
    return pagesize[1] - 12 * mm - 18 * mm - 2 * _PDF_FRAME_PAD


# ---------------------------------------------------------------------------
# Tower profile - PDF
# ---------------------------------------------------------------------------

def build_tower_pdf(tower, apps_by_bc, member_count, generated_by) -> bytes:
    width = _pdf_content_width()
    total_apps = sum(len(v) for v in apps_by_bc.values())

    story = [_pdf_title(f"Tower Profile - {tower.tower_name}",
                        "Application Support - Tower Summary", width),
             Spacer(0, 10)]
    story += _pdf_fields([
        ("Tower Name", tower.tower_name),
        ("Tower Lead", tower.tower_lead or "-"),
        ("Summary", tower.short_summary or "-"),
        ("Total Applications", total_apps),
        ("BC1 - Business Critical", len(apps_by_bc.get("BC1", []))),
        ("BC2 - High Priority", len(apps_by_bc.get("BC2", []))),
        ("BC3 - Normal Priority", len(apps_by_bc.get("BC3", []))),
        ("Tower Members", member_count),
        ("Generated", datetime.now().strftime("%d %b %Y %H:%M")
         + (f" by {generated_by}" if generated_by else "")),
    ], width)

    for bc in ("BC1", "BC2", "BC3"):
        _fill, _font, label = BC_META[bc]
        apps = apps_by_bc.get(bc, [])
        story += _pdf_section(
            f"{bc} - {label} - {len(apps)} application(s)", width)
        story += _pdf_table(
            ["#", "Application", "Category", "Description"],
            [[i, a.application_name,
              categories.category_name(a) or "Uncategorised",
              a.application_summary or "-"]
             for i, a in enumerate(apps, start=1)],
            [width * 0.05, width * 0.25, width * 0.18, width * 0.52],
            f"No {bc} applications in this tower.")

    return _pdf_document(story, f"Tower Profile - {tower.tower_name}")


# ---------------------------------------------------------------------------
# Application profile - PDF
# ---------------------------------------------------------------------------

def build_application_pdf(app, data, generated_by) -> bytes:
    width = _pdf_content_width()
    bc = app.business_criticality.value
    _fill, _font, bc_label = BC_META.get(bc, ("", "", bc))

    story = [_pdf_title(f"Application Profile - {app.application_name}",
                        f"Tower: {app.tower.tower_name if app.tower else '-'}"
                        " - Application Support", width),
             Spacer(0, 10)]
    story += _pdf_fields([
        ("Application Name", app.application_name),
        ("Business Criticality", f"{bc} - {bc_label}"),
        ("Category", categories.category_name(app) or "Uncategorised"),
        ("Tower", app.tower.tower_name if app.tower else "-"),
        ("Tower Lead", app.tower.tower_lead if app.tower else "-"),
        ("Description / Summary", app.application_summary or "-"),
        ("Accessibility", app.accessibility or "-"),
        ("Created", f"{data.get('created_by_name') or '-'} - "
                    f"{_fmt_date(app.created_at) or '-'}"),
        ("Last Updated", f"{data.get('updated_by_name') or '-'} - "
                         f"{_fmt_date(app.updated_at) or '-'}"),
        ("Generated", datetime.now().strftime("%d %b %Y %H:%M")
         + (f" by {generated_by}" if generated_by else "")),
    ], width)

    story += _pdf_section("Support Team", width)
    story += _pdf_table(
        ["#", "Member", "Role", "Email"],
        [[i, m.member_name, m.role.value if m.role else "", m.email]
         for i, m in enumerate(data.get("support_team") or [], start=1)],
        [width * 0.05, width * 0.35, width * 0.25, width * 0.35],
        "No support team members recorded.")

    story += _pdf_section("Business Users", width)
    story += _pdf_table(
        ["#", "User", "Role", "Email"],
        [[i, u.user_name, u.role.value if u.role else "", u.email]
         for i, u in enumerate(data.get("business_users") or [], start=1)],
        [width * 0.05, width * 0.35, width * 0.25, width * 0.35],
        "No business users recorded.")

    story += _pdf_section("Vendor Details", width)
    story += _pdf_table(
        ["#", "Vendor", "Type", "Email"],
        [[i, v.vendor_name,
          "Bespoke Application" if v.is_bespoke else "Vendor Product", v.email]
         for i, v in enumerate(data.get("vendors") or [], start=1)],
        [width * 0.05, width * 0.35, width * 0.25, width * 0.35],
        "No vendors recorded.")

    story += _pdf_section("Server Details", width)
    story += _pdf_table(
        ["#", "Server", "Location", "Operating System", "Environment"],
        [[i, s.server_name, s.location, s.operating_system,
          s.environment_description]
         for i, s in enumerate(data.get("servers") or [], start=1)],
        [width * 0.05, width * 0.23, width * 0.17, width * 0.20, width * 0.35],
        "No servers recorded.")

    story += _pdf_section("External Interfaces", width)
    story += _pdf_table(
        ["#", "Interface", "Direction", "Connectivity", "External Server",
         "Description"],
        [[i, x.interface_name,
          x.flow_direction.value if x.flow_direction else "",
          x.connectivity_type, x.external_server, x.description]
         for i, x in enumerate(data.get("interfaces") or [], start=1)],
        [width * 0.05, width * 0.20, width * 0.12, width * 0.14,
         width * 0.19, width * 0.30],
        "No external interfaces recorded.")

    story += _pdf_section("Individual Jobs", width)
    story += _pdf_table(
        ["#", "Job", "Frequency", "Description", "Failure Checks"],
        [[i, j.job_name, j.frequency,
          j.short_description or j.full_description, j.failure_checks]
         for i, j in enumerate(data.get("individual_jobs") or [], start=1)],
        [width * 0.05, width * 0.22, width * 0.13, width * 0.35, width * 0.25],
        "No individual jobs recorded.")

    story += _pdf_section("Suite Jobs", width)
    story += _pdf_table(
        ["#", "Suite - Job", "Frequency", "Description", "Failure Checks"],
        [[i, f"{j.suite_name} - {j.job_name}", j.frequency,
          j.short_description or j.full_description, j.failure_checks]
         for i, j in enumerate(data.get("suite_jobs") or [], start=1)],
        [width * 0.05, width * 0.22, width * 0.13, width * 0.35, width * 0.25],
        "No suite jobs recorded.")

    story += _pdf_section("Application Tasks", width)
    story += _pdf_table(
        ["#", "Task", "Description", "Steps"],
        [[i, t.task_name, t.description, t.steps]
         for i, t in enumerate(data.get("tasks") or [], start=1)],
        [width * 0.05, width * 0.25, width * 0.35, width * 0.35],
        "No tasks recorded.")

    story += _pdf_section("Critical Issues", width)
    story += _pdf_table(
        ["#", "Issue", "Problem Description", "Solution Steps"],
        [[i, c.issue_name, c.problem_description, c.solution_steps]
         for i, c in enumerate(data.get("critical_issues") or [], start=1)],
        [width * 0.05, width * 0.25, width * 0.35, width * 0.35],
        "No critical issues recorded.")

    story += _pdf_section("File Inventory", width)
    story += _pdf_table(
        ["#", "File", "Description", "Uploaded"],
        [[i, f.file_name, f.description, _fmt_date(f.uploaded_at)]
         for i, f in enumerate(data.get("files") or [], start=1)],
        [width * 0.05, width * 0.35, width * 0.45, width * 0.15],
        "No files uploaded for this application.")

    stack = data.get("tech_stack") or {}
    for key, plural, singular in TECH_CATEGORIES:
        story += _pdf_section(plural, width)
        story += _pdf_table(
            ["#", singular, "Version", "Description"],
            _tech_rows(stack, key),
            [width * 0.05, width * 0.32, width * 0.15, width * 0.48],
            f"No {plural.lower()} recorded.")

    story += _pdf_section("Application Standard Practices", width)
    story += _pdf_note(_standard_headline(data.get("std_summary")), width)
    std_headers = ["#", "Practice", "Description", "Status", "Start",
                   "Target End", "Comment"]
    std_widths = [width * 0.04, width * 0.16, width * 0.26, width * 0.12,
                  width * 0.09, width * 0.09, width * 0.24]
    sections = data.get("std_sections") or []
    if not sections:
        story += _pdf_table(
            std_headers, [], std_widths,
            "No standards checklist applies to this application yet.")
    for section in sections:
        story += _pdf_section(_standard_heading(section), width)
        story += _pdf_status_table(
            std_headers, _standard_rows(section), std_widths,
            "No practices defined for this section.", status_col=3)

    return _pdf_document(story, f"Application Profile - {app.application_name}")


# ---------------------------------------------------------------------------
# Architecture report - PDF
#
# The diagram AND the reading of it, in one document, in the same house style
# as the tower and application profiles.
#
# The diagram itself is rendered client-side: both architecture views draw
# HTML cards over an SVG wire layer, and only the page that laid them out
# knows where everything ended up. Rather than reimplement the layout here
# (two layout engines that must agree is a bug waiting to be filed), the page
# serialises the SAME model it drew to an image and posts it up; this builder
# places that image and then writes everything AROUND it from the estate as
# the server sees it, so the numbers in the report cannot drift from the
# database even if the picture is a second old.
#
# Landscape A4 throughout - an estate diagram and a group-to-group matrix are
# both wider than they are tall, and a portrait page would shrink one to
# illegibility to keep the other company.
# ---------------------------------------------------------------------------

_ARCH_PAGESIZE = landscape(A4)

#: Severity -> (fill, font) chip colours for the findings table. Same three
#: weights the module already uses for BC1/BC2/BC3 chips, so a reader who has
#: seen one of these documents can read the other without a key.
SEVERITY_META = {
    "High": ("FEE2E2", "991B1B"),
    "Medium": ("FEF3C7", "92400E"),
    "Low": ("E0F2FE", "075985"),
}

SEVERITY_LABELS = {"high": "High", "medium": "Medium", "low": "Low"}

#: The scorecard's grade bands, painted the way the screen paints them so a
#: printed report and the page it came from cannot be read differently.
GRADE_META = {
    "A": ("DCFCE7", "14532D"),
    "B": ("E0F2FE", "075985"),
    "C": ("FEF3C7", "92400E"),
    "D": ("FFEDD5", "9A3412"),
    "E": ("FEE2E2", "991B1B"),
    "n/a": ("F1F0EE", "57534E"),
}

#: How soon the estate is hurt by leaving an agenda item alone.
HORIZON_META = {
    "Now": ("FEE2E2", "991B1B"),
    "Next": ("FEF3C7", "92400E"),
    "Later": ("F1F0EE", "57534E"),
}

#: Past this many groups the matrix stops being readable on a page, so the
#: report prints the busiest ones and says so rather than printing a grid of
#: 4pt digits nobody can use. The full matrix is always on screen.
_MATRIX_PRINT_LIMIT = 12

#: The diagram gets a page of its own (see build_architecture_pdf), so it may
#: claim nearly all of it - the reserve is for the section band above it and
#: the caption below. Sizing it to a FRACTION of what is left over instead
#: was the version that printed a page-and-a-half of white space: reportlab
#: pushed a diagram that did not fit onto the next page and left the gap
#: where it had been.
_DIAGRAM_MAX_FRACTION = 0.80


def _fmt_pct(value):
    """A percentage that may legitimately be absent (no interfaces at all)."""
    if value is None:
        return "n/a"
    return f"{value}%"


def _joined(items, limit=6):
    """A short, honest list: the first few, then how many were left out."""
    items = [str(i) for i in items if str(i).strip()]
    if not items:
        return "-"
    if len(items) <= limit:
        return ", ".join(items)
    return ", ".join(items[:limit]) + f" (+{len(items) - limit} more)"


def _diagram_flowable(image_bytes, width, height):
    """The posted diagram, scaled to fit the page in both directions.

    Returns None when there is no usable image - the report is still worth
    printing without it, and a broken Image flowable would take the whole
    download down with a LayoutError.
    """
    if not image_bytes:
        return None
    try:
        reader = ImageReader(io.BytesIO(image_bytes))
        native_w, native_h = reader.getSize()
    except Exception:
        return None
    if not native_w or not native_h:
        return None
    scale = min(width / float(native_w), height / float(native_h))
    return Image(io.BytesIO(image_bytes),
                 width=native_w * scale, height=native_h * scale)


def _short(name, limit=14):
    """A column heading that fits: the matrix is square, so headings cannot
    be allowed to set the column width."""
    name = str(name or "")
    return name if len(name) <= limit else name[:limit - 1] + "."


def _matrix_pdf_table(matrix, noun, width):
    """The directional group-to-group matrix as a printable grid.

    Rows are sources, columns are targets, the diagonal is traffic that stays
    inside the group, and the last two columns are the fan-out / fan-in
    margins - identical to the on-screen table, because it is the same
    payload.
    """
    rows = matrix.get("rows") or []
    if len(rows) < 2:
        return _pdf_note(
            "At least two populated groups are needed before an integration "
            "matrix says anything.", width)

    order = sorted(range(len(rows)),
                   key=lambda i: (-rows[i]["total"], -rows[i]["apps"]))
    keep = sorted(order[:_MATRIX_PRINT_LIMIT])
    trimmed = len(rows) - len(keep)
    cells = matrix.get("cells") or []

    headers = ["From / To"] + [_short(rows[i]["name"]) for i in keep] + ["Out", "In"]
    body = []
    for i in keep:
        line = [rows[i]["name"]]
        for j in keep:
            value = cells[i][j]["count"] if i < len(cells) and j < len(cells[i]) else 0
            if i == j:
                line.append(f"[{value}]" if value else "-")
            else:
                line.append(str(value) if value else ".")
        line.append(str(rows[i]["out"]))
        line.append(str(rows[i]["inb"]))
        body.append(line)

    label_w = width * 0.20
    tail_w = width * 0.10
    grid_w = width - label_w - tail_w
    col_widths = ([label_w] + [grid_w / len(keep)] * len(keep)
                  + [tail_w / 2, tail_w / 2])

    flowables = _pdf_table(headers, body, col_widths,
                           "No integration recorded.")
    flowables[0].setStyle(TableStyle([
        ("ALIGN", (1, 1), (-1, -1), "CENTER"),
        ("FONTSIZE", (0, 0), (-1, -1), 7),
        ("BACKGROUND", (-2, 1), (-1, -1), _PDF_BAND),
    ]))
    note = (f"Read a row as the source and a column as the target: cell (row, "
            f"column) is the number of interfaces flowing from the row's "
            f"{noun} into the column's. A bracketed figure on the diagonal is "
            f"traffic that stays inside that {noun}; a dot is no traffic at "
            f"all. Out and In are the fan-out and fan-in margins. A two-way "
            f"interface counts once in each direction.")
    if trimmed:
        note += (f" The {trimmed} least-connected {noun}(s) are omitted here "
                 f"for legibility; the full matrix is on screen.")
    return flowables + _pdf_note(note, width)


def _findings_rows(findings):
    rows = []
    for entry in findings.get("rows") or []:
        rows.append([
            SEVERITY_LABELS.get(entry.get("severity"), "Low"),
            entry.get("area") or "",
            entry.get("title") or "",
            entry.get("detail") or "",
            entry.get("impact") or "-",
            entry.get("action") or "",
            entry.get("metric") or "-",
        ])
    return rows


def _executive_pdf(insights, width):
    """The reading of the estate: index, narrative, scorecard, agenda.

    This goes in FRONT of the measurements, because it is what the report is
    for. A reader who stops after these four pages has the position, the
    argument and the three things to commission; everything after it is the
    evidence they would turn to if they disagreed.
    """
    scorecard = insights.get("scorecard") or {}
    narrative = insights.get("narrative") or {}
    agenda = insights.get("agenda") or {}
    story = []

    # ---- the position ---------------------------------------------------
    story += _pdf_section("Executive summary", width)
    index = scorecard.get("index")
    story += _pdf_fields([
        ("Estate health index",
         "Not rated - too little recorded to grade" if index is None
         else "{0} out of 100 - grade {1}, {2}".format(
             index, scorecard.get("grade", "?"), scorecard.get("band", ""))),
        ("Strongest position", scorecard.get("strongest") or "-"),
        ("Weakest position", scorecard.get("weakest") or "-"),
        ("Open actions", "{0} now, {1} next, {2} later".format(
            (agenda.get("horizons") or {}).get("Now", 0),
            (agenda.get("horizons") or {}).get("Next", 0),
            (agenda.get("horizons") or {}).get("Later", 0))),
    ], width)

    for line in narrative.get("summary") or []:
        story += _pdf_note(line, width)

    # ---- what is working, what needs a decision -------------------------
    story += _pdf_section("Where the estate stands", width)
    rows = []
    for entry in narrative.get("working") or []:
        rows.append(["Working", entry["dimension"], entry["score"],
                     entry["note"]])
    for entry in narrative.get("attention") or []:
        rows.append(["Needs a decision", entry["dimension"], entry["score"],
                     entry["note"]])
    story += _pdf_table(
        ["Position", "Dimension", "Score", "What the score is saying"],
        rows,
        [width * 0.14, width * 0.22, width * 0.08, width * 0.56],
        "No dimension scored far enough either way to report.")

    # ---- the three to commission first ----------------------------------
    story += _pdf_section("Take these first", width)
    story += _pdf_status_table(
        ["When", "Action", "Why it matters to the business", "Owner",
         "Effort"],
        [[d["horizon"], d["title"], d["impact"], d["owner"], d["effort"]]
         for d in narrative.get("decisions") or []],
        [width * 0.08, width * 0.22, width * 0.40, width * 0.20,
         width * 0.10],
        "Nothing in this estate crossed a reporting threshold.",
        status_col=0, meta=HORIZON_META)
    story += _pdf_note(
        "The highest-severity items, cheapest first within that. Between two "
        "things that hurt equally, commission the one that can be closed this "
        "month. Severity is about how quickly the estate is hurt by leaving "
        "an item alone, not about how hard the fix is - that is the effort "
        "column.", width)

    # ---- the scorecard --------------------------------------------------
    story.append(PageBreak())
    story += _pdf_section("Estate scorecard", width)
    story += _pdf_status_table(
        ["Grade", "Dimension", "Score", "The question it answers",
         "What the grade is saying", "Weight"],
        [[r["grade"], r["dimension"],
          "-" if r["score"] is None else r["score"],
          r["question"], r["verdict"], "{0}%".format(r["weight"])]
         for r in scorecard.get("rows") or []],
        [width * 0.06, width * 0.18, width * 0.06, width * 0.26,
         width * 0.36, width * 0.08],
        "The estate holds nothing to score yet.",
        status_col=0, meta=GRADE_META)
    story += _pdf_note(
        "Each dimension starts at 100 and is marked down by what the estate "
        "record actually says; the drivers behind each grade are listed "
        "below. A dimension the estate holds no evidence for is marked not "
        "rated and left out of the overall index rather than scored zero - a "
        "missing measurement is not a bad result.", width)

    driver_rows = []
    for row in scorecard.get("rows") or []:
        for driver in row.get("drivers") or []:
            driver_rows.append([
                row["dimension"], driver["label"], driver["measure"],
                "-{0}".format(driver["impact"]) if driver["impact"] > 0
                else "no cost",
                driver["note"],
            ])
    story += _pdf_section("What produced each grade", width)
    story += _pdf_table(
        ["Dimension", "Driver", "Measured", "Points", "What it means"],
        driver_rows,
        [width * 0.18, width * 0.20, width * 0.12, width * 0.08,
         width * 0.42],
        "No drivers recorded.")

    # ---- the agenda ------------------------------------------------------
    story.append(PageBreak())
    story += _pdf_section(
        "Action agenda ({0})".format(agenda.get("total", 0)), width)
    agenda_rows = []
    for theme in agenda.get("themes") or []:
        for entry in theme.get("rows") or []:
            agenda_rows.append([
                entry["horizon"], theme["theme"], entry["title"],
                entry["impact"], entry["action"], entry["owner"],
                entry["effort"],
            ])
    story += _pdf_status_table(
        ["When", "Theme", "Finding", "Why it matters to the business",
         "Recommended action", "Owner", "Effort"],
        agenda_rows,
        [width * 0.06, width * 0.14, width * 0.15, width * 0.26,
         width * 0.20, width * 0.13, width * 0.06],
        "Nothing to commission - no threshold in the analysis was crossed.",
        status_col=0, meta=HORIZON_META)
    story += _pdf_note(
        "Grouped by the consequence it carries rather than by the analysis "
        "that found it, with the role that can close it. Owners are named as "
        "roles and never as people: an agenda that names individuals goes "
        "stale the first time somebody moves desk.", width)

    return story


def _profiles_pdf(insights, width, label, noun):
    """One row per group, in the words the profile cards use on screen."""
    profiles = insights.get("profiles") or {}
    story = _pdf_section("{0} profiles".format(label), width)
    story += _pdf_table(
        ["Risk", label, "Apps", "BC1", "Coupling", "Third parties",
         "What this {0} is".format(noun), "What needs attention"],
        [[r["risk"], r["name"], r["apps"], r["bc1"], r["posture"],
          r["externals"], r["role_sentence"],
          _joined([w["kind"] + " - " + w["text"] for w in r["watch"]])
          or "nothing crossed a reporting threshold"]
         for r in profiles.get("rows") or []],
        [width * 0.06, width * 0.14, width * 0.05, width * 0.05,
         width * 0.09, width * 0.07, width * 0.27, width * 0.27],
        "No {0} holds an application yet.".format(noun))
    story += _pdf_note(
        "Ordered by risk, then by size. Risk is read off what is recorded "
        "against the applications inside each {0} - support cover, "
        "dependencies, suppliers, and how much of the estate has to move when "
        "this one does.".format(noun), width)
    return story


def _reading_note(brief, key, width):
    """The Shows / Why / Action lines under a brief visual, as one note."""
    reading = (brief.get("readings") or {}).get(key) or {}
    parts = [f"{label}: {reading.get(field)}"
             for label, field in (("Shows", "shows"), ("Why", "why"),
                                  ("Action", "action"))
             if reading.get(field)]
    return _pdf_note("  ".join(parts), width) if parts else []


def _brief_pdf(insights, width, noun):
    """The Business and Enterprise Architecture brief, as printed pages.

    The same five questions the panel leads with on screen - integration,
    platform, capability tier, dependency and architectural risk - and in the
    same order, so the download and the page are one document rather than
    two. Everything after it in the report is the fuller written assessment
    the analysis pack produces, which the brief deliberately does not repeat.

    An older pack with no brief in it prints nothing rather than raising: the
    report's job is to come out.
    """
    brief = insights.get("brief") or {}
    if not brief:
        return []

    integration = brief.get("integration") or {}
    platform = brief.get("platform") or {}
    capability = brief.get("capability") or {}
    dependency = brief.get("dependency") or {}
    risks = brief.get("risks") or {}

    story = _pdf_section("Architecture brief", width)
    ownership = brief.get("ownership") or {}
    alignment = brief.get("alignment") or {}
    opportunities = brief.get("opportunities") or {}
    decisions = brief.get("decisions") or {}

    story += _pdf_note(
        "The Business Architecture reading of the estate: capabilities, "
        "dependencies, integrations, technology, ownership, alignment with "
        "the architecture principles, modernisation opportunities, risks "
        "and the decisions they call for. Under each table: what it shows, "
        "why it matters and the action. The fuller written assessment "
        "follows.", width)

    story += _pdf_table(
        ["Measure", "Value", "Context"],
        [[m.get("label", ""), m.get("value", ""), m.get("note", "")]
         for m in (brief.get("rail") or [])],
        [width * 0.30, width * 0.16, width * 0.54],
        "Nothing recorded to measure.")

    # ---- capability tiers ------------------------------------------------
    story += _pdf_sub("Business capability tiers", width)
    story += _pdf_table(
        ["Tier", "Applications", "Share", "Connections", "Third-party facing",
         "No interfaces"],
        [[f"{t.get('code') or 'Not rated'} - {t.get('label', '')}",
          t.get("count", 0), _fmt_pct(t.get("pct")), t.get("connections", 0),
          t.get("external_facing", 0), t.get("isolated", 0)]
         for t in (capability.get("tiers") or [])],
        [width * 0.34, width * 0.13, width * 0.11, width * 0.14,
         width * 0.17, width * 0.11],
        "No business criticality recorded.")

    story += _reading_note(brief, "capability", width)

    # ---- integration -----------------------------------------------------
    story += _pdf_sub("Integration patterns", width)
    story += _pdf_table(
        ["Pattern", "Interfaces", "Share", "Coupling", "What it means"],
        [[r.get("pattern", ""), r.get("count", 0), _fmt_pct(r.get("pct")),
          (r.get("coupling") or "").title(), r.get("note", "")]
         for r in (integration.get("patterns") or [])],
        [width * 0.22, width * 0.11, width * 0.09, width * 0.11, width * 0.47],
        "No interfaces recorded.")
    protocols = integration.get("protocols") or []
    if protocols:
        story += _pdf_sub("Protocols in use", width)
        story += _pdf_table(
            ["Protocol", "Interfaces", "Share", "Pattern"],
            [[r.get("name", ""), r.get("count", 0), _fmt_pct(r.get("pct")),
              r.get("pattern", "")] for r in protocols],
            [width * 0.32, width * 0.14, width * 0.12, width * 0.42],
            "No connectivity type recorded on any interface.")

    story += _reading_note(brief, "integration", width)

    # ---- platform --------------------------------------------------------
    story += _pdf_sub("Operating systems", width)
    story += _pdf_table(
        ["Platform", "Applications", "Servers", "Lifecycle"],
        [[r.get("name", ""), r.get("apps", 0), r.get("servers", 0),
          "Check support position" if r.get("dated") else "-"]
         for r in (platform.get("os") or [])[:14]],
        [width * 0.40, width * 0.15, width * 0.13, width * 0.32],
        "No operating system recorded against any server or stack.")
    for bucket in (platform.get("stack") or []):
        story += _pdf_sub(bucket.get("label", "Technology"), width)
        story += _pdf_table(
            ["Technology", "Applications"],
            [[r.get("name", ""), r.get("apps", 0)]
             for r in (bucket.get("top") or [])],
            [width * 0.70, width * 0.30],
            "Nothing recorded in this category.")

    story += _reading_note(brief, "platform", width)

    # ---- dependencies ----------------------------------------------------
    story += _pdf_sub("Application dependencies", width)
    story += _pdf_table(
        ["Application", "BC", "Upstream", "Downstream", f"Cross-{noun}"],
        [[r.get("app", ""), r.get("bc", "") or "-",
          r.get("upstream", 0) + r.get("ext_upstream", 0),
          r.get("downstream", 0) + r.get("ext_downstream", 0),
          r.get("cross", 0)]
         for r in (dependency.get("rows") or [])],
        [width * 0.42, width * 0.10, width * 0.16, width * 0.17, width * 0.15],
        "No application-to-application connection has resolved.")
    story += _reading_note(brief, "dependency", width)
    story += _pdf_sub("Upstream and downstream systems", width)
    story += _pdf_table(
        ["System", "Direction", "Applications", "BC1 applications"],
        [[r.get("name", ""), r.get("role", ""), r.get("apps", 0),
          r.get("bc1", 0)]
         for r in (dependency.get("externals") or [])],
        [width * 0.42, width * 0.18, width * 0.20, width * 0.20],
        "Every recorded interface resolves inside the estate.")

    story += _reading_note(brief, "externals", width)

    # ---- ownership and accountability ------------------------------------
    story += _pdf_sub("Ownership and accountability", width)
    story += _pdf_table(
        [ownership.get("label", "Group"),
         "Business areas" if ownership.get("has_lead") else "Supported by",
         "Lead", "Owner named", "BC1 unowned"],
        [[r.get("name", ""), ", ".join(r.get("counterparts") or []) or "-",
          ", ".join(r.get("leads") or []) or "-",
          f"{r.get('owner_named', 0)}/{r.get('apps', 0)}",
          r.get("bc1_unowned", 0) or "-"]
         for r in (ownership.get("rows") or [])],
        [width * 0.22, width * 0.30, width * 0.22, width * 0.13, width * 0.13],
        "No group holds an application yet.")
    story += _reading_note(brief, "ownership", width)

    # ---- strategic alignment ---------------------------------------------
    story += _pdf_sub("Strategic alignment", width)
    story += _pdf_table(
        ["Principle", "Estate", "Target", "Status", "Measure"],
        [[r.get("label", ""),
          "-" if r.get("value") is None else _fmt_pct(r.get("value")),
          _fmt_pct(r.get("target")), (r.get("status") or "").title(),
          r.get("measure", "")]
         for r in (alignment.get("rows") or [])],
        [width * 0.32, width * 0.12, width * 0.12, width * 0.14, width * 0.30],
        "Nothing recorded to measure against the principles.")
    story += _reading_note(brief, "alignment", width)

    # ---- modernisation opportunities -------------------------------------
    story += _pdf_sub("Modernisation opportunities", width)
    story += _pdf_table(
        ["Opportunity", "Scope", "First candidates", "Benefit"],
        [[r.get("title", ""), f"{r.get('scope', 0)} {r.get('unit', '')}",
          ", ".join(r.get("candidates") or []), r.get("benefit", "")]
         for r in (opportunities.get("rows") or [])],
        [width * 0.32, width * 0.14, width * 0.28, width * 0.26],
        "Nothing in the recorded estate calls for change yet.")
    story += _reading_note(brief, "opportunities", width)

    # ---- risk ------------------------------------------------------------
    story += _pdf_sub("Key architecture and technology risks", width)
    story += _pdf_table(
        ["Severity", "Risk", "Measure", "Consequence", "Action"],
        [[(r.get("severity") or "").upper(), r.get("title", ""),
          r.get("metric", ""), r.get("detail", ""), r.get("action", "")]
         for r in (risks.get("rows") or [])],
        [width * 0.09, width * 0.22, width * 0.13, width * 0.29, width * 0.27],
        "Nothing in the recorded estate raises an architecture concern.")
    story += _reading_note(brief, "risks", width)

    # ---- decisions required ----------------------------------------------
    story += _pdf_sub("Decisions required", width)
    story += _pdf_table(
        ["#", "When", "Decision", "Because", "Owner"],
        [[i + 1, r.get("horizon", ""), r.get("decision", ""),
          r.get("because", ""), r.get("owner", "")]
         for i, r in enumerate(decisions.get("rows") or [])],
        [width * 0.04, width * 0.08, width * 0.38, width * 0.32, width * 0.18],
        "No decision is outstanding on the recorded estate.")
    story += _reading_note(brief, "decisions", width)
    return story


def build_architecture_pdf(context, insights, image_bytes,
                           generated_by) -> bytes:
    """The architecture report: the diagram, then everything it implies.

    ``context`` is what the PAGE knows and the server does not - which view,
    which altitude, what was on screen and which filters were applied.
    ``insights`` is insights.build_insights() over a graph built fresh from
    the database in this request. ``image_bytes`` is the diagram as PNG, or
    None; the report is still built without it.
    """
    pagesize = _ARCH_PAGESIZE
    width = _pdf_content_width(pagesize)
    height = _pdf_content_height(pagesize)
    noun = insights.get("noun") or "group"
    label = insights.get("label") or "Group"
    view = context.get("view") or insights.get("view") or "Architecture"
    headline = insights.get("headline") or {}
    findings = insights.get("findings") or {}
    counts = findings.get("counts") or {}

    story = [_pdf_title(f"{view} - Architecture Report",
                        context.get("title") or "Application Support",
                        width),
             Spacer(0, 8)]

    scorecard = insights.get("scorecard") or {}
    index = scorecard.get("index")
    story += _pdf_fields([
        ("View", view),
        ("Sheet on screen", context.get("subtitle") or "-"),
        ("Grouped by", label),
        ("Filters applied", context.get("filters") or "None - full estate"),
        ("Estate", "{0} application(s) in {1} {2}(s)".format(
            headline.get("apps", 0), headline.get("groups", 0), noun)),
        ("Estate health index",
         "Not rated" if index is None
         else "{0}/100 - grade {1}, {2}".format(
             index, scorecard.get("grade", "?"), scorecard.get("band", ""))),
        ("Findings", "{0} high, {1} medium, {2} low".format(
            counts.get("high", 0), counts.get("medium", 0),
            counts.get("low", 0))),
        ("Generated", datetime.now().strftime("%d %b %Y %H:%M")
         + (f" by {generated_by}" if generated_by else "")),
    ], width)

    # ---- the diagram ----------------------------------------------------
    # On its own page, deliberately. An estate diagram is the thing a reader
    # puts on a screen and points at; sharing a page with a table shrinks it
    # to make room for something they would have turned to anyway.
    story.append(PageBreak())
    story += _pdf_section("Architecture diagram", width)
    diagram = _diagram_flowable(image_bytes, width,
                                height * _DIAGRAM_MAX_FRACTION)
    if diagram is None:
        story += _pdf_note(
            "The diagram could not be captured from the page. Every figure "
            "below is read from the estate record and is unaffected.", width)
    else:
        # Heading, drawing and caption travel as one block. Left loose, a
        # diagram that just misses the bottom of its page leaves a labelled
        # blank behind and drops its caption onto a page of its own.
        caption = _pdf_note(context.get("caption")
                            or "Rendered from the live estate record at the "
                               "moment this report was generated.", width)
        story[-3:] = [KeepTogether(story[-3:] + [diagram] + caption)]

    # ---- the executive reading -------------------------------------------
    # In front of the measurements on purpose: this is what the report is
    # for. Everything after it is the evidence a reader turns to only if
    # they want to argue with it.
    story.append(PageBreak())
    # The architecture brief leads, because it is what the panel on screen
    # leads with; the written assessment that follows is the longer reading
    # of the same estate. The page break above already opened a fresh page
    # for it, so it takes one of its own only on the way OUT.
    brief_story = _brief_pdf(insights, width, noun)
    if brief_story:
        story += brief_story
        story.append(PageBreak())
    story += _executive_pdf(insights, width)
    story += _profiles_pdf(insights, width, label, noun)

    # ---- headline measures ----------------------------------------------
    story.append(PageBreak())
    story += _pdf_section("Headline measures", width)
    story += _pdf_table(
        ["Measure", "Value", "What it says"],
        [
            ["Applications", headline.get("apps", 0),
             "active applications in the estate"],
            [f"{label}s", headline.get("groups", 0),
             f"{noun}s holding at least one application"],
            [f"Cross-{noun} interfaces", headline.get("cross", 0),
             f"traffic that leaves its own {noun}"],
            [f"Within-{noun} interfaces", headline.get("intra", 0),
             f"traffic that stays inside one {noun}"],
            ["Estate autonomy", _fmt_pct(headline.get("autonomy")),
             f"share of interfaces that never cross a {noun} boundary - "
             f"higher means {noun}s can change independently"],
            [f"Connected {noun} pairs", headline.get("pairs", 0),
             f"directed {noun}-to-{noun} relationships in use"],
            ["External systems", headline.get("externals", 0),
             "third parties the estate feeds or reads from"],
            ["Evidence-backed links", _fmt_pct(headline.get("evidence")),
             "share of connections matched by a recorded hostname rather "
             "than inferred from a name"],
        ],
        [width * 0.22, width * 0.12, width * 0.66],
        "No measures available.")

    # ---- findings --------------------------------------------------------
    story += _pdf_section(
        f"Architecture findings ({findings.get('total', 0)})", width)
    story += _pdf_status_table(
        ["Severity", "Area", "Finding", "What was measured",
         "Why it matters", "Recommended action", "Metric"],
        _findings_rows(findings),
        [width * 0.06, width * 0.11, width * 0.14, width * 0.24,
         width * 0.22, width * 0.15, width * 0.08],
        "Nothing to report - no threshold in the analysis was crossed.",
        status_col=0, meta=SEVERITY_META)

    # ---- the matrix ------------------------------------------------------
    story += _pdf_section(f"Cross-{noun} integration matrix", width)
    story += _matrix_pdf_table(insights.get("matrix") or {}, noun, width)

    pairs = (insights.get("matrix") or {}).get("pairs") or []
    story += _pdf_section(f"Busiest {noun}-to-{noun} flows", width)
    story += _pdf_table(
        ["#", "From", "To", "Interfaces", "Application pairs",
         "Dominant integration style"],
        [[i, p["src"], p["dst"], p["count"], p["app_pairs"],
          p["styles"][0][0] if p["styles"] else "-"]
         for i, p in enumerate(pairs[:20], start=1)],
        [width * 0.04, width * 0.22, width * 0.22, width * 0.10,
         width * 0.12, width * 0.30],
        f"No traffic crosses a {noun} boundary.")

    # ---- coupling --------------------------------------------------------
    coupling = insights.get("coupling") or {}
    story += _pdf_section(f"{label} coupling and autonomy", width)
    story += _pdf_table(
        [label, "Apps", "BC1", "Internal", "Out", "In", "Peers",
         "Externals", "Autonomy", "Role"],
        [[r["name"], r["apps"], r["bc_mix"].get("BC1", 0), r["intra"],
          r["out"], r["inb"], r["peers"], r["externals"],
          _fmt_pct(r["autonomy"]), r["role"]]
         for r in coupling.get("rows") or []],
        [width * 0.24, width * 0.06, width * 0.06, width * 0.09,
         width * 0.06, width * 0.06, width * 0.07, width * 0.09,
         width * 0.11, width * 0.16],
        f"No {noun}s hold applications yet.")
    story += _pdf_note(
        "Autonomy is the share of a group's interfaces that never leave it. "
        "A group near 100% can be changed on its own schedule; one near 0% "
        "cannot be touched without a conversation with everyone else, "
        "whatever the org chart says. Role is read off the fan-in / fan-out "
        "balance: Provider sends far more than it receives, Consumer the "
        "reverse, Hub touches most of the estate and carries a "
        "disproportionate share of it.", width)

    # ---- applications ----------------------------------------------------
    apps = insights.get("applications") or {}
    story += _pdf_section("Applications carrying the most traffic", width)
    story += _pdf_table(
        ["#", "Application", label, "BC", "Interfaces", "Inbound", "Outbound",
         f"Cross-{noun}", "External", f"Share of cross-{noun}"],
        [[i, r["name"], r["group"] or "-", r["bc"] or "-", r["degree"],
          r["inb"], r["out"], r["cross"], r["ext"], _fmt_pct(r["share"])]
         for i, r in enumerate(apps.get("hubs") or [], start=1)],
        [width * 0.04, width * 0.22, width * 0.16, width * 0.06,
         width * 0.08, width * 0.07, width * 0.08, width * 0.09,
         width * 0.08, width * 0.12],
        "No application records an interface.")

    # ---- continuity ------------------------------------------------------
    continuity = insights.get("continuity") or {}
    story += _pdf_section("Business continuity exposure", width)
    story += _pdf_table(
        ["Business-critical application", label, "Fed by", "Rated",
         "Integration style"],
        [[r["app"], r["group"] or "-", r["source"], r["source_bc"],
          r["style"]] for r in (continuity.get("inversions") or [])[:25]],
        [width * 0.24, width * 0.18, width * 0.24, width * 0.10,
         width * 0.24],
        "No criticality inversion: nothing business-critical depends on "
        "anything rated lower than itself.")
    story += _pdf_note(
        "A feed inherits the criticality of what it serves. Where a BC1 "
        "application is fed by a BC2 or BC3 system, either the upstream "
        "rating or the dependency is wrong.", width)

    story += _pdf_table(
        ["Business-critical application", label, "Third-party system",
         "Direction", "Integration style"],
        [[r["app"], r["group"] or "-", r["system"], r["direction"] or "-",
          r["style"]] for r in (continuity.get("third_party") or [])[:25]],
        [width * 0.24, width * 0.18, width * 0.24, width * 0.12,
         width * 0.22],
        "No business-critical application depends on an inbound third-party "
        "feed.")

    story += _pdf_table(
        ["Business-critical application", label, "Named contacts", "Contact"],
        [[r["app"], r["group"] or "-", r["contacts"], r["contact"] or "-"]
         for r in (continuity.get("thin_cover") or [])[:25]],
        [width * 0.30, width * 0.24, width * 0.16, width * 0.30],
        "Every business-critical application names at least two support "
        "contacts.")

    # ---- integration style ------------------------------------------------
    protocols = insights.get("protocols") or {}
    story += _pdf_section("Integration style mix", width)
    story += _pdf_table(
        ["Integration style", "Interfaces", "Share",
         "Modernisation candidate"],
        [[r["style"], r["count"], _fmt_pct(r["pct"]),
          "Yes" if r["modernise"] else "-"]
         for r in protocols.get("rows") or []],
        [width * 0.40, width * 0.15, width * 0.15, width * 0.30],
        "No interfaces recorded.")
    story += _pdf_note(
        "Styles are read from the free-text Connectivity Type on each "
        "interface. File drops, direct database links and email are flagged "
        "as modernisation candidates: none of them is wrong, but each couples "
        "two systems in a way that is brittle, hard to observe and hard to "
        "version. {0}% of the estate's interfaces use one of "
        "them.".format(protocols.get("legacy_pct", 0)), width)

    # ---- third parties ----------------------------------------------------
    externals = insights.get("externals") or {}
    story += _pdf_section("Third-party exposure", width)
    story += _pdf_table(
        ["#", "External system", "Applications", f"{label}s reached",
         "BC1 applications", f"{label}s", "Integration styles"],
        [[i, r["name"], r["apps"], r["groups"], r["bc1"],
          _joined(r["group_names"]),
          _joined([s for s, _n in r["styles"]])]
         for i, r in enumerate((externals.get("rows") or [])[:25], start=1)],
        [width * 0.04, width * 0.22, width * 0.09, width * 0.09,
         width * 0.09, width * 0.24, width * 0.23],
        "Every interface in the estate resolves to another application in it.")
    if externals.get("shared"):
        story += _pdf_note(
            "{0} of these are depended on by more than one {1}, so no single "
            "{1} owns the relationship, the contract or the outage. Those "
            "need an enterprise owner.".format(len(externals["shared"]), noun),
            width)

    # ---- ownership --------------------------------------------------------
    ownership = insights.get("ownership") or {}
    counter = (ownership.get("counterpart_label") or "").lower()
    story += _pdf_section("Ownership alignment", width)
    story += _pdf_table(
        [label, "Applications", f"{counter}s involved",
         "Largest share", "Split across"],
        [[r["name"], r["apps"], r["spread"], _fmt_pct(r["concentration"]),
          _joined([f"{p['name']} ({p['apps']})" for p in r["parts"]])]
         for r in ownership.get("rows") or []],
        [width * 0.22, width * 0.10, width * 0.12, width * 0.12,
         width * 0.44],
        "Nothing to align yet.")
    story += _pdf_note(
        f"A {noun} whose applications sit in several {counter}s has one "
        f"business conversation with several escalation paths behind it. "
        f"Neither reading of the estate shows this on its own, which is why "
        f"it is reported here.", width)

    # ---- technology -------------------------------------------------------
    technology = insights.get("technology") or {}
    story += _pdf_section("Technology standardisation", width)
    story += _pdf_table(
        ["Category", "Distinct technologies", "Used by one application only",
         "Most widely used"],
        [[b["label"], b["distinct"], b["singletons"],
          _joined([f"{e['name']} ({e['count']})" for e in b["top"]], limit=5)]
         for b in technology.get("summary") or []],
        [width * 0.22, width * 0.14, width * 0.18, width * 0.46],
        "No technology recorded against any application.")
    story += _pdf_note(
        "{0}% of applications record a technology stack. A technology used "
        "by exactly one application is not automatically wrong, but it is a "
        "skill, a licence and a patching obligation the estate carries for a "
        "single system - the cheapest rationalisation question there "
        "is.".format(technology.get("documented_pct", 0)), width)

    # ---- confidence -------------------------------------------------------
    coverage = insights.get("coverage") or {}
    story += _pdf_section("Map confidence and record completeness", width)
    story += _pdf_fields([
        ("Resolved connections", coverage.get("links", 0)),
        ("Matched by hostname", "{0} ({1})".format(
            coverage.get("by_host", 0), _fmt_pct(coverage.get("by_host_pct")))),
        ("Inferred from names", "{0} ({1})".format(
            coverage.get("by_name", 0), _fmt_pct(coverage.get("by_name_pct")))),
        ("Hostnames claimed twice", coverage.get("duplicate_hosts", 0)),
    ], width)
    story += _pdf_table(
        ["Field", "Applications missing it", "Share", "Consequence"],
        [[g["label"], g["count"], _fmt_pct(g["pct"]), g["why"]]
         for g in coverage.get("gaps") or []],
        [width * 0.26, width * 0.14, width * 0.10, width * 0.50],
        "Every application record is complete.")
    story += _pdf_note(
        "Every connection on the diagram is either backed by a hostname "
        "recorded on both sides - evidence - or inferred because two names "
        "happened to match. The second kind is usually right and occasionally "
        "embarrassing, so the ratio is stated rather than buried.", width)

    return _pdf_document(story, f"{view} - Architecture Report",
                         pagesize=pagesize)


# ---------------------------------------------------------------------------
# Tower Summary - Excel
#
# Four sheets, in the order the page reads: the headline, the assignment
# grid exactly as it appears on screen, the application-wise view and the
# member-wise view. Built from the SAME report dict team_summary.build()
# hands the page, so a circulated workbook can never quote a different
# number than the screen it came from.
# ---------------------------------------------------------------------------

# Coverage state -> (fill, font), matching the badges the page paints.
COVER_CHIP = {
    "Primary + secondary": ("DCFCE7", "166534"),
    "Primary only":        ("FEF3C7", "92400E"),
    "Secondary only":      ("FEF3C7", "92400E"),
    "Unassigned":          ("FEE2E2", "991B1B"),
}


def _cover_state(row) -> str:
    """The one-word verdict for an application's cover."""
    if row["primary"] and row["secondary"]:
        return "Primary + secondary"
    if row["primary"]:
        return "Primary only"
    if row["secondary"]:
        return "Secondary only"
    return "Unassigned"


def build_tower_summary_workbook(report, generated_by) -> bytes:
    """The Tower Summary - team, applications and the assignment grid."""
    tower = report["tower"]
    cover = report["coverage"]
    counts = report["counts"]
    slots = report["slots"]
    scope = tower.tower_name

    wb = Workbook()

    # --- Sheet 1: Summary -------------------------------------------------
    ws = wb.active
    ws.title = "Summary"
    ws.sheet_view.showGridLines = False
    _autosize(ws, [34, 84])
    row = _title_band(ws, "Tower Summary - {0}".format(scope),
                      "Application Support - team, applications and who "
                      "supports what", 2)
    row = _field(ws, row, "Tower", scope)
    row = _field(ws, row, "Tower Lead", tower.tower_lead or "-")
    row += 1

    row = _section_band(ws, row, "Team", 2)
    row = _field(ws, row, "Team Members", cover["members"])
    row = _field(ws, row, "Members Carrying Applications",
                 cover["members_loaded"])
    row = _field(ws, row, "Assignments Made", cover["assignments"])
    row = _field(ws, row, "Applications per Member (average)",
                 cover["average"])
    row = _field(ws, row, "Heaviest / Lightest",
                 "{0} / {1}".format(cover["heaviest"], cover["lightest"]))
    row += 1

    row = _section_band(ws, row, "Applications", 2)
    row = _field(ws, row, "Total Applications", counts["total"])
    for bc in ("BC1", "BC2", "BC3"):
        fill, font_clr, label = BC_META[bc]
        lc = ws.cell(row=row, column=1, value="{0} - {1}".format(bc, label))
        lc.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        lc.fill = PatternFill("solid", fgColor=BRAND_DK)
        lc.alignment = LEFT_TOP
        lc.border = _BORDER
        vc = ws.cell(row=row, column=2, value=counts["by_bc"].get(bc, 0))
        _chip(vc, fill, font_clr)
        vc.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        ws.row_dimensions[row].height = 20
        row += 1
    row = _field(ws, row, "With a Primary", cover["with_primary"])
    row = _field(ws, row, "With a Secondary", cover["with_secondary"])
    row = _field(ws, row, "Assigned to Somebody", cover["assigned"])
    row += 1

    row = _section_band(ws, row, "Gaps", 2)
    row = _field(ws, row, "No Primary",
                 ", ".join(cover["no_primary"]) or "none")
    row = _field(ws, row, "No Secondary (single point of cover)",
                 ", ".join(cover["no_secondary"]) or "none")
    row = _field(ws, row, "Nobody Assigned",
                 ", ".join(cover["unassigned"]) or "none")
    row = _field(ws, row, "Primary Claimed by More Than One Member",
                 ", ".join(cover["contested"]) or "none")
    row = _field(ws, row, "Members With Nothing Assigned",
                 ", ".join(cover["idle"]) or "none")
    row += 1

    row = _field(ws, row, "Generated",
                 datetime.now().strftime("%d %b %Y %H:%M"))
    _field(ws, row, "Generated by", generated_by or "-")
    _print_setup(ws, orientation="portrait")

    # --- Sheet 2: the assignment grid, as it reads on screen --------------
    ws2 = wb.create_sheet("Assignment Grid")
    ws2.sheet_view.showGridLines = False
    headers = ["Team Member"]
    headers += ["Primary {0}".format(i) for i in range(1, slots["primary"] + 1)]
    headers += ["Secondary {0}".format(i)
                for i in range(1, slots["secondary"] + 1)]
    headers.append("Total")
    ncols = len(headers)
    _autosize(ws2, [30] + [26] * (ncols - 2) + [10])
    row = _title_band(ws2, "Assignment Grid",
                      "Tower: {0} - {1} assignment(s) across {2} member(s)"
                      .format(scope, cover["assignments"], cover["members"]),
                      ncols)
    grid_rows = []
    for line in report["grid"]:
        values = [line["member"]["name"]
                  + (" (lead)" if line["member"]["is_lead"] else "")]
        for kind in ("primary", "secondary"):
            values += [cell["application_name"] for cell in line["cells"][kind]]
        values.append(line["total"])
        grid_rows.append(values)
    row = _table_section(
        ws2, row, "Members and their applications", headers, grid_rows, ncols,
        "This tower has no members yet, so there is nothing to assign.",
        center_cols=(ncols,))
    _print_setup(ws2, repeat_rows="1:2")

    # --- Sheet 3: application -> who supports it --------------------------
    ws3 = wb.create_sheet("By Application")
    ws3.sheet_view.showGridLines = False
    ncols3 = 6
    _autosize(ws3, [34, 8, 24, 38, 38, 20])
    row = _title_band(ws3, "Application - managed by team member",
                      "Tower: {0} - {1} application(s)".format(
                          scope, counts["total"]), ncols3)
    app_rows = []
    for line in report["app_rows"]:
        app = line["application"]
        app_rows.append([
            app.application_name,
            line["bc"],
            categories.category_name(app) or "Uncategorised",
            ", ".join(line["primary"]) or "",
            ", ".join(line["secondary"]) or "",
            _cover_state(line),
        ])
    row = _table_section(
        ws3, row, "Applications",
        ["Application", "BC", "Category", "Primary", "Secondary", "Cover"],
        app_rows, ncols3, "No applications in this tower.",
        center_cols=(2,), chip_col=6, chip_map=COVER_CHIP)
    _print_setup(ws3, repeat_rows="1:2")

    # --- Sheet 4: member -> what they support -----------------------------
    ws4 = wb.create_sheet("By Team Member")
    ws4.sheet_view.showGridLines = False
    ncols4 = 6
    _autosize(ws4, [30, 30, 10, 46, 46, 10])
    row = _title_band(ws4, "Team member - manages application",
                      "Tower: {0} - {1} member(s)".format(
                          scope, cover["members"]), ncols4)
    member_rows = []
    for line in report["member_rows"]:
        member = line["member"]
        member_rows.append([
            member["name"],
            member["email"] or "",
            "Lead" if member["is_lead"] else "Member",
            ", ".join(a.application_name for a in line["primary"]) or "",
            ", ".join(a.application_name for a in line["secondary"]) or "",
            line["total"],
        ])
    row = _table_section(
        ws4, row, "Team members",
        ["Team Member", "Email", "Role", "Primary applications",
         "Secondary applications", "Total"],
        member_rows, ncols4, "This tower has no members yet.",
        center_cols=(3, 6))
    _print_setup(ws4, repeat_rows="1:2")

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()
