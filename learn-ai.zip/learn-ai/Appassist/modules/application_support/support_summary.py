"""
Tower Summary Status - ServiceNow demand and support-workload distribution.

The second half of the tower scorecard. Where quality.py asks "is this tower
DOCUMENTED?", this module asks "is this tower RESOURCED?" - how much
ServiceNow demand its applications actually carry, and whether that demand is
spread sensibly across the people who support them.

WHERE THE NUMBERS COME FROM
---------------------------
Nothing here is typed in by hand. Two joins do all the work:

  1. TOWER -> TICKETS.  A tower records the ServiceNow assignment group(s) it
     answers for (AppSupportTower.tower_group_names, admin-managed, comma
     separated). A ticket in snow_ticket_workload belongs to the tower when
     its `assignment_group` matches one of those names.

  2. TICKET -> APPLICATION.  A ticket belongs to an application when the
     application's name appears in the ticket's `short_description`. The
     match is on normalised text with word boundaries, and where two
     application names both appear the LONGER (more specific) one wins -
     "API Management" beats "API" on a description that mentions both,
     because the longer phrase is the one that was actually typed.

Tickets that match the tower but no application are reported as
UNATTRIBUTED. They are never silently dropped and never spread across the
applications: they are shown as their own line, because a large unattributed
pile is itself the finding (descriptions that do not name the system).

THE WORKLOAD MODEL
------------------
The configured priority and effort weights retain the original model.
Distribution uses total ownership plus backup load, with explicit evidence
qualification. Handover suggestions use a greedy overload-relief heuristic.
The historical specification reference (sample_data/support_workload_distribution_logic.md)
is not shipped in this workspace; this implementation does not claim exact compliance:

  * computeWeight()  - priority term + effort term, effort discounted for
    vendor-supported applications (Section 4).
  * Load Summary     - weight per person, against the team average
    (Section 8.2).
  * rebalance()      - proposals prioritising overload relief, then vendor
    support and lower priority as tie-breakers. No global optimality guarantee.
    Always PROPOSALS. Nothing here changes an ownership record.

THE DISTRIBUTION RULES
----------------------
Weight is only half the question. A team can carry a perfectly even weight
and still have every application resting on one person, so four structural
rules sit alongside the bands and decide the verdict with them:

  1. Applications are spread EQUALLY by count. The fair share is the owned
     applications divided by the support members; the band is what a
     whole-application split allows.
  2. Every owned application has a BACKUP. No system depends on one person.
  3. That backup is a PRIMARY OWNER in their own right - cover is held by
     somebody who runs systems here, not by a name added to fill the field.
  4. Every support member OWNS a set of their own. Nobody is a permanent
     backup only.

A rule either holds or it does not, and a tower that breaks one is never
reported as Balanced. evaluate_distribution_rules() judges them and
propose_coverage_actions() names the assignments that would close them -
handing an application over always leaves the outgoing owner in place as the
backup, so a fix for one rule never breaks another. Rules 1 and 4 are only
enforced when there are enough applications to go round: a tower with four
systems and six people does not fail for arithmetic it cannot change.

Two substitutions are made where App Assist holds the fact under a different
name, and both are stated on the report itself:

  * The spec's per-application `priority` is taken from the application's
    BUSINESS CRITICALITY (BC1 -> P1, BC2 -> P2, BC3 -> P3). That is the
    field this application holds for "how important is this system", and it
    is set deliberately by the support team. The ticket-level ServiceNow
    priorities are reported separately as the P1/P2/P3/P4 mix.
  * The spec's `skills` list does not exist as a record. A person is treated
    as skilled in a technology when they are already on the support team of
    another application in this tower that runs it - derived from the
    Technical Details tab. An application with no recorded stack matches
    everybody, because "we do not know" must never read as "nobody can".

WHAT IS AND IS NOT COUNTED
--------------------------
The people the report balances are the ones named on the applications'
SUPPORT TEAM sections - the primary owners and team members - not the tower's
App Assist access list. Access is not ownership, and only the support team
rows say who actually runs what.

The rules half of this module (everything above the PERSISTENCE banner)
issues no queries and needs no session: it works on plain dicts, so it can be
unit-tested without a database (see tests/test_support_summary.py). Only the
loaders below the banner touch the database.

Python 3.9 compatible on purpose - production runs 3.9.
"""

import math
import re
from datetime import datetime, timedelta

from sqlalchemy import func, or_

from .models import (
    ApplicationDetails, SupportTeam, VendorDetails,
    ApplicationTechStack, TowerMember, TeamRole,
)

# ---------------------------------------------------------------------------
# Configuration - Section 2.5 of the logic specification
# ---------------------------------------------------------------------------

CONFIG = {
    'priority_weight_map': {'P1': 5, 'P2': 4, 'P3': 3, 'P4': 2},
    'priority_coeff': 3.0,
    'incident_effort_points': 1.0,
    'sr_effort_points': 0.4,
    'vendor_support_factor': 0.4,
    'hybrid_support_factor': 0.7,
    'bespoke_support_factor': 1.0,
    'default_new_app_load': 10,
    'bau_reserve_percent': 0.20,
    'overload_threshold_percent': 1.20,
    'churn_penalty': 2.0,
    'buddy_load_factor': 0.2,
    # Applications allowed BEYOND the mathematically fair band before the
    # spread is called uneven. Zero means as equal as whole applications
    # allow: with 5 applications and 2 people the band is 2 to 3, and with
    # 4 and 2 it is exactly 2 each. Raise it to give a tower slack.
    'count_slack': 0,
}

# Trailing window the spec works in: an annual ServiceNow pull carrying the
# last twelve months.
WINDOW_DAYS = 365

# Business criticality -> the spec's application priority. BC1 is the tower's
# own statement that the system is tier one; that is the same judgement the
# spec's priority field carries.
BC_TO_PRIORITY = {'BC1': 'P1', 'BC2': 'P2', 'BC3': 'P3'}

# The ticket priorities the ServiceNow export normalises to.
TICKET_PRIORITIES = ('P1', 'P2', 'P3', 'P4')

SUPPORT_TYPES = ('Vendor', 'Hybrid', 'Bespoke')

# Load bands. Tone names the CSS colour variable, matching the quality
# scorecard's vocabulary so the two tabs read the same way.
LOAD_META = {
    'overloaded':   ('Overloaded', 'badge-critical', 'critical'),
    'balanced':     ('Balanced', 'badge-success', 'success'),
    'underloaded':  ('Under-loaded', 'badge-warning', 'warning'),
    'idle':         ('No workload', 'badge-neutral', 'neutral'),
}

# Distribution verdicts, weakest first when several apply.
VERDICT_META = {
    'unconfigured': ('Not measurable', 'fa-plug-circle-xmark', 'neutral'),
    'no_owners':    ('No ownership recorded', 'fa-user-slash', 'critical'),
    'imbalanced':   ('Imbalanced', 'fa-scale-unbalanced', 'critical'),
    'cover_gaps':   ('Cover gaps', 'fa-user-shield', 'critical'),
    'uneven_count': ('Unevenly spread', 'fa-arrow-down-up-across-line', 'warning'),
    'watch':        ('Watch', 'fa-scale-unbalanced-flip', 'warning'),
    'balanced':     ('Balanced', 'fa-scale-balanced', 'success'),
    'incomplete':   ('Assessment incomplete', 'fa-circle-exclamation', 'warning'),
    'no_workload':  ('Not assessable', 'fa-circle-info', 'neutral'),
}

# How many applications a person holds against the fair share. Separate from
# LOAD_META on purpose: that band answers "how heavy is their work?", this one
# answers "how many systems are they accountable for?", and the two disagree
# often - one busy system can outweigh four quiet ones.
COUNT_META = {
    'over':  ('Above fair share', 'badge-warning', 'warning'),
    'fair':  ('Fair share', 'badge-success', 'success'),
    'under': ('Below fair share', 'badge-info', 'info'),
    'none':  ('Owns nothing', 'badge-critical', 'critical'),
}

# The structural conditions the ownership model must meet, in the order they
# are reported. These are rules, not measurements: each one either holds or
# it does not, and a tower that breaks one is never called Balanced however
# evenly the weights happen to fall.
RULE_META = {
    'equal_spread': (
        'Applications are spread equally',
        'Every support member is accountable for a comparable NUMBER of '
        'applications - within the band a whole-application split of the '
        'fair share allows.'),
    'backup_cover': (
        'Every owned application has a backup',
        'No application depends on one person. A named backup shares the '
        'record so a week of leave does not leave it unsupported.'),
    'backup_is_owner': (
        'Backups are primary owners in their own right',
        'The person covering an application owns applications of their own, '
        'so cover is held by a practising owner rather than a name on a '
        'list.'),
    'everyone_owns': (
        'Every support member owns applications',
        'Nobody sits on support teams as a permanent backup only. Everybody '
        'carries primary accountability for a set of their own.'),
}

SEVERITY_META = {
    'critical': ('Critical', 'badge-critical', 'critical', 'fa-circle-xmark'),
    'warning':  ('Action', 'badge-warning', 'warning', 'fa-triangle-exclamation'),
    'info':     ('Note', 'badge-info', 'info', 'fa-circle-info'),
}


# ---------------------------------------------------------------------------
# Text matching
# ---------------------------------------------------------------------------

_NON_WORD = re.compile(r'[^a-z0-9]+')


def normalise_text(value):
    """Lower-cased, punctuation collapsed to single spaces, padded.

    Padding with a leading and trailing space is what makes a plain `in`
    test a word-boundary test: ' api gateway ' cannot match inside
    'rapid gatewayx'.
    """
    text = _NON_WORD.sub(' ', str(value or '').lower()).strip()
    return ' {0} '.format(text) if text else ' '


def build_name_index(applications):
    """[(padded name, compact name, app id, app name)] longest phrase first.

    Sorted by descending phrase length so the first hit is always the most
    specific one: on "API Management gateway timeout" the entry for
    'API Management' is tested before the entry for 'API'.
    """
    index = []
    for app in applications:
        name = getattr(app, 'application_name', None) or ''
        padded = normalise_text(name)
        if not padded.strip():
            continue
        compact = padded.replace(' ', '')
        index.append((padded, compact, getattr(app, 'id', None), name))
    index.sort(key=lambda row: len(row[0]), reverse=True)
    return index


def match_application(description, name_index):
    """The application id named in this ticket description, or None.

    Two passes, in order of how much they can be trusted:

      1. the application name as a phrase, on word boundaries;
      2. the same name with its spaces removed, against the description with
         its spaces removed - which catches 'AMP2View' written as
         'AMP 2 View'. Restricted to names of five characters or more,
         because a compact three-letter name matches far too much.
    """
    padded = normalise_text(description)
    for phrase, _compact, app_id, _name in name_index:
        if phrase in padded:
            return app_id
    squashed = padded.replace(' ', '')
    if not squashed:
        return None
    for _phrase, compact, app_id, _name in name_index:
        if len(compact) >= 5 and compact in squashed:
            return app_id
    return None


def group_key(value):
    """Assignment-group names compare case- and spacing-insensitively."""
    return ' '.join(str(value or '').split()).lower()


# ---------------------------------------------------------------------------
# Weight - Section 4 of the logic specification
# ---------------------------------------------------------------------------

def support_factor(support_type, config=None):
    cfg = config or CONFIG
    if support_type == 'Vendor':
        return cfg['vendor_support_factor']
    if support_type == 'Hybrid':
        return cfg['hybrid_support_factor']
    return cfg['bespoke_support_factor']


def compute_weight(priority, support_type, incidents, service_requests,
                   is_new=False, config=None):
    """The spec's computeWeight(), returning (weight, effort, priority term).

    Priority and effort are ADDED, not multiplied, so a vendor-supported
    payment gateway that almost never raises a ticket still carries the
    responsibility of being tier one.
    """
    cfg = config or CONFIG
    priority_score = cfg['priority_weight_map'].get(priority, 3)
    priority_term = priority_score * cfg['priority_coeff']
    if is_new:
        effort = float(cfg['default_new_app_load'])
    else:
        effort = ((incidents or 0) * cfg['incident_effort_points']
                  + (service_requests or 0) * cfg['sr_effort_points']
                  ) * support_factor(support_type, cfg)
    weight = max(priority_term + effort, 1.0)
    return round(weight, 1), round(effort, 1), round(priority_term, 1)


def classify_support_type(vendor_rows):
    """'Vendor' / 'Bespoke' / 'Hybrid' from an application's vendor records.

    No vendor recorded reads as Bespoke: with nobody else on the hook, the
    full effort sits with the support team, which is exactly what the
    bespoke factor says.
    """
    rows = list(vendor_rows or [])
    if not rows:
        return 'Bespoke'
    bespoke = sum(1 for row in rows if getattr(row, 'is_bespoke', False))
    if bespoke == len(rows):
        return 'Bespoke'
    if bespoke:
        return 'Hybrid'
    return 'Vendor'


# ---------------------------------------------------------------------------
# Load summary and rebalance - Sections 5.2, 6 and 8 of the specification
# ---------------------------------------------------------------------------

def empty_priority_counts():
    return dict((code, 0) for code in TICKET_PRIORITIES)


def build_member_loads(app_rows, config=None):
    """One row per person named on a support team, heaviest first.

    Primary ownership carries the weight. Being a team member on someone
    else's application carries the buddy share (buddy_load_factor of the
    weight, Section 6) - real, but not day-to-day.
    """
    cfg = config or CONFIG
    members = {}

    def _slot(name):
        key = name.strip().lower()
        if key not in members:
            members[key] = {
                'name': name.strip(), 'owns': [], 'backs_up': [],
                'weight': 0.0, 'buddy_load': 0.0,
                'incidents': 0, 'service_requests': 0,
                'priority_counts': empty_priority_counts(),
            }
        return members[key]

    for row in app_rows:
        owner = row.get('owner')
        if owner:
            slot = _slot(owner)
            slot['owns'].append(row['name'])
            slot['weight'] += row['weight']
            slot['incidents'] += row['incidents']
            slot['service_requests'] += row['service_requests']
            for code in TICKET_PRIORITIES:
                slot['priority_counts'][code] += row['priority_counts'][code]
        unique_team = {}
        for name in row.get('team') or []:
            if name.strip():
                unique_team.setdefault(name.strip().lower(), name.strip())
        for name in unique_team.values():
            if owner and name.strip().lower() == owner.strip().lower():
                continue
            slot = _slot(name)
            slot['backs_up'].append(row['name'])
            slot['buddy_load'] += row['weight'] * cfg['buddy_load_factor']

    rows = list(members.values())
    for row in rows:
        row['weight'] = round(row['weight'], 1)
        row['buddy_load'] = round(row['buddy_load'], 1)
        row['total_load'] = round(row['weight'] + row['buddy_load'], 1)
        row['app_count'] = len(row['owns'])
        row['backup_count'] = len(row['backs_up'])
    rows.sort(key=lambda item: (-item['total_load'], item['name'].lower()))
    return rows


def apply_load_bands(member_rows, config=None):
    """Stamp each member with their share of the team average and a band.

    Returns the balance summary the report headline uses. The bands are the
    spec's: over `overload_threshold_percent` of the average is overloaded,
    under the average DIVIDED by that factor is under-loaded, and the
    stretch between the two is where a team is meant to sit.
    """
    cfg = config or CONFIG
    threshold = cfg['overload_threshold_percent']
    total = sum(row['total_load'] for row in member_rows)
    count = len(member_rows)
    average = (total / count) if count else 0.0

    # Compare against the displayed one-decimal thresholds to avoid contradictory badges.
    ceiling = round(average * threshold, 1)
    floor = round(average / threshold, 1) if threshold else 0.0

    for row in member_rows:
        row['percent_of_average'] = (
            int(round(row['total_load'] / average * 100)) if average else 0)
        if not average:
            row['band'] = 'idle'
        elif row['total_load'] > ceiling + 1e-9:
            row['band'] = 'overloaded'
        elif row['total_load'] < floor - 1e-9:
            row['band'] = 'underloaded'
        else:
            row['band'] = 'balanced'
        label, badge, tone = LOAD_META[row['band']]
        row['band_label'] = label
        row['band_badge'] = badge
        row['band_tone'] = tone
        # Relative margin to the same threshold used by the status band.
        # No person-hours or FTE data exists to infer absolute capacity.
        row['headroom'] = round(ceiling - row['total_load'], 1)

    overloaded = [r for r in member_rows if r['band'] == 'overloaded']
    underloaded = [r for r in member_rows if r['band'] == 'underloaded']
    heaviest = max((r['total_load'] for r in member_rows), default=0.0)
    lightest = min((r['total_load'] for r in member_rows), default=0.0)

    return {
        'members': count,
        'total_weight': round(total, 1),
        'average': round(average, 1),
        'ceiling': round(ceiling, 1),
        'floor': round(floor, 1),
        'threshold_percent': int(round(threshold * 100)),
        'bau_reserve_percent': int(round(cfg['bau_reserve_percent'] * 100)),
        'heaviest': round(heaviest, 1),
        'lightest': round(lightest, 1),
        # How far apart the ends of the team are, as a multiple of the
        # lightest load. One number that answers "is this fair?".
        'spread': round(heaviest / lightest, 2) if lightest else None,
        'overloaded': overloaded,
        'underloaded': underloaded,
    }


def evaluate_distribution_rules(app_rows, member_rows, config=None):
    """Do this tower's ownership records meet the four structural rules?

    The load bands above ask how HEAVY each person's work is. This asks
    whether the ownership model is the shape the tower agreed to:

      1. equal_spread     - applications spread equally by COUNT, not just
                            by weight. The fair share is the owned
                            applications divided by the support members, and
                            the band is what a whole-application split
                            allows: floor to ceiling of that share, widened
                            by `count_slack` where a tower needs the room.
      2. backup_cover     - every owned application names a backup.
      3. backup_is_owner  - that backup is a primary owner somewhere else,
                            so cover is held by a practising owner.
      4. everyone_owns    - nobody is a permanent backup only.

    A rule either holds or it does not. Rules 1 and 4 are measured against
    the support members named on the applications, so a tower with fewer
    applications than people does not fail rule 4 for an arithmetic reason
    it cannot fix - the minimum is only raised to one application each when
    there are enough applications to go round.

    Stamps `count_band`, `is_owner` and `backs_up_without_owning` onto the
    member rows on the way through, and returns the findings.
    """
    cfg = config or CONFIG
    slack = int(cfg.get('count_slack', 0))

    owned_apps = [row for row in app_rows if row.get('owner')]
    owner_keys = set(row['owner'].strip().lower() for row in owned_apps)

    members = len(member_rows)
    total_owned = len(owned_apps)
    fair = (total_owned / float(members)) if members else 0.0
    # Only insist on one application each when there are enough to go round.
    # Without this a tower with fewer applications than people would fail
    # rule 4 for an arithmetic reason it cannot fix.
    minimum = 1 if (members and total_owned >= members) else 0
    # The fair band is what a whole-application split allows - floor to
    # ceiling of the fair share - widened by the configured slack.
    low = max(int(math.floor(fair)) - slack, minimum) if members else 0
    high = (int(math.ceil(fair)) + slack) if members else 0

    over, under, ownerless = [], [], []
    for row in member_rows:
        count = row['app_count']
        row['is_owner'] = count > 0
        row['fair_share'] = round(fair, 1)
        row['count_low'] = low
        row['count_high'] = high
        if not members:
            band = 'fair'
        elif count == 0 and minimum:
            band = 'none'
        elif count > high:
            band = 'over'
        elif count < low:
            band = 'under'
        else:
            band = 'fair'
        row['count_band'] = band
        label, badge, tone = COUNT_META[band]
        row['count_label'] = label
        row['count_badge'] = badge
        row['count_tone'] = tone
        # A permanent backup: named on other people's applications, holding
        # none of their own. Rule 4's offender, and the reason rule 3 fails
        # on the applications they cover.
        row['backs_up_without_owning'] = bool(
            row['backup_count'] and not row['is_owner'])
        if band == 'over':
            over.append(row)
        elif band in ('under', 'none'):
            # Owning nothing is below the band as well as its own finding:
            # the spread panel would otherwise name who is over and nobody
            # who is under, which reads as though the count adds up.
            under.append(row)
        if not row['is_owner']:
            ownerless.append(row)

    counts = [row['app_count'] for row in member_rows]
    heaviest = max(counts) if counts else 0
    lightest = min(counts) if counts else 0

    equal_spread = {
        'key': 'equal_spread',
        'ok': not over and not under,
        'members': members,
        'applications': total_owned,
        'fair_share': round(fair, 1),
        'low': low, 'high': high, 'slack': slack,
        'most': heaviest, 'least': lightest,
        'gap': heaviest - lightest,
        'over': over, 'under': under,
    }

    # Rule 2 and rule 3 are read off the applications, because that is where
    # the risk sits: a system, not a person, is the thing left uncovered.
    no_backup = [row['name'] for row in owned_apps if not row.get('backup')]
    weak_backup = []
    for row in owned_apps:
        backups = row.get('backup') or []
        if not backups:
            continue
        if not any(name.strip().lower() in owner_keys for name in backups):
            weak_backup.append({'application': row['name'],
                                'backups': list(backups)})

    backup_cover = {'key': 'backup_cover', 'ok': not no_backup,
                    'missing': no_backup, 'applications': total_owned}
    backup_is_owner = {'key': 'backup_is_owner', 'ok': not weak_backup,
                       'offenders': weak_backup}
    # Rule 4 only bites when there are enough applications for everybody to
    # hold one. Below that, owning nothing is arithmetic, not a finding.
    everyone_owns = {
        'key': 'everyone_owns',
        'ok': not (ownerless and minimum),
        'enforced': bool(minimum),
        'members': [row['name'] for row in ownerless] if minimum else [],
        # Descriptive, never gated: somebody covering other people's
        # applications while holding none of their own is worth naming even
        # where there are not enough applications for them to own one.
        'backup_only': [row['name'] for row in ownerless
                        if row['backs_up_without_owning']],
    }

    rules = {'equal_spread': equal_spread, 'backup_cover': backup_cover,
             'backup_is_owner': backup_is_owner, 'everyone_owns': everyone_owns}
    for key, rule in rules.items():
        title, statement = RULE_META[key]
        rule['title'] = title
        rule['statement'] = statement
        rule['tone'] = 'success' if rule['ok'] else (
            'warning' if key == 'equal_spread' else 'critical')

    # `assessable` guards the verdict: with no ownership recorded at all the
    # rules are vacuously broken, and saying so would drown the one finding
    # that matters (there are no owners).
    assessable = bool(member_rows and owned_apps)
    broken = [key for key in ('backup_cover', 'backup_is_owner',
                              'everyone_owns', 'equal_spread')
              if not rules[key]['ok']] if assessable else []
    rules['order'] = ['equal_spread', 'backup_cover', 'backup_is_owner',
                      'everyone_owns']
    rules['assessable'] = assessable
    rules['broken'] = broken
    rules['ok'] = assessable and not broken
    rules['cover_broken'] = [key for key in broken if key != 'equal_spread']
    rules['total'] = len(rules['order'])
    # Vacuously true is not met: with nothing owned, every rule passes on an
    # empty set, and "4 of 4" would be the most misleading line on the page.
    rules['met'] = (sum(1 for key in rules['order'] if rules[key]['ok'])
                    if assessable else 0)
    return rules


def has_skill_match(member_row, app_row, skills_by_member):
    """Can this person plausibly take this application on?

    True when the application records no technology (we cannot claim they
    cannot), otherwise when they already support something in this tower
    running one of the same technologies.
    """
    needed = app_row.get('tech') or set()
    if not needed:
        return True
    have = skills_by_member.get(member_row['name'].strip().lower()) or set()
    return bool(needed & have)


def propose_moves(app_rows, member_rows, balance, skills_by_member,
                  config=None):
    """Greedy proposals prioritising overload relief, not a global optimum.

    Swap the primary and backup roles if the receiver is already a buddy;
    otherwise replace the primary owner. This preserves total modelled load.
    Each application can move once; every proposal reduces total excess.
    """
    cfg = config or CONFIG
    if not member_rows or not balance['overloaded']:
        return []
    working = {r['name'].strip().lower(): r['total_load'] for r in member_rows}
    ceiling = round(sum(working.values()) / len(working) * cfg['overload_threshold_percent'], 1)
    moved, moves = set(), []
    while True:
        choices = []
        for index, app in enumerate(app_rows):
            donor = (app.get('owner') or '').strip().lower()
            if index in moved or working.get(donor, 0) <= ceiling + 1e-9:
                continue
            buddies = {n.strip().lower() for n in app.get('team', [])} - {donor}
            for receiver in member_rows:
                target = receiver['name'].strip().lower()
                if target == donor or not has_skill_match(receiver, app, skills_by_member):
                    continue
                delta = app['weight'] * (1 - cfg['buddy_load_factor'] if target in buddies else 1)
                if delta <= 0 or working[target] + delta > ceiling + 1e-9:
                    continue
                relief = min(delta, working[donor] - ceiling)
                resolved = working[donor] - delta <= ceiling + 1e-9
                rank = (not resolved, -relief, app['support_type'] != 'Vendor',
                        -TICKET_PRIORITIES.index(app['priority']) if app['priority'] in TICKET_PRIORITIES else 0,
                        app['weight'], app['name'], receiver['name'])
                choices.append((rank, index, app, donor, target, receiver, delta, target in buddies))
        if not choices:
            break
        _, index, app, donor, target, receiver, delta, swap = min(choices, key=lambda c: c[0])
        before = working[donor]
        working[donor] -= delta
        working[target] += delta
        moved.add(index)
        moves.append({
            'application': app['name'], 'from': app['owner'], 'to': receiver['name'],
            'weight': app['weight'], 'net_transfer': delta, 'priority': app['priority'],
            'support_type': app['support_type'], 'disruption_cost': cfg['churn_penalty'],
            'reason': ('Swap primary and backup roles. ' if swap else
                       'Transfer primary ownership; outgoing owner leaves this support assignment. ')
                      + 'Modelled load: donor {0:.1f} to {1:.1f}; receiver to {2:.1f}; '
                        'ceiling {3:.1f}. Validate skills, availability and handover cover.'.format(
                            before, working[donor], working[target], ceiling),
        })
    return moves


def _key(name):
    return (name or '').strip().lower()


def _plan_state(app_rows, moves=None):
    """Simulated ownership, seeded from the record and any weight moves.

    The coverage plan starts where the overload moves finish, so the two
    tables read as one sequence rather than two proposals fighting over the
    same application. Everything in here is names, never records.
    """
    by_name = {}
    state = []
    for index, row in enumerate(app_rows):
        entry = {
            'index': index,
            'name': row['name'],
            'weight': row['weight'],
            'priority': row['priority'],
            'support_type': row['support_type'],
            'tech': row.get('tech') or set(),
            'owner': _key(row.get('owner')) or None,
            'backups': [_key(n) for n in (row.get('backup') or []) if _key(n)],
        }
        state.append(entry)
        by_name[row['name']] = entry
    for move in (moves or []):
        entry = by_name.get(move['application'])
        if not entry:
            continue
        donor, receiver = _key(move['from']), _key(move['to'])
        entry['backups'] = [n for n in entry['backups'] if n != receiver]
        entry['owner'] = receiver
        # The outgoing owner stays as the backup only where the move was a
        # role swap; propose_moves says so in its reason line.
        if move['reason'].startswith('Swap') and donor:
            entry['backups'].append(donor)
    return state


def propose_coverage_actions(app_rows, member_rows, rules, skills_by_member,
                             moves=None, config=None):
    """Assignments that would put the tower inside the four structural rules.

    Ordered the way the rules are: even the application COUNT out first,
    because who owns what decides who is eligible to back anybody up, then
    fill the missing backups, then replace the cover that is not an owner.

    Two conventions make the plan safe to hand to a team:

      * when ownership moves, the outgoing owner STAYS as the backup. The
        handover never creates a new single point of cover, and the receiver
        gets a colleague who already knows the system.
      * a receiver who already backs the application up is a promotion, not
        a handover - the two simply swap roles.

    Proposals only. Nothing here writes to a record, and every one needs the
    named people to agree before it is real.
    """
    if not member_rows or not app_rows or not rules.get('assessable'):
        return []

    names = dict((_key(row['name']), row['name']) for row in member_rows)
    skill_rows = dict((_key(row['name']), row) for row in member_rows)
    state = _plan_state(app_rows, moves)
    owned = [entry for entry in state if entry['owner']]
    if not owned:
        return []

    spread = rules['equal_spread']
    low, high = spread['low'], spread['high']
    counts = dict((key, 0) for key in names)
    backup_counts = dict((key, 0) for key in names)
    for entry in owned:
        counts[entry['owner']] = counts.get(entry['owner'], 0) + 1
        for name in entry['backups']:
            backup_counts[name] = backup_counts.get(name, 0) + 1

    def _fits(key, entry):
        row = skill_rows.get(key)
        return bool(row) and has_skill_match(row, entry, skills_by_member)

    actions, moved = [], set()

    def _pick_app(donor, receiver):
        """(application to hand over, are the skills evidenced?).

        A skill match is preferred, never required. Most people in this
        estate have no recorded technology at all, and treating that silence
        as "cannot" would leave a broken rule with no proposal against it -
        the same reading the module refuses to make of an application with
        no recorded stack. Where the match is not evidenced the proposal
        says so, and the reader decides.
        """
        options = [e for e in owned
                   if e['owner'] == donor and e['index'] not in moved]
        if not options:
            return None, False
        skilled = [e for e in options if _fits(receiver, e)]
        verified = bool(skilled)
        return min(skilled or options, key=lambda e: (
            receiver not in e['backups'],        # already backs it up = free
            e['support_type'] != 'Vendor',       # a vendor carries the depth
            e['weight'], e['name'])), verified

    def _hand_over(donor, receiver, entry, note, verified):
        swap = receiver in entry['backups']
        entry['backups'] = [n for n in entry['backups'] if n != receiver]
        if swap:
            backup_counts[receiver] = max(backup_counts.get(receiver, 1) - 1, 0)
        if donor and donor not in entry['backups']:
            entry['backups'].append(donor)
            backup_counts[donor] = backup_counts.get(donor, 0) + 1
        entry['owner'] = receiver
        counts[donor] -= 1
        counts[receiver] = counts.get(receiver, 0) + 1
        moved.add(entry['index'])
        actions.append({
            'kind': 'ownership', 'rule': 'equal_spread',
            'application': entry['name'],
            'from': names.get(donor, donor), 'to': names[receiver],
            'weight': entry['weight'], 'priority': entry['priority'],
            'support_type': entry['support_type'],
            'reason': '{0} {1} then owns {2}, {3} owns {4}. {5}{6}'.format(
                note, names[receiver], counts[receiver],
                names.get(donor, donor), counts[donor],
                ('They already back this application up, so the two simply '
                 'swap roles.' if swap else
                 'The outgoing owner stays on as the backup, so the handover '
                 'creates no new single point of cover.'),
                '' if verified else
                ' No recorded technology overlap with what they already '
                'support: confirm the skills before agreeing this one.'),
        })

    # ---- rules 1 and 4: even the count out -------------------------------
    # Receiver-driven: start from whoever is short, because that is the rule
    # being broken. Capped by the application count - each one moves once.
    for _ in range(len(state) + 1):
        needy = sorted((k for k in names if counts.get(k, 0) < low),
                       key=lambda k: (counts.get(k, 0), names[k].lower()))
        if not needy:
            break
        placed = False
        for receiver in needy:
            donors = sorted(
                (k for k in names
                 if counts.get(k, 0) >= low + 1
                 and counts.get(k, 0) > counts.get(receiver, 0) + 1),
                key=lambda k: (-counts.get(k, 0), names[k].lower()))
            for donor in donors:
                entry, verified = _pick_app(donor, receiver)
                if entry is None:
                    continue
                _hand_over(
                    donor, receiver, entry,
                    ('{0} owns nothing, and every support member is meant to '
                     'be the primary owner of a set of their own.'.format(
                         names[receiver])
                     if counts.get(receiver, 0) == 0 else
                     'Evening the spread towards {0} application(s) each.'
                     .format(low)), verified)
                placed = True
                break
            if placed:
                break
        if not placed:
            break

    # ---- rule 1, the other end: nobody carrying above the fair band ------
    for _ in range(len(state) + 1):
        donors = sorted((k for k in names if counts.get(k, 0) > high),
                        key=lambda k: (-counts.get(k, 0), names[k].lower()))
        if not donors:
            break
        placed = False
        for donor in donors:
            receivers = sorted(
                (k for k in names
                 if k != donor and counts.get(k, 0) + 1 <= high
                 and counts.get(k, 0) + 1 < counts.get(donor, 0)),
                key=lambda k: (counts.get(k, 0), names[k].lower()))
            for receiver in receivers:
                entry, verified = _pick_app(donor, receiver)
                if entry is None:
                    continue
                _hand_over(
                    donor, receiver, entry,
                    '{0} holds {1} applications against a fair share of {2}.'
                    .format(names[donor], counts[donor],
                            spread['fair_share']), verified)
                placed = True
                break
            if placed:
                break
        if not placed:
            break

    # ---- rules 2 and 3: cover held by a practising owner -----------------
    def _pick_backup(entry):
        """The lightest-loaded OWNER who can plausibly cover this one."""
        pool = [k for k in names
                if k != entry['owner'] and counts.get(k, 0) > 0
                and k not in entry['backups']]
        if not pool:
            return None, False
        skilled = [k for k in pool if _fits(k, entry)]
        verified = bool(skilled)
        pool = skilled or pool
        return min(pool, key=lambda k: (backup_counts.get(k, 0),
                                        names[k].lower())), verified

    for entry in state:
        if not entry['owner']:
            continue
        if any(counts.get(name, 0) > 0 for name in entry['backups']):
            continue                      # already covered by a real owner
        choice, verified = _pick_backup(entry)
        if choice is None:
            continue
        if entry['backups']:
            rule = 'backup_is_owner'
            note = ('{0} is backed up by {1}, who owns no application of '
                    'their own.'.format(
                        entry['name'],
                        ', '.join(names.get(n, n) for n in entry['backups'])))
        else:
            rule = 'backup_cover'
            note = '{0} names one person and nobody else.'.format(entry['name'])
        entry['backups'].append(choice)
        backup_counts[choice] = backup_counts.get(choice, 0) + 1
        actions.append({
            'kind': 'backup', 'rule': rule, 'application': entry['name'],
            'from': names.get(entry['owner'], entry['owner']),
            'to': names[choice], 'weight': entry['weight'],
            'priority': entry['priority'],
            'support_type': entry['support_type'],
            'reason': ('{0} Add {1} as backup - a primary owner of {2} '
                       'application(s) in their own right, carrying {3} '
                       'backup assignment(s) before this one.{4}').format(
                           note, names[choice], counts.get(choice, 0),
                           backup_counts[choice] - 1,
                           '' if verified else
                           ' No recorded technology overlap with what they '
                           'already support: confirm the skills before '
                           'relying on this cover.'),
        })

    return actions


def distribution_verdict(app_rows, member_rows, balance, groups_configured,
                         evidence_issues=None, rules=None):
    """One call on whether the tower's work is spread sensibly.

    Weight first, then shape. A tower is only Balanced when the loads sit
    inside the band AND the four structural rules hold: a team can carry a
    perfectly even weight and still have every application resting on one
    person, and that is not a balanced tower.
    """
    if not groups_configured:
        key = 'unconfigured'
        headline = 'No ServiceNow assignment group is mapped to this tower.'
        detail = ('Add the tower group name(s) on the tower record. Until '
                  'then there is no ticket data to distribute and this tab '
                  'can only report what is documented.')
    elif not app_rows:
        key = 'no_workload'
        headline = 'No active applications are available to assess.'
        detail = 'Register applications and their support ownership before assessing distribution.'
    elif not member_rows or not any(row.get('owner') for row in app_rows):
        key = 'no_owners'
        headline = 'No primary ownership is recorded for these applications.'
        detail = ('No application in this tower names a primary owner, '
                  'so the workload cannot be attributed to anyone. Fill in '
                  'the Support Team section on each application record.')
    elif any(not row.get('owner') for row in app_rows) or evidence_issues:
        key = 'incomplete'
        headline = 'Resolve ownership or ticket evidence gaps before accepting the assessment.'
        detail = ' '.join(evidence_issues or [])
        missing = sum(1 for row in app_rows if not row.get('owner'))
        if missing:
            detail += ' {0} application(s) have missing or ambiguous primary ownership.'.format(missing)
        detail += ' Individual bands describe recorded load only; they do not establish staffing capacity.'
    elif not balance['total_weight'] or len(member_rows) < 2:
        key = 'no_workload'
        headline = 'Insufficient workload or team size for a distribution comparison.'
        detail = 'At least two support members and positive modelled load are required.'
    elif balance['overloaded']:
        key = 'imbalanced'
        names = ', '.join(row['name'] for row in balance['overloaded'])
        headline = '{0} carrying more than {1}% of the team average.'.format(
            ('{0} people are'.format(len(balance['overloaded']))
             if len(balance['overloaded']) > 1 else '1 person is'),
            balance['threshold_percent'])
        detail = ('{0} above the ceiling of {1} weight units. Proposed moves '
                  'are listed below.'.format(names, balance['ceiling']))
    elif rules and rules.get('cover_broken'):
        key = 'cover_gaps'
        cover = rules['backup_cover']
        weak = rules['backup_is_owner']
        alone = rules['everyone_owns']
        parts = []
        if not cover['ok']:
            parts.append('{0} application(s) name one person and nobody '
                         'else'.format(len(cover['missing'])))
        if not weak['ok']:
            parts.append('{0} application(s) are backed up by somebody who '
                         'owns nothing themselves'.format(
                             len(weak['offenders'])))
        if not alone['ok']:
            parts.append('{0} support member(s) own no application at '
                         'all'.format(len(alone['members'])))
        headline = ('The load is inside the band, but the cover model is '
                    'not met.')
        detail = ('{0}. Every application needs a backup, and that backup '
                  'must be a primary owner in their own right. The coverage '
                  'plan below names the assignments that would close '
                  'this.'.format('; '.join(parts).capitalize()))
    elif rules and not rules['equal_spread']['ok']:
        key = 'uneven_count'
        spread = rules['equal_spread']
        headline = ('Applications are not spread equally across the support '
                    'team.')
        detail = ('{0} application(s) across {1} member(s) is a fair share of '
                  '{2} each; the team runs from {3} to {4}. Cover and weight '
                  'are fine - the accountability is not evenly '
                  'shared.'.format(spread['applications'], spread['members'],
                                   spread['fair_share'], spread['least'],
                                   spread['most']))
    elif balance['underloaded']:
        key = 'watch'
        names = ', '.join(row['name'] for row in balance['underloaded'])
        headline = 'Nobody is overloaded, but the load is uneven.'
        detail = ('{0} below the relative floor of {1} weight units. '
                  'Confirm availability and skills before assigning additional work.'
                  .format(names, balance['floor']))
    else:
        key = 'balanced'
        headline = 'Recorded workload is within the relative balance band.'
        detail = ('Every support member sits between {0} and {1} weight units, against '
                  'a team average of {2}.'.format(
                      balance['floor'], balance['ceiling'],
                      balance['average']))
        if rules and rules.get('ok'):
            detail += (' Applications are spread evenly, every one has a '
                       'backup, and every backup is a primary owner in '
                       'their own right.')

    unowned = [row['name'] for row in app_rows if not row.get('owner')]
    label, icon, tone = VERDICT_META[key]
    return {'key': key, 'label': label, 'icon': icon, 'tone': tone,
            'headline': headline, 'detail': detail, 'unowned': unowned}


def _listing(names, limit=6):
    """'A, B, C and 4 more' - a readable list that never runs away."""
    shown = ', '.join(names[:limit])
    if len(names) > limit:
        shown += ' and {0} more'.format(len(names) - limit)
    return shown


# ---------------------------------------------------------------------------
# Recommendations
# ---------------------------------------------------------------------------

def _rule_findings(app_rows, member_rows, rules, cfg):
    """One finding per broken structural rule, worst consequence first.

    The rules are conditions, not measurements, so each finding states the
    rule, names who or what breaks it, and says what would satisfy it. A
    rule that holds is not reported here - the compliance panel on the
    report already shows it as met.
    """
    out = []
    if not rules or not rules.get('assessable'):
        return out

    cover = rules['backup_cover']
    if not cover['ok']:
        names = cover['missing']
        out.append({
            'severity': 'critical', 'area': 'Backup cover',
            'title': '{0} application{1} with no backup resource'.format(
                len(names), '' if len(names) == 1 else 's'),
            'detail': ('{0} name{1} a primary owner and nobody else. Every '
                       'application must have a backup: a single week of '
                       'leave leaves {2} unsupported, and the knowledge sits '
                       'with one person.'.format(
                           _listing(names), 's' if len(names) == 1 else '',
                           'it' if len(names) == 1 else 'them')),
            'action': ('Add a backup on the Support Team section of {0}. The '
                       'model allocates {1}% of the application weight to '
                       'each backup; confirm the actual effort and their '
                       'availability.'.format(
                           'that record' if len(names) == 1
                           else 'each of those records',
                           int(round(cfg['buddy_load_factor'] * 100)))),
        })

    weak = rules['backup_is_owner']
    if not weak['ok']:
        offenders = weak['offenders']
        out.append({
            'severity': 'critical', 'area': 'Backup cover',
            'title': '{0} application{1} backed up by somebody who owns '
                     'nothing'.format(len(offenders),
                                      '' if len(offenders) == 1 else 's'),
            'detail': ('{0}. A backup is expected to be a primary owner in '
                       'their own right - somebody who runs systems here, '
                       'not a name added to make the record look '
                       'covered.'.format(_listing(
                           ['{0} (backed up by {1})'.format(
                               row['application'], ', '.join(row['backups']))
                            for row in offenders], limit=4))),
            'action': ('Either give the named backup primary ownership of a '
                       'set of applications, or add a backup who already '
                       'owns some.'),
        })

    alone = rules['everyone_owns']
    if not alone['ok']:
        names = alone['members']
        out.append({
            'severity': 'warning', 'area': 'Ownership spread',
            'title': '{0} support member{1} own{2} no application'.format(
                len(names), '' if len(names) == 1 else 's',
                's' if len(names) == 1 else ''),
            'detail': ('{0} appear{1} on support teams but hold{1} no primary '
                       'ownership. Every member is meant to own a set of '
                       'their own, so that the cover they provide is backed '
                       'by systems they run.'.format(
                           _listing(names), 's' if len(names) == 1 else '')),
            'action': ('Transfer primary ownership of an agreed set of '
                       'applications to {0}, or remove {1} from the support '
                       'teams if the role is not real.'.format(
                           'them' if len(names) > 1 else names[0],
                           'them')),
        })

    spread = rules['equal_spread']
    if not spread['ok']:
        over = ', '.join('{0} ({1})'.format(row['name'], row['app_count'])
                         for row in spread['over']) or 'nobody'
        under = ', '.join('{0} ({1})'.format(row['name'], row['app_count'])
                          for row in spread['under']) or 'nobody'
        out.append({
            'severity': 'warning', 'area': 'Equal spread',
            'title': 'Applications are not spread equally across the team',
            'detail': ('{0} application(s) across {1} member(s) is a fair '
                       'share of {2} each, so the agreed band is {3} to {4}. '
                       'Above it: {5}. Below it: {6}.'.format(
                           spread['applications'], spread['members'],
                           spread['fair_share'], spread['low'],
                           spread['high'], over, under)),
            'action': ('Move ownership from the members above the band to '
                       'those below it - the coverage plan proposes the '
                       'specific handovers. Weight is checked separately: '
                       'an even COUNT does not by itself mean an even load.'),
        })

    return out


def build_recommendations(app_rows, member_rows, balance, moves, verdict,
                          unattributed, groups_configured, config=None,
                          rules=None, coverage_actions=None):
    """Ordered, actionable findings. Severity: critical / warning / info."""
    cfg = config or CONFIG
    out = []

    if not groups_configured:
        out.append({
            'severity': 'critical', 'area': 'Configuration',
            'title': 'Map this tower to its ServiceNow assignment group(s)',
            'detail': ('Every figure on this tab comes from the tickets whose '
                       'assignment group matches the tower. With none set the '
                       'ticket counts are zero because nothing has been '
                       'matched - not because nothing was raised.'),
            'action': 'Edit the tower and fill in Tower Group Names.',
        })
        return _finalise(out, balance, cfg)

    unowned = verdict['unowned']
    if verdict['key'] in ('incomplete', 'no_workload'):
        out.append({
            'severity': 'warning', 'area': 'Assessment confidence',
            'title': verdict['label'], 'detail': verdict['detail'],
            'action': 'Resolve the evidence gaps and review the assessment before reallocating ownership.',
        })
    if unowned:
        out.append({
            'severity': 'critical', 'area': 'Ownership',
            'title': '{0} application{1} with no primary owner'.format(
                len(unowned), '' if len(unowned) == 1 else 's'),
            'detail': ('Work on {0} cannot be attributed to anybody, so it is '
                       'invisible in the distribution below and lands on '
                       'whoever happens to pick it up.'.format(
                           _listing(unowned))),
            'action': ('Name a Primary Owner on the Support Team section of '
                       'each of those application records.'),
        })

    # ---- the four structural rules ---------------------------------------
    # Reported before the weight moves because they decide the SHAPE of the
    # model: who owns what settles who is eligible to cover anybody.
    out.extend(_rule_findings(app_rows, member_rows, rules, cfg))

    for action in (coverage_actions or []):
        if action['kind'] == 'ownership':
            title = 'Hand {0} over from {1} to {2}'.format(
                action['application'], action['from'], action['to'])
            act = ('Proposal only, and it assumes the rebalance moves below '
                   'are applied first. Needs {0}\'s agreement and a '
                   'knowledge handover; the outgoing owner stays on as the '
                   'backup.'.format(action['to']))
        else:
            title = 'Name {0} as the backup for {1}'.format(
                action['to'], action['application'])
            act = ('Proposal only, and it assumes the rebalance moves below '
                   'are applied first. Add {0} to the Support Team section '
                   'of {1}, and confirm availability and a real handover of '
                   'knowledge - not just the record.'.format(
                       action['to'], action['application']))
        out.append({
            'severity': 'warning',
            'area': 'Coverage plan' if action['kind'] == 'backup'
                    else 'Equal spread',
            'title': title, 'detail': action['reason'], 'action': act,
        })

    for move in moves:
        out.append({
            'severity': 'warning', 'area': 'Rebalance',
            'title': 'Move {0} from {1} to {2}'.format(
                move['application'], move['from'], move['to']),
            'detail': move['reason'],
            'action': ('Proposal only - {0} weight units, disruption cost '
                       '{1}. Needs {2}\'s agreement and a knowledge handover '
                       'before the record changes.'.format(
                           move['weight'], move['disruption_cost'],
                           move['to'])),
        })

    projected = {r['name'].strip().lower(): r['total_load'] for r in member_rows}
    for move in moves:
        projected[move['from'].strip().lower()] -= move['net_transfer']
        projected[move['to'].strip().lower()] += move['net_transfer']
    exact_ceiling = round(sum(projected.values()) / len(projected)
                          * cfg['overload_threshold_percent'], 1) if projected else 0
    remaining = [r['name'] for r in member_rows
                 if projected[r['name'].strip().lower()] > exact_ceiling + 1e-9]
    if remaining:
        stuck = ', '.join(remaining)
        out.append({
            'severity': 'critical', 'area': 'Capacity',
            'title': 'Residual overload requires review',
            'detail': ('{0} sits above the ceiling, but no colleague can '
                       'absorb an application without going over it '
                       'themselves under the current skill assumptions. '
                       'Review skills, shared cover and demand before deciding staffing.'.format(stuck)),
            'action': ('Validate available hours, skills and shared cover; consider '
                       'demand reduction or additional capacity if justified.'),
        })

    if balance['spread'] and balance['spread'] >= 2 and member_rows:
        out.append({
            'severity': 'warning', 'area': 'Fairness',
            'title': 'The heaviest load is {0}x the lightest'.format(
                balance['spread']),
            'detail': ('{0} carries {1} weight units against {2} at the other '
                       'end of the team.'.format(
                           member_rows[0]['name'], balance['heaviest'],
                           balance['lightest'])),
            'action': ('Even it out at the next annual refresh - the model '
                       'prioritises overload relief with targeted moves rather than a full '
                       'reshuffle.'),
        })

    matched = sum(row['tickets'] for row in app_rows)
    if unattributed['tickets']:
        share = int(round(unattributed['tickets'] * 100.0
                          / max(matched + unattributed['tickets'], 1)))
        out.append({
            'severity': 'warning' if share >= 20 else 'info',
            'area': 'Data quality',
            'title': "{0}% of this tower's tickets name no application".format(
                share),
            'detail': ('{0} ticket{1} matched the assignment group but no '
                       'application name appears in the short description, so '
                       'they carry no weight in the distribution '
                       'below.'.format(unattributed['tickets'],
                                       '' if unattributed['tickets'] == 1
                                       else 's')),
            'action': ('Either the short descriptions do not name the system, '
                       'or the application is registered here under a '
                       'different name than the one used in ServiceNow. '
                       'Align the two.'),
        })

    heavy = [row for row in app_rows
             if balance['ceiling'] and row['weight'] >= balance['ceiling']]
    if heavy:
        top = sorted(heavy, key=lambda row: -row['weight'])[0]
        out.append({
            'severity': 'info', 'area': 'Concentration',
            'title': '{0} meets or exceeds the relative load ceiling'.format(top['name']),
            'detail': ('At {0} weight units it exceeds the {1} unit ceiling '
                       'for one person, so its owner cannot hold anything '
                       'else and stay inside the threshold.'.format(
                           top['weight'], balance['ceiling'])),
            'action': ('Review demand and backup cover while retaining one accountable '
                       'primary owner. Confirm actual effort before changing staffing.'),
        })

    if not out:
        out.append({
            'severity': 'info', 'area': 'Distribution',
            'title': 'No action needed',
            'detail': verdict['detail'],
            'action': ('Re-run after the next annual ServiceNow refresh - the '
                       'weights only change when the data does.'),
        })

    return _finalise(out, balance, cfg)


def _finalise(rows, balance, cfg):
    """Sort by severity and append the reading note the numbers need."""
    order = {'critical': 0, 'warning': 1, 'info': 2}
    rows.sort(key=lambda row: order.get(row['severity'], 3))
    rows.append({
        'severity': 'info', 'area': 'Model',
        'title': 'Weights exclude BAU work',
        'detail': ('Bands compare primary ownership plus buddy load against the team average. '
                   'Headroom is the margin to that relative ceiling, not available hours. '
                   'The {0}% BAU planning assumption is not deducted: person-level capacity, '
                   'availability and BAU effort are not recorded. Balanced does not establish '
                   'that the team is adequately staffed.'.format(
                       int(round(cfg['bau_reserve_percent'] * 100)))),
        'action': 'No action - stated so the numbers are read correctly.',
    })
    for row in rows:
        label, badge, tone, icon = SEVERITY_META[row['severity']]
        row['severity_label'] = label
        row['badge'] = badge
        row['tone'] = tone
        row['icon'] = icon
    return rows


# ===========================================================================
# PERSISTENCE - everything below here queries the database
# ===========================================================================

def window_start(days=WINDOW_DAYS):
    return datetime.now() - timedelta(days=days)


def load_tickets(db_session, group_names, days=WINDOW_DAYS):
    """The tower's ServiceNow tickets in the trailing window.

    Matching is on the normalised assignment group, done in Python rather
    than in SQL: the stored value carries whatever spacing and casing the
    export had, and a LIKE would not survive that.

    A ticket with no `opened_at` is KEPT. The column is only populated when
    the export carried an opened date; dropping those rows would quietly
    shrink the counts for an export that simply did not include the column.
    """
    from modules.service_now_analysis.models import SnowTicketWorkload

    wanted = set(group_key(name) for name in group_names)
    if not wanted:
        return []
    cutoff = window_start(days)
    rows = (db_session.query(SnowTicketWorkload)
            .filter(SnowTicketWorkload.assignment_group.isnot(None),
                    or_(SnowTicketWorkload.opened_at >= cutoff,
                        SnowTicketWorkload.opened_at.is_(None)))
            .all())
    return [row for row in rows if group_key(row.assignment_group) in wanted]


def _related(db_session, app_ids):
    """Support team, vendors and tech stack for a set of applications."""
    teams, vendors, tech = {}, {}, {}
    if not app_ids:
        return teams, vendors, tech
    for row in (db_session.query(SupportTeam)
                .filter(SupportTeam.application_id.in_(app_ids)).all()):
        teams.setdefault(row.application_id, []).append(row)
    for row in (db_session.query(VendorDetails)
                .filter(VendorDetails.application_id.in_(app_ids)).all()):
        vendors.setdefault(row.application_id, []).append(row)
    for row in (db_session.query(ApplicationTechStack)
                .filter(ApplicationTechStack.application_id.in_(app_ids))
                .all()):
        name = (row.item_name or '').strip().lower()
        if name:
            tech.setdefault(row.application_id, set()).add(name)
    return teams, vendors, tech


def _role_value(role):
    """TeamRole enum or raw string -> the comparable value."""
    return getattr(role, 'value', role)


def build_tower_report(db_session, tower, applications=None,
                       days=WINDOW_DAYS, config=None):
    """The whole Tower Summary Status report for one tower.

    The tab headline and the full report are both rendered from this single
    dict, so the summary card can never disagree with the report it links
    to - the same rule the documentation quality screens follow.
    """
    cfg = config or CONFIG
    group_names = tower.group_name_list()

    if applications is None:
        applications = (db_session.query(ApplicationDetails)
                        .filter_by(tower_id=tower.id, is_active=True)
                        .order_by(ApplicationDetails.application_name).all())
    app_ids = [app.id for app in applications]
    teams, vendors, tech = _related(db_session, app_ids)

    tickets = load_tickets(db_session, group_names, days)
    name_index = build_name_index(applications)

    # ---- attribute every ticket -----------------------------------------
    per_app = dict((app_id, {'incidents': 0, 'service_requests': 0,
                             'other': 0,
                             'priority_counts': empty_priority_counts(),
                             'assignees': {}}) for app_id in app_ids)
    unattributed = {'tickets': 0, 'incidents': 0, 'service_requests': 0,
                    'other': 0, 'priority_counts': empty_priority_counts(),
                    'samples': []}
    handled = {}
    opened_dates = []

    for ticket in tickets:
        app_id = match_application(ticket.short_description, name_index)
        bucket = per_app.get(app_id) if app_id is not None else None
        target = bucket if bucket is not None else unattributed
        if ticket.ticket_type == 'incident':
            target['incidents'] += 1
        elif ticket.ticket_type == 'service_request':
            target['service_requests'] += 1
        else:
            target['other'] += 1
        if bucket is None:
            unattributed['tickets'] += 1
            if len(unattributed['samples']) < 8 and ticket.short_description:
                unattributed['samples'].append(ticket.short_description)
        if ticket.priority in TICKET_PRIORITIES:
            target['priority_counts'][ticket.priority] += 1
        if ticket.opened_at:
            opened_dates.append(ticket.opened_at)
        assignee = (ticket.assigned_to or '').strip()
        if assignee:
            slot = handled.setdefault(
                assignee.lower(),
                {'name': assignee, 'tickets': 0, 'incidents': 0,
                 'service_requests': 0})
            slot['tickets'] += 1
            if ticket.ticket_type == 'incident':
                slot['incidents'] += 1
            elif ticket.ticket_type == 'service_request':
                slot['service_requests'] += 1
            if bucket is not None:
                bucket['assignees'][assignee] = \
                    bucket['assignees'].get(assignee, 0) + 1

    # ---- one row per application ----------------------------------------
    start = window_start(days)
    app_rows = []
    for app in applications:
        stats = per_app[app.id]
        criticality = getattr(app.business_criticality, 'value',
                              app.business_criticality) or 'BC3'
        priority = BC_TO_PRIORITY.get(criticality, 'P3')
        support_type = classify_support_type(vendors.get(app.id))
        owner = None
        primary_names = {}
        team_names = []
        for row in (teams.get(app.id) or []):
            name = (row.member_name or '').strip()
            if not name:
                continue
            if _role_value(row.role) == TeamRole.PRIMARY_OWNER.value:
                primary_names[name.lower()] = name
            team_names.append(name)
        owner = next(iter(primary_names.values())) if len(primary_names) == 1 else None
        team_names = list(dict((n.lower(), n) for n in team_names).values())
        backup = [name for name in team_names
                  if not owner or name.lower() != owner.lower()]
        total = stats['incidents'] + stats['service_requests'] + stats['other']
        created = getattr(app, 'created_at', None)
        # A record registered inside the window with no ticket history yet
        # gets the spec's flat new-application estimate rather than a weight
        # of nearly nothing - see Section 4.
        is_new = bool(created and created >= start and total == 0)
        weight, effort, priority_term = compute_weight(
            priority, support_type, stats['incidents'],
            stats['service_requests'], is_new, cfg)
        app_rows.append({
            'id': app.id,
            'app': app,
            'name': app.application_name,
            'criticality': criticality,
            'priority': priority,
            'support_type': support_type,
            'vendors': [v.vendor_name for v in (vendors.get(app.id) or [])],
            'owner': owner,
            'team': team_names,
            'backup': backup,
            'tech': tech.get(app.id) or set(),
            'incidents': stats['incidents'],
            'service_requests': stats['service_requests'],
            'other': stats['other'],
            'tickets': total,
            'priority_counts': stats['priority_counts'],
            'assignees': sorted(stats['assignees'].items(),
                                key=lambda kv: -kv[1]),
            'weight': weight,
            'effort': effort,
            'priority_term': priority_term,
            'is_new': is_new,
        })
    app_rows.sort(key=lambda row: (-row['weight'], row['name'].lower()))

    # ---- who is skilled in what, from who already supports what ---------
    skills_by_member = {}
    for row in app_rows:
        for name in row['team']:
            skills_by_member.setdefault(
                name.strip().lower(), set()).update(row['tech'])

    member_rows = build_member_loads(app_rows, cfg)
    for row in member_rows:
        actual = handled.get(row['name'].strip().lower())
        row['tickets_handled'] = actual['tickets'] if actual else 0
        row['handled_incidents'] = actual['incidents'] if actual else 0
        row['handled_service_requests'] = (actual['service_requests']
                                           if actual else 0)

    balance = apply_load_bands(member_rows, cfg)
    evidence_issues = []
    if not tickets:
        evidence_issues.append('No ServiceNow tickets were found for the reporting window.')
    if unattributed['tickets']:
        evidence_issues.append('{0} ticket(s) could not be attributed to an application.'.format(unattributed['tickets']))
    if any(not t.opened_at for t in tickets):
        evidence_issues.append('Undated tickets are included; the reporting window is not fully verified.')
    # The structural rules are evaluated BEFORE the verdict, because they
    # can overturn it: an evenly weighted team whose applications all rest on
    # one person each is not a balanced tower.
    rules = evaluate_distribution_rules(app_rows, member_rows, cfg)
    verdict = distribution_verdict(app_rows, member_rows, balance,
                                   bool(group_names), evidence_issues, rules)
    moves = propose_moves(app_rows, member_rows, balance, skills_by_member,
                          cfg)
    # The coverage plan picks up where the overload moves finish, so the two
    # tables are one sequence rather than two proposals for the same record.
    coverage_actions = propose_coverage_actions(
        app_rows, member_rows, rules, skills_by_member, moves, cfg)
    recommendations = build_recommendations(
        app_rows, member_rows, balance, moves, verdict, unattributed,
        bool(group_names), cfg, rules, coverage_actions)

    # People who worked this tower's tickets but sit on no support team -
    # the shadow workforce a load summary built on ownership alone misses.
    known = set(row['name'].strip().lower() for row in member_rows)
    unlisted = sorted((row for key, row in handled.items() if key not in known),
                      key=lambda row: -row['tickets'])

    totals = {
        'incidents': (sum(row['incidents'] for row in app_rows)
                      + unattributed['incidents']),
        'service_requests': (sum(row['service_requests'] for row in app_rows)
                             + unattributed['service_requests']),
        'tickets': (sum(row['tickets'] for row in app_rows)
                    + unattributed['tickets']),
        'priority_counts': empty_priority_counts(),
        'applications': len(app_rows),
        'team_members': len(member_rows),
        'owned_applications': sum(1 for row in app_rows if row['owner']),
        'weight': balance['total_weight'],
    }
    for row in app_rows:
        for code in TICKET_PRIORITIES:
            totals['priority_counts'][code] += row['priority_counts'][code]
    for code in TICKET_PRIORITIES:
        totals['priority_counts'][code] += \
            unattributed['priority_counts'][code]

    access_members = (db_session.query(func.count(TowerMember.id))
                      .filter_by(tower_id=tower.id).scalar() or 0)

    return {
        'tower': tower,
        'group_names': group_names,
        'groups_configured': bool(group_names),
        'window_days': days,
        'window_start': start,
        'data_from': min(opened_dates) if opened_dates else None,
        'data_to': max(opened_dates) if opened_dates else None,
        'app_rows': app_rows,
        'member_rows': member_rows,
        'unlisted_workers': unlisted,
        'balance': balance,
        'verdict': verdict,
        'rules': rules,
        'moves': moves,
        'coverage_actions': coverage_actions,
        'recommendations': recommendations,
        'unattributed': unattributed,
        'totals': totals,
        'access_members': access_members,
        'config': cfg,
    }


def headline(report):
    """The handful of numbers the tower page's summary tab shows."""
    totals = report['totals']
    return {
        'incidents': totals['incidents'],
        'service_requests': totals['service_requests'],
        'tickets': totals['tickets'],
        'team_members': totals['team_members'],
        'applications': totals['applications'],
        'owned_applications': totals['owned_applications'],
        'priority_counts': totals['priority_counts'],
        'groups_configured': report['groups_configured'],
        'group_names': report['group_names'],
        'verdict': report['verdict'],
        'balance': report['balance'],
        'rules': report['rules'],
        'window_days': report['window_days'],
        'access_members': report['access_members'],
        'open_findings': len([row for row in report['recommendations']
                              if row['severity'] in ('critical', 'warning')]),
    }
