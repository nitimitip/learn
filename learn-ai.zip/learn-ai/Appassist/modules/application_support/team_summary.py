"""
Tower Summary - the tower's team, its applications, and who supports what.

Three questions, one report:

  * WHO is on the tower and how much are they carrying?
  * For an APPLICATION, which team members support it (primary / secondary)?
  * For a MEMBER, which applications do they support?

The allocation itself is the assignment grid: members down the side, slots
(Primary 1..n, Secondary 1..n) across, one application per cell, a running
total on the right. The tower lead fills it in; every count on this page is
read back from it, so an application nobody has been given reports as
uncovered rather than quietly disappearing.

The rules live here rather than in routes.py so the page, the grid POST and
the workbook all read the same numbers - the same split the documentation
quality screens use. Everything below is a pure function over rows already
loaded, except the loaders at the bottom, so it stays testable without a
database.
"""

from models import User
from .models import (ApplicationAssignment, ApplicationDetails,
                     BusinessCriticality, SupportTeam, TeamRole, TowerMember)

PRIMARY = 'primary'
SECONDARY = 'secondary'
TYPES = (PRIMARY, SECONDARY)

TYPE_LABEL = {PRIMARY: 'Primary', SECONDARY: 'Secondary'}

# How many slot columns the grid offers per cover level. It always shows at
# least MIN_SLOTS so there is somewhere to put the next application, and
# grows to fit whatever is already allocated (plus one spare column). The
# ceiling is there only to stop a malformed POST asking for 10,000 columns.
MIN_SLOTS = 3
MAX_SLOTS = 30

# Business criticality -> the label the counts are reported under.
BC_LABEL = {'BC1': 'Business Critical', 'BC2': 'High Priority',
            'BC3': 'Normal Priority'}


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

def _bc_code(app):
    """'BC1' whether the column came back as the Enum or as raw text."""
    return getattr(app.business_criticality, 'value', app.business_criticality)


def cell_name(user_id, kind, index):
    """The form field name for one cell of the grid.

    Parsed straight back out of request.form, so the shape is fixed here and
    nowhere else.
    """
    return 'cell-{0}-{1}-{2}'.format(user_id, kind, index)


def _display_name(user_obj):
    """Full name, falling back to the username."""
    full = '{0} {1}'.format(getattr(user_obj, 'firstname', '') or '',
                            getattr(user_obj, 'lastname', '') or '').strip()
    return full or (getattr(user_obj, 'username', '') or '')


# ---------------------------------------------------------------------------
# Shaping the report
# ---------------------------------------------------------------------------

def slot_counts(assignments, minimum=MIN_SLOTS):
    """How many columns each cover level needs.

    The highest slot already used, plus one empty column to allocate into,
    never fewer than `minimum`.
    """
    counts = {}
    for kind in TYPES:
        used = [a.slot_index for a in assignments
                if a.assignment_type == kind and a.slot_index]
        wanted = (max(used) + 1) if used else minimum
        counts[kind] = max(minimum, min(MAX_SLOTS, wanted))
    return counts


def build_grid(members, applications, assignments, slots):
    """The assignment grid: one row per member, one cell per slot.

    Each cell carries the field name the form posts under and the application
    currently in it (or None). The row total is the number of filled cells,
    which is what the last column reports.
    """
    apps_by_id = {app.id: app for app in applications}
    placed = {}
    for row in assignments:
        placed[(row.user_id, row.assignment_type,
                row.slot_index)] = row.application_id

    grid = []
    for member in members:
        cells = {}
        filled = {PRIMARY: 0, SECONDARY: 0}
        for kind in TYPES:
            row_cells = []
            for index in range(1, slots[kind] + 1):
                app_id = placed.get((member['user_id'], kind, index))
                app = apps_by_id.get(app_id)
                if app is None:
                    app_id = None
                else:
                    filled[kind] += 1
                row_cells.append({
                    'name': cell_name(member['user_id'], kind, index),
                    'index': index,
                    'kind': kind,
                    'application_id': app_id,
                    'application_name': app.application_name if app else '',
                })
            cells[kind] = row_cells
        grid.append({
            'member': member,
            'cells': cells,
            'primary_count': filled[PRIMARY],
            'secondary_count': filled[SECONDARY],
            'total': filled[PRIMARY] + filled[SECONDARY],
        })
    return grid


def by_application(applications, assignments, members):
    """Application -> the members supporting it, by cover level.

    'Application: managed by team member'. Applications with nobody against
    them stay in the list, unassigned, because those are the rows that matter
    most.
    """
    names = {m['user_id']: m['name'] for m in members}
    holders = {}
    for row in assignments:
        name = names.get(row.user_id)
        if not name:
            continue
        slot = holders.setdefault(row.application_id,
                                  {PRIMARY: [], SECONDARY: []})
        if row.assignment_type in slot and name not in slot[row.assignment_type]:
            slot[row.assignment_type].append(name)

    out = []
    for app in applications:
        slot = holders.get(app.id, {PRIMARY: [], SECONDARY: []})
        out.append({
            'application': app,
            'bc': _bc_code(app),
            'primary': sorted(slot[PRIMARY]),
            'secondary': sorted(slot[SECONDARY]),
            'covered': bool(slot[PRIMARY] or slot[SECONDARY]),
        })
    out.sort(key=lambda r: (r['covered'],
                            (r['application'].application_name or '').lower()))
    return out


def by_member(members, applications, assignments):
    """Member -> the applications they support, by cover level.

    'Team member: manages application'. Every member is listed, including the
    ones carrying nothing.
    """
    apps_by_id = {app.id: app for app in applications}
    held = {}
    for row in assignments:
        app = apps_by_id.get(row.application_id)
        if app is None:
            continue
        slot = held.setdefault(row.user_id, {PRIMARY: [], SECONDARY: []})
        if row.assignment_type in slot:
            slot[row.assignment_type].append(app)

    def _name(app):
        return (app.application_name or '').lower()

    out = []
    for member in members:
        slot = held.get(member['user_id'], {PRIMARY: [], SECONDARY: []})
        primary = sorted(slot[PRIMARY], key=_name)
        secondary = sorted(slot[SECONDARY], key=_name)
        out.append({
            'member': member,
            'primary': primary,
            'secondary': secondary,
            'total': len(primary) + len(secondary),
        })
    return out


def coverage(app_rows, member_rows):
    """The counts and the findings - what is not covered, and who is idle.

    Nothing here is a score. They are lists of names a tower lead can act on,
    which is what the grid is for.
    """
    no_primary = [r['application'].application_name for r in app_rows
                  if not r['primary']]
    no_secondary = [r['application'].application_name for r in app_rows
                    if r['primary'] and not r['secondary']]
    unassigned = [r['application'].application_name for r in app_rows
                  if not r['covered']]
    # The same application named primary by two people. Allowed to save -
    # blocking it would lose work mid-reshuffle - but reported, because a
    # shared primary is an ownership gap wearing a disguise.
    contested = [r['application'].application_name for r in app_rows
                 if len(r['primary']) > 1]
    idle = [r['member']['name'] for r in member_rows if r['total'] == 0]

    totals = [r['total'] for r in member_rows]
    loaded = [t for t in totals if t]
    return {
        'applications': len(app_rows),
        'assigned': sum(1 for r in app_rows if r['covered']),
        'with_primary': sum(1 for r in app_rows if r['primary']),
        'with_secondary': sum(1 for r in app_rows if r['secondary']),
        'members': len(member_rows),
        'members_loaded': len(loaded),
        'assignments': sum(totals),
        'heaviest': max(totals) if totals else 0,
        'lightest': min(loaded) if loaded else 0,
        'average': round(sum(totals) / float(len(totals)), 1) if totals else 0,
        'no_primary': sorted(no_primary),
        'no_secondary': sorted(no_secondary),
        'unassigned': sorted(unassigned),
        'contested': sorted(contested),
        'idle': sorted(idle),
    }


def application_counts(applications):
    """Application count for the tower, split by business criticality."""
    counts = dict((bc.value, 0) for bc in BusinessCriticality)
    for app in applications:
        code = _bc_code(app)
        if code in counts:
            counts[code] += 1
    return {'total': len(applications), 'by_bc': counts, 'labels': BC_LABEL}


# ---------------------------------------------------------------------------
# Reading the grid back out of a POST
# ---------------------------------------------------------------------------

def parse_form(form, members, application_ids, slots):
    """Turn the posted grid into (cells, errors).

    `cells` is a list of dicts ready to become ApplicationAssignment rows.
    Anything the form did not send, or sent blank, is simply absent - the
    caller replaces the tower's whole allocation with what comes back, so a
    cleared cell clears the assignment.

    Only members of THIS tower and applications of THIS tower are accepted;
    a hand-edited field naming somebody else's application is dropped and
    reported rather than written.
    """
    app_ids = set(application_ids)
    cells, errors, seen = [], [], set()

    for member in members:
        for kind in TYPES:
            for index in range(1, slots[kind] + 1):
                raw = (form.get(cell_name(member['user_id'], kind, index))
                       or '').strip()
                if not raw:
                    continue
                try:
                    app_id = int(raw)
                except (TypeError, ValueError):
                    errors.append('Ignored an unreadable entry in {0} {1} for '
                                  '{2}.'.format(TYPE_LABEL[kind], index,
                                                member['name']))
                    continue
                if app_id not in app_ids:
                    errors.append('{0} {1} for {2} named an application that '
                                  'is not in this tower - not saved.'.format(
                                      TYPE_LABEL[kind], index, member['name']))
                    continue
                # The same application twice in one member's row at the same
                # cover level is a slip, not an intent: keep the first.
                key = (member['user_id'], kind, app_id)
                if key in seen:
                    errors.append('An application appears twice as a {0} '
                                  'for {1} - the duplicate was '
                                  'dropped.'.format(TYPE_LABEL[kind].lower(),
                                                    member['name']))
                    continue
                seen.add(key)
                cells.append({'user_id': member['user_id'],
                              'assignment_type': kind,
                              'slot_index': index,
                              'application_id': app_id})
    return cells, errors


def save(db_session, tower_id, cells, saved_by):
    """Replace the tower's allocation with `cells`. The caller commits.

    Replace rather than merge: the grid posts every cell it rendered, so what
    comes back IS the allocation. Anything missing was cleared on screen.
    """
    (db_session.query(ApplicationAssignment)
     .filter(ApplicationAssignment.tower_id == tower_id)
     .delete(synchronize_session=False))
    for cell in cells:
        db_session.add(ApplicationAssignment(
            tower_id=tower_id,
            application_id=cell['application_id'],
            user_id=cell['user_id'],
            assignment_type=cell['assignment_type'],
            slot_index=cell['slot_index'],
            assigned_by=saved_by))
    return len(cells)



# ---------------------------------------------------------------------------
# Writing the allocation through to the application records
#
# The grid is the tower lead's view; SupportTeam is what the APPLICATION page,
# the profile exports and the documentation scorecard all read. So an
# assignment is written through to `support_team` rather than only living in
# `app_support_assignments` - otherwise a lead could staff the whole tower and
# every application record would still say "no support team".
#
# The two sources are kept apart by `SupportTeam.source`:
#   NULL          typed on the application's own record (the pre-existing rows)
#   'assignment'  written from the grid, rebuilt on every save
#
# A derived row is never editable on the application form and a typed row is
# never deleted by a grid save, so neither side can quietly destroy the
# other's work.
# ---------------------------------------------------------------------------

SOURCE_ASSIGNMENT = 'assignment'

# Cover level -> the role the application record records it under.
ROLE_FOR = {PRIMARY: TeamRole.PRIMARY_OWNER,
            SECONDARY: TeamRole.TEAM_MEMBER}


def _identity(name, email):
    """How two support-team rows are judged to be the same person.

    Email when there is one on both sides, otherwise the name folded to
    lowercase - the same test Resource Utilization's membership match uses.
    """
    email = (email or '').strip().lower()
    return email or (name or '').strip().lower()


def sync_support_team(db_session, application_ids, cells, members, saved_by):
    """Rewrite the 'assignment' support-team rows for a tower's applications.

    `cells` is what parse_form() returned. Returns (written, promoted):
    how many derived rows were created, and how many already-typed rows had
    their role corrected to match the allocation.

    Three rules, in order:

    1. Every existing derived row for these applications goes, so a cleared
       cell clears the support-team entry too.
    2. Where the application record ALREADY names that person by hand, no
       second row is added. Their role is corrected to the allocated one
       instead - the lead's allocation is what decides who owns an
       application, and a card that contradicts the grid is worse than
       either on its own. The row stays typed (source NULL), so a later
       grid save will not delete somebody's hand-entered contact details.
    3. Everyone else gets a derived row.

    The caller commits.
    """
    if not application_ids:
        return 0, 0

    (db_session.query(SupportTeam)
     .filter(SupportTeam.application_id.in_(application_ids),
             SupportTeam.source == SOURCE_ASSIGNMENT)
     .delete(synchronize_session=False))

    people = {m['user_id']: m for m in members}

    # What the allocation says, per application: identity -> (role, member).
    # Primary wins over secondary if the lead put the same person in both,
    # because the stronger claim is the one worth recording.
    wanted = {}
    for cell in cells:
        member = people.get(cell['user_id'])
        if not member:
            continue
        role = ROLE_FOR.get(cell['assignment_type'])
        if role is None:
            continue
        key = (cell['application_id'], _identity(member['name'],
                                                 member['email']))
        current = wanted.get(key)
        if current is None or (current[0] is TeamRole.TEAM_MEMBER
                               and role is TeamRole.PRIMARY_OWNER):
            wanted[key] = (role, member)

    typed = {}
    for row in (db_session.query(SupportTeam)
                .filter(SupportTeam.application_id.in_(application_ids))
                .all()):
        typed[(row.application_id,
               _identity(row.member_name, row.email))] = row

    written = promoted = 0
    for (app_id, identity), (role, member) in wanted.items():
        existing = typed.get((app_id, identity))
        if existing is not None:
            if existing.role != role:
                existing.role = role
                promoted += 1
            continue
        db_session.add(SupportTeam(
            application_id=app_id,
            member_name=member['name'],
            role=role,
            email=member['email'] or '',
            source=SOURCE_ASSIGNMENT))
        written += 1
    return written, promoted


def release_member(db_session, tower_id, user_id, member_name, email):
    """Drop everything a person leaving the tower was allocated.

    Their grid cells go, and so do the support-team rows the grid wrote for
    them - a derived row is only ever true while the allocation behind it is.
    Rows TYPED on an application record are left alone: somebody losing
    App Assist access to the tower is not a statement about whether their
    name still belongs on that record. Returns (cells, rows). The caller
    commits.
    """
    cells = (db_session.query(ApplicationAssignment)
             .filter_by(tower_id=tower_id, user_id=user_id)
             .delete(synchronize_session=False))

    app_ids = [a.id for a in (db_session.query(ApplicationDetails.id)
                              .filter_by(tower_id=tower_id).all())]
    rows = 0
    if app_ids:
        identity = _identity(member_name, email)
        for row in (db_session.query(SupportTeam)
                    .filter(SupportTeam.application_id.in_(app_ids),
                            SupportTeam.source == SOURCE_ASSIGNMENT).all()):
            if _identity(row.member_name, row.email) == identity:
                db_session.delete(row)
                rows += 1
    return cells, rows


def split_support_team(rows):
    """(typed, derived) - the application form may only edit the typed half."""
    typed = [r for r in rows if r.source != SOURCE_ASSIGNMENT]
    derived = [r for r in rows if r.source == SOURCE_ASSIGNMENT]
    return typed, derived

# ---------------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------------

def load_members(db_session, tower_id):
    """The tower's members, leads first then alphabetically.

    This is the list the grid's rows are auto-populated from - membership of
    the tower is what makes somebody assignable, so adding a person to the
    tower is all it takes for them to appear here.
    """
    rows = (db_session.query(TowerMember, User)
            .join(User, User.id == TowerMember.user_id)
            .filter(TowerMember.tower_id == tower_id)
            .all())
    members = [{
        'user_id': u.id,
        'name': _display_name(u),
        'username': u.username,
        'email': u.email,
        'is_lead': bool(m.is_lead),
        'is_active': bool(u.is_active),
    } for m, u in rows]
    members.sort(key=lambda m: (not m['is_lead'], (m['name'] or '').lower()))
    return members


def load_applications(db_session, tower_id):
    """The tower's live applications, in name order."""
    return (db_session.query(ApplicationDetails)
            .filter_by(tower_id=tower_id, is_active=True)
            .order_by(ApplicationDetails.application_name)
            .all())


def load_assignments(db_session, tower_id):
    """The allocation rows for a tower."""
    return (db_session.query(ApplicationAssignment)
            .filter_by(tower_id=tower_id)
            .order_by(ApplicationAssignment.assignment_type,
                      ApplicationAssignment.slot_index)
            .all())


def build(db_session, tower, applications=None):
    """The whole Tower Summary for one tower, as a single dict.

    The page, the grid POST and the workbook all render from this, so they
    can never quote different numbers.
    """
    members = load_members(db_session, tower.id)
    if applications is None:
        applications = load_applications(db_session, tower.id)
    assignments = load_assignments(db_session, tower.id)

    slots = slot_counts(assignments)
    app_rows = by_application(applications, assignments, members)
    member_rows = by_member(members, applications, assignments)

    return {
        'tower': tower,
        'members': members,
        'applications': applications,
        'slots': slots,
        'grid': build_grid(members, applications, assignments, slots),
        'app_rows': app_rows,
        'member_rows': member_rows,
        'coverage': coverage(app_rows, member_rows),
        'counts': application_counts(applications),
        'type_label': TYPE_LABEL,
    }
