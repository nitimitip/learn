"""
Activity Tracker module - routes.

A personal weekly timesheet, available to every signed-in user:

* /activity-tracker/                     - the week view (?week=YYYY-MM-DD is
                                           any date inside the wanted week)
* /activity-tracker/add                  - add one timesheet entry
* /activity-tracker/entry/<id>/update    - edit an entry (own entries only)
* /activity-tracker/entry/<id>/delete    - delete an entry (own entries only)

A standard office day is 8 hours; each day shows its logged total against
that bar. Entries are private to the user who logged them - only the
Resource Utilization module (project managers) reads them in aggregate.

Retention: rows older than one year are purged opportunistically whenever
the timesheet is opened.
"""

import logging
from datetime import date, timedelta

from flask import (Blueprint, flash, redirect, render_template, request,
                   url_for)
from sqlalchemy import func

from auth import get_current_user
from csrf_utils import csrf_protect
from database import get_db_session

from .models import (ACTIVITY_CATEGORIES, MAX_ENTRY_HOURS, MIN_ENTRY_HOURS,
                     STANDARD_DAY_HOURS, ActivityEntry, purge_expired_entries,
                     retention_cutoff)

logger = logging.getLogger(__name__)

activity_tracker_bp = Blueprint(
    'activity_tracker', __name__,
    template_folder='../../templates/activity_tracker',
)


def _require_user():
    user = get_current_user()
    if not user:
        flash('Please login to use the Activity Tracker.', 'error')
    return user


def _monday_of(d: date) -> date:
    return d - timedelta(days=d.weekday())


def _parse_date(raw):
    try:
        return date.fromisoformat((raw or '').strip())
    except (TypeError, ValueError):
        return None


def _parse_entry_form(form):
    """
    Validate the add/update form. Returns (values_dict, error_message);
    exactly one of the two is None. One form covers project and non-project
    work: picking one of your assigned project tasks links the hours to that
    task's T&M allocation; otherwise the free-text task name is required.
    """
    entry_date = _parse_date(form.get('entry_date'))
    task_name = (form.get('task_name') or '').strip()
    category = (form.get('category') or '').strip()
    notes = (form.get('notes') or '').strip()
    try:
        hours = float((form.get('hours') or '').strip())
    except (TypeError, ValueError):
        hours = None

    raw_task = (form.get('project_task_id') or '').strip()
    project_task_id = None
    if raw_task:
        try:
            project_task_id = int(raw_task)
        except ValueError:
            return None, 'Invalid project task selection.'

    today = date.today()
    if not entry_date:
        return None, 'A valid date is required.'
    if entry_date > today:
        return None, 'Timesheet entries record actual work - the date cannot be in the future.'
    if entry_date < retention_cutoff(today):
        return None, 'The date is outside the one-year timesheet window.'
    if not task_name and not project_task_id:
        return None, 'Pick a project task or type what you worked on.'
    if hours is None or not (MIN_ENTRY_HOURS <= hours <= MAX_ENTRY_HOURS):
        return None, (f'Hours must be between {MIN_ENTRY_HOURS:g} and '
                      f'{MAX_ENTRY_HOURS:g}.')
    if category and category not in ACTIVITY_CATEGORIES:
        return None, 'Invalid category selection.'

    return {
        'entry_date': entry_date,
        'task_name': task_name[:300],
        'project_task_id': project_task_id,
        'category': category or None,
        'hours': round(hours * 4) / 4.0,   # quarter-hour steps
        'notes': notes[:2000] or None,
    }, None


def _project_is_open(project):
    """Open = still accepting timesheet hours: not Completed / Failed /
    Closed and not flagged closed."""
    from modules.project_management.models import ProjectStatus
    return (not project.is_closed
            and project.status not in (ProjectStatus.COMPLETED,
                                       ProjectStatus.FAILED,
                                       ProjectStatus.CLOSED))


def _apply_task_link(db_session, user, values, current_task_id=None):
    """
    Validate the optional project-task link on parsed form values: the task
    must be one of the user's own assignments on an OPEN project (an entry
    already linked to `current_task_id` may keep that link even after the
    project closes, so old entries stay editable). Fills the task name and
    category from the task when left blank. Returns an error string or None.
    """
    tid = values.get('project_task_id')
    if not tid:
        return None
    from modules.project_management.models import (Project, ProjectMilestone,
                                                   ProjectTask)
    row = (db_session.query(ProjectTask, Project)
           .join(ProjectMilestone,
                 ProjectTask.milestone_id == ProjectMilestone.id)
           .join(Project, ProjectMilestone.project_id == Project.id)
           .filter(ProjectTask.id == tid,
                   ProjectTask.assigned_to == user.id)
           .first())
    if not row:
        return 'Pick one of your own assigned project tasks.'
    task, project = row
    if tid != current_task_id and not _project_is_open(project):
        return ('This task belongs to a closed project - hours can only '
                'be logged against tasks of open projects.')
    if not values['task_name']:
        values['task_name'] = task.name[:300]
    if not values['category']:
        values['category'] = 'Project work'
    return None


def _my_task_rows(db_session, user_id):
    """
    [(task, milestone, project)] the user is assigned to, newest first.
    These feed both the entry form's task picker and the T&M allocation
    banners - one timesheet entry form covers project and non-project work.
    """
    from modules.project_management.models import (Project, ProjectMilestone,
                                                   ProjectTask)
    return (db_session.query(ProjectTask, ProjectMilestone, Project)
            .join(ProjectMilestone,
                  ProjectTask.milestone_id == ProjectMilestone.id)
            .join(Project, ProjectMilestone.project_id == Project.id)
            .filter(ProjectTask.assigned_to == user_id)
            .order_by(ProjectTask.start_date.desc(), ProjectTask.id.desc())
            .all())


def _my_allocations(db_session, user_id, task_rows, day_hours=None,
                    holidays=None):
    """
    [(task, project, consumption)] for the user's assigned project tasks.
    The allocation is the task's planned working days x the configured day
    hours (holiday calendar excluded); consumption is the hours the user
    logged AGAINST that task; hours after the planned end mean the
    engagement is extended. Math imported from Resource Utilization (that
    module owns the allocation model).
    """
    from modules.resource_utilization.service import (allocation_consumption,
                                                      split_task_hours,
                                                      task_allocation)

    per_day = day_hours or STANDARD_DAY_HOURS
    tasks = [t for t, _, _ in task_rows]
    if not tasks:
        return []
    rows = (db_session.query(ActivityEntry.project_task_id,
                             ActivityEntry.entry_date,
                             func.sum(ActivityEntry.hours))
            .filter(ActivityEntry.user_id == user_id,
                    ActivityEntry.project_task_id.in_([t.id for t in tasks]))
            .group_by(ActivityEntry.project_task_id,
                      ActivityEntry.entry_date)
            .all())
    hours = {}
    for tid, d, h in rows:
        hours.setdefault(tid, {})[d] = float(h or 0.0)

    out = []
    for t, m, p in task_rows:
        _, allocated_hours = task_allocation(t.start_date, t.end_date,
                                             per_day, holidays)
        consumed, days_logged, after_h, after_d = split_task_hours(
            hours.get(t.id, {}), t.end_date)
        out.append((t, p, allocation_consumption(
            allocated_hours, per_day, consumed,
            after_end_hours=after_h, days_logged=days_logged,
            after_end_days=after_d)))
    return out


def _week_redirect(entry_date=None):
    """Back to the week view showing the given date's week."""
    if entry_date:
        return redirect(url_for('activity_tracker.index',
                                week=entry_date.isoformat()))
    return redirect(url_for('activity_tracker.index'))


# ---------------------------------------------------------------------------
# Week view
# ---------------------------------------------------------------------------

@activity_tracker_bp.route('/')
def index():
    user = _require_user()
    if not user:
        return redirect(url_for('login'))

    anchor = _parse_date(request.args.get('week')) or date.today()
    week_start = _monday_of(anchor)
    week_end = week_start + timedelta(days=6)
    days = [week_start + timedelta(days=i) for i in range(7)]
    today = date.today()

    from modules.resource_utilization.models import (load_holidays,
                                                     load_settings)

    db_session = get_db_session()
    try:
        purge_expired_entries(db_session, today)
        settings = load_settings(db_session)
        holidays = load_holidays(db_session)
        entries = (db_session.query(ActivityEntry)
                   .filter(ActivityEntry.user_id == user.id,
                           ActivityEntry.entry_date >= week_start,
                           ActivityEntry.entry_date <= week_end)
                   .order_by(ActivityEntry.entry_date,
                             ActivityEntry.created_at, ActivityEntry.id)
                   .all())
        task_rows = _my_task_rows(db_session, user.id)
        my_allocations = _my_allocations(db_session, user.id, task_rows,
                                         settings['day_hours'], holidays)
    finally:
        db_session.close()

    # {task_id: (task, project)} so linked entries can show their project.
    task_info = {t.id: (t, p) for t, m, p in task_rows}

    # Task picker: current or recent assignments on OPEN projects only -
    # a closed / completed / failed project no longer accepts hours. Within
    # an open project, a task that ended weeks ago stays offered for a
    # while - extension hours are exactly the point.
    picker_cutoff = today - timedelta(days=60)
    picker_tasks = [(t, p) for t, m, p in task_rows
                    if _project_is_open(p)
                    and (t.end_date >= picker_cutoff
                         or t.status.name != 'COMPLETED')]

    # Banner: allocations that need attention (nearing / used / extended)
    # plus whatever is currently underway.
    banner_allocations = [
        (t, p, cs) for t, p, cs in my_allocations
        if cs['band'] != 'ok' or t.start_date <= today <= t.end_date]

    by_day = {d: [] for d in days}
    for e in entries:
        by_day.setdefault(e.entry_date, []).append(e)
    day_totals = {d: round(sum(e.hours for e in rows), 2)
                  for d, rows in by_day.items()}

    week_total = round(sum(day_totals.values()), 2)
    # The target only counts weekdays that have already happened (a Wednesday
    # visit to the current week expects 3 x 8h, not 40h). Public holidays
    # from the workforce calendar do not expect hours.
    elapsed_weekdays = [d for d in days
                        if d.weekday() < 5 and d <= today
                        and d not in holidays]
    week_target = len(elapsed_weekdays) * settings['day_hours']

    return render_template(
        'activity_tracker/index.html',
        user=user,
        days=days, by_day=by_day, day_totals=day_totals,
        week_start=week_start, week_end=week_end,
        prev_week=(week_start - timedelta(days=7)).isoformat(),
        next_week=(week_start + timedelta(days=7)).isoformat(),
        is_current_week=(week_start == _monday_of(today)),
        today=today,
        week_total=week_total, week_target=week_target,
        day_hours=settings['day_hours'],
        categories=ACTIVITY_CATEGORIES,
        min_hours=MIN_ENTRY_HOURS, max_hours=MAX_ENTRY_HOURS,
        banner_allocations=banner_allocations,
        picker_tasks=picker_tasks, task_info=task_info,
    )


# ---------------------------------------------------------------------------
# Add / update / delete
# ---------------------------------------------------------------------------

@activity_tracker_bp.route('/add', methods=['POST'])
@csrf_protect
def add_entry():
    user = _require_user()
    if not user:
        return redirect(url_for('login'))

    values, error = _parse_entry_form(request.form)
    if error:
        flash(error, 'error')
        return _week_redirect(_parse_date(request.form.get('entry_date')))

    db_session = get_db_session()
    try:
        error = _apply_task_link(db_session, user, values)
        if error:
            flash(error, 'error')
            return _week_redirect(values['entry_date'])
        db_session.add(ActivityEntry(user_id=user.id, **values))
        db_session.commit()
        flash(f"Logged {values['hours']:g}h on "
              f"{values['entry_date'].strftime('%a %d %b')}.", 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error adding timesheet entry for %s: %s',
                         user.username, e)
        flash('An error occurred while saving the entry.', 'error')
    finally:
        db_session.close()

    return _week_redirect(values['entry_date'])


@activity_tracker_bp.route('/entry/<int:entry_id>/update', methods=['POST'])
@csrf_protect
def update_entry(entry_id):
    user = _require_user()
    if not user:
        return redirect(url_for('login'))

    values, error = _parse_entry_form(request.form)
    if error:
        flash(error, 'error')
        return _week_redirect(_parse_date(request.form.get('entry_date')))

    db_session = get_db_session()
    try:
        entry = (db_session.query(ActivityEntry)
                 .filter_by(id=entry_id, user_id=user.id).first())
        if not entry:
            flash('Entry not found.', 'error')
            return _week_redirect()
        error = _apply_task_link(db_session, user, values,
                                 current_task_id=entry.project_task_id)
        if error:
            flash(error, 'error')
            return _week_redirect(values['entry_date'])
        for field, value in values.items():
            setattr(entry, field, value)
        db_session.commit()
        flash('Entry updated.', 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error updating timesheet entry %s for %s: %s',
                         entry_id, user.username, e)
        flash('An error occurred while updating the entry.', 'error')
    finally:
        db_session.close()

    return _week_redirect(values['entry_date'])


@activity_tracker_bp.route('/entry/<int:entry_id>/delete', methods=['POST'])
@csrf_protect
def delete_entry(entry_id):
    user = _require_user()
    if not user:
        return redirect(url_for('login'))

    db_session = get_db_session()
    entry_date = None
    try:
        entry = (db_session.query(ActivityEntry)
                 .filter_by(id=entry_id, user_id=user.id).first())
        if not entry:
            flash('Entry not found.', 'error')
        else:
            entry_date = entry.entry_date
            db_session.delete(entry)
            db_session.commit()
            flash('Entry deleted.', 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error deleting timesheet entry %s for %s: %s',
                         entry_id, user.username, e)
        flash('An error occurred while deleting the entry.', 'error')
    finally:
        db_session.close()

    return _week_redirect(entry_date)
