"""
Activity Tracker module - data model.

One row per timesheet line: a user logs "what I worked on" for a given date
with the hours spent. A standard office day is 8 hours (STANDARD_DAY_HOURS);
the timesheet page shows each day's total against that bar, and the Resource
Utilization module adds these hours on top of project-task allocation.

Retention: the application keeps timesheet data for the last one year only.
purge_expired_entries() enforces this and is called opportunistically from the
timesheet routes - no scheduler needed, a cheap indexed DELETE.
"""

from datetime import date, timedelta

from sqlalchemy import (Column, Date, DateTime, Float, ForeignKey, Index,
                        Integer, String, Text)
from sqlalchemy.sql import func

from database import Base


# The standard office working day, in hours.
STANDARD_DAY_HOURS = 8.0

# Timesheet data is kept for the last one year only.
RETENTION_DAYS = 365

# Offered activity categories (optional on an entry; free "Other" catch-all).
# Plain strings, validated in the routes - same philosophy as the Go-Live
# vocabularies: adding one never needs a migration.
#
# LEAVE_CATEGORY is special: Resource Utilization treats hours logged under
# it as absence - they REDUCE the person's capacity for the period instead
# of counting as worked hours, so someone on approved leave never reads as
# under-utilized or non-compliant.
LEAVE_CATEGORY = 'Leave / Time off'

ACTIVITY_CATEGORIES = [
    'Project work',
    'BAU / Support',
    'Incident',
    'Change',
    'Meeting',
    'Training',
    'Documentation',
    'Admin',
    LEAVE_CATEGORY,
    'Other',
]

# Hours per entry: quarter-hour steps, and a hard sanity ceiling per line.
MIN_ENTRY_HOURS = 0.25
MAX_ENTRY_HOURS = 24.0


class ActivityEntry(Base):
    """One timesheet line: user + date + task name + hours spent."""
    __tablename__ = 'activity_entries'
    __table_args__ = (
        # The timesheet page reads one user's week; the utilization module
        # sums hours per user over a date range. Both hit this index.
        Index('ix_activity_entries_user_date', 'user_id', 'entry_date'),
        # T&M allocation tracking sums hours per linked project task.
        Index('ix_activity_entries_task', 'project_task_id'),
    )

    id         = Column(Integer, primary_key=True)
    user_id    = Column(Integer, ForeignKey('users.id'), nullable=False)
    entry_date = Column(Date, nullable=False)
    task_name  = Column(String(300), nullable=False)
    # Optional link to the Project Management task the hours were spent on.
    # This is what ties the timesheet to the project plan: hours logged
    # against a task count toward that task's T&M allocation (its planned
    # working days x 8h), and hours dated after the task's planned end mark
    # the engagement as EXTENDED. Free-text entries (no link) stay exactly
    # as before - one entry form for both.
    project_task_id = Column(Integer, ForeignKey('project_tasks.id'))
    category   = Column(String(50))
    hours      = Column(Float, nullable=False)
    notes      = Column(Text)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    def __repr__(self):
        return (f'<ActivityEntry user={self.user_id} {self.entry_date} '
                f'{self.hours}h {self.task_name!r}>')


def retention_cutoff(today=None) -> date:
    """Oldest entry_date the application keeps (inclusive)."""
    today = today or date.today()
    return today - timedelta(days=RETENTION_DAYS)


def purge_expired_entries(db_session, today=None) -> int:
    """Delete timesheet rows older than the one-year retention window."""
    cutoff = retention_cutoff(today)
    deleted = (db_session.query(ActivityEntry)
               .filter(ActivityEntry.entry_date < cutoff)
               .delete(synchronize_session=False))
    db_session.commit()
    return deleted
