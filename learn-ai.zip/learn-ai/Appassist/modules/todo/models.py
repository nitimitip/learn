"""
models.py - To-Do module.

A single table, ``todo_items``, holding one row per to-do activity. Every row
is OWNED by exactly one user (``user_id``), and the routes only ever query
rows scoped to the logged-in user, so a user can only ever see - or change -
their own activities.

Status model
------------
``status`` is deliberately a tiny two-value vocabulary:

  * ``open``       - outstanding work the user still has to do.
  * ``completed``  - finished. ``completed_at`` is stamped when this is set,
                     and is what the 4-month retention purge keys off.

Everything else (overdue / due-today / urgency colour) is DERIVED from
``due_date`` against the current date, so it can never go stale - exactly the
pattern the Security module uses for certificate ``days_left`` / ``status``.
"""

from datetime import date

from sqlalchemy import (
    Column, Integer, String, DateTime, Date, Text, ForeignKey, Index,
    UniqueConstraint,
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from database import Base


# Status vocabulary - imported by routes / scheduler so the strings live in
# exactly one place.
STATUS_OPEN = 'open'
STATUS_COMPLETED = 'completed'

# Priority vocabulary (display + sort only).
PRIORITY_LOW = 'low'
PRIORITY_MEDIUM = 'medium'
PRIORITY_HIGH = 'high'
PRIORITIES = (PRIORITY_HIGH, PRIORITY_MEDIUM, PRIORITY_LOW)


class TodoItem(Base):
    __tablename__ = 'todo_items'

    id = Column(Integer, primary_key=True)

    # Owner. NOT NULL - a to-do with no owner would be invisible to every user
    # and would leak into nobody's digest. ON DELETE is left to the DB default;
    # off-boarding a user is done by disabling (is_active=False), which keeps
    # their rows intact, mirroring the rest of the app.
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False, index=True)

    title = Column(String(300), nullable=False)
    description = Column(Text)

    priority = Column(String(10), nullable=False, default=PRIORITY_MEDIUM)
    status = Column(String(12), nullable=False, default=STATUS_OPEN, index=True)

    # Optional target date. A NULL due_date means "someday / no deadline" - it
    # is never overdue and never highlighted as due-today.
    due_date = Column(Date, index=True)

    # Stamped the moment the item is marked completed; cleared if it is
    # re-opened. The retention purge deletes completed rows whose completed_at
    # is older than the retention window.
    completed_at = Column(DateTime)

    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    user = relationship('User', foreign_keys=[user_id])

    # Composite index for the two hot paths: the per-user list view and the
    # morning-digest sweep, both of which filter on (user_id, status).
    __table_args__ = (
        Index('ix_todo_user_status', 'user_id', 'status'),
    )

    # ------------------------------------------------------------------
    # Derived state (never stored - always evaluated against today)
    # ------------------------------------------------------------------
    @property
    def is_open(self) -> bool:
        return self.status == STATUS_OPEN

    @property
    def is_completed(self) -> bool:
        return self.status == STATUS_COMPLETED

    @property
    def is_due_today(self) -> bool:
        """Open AND its due date is exactly today (the 'highlight if open for
        the current date' rule)."""
        return self.is_open and self.due_date == date.today()

    @property
    def is_overdue(self) -> bool:
        """Open AND its due date has already passed (the 'highlight if open and
        date is expired' rule)."""
        return (
            self.is_open
            and self.due_date is not None
            and self.due_date < date.today()
        )

    @property
    def days_to_due(self):
        """Whole days until the due date (negative if overdue, None if no
        due date)."""
        if self.due_date is None:
            return None
        return (self.due_date - date.today()).days

    @property
    def urgency(self) -> str:
        """Bucket used everywhere for colour-coding.

        completed | overdue | today | soon (<=3d) | upcoming | someday
        """
        if not self.is_open:
            return 'completed'
        d = self.days_to_due
        if d is None:
            return 'someday'
        if d < 0:
            return 'overdue'
        if d == 0:
            return 'today'
        if d <= 3:
            return 'soon'
        return 'upcoming'

    def __repr__(self):
        return f'<TodoItem id={self.id} user={self.user_id} {self.status!r}>'


class TodoDigestLog(Base):
    """One row per (user, day) on which the automated morning digest was sent.

    This is the cross-process idempotency guard for the digest sweep. Before
    sending, the sweep atomically INSERTs a row for (user_id, today); the
    UNIQUE constraint means a SECOND runner (e.g. an IIS worker that also
    started the scheduler) gets an IntegrityError and skips - so each user
    receives at most ONE automated digest per day no matter how many processes
    run the sweep. Stale rows are pruned by the daily retention purge.

    The manual "email me my open list now" button does NOT touch this table,
    so a user can always re-request their summary on demand.
    """
    __tablename__ = 'todo_digest_log'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    sent_date = Column(Date, nullable=False)
    created_at = Column(DateTime, default=func.now())

    __table_args__ = (
        UniqueConstraint('user_id', 'sent_date', name='uq_todo_digest_user_date'),
    )

    def __repr__(self):
        return f'<TodoDigestLog user={self.user_id} {self.sent_date}>'
