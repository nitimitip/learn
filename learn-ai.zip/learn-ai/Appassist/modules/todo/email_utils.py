"""
email_utils.py - To-Do morning-digest email.

Builds and sends the per-user "open to-do" summary that the scheduler fires
every morning. Design language and Outlook-safety rules are intentionally the
same as the MIMP / health-check emails so the digest looks like a sibling
product:

  * 100% nested <table> layout - no <div>s for structure.
  * State is a tint fill plus a hairline on ALL FOUR sides - never a
    coloured stripe down one edge (matches the web theme).
  * Status pills are tiny <table>s, not inline-block spans.
  * Labels are PRE-UPPERCASED in Python (Word ignores text-transform).
  * Solid colours only; bgcolor attributes accompany every background-color.
  * A multipart/alternative plain-text part is included for deliverability.

The two highlight rules the brief calls out are rendered as their own,
visually distinct sections:

  * OVERDUE   - open items whose due date has passed (red).
  * DUE TODAY - open items due on the current date (amber).
  * UPCOMING / SOMEDAY - everything else still open (neutral).
"""

from __future__ import annotations

import logging
import os
import smtplib
from datetime import date, datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

logger = logging.getLogger(__name__)


# SMTP (shared convention with the rest of the app)
_SMTP_SERVER = os.environ.get('SMTP_SERVER', 'mail1.northernpowergrid.com')
_SMTP_PORT = int(os.environ.get('SMTP_PORT', '25'))
_EMAIL_FROM = os.environ.get('EMAIL_FROM', 'NPgAppAssist@northernpowergrid.com')


# NPG palette - imported from the shared email theme so a colour is
# defined ONCE for the whole application (email_theme.py). The private
# aliases keep this module's f-strings unchanged.
from email_theme import (                             # noqa: E402
    NPG_RED as _NPG_RED, NPG_DARK as _NPG_DARK, NPG_LIGHT as _NPG_LIGHT,
    NPG_BORDER as _NPG_BORDER, NPG_TEXT as _NPG_TEXT,
    NPG_TEXT_MUTED as _NPG_TEXT_MUTED, CHIP_BG as _CHIP_BG,
    FONT as _FONT,
)

# Masthead and footer come from the shared NPG theme (email_theme.py): a flat
# maroon banner closed by a graphite rule, and a graphite footer band. Flat, not
# a gradient - the Word engine behind desktop Outlook cannot render one.
from email_theme import hero_rows, footer_rows

# Section palettes keyed by urgency bucket.
_SECTION = {
    'overdue': {
        'border': _NPG_RED, 'tint': '#FEF2F2', 'tint_border': '#FECACA',
        'pill_bg': '#FEE2E2', 'pill_fg': '#991B1B', 'detail_fg': '#991B1B',
        'label': 'PAST THEIR TARGET DATE',
    },
    'today': {
        'border': '#F59E0B', 'tint': '#FFFBEB', 'tint_border': '#FDE68A',
        'pill_bg': '#FEF3C7', 'pill_fg': '#92400E', 'detail_fg': '#92400E',
        'label': "TODAY'S LIST",
    },
    'upcoming': {
        'border': '#2563EB', 'tint': '#EFF6FF', 'tint_border': '#BFDBFE',
        'pill_bg': '#DBEAFE', 'pill_fg': '#1D4ED8', 'detail_fg': '#1E3A8A',
        'label': 'COMING UP',
    },
    'someday': {
        'border': '#94A3B8', 'tint': '#F8FAFC', 'tint_border': _NPG_BORDER,
        'pill_bg': '#E2E8F0', 'pill_fg': '#475569', 'detail_fg': '#475569',
        'label': 'NO DATE YET',
    },
}

_PRIORITY_LABEL = {'high': 'HIGH', 'medium': 'MEDIUM', 'low': 'LOW'}


# Public entry point
def send_todo_digest(user, open_items: list, run_date: date) -> bool:
    """Email *user* their open-to-do summary.

    Returns True if an email was sent, False if there was nothing to send
    (no recipient / no open items). SMTP errors are logged and swallowed so a
    single bad recipient can't abort the whole morning sweep.
    """
    if not getattr(user, 'email', None):
        logger.warning('User %s has no email - skipping digest.', getattr(user, 'id', '?'))
        return False
    if not open_items:
        return False

    buckets = _bucketize(open_items)
    overdue = len(buckets['overdue'])
    today = len(buckets['today'])
    total = len(open_items)

    try:
        msg = MIMEMultipart('alternative')
        bits = [f'{total} open']
        if overdue:
            bits.append(f'{overdue} overdue')
        if today:
            bits.append(f'{today} due today')
        msg['Subject'] = (
            f"[App Assist] Your to-do summary - {', '.join(bits)}  |  "
            f"{run_date.strftime('%d %b %Y')}"
        )
        msg['From'] = _EMAIL_FROM
        msg['To'] = user.email
        # Bump priority when something is actually overdue or due today.
        msg['X-Priority'] = '2' if (overdue or today) else '3'

        msg.attach(MIMEText(_build_text(user, buckets, run_date), 'plain', 'utf-8'))
        msg.attach(MIMEText(_build_html(user, buckets, run_date), 'html', 'utf-8'))

        with smtplib.SMTP(_SMTP_SERVER, _SMTP_PORT, timeout=30) as server:
            server.send_message(msg)

        logger.info('To-do digest sent to %s (%d open, %d overdue, %d today).',
                    user.email, total, overdue, today)
        return True

    except smtplib.SMTPException as exc:
        logger.error('SMTP error sending to-do digest to %s: %s', user.email, exc)
        return False
    except Exception:
        logger.exception('Unexpected error sending to-do digest to %s.', user.email)
        return False


# Grouping
def _bucketize(open_items: list) -> dict:
    """Split open items into overdue / today / upcoming / someday, each already
    sorted (overdue & upcoming by due date ascending)."""
    buckets = {'overdue': [], 'today': [], 'upcoming': [], 'someday': []}
    for it in open_items:
        if it.is_overdue:
            buckets['overdue'].append(it)
        elif it.is_due_today:
            buckets['today'].append(it)
        elif it.due_date is None:
            buckets['someday'].append(it)
        else:
            buckets['upcoming'].append(it)
    buckets['overdue'].sort(key=lambda t: t.due_date)
    buckets['upcoming'].sort(key=lambda t: t.due_date)
    return buckets


# Outlook-safe building blocks
def _badge(bg: str, fg: str, label: str) -> str:
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
        f'style="display:inline-table;"><tr>'
        f'<td bgcolor="{bg}" style="background-color:{bg};padding:5px 12px;'
        f'font-family:{_FONT};font-size:11px;font-weight:bold;color:{fg};'
        f'mso-line-height-rule:exactly;line-height:14px;letter-spacing:1px;'
        f'border-collapse:separate;border-spacing:0;border-radius:20px;">{label}</td></tr></table>'
    )


def _stat_card(bg: str, big_fg: str, label_fg: str, value: int, label: str,
               border: str = _NPG_BORDER) -> str:
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
        f'width="100%" bgcolor="{bg}" style="background-color:{bg};'
        f'border:1px solid {border};border-collapse:separate;border-spacing:0;border-radius:10px;">'
        f'<tr><td align="center" style="padding:16px 12px;font-family:{_FONT};">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0">'
        f'<tr><td align="center" style="font-size:28px;font-weight:bold;color:{big_fg};'
        f'letter-spacing:-0.4px;mso-line-height-rule:exactly;line-height:32px;">{value}</td></tr>'
        f'<tr><td align="center" style="font-size:10px;font-weight:bold;color:{label_fg};'
        f'mso-line-height-rule:exactly;line-height:14px;letter-spacing:1.3px;padding-top:5px;">'
        f'{label}</td></tr></table>'
        f'</td></tr></table>'
    )


def _due_phrase(item, run_date: date) -> str:
    """Human due-date phrase, e.g. 'Due today', 'Overdue by 3 days', 'Due 14 Jul'."""
    if item.due_date is None:
        return 'No due date'
    delta = (item.due_date - run_date).days
    if delta < 0:
        n = -delta
        return f'Overdue by {n} day{"s" if n != 1 else ""} (was {item.due_date.strftime("%d %b %Y")})'
    if delta == 0:
        return 'Due today'
    if delta == 1:
        return 'Due tomorrow'
    return f'Due {item.due_date.strftime("%d %b %Y")} ({delta} days)'


def _item_card(item, palette: dict, run_date: date) -> str:
    title = _esc(item.title)
    due = _esc(_due_phrase(item, run_date))
    prio = _PRIORITY_LABEL.get(item.priority, 'MEDIUM')

    desc_html = ''
    if item.description:
        desc_html = (
            f'<tr><td colspan="2" style="padding-top:4px;font-family:{_FONT};'
            f'font-size:12px;color:{_NPG_TEXT_MUTED};mso-line-height-rule:exactly;'
            f'line-height:16px;">{_esc(item.description)}</td></tr>'
        )

    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
        f'bgcolor="{palette["tint"]}" style="background-color:{palette["tint"]};'
        f'border:1px solid {palette["tint_border"]};border-collapse:separate;border-spacing:0;border-radius:10px;'
        f'margin-bottom:8px;">'
        f'<tr>'
        f'<td style="padding:12px 14px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr>'
        f'<td style="font-family:{_FONT};font-size:14px;font-weight:bold;color:{_NPG_TEXT};'
        f'mso-line-height-rule:exactly;line-height:18px;">{title}</td>'
        f'<td align="right" valign="top">{_badge(palette["pill_bg"], palette["pill_fg"], prio)}</td>'
        f'</tr>'
        f'<tr><td colspan="2" style="padding-top:4px;font-family:{_FONT};font-size:12px;'
        f'font-weight:bold;color:{palette["detail_fg"]};mso-line-height-rule:exactly;line-height:16px;">'
        f'{due}</td></tr>'
        f'{desc_html}'
        f'</table>'
        f'</td></tr></table>'
    )


def _section(key: str, items: list, run_date: date, intro: str = '') -> str:
    if not items:
        return ''
    palette = _SECTION[key]
    cards = ''.join(_item_card(it, palette, run_date) for it in items)
    intro_html = ''
    if intro:
        intro_html = (
            f'<tr><td style="padding-top:6px;font-family:{_FONT};font-size:13px;'
            f'color:{_NPG_TEXT_MUTED};mso-line-height-rule:exactly;line-height:19px;">{intro}</td></tr>'
        )
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
        f'style="margin-bottom:18px;">'
        f'<tr><td style="border-bottom:1px solid {palette["border"]};padding-bottom:8px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"><tr>'
        f'<td style="font-family:{_FONT};font-size:13px;font-weight:bold;color:{palette["detail_fg"]};'
        f'letter-spacing:0.4px;mso-line-height-rule:exactly;line-height:17px;">{palette["label"]}</td>'
        f'<td align="right" style="font-family:{_FONT};font-size:11px;color:{_NPG_TEXT_MUTED};'
        f'font-weight:bold;mso-line-height-rule:exactly;line-height:15px;">{len(items)} item'
        f'{"s" if len(items) != 1 else ""}</td>'
        f'</tr></table></td></tr>'
        f'{intro_html}'
        f'<tr><td style="padding-top:12px;">{cards}</td></tr>'
        f'</table>'
    )


# HTML composition
def _build_html(user, buckets: dict, run_date: date) -> str:
    overdue = len(buckets['overdue'])
    today = len(buckets['today'])
    total = sum(len(v) for v in buckets.values())
    first_name = _esc((getattr(user, 'firstname', '') or 'there').strip() or 'there')
    when = run_date.strftime('%A, %d %b %Y')

    # Personal note (assistant voice), tuned to the day's shape
    def _n(count, singular, plural):
        return f"{count} {singular if count == 1 else plural}"

    if today and overdue:
        ribbon_pal = _SECTION['today']
        ribbon_title = "Here's your day"
        ribbon_body = (
            f"You've got <strong>{_n(today, 'thing', 'things')}</strong> lined up for today, "
            f"and <strong>{_n(overdue, 'item', 'items')}</strong> that slipped past the target "
            f"date and {'is' if overdue == 1 else 'are'} still open. I'd clear those first."
        )
    elif today:
        ribbon_pal = _SECTION['today']
        ribbon_title = "Here's your day"
        ribbon_body = (
            f"You've got <strong>{_n(today, 'thing', 'things')}</strong> on today's list, "
            f"and nothing's overdue - looking good."
        )
    elif overdue:
        ribbon_pal = _SECTION['overdue']
        ribbon_title = 'A couple of things slipped'
        ribbon_body = (
            f"Nothing's due today, but <strong>{_n(overdue, 'item', 'items')}</strong> "
            f"{'has' if overdue == 1 else 'have'} gone past the target date and "
            f"{'is' if overdue == 1 else 'are'} still open - worth a look."
        )
    else:
        ribbon_pal = _SECTION['upcoming']
        ribbon_title = "You're all clear for now"
        ribbon_body = (
            f"Nothing due today and nothing overdue. Here's what's coming up so it "
            f"doesn't sneak up on you - {_n(total, 'open item', 'open items')} in total."
        )

    # Sections, in the order an assistant would walk you through them:
    # today first, then anything past its date, then what's coming up.
    sections = (
        _section('today', buckets['today'], run_date,
                 intro="Let's get these done today.")
        + _section('overdue', buckets['overdue'], run_date,
                   intro='These went past their target date and are still open.')
        + _section('upcoming', buckets['upcoming'], run_date,
                   intro="Further out - nothing to do yet, just so it's on your radar.")
        + _section('someday', buckets['someday'], run_date,
                   intro='Captured without a date, for whenever you get to them.')
    )

    badge_open = _badge(_CHIP_BG, '#FFFFFF',
                        f"{total} OPEN")
    badge_when = _badge(_CHIP_BG, '#FFFFFF', when.upper())

    hero = hero_rows('NPG APP ASSIST &middot; DAILY TO-DO SUMMARY',
                     f'Good morning, {first_name}', [badge_open, badge_when])
    footer = footer_rows('To-Do')

    return f"""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>NPG App Assist &mdash; Your to-do summary</title>
  <!--[if mso]>
  <xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch><o:AllowPNG/></o:OfficeDocumentSettings></xml>
  <style type="text/css">table {{border-collapse:collapse;}} td {{mso-line-height-rule:exactly;}}</style>
  <![endif]-->
  <style type="text/css">
    body, table, td {{ -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }}
    table {{ border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }}
    a {{ color:{_NPG_RED}; text-decoration:none; }}
    @media only screen and (max-width:620px) {{
      .container {{ width:100% !important; }}
      .px-32 {{ padding-left:18px !important; padding-right:18px !important; }}
      .stat-cell {{ display:block !important; width:100% !important; padding:0 0 6px 0 !important; }}
    }}
  </style>
</head>
<body style="margin:0;padding:0;background-color:{_NPG_LIGHT};font-family:{_FONT};">
<div style="display:none;font-size:1px;color:{_NPG_LIGHT};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
Your App Assist to-do summary &mdash; {total} open ({overdue} overdue, {today} due today)
</div>

<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="{_NPG_LIGHT}" style="background-color:{_NPG_LIGHT};">
  <tr><td align="center" style="padding:34px 16px 40px 16px;">
    <!--[if mso]><table role="presentation" align="center" cellpadding="0" cellspacing="0" border="0" width="600"><tr><td><![endif]-->
    <table role="presentation" class="container" cellpadding="0" cellspacing="0" border="0" width="600"
           style="width:600px;max-width:600px;background-color:#FFFFFF;border:1px solid {_NPG_BORDER};border-bottom-color:#C6D0DE;border-collapse:separate;border-spacing:0;border-radius:14px;">

      <!-- Header (shared NPG theme: flat maroon masthead) -->
      {hero}

      <!-- Ribbon -->
      <tr><td class="px-32" style="padding:24px 32px;">
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"
               bgcolor="{ribbon_pal['tint']}" style="background-color:{ribbon_pal['tint']};border:1px solid {ribbon_pal['tint_border']};border-collapse:separate;border-spacing:0;border-radius:10px;">
          <tr>
            <td style="padding:14px 16px;font-family:{_FONT};color:{ribbon_pal['detail_fg']};">
              <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                <tr><td style="font-size:13px;font-weight:bold;mso-line-height-rule:exactly;line-height:18px;
                           padding-bottom:4px;color:{ribbon_pal['detail_fg']};">{ribbon_title}</td></tr>
                <tr><td style="font-size:13px;mso-line-height-rule:exactly;line-height:20px;
                           color:{ribbon_pal['detail_fg']};">{ribbon_body}</td></tr>
              </table>
            </td>
          </tr>
        </table>
      </td></tr>

      <!-- Stat strip -->
      <tr><td class="px-32" style="padding:20px 32px;">
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
          <td class="stat-cell" width="33%" valign="top" style="padding-right:6px;">
            {_stat_card('#FEF2F2', _NPG_RED, '#991B1B', overdue, 'OVERDUE', '#FECACA')}</td>
          <td class="stat-cell" width="34%" valign="top" style="padding:0 3px;">
            {_stat_card('#FFFBEB', '#B45309', '#92400E', today, 'DUE TODAY', '#FDE68A')}</td>
          <td class="stat-cell" width="33%" valign="top" style="padding-left:6px;">
            {_stat_card('#F0FDF4', '#15803D', '#166534', total, 'TOTAL OPEN', '#BBF7D0')}</td>
        </tr></table>
      </td></tr>

      <!-- Sections -->
      <tr><td class="px-32" style="padding:24px 32px;">
        {sections}
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-top:1px solid {_NPG_LIGHT};">
          <tr><td style="padding-top:14px;font-family:{_FONT};font-size:12px;color:{_NPG_TEXT_MUTED};
                     mso-line-height-rule:exactly;line-height:18px;">
            This is your personal list - only you receive it. Sign in to App Assist to add, edit or complete items.
          </td></tr>
        </table>
      </td></tr>

      <!-- Footer (shared NPG theme) -->
      {footer}

    </table>
    <!--[if mso]></td></tr></table><![endif]-->
  </td></tr>
</table>
</body>
</html>"""


# Plain-text alternative
def _build_text(user, buckets: dict, run_date: date) -> str:
    total = sum(len(v) for v in buckets.values())
    overdue = len(buckets['overdue'])
    today = len(buckets['today'])
    first_name = (getattr(user, 'firstname', '') or 'there').strip() or 'there'

    # A one-line personal note matching the HTML ribbon's tone.
    if today and overdue:
        note = (f"You've got {today} lined up for today, and {overdue} that slipped "
                f"past the target date and are still open - clear those first.")
    elif today:
        note = f"You've got {today} on today's list, and nothing's overdue - looking good."
    elif overdue:
        note = (f"Nothing's due today, but {overdue} have gone past the target date "
                f"and are still open - worth a look.")
    else:
        note = "Nothing due today and nothing overdue. Here's what's coming up."

    lines = [
        'NPG APP ASSIST - YOUR TO-DO SUMMARY',
        '=' * 52,
        f'Good morning, {first_name}.',
        run_date.strftime('%A, %d %b %Y'),
        '',
        note,
        '',
    ]
    for key, heading, intro in (
        ('today', "TODAY'S LIST", "Let's get these done today."),
        ('overdue', 'PAST THEIR TARGET DATE',
         'These went past their target date and are still open.'),
        ('upcoming', 'COMING UP', 'Further out, just so it is on your radar.'),
        ('someday', 'NO DATE YET', 'Captured without a date.'),
    ):
        items = buckets[key]
        if not items:
            continue
        lines.append(heading)
        lines.append('-' * 52)
        lines.append(intro)
        for it in items:
            prio = _PRIORITY_LABEL.get(it.priority, 'MEDIUM')
            lines.append(f'  [{prio}] {it.title}')
            lines.append(f'         {_due_phrase(it, run_date)}')
            if it.description:
                lines.append(f'         {it.description}')
        lines.append('')
    lines.append('This is your personal list - only you receive it.')
    lines.append('NPG App Assist - To-Do - Generated automatically - Do not reply')
    return '\n'.join(lines)


# Helper
def _esc(text) -> str:
    if text is None:
        return ''
    return (str(text)
            .replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;'))
