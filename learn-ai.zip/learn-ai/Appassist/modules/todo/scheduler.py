"""
scheduler.py - To-Do background scheduler.

Mirrors the certificate-monitor lifecycle: an in-process APScheduler
BackgroundScheduler running TWO daily cron jobs, with its OWN jobstore table
(``apscheduler_jobs_todo``) so it never loads or fires the health-check / MIMP /
cert jobs.

  * todo_morning_digest  - every morning at TODO_DIGEST_HOUR:MINUTE (07:00
                           local by default). Emails each active user with open
                           to-dos their personal summary, highlighting items
                           that are due today or overdue.
  * todo_retention_purge - daily at TODO_PURGE_HOUR:MINUTE (02:30 local by
                           default). Deletes completed to-dos older than the
                           retention window (4 months).

Deployment model (identical to the other schedulers):
  * The dedicated Windows service (health_monitor_app_sched.py) owns the
    schedule in production and calls init_todo_monitoring().
  * The in-process Flask scheduler may also start it, guarded by
    RUN_SCHEDULERS_IN_APP in main_app.py. Both jobs are
    daily cron jobs with coalesce=True and max_instances=1, so a second runner
    is harmless (at worst the digest is sent once - APScheduler coalesces
    missed runs).
"""

import logging
import os
import threading
from typing import Optional

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from tzlocal import get_localzone

from database import engine
from .service import run_morning_digests, run_todo_retention_purge

logger = logging.getLogger(__name__)

# Morning digest time (local). Override with TODO_DIGEST_HOUR / _MINUTE.
_DIGEST_HOUR = int(os.environ.get('TODO_DIGEST_HOUR', '7'))
_DIGEST_MINUTE = int(os.environ.get('TODO_DIGEST_MINUTE', '0'))

# Retention purge time (local). Kept off the top of the hour and clear of the
# digest so the two never contend. Override with TODO_PURGE_HOUR / _MINUTE.
_PURGE_HOUR = int(os.environ.get('TODO_PURGE_HOUR', '2'))
_PURGE_MINUTE = int(os.environ.get('TODO_PURGE_MINUTE', '30'))

_JOBSTORE_TABLE = os.environ.get('TODO_APSCHEDULER_TABLE', 'apscheduler_jobs_todo')
_DIGEST_JOB = 'todo_morning_digest'
_PURGE_JOB = 'todo_retention_purge'

_init_lock = threading.Lock()
_scheduler: Optional[BackgroundScheduler] = None


def _digest_safe():
    """Scheduler entry point - never lets an exception kill the thread."""
    try:
        run_morning_digests()
    except Exception:
        logger.exception('To-do morning digest sweep crashed (suppressed).')


def _purge_safe():
    try:
        run_todo_retention_purge()
    except Exception:
        logger.exception('To-do retention purge crashed (suppressed).')


def init_todo_monitoring() -> None:
    """Start the in-process to-do scheduler. Idempotent."""
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            logger.info('To-do monitoring already running - skipping re-init.')
            return

        _scheduler = BackgroundScheduler(
            jobstores={'default': SQLAlchemyJobStore(engine=engine, tablename=_JOBSTORE_TABLE)},
            job_defaults={'coalesce': True, 'max_instances': 1, 'misfire_grace_time': 3600},
            timezone=get_localzone(),
        )
        _scheduler.add_job(
            func=_digest_safe,
            trigger=CronTrigger(hour=_DIGEST_HOUR, minute=_DIGEST_MINUTE),
            id=_DIGEST_JOB,
            name=f'To-do morning digest (daily {_DIGEST_HOUR:02d}:{_DIGEST_MINUTE:02d})',
            replace_existing=True,
        )
        _scheduler.add_job(
            func=_purge_safe,
            trigger=CronTrigger(hour=_PURGE_HOUR, minute=_PURGE_MINUTE),
            id=_PURGE_JOB,
            name=f'To-do retention purge (daily {_PURGE_HOUR:02d}:{_PURGE_MINUTE:02d})',
            replace_existing=True,
        )
        _scheduler.start()
        logger.info('To-do monitoring started - digest at %02d:%02d, purge at %02d:%02d.',
                    _DIGEST_HOUR, _DIGEST_MINUTE, _PURGE_HOUR, _PURGE_MINUTE)


def shutdown_todo_monitoring() -> None:
    """Cleanly stop the scheduler. Call from service teardown / atexit."""
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            _scheduler.shutdown(wait=False)
            logger.info('To-do monitoring stopped.')
        _scheduler = None
