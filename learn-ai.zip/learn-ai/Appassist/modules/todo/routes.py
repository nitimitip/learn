"""
routes.py - To-Do module.

Access model
------------
EVERY route here requires an authenticated user (no guest / public view), and
every query is scoped to ``user_id == current_user.id``. A user therefore only
ever sees, edits, completes or deletes their OWN to-do activities - there is no
route that can reach another user's rows. The ``_owned_or_404`` helper enforces
ownership on the per-item routes so a hand-crafted id in the URL cannot touch
someone else's data.

State changes (add / edit / toggle / delete / send-digest) are POST-only and
CSRF-protected, consistent with the rest of the application.
"""

import logging
from datetime import date, datetime
from functools import wraps

from flask import (
    Blueprint, render_template, request, redirect, url_for, flash, abort,
)

from auth import get_current_user
from csrf_utils import csrf_protect
from database import get_db_session
from .models import (
    TodoItem, STATUS_OPEN, STATUS_COMPLETED, PRIORITIES, PRIORITY_MEDIUM,
)

logger = logging.getLogger(__name__)

todo_bp = Blueprint('todo', __name__, template_folder='templates')


# ---------------------------------------------------------------------------
# Auth gate - login required for the whole blueprint
# ---------------------------------------------------------------------------
def login_required(view):
    """Redirect anonymous callers to the login page.

    Stashes the authenticated User on flask.g so the view can use it without a
    second lookup, and exposes it as the ``user`` kwarg.
    """
    @wraps(view)
    def wrapper(*args, **kwargs):
        user = get_current_user()
        if not user:
            flash('Please sign in to manage your to-do list.', 'error')
            return redirect(url_for('login'))
        return view(*args, user=user, **kwargs)
    return wrapper


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _owned_or_404(db_session, item_id, user):
    """Fetch a to-do by id but ONLY if it belongs to ``user``.

    Returns the row, or aborts 404 - we deliberately do not distinguish
    "does not exist" from "not yours" so the endpoint cannot be used to probe
    which ids exist for other users.
    """
    item = (
        db_session.query(TodoItem)
        .filter(TodoItem.id == item_id, TodoItem.user_id == user.id)
        .first()
    )
    if item is None:
        abort(404)
    return item


def _parse_due_date(raw):
    """Parse the <input type=date> value (YYYY-MM-DD). Empty -> None."""
    raw = (raw or '').strip()
    if not raw:
        return None
    try:
        return datetime.strptime(raw, '%Y-%m-%d').date()
    except ValueError:
        return None


def _clean_priority(raw):
    raw = (raw or '').strip().lower()
    return raw if raw in PRIORITIES else PRIORITY_MEDIUM


# Open items: overdue first, then due-today, then by due date (no-date last),
# then high priority first, newest last. Mirrors the digest ordering so the
# screen and the email agree.
_PRIORITY_RANK = {'high': 0, 'medium': 1, 'low': 2}


def _open_sort_key(item):
    has_date = item.due_date is not None
    return (
        0 if item.is_overdue else 1,
        0 if item.is_due_today else 1,
        date.max if not has_date else item.due_date,
        _PRIORITY_RANK.get(item.priority, 1),
        -(item.id or 0),
    )


# ---------------------------------------------------------------------------
# List view
# ---------------------------------------------------------------------------
@todo_bp.route('/')
@login_required
def index(user):
    """The user's personal to-do board: open items grouped by urgency, with a
    collapsible completed list."""
    db_session = get_db_session()
    try:
        rows = (
            db_session.query(TodoItem)
            .filter(TodoItem.user_id == user.id)
            .all()
        )

        open_items = sorted(
            (t for t in rows if t.is_open), key=_open_sort_key
        )
        completed_items = sorted(
            (t for t in rows if t.is_completed),
            key=lambda t: (t.completed_at or datetime.min),
            reverse=True,
        )

        stats = {
            'open': len(open_items),
            'overdue': sum(1 for t in open_items if t.is_overdue),
            'today': sum(1 for t in open_items if t.is_due_today),
            'completed': len(completed_items),
        }

        return render_template(
            'todo/index.html',
            user=user,
            open_items=open_items,
            completed_items=completed_items,
            stats=stats,
            today=date.today(),
        )
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------
@todo_bp.route('/add', methods=['POST'])
@csrf_protect
@login_required
def add(user):
    title = (request.form.get('title') or '').strip()
    if not title:
        flash('A to-do needs a title.', 'error')
        return redirect(url_for('todo.index'))
    if len(title) > 300:
        title = title[:300]

    db_session = get_db_session()
    try:
        item = TodoItem(
            user_id=user.id,
            title=title,
            description=(request.form.get('description') or '').strip() or None,
            priority=_clean_priority(request.form.get('priority')),
            due_date=_parse_due_date(request.form.get('due_date')),
            status=STATUS_OPEN,
        )
        db_session.add(item)
        db_session.commit()
        flash('To-do added.', 'success')
    except Exception:
        db_session.rollback()
        logger.exception('Error adding to-do for user %s', user.id)
        flash('Could not add the to-do. Please try again.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('todo.index'))


# ---------------------------------------------------------------------------
# Edit
# ---------------------------------------------------------------------------
@todo_bp.route('/<int:item_id>/edit', methods=['GET', 'POST'])
@csrf_protect
@login_required
def edit(item_id, user):
    db_session = get_db_session()
    try:
        item = _owned_or_404(db_session, item_id, user)

        if request.method == 'POST':
            title = (request.form.get('title') or '').strip()
            if not title:
                flash('A to-do needs a title.', 'error')
                return redirect(url_for('todo.edit', item_id=item_id))

            item.title = title[:300]
            item.description = (request.form.get('description') or '').strip() or None
            item.priority = _clean_priority(request.form.get('priority'))
            item.due_date = _parse_due_date(request.form.get('due_date'))
            try:
                db_session.commit()
                flash('To-do updated.', 'success')
                return redirect(url_for('todo.index'))
            except Exception:
                db_session.rollback()
                logger.exception('Error updating to-do %s', item_id)
                flash('Could not save your changes. Please try again.', 'error')

        return render_template('todo/edit.html', user=user, item=item)
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Toggle complete / re-open
# ---------------------------------------------------------------------------
@todo_bp.route('/<int:item_id>/toggle', methods=['POST'])
@csrf_protect
@login_required
def toggle(item_id, user):
    db_session = get_db_session()
    try:
        item = _owned_or_404(db_session, item_id, user)
        if item.is_open:
            item.status = STATUS_COMPLETED
            item.completed_at = datetime.now()
            msg = 'Marked as completed.'
        else:
            item.status = STATUS_OPEN
            item.completed_at = None
            msg = 'Re-opened.'
        db_session.commit()
        flash(msg, 'success')
    except Exception:
        db_session.rollback()
        logger.exception('Error toggling to-do %s', item_id)
        flash('Could not update the to-do. Please try again.', 'error')
    finally:
        db_session.close()

    return redirect(request.referrer or url_for('todo.index'))


# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------
@todo_bp.route('/<int:item_id>/delete', methods=['POST'])
@csrf_protect
@login_required
def delete(item_id, user):
    db_session = get_db_session()
    try:
        item = _owned_or_404(db_session, item_id, user)
        db_session.delete(item)
        db_session.commit()
        flash('To-do deleted.', 'success')
    except Exception:
        db_session.rollback()
        logger.exception('Error deleting to-do %s', item_id)
        flash('Could not delete the to-do. Please try again.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('todo.index'))


# ---------------------------------------------------------------------------
# Send my digest now (manual trigger - lets a user verify the morning email)
# ---------------------------------------------------------------------------
@todo_bp.route('/send-digest', methods=['POST'])
@csrf_protect
@login_required
def send_digest_now(user):
    from .service import send_digest_for_user

    if not user.email:
        flash('Your account has no email address on file.', 'error')
        return redirect(url_for('todo.index'))

    try:
        sent = send_digest_for_user(user.id)
        if sent:
            flash(f'Your to-do summary has been emailed to {user.email}.', 'success')
        else:
            flash('You have no open to-dos - nothing to email.', 'info')
    except Exception:
        logger.exception('Manual digest send failed for user %s', user.id)
        flash('Could not send the email. Please contact an administrator.', 'error')

    return redirect(url_for('todo.index'))


# ---------------------------------------------------------------------------
# About
# ---------------------------------------------------------------------------
@todo_bp.route('/about')
@login_required
def about(user):
    return render_template('todo/about.html', user=user)
