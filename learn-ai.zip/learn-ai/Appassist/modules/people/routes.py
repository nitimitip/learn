"""
People Directory module - routes.

The organisation's people directory, part of the Workforce area:

* /people/            - search the directory by name, team, sub-group or
                        Application Support tower
* /people/<user_id>   - one person's professional profile, presented as a CV

Access model: EVERY signed-in user, whatever their role or user group -
Organization Members ('guest') included. It is a directory, so it is
deliberately open to the whole organisation; there is nothing on it a
colleague could not read from Application Support, ServiceNow Analysis or
Project Management directly.

The module stores nothing. See service.py for where each section of the CV
is read from and how a person is attributed to a tower.
"""

import logging

from flask import (Blueprint, abort, flash, redirect, render_template,
                   request, url_for)

from auth import get_current_user
from database import get_db_session
from models import User
from modules.user_profile.models import (USER_GROUP_LABELS, USER_TEAMS)

from .service import (TOWER_SOURCE_LABELS, build_profile, directory_rows,
                      search_users, sub_group_options, tower_options)

logger = logging.getLogger(__name__)

people_bp = Blueprint(
    'people', __name__,
    template_folder='../../templates/people',
)


def _clean(value):
    """A submitted filter value, whitespace collapsed; '' when absent."""
    return ' '.join((value or '').split())


def _int_or_none(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


@people_bp.route('/')
def directory():
    """Search results - every active person matching the filters."""
    user = get_current_user()
    if not user:
        return redirect(url_for('login'))

    f_name = _clean(request.args.get('name'))
    f_team = _clean(request.args.get('team'))
    f_sub = _clean(request.args.get('sub'))
    f_tower = _int_or_none(request.args.get('tower'))

    db_session = get_db_session()
    try:
        towers = tower_options(db_session)
        # A tower id that is not on the list (stale bookmark, hand-edited
        # URL) is dropped rather than silently returning nobody.
        if f_tower is not None and f_tower not in [t[0] for t in towers]:
            f_tower = None
        sub_groups = sub_group_options(db_session)

        people = search_users(db_session, name=f_name, team=f_team,
                              sub_group=f_sub, tower_id=f_tower)
        rows = directory_rows(db_session, people)
    finally:
        db_session.close()

    return render_template(
        'people/directory.html',
        user=user, rows=rows,
        f_name=f_name, f_team=f_team, f_sub=f_sub, f_tower=f_tower,
        tower_choices=towers, sub_group_choices=sub_groups,
        team_choices=USER_TEAMS,
        user_group_labels=USER_GROUP_LABELS,
        tower_source_labels=TOWER_SOURCE_LABELS,
        filtered=bool(f_name or f_team or f_sub or f_tower),
    )


@people_bp.route('/<int:user_id>')
def profile(user_id):
    """One person's professional profile, laid out as a CV."""
    user = get_current_user()
    if not user:
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        person = db_session.query(User).filter_by(id=user_id).first()
        if person is None:
            abort(404)
        # A disabled account keeps its historical records everywhere else in
        # the app, but it does not belong in a live people directory.
        if not person.is_active:
            flash('That person no longer has an active account.', 'info')
            return redirect(url_for('people.directory'))
        profile_data = build_profile(db_session, person)
    finally:
        db_session.close()

    return render_template(
        'people/profile.html',
        user=user, p=profile_data, person=profile_data['person'],
        user_group_labels=USER_GROUP_LABELS,
        tower_source_labels=TOWER_SOURCE_LABELS,
        is_self=(person.id == user.id),
    )
