from .routes import people_bp

__all__ = ['people_bp']
