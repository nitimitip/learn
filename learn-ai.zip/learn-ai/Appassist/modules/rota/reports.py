"""
reports.py - the attendance report.

ONE REPORT. The previous build had twelve, which between them answered every
question anybody had thought of and made it hard to find the one anybody
actually asked: who was on, did they turn up, and were they on time.

So there is a single report with two readings of the same rows:

    by_person   one line per member - shifts held, attended, late, missed,
                and an attendance percentage
    by_shift    one line per assignment - the raw record behind those numbers

Both come from the same query and the same status rules the screens use, so
the report can never disagree with the dashboard about what "missed" means.

THE PERCENTAGE ONLY COUNTS SHIFTS THAT HAVE HAPPENED. A member rostered for
ten shifts of which two have run and both were worked is at 100%, not 20%.
Counting the future as absence would make every new rota look like a crisis,
and the number would be useless until the last shift ended.

Exported as .xlsx through openpyxl, with a CSV fallback so the download works
on a host where openpyxl is missing.
"""

import logging
from datetime import date, datetime

from sqlalchemy.orm import joinedload

from .models import (MISSED_STATUSES, ST_DONE, ST_MISSED, ST_MISSED_SIGNOFF,
                     STATE_ACTIVE, STATUS_DRAFT, STATUS_TEXT, Rota,
                     RotaAssignment, RotaMember, RotaShift)
from .service import graces, person_name

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Gathering
# ---------------------------------------------------------------------------

def _assignments(db_session, rota_ids=None, start=None, end=None,
                 user_id=None):
    query = (db_session.query(RotaAssignment)
             .join(RotaShift, RotaShift.id == RotaAssignment.shift_id)
             .join(Rota, Rota.id == RotaAssignment.rota_id)
             .options(joinedload(RotaAssignment.shift),
                      joinedload(RotaAssignment.rota),
                      joinedload(RotaAssignment.user),
                      joinedload(RotaAssignment.recorder))
             .filter(RotaAssignment.state == STATE_ACTIVE,
                     # A draft rota's shifts were never asked of anybody, so
                     # counting them as attendance would be an accusation
                     # about work nobody was told to do.
                     Rota.status != STATUS_DRAFT))
    if rota_ids is not None:
        if not rota_ids:
            return []
        query = query.filter(RotaAssignment.rota_id.in_(tuple(rota_ids)))
    if start is not None:
        query = query.filter(RotaShift.shift_date >= start)
    if end is not None:
        query = query.filter(RotaShift.shift_date <= end)
    if user_id is not None:
        query = query.filter(RotaAssignment.user_id == user_id)
    return query.order_by(RotaShift.starts_at.asc()).all()


def _pct(part, whole):
    return int(round(100.0 * part / whole)) if whole else None


def _when(value, fmt='%d %b %Y %H:%M'):
    return value.strftime(fmt) if value else ''


# ---------------------------------------------------------------------------
# The report
# ---------------------------------------------------------------------------

def attendance(db_session, rota_ids=None, start=None, end=None, user_id=None,
               now=None):
    """Both readings plus the headline figures, in one pass."""
    now = now or datetime.now()
    rows = _assignments(db_session, rota_ids, start, end, user_id)

    # Resolve each rota's grace windows once, not once per assignment.
    grace_cache = {}

    def _graces_for(rota):
        if rota.id not in grace_cache:
            grace_cache[rota.id] = graces(rota)
        return grace_cache[rota.id]

    people = {}
    detail = []
    totals = {'held': 0, 'past': 0, 'attended': 0, 'late_in': 0,
              'late_out': 0, 'missed': 0, 'recorded': 0, 'minutes': 0}

    for row in rows:
        shift = row.shift
        signin_grace, signoff_grace, _ = _graces_for(row.rota)
        status = row.status_at(now, signin_grace, signoff_grace)
        # "Has happened" means the shift has ended. A shift running right now
        # is neither attendance nor absence yet.
        is_past = shift.ends_at <= now

        bucket = people.setdefault(row.user_id, {
            'user_id': row.user_id,
            'person': person_name(row.user),
            'held': 0, 'past': 0, 'attended': 0, 'late_in': 0,
            'late_out': 0, 'missed': 0, 'minutes': 0,
        })

        bucket['held'] += 1
        totals['held'] += 1
        if is_past:
            bucket['past'] += 1
            totals['past'] += 1
        if row.attended:
            bucket['attended'] += 1
            totals['attended'] += 1
        if row.signin_was_late:
            bucket['late_in'] += 1
            totals['late_in'] += 1
        if row.signoff_was_late:
            bucket['late_out'] += 1
            totals['late_out'] += 1
        if status in MISSED_STATUSES:
            bucket['missed'] += 1
            totals['missed'] += 1
        if row.recorded_by:
            totals['recorded'] += 1
        worked = row.worked_minutes
        if worked:
            bucket['minutes'] += worked
            totals['minutes'] += worked

        detail.append({
            'date': shift.shift_date.strftime('%d %b %Y'),
            'shift': shift.time_label,
            'label': shift.label or '',
            'rota': row.rota.name,
            'person': person_name(row.user),
            'status': STATUS_TEXT.get(status, status),
            'signed_in': _when(row.signed_in_at, '%H:%M'),
            'signed_off': _when(row.signed_off_at, '%H:%M'),
            'late_in': 'Yes' if row.signin_was_late else '',
            'late_out': 'Yes' if row.signoff_was_late else '',
            'hours': round(worked / 60.0, 2) if worked else '',
            'recorded_by': (person_name(row.recorder)
                            if row.recorded_by else ''),
            'note': (row.note or '')[:200],
            '_sort': shift.starts_at,
        })

    by_person = []
    for bucket in people.values():
        bucket['attendance_pct'] = _pct(bucket['attended'], bucket['past'])
        bucket['hours'] = round(bucket['minutes'] / 60.0, 1)
        by_person.append(bucket)
    by_person.sort(key=lambda b: (-(b['missed']), b['person'].lower()))

    detail.sort(key=lambda d: d['_sort'], reverse=True)
    for item in detail:
        item.pop('_sort', None)

    return {
        'by_person': by_person,
        'by_shift': detail,
        'totals': totals,
        'attendance_pct': _pct(totals['attended'], totals['past']),
        'hours': round(totals['minutes'] / 60.0, 1),
        'start': start,
        'end': end,
        'generated_at': now,
    }


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

_PERSON_COLUMNS = (
    ('person', 'Member', 'left'),
    ('held', 'Shifts held', 'right'),
    ('past', 'Shifts run', 'right'),
    ('attended', 'Attended', 'right'),
    ('missed', 'Missed', 'right'),
    ('late_in', 'Late clock-in', 'right'),
    ('late_out', 'Late clock-out', 'right'),
    ('attendance_pct', 'Attendance %', 'right'),
    ('hours', 'Hours worked', 'right'),
)

_SHIFT_COLUMNS = (
    ('date', 'Date', 'left'),
    ('shift', 'Shift', 'left'),
    ('label', 'Name', 'left'),
    ('rota', 'Rota', 'left'),
    ('person', 'Member', 'left'),
    ('status', 'Status', 'left'),
    ('signed_in', 'Clocked in', 'left'),
    ('signed_off', 'Clocked out', 'left'),
    ('late_in', 'Late in', 'left'),
    ('late_out', 'Late out', 'left'),
    ('hours', 'Hours', 'right'),
    ('recorded_by', 'Recorded by', 'left'),
    ('note', 'Note', 'left'),
)


def to_workbook(report, filename_hint='rota-attendance'):
    """Both readings as a two-sheet .xlsx, returned as a BytesIO.

    Returns (buffer, filename), or (None, None) where openpyxl is missing -
    the caller then offers CSV instead rather than failing the request.
    """
    try:
        from io import BytesIO
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter
    except Exception:                                      # pragma: no cover
        logger.warning('openpyxl is not available - rota report not exported.')
        return None, None

    book = Workbook()
    header_fill = PatternFill('solid', fgColor='8D4D9E')
    header_font = Font(bold=True, color='FFFFFF', size=10)

    summary = {
        'Generated': report['generated_at'].strftime('%d %b %Y %H:%M'),
        'Period': _period_label(report),
        'Shifts held': report['totals']['held'],
        'Shifts run': report['totals']['past'],
        'Attended': report['totals']['attended'],
        'Missed': report['totals']['missed'],
        'Attendance %': report['attendance_pct'],
        'Hours worked': report['hours'],
    }

    sheets = (
        ('By member', _PERSON_COLUMNS, report['by_person'], summary),
        ('By shift', _SHIFT_COLUMNS, report['by_shift'], None),
    )

    first = True
    for title, columns, rows, sheet_summary in sheets:
        sheet = book.active if first else book.create_sheet()
        sheet.title = title
        first = False

        line = 1
        if sheet_summary:
            sheet.cell(row=1, column=1, value='Rota attendance').font = Font(
                bold=True, size=13)
            line = 2
            for label, value in sheet_summary.items():
                sheet.cell(row=line, column=1, value=label).font = Font(
                    bold=True, size=9)
                sheet.cell(row=line, column=2,
                           value='' if value is None else value)
                line += 1
            line += 1

        for index, (_key, label, _align) in enumerate(columns, start=1):
            cell = sheet.cell(row=line, column=index, value=label)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center', vertical='center')
        sheet.freeze_panes = sheet.cell(row=line + 1, column=1)

        widths = [len(label) + 2 for _k, label, _a in columns]
        for offset, row in enumerate(rows, start=1):
            for index, (key, _label, align) in enumerate(columns, start=1):
                value = row.get(key)
                cell = sheet.cell(row=line + offset, column=index,
                                  value='' if value is None else value)
                cell.alignment = Alignment(
                    horizontal='right' if align == 'right' else 'left')
                widths[index - 1] = max(widths[index - 1],
                                        min(60, len(str(value or '')) + 2))
        for index, width in enumerate(widths, start=1):
            sheet.column_dimensions[get_column_letter(index)].width = width

    buffer = BytesIO()
    book.save(buffer)
    buffer.seek(0)
    filename = '{0}-{1}.xlsx'.format(filename_hint,
                                     date.today().strftime('%Y%m%d'))
    return buffer, filename


def to_csv(report, view='by_person'):
    """The fallback export - always available, no dependency."""
    import csv
    from io import StringIO

    columns = _PERSON_COLUMNS if view == 'by_person' else _SHIFT_COLUMNS
    rows = report.get(view) or []

    out = StringIO()
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow([label for _k, label, _a in columns])
    for row in rows:
        writer.writerow([row.get(key, '') for key, _l, _a in columns])
    return out.getvalue()


def _period_label(report):
    start, end = report.get('start'), report.get('end')
    if start and end:
        return '{0} to {1}'.format(start.strftime('%d %b %Y'),
                                   end.strftime('%d %b %Y'))
    if start:
        return 'From {0}'.format(start.strftime('%d %b %Y'))
    if end:
        return 'To {0}'.format(end.strftime('%d %b %Y'))
    return 'All dates'
