"""
Rota module (Workforce).

    Rota -> Shift -> Assignment, and a person clocks in and clocks out.

Eight tables, one blueprint, one routes file. See routes.py for the screens,
service.py for the rules they run under, and alerts.py for the sweep that
raises a notification when a clock-in, a clock-out or a whole shift is missed.

This replaced a build with eighteen tables and five routes files in September
2026. What the old one did that this one does not - escalation ladders,
per-event notification templates, holiday calendars, rota templates, scoped
administration, unavailability, a fourteen-state assignment lifecycle - is in
backup/rota_complex_20260915/ if any of it is ever wanted back.
"""

from .routes import rota_bp

__all__ = ['rota_bp']
