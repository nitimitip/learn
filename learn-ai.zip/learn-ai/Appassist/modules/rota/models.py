"""
models.py - Rota module (Workforce).

THE SHAPE OF THE MODEL
----------------------
Three levels, and nothing between them:

    Rota            one duty roster - a name, a description, a date range.
      -> RotaShift  ONE WORKING WINDOW - Tuesday 09:00-17:00.
        -> RotaAssignment
                    ONE PERSON on that window, with their clock-in and
                    clock-out.

That is the whole containment. The previous build put a PERIOD between the
rota and the shift so that a date range could be sliced into calendar weeks
and months before shifts were cut on the slices. It worked, but a period with
exactly one shift on it - which is what almost every real rota produced - is a
row that exists only to be traversed. The frequency a rota is created with is
now purely an INPUT choice: "day", "week" or "month" decides which dates the
builder generates, and then it is finished. Only the shifts survive it, and
`Rota.frequency` is kept solely so the screens can say how the rota was built.

WHY THE ASSIGNMENT HAS NO STATUS COLUMN
---------------------------------------
Its state is a reading of four facts: has the shift started, has it ended, is
there a clock-in, is there a clock-out. Storing a status beside those would
give
two sources of truth that drift the first time a row is repaired by hand, so
`status` is a property and the evidence is what is stored.

The one exception is a DECISION, which leaves no other trace: an assignment
that was cancelled by an admin. That is the only thing `state` records, and it
has exactly two values.

WHY THERE IS NO ACKNOWLEDGEMENT STEP
------------------------------------
There were three things to do to a shift: accept it, start it, finish it. Two
of them mean "yes I am here", one of them a day early. The brief for this
rebuild asks to clock in and clock out, so accept is gone - a member who is
unhappy with a shift raises a swap request, which is a real answer rather than
a silent refusal to tick a box.

GRACE WINDOWS AND WHAT COUNTS AS MISSED
---------------------------------------
Three columns on the rota, and every alert in the module is one of them
elapsing:

    signin_grace_minutes    after the shift starts, no clock-in  -> late,
                            then missed
    signoff_grace_minutes   after the shift ends, no clock-out   -> missed
    reminder_minutes        before the shift starts              -> reminder

WHAT THE COLUMNS ARE CALLED AND WHAT THE SCREENS SAY
----------------------------------------------------
The stored names are ``signed_in_at``, ``signed_off_at``, ``signin_was_late``
and the two ``*_grace_minutes`` windows. NOTHING USER-FACING SAYS "SIGN IN"
ANY MORE: the module speaks of CLOCKING IN and CLOCKING OUT, because "sign in"
is what a person does to App Assist itself, and reusing it for attendance made
two unrelated acts share a word. The columns keep the old spellings on
purpose - renaming them would rewrite a table, a migration and every row of
the audit trail in order to change a label - and the vocabulary below is the
one place the screens read their words from.

They are read at the moment the sweep runs rather than stamped onto the
assignment. Deadlines were stored in the previous build so that a retuned
grace window could not rewrite what an email had already quoted; this build
sends the deadline as an absolute time in the email text instead, which
answers the same objection without a column that has to be kept in step.
"""

from datetime import datetime, timedelta

from sqlalchemy import (
    Boolean, Column, Date, DateTime, ForeignKey, Index, Integer,
    String, Text, UniqueConstraint,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from database import Base


# ===========================================================================
# Vocabularies
#
# Imported by the service, the alerts, the routes, the emails and the
# templates, so each string is spelled in exactly one place.
# ===========================================================================

# --- How the shifts were generated -----------------------------------------
# An input choice only. See the module docstring.
FREQ_DAY = 'day'
FREQ_WEEK = 'week'
FREQ_MONTH = 'month'
FREQUENCIES = (FREQ_DAY, FREQ_WEEK, FREQ_MONTH)

FREQUENCY_LABELS = {
    FREQ_DAY: 'Single day',
    FREQ_WEEK: 'Week',
    FREQ_MONTH: 'Month',
}

# --- Rota status -----------------------------------------------------------
# Three states, because there are only three questions worth asking: is it
# still being built, is it live, is it over.
STATUS_DRAFT = 'draft'
STATUS_PUBLISHED = 'published'
STATUS_CLOSED = 'closed'
STATUSES = (STATUS_DRAFT, STATUS_PUBLISHED, STATUS_CLOSED)

STATUS_LABELS = {
    STATUS_DRAFT: 'Draft',
    STATUS_PUBLISHED: 'Published',
    STATUS_CLOSED: 'Closed',
}

# Nobody is emailed and nobody is chased while a rota is in draft. That is the
# whole meaning of the state, so it is worth one named constant rather than a
# comparison repeated in the sweep, the publish path and three templates.
LIVE_STATUSES = (STATUS_PUBLISHED,)

# --- Assignment state (the stored decision) --------------------------------
STATE_ACTIVE = 'active'
STATE_CANCELLED = 'cancelled'

# --- Assignment status (derived - see the module docstring) -----------------
ST_DRAFT = 'draft'              # the rota has not been published yet
ST_UPCOMING = 'upcoming'        # published, shift is in the future
ST_DUE = 'due'                  # shift has started, still inside the grace
ST_LATE = 'late'                # grace elapsed, no clock-in, shift still on
ST_ON_SHIFT = 'on_shift'        # clocked in, shift running
ST_TO_SIGN_OFF = 'to_sign_off'  # shift over, clocked in, clock-out due
ST_MISSED_SIGNOFF = 'missed_signoff'
ST_MISSED = 'missed'            # shift over, never clocked in
ST_DONE = 'done'                # clocked in and clocked out
ST_CANCELLED = 'cancelled'

STATUS_TEXT = {
    ST_DRAFT: 'Draft',
    ST_UPCOMING: 'Upcoming',
    ST_DUE: 'Clock in now',
    ST_LATE: 'Clock-in late',
    ST_ON_SHIFT: 'On shift',
    ST_TO_SIGN_OFF: 'Clock out now',
    ST_MISSED_SIGNOFF: 'Clock-out missed',
    ST_MISSED: 'Shift missed',
    ST_DONE: 'Complete',
    ST_CANCELLED: 'Cancelled',
}

# The three the dashboard counts as "needs somebody to do something". Kept as
# one tuple because the dashboard, My shifts and the report must agree on what
# a missed action is.
MISSED_STATUSES = (ST_LATE, ST_MISSED_SIGNOFF, ST_MISSED)

# The two that are a live call to action for the person holding the shift.
ACTION_STATUSES = (ST_DUE, ST_LATE, ST_TO_SIGN_OFF)

# --- Alert kinds -----------------------------------------------------------
# One row per (assignment, kind), so each of these fires at most once per
# assignment however often the sweep runs.
ALERT_REMINDER = 'reminder'
ALERT_MISSED_SIGNIN = 'missed_signin'
ALERT_MISSED_SIGNOFF = 'missed_signoff'
ALERT_MISSED_SHIFT = 'missed_shift'

ALERT_LABELS = {
    ALERT_REMINDER: 'Shift reminder',
    ALERT_MISSED_SIGNIN: 'Clock-in not recorded',
    ALERT_MISSED_SIGNOFF: 'Clock-out not recorded',
    ALERT_MISSED_SHIFT: 'Shift missed',
}

# Which alerts the admins are copied on. A reminder is the member's business;
# a miss is the rota's business, which is why it escalates outward.
ALERT_TO_ADMINS = (ALERT_MISSED_SIGNIN, ALERT_MISSED_SIGNOFF,
                   ALERT_MISSED_SHIFT)

# --- Request kinds ---------------------------------------------------------
REQ_SWAP = 'swap'
REQ_LEAVE = 'leave'
REQUEST_KINDS = (REQ_SWAP, REQ_LEAVE)

REQUEST_LABELS = {
    REQ_SWAP: 'Swap',
    REQ_LEAVE: 'Give up',
}

REQ_OPEN = 'open'
REQ_APPROVED = 'approved'
REQ_DECLINED = 'declined'
REQ_WITHDRAWN = 'withdrawn'

REQUEST_STATE_LABELS = {
    REQ_OPEN: 'Awaiting decision',
    REQ_APPROVED: 'Approved',
    REQ_DECLINED: 'Declined',
    REQ_WITHDRAWN: 'Withdrawn',
}

# --- Audit events ----------------------------------------------------------
AUDIT_EVENTS = {
    'rota.created': 'Rota created',
    'rota.updated': 'Rota updated',
    'rota.published': 'Rota published',
    'rota.closed': 'Rota closed',
    'rota.reopened': 'Rota reopened',
    'rota.deleted': 'Rota deleted',
    'member.added': 'Member added',
    'member.removed': 'Member removed',
    'member.updated': 'Member updated',
    'shift.created': 'Shift created',
    'shift.updated': 'Shift updated',
    'shift.deleted': 'Shift deleted',
    'assignment.created': 'Member assigned',
    'assignment.cancelled': 'Assignment cancelled',
    'assignment.signed_in': 'Clocked in',
    'assignment.signed_off': 'Clocked out',
    'assignment.recorded': 'Attendance recorded by admin',
    'handover.saved': 'Handover saved',
    'request.raised': 'Request raised',
    'request.decided': 'Request decided',
    'request.withdrawn': 'Request withdrawn',
    'alert.sent': 'Alert sent',
    'admin.granted': 'Rota Admin granted',
    'admin.revoked': 'Rota Admin revoked',
}


# ===========================================================================
# Tables
# ===========================================================================

class RotaAdmin(Base):
    """One user granted the Rota Admin role.

    Kept exactly as it was, including the table name: the grant survived the
    rebuild because it is the one piece of the old module that was already as
    simple as it could be. ``scope`` is retained as a nullable column so the
    existing rows still load, but nothing reads it - a Rota Admin administers
    every rota. Scoped administration was one of the things that made the
    module hard to reason about, and an organisation that needs it can say so.
    """
    __tablename__ = 'rota_admins'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False,
                     unique=True)
    scope = Column(String(200))
    added_by = Column(Integer, ForeignKey('users.id'))
    added_at = Column(DateTime, default=func.now())

    user = relationship('User', foreign_keys=[user_id])

    def __repr__(self):
        return '<RotaAdmin user_id={0}>'.format(self.user_id)


class Rota(Base):
    """A duty roster.

    Eleven columns that matter, against the previous build's thirty-four. The
    ones that went were either configuration nobody changed (six booleans
    switching parts of the workflow on and off), scoping fields that made
    visibility hard to predict, or lifecycle timestamps for states that no
    longer exist.
    """
    __tablename__ = 'rotas'

    id = Column(Integer, primary_key=True)

    name = Column(String(200), nullable=False)
    description = Column(Text)
    # WHAT THE PERSON ON SHIFT HAS TO DO, as against `description`, which is
    # what the rota is FOR. The distinction is worth two columns because the
    # two are read at different moments and by different people: a manager
    # picking a rota off the list reads the description, and somebody who has
    # just clocked in reads the instructions. Folding them into one field
    # would mean whichever reader came second got the other one's answer.
    instructions = Column(Text)
    # How the shifts were generated. Input provenance, not behaviour.
    frequency = Column(String(10), nullable=False, default=FREQ_WEEK)
    status = Column(String(12), nullable=False, default=STATUS_DRAFT,
                    index=True)

    # The span the shifts actually cover. Maintained by the service whenever
    # shifts change, so the list screen can show a date range without
    # aggregating over every shift row.
    start_date = Column(Date)
    end_date = Column(Date)

    # Grace windows, in minutes. NULL means "use the site default", which is
    # what the environment variables in alerts.py provide - so an organisation
    # can retune every rota at once, and a single rota can still opt out.
    signin_grace_minutes = Column(Integer)
    signoff_grace_minutes = Column(Integer)
    reminder_minutes = Column(Integer)

    created_by = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    published_at = Column(DateTime)

    owner = relationship('User', foreign_keys=[created_by])
    members = relationship('RotaMember', back_populates='rota',
                           cascade='all, delete-orphan')
    shifts = relationship('RotaShift', back_populates='rota',
                          cascade='all, delete-orphan',
                          order_by='RotaShift.starts_at')

    # ---------------------------------------------------------------- views
    @property
    def status_label(self):
        return STATUS_LABELS.get(self.status, self.status)

    @property
    def frequency_label(self):
        return FREQUENCY_LABELS.get(self.frequency, self.frequency)

    @property
    def is_live(self):
        return self.status in LIVE_STATUSES

    @property
    def has_instructions(self):
        return bool((self.instructions or '').strip())

    @property
    def date_range_label(self):
        """'12 Sep', or '12 Sep - 18 Sep 2026'. Empty when unscheduled."""
        if not self.start_date:
            return ''
        if not self.end_date or self.end_date == self.start_date:
            return self.start_date.strftime('%d %b %Y')
        same_year = self.start_date.year == self.end_date.year
        left = self.start_date.strftime('%d %b' if same_year else '%d %b %Y')
        return '{0} - {1}'.format(left, self.end_date.strftime('%d %b %Y'))

    def __repr__(self):
        return '<Rota {0} {1!r}>'.format(self.id, self.name)


class RotaMember(Base):
    """One person on a rota's roster.

    The roster is who MAY be put on a shift, which is not the same as who is
    on one. Keeping it separate is what makes the assign control a short list
    of the right people rather than every account in the directory.
    """
    __tablename__ = 'rota_members'

    id = Column(Integer, primary_key=True)
    rota_id = Column(Integer, ForeignKey('rotas.id', ondelete='CASCADE'),
                     nullable=False, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False,
                     index=True)
    # A lead sees the whole rota and decides swap requests on it. One extra
    # boolean is the entire role model here; the previous build had five
    # roles, three of which nobody could describe without the source.
    is_lead = Column(Boolean, default=False, nullable=False)
    added_at = Column(DateTime, default=func.now())

    rota = relationship('Rota', back_populates='members')
    user = relationship('User', foreign_keys=[user_id])

    __table_args__ = (
        UniqueConstraint('rota_id', 'user_id', name='uq_rota_member'),
    )

    def __repr__(self):
        return '<RotaMember rota={0} user={1}>'.format(self.rota_id,
                                                       self.user_id)


class RotaShift(Base):
    """One working window on one date.

    ``shift_date`` is redundant against ``starts_at`` for every shift that
    does not cross midnight, and is stored anyway: a night shift beginning
    22:00 Tuesday belongs to Tuesday's column on the schedule grid even though
    most of it happens on Wednesday, and deriving that from starts_at would
    put it in the right place only by accident.
    """
    __tablename__ = 'rota_shifts'

    id = Column(Integer, primary_key=True)
    rota_id = Column(Integer, ForeignKey('rotas.id', ondelete='CASCADE'),
                     nullable=False, index=True)

    shift_date = Column(Date, nullable=False, index=True)
    starts_at = Column(DateTime, nullable=False, index=True)
    ends_at = Column(DateTime, nullable=False)

    # Optional. 'Early', 'Night', 'On call' - shown as a chip where it is set
    # and simply absent where it is not, rather than defaulted to something
    # meaningless like 'Shift 1'.
    label = Column(String(60))
    notes = Column(Text)

    created_at = Column(DateTime, default=func.now())

    rota = relationship('Rota', back_populates='shifts')
    assignments = relationship('RotaAssignment', back_populates='shift',
                               cascade='all, delete-orphan')
    handover = relationship('RotaHandover', back_populates='shift',
                            uselist=False, cascade='all, delete-orphan')

    __table_args__ = (
        Index('ix_rota_shift_rota_date', 'rota_id', 'shift_date'),
    )

    # ---------------------------------------------------------------- views
    @property
    def active_assignments(self):
        return [a for a in self.assignments if a.state == STATE_ACTIVE]

    @property
    def time_label(self):
        """'09:00 - 17:00', with a marker where it runs past midnight."""
        left = self.starts_at.strftime('%H:%M')
        right = self.ends_at.strftime('%H:%M')
        if self.ends_at.date() != self.starts_at.date():
            return '{0} - {1} (+1)'.format(left, right)
        return '{0} - {1}'.format(left, right)

    @property
    def day_label(self):
        return self.shift_date.strftime('%a %d %b')

    @property
    def title(self):
        return self.label or self.time_label

    def is_running(self, now=None):
        now = now or datetime.now()
        return self.starts_at <= now < self.ends_at

    def __repr__(self):
        return '<RotaShift {0} {1}>'.format(self.id, self.starts_at)


class RotaAssignment(Base):
    """One person on one shift.

    The four facts the whole module turns on are here: the two timestamps that
    say what happened, and the two booleans derived from them that say whether
    it happened on time.
    """
    __tablename__ = 'rota_assignments'

    id = Column(Integer, primary_key=True)
    shift_id = Column(Integer, ForeignKey('rota_shifts.id',
                                          ondelete='CASCADE'),
                      nullable=False, index=True)
    # Denormalised from the shift. Every "my shifts" and "this rota's
    # attendance" query filters on it, and the alternative is a join to the
    # shift on every one of them.
    rota_id = Column(Integer, ForeignKey('rotas.id', ondelete='CASCADE'),
                     nullable=False, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False,
                     index=True)

    signed_in_at = Column(DateTime)
    signed_off_at = Column(DateTime)
    # Stamped when the clock-in / clock-out is recorded, by comparing against
    # the grace window IN FORCE AT THAT MOMENT. Retuning the window later
    # therefore never rewrites history, which is the same guarantee the
    # previous build got from storing a deadline column.
    signin_was_late = Column(Boolean, default=False, nullable=False)
    signoff_was_late = Column(Boolean, default=False, nullable=False)

    # Set when an admin records attendance on somebody's behalf - a member who
    # worked the shift but could not reach a browser. Nulled on a self-recorded
    # action, so "did they sign themselves in" stays answerable.
    recorded_by = Column(Integer, ForeignKey('users.id'))

    # The only stored decision. See the module docstring.
    state = Column(String(12), nullable=False, default=STATE_ACTIVE,
                   index=True)
    cancelled_at = Column(DateTime)
    cancel_reason = Column(String(200))

    note = Column(Text)
    created_at = Column(DateTime, default=func.now())

    shift = relationship('RotaShift', back_populates='assignments')
    rota = relationship('Rota')
    user = relationship('User', foreign_keys=[user_id])
    recorder = relationship('User', foreign_keys=[recorded_by])

    __table_args__ = (
        UniqueConstraint('shift_id', 'user_id', name='uq_rota_assignment'),
        Index('ix_rota_assignment_user_state', 'user_id', 'state'),
    )

    # ---------------------------------------------------------------- views
    def status_at(self, now=None, signin_grace=None, signoff_grace=None):
        """The derived status. Everything the module shows reads this.

        The grace windows are passed in rather than looked up, because the
        caller rendering a list of eighty assignments has already resolved
        them once for the rota and should not resolve them eighty more times.
        """
        if self.state == STATE_CANCELLED:
            return ST_CANCELLED

        rota = self.rota or (self.shift.rota if self.shift else None)
        if rota is not None and rota.status == STATUS_DRAFT:
            return ST_DRAFT

        now = now or datetime.now()
        shift = self.shift
        if shift is None:                                  # pragma: no cover
            return ST_UPCOMING

        if self.signed_off_at:
            return ST_DONE

        if self.signed_in_at:
            # Clocked in, so the only question left is the clock-out.
            if now < shift.ends_at:
                return ST_ON_SHIFT
            grace = signoff_grace if signoff_grace is not None else 30
            if now <= shift.ends_at + timedelta(minutes=grace):
                return ST_TO_SIGN_OFF
            return ST_MISSED_SIGNOFF

        # Never clocked in.
        if now < shift.starts_at:
            return ST_UPCOMING
        if now >= shift.ends_at:
            return ST_MISSED
        grace = signin_grace if signin_grace is not None else 15
        if now <= shift.starts_at + timedelta(minutes=grace):
            return ST_DUE
        return ST_LATE

    @property
    def status(self):
        """The status under today's clock and the site default graces.

        Convenient in a template; the list screens call ``status_at`` with the
        rota's own windows instead.
        """
        return self.status_at()

    @property
    def attended(self):
        """Did this person actually work the shift - late or not."""
        return self.signed_in_at is not None

    @property
    def worked_minutes(self):
        """Minutes between clock-in and clock-out, or None."""
        if not (self.signed_in_at and self.signed_off_at):
            return None
        delta = self.signed_off_at - self.signed_in_at
        return max(0, int(delta.total_seconds() // 60))

    def __repr__(self):
        return '<RotaAssignment {0} shift={1} user={2}>'.format(
            self.id, self.shift_id, self.user_id)


class RotaHandover(Base):
    """What the outgoing shift left for whoever comes next.

    One row per shift, not one per person: a handover is the shift's account
    of itself, and two members of the same shift writing competing versions
    is a worse outcome than one of them writing it and the other reading it.
    """
    __tablename__ = 'rota_handovers'

    id = Column(Integer, primary_key=True)
    shift_id = Column(Integer, ForeignKey('rota_shifts.id',
                                          ondelete='CASCADE'),
                      nullable=False, unique=True)
    rota_id = Column(Integer, ForeignKey('rotas.id', ondelete='CASCADE'),
                     nullable=False, index=True)

    summary = Column(Text)
    open_items = Column(Text)

    author_id = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    shift = relationship('RotaShift', back_populates='handover')
    author = relationship('User', foreign_keys=[author_id])

    @property
    def is_empty(self):
        return not ((self.summary or '').strip()
                    or (self.open_items or '').strip())

    def __repr__(self):
        return '<RotaHandover shift={0}>'.format(self.shift_id)


class RotaRequest(Base):
    """A member asking to be taken off a shift.

    Two kinds, and the difference is only whether a replacement is named:
    ``swap`` nominates somebody who has agreed to take it, ``leave`` asks the
    admin to find cover. Approving a swap moves the assignment to the named
    person; approving a leave cancels it and leaves the shift short, which is
    exactly the state the schedule screen is built to make visible.
    """
    __tablename__ = 'rota_requests'

    id = Column(Integer, primary_key=True)
    rota_id = Column(Integer, ForeignKey('rotas.id', ondelete='CASCADE'),
                     nullable=False, index=True)
    assignment_id = Column(Integer, ForeignKey('rota_assignments.id',
                                               ondelete='CASCADE'),
                           nullable=False, index=True)

    kind = Column(String(12), nullable=False)
    state = Column(String(12), nullable=False, default=REQ_OPEN, index=True)

    requested_by = Column(Integer, ForeignKey('users.id'), nullable=False)
    # The nominated replacement on a swap; NULL on a leave request.
    target_user_id = Column(Integer, ForeignKey('users.id'))
    reason = Column(Text)
    created_at = Column(DateTime, default=func.now())

    decided_by = Column(Integer, ForeignKey('users.id'))
    decided_at = Column(DateTime)
    decision_note = Column(Text)

    rota = relationship('Rota')
    assignment = relationship('RotaAssignment')
    requester = relationship('User', foreign_keys=[requested_by])
    target = relationship('User', foreign_keys=[target_user_id])
    decider = relationship('User', foreign_keys=[decided_by])

    @property
    def kind_label(self):
        return REQUEST_LABELS.get(self.kind, self.kind)

    @property
    def state_label(self):
        return REQUEST_STATE_LABELS.get(self.state, self.state)

    @property
    def is_open(self):
        return self.state == REQ_OPEN

    def __repr__(self):
        return '<RotaRequest {0} {1} {2}>'.format(self.id, self.kind,
                                                  self.state)


class RotaAlert(Base):
    """One alert that was raised about one assignment.

    THIS TABLE IS BOTH THE SEND LOG AND THE NOTIFICATION FEED, which is why it
    replaced the previous build's two separate tables. The UNIQUE constraint
    on (assignment_id, kind) is what stops a ten-minute sweep sending the same
    missed-clock-in alert six times an hour: the row is INSERTED FIRST and the
    email sent afterwards, so two processes racing produce one winner and one
    integrity error, and the loser skips rather than duplicates.

    ``emailed`` records whether the send then actually succeeded. A failed
    send leaves the claim in place deliberately - the alert is still true, the
    dashboard still shows it, and a dead SMTP server must not turn into a
    retry loop that floods the mailbox when it comes back.
    """
    __tablename__ = 'rota_alerts'

    id = Column(Integer, primary_key=True)
    assignment_id = Column(Integer, ForeignKey('rota_assignments.id',
                                               ondelete='CASCADE'),
                           nullable=False, index=True)
    rota_id = Column(Integer, ForeignKey('rotas.id', ondelete='CASCADE'),
                     nullable=False, index=True)
    shift_id = Column(Integer, ForeignKey('rota_shifts.id',
                                          ondelete='CASCADE'), index=True)
    # Who the alert is ABOUT. The admins are copied on it; this is the person
    # whose shift it is.
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False,
                     index=True)

    kind = Column(String(24), nullable=False)
    message = Column(String(400))
    created_at = Column(DateTime, default=func.now(), index=True)
    emailed = Column(Boolean, default=False, nullable=False)
    # Cleared from the dashboard feed by the person it belongs to. An admin
    # dismissing somebody else's alert would hide it from the one person who
    # can act on it, so only the owner may.
    seen_at = Column(DateTime)

    assignment = relationship('RotaAssignment')
    rota = relationship('Rota')
    shift = relationship('RotaShift')
    user = relationship('User', foreign_keys=[user_id])

    __table_args__ = (
        UniqueConstraint('assignment_id', 'kind', name='uq_rota_alert'),
        Index('ix_rota_alert_user_seen', 'user_id', 'seen_at'),
    )

    @property
    def kind_label(self):
        return ALERT_LABELS.get(self.kind, self.kind)

    @property
    def is_miss(self):
        return self.kind in ALERT_TO_ADMINS

    def __repr__(self):
        return '<RotaAlert {0} {1} assignment={2}>'.format(
            self.id, self.kind, self.assignment_id)


class RotaAudit(Base):
    """One audited event.

    Append-only by convention - nothing in this module updates or deletes a
    row here, and the delete cascade deliberately does NOT reach it: a rota
    that is deleted leaves its audit trail behind, because "who deleted the
    on-call rota" is exactly the question an audit trail exists to answer.
    That is why rota_id is a plain integer rather than a foreign key.

    Carried across the rebuild unchanged, table and all, so the trail written
    by the previous build still reads on the new screen.
    """
    __tablename__ = 'rota_audit'

    id = Column(Integer, primary_key=True)

    event = Column(String(40), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), index=True)
    # Denormalised so the trail still names the actor after the account is
    # disabled or renamed.
    user_name = Column(String(200))
    at = Column(DateTime, default=func.now(), index=True)

    rota_id = Column(Integer, index=True)
    rota_name = Column(String(200))
    shift_id = Column(Integer)
    assignment_id = Column(Integer)
    subject_user_id = Column(Integer)
    subject_name = Column(String(200))

    field = Column(String(60))
    old_value = Column(Text)
    new_value = Column(Text)
    reason = Column(Text)
    detail = Column(Text)

    __table_args__ = (
        Index('ix_rota_audit_rota_at', 'rota_id', 'at'),
    )

    @property
    def event_label(self):
        return AUDIT_EVENTS.get(self.event, self.event)

    def __repr__(self):
        return '<RotaAudit {0} {1} rota={2}>'.format(self.id, self.event,
                                                     self.rota_id)
