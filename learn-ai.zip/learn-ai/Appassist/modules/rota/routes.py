"""
routes.py - every screen and every action in the rota module.

ONE FILE, because there are now few enough routes to hold in one head. The
previous build needed four (routes, routes_manage, routes_config,
routes_reports) and a fifth for the shared helpers; the configuration screens
it split off no longer exist, and what is left divides cleanly into the six
sections marked below.

THE SCREENS
-----------
    /rota                 Dashboard   what is happening and what needs doing
    /rota/mine            My shifts   clock in, clock out, hand over
    /rota/schedule        Schedule    the week, everyone on it
    /rota/manage          Rotas       admin: the list, and building one

and four secondary screens reached from the module bar rather than the nav -
Requests, Attendance, Audit and Rota Admins.

ACCESS is decided by service.py and stated at the top of every route. The
short version: a Rota Admin manages every rota, a member opens the rotas they
are on and acts on their own shifts only, and nobody clocks in or out as
somebody else. See the service docstring for the whole of it.

CSRF is applied application-wide by csrf_utils.enforce_csrf, so state-changing
routes need no decorator of their own; @csrf_protect is added anyway on the
destructive ones to match the convention the older modules set.
"""

import logging
from datetime import date, datetime, time, timedelta

from flask import (Blueprint, abort, flash, redirect, render_template,
                   request, send_file, url_for)

from auth import get_current_user
from csrf_utils import csrf_protect
from database import get_db_session
from models import User

# `col == sql_true()` rather than `col.is_(True)`: SQLAlchemy renders
# the latter as `col IS 1`, which SQLite accepts and SQL SERVER REJECTS
# - T-SQL allows IS only with NULL. Both compile `== true()` to `= 1`.
from sqlalchemy import true as sql_true
from . import audit, emails, reports, service
from .models import (ACTION_STATUSES, ALERT_LABELS, FREQ_DAY, FREQ_MONTH,
                     FREQ_WEEK, FREQUENCIES, FREQUENCY_LABELS,
                     MISSED_STATUSES, REQ_LEAVE, REQ_OPEN, REQ_SWAP,
                     REQUEST_KINDS, STATE_ACTIVE, STATUS_CLOSED, STATUS_DRAFT,
                     STATUS_LABELS, STATUS_PUBLISHED, STATUS_TEXT, Rota,
                     RotaAdmin, RotaAlert, RotaAssignment, RotaMember,
                     RotaRequest, RotaShift)

logger = logging.getLogger(__name__)

rota_bp = Blueprint('rota', __name__, template_folder='../../templates/rota')

# Monday. The schedule grid and the week expansion both start here; a site
# that runs Sunday-first sets ROTA_WEEK_START=6.
_WEEK_START = service._env_int('ROTA_WEEK_START', 0, minimum=0, maximum=6)


# ===========================================================================
# 0. Helpers
# ===========================================================================

def _clean(value, limit=None):
    """A submitted text value, whitespace collapsed; '' when absent."""
    text = ' '.join((value or '').split())
    return text[:limit] if limit else text


def _clean_multiline(value, limit=None):
    """A submitted textarea, trailing space stripped but line breaks kept."""
    text = (value or '').replace('\r\n', '\n').strip()
    return text[:limit] if limit else text


def _parse_date(value):
    try:
        return datetime.strptime((value or '').strip(), '%Y-%m-%d').date()
    except (TypeError, ValueError):
        return None


def _parse_time(value):
    raw = (value or '').strip()
    for fmt in ('%H:%M', '%H:%M:%S'):
        try:
            return datetime.strptime(raw, fmt).time()
        except ValueError:
            continue
    return None


def _parse_datetime(value):
    raw = (value or '').strip()
    for fmt in ('%Y-%m-%dT%H:%M', '%Y-%m-%d %H:%M'):
        try:
            return datetime.strptime(raw, fmt)
        except ValueError:
            continue
    return None


def _parse_int(value, default=None, minimum=None, maximum=None):
    try:
        number = int(str(value).strip())
    except (TypeError, ValueError):
        return default
    if minimum is not None and number < minimum:
        number = minimum
    if maximum is not None and number > maximum:
        number = maximum
    return number


def _safe_next(value, fallback):
    """A submitted `next` target, accepted only if it stays in this module.

    The action forms carry where to return to, so somebody clocking in from the
    dashboard lands back on the dashboard rather than always on My shifts.
    That value is attacker-shaped input, and handing it to redirect()
    unchecked is the textbook open redirect - so it must be a plain relative
    path under /rota/. A protocol-relative "//evil.example" is rejected too:
    it starts with a slash but is an absolute URL to a browser.
    """
    target = (value or '').strip()
    if (target.startswith('/rota')
            and not target.startswith('//')
            and '\\' not in target):
        return target
    return fallback


def _require_login():
    user = get_current_user()
    if not user:
        return None, redirect(url_for('login'))
    return user, None


def _load_rota(db_session, rota_id):
    rota = db_session.query(Rota).filter_by(id=rota_id).first()
    if rota is None:
        abort(404)
    return rota


def _base(db_session, user, **extra):
    """The context every template in this module expects."""
    context = {
        'user': user,
        'is_admin': service.is_rota_admin(db_session, user),
        'is_system_admin': service.is_system_admin(user),
        'status_labels': STATUS_LABELS,
        'status_text': STATUS_TEXT,
        'frequency_labels': FREQUENCY_LABELS,
        'alert_labels': ALERT_LABELS,
        'missed_statuses': MISSED_STATUSES,
        'action_statuses': ACTION_STATUSES,
    }
    context.update(extra)
    return context


def _own_assignment(db_session, assignment_id, user):
    """An assignment, but only if it is this person's own.

    A 404 rather than a 403 on somebody else's: the answer to "does assignment
    5012 exist" is not one a member is owed.
    """
    row = db_session.query(RotaAssignment).filter_by(
        id=assignment_id).first()
    if row is None or row.user_id != user.id:
        abort(404)
    return row


def _decorate(assignments, now=None):
    """[(assignment, status), ...] with each rota's graces resolved once."""
    now = now or datetime.now()
    cache = {}
    out = []
    for row in assignments:
        rota = row.rota
        if rota is None:                                   # pragma: no cover
            continue
        if rota.id not in cache:
            cache[rota.id] = service.graces(rota)
        signin_grace, signoff_grace, _ = cache[rota.id]
        out.append((row, row.status_at(now, signin_grace, signoff_grace)))
    return out


def _read_windows():
    """The shift time rows from the builder form.

    The form posts three parallel arrays - label, start, end - one entry per
    row the user added. A row with no usable start or end is DROPPED rather
    than failing the whole submission: the rows are added by a script, so a
    stray empty one means the user clicked add and changed their mind, which
    is not a mistake worth rejecting a form over. If every row is empty the
    caller gets an empty list and says "add at least one shift time", which is
    the right message either way.
    """
    labels = request.form.getlist('window_label')
    starts = request.form.getlist('window_start')
    ends = request.form.getlist('window_end')

    windows = []
    for index, start_raw in enumerate(starts):
        start_time = _parse_time(start_raw)
        end_time = _parse_time(ends[index] if index < len(ends) else None)
        if start_time is None or end_time is None:
            continue
        label = _clean(labels[index] if index < len(labels) else '', 60)
        windows.append((label, start_time, end_time))
    return windows


def _read_weekdays():
    """The weekday checkboxes, as a set of Python weekday numbers."""
    out = set()
    for raw in request.form.getlist('weekday'):
        number = _parse_int(raw, minimum=0, maximum=6)
        if number is not None:
            out.add(number)
    return out


# ===========================================================================
# 1. Dashboard
# ===========================================================================

@rota_bp.route('/')
def index():
    """The overview. Open to any signed-in user; what it shows depends on
    whether they administer rotas or merely work them."""
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        # ONE service call. The overview that leads the page comes back
        # inside it, so the cards and the figures above them are counted off
        # the same clock - a dashboard whose header disagrees with the cards
        # under it is worse than no dashboard.
        data = service.dashboard(db_session, user)
        return render_template('rota/dashboard.html', **_base(
            db_session, user, d=data, overview=data['overview'],
            rota_count=data['rota_count'], live_count=data['live_count'],
            now=data['now']))
    finally:
        db_session.close()


@rota_bp.route('/alerts/<int:alert_id>/dismiss', methods=['POST'])
def dismiss_alert(alert_id):
    """Clear one alert from the feed. Only the person it is about may."""
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        alert = db_session.query(RotaAlert).filter_by(id=alert_id).first()
        if alert is None:
            abort(404)
        if service.dismiss_alert(db_session, alert, user):
            db_session.commit()
        else:
            flash('That alert belongs to somebody else.', 'warning')
        return redirect(_safe_next(request.form.get('next'),
                                   url_for('rota.index')))
    finally:
        db_session.close()


# ===========================================================================
# 2. My shifts - clock in, clock out, hand over, ask for a swap
# ===========================================================================

@rota_bp.route('/mine')
def mine():
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        now = datetime.now()
        rows = service.my_assignments(db_session, user,
                                      start=now - timedelta(days=30),
                                      end=now + timedelta(days=90))
        decorated = _decorate(rows, now)

        # Three groups, because they are three different jobs: what needs
        # doing right now, what is coming, and what is finished.
        needs_action = [(a, s) for a, s in decorated if s in ACTION_STATUSES]
        upcoming = [(a, s) for a, s in decorated
                    if a.shift.starts_at > now and s not in ACTION_STATUSES]
        past = [(a, s) for a, s in decorated
                if a.shift.ends_at <= now and s not in ACTION_STATUSES]
        past.reverse()

        my_requests = (db_session.query(RotaRequest)
                       .filter(RotaRequest.requested_by == user.id)
                       .order_by(RotaRequest.created_at.desc())
                       .limit(20).all())

        # Who this person could swap a shift to, per rota.
        swap_targets = {}
        for assignment, _status in needs_action + upcoming:
            if assignment.rota_id in swap_targets:
                continue
            swap_targets[assignment.rota_id] = [
                m for m in service.eligible_members(db_session,
                                                    assignment.rota)
                if m.user_id != user.id]

        return render_template('rota/mine.html', **_base(
            db_session, user, needs_action=needs_action, upcoming=upcoming,
            past=past[:25], my_requests=my_requests,
            swap_targets=swap_targets, now=now,
            req_swap=REQ_SWAP, req_leave=REQ_LEAVE))
    finally:
        db_session.close()


def _member_action(assignment_id, handler):
    """The shape every self-service action shares.

    Load the caller's OWN assignment, run the handler, flash whatever it says
    and return where the form asked. Refusals are flashed as warnings rather
    than aborted, because every one of them is a thing the person can fix -
    "clock in first", "this shift has already started" - and a 403 page says
    none of that.
    """
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        assignment = _own_assignment(db_session, assignment_id, user)
        ok, message = handler(db_session, assignment, user)
        if ok:
            db_session.commit()
            flash(message, 'success')
        else:
            db_session.rollback()
            flash(message, 'warning')
        return redirect(_safe_next(request.form.get('next'),
                                   url_for('rota.mine')))
    finally:
        db_session.close()


@rota_bp.route('/assignments/<int:assignment_id>/clock-in', methods=['POST'])
def clock_in(assignment_id):
    return _member_action(assignment_id, lambda s, a, u:
                          service.clock_in(s, a, u))


@rota_bp.route('/assignments/<int:assignment_id>/clock-out', methods=['POST'])
def clock_out(assignment_id):
    note = _clean_multiline(request.form.get('note'), 2000)
    return _member_action(assignment_id, lambda s, a, u:
                          service.clock_out(s, a, u, note=note))


@rota_bp.route('/assignments/<int:assignment_id>/request', methods=['POST'])
def raise_request(assignment_id):
    """Ask to swap a shift, or to give it up."""
    user, bail = _require_login()
    if bail:
        return bail

    kind = (request.form.get('kind') or '').strip()
    if kind not in REQUEST_KINDS:
        abort(400)
    target_id = _parse_int(request.form.get('target_user_id'))
    reason = _clean_multiline(request.form.get('reason'), 1000)

    db_session = get_db_session()
    try:
        assignment = _own_assignment(db_session, assignment_id, user)
        row, error = service.raise_request(db_session, assignment, user, kind,
                                           target_user_id=target_id,
                                           reason=reason)
        if error:
            db_session.rollback()
            flash(error, 'warning')
        else:
            db_session.commit()
            approvers = service.rota_recipients(db_session, assignment.rota)
            emails.send_request_raised(assignment.rota, row, approvers)
            flash('Request sent. You will be told once it is decided.',
                  'success')
        return redirect(_safe_next(request.form.get('next'),
                                   url_for('rota.mine')))
    finally:
        db_session.close()


@rota_bp.route('/requests/<int:request_id>/withdraw', methods=['POST'])
def withdraw_request(request_id):
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        row = db_session.query(RotaRequest).filter_by(id=request_id).first()
        if row is None:
            abort(404)
        ok, message = service.withdraw_request(db_session, row, user)
        if ok:
            db_session.commit()
            flash(message, 'success')
        else:
            db_session.rollback()
            flash(message, 'warning')
        return redirect(_safe_next(request.form.get('next'),
                                   url_for('rota.mine')))
    finally:
        db_session.close()


@rota_bp.route('/shifts/<int:shift_id>/handover', methods=['GET', 'POST'])
def handover(shift_id):
    """Write what the next shift needs to know.

    Open to anybody who was ON the shift, and to the people who manage the
    rota. A handover written by somebody who was not there is not a handover.
    """
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        shift = db_session.query(RotaShift).filter_by(id=shift_id).first()
        if shift is None:
            abort(404)
        rota = shift.rota
        was_on_it = any(a.user_id == user.id and a.state == STATE_ACTIVE
                        for a in shift.assignments)
        if not (was_on_it or service.can_manage(db_session, rota, user)):
            abort(403)

        if request.method == 'POST':
            if not was_on_it:
                flash('Only somebody who worked this shift can write its '
                      'handover.', 'warning')
                return redirect(url_for('rota.handover', shift_id=shift.id))
            service.save_handover(
                db_session, shift, user,
                _clean_multiline(request.form.get('summary'), 8000),
                _clean_multiline(request.form.get('open_items'), 8000))
            db_session.commit()
            flash('Handover saved.', 'success')
            return redirect(_safe_next(request.form.get('next'),
                                       url_for('rota.mine')))

        return render_template('rota/handover.html', **_base(
            db_session, user, shift=shift, rota=rota,
            handover=shift.handover, was_on_it=was_on_it,
            previous=service.previous_handover(db_session, shift)))
    finally:
        db_session.close()


# ===========================================================================
# 3. Schedule - the week, everyone on it
# ===========================================================================

@rota_bp.route('/schedule')
def schedule():
    """A week at a time. One grid, seven columns, every shift the viewer can
    see - which for an admin is all of them and for a member is the rotas
    they are on."""
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        anchor = _parse_date(request.args.get('week')) or date.today()
        offset = (anchor.weekday() - _WEEK_START) % 7
        first = anchor - timedelta(days=offset)
        days = [first + timedelta(days=i) for i in range(7)]

        start = datetime.combine(days[0], time.min)
        end = datetime.combine(days[-1], time.max)

        rota_ids = service.visible_rota_ids(db_session, user)
        selected = _parse_int(request.args.get('rota'))
        if selected and selected in rota_ids:
            rota_ids = [selected]

        shifts = service.shifts_in_range(db_session, start, end, rota_ids)
        shifts = [s for s in shifts
                  if s.rota is not None
                  and (s.rota.status != STATUS_DRAFT
                       or service.can_manage(db_session, s.rota, user))]

        # Bucketed by the day the shift BELONGS to rather than the day it
        # starts - see RotaShift.shift_date for why those differ.
        by_day = {day: [] for day in days}
        for shift in shifts:
            if shift.shift_date in by_day:
                by_day[shift.shift_date].append(shift)

        return render_template('rota/schedule.html', **_base(
            db_session, user, days=days, by_day=by_day, week_start=days[0],
            prev_week=days[0] - timedelta(days=7),
            next_week=days[0] + timedelta(days=7),
            today=date.today(), now=datetime.now(),
            rotas=service.visible_rotas(db_session, user),
            selected_rota=selected, shift_count=len(shifts)))
    finally:
        db_session.close()


# ===========================================================================
# 4. Manage - the rota list, the builder, the detail screen
# ===========================================================================

@rota_bp.route('/manage')
def manage():
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        if not service.is_rota_admin(db_session, user):
            abort(403)
        search = _clean(request.args.get('q'), 100)
        # The SAME rows the dashboard renders, through the same card macro.
        # Two screens computing "is this rota healthy" two ways is how a
        # rota comes to look fine on one and broken on the other.
        rows = service.rota_overview(db_session, user, search=search or None)
        return render_template('rota/manage.html', **_base(
            db_session, user, rows=rows, search=search,
            open_requests=len(service.open_requests(
                db_session, user, [r['rota'].id for r in rows]))))
    finally:
        db_session.close()


@rota_bp.route('/new', methods=['GET', 'POST'])
@csrf_protect
def create():
    """The builder. ONE screen, five questions, and a rota at the end of it.

        what is it called    name and an optional description
        what is the task     the instructions whoever is on shift works to
        when                 day / week / month, plus the date
        which days           weekday checkboxes (week and month only)
        what hours           one or more time windows
        who is on it         the roster

    The previous build asked thirty-five questions across five cards. Every
    one of them that was not one of these either had a sensible default
    nobody changed or configured a feature this build does not have.
    """
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        if not service.is_rota_admin(db_session, user):
            abort(403)

        if request.method == 'POST':
            name = _clean(request.form.get('name'), 200)
            description = _clean_multiline(request.form.get('description'),
                                           4000)
            # What the person on shift has to DO, as against what the rota is
            # for. Long, because a real runbook is - eight thousand is about
            # two screens of instructions, which is as much as anybody will
            # read off a shift card.
            instructions = _clean_multiline(request.form.get('instructions'),
                                            8000)
            frequency = (request.form.get('frequency') or '').strip()
            anchor = _parse_date(request.form.get('anchor'))
            weekdays = _read_weekdays()
            windows = _read_windows()
            member_ids = [_parse_int(v) for v in
                          request.form.getlist('member_id')]
            member_ids = [m for m in member_ids if m]

            problems = []
            if not name:
                problems.append('Give the rota a name.')
            if frequency not in FREQUENCIES:
                problems.append('Choose whether this covers a day, a week or '
                                'a month.')
            if anchor is None:
                problems.append('Pick the date it covers.')
            if not windows:
                problems.append('Add at least one shift time.')
            if frequency in (FREQ_WEEK, FREQ_MONTH) and not weekdays:
                problems.append('Choose which days of the week are covered.')

            if problems:
                for problem in problems:
                    flash(problem, 'warning')
                return render_template('rota/new.html', **_base(
                    db_session, user, form=request.form,
                    people=_people(db_session),
                    selected_members=member_ids,
                    selected_weekdays=weekdays, today=date.today(),
                    defaults=_site_defaults()))

            rota = Rota(name=name, description=description or None,
                        instructions=instructions or None,
                        frequency=frequency, status=STATUS_DRAFT,
                        signin_grace_minutes=_parse_int(
                            request.form.get('signin_grace'), None, 1, 720),
                        signoff_grace_minutes=_parse_int(
                            request.form.get('signoff_grace'), None, 1, 720),
                        reminder_minutes=_parse_int(
                            request.form.get('reminder'), None, 5, 1440),
                        created_by=user.id)
            db_session.add(rota)
            db_session.flush()
            audit.record(db_session, 'rota.created', actor=user, rota=rota)

            for user_id in member_ids:
                db_session.add(RotaMember(rota_id=rota.id, user_id=user_id,
                                          is_lead=False))
            db_session.flush()

            created, _skipped = service.build_shifts(
                db_session, rota, frequency, anchor, windows,
                weekdays=weekdays, week_start=_WEEK_START, actor=user)
            db_session.commit()

            flash('{0} created with {1} shift{2}. Assign people to the '
                  'shifts, then publish it.'.format(
                      rota.name, created, '' if created == 1 else 's'),
                  'success')
            return redirect(url_for('rota.detail', rota_id=rota.id))

        return render_template('rota/new.html', **_base(
            db_session, user, form={}, people=_people(db_session),
            selected_members=[], selected_weekdays={0, 1, 2, 3, 4},
            today=date.today(), defaults=_site_defaults()))
    finally:
        db_session.close()


def _site_defaults():
    """(signin, signoff, reminder) - the minutes a rota falls back to.

    Shown as the PLACEHOLDER in every grace field, so somebody who leaves the
    box empty can see what will actually happen. An optional setting with a
    visible default is a setting nobody has to think about; an optional
    setting with an empty box is a question.
    """
    return (service.DEFAULT_SIGNIN_GRACE, service.DEFAULT_SIGNOFF_GRACE,
            service.DEFAULT_REMINDER)


def _people(db_session):
    """Every active account, for the member picker."""
    rows = db_session.query(User).filter(User.is_active == sql_true()).all()
    rows.sort(key=lambda u: service.person_name(u).lower())
    return rows


@rota_bp.route('/<int:rota_id>')
def detail(rota_id):
    """One rota: its team, its shifts, and who is on each of them.

    This is where staffing happens, so the shift list is the body of the page
    and everything else is around the edge.
    """
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        rota = _load_rota(db_session, rota_id)
        if not service.can_view(db_session, rota, user):
            abort(403)

        manage_it = service.can_manage(db_session, rota, user)
        now = datetime.now()
        signin_grace, signoff_grace, reminder = service.graces(rota)

        shifts = (db_session.query(RotaShift)
                  .filter(RotaShift.rota_id == rota.id)
                  .order_by(RotaShift.starts_at.asc()).all())

        # Pre-compute each assignment's status once, keyed by id, so the
        # template does not call into the model inside a nested loop.
        statuses = {}
        for shift in shifts:
            for row in shift.assignments:
                statuses[row.id] = row.status_at(now, signin_grace,
                                                 signoff_grace)

        members = (db_session.query(RotaMember)
                   .filter(RotaMember.rota_id == rota.id).all())
        members.sort(key=lambda m: service.person_name(m.user).lower())

        return render_template('rota/detail.html', **_base(
            db_session, user, rota=rota, shifts=shifts, members=members,
            statuses=statuses, can_manage=manage_it,
            stats=service.rota_stats(db_session, rota, now),
            blockers=service.publish_blockers(db_session, rota)
            if manage_it else [],
            people=_people(db_session) if manage_it else [],
            member_ids={m.user_id for m in members},
            graces=(signin_grace, signoff_grace, reminder),
            now=now, today=date.today()))
    finally:
        db_session.close()


def _admin_action(rota_id, handler, redirect_to=None):
    """The shape every rota-management action shares."""
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        rota = _load_rota(db_session, rota_id)
        if not service.can_manage(db_session, rota, user):
            abort(403)
        result = handler(db_session, rota, user)
        db_session.commit()
        if result is not None:
            return result
        return redirect(_safe_next(
            request.form.get('next'),
            redirect_to or url_for('rota.detail', rota_id=rota_id)))
    finally:
        db_session.close()


@rota_bp.route('/<int:rota_id>/edit', methods=['POST'])
@csrf_protect
def edit(rota_id):
    """Rename, re-describe, retune the grace windows. Not the schedule -
    that is what the shift builder on the same page is for."""
    def _apply(db_session, rota, user):
        name = _clean(request.form.get('name'), 200)
        if not name:
            flash('The rota needs a name.', 'warning')
            return None
        old = rota.name
        rota.name = name
        rota.description = _clean_multiline(request.form.get('description'),
                                            4000) or None
        # Only written when the form CARRIES the field. The settings card on
        # the rota page posts it; a form that does not must not silently wipe
        # a runbook somebody spent an afternoon on.
        if 'instructions' in request.form:
            rota.instructions = _clean_multiline(
                request.form.get('instructions'), 8000) or None
        rota.signin_grace_minutes = _parse_int(
            request.form.get('signin_grace'), None, 1, 720)
        rota.signoff_grace_minutes = _parse_int(
            request.form.get('signoff_grace'), None, 1, 720)
        rota.reminder_minutes = _parse_int(request.form.get('reminder'),
                                           None, 5, 1440)
        audit.record(db_session, 'rota.updated', actor=user, rota=rota,
                     field='name' if old != name else None,
                     old_value=old if old != name else None,
                     new_value=name if old != name else None)
        flash('Rota updated.', 'success')
        return None
    return _admin_action(rota_id, _apply)


@rota_bp.route('/<int:rota_id>/delete', methods=['POST'])
@csrf_protect
def delete(rota_id):
    """Remove a rota and everything hanging off it.

    The audit trail survives - it carries no foreign key and is in no cascade,
    which is the point of it. See audit.py.
    """
    def _apply(db_session, rota, user):
        name = rota.name
        audit.record(db_session, 'rota.deleted', actor=user, rota=rota,
                     detail='{0} shift(s)'.format(len(rota.shifts)))
        db_session.delete(rota)
        flash('{0} deleted.'.format(name), 'success')
        return redirect(url_for('rota.manage'))
    return _admin_action(rota_id, _apply)


@rota_bp.route('/<int:rota_id>/publish', methods=['POST'])
@csrf_protect
def publish(rota_id):
    """Make it live and email everybody their own shifts."""
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        rota = _load_rota(db_session, rota_id)
        if not service.can_manage(db_session, rota, user):
            abort(403)

        recipients, error = service.publish(db_session, rota, actor=user)
        if error:
            db_session.rollback()
            flash(error, 'warning')
            return redirect(url_for('rota.detail', rota_id=rota_id))
        db_session.commit()

        sent = 0
        for person, assignments in recipients:
            if emails.send_schedule(rota, person, assignments):
                sent += 1
        flash('{0} is live. {1} member{2} emailed their shifts.'.format(
            rota.name, sent, '' if sent == 1 else 's'), 'success')
        return redirect(url_for('rota.detail', rota_id=rota_id))
    finally:
        db_session.close()


@rota_bp.route('/<int:rota_id>/status', methods=['POST'])
@csrf_protect
def set_status(rota_id):
    """Close a rota, or reopen one that was closed."""
    def _apply(db_session, rota, user):
        wanted = (request.form.get('status') or '').strip()
        if wanted == STATUS_CLOSED:
            service.close_rota(db_session, rota, actor=user)
            flash('{0} closed.'.format(rota.name), 'success')
        elif wanted == STATUS_PUBLISHED:
            service.reopen_rota(db_session, rota, actor=user)
            flash('{0} reopened.'.format(rota.name), 'success')
        else:
            flash('Unknown status.', 'warning')
        return None
    return _admin_action(rota_id, _apply)


# --- the team --------------------------------------------------------------

@rota_bp.route('/<int:rota_id>/members/add', methods=['POST'])
def add_members(rota_id):
    """Add one or more people to the roster."""
    def _apply(db_session, rota, user):
        wanted = {_parse_int(v) for v in request.form.getlist('user_id')}
        wanted.discard(None)
        if not wanted:
            flash('Nobody was selected.', 'warning')
            return None

        existing = {m.user_id for m in db_session.query(RotaMember).filter(
            RotaMember.rota_id == rota.id).all()}
        added = 0
        for user_id in wanted:
            if user_id in existing:
                continue
            person = db_session.query(User).filter_by(id=user_id).first()
            if person is None or not person.is_active:
                continue
            db_session.add(RotaMember(rota_id=rota.id, user_id=user_id,
                                      is_lead=False))
            audit.record(db_session, 'member.added', actor=user, rota=rota,
                         subject=person)
            added += 1
        flash('{0} member{1} added.'.format(added, '' if added == 1 else 's')
              if added else 'They are already on this rota.',
              'success' if added else 'info')
        return None
    return _admin_action(rota_id, _apply)


@rota_bp.route('/<int:rota_id>/members/<int:member_id>/remove',
               methods=['POST'])
@csrf_protect
def remove_member(rota_id, member_id):
    """Take somebody off the roster.

    Refused while they still hold a shift. Removing them silently would leave
    assignments pointing at a person who is no longer on the rota, and the
    honest order of operations is to deal with the shifts first.
    """
    def _apply(db_session, rota, user):
        member = db_session.query(RotaMember).filter_by(
            id=member_id, rota_id=rota.id).first()
        if member is None:
            abort(404)

        held = db_session.query(RotaAssignment).filter(
            RotaAssignment.rota_id == rota.id,
            RotaAssignment.user_id == member.user_id,
            RotaAssignment.state == STATE_ACTIVE).count()
        if held:
            flash('{0} is still on {1} shift{2}. Take them off those first.'
                  .format(service.person_name(member.user), held,
                          '' if held == 1 else 's'), 'warning')
            return None

        audit.record(db_session, 'member.removed', actor=user, rota=rota,
                     subject=member.user)
        db_session.delete(member)
        flash('Removed from the team.', 'success')
        return None
    return _admin_action(rota_id, _apply)


@rota_bp.route('/<int:rota_id>/members/<int:member_id>/lead',
               methods=['POST'])
def toggle_lead(rota_id, member_id):
    """A lead sees the whole rota and decides its swap requests."""
    def _apply(db_session, rota, user):
        member = db_session.query(RotaMember).filter_by(
            id=member_id, rota_id=rota.id).first()
        if member is None:
            abort(404)
        member.is_lead = not member.is_lead
        audit.record(db_session, 'member.updated', actor=user, rota=rota,
                     subject=member.user, field='is_lead',
                     new_value='lead' if member.is_lead else 'member')
        flash('{0} is now {1}.'.format(
            service.person_name(member.user),
            'a rota lead' if member.is_lead else 'a member'), 'success')
        return None
    return _admin_action(rota_id, _apply)


# --- the shifts ------------------------------------------------------------

@rota_bp.route('/<int:rota_id>/shifts/add', methods=['POST'])
def add_shifts(rota_id):
    """Run the builder again to extend an existing rota.

    Shifts that already exist are skipped rather than duplicated, so adding
    Saturday to a rota that already covers Monday to Friday does exactly that.
    """
    def _apply(db_session, rota, user):
        frequency = (request.form.get('frequency') or rota.frequency).strip()
        anchor = _parse_date(request.form.get('anchor'))
        weekdays = _read_weekdays()
        windows = _read_windows()

        if frequency not in FREQUENCIES or anchor is None or not windows:
            flash('Pick the dates and at least one shift time.', 'warning')
            return None
        if frequency in (FREQ_WEEK, FREQ_MONTH) and not weekdays:
            flash('Choose which days of the week are covered.', 'warning')
            return None

        created, skipped = service.build_shifts(
            db_session, rota, frequency, anchor, windows, weekdays=weekdays,
            week_start=_WEEK_START, actor=user)
        if created:
            flash('{0} shift{1} added{2}.'.format(
                created, '' if created == 1 else 's',
                ' ({0} already existed)'.format(skipped) if skipped else ''),
                'success')
        else:
            flash('Nothing to add - those shifts already exist.', 'info')
        return None
    return _admin_action(rota_id, _apply)


@rota_bp.route('/shifts/<int:shift_id>/edit', methods=['POST'])
def edit_shift(shift_id):
    """Change one shift's times, name or notes."""
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        shift = db_session.query(RotaShift).filter_by(id=shift_id).first()
        if shift is None:
            abort(404)
        if not service.can_manage(db_session, shift.rota, user):
            abort(403)

        start_time = _parse_time(request.form.get('start'))
        end_time = _parse_time(request.form.get('end'))
        if start_time and end_time:
            starts_at = datetime.combine(shift.shift_date, start_time)
            ends_at = datetime.combine(shift.shift_date, end_time)
            if ends_at <= starts_at:
                ends_at += timedelta(days=1)
            shift.starts_at = starts_at
            shift.ends_at = ends_at
        shift.label = _clean(request.form.get('label'), 60) or None
        shift.notes = _clean_multiline(request.form.get('notes'), 2000) or None

        audit.record(db_session, 'shift.updated', actor=user, rota=shift.rota,
                     shift=shift)
        db_session.commit()
        flash('Shift updated.', 'success')
        return redirect(_safe_next(request.form.get('next'),
                                   url_for('rota.detail',
                                           rota_id=shift.rota_id)))
    finally:
        db_session.close()


@rota_bp.route('/shifts/<int:shift_id>/delete', methods=['POST'])
@csrf_protect
def delete_shift(shift_id):
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        shift = db_session.query(RotaShift).filter_by(id=shift_id).first()
        if shift is None:
            abort(404)
        rota = shift.rota
        if not service.can_manage(db_session, rota, user):
            abort(403)

        audit.record(db_session, 'shift.deleted', actor=user, rota=rota,
                     shift=shift,
                     detail='{0} {1}'.format(shift.day_label,
                                             shift.time_label))
        db_session.delete(shift)
        db_session.flush()
        service.refresh_span(db_session, rota)
        db_session.commit()
        flash('Shift removed.', 'success')
        return redirect(_safe_next(request.form.get('next'),
                                   url_for('rota.detail', rota_id=rota.id)))
    finally:
        db_session.close()


# --- staffing --------------------------------------------------------------

@rota_bp.route('/shifts/<int:shift_id>/assign', methods=['POST'])
def assign(shift_id):
    """Put one or more people on a shift.

    A clash - the same person already on an overlapping shift - is reported
    and skipped rather than blocking the others in the same submission.
    """
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        shift = db_session.query(RotaShift).filter_by(id=shift_id).first()
        if shift is None:
            abort(404)
        rota = shift.rota
        if not service.can_manage(db_session, rota, user):
            abort(403)

        wanted = {_parse_int(v) for v in request.form.getlist('user_id')}
        wanted.discard(None)
        if not wanted:
            flash('Nobody was selected.', 'warning')
            return redirect(_safe_next(request.form.get('next'),
                                       url_for('rota.detail',
                                               rota_id=rota.id)))

        added = 0
        for user_id in sorted(wanted):
            clash = service.clash_for(db_session, user_id, shift.starts_at,
                                      shift.ends_at,
                                      exclude_shift_id=shift.id)
            if clash is not None:
                flash('{0} is already on {1} at that time.'.format(
                    service.person_name(clash.user),
                    clash.rota.name if clash.rota else 'another shift'),
                    'warning')
                continue
            _row, error = service.assign(db_session, shift, user_id,
                                         actor=user)
            if error:
                flash(error, 'warning')
            else:
                added += 1

        db_session.commit()
        if added:
            flash('{0} assigned to {1} {2}.'.format(
                added, shift.day_label, shift.time_label), 'success')
        return redirect(_safe_next(request.form.get('next'),
                                   url_for('rota.detail', rota_id=rota.id)))
    finally:
        db_session.close()


@rota_bp.route('/assignments/<int:assignment_id>/unassign', methods=['POST'])
@csrf_protect
def unassign(assignment_id):
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        row = db_session.query(RotaAssignment).filter_by(
            id=assignment_id).first()
        if row is None:
            abort(404)
        if not service.can_manage(db_session, row.rota, user):
            abort(403)

        service.unassign(db_session, row, actor=user,
                         reason=_clean(request.form.get('reason'), 200))
        db_session.commit()
        flash('{0} taken off that shift.'.format(
            service.person_name(row.user)), 'success')
        return redirect(_safe_next(request.form.get('next'),
                                   url_for('rota.detail',
                                           rota_id=row.rota_id)))
    finally:
        db_session.close()


@rota_bp.route('/assignments/<int:assignment_id>/record', methods=['POST'])
def record_attendance(assignment_id):
    """An admin recording that somebody did work a shift.

    The only path by which a third party may write a clock-in or clock-out, and
    it stamps who did it. See service.record_attendance.
    """
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        row = db_session.query(RotaAssignment).filter_by(
            id=assignment_id).first()
        if row is None:
            abort(404)
        if not service.can_manage(db_session, row.rota, user):
            abort(403)

        ok, message = service.record_attendance(
            db_session, row, user,
            signed_in_at=_parse_datetime(request.form.get('signed_in_at')),
            signed_off_at=_parse_datetime(request.form.get('signed_off_at')),
            note=_clean_multiline(request.form.get('note'), 2000))
        if ok:
            db_session.commit()
            flash(message, 'success')
        else:
            db_session.rollback()
            flash(message, 'warning')
        return redirect(_safe_next(request.form.get('next'),
                                   url_for('rota.detail',
                                           rota_id=row.rota_id)))
    finally:
        db_session.close()


# ===========================================================================
# 5. Requests queue
# ===========================================================================

@rota_bp.route('/requests')
def requests_queue():
    """Open swap and give-up requests, for the people who decide them."""
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        rota_ids = [r.id for r in service.visible_rotas(db_session, user)]
        if not service.is_rota_admin(db_session, user):
            # A lead decides requests on their own rota and sees no others.
            rota_ids = [rid for rid in rota_ids
                        if service.is_lead(db_session, rid, user)]
            if not rota_ids:
                abort(403)

        rows = service.open_requests(db_session, user, rota_ids)
        decided = (db_session.query(RotaRequest)
                   .filter(RotaRequest.rota_id.in_(tuple(rota_ids)),
                           RotaRequest.state != REQ_OPEN)
                   .order_by(RotaRequest.decided_at.desc())
                   .limit(20).all()) if rota_ids else []

        return render_template('rota/requests.html', **_base(
            db_session, user, rows=rows, decided=decided, now=datetime.now()))
    finally:
        db_session.close()


@rota_bp.route('/requests/<int:request_id>/decide', methods=['POST'])
@csrf_protect
def decide_request(request_id):
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        row = db_session.query(RotaRequest).filter_by(id=request_id).first()
        if row is None:
            abort(404)
        if not service.can_decide_requests(db_session, row.rota, user):
            abort(403)

        approve = (request.form.get('decision') or '') == 'approve'
        message, error = service.decide_request(
            db_session, row, user, approve,
            note=_clean_multiline(request.form.get('note'), 1000))
        if error:
            db_session.rollback()
            flash(error, 'warning')
        else:
            db_session.commit()
            emails.send_request_decided(row.rota, row, approve)
            flash(message, 'success')
        return redirect(_safe_next(request.form.get('next'),
                                   url_for('rota.requests_queue')))
    finally:
        db_session.close()


# ===========================================================================
# 6. Attendance, audit and admins
# ===========================================================================

def _report_window():
    """The report's date range - last 30 days unless asked otherwise."""
    end = _parse_date(request.args.get('to')) or date.today()
    start = _parse_date(request.args.get('from')) or (end -
                                                      timedelta(days=30))
    if start > end:
        start, end = end, start
    return start, end


def _report_scope(db_session, user):
    """Which rotas the report covers, honouring a ?rota= filter."""
    rota_ids = [r.id for r in service.visible_rotas(db_session, user)]
    selected = _parse_int(request.args.get('rota'))
    if selected and selected in rota_ids:
        return [selected], selected
    return rota_ids, None


@rota_bp.route('/reports')
def report_screen():
    """Attendance. A member sees their own record; an admin or lead sees the
    whole rota."""
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        start, end = _report_window()
        rota_ids, selected = _report_scope(db_session, user)
        admin = service.is_rota_admin(db_session, user)
        leads = [rid for rid in rota_ids
                 if service.is_lead(db_session, rid, user)]
        whole_rota = admin or bool(leads)

        report = reports.attendance(
            db_session, rota_ids=rota_ids, start=start, end=end,
            user_id=None if whole_rota else user.id)

        return render_template('rota/reports.html', **_base(
            db_session, user, report=report, start=start, end=end,
            rotas=service.visible_rotas(db_session, user),
            selected_rota=selected, whole_rota=whole_rota))
    finally:
        db_session.close()


@rota_bp.route('/reports/export')
def report_export():
    """The same report as a two-sheet workbook, or CSV where openpyxl is
    missing."""
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        start, end = _report_window()
        rota_ids, _selected = _report_scope(db_session, user)
        admin = service.is_rota_admin(db_session, user)
        leads = any(service.is_lead(db_session, rid, user)
                    for rid in rota_ids)

        report = reports.attendance(
            db_session, rota_ids=rota_ids, start=start, end=end,
            user_id=None if (admin or leads) else user.id)

        buffer, filename = reports.to_workbook(report)
        if buffer is None:
            from flask import Response
            body = reports.to_csv(report, view=request.args.get(
                'view', 'by_person'))
            return Response(
                body, mimetype='text/csv',
                headers={'Content-Disposition':
                         'attachment; filename=rota-attendance.csv'})
        return send_file(
            buffer, as_attachment=True, download_name=filename,
            mimetype='application/vnd.openxmlformats-officedocument.'
                     'spreadsheetml.sheet')
    finally:
        db_session.close()


@rota_bp.route('/audit')
def audit_history():
    """Who changed what. Rota Admins only - it names people and decisions."""
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        if not service.is_rota_admin(db_session, user):
            abort(403)
        rota_id = _parse_int(request.args.get('rota'))
        rows = audit.trail(db_session, rota_id=rota_id, limit=400)
        return render_template('rota/audit.html', **_base(
            db_session, user, rows=rows, selected_rota=rota_id,
            rotas=service.visible_rotas(db_session, user)))
    finally:
        db_session.close()


@rota_bp.route('/admins')
def admins():
    """Who may administer rotas. Application admins only."""
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        if not service.is_system_admin(user):
            abort(403)
        rows = (db_session.query(RotaAdmin)
                .order_by(RotaAdmin.added_at.desc()).all())
        granted = {r.user_id for r in rows}
        return render_template('rota/admins.html', **_base(
            db_session, user, rows=rows,
            candidates=[p for p in _people(db_session)
                        if p.id not in granted]))
    finally:
        db_session.close()


@rota_bp.route('/admins/add', methods=['POST'])
def add_admin():
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        if not service.is_system_admin(user):
            abort(403)
        user_id = _parse_int(request.form.get('user_id'))
        person = (db_session.query(User).filter_by(id=user_id).first()
                  if user_id else None)
        if person is None:
            flash('Choose somebody to grant it to.', 'warning')
            return redirect(url_for('rota.admins'))

        existing = db_session.query(RotaAdmin).filter_by(
            user_id=user_id).first()
        if existing is not None:
            flash('{0} is already a Rota Admin.'.format(
                service.person_name(person)), 'info')
            return redirect(url_for('rota.admins'))

        db_session.add(RotaAdmin(user_id=user_id, added_by=user.id))
        audit.record(db_session, 'admin.granted', actor=user, subject=person)
        db_session.commit()
        flash('{0} can now administer rotas.'.format(
            service.person_name(person)), 'success')
        return redirect(url_for('rota.admins'))
    finally:
        db_session.close()


@rota_bp.route('/admins/<int:admin_id>/remove', methods=['POST'])
@csrf_protect
def remove_admin(admin_id):
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        if not service.is_system_admin(user):
            abort(403)
        row = db_session.query(RotaAdmin).filter_by(id=admin_id).first()
        if row is None:
            abort(404)
        person = row.user
        audit.record(db_session, 'admin.revoked', actor=user, subject=person)
        db_session.delete(row)
        db_session.commit()
        flash('{0} is no longer a Rota Admin.'.format(
            service.person_name(person)), 'success')
        return redirect(url_for('rota.admins'))
    finally:
        db_session.close()


@rota_bp.route('/about')
def about():
    """How the module works, in the reader's terms rather than the model's."""
    user, bail = _require_login()
    if bail:
        return bail

    db_session = get_db_session()
    try:
        return render_template('rota/about.html', **_base(
            db_session, user, defaults=_site_defaults()))
    finally:
        db_session.close()
