"""
audit.py - Rota audit trail (FR-098, FR-099).

One function does the writing. Every material change in the module calls it,
and nothing else writes to rota_audit, so the trail has exactly one shape.

THREE RULES THIS FILE ENFORCES
------------------------------
1. THE TRAIL OUTLIVES ITS SUBJECT. rota_audit carries no foreign keys and is
   not in any cascade, and the names of the actor, the rota and the subject
   are copied in as text. A deleted rota, a disabled account and a renamed
   user all leave a trail that still reads.

2. AUDITING NEVER BREAKS THE ACTION. ``record()`` swallows its own errors and
   logs them. An audit row that cannot be written is a serious operational
   problem, but refusing somebody's clock-out because of it is a worse one -
   and the application log still carries the event either way.

3. THE CALLER DOES NOT COMMIT. ``record()`` adds to the session it is handed
   and leaves the commit to the transaction that is already in progress, so
   the audit row lands with the change it describes or not at all.
"""

import logging

from .models import RotaAudit

logger = logging.getLogger(__name__)

# Nothing useful comes of storing 40KB of pasted runbook in an audit column,
# and a trail screen that has to render it becomes unusable.
_VALUE_LIMIT = 2000


def _name_of(user):
    """A person's display name, falling back through what is actually set."""
    if user is None:
        return None
    first = (getattr(user, 'firstname', '') or '').strip()
    last = (getattr(user, 'lastname', '') or '').strip()
    full = ' '.join(part for part in (first, last) if part)
    return full or getattr(user, 'username', None) or None


def _clip(value):
    if value is None:
        return None
    text = value if isinstance(value, str) else str(value)
    return text[:_VALUE_LIMIT]


def record(db_session, event, actor=None, rota=None, shift=None,
           assignment=None, subject=None, field=None, old_value=None,
           new_value=None, reason=None, detail=None):
    """Write one audit row. Never raises.

    ``rota``, ``shift``, ``assignment`` and ``subject`` take the ORM objects
    where the caller has them; the ids and names are lifted off here so no
    caller has to remember which pieces the trail wants.
    """
    try:
        rota_id = getattr(rota, 'id', None)
        if rota_id is None and assignment is not None:
            rota_id = getattr(assignment, 'rota_id', None)
        if rota_id is None and shift is not None:
            rota_id = getattr(shift, 'rota_id', None)

        row = RotaAudit(
            event=event,
            user_id=getattr(actor, 'id', None),
            user_name=_name_of(actor) or 'system',
            rota_id=rota_id,
            rota_name=_clip(getattr(rota, 'name', None)),
            shift_id=(getattr(shift, 'id', None)
                      or getattr(assignment, 'shift_id', None)),
            assignment_id=getattr(assignment, 'id', None),
            subject_user_id=(getattr(subject, 'id', None)
                             or getattr(assignment, 'user_id', None)),
            subject_name=_name_of(subject),
            field=_clip(field),
            old_value=_clip(old_value),
            new_value=_clip(new_value),
            reason=_clip(reason),
            detail=_clip(detail),
        )
        db_session.add(row)
        return row
    except Exception:                                      # pragma: no cover
        logger.exception('Could not record rota audit event %r.', event)
        return None


def trail(db_session, rota_id=None, user_id=None, event=None, since=None,
          until=None, limit=500):
    """Read the audit trail, newest first.

    Every argument narrows; none of them is required, so the same query backs
    the per-rota history tab and the module-wide Audit History screen.
    """
    query = db_session.query(RotaAudit)
    if rota_id:
        query = query.filter(RotaAudit.rota_id == rota_id)
    if user_id:
        query = query.filter(RotaAudit.user_id == user_id)
    if event:
        query = query.filter(RotaAudit.event == event)
    if since:
        query = query.filter(RotaAudit.at >= since)
    if until:
        query = query.filter(RotaAudit.at <= until)
    return (query.order_by(RotaAudit.at.desc(), RotaAudit.id.desc())
            .limit(limit).all())
