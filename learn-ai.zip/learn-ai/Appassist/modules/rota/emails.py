"""
emails.py - every message the rota module sends.

FIVE MESSAGES, and that is the complete list:

    send_schedule        the rota was published - here are your shifts
    send_reminder        your shift starts shortly
    send_miss_alert      a clock-in, a clock-out or a whole shift was missed
    send_request_raised  somebody wants off a shift - a decision is needed
    send_request_decided the answer

The previous build had fifteen, configurable per event through a template
table an administrator maintained. The table is gone. Wording that can be
edited in two places is wording nobody can predict, and the events that were
worth overriding were the ones this module no longer raises.

All five share one envelope so they read as one product, and the design rules
are the ones the rest of the application already follows:

  * 100% nested <table> layout - no <div>s for structure.
  * State is a tint fill plus a hairline on ALL FOUR sides, never a coloured
    stripe down one edge.
  * Labels are PRE-UPPERCASED in Python (the Word engine ignores
    text-transform).
  * Solid colours only; a bgcolor attribute accompanies every
    background-color.
  * A multipart/alternative plain-text part is always included.

The masthead, footer and palette come from the shared email_theme, so a colour
is defined once for the whole application.

THE DEEP LINK is opt-in. ROTA_APP_BASE_URL (e.g. https://appassist/) turns the
"Open the rota" button on. Unset - the default - the email says to open
App Assist instead of inventing a hostname that may not resolve from wherever
the reader opens their mail.
"""

import logging
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from email_theme import (CHIP_BG, CHIP_BORDER, CHIP_FG, FONT, NPG_BORDER,
                         NPG_DARK, NPG_INK, NPG_LIGHT, NPG_RED,
                         NPG_TEXT_MUTED, badge, button, callout, footer_rows,
                         hero_rows, section_label, tone)

from .models import (ALERT_MISSED_SHIFT, ALERT_MISSED_SIGNIN,
                     ALERT_MISSED_SIGNOFF, REQ_SWAP)

logger = logging.getLogger(__name__)

# SMTP - the shared convention across this application.
_SMTP_SERVER = os.environ.get('SMTP_SERVER', 'mail1.northernpowergrid.com')
_SMTP_PORT = int(os.environ.get('SMTP_PORT', '25'))
_EMAIL_FROM = os.environ.get('EMAIL_FROM',
                             'NPgAppAssist@northernpowergrid.com')

# Optional deep link - see the module docstring.
_BASE_URL = (os.environ.get('ROTA_APP_BASE_URL') or '').strip().rstrip('/')

_FOOTER_LINE = 'Workforce &middot; Rota'

# What each miss means, in the reader's terms. The tuple is
# (subject verb, headline, what the reader should do about it).
_MISS_COPY = {
    ALERT_MISSED_SIGNIN: (
        'Clock-in missing',
        'You have not clocked in',
        'Clock in now if you are on shift. If you cannot work it, tell your '
        'rota admin straight away so the shift can be covered.',
    ),
    ALERT_MISSED_SIGNOFF: (
        'Clock-out missing',
        'You have not clocked out',
        'Clock out to close the shift. If you are still working, clock out '
        'as soon as you finish.',
    ),
    ALERT_MISSED_SHIFT: (
        'Shift missed',
        'A shift was missed',
        'Nobody clocked in for this shift. If it was worked, ask a rota '
        'admin to record the attendance so the record is right.',
    ),
}

_MISS_TONE = {
    ALERT_MISSED_SIGNIN: 'warn',
    ALERT_MISSED_SIGNOFF: 'warn',
    ALERT_MISSED_SHIFT: 'stop',
}


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

def _esc(value) -> str:
    """HTML-escape. Every piece of user text goes through this."""
    if value is None:
        return ''
    return (str(value).replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;').replace('"', '&quot;'))


def _name(person) -> str:
    if person is None:
        return 'there'
    first = (getattr(person, 'firstname', '') or '').strip()
    last = (getattr(person, 'lastname', '') or '').strip()
    full = ' '.join(part for part in (first, last) if part)
    return full or getattr(person, 'username', None) or 'there'


def _first_name(person) -> str:
    return _name(person).split()[0] if _name(person) != 'there' else 'there'


def _link() -> str:
    return '{0}/rota'.format(_BASE_URL) if _BASE_URL else ''


def _when(value) -> str:
    """'Tue 16 Sep, 09:00' - the one date format every rota email uses."""
    return value.strftime('%a %d %b, %H:%M') if value else ''


def _shift_line(shift) -> str:
    """'Tue 16 Sep, 09:00 - 17:00' plus the label where there is one."""
    left = shift.starts_at.strftime('%a %d %b, %H:%M')
    right = shift.ends_at.strftime('%H:%M')
    if shift.ends_at.date() != shift.starts_at.date():
        right = shift.ends_at.strftime('%H:%M (%a %d %b)')
    line = '{0} - {1}'.format(left, right)
    return '{0}  [{1}]'.format(line, shift.label) if shift.label else line


# ---------------------------------------------------------------------------
# The envelope
# ---------------------------------------------------------------------------

def _envelope(preheader, hero_html, body_html, subject_title) -> str:
    """The shared HTML document every rota email is poured into."""
    footer = footer_rows(_FOOTER_LINE)
    return """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>NPG App Assist &mdash; {title}</title>
  <!--[if mso]>
  <xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch><o:AllowPNG/></o:OfficeDocumentSettings></xml>
  <style type="text/css">table {{border-collapse:collapse;}} td {{mso-line-height-rule:exactly;}}</style>
  <![endif]-->
  <style type="text/css">
    body, table, td {{ -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }}
    table {{ border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }}
    a {{ color:{red}; text-decoration:none; }}
    @media only screen and (max-width:620px) {{
      .container {{ width:100% !important; }}
      .px-32 {{ padding-left:18px !important; padding-right:18px !important; }}
    }}
  </style>
</head>
<body style="margin:0;padding:0;background-color:{light};font-family:{font};">
<div style="display:none;font-size:1px;color:{light};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
{preheader}
</div>

<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="{light}" style="background-color:{light};">
  <tr><td align="center" style="padding:34px 16px 40px 16px;">
    <!--[if mso]><table role="presentation" align="center" cellpadding="0" cellspacing="0" border="0" width="600"><tr><td><![endif]-->
    <table role="presentation" class="container" cellpadding="0" cellspacing="0" border="0" width="600"
           style="width:600px;max-width:600px;background-color:#FFFFFF;border:1px solid {border};border-bottom-color:#C6D0DE;border-collapse:separate;border-spacing:0;border-radius:14px;">
      {hero}
      {body}
      {footer}
    </table>
    <!--[if mso]></td></tr></table><![endif]-->
  </td></tr>
</table>
</body>
</html>""".format(title=_esc(subject_title), red=NPG_RED, light=NPG_LIGHT,
                  font=FONT, border=NPG_BORDER, preheader=_esc(preheader),
                  hero=hero_html, body=body_html, footer=footer)


def _band(inner_html, top=24, bottom=0) -> str:
    """One padded content row inside the envelope."""
    return ('<tr><td class="px-32" style="padding:{0}px 32px {1}px 32px;">{2}'
            '</td></tr>').format(top, bottom, inner_html)


def _paragraph(text_html, size=14) -> str:
    return ('<p style="margin:0 0 12px 0;font-family:{0};font-size:{1}px;'
            'color:{2};mso-line-height-rule:exactly;line-height:22px;">{3}'
            '</p>').format(FONT, size, NPG_INK, text_html)


def _multiline(value, size=13) -> str:
    """User text with its line breaks kept, as one paragraph per block.

    Instructions are written in a textarea and people press Return in them.
    Escaping the text and then handing it to a single <p> would run a
    numbered list into one sentence, so each non-empty line becomes its own
    paragraph - which is the reading that survives every mail client,
    including the Word engine, without a <br> or a <pre>.
    """
    lines = [line.strip() for line in str(value or '').splitlines()]
    return ''.join(_paragraph(_esc(line), size=size) for line in lines if line)


def _instruction_lines(rota, heading='What the shift involves:'):
    """The same instructions for the plain-text alternative."""
    body = (rota.instructions or '').strip()
    if not body:
        return []
    return ['', heading, ''] + ['  ' + line.strip()
                                for line in body.splitlines() if line.strip()]


def _instruction_band(rota, heading='WHAT THE SHIFT INVOLVES'):
    """The rota's instructions, or nothing at all.

    Sent with the schedule and with every reminder, because the one moment
    somebody wants the runbook is the moment their shift is about to start -
    and an email they already have beats a screen they have to go and find.
    """
    if not (rota.instructions or '').strip():
        return ''
    return _band(section_label(heading) + _multiline(rota.instructions),
                 top=20)


def _shift_table(shifts, show_person=False) -> str:
    """The shifts, as a bordered table. The centrepiece of most of these."""
    header = ('<tr>'
              '<td bgcolor="#F2F5FA" style="background-color:#F2F5FA;'
              'padding:9px 14px;font-family:{font};font-size:10px;'
              'font-weight:bold;color:{muted};letter-spacing:1.1px;'
              'border-bottom:1px solid {border};">WHEN</td>'
              '<td bgcolor="#F2F5FA" style="background-color:#F2F5FA;'
              'padding:9px 14px;font-family:{font};font-size:10px;'
              'font-weight:bold;color:{muted};letter-spacing:1.1px;'
              'border-bottom:1px solid {border};">{second}</td>'
              '</tr>').format(font=FONT, muted=NPG_TEXT_MUTED,
                              border=NPG_BORDER,
                              second='WHO' if show_person else 'ROTA')

    rows = []
    for item in shifts:
        shift = getattr(item, 'shift', item)
        right = (_name(getattr(item, 'user', None)) if show_person
                 else getattr(getattr(shift, 'rota', None), 'name', ''))
        rows.append(
            '<tr>'
            '<td style="padding:11px 14px;font-family:{font};font-size:13px;'
            'color:{ink};border-bottom:1px solid {border};'
            'mso-line-height-rule:exactly;line-height:19px;">'
            '<strong>{when}</strong></td>'
            '<td style="padding:11px 14px;font-family:{font};font-size:13px;'
            'color:{muted};border-bottom:1px solid {border};'
            'mso-line-height-rule:exactly;line-height:19px;">{right}</td>'
            '</tr>'.format(font=FONT, ink=NPG_DARK, muted=NPG_TEXT_MUTED,
                           border=NPG_BORDER, when=_esc(_shift_line(shift)),
                           right=_esc(right)))

    return ('<table role="presentation" cellpadding="0" cellspacing="0" '
            'border="0" width="100%" style="width:100%;border:1px solid {0};'
            'border-collapse:separate;border-spacing:0;border-radius:10px;'
            'overflow:hidden;">{1}{2}</table>').format(
                NPG_BORDER, header, ''.join(rows))


def _action_band(note) -> str:
    """The closing band: the deep link when configured, the note either way."""
    action = ''
    if _link():
        action = ('<table role="presentation" cellpadding="0" cellspacing="0" '
                  'border="0"><tr><td style="padding-bottom:14px;">{0}</td>'
                  '</tr></table>'.format(button(_link(), 'Open the rota')))
    return _band(
        '{0}<table role="presentation" cellpadding="0" cellspacing="0" '
        'border="0" width="100%" style="border-top:1px solid {1};">'
        '<tr><td style="padding-top:14px;font-family:{2};font-size:12px;'
        'color:{3};mso-line-height-rule:exactly;line-height:18px;">{4}</td>'
        '</tr></table>'.format(action, NPG_LIGHT, FONT, NPG_TEXT_MUTED,
                               _esc(note)),
        top=20, bottom=26)


def _chip(label) -> str:
    return badge(CHIP_BG, CHIP_FG, _esc(label).upper(), CHIP_BORDER)


def _send(to_addresses, cc_addresses, subject, html, text,
          priority='3') -> bool:
    """Send one message. Never raises - a bad address must not abort a sweep."""
    to_addresses = [a for a in (to_addresses or []) if a]
    cc_addresses = [a for a in (cc_addresses or [])
                    if a and a not in to_addresses]
    if not to_addresses:
        logger.warning('Rota email %r has no recipient - skipped.', subject)
        return False
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = _EMAIL_FROM
        msg['To'] = ', '.join(to_addresses)
        if cc_addresses:
            msg['Cc'] = ', '.join(cc_addresses)
        msg['X-Priority'] = priority
        msg.attach(MIMEText(text, 'plain', 'utf-8'))
        msg.attach(MIMEText(html, 'html', 'utf-8'))
        with smtplib.SMTP(_SMTP_SERVER, _SMTP_PORT, timeout=30) as server:
            server.send_message(msg, to_addrs=to_addresses + cc_addresses)
        logger.info('Rota email sent: %r -> %s', subject,
                    ', '.join(to_addresses))
        return True
    except smtplib.SMTPException as exc:
        logger.error('SMTP error sending rota email %r to %s: %s',
                     subject, ', '.join(to_addresses), exc)
        return False
    except Exception:
        logger.exception('Unexpected error sending rota email %r.', subject)
        return False


def _text_body(greeting, lines, closing) -> str:
    """The plain-text alternative. Always sent, never an afterthought."""
    parts = [greeting, '']
    parts.extend(lines)
    parts.extend(['', closing, '',
                  'Open the rota: {0}'.format(_link()) if _link()
                  else 'Open App Assist to reach the rota.',
                  '', 'NPG App Assist - Workforce / Rota'])
    return '\n'.join(parts)


# ===========================================================================
# 1. The schedule
# ===========================================================================

def send_schedule(rota, person, assignments) -> bool:
    """'The rota is published, here are your shifts.'"""
    if not assignments or not getattr(person, 'email', None):
        return False

    count = len(assignments)
    subject = 'Your shifts on {0}'.format(rota.name)
    chips = [_chip('{0} shift{1}'.format(count, '' if count == 1 else 's'))]
    if rota.date_range_label:
        chips.append(_chip(rota.date_range_label))

    hero = hero_rows(eyebrow='ROTA PUBLISHED', title=_esc(rota.name),
                     chips=chips,
                     subtitle='Your shifts are confirmed below.')

    body = [
        _band(_paragraph('Hello {0},'.format(_esc(_first_name(person)))) +
              _paragraph('{0} has been published. These are the shifts you '
                         'are on.'.format(_esc(rota.name)))),
        _band(_shift_table(assignments), top=6),
    ]
    if rota.description:
        body.append(_band(section_label('ABOUT THIS ROTA') +
                          _paragraph(_esc(rota.description), size=13), top=20))
    body.append(_instruction_band(rota))
    body.append(_band(callout(
        'info', 'Clock in and clock out',
        'Open the rota when your shift starts and press Clock in. Press '
        'Clock out when you finish. If either is missed you and the rota '
        'admins are told automatically.'), top=20))
    body.append(_action_band(
        'You are receiving this because you are on the {0} rota.'.format(
            rota.name)))

    html = _envelope('Your shifts on {0}'.format(rota.name), hero,
                     ''.join(body), subject)
    text = _text_body(
        'Hello {0},'.format(_first_name(person)),
        ['{0} has been published. Your shifts:'.format(rota.name), ''] +
        ['  ' + _shift_line(a.shift) for a in assignments] +
        _instruction_lines(rota),
        'Clock in when your shift starts and clock out when you finish.')
    return _send([person.email], [], subject, html, text)


# ===========================================================================
# 2. The reminder
# ===========================================================================

def send_reminder(rota, assignment, person) -> bool:
    """'Your shift starts shortly.' The only email that is not about a
    problem, and the one that prevents most of the ones that are."""
    if not getattr(person, 'email', None):
        return False

    shift = assignment.shift
    subject = 'Your shift starts at {0}'.format(
        shift.starts_at.strftime('%H:%M'))

    hero = hero_rows(eyebrow='SHIFT REMINDER', title='Starting shortly',
                     chips=[_chip(rota.name),
                            _chip(shift.starts_at.strftime('%H:%M'))],
                     subtitle=_esc(_shift_line(shift)))

    body = [
        _band(_paragraph('Hello {0},'.format(_esc(_first_name(person)))) +
              _paragraph('Your next shift on <strong>{0}</strong> starts at '
                         '<strong>{1}</strong>.'.format(
                             _esc(rota.name),
                             _esc(_when(shift.starts_at))))),
        _band(_shift_table([assignment]), top=6),
        _instruction_band(rota),
        _band(callout('info', 'Remember to clock in',
                      'Open the rota when the shift starts and press Clock '
                      'in, so the record shows you are on.'), top=20),
        _action_band('A reminder from the {0} rota.'.format(rota.name)),
    ]
    html = _envelope('Your shift starts at {0}'.format(
        shift.starts_at.strftime('%H:%M')), hero, ''.join(body), subject)
    text = _text_body(
        'Hello {0},'.format(_first_name(person)),
        ['Your next shift on {0} starts shortly:'.format(rota.name), '',
         '  ' + _shift_line(shift)] + _instruction_lines(rota),
        'Remember to clock in when it starts.')
    return _send([person.email], [], subject, html, text)


# ===========================================================================
# 3. The misses
# ===========================================================================

def send_miss_alert(rota, assignment, person, kind, recipients=()) -> bool:
    """One email covers all three misses.

    The member is the addressee and the rota's leads and admins are CC'd -
    that ordering is deliberate. A miss is first of all something the person
    can still fix; copying the admins makes it visible without turning the
    message into a report about somebody written in the third person.
    """
    label, headline, guidance = _MISS_COPY.get(
        kind, ('Rota alert', 'A rota action was missed', ''))
    tone_name = _MISS_TONE.get(kind, 'warn')
    shift = assignment.shift

    to_addresses = [getattr(person, 'email', None)]
    cc_addresses = [getattr(r, 'email', None) for r in recipients
                    if getattr(r, 'id', None) != getattr(person, 'id', None)]
    if not any(to_addresses):
        # The member has no address. The alert still has to reach somebody who
        # can act, so the copies become the recipients.
        to_addresses, cc_addresses = cc_addresses, []

    subject = '{0} - {1} on {2}'.format(label, _name(person), rota.name)

    hero = hero_rows(eyebrow='ACTION MISSED', title=_esc(headline),
                     chips=[_chip(rota.name), _chip(label)],
                     subtitle=_esc(_shift_line(shift)))

    intro = {
        ALERT_MISSED_SIGNIN: 'This shift started at <strong>{0}</strong> and '
                             'no clock-in has been recorded.',
        ALERT_MISSED_SIGNOFF: 'This shift ended at <strong>{1}</strong> and '
                              'no clock-out has been recorded.',
        ALERT_MISSED_SHIFT: 'This shift ran from <strong>{0}</strong> to '
                            '<strong>{1}</strong> and nobody clocked in.',
    }.get(kind, '')
    intro = intro.format(_esc(_when(shift.starts_at)),
                         _esc(_when(shift.ends_at)))

    body = [
        _band(_paragraph('Hello {0},'.format(_esc(_first_name(person)))) +
              _paragraph(intro)),
        _band(_shift_table([assignment], show_person=True), top=6),
        _band(callout(tone_name, 'What to do now', guidance), top=20),
        _action_band('The rota leads and admins have been copied on this.'),
    ]
    html = _envelope('{0} on {1}'.format(label, rota.name), hero,
                     ''.join(body), subject)
    text = _text_body(
        'Hello {0},'.format(_first_name(person)),
        [headline + '.', '', '  ' + _shift_line(shift),
         '  Rota: {0}'.format(rota.name)],
        guidance)
    # High priority: these are the only messages the module sends that are
    # about something already going wrong.
    return _send(to_addresses, cc_addresses, subject, html, text,
                 priority='2')


# ===========================================================================
# 4 and 5. Requests
# ===========================================================================

def send_request_raised(rota, request, approvers) -> bool:
    """A swap or a give-up needs a decision."""
    addresses = [getattr(a, 'email', None) for a in approvers]
    if not any(addresses):
        return False

    assignment = request.assignment
    shift = assignment.shift
    who = _name(request.requester)
    subject = '{0} request from {1} on {2}'.format(request.kind_label, who,
                                                   rota.name)

    if request.kind == REQ_SWAP:
        ask = ('<strong>{0}</strong> would like to swap this shift to '
               '<strong>{1}</strong>.'.format(_esc(who),
                                              _esc(_name(request.target))))
    else:
        ask = ('<strong>{0}</strong> would like to give up this shift. '
               'Approving it leaves the shift unstaffed.'.format(_esc(who)))

    hero = hero_rows(eyebrow='DECISION NEEDED',
                     title='{0} request'.format(_esc(request.kind_label)),
                     chips=[_chip(rota.name), _chip(who)],
                     subtitle=_esc(_shift_line(shift)))

    body = [
        _band(_paragraph(ask)),
        _band(_shift_table([assignment], show_person=True), top=6),
    ]
    if request.reason:
        body.append(_band(section_label('THEIR REASON') +
                          _paragraph(_esc(request.reason), size=13), top=20))
    body.append(_band(callout(
        'info', 'Approve or decline in the rota',
        'Open Rota and go to Requests. The person is told either way.'),
        top=20))
    body.append(_action_band(
        'You are receiving this because you administer this rota.'))

    html = _envelope(subject, hero, ''.join(body), subject)
    text = _text_body(
        'Hello,',
        ['{0} raised a {1} request on {2}:'.format(who, request.kind_label,
                                                   rota.name), '',
         '  ' + _shift_line(shift),
         '  Reason: {0}'.format(request.reason or 'none given')],
        'Open Rota and go to Requests to decide it.')
    return _send(addresses, [], subject, html, text)


def send_request_decided(rota, request, approved) -> bool:
    """The answer, to whoever asked - and to the incoming person on a swap."""
    person = request.requester
    if not getattr(person, 'email', None):
        return False

    assignment = request.assignment
    shift = assignment.shift
    verdict = 'approved' if approved else 'declined'
    subject = 'Your {0} request was {1}'.format(request.kind_label.lower(),
                                                verdict)

    hero = hero_rows(eyebrow='REQUEST {0}'.format(verdict.upper()),
                     title='Request {0}'.format(verdict),
                     chips=[_chip(rota.name), _chip(request.kind_label)],
                     subtitle=_esc(_shift_line(shift)))

    if approved and request.kind == REQ_SWAP:
        outcome = ('The shift has moved to <strong>{0}</strong>. It is no '
                   'longer on your rota.'.format(_esc(_name(request.target))))
    elif approved:
        outcome = 'You have been taken off this shift.'
    else:
        outcome = ('The shift is still yours. Clock in as normal when it '
                   'starts.')

    body = [
        _band(_paragraph('Hello {0},'.format(_esc(_first_name(person)))) +
              _paragraph(outcome)),
        _band(_shift_table([assignment], show_person=True), top=6),
    ]
    if request.decision_note:
        body.append(_band(section_label('NOTE FROM THE ADMIN') +
                          _paragraph(_esc(request.decision_note), size=13),
                          top=20))
    body.append(_action_band('A decision on the {0} rota.'.format(rota.name)))

    html = _envelope(subject, hero, ''.join(body), subject)
    text = _text_body(
        'Hello {0},'.format(_first_name(person)),
        ['Your {0} request was {1}.'.format(request.kind_label.lower(),
                                            verdict), '',
         '  ' + _shift_line(shift),
         '  Note: {0}'.format(request.decision_note or 'none')],
        outcome.replace('<strong>', '').replace('</strong>', ''))
    ok = _send([person.email], [], subject, html, text)

    # On an approved swap the incoming person is now holding a shift they have
    # not been told about, which would be the module's worst possible silence.
    if approved and request.kind == REQ_SWAP and request.target is not None:
        send_schedule(rota, request.target, [assignment])
    return ok
