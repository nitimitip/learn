"""
scheduler.py - the timer behind the automatic alerts.

An in-process APScheduler BackgroundScheduler with its OWN jobstore table
(``apscheduler_jobs_rota``) so it never loads or fires the health-check, MIMP,
certificate or to-do jobs.

One job: ``rota_sweep``, every ROTA_SWEEP_MINUTES (10 by default), running
alerts.run_sweep().

WHY AN INTERVAL JOB AND NOT A DAILY CRON
----------------------------------------
Every other scheduled job in this application is a daily cron, because every
other deadline it watches is a date. This one is not: a member has fifteen
minutes from the start of a shift to clock in. A nightly sweep would report a
07:00 miss at 02:30 the following morning, which is not an alert - it is a
post-mortem.

The interval therefore has to be shorter than the grace window, and ten
minutes gives a worst-case notice of twenty-five minutes against a
fifteen-minute rule while still being a cheap query: one indexed select over
the assignments whose shift is near now, which is almost always empty.

The cadence also bounds how late a REMINDER is. A rota asking for sixty
minutes' notice actually gets between fifty and sixty, because the sweep only
looks every ten - which is why a reminder window is worth setting in multiples
of the sweep interval.

DEPLOYMENT (identical to the other schedulers here):
  * The dedicated Windows service (health_monitor_app_sched.py) owns the
    schedule in production and calls init_rota_monitoring().
  * The in-process Flask scheduler may also start it, guarded by
    RUN_SCHEDULERS_IN_APP in main_app.py.

Running both is harmless. Each alert is claimed through a UNIQUE row in
rota_alerts before it is sent, so the loser of the race skips rather than
duplicates - see alerts.py.
"""

import logging
import os
import threading
from typing import Optional

from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from tzlocal import get_localzone

from database import engine

from .alerts import run_sweep

logger = logging.getLogger(__name__)

# Sweep cadence in minutes. Must stay BELOW the clock-in grace window
# (ROTA_SIGNIN_GRACE_MINUTES, 15 by default) for the alert to be useful -
# see the module docstring.
_SWEEP_MINUTES = max(1, int(os.environ.get('ROTA_SWEEP_MINUTES', '10')))

_JOBSTORE_TABLE = os.environ.get('ROTA_APSCHEDULER_TABLE',
                                 'apscheduler_jobs_rota')
_SWEEP_JOB = 'rota_sweep'

# The previous build's job id. A jobstore row survives a code change, so the
# old id is removed explicitly rather than left to fire a function that no
# longer exists.
_RETIRED_JOBS = ('rota_compliance_sweep',)

_init_lock = threading.Lock()
_scheduler: Optional[BackgroundScheduler] = None


def _sweep_safe():
    """Scheduler entry point - never lets an exception kill the thread."""
    try:
        run_sweep()
    except Exception:
        logger.exception('Rota sweep crashed (suppressed).')


def init_rota_monitoring() -> None:
    """Start the in-process rota scheduler. Idempotent."""
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            logger.info('Rota monitoring already running - skipping re-init.')
            return

        _scheduler = BackgroundScheduler(
            jobstores={'default': SQLAlchemyJobStore(
                engine=engine, tablename=_JOBSTORE_TABLE)},
            # misfire_grace_time is deliberately short. A sweep missed while
            # the service was down has nothing to catch up on - the next run
            # sees exactly the same outstanding assignments - so replaying a
            # backlog of coalesced runs would only waste queries.
            job_defaults={'coalesce': True, 'max_instances': 1,
                          'misfire_grace_time': 300},
            timezone=get_localzone(),
        )

        for retired in _RETIRED_JOBS:
            try:
                _scheduler.remove_job(retired)
                logger.info('Removed the retired rota job %r.', retired)
            except Exception:
                pass            # not there, which is the usual case

        _scheduler.add_job(
            func=_sweep_safe,
            trigger=IntervalTrigger(minutes=_SWEEP_MINUTES),
            id=_SWEEP_JOB,
            name='Rota sweep (every {0} min)'.format(_SWEEP_MINUTES),
            replace_existing=True,
        )
        _scheduler.start()
        logger.info('Rota monitoring started - sweep every %d minute(s).',
                    _SWEEP_MINUTES)


def shutdown_rota_monitoring() -> None:
    """Cleanly stop the scheduler. Call from service teardown / atexit."""
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            _scheduler.shutdown(wait=False)
            logger.info('Rota monitoring stopped.')
        _scheduler = None
