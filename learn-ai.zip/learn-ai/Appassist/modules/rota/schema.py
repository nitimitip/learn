"""
schema.py - taking an existing rota database from the old shape to this one.

TWO FUNCTIONS, AND THE ORDER THEY RUN IN IS THE WHOLE DESIGN.

    retire_legacy_rota_tables(engine)   BEFORE Base.metadata.create_all()
    ensure_rota_schema(engine)          AFTER  Base.metadata.create_all()

The second of those also carries the module's ONGOING migrations - the columns
declared after the tables first shipped, in ``_ADDED_COLUMNS``. They are here
rather than in a file of their own because they answer the same question this
one does, which is "what does an existing database still need doing to it".

WHY RENAME RATHER THAN ALTER
----------------------------
The rebuild removed columns that the old tables declare NOT NULL - a shift's
``period_id``, an assignment's ``ack_due_at`` - so the new code cannot insert
into the old tables at all. SQLite cannot drop a NOT NULL constraint without
rebuilding the table, and rebuilding sixteen tables in place, on a backend
that may be SQL Server instead, is a great deal of machinery to arrive at a
schema that is meant to be simpler than what it replaced.

So the old tables are renamed out of the way, ``create_all()`` builds clean
ones under the proper names, and the rows that still mean something are copied
across. The legacy tables are LEFT IN PLACE afterwards rather than dropped:
they are the only copy of the data this module used to hold, and a migration
that destroys its own source on first boot is one that can never be checked.
``drop_legacy_rota_tables(engine)`` removes them when somebody has looked.

WHY THE INDEXES ARE DROPPED
---------------------------
SQLite carries an index across a table rename under its ORIGINAL name, so a
renamed ``rota_shifts`` still owns ``ix_rota_shifts_rota_id`` - and
``create_all()`` then fails trying to create that index on the new table. The
rename step therefore drops every index on the tables it retires. Nothing is
lost: they are indexes on tables that will never be queried again.

WHAT IS NOT RENAMED
-------------------
``rota_admins`` and ``rota_audit`` keep their tables and their rows. The grant
table was already exactly right, and the audit trail is the one thing in the
module that must survive a rebuild - a trail with a hole where the rebuild
happened is worth much less than one without.

Everything here is idempotent, swallows its own errors and logs them. A boot
must not fail over a migration, and both functions are safe to run on a
database that has already been through them or was created fresh.
"""

import logging

from sqlalchemy import inspect, text

logger = logging.getLogger(__name__)

# The sixteen tables the rebuild leaves behind, and the prefix they are moved
# to. rota_admins and rota_audit are deliberately absent - see the docstring.
_LEGACY_TABLES = (
    'rotas',
    'rota_contacts',
    'rota_periods',
    'rota_members',
    'rota_shifts',
    'rota_assignments',
    'rota_handovers',
    'rota_requests',
    'rota_unavailability',
    'rota_escalation_rules',
    'rota_escalations',
    'rota_notifications',
    'rota_shift_notifications',
    'rota_notification_templates',
    'rota_templates',
    'rota_holidays',
)

_LEGACY_PREFIX = 'rota_legacy_'

# The column that says a `rotas` table belongs to the OLD build. The concept
# was renamed to `frequency` and given its own column, so a table carrying
# `timeframe` has not been migrated yet. Checking a column rather than a
# version row means a half-finished migration is detected correctly on the
# next boot instead of being recorded as done.
_LEGACY_MARKER_COLUMN = 'timeframe'

# --- value maps ------------------------------------------------------------
# The old build's four frequencies and nine statuses, folded onto this one's
# three and three. Both maps are lossy on purpose: the distinctions they drop
# (READY vs SCHEDULED, a custom block size) are exactly the ones the rebuild
# set out to remove.
_FREQUENCY_MAP = {
    'daily': 'day',
    'weekly': 'week',
    'monthly': 'month',
    'custom': 'week',
}

_STATUS_MAP = {
    'draft': 'draft',
    'ready': 'draft',
    'scheduled': 'draft',
    'published': 'published',
    'active': 'published',
    'suspended': 'closed',
    'completed': 'closed',
    'cancelled': 'closed',
    'closed': 'closed',
}

# An old assignment was in one of five lifecycles. Only one of them is a
# person who is still expected on the shift.
_LIVE_LIFECYCLE = 'active'


# ===========================================================================
# Step 1 - run BEFORE create_all()
# ===========================================================================

def retire_legacy_rota_tables(engine) -> None:
    """Move the previous build's tables aside. Never raises."""
    try:
        inspector = inspect(engine)
        tables = set(inspector.get_table_names())
    except Exception as exc:                               # pragma: no cover
        logger.warning('Could not inspect the schema to retire the legacy '
                       'rota tables: %s', exc)
        return

    if 'rotas' not in tables:
        return                      # fresh database - nothing to retire

    try:
        columns = {c['name'] for c in inspector.get_columns('rotas')}
    except Exception as exc:                               # pragma: no cover
        logger.warning('Could not read the rotas columns: %s', exc)
        return

    if _LEGACY_MARKER_COLUMN not in columns:
        return                      # already migrated

    moved = []
    for table in _LEGACY_TABLES:
        if table not in tables:
            continue
        target = _LEGACY_PREFIX + table
        if target in tables:
            # A previous run got this far and then failed. The already-moved
            # copy is the real one; drop the leftover rather than colliding.
            logger.warning('Both %s and %s exist - dropping the un-migrated '
                           '%s.', table, target, table)
            _run(engine, 'DROP TABLE {0}'.format(table))
            continue
        if _drop_indexes(engine, inspector, table) and \
                _run(engine, 'ALTER TABLE {0} RENAME TO {1}'.format(table,
                                                                    target)):
            moved.append(table)

    if moved:
        logger.info('Retired %d legacy rota table(s) to the %s prefix: %s',
                    len(moved), _LEGACY_PREFIX, ', '.join(moved))


def _drop_indexes(engine, inspector, table) -> bool:
    """Free every index name the table owns. True when the table is clear."""
    try:
        names = [i['name'] for i in inspector.get_indexes(table)
                 if i.get('name')]
    except Exception as exc:                               # pragma: no cover
        logger.warning('Could not list the indexes on %s: %s', table, exc)
        return False

    dialect = engine.dialect.name.lower()
    for name in names:
        # SQL Server scopes an index to its table and needs it named that way;
        # SQLite and PostgreSQL treat index names as schema-global.
        statement = ('DROP INDEX {0} ON {1}'.format(name, table)
                     if dialect == 'mssql' else
                     'DROP INDEX IF EXISTS {0}'.format(name))
        _run(engine, statement)
    return True


def _run(engine, statement) -> bool:
    """Execute one DDL statement, logging rather than raising on failure."""
    try:
        with engine.begin() as conn:
            conn.execute(text(statement))
        return True
    except Exception as exc:                               # pragma: no cover
        logger.warning('Rota schema step failed (%s): %s', statement, exc)
        return False


# ===========================================================================
# Step 2 - run AFTER create_all()
# ===========================================================================

# Columns added to a table AFTER the rebuild shipped, in the order they were
# added. `create_all()` only ever creates a table that is missing entirely, so
# a site that has been running since before one of these was declared has the
# table without the column, and every query against it fails. One ALTER per
# entry closes that, and re-running it is a no-op because the column is only
# added when the inspector says it is absent.
#
# ONLY NULLABLE COLUMNS BELONG HERE. A NOT NULL addition needs a default that
# every existing row can take, which is a decision per column rather than a
# loop, and it is better made explicitly than smuggled into this table.
_ADDED_COLUMNS = (
    # (table, column, DDL type)
    ('rotas', 'instructions', 'TEXT'),
)


def ensure_rota_columns(engine) -> None:
    """Add any column declared after the table was first created."""
    try:
        inspector = inspect(engine)
        tables = set(inspector.get_table_names())
    except Exception as exc:                               # pragma: no cover
        logger.warning('Could not inspect the schema to add the newer rota '
                       'columns: %s', exc)
        return

    for table, column, ddl_type in _ADDED_COLUMNS:
        if table not in tables:
            continue                    # create_all() will build it complete
        try:
            present = {c['name'] for c in inspector.get_columns(table)}
        except Exception as exc:                           # pragma: no cover
            logger.warning('Could not read the %s columns: %s', table, exc)
            continue
        if column in present:
            continue
        if _run(engine, 'ALTER TABLE {0} ADD COLUMN {1} {2}'.format(
                table, column, ddl_type)):
            logger.info('Added %s.%s to the rota schema.', table, column)


def ensure_rota_schema(engine) -> None:
    """Copy what the retired tables still mean into the new ones, and add any
    column the module has grown since the tables were built.

    Guarded on the NEW rotas table being empty, which is true exactly once:
    on the first boot after the rebuild. A site that later deletes every rota
    would technically re-arm the guard, so the copy also checks that the
    legacy tables are still there - and a re-run would in any case write the
    same rows it wrote the first time.
    """
    # Runs FIRST and unconditionally: the carry-over below returns early on
    # every boot after the first, and a column addition has to happen on all
    # of them.
    ensure_rota_columns(engine)

    try:
        inspector = inspect(engine)
        tables = set(inspector.get_table_names())
    except Exception as exc:                               # pragma: no cover
        logger.warning('Could not inspect the schema for the rota carry-over: '
                       '%s', exc)
        return

    legacy_rotas = _LEGACY_PREFIX + 'rotas'
    if legacy_rotas not in tables or 'rotas' not in tables:
        return

    try:
        with engine.begin() as conn:
            existing = conn.execute(text(
                'SELECT COUNT(*) FROM rotas')).scalar()
            if existing:
                return                  # already carried over, or in use

            source = conn.execute(text(
                'SELECT COUNT(*) FROM {0}'.format(legacy_rotas))).scalar()
            if not source:
                return                  # nothing to carry

            counts = _carry_over(conn, tables)

        logger.info('Rota carry-over complete - %s.',
                    ', '.join('{0} {1}'.format(v, k)
                              for k, v in counts.items() if v))
    except Exception as exc:                               # pragma: no cover
        logger.warning('Rota carry-over failed (the new tables are empty and '
                       'the legacy tables are untouched): %s', exc)


def _carry_over(conn, tables):
    """The copy itself, inside the caller's transaction.

    Ids are PRESERVED on every table. They have to be: the audit trail that
    survived the rebuild names rotas, shifts and assignments by id, and a
    carry-over that renumbered them would silently repoint twenty-three
    audit rows at the wrong subjects.
    """
    counts = {'rotas': 0, 'members': 0, 'shifts': 0, 'assignments': 0,
              'handovers': 0, 'requests': 0}

    # ---------------------------------------------------------------- rotas
    for row in conn.execute(text(
            'SELECT id, name, description, timeframe, status, start_date, '
            '       end_date, ack_grace_minutes, signoff_grace_minutes, '
            '       created_by, created_at, published_at '
            '  FROM {0}'.format(_LEGACY_PREFIX + 'rotas'))).mappings():
        conn.execute(text(
            'INSERT INTO rotas (id, name, description, frequency, status, '
            '                   start_date, end_date, signin_grace_minutes, '
            '                   signoff_grace_minutes, created_by, '
            '                   created_at, published_at) '
            'VALUES (:id, :name, :description, :frequency, :status, '
            '        :start_date, :end_date, :signin, :signoff, :created_by, '
            '        :created_at, :published_at)'),
            {'id': row['id'],
             'name': row['name'],
             # The new table allows a null description; the old one did not,
             # so an empty string here is the old table's way of saying none.
             'description': (row['description'] or '').strip() or None,
             'frequency': _FREQUENCY_MAP.get(
                 (row['timeframe'] or '').lower(), 'week'),
             'status': _STATUS_MAP.get((row['status'] or '').lower(), 'draft'),
             'start_date': row['start_date'],
             'end_date': row['end_date'],
             'signin': row['ack_grace_minutes'],
             'signoff': row['signoff_grace_minutes'],
             'created_by': row['created_by'],
             'created_at': row['created_at'],
             'published_at': row['published_at']})
        counts['rotas'] += 1

    # -------------------------------------------------------------- members
    if _LEGACY_PREFIX + 'rota_members' in tables:
        for row in conn.execute(text(
                'SELECT id, rota_id, user_id, is_lead, added_at '
                '  FROM {0}'.format(
                    _LEGACY_PREFIX + 'rota_members'))).mappings():
            conn.execute(text(
                'INSERT INTO rota_members (id, rota_id, user_id, is_lead, '
                '                          added_at) '
                'VALUES (:id, :rota_id, :user_id, :is_lead, :added_at)'),
                {'id': row['id'], 'rota_id': row['rota_id'],
                 'user_id': row['user_id'],
                 'is_lead': 1 if row['is_lead'] else 0,
                 'added_at': row['added_at']})
            counts['members'] += 1

    # --------------------------------------------------------------- shifts
    # `shift_date` is new and has no source column. It is taken from the start
    # of the window, which is right for every shift that does not cross
    # midnight and is the only reading available for one that does.
    if _LEGACY_PREFIX + 'rota_shifts' in tables:
        for row in conn.execute(text(
                'SELECT id, rota_id, name, starts_at, ends_at, instructions, '
                '       created_at '
                '  FROM {0} '
                ' WHERE cancelled_at IS NULL'.format(
                    _LEGACY_PREFIX + 'rota_shifts'))).mappings():
            conn.execute(text(
                'INSERT INTO rota_shifts (id, rota_id, shift_date, starts_at, '
                '                         ends_at, label, notes, created_at) '
                'VALUES (:id, :rota_id, :shift_date, :starts_at, :ends_at, '
                '        :label, :notes, :created_at)'),
                {'id': row['id'], 'rota_id': row['rota_id'],
                 'shift_date': _date_of(row['starts_at']),
                 'starts_at': row['starts_at'], 'ends_at': row['ends_at'],
                 'label': row['name'], 'notes': row['instructions'],
                 'created_at': row['created_at']})
            counts['shifts'] += 1

    # ---------------------------------------------------------- assignments
    # `started_at` was the old build's clock-in. An assignment that was
    # declined, reassigned, cancelled or marked a no-show is carried as
    # CANCELLED: all four mean the same thing to this build, which is that
    # the person is not expected on the shift.
    if _LEGACY_PREFIX + 'rota_assignments' in tables:
        for row in conn.execute(text(
                'SELECT id, shift_id, rota_id, user_id, started_at, '
                '       signed_off_at, signoff_was_late, lifecycle, '
                '       cancelled_at, signoff_note, created_at '
                '  FROM {0} '
                ' WHERE shift_id IS NOT NULL'.format(
                    _LEGACY_PREFIX + 'rota_assignments'))).mappings():
            live = (row['lifecycle'] or _LIVE_LIFECYCLE) == _LIVE_LIFECYCLE
            conn.execute(text(
                'INSERT INTO rota_assignments (id, shift_id, rota_id, '
                '       user_id, signed_in_at, signed_off_at, '
                '       signin_was_late, signoff_was_late, state, '
                '       cancelled_at, note, created_at) '
                'VALUES (:id, :shift_id, :rota_id, :user_id, :signed_in_at, '
                '        :signed_off_at, 0, :signoff_late, :state, '
                '        :cancelled_at, :note, :created_at)'),
                {'id': row['id'], 'shift_id': row['shift_id'],
                 'rota_id': row['rota_id'], 'user_id': row['user_id'],
                 'signed_in_at': row['started_at'],
                 'signed_off_at': row['signed_off_at'],
                 'signoff_late': 1 if row['signoff_was_late'] else 0,
                 'state': 'active' if live else 'cancelled',
                 'cancelled_at': row['cancelled_at'],
                 'note': row['signoff_note'],
                 'created_at': row['created_at']})
            counts['assignments'] += 1

    # ------------------------------------------------------------ handovers
    # Seven free-text fields become two. Everything that described the state
    # of the world joins the summary; the two that described what the next
    # shift must pick up join the open items, under their old headings so
    # nothing reads as if it had always been one field.
    if _LEGACY_PREFIX + 'rota_handovers' in tables:
        for row in conn.execute(text(
                'SELECT id, shift_id, rota_id, open_incidents, '
                '       major_incidents, escalated_incidents, '
                '       pending_actions, known_issues, risks, notes, '
                '       next_shift_instructions, submitted_by, submitted_at '
                '  FROM {0}'.format(
                    _LEGACY_PREFIX + 'rota_handovers'))).mappings():
            summary = _join_sections((
                ('Open incidents', row['open_incidents']),
                ('Major incidents', row['major_incidents']),
                ('Escalated', row['escalated_incidents']),
                ('Known issues', row['known_issues']),
                ('Risks', row['risks']),
                ('Notes', row['notes']),
            ))
            open_items = _join_sections((
                ('Pending actions', row['pending_actions']),
                ('For the next shift', row['next_shift_instructions']),
            ))
            conn.execute(text(
                'INSERT INTO rota_handovers (id, shift_id, rota_id, summary, '
                '       open_items, author_id, created_at) '
                'VALUES (:id, :shift_id, :rota_id, :summary, :open_items, '
                '        :author_id, :created_at)'),
                {'id': row['id'], 'shift_id': row['shift_id'],
                 'rota_id': row['rota_id'], 'summary': summary or None,
                 'open_items': open_items or None,
                 'author_id': row['submitted_by'],
                 'created_at': row['submitted_at']})
            counts['handovers'] += 1

    # ------------------------------------------------------------- requests
    if _LEGACY_PREFIX + 'rota_requests' in tables:
        for row in conn.execute(text(
                'SELECT id, rota_id, assignment_id, kind, state, '
                '       requested_by, proposed_user_id, reason, decided_by, '
                '       decided_at, decision_note, created_at '
                '  FROM {0}'.format(
                    _LEGACY_PREFIX + 'rota_requests'))).mappings():
            # The old build had swap, replacement and cover. Only a swap
            # named a person, so the other two are this build's `leave`.
            kind = 'swap' if (row['kind'] or '') == 'swap' else 'leave'
            conn.execute(text(
                'INSERT INTO rota_requests (id, rota_id, assignment_id, kind, '
                '       state, requested_by, target_user_id, reason, '
                '       decided_by, decided_at, decision_note, created_at) '
                'VALUES (:id, :rota_id, :assignment_id, :kind, :state, '
                '        :requested_by, :target, :reason, :decided_by, '
                '        :decided_at, :decision_note, :created_at)'),
                {'id': row['id'], 'rota_id': row['rota_id'],
                 'assignment_id': row['assignment_id'], 'kind': kind,
                 'state': row['state'] or 'open',
                 'requested_by': row['requested_by'],
                 'target': row['proposed_user_id'] if kind == 'swap' else None,
                 'reason': row['reason'], 'decided_by': row['decided_by'],
                 'decided_at': row['decided_at'],
                 'decision_note': row['decision_note'],
                 'created_at': row['created_at']})
            counts['requests'] += 1

    # The span the rota ACTUALLY covers, recomputed from the shifts that were
    # carried. The legacy start_date / end_date were the range the rota was
    # configured over, which is not the same thing - a rota set up for a week
    # but only cut for two days would otherwise keep claiming the week, and
    # every screen reads this pair rather than aggregating the shifts. It is
    # what service.refresh_span() maintains from here on.
    conn.execute(text(
        'UPDATE rotas SET '
        '  start_date = (SELECT MIN(s.shift_date) FROM rota_shifts s '
        '                 WHERE s.rota_id = rotas.id), '
        '  end_date   = (SELECT MAX(s.shift_date) FROM rota_shifts s '
        '                 WHERE s.rota_id = rotas.id) '
        ' WHERE EXISTS (SELECT 1 FROM rota_shifts s WHERE s.rota_id = rotas.id)'
    ))

    return counts


def _date_of(value):
    """The date part of a stored datetime, whatever the driver returned.

    SQLite hands back a string; SQL Server hands back a datetime. Both have
    to produce something the DATE column accepts.
    """
    if value is None:
        return None
    if hasattr(value, 'date'):
        return value.date()
    return str(value)[:10]


def _join_sections(pairs):
    """Fold labelled free-text fields into one block, dropping the empties."""
    parts = []
    for label, body in pairs:
        text_value = (body or '').strip()
        if text_value:
            parts.append('{0}:\n{1}'.format(label, text_value))
    return '\n\n'.join(parts)


# ===========================================================================
# Cleanup - never called automatically
# ===========================================================================

def drop_legacy_rota_tables(engine) -> int:
    """Permanently remove the retired tables. Returns how many went.

    Deliberately not wired into startup. Run it by hand once the carried-over
    rota reads correctly on the new screens:

        python -c "from database import engine; \
                   from modules.rota.schema import drop_legacy_rota_tables; \
                   print(drop_legacy_rota_tables(engine))"
    """
    try:
        tables = set(inspect(engine).get_table_names())
    except Exception as exc:                               # pragma: no cover
        logger.warning('Could not inspect the schema: %s', exc)
        return 0

    dropped = 0
    # Reversed so a child table goes before the parent it references.
    for table in reversed(_LEGACY_TABLES):
        target = _LEGACY_PREFIX + table
        if target in tables and _run(engine, 'DROP TABLE {0}'.format(target)):
            dropped += 1
    logger.info('Dropped %d legacy rota table(s).', dropped)
    return dropped
