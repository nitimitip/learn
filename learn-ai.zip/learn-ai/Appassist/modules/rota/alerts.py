"""
alerts.py - the automatic notifications.

ONE FUNCTION MATTERS: ``run_sweep()``. Every ten minutes it walks the
assignments that are close enough to now to be interesting and asks four
questions of each:

    is the shift about to start and this person not clocked in? reminder
    has it started, the grace gone, and still no clock-in?      missed_signin
    is it over, they clocked in, and never clocked out?         missed_signoff
    is it over and they never clocked in at all?                missed_shift

Anything it finds becomes a RotaAlert row and an email. Nothing else in this
module raises an alert, so "what will the system tell people about" has one
answer and it is the four lines above.

CLAIM FIRST, SEND SECOND
------------------------
The row is INSERTED and COMMITTED before the email is attempted, and the
UNIQUE constraint on (assignment_id, kind) is what makes that safe. Two
processes running the sweep at once - the Windows service and an in-process
scheduler, which is a supported deployment - both try to insert; one wins and
sends, the other takes an IntegrityError and skips. Without the claim they
would both send.

A FAILED SEND LEAVES THE CLAIM IN PLACE. That is deliberate and it is the
opposite of what the previous build did, which released the claim so the next
sweep could retry. Retrying sounds right and is not: an SMTP server down for
an hour means six sweeps queue six identical alerts and deliver all of them
when it returns. The alert is still true whether or not the email arrived,
the dashboard shows it either way, and ``emailed`` records which happened -
so an administrator can see that mail failed rather than being told nothing
went wrong.

WHY A REMINDER IS NOT SENT FOR A SHIFT THAT ALREADY STARTED
-----------------------------------------------------------
The sweep is periodic, so a shift starting at 09:03 with a 60-minute reminder
window becomes eligible at 08:03 and is first seen at whatever time the sweep
next runs. If the service was down all morning, the first run after it comes
back would otherwise send a "starting shortly" email at 11:00 for a shift that
began two hours ago. The reminder therefore requires the shift to still be in
the future at the moment the sweep looks.

THE SCAN IS BOUNDED. Only assignments whose shift ends within the last
ROTA_LOOKBACK_HOURS (36 by default) or starts within the next few hours are
considered. A rota published for next year must not make the sweep walk
every row in the table, and an alert about a shift three weeks gone helps
nobody.
"""

import logging
import os
from datetime import datetime, timedelta

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import joinedload

from database import get_db_session

from . import audit, emails, service
from .models import (ALERT_MISSED_SHIFT, ALERT_MISSED_SIGNIN,
                     ALERT_MISSED_SIGNOFF, ALERT_REMINDER, ALERT_TO_ADMINS,
                     STATE_ACTIVE, STATUS_PUBLISHED, Rota, RotaAlert,
                     RotaAssignment, RotaShift)

logger = logging.getLogger(__name__)

# How far back a finished shift stays worth alerting about. A miss older than
# this is a matter for the attendance report, not for an email.
_LOOKBACK_HOURS = service._env_int('ROTA_LOOKBACK_HOURS', 36, minimum=1,
                                   maximum=168)

# How far ahead to look. Only the reminder needs the future, and it needs at
# most the largest reminder window any rota sets.
_LOOKAHEAD_HOURS = service._env_int('ROTA_LOOKAHEAD_HOURS', 24, minimum=1,
                                    maximum=168)


def run_sweep(now=None):
    """The whole job. Returns a dict of what it did. Never raises.

    Safe to call from anywhere - the scheduler, a test, or by hand from a
    shell to see what the next run would do.
    """
    now = now or datetime.now()
    db_session = get_db_session()
    # Only what was RAISED is counted. An alert that was already claimed - by
    # an earlier sweep, or by the other process running this one - is the
    # steady state, not an event: every sweep after the first would otherwise
    # log the same "skipped=3" forever and the line would stop being read.
    counts = {ALERT_REMINDER: 0, ALERT_MISSED_SIGNIN: 0,
              ALERT_MISSED_SIGNOFF: 0, ALERT_MISSED_SHIFT: 0,
              'closed': 0}
    try:
        for assignment in _candidates(db_session, now):
            rota = assignment.rota
            shift = assignment.shift
            if rota is None or shift is None:              # pragma: no cover
                continue
            signin_grace, signoff_grace, reminder = service.graces(rota)

            for kind in _due_alerts(assignment, shift, now, signin_grace,
                                    signoff_grace, reminder):
                if _raise_alert(db_session, assignment, kind, now):
                    counts[kind] += 1

        # A finished rota moving to closed is the other thing that has to
        # happen on a timer, and it belongs to the same transaction boundary.
        closed = service.close_finished_rotas(db_session, now)
        if closed:
            db_session.commit()
            counts['closed'] = closed

        if any(counts.values()):
            logger.info('Rota sweep: %s', ', '.join(
                '{0}={1}'.format(k, v) for k, v in counts.items() if v))
        return counts
    except Exception:
        logger.exception('Rota sweep failed.')
        db_session.rollback()
        return counts
    finally:
        db_session.close()


def _candidates(db_session, now):
    """The assignments close enough to now to be worth asking about."""
    window_start = now - timedelta(hours=_LOOKBACK_HOURS)
    window_end = now + timedelta(hours=_LOOKAHEAD_HOURS)
    return (db_session.query(RotaAssignment)
            .join(RotaShift, RotaShift.id == RotaAssignment.shift_id)
            .join(Rota, Rota.id == RotaAssignment.rota_id)
            .options(joinedload(RotaAssignment.shift),
                     joinedload(RotaAssignment.rota),
                     joinedload(RotaAssignment.user))
            .filter(RotaAssignment.state == STATE_ACTIVE,
                    # Only a published rota is an instruction to anybody. A
                    # draft is a plan, and chasing somebody over a plan is how
                    # a rota loses the room.
                    Rota.status == STATUS_PUBLISHED,
                    RotaShift.ends_at >= window_start,
                    RotaShift.starts_at <= window_end)
            .order_by(RotaShift.starts_at.asc()).all())


def _due_alerts(assignment, shift, now, signin_grace, signoff_grace,
                reminder):
    """Which of the four this assignment has earned, right now.

    A list rather than a single value: a shift that is over and was never
    clocked in earns both missed_signin (raised while it was running) and
    missed_shift (raised once it ended), and on the first sweep after a long
    outage both fall due in the same pass.
    """
    due = []

    if not assignment.signed_in_at:
        # Reminder - future shifts only. See the module docstring.
        if now < shift.starts_at <= now + timedelta(minutes=reminder):
            due.append(ALERT_REMINDER)

        late_from = shift.starts_at + timedelta(minutes=signin_grace)
        if now > late_from:
            if now < shift.ends_at:
                due.append(ALERT_MISSED_SIGNIN)
            else:
                # The shift is over. Both are true; both are sent, because
                # "you were late" and "nobody worked it" are different facts
                # and the second one is the one an admin acts on.
                due.append(ALERT_MISSED_SIGNIN)
                due.append(ALERT_MISSED_SHIFT)
    elif not assignment.signed_off_at:
        if now > shift.ends_at + timedelta(minutes=signoff_grace):
            due.append(ALERT_MISSED_SIGNOFF)

    return due


def _raise_alert(db_session, assignment, kind, now):
    """Claim, then send. True when this process was the one that raised it."""
    rota = assignment.rota
    shift = assignment.shift
    person = assignment.user

    message = _message_for(kind, assignment, shift)
    row = RotaAlert(assignment_id=assignment.id, rota_id=rota.id,
                    shift_id=shift.id, user_id=assignment.user_id,
                    kind=kind, message=message, created_at=now)
    db_session.add(row)
    try:
        db_session.commit()
    except IntegrityError:
        # Already raised - either by an earlier sweep or by the other process
        # running this one. Both are the normal case, not an error.
        db_session.rollback()
        return False
    except Exception:                                      # pragma: no cover
        logger.exception('Could not claim rota alert %s for assignment %s.',
                         kind, assignment.id)
        db_session.rollback()
        return False

    recipients = (service.rota_recipients(db_session, rota)
                  if kind in ALERT_TO_ADMINS else [])

    if kind == ALERT_REMINDER:
        sent = emails.send_reminder(rota, assignment, person)
    else:
        sent = emails.send_miss_alert(rota, assignment, person, kind,
                                      recipients)

    row.emailed = bool(sent)
    audit.record(db_session, 'alert.sent', rota=rota, shift=shift,
                 assignment=assignment, subject=person, detail=kind,
                 new_value='emailed' if sent else 'email failed')
    try:
        db_session.commit()
    except Exception:                                      # pragma: no cover
        logger.exception('Could not record the send result for alert %s.',
                         row.id)
        db_session.rollback()
    return True


def _message_for(kind, assignment, shift):
    """The one line the dashboard feed shows. Written once, here, so the
    feed and the email cannot describe the same event differently."""
    who = service.person_name(assignment.user)
    when = shift.starts_at.strftime('%a %d %b %H:%M')
    if kind == ALERT_REMINDER:
        return 'Shift starting at {0}'.format(
            shift.starts_at.strftime('%H:%M on %a %d %b'))
    if kind == ALERT_MISSED_SIGNIN:
        return '{0} has not clocked in for the {1} shift'.format(who, when)
    if kind == ALERT_MISSED_SIGNOFF:
        return '{0} has not clocked out of the {1} shift'.format(who, when)
    if kind == ALERT_MISSED_SHIFT:
        return '{0} missed the {1} shift'.format(who, when)
    return '{0}: {1}'.format(kind, when)                   # pragma: no cover


# Kept under the name the scheduler has always imported, so a jobstore row
# persisted by the previous build still resolves to a callable.
def run_rota_compliance_sweep():
    """Entry point for the scheduler."""
    return run_sweep()
