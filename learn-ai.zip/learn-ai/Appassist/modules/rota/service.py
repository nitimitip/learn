"""
service.py - everything the rota screens do to the database.

The routes read the form, call one function in here, and render. Nothing in
this file knows about Flask, which is what lets the sweep in alerts.py and the
report in reports.py reuse the same rules the screens run under.

THE ACCESS MODEL, IN FULL
-------------------------
Three roles, and that is the whole of it:

    System Admin    everything, plus deciding who the Rota Admins are.
    Rota Admin      create, staff, publish and manage EVERY rota.
    Member          opens the rotas they are rostered on, and acts on THEIR
                    OWN shifts only.

A member marked ``is_lead`` on a rota is still a member; the flag adds two
things - they see the whole rota rather than only their own shifts, and they
decide swap requests on it. It is not a fourth role, and no route tests for it
except those two.

Nobody, including a System Admin, can clock in or clock out AS somebody
else.
An admin who needs to record that a member did work a shift uses
``record_attendance``, which writes the same timestamps but stamps
``recorded_by`` - so "did they sign themselves in" remains answerable, which
is the entire value of the record.

WHY THE GRACE WINDOWS ARE RESOLVED HERE
---------------------------------------
A rota may set its own; where it does not, the site default from the
environment applies. Every caller goes through ``graces()``, which returns all
three at once, because a screen that resolves them once per rota and then
hands them to eighty status calls is the difference between one lookup and
two hundred and forty.
"""

import calendar
import logging
import os
from datetime import date, datetime, time, timedelta

# `col == sql_true()` rather than `col.is_(True)`: SQLAlchemy renders
# the latter as `col IS 1`, which SQLite accepts and SQL SERVER REJECTS
# - T-SQL allows IS only with NULL. Both compile `== true()` to `= 1`.
from sqlalchemy import and_, func, or_, true as sql_true
from sqlalchemy.orm import joinedload

from models import User

from . import audit
from .models import (
    ACTION_STATUSES, FREQ_DAY, FREQ_MONTH, FREQ_WEEK, MISSED_STATUSES,
    REQ_APPROVED, REQ_DECLINED, REQ_LEAVE, REQ_OPEN, REQ_SWAP, REQ_WITHDRAWN,
    ST_DONE, ST_MISSED, STATE_ACTIVE, STATE_CANCELLED, STATUS_CLOSED,
    STATUS_DRAFT, STATUS_PUBLISHED, Rota, RotaAdmin, RotaAlert, RotaAssignment,
    RotaHandover, RotaMember, RotaRequest, RotaShift,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Site defaults
#
# Each is the value used by a rota that does not set its own. They are read at
# import so a mis-set variable shows up at boot rather than at 3am, and each
# is floored at a value that keeps the rule meaningful - a zero-minute clock-in
# grace would mark somebody late for being eight seconds behind the clock.
# ---------------------------------------------------------------------------

def _env_int(name, default, minimum=1, maximum=1440):
    try:
        value = int(os.environ.get(name, '').strip() or default)
    except (TypeError, ValueError):
        logger.warning('%s is not a whole number - using %s.', name, default)
        return default
    return max(minimum, min(maximum, value))


DEFAULT_SIGNIN_GRACE = _env_int('ROTA_SIGNIN_GRACE_MINUTES', 15)
DEFAULT_SIGNOFF_GRACE = _env_int('ROTA_SIGNOFF_GRACE_MINUTES', 30)
DEFAULT_REMINDER = _env_int('ROTA_REMINDER_MINUTES', 60)

# How many shifts one build of the form may generate. A month of three daily
# windows is ninety-three; the cap exists to stop a mistyped year producing
# forty thousand rows, not to limit real use.
MAX_SHIFTS_PER_BUILD = _env_int('ROTA_MAX_SHIFTS', 400, minimum=1,
                                maximum=5000)


def graces(rota):
    """(signin, signoff, reminder) in minutes for this rota."""
    return (
        rota.signin_grace_minutes or DEFAULT_SIGNIN_GRACE,
        rota.signoff_grace_minutes or DEFAULT_SIGNOFF_GRACE,
        rota.reminder_minutes or DEFAULT_REMINDER,
    )


# ===========================================================================
# Who can do what
# ===========================================================================

def is_system_admin(user):
    return bool(user is not None and getattr(user, 'role', '') == 'admin')


def is_rota_admin(db_session, user):
    """A Rota Admin, or an application admin (who is one implicitly)."""
    if user is None:
        return False
    if is_system_admin(user):
        return True
    return db_session.query(RotaAdmin.id).filter(
        RotaAdmin.user_id == user.id).first() is not None


def membership(db_session, rota_id, user):
    if user is None:
        return None
    return db_session.query(RotaMember).filter(
        RotaMember.rota_id == rota_id,
        RotaMember.user_id == user.id).first()


def is_lead(db_session, rota_id, user):
    row = membership(db_session, rota_id, user)
    return bool(row is not None and row.is_lead)


def can_view(db_session, rota, user):
    """A rota is not open to every signed-in account.

    It names who is on call and is read as an instruction by the people on it,
    so it is visible to its own roster and to the people who administer it -
    not to the directory at large the way the People module is.
    """
    if user is None:
        return False
    if is_rota_admin(db_session, user):
        return True
    return membership(db_session, rota.id, user) is not None


def can_manage(db_session, rota, user):
    """Build, staff, publish and delete. Rota Admins only."""
    return is_rota_admin(db_session, user)


def can_decide_requests(db_session, rota, user):
    """Rota Admins, plus a lead on this particular rota."""
    return (is_rota_admin(db_session, user)
            or is_lead(db_session, rota.id, user))


def admin_users(db_session):
    """Everyone who should be copied on a missed-action alert."""
    granted = (db_session.query(User)
               .join(RotaAdmin, RotaAdmin.user_id == User.id)
               .filter(User.is_active == sql_true()).all())
    if granted:
        return granted
    # No explicit grants: fall back to the application admins, so alerts still
    # reach a human on a site that has not set the module up yet.
    return (db_session.query(User)
            .filter(User.role == 'admin', User.is_active == sql_true()).all())


def rota_recipients(db_session, rota):
    """Who gets told when something on this rota goes wrong.

    The rota's own leads first, because they are the people who can actually
    re-staff the shift, and the Rota Admins behind them. De-duplicated by id.
    """
    leads = (db_session.query(User)
             .join(RotaMember, RotaMember.user_id == User.id)
             .filter(RotaMember.rota_id == rota.id,
                     RotaMember.is_lead == sql_true(),
                     User.is_active == sql_true()).all())
    seen = {u.id for u in leads}
    for person in admin_users(db_session):
        if person.id not in seen:
            seen.add(person.id)
            leads.append(person)
    return leads


# ===========================================================================
# Reading rotas
# ===========================================================================

def visible_rotas(db_session, user, statuses=None, search=None):
    """The rotas this person may open, newest span first."""
    query = db_session.query(Rota)
    if not is_rota_admin(db_session, user):
        query = query.join(RotaMember, RotaMember.rota_id == Rota.id).filter(
            RotaMember.user_id == user.id)
    if statuses:
        query = query.filter(Rota.status.in_(tuple(statuses)))
    if search:
        like = '%{0}%'.format(search.strip())
        query = query.filter(or_(Rota.name.ilike(like),
                                 Rota.description.ilike(like),
                                 Rota.instructions.ilike(like)))
    # A rota with no shifts yet has no start_date, and belongs at the top
    # rather than the bottom - it is the one still being built.
    return query.order_by(Rota.start_date.is_(None).desc(),
                          Rota.start_date.desc(), Rota.id.desc()).all()


def visible_rota_ids(db_session, user):
    return [r.id for r in visible_rotas(db_session, user)]


def rota_stats(db_session, rota, now=None):
    """The counts the list and detail screens show for one rota."""
    now = now or datetime.now()
    signin_grace, signoff_grace, _ = graces(rota)

    rows = (db_session.query(RotaAssignment)
            .options(joinedload(RotaAssignment.shift))
            .filter(RotaAssignment.rota_id == rota.id,
                    RotaAssignment.state == STATE_ACTIVE).all())

    shifts = db_session.query(func.count(RotaShift.id)).filter(
        RotaShift.rota_id == rota.id).scalar() or 0
    members = db_session.query(func.count(RotaMember.id)).filter(
        RotaMember.rota_id == rota.id).scalar() or 0

    done = missed = upcoming = 0
    for row in rows:
        status = row.status_at(now, signin_grace, signoff_grace)
        if status == ST_DONE:
            done += 1
        elif status in MISSED_STATUSES:
            missed += 1
        else:
            upcoming += 1

    # A shift nobody is on. The single most useful number on the screen, and
    # the reason the schedule grid colours an empty cell.
    staffed = {row.shift_id for row in rows}
    unstaffed = max(0, shifts - len(staffed))

    return {
        'shifts': shifts,
        'members': members,
        'assignments': len(rows),
        'done': done,
        'missed': missed,
        'upcoming': upcoming,
        'unstaffed': unstaffed,
        'attendance_pct': _pct(done, done + missed),
    }


def _pct(part, whole):
    return int(round(100.0 * part / whole)) if whole else None


def rota_overview(db_session, user, now=None, limit=None, search=None):
    """Every rota this person can see, with the figures the dashboard shows.

    WHY THIS IS NOT A LOOP OVER ``rota_stats``. The dashboard leads on the
    rotas, so on a site with twenty of them the obvious implementation is
    twenty-one round trips before the first pixel - and the screen is opened
    by everybody, all day. This makes THREE queries whatever the count: the
    rotas, their shifts with the assignments joined, and the member tally.

    Each row carries what a card needs and nothing else:

        rota        the object itself
        stats       the same keys ``rota_stats`` returns, so a template can
                    move between the two without learning a second vocabulary
        coverage    percent of shifts with at least one person on them - the
                    number that says whether the rota is actually built
        on_now      how many of its people are on shift at this moment
        next_shift  the next shift due to start, or None
        first_shift the earliest shift on the rota, or None
        today       how many of its shifts run today
        headline    ('bad'|'warn'|'go'|'quiet', words) - the one thing to say
                    about this rota, resolved here so the dashboard and the
                    Rotas screen cannot disagree about what is wrong

    Ordered BY START TIME, earliest first - see _overview_order.
    """
    now = now or datetime.now()
    rotas = visible_rotas(db_session, user, search=search)
    if not rotas:
        return []
    if limit:
        rotas = rotas[:limit]

    ids = [r.id for r in rotas]
    today = now.date()

    shifts = (db_session.query(RotaShift)
              .options(joinedload(RotaShift.assignments))
              .filter(RotaShift.rota_id.in_(ids))
              .order_by(RotaShift.starts_at.asc()).all())

    member_counts = dict(
        db_session.query(RotaMember.rota_id, func.count(RotaMember.id))
        .filter(RotaMember.rota_id.in_(ids))
        .group_by(RotaMember.rota_id).all())

    blank = {'shifts': 0, 'staffed': 0, 'assignments': 0, 'done': 0,
             'missed': 0, 'upcoming': 0, 'on_now': 0, 'today': 0,
             'next_shift': None, 'first_shift': None}
    tally = {rota_id: dict(blank) for rota_id in ids}

    grace_cache = {r.id: graces(r) for r in rotas}

    for shift in shifts:
        bucket = tally.get(shift.rota_id)
        if bucket is None:                                 # pragma: no cover
            continue
        signin_grace, signoff_grace, _ = grace_cache[shift.rota_id]
        bucket['shifts'] += 1
        # The shifts arrive in starts_at order, so the first one seen is the
        # earliest. It is what breaks a tie between two rotas that start on
        # the same DATE - an 06:00 rota reads before a 20:00 one.
        if bucket['first_shift'] is None:
            bucket['first_shift'] = shift
        if shift.shift_date == today:
            bucket['today'] += 1
        if shift.starts_at > now and bucket['next_shift'] is None:
            bucket['next_shift'] = shift

        active = [a for a in shift.assignments if a.state == STATE_ACTIVE]
        if active:
            bucket['staffed'] += 1
        running = shift.is_running(now)
        for row in active:
            bucket['assignments'] += 1
            status = row.status_at(now, signin_grace, signoff_grace)
            if status == ST_DONE:
                bucket['done'] += 1
            elif status in MISSED_STATUSES:
                bucket['missed'] += 1
            else:
                bucket['upcoming'] += 1
            if running and row.signed_in_at and not row.signed_off_at:
                bucket['on_now'] += 1

    out = []
    for rota in rotas:
        bucket = tally[rota.id]
        members = member_counts.get(rota.id, 0)
        unstaffed = max(0, bucket['shifts'] - bucket['staffed'])
        stats = {
            'shifts': bucket['shifts'],
            'members': members,
            'assignments': bucket['assignments'],
            'done': bucket['done'],
            'missed': bucket['missed'],
            'upcoming': bucket['upcoming'],
            'unstaffed': unstaffed,
            'attendance_pct': _pct(bucket['done'],
                                   bucket['done'] + bucket['missed']),
        }
        out.append({
            'rota': rota,
            'stats': stats,
            'coverage': _pct(bucket['staffed'], bucket['shifts']),
            'on_now': bucket['on_now'],
            'next_shift': bucket['next_shift'],
            'first_shift': bucket['first_shift'],
            'today': bucket['today'],
            'headline': _headline(rota, stats, bucket),
        })

    out.sort(key=_overview_order)
    return out


# A date that sorts after every real one, for a rota with no shifts yet and
# therefore no start. It goes LAST rather than first: a rota that has not
# been scheduled has not started, so there is no start time to place it by,
# and putting it at the top would push every rota that does have one down.
_NO_START = date(9999, 12, 31)


def _overview_order(row):
    """Sort key for the overview grid: BY START TIME, earliest first.

    The rota's own start - the first date it covers - is what orders the
    cards, so the grid reads as a timeline: what ran first, then what is
    running, then what is coming. It is the same order on the dashboard and
    on the Rotas screen.

    The start is a DATE, so two rotas beginning on the same day would sort
    arbitrarily; the first shift's clock time breaks that tie, and the name
    breaks it again for two rotas that also start at the same minute.
    """
    rota = row['rota']
    start = rota.start_date or _NO_START
    first = row.get('first_shift')
    minute = (first.starts_at.hour * 60 + first.starts_at.minute) \
        if first is not None else 0
    return (start, minute, rota.name.lower())


def _headline(rota, stats, bucket):
    """The ONE thing worth saying about a rota, as (tone, words).

    Ordered by what somebody would act on first, and it stops at the first
    match: a rota with a missed shift AND an empty one is reported as missing
    cover, because cover is the thing that has not happened yet.
    """
    if rota.status == STATUS_DRAFT:
        if not stats['shifts']:
            return ('warn', 'No shifts yet')
        if not stats['members']:
            return ('warn', 'Nobody on the team yet')
        if stats['unstaffed']:
            return ('warn', '{0} shift{1} unstaffed'.format(
                stats['unstaffed'], '' if stats['unstaffed'] == 1 else 's'))
        return ('quiet', 'Ready to publish')
    if rota.status == STATUS_CLOSED:
        return ('quiet', 'Closed')
    if stats['unstaffed']:
        return ('bad', '{0} shift{1} with nobody on'.format(
            stats['unstaffed'], '' if stats['unstaffed'] == 1 else 's'))
    if stats['missed']:
        return ('bad', '{0} missed action{1}'.format(
            stats['missed'], '' if stats['missed'] == 1 else 's'))
    if bucket['on_now']:
        return ('go', '{0} on shift now'.format(bucket['on_now']))
    if bucket['today']:
        return ('go', '{0} shift{1} today'.format(
            bucket['today'], '' if bucket['today'] == 1 else 's'))
    if bucket['next_shift'] is not None:
        return ('quiet', 'Next {0}'.format(
            bucket['next_shift'].shift_date.strftime('%a %d %b')))
    return ('quiet', 'Nothing scheduled')


def my_assignments(db_session, user, start=None, end=None, limit=None,
                   include_drafts=False):
    """This person's own shifts, earliest first.

    Draft rotas are excluded by default: a rota that has not been published is
    a plan, and showing somebody a shift they may never be asked to work is
    how a roster loses its authority.
    """
    query = (db_session.query(RotaAssignment)
             .join(RotaShift, RotaShift.id == RotaAssignment.shift_id)
             .join(Rota, Rota.id == RotaAssignment.rota_id)
             .options(joinedload(RotaAssignment.shift),
                      joinedload(RotaAssignment.rota))
             .filter(RotaAssignment.user_id == user.id,
                     RotaAssignment.state == STATE_ACTIVE))
    if not include_drafts:
        query = query.filter(Rota.status != STATUS_DRAFT)
    if start is not None:
        query = query.filter(RotaShift.ends_at >= start)
    if end is not None:
        query = query.filter(RotaShift.starts_at <= end)
    query = query.order_by(RotaShift.starts_at.asc())
    if limit:
        query = query.limit(limit)
    return query.all()


def assignments_in_range(db_session, start, end, rota_ids=None):
    """Every active assignment overlapping a window, for the schedule grid."""
    query = (db_session.query(RotaAssignment)
             .join(RotaShift, RotaShift.id == RotaAssignment.shift_id)
             .options(joinedload(RotaAssignment.shift),
                      joinedload(RotaAssignment.user),
                      joinedload(RotaAssignment.rota))
             .filter(RotaAssignment.state == STATE_ACTIVE,
                     RotaShift.ends_at >= start,
                     RotaShift.starts_at <= end))
    if rota_ids is not None:
        if not rota_ids:
            return []
        query = query.filter(RotaAssignment.rota_id.in_(tuple(rota_ids)))
    return query.order_by(RotaShift.starts_at.asc()).all()


def shifts_in_range(db_session, start, end, rota_ids=None):
    query = (db_session.query(RotaShift)
             .options(joinedload(RotaShift.assignments)
                      .joinedload(RotaAssignment.user),
                      joinedload(RotaShift.rota))
             .filter(RotaShift.ends_at >= start, RotaShift.starts_at <= end))
    if rota_ids is not None:
        if not rota_ids:
            return []
        query = query.filter(RotaShift.rota_id.in_(tuple(rota_ids)))
    return query.order_by(RotaShift.starts_at.asc()).all()


def eligible_members(db_session, rota, shift=None):
    """The roster, minus anybody already on this shift.

    Sorted by name rather than by when they were added: the control is a list
    somebody reads, and insertion order is meaningless to the reader.
    """
    taken = set()
    if shift is not None:
        taken = {a.user_id for a in shift.assignments
                 if a.state == STATE_ACTIVE}
    rows = (db_session.query(RotaMember)
            .options(joinedload(RotaMember.user))
            .filter(RotaMember.rota_id == rota.id).all())
    out = [m for m in rows if m.user is not None and m.user_id not in taken]
    out.sort(key=lambda m: person_name(m.user).lower())
    return out


def person_name(person):
    if person is None:
        return 'Unknown'
    first = (getattr(person, 'firstname', '') or '').strip()
    last = (getattr(person, 'lastname', '') or '').strip()
    full = ' '.join(part for part in (first, last) if part)
    return full or getattr(person, 'username', None) or 'Unknown'


def clash_for(db_session, user_id, starts_at, ends_at, exclude_shift_id=None):
    """An active assignment this person already holds over the same window.

    Overlap, not equality: a 09:00-17:00 shift and a 16:00-00:00 one are a
    clash even though neither boundary matches.
    """
    query = (db_session.query(RotaAssignment)
             .join(RotaShift, RotaShift.id == RotaAssignment.shift_id)
             .options(joinedload(RotaAssignment.shift),
                      joinedload(RotaAssignment.rota))
             .filter(RotaAssignment.user_id == user_id,
                     RotaAssignment.state == STATE_ACTIVE,
                     RotaShift.starts_at < ends_at,
                     RotaShift.ends_at > starts_at))
    if exclude_shift_id:
        query = query.filter(RotaShift.id != exclude_shift_id)
    return query.first()


# ===========================================================================
# Building the shifts
#
# This is the whole of "create a rota for a specific day, week or month". The
# form collects a cover choice, one date, a set of weekdays and one or more
# time windows; the two functions below turn that into shift rows and nothing
# else happens.
# ===========================================================================

def cover_dates(frequency, anchor, weekdays=None, week_start=0):
    """The dates a cover choice expands to.

    ``anchor`` is one date the user picked, and the frequency decides what it
    means: the day itself, the week containing it, or the month containing
    it. Choosing a date INSIDE the period rather than asking for a start and
    an end is what makes the form one control instead of two - and there is no
    week a user can pick that is not a real week.

    ``weekdays`` is a set of Python weekday numbers (Monday 0). Empty or None
    means every day of the period; it is ignored for a single day, where the
    user has already named the date they want.
    """
    if frequency == FREQ_DAY:
        return [anchor]

    if frequency == FREQ_WEEK:
        offset = (anchor.weekday() - week_start) % 7
        first = anchor - timedelta(days=offset)
        span = [first + timedelta(days=i) for i in range(7)]
    elif frequency == FREQ_MONTH:
        last_day = calendar.monthrange(anchor.year, anchor.month)[1]
        span = [date(anchor.year, anchor.month, day)
                for day in range(1, last_day + 1)]
    else:                                                  # pragma: no cover
        return [anchor]

    if weekdays:
        span = [d for d in span if d.weekday() in weekdays]
    return span


def build_shifts(db_session, rota, frequency, anchor, windows, weekdays=None,
                 week_start=0, actor=None):
    """Create the shift rows for a cover choice. Returns (created, skipped).

    ``windows`` is a list of (label, start_time, end_time). A window whose end
    is at or before its start is read as crossing midnight and lands on the
    following day - which is how a 22:00-06:00 night shift is entered without
    a second date field.

    A window that already exists on the date is SKIPPED rather than
    duplicated, so re-running the builder to add a shift to an existing rota
    is safe and the count reported back is honest about what it did.
    """
    dates = cover_dates(frequency, anchor, weekdays, week_start)
    if not dates or not windows:
        return 0, 0

    existing = {(s.shift_date, s.starts_at, s.ends_at)
                for s in db_session.query(RotaShift).filter(
                    RotaShift.rota_id == rota.id).all()}

    created = skipped = 0
    for day in dates:
        for label, start_time, end_time in windows:
            starts_at = datetime.combine(day, start_time)
            ends_at = datetime.combine(day, end_time)
            if ends_at <= starts_at:
                ends_at += timedelta(days=1)

            key = (day, starts_at, ends_at)
            if key in existing:
                skipped += 1
                continue
            if created >= MAX_SHIFTS_PER_BUILD:
                skipped += 1
                continue

            db_session.add(RotaShift(
                rota_id=rota.id, shift_date=day, starts_at=starts_at,
                ends_at=ends_at, label=(label or None)))
            existing.add(key)
            created += 1

    if created:
        db_session.flush()
        refresh_span(db_session, rota)
        audit.record(db_session, 'shift.created', actor=actor, rota=rota,
                     detail='{0} shift(s) over {1} date(s)'.format(
                         created, len(dates)))
    return created, skipped


def refresh_span(db_session, rota):
    """Keep Rota.start_date / end_date in step with the shifts.

    Called after anything that adds or removes a shift. Storing the span costs
    this one function and saves every list screen an aggregate over the shift
    table.
    """
    row = db_session.query(func.min(RotaShift.shift_date),
                           func.max(RotaShift.shift_date)).filter(
        RotaShift.rota_id == rota.id).first()
    rota.start_date = row[0] if row else None
    rota.end_date = row[1] if row else None


# ===========================================================================
# Staffing
# ===========================================================================

def assign(db_session, shift, user_id, actor=None):
    """Put one person on one shift. Returns (assignment, error).

    Both outcomes are values rather than exceptions because every caller is a
    route that has to turn the failure into a flash message anyway.
    """
    member = db_session.query(RotaMember).filter(
        RotaMember.rota_id == shift.rota_id,
        RotaMember.user_id == user_id).first()
    if member is None:
        return None, 'That person is not on this rota.'

    existing = db_session.query(RotaAssignment).filter(
        RotaAssignment.shift_id == shift.id,
        RotaAssignment.user_id == user_id).first()
    if existing is not None:
        if existing.state == STATE_ACTIVE:
            return None, 'They are already on this shift.'
        # Reinstating somebody who was taken off. Clearing the cancellation
        # rather than inserting a second row keeps one history per person per
        # shift, which is what the unique constraint is there to guarantee.
        existing.state = STATE_ACTIVE
        existing.cancelled_at = None
        existing.cancel_reason = None
        audit.record(db_session, 'assignment.created', actor=actor,
                     rota=shift.rota, shift=shift, assignment=existing,
                     subject=member.user, detail='Reinstated')
        return existing, None

    row = RotaAssignment(shift_id=shift.id, rota_id=shift.rota_id,
                         user_id=user_id, state=STATE_ACTIVE)
    db_session.add(row)
    db_session.flush()
    audit.record(db_session, 'assignment.created', actor=actor,
                 rota=shift.rota, shift=shift, assignment=row,
                 subject=member.user)
    return row, None


def unassign(db_session, assignment, actor=None, reason=None):
    """Take somebody off a shift.

    Cancelled, not deleted. A member who was on Saturday and then was not is
    a fact the schedule has to be able to answer for, and a deleted row
    answers nothing.
    """
    assignment.state = STATE_CANCELLED
    assignment.cancelled_at = datetime.now()
    assignment.cancel_reason = (reason or '')[:200] or None
    audit.record(db_session, 'assignment.cancelled', actor=actor,
                 rota=assignment.rota, shift=assignment.shift,
                 assignment=assignment, subject=assignment.user,
                 reason=reason)


# ===========================================================================
# Clock in and clock out
#
# The two actions the whole module exists to record. Each returns (ok,
# message); the message is shown to the person either way, so a refusal has to
# say WHY in words they can act on.
# ===========================================================================

def clock_in(db_session, assignment, actor, now=None):
    now = now or datetime.now()
    shift = assignment.shift
    rota = assignment.rota
    signin_grace, _, _ = graces(rota)

    if assignment.state != STATE_ACTIVE:
        return False, 'This shift was cancelled.'
    if rota.status == STATUS_DRAFT:
        return False, 'This rota has not been published yet.'
    if assignment.signed_in_at:
        return False, 'You have already clocked in for this shift.'

    # Clocking in early is allowed inside the reminder window and refused
    # before it. Somebody arriving twenty minutes early should not be told to
    # wait; somebody clocking in two days early has misread the rota, and
    # letting them do it silently turns the record into fiction.
    _, _, reminder = graces(rota)
    earliest = shift.starts_at - timedelta(minutes=reminder)
    if now < earliest:
        return False, ('This shift starts at {0}. You can clock in from {1}.'
                       .format(shift.starts_at.strftime('%H:%M on %d %b'),
                               earliest.strftime('%H:%M')))
    if now >= shift.ends_at:
        return False, ('This shift ended at {0}. Ask a rota admin to record '
                       'your attendance.'.format(
                           shift.ends_at.strftime('%H:%M on %d %b')))

    assignment.signed_in_at = now
    assignment.recorded_by = None
    assignment.signin_was_late = now > shift.starts_at + timedelta(
        minutes=signin_grace)
    audit.record(db_session, 'assignment.signed_in', actor=actor, rota=rota,
                 shift=shift, assignment=assignment, subject=assignment.user,
                 detail='Late' if assignment.signin_was_late else 'On time')

    if assignment.signin_was_late:
        return True, 'Clocked in. This was recorded as a late clock-in.'
    return True, 'Clocked in. Have a good shift.'


def clock_out(db_session, assignment, actor, note=None, now=None):
    now = now or datetime.now()
    shift = assignment.shift
    rota = assignment.rota
    _, signoff_grace, _ = graces(rota)

    if assignment.state != STATE_ACTIVE:
        return False, 'This shift was cancelled.'
    if not assignment.signed_in_at:
        return False, 'Clock in first - there is no shift to clock out of.'
    if assignment.signed_off_at:
        return False, 'You have already clocked out of this shift.'

    assignment.signed_off_at = now
    assignment.signoff_was_late = now > shift.ends_at + timedelta(
        minutes=signoff_grace)
    if note:
        assignment.note = note
    audit.record(db_session, 'assignment.signed_off', actor=actor, rota=rota,
                 shift=shift, assignment=assignment, subject=assignment.user,
                 detail='Late' if assignment.signoff_was_late else 'On time')

    if now < shift.ends_at:
        return True, ('Clocked out early - the shift runs until {0}.'
                      .format(shift.ends_at.strftime('%H:%M')))
    return True, 'Clocked out. Thank you.'


def record_attendance(db_session, assignment, actor, signed_in_at=None,
                      signed_off_at=None, note=None):
    """An admin recording that somebody did work a shift.

    The one path by which a third party may write these timestamps, and it
    stamps ``recorded_by`` so the record says plainly that it was not the
    member who entered it. See the module docstring.
    """
    if assignment.state != STATE_ACTIVE:
        return False, 'This assignment was cancelled.'
    if not (signed_in_at or signed_off_at):
        return False, 'Give a clock-in time, a clock-out time, or both.'

    shift = assignment.shift
    rota = assignment.rota
    signin_grace, signoff_grace, _ = graces(rota)

    if signed_in_at and signed_off_at and signed_off_at < signed_in_at:
        return False, 'The clock-out time is before the clock-in time.'

    if signed_in_at:
        assignment.signed_in_at = signed_in_at
        assignment.signin_was_late = signed_in_at > shift.starts_at + \
            timedelta(minutes=signin_grace)
    if signed_off_at:
        if not assignment.signed_in_at:
            return False, 'Record a clock-in time as well - a clock-out on '\
                          'its own does not say the shift was worked.'
        assignment.signed_off_at = signed_off_at
        assignment.signoff_was_late = signed_off_at > shift.ends_at + \
            timedelta(minutes=signoff_grace)
    if note:
        assignment.note = note
    assignment.recorded_by = actor.id

    audit.record(db_session, 'assignment.recorded', actor=actor, rota=rota,
                 shift=shift, assignment=assignment, subject=assignment.user,
                 detail='Recorded on their behalf')
    return True, 'Attendance recorded for {0}.'.format(
        person_name(assignment.user))


# ===========================================================================
# Publishing
# ===========================================================================

def publish_blockers(db_session, rota):
    """Why this rota cannot be published yet. Empty list means it can."""
    problems = []
    shifts = db_session.query(func.count(RotaShift.id)).filter(
        RotaShift.rota_id == rota.id).scalar() or 0
    if not shifts:
        problems.append('There are no shifts yet - add the schedule first.')

    members = db_session.query(func.count(RotaMember.id)).filter(
        RotaMember.rota_id == rota.id).scalar() or 0
    if not members:
        problems.append('Nobody is on the team yet - add members first.')

    staffed = db_session.query(func.count(func.distinct(
        RotaAssignment.shift_id))).filter(
        RotaAssignment.rota_id == rota.id,
        RotaAssignment.state == STATE_ACTIVE).scalar() or 0
    if shifts and not staffed:
        problems.append('No shift has anybody on it yet.')
    return problems


def publish(db_session, rota, actor=None):
    """Make the rota live. Returns (people_to_email, error).

    Publishing is what turns a plan into an instruction: from this moment the
    shifts appear on people's My Shifts, the sweep starts watching them, and
    an alert can be raised. That is why a rota with no shifts or no members
    cannot be published - there would be nothing to instruct anybody to do.

    A rota with SOME unstaffed shifts publishes happily. Unstaffed cover is a
    normal state of a live rota and the screens are built to show it; refusing
    to publish until it is perfect only means people work from a spreadsheet
    until it is.
    """
    problems = publish_blockers(db_session, rota)
    if problems:
        return [], problems[0]

    was_draft = rota.status == STATUS_DRAFT
    rota.status = STATUS_PUBLISHED
    if not rota.published_at:
        rota.published_at = datetime.now()
    audit.record(db_session, 'rota.published', actor=actor, rota=rota)

    if not was_draft:
        # Re-publishing an already-live rota is how an admin sends the
        # schedule out again after changing it, so it still returns the
        # recipients - it simply does not move the status.
        pass

    return _members_with_shifts(db_session, rota), None


def _members_with_shifts(db_session, rota):
    """[(user, [assignment, ...]), ...] for everybody holding a shift."""
    rows = (db_session.query(RotaAssignment)
            .options(joinedload(RotaAssignment.shift),
                     joinedload(RotaAssignment.user))
            .join(RotaShift, RotaShift.id == RotaAssignment.shift_id)
            .filter(RotaAssignment.rota_id == rota.id,
                    RotaAssignment.state == STATE_ACTIVE)
            .order_by(RotaShift.starts_at.asc()).all())

    grouped = {}
    for row in rows:
        grouped.setdefault(row.user_id, []).append(row)
    out = []
    for user_id, items in grouped.items():
        person = items[0].user
        if person is not None and person.is_active:
            out.append((person, items))
    out.sort(key=lambda pair: person_name(pair[0]).lower())
    return out


def close_rota(db_session, rota, actor=None):
    rota.status = STATUS_CLOSED
    audit.record(db_session, 'rota.closed', actor=actor, rota=rota)


def reopen_rota(db_session, rota, actor=None):
    rota.status = STATUS_PUBLISHED if rota.published_at else STATUS_DRAFT
    audit.record(db_session, 'rota.reopened', actor=actor, rota=rota)


def close_finished_rotas(db_session, now=None):
    """Move a published rota to closed once its last shift is well over.

    Called by the sweep. The delay is a day rather than a minute so that a
    late clock-out on the final shift still lands on a live rota.
    """
    now = now or datetime.now()
    cutoff = (now - timedelta(days=1)).date()
    finished = db_session.query(Rota).filter(
        Rota.status == STATUS_PUBLISHED,
        Rota.end_date.isnot(None),
        Rota.end_date < cutoff).all()
    for rota in finished:
        rota.status = STATUS_CLOSED
        audit.record(db_session, 'rota.closed', rota=rota,
                     detail='Closed automatically - last shift has passed')
    return len(finished)


# ===========================================================================
# Requests
# ===========================================================================

def raise_request(db_session, assignment, actor, kind, target_user_id=None,
                  reason=None):
    """A member asking to be taken off a shift. Returns (request, error)."""
    if assignment.user_id != actor.id:
        return None, 'You can only raise a request about your own shift.'
    if assignment.state != STATE_ACTIVE:
        return None, 'This shift was cancelled.'
    if assignment.signed_in_at:
        return None, 'You have already clocked in for this shift.'
    if assignment.shift.starts_at <= datetime.now():
        return None, 'This shift has already started.'

    open_already = db_session.query(RotaRequest).filter(
        RotaRequest.assignment_id == assignment.id,
        RotaRequest.state == REQ_OPEN).first()
    if open_already is not None:
        return None, 'You already have a request open on this shift.'

    target = None
    if kind == REQ_SWAP:
        if not target_user_id:
            return None, 'Choose who is taking the shift.'
        if target_user_id == actor.id:
            return None, 'Choose somebody other than yourself.'
        target = db_session.query(RotaMember).filter(
            RotaMember.rota_id == assignment.rota_id,
            RotaMember.user_id == target_user_id).first()
        if target is None:
            return None, 'That person is not on this rota.'
        clash = clash_for(db_session, target_user_id,
                          assignment.shift.starts_at,
                          assignment.shift.ends_at)
        if clash is not None:
            return None, ('{0} is already on another shift at that time.'
                          .format(person_name(target.user)))

    row = RotaRequest(rota_id=assignment.rota_id, assignment_id=assignment.id,
                      kind=kind, state=REQ_OPEN, requested_by=actor.id,
                      target_user_id=target_user_id if kind == REQ_SWAP
                      else None,
                      reason=reason)
    db_session.add(row)
    db_session.flush()
    audit.record(db_session, 'request.raised', actor=actor,
                 rota=assignment.rota, shift=assignment.shift,
                 assignment=assignment, detail=kind, reason=reason)
    return row, None


def decide_request(db_session, request, actor, approve, note=None):
    """Approve or decline. Returns (message, error).

    APPROVING A SWAP moves the assignment to the named person rather than
    creating a second one, so the shift keeps its handover and its history.
    APPROVING A LEAVE cancels the assignment and leaves the shift short - the
    schedule then shows it as unstaffed, which is the honest state and the one
    somebody has to act on.
    """
    if request.state != REQ_OPEN:
        return None, 'This request has already been decided.'

    assignment = request.assignment
    if assignment is None:                                 # pragma: no cover
        return None, 'The shift this request was about has gone.'

    request.state = REQ_APPROVED if approve else REQ_DECLINED
    request.decided_by = actor.id
    request.decided_at = datetime.now()
    request.decision_note = note

    if not approve:
        audit.record(db_session, 'request.decided', actor=actor,
                     rota=request.rota, assignment=assignment,
                     detail='Declined', reason=note)
        return 'Request declined.', None

    if request.kind == REQ_SWAP:
        clash = clash_for(db_session, request.target_user_id,
                          assignment.shift.starts_at, assignment.shift.ends_at,
                          exclude_shift_id=assignment.shift_id)
        if clash is not None:
            request.state = REQ_OPEN
            request.decided_by = None
            request.decided_at = None
            return None, ('{0} has been given another shift at that time '
                          'since this was raised.'.format(
                              person_name(request.target)))
        # The unique constraint is on (shift, user), so a previously
        # cancelled row for the incoming person has to be reused rather than
        # inserted alongside.
        previous = db_session.query(RotaAssignment).filter(
            RotaAssignment.shift_id == assignment.shift_id,
            RotaAssignment.user_id == request.target_user_id).first()
        if previous is not None and previous.id != assignment.id:
            db_session.delete(previous)
            db_session.flush()

        old_name = person_name(assignment.user)
        assignment.user_id = request.target_user_id
        assignment.signed_in_at = None
        assignment.signed_off_at = None
        assignment.signin_was_late = False
        assignment.signoff_was_late = False
        # The alerts raised against the OUTGOING person are about a shift
        # they no longer hold. Clearing them stops the incoming person
        # inheriting somebody else's missed clock-in.
        db_session.query(RotaAlert).filter(
            RotaAlert.assignment_id == assignment.id).delete(
                synchronize_session=False)
        audit.record(db_session, 'request.decided', actor=actor,
                     rota=request.rota, assignment=assignment,
                     subject=request.target, detail='Swap approved',
                     old_value=old_name,
                     new_value=person_name(request.target))
        return 'Swap approved - the shift now belongs to {0}.'.format(
            person_name(request.target)), None

    unassign(db_session, assignment, actor=actor,
             reason='Given up - request approved')
    audit.record(db_session, 'request.decided', actor=actor, rota=request.rota,
                 assignment=assignment, detail='Given up, shift now unstaffed')
    return ('Approved. That shift is now unstaffed - assign somebody from '
            'the schedule.'), None


def withdraw_request(db_session, request, actor):
    if request.state != REQ_OPEN:
        return False, 'This request has already been decided.'
    if request.requested_by != actor.id:
        return False, 'You can only withdraw your own request.'
    request.state = REQ_WITHDRAWN
    request.decided_at = datetime.now()
    audit.record(db_session, 'request.withdrawn', actor=actor,
                 rota=request.rota, assignment=request.assignment)
    return True, 'Request withdrawn.'


def open_requests(db_session, user, rota_ids=None):
    """The queue an admin or lead decides."""
    query = (db_session.query(RotaRequest)
             .options(joinedload(RotaRequest.assignment)
                      .joinedload(RotaAssignment.shift),
                      joinedload(RotaRequest.requester),
                      joinedload(RotaRequest.target),
                      joinedload(RotaRequest.rota))
             .filter(RotaRequest.state == REQ_OPEN))
    if rota_ids is not None:
        if not rota_ids:
            return []
        query = query.filter(RotaRequest.rota_id.in_(tuple(rota_ids)))
    return query.order_by(RotaRequest.created_at.asc()).all()


# ===========================================================================
# Handover
# ===========================================================================

def save_handover(db_session, shift, actor, summary, open_items):
    row = shift.handover
    if row is None:
        row = RotaHandover(shift_id=shift.id, rota_id=shift.rota_id,
                           author_id=actor.id)
        db_session.add(row)
    row.summary = summary or None
    row.open_items = open_items or None
    row.author_id = actor.id
    audit.record(db_session, 'handover.saved', actor=actor, rota=shift.rota,
                 shift=shift)
    return row


def previous_handover(db_session, shift):
    """The last handover written before this shift, on the same rota.

    What the incoming shift needs to read, and the reason the handover screen
    shows two panes rather than one.
    """
    return (db_session.query(RotaHandover)
            .join(RotaShift, RotaShift.id == RotaHandover.shift_id)
            .options(joinedload(RotaHandover.author),
                     joinedload(RotaHandover.shift))
            .filter(RotaHandover.rota_id == shift.rota_id,
                    RotaShift.starts_at < shift.starts_at)
            .order_by(RotaShift.starts_at.desc()).first())


# ===========================================================================
# Alerts feed
# ===========================================================================

def alerts_for(db_session, user, rota_ids=None, limit=20, unseen_only=False):
    """The notification feed on the dashboard.

    A member sees the alerts raised about their own shifts. An admin sees
    those, plus every alert on every rota - because a missed clock-in that
    nobody is watching is the failure this module exists to prevent.
    """
    query = (db_session.query(RotaAlert)
             .options(joinedload(RotaAlert.shift),
                      joinedload(RotaAlert.rota),
                      joinedload(RotaAlert.user)))
    if rota_ids is None:
        query = query.filter(RotaAlert.user_id == user.id)
    elif rota_ids:
        query = query.filter(or_(RotaAlert.user_id == user.id,
                                 RotaAlert.rota_id.in_(tuple(rota_ids))))
    else:
        query = query.filter(RotaAlert.user_id == user.id)
    if unseen_only:
        query = query.filter(RotaAlert.seen_at.is_(None))
    return query.order_by(RotaAlert.created_at.desc()).limit(limit).all()


def dismiss_alert(db_session, alert, actor):
    """Only the person an alert is about may clear it. See RotaAlert."""
    if alert.user_id != actor.id:
        return False
    alert.seen_at = datetime.now()
    return True


# ===========================================================================
# Dashboard
# ===========================================================================

# How many ticks the day axis aims for. Fewer than this and the ruler is too
# coarse to read a start time off; more and the labels collide at the width
# the panel actually gets.
_AXIS_TICKS = 8
_AXIS_STEPS = (1, 2, 3, 4, 6, 8, 12)

# The narrowest a bar may be drawn, as a percentage of the axis. A 30-minute
# shift on a 16-hour day is 3% wide, which is a sliver nobody can click or
# read; it is widened to this, and the times stay on its label either way.
_MIN_BAR_PCT = 7.0


def _axis_step(span_minutes):
    """The tick spacing, in hours, for a day this long."""
    hours = max(1, int(round(span_minutes / 60.0)))
    for step in _AXIS_STEPS:
        if hours / float(step) <= _AXIS_TICKS:
            return step
    return _AXIS_STEPS[-1]


def today_lanes(shifts, now=None, statuses=None, day=None):
    """Today's shifts as ONE LANE PER ROTA on a shared hour axis.

    THE PROBLEM THIS SOLVES. Today's shifts arrive as one flat list in start
    order. With a single rota that reads as a timeline; with three it reads as
    a shuffle, because consecutive rows belong to different rotas and the only
    thing telling them apart is a name in the middle of the row. The question
    somebody actually has on a multi-rota day - "is every rota covered right
    now, and by whom" - takes a full read of the list to answer.

    Laid out as lanes it is a glance: the rota is the row, the hour is the
    column, and a hole in cover is a hole in the row.

    WHY THE GEOMETRY IS COMPUTED HERE rather than in the template. It is
    arithmetic with three edge cases in it - a shift that runs past midnight,
    a shift too short to draw, and a day whose shifts do not start on the
    hour - and a Jinja expression that gets one of them wrong draws a bar in
    the wrong place with no error anywhere. Here it is also testable.

    Returns None when there is nothing today, so the caller falls through to
    its own empty state. Otherwise, the keys the template uses:

        axis_start / axis_end   the span drawn, rounded out to whole hours
        ticks                   [{'label': '08', 'pct': 12.5}, ...]
        now_pct                 where the now-line goes, or None if off-axis
        lanes                   one per rota, unstaffed ones first
    """
    now = now or datetime.now()
    shifts = [s for s in shifts if s.rota is not None]
    if not shifts:
        return None

    # --- the axis -------------------------------------------------------
    # THE AXIS IS THE DAY, and never more than the day.
    #
    # Today's shifts include any that OVERLAP today, so a night shift that
    # began at 20:00 yesterday is on the panel, and one starting at 20:00
    # tonight runs to 04:00 tomorrow. Drawn end to end that is a 32-hour
    # ruler on which the working day is a third of the width - the exact
    # opposite of the point. So every shift is clipped to midnight-to-
    # midnight and the overhang is stated on the bar instead, which is
    # where somebody can actually read it.
    #
    # Within the day the ends are then rounded OUT to whole hours, so the
    # ruler reads in round numbers, and widened to hold NOW - "everything
    # today is over" is only legible if you can still see where now sits.
    day_start = datetime.combine(day or now.date(), time.min)
    day_end = day_start + timedelta(days=1)

    def clip(moment):
        return max(day_start, min(day_end, moment))

    first = min(clip(s.starts_at) for s in shifts)
    last = max(clip(s.ends_at) for s in shifts)
    hour = now.replace(minute=0, second=0, microsecond=0)

    axis_start = min(first, clip(now)).replace(minute=0, second=0,
                                               microsecond=0)
    axis_end = max(last, clip(now))
    if axis_end.minute or axis_end.second or axis_end.microsecond:
        axis_end = axis_end.replace(minute=0, second=0,
                                    microsecond=0) + timedelta(hours=1)
    axis_end = min(axis_end, day_end)
    if axis_end <= hour and hour < day_end:
        axis_end = min(hour + timedelta(hours=1), day_end)

    span = (axis_end - axis_start).total_seconds() / 60.0
    if span <= 0:
        return None

    def pct(moment):
        share = ((clip(moment) - axis_start).total_seconds()
                 / 60.0) / span * 100.0
        return max(0.0, min(100.0, share))

    step = _axis_step(span)
    ticks = []
    tick = axis_start
    while tick <= axis_end:
        ticks.append({'label': tick.strftime('%H'),
                      'pct': round(pct(tick), 4)})
        tick += timedelta(hours=step)

    # --- the lanes ------------------------------------------------------
    statuses = statuses or {}
    lanes = {}
    order = []
    for shift in shifts:
        rota = shift.rota
        if rota.id not in lanes:
            lanes[rota.id] = {'rota': rota, 'bars': [], 'shifts': 0,
                              'unstaffed': 0, 'people': 0, 'on_now': 0,
                              'live': False, 'first': shift.starts_at}
            order.append(rota.id)
        lane = lanes[rota.id]

        active = shift.active_assignments
        running = shift.is_running(now)
        left = pct(shift.starts_at)
        width = pct(shift.ends_at) - left
        # A bar too narrow to read is widened rather than dropped, and pushed
        # back inside the axis if that would run it off the right-hand edge.
        if width < _MIN_BAR_PCT:
            width = _MIN_BAR_PCT
            left = min(left, 100.0 - width)

        people = []
        for row in active:
            status = statuses.get(row.id)
            if status is None:
                status = ('done' if row.signed_off_at
                          else ('on_shift' if row.signed_in_at
                                else 'upcoming'))
            people.append({'assignment': row, 'status': status,
                           'name': person_name(row.user)})
            if status == 'on_shift':
                lane['on_now'] += 1

        lane['shifts'] += 1
        lane['people'] += len(people)
        if not active:
            lane['unstaffed'] += 1
        if running:
            lane['live'] = True

        lane['bars'].append({
            'shift': shift,
            'left_pct': round(left, 4),
            'width_pct': round(width, 4),
            'running': running,
            'over': shift.ends_at <= now,
            'overnight': shift.ends_at > day_end,
            'from_yesterday': shift.starts_at < day_start,
            'people': people,
            'tone': ('empty' if not active
                     else ('running' if running
                           else ('done' if shift.ends_at <= now else 'ahead'))),
        })

    # UNSTAFFED LANES FIRST. Everything else on the panel is a report; an
    # empty bar is the one row somebody has to act on today, so it does not
    # get to sit third just because that rota starts later.
    rows = [lanes[rid] for rid in order]
    rows.sort(key=lambda lane: (0 if lane['unstaffed'] else 1, lane['first']))

    return {
        'axis_start': axis_start,
        'axis_end': axis_end,
        'span_minutes': int(span),
        'ticks': ticks,
        'now_pct': (round(pct(now), 4)
                    if axis_start <= now <= axis_end else None),
        'lanes': rows,
        'rota_count': len(rows),
        'shift_count': len(shifts),
        'unstaffed': sum(lane['unstaffed'] for lane in rows),
    }


def dashboard(db_session, user, now=None):
    """Everything the overview screen shows, in one call.

    Gathered here rather than in the route so the numbers on the dashboard and
    the numbers on every other screen come from the same rules - a dashboard
    that disagrees with the page it links to is worse than no dashboard.
    """
    now = now or datetime.now()
    admin = is_rota_admin(db_session, user)
    day_start = datetime.combine(now.date(), time.min)
    day_end = day_start + timedelta(days=1)

    scope_ids = visible_rota_ids(db_session, user) if admin else None

    # --- the viewer's own position -------------------------------------
    mine = my_assignments(db_session, user, start=now - timedelta(days=2),
                          end=now + timedelta(days=14))
    my_rows = []
    for row in mine:
        signin_grace, signoff_grace, _ = graces(row.rota)
        my_rows.append((row, row.status_at(now, signin_grace, signoff_grace)))

    actions = [(a, s) for a, s in my_rows if s in ACTION_STATUSES]
    upcoming = [(a, s) for a, s in my_rows
                if a.shift.starts_at > now][:6]
    on_now = next((a for a, s in my_rows if a.shift.is_running(now)), None)

    # --- today, across everything the viewer can see --------------------
    today_shifts = shifts_in_range(db_session, day_start, day_end,
                                   rota_ids=scope_ids)
    today_shifts = [s for s in today_shifts if s.rota is not None
                    and s.rota.status != STATUS_DRAFT]

    on_shift_now = 0
    today_total = today_expected = today_in = 0
    # The per-assignment status, resolved ONCE and handed to today_lanes, so
    # the chip on a bar and the figures beside the panel title cannot come
    # from two different readings of the same row.
    today_statuses = {}
    for shift in today_shifts:
        for row in shift.assignments:
            if row.state != STATE_ACTIVE:
                continue
            today_total += 1
            if row.signed_in_at:
                today_in += 1
                if not row.signed_off_at and shift.is_running(now):
                    on_shift_now += 1
            if shift.starts_at <= now:
                today_expected += 1
            today_statuses[row.id] = (
                'done' if row.signed_off_at
                else ('on_shift' if row.signed_in_at else 'upcoming'))

    # --- missed actions, across the same scope --------------------------
    window_start = now - timedelta(days=7)
    watch = assignments_in_range(db_session, window_start, now,
                                 rota_ids=scope_ids)
    if not admin:
        watch = [a for a in watch if a.user_id == user.id]
    missed = []
    for row in watch:
        if row.rota is None or row.rota.status == STATUS_DRAFT:
            continue
        signin_grace, signoff_grace, _ = graces(row.rota)
        status = row.status_at(now, signin_grace, signoff_grace)
        if status in MISSED_STATUSES:
            missed.append((row, status))
    missed.sort(key=lambda pair: pair[0].shift.starts_at, reverse=True)

    # --- unstaffed cover in the next week -------------------------------
    gaps = []
    if admin:
        ahead = shifts_in_range(db_session, now, now + timedelta(days=7),
                                rota_ids=scope_ids)
        gaps = [s for s in ahead
                if s.rota is not None and s.rota.status != STATUS_DRAFT
                and not s.active_assignments]

    # The rota overview - the body of the redesigned dashboard. Gathered
    # here rather than in the route so the route makes ONE service call and
    # the figures on the cards come from the same clock as everything above.
    overview = rota_overview(db_session, user, now=now)

    return {
        'now': now,
        'is_admin': admin,
        'overview': overview,
        'rota_count': len(overview),
        'live_count': sum(1 for row in overview
                          if row['rota'].status == STATUS_PUBLISHED),
        'draft_count': sum(1 for row in overview
                           if row['rota'].status == STATUS_DRAFT),
        'needs_staffing': sum(1 for row in overview
                              if row['stats']['unstaffed']),
        'my_actions': actions,
        'my_upcoming': upcoming,
        'my_total': len(my_rows),
        'on_now': on_now,
        'today_shifts': today_shifts,
        'today_lanes': today_lanes(today_shifts, now=now,
                                   statuses=today_statuses,
                                   day=now.date()),
        'today_total': today_total,
        'today_signed_in': today_in,
        'today_attendance_pct': _pct(today_in, today_expected),
        'on_shift_now': on_shift_now,
        'missed': missed[:12],
        'missed_count': len(missed),
        'gaps': gaps[:8],
        'gap_count': len(gaps),
        'alerts': alerts_for(db_session, user, rota_ids=scope_ids, limit=8),
        'open_requests': (open_requests(db_session, user, rota_ids=scope_ids)
                          if admin else []),
    }
