"""
scheduler.py - ServiceNow open-incident afternoon digest.

Mirrors the to-do / certificate scheduler lifecycle: an in-process APScheduler
BackgroundScheduler with its OWN jobstore table (``apscheduler_jobs_snow_open``)
so it never loads or fires the health-check / MIMP / cert / to-do jobs.

  * snow_open_incident_digest - every afternoon at SNOW_OPEN_DIGEST_HOUR:MINUTE
    (14:00 local by default). Emails a professional per-group summary for the
    MOST RECENT open-incident, open-service-request and open-change-request
    uploads (each kind as its own labelled email set), to every group that has
    escalation contacts configured under Manage Members. Groups without a
    mapping are silently skipped. Incidents and service requests are addressed
    by assignment group (open_incident_email); change requests by technical
    reviewer group (open_change_email).

Deployment model (identical to the other schedulers):
  * The dedicated Windows service (health_monitor_app_sched.py) owns the
    schedule in production and calls init_open_incident_monitoring().
  * The in-process Flask scheduler may also start it, guarded by
    RUN_SCHEDULERS_IN_APP in main_app.py. The job is a daily cron with
    coalesce=True and max_instances=1, so a second runner is harmless.
"""

import logging
import os
import threading
from typing import Optional

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from tzlocal import get_localzone

from database import engine

logger = logging.getLogger(__name__)

# Afternoon digest time (local). Override with SNOW_OPEN_DIGEST_HOUR / _MINUTE.
_DIGEST_HOUR = int(os.environ.get('SNOW_OPEN_DIGEST_HOUR', '14'))
_DIGEST_MINUTE = int(os.environ.get('SNOW_OPEN_DIGEST_MINUTE', '0'))

_JOBSTORE_TABLE = os.environ.get('SNOW_OPEN_APSCHEDULER_TABLE', 'apscheduler_jobs_snow_open')
_DIGEST_JOB = 'snow_open_incident_digest'

_init_lock = threading.Lock()
_scheduler: Optional[BackgroundScheduler] = None


def _digest_safe():
    """Scheduler entry point - never lets an exception kill the thread.

    The three item kinds are dispatched independently and each is wrapped on
    its own, so a failure in one (a bad upload, an SMTP refusal) can never stop
    the others going out.
    """
    try:
        from .open_incident_email import dispatch_latest_open_incident_digest
        dispatch_latest_open_incident_digest()
    except Exception:
        logger.exception('Open-incident afternoon digest crashed (suppressed).')

    try:
        from .open_change_email import dispatch_latest_open_change_digest
        dispatch_latest_open_change_digest()
    except Exception:
        logger.exception('Open-change afternoon digest crashed (suppressed).')


def init_open_incident_monitoring() -> None:
    """Start the in-process open-incident digest scheduler. Idempotent."""
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            logger.info('Open-incident monitoring already running - skipping re-init.')
            return

        _scheduler = BackgroundScheduler(
            jobstores={'default': SQLAlchemyJobStore(engine=engine, tablename=_JOBSTORE_TABLE)},
            job_defaults={'coalesce': True, 'max_instances': 1, 'misfire_grace_time': 3600},
            timezone=get_localzone(),
        )
        _scheduler.add_job(
            func=_digest_safe,
            trigger=CronTrigger(hour=_DIGEST_HOUR, minute=_DIGEST_MINUTE),
            id=_DIGEST_JOB,
            name=f'Open incident + service request + change request afternoon digest (daily {_DIGEST_HOUR:02d}:{_DIGEST_MINUTE:02d})',
            replace_existing=True,
        )
        _scheduler.start()
        logger.info('Open-incident monitoring started - digest at %02d:%02d local.',
                    _DIGEST_HOUR, _DIGEST_MINUTE)


def shutdown_open_incident_monitoring() -> None:
    """Cleanly stop the scheduler. Call from service teardown / atexit."""
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            _scheduler.shutdown(wait=False)
            logger.info('Open-incident monitoring stopped.')
        _scheduler = None
