"""
Capture per-person ServiceNow workload from a Batch Analysis upload.

Called (best-effort, never fatal) right after an upload is analysed. Each
new file COMPLETELY REFRESHES the workload rows *of its ticket type*:
previously captured tickets of that type are removed and replaced by the
rows of this upload that carry both a ticket number and an assignee.
Incident and service-request exports are uploaded separately, so scoping
the wipe by type keeps the latest dump of EACH kind as the source of truth
without the two uploads clobbering one another.

The upload `kind` ("batch" = incident section, "sr" = service-request
section) is authoritative for that scoping: the wipe always covers the
kind's ticket type - even when the new file has no assignable rows, so
stale counts never outlive the upload that superseded them - and a ticket
number whose prefix isn't recognised (custom numbering schemes) still
lands in the uploading section's bucket instead of an invisible 'other'.

The Resource Utilization module reads the table to show, next to each
person, the incidents / service requests they worked in the last year -
as a count, a monthly trend, a priority profile, ML-derived themes of a
similar nature, and a downloadable Excel ticket list.

Honest attributes
-----------------
The descriptive columns are read from the RAW mapped frame, not from the
preprocessed one. preprocess() fills a blank categorical with that
column's mode, which is the right call for aggregate model input but
would stamp the modal priority / category onto an individual's ticket
list and make a person look like they worked something they did not.
Anything the export left blank is therefore stored as NULL, and every
downstream view reports it as "Not set" rather than guessing.
"""

import logging

import pandas as pd

from database import get_db_session

from .ml.column_mapper import map_columns
from .ml.preprocess import normalise_priority, normalise_state
from .models import SnowTicketWorkload, classify_ticket_number

logger = logging.getLogger(__name__)


# Upload section -> the ticket type it is the source of truth for.
KIND_DEFAULT_TYPE = {'batch': 'incident', 'sr': 'service_request'}

# Raw mapped feature -> (workload column, max length the column holds).
_RAW_TEXT_FIELDS = {
    'category': ('category', 200),
    'subcategory': ('subcategory', 200),
    'title': ('short_description', 500),
    'assignment_group': ('assignment_group', 200),
}

# Values that mean "the export said nothing" once stringified.
_BLANK_TOKENS = {'', 'nan', 'none', 'null', 'nat'}


def resolve_ticket_type(number, kind=None):
    """
    Ticket type from the number prefix, falling back to the upload kind's
    type when the prefix is unrecognised - so every ticket in an incident
    upload counts as an incident and every one in a service-request upload
    counts as a service request, whatever the numbering scheme.
    """
    ticket_type = classify_ticket_number(number)
    if ticket_type == 'other':
        return KIND_DEFAULT_TYPE.get(kind, ticket_type)
    return ticket_type


def _clean(value, limit=None):
    """Trimmed string, or None when the export said nothing."""
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass                       # arrays / odd types: fall through
    text = str(value).strip()
    if text.lower() in _BLANK_TOKENS:
        return None
    return text[:limit] if limit else text


def _timestamp(value):
    """A python datetime, or None when absent / unparseable."""
    if value is None:
        return None
    parsed = pd.to_datetime(value, errors='coerce')
    if parsed is None or pd.isna(parsed):
        return None
    return parsed.to_pydatetime()


def _raw_attributes(raw_df):
    """
    {ticket number: {column: value}} of the descriptive attributes, read
    from the export BEFORE null-filling so a blank cell stays blank.

    Returns {} when no raw frame was supplied - the caller then stores
    only what it can state honestly (number, type, assignee, opened).
    """
    if raw_df is None or not len(raw_df):
        return {}
    try:
        mapped = map_columns(raw_df)
    except Exception as exc:            # never fail an upload over context
        logger.warning('Could not map raw columns for workload '
                       'attributes: %s', exc)
        return {}

    attributes = {}
    for _, row in mapped.iterrows():
        number = _clean(row.get('incident_id'))
        if not number:
            continue
        entry = {}
        for feature, (column, limit) in _RAW_TEXT_FIELDS.items():
            entry[column] = _clean(row.get(feature), limit)
        # Priority and state are normalised (P1..P4 / Open, Resolved, ...)
        # but ONLY when the export actually carried a value: both
        # normalisers default a blank to a real-looking label ("P3" /
        # "Unknown"), which is exactly the fabrication to avoid here.
        raw_priority = _clean(row.get('priority'))
        entry['priority'] = (normalise_priority(raw_priority)
                             if raw_priority else None)
        raw_state = _clean(row.get('state'))
        entry['state'] = (_clean(normalise_state(raw_state), 60)
                          if raw_state else None)
        entry['resolved_at'] = _timestamp(row.get('resolved_timestamp'))
        attributes[number] = entry
    return attributes


def capture_assigned_workload(full_df, kind=None, raw_df=None) -> int:
    """
    Rebuild snow_ticket_workload from this upload; returns rows stored.

    full_df - the preprocessed frame; authoritative for which rows are
              real tickets carrying a real assignee.
    raw_df  - the same upload BEFORE preprocessing, used for the
              descriptive attributes so null-filled values never reach an
              individual's ticket list. Optional: without it the rows are
              stored with counts and dates only.
    """
    default_type = KIND_DEFAULT_TYPE.get(kind)
    if full_df is None or not len(full_df):
        return 0
    if 'incident_id' not in full_df.columns or \
            'assigned_to' not in full_df.columns:
        return 0

    attributes = _raw_attributes(raw_df)

    # Deduplicate within the file (last occurrence wins - exports are
    # typically ordered oldest first, so 'last' is the freshest state).
    records = {}
    has_opened = 'opened_timestamp' in full_df.columns
    for _, row in full_df.iterrows():
        number = str(row.get('incident_id') or '').strip()
        assignee = str(row.get('assigned_to') or '').strip()
        if not number or not assignee or assignee.lower() in ('nan', 'none'):
            continue
        opened = _timestamp(row.get('opened_timestamp')) if has_opened else None
        records[number] = (assignee, opened)

    if not records and not default_type:
        return 0

    # Wipe the upload kind's ticket type (source of truth, even when the
    # new file has no assignable rows) plus any other types it contains -
    # never the other section's data.
    types_present = {resolve_ticket_type(n, kind) for n in records}
    if default_type:
        types_present.add(default_type)

    db_session = get_db_session()
    try:
        removed = (db_session.query(SnowTicketWorkload)
                   .filter(SnowTicketWorkload.ticket_type.in_(types_present))
                   .delete(synchronize_session=False))
        described = 0
        for number, (assignee, opened) in records.items():
            attrs = attributes.get(number)
            if attrs:
                described += 1
            else:
                attrs = {}
            db_session.add(SnowTicketWorkload(
                ticket_number=number,
                ticket_type=resolve_ticket_type(number, kind),
                assigned_to=assignee,
                opened_at=opened,
                resolved_at=attrs.get('resolved_at'),
                priority=attrs.get('priority'),
                category=attrs.get('category'),
                subcategory=attrs.get('subcategory'),
                short_description=attrs.get('short_description'),
                assignment_group=attrs.get('assignment_group'),
                state=attrs.get('state'),
            ))
        db_session.commit()
        logger.info('Workload table refreshed: %d old rows replaced by %d '
                    'from the new upload (%d carry descriptive attributes)',
                    removed, len(records), described)
        return len(records)
    except Exception:
        db_session.rollback()
        raise
    finally:
        db_session.close()
