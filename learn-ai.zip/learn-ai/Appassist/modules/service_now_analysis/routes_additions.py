"""
ROUTE ADDITIONS for modules/service_now_analysis/routes.py
==========================================================

This file contains the NEW imports, helper functions, and route handlers
to add to your existing service_now_analysis/routes.py.

It does NOT replace the existing file - the existing routes (upload,
batch dashboard, summary, incident template, similar incidents,
upload history) all remain unchanged.

Place each block at the indicated location.
"""

# ===========================================================================
# 1. ADDITIONAL IMPORTS - add to the imports at the top of routes.py
# ===========================================================================

# At the top of routes.py, alongside the existing imports, ADD:

from .change_predict import generate_cr_template, cr_models_status
from .ml.similarity import (
    find_similar,                      # already used by existing similar_page
    find_related_problems,             # NEW
    find_similar_with_problems,        # NEW
    synthesize_recommendation,         # already used
)


# ===========================================================================
# 2. NEW HELPER - add near the existing helpers
# ===========================================================================

def _cr_models_status_for_template():
    """Compact status dict used to drive the 'models trained on ...' banner."""
    try:
        return cr_models_status()
    except Exception:
        return {"all_loaded": False, "trained_at": None, "n_changes": None,
                "artifacts": {}, "field_models": []}


# ===========================================================================
# 3. NEW ROUTES - add anywhere in routes.py (after the similar_page block
#    is a natural place)
# ===========================================================================

@service_now_analysis_bp.route("/change-template")
def change_template_page():
    """CR Template Generator (NEW tab)."""
    return render_template(
        "service_now_analysis/change_template.html",
        snow_active="change",
        cr_status=_cr_models_status_for_template(),
    )


@service_now_analysis_bp.route("/api/change-template", methods=["POST"])
def change_template_api():
    """JSON endpoint that drives the CR template generator UI."""
    data = request.get_json(silent=True) or {}

    title          = (data.get("title") or "").strip()
    description    = (data.get("description") or "").strip()
    planned_start  = (data.get("planned_start") or "").strip()
    planned_end    = (data.get("planned_end") or "").strip()
    environment    = (data.get("environment") or "").strip()
    server_list    = (data.get("server_list") or "").strip()
    requested_by   = (data.get("requested_by") or "").strip()

    # Quick input checks (the function below also validates)
    if not title:
        return jsonify({"status": "error",
                        "message": "Title is required."}), 400
    if not description:
        return jsonify({"status": "error",
                        "message": "Description is required."}), 400
    if not planned_start or not planned_end:
        return jsonify({"status": "error",
                        "message": "Planned start and end are required."}), 400

    try:
        result = generate_cr_template(
            title=title,
            description=description,
            planned_start=planned_start,
            planned_end=planned_end,
            environment=environment or None,
            server_list=server_list or None,
            requested_by=requested_by or None,
        )
    except Exception as exc:
        current_app.logger.exception("CR template generation failed")
        return jsonify({"status": "error",
                        "message": f"Generation failed: {exc}"}), 500

    return jsonify(to_json_safe(result))


@service_now_analysis_bp.route("/api/change-status")
def change_status_api():
    """Tiny status endpoint - used by the Change Management landing banner."""
    return jsonify(to_json_safe(_cr_models_status_for_template()))


# ===========================================================================
# 4. MODIFY THE EXISTING similar API ROUTE
# ===========================================================================
# Locate the existing route that backs the Similar Incidents page.  In
# the original similar.html the JS posts to (something like)
# `/api/similar` and the route returns the find_similar(...) output.
#
# Replace the existing call to find_similar(...) with
# find_similar_with_problems(...) so the response also contains a
# `problems` block.  The existing JS in snow.js will be updated to
# render this new section.
# ===========================================================================

# BEFORE - typical existing handler:
#
#     result = find_similar(description=..., category_filter=...,
#                           priority_filter=..., top_n=...)
#     recommendation = synthesize_recommendation(result.get("matches", []))
#     return jsonify(to_json_safe({
#         "result": result,
#         "recommendation": recommendation,
#     }))
#
# AFTER - replace with:
#
#     result = find_similar_with_problems(
#         description=description,
#         category_filter=category_filter,
#         priority_filter=priority_filter,
#         top_n=top_n,
#         problem_top_n=3,
#     )
#     incident_matches = result["incidents"].get("matches", [])
#     recommendation = synthesize_recommendation(incident_matches)
#
#     return jsonify(to_json_safe({
#         "incidents":      result["incidents"],     # same shape as before
#         "problems":       result["problems"],      # NEW
#         "recommendation": recommendation,
#     }))
#
# The frontend changes that go with this are already in:
#     templates/service_now_analysis/similar.html  (additional section)
#     static/service_now_analysis/js/snow.js       (renderProblemMatches)


# ===========================================================================
# 5. NO CHANGE NEEDED to:
#     - Incident template generator route (per your spec)
#     - Batch upload, dashboard, summary routes
#     - Upload history routes
# ===========================================================================
