"""
Per-section quality scoring for the generated CR template.

Every section of the CR template gets a quality score (0-100) plus a
band (green / amber / red), driven by:

    1. Completeness   - was the field populated?
    2. Confidence     - for ML-predicted fields, how sure was the model?
    3. Relevance      - for plan sections, do the steps actually match
                        the predicted category and risk?
    4. Coverage       - did we get enough plan steps to be useful?

The scorer is intentionally simple (no ML) so it always works, even
before any models have been trained. It's surfaced as a small badge
next to each section in the UI.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Description quality (input side - mirrors incident_quality.score_description_quality
# but tuned for CR descriptions)
# ---------------------------------------------------------------------------
_VAGUE_RE = re.compile(
    r"^(make\s+(some\s+)?changes?|fix\s+something|update\s+stuff|patch\s+it)",
    re.I)
_W_HINTS = {
    "what":  re.compile(r"\b(server|application|database|service|system|cluster|"
                        r"cmdb|ci|module|patch|upgrade|deploy|config)\b", re.I),
    "where": re.compile(r"\b(production|prod|uat|test|dev|environment|"
                        r"site|location|region|cluster)\b", re.I),
    "when":  re.compile(r"\b(today|tonight|this\s+\w+|next\s+\w+|after|"
                        r"during|window|maintenance|scheduled)\b", re.I),
    "why":   re.compile(r"\b(because|due\s+to|in\s+order\s+to|to\s+fix|"
                        r"to\s+resolve|to\s+enable|security|"
                        r"performance|compliance)\b", re.I),
}


def score_cr_description(text: str) -> Dict[str, Any]:
    """Score a CR description on input. Used for the live quality meter."""
    text = (text or "").strip()
    n_words = len(text.split())
    score = 0
    notes: List[str] = []

    # Length (0-25)
    if n_words >= 40:
        score += 25
    elif n_words >= 20:
        score += 18
        notes.append("Add a little more detail.")
    elif n_words >= 10:
        score += 10
        notes.append("Description is short - readers may need to ask for more context.")
    else:
        notes.append("Description is too brief - aim for at least 20 words.")

    # Vagueness (0-15)
    if _VAGUE_RE.search(text):
        notes.append("Avoid vague phrasing like 'make changes' or 'fix something'.")
    else:
        score += 15

    # 4 W's (0-32)
    answered = [q for q, p in _W_HINTS.items() if p.search(text)]
    score += min(8 * len(answered), 32)
    missing = [q for q in _W_HINTS if q not in answered]
    if missing:
        notes.append(f"Mention {' / '.join(missing)} for a complete picture.")

    # Specifics (0-18) - mention of CIs, version numbers, ticket refs
    if re.search(r"\b(KB\d+|v\d+\.\d|\d+\.\d+\.\d+|patch\s+\w+|"
                 r"PRB\d+|INC\d+|CHG\d+|RFC\d+)\b", text, re.I):
        score += 18
    else:
        score += 5
        notes.append("Reference specific patch IDs, ticket numbers, or version numbers if relevant.")

    # Structure (0-10)
    if "\n" in text or re.search(r"^\s*[\-\*\d]\.", text, re.M) or n_words > 30:
        score += 10
    else:
        score += 5

    score = min(int(score), 100)
    band = "green" if score >= 75 else "amber" if score >= 50 else "red"
    return {"score": score, "band": band, "notes": notes,
            "word_count": n_words, "char_count": len(text)}


# ---------------------------------------------------------------------------
# Per-section quality scoring (output side)
# ---------------------------------------------------------------------------
def _band(score: int) -> str:
    return "green" if score >= 75 else "amber" if score >= 50 else "red"


def _score_predicted_field(value: Any, confidence: Optional[float] = None,
                           default_value: str = "Unknown") -> Dict[str, Any]:
    """Score a single ML-predicted classifier output."""
    val = str(value or "").strip()
    if not val or val.lower() in ("unknown", "none", "nan", default_value.lower()):
        return {"score": 25, "band": "red",
                "note": "Field could not be predicted with confidence - set manually."}
    if confidence is None:
        # No confidence info - just score on populated/not populated
        return {"score": 70, "band": "amber",
                "note": "Predicted from history (confidence unknown)."}
    pct = float(confidence)
    if pct >= 0.7:
        return {"score": 95, "band": "green",
                "note": f"High confidence ({pct*100:.0f}%) from similar past CRs."}
    if pct >= 0.5:
        return {"score": 75, "band": "green",
                "note": f"Good confidence ({pct*100:.0f}%) - review before submitting."}
    if pct >= 0.3:
        return {"score": 55, "band": "amber",
                "note": f"Moderate confidence ({pct*100:.0f}%) - verify the value."}
    return {"score": 35, "band": "red",
            "note": f"Low confidence ({pct*100:.0f}%) - manually choose."}


def _score_text_field(text: str, *, min_words: int = 10,
                      ideal_words: int = 30) -> Dict[str, Any]:
    """Score a freeform text field by length / specificity."""
    text = (text or "").strip()
    n_words = len(text.split())
    if n_words == 0:
        return {"score": 0, "band": "red", "note": "Field is empty."}
    if n_words < min_words:
        return {"score": 35, "band": "red",
                "note": f"Too brief ({n_words} words) - add more detail."}
    if n_words < ideal_words:
        return {"score": 65, "band": "amber",
                "note": f"Adequate ({n_words} words) but could be richer."}
    return {"score": 90, "band": "green",
            "note": f"Detailed ({n_words} words)."}


def _score_plan_steps(steps: List[str], *, min_steps: int = 3,
                      ideal_steps: int = 5) -> Dict[str, Any]:
    """Score a plan (implementation / backout / test) by number of steps + specificity."""
    if not steps:
        return {"score": 10, "band": "red",
                "note": "No standard steps could be drawn from similar past CRs."}
    n = len(steps)
    avg_len = sum(len(s.split()) for s in steps) / max(n, 1)

    base = min(int(50 + 10 * n), 90)
    if avg_len < 4:
        base = max(base - 20, 30)
        note_suffix = "; steps are very short, consider adding detail"
    elif avg_len > 25:
        note_suffix = "; steps are detailed"
    else:
        note_suffix = ""

    if n < min_steps:
        return {"score": base - 15, "band": _band(base - 15),
                "note": f"Only {n} step(s) drawn from similar past CRs{note_suffix}."}
    if n < ideal_steps:
        return {"score": base, "band": _band(base),
                "note": f"{n} step(s) drawn from similar CRs{note_suffix}."}
    return {"score": min(base + 5, 95), "band": _band(min(base + 5, 95)),
            "note": f"{n} step(s) drawn from similar CRs{note_suffix}."}


def _score_window(start_iso: str, end_iso: str) -> Dict[str, Any]:
    """Score the planned start/end window."""
    if not start_iso or not end_iso:
        return {"score": 0, "band": "red",
                "note": "Planned start and/or end is missing."}
    try:
        from datetime import datetime
        s = datetime.fromisoformat(start_iso.replace(" ", "T"))
        e = datetime.fromisoformat(end_iso.replace(" ", "T"))
        if e <= s:
            return {"score": 20, "band": "red",
                    "note": "End time is not after start time."}
        hours = (e - s).total_seconds() / 3600
        if hours < 0.5:
            return {"score": 60, "band": "amber",
                    "note": f"Very short window ({hours*60:.0f} minutes) - confirm feasibility."}
        if hours > 168:
            return {"score": 50, "band": "amber",
                    "note": f"Window is over a week ({hours/24:.1f} days) - confirm scope."}
        return {"score": 95, "band": "green",
                "note": f"Window is {hours:.1f} hours - looks reasonable."}
    except (ValueError, TypeError):
        return {"score": 30, "band": "red",
                "note": "Could not parse start/end timestamps."}


# ---------------------------------------------------------------------------
# Top-level
# ---------------------------------------------------------------------------
def score_template(template: Dict[str, Any]) -> Dict[str, Any]:
    """
    Score every section of a generated CR template.

    Parameters
    ----------
    template : the dict returned by the template generator. Expected keys:
        title, description, type, category, subcategory, risk, priority,
        impact, urgency, business_service, assignment_group,
        environment, planned_start, planned_end, implementation_plan,
        backout_plan, test_plan, risk_impact_analysis, confidences (dict)

    Returns
    -------
    {
        "sections": {
            "<section_key>": {"score", "band", "note"},
            ...
        },
        "overall": {"score", "band", "weakest_sections": [...] }
    }
    """
    confs: Dict[str, float] = template.get("confidences") or {}
    sections: Dict[str, Dict[str, Any]] = {}

    sections["title"]            = _score_text_field(template.get("title", ""),
                                                     min_words=4, ideal_words=10)
    sections["description"]      = _score_text_field(template.get("description", ""),
                                                     min_words=10, ideal_words=30)

    sections["type"]             = _score_predicted_field(template.get("type"),
                                                          confs.get("type"))
    sections["category"]         = _score_predicted_field(template.get("category"),
                                                          confs.get("category"))
    sections["subcategory"]      = _score_predicted_field(template.get("subcategory"),
                                                          confs.get("subcategory"))
    sections["risk"]             = _score_predicted_field(template.get("risk"),
                                                          confs.get("risk"))
    sections["priority"]         = _score_predicted_field(template.get("priority"),
                                                          confs.get("priority"))
    sections["impact"]           = _score_predicted_field(template.get("impact"),
                                                          confs.get("impact"))
    sections["urgency"]          = _score_predicted_field(template.get("urgency"),
                                                          confs.get("urgency"))
    sections["business_service"] = _score_predicted_field(
        template.get("business_service"), confs.get("business_service"))
    sections["assignment_group"] = _score_predicted_field(
        template.get("assignment_group"), confs.get("assignment_group"))

    # Environment is user-supplied, so a non-empty value is good.
    env = (template.get("environment") or "").strip()
    sections["environment"] = ({"score": 95, "band": "green",
                                "note": f"Specified: {env}"}
                               if env and env.lower() != "unknown"
                               else {"score": 50, "band": "amber",
                                     "note": "Environment not specified."})

    sections["planned_window"] = _score_window(
        template.get("planned_start", ""), template.get("planned_end", ""))

    sections["implementation_plan"] = _score_plan_steps(
        template.get("implementation_plan", []) or [])
    sections["backout_plan"] = _score_plan_steps(
        template.get("backout_plan", []) or [])
    sections["test_plan"] = _score_plan_steps(
        template.get("test_plan", []) or [])

    sections["risk_impact_analysis"] = _score_text_field(
        template.get("risk_impact_analysis", ""), min_words=8, ideal_words=25)

    # Overall = weighted mean
    weights = {
        "title": 1, "description": 2,
        "type": 1.5, "category": 1.5, "subcategory": 1,
        "risk": 1.5, "priority": 1, "impact": 1, "urgency": 1,
        "business_service": 1, "assignment_group": 1.5,
        "environment": 1, "planned_window": 2,
        "implementation_plan": 2.5, "backout_plan": 2.5, "test_plan": 1.5,
        "risk_impact_analysis": 1.5,
    }
    weighted_sum = sum(weights[k] * v["score"] for k, v in sections.items() if k in weights)
    weight_total = sum(weights[k] for k in sections if k in weights)
    overall_score = int(round(weighted_sum / max(weight_total, 1)))

    weakest = sorted(sections.items(), key=lambda kv: kv[1]["score"])[:3]
    weakest_keys = [k for k, _ in weakest if sections[k]["band"] != "green"]

    return {
        "sections": sections,
        "overall": {
            "score": overall_score,
            "band": _band(overall_score),
            "weakest_sections": weakest_keys,
        },
    }
