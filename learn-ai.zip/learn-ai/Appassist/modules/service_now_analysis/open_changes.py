"""
open_changes.py - analytics for the Open Change Request sub-module (the
"Open Change Request" tab of Open ServiceNow Items).

Consumes a ServiceNow *change_request* export and produces the CR report:

    Number | Short description | Type | State | Planned start date |
    Planned end date | Created | Technical reviewer group

Everything is grouped by **Technical reviewer group** (not assignment group):
that is the queue a change sits in for technical review, and it is the address
key used for the per-group escalation email. The per-member breakdown counts
**Created by**, because a change is raised by its co-ordinator rather than
"assigned" the way an incident is.

Four action buckets drive both the dashboard and the email:

  * NEW              - state New with a planned start date still in the future.
                       Not yet actioned; there is still time to review it.
  * IMPLEMENT        - state Implement. Work is in the change window now.
  * REVIEW           - state Review. Implemented, waiting on post-change review.
  * OVERDUE CLOSURE  - the planned end date has passed but the change is still
                       open (not Closed / Cancelled). The change WINDOW closed;
                       the change itself did not.

Header conventions
------------------
Both export flavours are accepted and land on one set of field names, using the
mapping in sample_data/mapping_data.xlsx:

    Excel display header        CSV field name
    --------------------        --------------
    Number                      number
    Short description           short_description
    Type                        type
    State                       state
    Planned start date          start_date
    Planned end date            end_date
    Created                     sys_created_on
    Created by                  sys_created_by
    Technical reviewer group    u_technical_reviewer_group

Reuses ``service_request.normalise_display_export`` for the snake-casing and
the shared display renames (Created -> sys_created_on, ...), then applies the
change-specific ones on top.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime
from typing import Any, Dict, List, Optional

import pandas as pd

# Cell cleaner shared with the open-incident report - one definition of what
# counts as an empty ServiceNow cell ("", "nan", "NaT", None).
from .open_incidents import _clean as clean_cell
from .open_incidents import SLASH_DATES_ARE_DAY_FIRST  # noqa: F401 (re-exported)
from .open_incidents import to_datetime_series as _to_datetime
from .service_request import normalise_display_export

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Column handling
# ---------------------------------------------------------------------------
# Applied AFTER snake-casing, and only when the target field name is not
# already present - so a CSV export (already field-named) passes through
# untouched and an Excel export lands on the same names.
_CHANGE_DISPLAY_RENAMES = {
    "planned_start_date":        "start_date",
    "planned_end_date":          "end_date",
    "created_by":                "sys_created_by",
    "technical_reviewer_group":  "u_technical_reviewer_group",
    "actual_start_date":         "work_start",
    "actual_end_date":           "work_end",
    "change_co_ordinator":       "assigned_to",
    "change_co_ordinator_group": "assignment_group",
}

# Internal name -> candidate source columns, first match wins.
CHANGE_COLUMN_MAPPING: Dict[str, List[str]] = {
    "number":             ["number"],
    "short_description":  ["short_description"],
    "type":               ["type"],
    "state":              ["state"],
    "planned_start":      ["start_date", "expected_start"],
    "planned_end":        ["end_date"],
    "created":            ["sys_created_on", "opened_at"],
    "created_by":         ["sys_created_by", "opened_by"],
    "tech_group":         ["u_technical_reviewer_group"],
    # Not part of the eight report columns, but useful context on the detail
    # table when the export carries them.
    "assignment_group":   ["assignment_group"],
    "assigned_to":        ["assigned_to"],
}

# Without these the report cannot be produced at all: the change identity, its
# position in the lifecycle, the window that decides three of the four buckets,
# and the group the email is addressed to.
REQUIRED_CHANGE_COLUMNS = {
    "number", "short_description", "state", "start_date", "end_date",
    "u_technical_reviewer_group",
}

# Present in every real export; a file without them still renders, with the
# affected columns blank.
RECOMMENDED_CHANGE_COLUMNS = {"type", "sys_created_on", "sys_created_by"}

# Phrase "missing column" errors in the vocabulary of the uploaded file.
REQUIRED_CHANGE_DISPLAY_NAMES = {
    "number":                     "Number",
    "short_description":          "Short description",
    "state":                      "State",
    "start_date":                 "Planned start date",
    "end_date":                   "Planned end date",
    "u_technical_reviewer_group": "Technical reviewer group",
    "type":                       "Type",
    "sys_created_on":             "Created",
    "sys_created_by":             "Created by",
}


def normalise_change_export(raw_df: pd.DataFrame) -> pd.DataFrame:
    """Map a change export (either header convention) onto field names.

    Safe to run on a CSV export too: snake-casing a field name is a no-op and
    every rename is skipped when its target column already exists.
    """
    df = normalise_display_export(raw_df)
    renames = {src: dst for src, dst in _CHANGE_DISPLAY_RENAMES.items()
               if src in df.columns and dst not in df.columns}
    if renames:
        df = df.rename(columns=renames)
        logger.info("Normalised change export: %d change-specific rename(s)",
                    len(renames))
    return df


def validate_change_columns(df: pd.DataFrame):
    """(ok, missing_required, missing_recommended) for a normalised frame."""
    cols = set(df.columns)
    missing_required = sorted(REQUIRED_CHANGE_COLUMNS - cols)
    missing_recommended = sorted(RECOMMENDED_CHANGE_COLUMNS - cols)
    return (len(missing_required) == 0, missing_required, missing_recommended)


def to_change_display_names(missing: List[str]) -> List[str]:
    """Rephrase missing field names using their Excel display headers."""
    return [REQUIRED_CHANGE_DISPLAY_NAMES.get(c, c) for c in missing]


# ---------------------------------------------------------------------------
# State normalisation
#
# ServiceNow exports the change state either as a label or as its underlying
# integer. Both are canonicalised here so the buckets never depend on which
# view the file was exported from.
# ---------------------------------------------------------------------------
CHANGE_STATES = ["New", "Assess", "Authorize", "Scheduled", "Implement",
                 "Review", "Closed", "Cancelled"]

_NUMERIC_STATES = {
    "-5": "New", "-4": "Assess", "-3": "Authorize", "-2": "Scheduled",
    "-1": "Implement", "0": "Review", "3": "Closed", "4": "Cancelled",
}

_TEXT_STATES = {
    "new": "New", "draft": "New", "open": "New",
    "assess": "Assess", "assessment": "Assess",
    "authorize": "Authorize", "authorise": "Authorize", "authorized": "Authorize",
    "scheduled": "Scheduled", "schedule": "Scheduled", "approved": "Scheduled",
    "implement": "Implement", "implementation": "Implement",
    "in progress": "Implement", "work in progress": "Implement",
    "review": "Review", "pending review": "Review",
    "post implementation review": "Review",
    "closed": "Closed", "complete": "Closed", "completed": "Closed",
    "cancelled": "Cancelled", "canceled": "Cancelled",
}


def normalise_change_state(val) -> str:
    """Canonical change state from a label or the underlying integer."""
    s = clean_cell(val)
    if not s:
        return "Unknown"
    key = s.strip().lower()
    if key in _TEXT_STATES:
        return _TEXT_STATES[key]
    # Integer states arrive as "-1", "-1.0" or -1 depending on the reader.
    num = re.match(r"^(-?\d+)(?:\.0+)?$", s.strip())
    if num and num.group(1) in _NUMERIC_STATES:
        return _NUMERIC_STATES[num.group(1)]
    # Composite labels ("Closed Complete", "Closed Incomplete", "Closed Skipped").
    if key.startswith("closed"):
        return "Closed"
    if key.startswith("cancel"):
        return "Cancelled"
    return s.strip().title()


def is_closed_state(state: str) -> bool:
    """True for the two terminal change states."""
    return state in ("Closed", "Cancelled")


# ---------------------------------------------------------------------------
# Date parsing
#
# ServiceNow renders dates in the EXPORTING USER'S display format, so a change
# export may carry either the ISO system format (2026-08-21 09:00:00) or a
# slash format (21/08/2026 09:00:00). A slash date is ambiguous, and getting it
# wrong is not cosmetic here: reading 03/08/2026 as 8 March instead of 3 August
# moves a change five months and flips it into - or out of - the overdue-closure
# bucket. pandas defaults to month-first and only warns.
#
# This is a UK instance, so slash dates are day-first. The rule and its
# implementation live in open_incidents (SLASH_DATES_ARE_DAY_FIRST /
# to_datetime_series) - the open-item report reads dates the same way and its
# off-hold section depends on exactly this behaviour - and are imported at the
# top of this file under the local names, so there is ONE definition of "how a
# ServiceNow date is read" for the whole sub-module and one line to change for
# a non-UK deployment.
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Buckets
#
# Order matters - it is the order of the cards, the report sections and the
# email sections. A change can appear in more than one bucket (an Implement
# change whose window has already elapsed is both IMPLEMENT and OVERDUE
# CLOSURE); that is deliberate, each bucket answers a different question.
# ---------------------------------------------------------------------------
BUCKETS = [
    {
        "key": "new",
        "label": "New CRs",
        "email_label": "NEW CRs",
        "hint": "state New, planned start date still in the future",
        "tone": "blue",
    },
    {
        "key": "implement",
        "label": "Implement CRs",
        "email_label": "IMPLEMENT CRs",
        "hint": "state Implement - in the change window now",
        "tone": "amber",
    },
    {
        "key": "review",
        "label": "Review CRs",
        "email_label": "REVIEW CRs",
        "hint": "state Review - awaiting post-implementation review",
        "tone": "neutral",
    },
    {
        "key": "overdue_closure",
        "label": "Overdue Closure",
        "email_label": "OVERDUE CLOSURE",
        "hint": ("planned end date has passed but the change is not Closed "
                 "or Cancelled"),
        "tone": "red",
    },
]

BUCKET_KEYS = [b["key"] for b in BUCKETS]


# ---------------------------------------------------------------------------
# Data preparation
# ---------------------------------------------------------------------------
def prepare_open_changes(raw_df: pd.DataFrame,
                         now: Optional[datetime] = None) -> pd.DataFrame:
    """Map + clean a normalised change export into the working frame.

    Terminal changes (Closed / Cancelled) are dropped: this is the *open*
    change backlog. Everything else is kept, so a custom state label is never
    silently discarded.

    Output columns: number, short_description, type, state, state_raw,
    planned_start, planned_end, created, created_by, tech_group,
    assignment_group, assigned_to, days_to_start, days_overdue, and one
    boolean column per bucket key.
    """
    now_ts = pd.Timestamp(now or datetime.now())

    src = pd.DataFrame(index=raw_df.index)
    for feature, candidates in CHANGE_COLUMN_MAPPING.items():
        col = next((c for c in candidates if c in raw_df.columns), None)
        src[feature] = raw_df[col] if col is not None else None

    df = pd.DataFrame(index=raw_df.index)
    df["number"] = src["number"].map(clean_cell)
    df["short_description"] = src["short_description"].map(clean_cell)
    df["type"] = src["type"].map(clean_cell).replace("", "Unspecified")
    df["state_raw"] = src["state"].map(clean_cell)
    df["state"] = src["state"].map(normalise_change_state)
    df["tech_group"] = (src["tech_group"].map(clean_cell)
                        .replace("", "Unassigned reviewer group"))
    # Display each raw name with its initials capitalised, matching the
    # open-incident report ("alice tan" / "ALICE TAN" -> "Alice Tan").
    df["created_by"] = (src["created_by"].map(clean_cell)
                        .map(lambda s: s.title() if s else "")
                        .replace("", "Unknown"))
    df["assignment_group"] = src["assignment_group"].map(clean_cell)
    df["assigned_to"] = src["assigned_to"].map(clean_cell)

    for col in ("planned_start", "planned_end", "created"):
        df[col] = _to_datetime(src[col])

    # Drop rows without a change number - blank spacer rows are common in
    # hand-edited exports and would otherwise become phantom changes.
    df = df[df["number"] != ""].copy()

    closed_mask = df["state"].map(is_closed_state)
    excluded_closed = int(closed_mask.sum())
    df = df[~closed_mask].copy()

    df["days_to_start"] = ((df["planned_start"] - now_ts)
                           .dt.total_seconds() / 86400).round().astype("Int64")
    df["days_overdue"] = ((now_ts - df["planned_end"])
                          .dt.total_seconds() / 86400).round().astype("Int64")

    df["new"] = ((df["state"] == "New") & df["planned_start"].notna()
                 & (df["planned_start"] > now_ts))
    df["implement"] = df["state"] == "Implement"
    df["review"] = df["state"] == "Review"
    # The state test is redundant once terminal rows are dropped above, but it
    # is spelled out so the rule survives any future change to that filter.
    df["overdue_closure"] = (df["planned_end"].notna()
                             & (df["planned_end"] < now_ts)
                             & ~df["state"].map(is_closed_state))

    df = df.reset_index(drop=True)
    df.attrs["excluded_closed"] = excluded_closed
    logger.info("Prepared %d open change(s); excluded %d closed/cancelled",
                len(df), excluded_closed)
    return df


# ---------------------------------------------------------------------------
# Row rendering - the eight report columns, in the order they are specified
# ---------------------------------------------------------------------------
def _fmt_ts(val) -> str:
    if val is None or pd.isna(val):
        return ""
    return pd.Timestamp(val).strftime("%Y-%m-%d %H:%M")


def _row(r) -> Dict[str, Any]:
    return {
        "number": r["number"],
        "short_description": r["short_description"],
        "type": r["type"],
        "state": r["state"],
        "planned_start": _fmt_ts(r["planned_start"]),
        "planned_end": _fmt_ts(r["planned_end"]),
        "created": _fmt_ts(r["created"]),
        "tech_group": r["tech_group"],
        "created_by": r["created_by"],
        "days_to_start": (int(r["days_to_start"])
                          if pd.notna(r["days_to_start"]) else None),
        "days_overdue": (int(r["days_overdue"])
                         if pd.notna(r["days_overdue"]) else None),
    }


def _rows_for(df: pd.DataFrame, bucket_key: str) -> List[Dict[str, Any]]:
    """Rows in one bucket, most urgent first.

    Overdue changes lead with the longest overrun; everything else is ordered
    by planned start, so the nearest window is at the top.
    """
    sub = df[df[bucket_key]].copy()
    if sub.empty:
        return []
    if bucket_key == "overdue_closure":
        sub = sub.sort_values("days_overdue", ascending=False, na_position="last")
    else:
        sub = sub.sort_values("planned_start", ascending=True, na_position="last")
    return [_row(r) for _, r in sub.iterrows()]


def _counts(df: pd.DataFrame, column: str,
            limit: Optional[int] = None) -> List[Dict[str, Any]]:
    vc = df[column].value_counts()
    items = [{"name": str(k), "count": int(v)} for k, v in vc.items()]
    return items[:limit] if limit else items


def bucket_counts(df: pd.DataFrame) -> Dict[str, int]:
    return {k: int(df[k].sum()) for k in BUCKET_KEYS}


# ---------------------------------------------------------------------------
# Aggregations
# ---------------------------------------------------------------------------
def _worst_overdue(df: pd.DataFrame) -> Dict[str, Any]:
    sub = df[df["overdue_closure"]].dropna(subset=["days_overdue"])
    if sub.empty:
        return {}
    row = sub.loc[sub["days_overdue"].astype(int).idxmax()]
    return {"number": row["number"], "days_overdue": int(row["days_overdue"]),
            "short_description": row["short_description"]}


def compute_overall_summary(work_df: pd.DataFrame) -> Dict[str, Any]:
    """Portfolio view across every technical reviewer group."""
    total = int(len(work_df))

    groups = []
    for g, sub in work_df.groupby("tech_group", sort=False):
        row = {"name": str(g), "count": int(len(sub))}
        row.update(bucket_counts(sub))
        groups.append(row)
    groups.sort(key=lambda r: (-r["count"], r["name"]))

    return {
        "total_open": total,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "bucket_counts": bucket_counts(work_df),
        "buckets": BUCKETS,
        "state_counts": _counts(work_df, "state"),
        "type_counts": _counts(work_df, "type"),
        "created_by": _counts(work_df, "created_by"),
        "groups": groups,
        "group_count": len(groups),
        "excluded_closed": int(work_df.attrs.get("excluded_closed", 0)),
        "worst_overdue": _worst_overdue(work_df),
    }


def list_groups(work_df: pd.DataFrame) -> List[Dict[str, Any]]:
    """Technical reviewer groups present in the upload, busiest first."""
    by_group = work_df.groupby("tech_group").size().sort_values(ascending=False)
    return [{"name": str(g), "count": int(c)} for g, c in by_group.items()]


def compute_group_report(work_df: pd.DataFrame,
                         group: str) -> Optional[Dict[str, Any]]:
    """Per-technical-reviewer-group report, or None when the group has no open
    changes in this upload."""
    g = work_df[work_df["tech_group"] == group].copy()
    if g.empty:
        return None

    return {
        "group": group,
        "total_open": int(len(g)),
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "bucket_counts": bucket_counts(g),
        "buckets": BUCKETS,
        "bucket_rows": {k: _rows_for(g, k) for k in BUCKET_KEYS},
        "state_counts": _counts(g, "state"),
        "type_counts": _counts(g, "type"),
        # The "assigned member" summary for a change counts who RAISED it -
        # the Created by column, per the report specification.
        "created_by": _counts(g, "created_by"),
        "table_rows": [_row(r) for _, r in
                       g.sort_values("planned_start", ascending=True,
                                     na_position="last").iterrows()],
        "worst_overdue": _worst_overdue(g),
    }
