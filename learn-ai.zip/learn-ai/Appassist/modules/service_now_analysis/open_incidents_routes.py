"""
open_incidents_routes.py - routes for the Open ServiceNow Items sub-module
(open incidents + open service requests).

Registered onto the ServiceNow Analysis blueprint by
``init_open_incident_routes(service_now_analysis_bp)`` (called at the end of
routes.py), so it shares the same /service-now-analysis URL prefix, standalone
layout, sidebar and module-wide context processor.

Both item kinds share the same handlers, parameterised by a kind config:

  incidents          service requests
  ---------          ----------------
GET  /open-incidents                     /open-service-requests            upload page
POST /open-incidents/upload              /open-service-requests/upload     members-only: validate + compute + store
GET  /open-incidents/report/<sid>        /open-service-requests/report/<sid>
GET  /open-incidents/report/<sid>/group  /open-service-requests/report/<sid>/group
GET  /api/open-incidents/<sid>           /api/open-service-requests/<sid>
POST /open-incidents/email/<sid>         /open-service-requests/email/<sid>  admin-only dispatch

The PER-GROUP report also carries an **off-hold-today** section: the items whose
Off hold date ("Off hold date" in an Excel export, ``due_date`` in a CSV one)
falls on the day the page is being read. It is recomputed per request rather
than cached with the upload - see open_incidents.compute_off_hold_report. The
all-groups overview deliberately omits it; the JSON API still exposes the
portfolio-wide figures for callers that want them.

Incident endpoints keep their original names so existing links keep working.
Service-request exports arrive with display headers and are normalised via
service_request.normalise_sr_export before the shared analytics run.
"""

from __future__ import annotations

import logging
import secrets
from datetime import datetime

from flask import (
    flash, jsonify, redirect, render_template, request, url_for,
)
from werkzeug.utils import secure_filename

from auth import get_current_user
from csrf_utils import csrf_protect

from . import config
from . import session_store
from .access import DENIED_MESSAGE, is_servicenow_member
from .ml.column_mapper import validate_columns
from .ml.preprocess import load_export
from .service_request import (
    apply_sr_fallbacks, normalise_display_export, to_display_names,
)
from .utils.json_safe import to_json_safe
from .open_incidents import (
    prepare_open_incidents, compute_overall_summary, compute_group_report,
    compute_off_hold_report,
)
from . import open_incident_email

logger = logging.getLogger(__name__)


def _allowed_file(filename: str) -> bool:
    return ("." in filename and
            filename.rsplit(".", 1)[1].lower() in config.ALLOWED_EXTENSIONS)


# Per-kind configuration. `session_kind` is stored inside the session dict
# and doubles as the session_store "latest" pointer key ("open" keeps its
# original value for backwards compatibility with existing sessions).
_KINDS = {
    "incident": {
        "kind": "incident",
        "session_kind": "open",
        "label": "incident",
        "label_plural": "incidents",
        "title": "Open Incidents",
        "upload_prefix": "open_",
        "ep_index":  "service_now_analysis.open_incidents_index",
        "ep_upload": "service_now_analysis.open_incidents_upload",
        "ep_report": "service_now_analysis.open_incidents_report",
        "ep_group":  "service_now_analysis.open_incidents_group_report",
        "ep_email":  "service_now_analysis.open_incidents_email",
    },
    "sr": {
        "kind": "sr",
        "session_kind": "open_sr",
        "label": "service request",
        "label_plural": "service requests",
        "title": "Open Service Requests",
        "upload_prefix": "open_sr_",
        "ep_index":  "service_now_analysis.open_srs_index",
        "ep_upload": "service_now_analysis.open_srs_upload",
        "ep_report": "service_now_analysis.open_srs_report",
        "ep_group":  "service_now_analysis.open_srs_group_report",
        "ep_email":  "service_now_analysis.open_srs_email",
    },
}


def init_open_incident_routes(bp):
    """Register the Open ServiceNow Items routes onto the given blueprint."""

    # -------------------------------------------------------------------
    # Shared handlers (parameterised by kind config)
    # -------------------------------------------------------------------
    def _index(cfg):
        # An existing analysis opens directly in display mode; the upload
        # form is reached explicitly via `?new=1` (the report's "New
        # upload" button) or when nothing has been uploaded yet.
        latest = session_store.get_latest(cfg["session_kind"])
        latest_sess = session_store.get(latest) if latest else None
        if latest_sess and request.args.get("new") != "1":
            return redirect(url_for(cfg["ep_report"], sid=latest))
        return render_template("service_now_analysis/open_incidents/index.html",
                               oi=cfg)

    def _upload(cfg):
        # Upload is the write side of this module - it replaces the org-wide
        # latest report and drives the escalation emails - so it is restricted
        # to ServiceNow group members (admins included). Reading the resulting
        # report stays open to everyone.
        if not is_servicenow_member():
            logger.warning("Open-%s upload denied - not a ServiceNow group member",
                           cfg["label"])
            flash(DENIED_MESSAGE, "error")
            return redirect(url_for(cfg["ep_index"]))

        session_store.cleanup_expired()

        file = request.files.get("file")
        if not file or not file.filename:
            flash("Please choose a file to upload", "error")
            return redirect(url_for(cfg["ep_index"]))
        if not _allowed_file(file.filename):
            flash(f"Unsupported file type. Allowed: "
                  f"{', '.join(sorted(config.ALLOWED_EXTENSIONS))}", "error")
            return redirect(url_for(cfg["ep_index"]))

        session_id = secrets.token_urlsafe(16)
        safe_name = secure_filename(file.filename)
        ts_prefix = datetime.now().strftime("%Y%m%d-%H%M%S")
        saved_path = (config.UPLOAD_DIR /
                      f"{cfg['upload_prefix']}{ts_prefix}_{session_id[:8]}_{safe_name}")
        try:
            file.save(saved_path)
        except Exception:
            logger.exception("Failed to save open-%s upload", cfg["label"])
            flash("Could not save the uploaded file", "error")
            return redirect(url_for(cfg["ep_index"]))

        try:
            raw = load_export(saved_path)
        except Exception as exc:
            flash(f"Could not read the file: {exc}", "error")
            return redirect(url_for(cfg["ep_index"]))

        # Header convention follows the FILE TYPE for both kinds: CSV =
        # snake_case field names, Excel = display headers (normalised here).
        is_excel = saved_path.suffix.lower() in (".xlsx", ".xls")
        if is_excel:
            raw = normalise_display_export(raw)
        if cfg["kind"] == "sr":
            raw = apply_sr_fallbacks(raw)

        ok, missing_required, _ = validate_columns(raw)
        if not ok:
            if is_excel:
                missing_required = to_display_names(missing_required)
            flash("Required columns missing: " + ", ".join(missing_required), "error")
            return redirect(url_for(cfg["ep_index"]))

        try:
            work_df = prepare_open_incidents(raw)
        except Exception as exc:
            logger.exception("Open-%s processing failed", cfg["label"])
            flash(f"Could not process the file: {exc}", "error")
            return redirect(url_for(cfg["ep_index"]))

        if work_df.empty:
            flash(f"No open {cfg['label_plural']} were found in that file "
                  "(every row looked resolved/closed). Please upload an "
                  "open/pending/on-hold list.", "warning")
            return redirect(url_for(cfg["ep_index"]))

        overall = compute_overall_summary(work_df)

        saved = session_store.set(session_id, {
            "kind": cfg["session_kind"],
            "work_df": work_df,
            "overall": overall,
            "filename": safe_name,
            "uploaded_at": datetime.now().isoformat(timespec="seconds"),
            "row_count": int(len(work_df)),
            "filepath": str(saved_path),
        })
        if not saved:
            flash("Server could not save the analysis - check server logs.", "error")
            return redirect(url_for(cfg["ep_index"]))

        session_store.set_latest(cfg["session_kind"], session_id)
        return redirect(url_for(cfg["ep_report"], sid=session_id))

    def _get_open_session(cfg, sid):
        sess = session_store.get(sid)
        if sess is None or sess.get("kind") != cfg["session_kind"]:
            return None
        return sess

    def _report(cfg, sid):
        sess = _get_open_session(cfg, sid)
        if sess is None:
            return render_template(
                "service_now_analysis/error.html", code=404,
                message=f"Open-{cfg['label']} analysis not found or expired. "
                        "Please upload the file again."), 404
        # The all-groups overview carries no off-hold section: it is a worklist
        # for the team that owns a queue, so it lives on the per-group report.
        return render_template(
            "service_now_analysis/open_incidents/report.html",
            oi=cfg, sid=sid, filename=sess["filename"],
            uploaded_at=sess["uploaded_at"], row_count=sess["row_count"],
            overall=sess["overall"], group=None,
        )

    def _group_report(cfg, sid):
        sess = _get_open_session(cfg, sid)
        if sess is None:
            return render_template(
                "service_now_analysis/error.html", code=404,
                message=f"Open-{cfg['label']} analysis not found or expired."), 404
        group = (request.args.get("name") or "").strip()
        report = compute_group_report(sess["work_df"], group) if group else None
        if report is None:
            flash(f"That assignment group has no open {cfg['label_plural']} "
                  "in this upload.", "warning")
            return redirect(url_for(cfg["ep_report"], sid=sid))
        return render_template(
            "service_now_analysis/open_incidents/report.html",
            oi=cfg, sid=sid, filename=sess["filename"],
            uploaded_at=sess["uploaded_at"], row_count=sess["row_count"],
            overall=sess["overall"], group=group, report=report,
            off_hold=report["off_hold"],
        )

    def _api(cfg, sid):
        sess = _get_open_session(cfg, sid)
        if sess is None:
            return jsonify({"ok": False, "error": "Session not found"}), 404
        payload = dict(sess["overall"])
        payload["off_hold"] = compute_off_hold_report(sess["work_df"])
        return jsonify({"ok": True, "data": to_json_safe(payload)})

    def _email(cfg, sid):
        user = get_current_user()
        if not user or user.role != "admin":
            flash("Admin access required to email summaries", "error")
            return redirect(url_for(cfg["ep_report"], sid=sid))

        sess = _get_open_session(cfg, sid)
        if sess is None:
            flash(f"Open-{cfg['label']} analysis not found or expired.", "error")
            return redirect(url_for(cfg["ep_index"]))

        # Optionally scope to a single group (per-group report page button).
        only = (request.form.get("group") or "").strip() or None

        # Send to whichever groups have escalation contacts configured. Groups
        # without a mapping are silently skipped - many assignment groups won't
        # be ours to contact, so we deliberately do NOT surface which ones lack
        # addresses.
        result = open_incident_email.dispatch_open_incident_digest(
            sess["work_df"], only_group=only,
            source_filename=sess.get("filename", ""),
            item_label=cfg["label"])
        sent = result["sent"]

        if sent:
            flash(f"Open-{cfg['label']} summary emailed to {len(sent)} assignment "
                  f"group{'' if len(sent) == 1 else 's'} "
                  f"({', '.join(sent)}).", "success")
        else:
            flash("No summary was sent - no escalation contacts are configured for "
                  "these assignment groups yet.", "info")

        management = result.get("management") or {}
        if management.get("sent"):
            flash(f"Consolidated management summary (with Excel workbook) emailed "
                  f"to {management['recipients']} management "
                  f"recipient{'' if management['recipients'] == 1 else 's'}.",
                  "success")
        elif management.get("reason") in ("excel_failed", "smtp_failed"):
            flash("The consolidated management summary could not be sent - "
                  "check the server logs.", "error")

        target = (url_for(cfg["ep_group"], sid=sid, name=only)
                  if only else url_for(cfg["ep_report"], sid=sid))
        return redirect(target)

    # -------------------------------------------------------------------
    # Incident routes (original endpoint names preserved)
    # -------------------------------------------------------------------
    inc = _KINDS["incident"]

    @bp.route("/open-incidents")
    def open_incidents_index():
        return _index(inc)

    @bp.route("/open-incidents/upload", methods=["POST"])
    @csrf_protect
    def open_incidents_upload():
        return _upload(inc)

    @bp.route("/open-incidents/report/<sid>")
    def open_incidents_report(sid):
        return _report(inc, sid)

    @bp.route("/open-incidents/report/<sid>/group")
    def open_incidents_group_report(sid):
        return _group_report(inc, sid)

    @bp.route("/api/open-incidents/<sid>")
    def api_open_incidents(sid):
        return _api(inc, sid)

    @bp.route("/open-incidents/email/<sid>", methods=["POST"])
    @csrf_protect
    def open_incidents_email(sid):
        return _email(inc, sid)

    # -------------------------------------------------------------------
    # Service-request routes
    # -------------------------------------------------------------------
    sr = _KINDS["sr"]

    @bp.route("/open-service-requests")
    def open_srs_index():
        return _index(sr)

    @bp.route("/open-service-requests/upload", methods=["POST"])
    @csrf_protect
    def open_srs_upload():
        return _upload(sr)

    @bp.route("/open-service-requests/report/<sid>")
    def open_srs_report(sid):
        return _report(sr, sid)

    @bp.route("/open-service-requests/report/<sid>/group")
    def open_srs_group_report(sid):
        return _group_report(sr, sid)

    @bp.route("/api/open-service-requests/<sid>")
    def api_open_srs(sid):
        return _api(sr, sid)

    @bp.route("/open-service-requests/email/<sid>", methods=["POST"])
    @csrf_protect
    def open_srs_email(sid):
        return _email(sr, sid)
