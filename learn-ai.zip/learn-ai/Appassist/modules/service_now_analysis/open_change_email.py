"""
open_change_email.py - professional per-technical-reviewer-group summary email
for open Change Requests.

Sibling of open_incident_email.py and deliberately built from the SAME
Outlook-safe primitives (imported rather than re-implemented, so the two
emails can never drift apart visually): 100% nested tables, state carried by
a tint plus a four-sided hairline, pre-uppercased labels, solid colours with bgcolor
attributes, and a plain-text alternative part.

The email is one section per action bucket, in the order a reviewer works
them, plus a member summary:

  * NEW CRs           - state New, planned start still in the future.
  * IMPLEMENT CRs     - state Implement.
  * REVIEW CRs        - state Review.
  * OVERDUE CLOSURE   - planned end date has passed, change still open.
  * RAISED BY MEMBER  - open changes per Created by.

Addressing: a change's queue is its **Technical reviewer group**, so that is
what the recipient lookup is keyed on. It reuses the existing
servicenow_assignment_groups directory (Manage Members -> Assignment Groups &
Escalation Contacts) - add a row whose name is the technical reviewer group
exactly as it appears in the export. Groups with no mapping are silently
skipped, exactly as they are for the open-incident digest.
"""

from __future__ import annotations

import logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Any, Dict, List

from email_theme import hero_rows, footer_rows

from .open_changes import BUCKETS
# Shared Outlook-safe building blocks + SMTP settings. One definition of the
# NPg email language for every ServiceNow digest.
from .open_incident_email import (
    _AMBER, _BLUE, _CHIP_BG, _EMAIL_FROM, _FONT, _NEUTRAL, _NPG_BORDER,
    _NPG_DARK, _NPG_LIGHT, _NPG_MUTED, _NPG_RED, _NPG_TEXT, _RED, _SMTP_PORT,
    _SMTP_SERVER, _badge, _data_table, _esc, _recipients_for, _section_block,
    _section_header, _stat_card,
)

logger = logging.getLogger(__name__)

# Bucket tone -> (palette, stat-card background, stat-card value colour).
_TONE = {
    "blue":    (_BLUE, "#EFF6FF", "#1D4ED8"),
    "amber":   (_AMBER, "#FFFBEB", "#B45309"),
    "neutral": (_NEUTRAL, "#EEF2F7", _NPG_DARK),
    "red":     (_RED, "#FEF2F2", _NPG_RED),
}

# Rows per bucket table in the email. The full list always lives on the report
# page; the email is a nudge, not an archive.
_MAX_ROWS_PER_BUCKET = 12


def _tone(bucket: Dict[str, Any]):
    return _TONE.get(bucket.get("tone"), _TONE["neutral"])


# ---------------------------------------------------------------------------
# Subject / plain text
# ---------------------------------------------------------------------------
def _subject(group: str, report: Dict[str, Any]) -> str:
    bc = report["bucket_counts"]
    tail = (f", {bc['overdue_closure']} overdue closure"
            if bc.get("overdue_closure") else "")
    return (f"[App Assist] Open change request summary - {group} "
            f"({report['total_open']} open{tail})")


def build_plaintext(group: str, report: Dict[str, Any]) -> str:
    bc = report["bucket_counts"]
    lines = [
        "NPG APP ASSIST - OPEN CHANGE REQUEST SUMMARY",
        "=" * 56,
        f"Technical reviewer group: {group}",
        f"Generated: {report['generated_at']}",
        "",
        f"Total open change requests: {report['total_open']}",
        "",
        "SUMMARY",
        "-" * 56,
    ]
    for b in BUCKETS:
        lines.append(f"  {b['label']:<20} {bc.get(b['key'], 0)}   ({b['hint']})")

    for b in BUCKETS:
        rows = report["bucket_rows"].get(b["key"]) or []
        lines += ["", f"{b['email_label']}  ({len(rows)})", "-" * 56]
        if not rows:
            lines.append("    None.")
            continue
        for r in rows[:_MAX_ROWS_PER_BUCKET]:
            lines.append(
                f"    {r['number']:<14} [{r['state']:<10}] "
                f"{r['planned_start'][:16]:<16} -> {r['planned_end'][:16]:<16} "
                f"{r['short_description'][:45]}")
        if len(rows) > _MAX_ROWS_PER_BUCKET:
            lines.append(f"    ... and {len(rows) - _MAX_ROWS_PER_BUCKET} more.")

    lines += ["", "RAISED BY MEMBER (Created by)", "-" * 56]
    for a in report["created_by"]:
        lines.append(f"    {a['name']:<32} {a['count']}")

    lines += ["",
              "Please progress the change requests above - in particular any "
              "listed under Overdue Closure.",
              "NPG App Assist - ServiceNow Analysis - Generated automatically "
              "- Do not reply"]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# HTML
# ---------------------------------------------------------------------------
def _bucket_table(bucket: Dict[str, Any],
                  rows: List[Dict[str, Any]]) -> str:
    """The eight report columns, trimmed to what fits an email at 640px.

    Technical reviewer group is not repeated per row - the whole email is that
    one group - and the age column carries the fact each bucket is about.
    """
    palette, _, _ = _tone(bucket)
    if not rows:
        return (
            f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" '
            f'border="0" bgcolor="{palette["tint"]}" style="background-color:{palette["tint"]};'
            f'border:1px solid {palette["tint_border"]};border-collapse:separate;border-spacing:0;border-radius:10px;">'
            f'<tr><td style="padding:12px 14px;font-family:{_FONT};font-size:12px;'
            f'color:{palette["fg"]};">No change requests in this category.</td></tr></table>'
        )

    if bucket["key"] == "overdue_closure":
        last_header, last_align = "Overdue", "right"

        def _last(r):
            d = r.get("days_overdue")
            return (f'<strong style="color:{_RED["fg"]};">{d} days</strong>'
                    if d is not None else "-")
    elif bucket["key"] == "new":
        last_header, last_align = "Starts in", "right"

        def _last(r):
            d = r.get("days_to_start")
            return f'<strong>{d} days</strong>' if d is not None else "-"
    else:
        last_header, last_align = "Created", "left"

        def _last(r):
            return _esc(r.get("created", ""))

    body = [[f'<strong>{_esc(r["number"])}</strong>',
             _esc(r["short_description"][:60]),
             _esc(r["type"]),
             _esc(r["state"]),
             _esc(r["planned_start"]),
             _esc(r["planned_end"]),
             _last(r)]
            for r in rows[:_MAX_ROWS_PER_BUCKET]]

    table = _data_table(
        ["Number", "Short description", "Type", "State",
         "Planned start", "Planned end", last_header],
        body,
        aligns=["left", "left", "left", "left", "left", "left", last_align],
    )
    if len(rows) > _MAX_ROWS_PER_BUCKET:
        table += (
            f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" '
            f'border="0"><tr><td style="padding:8px 2px 0;font-family:{_FONT};'
            f'font-size:11px;color:{_NPG_MUTED};">Showing the first '
            f'{_MAX_ROWS_PER_BUCKET} of {len(rows)} - the full list is on the '
            f'Open Change Request report.</td></tr></table>'
        )
    return table


def build_html(group: str, report: Dict[str, Any]) -> str:
    bc = report["bucket_counts"]
    total = report["total_open"]

    # ---- Summary strip: one stat card per bucket ----
    cells = [
        f'<td class="stat-cell" width="20%" valign="top" style="padding-right:5px;">'
        f'{_stat_card("#EEF2F7", _NPG_DARK, _NPG_MUTED, total, "TOTAL OPEN")}</td>'
    ]
    for i, b in enumerate(BUCKETS):
        _, bg, fg = _tone(b)
        pad = ("padding-left:5px;" if i == len(BUCKETS) - 1 else "padding:0 3px;")
        cells.append(
            f'<td class="stat-cell" width="20%" valign="top" style="{pad}">'
            f'{_stat_card(bg, fg, _NPG_MUTED, bc.get(b["key"], 0), b["email_label"])}'
            f'</td>')
    summary_section = _section_block(
        _section_header("SUMMARY", f"{total} open", _NEUTRAL),
        f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" '
        f'border="0"><tr>{"".join(cells)}</tr></table>',
    )

    # ---- One section per bucket ----
    bucket_sections = ""
    for b in BUCKETS:
        rows = report["bucket_rows"].get(b["key"]) or []
        palette, _, _ = _tone(b)
        bucket_sections += _section_block(
            _section_header(b["email_label"], f"{len(rows)}", palette),
            _bucket_table(b, rows),
        )

    # ---- Raised by member (Created by) ----
    member_rows = [[_esc(a["name"]), f'<strong>{a["count"]}</strong>']
                   for a in report["created_by"]]
    member_section = _section_block(
        _section_header("RAISED BY MEMBER", f"{len(member_rows)} member(s)", _BLUE),
        _data_table(["Member (created by)", "Open CRs"], member_rows,
                    aligns=["left", "right"]),
    )

    badge_open = _badge(_CHIP_BG, "#FFFFFF", f"{total} OPEN")
    badge_when = _badge(_CHIP_BG, "#FFFFFF",
                        report["generated_at"].upper())
    hero = hero_rows("NPG APP ASSIST &middot; OPEN CHANGE REQUEST SUMMARY",
                     _esc(group), [badge_open, badge_when], width=640)
    footer = footer_rows("ServiceNow Analysis", width=640)

    overdue = bc.get("overdue_closure", 0)
    intro = (
        f"There {'is' if total == 1 else 'are'} <strong>{total}</strong> open "
        f"change request{'' if total == 1 else 's'} awaiting the "
        f"<strong>{_esc(group)}</strong> technical reviewer group. "
        f"<strong>{bc.get('implement', 0)}</strong> "
        f"{'is' if bc.get('implement', 0) == 1 else 'are'} in the implement "
        f"window, <strong>{bc.get('review', 0)}</strong> "
        f"{'is' if bc.get('review', 0) == 1 else 'are'} awaiting review, and "
        f"<strong>{overdue}</strong> {'has' if overdue == 1 else 'have'} "
        f"passed the planned end date without being closed."
    )

    return f"""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>NPG App Assist &mdash; Open change request summary</title>
  <!--[if mso]>
  <xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch><o:AllowPNG/></o:OfficeDocumentSettings></xml>
  <style type="text/css">table {{border-collapse:collapse;}} td {{mso-line-height-rule:exactly;}}</style>
  <![endif]-->
  <style type="text/css">
    body, table, td {{ -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }}
    table {{ border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }}
    a {{ color:{_NPG_RED}; text-decoration:none; }}
    @media only screen and (max-width:640px) {{
      .container {{ width:100% !important; }}
      .px-32 {{ padding-left:18px !important; padding-right:18px !important; }}
      .stat-cell {{ display:block !important; width:100% !important; padding:0 0 6px 0 !important; }}
    }}
  </style>
</head>
<body style="margin:0;padding:0;background-color:{_NPG_LIGHT};font-family:{_FONT};">
<div style="display:none;font-size:1px;color:{_NPG_LIGHT};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
Open change request summary for {_esc(group)} &mdash; {total} open, {bc.get('implement', 0)} implement, {bc.get('review', 0)} review, {overdue} overdue closure
</div>

<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="{_NPG_LIGHT}" style="background-color:{_NPG_LIGHT};">
  <tr><td align="center" style="padding:34px 16px 40px 16px;">
    <!--[if mso]><table role="presentation" align="center" cellpadding="0" cellspacing="0" border="0" width="640"><tr><td><![endif]-->
    <table role="presentation" class="container" cellpadding="0" cellspacing="0" border="0" width="640"
           style="width:640px;max-width:640px;background-color:#FFFFFF;border:1px solid {_NPG_BORDER};border-bottom-color:#C6D0DE;border-collapse:separate;border-spacing:0;border-radius:14px;">

      <!-- Header (shared NPG theme) -->
      {hero}

      <!-- Intro ribbon -->
      <tr><td class="px-32" style="padding:22px 32px;">
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"
               bgcolor="{_NEUTRAL['tint']}" style="background-color:{_NEUTRAL['tint']};border:1px solid {_NEUTRAL['tint_border']};border-collapse:separate;border-spacing:0;border-radius:10px;">
          <tr>
            <td style="padding:14px 16px;font-family:{_FONT};font-size:13px;color:{_NPG_TEXT};
                       mso-line-height-rule:exactly;line-height:20px;">{intro}</td>
          </tr>
        </table>
      </td></tr>

      <!-- Sections -->
      <tr><td class="px-32" style="padding:24px 32px;">
        {summary_section}
        {bucket_sections}
        {member_section}
      </td></tr>

      <!-- Footer (shared NPG theme) -->
      {footer}

    </table>
    <!--[if mso]></td></tr></table><![endif]-->
  </td></tr>
</table>
</body>
</html>"""


# ---------------------------------------------------------------------------
# Delivery
# ---------------------------------------------------------------------------
def send_group_summary(group: str, report: Dict[str, Any],
                       recipients: List[str]) -> bool:
    """Send one technical reviewer group's summary. True on success."""
    if not recipients:
        return False
    try:
        msg = MIMEMultipart("alternative")
        msg["From"] = _EMAIL_FROM
        msg["To"] = ", ".join(recipients)
        msg["Subject"] = _subject(group, report)
        # An elapsed change window is the one condition worth flagging as
        # high importance in the recipient's inbox.
        msg["X-Priority"] = ("2" if report["bucket_counts"].get("overdue_closure")
                             else "3")
        msg.attach(MIMEText(build_plaintext(group, report), "plain", "utf-8"))
        msg.attach(MIMEText(build_html(group, report), "html", "utf-8"))

        with smtplib.SMTP(_SMTP_SERVER, _SMTP_PORT, timeout=30) as server:
            server.sendmail(_EMAIL_FROM, recipients, msg.as_string())

        logger.info("Open-change summary emailed for group '%s' to %d "
                    "recipient(s)", group, len(recipients))
        return True
    except smtplib.SMTPException as exc:
        logger.error("SMTP error sending open-change summary for '%s': %s",
                     group, exc)
        return False
    except Exception:
        logger.exception("Unexpected error sending open-change summary for '%s'",
                         group)
        return False


def dispatch_open_change_digest(work_df, only_group: str | None = None,
                                source_filename: str = "") -> Dict[str, Any]:
    """Email the per-group summary for every technical reviewer group in
    `work_df` that has contacts configured.

    Groups without a mapping (or without a usable address) are silently
    skipped - many reviewer groups will not be ours to contact.

    Returns {"sent": [group, ...], "total_groups": n}.
    """
    from database import get_db_session
    from .models import AssignmentGroupContact
    from .open_changes import compute_group_report, list_groups

    groups = [only_group] if only_group else [g["name"] for g in list_groups(work_df)]

    db = get_db_session()
    try:
        contacts = {c.name: c for c in db.query(AssignmentGroupContact).all()}
    finally:
        db.close()

    sent: List[str] = []
    for group in groups:
        contact = contacts.get(group)
        if not contact:
            continue
        recipients = _recipients_for(contact)
        if not recipients:
            continue
        report = compute_group_report(work_df, group)
        if report and send_group_summary(group, report, recipients):
            sent.append(group)

    logger.info("Open-change digest (%s): emailed %d of %d group(s) from %s",
                only_group or "all groups", len(sent), len(groups),
                source_filename or "the latest upload")
    return {"sent": sent, "total_groups": len(groups)}


def dispatch_latest_open_change_digest() -> Dict[str, Any]:
    """Scheduler entry point: email the summaries for the most recent open
    change-request upload. No-ops cleanly when nothing has been uploaded or
    the session has expired."""
    from . import session_store

    sid = session_store.get_latest("open_cr")
    if not sid:
        logger.info("Open-change digest: no recent upload - nothing to send.")
        return {"sent": [], "reason": "no_upload"}
    sess = session_store.get(sid)
    if not sess or sess.get("kind") != "open_cr":
        logger.info("Open-change digest: latest session missing/expired.")
        return {"sent": [], "reason": "no_session"}

    return dispatch_open_change_digest(sess["work_df"],
                                       source_filename=sess.get("filename", ""))
