"""
open_incidents.py - analytics for the Open ServiceNow Items sub-module.

Consumes a mapped ServiceNow export of *currently open* items - incidents
or service requests (an open / pending / on-hold list; SR exports are first
normalised by service_request.normalise_sr_export) - and produces:

  * an **overall** summary - counts by state, priority, assignment group,
    ageing/duration bands, a long-open trend and a "no recent update" tally;
  * a **per-assignment-group** professional report - P1-P4 open counts,
    state breakdown, long-open buckets (>7d / >15d / >1 month), incidents with
    no recent update, an assigned-to workload breakdown, and a detail table
    ordered by duration (oldest first);
  * an **off-hold-today** section - the items whose Off hold date falls on the
    day the report is being read (see ``compute_off_hold_report``).

Reuses the existing offline helpers rather than re-implementing them:
  * ``ml.preprocess.load_export``      - encoding-aware CSV/XLSX reader
  * ``ml.column_mapper.map_columns``   - raw -> standardised feature names
  * ``ml.preprocess.normalise_priority / normalise_state`` - canonical labels

Everything runs on the already-uploaded file; no ML models are required, so
this works even before the incident models are trained.
"""

from __future__ import annotations

import logging
import re
from datetime import date, datetime
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from . import config
from .ml.column_mapper import map_columns
from .ml.preprocess import normalise_priority, normalise_state

logger = logging.getLogger(__name__)

# Ageing thresholds (days).
LONG_OPEN_7 = 7
LONG_OPEN_15 = 15
LONG_OPEN_30 = 30          # "> 1 month"
NO_UPDATE_DAYS = 6         # work_notes stale / no update in > 6 days

PRIORITIES = ["P1", "P2", "P3", "P4"]

# States that mean "not open" - used to drop any resolved/closed rows that
# slipped into the export. Everything else is treated as open so custom state
# labels are never silently discarded.
_CLOSED_STATES = {s.lower() for s in config.RESOLVED_STATES}


def _duration_label(days: Optional[int]) -> str:
    """Human 'Xd' / 'Xd Yh'-style label from a whole-day age."""
    if days is None or (isinstance(days, float) and np.isnan(days)):
        return ""
    days = int(days)
    if days <= 0:
        return "< 1 day"
    if days == 1:
        return "1 day"
    if days < 30:
        return f"{days} days"
    months = days // 30
    rem = days % 30
    m = f"{months} month" + ("" if months == 1 else "s")
    return m if rem == 0 else f"{m} {rem}d"


# ---------------------------------------------------------------------------
# Timestamp parsing
#
# ServiceNow renders dates in the EXPORTING USER'S display format, so the same
# field arrives either as the ISO system format (2026-08-21 09:00:00) or in a
# slash format (21/08/2026 09:00:00). A slash date is ambiguous and pandas
# defaults to MONTH-first with only a warning, which silently moves 03/08/2026
# from 3 August to 8 March. On the off-hold report - an equality test against
# today's date - that difference is the whole answer.
#
# This is a UK instance, so slash dates are day-first. The flag is named rather
# than inlined so a non-UK deployment has one line to change. Shared with
# open_changes.py, which imports it, so both sub-modules read a date the same
# way.
# ---------------------------------------------------------------------------
SLASH_DATES_ARE_DAY_FIRST = True

_SLASH_DATE_RE = re.compile(r"^\s*\d{1,2}/\d{1,2}/\d{4}")


def to_datetime_series(series: pd.Series) -> pd.Series:
    """Parse a ServiceNow timestamp column, resolving slash-date ambiguity.

    day-first is applied only when the column actually looks slash-formatted,
    so an ISO export is parsed exactly as pandas would parse it anyway.
    """
    values = series.dropna().astype(str)
    dayfirst = False
    if SLASH_DATES_ARE_DAY_FIRST and len(values):
        slashed = int(values.str.match(_SLASH_DATE_RE).sum())
        dayfirst = slashed > len(values) / 2
    return pd.to_datetime(series, errors="coerce", dayfirst=dayfirst)


def _clean(val) -> str:
    if val is None:
        return ""
    try:
        if pd.isna(val):
            return ""
    except (TypeError, ValueError):
        pass
    s = str(val).strip()
    return "" if s.lower() in ("nan", "nat", "none") else s


# ---------------------------------------------------------------------------
# Data preparation
# ---------------------------------------------------------------------------
def prepare_open_incidents(raw_df: pd.DataFrame,
                           now: Optional[datetime] = None) -> pd.DataFrame:
    """Map + clean the raw export into a working frame of open incidents.

    Output columns: number, short_description, assignment_group, assigned_to,
    priority, state, opened_ts, updated_ts, off_hold_ts, work_notes, days_open,
    days_since_update, no_update.

    `now` overrides "the moment the file was processed" and exists for tests;
    production always passes None so the ages are computed against the clock.
    """
    mapped = map_columns(raw_df)
    now = pd.Timestamp(now or datetime.now())

    df = pd.DataFrame(index=mapped.index)
    df["number"] = mapped["incident_id"].map(_clean)
    df["short_description"] = mapped["title"].map(_clean)
    df["assignment_group"] = mapped["assignment_group"].map(_clean).replace("", "Unassigned group")
    # Display member names with each word's initial capitalised (e.g. an export
    # value of "alice tan" / "ALICE TAN" shows as "Alice Tan") in both the
    # dashboard and the email.
    df["assigned_to"] = (mapped["assigned_to"].map(_clean)
                         .map(lambda s: s.title() if s else "").replace("", "Unassigned"))
    df["priority"] = mapped["priority"].map(normalise_priority)

    # Prefer the detailed incident_state, fall back to state.
    state_src = mapped["incident_state"]
    if state_src.isna().all():
        state_src = mapped["state"]
    df["state_raw"] = state_src.map(_clean)
    df["state"] = df["state_raw"].map(normalise_state)

    df["opened_ts"] = to_datetime_series(mapped["opened_timestamp"])
    df["updated_ts"] = to_datetime_series(mapped["updated_timestamp"])
    # "Off hold date" (Excel display header) / due_date (CSV field name): the
    # date an on-hold item is due to come back off hold. Parsed here, filtered
    # against TODAY at report time - see compute_off_hold_report - so a report
    # opened the day after the upload still answers "due off hold today".
    df["off_hold_ts"] = to_datetime_series(mapped["due_date"])
    df["work_notes"] = mapped["work_notes"].map(_clean)

    # Drop rows that are actually resolved/closed. Service-request exports
    # use composite closed states ("Closed Complete", "Closed Incomplete",
    # "Closed Skipped") and cancellations, so any state starting with
    # "closed"/"cancel" is also treated as not open.
    state_lc = df["state_raw"].str.lower().str.strip()
    closed_mask = (state_lc.isin(_CLOSED_STATES)
                   | state_lc.str.startswith("closed")
                   | state_lc.str.startswith("cancel"))
    df = df[~closed_mask].copy()

    df["days_open"] = ((now - df["opened_ts"]).dt.total_seconds() / 86400).round().astype("Int64")
    df["days_since_update"] = ((now - df["updated_ts"]).dt.total_seconds() / 86400).round().astype("Int64")

    def _no_update(row) -> bool:
        if not row["work_notes"]:
            return True
        dsu = row["days_since_update"]
        if pd.notna(dsu):
            return int(dsu) > NO_UPDATE_DAYS
        # No update timestamp at all - fall back to age.
        do = row["days_open"]
        return bool(pd.notna(do) and int(do) > NO_UPDATE_DAYS)

    df["no_update"] = df.apply(_no_update, axis=1)
    return df.reset_index(drop=True)


# ---------------------------------------------------------------------------
# Aggregations
# ---------------------------------------------------------------------------
def _priority_counts(df: pd.DataFrame) -> Dict[str, int]:
    vc = df["priority"].value_counts()
    return {p: int(vc.get(p, 0)) for p in PRIORITIES}


def _state_counts(df: pd.DataFrame) -> List[Dict[str, Any]]:
    vc = df["state"].value_counts()
    return [{"state": str(s), "count": int(c)} for s, c in vc.items()]


def _ageing_bands(df: pd.DataFrame) -> Dict[str, int]:
    days = pd.to_numeric(df["days_open"], errors="coerce")
    return {
        "over_7": int((days > LONG_OPEN_7).sum()),
        "over_15": int((days > LONG_OPEN_15).sum()),
        "over_30": int((days > LONG_OPEN_30).sum()),
    }


def _long_open_trend(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """Open count by the month each incident was opened (oldest -> newest)."""
    d = df.dropna(subset=["opened_ts"]).copy()
    if d.empty:
        return []
    d["month"] = d["opened_ts"].dt.to_period("M")
    grp = d.groupby("month").size().reset_index(name="count")
    return [{"month": str(r["month"]), "count": int(r["count"])} for _, r in grp.iterrows()]


def _oldest(df: pd.DataFrame) -> Dict[str, Any]:
    d = df.dropna(subset=["days_open"])
    if d.empty:
        return {}
    row = d.loc[d["days_open"].astype(int).idxmax()]
    return {"number": row["number"], "days_open": int(row["days_open"]),
            "short_description": row["short_description"]}


def compute_overall_summary(work_df: pd.DataFrame) -> Dict[str, Any]:
    total = int(len(work_df))
    by_group = (work_df.groupby("assignment_group").size()
                .sort_values(ascending=False))
    groups = [{"name": str(g), "count": int(c)} for g, c in by_group.items()]

    no_update_n = int(work_df["no_update"].sum())
    days = pd.to_numeric(work_df["days_open"], errors="coerce")

    return {
        "total_open": total,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "priority_counts": _priority_counts(work_df),
        "state_counts": _state_counts(work_df),
        "groups": groups,
        "group_count": len(groups),
        "ageing_bands": _ageing_bands(work_df),
        "long_open_trend": _long_open_trend(work_df),
        "no_update_count": no_update_n,
        "no_update_pct": round(no_update_n / total * 100, 1) if total else 0.0,
        "avg_days_open": round(float(days.mean()), 1) if total and days.notna().any() else 0.0,
        "oldest": _oldest(work_df),
    }


def list_groups(work_df: pd.DataFrame) -> List[Dict[str, Any]]:
    by_group = (work_df.groupby("assignment_group").size()
                .sort_values(ascending=False))
    return [{"name": str(g), "count": int(c)} for g, c in by_group.items()]


# ---------------------------------------------------------------------------
# Off-hold-today section
#
# "Which on-hold items are due back TODAY?" - a date equality test against the
# Off hold date column ("Off hold date" in an Excel export, due_date in a CSV
# one), comparing calendar DATES only; the time of day the item is scheduled to
# come off hold is shown but never filtered on.
#
# Deliberately computed at READ time rather than folded into the cached upload
# summary: an upload stays the org-wide "latest" until it is replaced, so a
# report opened the morning after the upload must answer for that morning, not
# for the day the file was loaded. Everything it needs is the off_hold_ts
# column already on the working frame.
# ---------------------------------------------------------------------------
_PRIORITY_ORDER = {p: i for i, p in enumerate(PRIORITIES)}


def _off_hold_row(r) -> Dict[str, Any]:
    off = r["off_hold_ts"]
    return {
        "number": r["number"],
        "short_description": r["short_description"],
        "priority": r["priority"],
        "state": r["state"],
        "assignment_group": r["assignment_group"],
        "assigned_to": r["assigned_to"],
        "opened_at": (r["opened_ts"].strftime("%Y-%m-%d %H:%M")
                      if pd.notna(r["opened_ts"]) else ""),
        "off_hold_at": off.strftime("%Y-%m-%d %H:%M") if pd.notna(off) else "",
        "off_hold_time": off.strftime("%H:%M") if pd.notna(off) else "",
        "days_open": int(r["days_open"]) if pd.notna(r["days_open"]) else None,
        "duration": _duration_label(r["days_open"] if pd.notna(r["days_open"]) else None),
    }


def compute_off_hold_report(work_df: pd.DataFrame,
                            group: Optional[str] = None,
                            today: Optional[date] = None) -> Dict[str, Any]:
    """Items whose Off hold date falls on `today` (defaults to the system date).

    Pass `group` to scope the section to one assignment group; omit it for the
    portfolio view, which additionally returns a per-group count breakdown.

    ``column_present`` distinguishes "nothing is due off hold today" from "this
    export carried no Off hold date at all" - an empty list means two very
    different things to whoever is reading the report, so the caller is told
    which one it is instead of guessing.
    """
    day = today or date.today()

    # An export without the column at all still yields an all-NaT series from
    # the column mapper, so "does any row carry a date?" is the honest test.
    if "off_hold_ts" in work_df.columns:
        dated = work_df[work_df["off_hold_ts"].notna()]
    else:
        dated = work_df.iloc[0:0]

    scoped = dated if group is None else dated[dated["assignment_group"] == group]
    if len(scoped):
        due = scoped[scoped["off_hold_ts"].dt.date == day].copy()
    else:
        due = scoped

    if len(due):
        due = due.assign(
            _pri=due["priority"].map(lambda p: _PRIORITY_ORDER.get(p, len(PRIORITIES))),
            _age=pd.to_numeric(due["days_open"], errors="coerce").fillna(-1),
        ).sort_values(["_pri", "_age"], ascending=[True, False])

    rows = [_off_hold_row(r) for _, r in due.iterrows()]

    groups: List[Dict[str, Any]] = []
    if group is None and rows:
        counts = due.groupby("assignment_group").size().sort_values(ascending=False)
        groups = [{"name": str(g), "count": int(c)} for g, c in counts.items()]

    return {
        "date": day.strftime("%Y-%m-%d"),
        "date_label": day.strftime("%d %b %Y"),
        "group": group,
        "count": len(rows),
        "rows": rows,
        "groups": groups,
        "priority_counts": _priority_counts(due) if len(due) else {p: 0 for p in PRIORITIES},
        "column_present": bool(len(dated)),
        "total_dated": int(len(scoped)),
    }


def compute_group_report(work_df: pd.DataFrame, group: str) -> Optional[Dict[str, Any]]:
    """Professional per-assignment-group report. Returns None if the group has
    no open incidents in this upload."""
    g = work_df[work_df["assignment_group"] == group].copy()
    if g.empty:
        return None

    total = int(len(g))
    days = pd.to_numeric(g["days_open"], errors="coerce")

    # Assigned-to workload (member name + count), unassigned last.
    aw = g.groupby("assigned_to").size().sort_values(ascending=False)
    assigned_breakdown = [{"name": str(n), "count": int(c)} for n, c in aw.items()]

    # No-update incidents (work_notes empty or stale > 6 days).
    nu = g[g["no_update"]].copy()
    nu_sorted = nu.sort_values("days_since_update", ascending=False, na_position="first")
    no_update_rows = [{
        "number": r["number"],
        "short_description": r["short_description"],
        "opened_at": _clean(r["opened_ts"].strftime("%Y-%m-%d %H:%M") if pd.notna(r["opened_ts"]) else ""),
        "days_since_update": (int(r["days_since_update"]) if pd.notna(r["days_since_update"]) else None),
        "priority": r["priority"],
    } for _, r in nu_sorted.iterrows()]

    # Detail table ordered by duration (oldest first).
    detail = g.sort_values("days_open", ascending=False, na_position="last")
    table_rows = [{
        "number": r["number"],
        "short_description": r["short_description"],
        "priority": r["priority"],
        "state": r["state"],
        "assigned_to": r["assigned_to"],
        "opened_at": _clean(r["opened_ts"].strftime("%Y-%m-%d %H:%M") if pd.notna(r["opened_ts"]) else ""),
        "days_open": (int(r["days_open"]) if pd.notna(r["days_open"]) else None),
        "duration": _duration_label(r["days_open"] if pd.notna(r["days_open"]) else None),
    } for _, r in detail.iterrows()]

    return {
        "group": group,
        "total_open": total,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        # Computed here rather than at upload time so the section always
        # reflects the day the report is READ (or the digest is sent).
        "off_hold": compute_off_hold_report(work_df, group=group),
        "priority_counts": _priority_counts(g),
        "state_counts": _state_counts(g),
        "ageing_bands": _ageing_bands(g),
        "no_update_count": int(len(nu)),
        "no_update_pct": round(len(nu) / total * 100, 1) if total else 0.0,
        "no_update_rows": no_update_rows,
        "assigned_breakdown": assigned_breakdown,
        "table_rows": table_rows,
        "avg_days_open": round(float(days.mean()), 1) if days.notna().any() else 0.0,
        "oldest": _oldest(g),
    }
