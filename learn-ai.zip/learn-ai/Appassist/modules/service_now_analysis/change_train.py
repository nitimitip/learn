"""
Quarterly retraining script for the CR Template Generator.

Changes vs previous version
----------------------------
* **LightGBM classifiers** - per-field classifiers now use LGBMClassifier
  instead of LogisticRegression.  Graceful fallback to LR if lightgbm is
  not installed.  LightGBM handles the heavy class-imbalance common in CR
  fields (assignment_group, business_service) better than plain LR.

* **Semantic corpus** - after the TF-IDF corpus is built, sentence-embedding
  vectors (``cr_sem_vectors_latest.pkl``) and a BM25 index
  (``cr_bm25_latest.pkl``) are also built if the supporting libraries are
  installed.  change_predict.py uses these for hybrid retrieval.

* **Persisted null fills** - training-time mode/median values are saved to
  ``cr_null_fills.json`` so inference always uses stable fill values.

Trains
------
    * TF-IDF vectorizer         (cr_vectorizer_latest.pkl)
    * Per-field classifiers      (cr_field_<name>_latest.pkl)
    * TF-IDF retrieval corpus    (cr_corpus_vectors_latest.pkl)
    * Semantic retrieval corpus  (cr_sem_vectors_latest.pkl)    [optional]
    * BM25 index                 (cr_bm25_latest.pkl)           [optional]
    * Null fills                 (cr_null_fills.json)

Usage
-----
    python -m modules.service_now_analysis.change_train \\
        --change-input data/2025_Q4_changes.csv
"""

from __future__ import annotations

import argparse
import json
import logging
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import joblib
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split

from . import config
from .ml.change_column_mapper import validate_columns as validate_change_cols
from .ml.change_preprocess import (
    is_successful_change, load_export, preprocess as preprocess_changes,
    compute_null_fills, save_null_fills,
)
from .ml.embedding_utils import build_and_save_extras

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)-7s %(name)s: %(message)s")
logger = logging.getLogger("change_train")

# ---------------------------------------------------------------------------
# Optional LightGBM
# ---------------------------------------------------------------------------
try:
    from lightgbm import LGBMClassifier
    _LGBM_AVAILABLE = True
    logger.info("LightGBM available - CR per-field classifiers will use LGBMClassifier")
except ImportError:
    _LGBM_AVAILABLE = False
    logger.info("LightGBM not installed - CR classifiers will use LogisticRegression")


def _make_classifier():
    """Return LGBMClassifier if available, else LogisticRegression."""
    if _LGBM_AVAILABLE:
        return LGBMClassifier(
            n_estimators=300,
            learning_rate=0.05,
            num_leaves=63,
            class_weight="balanced",
            n_jobs=-1,
            random_state=config.RANDOM_STATE,
            verbose=-1,
        )
    return LogisticRegression(
        max_iter=config.LR_MAX_ITER,
        class_weight="balanced",
        solver="lbfgs",
        multi_class="auto",
    )


# ---------------------------------------------------------------------------
# Loading & accumulation
# ---------------------------------------------------------------------------
def _load_one_or_many(path_or_dir: str) -> pd.DataFrame:
    p = Path(path_or_dir)
    if p.is_dir():
        frames = []
        for f in sorted(p.iterdir()):
            if f.suffix.lower() in (".csv", ".xlsx", ".xls", ".tsv"):
                logger.info("Loading %s (%.1f MB)", f.name,
                            f.stat().st_size / 1024 / 1024)
                frames.append(load_export(f))
        if not frames:
            raise FileNotFoundError(f"No CSV/XLSX files found in {p}")
        df = pd.concat(frames, ignore_index=True, sort=False)
        logger.info("Concatenated %d files -> %d rows", len(frames), len(df))
        return df
    return load_export(p)


def _dedupe_keep_latest(df: pd.DataFrame, id_col: str = "number",
                        ts_col: str = "sys_updated_on") -> pd.DataFrame:
    if id_col not in df.columns:
        return df
    if ts_col in df.columns:
        df = df.copy()
        df["_ts"] = pd.to_datetime(df[ts_col], errors="coerce")
        df = df.sort_values("_ts").drop_duplicates(
            subset=[id_col], keep="last"
        ).drop(columns=["_ts"])
    else:
        df = df.drop_duplicates(subset=[id_col], keep="last")
    return df.reset_index(drop=True)


# ---------------------------------------------------------------------------
# Archiving
# ---------------------------------------------------------------------------
def _archive_existing_cr_models() -> None:
    cr_files = list(config.MODELS_DIR.glob("cr_*"))
    if not cr_files:
        return
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    arch_dir = config.ARCHIVE_DIR / f"cr_{stamp}"
    arch_dir.mkdir(parents=True, exist_ok=True)
    for f in cr_files:
        try:
            shutil.move(str(f), str(arch_dir / f.name))
        except Exception as exc:
            logger.warning("Could not archive %s: %s", f.name, exc)
    logger.info("Archived %d CR artifacts to %s", len(cr_files), arch_dir)

    archives = sorted([d for d in config.ARCHIVE_DIR.iterdir()
                       if d.is_dir() and d.name.startswith("cr_")],
                      reverse=True)
    for old in archives[config.ARCHIVE_KEEP_VERSIONS:]:
        try:
            shutil.rmtree(old)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Per-field classifier training
# ---------------------------------------------------------------------------
def _train_field_classifier(text: List[str], y: pd.Series, vec: TfidfVectorizer,
                             field_name: str) -> Tuple[Optional[Any], Dict[str, Any]]:
    """
    Train one multi-class classifier per CR field.

    Uses LightGBM when available (better calibration on the long-tailed
    class distributions common in assignment_group / business_service).
    Falls back to LogisticRegression otherwise.
    """
    y = y.astype(str).str.strip()
    y = y.replace({"": "Unknown", "nan": "Unknown"})

    counts = y.value_counts()
    keep = counts[counts >= 2].index
    mask = y.isin(keep)

    if mask.sum() < 30 or len(keep) < 2:
        logger.warning("Field %-18s SKIPPED (%d usable rows / %d classes)",
                       field_name, int(mask.sum()), len(keep))
        return None, {"trained": False, "reason": "insufficient_data",
                      "rows": int(mask.sum()), "classes": int(len(keep))}

    X = vec.transform(np.array(text)[mask.values])
    yk = y[mask]

    try:
        Xtr, Xte, ytr, yte = train_test_split(
            X, yk, test_size=config.TEST_SIZE,
            random_state=config.RANDOM_STATE,
            stratify=yk if (yk.value_counts().min() >= 2) else None,
        )
    except ValueError:
        Xtr, Xte, ytr, yte = train_test_split(
            X, yk, test_size=config.TEST_SIZE, random_state=config.RANDOM_STATE)

    mdl = _make_classifier()
    mdl.fit(Xtr, ytr)
    yhat = mdl.predict(Xte)
    f1 = f1_score(yte, yhat, average="weighted", zero_division=0)

    classifier_name = "LightGBM" if _LGBM_AVAILABLE else "LogisticRegression"
    logger.info("Field %-18s f1=%.3f  (%d train / %d test, %d classes) [%s]",
                field_name, f1, Xtr.shape[0], Xte.shape[0], len(keep), classifier_name)

    return mdl, {
        "trained": True,
        "f1_weighted": round(float(f1), 4),
        "n_train": int(Xtr.shape[0]),
        "n_test": int(Xte.shape[0]),
        "classes": int(len(keep)),
        "classifier": classifier_name,
    }


# ---------------------------------------------------------------------------
# Full training
# ---------------------------------------------------------------------------
def _train_all(cr: pd.DataFrame) -> Dict[str, Any]:
    """Train vectorizer + per-field classifiers + TF-IDF and semantic corpora."""
    logger.info("=== Training on %d preprocessed CRs ===", len(cr))

    text = cr["text"].fillna("").astype(str).tolist()

    # TF-IDF vectorizer
    vec = TfidfVectorizer(max_features=config.TFIDF_MAX_FEATURES,
                          ngram_range=(1, config.TFIDF_NGRAM_MAX),
                          min_df=config.TFIDF_MIN_DF,
                          stop_words="english")
    vec.fit(text)
    joblib.dump(vec, config.MODELS_DIR / "cr_vectorizer_latest.pkl")
    logger.info("Vectorizer trained: %d features", len(vec.get_feature_names_out()))

    # Per-field classifiers
    field_metrics: Dict[str, Any] = {}
    for field in ["type", "category", "subcategory", "risk", "priority",
                  "impact", "urgency", "assignment_group", "business_service"]:
        if field not in cr.columns:
            field_metrics[field] = {"trained": False, "reason": "column_missing"}
            continue
        mdl, m = _train_field_classifier(text, cr[field], vec, field)
        if mdl is not None:
            joblib.dump(mdl, config.MODELS_DIR / f"cr_field_{field}_latest.pkl")
        field_metrics[field] = m

    # Retrieval corpus: SUCCESSFUL past CRs only
    cr["_is_success"] = cr.apply(is_successful_change, axis=1)
    corpus = cr[cr["_is_success"]].copy()
    if len(corpus) < 20:
        logger.warning("Only %d successful CRs; falling back to all closed CRs.", len(corpus))
        corpus = cr[cr["state"].astype(str).str.lower().str.contains("closed", na=False)].copy()
        if len(corpus) < 10:
            corpus = cr.copy()

    corpus_text = corpus["text"].fillna("").astype(str).tolist()
    corpus_vecs = vec.transform(corpus_text)

    keep_cols = ["change_id", "title", "type", "risk", "priority", "category",
                 "subcategory", "assignment_group", "configuration_item",
                 "business_service", "implementation_plan", "backout_plan",
                 "test_plan", "close_notes", "risk_impact_analysis",
                 "business_duration", "environment",
                 "closed_timestamp", "end_timestamp", "opened_timestamp"]
    keep_cols = [c for c in keep_cols if c in corpus.columns]

    joblib.dump(corpus_vecs, config.MODELS_DIR / "cr_corpus_vectors_latest.pkl")
    joblib.dump(corpus[keep_cols].reset_index(drop=True),
                config.MODELS_DIR / "cr_corpus_dataframe_latest.pkl")
    logger.info("Saved CR retrieval corpus: %d successful CRs", len(corpus))

    # NEW: Semantic corpus + BM25
    # Build sentence-embedding vectors and BM25 index for the successful CR
    # corpus.  Used by change_predict.py for hybrid retrieval.
    # Skipped silently if libraries / model path are unavailable.
    embedding_model_path = getattr(config, "EMBEDDING_MODEL_PATH", None)
    sem_results = build_and_save_extras(
        texts=corpus_text,
        prefix="cr",
        models_dir=config.MODELS_DIR,
        model_path=str(embedding_model_path) if embedding_model_path else None,
    )
    if sem_results["sem_ok"]:
        logger.info("Semantic CR corpus vectors saved (%d CRs)", len(corpus))
    if sem_results["bm25_ok"]:
        logger.info("BM25 CR index saved (%d CRs)", len(corpus))

    return {
        "field_metrics": field_metrics,
        "corpus_size": int(len(corpus)),
        "semantic_corpus_built": sem_results["sem_ok"],
        "bm25_corpus_built": sem_results["bm25_ok"],
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> int:
    p = argparse.ArgumentParser(description="Train CR Template Generator models.")
    p.add_argument("--change-input", help="Single CR export file (CSV/XLSX)")
    p.add_argument("--change-input-dir",
                   help="Folder containing one or more CR exports")
    p.add_argument("--skip-archive", action="store_true")
    args = p.parse_args()

    if not (args.change_input or args.change_input_dir):
        p.error("Provide either --change-input or --change-input-dir")

    t0 = time.time()
    logger.info("Loading CR data...")
    cr_raw = _load_one_or_many(args.change_input or args.change_input_dir)
    logger.info("Raw CR rows: %d", len(cr_raw))

    ok, missing_req, missing_rec = validate_change_cols(cr_raw)
    if not ok:
        logger.error("Missing required CR columns: %s", missing_req)
        return 2
    if missing_rec:
        logger.warning("Missing recommended CR columns: %s", missing_rec)

    cr_raw = _dedupe_keep_latest(cr_raw)
    logger.info("After dedup-by-number: %d rows", len(cr_raw))

    cr = preprocess_changes(cr_raw)
    logger.info("After preprocessing: %d rows", len(cr))

    if len(cr) < 100:
        logger.error("Need at least 100 valid CRs to train; have %d", len(cr))
        return 2

    # Persist null fills before archiving
    fills = compute_null_fills(cr)
    save_null_fills(fills, config.MODELS_DIR / "cr_null_fills.json")
    logger.info("CR null fills persisted (%d columns)", len(fills))

    if not args.skip_archive:
        _archive_existing_cr_models()

    metrics: Dict[str, Any] = {
        "trained_at": datetime.now().isoformat(timespec="seconds"),
        "n_changes": len(cr),
        "training_data_files": (str(args.change_input)
                                if args.change_input
                                else str(args.change_input_dir)),
        "lgbm_used": _LGBM_AVAILABLE,
    }
    metrics.update(_train_all(cr))
    metrics["elapsed_seconds"] = round(time.time() - t0, 1)

    with open(config.MODELS_DIR / "cr_metadata.json", "w") as f:
        json.dump(metrics, f, indent=2, default=str)

    logger.info("OK CR training complete in %.1fs.", metrics["elapsed_seconds"])
    print(json.dumps(metrics, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
