"""
Group one person's captured ServiceNow tickets into THEMES of a similar
nature, and roll them up by priority.

This is the individual-level counterpart of the Batch Analysis chronic-issue
panel (ml/predict.py, panel_chronic_issues): the same technique - TF-IDF over
the ticket text followed by MiniBatchKMeans, with the cluster centroid's top
terms as the label - applied to the tickets captured against one assignee
instead of a whole export. Reused by the Resource Utilization individual page
and by that page's Excel download, so the screen and the workbook can never
disagree about what a theme is.

Honesty rules (the reason this is a module and not an inline helper)
--------------------------------------------------------------------
* Clustering runs only with enough real text to mean anything
  (MIN_TICKETS_FOR_CLUSTERING). Below that the tickets are grouped by the
  category the export actually stated, and the result says so via `method`
  - the caller renders the method, so a reader is never left thinking a
  keyword grouping was a model.
* A ticket whose export carried no short description cannot join a text
  theme. It is counted in `unthemed` rather than being forced into the
  nearest cluster.
* A missing priority / category is reported as NOT_SET, never as the modal
  value (workload_capture stores those blanks as NULL for this reason).
* Nothing here trains or persists a model; it is a read-only analysis of
  rows already captured.
"""

import logging
import re
from collections import Counter

logger = logging.getLogger(__name__)


# Canonical priority ordering; anything the export left blank sorts last.
PRIORITY_ORDER = ['P1', 'P2', 'P3', 'P4']
NOT_SET = 'Not set'

PRIORITY_LABELS = {
    'P1': 'P1 - Critical',
    'P2': 'P2 - High',
    'P3': 'P3 - Moderate',
    'P4': 'P4 - Low',
    NOT_SET: 'Priority not set',
}

# Fixed priority colours (severity ramp - red hot, slate cold). Colour
# follows severity, so the same priority reads the same on every screen.
PRIORITY_COLORS = {
    'P1': '#B91C1C',
    'P2': '#EA580C',
    'P3': '#2A78D6',
    'P4': '#0E9488',
    NOT_SET: '#94A3B8',
}

# Below this many usable ticket texts, k-means says more about the
# random seed than about the work - fall back to stated categories.
MIN_TICKETS_FOR_CLUSTERING = 12

# A theme has to hold at least this many tickets to be worth naming.
MIN_THEME_SIZE = 2

# Roughly this many tickets per cluster, so a bigger queue gets more
# themes without the list becoming unreadable.
TICKETS_PER_THEME = 8

MAX_THEMES = 8
MAX_SAMPLES_PER_THEME = 3
MAX_LABEL_TERMS = 3

# Ticket-tracker boilerplate that carries no meaning in a theme label.
# Deliberately short: real operational words (password, access, unable)
# stay in, because they are exactly what a theme is about.
_DOMAIN_STOPWORDS = [
    'please', 'kindly', 'thanks', 'thank', 'regards', 'hi', 'hello',
    'dear', 'team', 'fw', 'fwd', 're', 'urgent', 'asap',
    'incident', 'inc', 'ticket', 'request', 'req', 'ritm', 'sctask',
]

# Tokens must start with a letter, so ticket numbers, dates and ids do not
# become theme labels.
_TOKEN_PATTERN = r'(?u)\b[a-zA-Z][a-zA-Z0-9_-]{2,}\b'

_WHITESPACE = re.compile(r'\s+')


def _text_of(ticket):
    """The clustering text for a ticket: its short description."""
    return _WHITESPACE.sub(' ', (ticket.get('title') or '').strip())


def _value_or_not_set(value):
    text = (value or '').strip()
    return text or NOT_SET


def priority_breakdown(tickets):
    """
    [{key, label, color, incidents, service_requests, total}] over the
    canonical priority order, blanks last. Priorities with no tickets at
    all are dropped so the chart shows the profile, not the enum.
    """
    counts = {}
    for ticket in tickets:
        key = _value_or_not_set(ticket.get('priority'))
        if key not in PRIORITY_LABELS:
            key = NOT_SET
        bucket = counts.setdefault(key, {'incidents': 0,
                                         'service_requests': 0,
                                         'total': 0})
        if ticket.get('type') == 'service_request':
            bucket['service_requests'] += 1
        else:
            bucket['incidents'] += 1
        bucket['total'] += 1

    rows = []
    for key in PRIORITY_ORDER + [NOT_SET]:
        bucket = counts.get(key)
        if not bucket:
            continue
        rows.append({
            'key': key,
            'label': PRIORITY_LABELS[key],
            'color': PRIORITY_COLORS[key],
            'incidents': bucket['incidents'],
            'service_requests': bucket['service_requests'],
            'total': bucket['total'],
        })
    return rows


def _label_from_terms(terms):
    """
    A readable theme label from the centroid's strongest terms.

    Terms arrive strongest-first, so the first one wins any overlap: once
    "password reset" is kept, a later "password" or "reset" adds nothing
    to the label and is skipped.
    """
    kept = []
    kept_words = set()
    for term in terms:
        words = set(term.split())
        if words & kept_words:
            continue
        kept.append(term)
        kept_words |= words
        if len(kept) >= MAX_LABEL_TERMS:
            break
    return ' / '.join(k.title() for k in kept) if kept else 'Mixed requests'


def _theme_from_tickets(rows, label, total, terms=None):
    """Summarise one group of tickets into the theme shape the UI renders."""
    priorities = Counter(_value_or_not_set(t.get('priority')) for t in rows)
    categories = Counter(_value_or_not_set(t.get('category')) for t in rows)
    opened = sorted(t['opened_at'] for t in rows if t.get('opened_at'))

    ranked_priorities = sorted(
        priorities.items(),
        key=lambda kv: (-kv[1],
                        PRIORITY_ORDER.index(kv[0])
                        if kv[0] in PRIORITY_ORDER else len(PRIORITY_ORDER)))

    return {
        'label': label,
        'terms': list(terms or []),
        'size': len(rows),
        'share': round(len(rows) * 100.0 / total, 1) if total else 0.0,
        'incidents': sum(1 for t in rows
                         if t.get('type') != 'service_request'),
        'service_requests': sum(1 for t in rows
                                if t.get('type') == 'service_request'),
        'priority_counts': dict(priorities),
        'top_priority': ranked_priorities[0][0] if ranked_priorities else NOT_SET,
        'priority_summary': ', '.join('%s x%d' % (key, count)
                                      for key, count in ranked_priorities),
        'categories': categories.most_common(3),
        'top_category': categories.most_common(1)[0][0] if categories
                        else NOT_SET,
        'samples': [{'number': t.get('number'), 'title': t.get('title') or ''}
                    for t in rows[:MAX_SAMPLES_PER_THEME]],
        'numbers': [t.get('number') for t in rows],
        'first_seen': opened[0] if opened else None,
        'last_seen': opened[-1] if opened else None,
    }


def _cluster_themes(tickets, max_themes):
    """
    TF-IDF + MiniBatchKMeans over the ticket titles.

    Returns (themes, unthemed_count) or None when the model libraries are
    unavailable or the corpus is too thin to vectorise - the caller then
    falls back to the stated categories.
    """
    try:
        from sklearn.cluster import MiniBatchKMeans
        from sklearn.feature_extraction.text import (ENGLISH_STOP_WORDS,
                                                     TfidfVectorizer)
    except ImportError:
        logger.info('scikit-learn unavailable - ticket themes fall back to '
                    'stated categories')
        return None

    from . import config

    usable = [t for t in tickets if _text_of(t)]
    if len(usable) < MIN_TICKETS_FOR_CLUSTERING:
        return None

    stop_words = list(ENGLISH_STOP_WORDS.union(_DOMAIN_STOPWORDS))
    try:
        vectorizer = TfidfVectorizer(
            ngram_range=(1, config.TFIDF_NGRAM_MAX),
            max_features=config.TFIDF_MAX_FEATURES,
            min_df=1,               # a personal queue is a small corpus
            stop_words=stop_words,
            token_pattern=_TOKEN_PATTERN,
            sublinear_tf=True,
        )
        matrix = vectorizer.fit_transform(_text_of(t) for t in usable)
    except ValueError as exc:
        # Empty vocabulary: every title was stopwords / numbers.
        logger.info('Ticket theme vectorisation produced no vocabulary '
                    '(%s) - falling back to stated categories', exc)
        return None

    if matrix.shape[1] == 0:
        return None

    n_clusters = max(2, min(max_themes,
                            len(usable) // TICKETS_PER_THEME,
                            matrix.shape[0] - 1))
    try:
        model = MiniBatchKMeans(n_clusters=n_clusters,
                                random_state=config.RANDOM_STATE,
                                batch_size=256, n_init=3)
        labels = model.fit_predict(matrix)
    except Exception as exc:
        logger.warning('Ticket theme clustering failed: %s', exc)
        return None

    feature_names = vectorizer.get_feature_names_out()
    grouped = {}
    for ticket, cluster_id in zip(usable, labels):
        grouped.setdefault(int(cluster_id), []).append(ticket)

    total = len(tickets)
    themes = []
    unthemed = total - len(usable)
    for cluster_id, rows in grouped.items():
        if len(rows) < MIN_THEME_SIZE:
            unthemed += len(rows)
            continue
        centre = model.cluster_centers_[cluster_id]
        ranked = centre.argsort()[::-1][:MAX_LABEL_TERMS * 3]
        terms = [feature_names[i] for i in ranked if centre[i] > 0]
        themes.append(_theme_from_tickets(rows, _label_from_terms(terms),
                                          total, terms=terms))

    if not themes:
        return None
    themes.sort(key=lambda t: (-t['size'], t['label']))
    return themes, unthemed


def _category_themes(tickets, max_themes):
    """Fallback grouping: the category the export actually stated."""
    grouped = {}
    unthemed = 0
    for ticket in tickets:
        key = (ticket.get('category') or '').strip()
        if not key:
            unthemed += 1
            continue
        grouped.setdefault(key, []).append(ticket)

    total = len(tickets)
    themes = []
    for key, rows in grouped.items():
        if len(rows) < MIN_THEME_SIZE:
            unthemed += len(rows)
            continue
        themes.append(_theme_from_tickets(rows, key, total))
    themes.sort(key=lambda t: (-t['size'], t['label']))

    if len(themes) > max_themes:
        unthemed += sum(t['size'] for t in themes[max_themes:])
        themes = themes[:max_themes]
    return themes, unthemed


def analyse_themes(tickets, max_themes=MAX_THEMES):
    """
    Group `tickets` into themes of a similar nature.

    `tickets` is a list of dicts with at least: number, type, title,
    priority, category, opened_at (any of which may be None).

    Returns a dict the page and the workbook both render:
        method        'clustering' | 'category' | 'none'
        method_label  a sentence naming what produced the grouping
        themes        [{label, size, share, incidents, service_requests,
                        priority_summary, top_priority, categories,
                        samples, numbers, first_seen, last_seen, terms}]
        unthemed      tickets in no named theme (too few of their kind, or
                      no short description to cluster on)
        total         tickets considered
    """
    tickets = list(tickets or [])
    total = len(tickets)
    if not total:
        return {'method': 'none', 'method_label': 'No tickets captured.',
                'themes': [], 'unthemed': 0, 'total': 0}

    clustered = _cluster_themes(tickets, max_themes)
    if clustered:
        themes, unthemed = clustered
        return {
            'method': 'clustering',
            'method_label': (
                'Grouped by TF-IDF + k-means over the ticket short '
                'descriptions - the same technique as the Batch Analysis '
                'chronic-issue panel, run over this person\'s tickets. '
                'Theme names are the strongest terms in each group.'),
            'themes': themes[:max_themes],
            'unthemed': unthemed + sum(t['size'] for t in themes[max_themes:]),
            'total': total,
        }

    themes, unthemed = _category_themes(tickets, max_themes)
    if themes:
        return {
            'method': 'category',
            'method_label': (
                'Too few tickets with a short description to cluster '
                'reliably, so these are grouped by the category the '
                'ServiceNow export stated - not a model result.'),
            'themes': themes,
            'unthemed': unthemed,
            'total': total,
        }

    return {
        'method': 'none',
        'method_label': (
            'Not enough descriptive data in the captured tickets to group '
            'them - the export carried no short description or category.'),
        'themes': [],
        'unthemed': total,
        'total': total,
    }
