"""
service_request.py - header normalisation for ServiceNow exports.

Two header conventions arrive in uploads, decided by the FILE TYPE (the same
rule applies to incident and service-request files):

  * CSV exports   - snake_case field names (number, short_description,
                    opened_at, sys_updated_on, ...). Consumed as-is.
  * Excel exports - display headers with spaces ("Number",
                    "Short description", "Opened", "Assignment group", ...).
                    `normalise_display_export` maps them onto the same
                    snake_case field names so everything downstream -
                    ml.column_mapper, ml.preprocess, summary_processor,
                    open_incidents - works unchanged.

Display-header renames applied after snake-casing:

  Opened      -> opened_at           Updated    -> sys_updated_on
  Created     -> sys_created_on      Closed     -> closed_at
  Resolved    -> resolved_at         Caller     -> caller_id
  Configuration item -> cmdb_ci      Off hold date -> due_date

`apply_sr_fallbacks` adds the service-request-specific derivations (used for
SR uploads of EITHER file type):

  resolved_at  <- Closed, falling back to Actual end (SRs have no "Resolved")
  u_tenant_category <- Item / cat_item  (catalog item = the "type" breakdown)
  made_sla     <- SLA Met (when Made SLA is absent)
"""

from __future__ import annotations

import logging
import re
from typing import List

import pandas as pd

logger = logging.getLogger(__name__)


def _snake(name: str) -> str:
    """'Short description' -> 'short_description'."""
    return re.sub(r"[^0-9a-z]+", "_", str(name).strip().lower()).strip("_")


# Applied AFTER snake-casing. Only renames whose target isn't already present
# are applied, so a file that already uses field names passes through cleanly.
_DISPLAY_RENAMES = {
    "opened":   "opened_at",
    "updated":  "sys_updated_on",
    "created":  "sys_created_on",
    "closed":   "closed_at",
    "resolved": "resolved_at",
    "caller":   "caller_id",
    "configuration_item": "cmdb_ci",
    # ServiceNow labels the due-date field "Off hold date" on incident and
    # service-request views; the CSV field name is due_date. The Off-hold-today
    # report reads due_date, so an Excel export lands on the same name.
    "off_hold_date": "due_date",
}

# The pipeline's required columns, with the display header users see in an
# Excel export - used to phrase "missing column" errors in the vocabulary
# of the file they actually uploaded.
REQUIRED_DISPLAY_NAMES = {
    "number":            "Number",
    "short_description": "Short description",
    "state":             "State",
    "opened_at":         "Opened",
}


def normalise_display_export(raw_df: pd.DataFrame) -> pd.DataFrame:
    """Map an Excel export's display headers onto snake_case field names.

    Works for incident AND service-request files; CSV exports (already
    field-named) must NOT be passed through this - their snake_case headers
    are consumed directly.
    """
    df = raw_df.copy()
    df.columns = [_snake(c) for c in df.columns]
    # Duplicate headers after snake-casing: keep the first occurrence.
    df = df.loc[:, ~df.columns.duplicated()]

    renames = {src: dst for src, dst in _DISPLAY_RENAMES.items()
               if src in df.columns and dst not in df.columns}
    df = df.rename(columns=renames)

    logger.info("Normalised display-header export: %d columns (%d renamed)",
                len(df.columns), len(renames))
    return df


def apply_sr_fallbacks(df: pd.DataFrame) -> pd.DataFrame:
    """Service-request-specific column derivations (any file type).

    Expects snake_case field names (a CSV export as-is, or an Excel export
    already passed through normalise_display_export).
    """
    df = df.copy()

    # Resolution point for an SR: Closed, falling back to Actual end.
    if "resolved_at" not in df.columns:
        if "closed_at" in df.columns:
            df["resolved_at"] = df["closed_at"]
            if "actual_end" in df.columns:
                blank = df["resolved_at"].isna() | \
                    (df["resolved_at"].astype(str).str.strip() == "")
                df.loc[blank, "resolved_at"] = df.loc[blank, "actual_end"]
        elif "actual_end" in df.columns:
            df["resolved_at"] = df["actual_end"]

    # The catalog Item is the most meaningful "type" for a service request -
    # surface it through the category slot the summary's type breakdown reads
    # (u_tenant_category wins over category in the column mapper). Field-name
    # exports call the same column cat_item.
    if "u_tenant_category" not in df.columns:
        for src in ("item", "cat_item"):
            if src in df.columns:
                df["u_tenant_category"] = df[src]
                break

    # SLA flag fallback.
    if "made_sla" not in df.columns and "sla_met" in df.columns:
        df["made_sla"] = df["sla_met"]

    return df


def normalise_sr_export(raw_df: pd.DataFrame) -> pd.DataFrame:
    """Display-header SR export -> pipeline-ready frame (kept for callers
    that always deal with Excel-style headers)."""
    return apply_sr_fallbacks(normalise_display_export(raw_df))


def to_display_names(missing: List[str]) -> List[str]:
    """Rephrase missing snake_case column names using Excel display headers."""
    return [REQUIRED_DISPLAY_NAMES.get(c, c) for c in missing]
