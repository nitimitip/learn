"""
Shared utilities for semantic search (sentence embeddings), BM25 retrieval,
and MMR-based diversity reranking.

All three features are OPTIONAL - every function returns None / original
input gracefully when the underlying library is not installed or the model
files are not present.  The callers in similarity.py, train.py, etc. check
for None and fall back to pure TF-IDF, so the pipeline degrades cleanly
rather than crashing.

Sentence-transformers model
---------------------------
Must be downloaded once on an internet-connected machine and saved locally:

    from sentence_transformers import SentenceTransformer
    SentenceTransformer("all-MiniLM-L6-v2").save("/models/all-MiniLM-L6-v2")

Then set in config.py:

    EMBEDDING_MODEL_PATH = Path("/models/all-MiniLM-L6-v2")

The model is cached in memory after the first load so repeated inference
calls (e.g. per-request similarity lookups) pay the ~400 MB load cost
only once per process.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, List, Optional, Tuple

import joblib
import numpy as np

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional library imports - fail silently so the rest of the code works
# ---------------------------------------------------------------------------
try:
    from sentence_transformers import SentenceTransformer as _ST
    _ST_AVAILABLE = True
except ImportError:
    _ST_AVAILABLE = False
    logger.info("sentence-transformers not installed - semantic search disabled")

try:
    from rank_bm25 import BM25Okapi as _BM25
    _BM25_AVAILABLE = True
except ImportError:
    _BM25_AVAILABLE = False
    logger.info("rank-bm25 not installed - BM25 search disabled")

# Module-level encoder cache: one entry per model path so different corpora
# that share a model path pay the load cost only once.
_encoder_cache: dict = {}


# ---------------------------------------------------------------------------
# Encoder loading & caching
# ---------------------------------------------------------------------------
def get_encoder(model_path: Optional[str | Path]) -> Optional[Any]:
    """
    Load the sentence encoder from a local directory, caching it in memory.

    Parameters
    ----------
    model_path :
        Filesystem path to the saved SentenceTransformer model directory
        (the folder produced by model.save(...)). Pass None to skip.

    Returns None if sentence-transformers is not installed or the path is
    invalid, so callers can detect unavailability without try/except.
    """
    if not _ST_AVAILABLE or not model_path:
        return None
    key = str(model_path)
    if key in _encoder_cache:
        return _encoder_cache[key]
    try:
        model = _ST(str(model_path))
        _encoder_cache[key] = model
        logger.info("Sentence encoder loaded from %s", model_path)
        return model
    except Exception as exc:
        logger.warning("Could not load sentence encoder from %s: %s", model_path, exc)
        return None


# ---------------------------------------------------------------------------
# Encoding
# ---------------------------------------------------------------------------
def encode_texts(texts: List[str], model, batch_size: int = 64) -> Optional[np.ndarray]:
    """
    Encode a list of texts into L2-normalised dense vectors.

    Returns a float32 numpy array of shape (n_texts, embedding_dim), or
    None if the model is unavailable.  Vectors are normalised so that dot
    product == cosine similarity, which is important for the hybrid scoring.
    """
    if model is None or not texts:
        return None
    try:
        vecs = model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=len(texts) > 1000,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        return vecs.astype(np.float32)
    except Exception as exc:
        logger.warning("Text encoding failed: %s", exc)
        return None


# ---------------------------------------------------------------------------
# BM25
# ---------------------------------------------------------------------------
def build_bm25(texts: List[str]) -> Optional[Any]:
    """
    Build a BM25 index from a list of text strings.

    Tokenisation is naive (lowercase split) which is consistent with how
    the BM25 query function tokenises at inference time.

    Returns None if rank-bm25 is not installed.
    """
    if not _BM25_AVAILABLE or not texts:
        return None
    try:
        tokenized = [t.lower().split() for t in texts]
        return _BM25(tokenized)
    except Exception as exc:
        logger.warning("BM25 build failed: %s", exc)
        return None


def bm25_scores(bm25_index, query: str, n_docs: int) -> Optional[np.ndarray]:
    """
    Retrieve BM25 scores for all n_docs documents given a query string.
    Returns a float32 numpy array of length n_docs, or None.
    """
    if bm25_index is None:
        return None
    try:
        scores = np.array(bm25_index.get_scores(query.lower().split()), dtype=np.float32)
        return scores
    except Exception as exc:
        logger.warning("BM25 scoring failed: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Build + save helpers (used during training)
# ---------------------------------------------------------------------------
def build_and_save_extras(
    texts: List[str],
    prefix: str,
    models_dir: Path,
    model_path: Optional[str | Path] = None,
) -> dict:
    """
    Build and save semantic vectors and a BM25 index for a corpus.

    Artifacts are named ``{prefix}_sem_vectors_latest.pkl`` and
    ``{prefix}_bm25_latest.pkl`` and placed under ``models_dir``.

    Parameters
    ----------
    texts :
        The corpus texts in the same order as the corpus dataframe rows.
    prefix :
        Short identifier, e.g. ``"incident"``, ``"cr"``, ``"problem"``.
    models_dir :
        Directory where model files live (config.MODELS_DIR).
    model_path :
        Local path to the SentenceTransformer model. None = skip embeddings.

    Returns
    -------
    dict with keys ``sem_ok`` and ``bm25_ok`` (booleans).
    """
    results = {"sem_ok": False, "bm25_ok": False}

    # --- Sentence embeddings ---
    encoder = get_encoder(model_path)
    if encoder is not None:
        vecs = encode_texts(texts, encoder)
        if vecs is not None:
            out = models_dir / f"{prefix}_sem_vectors_latest.pkl"
            joblib.dump(vecs, out)
            logger.info("Saved semantic vectors (%s): shape %s -> %s", prefix, vecs.shape, out.name)
            results["sem_ok"] = True

    # --- BM25 ---
    bm25 = build_bm25(texts)
    if bm25 is not None:
        out = models_dir / f"{prefix}_bm25_latest.pkl"
        joblib.dump(bm25, out)
        logger.info("Saved BM25 index (%s): %d docs -> %s", prefix, len(texts), out.name)
        results["bm25_ok"] = True

    return results


# ---------------------------------------------------------------------------
# Load helpers (used at inference / similarity time)
# ---------------------------------------------------------------------------
def load_sem_vectors(prefix: str, models_dir: Path) -> Optional[np.ndarray]:
    """Load pre-built semantic corpus vectors. Returns None if not found."""
    path = models_dir / f"{prefix}_sem_vectors_latest.pkl"
    if not path.exists():
        return None
    try:
        return joblib.load(path)
    except Exception as exc:
        logger.warning("Could not load sem vectors (%s): %s", prefix, exc)
        return None


def load_bm25_index(prefix: str, models_dir: Path) -> Optional[Any]:
    """Load pre-built BM25 index. Returns None if not found."""
    path = models_dir / f"{prefix}_bm25_latest.pkl"
    if not path.exists():
        return None
    try:
        return joblib.load(path)
    except Exception as exc:
        logger.warning("Could not load BM25 index (%s): %s", prefix, exc)
        return None


# ---------------------------------------------------------------------------
# Null-fill persistence helpers  (used by all three preprocessing pipelines)
# ---------------------------------------------------------------------------
import json


def save_null_fills(fills: dict, path: Path) -> None:
    """
    Persist training-time null-fill values to a JSON file.

    Saving fills alongside the model artifacts means inference always uses
    the same mode/median values that were computed on the training corpus,
    rather than recomputing them from each inference batch (which can differ
    significantly for small or skewed batches).
    """
    try:
        with open(path, "w") as f:
            json.dump(fills, f, indent=2, default=str)
        logger.info("Null fills saved to %s (%d columns)", path.name, len(fills))
    except Exception as exc:
        logger.warning("Could not save null fills to %s: %s", path, exc)


def load_null_fills(path: Path) -> Optional[dict]:
    """
    Load previously persisted null-fill values.  Returns None if the file
    does not exist so callers can fall back to computing fills from the batch.
    """
    if not path.exists():
        return None
    try:
        with open(path) as f:
            fills = json.load(f)
        logger.info("Null fills loaded from %s (%d columns)", path.name, len(fills))
        return fills
    except Exception as exc:
        logger.warning("Could not load null fills from %s: %s", path, exc)
        return None


# ---------------------------------------------------------------------------
# Reciprocal Rank Fusion (RRF) hybrid scoring
# ---------------------------------------------------------------------------
def reciprocal_rank_fusion(
    ranked_lists: List[List[int]],
    n_docs: int,
    k: int = 60,
) -> np.ndarray:
    """
    Combine multiple ranked lists into a single score array using RRF.

    RRF score for document i = sum  1 / (k + rank(i, method))
    where rank is 1-based and only methods that have the document contribute.

    Parameters
    ----------
    ranked_lists :
        Each element is a list of document indices in rank order (best first).
        Not all lists need to cover all documents.
    n_docs :
        Total number of documents in the corpus.
    k :
        RRF constant (default 60, standard value from the original paper).

    Returns
    -------
    float32 numpy array of length n_docs; higher is better.
    """
    scores = np.zeros(n_docs, dtype=np.float32)
    for ranked in ranked_lists:
        for rank, doc_idx in enumerate(ranked, start=1):
            if 0 <= doc_idx < n_docs:
                scores[doc_idx] += 1.0 / (k + rank)
    return scores


# ---------------------------------------------------------------------------
# MMR diversity reranking
# ---------------------------------------------------------------------------
def mmr_rerank(
    query_vec: np.ndarray,
    candidate_vecs: np.ndarray,
    candidate_indices: List[int],
    top_n: int = 10,
    lambda_param: float = 0.7,
) -> List[int]:
    """
    Maximal Marginal Relevance reranking for diversity.

    Selects documents iteratively: at each step the document that maximises
    lambda-sim(doc, query) - (1-lambda)-max_sim(doc, already_selected) is chosen.
    lambda=1.0 -> pure relevance (no diversity), lambda=0.0 -> pure diversity.

    Parameters
    ----------
    query_vec :
        Dense query vector, shape (dim,) or (1, dim).  Must be L2-normalised
        if cosine similarity is desired (sentence-transformer vectors are).
    candidate_vecs :
        Dense candidate vectors, shape (n_candidates, dim).  Same normalisation
        requirement as query_vec.
    candidate_indices :
        Original corpus indices corresponding to each row of candidate_vecs.
    top_n :
        Number of items to return.
    lambda_param :
        Relevance vs diversity trade-off (0.7 is a sensible default).

    Returns
    -------
    List of selected original corpus indices (subset of candidate_indices).
    """
    n = len(candidate_indices)
    if n == 0:
        return []
    if n <= top_n:
        return list(candidate_indices)

    query_vec = np.array(query_vec, dtype=np.float32).flatten()
    # Relevance: dot product with query (equivalent to cosine sim for normalised vecs)
    rel_scores = candidate_vecs.dot(query_vec)  # shape (n,)

    selected_positions: List[int] = []
    remaining: List[int] = list(range(n))

    while len(selected_positions) < top_n and remaining:
        if not selected_positions:
            # First pick: purely by relevance
            best_pos = max(remaining, key=lambda i: rel_scores[i])
        else:
            sel_vecs = candidate_vecs[selected_positions]  # (n_sel, dim)
            # For each remaining candidate: max sim to already-selected docs
            rem_vecs = candidate_vecs[remaining]           # (n_rem, dim)
            sim_to_sel = rem_vecs.dot(sel_vecs.T).max(axis=1)  # (n_rem,)
            mmr_vals = (lambda_param * rel_scores[remaining]
                        - (1.0 - lambda_param) * sim_to_sel)
            best_pos = remaining[int(np.argmax(mmr_vals))]

        selected_positions.append(best_pos)
        remaining.remove(best_pos)

    return [candidate_indices[i] for i in selected_positions]
