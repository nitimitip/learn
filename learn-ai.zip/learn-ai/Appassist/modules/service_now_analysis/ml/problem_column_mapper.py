"""
Map raw ServiceNow Problem export columns to standardised internal feature
names. Used to build a problem corpus for the enhanced similar-incident
search, which now also surfaces matching open Problem tickets.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Tuple

import pandas as pd

logger = logging.getLogger(__name__)


COLUMN_MAPPING: Dict[str, List[str]] = {
    "problem_id":          ["number"],
    "title":               ["short_description"],
    "description_full":    ["description"],
    "category":            ["u_tenant_category", "category"],
    "subcategory":         ["u_tenant_subcategory", "subcategory"],
    "priority":            ["priority"],
    "impact":              ["impact"],
    "urgency":             ["urgency"],
    "state":               ["state", "problem_state"],
    "assignment_group":    ["assignment_group"],
    "assigned_to":         ["assigned_to"],
    "configuration_item":  ["cmdb_ci"],
    "business_service":    ["business_service"],
    "company":             ["company"],
    "location":            ["location"],
    "environment":         ["u_environment"],
    "opened_timestamp":    ["opened_at", "sys_created_on", "u_reported_date"],
    "closed_timestamp":    ["closed_at"],
    "resolved_timestamp":  ["resolved_at"],
    "updated_timestamp":   ["sys_updated_on"],
    "fix_at":              ["fix_at"],
    "cause_notes":         ["cause_notes"],
    "close_notes":         ["close_notes"],
    "fix_notes":           ["fix_notes"],
    "workaround":          ["workaround"],
    "workaround_applied":  ["workaround_applied"],
    "known_error":         ["known_error"],
    "major_problem":       ["major_problem"],
    "duplicate_of":        ["duplicate_of"],
    "related_incidents":   ["related_incidents"],
    "rfc":                 ["rfc"],
    "resolution_code":     ["resolution_code"],
    "close_code":          ["u_tenant_close_code"],
    "reopen_count":        ["u_cancel_count"],
    "reassignment_count":  ["reassignment_count"],
    "made_sla":            ["made_sla", "x_caukp_slc_sla_met"],
}

REQUIRED_RAW_COLUMNS = {"number", "short_description", "state"}
RECOMMENDED_RAW_COLUMNS = {
    "u_tenant_category", "priority", "assignment_group", "cmdb_ci",
    "description", "workaround", "cause_notes", "known_error",
}


def map_columns(df: pd.DataFrame) -> pd.DataFrame:
    mapped = pd.DataFrame(index=df.index)
    for feature, candidates in COLUMN_MAPPING.items():
        source_col = next((c for c in candidates if c in df.columns), None)
        if source_col is not None:
            mapped[feature] = df[source_col]
        else:
            mapped[feature] = None

    if "problem_id" in mapped.columns:
        mapped["problem_id"] = mapped["problem_id"].astype(str)

    logger.info("Mapped %d raw problem columns -> %d internal features",
                len(df.columns), len(mapped.columns))
    return mapped


def validate_columns(df: pd.DataFrame) -> Tuple[bool, List[str], List[str]]:
    cols = set(df.columns)
    missing_required = sorted(REQUIRED_RAW_COLUMNS - cols)
    missing_recommended = sorted(RECOMMENDED_RAW_COLUMNS - cols)
    return (len(missing_required) == 0, missing_required, missing_recommended)
