"""
Inference engine: runs all 6 batch-analysis use cases on an uploaded export.

Changes vs previous version
----------------------------
* **Persisted null fills** - ``ModelStore`` now loads ``null_fills.json``
  (written by train.py at training time) and passes the values to
  ``preprocess()`` so single-record and batch inference both use the
  same mode/median fill values that were computed on the training corpus.
  This prevents skewed fills on small batches and aligns inference
  behaviour with what the models were actually trained on.

* Classifier references updated for LightGBM compatibility - both
  LGBMClassifier and the previous LogisticRegression/RandomForest expose
  the same predict / predict_proba API so no other changes are needed here.
"""

from __future__ import annotations

import logging
import re
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

import joblib
import numpy as np
import pandas as pd
import scipy.sparse as sp
from sklearn.cluster import MiniBatchKMeans

from .. import config
from .preprocess import (
    add_resolution_features, get_open_tickets, get_resolved_tickets,
    load_export, preprocess,
)
from .embedding_utils import load_null_fills

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Model cache
# ---------------------------------------------------------------------------
class ModelStore:
    """
    Lazy-loads and caches trained models from disk.

    Thread safety
    -------------
    A single threading.Lock guards every cache read/write.

    mtime-based cache invalidation
    --------------------------------
    The in-process cache reloads a file if its mtime has changed since last
    load, so newly retrained models are picked up without a process restart.

    Null fills
    ----------
    ``null_fills()`` loads the JSON file written by train.py.  These are
    the training-time mode/median values for every categorical and numeric
    column.  Passing them to ``preprocess()`` ensures inference uses stable
    fills rather than recomputing from each (potentially small) batch.
    """

    def __init__(self, models_dir: Path = config.MODELS_DIR):
        self.dir = models_dir
        self._cache: Dict[str, Any] = {}
        self._lock = threading.Lock()

    def _load(self, name: str):
        path = self.dir / f"{name}_latest.pkl"
        with self._lock:
            mtime = path.stat().st_mtime if path.exists() else None
            cached = self._cache.get(name)
            if cached is not None and cached["mtime"] == mtime:
                return cached["obj"]
            if mtime is None:
                self._cache[name] = {"obj": None, "mtime": None}
                return None
            try:
                obj = joblib.load(path)
                logger.info("Loaded (or reloaded) model: %s", name)
            except Exception as exc:
                logger.warning("Failed to load %s: %s", name, exc)
                obj = None
            self._cache[name] = {"obj": obj, "mtime": mtime}
            return obj

    def vectorizer(self):           return self._load("vectorizer")
    def cat_model(self):            return self._load("cat_model")
    def subcat_model(self):         return self._load("subcat_model")
    def pri_model(self):            return self._load("pri_model")
    def route_model(self):          return self._load("route_model")
    def eta_model(self):            return self._load("eta_model")
    def sla_model(self):            return self._load("sla_model")
    def corpus_vectors(self):       return self._load("corpus_vectors")
    def corpus_dataframe(self):     return self._load("corpus_dataframe")
    def column_encoders(self):      return self._load("column_encoders")
    def res_column_encoders(self):  return self._load("res_column_encoders")

    def null_fills(self) -> Optional[dict]:
        """
        Load training-time null fill values from ``null_fills.json``.

        Returns None if the file does not exist (e.g. models not yet
        trained), in which case callers should let preprocess() compute
        fills from the batch itself.
        """
        return load_null_fills(self.dir / "null_fills.json")

    def is_trained(self) -> bool:
        return self.vectorizer() is not None


# ---------------------------------------------------------------------------
# Helpers (unchanged)
# ---------------------------------------------------------------------------
def _augment_with_encoders(X_text: sp.csr_matrix, df: pd.DataFrame,
                            encoders: Optional[Dict], cols: tuple) -> sp.csr_matrix:
    if not encoders:
        return X_text.tocsr() if sp.issparse(X_text) else sp.csr_matrix(X_text)
    blocks = [X_text]
    for col in cols:
        enc = encoders.get(col)
        if enc is None or col not in df.columns:
            continue
        values = df[[col]].astype(str).fillna("Unknown")
        blocks.append(enc.transform(values))
    if len(blocks) == 1:
        return X_text.tocsr() if sp.issparse(X_text) else sp.csr_matrix(X_text)
    return sp.hstack(blocks).tocsr()


def _safe_predict(model, X, default):
    try:
        return model.predict(X)
    except Exception as exc:
        logger.warning("Predict failed: %s", exc)
        return np.full(X.shape[0], default)


def _safe_predict_proba(model, X) -> Optional[np.ndarray]:
    try:
        return model.predict_proba(X)
    except Exception as exc:
        logger.warning("predict_proba failed: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Panel 1 - Categorisation audit
# ---------------------------------------------------------------------------
def panel_categorisation(df: pd.DataFrame, store: ModelStore) -> Dict:
    vec = store.vectorizer()
    model = store.cat_model()

    out = df[["incident_id", "title", "category"]].copy()
    out["ml_category"] = "Unclassified"
    out["ml_category_confidence"] = 0.0
    out["categorisation_match"] = True

    if vec is None or model is None:
        return _summarise_categorisation(out, fallback=True)

    X = vec.transform(df["text"].fillna(""))
    pred = _safe_predict(model, X, default="Unknown")
    proba = _safe_predict_proba(model, X)
    conf = proba.max(axis=1) if proba is not None else np.full(len(df), 0.5)

    out["ml_category"] = pred
    out["ml_category_confidence"] = np.round(conf, 3)
    out["categorisation_match"] = (
        out["ml_category"].astype(str).str.strip().str.lower()
        == out["category"].astype(str).str.strip().str.lower()
    )
    return _summarise_categorisation(out, fallback=False)


def _summarise_categorisation(out: pd.DataFrame, *, fallback: bool) -> Dict:
    counts = out["ml_category"].value_counts().head(15)
    mismatches = (~out["categorisation_match"]).sum()
    return {
        "rows": out,
        "category_counts": counts.to_dict(),
        "total_mismatches": int(mismatches),
        "mismatch_pct": round(float(mismatches) / max(len(out), 1) * 100, 1),
        "fallback_mode": fallback,
    }


# ---------------------------------------------------------------------------
# Panel 2 - SLA breach risk
# ---------------------------------------------------------------------------
def panel_sla_risk(df: pd.DataFrame, store: ModelStore) -> Dict:
    open_df = get_open_tickets(df).copy()
    if open_df.empty:
        return {"rows": open_df, "top_at_risk": [], "high_risk_pct": 0.0}

    vec = store.vectorizer()
    model = store.sla_model()

    if vec is not None and model is not None:
        X_text = vec.transform(open_df["text"].fillna(""))
        try:
            X = _augment_with_encoders(
                X_text, open_df,
                store.res_column_encoders(),
                ("priority", "category", "assignment_group"),
            )
            proba = model.predict_proba(X)[:, 1]
        except Exception as exc:
            logger.warning("SLA model failed, using heuristic: %s", exc)
            proba = _heuristic_sla_risk(open_df)
    else:
        proba = _heuristic_sla_risk(open_df)

    open_df["sla_breach_risk_score"] = np.round(proba, 3)
    open_df["sla_breach_flag"] = proba >= config.SLA_BREACH_HIGH_RISK
    open_df["days_until_breach"] = _days_until_sla(open_df)

    top = (open_df.sort_values("sla_breach_risk_score", ascending=False)
                  .head(config.TOP_N_AT_RISK)
                  [["incident_id", "title", "priority", "assignment_group",
                    "sla_breach_risk_score", "days_until_breach", "age_hours"]])

    return {
        "rows": open_df[["incident_id", "title", "priority", "assignment_group",
                         "sla_breach_risk_score", "sla_breach_flag",
                         "days_until_breach", "age_hours"]],
        "top_at_risk": top.to_dict(orient="records"),
        "high_risk_pct": round(float(open_df["sla_breach_flag"].sum()) /
                               max(len(open_df), 1) * 100, 1),
        "scatter_data": {
            "age_hours": open_df["age_hours"].tolist(),
            "risk": open_df["sla_breach_risk_score"].tolist(),
            "priority": open_df["priority"].astype(str).tolist(),
            "incident_id": open_df["incident_id"].astype(str).tolist(),
        },
    }


def _heuristic_sla_risk(df: pd.DataFrame) -> np.ndarray:
    age_hours = df["age_hours"].fillna(0).clip(lower=0)
    pri_weight = df["priority"].map({"P1": 1.0, "P2": 0.7, "P3": 0.4, "P4": 0.2}).fillna(0.4)
    norm_age = (age_hours / 168.0).clip(upper=1.0)
    return (0.6 * pri_weight + 0.4 * norm_age).clip(0, 1).to_numpy()


def _days_until_sla(df: pd.DataFrame) -> pd.Series:
    if "sla_due" not in df.columns:
        return pd.Series([np.nan] * len(df), index=df.index)
    sla = pd.to_datetime(df["sla_due"], errors="coerce")
    delta = (sla - pd.Timestamp.now()).dt.total_seconds() / 86400.0
    return delta.round(2)


# ---------------------------------------------------------------------------
# Panel 3 - Resolution time prediction
# ---------------------------------------------------------------------------
def panel_resolution_time(df: pd.DataFrame, store: ModelStore) -> Dict:
    open_df = get_open_tickets(df).copy()
    if open_df.empty:
        return {"rows": open_df, "by_priority": {}, "by_team": {},
                "summary": {"mean": 0, "median": 0, "p90": 0}}

    vec = store.vectorizer()
    model = store.eta_model()

    if vec is not None and model is not None:
        X_text = vec.transform(open_df["text"].fillna(""))
        try:
            X = _augment_with_encoders(
                X_text, open_df, store.res_column_encoders(), ("priority", "category"),
            )
            pred = model.predict(X)
        except Exception as exc:
            logger.warning("ETA model failed, using heuristic: %s", exc)
            pred = _heuristic_resolution_hours(open_df)
    else:
        pred = _heuristic_resolution_hours(open_df)

    pred = np.clip(pred, 0.5, config.RESOLUTION_HOURS_CLIP)
    open_df["predicted_resolution_hours"] = np.round(pred, 1)
    pred_dates = pd.Timestamp.now() + pd.to_timedelta(pred, unit="h")
    open_df["predicted_resolution_date"] = pd.Series(pred_dates, index=open_df.index).dt.strftime("%Y-%m-%d %H:%M")

    by_priority: Dict[str, List[float]] = {}
    for pri in ["P1", "P2", "P3", "P4"]:
        vals = open_df.loc[open_df["priority"] == pri, "predicted_resolution_hours"].tolist()
        by_priority[pri] = vals

    by_team = (open_df.groupby("assignment_group")["predicted_resolution_hours"]
                       .agg(["count", "mean", "median"])
                       .round(2)
                       .sort_values("count", ascending=False)
                       .head(15)
                       .reset_index()
                       .to_dict(orient="records"))

    return {
        "rows": open_df[["incident_id", "title", "priority", "assignment_group",
                         "predicted_resolution_hours", "predicted_resolution_date"]],
        "by_priority": by_priority,
        "by_team": by_team,
        "summary": {
            "mean":   round(float(open_df["predicted_resolution_hours"].mean()), 2),
            "median": round(float(open_df["predicted_resolution_hours"].median()), 2),
            "p90":    round(float(open_df["predicted_resolution_hours"].quantile(0.9)), 2),
        },
    }


def _heuristic_resolution_hours(df: pd.DataFrame) -> np.ndarray:
    base = df["priority"].map({"P1": 4, "P2": 12, "P3": 48, "P4": 96}).fillna(48)
    return base.to_numpy(dtype=float)


# ---------------------------------------------------------------------------
# Panel 4 - Chronic issue detection
# ---------------------------------------------------------------------------
def panel_chronic_issues(df: pd.DataFrame, store: ModelStore) -> Dict:
    resolved = get_resolved_tickets(df)
    if len(resolved) < 20:
        return {"top_chronic_cis": [], "clusters": [],
                "treemap_data": {"labels": [], "parents": [], "values": []}}

    ci_counts = (resolved["configuration_item"].astype(str)
                 .replace({"Unknown": np.nan, "nan": np.nan, "": np.nan})
                 .dropna().value_counts().head(config.TOP_N_CHRONIC_CIS))

    top_chronic = []
    for ci, count in ci_counts.items():
        sample_titles = resolved.loc[resolved["configuration_item"] == ci, "title"].head(3).tolist()
        cats = resolved.loc[resolved["configuration_item"] == ci, "category"].value_counts().head(2)
        top_chronic.append({
            "ci": ci, "incident_count": int(count),
            "primary_category": cats.index[0] if len(cats) else "Unknown",
            "sample_titles": sample_titles,
            "suggested_problem_title": _suggest_problem_title(ci, sample_titles),
        })

    clusters = []
    vec = store.vectorizer()
    if vec is not None and len(resolved) >= 30:
        try:
            X = vec.transform(resolved["text"].fillna(""))
            n_clusters = min(config.KMEANS_N_CLUSTERS, max(2, len(resolved) // 20))
            km = MiniBatchKMeans(n_clusters=n_clusters, random_state=config.RANDOM_STATE,
                                 batch_size=256, n_init=3)
            labels = km.fit_predict(X)
            resolved = resolved.copy()
            resolved["cluster"] = labels
            for cid in range(n_clusters):
                rows = resolved[resolved["cluster"] == cid]
                if len(rows) < 3:
                    continue
                clusters.append({
                    "cluster_id": int(cid),
                    "size": int(len(rows)),
                    "top_terms": _top_cluster_terms(km, vec, cid, top_n=5),
                    "sample_titles": rows["title"].head(3).tolist(),
                    "primary_category": rows["category"].mode().iloc[0]
                                        if not rows["category"].mode().empty else "Unknown",
                })
            clusters.sort(key=lambda c: c["size"], reverse=True)
            clusters = clusters[:10]
        except Exception as exc:
            logger.warning("Clustering failed: %s", exc)

    treemap_labels, treemap_parents, treemap_values = ["All Chronic CIs"], [""], [int(ci_counts.sum())]
    seen_categories = set()
    for entry in top_chronic:
        cat = entry["primary_category"]
        if cat not in seen_categories:
            seen_categories.add(cat)
            treemap_labels.append(cat)
            treemap_parents.append("All Chronic CIs")
            treemap_values.append(sum(e["incident_count"] for e in top_chronic if e["primary_category"] == cat))
        treemap_labels.append(entry["ci"])
        treemap_parents.append(cat)
        treemap_values.append(entry["incident_count"])

    return {
        "top_chronic_cis": top_chronic,
        "clusters": clusters,
        "treemap_data": {"labels": treemap_labels, "parents": treemap_parents, "values": treemap_values},
    }


def _top_cluster_terms(km, vec, cid: int, top_n: int = 5) -> List[str]:
    centers = km.cluster_centers_[cid]
    feature_names = np.array(vec.get_feature_names_out())
    return feature_names[centers.argsort()[::-1][:top_n]].tolist()


def _suggest_problem_title(ci: str, sample_titles: List[str]) -> str:
    if not sample_titles:
        return f"Recurring incidents on {ci}"
    common_words = re.findall(r"\b[a-zA-Z]{4,}\b", " ".join(sample_titles).lower())
    if not common_words:
        return f"Recurring incidents on {ci}"
    keyword = max(set(common_words), key=common_words.count)
    return f"Investigate recurring '{keyword}' issues on {ci}"


# ---------------------------------------------------------------------------
# Panel 5 - Team workload & routing analysis
# ---------------------------------------------------------------------------
def panel_routing(df: pd.DataFrame, store: ModelStore) -> Dict:
    vec = store.vectorizer()
    model = store.route_model()

    out = df[["incident_id", "title", "category", "assignment_group",
              "priority", "state", "reassignment_count"]].copy()
    out["suggested_assignment_group"] = out["assignment_group"]
    out["routing_mismatch"] = False
    out["routing_confidence"] = 0.0

    if vec is not None and model is not None:
        try:
            X_text = vec.transform(df["text"].fillna(""))
            X = _augment_with_encoders(X_text, df, store.column_encoders(), ("category", "priority"))
            pred = model.predict(X)
            proba = _safe_predict_proba(model, X)
            conf = proba.max(axis=1) if proba is not None else np.full(len(df), 0.5)
            out["suggested_assignment_group"] = pred
            out["routing_confidence"] = np.round(conf, 3)
            out["routing_mismatch"] = (
                (out["suggested_assignment_group"].astype(str) != out["assignment_group"].astype(str))
                & (out["routing_confidence"] >= 0.5)
            )
        except Exception as exc:
            logger.warning("Routing model failed: %s", exc)

    open_df = get_open_tickets(df)
    workload = (open_df.groupby(["assignment_group", "priority"]).size()
                .unstack(fill_value=0).reset_index())
    workload_total = open_df["assignment_group"].value_counts().head(15)
    reassign = (df.groupby("assignment_group")["reassignment_count"]
                  .agg(["mean", "sum", "count"]).round(2)
                  .sort_values("mean", ascending=False).head(10).reset_index())

    return {
        "rows": out,
        "mis_routed": out[out["routing_mismatch"]].head(20).to_dict(orient="records"),
        "mis_routed_count": int(out["routing_mismatch"].sum()),
        "workload_chart": {
            "teams": workload_total.index.tolist(),
            "counts": workload_total.values.tolist(),
            "by_priority": workload.to_dict(orient="records"),
        },
        "high_reassignment_teams": reassign.to_dict(orient="records"),
    }


# ---------------------------------------------------------------------------
# Panel 6 - Auto-resolve candidates
# ---------------------------------------------------------------------------
def panel_auto_resolve(df: pd.DataFrame) -> Dict:
    candidates = df[df["priority"].isin(["P3", "P4"])].copy()
    if candidates.empty:
        return {"rows": candidates, "by_type": {}, "total_count": 0,
                "estimated_hours_saved": 0}

    text_lower = candidates["text"].astype(str).str.lower()
    candidates["auto_resolve_candidate"] = False
    candidates["auto_resolve_type"] = ""
    candidates["confidence_score"] = 0.0

    for type_name, patterns in config.AUTO_RESOLVE_PATTERNS.items():
        regex = re.compile("|".join(re.escape(p) for p in patterns))
        match = text_lower.str.contains(regex, na=False)
        new_match = match & (~candidates["auto_resolve_candidate"])
        candidates.loc[new_match, "auto_resolve_candidate"] = True
        candidates.loc[new_match, "auto_resolve_type"] = type_name
        candidates.loc[new_match, "confidence_score"] = 0.85

    eligible = candidates[candidates["auto_resolve_candidate"]]
    by_type = eligible["auto_resolve_type"].value_counts().to_dict()
    hours_saved = round(len(eligible) * 25 / 60, 1)

    return {
        "rows": eligible[["incident_id", "title", "priority",
                           "auto_resolve_type", "confidence_score"]],
        "by_type": by_type,
        "total_count": int(len(eligible)),
        "estimated_hours_saved": hours_saved,
        "candidate_pct": round(float(len(eligible)) / max(len(candidates), 1) * 100, 1),
    }


# ---------------------------------------------------------------------------
# Master pipeline
# ---------------------------------------------------------------------------
def run_batch_inference(input_path, store: Optional[ModelStore] = None) -> Dict:
    """
    Top-level: load file -> preprocess (with training-time fills) ->
    run all 6 panels -> return JSON-friendly dict.
    """
    store = store or ModelStore()

    # Load persisted training-time null fills so the preprocess step uses
    # stable values rather than computing them from this (possibly small) batch.
    fills = store.null_fills()   # None if not yet trained

    raw = load_export(input_path)
    df = preprocess(raw, fill_values=fills)

    results: Dict[str, Any] = {
        "summary": {
            "total_rows": int(len(df)),
            "open_count": int(len(get_open_tickets(df))),
            "resolved_count": int(len(get_resolved_tickets(df))),
            "categories": int(df["category"].nunique()),
            "teams": int(df["assignment_group"].nunique()),
            "models_trained": store.is_trained(),
        },
        "panel1_categorisation":  panel_categorisation(df, store),
        "panel2_sla_risk":        panel_sla_risk(df, store),
        "panel3_resolution_time": panel_resolution_time(df, store),
        "panel4_chronic_issues":  panel_chronic_issues(df, store),
        "panel5_routing":         panel_routing(df, store),
        "panel6_auto_resolve":    panel_auto_resolve(df),
        "_full_df": df,
    }
    return results


def predict_template_fields(description: str, scope: str = "Individual",
                            environment: str = "Production",
                            caller: str = "Unknown",
                            store: Optional[ModelStore] = None) -> Dict:
    """
    Predict ServiceNow fields for a free-text incident description.
    Uses persisted training-time null fills for consistent single-record inference.
    """
    store = store or ModelStore()
    vec = store.vectorizer()

    result = {
        "short_description": (description.split("\n")[0])[:80],
        "description": description,
        "category": "General",
        "subcategory": "",
        "priority": "P3",
        "impact": "3 - Low",
        "urgency": "3 - Low",
        "assignment_group": "Service Desk",
        "environment": environment,
        "estimated_resolution_hours": 24.0,
        "confidence": {"category": 0.0, "priority": 0.0, "assignment_group": 0.0},
        "fallback_mode": vec is None,
    }

    if vec is None:
        return result

    X_text = vec.transform([description])

    cat_model = store.cat_model()
    if cat_model is not None:
        try:
            result["category"] = str(cat_model.predict(X_text)[0])
            proba = _safe_predict_proba(cat_model, X_text)
            if proba is not None:
                result["confidence"]["category"] = round(float(proba.max()), 3)
        except Exception as exc:
            logger.warning("Cat predict failed: %s", exc)

    pri_model = store.pri_model()
    if pri_model is not None:
        try:
            df_temp = pd.DataFrame([{"category": result["category"],
                                     "assignment_group": "Service Desk"}])
            X = _augment_with_encoders(X_text, df_temp, store.column_encoders(),
                                       ("assignment_group", "category"))
            result["priority"] = str(pri_model.predict(X)[0])
            proba = _safe_predict_proba(pri_model, X)
            if proba is not None:
                result["confidence"]["priority"] = round(float(proba.max()), 3)
        except Exception as exc:
            logger.warning("Priority predict failed: %s", exc)

    route_model = store.route_model()
    if route_model is not None:
        try:
            df_temp = pd.DataFrame([{"category": result["category"],
                                     "priority": result["priority"]}])
            X = _augment_with_encoders(X_text, df_temp, store.column_encoders(),
                                       ("category", "priority"))
            result["assignment_group"] = str(route_model.predict(X)[0])
            proba = _safe_predict_proba(route_model, X)
            if proba is not None:
                result["confidence"]["assignment_group"] = round(float(proba.max()), 3)
        except Exception as exc:
            logger.warning("Routing predict failed: %s", exc)

    eta_model = store.eta_model()
    if eta_model is not None:
        try:
            df_temp = pd.DataFrame([{"priority": result["priority"],
                                     "category": result["category"]}])
            X = _augment_with_encoders(X_text, df_temp, store.res_column_encoders(),
                                       ("priority", "category"))
            result["estimated_resolution_hours"] = round(float(eta_model.predict(X)[0]), 1)
        except Exception as exc:
            logger.warning("ETA predict failed: %s", exc)

    impact_map = {"Individual": "3 - Low", "Team": "2 - Medium",
                  "Department": "2 - Medium", "Company-wide": "1 - High"}
    urgency_map = {"P1": "1 - High", "P2": "2 - Medium", "P3": "3 - Low", "P4": "3 - Low"}
    result["impact"] = impact_map.get(scope, "3 - Low")
    result["urgency"] = urgency_map.get(result["priority"], "3 - Low")

    return result
