"""
Data cleaning, normalisation, and feature engineering for ServiceNow exports.

Designed to be tolerant of:
    * Lots of nulls (your spec calls these out explicitly)
    * Inconsistent state / priority spellings
    * Mixed timestamp formats
    * UTF-8, Latin-1, Windows-1252 encodings on input

Null-fill persistence
---------------------
Training-time null fills (mode for categoricals, median for numerics) are
now persisted to disk via ``save_null_fills`` / ``load_null_fills`` so that
inference always uses the values computed on the training corpus rather than
recomputing them from each (potentially small or skewed) inference batch.

Usage during training::

    fills = compute_null_fills(df_train)
    save_null_fills(fills, config.MODELS_DIR / "null_fills.json")

Usage at inference::

    fills = load_null_fills(config.MODELS_DIR / "null_fills.json")
    df = preprocess(raw_df, fill_values=fills)   # None -> compute from batch
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from .. import config
from .column_mapper import map_columns

# Null-fill persistence helpers live in embedding_utils so they can be
# shared with change_preprocess and problem_preprocess without circular
# imports.
from .embedding_utils import save_null_fills, load_null_fills  # noqa: F401 (re-exported)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# File loading
# ---------------------------------------------------------------------------
def load_export(path: str | Path) -> pd.DataFrame:
    """
    Load a ServiceNow export from CSV or Excel, auto-detecting encoding.
    """
    path = Path(path)
    suffix = path.suffix.lower()

    if suffix in (".xlsx", ".xls"):
        # openpyxl handles xlsx; xlrd or openpyxl for legacy xls.
        try:
            return pd.read_excel(path, dtype=str)
        except Exception as exc:
            logger.error("Excel read failed: %s", exc)
            raise

    if suffix in (".csv", ".txt"):
        for enc in ("utf-8", "utf-8-sig", "latin-1", "cp1252"):
            try:
                return pd.read_csv(path, dtype=str, encoding=enc,
                                   low_memory=False, on_bad_lines="warn")
            except UnicodeDecodeError:
                continue
        # Last resort
        return pd.read_csv(path, dtype=str, encoding="latin-1",
                           low_memory=False, on_bad_lines="warn")

    raise ValueError(f"Unsupported file type: {suffix}")


# ---------------------------------------------------------------------------
# Normalisation
# ---------------------------------------------------------------------------
_PRIORITY_PATTERNS = [
    (re.compile(r"\b1\b|critical|p\s*1", re.I), "P1"),
    (re.compile(r"\b2\b|high|p\s*2", re.I), "P2"),
    (re.compile(r"\b3\b|moderate|medium|p\s*3", re.I), "P3"),
    (re.compile(r"\b4\b|low|p\s*4", re.I), "P4"),
]


def normalise_priority(val) -> str:
    """Map any priority spelling/numbering to canonical P1..P4."""
    if val is None or (isinstance(val, float) and np.isnan(val)):
        return "P3"
    s = str(val).strip()
    if not s:
        return "P3"
    for pat, label in _PRIORITY_PATTERNS:
        if pat.search(s):
            return label
    return "P3"


_STATE_MAP = {
    "new": "Open", "open": "Open", "active": "Open", "assigned": "Open",
    "in progress": "In Progress", "work in progress": "In Progress",
    "in-progress": "In Progress", "wip": "In Progress",
    "on hold": "On Hold", "pending": "On Hold", "awaiting": "On Hold",
    "resolved": "Resolved", "complete": "Resolved", "completed": "Resolved",
    "closed": "Closed", "cancelled": "Closed", "canceled": "Closed",
}


def normalise_state(val) -> str:
    if val is None:
        return "Unknown"
    s = str(val).strip().lower()
    return _STATE_MAP.get(s, str(val).strip().title() or "Unknown")


def _map_unique(series: pd.Series, func):
    """
    Apply ``func`` once per *unique* value, then map the results back over the
    whole Series.  For low-cardinality columns (priority, state) this is
    dramatically faster than ``series.apply(func)`` - a handful of calls
    instead of one per row - while producing identical output.  NaN entries
    are filled with ``func(None)`` to match the per-element behaviour.
    """
    mapping = {v: func(v) for v in series.dropna().unique()}
    return series.map(mapping).fillna(func(None))


def parse_timestamp(val) -> Optional[pd.Timestamp]:
    """Parse a single timestamp, returning NaT on failure."""
    if val is None or pd.isna(val) or str(val).strip() == "":
        return pd.NaT
    return pd.to_datetime(val, errors="coerce", utc=False)


# ---------------------------------------------------------------------------
# Null handling
# ---------------------------------------------------------------------------
TEXT_COLUMNS = ["title", "description_full", "work_notes", "close_notes",
                "comments", "actions_taken", "root_cause_notes"]
CATEGORICAL_COLUMNS = ["category", "subcategory", "priority", "assignment_group",
                       "assigned_to", "configuration_item", "environment",
                       "company", "location", "contact_type", "vendor"]
NUMERIC_COLUMNS = ["reassignment_count", "reopen_count", "time_worked",
                   "business_duration", "calendar_duration", "clients_impacted"]
BOOLEAN_COLUMNS = ["made_sla", "major_incident_flag"]
TIMESTAMP_COLUMNS = ["opened_timestamp", "resolved_timestamp", "closed_timestamp",
                     "updated_timestamp", "due_date", "sla_due"]


_BOOL_TRUE_TOKENS = {"true", "1", "yes", "y", "t", "met"}


def _to_bool(val) -> bool:
    if val is None or pd.isna(val):
        return False
    s = str(val).strip().lower()
    return s in _BOOL_TRUE_TOKENS


def _to_bool_series(s: pd.Series) -> pd.Series:
    """Vectorised equivalent of ``s.apply(_to_bool)``."""
    return s.astype(str).str.strip().str.lower().isin(_BOOL_TRUE_TOKENS)


def _to_numeric(val) -> float:
    if val is None or pd.isna(val):
        return np.nan
    try:
        return float(str(val).replace(",", "").strip())
    except (ValueError, TypeError):
        return np.nan


def _to_numeric_series(s: pd.Series) -> pd.Series:
    """
    Vectorised equivalent of ``s.apply(_to_numeric)`` - strips thousands
    separators and whitespace, then coerces to float, yielding NaN on failure.
    """
    cleaned = s.astype(str).str.replace(",", "", regex=False).str.strip()
    return pd.to_numeric(cleaned, errors="coerce")


def compute_null_fills(df: pd.DataFrame) -> dict:
    """
    Compute null-fill values (mode for categoricals, median for numerics)
    from ``df``. Pass the result to ``handle_nulls(..., fill_values=...)`` so
    that both the training and test splits are filled using statistics
    derived from the training rows only.  This avoids the target-leakage
    that occurs when the mode / median is computed on the full pre-split
    dataset and a test row's null coincidentally matches the training mode.

    Calling ``handle_nulls(df)`` without ``fill_values`` still works - it
    computes fills internally from ``df``, which is correct for inference
    (no train/test split exists there).

    Persist the returned dict via ``save_null_fills`` so inference uses the
    same values even when the inference batch is small or skewed.
    """
    fills: dict = {}
    for col in CATEGORICAL_COLUMNS:
        if col not in df.columns:
            continue
        s = df[col].astype("object")
        mode = s.mode(dropna=True)
        fills[col] = mode.iloc[0] if (not mode.empty and s.notna().any()) else "Unknown"
    for col in NUMERIC_COLUMNS:
        if col not in df.columns:
            continue
        coerced = _to_numeric_series(df[col])
        med = coerced.median()
        fills[col] = float(med) if pd.notna(med) else 0.0
    return fills


def handle_nulls(df: pd.DataFrame,
                 fill_values: Optional[dict] = None) -> pd.DataFrame:
    """
    Apply column-type-aware null handling.

    Parameters
    ----------
    df :
        The dataframe to clean (a copy is returned; the original is
        not mutated).
    fill_values :
        Dict produced by ``compute_null_fills(df_train)``.  When supplied
        the categorical mode and numeric median come from the training
        rows only, avoiding test-set leakage.  When None (the default),
        fills are computed from ``df`` itself - which is correct for the
        inference path where there is no train/test split.
    """
    df = df.copy()

    # Compute fills from this frame if the caller didn't supply them
    if fill_values is None:
        fill_values = compute_null_fills(df)

    # Text -> empty string
    for col in TEXT_COLUMNS:
        if col in df.columns:
            df[col] = df[col].fillna("").astype(str)

    # Categorical -> mode (training-only) else 'Unknown'
    for col in CATEGORICAL_COLUMNS:
        if col not in df.columns:
            continue
        fill_val = fill_values.get(col, "Unknown")
        s = df[col].astype("object")
        df[col] = s.fillna(fill_val).astype(str).replace({"": "Unknown", "nan": "Unknown"})

    # Numeric -> coerce then fill with training median (or 0)
    for col in NUMERIC_COLUMNS:
        if col not in df.columns:
            continue
        df[col] = _to_numeric_series(df[col]).fillna(fill_values.get(col, 0.0))

    # Boolean -> coerce then fill False
    for col in BOOLEAN_COLUMNS:
        if col in df.columns:
            df[col] = _to_bool_series(df[col])

    # Timestamps -> parse column-at-a-time, leave NaT (downstream code knows).
    # Vectorised pd.to_datetime is orders of magnitude faster than parsing one
    # cell at a time; unparseable values still coerce to NaT.
    for col in TIMESTAMP_COLUMNS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")

    return df


# ---------------------------------------------------------------------------
# Feature engineering
# ---------------------------------------------------------------------------
def add_text_features(df: pd.DataFrame) -> pd.DataFrame:
    """Concatenate short + long description into a single 'text' column."""
    df = df.copy()
    title = df.get("title", pd.Series([""] * len(df))).fillna("").astype(str)
    desc = df.get("description_full", pd.Series([""] * len(df))).fillna("").astype(str)
    df["text"] = (title + " " + desc).str.strip().str.replace(r"\s+", " ", regex=True)
    df["description_length"] = df["text"].str.len()
    return df


def add_temporal_features(df: pd.DataFrame, ts_col: str = "opened_timestamp") -> pd.DataFrame:
    """Hour, day-of-week, weekend flag, month - all from the opened timestamp."""
    df = df.copy()
    if ts_col not in df.columns:
        df["hour_created"] = 0
        df["day_of_week"] = 0
        df["is_weekend"] = False
        df["month"] = 1
        return df

    ts = pd.to_datetime(df[ts_col], errors="coerce")
    df["hour_created"] = ts.dt.hour.fillna(0).astype(int)
    df["day_of_week"] = ts.dt.dayofweek.fillna(0).astype(int)
    df["is_weekend"] = df["day_of_week"].isin([5, 6])
    df["month"] = ts.dt.month.fillna(1).astype(int)
    return df


def add_resolution_features(df: pd.DataFrame, *, now: Optional[pd.Timestamp] = None) -> pd.DataFrame:
    """
    Compute resolution_hours for resolved/closed tickets and age_hours for all.
    Outliers in resolution_hours are clipped at config.RESOLUTION_HOURS_CLIP.
    """
    df = df.copy()
    now = now if now is not None else pd.Timestamp.now()

    opened = pd.to_datetime(df.get("opened_timestamp"), errors="coerce")
    resolved = pd.to_datetime(df.get("resolved_timestamp"), errors="coerce")
    closed = pd.to_datetime(df.get("closed_timestamp"), errors="coerce")
    end_ts = resolved.fillna(closed)

    # Resolution time (hours) - only meaningful for resolved/closed
    delta_hours = (end_ts - opened).dt.total_seconds() / 3600.0
    delta_hours = delta_hours.clip(lower=0, upper=config.RESOLUTION_HOURS_CLIP)
    df["resolution_hours"] = delta_hours

    # Age for any ticket (hours from opened to now)
    age_hours = (now - opened).dt.total_seconds() / 3600.0
    df["age_hours"] = age_hours.clip(lower=0)
    df["age_days"] = df["age_hours"] / 24.0

    # Reassignment rate
    if "reassignment_count" in df.columns:
        df["reassignment_rate"] = df["reassignment_count"] / df["age_days"].replace(0, 1)
    else:
        df["reassignment_rate"] = 0.0

    # Has-CI flag
    if "configuration_item" in df.columns:
        df["has_ci"] = df["configuration_item"].astype(str).str.lower().isin(
            ["", "unknown", "nan", "none"]
        ).map(lambda x: not x)
    else:
        df["has_ci"] = False

    return df


# ---------------------------------------------------------------------------
# Filtering
# ---------------------------------------------------------------------------
def filter_system_tickets(df: pd.DataFrame) -> pd.DataFrame:
    """Drop rows raised by automation/system accounts."""
    if "caller" not in df.columns:
        return df
    # Single case-insensitive substring regex across all system-caller tokens,
    # vectorised over the whole column instead of a per-row Python lambda.
    pattern = "|".join(re.escape(s) for s in config.SYSTEM_CALLERS)
    is_system = df["caller"].astype(str).str.contains(
        pattern, case=False, na=False, regex=True
    )
    return df[~is_system].reset_index(drop=True)


def get_resolved_tickets(df: pd.DataFrame) -> pd.DataFrame:
    """Subset to tickets that are Resolved or Closed."""
    if "state" not in df.columns:
        return df.iloc[0:0]
    mask = df["state"].astype(str).str.lower().isin(config.RESOLVED_STATES)
    return df[mask].reset_index(drop=True)


def get_open_tickets(df: pd.DataFrame) -> pd.DataFrame:
    """Subset to tickets that are still open."""
    if "state" not in df.columns:
        return df.iloc[0:0]
    mask = df["state"].astype(str).str.lower().isin(config.OPEN_STATES)
    return df[mask].reset_index(drop=True)


# ---------------------------------------------------------------------------
# Top-level pipeline
# ---------------------------------------------------------------------------
def preprocess(raw_df: pd.DataFrame, *, drop_invalid: bool = True,
               fill_values: Optional[dict] = None) -> pd.DataFrame:
    """
    Run the full preprocessing pipeline:
        map columns -> normalise -> handle nulls -> feature engineer.

    Parameters
    ----------
    fill_values :
        Dict from ``compute_null_fills(df_train)``.  Supply this during
        training to ensure null fills are derived from training rows
        only, avoiding leakage into the test split.  Leave None for
        inference when no persisted fills are available (fills are then
        computed from the batch itself).

        Best practice for inference: load the persisted training-time
        fills via ``load_null_fills(config.MODELS_DIR / "null_fills.json")``
        and pass them here so single-record inference uses stable fills.
    """
    df = map_columns(raw_df)

    # Normalise key categorical columns BEFORE null handling so the mode is sane.
    # normalise_priority defaults blanks to "P3", which is the right behaviour
    # for analysis/inference but would fabricate a P3 majority if such rows were
    # used to *train* the priority model.  Record whether each row actually had
    # a populated priority so train_priority can exclude the defaulted ones.
    if "priority" in df.columns:
        raw_priority = df["priority"].astype(str).str.strip().str.lower()
        df["priority_present"] = (
            df["priority"].notna() & ~raw_priority.isin({"", "nan", "none"})
        )
        df["priority"] = _map_unique(df["priority"], normalise_priority)
    if "state" in df.columns:
        df["state"] = _map_unique(df["state"], normalise_state)

    df = handle_nulls(df, fill_values=fill_values)
    df = add_text_features(df)
    df = add_temporal_features(df)
    df = add_resolution_features(df)

    if drop_invalid:
        # Critical-field drop: incident_id must be present, title must be non-empty
        before = len(df)
        df = df[df["incident_id"].astype(str).str.strip() != ""]
        df = df[df["incident_id"].astype(str).str.lower() != "nan"]
        df = df[df["title"].str.strip() != ""]
        df = df.drop_duplicates(subset=["incident_id"], keep="last").reset_index(drop=True)
        dropped = before - len(df)
        if dropped:
            logger.info("Dropped %d invalid/duplicate rows during preprocessing", dropped)

    return df
