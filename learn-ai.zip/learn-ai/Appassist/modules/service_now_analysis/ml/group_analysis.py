"""
Assignment Group analysis for the Summary Report.

Answers, per assignment group: what kinds of request does this team
actually receive, how many of each, how long each kind takes them to
resolve, and how does the group's overall workload and resolution
performance compare with the rest of the estate.

HOW A TICKET GETS ITS TYPE
--------------------------
Two stages, and every family reports which one named it:

  1. `request_taxonomy` - an ordered rule list over the ticket's short
     description, category and subcategory. Deterministic, so "Password
     Reset / Account Unlock" means the same thing in every group and in
     every upload, which is what makes the numbers comparable at all.

  2. TF-IDF + MiniBatchKMeans over whatever stage 1 did not claim, via
     `workload_themes.analyse_themes` - the same clustering the Batch
     Analysis chronic-issue panel and the individual workload page use.
     This names the families the rules do not know about instead of
     dumping them in "Other". Clustering runs across the whole residual,
     not per group, so an emergent family is called the same thing
     wherever it appears.

Anything neither stage could name stays `Unclassified` and is counted as
such. It is never folded into a real family.

HONESTY RULES
-------------
* The assignment group is read from the RAW export, not from the
  preprocessed frame. `ml.preprocess.handle_nulls` fills a blank
  categorical with that column's mode - correct for model input, but it
  would silently move every unassigned ticket into whichever group is
  largest and then report that group's resolution time as if it had
  worked them. A ticket the export left unassigned is counted under
  "(No assignment group)" and `group_source` says where the labels came
  from. This is the same rule `workload_capture` follows.

* Resolution statistics are computed over RESOLVED tickets only. A group
  sitting on a hundred untouched tickets must not post a fast average
  because the unresolved ones carry no duration; the open count and the
  ageing backlog are reported next to the average so the two are read
  together.

* Resolution hours inherit `config.RESOLUTION_HOURS_CLIP` (30 days) from
  preprocessing - a ticket that took longer is counted at the clip. The
  payload states the clip so a reader knows the tail is bounded.

* SLA percentages are reported only when the export carried an SLA field
  or the timestamps needed to recompute one; otherwise the value is None
  and the UI shows "not available" rather than 0%.

* Median and p90 are reported next to the mean. A support queue's
  resolution time is heavily right-skewed, and a mean on its own is the
  single easiest number on this page to misread.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .. import config
from . import request_taxonomy
from .column_mapper import map_columns

logger = logging.getLogger(__name__)


# Label for tickets the export left without an assignment group.
NO_GROUP = "(No assignment group)"

# Groups below this many tickets are still reported, but their averages
# carry a "thin sample" flag - a two-ticket group with a 30-minute mean
# is not a performance result.
MIN_TICKETS_FOR_STABLE_STATS = 10

# Cap on the emergent families the clustering stage may name. Keeps the
# type axis readable; the rules already cover the bulk of the volume.
MAX_MODEL_FAMILIES = 6

# Tickets older than this, still open, are the ageing backlog.
BACKLOG_AGE_DAYS = 30

# Values that mean "the export said nothing" once stringified.
#
# "unknown" is in the set because it is not a value any export writes - it
# is the literal string ml.preprocess.handle_nulls substitutes for a blank
# categorical. Reading it as a real team name would invent a group called
# Unknown and attribute unassigned work to it.
_BLANK_TOKENS = {"", "nan", "none", "null", "nat", "unknown"}


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
def _clean(value) -> Optional[str]:
    """Trimmed string, or None when the export said nothing."""
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass                      # arrays / odd types: fall through
    text = str(value).strip()
    if text.lower() in _BLANK_TOKENS:
        return None
    return text


def _round(value, digits: int = 1) -> Optional[float]:
    """A JSON-safe rounded float, or None for NaN / inf / missing."""
    if value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not np.isfinite(number):
        return None
    return round(number, digits)


def _pct(part: float, whole: float, digits: int = 1) -> Optional[float]:
    if not whole:
        return None
    return _round(part * 100.0 / whole, digits)


def _iso(ts) -> str:
    """Format a timestamp as YYYY-MM-DD HH:MM, or '' if missing."""
    try:
        if ts is None or pd.isna(ts):
            return ""
        return pd.Timestamp(ts).strftime("%Y-%m-%d %H:%M")
    except (TypeError, ValueError, OverflowError):
        return ""


def _duration_stats(hours: pd.Series) -> Dict[str, Any]:
    """
    Descriptive statistics over the resolution hours of ONE slice.

    `hours` may contain NaN for tickets that are not resolved; those are
    dropped here rather than treated as zero, which is why `resolved` is
    reported alongside every average.
    """
    resolved = pd.to_numeric(hours, errors="coerce").dropna()
    resolved = resolved[resolved >= 0]
    if resolved.empty:
        return {
            "resolved": 0, "avg_hours": None, "median_hours": None,
            "p90_hours": None, "min_hours": None, "max_hours": None,
            "total_hours": None, "avg_days": None,
        }
    return {
        "resolved":     int(resolved.size),
        "avg_hours":    _round(resolved.mean()),
        "median_hours": _round(resolved.median()),
        "p90_hours":    _round(resolved.quantile(0.90)),
        "min_hours":    _round(resolved.min()),
        "max_hours":    _round(resolved.max()),
        "total_hours":  _round(resolved.sum()),
        "avg_days":     _round(resolved.mean() / 24.0, 2),
    }


def _state_series(df: pd.DataFrame) -> pd.Series:
    """
    The ticket state, lowercased.

    `incident_state` is preferred where the export carried it, because it
    is the finer-grained field - but ml.column_mapper creates the column
    unconditionally and leaves it all-None when the export has no such
    field, and unlike the other categoricals nothing later fills it. Taking
    it blindly would make every ticket's state "none", and with it every
    open count and ageing backlog on this panel zero. So it is used only
    when it actually holds values.
    """
    for column in ("incident_state", "state"):
        if column not in df.columns:
            continue
        # _clean, not astype(str): on pandas 3 an all-None object column
        # stringifies to NaN rather than "None", which would slip past a
        # blank check done on the stringified values.
        values = df[column].map(_clean)
        if values.notna().any():
            return values.fillna("").astype(str).str.lower()
    return pd.Series([""] * len(df), index=df.index, dtype="object")


def _sla_basis(df: pd.DataFrame) -> Optional[str]:
    """
    What, if anything, the SLA percentages are computed from.

    Mirrors the decision `SummaryProcessor._augment` already made when it
    built `SLA Met Calculated`, so the panel never reports 0% SLA for an
    export that simply never carried the field.
    """
    if "made_sla" in df.columns and df["made_sla"].notna().any():
        return "made_sla field in the export"
    if {"opened_timestamp", "resolved_timestamp"}.issubset(df.columns):
        return "recomputed from opened / resolved against the priority SLA target"
    return None


# ---------------------------------------------------------------------------
# Stage 0 - honest assignment groups and categories
# ---------------------------------------------------------------------------
# Fields that MUST come from the raw export rather than the preprocessed
# frame, because ml.preprocess.handle_nulls fills a blank categorical with
# the column mode:
#
#   assignment_group  - a mode fill would move every unassigned ticket into
#                       the largest team and credit it with their handling.
#   category /        - these feed the type classifier. A mode fill would
#   subcategory         stamp the most common category's vocabulary onto
#                       every uncategorised ticket, which is exactly the
#                       text the rules match on.
_RAW_FIELDS = ("assignment_group", "category", "subcategory")


def _raw_fields(df: pd.DataFrame,
                raw_df: Optional[pd.DataFrame]) -> Tuple[Dict[str, pd.Series], str]:
    """
    The blank-preserving values of `_RAW_FIELDS`, aligned to `df`'s index.

    Returns (fields, source) where source is:
        "export"        - taken from the raw upload, blanks preserved
        "preprocessed"  - the raw frame was unusable, so the null-filled
                          columns were used; the caller warns about it
        "missing"       - no assignment group anywhere in the upload
    """
    blank = pd.Series([None] * len(df), index=df.index, dtype="object")

    if raw_df is not None and len(raw_df) and "incident_id" in df.columns:
        try:
            mapped = map_columns(raw_df)
            # Last occurrence wins, matching the `keep="last"`
            # de-duplication ml.preprocess applied to build `df`.
            keys = mapped["incident_id"].astype(str).str.strip()
            ids = df["incident_id"].astype(str).str.strip()
            fields = {}
            for name in _RAW_FIELDS:
                values = mapped[name].map(_clean)
                # The trailing _clean matters: Series.map yields NaN - a
                # float - for an id the lookup does not hold, and a float
                # NaN is not the None the consumers of these Series expect
                # (workload_themes in particular does `(value or "")
                # .strip()`, which a NaN would break). Re-cleaning turns
                # every flavour of "nothing" back into None.
                fields[name] = ids.map(dict(zip(keys, values))).map(_clean)
            if fields["assignment_group"].notna().any():
                return fields, "export"
        except Exception as exc:        # never fail a report over context
            logger.warning("Could not read %s from the raw export (%s); "
                           "falling back to the preprocessed columns",
                           ", ".join(_RAW_FIELDS), exc)

    fallback = {name: (df[name].map(_clean) if name in df.columns
                       else blank.copy())
                for name in _RAW_FIELDS}
    if fallback["assignment_group"].notna().any():
        return fallback, "preprocessed"
    return fallback, "missing"


# ---------------------------------------------------------------------------
# Stage 1 + 2 - request families
# ---------------------------------------------------------------------------
def _model_families(df: pd.DataFrame, categories: pd.Series,
                    residual_index: pd.Index, kind: str) -> Dict[str, str]:
    """
    Cluster the tickets no rule claimed and name the families found.

    Returns {incident_id: family label} for the residual tickets that
    landed in a named cluster. Tickets the clustering could not place
    keep None and end up Unclassified.

    Delegates to `workload_themes.analyse_themes` so there is exactly one
    definition of "a theme" in this module: the same TF-IDF + k-means with
    the same stopword list, minimum theme size and labelling rule that the
    individual workload page renders.
    """
    if residual_index.empty:
        return {}
    try:
        from .. import workload_themes
    except Exception as exc:
        logger.info("Ticket clustering unavailable (%s) - unmatched tickets "
                    "stay Unclassified", exc)
        return {}

    residual = df.loc[residual_index]
    residual_categories = categories.loc[residual_index]
    ticket_type = "service_request" if kind == "sr" else "incident"
    tickets = [{
        "number":    str(row.get("incident_id") or ""),
        "type":      ticket_type,
        "title":     _clean(row.get("title")) or "",
        "priority":  _clean(row.get("priority")),
        "category":  _clean(category),
        "opened_at": _iso(row.get("opened_timestamp")) or None,
    } for (_, row), category in zip(residual.iterrows(), residual_categories)]

    try:
        result = workload_themes.analyse_themes(tickets,
                                                max_themes=MAX_MODEL_FAMILIES)
    except Exception as exc:
        logger.warning("Residual ticket clustering failed: %s", exc)
        return {}

    if result.get("method") == "none":
        return {}

    labels: Dict[str, str] = {}
    for theme in result.get("themes") or []:
        label = str(theme.get("label") or "").strip()
        if not label:
            continue
        for number in theme.get("numbers") or []:
            if number:
                labels[str(number)] = label
    return labels


def _classify(df: pd.DataFrame, categories: pd.Series,
              subcategories: pd.Series,
              kind: str) -> Tuple[pd.Series, pd.Series, Dict[str, Any]]:
    """
    Request family and label source per row, plus a description of how the
    labelling went.

    `categories` / `subcategories` are the blank-preserving values from
    `_raw_fields`, NOT the preprocessed columns - see the note there for
    why classifying on a mode-filled category would be self-fulfilling.

    Returns (families, sources, meta).
    """
    text_frame = pd.DataFrame({
        "title": (df["title"] if "title" in df.columns
                  else pd.Series([""] * len(df), index=df.index)),
        "category": categories,
        "subcategory": subcategories,
    }, index=df.index)

    families = request_taxonomy.classify_frame(text_frame)
    sources = pd.Series([request_taxonomy.SOURCE_RULE] * len(df),
                        index=df.index, dtype="object")

    residual_index = families[families.isna()].index
    model_labels = _model_families(df, categories, residual_index, kind)

    if model_labels and "incident_id" in df.columns:
        numbers = df.loc[residual_index, "incident_id"].astype(str).str.strip()
        mapped = numbers.map(model_labels)
        matched = mapped[mapped.notna()].index
        families.loc[matched] = mapped.loc[matched]
        sources.loc[matched] = request_taxonomy.SOURCE_MODEL

    unclassified = families.isna()
    families = families.fillna(request_taxonomy.UNCLASSIFIED)
    sources[unclassified] = "none"

    rule_count = int((sources == request_taxonomy.SOURCE_RULE).sum())
    model_count = int((sources == request_taxonomy.SOURCE_MODEL).sum())
    unknown_count = int(unclassified.sum())
    total = len(df)

    if model_count:
        method_label = (
            "Types come from two stages. %d of %d tickets (%s%%) matched the "
            "fixed request-family rules, so those names mean the same thing "
            "in every group and every upload. The remaining tickets were "
            "clustered with TF-IDF + k-means over their short descriptions - "
            "the same technique as the chronic-issue panel - which named %d "
            "more; those labels are discovered from this upload and can "
            "change as the mix of work changes."
            % (rule_count, total, _pct(rule_count, total), model_count)
        )
    elif unknown_count:
        # There WAS a residual and clustering named none of it - either it
        # was too thin to cluster or the model stage failed (logged). Say
        # what is true either way rather than implying nothing was left.
        method_label = (
            "Types come from the fixed request-family rules, which matched "
            "%d of %d tickets (%s%%). The remaining %d could not be grouped "
            "into an additional named family and are counted as "
            "Unclassified."
            % (rule_count, total, _pct(rule_count, total), unknown_count)
        )
    else:
        method_label = (
            "Types come from the fixed request-family rules, which matched "
            "every one of the %d tickets in this upload." % total
        )

    meta = {
        "method_label":     method_label,
        "rule_labelled":    rule_count,
        "model_labelled":   model_count,
        "unclassified":     unknown_count,
        "unclassified_pct": _pct(unknown_count, total),
        "rules":            request_taxonomy.rule_documentation(),
    }
    return families, sources, meta


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------
def _family_sort_key(label: str) -> int:
    """Rule families keep their declared order; model families follow;
    Unclassified always sorts last."""
    if label == request_taxonomy.UNCLASSIFIED:
        return len(request_taxonomy.FAMILIES) + 1000
    try:
        return request_taxonomy.FAMILIES.index(label)
    except ValueError:
        return len(request_taxonomy.FAMILIES)


def _type_rows(slice_df: pd.DataFrame, group_total: int,
               has_sla: bool) -> List[Dict[str, Any]]:
    """The per-request-type breakdown within one assignment group."""
    rows: List[Dict[str, Any]] = []
    for family, chunk in slice_df.groupby("__family", sort=False):
        stats = _duration_stats(chunk["__hours"])
        open_count = int(chunk["__is_open"].sum())
        sla_met = None
        if has_sla and stats["resolved"]:
            resolved_chunk = chunk[chunk["__hours"].notna()]
            sla_met = _pct(int(resolved_chunk["__sla_met"].sum()),
                           len(resolved_chunk))
        opened = sorted(t for t in chunk["__opened"] if t)
        rows.append({
            "type":             str(family),
            "label_source":     str(chunk["__source"].mode().iat[0])
                                if not chunk["__source"].mode().empty else "none",
            "count":            int(len(chunk)),
            "share_pct":        _pct(len(chunk), group_total),
            "open":             open_count,
            "unresolved":       int(len(chunk) - stats["resolved"]),
            "sla_met_pct":      sla_met,
            "first_seen":       opened[0] if opened else "",
            "last_seen":        opened[-1] if opened else "",
            "samples":          [s for s in chunk["__title"].head(3).tolist() if s],
            **stats,
        })
    rows.sort(key=lambda r: (-r["count"], _family_sort_key(r["type"])))
    return rows


def _group_row(name: str, chunk: pd.DataFrame, grand_total: int,
               has_sla: bool) -> Dict[str, Any]:
    """One assignment group's workload and resolution performance."""
    total = int(len(chunk))
    stats = _duration_stats(chunk["__hours"])
    open_count = int(chunk["__is_open"].sum())
    backlog = int((chunk["__is_open"] &
                   (chunk["__age_days"] > BACKLOG_AGE_DAYS)).sum())

    sla_met = None
    if has_sla and stats["resolved"]:
        resolved_chunk = chunk[chunk["__hours"].notna()]
        sla_met = _pct(int(resolved_chunk["__sla_met"].sum()),
                       len(resolved_chunk))

    reopened = int((pd.to_numeric(chunk["__reopens"], errors="coerce")
                    .fillna(0) > 0).sum())

    priorities = (chunk["__priority"].replace("", "Not set")
                  .value_counts().to_dict())

    types = _type_rows(chunk, total, has_sla)
    named = [t for t in types if t["type"] != request_taxonomy.UNCLASSIFIED]

    return {
        "group":                name,
        "total":                total,
        "share_pct":            _pct(total, grand_total),
        "resolved":             stats["resolved"],
        "resolved_pct":         _pct(stats["resolved"], total),
        "open":                 open_count,
        "open_pct":             _pct(open_count, total),
        "ageing_backlog":       backlog,
        "avg_resolution_hours": stats["avg_hours"],
        "median_resolution_hours": stats["median_hours"],
        "p90_resolution_hours": stats["p90_hours"],
        "max_resolution_hours": stats["max_hours"],
        "avg_resolution_days":  stats["avg_days"],
        "total_resolution_hours": stats["total_hours"],
        "sla_met_pct":          sla_met,
        "reopened":             reopened,
        "reopen_rate":          _pct(reopened, total),
        "priority_counts":      {str(k): int(v) for k, v in priorities.items()},
        "distinct_types":       len(named),
        "top_type":             named[0]["type"] if named else
                                request_taxonomy.UNCLASSIFIED,
        "unclassified":         sum(t["count"] for t in types
                                    if t["type"] == request_taxonomy.UNCLASSIFIED),
        "thin_sample":          total < MIN_TICKETS_FOR_STABLE_STATS,
        "request_types":        types,
    }


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def compute_group_analysis(df: pd.DataFrame,
                           raw_df: Optional[pd.DataFrame] = None,
                           kind: str = "batch") -> Dict[str, Any]:
    """
    Assignment-group-wise workload and resolution analysis.

    Parameters
    ----------
    df :
        The AUGMENTED frame `SummaryProcessor._augment` produced - it
        carries `Calculated Resolution Time` and `SLA Met Calculated`
        alongside the preprocessed feature columns, so this panel and the
        rest of the report can never disagree about how long a ticket took
        or whether it met its SLA.
    raw_df :
        The same upload BEFORE preprocessing. Used for the assignment
        group so a blank stays blank instead of inheriting the column
        mode. Optional, but the panel says so when it is missing.
    kind :
        "batch" (incidents) or "sr" (service requests) - only affects the
        ticket type handed to the clustering stage.
    """
    empty = {
        "available": False, "groups": [], "chart_data": [],
        "table_data": [], "type_table_data": [], "incident_rows": [],
        "totals": {}, "classification": {},
    }
    try:
        if df is None or not len(df):
            empty["reason"] = "No tickets in this upload."
            return empty

        fields, group_source = _raw_fields(df, raw_df)
        if group_source == "missing":
            empty["reason"] = (
                "This export carries no assignment group column, so the "
                "work cannot be attributed to a team. Re-export with "
                "'Assignment group' included.")
            empty["group_source"] = group_source
            return empty

        groups = fields["assignment_group"].fillna(NO_GROUP)
        families, sources, classification = _classify(
            df, fields["category"], fields["subcategory"], kind)
        has_sla = _sla_basis(df) is not None

        work = pd.DataFrame(index=df.index)
        work["__group"] = groups.astype(str)
        work["__family"] = families.astype(str)
        work["__source"] = sources.astype(str)
        work["__hours"] = (pd.to_numeric(df.get("Calculated Resolution Time"),
                                         errors="coerce") / 3600.0
                           if "Calculated Resolution Time" in df.columns
                           else np.nan)
        work["__sla_met"] = (df["SLA Met Calculated"].astype(bool)
                             if "SLA Met Calculated" in df.columns else False)
        work["__is_open"] = _state_series(df).isin(config.OPEN_STATES)
        work["__age_days"] = (pd.to_numeric(df.get("age_days"), errors="coerce")
                              .fillna(0) if "age_days" in df.columns else 0.0)
        work["__reopens"] = (df["reopen_count"] if "reopen_count" in df.columns
                             else 0)
        work["__priority"] = (df["priority"].astype(str).str.upper()
                              if "priority" in df.columns else "")
        work["__title"] = (df["title"].astype(str).str.slice(0, 120)
                           if "title" in df.columns else "")
        work["__opened"] = ([_iso(v) for v in df["opened_timestamp"]]
                            if "opened_timestamp" in df.columns else "")
        work["__id"] = (df["incident_id"].astype(str)
                        if "incident_id" in df.columns else "")
        work["__state"] = _state_series(df).str.title()

        grand_total = int(len(work))
        rows = [_group_row(str(name), chunk, grand_total, has_sla)
                for name, chunk in work.groupby("__group", sort=False)]
        rows.sort(key=lambda r: (-r["total"], r["group"]))

        estate = _duration_stats(work["__hours"])
        estate_sla = None
        if has_sla and estate["resolved"]:
            resolved_all = work[work["__hours"].notna()]
            estate_sla = _pct(int(resolved_all["__sla_met"].sum()),
                              len(resolved_all))

        totals = {
            "groups":               len(rows),
            "tickets":              grand_total,
            "resolved":             estate["resolved"],
            "open":                 int(work["__is_open"].sum()),
            "ageing_backlog":       int((work["__is_open"] &
                                         (work["__age_days"] > BACKLOG_AGE_DAYS)).sum()),
            "avg_resolution_hours": estate["avg_hours"],
            "median_resolution_hours": estate["median_hours"],
            "p90_resolution_hours": estate["p90_hours"],
            "sla_met_pct":          estate_sla,
            "unassigned":           int((work["__group"] == NO_GROUP).sum()),
        }

        return {
            "available":      True,
            "group_source":   group_source,
            "group_source_label": _GROUP_SOURCE_LABELS.get(group_source, ""),
            "sla_basis":      _sla_basis(df),
            "resolution_clip_hours": config.RESOLUTION_HOURS_CLIP,
            "backlog_age_days": BACKLOG_AGE_DAYS,
            "thin_sample_below": MIN_TICKETS_FOR_STABLE_STATS,
            "classification": classification,
            "groups":         rows,
            "totals":         totals,
            "chart_data":     _chart_data(rows),
            "table_data":     _table_data(rows),
            "type_table_data": _type_table_data(rows),
            "incident_rows":  _incident_rows(work),
        }
    except Exception:
        logger.exception("Error computing assignment-group analysis")
        empty["reason"] = ("The assignment-group analysis could not be "
                           "computed - see the application log.")
        return empty


_GROUP_SOURCE_LABELS = {
    "export": ("Assignment groups read from the uploaded export. Tickets "
               "the export left unassigned are counted under "
               "\"%s\" rather than being attributed to a team." % NO_GROUP),
    "preprocessed": ("The raw upload could not be re-read, so assignment "
                     "groups come from the preprocessed frame, where a "
                     "blank group was filled with the most common group. "
                     "Treat the largest group's volume as an upper bound."),
}


# ---------------------------------------------------------------------------
# Presentation projections
# ---------------------------------------------------------------------------
def _chart_data(rows: List[Dict[str, Any]], limit: int = 12) -> List[Dict]:
    """Top groups by volume - the workload-vs-speed chart on the panel."""
    return [{
        "group":                r["group"],
        "count":                r["total"],
        "open":                 r["open"],
        "resolved":             r["resolved"],
        "avg_resolution_hours": r["avg_resolution_hours"],
        "median_resolution_hours": r["median_resolution_hours"],
        "sla_met_pct":          r["sla_met_pct"],
        "thin_sample":          r["thin_sample"],
    } for r in rows[:limit]]


def _table_data(rows: List[Dict[str, Any]]) -> List[Dict]:
    """Flat per-group table - rendered on screen and written to Excel."""
    return [{
        "Assignment Group":     r["group"],
        "Tickets":              r["total"],
        "Share %":              r["share_pct"],
        "Resolved":             r["resolved"],
        "Open":                 r["open"],
        "Ageing Backlog (>%dd)" % BACKLOG_AGE_DAYS: r["ageing_backlog"],
        "Avg Resolution (h)":   r["avg_resolution_hours"],
        "Median Resolution (h)": r["median_resolution_hours"],
        "P90 Resolution (h)":   r["p90_resolution_hours"],
        "SLA Met %":            r["sla_met_pct"],
        "Reopen Rate %":        r["reopen_rate"],
        "Request Types":        r["distinct_types"],
        "Top Request Type":     r["top_type"],
    } for r in rows]


def _type_table_data(rows: List[Dict[str, Any]]) -> List[Dict]:
    """Flat group x request-type table - the answer to 'what does this
    team handle, how much of it, and how long does each kind take'."""
    out: List[Dict] = []
    for group in rows:
        for t in group["request_types"]:
            out.append({
                "Assignment Group":   group["group"],
                "Request Type":       t["type"],
                "Labelled By":        t["label_source"],
                "Tickets":            t["count"],
                "Share of Group %":   t["share_pct"],
                "Resolved":           t["resolved"],
                "Open":               t["open"],
                "Avg Resolution (h)": t["avg_hours"],
                "Median Resolution (h)": t["median_hours"],
                "P90 Resolution (h)": t["p90_hours"],
                "Longest (h)":        t["max_hours"],
                "Total Effort (h)":   t["total_hours"],
                "SLA Met %":          t["sla_met_pct"],
                "First Seen":         t["first_seen"],
                "Last Seen":          t["last_seen"],
            })
    return out


def _incident_rows(work: pd.DataFrame) -> List[Dict]:
    """Per-ticket detail behind the panel, for the Chart / Table toggle."""
    return [{
        "incident_id":      str(r["__id"]),
        "assignment_group": str(r["__group"]),
        "request_type":     str(r["__family"]),
        "labelled_by":      str(r["__source"]),
        "priority":         str(r["__priority"]),
        "state":            str(r["__state"]),
        "opened_at":        str(r["__opened"]),
        "resolution_hours": _round(r["__hours"], 2),
        "sla_met":          bool(r["__sla_met"]),
    } for _, r in work.iterrows()]
