"""
Map raw ServiceNow Change Request export columns to the standardised
internal feature names used by the CR template-generator pipeline.

Mirrors the structure of column_mapper.py (incident).
Missing source columns become None columns rather than raising,
so downstream code can decide how to handle them.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Tuple

import pandas as pd

logger = logging.getLogger(__name__)


# Internal feature name -> list of candidate ServiceNow column names
# (first match wins). Mirrors incident column_mapper pattern.
COLUMN_MAPPING: Dict[str, List[str]] = {
    "change_id":           ["number"],
    "title":               ["short_description"],
    "description_full":    ["description"],
    "type":                ["type"],
    "category":            ["u_tenant_category", "category"],
    "subcategory":         ["u_tenant_subcategory", "subcategory"],
    "priority":            ["priority"],
    "risk":                ["risk"],
    "risk_value":          ["risk_value"],
    "risk_impact_analysis":["risk_impact_analysis"],
    "impact":              ["impact"],
    "urgency":             ["urgency"],
    "state":               ["state"],
    "phase":               ["phase"],
    "phase_state":         ["phase_state"],
    "approval":            ["approval"],
    "assignment_group":    ["assignment_group"],
    "assigned_to":         ["assigned_to"],
    "requested_by":        ["requested_by"],
    "tech_reviewer_group": ["u_technical_reviewer_group"],
    "created_by":          ["sys_created_by", "opened_by"],
    "configuration_item":  ["cmdb_ci"],
    "business_service":    ["business_service"],
    "service_offering":    ["service_offering"],
    "company":             ["company"],
    "location":            ["location"],
    "environment":         ["u_environment"],
    "opened_timestamp":    ["opened_at", "sys_created_on", "u_reported_date"],
    "created_timestamp":   ["sys_created_on"],
    "start_timestamp":     ["start_date", "expected_start"],
    "end_timestamp":       ["end_date"],
    "work_start_timestamp":["work_start"],
    "work_end_timestamp":  ["work_end"],
    "closed_timestamp":    ["closed_at"],
    "updated_timestamp":   ["sys_updated_on"],
    "closed_by":           ["closed_by"],
    "close_code":          ["u_tenant_close_code"],
    "close_notes":         ["close_notes"],
    "implementation_plan": ["implementation_plan"],
    "backout_plan":        ["backout_plan"],
    "test_plan":           ["test_plan"],
    "change_plan":         ["change_plan"],
    "justification":       ["justification"],
    "cab_required":        ["cab_required"],
    "cab_recommendation":  ["cab_recommendation"],
    "cab_date":            ["cab_date", "cab_date_time"],
    "made_sla":            ["made_sla", "x_caukp_slc_sla_met"],
    "business_duration":   ["business_duration"],
    "calendar_duration":   ["calendar_duration"],
    "actual_outage":       ["u_actual_outage"],
    "reassignment_count":  ["reassignment_count"],
    "chg_model":           ["chg_model"],
    "std_change_template": ["std_change_producer_version"],
    "outside_maint_sched": ["outside_maintenance_schedule"],
    "supporting_incident": ["u_supporting_incident"],
    "scope":               ["scope"],
}

# Minimum columns the CR pipeline needs to do anything meaningful.
REQUIRED_RAW_COLUMNS = {"number", "short_description", "type", "state"}

# Strongly recommended for a high-quality template generator.
RECOMMENDED_RAW_COLUMNS = {
    "u_tenant_category", "u_tenant_subcategory", "priority", "risk",
    "assignment_group", "cmdb_ci", "business_service",
    "start_date", "end_date", "close_notes",
    "implementation_plan", "backout_plan", "test_plan",
    "risk_impact_analysis", "description",
}


def map_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Project raw CR export down to internal feature names."""
    mapped = pd.DataFrame(index=df.index)
    for feature, candidates in COLUMN_MAPPING.items():
        source_col = next((c for c in candidates if c in df.columns), None)
        if source_col is not None:
            mapped[feature] = df[source_col]
        else:
            mapped[feature] = None

    if "change_id" in mapped.columns:
        mapped["change_id"] = mapped["change_id"].astype(str)

    logger.info("Mapped %d raw CR columns -> %d internal features",
                len(df.columns), len(mapped.columns))
    return mapped


def validate_columns(df: pd.DataFrame) -> Tuple[bool, List[str], List[str]]:
    cols = set(df.columns)
    missing_required = sorted(REQUIRED_RAW_COLUMNS - cols)
    missing_recommended = sorted(RECOMMENDED_RAW_COLUMNS - cols)
    return (len(missing_required) == 0, missing_required, missing_recommended)


def column_coverage_report(df: pd.DataFrame) -> Dict[str, Dict]:
    report: Dict[str, Dict] = {}
    for feature, candidates in COLUMN_MAPPING.items():
        source = next((c for c in candidates if c in df.columns), None)
        if source is None:
            report[feature] = {"source": None, "present": False, "populated_pct": 0.0}
        else:
            populated = df[source].notna().sum()
            pct = (populated / max(len(df), 1)) * 100
            report[feature] = {
                "source": source,
                "present": True,
                "populated_pct": round(float(pct), 1),
            }
    return report
