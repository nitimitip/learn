"""
Request-family taxonomy for the Assignment Group analysis.

WHY A RULE LIST AND NOT A MODEL
-------------------------------
The Assignment Group panel exists to answer "what kind of work does this
team actually do, and how fast do they close each kind?". That question is
only answerable if the SAME work is called the SAME thing in every upload
and in every group - otherwise a group cannot be compared against itself
last month, nor against the group next to it.

Unsupervised labels cannot promise that. The clustering used elsewhere in
this module (workload_themes.py, ml/predict.py chronic issues) names a
group from its own centroid's strongest terms, so the same work can surface
as "Password / Reset" in one upload and "Reset / Locked / Account" in the
next. Excellent for discovery; useless as a stable reporting axis.

So the taxonomy below is deterministic: an ordered list of regular
expressions over the ticket text, first match wins. It covers the request
families an application-support desk sees, including the ones the report
was asked for by name (user creation, password reset, data requests, job
failures). Anything no rule claims is handed to the ML stage in
group_analysis.py, which clusters the residual and names the emergent
families - so the rules carry the known work and the model discovers the
rest, and each row says which of the two produced its label.

RULE ORDER IS THE SPECIFICITY ORDER
-----------------------------------
Rules are evaluated top to bottom, so the narrow reading of an ambiguous
ticket must come first. "Reset password for new joiner" is a password
reset, not a user creation; "unable to run the payroll job" is a job
failure, not a generic application error. Each entry below sits where it
does for that reason - moving one changes how tickets are counted.

The matched text is the short description plus the category and
subcategory the export stated, so a desk that categorises its tickets well
is classified from its own vocabulary rather than from prose alone.
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple

import pandas as pd

# Label used when no rule matches and the ML stage could not name the
# ticket either. Never merged into a real family - an honest "we could not
# tell" bucket is worth more than a wrong label on a performance report.
UNCLASSIFIED = "Unclassified"

# Label source markers, reported per family so a reader knows whether the
# name came from a rule or from the model.
SOURCE_RULE = "rule"
SOURCE_MODEL = "model"


# (family, pattern) - evaluated in order, first match wins.
#
# Patterns are matched case-insensitively against the normalised ticket
# text. \b guards keep short tokens ("id", "ad", "job") from matching
# inside longer words.
_RULES: List[Tuple[str, str]] = [
    # --- Identity and access -------------------------------------------
    # Password / unlock first: it is the single highest-volume family on
    # most desks and its wording overlaps heavily with account creation
    # ("new user cannot log in") and access requests ("no access - locked
    # out"). Claiming it first keeps those two families clean.
    ("Password Reset / Account Unlock",
     r"\b(password|passwd|pwd|passphrase)\b.*\b(reset|resett?ing|change|"
     r"expired|forgot|forgotten|unlock|renew)\b"
     r"|\b(reset|forgot|forgotten|expired|change)\b.*\b(password|passwd|pwd)\b"
     r"|\b(account|user|id|login)\b.*\block(ed)?\b"
     r"|\bunlock\b.*\b(account|user|id|login)\b"
     r"|\bmfa\b.*\b(reset|re-?enrol|re-?register)\b"
     r"|\b(token|otp)\b.*\b(reset|resync|re-?sync)\b"),

    ("User / Account Creation",
     r"\b(create|creation|new|setup|set up|provision|provisioning|onboard|"
     r"onboarding|add)\b.*\b(user|users|account|accounts|login|userid|"
     r"user id|profile|mailbox|joiner)\b"
     r"|\b(user|account)\b.*\b(creation|provisioning|onboarding)\b"
     r"|\bnew joiner\b|\bnew hire\b"),

    ("User / Account Deletion",
     r"\b(delete|deletion|remove|removal|disable|deactivate|deactivation|"
     r"terminate|termination|offboard|offboarding|revoke)\b.*"
     r"\b(user|users|account|accounts|login|userid|user id|access|leaver)\b"
     r"|\bleaver\b|\bexit(ing)? employee\b"),

    ("Access / Permission Request",
     r"\b(access|permission|permissions|entitlement|entitlements|"
     r"authorisation|authorization|privilege|privileges|role|roles|"
     r"group membership|rights)\b"
     r"|\b(grant|revoke|extend)\b.*\b(rights|role|access)\b"
     r"|\b(shared\s+(drive|folder|mailbox))\b"
     r"|\b(ad|active directory)\s+group\b"),

    # --- Batch and data -------------------------------------------------
    # Job failures before the generic error family: an abended job is
    # reported with the same "failed / error" vocabulary as an application
    # defect, but it is a different kind of work with a different fix.
    ("Job / Batch Failure",
     r"\b(job|jobs|batch|schedule[rd]?|cron|autosys|control-?m|"
     r"workflow|dag|etl|interface|feed)\b.*"
     r"\b(fail|failed|failure|failing|abend|abended|abort|aborted|error|"
     r"errored|stuck|hung|hanging|not running|did not run|didn'?t run|"
     r"long running|delayed)\b"
     r"|\b(abend|abended)\b"
     r"|\b(job|batch)\s+(restart|rerun|re-?run|resubmit)\b"),

    ("Data Request / Data Correction",
     r"\b(data|record|records|table|tables|database|dataset|entry|entries)\b.*"
     r"\b(fix|correct|correction|update|updating|amend|amendment|change|"
     r"missing|mismatch|incorrect|wrong|duplicate|duplicated|discrepanc|"
     r"clean\s?up|cleanse|load|reload|refresh|purge|delete)\b"
     r"|\b(data)\b.*\b(request|extract|pull|fix|issue|quality)\b"
     r"|\b(update|correct|amend|delete)\b.*\b(record|records|row|rows|"
     r"table|database)\b"
     r"|\bdata\s+(entry|migration|load|patch|correction|quality)\b"
     r"|\b(sql|db)\s+(update|script|patch)\b"),

    ("Report / Extract Request",
     r"\b(report|reports|reporting|dashboard|extract|extraction|export|"
     r"download)\b.*"
     r"\b(request|required|need|provide|generate|run|share|send|create|"
     r"fail|failed|error|incorrect|blank|missing|not available)\b"
     r"|\b(provide|send|share|generate|run)\b.*\b(report|extract|export|"
     r"dashboard|statement)\b"
     r"|\b(ad-?hoc)\b.*\b(report|extract|data)\b"),

    # --- Application and platform ---------------------------------------
    ("Performance / Availability",
     r"\b(slow|slowness|performance|latency|lagging|timeout|timing out|"
     r"timed out|hang|hanging|freeze|freezing|unresponsive)\b"
     r"|\b(down|outage|unavailable|inaccessible|not accessible|"
     r"cannot access|can'?t access|unable to access)\b"
     r"|\b(high)\b.*\b(cpu|memory|utilisation|utilization|load)\b"
     r"|\b(disk|space|storage|filesystem|file system|tablespace)\b.*"
     r"\b(full|low|threshold|alert|90|95)\b"),

    ("Connectivity / Network",
     r"\b(network|vpn|wifi|wi-?fi|lan|wan|firewall|port|dns|proxy|"
     r"connectivity|connection)\b"
     r"|\b(unable|cannot|can'?t|failed)\b.*\bconnect\b"
     r"|\b(citrix|rdp|remote desktop)\b"
     r"|\b(certificate|ssl|tls)\b.*\b(expire[d]?|error|invalid|renew)\b"),

    ("Software Install / Upgrade",
     r"\b(install|installation|installing|reinstall|re-?install|uninstall|"
     r"upgrade|upgrading|patch|patching|deploy|deployment|licence|license|"
     r"licensing)\b.*"
     r"\b(software|application|app|tool|client|agent|version|package|"
     r"plugin|add-?in|driver)\b"
     r"|\b(software|application|licence|license)\b.*"
     r"\b(request|install|upgrade|renewal)\b"
     r"|\b(install|upgrade)\b.*\b(on|for)\b.*\b(laptop|desktop|server|pc)\b"),

    ("Hardware / Device",
     r"\b(laptop|desktop|pc|monitor|keyboard|mouse|printer|printing|"
     r"scanner|headset|docking station|dock|mobile|phone|handset|token|"
     r"smartcard|smart card|usb|hard ?disk|hdd|ssd)\b"
     r"|\bhardware\b|\bperipheral\b|\basset (request|replacement)\b"),

    ("Configuration / Setup Change",
     r"\b(config|configure|configuration|setting|settings|parameter|"
     r"parameters|mapping|threshold|rule|template)\b.*"
     r"\b(change|update|add|remove|modify|enable|disable|set|new|correct)\b"
     r"|\b(enable|disable)\b.*\b(feature|flag|option|service|module)\b"
     r"|\b(dl|distribution list|mailing list)\b.*\b(add|remove|update)\b"),

    # Deliberately last of the substantive rules: "error", "issue" and
    # "not working" appear in tickets from every family above, so this one
    # only ever sees what none of them claimed.
    ("Application Error / Defect",
     r"\b(error|exception|bug|defect|crash|crashed|crashing|failure|"
     r"failed|failing)\b"
     r"|\b(not working|doesn'?t work|does not work|unable to|cannot|"
     r"can'?t)\b"
     r"|\b(issue|problem|incorrect|wrong|unexpected)\b"),
]

# Compiled once at import. re.IGNORECASE only - the text is normalised to
# single-spaced lowercase before matching, so no DOTALL/MULTILINE needed.
_COMPILED: List[Tuple[str, re.Pattern]] = [
    (family, re.compile(pattern, re.IGNORECASE)) for family, pattern in _RULES
]

# Ordered family names, for stable display ordering when two families tie
# on volume. UNCLASSIFIED always sorts last.
FAMILIES: List[str] = [family for family, _ in _RULES]

_WHITESPACE = re.compile(r"\s+")

# Values that mean "the export said nothing" once stringified. Same token
# set as workload_capture._BLANK_TOKENS - a blank must never become text
# the classifier can match on.
_BLANK_TOKENS = {"", "nan", "none", "null", "nat", "unknown"}


def _clean_fragment(value) -> str:
    """One text fragment, or '' when the export said nothing."""
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass                      # arrays / odd types: fall through
    text = _WHITESPACE.sub(" ", str(value).strip())
    return "" if text.lower() in _BLANK_TOKENS else text


def build_text(title, category=None, subcategory=None) -> str:
    """
    The text a ticket is classified from: its short description plus the
    category and subcategory the export stated.

    Category is included deliberately. A desk that already files tickets
    under "Access Management" or "Batch Support" is telling us the family
    in its own vocabulary, and that statement is usually more reliable
    than prose typed by the caller.
    """
    parts = [_clean_fragment(title),
             _clean_fragment(category),
             _clean_fragment(subcategory)]
    return " ".join(p for p in parts if p)


def classify(text: str) -> Optional[str]:
    """
    The request family for one ticket text, or None when no rule matched.

    None is a real answer, not a failure: the caller passes those tickets
    to the clustering stage rather than forcing them into the nearest
    family.
    """
    if not text:
        return None
    for family, pattern in _COMPILED:
        if pattern.search(text):
            return family
    return None


def classify_frame(df: pd.DataFrame,
                   title_col: str = "title",
                   category_col: str = "category",
                   subcategory_col: str = "subcategory") -> pd.Series:
    """
    Classify a whole frame, returning a Series aligned to its index whose
    values are a family name or None.

    Distinct texts are classified once and the result mapped back, so a
    250k-row export costs one regex pass per DISTINCT description rather
    than per row - the same trick ml.preprocess._map_unique uses.
    """
    if df is None or not len(df):
        return pd.Series(dtype="object")

    def _col(name):
        if name in df.columns:
            return df[name]
        return pd.Series([None] * len(df), index=df.index)

    texts = [build_text(t, c, s) for t, c, s in
             zip(_col(title_col), _col(category_col), _col(subcategory_col))]
    series = pd.Series(texts, index=df.index, dtype="object")

    cache: Dict[str, Optional[str]] = {}
    for text in series.unique():
        cache[text] = classify(text)
    return series.map(cache)


def rule_documentation() -> List[Dict[str, str]]:
    """
    The rule list as display rows, so the UI can show exactly what each
    family means without the reader having to open this file. Rendered
    under the panel's "How are types identified?" tab.
    """
    return [{"family": family, "pattern": pattern, "order": index + 1}
            for index, (family, pattern) in enumerate(_RULES)]
