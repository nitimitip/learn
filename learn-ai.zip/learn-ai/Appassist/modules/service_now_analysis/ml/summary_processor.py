"""
Statistical (non-ML) summary report processor.

Adapted from the standalone donor `data_processor.py` shipped by another
team. Key differences from the original:

  * Consumes the *already-preprocessed* dataframe produced by
    ml.preprocess.preprocess() rather than the raw upload, so it shares
    one upload pass with the ML pipeline. The standardised column names
    are used (`opened_timestamp`, `resolved_timestamp`, `made_sla`,
    `reopen_count`, `incident_state`, `priority`, `configuration_item`
    ...) instead of the donor's display names (`Created`, `Resolved`,
    `SLA Met`, `Incident state` ...).

  * Date conversion, column normalisation, priority derivation and
    duplicate filtering are already done by the ML preprocess step, so
    those passes are removed here.

  * Quality score, SLA trends, resolution times, priority trends,
    reopened and long-open analyses are preserved verbatim from the
    donor (formulae unchanged) so the reports remain comparable to the
    original tool.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from ..utils.sla_calculator import SLACalculator

logger = logging.getLogger(__name__)


# Open-state strings the donor treats as "still open"
OPEN_STATES = {"new", "open", "in progress", "on hold", "active",
               "work in progress", "pending", "assigned"}

# SLA target hours by priority - same as the donor (P3=72h business, P4=48h)
SLA_TARGET_HOURS = {"P1": 4, "P2": 8, "P3": 72, "P4": 48}


class SummaryProcessor:
    """
    Computes the statistical analyses for the Summary Report from a
    preprocessed ServiceNow dataframe: the eight the donor tool shipped,
    plus the assignment-group analysis (ml/group_analysis.py), which
    `compute_summary` attaches from the same augmented frame.
    """

    def __init__(self):
        self.sla_calculator = SLACalculator()

    # ---------------------------------------------------------------
    # Data adaptation
    # ---------------------------------------------------------------
    def _augment(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Add the donor-style columns the original `_calculate_sla_metrics`
        produced, but reading from the standardised feature names that
        ml.preprocess already created.

        This isolates the rename/derive logic in one place so the rest
        of the methods stay close to the donor source for easier
        comparison.
        """
        out = df.copy()

        # SLA target hours per row, derived from priority
        if "priority" in out.columns:
            out["SLA Target (hours)"] = out["priority"].astype(str).str.upper().map(
                lambda p: SLA_TARGET_HOURS.get(p, 24)
            )

        # Resolution time in seconds (donor stored as 'Calculated Resolution Time')
        # ml.preprocess already gives us `resolution_hours`; convert.
        if "resolution_hours" in out.columns:
            out["Calculated Resolution Time"] = (
                pd.to_numeric(out["resolution_hours"], errors="coerce") * 3600
            )
        elif "opened_timestamp" in out.columns and "resolved_timestamp" in out.columns:
            delta = (out["resolved_timestamp"] - out["opened_timestamp"]).dt.total_seconds()
            out["Calculated Resolution Time"] = delta

        # Was SLA met? Prefer the explicit `made_sla` field if the
        # export carries it; fall back to a recomputation against the
        # business-hours SLA calculator otherwise.
        if "made_sla" in out.columns and out["made_sla"].notna().any():
            out["SLA Met Calculated"] = (
                out["made_sla"].astype(str).str.lower()
                .isin(["true", "1", "yes", "y", "met"])
            )
        elif {"opened_timestamp", "resolved_timestamp"}.issubset(out.columns):
            def _row_met(row):
                if pd.isna(row["opened_timestamp"]) or pd.isna(row["resolved_timestamp"]):
                    return False
                return self.sla_calculator.is_sla_met(
                    row["opened_timestamp"], row["resolved_timestamp"],
                    row.get("SLA Target (hours)", 24),
                )
            out["SLA Met Calculated"] = out.apply(_row_met, axis=1)
        else:
            out["SLA Met Calculated"] = False

        # Reopen count, ensuring numeric
        if "reopen_count" in out.columns:
            out["reopen_count"] = pd.to_numeric(out["reopen_count"], errors="coerce").fillna(0)
        else:
            out["reopen_count"] = 0

        return out

    # ---------------------------------------------------------------
    # Proxy satisfaction scoring (replaces hardcoded feedback_score=70)
    # ---------------------------------------------------------------
    def _compute_proxy_satisfaction(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Derives a satisfaction-proxy score (0-100) from four operational
        signals that correlate with user-perceived service quality.

        Each signal is optional: if the required column is absent the signal
        is simply skipped and the remaining signals are re-weighted to 100 %,
        so the method never raises and never returns a stale constant.

        Signals and their nominal weights
        ----------------------------------
        1. First-call resolution  (35 %) - % of closed tickets with
           reopen_count == 0.  Closed = any state NOT in OPEN_STATES.

        2. P1/P2 within SLA       (30 %) - % of high-priority tickets
           where SLA Met Calculated is True.

        3. Work-notes density     (20 %) - average character length of the
           ``work_notes`` field; very short notes indicate poor communication.

        4. Escalation / reassign  (15 %) - % of tickets with
           reassignment_count > 1 (or non-zero ``escalation`` flag when
           reassignment_count is not present in the export).

        Returns
        -------
        {"score": float, "breakdown": {metric_name: value, ...}}
        The breakdown dict is injected into the quality-score metrics so the
        UI can surface the individual signals.
        """
        total = len(df)
        if total == 0:
            return {"score": 70.0, "breakdown": {}}

        weighted_scores: List[tuple[float, float]] = []   # (score_0_100, weight)
        breakdown: Dict[str, Any] = {}

        # 1. First-call resolution
        if "reopen_count" in df.columns:
            state_col = (
                "incident_state" if "incident_state" in df.columns
                else "state" if "state" in df.columns
                else None
            )
            if state_col:
                closed = df[~df[state_col].astype(str).str.lower().isin(OPEN_STATES)]
            else:
                closed = df  # no state column -> treat all as closed

            n_closed = len(closed)
            fcr_pct = (
                (closed["reopen_count"] == 0).sum() / n_closed * 100
                if n_closed else 100.0
            )
            fcr_score = (
                100 if fcr_pct >= 90 else
                 80 if fcr_pct >= 80 else
                 60 if fcr_pct >= 70 else
                 30
            )
            weighted_scores.append((fcr_score, 35.0))
            breakdown["fcr_pct"] = round(fcr_pct, 1)

        # 2. P1/P2 tickets resolved within SLA
        if "SLA Met Calculated" in df.columns and "priority" in df.columns:
            p12 = df[df["priority"].astype(str).str.upper().isin(["P1", "P2"])]
            n_p12 = len(p12)
            p12_sla_pct = (
                p12["SLA Met Calculated"].sum() / n_p12 * 100
                if n_p12 else 100.0
            )
            p12_score = (
                100 if p12_sla_pct >= 90 else
                 80 if p12_sla_pct >= 75 else
                 60 if p12_sla_pct >= 60 else
                 30
            )
            weighted_scores.append((p12_score, 30.0))
            breakdown["p1_p2_sla_pct"] = round(p12_sla_pct, 1)

        # 3. Work-notes density
        if "work_notes" in df.columns:
            avg_len = (
                df["work_notes"]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.len()
                .mean()
            )
            notes_score = (
                100 if avg_len >= 300 else
                 80 if avg_len >= 150 else
                 60 if avg_len >=  50 else
                 30
            )
            weighted_scores.append((notes_score, 20.0))
            breakdown["avg_work_notes_length"] = round(avg_len, 1)

        # 4. Escalation / reassignment rate
        #   Prefer reassignment_count (not always exported); fall back to
        #   the escalation flag which IS a standard ServiceNow field.
        if "reassignment_count" in df.columns:
            high = (
                pd.to_numeric(df["reassignment_count"], errors="coerce")
                .fillna(0) > 1
            ).sum()
            esc_rate = high / total * 100
            label = "reassignment_rate_pct"
        elif "escalation" in df.columns:
            high = (
                pd.to_numeric(df["escalation"], errors="coerce")
                .fillna(0) > 0
            ).sum()
            esc_rate = high / total * 100
            label = "escalation_rate_pct"
        else:
            high = None

        if high is not None:
            esc_score = (
                100 if esc_rate <=  5 else
                 80 if esc_rate <= 10 else
                 60 if esc_rate <= 20 else
                 30
            )
            weighted_scores.append((esc_score, 15.0))
            breakdown[label] = round(esc_rate, 1)

        # Composite
        if not weighted_scores:
            # No proxy signals available at all - keep neutral default so
            # the caller receives a usable score without crashing.
            logger.warning(
                "_compute_proxy_satisfaction: none of the proxy columns "
                "(reopen_count, SLA Met Calculated, work_notes, "
                "reassignment_count, escalation) were present; "
                "falling back to neutral score 70."
            )
            return {"score": 70.0, "breakdown": {}}

        total_weight = sum(w for _, w in weighted_scores)
        composite = sum(s * w for s, w in weighted_scores) / total_weight
        return {"score": round(composite, 1), "breakdown": breakdown}

    # ---------------------------------------------------------------
    # The eight metrics - identical in spirit to the donor methods,
    # adapted to the new column names.
    # ---------------------------------------------------------------
    # ---------------------------------------------------------------
    # Helpers for the new "table view" toggles in the UI.
    # The eight section processors emit aggregated `table_data` for the
    # chart-equivalent view - but the new toggle in the UI also wants
    # per-incident detail with searchable / filterable rows. These
    # helpers do that conversion in one place so each section method
    # stays small.
    # ---------------------------------------------------------------
    @staticmethod
    def _safe_str(val) -> str:
        """Return '' for NaN / None / 'nan'; str(val) otherwise."""
        if val is None:
            return ""
        try:
            if pd.isna(val):
                return ""
        except (TypeError, ValueError):
            pass
        s = str(val)
        return "" if s.lower() in ("nan", "nat", "none") else s

    @staticmethod
    def _safe_iso(ts) -> str:
        """Format a timestamp as YYYY-MM-DD HH:MM, or '' if missing."""
        if ts is None:
            return ""
        try:
            if pd.isna(ts):
                return ""
            return pd.Timestamp(ts).strftime("%Y-%m-%d %H:%M")
        except (TypeError, ValueError, OverflowError):
            return ""

    def _project_incident_rows(self, df: pd.DataFrame, columns: List[str]) -> List[Dict]:
        """
        Convert the named columns into a list of dicts, one per incident,
        sanitised for JSON. Used by section processors to populate
        `incident_rows`. The first column is always the incident_id.
        """
        if "incident_id" not in df.columns or len(df) == 0:
            return []
        rows: List[Dict] = []
        for _, row in df.iterrows():
            d: Dict[str, Any] = {"incident_id": self._safe_str(row.get("incident_id"))}
            for col in columns:
                v = row.get(col)
                # Order matters - bool MUST come before int because
                # bool is a subclass of int in Python.
                if isinstance(v, (bool, np.bool_)):
                    d[col] = bool(v)
                elif isinstance(v, pd.Timestamp) or (
                    hasattr(v, "isoformat") and not isinstance(v, str)
                ):
                    d[col] = self._safe_iso(v)
                elif isinstance(v, (int, np.integer)):
                    d[col] = int(v)
                elif isinstance(v, (float, np.floating)):
                    f = float(v)
                    d[col] = None if (f != f or f in (float("inf"), float("-inf"))) else round(f, 2)
                else:
                    d[col] = self._safe_str(v)
            rows.append(d)
        return rows

    # ---------------------------------------------------------------
    # Quality-score calculation breakdown - exposed under a new tab in
    # the UI so users can see HOW each weighted contribution was
    # derived. Pure presentation: bands and weights are read straight
    # from `calculate_quality_score`; this method just expresses them
    # as human-readable rows so the UI doesn't need to reimplement the
    # logic.
    # ---------------------------------------------------------------
    def calculation_breakdown(self) -> List[Dict[str, Any]]:
        return [
            {
                "metric":  "SLA Met",
                "weight":  30,
                "formula": "% of incidents where business-hours resolution time <= "
                           "SLA target for that priority (P1=4h, P2=8h, P3=72h, P4=48h)",
                "bands": [
                    {"if": "SLA met % >= 95", "score": 100},
                    {"if": "SLA met % >= 85", "score":  80},
                    {"if": "SLA met % >= 70", "score":  60},
                    {"if": "SLA met % < 70", "score":  30},
                ],
                "source_column": "made_sla (or recomputed via SLACalculator)",
            },
            {
                "metric":  "Resolution Time",
                "weight":  20,
                "formula": "Mean resolution time across all resolved incidents, "
                           "expressed in days (= mean(resolution_hours) / 24)",
                "bands": [
                    {"if": "Avg <= 1 day",  "score": 100},
                    {"if": "Avg <= 2 days", "score":  80},
                    {"if": "Avg <= 5 days", "score":  60},
                    {"if": "Avg > 5 days", "score":  30},
                ],
                "source_column": "resolution_hours",
            },
            {
                "metric":  "Reopen Rate",
                "weight":  15,
                "formula": "% of incidents with reopen_count > 0",
                "bands": [
                    {"if": "<= 2 %",  "score": 100},
                    {"if": "<= 5 %",  "score":  80},
                    {"if": "<= 10 %", "score":  60},
                    {"if": "> 10 %", "score":  30},
                ],
                "source_column": "reopen_count",
            },
            {
                "metric":  "Incident Backlog",
                "weight":  15,
                "formula": "Number of incidents currently in an open state "
                           "(new / open / in progress / on hold / pending / "
                           "active / work in progress / assigned)",
                "bands": [
                    {"if": "<= 20 open",  "score": 100},
                    {"if": "<= 50 open",  "score":  80},
                    {"if": "<= 100 open", "score":  60},
                    {"if": "> 100 open", "score":  30},
                ],
                "source_column": "incident_state (or state)",
            },
            {
                "metric":  "High Priority",
                "weight":  10,
                "formula": "% of incidents with priority P1 or P2",
                "bands": [
                    {"if": "<= 5 %",  "score": 100},
                    {"if": "<= 10 %", "score":  80},
                    {"if": "<= 20 %", "score":  60},
                    {"if": "> 20 %", "score":  30},
                ],
                "source_column": "priority",
            },
            {
                "metric":  "Customer Feedback (proxy)",
                "weight":  10,
                "formula": "Composite proxy score - no real survey data is "
                           "available, so this combines four operational "
                           "signals that correlate with satisfaction. "
                           "Each signal contributes only if its source column "
                           "is present; remaining weights renormalise to 100 %.",
                "bands": [
                    {"signal": "First-call resolution",
                     "weight": 35, "rule": "% of closed tickets with reopen_count == 0"},
                    {"signal": "P1/P2 SLA performance",
                     "weight": 25, "rule": "% of P1+P2 tickets that met SLA"},
                    {"signal": "Communication density",
                     "weight": 20, "rule": "% of tickets with non-empty work_notes"},
                    {"signal": "Escalation / reassignment",
                     "weight": 20, "rule": "Inverse rate of avg(reassignment_count) > 1"},
                ],
                "source_column": "Multiple - see sub-rows above",
                "is_proxy": True,
            },
        ]

    def calculate_quality_score(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Weighted service quality score based on five live metrics
        (SLA, resolution time, reopen rate, backlog, high-priority
        share) plus a default for the unavailable customer-feedback
        component. Logic preserved from the donor.
        """
        try:
            total = len(df)
            if total == 0:
                return {"score": "N/A", "rating": "No Data", "metrics": {}, "weightages": {}}

            sla_met_pct = (df["SLA Met Calculated"].sum() / total) * 100
            avg_resolution_hours = float(df["Calculated Resolution Time"].mean() / 3600)
            reopen_rate = (df[df["reopen_count"] > 0].shape[0] / total) * 100
            open_count = df[
                df.get("incident_state", df.get("state", pd.Series([], dtype=str)))
                .astype(str).str.lower().isin(OPEN_STATES)
            ].shape[0]
            high_priority_pct = (
                df[df["priority"].astype(str).str.upper().isin(["P1", "P2"])].shape[0] / total
            ) * 100

            # Five-band scoring identical to the donor
            sla_score        = 100 if sla_met_pct >= 95 else 80 if sla_met_pct >= 85 else 60 if sla_met_pct >= 70 else 30
            avg_days         = avg_resolution_hours / 24
            resolution_score = 100 if avg_days <= 1   else 80 if avg_days <= 2   else 60 if avg_days <= 5   else 30
            reopen_score     = 100 if reopen_rate <= 2 else 80 if reopen_rate <= 5 else 60 if reopen_rate <= 10 else 30
            backlog_score    = 100 if open_count <= 20 else 80 if open_count <= 50 else 60 if open_count <= 100 else 30
            priority_score   = 100 if high_priority_pct <= 5 else 80 if high_priority_pct <= 10 else 60 if high_priority_pct <= 20 else 30

            # Proxy satisfaction score - replaces the old hardcoded 70.
            # Computed from first-call resolution, P1/P2 SLA performance,
            # work-notes density, and escalation/reassignment rate.
            # Falls back gracefully to 70 if none of those columns exist.
            proxy            = self._compute_proxy_satisfaction(df)
            feedback_score   = proxy["score"]

            score = (
                sla_score        * 30 +
                resolution_score * 20 +
                reopen_score     * 15 +
                backlog_score    * 15 +
                priority_score   * 10 +
                feedback_score   * 10
            ) / 100

            if   score >= 85: rating = "Excellent"
            elif score >= 70: rating = "Good"
            elif score >= 50: rating = "Average"
            else:             rating = "Bad"

            return {
                "score": round(score, 1),
                "rating": rating,
                "metrics": {
                    "sla_met_pct":          round(sla_met_pct, 1),
                    "avg_resolution_hours": round(avg_resolution_hours, 1),
                    "reopen_rate":          round(reopen_rate, 1),
                    "open_incidents":       int(open_count),
                    "high_priority_pct":    round(high_priority_pct, 1),
                    # Proxy satisfaction breakdown - new additive keys.
                    # Downstream consumers that don't know these keys are unaffected.
                    "proxy_satisfaction":   proxy["breakdown"],
                },
                "weightages": {
                    "sla_met":           {"score": sla_score,        "weight": 30, "contribution": round(sla_score        * 30 / 100, 1)},
                    "resolution_time":   {"score": resolution_score, "weight": 20, "contribution": round(resolution_score * 20 / 100, 1)},
                    "reopen_rate":       {"score": reopen_score,     "weight": 15, "contribution": round(reopen_score     * 15 / 100, 1)},
                    "incident_backlog":  {"score": backlog_score,    "weight": 15, "contribution": round(backlog_score    * 15 / 100, 1)},
                    "high_priority":     {"score": priority_score,   "weight": 10, "contribution": round(priority_score   * 10 / 100, 1)},
                    # key name, weight (10), and contribution formula are UNCHANGED
                    # so no existing consumer of this dict needs updating.
                    "customer_feedback": {"score": feedback_score,   "weight": 10, "contribution": round(feedback_score   * 10 / 100, 1)},
                },
                # NEW - drives the "How is this calculated?" tab beside
                # the chart. Pure presentation: this lists the band
                # thresholds and source columns that produced the
                # weighted contribution numbers in `weightages`.
                "calculation_breakdown": self.calculation_breakdown(),
            }
        except Exception:
            logger.exception("Error calculating quality score")
            return {"score": "Error", "rating": "Error", "metrics": {}, "weightages": {}}

    def get_sla_trends(self, df: pd.DataFrame) -> Dict[str, Any]:
        try:
            if "opened_timestamp" not in df.columns:
                return {"chart_data": [], "table_data": []}

            d = df.copy()
            d["Month"] = d["opened_timestamp"].dt.to_period("M")
            monthly = d.groupby("Month").agg(
                sla_met=("SLA Met Calculated", "sum"),
                total=("SLA Met Calculated", "count"),
            ).reset_index()
            monthly["sla_met_pct"]    = (monthly["sla_met"]    / monthly["total"] * 100).round(1)
            monthly["sla_breach"]     = monthly["total"] - monthly["sla_met"]
            monthly["sla_breach_pct"] = (monthly["sla_breach"] / monthly["total"] * 100).round(1)

            chart_data = [{
                "month":       str(r["Month"]),
                "sla_met":     int(r["sla_met"]),
                "sla_breach":  int(r["sla_breach"]),
                "sla_met_pct": float(r["sla_met_pct"]),
                "total":       int(r["total"]),
            } for _, r in monthly.iterrows()]

            table_data = [{
                "Month":      str(r["Month"]),
                "SLA Met":    int(r["sla_met"]),
                "SLA Breach": int(r["sla_breach"]),
                "Total":      int(r["total"]),
                "SLA Met %":  float(r["sla_met_pct"]),
            } for _, r in monthly.iterrows()]

            # Per-incident detail for the new "table view" toggle.
            # Includes the SLA target (so users can see WHY a row counted
            # as a breach), the actual resolution hours, and Y/N met flag.
            detail_df = d.copy()
            detail_df["__sla_met"] = detail_df["SLA Met Calculated"].map(lambda v: "Yes" if v else "No")
            detail_df["__resolution_hours"] = (
                pd.to_numeric(detail_df.get("Calculated Resolution Time", pd.Series([])),
                              errors="coerce") / 3600
            ).round(2)
            detail_df["__opened"] = detail_df["opened_timestamp"]
            detail_df["__priority"] = detail_df["priority"].astype(str) if "priority" in detail_df.columns else ""
            detail_df["__sla_target"] = detail_df.get("SLA Target (hours)", pd.Series([])).fillna("")
            incident_rows = self._project_incident_rows(detail_df, [
                "__opened", "__priority", "__sla_target",
                "__resolution_hours", "__sla_met",
            ])
            # Rename keys for UI friendliness
            for r in incident_rows:
                r["opened_at"]        = r.pop("__opened", "")
                r["priority"]         = r.pop("__priority", "")
                r["sla_target_hours"] = r.pop("__sla_target", "")
                r["resolution_hours"] = r.pop("__resolution_hours", "")
                r["sla_met"]          = r.pop("__sla_met", "")

            return {
                "chart_data":    chart_data,
                "table_data":    table_data,
                "incident_rows": incident_rows,
            }
        except Exception:
            logger.exception("Error getting SLA trends")
            return {"chart_data": [], "table_data": []}

    def get_incident_types(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Top 10 incident categories by count. Uses the `category` field
        from the ML preprocess (which itself comes from `u_tenant_category`
        or `category` in the raw export)."""
        try:
            if "category" not in df.columns:
                return {"chart_data": [], "table_data": []}
            counts = df["category"].astype(str).value_counts().head(10)
            total = len(df)
            chart_data = [{
                "type":       str(t),
                "count":      int(c),
                "percentage": round(c / total * 100, 1),
            } for t, c in counts.items()]
            table_data = [{
                "Incident Type": str(t),
                "Count":         int(c),
                "Percentage":    round(c / total * 100, 1),
            } for t, c in counts.items()]

            # Per-incident detail - every ticket with its category,
            # subcategory, priority, opened date and current state.
            detail_df = df.copy()
            detail_df["__category"]    = detail_df["category"].astype(str)
            detail_df["__subcategory"] = detail_df["subcategory"].astype(str) if "subcategory" in detail_df.columns else ""
            detail_df["__priority"]    = detail_df["priority"].astype(str) if "priority" in detail_df.columns else ""
            detail_df["__opened"]      = detail_df["opened_timestamp"] if "opened_timestamp" in detail_df.columns else ""
            state_col = "incident_state" if "incident_state" in detail_df.columns else "state"
            detail_df["__state"]       = detail_df[state_col].astype(str) if state_col in detail_df.columns else ""
            incident_rows = self._project_incident_rows(detail_df, [
                "__category", "__subcategory", "__priority", "__opened", "__state",
            ])
            for r in incident_rows:
                r["category"]    = r.pop("__category", "")
                r["subcategory"] = r.pop("__subcategory", "")
                r["priority"]    = r.pop("__priority", "")
                r["opened_at"]   = r.pop("__opened", "")
                r["state"]       = r.pop("__state", "")

            return {
                "chart_data":    chart_data,
                "table_data":    table_data,
                "incident_rows": incident_rows,
            }
        except Exception:
            logger.exception("Error getting incident types")
            return {"chart_data": [], "table_data": []}

    def get_state_trends(self, df: pd.DataFrame) -> Dict[str, Any]:
        try:
            state_col = "incident_state" if "incident_state" in df.columns else "state"
            if "opened_timestamp" not in df.columns or state_col not in df.columns:
                return {"chart_data": [], "table_data": []}

            d = df.copy()
            d["Month"] = d["opened_timestamp"].dt.to_period("M")
            grouped = d.groupby(["Month", state_col]).size().reset_index(name="Count")
            pivot = grouped.pivot(index="Month", columns=state_col, values="Count").fillna(0)

            chart_data = []
            for month in pivot.index:
                row = {"month": str(month)}
                for s in pivot.columns:
                    row[str(s).lower().replace(" ", "_")] = int(pivot.loc[month, s])
                chart_data.append(row)

            table_data = []
            for month in pivot.index:
                row = {"Month": str(month)}
                for s in pivot.columns:
                    row[str(s)] = int(pivot.loc[month, s])
                table_data.append(row)

            # Per-incident detail with current state, opened date and priority.
            detail_df = df.copy()
            detail_df["__state"]    = detail_df[state_col].astype(str)
            detail_df["__opened"]   = detail_df["opened_timestamp"]
            detail_df["__priority"] = detail_df["priority"].astype(str) if "priority" in detail_df.columns else ""
            detail_df["__assigned"] = detail_df["assignment_group"].astype(str) if "assignment_group" in detail_df.columns else ""
            incident_rows = self._project_incident_rows(detail_df, [
                "__state", "__opened", "__priority", "__assigned",
            ])
            for r in incident_rows:
                r["state"]            = r.pop("__state", "")
                r["opened_at"]        = r.pop("__opened", "")
                r["priority"]         = r.pop("__priority", "")
                r["assignment_group"] = r.pop("__assigned", "")

            return {
                "chart_data":    chart_data,
                "table_data":    table_data,
                "incident_rows": incident_rows,
            }
        except Exception:
            logger.exception("Error getting state trends")
            return {"chart_data": [], "table_data": []}

    def get_resolution_times(self, df: pd.DataFrame) -> Dict[str, Any]:
        try:
            if "Calculated Resolution Time" not in df.columns:
                return {"chart_data": [], "table_data": [], "stats": {}}

            hours = (df["Calculated Resolution Time"] / 3600).dropna()
            hours = hours[hours >= 0]
            if hours.empty:
                return {"chart_data": [], "table_data": [], "stats": {}}

            bins   = [0, 4, 24, 72, 168, float("inf")]
            labels = ["< 4 hours", "4-24 hours", "1-3 days", "3-7 days", "> 1 week"]
            binned = pd.cut(hours, bins=bins, labels=labels, include_lowest=True)
            counts = binned.value_counts().reindex(labels, fill_value=0)
            total = int(counts.sum())

            chart_data = [{
                "bin":        str(label),
                "count":      int(c),
                "percentage": round(c / total * 100, 1) if total else 0,
            } for label, c in counts.items()]

            table_data = [{
                "Time Range": str(label),
                "Count":      int(c),
                "Percentage": round(c / total * 100, 1) if total else 0,
            } for label, c in counts.items()]

            stats = {
                "mean_hours":   round(float(hours.mean()),   1),
                "median_hours": round(float(hours.median()), 1),
                "min_hours":    round(float(hours.min()),    1),
                "max_hours":    round(float(hours.max()),    1),
            }

            # Per-incident detail - only resolved tickets with a non-null
            # resolution time. Includes the bin label so the table can
            # be filtered to the same buckets shown in the chart.
            detail_df = df.copy()
            res_hours = pd.to_numeric(detail_df["Calculated Resolution Time"], errors="coerce") / 3600
            detail_df["__resolution_hours"] = res_hours.round(2)
            detail_df["__bin"] = pd.cut(res_hours, bins=bins, labels=labels,
                                        include_lowest=True).astype(str)
            detail_df = detail_df[res_hours.notna() & (res_hours >= 0)]
            detail_df["__priority"] = detail_df["priority"].astype(str) if "priority" in detail_df.columns else ""
            detail_df["__category"] = detail_df["category"].astype(str) if "category" in detail_df.columns else ""
            detail_df["__opened"]   = detail_df["opened_timestamp"] if "opened_timestamp" in detail_df.columns else ""
            incident_rows = self._project_incident_rows(detail_df, [
                "__resolution_hours", "__bin", "__priority", "__category", "__opened",
            ])
            for r in incident_rows:
                r["resolution_hours"] = r.pop("__resolution_hours", "")
                r["time_range"]       = r.pop("__bin", "")
                r["priority"]         = r.pop("__priority", "")
                r["category"]         = r.pop("__category", "")
                r["opened_at"]        = r.pop("__opened", "")

            return {
                "chart_data":    chart_data,
                "table_data":    table_data,
                "stats":         stats,
                "incident_rows": incident_rows,
            }
        except Exception:
            logger.exception("Error getting resolution times")
            return {"chart_data": [], "table_data": [], "stats": {}}

    def get_priority_trends(self, df: pd.DataFrame) -> Dict[str, Any]:
        try:
            if "priority" not in df.columns or "opened_timestamp" not in df.columns:
                return {"chart_data": [], "table_data": []}
            d = df.copy()
            d["Month"] = d["opened_timestamp"].dt.to_period("M")
            d["pri"]   = d["priority"].astype(str).str.upper()
            grouped = d.groupby(["Month", "pri"]).size().reset_index(name="Count")
            pivot = grouped.pivot(index="Month", columns="pri", values="Count").fillna(0)

            chart_data = []
            for month in pivot.index:
                row = {"month": str(month)}
                for p in ["P1", "P2", "P3", "P4"]:
                    row[p.lower()] = int(pivot.loc[month, p]) if p in pivot.columns else 0
                chart_data.append(row)

            table_data = []
            for month in pivot.index:
                row = {"Month": str(month)}
                for p in ["P1", "P2", "P3", "P4"]:
                    row[p] = int(pivot.loc[month, p]) if p in pivot.columns else 0
                table_data.append(row)

            # Per-incident detail with priority and opened date.
            detail_df = d.copy()
            detail_df["__priority"] = detail_df["pri"]
            detail_df["__opened"]   = detail_df["opened_timestamp"]
            detail_df["__category"] = detail_df["category"].astype(str) if "category" in detail_df.columns else ""
            state_col = "incident_state" if "incident_state" in detail_df.columns else "state"
            detail_df["__state"]    = detail_df[state_col].astype(str) if state_col in detail_df.columns else ""
            incident_rows = self._project_incident_rows(detail_df, [
                "__priority", "__opened", "__category", "__state",
            ])
            for r in incident_rows:
                r["priority"]  = r.pop("__priority", "")
                r["opened_at"] = r.pop("__opened", "")
                r["category"]  = r.pop("__category", "")
                r["state"]     = r.pop("__state", "")

            return {
                "chart_data":    chart_data,
                "table_data":    table_data,
                "incident_rows": incident_rows,
            }
        except Exception:
            logger.exception("Error getting priority trends")
            return {"chart_data": [], "table_data": []}

    def get_reopened_incidents(self, df: pd.DataFrame) -> Dict[str, Any]:
        try:
            if "reopen_count" not in df.columns:
                return {"chart_data": [], "table_data": [], "stats": {}}

            reopened = df[df["reopen_count"] > 0]
            counts = reopened["reopen_count"].astype(int).value_counts().sort_index()
            total = len(df)
            n_reopened = len(reopened)

            chart_data = [{
                "reopen_count":   int(k),
                "incident_count": int(v),
                "percentage":     round(v / n_reopened * 100, 1) if n_reopened else 0,
            } for k, v in counts.items()]

            table_data = [{
                "Times Reopened": int(k),
                "Incident Count": int(v),
                "Percentage":     round(v / n_reopened * 100, 1) if n_reopened else 0,
            } for k, v in counts.items()]

            stats = {
                "total_incidents":    total,
                "reopened_incidents": n_reopened,
                "reopen_rate":        round(n_reopened / total * 100, 1) if total else 0,
                "avg_reopens":        round(float(reopened["reopen_count"].mean()), 1) if n_reopened else 0,
            }

            # Per-incident detail - only the tickets that were ACTUALLY
            # reopened (reopen_count > 0). This matches the user's
            # example: section 7 should show incident_id and how many
            # times it was reopened.
            detail_df = reopened.copy()
            detail_df["__reopen_count"] = detail_df["reopen_count"].astype(int)
            # Friendly label: "1 time" / "2 times" so the column is searchable
            # by both the integer and the natural-language form.
            detail_df["__times_reopened"] = detail_df["__reopen_count"].apply(
                lambda n: f"{n} time" if n == 1 else f"{n} times"
            )
            detail_df["__priority"] = detail_df["priority"].astype(str) if "priority" in detail_df.columns else ""
            detail_df["__category"] = detail_df["category"].astype(str) if "category" in detail_df.columns else ""
            detail_df["__opened"]   = detail_df["opened_timestamp"] if "opened_timestamp" in detail_df.columns else ""
            state_col_r = "incident_state" if "incident_state" in detail_df.columns else "state"
            detail_df["__state"]    = detail_df[state_col_r].astype(str) if state_col_r in detail_df.columns else ""
            incident_rows = self._project_incident_rows(detail_df, [
                "__reopen_count", "__times_reopened", "__priority",
                "__category", "__opened", "__state",
            ])
            for r in incident_rows:
                r["reopen_count"]   = r.pop("__reopen_count", 0)
                r["times_reopened"] = r.pop("__times_reopened", "")
                r["priority"]       = r.pop("__priority", "")
                r["category"]       = r.pop("__category", "")
                r["opened_at"]      = r.pop("__opened", "")
                r["state"]          = r.pop("__state", "")

            return {
                "chart_data":    chart_data,
                "table_data":    table_data,
                "stats":         stats,
                "incident_rows": incident_rows,
            }
        except Exception:
            logger.exception("Error getting reopened incidents")
            return {"chart_data": [], "table_data": [], "stats": {}}

    def get_long_open_incidents(self, df: pd.DataFrame) -> Dict[str, Any]:
        try:
            state_col = "incident_state" if "incident_state" in df.columns else "state"
            if state_col not in df.columns or "opened_timestamp" not in df.columns:
                return {"chart_data": [], "table_data": [], "stats": {}}

            open_df = df[df[state_col].astype(str).str.lower().isin(OPEN_STATES)].copy()
            if open_df.empty:
                return {"chart_data": [], "table_data": [], "stats": {
                    "total_open": 0, "avg_days_open": 0, "longest_open": 0, "over_30_days": 0
                }}

            now = datetime.now()
            open_df["Days Open"] = (pd.Timestamp(now) - open_df["opened_timestamp"]).dt.days

            bins   = [0, 7, 30, 90, 180, float("inf")]
            labels = ["< 1 week", "1 week - 1 month", "1-3 months", "3-6 months", "> 6 months"]
            binned = pd.cut(open_df["Days Open"], bins=bins, labels=labels, include_lowest=True)
            counts = binned.value_counts().reindex(labels, fill_value=0)
            total = int(counts.sum())

            chart_data = [{
                "bin":        str(label),
                "count":      int(c),
                "percentage": round(c / total * 100, 1) if total else 0,
            } for label, c in counts.items()]

            table_data = [{
                "Time Range": str(label),
                "Count":      int(c),
                "Percentage": round(c / total * 100, 1) if total else 0,
            } for label, c in counts.items()]

            stats = {
                "total_open":    int(len(open_df)),
                "avg_days_open": round(float(open_df["Days Open"].mean()), 1),
                "longest_open":  int(open_df["Days Open"].max()),
                "over_30_days":  int(len(open_df[open_df["Days Open"] > 30])),
            }

            # Per-incident detail - every still-open ticket with its
            # age in days and bin label.
            detail_df = open_df.copy()
            detail_df["__days_open"] = detail_df["Days Open"].astype(int)
            detail_df["__bin"]       = pd.cut(detail_df["Days Open"], bins=bins,
                                              labels=labels, include_lowest=True).astype(str)
            detail_df["__state"]     = detail_df[state_col].astype(str)
            detail_df["__priority"]  = detail_df["priority"].astype(str) if "priority" in detail_df.columns else ""
            detail_df["__assigned"]  = detail_df["assignment_group"].astype(str) if "assignment_group" in detail_df.columns else ""
            detail_df["__opened"]    = detail_df["opened_timestamp"]
            incident_rows = self._project_incident_rows(detail_df, [
                "__days_open", "__bin", "__state", "__priority", "__assigned", "__opened",
            ])
            for r in incident_rows:
                r["days_open"]        = r.pop("__days_open", 0)
                r["age_band"]         = r.pop("__bin", "")
                r["state"]            = r.pop("__state", "")
                r["priority"]         = r.pop("__priority", "")
                r["assignment_group"] = r.pop("__assigned", "")
                r["opened_at"]        = r.pop("__opened", "")
            # Sort newest-to-oldest age so the longest-open tickets show first
            incident_rows.sort(key=lambda r: r.get("days_open", 0), reverse=True)

            return {
                "chart_data":    chart_data,
                "table_data":    table_data,
                "stats":         stats,
                "incident_rows": incident_rows,
            }
        except Exception:
            logger.exception("Error getting long-open incidents")
            return {"chart_data": [], "table_data": [], "stats": {}}

    def get_support_quality(self, df: pd.DataFrame, quality_score: Dict) -> Dict[str, Any]:
        """Headline KPIs panel. Reuses the already-computed quality score
        rather than recomputing to keep the values consistent."""
        try:
            total = len(df)
            sla_met_pct          = round(float(df["SLA Met Calculated"].sum() / total * 100), 1) if total else 0.0
            avg_resolution_hours = round(float(df["Calculated Resolution Time"].mean() / 3600), 1) if total else 0.0
            reopen_rate          = round(float((df["reopen_count"] > 0).sum() / total * 100), 1) if total else 0.0

            priorities = df["priority"].astype(str).str.upper().value_counts(normalize=True) * 100 if total else pd.Series(dtype=float)
            return {
                "sla_performance":      sla_met_pct,
                "avg_resolution_hours": avg_resolution_hours,
                "reopen_rate":          reopen_rate,
                "p1_percentage":        round(float(priorities.get("P1", 0)), 1),
                "p2_percentage":        round(float(priorities.get("P2", 0)), 1),
                "p3_percentage":        round(float(priorities.get("P3", 0)), 1),
                "p4_percentage":        round(float(priorities.get("P4", 0)), 1),
                "overall_score":        quality_score.get("score", "N/A"),
                "overall_rating":       quality_score.get("rating", "Unknown"),
            }
        except Exception:
            logger.exception("Error getting support quality")
            return {}


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def compute_summary(df: pd.DataFrame,
                    raw_df: Optional[pd.DataFrame] = None,
                    kind: str = "batch") -> Dict[str, Any]:
    """
    Compute all nine summary-report metrics from a preprocessed
    dataframe. Returns a single dict that can be cached alongside the
    ML inference results, jsonified, or fed into the Excel builder.

    Parameters
    ----------
    raw_df :
        The same upload BEFORE preprocessing. Optional, and only the
        assignment-group analysis uses it: that panel attributes work to
        teams and classifies it by request type, and both of those read
        columns (`assignment_group`, `category`) whose blanks
        ``handle_nulls`` fills with the column mode. Passing the raw frame
        keeps a blank blank. Every other metric here is unaffected and
        behaves exactly as before when it is omitted.
    kind :
        "batch" (incidents) or "sr" (service requests).
    """
    proc = SummaryProcessor()
    augmented = proc._augment(df)

    quality   = proc.calculate_quality_score(augmented)
    sla       = proc.get_sla_trends(augmented)
    types     = proc.get_incident_types(augmented)
    states    = proc.get_state_trends(augmented)
    reso      = proc.get_resolution_times(augmented)
    pri       = proc.get_priority_trends(augmented)
    reopen    = proc.get_reopened_incidents(augmented)
    long_open = proc.get_long_open_incidents(augmented)
    support   = proc.get_support_quality(augmented, quality)

    # Assignment-group analysis. Deliberately computed from `augmented`
    # rather than `df` so the group panel's resolution hours and SLA flags
    # are the same numbers the other eight sections report - one
    # definition of "how long did this take", not two.
    from .group_analysis import compute_group_analysis
    groups = compute_group_analysis(augmented, raw_df=raw_df, kind=kind)

    return {
        "quality_score":      quality,
        "sla_trends":         sla,
        "incident_types":     types,
        "state_trends":       states,
        "resolution_times":   reso,
        "priority_trends":    pri,
        "reopened_incidents": reopen,
        "long_open_incidents": long_open,
        "support_quality":    support,
        "assignment_groups":  groups,
        "total_incidents":    int(len(df)),
    }