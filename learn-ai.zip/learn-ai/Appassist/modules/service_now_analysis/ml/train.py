"""
Full retraining pipeline for the ServiceNow ML Workbench.

Changes vs previous version
----------------------------
* **LightGBM classifiers** - categorisation, subcategorisation, and routing
  models now use LGBMClassifier in place of LogisticRegression.  A graceful
  fallback to LR is in place so the pipeline still works if lightgbm is not
  installed.  Priority uses LightGBM too (replacing RandomForest).

* **Semantic corpus vectors** - after the standard TF-IDF corpus is built,
  the pipeline also encodes the resolved-incident corpus with a local
  sentence-transformers model (``config.EMBEDDING_MODEL_PATH``) and saves the
  dense vectors as ``incident_sem_vectors_latest.pkl``.  A BM25 index is also
  built and saved.  Both are optional: if the libraries / model are absent the
  step is skipped and similarity.py falls back to TF-IDF alone.

* **Persisted null fills** - training-time mode/median values are saved to
  ``null_fills.json`` so inference always uses the same fill values rather
  than recomputing them from each (potentially small) inference batch.

Trains
------
    1. TF-IDF vectorizer       (vectorizer_latest.pkl)
    2. Categorisation model    (cat_model_latest.pkl)
    3. Subcategorisation model (subcat_model_latest.pkl)
    4. Priority model          (pri_model_latest.pkl)
    5. Routing model           (route_model_latest.pkl)
    6. Resolution-time model   (eta_model_latest.pkl)
    7. SLA-breach model        (sla_model_latest.pkl)
    8. TF-IDF corpus vectors   (corpus_vectors_latest.pkl)
    9. Semantic corpus vectors (incident_sem_vectors_latest.pkl) [optional]
   10. BM25 index              (incident_bm25_latest.pkl)        [optional]
   11. Null fills              (null_fills.json)

Usage
-----
    python -m ml.train --input data/uploads/export.csv --evaluate --replace-if-better
    python -m ml.train --input data/uploads/export.csv --force-replace
    python -m ml.train --input data/uploads/export.csv --dry-run
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import shutil
import sys
import time
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional, Tuple

import joblib
import numpy as np
import pandas as pd
import scipy.sparse as sp
from sklearn.compose import TransformedTargetRegressor
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import (
    accuracy_score, f1_score,
    mean_absolute_error, mean_squared_error, roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder

from .. import config
from .preprocess import (
    add_resolution_features, compute_null_fills, filter_system_tickets,
    get_resolved_tickets, load_export, preprocess,
    save_null_fills,
)
from .embedding_utils import build_and_save_extras

# ---------------------------------------------------------------------------
# Optional LightGBM - graceful fallback to LR / RF if not installed
# ---------------------------------------------------------------------------
try:
    from lightgbm import LGBMClassifier
    _LGBM_AVAILABLE = True
    logger_startup = logging.getLogger("train")
    logger_startup.info("LightGBM available - using LGBMClassifier for categorisation, "
                        "subcategorisation, routing, priority and SLA models")
    # Early-stopping / silent-logging callbacks (lightgbm >= 3.3). If this
    # secondary import fails we still use LightGBM, just without early stopping.
    try:
        from lightgbm import early_stopping, log_evaluation
        _LGBM_CALLBACKS = True
    except ImportError:
        _LGBM_CALLBACKS = False
        logger_startup.info("lightgbm.early_stopping unavailable - training with a "
                            "fixed number of rounds.")
except ImportError:
    _LGBM_AVAILABLE = False
    _LGBM_CALLBACKS = False
    logging.getLogger("train").info(
        "LightGBM not installed - falling back to LogisticRegression / RandomForest. "
        "Install lightgbm for better calibration and faster training.")

logger = logging.getLogger(__name__)


@contextmanager
def _timed(stage: str):
    """Log how long a pipeline stage takes, so the slow steps are measurable."""
    t0 = time.perf_counter()
    try:
        yield
    finally:
        logger.info("  %s: %.1fs", stage, time.perf_counter() - t0)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _save_versioned(obj, name: str) -> Path:
    """
    Save obj as models/{name}_{ts}.pkl atomically and update the
    _latest.pkl pointer. Resilient to mid-write crashes.
    """
    ts = _timestamp()
    versioned = config.MODELS_DIR / f"{name}_{ts}.pkl"
    latest = config.MODELS_DIR / f"{name}_latest.pkl"

    versioned_tmp = versioned.with_suffix(versioned.suffix + ".tmp")
    joblib.dump(obj, versioned_tmp)
    os.replace(versioned_tmp, versioned)

    if latest.exists():
        archive_path = config.ARCHIVE_DIR / f"{name}_archived_{_timestamp()}.pkl"
        try:
            shutil.copy2(latest, archive_path)
            _prune_archive(name)
        except OSError as exc:
            logger.warning("Could not archive previous %s_latest: %s", name, exc)

    latest_tmp = latest.with_suffix(latest.suffix + ".tmp")
    shutil.copy2(versioned, latest_tmp)
    os.replace(latest_tmp, latest)

    logger.info("Saved %s (versioned: %s)", name, versioned.name)
    return versioned


def _prune_archive(name: str) -> None:
    archived = sorted(
        config.ARCHIVE_DIR.glob(f"{name}_archived_*.pkl"),
        key=lambda p: p.stat().st_mtime, reverse=True,
    )
    for old in archived[config.ARCHIVE_KEEP_VERSIONS:]:
        try:
            old.unlink()
        except OSError as exc:
            logger.warning("Could not prune %s: %s", old, exc)


def _load_metadata() -> Dict:
    if config.MODEL_METADATA_FILE.exists():
        try:
            return json.loads(config.MODEL_METADATA_FILE.read_text())
        except json.JSONDecodeError:
            logger.warning("Corrupt metadata.json, starting fresh")
    return {"models": {}, "history": []}


def _save_metadata(meta: Dict) -> None:
    config.MODEL_METADATA_FILE.write_text(json.dumps(meta, indent=2, default=str))


# ---------------------------------------------------------------------------
# Feature builders
# ---------------------------------------------------------------------------
def _fit_categorical_encoders(df: pd.DataFrame,
                              cols: Tuple[str, ...]) -> Dict[str, OneHotEncoder]:
    out: Dict[str, OneHotEncoder] = {}
    for col in cols:
        if col not in df.columns:
            continue
        enc = OneHotEncoder(handle_unknown="ignore", sparse_output=True, dtype=np.float32)
        values = df[[col]].astype(str).fillna("Unknown")
        enc.fit(values)
        out[col] = enc
    return out


def _augment_with_encoders(X_text: sp.csr_matrix, df: pd.DataFrame,
                            encoders: Dict[str, OneHotEncoder],
                            cols: Tuple[str, ...]) -> sp.csr_matrix:
    blocks = [X_text]
    for col in cols:
        enc = encoders.get(col)
        if enc is None or col not in df.columns:
            continue
        values = df[[col]].astype(str).fillna("Unknown")
        blocks.append(enc.transform(values))
    if len(blocks) == 1:
        return X_text.tocsr() if sp.issparse(X_text) else sp.csr_matrix(X_text)
    return sp.hstack(blocks).tocsr()


ALL_CATEGORICAL_COLUMNS: Tuple[str, ...] = (
    "category", "subcategory", "priority", "assignment_group",
)


def _build_tfidf(corpus: pd.Series) -> Tuple[TfidfVectorizer, sp.csr_matrix]:
    vec = TfidfVectorizer(
        max_features=config.TFIDF_MAX_FEATURES,
        ngram_range=(1, config.TFIDF_NGRAM_MAX),
        min_df=config.TFIDF_MIN_DF,
        stop_words="english",
        sublinear_tf=True,
        dtype=np.float32,   # default float64 doubles memory and upcasts the
                            # float32 one-hot blocks during hstack
    )
    X = vec.fit_transform(corpus.fillna("").astype(str))
    return vec, X


# ---------------------------------------------------------------------------
# Classifier factory - LightGBM with fallback to LR
# ---------------------------------------------------------------------------
def _make_classifier(class_weight: str = "balanced"):
    """
    Return a LGBMClassifier if available, otherwise LogisticRegression.

    Both share the same sklearn-compatible API so callers are unchanged.
    LightGBM advantages: better calibration on imbalanced data, native
    handling of sparse matrices, faster training, no max_iter limit.
    """
    if _LGBM_AVAILABLE:
        return LGBMClassifier(
            n_estimators=config.LGBM_N_ESTIMATORS,   # upper bound; early stopping trims it
            learning_rate=config.LGBM_LEARNING_RATE,
            num_leaves=config.LGBM_NUM_LEAVES,
            class_weight=class_weight,
            n_jobs=-1,
            random_state=config.RANDOM_STATE,
            verbose=-1,            # suppress per-iteration output
        )
    return LogisticRegression(
        max_iter=config.LR_MAX_ITER,
        class_weight=class_weight,
        solver="lbfgs",
        multi_class="auto",
        n_jobs=-1,
    )


def _fit_classifier(model, Xtr, ytr, Xte, yte):
    """
    Fit ``model``.  For LightGBM, pass the held-out split as an eval set and
    stop boosting once the validation metric plateaus (config.
    LGBM_EARLY_STOPPING_ROUNDS) - typically halving training time and reducing
    overfit versus a fixed round count.  Falls back to a plain fit for the
    LogisticRegression path or if early stopping raises (e.g. a label only
    present in the eval split).
    """
    if _LGBM_AVAILABLE and _LGBM_CALLBACKS and isinstance(model, LGBMClassifier):
        try:
            model.fit(
                Xtr, ytr,
                eval_set=[(Xte, yte)],
                callbacks=[
                    early_stopping(config.LGBM_EARLY_STOPPING_ROUNDS, verbose=False),
                    log_evaluation(0),
                ],
            )
            return model
        except Exception as exc:
            logger.warning("Early-stopping fit failed (%s); refitting without eval set", exc)
    model.fit(Xtr, ytr)
    return model


def _collapse_rare_classes(y: pd.Series, min_count: int) -> pd.Series:
    """
    Group labels with fewer than ``min_count`` samples into a single "Other"
    bucket.  For multiclass LightGBM (one tree per class per boosting round)
    this caps the per-round tree count, and it removes noisy singleton labels
    that hurt generalisation.  ``min_count <= 1`` disables collapsing.
    """
    if min_count <= 1:
        return y
    counts = y.value_counts()
    rare = counts.index[counts < min_count]
    if len(rare) == 0:
        return y
    logger.info("Collapsing %d rare class(es) (<%d samples) into 'Other'",
                len(rare), min_count)
    return y.where(~y.isin(rare), "Other")


def _safe_stratify(y: pd.Series):
    """Return ``y`` for use as a stratify key only if every class has >= 2
    members (a hard requirement of train_test_split); otherwise None."""
    return y if y.value_counts().min() >= 2 else None


def _best_iteration(model) -> Optional[int]:
    """Number of boosting rounds actually used (set by LightGBM early stopping)."""
    return getattr(model, "best_iteration_", None)


# ---------------------------------------------------------------------------
# Individual trainers
# ---------------------------------------------------------------------------
def train_categorisation(df: pd.DataFrame, X_text: sp.csr_matrix) -> Tuple[object, Dict]:
    if "category" not in df.columns or df["category"].nunique() < 2:
        return None, {"skipped": "Not enough category labels"}

    y = df["category"].astype(str)
    valid = y != "Unknown"
    if valid.sum() < config.MIN_ROWS_FOR_TRAINING:
        return None, {"skipped": f"Only {int(valid.sum())} labelled rows"}

    X = X_text[valid.to_numpy()]
    y = _collapse_rare_classes(y[valid].reset_index(drop=True),
                               config.RARE_CLASS_MIN_COUNT)
    if y.nunique() < 2:
        return None, {"skipped": "Fewer than 2 categories after collapsing rare labels"}
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=config.TEST_SIZE,
                                          random_state=config.RANDOM_STATE,
                                          stratify=_safe_stratify(y))
    model = _make_classifier()
    _fit_classifier(model, Xtr, ytr, Xte, yte)
    pred = model.predict(Xte)
    metrics = {
        "f1_weighted": float(f1_score(yte, pred, average="weighted", zero_division=0)),
        "accuracy": float(accuracy_score(yte, pred)),
        "classes": int(len(np.unique(ytr))),
        "training_rows": int(len(ytr)),
        "best_iteration": _best_iteration(model),
        "classifier": "LightGBM" if _LGBM_AVAILABLE else "LogisticRegression",
    }
    logger.info("Categorisation F1 (weighted): %.3f  [%s]",
                metrics["f1_weighted"], metrics["classifier"])
    return model, metrics


def train_subcategorisation(df: pd.DataFrame, X_text: sp.csr_matrix,
                            encoders: Optional[Dict[str, OneHotEncoder]] = None
                            ) -> Tuple[object, Dict]:
    """
    Train subcategory predictor with category as an additional feature.

    This implements the hierarchical classification improvement: by
    including the predicted/actual category as a one-hot feature the model
    learns category->subcategory relationships and avoids nonsensical
    pairings (e.g. subcategory='Network' with category='HR').
    """
    if "subcategory" not in df.columns or df["subcategory"].nunique() < 2:
        return None, {"skipped": "Not enough subcategory labels"}
    y = df["subcategory"].astype(str)
    valid = y != "Unknown"
    if valid.sum() < config.MIN_ROWS_FOR_TRAINING:
        return None, {"skipped": f"Only {int(valid.sum())} labelled rows"}

    # Include category as a feature so the model learns the hierarchy.
    X = _augment_with_encoders(
        X_text[valid.to_numpy()], df[valid].reset_index(drop=True),
        encoders or {}, ("category",),
    )
    y = _collapse_rare_classes(y[valid].reset_index(drop=True),
                               config.RARE_CLASS_MIN_COUNT)
    if y.nunique() < 2:
        return None, {"skipped": "Fewer than 2 subcategories after collapsing rare labels"}
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=config.TEST_SIZE,
                                          random_state=config.RANDOM_STATE,
                                          stratify=_safe_stratify(y))
    model = _make_classifier()
    _fit_classifier(model, Xtr, ytr, Xte, yte)
    pred = model.predict(Xte)
    metrics = {
        "f1_weighted": float(f1_score(yte, pred, average="weighted", zero_division=0)),
        "accuracy": float(accuracy_score(yte, pred)),
        "training_rows": int(len(ytr)),
        "best_iteration": _best_iteration(model),
        "classifier": "LightGBM" if _LGBM_AVAILABLE else "LogisticRegression",
    }
    return model, metrics


def train_priority(df: pd.DataFrame, X_text: sp.csr_matrix,
                   encoders: Optional[Dict[str, OneHotEncoder]] = None
                   ) -> Tuple[object, Dict]:
    if "priority" not in df.columns or df["priority"].nunique() < 2:
        return None, {"skipped": "Not enough priority labels"}

    # Train only on rows whose priority was actually populated in the source.
    # Rows with a missing priority were defaulted to "P3" by normalise_priority;
    # including them fabricates a P3 majority that biases the model and inflates
    # apparent accuracy.  preprocess records this in the priority_present flag.
    if "priority_present" in df.columns:
        valid = df["priority_present"].fillna(False).to_numpy(dtype=bool)
    else:
        valid = np.ones(len(df), dtype=bool)
    if valid.sum() < config.MIN_ROWS_FOR_TRAINING:
        return None, {"skipped": f"Only {int(valid.sum())} rows with a populated priority"}

    y = df["priority"].astype(str)[valid].reset_index(drop=True)
    X = _augment_with_encoders(
        X_text[valid], df[valid].reset_index(drop=True), encoders or {},
        ("assignment_group", "category"),
    )
    if y.nunique() < 2:
        return None, {"skipped": "Priority has <2 classes after excluding defaulted rows"}
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=config.TEST_SIZE,
                                          random_state=config.RANDOM_STATE,
                                          stratify=_safe_stratify(y))
    model = _make_classifier()
    _fit_classifier(model, Xtr, ytr, Xte, yte)
    pred = model.predict(Xte)
    metrics = {
        "f1_macro": float(f1_score(yte, pred, average="macro", zero_division=0)),
        "f1_weighted": float(f1_score(yte, pred, average="weighted", zero_division=0)),
        "accuracy": float(accuracy_score(yte, pred)),
        "per_class_f1": {
            cls: float(f1_score(yte == cls, pred == cls, zero_division=0))
            for cls in sorted(set(y))
        },
        "training_rows": int(len(ytr)),
        "class_distribution": y.value_counts().to_dict(),
        "best_iteration": _best_iteration(model),
        "classifier": "LightGBM" if _LGBM_AVAILABLE else "LogisticRegression",
    }
    logger.info("Priority F1 (macro): %.3f | per-class: %s",
                metrics["f1_macro"],
                {k: round(v, 2) for k, v in metrics["per_class_f1"].items()})
    return model, metrics


def train_routing(df: pd.DataFrame, X_text: sp.csr_matrix,
                  encoders: Optional[Dict[str, OneHotEncoder]] = None
                  ) -> Tuple[object, Dict]:
    if "assignment_group" not in df.columns or df["assignment_group"].nunique() < 2:
        reason = "assignment_group column missing or has fewer than 2 unique values"
        logger.warning("Routing model SKIPPED: %s", reason)
        return None, {"skipped": reason}
    y = df["assignment_group"].astype(str)
    valid = y != "Unknown"
    if valid.sum() < config.MIN_ROWS_FOR_TRAINING:
        reason = (f"only {int(valid.sum())} rows with a known assignment_group "
                  f"(need >= {config.MIN_ROWS_FOR_TRAINING})")
        logger.warning("Routing model SKIPPED: %s", reason)
        return None, {"skipped": reason}

    X = _augment_with_encoders(
        X_text[valid.to_numpy()], df[valid].reset_index(drop=True),
        encoders or {}, ("category", "priority"),
    )
    y = _collapse_rare_classes(y[valid].reset_index(drop=True),
                               config.RARE_CLASS_MIN_COUNT)
    if y.nunique() < 2:
        reason = "fewer than 2 assignment groups after collapsing rare labels"
        logger.warning("Routing model SKIPPED: %s", reason)
        return None, {"skipped": reason}
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=config.TEST_SIZE,
                                          random_state=config.RANDOM_STATE,
                                          stratify=_safe_stratify(y))
    model = _make_classifier()
    _fit_classifier(model, Xtr, ytr, Xte, yte)
    pred = model.predict(Xte)
    metrics = {
        "accuracy": float(accuracy_score(yte, pred)),
        "f1_weighted": float(f1_score(yte, pred, average="weighted", zero_division=0)),
        "training_rows": int(len(ytr)),
        "classes": int(y.nunique()),
        "best_iteration": _best_iteration(model),
        "classifier": "LightGBM" if _LGBM_AVAILABLE else "LogisticRegression",
    }
    logger.info("Routing accuracy: %.3f  [%s]", metrics["accuracy"], metrics["classifier"])
    return model, metrics


def train_resolution_time(df: pd.DataFrame, X_text: sp.csr_matrix,
                          encoders: Optional[Dict[str, OneHotEncoder]] = None
                          ) -> Tuple[object, Dict]:
    if "resolution_hours" not in df.columns:
        return None, {"skipped": "No resolution_hours column"}

    mask = df["resolution_hours"].notna() & (df["resolution_hours"] > 0)
    if mask.sum() < config.MIN_ROWS_FOR_TRAINING:
        return None, {"skipped": f"Only {int(mask.sum())} resolved rows"}

    y = df.loc[mask, "resolution_hours"].astype(float).to_numpy()
    X = _augment_with_encoders(
        X_text[mask.to_numpy()], df[mask].reset_index(drop=True),
        encoders or {}, ("priority", "category"),
    )

    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=config.TEST_SIZE,
                                          random_state=config.RANDOM_STATE)
    inner = Ridge(alpha=1.0)
    model = TransformedTargetRegressor(
        regressor=inner, func=np.log1p, inverse_func=np.expm1,
    )
    model.fit(Xtr, ytr)
    pred = model.predict(Xte)
    metrics = {
        "mae_hours": float(mean_absolute_error(yte, pred)),
        "rmse_hours": float(np.sqrt(mean_squared_error(yte, pred))),
        "median_ae_hours": float(np.median(np.abs(yte - pred))),
        "training_rows": int(len(ytr)),
        "y_mean_hours": float(np.mean(y)),
        "y_median_hours": float(np.median(y)),
        "y_p90_hours": float(np.quantile(y, 0.9)),
    }
    logger.info("Resolution MAE: %.2f hours (median AE: %.2f)",
                metrics["mae_hours"], metrics["median_ae_hours"])
    return model, metrics


def train_sla_breach(df: pd.DataFrame, X_text: sp.csr_matrix,
                     encoders: Optional[Dict[str, OneHotEncoder]] = None
                     ) -> Tuple[object, Dict]:
    if "made_sla" not in df.columns:
        return None, {"skipped": "made_sla column not present"}
    if df["made_sla"].nunique() < 2:
        return None, {"skipped": "made_sla has only one value"}

    y = (~df["made_sla"].astype(bool)).astype(int)
    X = _augment_with_encoders(X_text, df, encoders or {},
                               ("priority", "category", "assignment_group"))
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=config.TEST_SIZE,
                                          random_state=config.RANDOM_STATE,
                                          stratify=y if y.nunique() == 2 else None)
    # Binary SLA-breach prediction.  LightGBM with class_weight="balanced"
    # trains far faster than a 100-tree unbounded RandomForest on the
    # high-dimensional sparse TF-IDF matrix, at comparable AUC.  RandomForest
    # remains the fallback when LightGBM is not installed.
    if _LGBM_AVAILABLE:
        model = LGBMClassifier(
            n_estimators=config.LGBM_N_ESTIMATORS,
            learning_rate=config.LGBM_LEARNING_RATE,
            num_leaves=config.LGBM_NUM_LEAVES,
            class_weight="balanced",
            n_jobs=-1,
            random_state=config.RANDOM_STATE,
            verbose=-1,
        )
        _fit_classifier(model, Xtr, ytr, Xte, yte)
    else:
        from sklearn.ensemble import RandomForestClassifier
        model = RandomForestClassifier(
            n_estimators=config.RF_N_ESTIMATORS,
            random_state=config.RANDOM_STATE,
            n_jobs=-1,
            class_weight="balanced",
        )
        model.fit(Xtr, ytr)
    proba = model.predict_proba(Xte)[:, 1]
    metrics = {
        "roc_auc": float(roc_auc_score(yte, proba)) if len(set(yte)) == 2 else None,
        "training_rows": int(len(ytr)),
        "best_iteration": _best_iteration(model),
        "classifier": "LightGBM" if _LGBM_AVAILABLE else "RandomForest",
    }
    logger.info("SLA-breach AUC: %.3f  [%s]",
                metrics.get("roc_auc") or 0.0, metrics["classifier"])
    return model, metrics


# ---------------------------------------------------------------------------
# Master pipeline
# ---------------------------------------------------------------------------
def _resolve_input_path(user_path: Path) -> Path:
    cwd_path = Path.cwd() / user_path if not user_path.is_absolute() else user_path
    candidates = [
        user_path if user_path.is_absolute() else cwd_path,
        config.HOST_ROOT / user_path,
        config.HOST_ROOT / "data" / user_path.name,
        config.UPLOAD_DIR / user_path.name,
        config.DATA_DIR / user_path.name,
    ]

    seen = set()
    tried = []
    for c in candidates:
        c = c.resolve() if c.is_absolute() else (Path.cwd() / c).resolve()
        if c in seen:
            continue
        seen.add(c)
        tried.append(c)
        if c.is_file():
            return c

    msg_lines = [f"Could not find input file: {user_path}"]
    for p in tried:
        msg_lines.append(f"    - {p}")
    raise FileNotFoundError("\n".join(msg_lines))


def run_training(input_path: Path, *, dry_run: bool = False,
                 force_replace: bool = False,
                 replace_if_better: bool = True) -> Dict:
    """Execute the full retraining pipeline. Returns the run report."""
    input_path = _resolve_input_path(Path(input_path))

    logger.info("=" * 70)
    logger.info("Training pipeline started: %s", input_path)
    logger.info("=" * 70)

    with _timed("load_export"):
        raw = load_export(input_path)
    logger.info("Loaded %d raw rows, %d columns", len(raw), len(raw.columns))

    with _timed("preprocess + system-ticket filter"):
        df = preprocess(raw)
        df = filter_system_tickets(df)
    logger.info("After preprocessing & system-ticket filter: %d rows", len(df))

    if len(df) < config.MIN_ROWS_FOR_TRAINING:
        raise ValueError(
            f"Only {len(df)} usable rows; need at least {config.MIN_ROWS_FOR_TRAINING}"
        )

    resolved = get_resolved_tickets(df)
    logger.info("Resolved/closed rows used for label training: %d", len(resolved))

    # Compute and persist null fills from training corpus.
    # These are loaded at inference time by predict.py so single-record
    # inference uses stable fills rather than batch-derived ones.
    label_fill_values = compute_null_fills(df)
    save_null_fills(label_fill_values, config.MODELS_DIR / "null_fills.json")
    logger.info("Null fills computed and persisted for %d columns", len(label_fill_values))

    res_fill_values = compute_null_fills(resolved) if len(resolved) else label_fill_values
    label_df = resolved if len(resolved) >= config.MIN_ROWS_FOR_TRAINING else df

    # Build the TF-IDF matrix once.  The resolved-corpus transform is reused by
    # the resolution-time, SLA and corpus-vector steps instead of being
    # recomputed three separate times.  When label_df *is* the resolved frame
    # (the common case) X_label reuses X_resolved rather than transforming again.
    with _timed("TF-IDF fit"):
        vectorizer, X_full = _build_tfidf(df["text"])
    with _timed("TF-IDF transform (corpus)"):
        X_resolved = vectorizer.transform(resolved["text"].fillna(""))
        X_label = (X_resolved if label_df is resolved
                   else vectorizer.transform(label_df["text"].fillna("")))

    col_encoders = _fit_categorical_encoders(label_df, ALL_CATEGORICAL_COLUMNS)
    res_encoders = _fit_categorical_encoders(resolved, ALL_CATEGORICAL_COLUMNS) if len(resolved) else col_encoders

    with _timed("train categorisation"):
        cat_model, cat_metrics = train_categorisation(label_df, X_label)
    with _timed("train subcategorisation"):
        subcat_model, subcat_metrics = train_subcategorisation(label_df, X_label, encoders=col_encoders)
    with _timed("train priority"):
        pri_model, pri_metrics = train_priority(label_df, X_label, encoders=col_encoders)
    with _timed("train routing"):
        route_model, route_metrics = train_routing(label_df, X_label, encoders=col_encoders)
    with _timed("train resolution-time"):
        eta_model, eta_metrics = train_resolution_time(resolved, X_resolved, encoders=res_encoders)
    with _timed("train SLA-breach"):
        sla_model, sla_metrics = train_sla_breach(resolved, X_resolved, encoders=res_encoders)

    new_metrics = {
        "vectorizer": {"vocab_size": len(vectorizer.vocabulary_)},
        "cat_model": cat_metrics,
        "subcat_model": subcat_metrics,
        "pri_model": pri_metrics,
        "route_model": route_metrics,
        "eta_model": eta_metrics,
        "sla_model": sla_metrics,
        "training_rows": len(df),
        "resolved_rows": len(resolved),
        "trained_at": datetime.now().isoformat(timespec="seconds"),
        "input_file": str(input_path),
        "lgbm_used": _LGBM_AVAILABLE,
    }

    if dry_run:
        logger.info("Dry run - not saving any artefacts.")
        return new_metrics

    metadata = _load_metadata()
    decisions: Dict[str, str] = {}

    artefacts = {
        "vectorizer":  vectorizer,
        "cat_model":   cat_model,
        "subcat_model": subcat_model,
        "pri_model":   pri_model,
        "route_model": route_model,
        "eta_model":   eta_model,
        "sla_model":   sla_model,
    }

    for name, obj in artefacts.items():
        if obj is None:
            decisions[name] = f"skipped: {new_metrics[name].get('skipped', 'no model returned')}"
            stale_latest = config.MODELS_DIR / f"{name}_latest.pkl"
            if stale_latest.exists():
                stale_latest.unlink()
                logger.warning("Removed stale %s_latest.pkl (incompatible with new vectorizer)", name)
            metadata.setdefault("models", {}).pop(name, None)
            continue

        old = metadata.get("models", {}).get(name, {})
        regressed = (not force_replace) and bool(old) and not _should_replace(name, old, new_metrics[name])
        _save_versioned(obj, name)
        metadata.setdefault("models", {})[name] = new_metrics[name]
        decisions[name] = "replaced (metrics regressed; new vectorizer requires it)" if regressed else "replaced"
        if regressed:
            logger.warning("  %s: metrics regressed but replaced to stay consistent with new vectorizer.", name)

    # TF-IDF corpus vectors - reuse the resolved-corpus transform computed above
    # rather than transforming the same texts a third time.
    corpus_vectors = X_resolved
    _save_versioned(corpus_vectors, "corpus_vectors")
    _save_versioned(resolved.reset_index(drop=True), "corpus_dataframe")
    _save_versioned(col_encoders, "column_encoders")
    _save_versioned(res_encoders, "res_column_encoders")
    decisions["column_encoders"] = "saved"
    decisions["corpus_vectors"] = "rebuilt"

    # NEW: Semantic + BM25 corpus
    # Build optional sentence-embedding vectors and BM25 index for the
    # resolved-incident corpus.  Used by similarity.py for hybrid search.
    # Skipped silently if sentence-transformers / rank-bm25 are not installed
    # or EMBEDDING_MODEL_PATH is not configured.
    embedding_model_path = getattr(config, "EMBEDDING_MODEL_PATH", None)
    corpus_texts = resolved["text"].fillna("").astype(str).tolist()
    sem_results = build_and_save_extras(
        texts=corpus_texts,
        prefix="incident",
        models_dir=config.MODELS_DIR,
        model_path=str(embedding_model_path) if embedding_model_path else None,
    )
    new_metrics["semantic_corpus_built"] = sem_results["sem_ok"]
    new_metrics["bm25_corpus_built"] = sem_results["bm25_ok"]
    if sem_results["sem_ok"]:
        logger.info("Semantic corpus vectors saved for %d resolved incidents", len(resolved))
    if sem_results["bm25_ok"]:
        logger.info("BM25 index saved for %d resolved incidents", len(resolved))
    decisions["semantic_corpus"] = "built" if sem_results["sem_ok"] else "skipped (model not configured)"
    decisions["bm25_corpus"] = "built" if sem_results["bm25_ok"] else "skipped (rank-bm25 not installed)"

    _append_to_master(df)

    metadata.setdefault("history", []).append({
        "trained_at": new_metrics["trained_at"],
        "decisions": decisions,
        "metrics": new_metrics,
    })
    metadata["history"] = metadata["history"][-20:]
    _save_metadata(metadata)

    logger.info("Decisions: %s", decisions)
    return {"metrics": new_metrics, "decisions": decisions}


def _should_replace(name: str, old: Dict, new: Dict) -> bool:
    if not old:
        return True
    if name in ("cat_model", "subcat_model", "route_model"):
        old_f1 = old.get("f1_weighted") or old.get("accuracy") or 0
        new_f1 = new.get("f1_weighted") or new.get("accuracy") or 0
        return (new_f1 - old_f1) * 100 >= config.CLASSIFIER_F1_IMPROVEMENT_PCT
    if name == "pri_model":
        old_f1 = old.get("f1_macro", 0)
        new_f1 = new.get("f1_macro", 0)
        if (new_f1 - old_f1) * 100 < config.CLASSIFIER_F1_IMPROVEMENT_PCT:
            return False
        old_per = old.get("per_class_f1", {})
        new_per = new.get("per_class_f1", {})
        for cls, old_score in old_per.items():
            new_score = new_per.get(cls, 0)
            if (old_score - new_score) * 100 > config.PER_CLASS_DEGRADATION_PCT:
                return False
        return True
    if name == "eta_model":
        old_mae = old.get("mae_hours", float("inf"))
        new_mae = new.get("mae_hours", float("inf"))
        return ((old_mae - new_mae) / max(old_mae, 1e-6)) * 100 >= config.REGRESSOR_MAE_IMPROVEMENT_PCT
    if name == "sla_model":
        old_auc = old.get("roc_auc", 0) or 0
        new_auc = new.get("roc_auc", 0) or 0
        return (new_auc - old_auc) * 100 >= config.CLASSIFIER_F1_IMPROVEMENT_PCT
    if name == "vectorizer":
        return True
    return True


def _append_to_master(df: pd.DataFrame) -> None:
    if config.MASTER_TRAINING_CSV.exists():
        try:
            existing = pd.read_csv(config.MASTER_TRAINING_CSV, dtype=str, low_memory=False)
            combined = pd.concat([existing, df.astype(str)], ignore_index=True)
            combined = combined.drop_duplicates(subset=["incident_id"], keep="last")
        except Exception as exc:
            logger.warning("Could not read master file, overwriting: %s", exc)
            combined = df
    else:
        combined = df
    combined.to_csv(config.MASTER_TRAINING_CSV, index=False)
    logger.info("Master training file now contains %d rows", len(combined))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main(argv: Optional[list] = None) -> int:
    parser = argparse.ArgumentParser(description="Retrain ServiceNow ML models")
    parser.add_argument("--input", required=True, help="Path to ServiceNow export (CSV/XLSX)")
    parser.add_argument("--evaluate", action="store_true", help="Print performance report")
    parser.add_argument("--replace-if-better", action="store_true", default=True)
    parser.add_argument("--force-replace", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)

    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

    try:
        report = run_training(
            Path(args.input),
            dry_run=args.dry_run,
            force_replace=args.force_replace,
            replace_if_better=args.replace_if_better,
        )
    except Exception as exc:
        logger.exception("Training failed: %s", exc)
        return 1

    if args.evaluate:
        print(json.dumps(report, indent=2, default=str))
    else:
        print("Training complete. See models/metadata.json for details.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
