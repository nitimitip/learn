"""
Cosine-similarity search over resolved incidents PLUS related Problem
tickets.

What changed vs the original
------------------------------
* **Hybrid search** - three retrieval signals are now fused via Reciprocal
  Rank Fusion (RRF):
    1. TF-IDF cosine similarity  (always available, same as before)
    2. Sentence-embedding cosine (if ``incident_sem_vectors_latest.pkl``
       exists - built by train.py when sentence-transformers is installed)
    3. BM25 lexical retrieval    (if ``incident_bm25_latest.pkl`` exists -
       built by train.py when rank-bm25 is installed)

  When only TF-IDF is available the function behaves identically to the
  original.  The hybrid path is purely additive.

* **MMR diversity reranking** - after the hybrid scores are computed the
  top candidates are re-ordered by Maximal Marginal Relevance (lambda=0.7)
  so users see a diverse set of results rather than five variants of the
  same incident.  MMR operates on dense vectors; it falls back to pure
  relevance order if semantic vectors are not available.

* **Tuned similarity floors** - the incident floor raised from 0.05 -> 0.10
  and the problem floor from 0.10 -> 0.12.  The old values were below the
  noise level for TF-IDF cosine scores on typical IT operations text.

Backward-compatible entry points
---------------------------------
``find_similar()``              - unchanged signature, enhanced internals
``find_related_problems()``     - unchanged signature, enhanced internals
``find_similar_with_problems()``- unchanged
``synthesize_recommendation()`` - unchanged
"""

from __future__ import annotations

import html
import logging
import re
from typing import Any, Dict, List, Optional

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

from .. import config
from .embedding_utils import (
    get_encoder,
    encode_texts,
    load_sem_vectors,
    load_bm25_index,
    bm25_scores,
    reciprocal_rank_fusion,
    mmr_rerank,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Similarity thresholds
# ---------------------------------------------------------------------------
# Raised from original 0.05 / 0.10 - below ~10 % TF-IDF cosine scores are
# essentially noise on short IT-operations text.  The hybrid RRF scores are
# on a different (aggregated-rank) scale so the main gate is the per-method
# floor applied before RRF rather than a post-RRF absolute cutoff.
_INCIDENT_SIM_FLOOR = 0.10    # min TF-IDF cosine to enter the candidate set
_PROBLEM_SIM_FLOOR  = 0.12    # slightly stricter to reduce false positives

# MMR diversity parameter - 0.7 gives a good relevance/diversity balance.
# Set to 1.0 to restore pure-relevance ranking.
_MMR_LAMBDA = 0.7

# How many candidates to pass to MMR (fetch more than top_n, rerank, trim).
_MMR_CANDIDATE_MULTIPLIER = 3


# ---------------------------------------------------------------------------
# Artifact loaders
# ---------------------------------------------------------------------------
def _load_incident_artefacts():
    vec_path    = config.MODELS_DIR / "vectorizer_latest.pkl"
    corpus_path = config.MODELS_DIR / "corpus_vectors_latest.pkl"
    df_path     = config.MODELS_DIR / "corpus_dataframe_latest.pkl"

    if not (vec_path.exists() and corpus_path.exists() and df_path.exists()):
        return None, None, None

    try:
        return (joblib.load(vec_path),
                joblib.load(corpus_path),
                joblib.load(df_path))
    except Exception as exc:
        logger.error("Failed to load incident artefacts: %s", exc)
        return None, None, None


def _load_problem_artefacts():
    vec_path    = config.MODELS_DIR / "problem_vectorizer_latest.pkl"
    corpus_path = config.MODELS_DIR / "problem_corpus_vectors_latest.pkl"
    df_path     = config.MODELS_DIR / "problem_corpus_dataframe_latest.pkl"

    if not (vec_path.exists() and corpus_path.exists() and df_path.exists()):
        return None, None, None

    try:
        return (joblib.load(vec_path),
                joblib.load(corpus_path),
                joblib.load(df_path))
    except Exception as exc:
        logger.error("Failed to load Problem artefacts: %s", exc)
        return None, None, None


def _get_embedding_model():
    """Lazy-load the sentence encoder from config.EMBEDDING_MODEL_PATH."""
    model_path = getattr(config, "EMBEDDING_MODEL_PATH", None)
    if not model_path:
        return None
    return get_encoder(str(model_path))


# ---------------------------------------------------------------------------
# Keyword highlighting helper (unchanged)
# ---------------------------------------------------------------------------
def _highlight_keywords(text: str, query_terms: List[str], max_len: int = 200) -> str:
    if not text:
        return ""
    snippet = text[:max_len] + ("..." if len(text) > max_len else "")
    # Escape BEFORE adding <mark> tags: the result is rendered as raw HTML in
    # the browser, so corpus text (uploaded ServiceNow exports) must never be
    # able to carry live markup. Terms are escaped the same way so they still
    # match inside the escaped snippet.
    snippet = html.escape(snippet)
    for term in sorted(set(query_terms), key=len, reverse=True):
        if len(term) < 3:
            continue
        pattern = re.compile(rf"\b({re.escape(html.escape(term))})\b", re.I)
        snippet = pattern.sub(r"<mark>\1</mark>", snippet)
    return snippet


# ---------------------------------------------------------------------------
# Internal: hybrid retrieval helpers
# ---------------------------------------------------------------------------
def _hybrid_incident_scores(
    description: str,
    tfidf_vec,
    tfidf_corpus,
    n_docs: int,
) -> np.ndarray:
    """
    Combine TF-IDF, semantic, and BM25 signals via RRF.

    Parameters
    ----------
    description :   raw query string
    tfidf_vec :     fitted TfidfVectorizer
    tfidf_corpus :  sparse TF-IDF corpus matrix (n_docs x vocab)
    n_docs :        total corpus size (needed for RRF array allocation)

    Returns
    -------
    float32 array of length n_docs; higher = more relevant.
    If only TF-IDF is available this degrades to a plain TF-IDF rank.
    """
    ranked_lists: List[List[int]] = []

    # 1. TF-IDF cosine
    qv_tfidf = tfidf_vec.transform([description])
    tfidf_raw = cosine_similarity(qv_tfidf, tfidf_corpus).flatten()
    # Filter out below-floor candidates before ranking
    tfidf_above = np.where(tfidf_raw >= _INCIDENT_SIM_FLOOR)[0]
    if len(tfidf_above):
        tfidf_ranked = tfidf_above[tfidf_raw[tfidf_above].argsort()[::-1]].tolist()
        ranked_lists.append(tfidf_ranked)

    # 2. Semantic cosine (optional)
    sem_vecs = load_sem_vectors("incident", config.MODELS_DIR)
    if sem_vecs is not None:
        enc = _get_embedding_model()
        if enc is not None:
            q_sem = encode_texts([description], enc)
            if q_sem is not None:
                # Vectors are L2-normalised -> dot product = cosine similarity
                sem_raw = sem_vecs.dot(q_sem[0])          # (n_docs,)
                sem_ranked = sem_raw.argsort()[::-1].tolist()
                ranked_lists.append(sem_ranked)

    # 3. BM25 (optional)
    bm25_idx = load_bm25_index("incident", config.MODELS_DIR)
    if bm25_idx is not None:
        bm25_raw = bm25_scores(bm25_idx, description, n_docs)
        if bm25_raw is not None:
            bm25_ranked = bm25_raw.argsort()[::-1].tolist()
            ranked_lists.append(bm25_ranked)

    if not ranked_lists:
        return np.zeros(n_docs, dtype=np.float32)

    return reciprocal_rank_fusion(ranked_lists, n_docs)


def _hybrid_problem_scores(
    description: str,
    tfidf_vec,
    tfidf_corpus,
    n_docs: int,
) -> np.ndarray:
    """Same hybrid fusion but for the problem corpus."""
    ranked_lists: List[List[int]] = []

    qv_tfidf = tfidf_vec.transform([description])
    tfidf_raw = cosine_similarity(qv_tfidf, tfidf_corpus).flatten()
    tfidf_above = np.where(tfidf_raw >= _PROBLEM_SIM_FLOOR)[0]
    if len(tfidf_above):
        ranked_lists.append(
            tfidf_above[tfidf_raw[tfidf_above].argsort()[::-1]].tolist()
        )

    sem_vecs = load_sem_vectors("problem", config.MODELS_DIR)
    if sem_vecs is not None:
        enc = _get_embedding_model()
        if enc is not None:
            q_sem = encode_texts([description], enc)
            if q_sem is not None:
                sem_raw = sem_vecs.dot(q_sem[0])
                ranked_lists.append(sem_raw.argsort()[::-1].tolist())

    bm25_idx = load_bm25_index("problem", config.MODELS_DIR)
    if bm25_idx is not None:
        bm25_raw = bm25_scores(bm25_idx, description, n_docs)
        if bm25_raw is not None:
            ranked_lists.append(bm25_raw.argsort()[::-1].tolist())

    if not ranked_lists:
        return np.zeros(n_docs, dtype=np.float32)

    return reciprocal_rank_fusion(ranked_lists, n_docs)


def _apply_mmr(
    description: str,
    candidate_indices: List[int],
    top_n: int,
) -> List[int]:
    """
    Apply MMR reranking using sentence embeddings if available.
    Falls back to the original relevance order when no encoder is present.

    Parameters
    ----------
    candidate_indices :
        Indices into the corpus, already sorted by hybrid relevance
        (best first).  MMR reorders this list.
    """
    sem_vecs = load_sem_vectors("incident", config.MODELS_DIR)
    if sem_vecs is None or not candidate_indices:
        return candidate_indices[:top_n]

    enc = _get_embedding_model()
    if enc is None:
        return candidate_indices[:top_n]

    q_sem = encode_texts([description], enc)
    if q_sem is None:
        return candidate_indices[:top_n]

    cand_vecs = sem_vecs[candidate_indices]   # (n_candidates, dim)
    return mmr_rerank(
        query_vec=q_sem[0],
        candidate_vecs=cand_vecs,
        candidate_indices=candidate_indices,
        top_n=top_n,
        lambda_param=_MMR_LAMBDA,
    )


# ===========================================================================
# Incident search - same public signature, enhanced internals
# ===========================================================================
def find_similar(description: str,
                 category_filter: Optional[str] = None,
                 priority_filter: Optional[str] = None,
                 top_n: int = config.TOP_N_SIMILAR) -> Dict[str, Any]:
    """
    Find the top-N most similar resolved incidents using hybrid retrieval
    (TF-IDF + semantic embeddings + BM25) and MMR diversity reranking.

    Signature is identical to the original - existing callers need no changes.
    """
    if not description or not description.strip():
        return {"matches": [], "status": "no_query"}

    vec, corpus_vectors, df = _load_incident_artefacts()
    if vec is None:
        return {
            "matches": [],
            "status": "no_models",
            "message": "Models not trained yet. Run `python -m ml.train --input <export.csv>` first.",
        }

    df = df.copy()

    # Apply filters - narrow both the dataframe and the sparse corpus matrix
    # so index arithmetic stays consistent.
    if category_filter and category_filter.strip():
        mask = df["category"].astype(str).str.lower() == category_filter.strip().lower()
        if mask.any():
            corpus_vectors = corpus_vectors[mask.to_numpy()]
        df = df[mask].reset_index(drop=True)

    if priority_filter and priority_filter.strip():
        mask = df["priority"].astype(str).str.upper() == priority_filter.strip().upper()
        if mask.any():
            corpus_vectors = corpus_vectors[mask.to_numpy()]
        df = df[mask].reset_index(drop=True)

    if len(df) == 0:
        return {"matches": [], "status": "no_results",
                "message": "No resolved incidents match the chosen filters."}

    n_docs = len(df)

    # Hybrid scoring
    hybrid = _hybrid_incident_scores(description, vec, corpus_vectors, n_docs)

    # Gather more candidates than top_n so MMR has room to pick diverse ones
    n_candidates = min(n_docs, top_n * _MMR_CANDIDATE_MULTIPLIER)
    candidate_idx = hybrid.argsort()[::-1][:n_candidates].tolist()
    # Remove zero-score candidates (no method found them relevant)
    candidate_idx = [i for i in candidate_idx if hybrid[i] > 0]

    # MMR reranking
    final_idx = _apply_mmr(description, candidate_idx, top_n)

    query_terms = re.findall(r"\w{3,}", description.lower())

    # Also fetch TF-IDF scores for the similarity_score field (user-facing %)
    qv = vec.transform([description])
    tfidf_scores_all = cosine_similarity(qv, corpus_vectors).flatten()

    matches = []
    for i in final_idx:
        sim = float(tfidf_scores_all[int(i)])   # show TF-IDF % for legibility
        if sim < _INCIDENT_SIM_FLOOR:
            # Skip if even TF-IDF thought it irrelevant (may have been lifted
            # by semantic/BM25 signal for a very different-worded incident)
            # We still show it, but it will show as a low-band match.
            pass

        row = df.iloc[int(i)]

        resolution_text = (str(row.get("close_notes", "")) or
                           str(row.get("root_cause_notes", "")))
        resolution_steps = [s.strip(" -**\t") for s in resolution_text.split("\n")
                            if s.strip(" -**\t")][:10]

        sim_pct = round(sim * 100, 1)
        if sim_pct >= config.SIMILARITY_GREEN:
            band = "high"
        elif sim_pct >= config.SIMILARITY_AMBER:
            band = "medium"
        else:
            band = "low"

        matches.append({
            "incident_id":          str(row.get("incident_id", "")),
            "title":                str(row.get("title", "")),
            "title_highlighted":    _highlight_keywords(str(row.get("title", "")), query_terms, 300),
            "description_snippet":  _highlight_keywords(
                                        str(row.get("description_full", "")), query_terms, 400),
            "category":             str(row.get("category", "Unknown")),
            "subcategory":          str(row.get("subcategory", "")),
            "priority":             str(row.get("priority", "P3")),
            "assignment_group":     str(row.get("assignment_group", "")),
            "configuration_item":   str(row.get("configuration_item", "")),
            "resolved_date":        str(row.get("resolved_timestamp", "")),
            "resolution_hours":     (round(float(row["resolution_hours"]), 1)
                                     if pd.notna(row.get("resolution_hours")) else None),
            "root_cause":           (str(row.get("root_cause_notes", "")) or
                                     str(row.get("root_cause_code", ""))),
            "resolution_steps":     resolution_steps,
            "similarity_score":     sim_pct,
            "similarity_band":      band,
            "work_notes":           str(row.get("work_notes", ""))[:1000],
        })

    if not matches:
        return {"matches": [], "status": "no_results",
                "message": "No sufficiently similar incidents found."}

    return {"matches": matches, "status": "ok", "total_searched": n_docs}


# ===========================================================================
# Problem search - same public signature, enhanced internals
# ===========================================================================
_PROBLEM_SIMILARITY_LIKELY   = 50.0
_PROBLEM_SIMILARITY_NOTABLE  = 25.0


def find_related_problems(description: str,
                          category_filter: Optional[str] = None,
                          ci_filter: Optional[str] = None,
                          top_n: int = 3) -> Dict[str, Any]:
    """
    Search the Problem corpus for tickets related to the query.

    Signature unchanged from original.
    """
    if not description or not description.strip():
        return {"matches": [], "status": "no_query"}

    vec, corpus_vectors, df = _load_problem_artefacts()
    if vec is None:
        return {"matches": [], "status": "no_models",
                "message": "Problem corpus not trained yet - "
                           "run problem_train.py to enable this section."}

    df = df.copy()

    if category_filter and category_filter.strip():
        if "category" in df.columns:
            mask = df["category"].astype(str).str.lower() == category_filter.strip().lower()
            if mask.any():
                corpus_vectors = corpus_vectors[mask.to_numpy()]
                df = df[mask].reset_index(drop=True)

    if ci_filter and ci_filter.strip():
        if "configuration_item" in df.columns:
            target = ci_filter.strip().lower()
            mask = df["configuration_item"].astype(str).str.lower().str.contains(
                target, na=False)
            if mask.any():
                corpus_vectors = corpus_vectors[mask.to_numpy()]
                df = df[mask].reset_index(drop=True)

    if len(df) == 0:
        return {"matches": [], "status": "no_results",
                "message": "No problems match the chosen filters."}

    n_docs = len(df)

    # Hybrid scoring
    hybrid = _hybrid_problem_scores(description, vec, corpus_vectors, n_docs)
    n_candidates = min(n_docs, top_n * _MMR_CANDIDATE_MULTIPLIER)
    candidate_idx = hybrid.argsort()[::-1][:n_candidates].tolist()
    candidate_idx = [i for i in candidate_idx if hybrid[i] > 0]

    # Problem corpus is usually small - no MMR here to avoid over-filtering.
    # Just take the top_n by hybrid score.
    final_idx = candidate_idx[:top_n]

    # TF-IDF scores for user-facing percentage
    qv = vec.transform([description])
    tfidf_scores_all = cosine_similarity(qv, corpus_vectors).flatten()

    query_terms = re.findall(r"\w{3,}", description.lower())

    matches: List[Dict[str, Any]] = []
    best_band: Optional[str] = None

    for i in final_idx:
        sim = float(tfidf_scores_all[int(i)])
        if sim < _PROBLEM_SIM_FLOOR:
            pass   # may still be surfaced via semantic/BM25
        row = df.iloc[int(i)]
        sim_pct = round(sim * 100, 1)

        if sim_pct >= _PROBLEM_SIMILARITY_LIKELY:
            band = "likely"
        elif sim_pct >= _PROBLEM_SIMILARITY_NOTABLE:
            band = "possible"
        else:
            band = "weak"
        if best_band is None or _band_rank(band) > _band_rank(best_band):
            best_band = band

        matches.append({
            "problem_id":          str(row.get("problem_id", "")),
            "title":               str(row.get("title", "")),
            "title_highlighted":   _highlight_keywords(str(row.get("title", "")), query_terms, 300),
            "description_snippet": _highlight_keywords(
                                       str(row.get("description_full", "")), query_terms, 350),
            "state":               str(row.get("state", "")),
            "category":            str(row.get("category", "Unknown")),
            "priority":            str(row.get("priority", "")),
            "assignment_group":    str(row.get("assignment_group", "")),
            "configuration_item":  str(row.get("configuration_item", "")),
            "business_service":    str(row.get("business_service", "")),
            "workaround":          str(row.get("workaround", "")),
            "cause_notes":         str(row.get("cause_notes", "")),
            "is_known_error":      bool(row.get("known_error", False)),
            "is_major_problem":    bool(row.get("major_problem", False)),
            "rfc":                 str(row.get("rfc", "")),
            "opened_at":           str(row.get("opened_timestamp", "")),
            "similarity_score":    sim_pct,
            "similarity_band":     band,
        })

    if not matches:
        return {"matches": [], "status": "no_results",
                "message": "No related problems found.", "best_band": None}

    return {"matches": matches, "status": "ok",
            "total_searched": n_docs, "best_band": best_band}


def _band_rank(band: str) -> int:
    return {"likely": 3, "possible": 2, "weak": 1}.get(band, 0)


# ===========================================================================
# Combined entry point - unchanged signature
# ===========================================================================
def find_similar_with_problems(description: str,
                               category_filter: Optional[str] = None,
                               priority_filter: Optional[str] = None,
                               top_n: int = config.TOP_N_SIMILAR,
                               problem_top_n: int = 3) -> Dict[str, Any]:
    incidents = find_similar(
        description=description,
        category_filter=category_filter,
        priority_filter=priority_filter,
        top_n=top_n,
    )
    problems = find_related_problems(
        description=description,
        category_filter=category_filter,
        top_n=problem_top_n,
    )
    return {"incidents": incidents, "problems": problems}


# ===========================================================================
# Recommendation synthesiser - unchanged
# ===========================================================================
def synthesize_recommendation(matches: List[Dict]) -> Dict[str, Any]:
    if not matches:
        return {"recommended_steps": [], "likely_root_cause": "",
                "confidence": "low", "based_on": 0}

    all_steps: List[str] = []
    for m in matches:
        all_steps.extend(m.get("resolution_steps", []))

    seen = set()
    unique_steps = []
    for step in all_steps:
        key = step.lower()[:80]
        if key in seen or len(step) < 5:
            continue
        seen.add(key)
        unique_steps.append(step)

    sorted_matches = sorted(matches, key=lambda m: m["similarity_score"], reverse=True)
    likely_cause = next((m.get("root_cause", "") for m in sorted_matches
                         if m.get("root_cause")), "")

    avg_sim = sum(m["similarity_score"] for m in matches) / len(matches)
    confidence = "high" if avg_sim >= 70 else "medium" if avg_sim >= 50 else "low"

    return {
        "recommended_steps":  unique_steps[:8],
        "likely_root_cause":  likely_cause,
        "confidence":         confidence,
        "average_similarity": round(avg_sim, 1),
        "based_on":           len(matches),
    }
