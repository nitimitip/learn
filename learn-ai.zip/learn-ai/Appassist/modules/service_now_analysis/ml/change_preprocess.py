"""
Cleaning, normalisation, and feature engineering for ServiceNow Change
Request exports. Used during quarterly retraining and inference.

Mirrors preprocess.py for incidents but with CR-specific normalisation.

Null-fill persistence
---------------------
``save_null_fills`` / ``load_null_fills`` are re-exported from
``embedding_utils`` so callers can do::

    from .change_preprocess import save_null_fills, load_null_fills
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from .. import config
from .change_column_mapper import map_columns
from .preprocess import (
    _to_bool, _to_numeric, parse_timestamp, load_export,
)

# Re-export so callers can import from one place.
from .embedding_utils import save_null_fills, load_null_fills  # noqa: F401

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Normalisation
# ---------------------------------------------------------------------------
_TYPE_MAP = {
    "standard":  "Standard",  "std": "Standard",
    "normal":    "Normal",
    "emergency": "Emergency", "e": "Emergency", "emerg": "Emergency",
}

def normalise_type(val) -> str:
    if val is None or (isinstance(val, float) and np.isnan(val)):
        return "Normal"
    s = str(val).strip().lower()
    return _TYPE_MAP.get(s, str(val).strip().title() or "Normal")


_RISK_MAP = {
    "high":      "High", "1": "High", "h": "High",
    "moderate":  "Moderate", "medium": "Moderate", "med": "Moderate",
    "2": "Moderate", "m": "Moderate",
    "low":       "Low", "3": "Low", "l": "Low",
    "very low":  "Low", "minimal": "Low",
}

def normalise_risk(val) -> str:
    if val is None or (isinstance(val, float) and np.isnan(val)):
        return "Moderate"
    s = str(val).strip().lower()
    return _RISK_MAP.get(s, str(val).strip().title() or "Moderate")


_STATE_MAP = {
    "new": "New", "open": "New", "draft": "New",
    "assess": "Assess", "assessment": "Assess",
    "authorize": "Authorize", "authorise": "Authorize", "approve": "Authorize",
    "scheduled": "Scheduled",
    "implement": "Implement", "implementing": "Implement", "in progress": "Implement",
    "review": "Review",
    "closed": "Closed", "closed complete": "Closed",
    "closed successful": "Closed Successful",
    "closed unsuccessful": "Closed Unsuccessful",
    "closed incomplete": "Closed Incomplete",
    "cancelled": "Cancelled", "canceled": "Cancelled",
}

def normalise_state(val) -> str:
    if val is None:
        return "Unknown"
    s = str(val).strip().lower()
    return _STATE_MAP.get(s, str(val).strip().title() or "Unknown")


# ---------------------------------------------------------------------------
# Null handling
# ---------------------------------------------------------------------------
TEXT_COLUMNS = ["title", "description_full", "implementation_plan",
                "backout_plan", "test_plan", "change_plan", "justification",
                "close_notes", "risk_impact_analysis"]
CATEGORICAL_COLUMNS = ["type", "category", "subcategory", "priority", "risk",
                       "impact", "urgency", "state", "phase", "approval",
                       "assignment_group", "configuration_item",
                       "business_service", "service_offering", "environment",
                       "company", "location", "chg_model", "scope"]
NUMERIC_COLUMNS = ["business_duration", "calendar_duration", "reassignment_count",
                   "actual_outage", "risk_value"]
BOOLEAN_COLUMNS = ["made_sla", "cab_required", "outside_maint_sched"]
TIMESTAMP_COLUMNS = ["opened_timestamp", "start_timestamp", "end_timestamp",
                     "work_start_timestamp", "work_end_timestamp",
                     "closed_timestamp", "updated_timestamp", "cab_date"]


def compute_null_fills(df: pd.DataFrame) -> dict:
    """Mode for cats, median for nums, computed only on training rows."""
    fills: dict = {}
    for col in CATEGORICAL_COLUMNS:
        if col not in df.columns:
            continue
        s = df[col].astype("object")
        mode = s.mode(dropna=True)
        fills[col] = mode.iloc[0] if (not mode.empty and s.notna().any()) else "Unknown"
    for col in NUMERIC_COLUMNS:
        if col not in df.columns:
            continue
        coerced = df[col].apply(_to_numeric)
        med = coerced.median()
        fills[col] = float(med) if pd.notna(med) else 0.0
    return fills


def handle_nulls(df: pd.DataFrame,
                 fill_values: Optional[dict] = None) -> pd.DataFrame:
    df = df.copy()
    if fill_values is None:
        fill_values = compute_null_fills(df)

    for col in TEXT_COLUMNS:
        if col in df.columns:
            df[col] = df[col].fillna("").astype(str)

    for col in CATEGORICAL_COLUMNS:
        if col not in df.columns:
            continue
        fill_val = fill_values.get(col, "Unknown")
        s = df[col].astype("object")
        df[col] = s.fillna(fill_val).astype(str).replace({"": "Unknown", "nan": "Unknown"})

    for col in NUMERIC_COLUMNS:
        if col not in df.columns:
            continue
        df[col] = df[col].apply(_to_numeric)
        df[col] = df[col].fillna(fill_values.get(col, 0.0))

    for col in BOOLEAN_COLUMNS:
        if col in df.columns:
            df[col] = df[col].apply(_to_bool)

    for col in TIMESTAMP_COLUMNS:
        if col in df.columns:
            df[col] = df[col].apply(parse_timestamp)

    return df


# ---------------------------------------------------------------------------
# Feature engineering
# ---------------------------------------------------------------------------
def add_text_features(df: pd.DataFrame) -> pd.DataFrame:
    """Concatenate title + description into a 'text' column for TF-IDF."""
    df = df.copy()
    title = df.get("title", pd.Series([""] * len(df))).fillna("").astype(str)
    desc = df.get("description_full", pd.Series([""] * len(df))).fillna("").astype(str)
    df["text"] = (title + " " + desc).str.strip().str.replace(r"\s+", " ", regex=True)
    df["description_length"] = df["text"].str.len()
    return df


# ---------------------------------------------------------------------------
# Successful-CR filter
# ---------------------------------------------------------------------------
_FAILURE_STATE_RE = re.compile(
    r"unsuccessful|incomplete|failed|cancel{1,2}ed|withdrawn", re.I)
_FAILURE_NOTES_RE = re.compile(
    r"\b(?:roll(?:ed)?\s*back|rollback|back(?:ed)?\s*out|"
    r"reverted|aborted|change\s+failed|did\s+not\s+complete|"
    r"deployment\s+failed|unable\s+to\s+complete)\b", re.I)


def is_successful_change(row) -> bool:
    """
    True if the CR closed cleanly (no failure / rollback / cancellation
    indicators and state is a closed-successful variant).
    """
    state = str(row.get("state", "")).lower()
    close_code = str(row.get("close_code", "")).lower()
    close_notes = str(row.get("close_notes", "")).lower()

    if _FAILURE_STATE_RE.search(state) or _FAILURE_STATE_RE.search(close_code):
        return False
    if _FAILURE_NOTES_RE.search(close_notes):
        return False
    return ("closed" in state and "successful" in state) \
        or ("closed" in state and "complete" in state) \
        or state == "closed"


# ---------------------------------------------------------------------------
# Top-level pipeline
# ---------------------------------------------------------------------------
def preprocess(raw_df: pd.DataFrame, *, drop_invalid: bool = True,
               fill_values: Optional[dict] = None) -> pd.DataFrame:
    """
    Run the full CR preprocessing pipeline.

    Parameters
    ----------
    fill_values :
        Training-time null fills loaded via
        ``load_null_fills(config.MODELS_DIR / "cr_null_fills.json")``.
        Pass None to compute fills from the batch (inference fallback).
    """
    df = map_columns(raw_df)

    for col, fn in [("type", normalise_type),
                    ("risk", normalise_risk),
                    ("state", normalise_state)]:
        if col in df.columns:
            df[col] = df[col].apply(fn)

    df = handle_nulls(df, fill_values=fill_values)
    df = add_text_features(df)

    if drop_invalid:
        before = len(df)
        df = df[df["change_id"].astype(str).str.strip() != ""]
        df = df[df["change_id"].astype(str).str.lower() != "nan"]
        df = df[df["title"].str.strip() != ""]
        df = df.drop_duplicates(subset=["change_id"], keep="last").reset_index(drop=True)
        dropped = before - len(df)
        if dropped:
            logger.info("Dropped %d invalid/duplicate CR rows during preprocessing",
                        dropped)
    return df
