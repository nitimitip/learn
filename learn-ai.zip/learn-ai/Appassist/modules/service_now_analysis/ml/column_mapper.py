"""
Map raw ServiceNow export columns to the standardised feature names used
internally by the ML pipeline.

The mapper is deliberately tolerant: missing columns are filled with None
rather than raising, so the rest of the pipeline can decide how to handle
them. Critical-column validation is the caller's job.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Tuple

import pandas as pd

logger = logging.getLogger(__name__)


# Internal feature name -> list of candidate ServiceNow column names
# (first match wins). This mirrors the spec but allows fallbacks for
# instances where the custom field naming differs.
COLUMN_MAPPING: Dict[str, List[str]] = {
    "incident_id":         ["number"],
    "title":               ["short_description"],
    "description_full":    ["description"],
    "category":            ["u_tenant_category", "category"],
    "subcategory":         ["u_tenant_subcategory", "subcategory"],
    "priority":            ["priority"],
    "state":               ["state"],
    "incident_state":      ["incident_state"],
    "assignment_group":    ["assignment_group"],
    "assigned_to":         ["assigned_to"],
    "opened_timestamp":    ["opened_at", "sys_created_on", "u_reported_date"],
    "resolved_timestamp":  ["resolved_at"],
    "closed_timestamp":    ["closed_at"],
    "updated_timestamp":   ["sys_updated_on"],
    # "Off hold date" is the display header ServiceNow uses for this field on
    # incident / service-request exports; the CSV field name is due_date. Both
    # land here so the Off-hold-today report works from either flavour.
    "due_date":            ["due_date", "off_hold_date"],
    "sla_due":             ["sla_due"],
    "caller":              ["caller_id"],
    "opened_by":           ["opened_by"],
    "impact":              ["impact"],
    "urgency":             ["urgency"],
    "severity":            ["severity"],
    "configuration_item":  ["cmdb_ci"],
    "business_service":    ["business_service"],
    "company":             ["company"],
    "location":            ["location"],
    "environment":         ["u_environment"],
    "work_notes":          ["work_notes"],
    "comments":            ["comments"],
    "close_notes":         ["close_notes"],
    "actions_taken":       ["actions_taken"],
    "root_cause_code":     ["u_cause_code"],
    "root_cause_notes":    ["u_cause_notes"],
    "resolution_category": ["u_tenant_resolution_category"],
    "resolution_code":     ["u_tenant_resolution_code"],
    "made_sla":            ["made_sla", "x_caukp_slc_sla_met"],
    "business_duration":   ["business_duration"],
    "calendar_duration":   ["calendar_duration"],
    "reassignment_count":  ["reassignment_count"],
    "reopen_count":        ["reopen_count"],
    "major_incident_flag": ["u_major_incident", "u_dora_mim"],
    "vendor":              ["u_vendor"],
    "vendor_ticket":       ["u_vendor_ticket_number"],
    "correlation_id":      ["correlation_id"],
    "contact_type":        ["contact_type"],
    "time_worked":         ["time_worked"],
    "escalation":          ["escalation"],
    "clients_impacted":    ["u_clients_impacted", "u_clients_affected"],
    "impacted_locations":  ["u_impacted_locations"],
}

# Minimum columns the pipeline needs to do anything meaningful.
REQUIRED_RAW_COLUMNS = {"number", "short_description", "state", "opened_at"}

# Columns that are recommended but not strictly required.
RECOMMENDED_RAW_COLUMNS = {
    "u_tenant_category", "priority", "assignment_group",
    "resolved_at", "close_notes", "description",
}


def map_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Project the raw export DataFrame down to the internal feature names.

    Missing source columns become None columns so downstream code can
    use a single naming convention.
    """
    mapped = pd.DataFrame(index=df.index)

    for feature, candidates in COLUMN_MAPPING.items():
        source_col = next((c for c in candidates if c in df.columns), None)
        if source_col is not None:
            mapped[feature] = df[source_col]
        else:
            mapped[feature] = None

    # Preserve incident_id as string for safe joining later.
    if "incident_id" in mapped.columns:
        mapped["incident_id"] = mapped["incident_id"].astype(str)

    logger.info("Mapped %d raw columns -> %d internal features",
                len(df.columns), len(mapped.columns))
    return mapped


def validate_columns(df: pd.DataFrame) -> Tuple[bool, List[str], List[str]]:
    """
    Check whether the raw DataFrame has the required and recommended columns.

    Returns
    -------
    (ok, missing_required, missing_recommended)
    """
    cols = set(df.columns)
    missing_required = sorted(REQUIRED_RAW_COLUMNS - cols)
    missing_recommended = sorted(RECOMMENDED_RAW_COLUMNS - cols)
    return (len(missing_required) == 0, missing_required, missing_recommended)


def column_coverage_report(df: pd.DataFrame) -> Dict[str, Dict]:
    """
    Per internal-feature report: was the source column present, what % populated.

    Useful for diagnosing data-quality issues in the upload screen.
    """
    report: Dict[str, Dict] = {}
    for feature, candidates in COLUMN_MAPPING.items():
        source = next((c for c in candidates if c in df.columns), None)
        if source is None:
            report[feature] = {"source": None, "present": False, "populated_pct": 0.0}
        else:
            populated = df[source].notna().sum()
            pct = (populated / max(len(df), 1)) * 100
            report[feature] = {
                "source": source,
                "present": True,
                "populated_pct": round(float(pct), 1),
            }
    return report
