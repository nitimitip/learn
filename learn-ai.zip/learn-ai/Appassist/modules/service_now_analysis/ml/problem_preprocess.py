"""
Preprocessing for ServiceNow Problem ticket exports.

Builds a corpus of problems (focused on open / known-error / active states)
that the enhanced similar-incident search can query alongside the
incident corpus, so users see when an issue is part of a known Problem.

Null-fill persistence
---------------------
``save_null_fills`` / ``load_null_fills`` are re-exported from
``embedding_utils`` so callers can do::

    from .problem_preprocess import save_null_fills, load_null_fills
"""

from __future__ import annotations

import logging
from typing import Optional

import pandas as pd

from .. import config
from .problem_column_mapper import map_columns
from .preprocess import _to_bool, _to_numeric, parse_timestamp, load_export

# Re-export so callers can import from one place.
from .embedding_utils import save_null_fills, load_null_fills  # noqa: F401

logger = logging.getLogger(__name__)


# States that are still 'live' - these are the problems we want to surface
# when a user searches for a similar incident.
ACTIVE_PROBLEM_STATES = {
    "new", "open", "active", "assess", "root cause analysis",
    "fix in progress", "pending", "on hold", "known error",
    "in progress", "investigating",
}


TEXT_COLUMNS = ["title", "description_full", "cause_notes", "close_notes",
                "fix_notes", "workaround"]
CATEGORICAL_COLUMNS = ["category", "subcategory", "priority", "impact", "urgency",
                       "state", "assignment_group", "configuration_item",
                       "business_service", "environment", "company", "location",
                       "resolution_code"]
NUMERIC_COLUMNS = ["reassignment_count", "reopen_count"]
BOOLEAN_COLUMNS = ["made_sla", "known_error", "major_problem"]
TIMESTAMP_COLUMNS = ["opened_timestamp", "resolved_timestamp",
                     "closed_timestamp", "updated_timestamp", "fix_at"]


def compute_null_fills(df: pd.DataFrame) -> dict:
    fills: dict = {}
    for col in CATEGORICAL_COLUMNS:
        if col not in df.columns:
            continue
        s = df[col].astype("object")
        mode = s.mode(dropna=True)
        fills[col] = mode.iloc[0] if (not mode.empty and s.notna().any()) else "Unknown"
    for col in NUMERIC_COLUMNS:
        if col not in df.columns:
            continue
        coerced = df[col].apply(_to_numeric)
        med = coerced.median()
        fills[col] = float(med) if pd.notna(med) else 0.0
    return fills


def handle_nulls(df: pd.DataFrame,
                 fill_values: Optional[dict] = None) -> pd.DataFrame:
    df = df.copy()
    if fill_values is None:
        fill_values = compute_null_fills(df)

    for col in TEXT_COLUMNS:
        if col in df.columns:
            df[col] = df[col].fillna("").astype(str)

    for col in CATEGORICAL_COLUMNS:
        if col not in df.columns:
            continue
        fill_val = fill_values.get(col, "Unknown")
        s = df[col].astype("object")
        df[col] = s.fillna(fill_val).astype(str).replace({"": "Unknown", "nan": "Unknown"})

    for col in NUMERIC_COLUMNS:
        if col not in df.columns:
            continue
        df[col] = df[col].apply(_to_numeric).fillna(fill_values.get(col, 0.0))

    for col in BOOLEAN_COLUMNS:
        if col in df.columns:
            df[col] = df[col].apply(_to_bool)

    for col in TIMESTAMP_COLUMNS:
        if col in df.columns:
            df[col] = df[col].apply(parse_timestamp)
    return df


def add_text_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    title = df.get("title", pd.Series([""] * len(df))).fillna("").astype(str)
    desc = df.get("description_full", pd.Series([""] * len(df))).fillna("").astype(str)
    cause = df.get("cause_notes", pd.Series([""] * len(df))).fillna("").astype(str)
    # Combine title + description + cause notes - cause notes are particularly
    # valuable for matching incidents to a known problem.
    df["text"] = (title + " " + desc + " " + cause).str.strip().str.replace(
        r"\s+", " ", regex=True)
    df["description_length"] = df["text"].str.len()
    return df


def is_active_problem(row) -> bool:
    """Filter for problems we want to surface in the search."""
    state = str(row.get("state", "")).strip().lower()
    return state in ACTIVE_PROBLEM_STATES


def preprocess(raw_df: pd.DataFrame, *, drop_invalid: bool = True,
               fill_values: Optional[dict] = None,
               only_active: bool = False) -> pd.DataFrame:
    """
    Run the full Problem preprocessing pipeline.

    Parameters
    ----------
    fill_values :
        Training-time null fills loaded via
        ``load_null_fills(config.MODELS_DIR / "problem_null_fills.json")``.
        Pass None to compute fills from the batch (inference fallback).
    """
    df = map_columns(raw_df)
    df = handle_nulls(df, fill_values=fill_values)
    df = add_text_features(df)

    if drop_invalid:
        before = len(df)
        df = df[df["problem_id"].astype(str).str.strip() != ""]
        df = df[df["problem_id"].astype(str).str.lower() != "nan"]
        df = df[df["title"].str.strip() != ""]
        df = df.drop_duplicates(subset=["problem_id"], keep="last").reset_index(drop=True)
        dropped = before - len(df)
        if dropped:
            logger.info("Dropped %d invalid/duplicate Problem rows", dropped)

    if only_active:
        before = len(df)
        df = df[df.apply(is_active_problem, axis=1)].reset_index(drop=True)
        logger.info("Filtered to %d active problems (was %d)", len(df), before)

    return df
