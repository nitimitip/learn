"""
open_incident_email.py - professional per-assignment-group summary emails
for open ServiceNow items (incidents AND service requests).

Every builder/dispatcher takes an ``item_label`` ("incident" - the default -
or "service request") that drives all user-visible wording, so the two kinds
produce **separate, clearly-labelled emails**. Separate (rather than one
consolidated email) is deliberate: incident and SR lists are uploaded
independently and may differ in freshness, so combining them risks pairing a
fresh list with a stale one; distinct subjects also let recipients filter
and route each stream.

Design language and Outlook-safety rules are intentionally the same as the
MIMP / to-do / health-check emails so this looks like a sibling product:

  * 100% nested <table> layout - no <div>s for structure.
  * State is a tint fill plus a hairline on ALL FOUR sides - never a
    coloured stripe down one edge (matches the web theme).
  * Labels are PRE-UPPERCASED in Python (Word ignores text-transform).
  * Solid colours only; bgcolor attributes accompany every background-color.
  * A multipart/alternative plain-text part is included for deliverability.

The email is built from a per-group report (see
``open_incidents.compute_group_report``) and rendered as distinct sections:

  * SUMMARY BY PRIORITY      - P1-P4 stat cards (P1 red ... P4 grey).
  * DUE OFF HOLD TODAY       - Off hold date falls on the send date (teal).
  * LONG-PENDING INCIDENTS   - >7 / >15 / >1 month counts (amber) + oldest list.
  * NO UPDATE PROVIDED       - work notes empty or last update > 6 days (red).
  * ASSIGNED TO MEMBER       - open incidents per member (blue).

The off-hold section is resolved against the date the digest is SENT, not the
date the file was uploaded: compute_group_report recomputes it per call, so a
scheduled digest running against a two-day-old upload still lists the items
that come off hold that morning.

Sending uses the same SMTP convention the rest of the app uses
(SMTP_SERVER / SMTP_PORT / EMAIL_FROM). The web layer decides who may trigger a
send (admins only); this module just formats and delivers.

In addition to the per-group emails, an optional **management summary** can be
enabled under Manage Members (OpenIncidentEmailSettings): one consolidated
email covering every assignment group, with a professional Excel workbook
attached (Summary sheet + one detail sheet per group - see
utils/open_incident_excel.py). It is sent on every FULL digest run (the
"Email all groups" button and the scheduled afternoon digest), never on a
single-group send.
"""

from __future__ import annotations

import logging
import os
import smtplib
from datetime import datetime
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# SMTP - shared convention with password_reset.py / the rest of the app.
_SMTP_SERVER = os.environ.get("SMTP_SERVER", "mail1.northernpowergrid.com")
_SMTP_PORT = int(os.environ.get("SMTP_PORT", "25"))
_EMAIL_FROM = os.environ.get("EMAIL_FROM", "NPgAppAssist@northernpowergrid.com")

# NPG palette - imported from the shared email theme so a colour is
# defined ONCE for the whole application (email_theme.py). The private
# aliases keep this module's f-strings unchanged.
from email_theme import (                             # noqa: E402
    NPG_RED as _NPG_RED, NPG_DARK as _NPG_DARK, NPG_LIGHT as _NPG_LIGHT,
    NPG_BORDER as _NPG_BORDER, NPG_TEXT as _NPG_TEXT,
    NPG_TEXT_MUTED as _NPG_MUTED, CHIP_BG as _CHIP_BG,
    FONT as _FONT,
)

# Masthead and footer come from the shared NPG theme (email_theme.py): a flat
# maroon banner closed by a graphite rule, and a graphite footer band. Flat, not
# a gradient - the Word engine behind desktop Outlook cannot render one.
from email_theme import hero_rows, footer_rows

# Per-priority accent colours for the stat cards.
_PRIORITY_CARD = {
    "P1": ("#FEF2F2", _NPG_RED, "#991B1B"),
    "P2": ("#FFFBEB", "#B45309", "#92400E"),
    "P3": ("#EFF6FF", "#1D4ED8", "#1E3A8A"),
    "P4": ("#F8FAFC", "#475569", "#475569"),
}

# Section palettes.
_AMBER = {"border": "#F59E0B", "tint": "#FFFBEB", "tint_border": "#FDE68A", "fg": "#92400E"}
_RED = {"border": _NPG_RED, "tint": "#FEF2F2", "tint_border": "#FECACA", "fg": "#991B1B"}
_BLUE = {"border": "#2563EB", "tint": "#EFF6FF", "tint_border": "#BFDBFE", "fg": "#1D4ED8"}
_TEAL = {"border": "#0D9488", "tint": "#F0FDFA", "tint_border": "#CCFBF1", "fg": "#0F766E"}
_NEUTRAL = {"border": _NPG_DARK, "tint": "#F8FAFC", "tint_border": _NPG_BORDER, "fg": _NPG_TEXT}


# ---------------------------------------------------------------------------
# Outlook-safe building blocks
# ---------------------------------------------------------------------------
def _esc(s: Any) -> str:
    return (str(s if s is not None else "")
            .replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _badge(bg: str, fg: str, label: str) -> str:
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="display:inline-table;">'
        f'<tr><td bgcolor="{bg}" style="background-color:{bg};padding:5px 12px;font-family:{_FONT};'
        f'font-size:11px;font-weight:bold;color:{fg};mso-line-height-rule:exactly;line-height:14px;'
        f'letter-spacing:1px;border-collapse:separate;border-spacing:0;border-radius:20px;">{label}</td></tr></table>'
    )


def _stat_card(bg: str, big_fg: str, label_fg: str, value: Any, label: str) -> str:
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
        f'bgcolor="{bg}" style="background-color:{bg};border:1px solid {_NPG_BORDER};border-collapse:separate;border-spacing:0;border-radius:10px;">'
        f'<tr><td align="center" style="padding:12px 6px;font-family:{_FONT};">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0">'
        f'<tr><td align="center" style="font-size:26px;font-weight:bold;color:{big_fg};'
        f'letter-spacing:-0.4px;mso-line-height-rule:exactly;line-height:30px;">{value}</td></tr>'
        f'<tr><td align="center" style="font-size:10px;font-weight:bold;color:{label_fg};'
        f'mso-line-height-rule:exactly;line-height:13px;letter-spacing:1px;padding-top:5px;">{label}</td></tr>'
        f'</table></td></tr></table>'
    )


def _section_header(label: str, count_text: str, palette: dict) -> str:
    return (
        f'<tr><td style="border-bottom:1px solid {palette["border"]};padding:0 0 8px;">'
        f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        f'<td style="font-family:{_FONT};font-size:13px;font-weight:bold;color:{palette["fg"]};'
        f'letter-spacing:0.4px;mso-line-height-rule:exactly;line-height:17px;">{label}</td>'
        f'<td align="right" style="font-family:{_FONT};font-size:11px;font-weight:bold;color:{_NPG_MUTED};'
        f'mso-line-height-rule:exactly;line-height:15px;">{count_text}</td>'
        f'</tr></table></td></tr>'
    )


def _data_table(headers: List[str], rows: List[List[str]], aligns: List[str] | None = None) -> str:
    aligns = aligns or ["left"] * len(headers)
    head = "".join(
        f'<th align="{aligns[i]}" style="padding:7px 10px;font-family:{_FONT};font-size:10px;'
        f'font-weight:bold;color:{_NPG_MUTED};border-bottom:1px solid {_NPG_BORDER};letter-spacing:.4px;'
        f'text-transform:uppercase;">{_esc(h)}</th>'
        for i, h in enumerate(headers)
    )
    body = ""
    for r in rows:
        tds = "".join(
            f'<td align="{aligns[i]}" style="padding:7px 10px;font-family:{_FONT};font-size:12px;'
            f'color:{_NPG_TEXT};border-bottom:1px solid {_NPG_LIGHT};mso-line-height-rule:exactly;'
            f'line-height:16px;">{c}</td>'
            for i, c in enumerate(r)
        )
        body += f"<tr>{tds}</tr>"
    return (
        f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
        f'bgcolor="#FFFFFF" style="background-color:#FFFFFF;border:1px solid {_NPG_BORDER};border-collapse:separate;border-spacing:0;border-radius:10px;">'
        f'<tr bgcolor="{_NPG_LIGHT}" style="background-color:{_NPG_LIGHT};">{head}</tr>{body}</table>'
    )


def _section_block(header_html: str, body_html: str) -> str:
    return (
        f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
        f'style="margin-bottom:20px;">{header_html}'
        f'<tr><td style="padding-top:12px;">{body_html}</td></tr></table>'
    )


# ---------------------------------------------------------------------------
# Item-kind wording
# ---------------------------------------------------------------------------
def _plural(item_label: str) -> str:
    return f"{item_label}s"


def _off_hold(report: Dict[str, Any]) -> Dict[str, Any]:
    """The report's off-hold-today block, with safe defaults.

    Read through ``.get`` rather than indexed: a report dict handed in by an
    older caller (or a fixture) must degrade to an empty section rather than
    take the whole digest down with a KeyError.
    """
    oh = report.get("off_hold") or {}
    return {
        "date_label": oh.get("date_label", datetime.now().strftime("%d %b %Y")),
        "count": oh.get("count", 0),
        "rows": oh.get("rows") or [],
        "total_dated": oh.get("total_dated", 0),
        "column_present": oh.get("column_present", False),
    }


# ---------------------------------------------------------------------------
# Subject / plain-text
# ---------------------------------------------------------------------------
def _subject(group: str, report: Dict[str, Any],
             item_label: str = "incident") -> str:
    ab = report["ageing_bands"]
    tail = f", {ab['over_7']} over 7 days" if ab.get("over_7") else ""
    return (f"[App Assist] Open {item_label} summary - {group} "
            f"({report['total_open']} open{tail})")


def build_plaintext(group: str, report: Dict[str, Any],
                    item_label: str = "incident") -> str:
    plural = _plural(item_label)
    pc = report["priority_counts"]
    ab = report["ageing_bands"]
    oh = _off_hold(report)
    lines = [
        f"NPG APP ASSIST - OPEN {item_label.upper()} SUMMARY",
        "=" * 56,
        f"Assignment group: {group}",
        f"Generated: {report['generated_at']}",
        "",
        f"Total open {plural}: {report['total_open']}    (avg age {report['avg_days_open']} days)",
        "",
        "SUMMARY BY PRIORITY",
        "-" * 56,
        f"  P1 Critical: {pc['P1']}   P2 High: {pc['P2']}   "
        f"P3 Moderate: {pc['P3']}   P4 Low: {pc['P4']}",
        "",
        f"DUE OFF HOLD TODAY  ({oh['date_label']})",
        "-" * 56,
    ]
    if oh["rows"]:
        for r in oh["rows"]:
            lines.append(f"    {r['number']:<12} [{r['priority']}] off hold "
                         f"{r['off_hold_time'] or '--:--':>5}  "
                         f"{r['short_description'][:52]}")
    elif oh["column_present"]:
        lines.append(f"    None - no {plural} come off hold today.")
    else:
        lines.append("    Not reported - this upload carried no Off hold date values.")
    lines += [
        "",
        f"LONG-PENDING {plural.upper()}",
        "-" * 56,
        f"  > 7 days: {ab['over_7']}    > 15 days: {ab['over_15']}    > 1 month: {ab['over_30']}",
    ]
    for r in report["table_rows"][:10]:
        lines.append(f"    {r['number']:<12} [{r['priority']}] {r['duration']:>12}  "
                     f"{r['short_description'][:60]}")
    lines += ["", "ASSIGNED TO MEMBER", "-" * 56]
    for a in report["assigned_breakdown"]:
        lines.append(f"    {a['name']:<32} {a['count']}")
    lines += [
        "",
        f"NO UPDATE PROVIDED  ({report['no_update_count']} - work notes empty or last update > 6 days)",
        "-" * 56,
    ]
    for r in report["no_update_rows"][:10]:
        dsu = r["days_since_update"]
        dsu_txt = f"{dsu}d since update" if dsu is not None else "no update recorded"
        lines.append(f"    {r['number']:<12} [{r['priority']}] {dsu_txt:>18}  "
                     f"{r['short_description'][:55]}")
    lines += ["", f"Please review and progress the ageing {plural} above.",
              "NPG App Assist - ServiceNow Analysis - Generated automatically - Do not reply"]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# HTML
# ---------------------------------------------------------------------------
def build_html(group: str, report: Dict[str, Any],
               item_label: str = "incident") -> str:
    plural = _plural(item_label)
    pc = report["priority_counts"]
    ab = report["ageing_bands"]
    total = report["total_open"]
    oldest = report.get("oldest") or {}
    oh = _off_hold(report)

    # ---- Priority summary (stat cards) ----
    def _card(pri: str) -> str:
        bg, big, lab = _PRIORITY_CARD[pri]
        return _stat_card(bg, big, lab, pc[pri], pri)

    priority_cards = (
        f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        f'<td class="stat-cell" width="20%" valign="top" style="padding-right:5px;">'
        f'{_stat_card("#EEF2F7", _NPG_DARK, _NPG_MUTED, total, "TOTAL OPEN")}</td>'
        f'<td class="stat-cell" width="20%" valign="top" style="padding:0 3px;">{_card("P1")}</td>'
        f'<td class="stat-cell" width="20%" valign="top" style="padding:0 3px;">{_card("P2")}</td>'
        f'<td class="stat-cell" width="20%" valign="top" style="padding:0 3px;">{_card("P3")}</td>'
        f'<td class="stat-cell" width="20%" valign="top" style="padding-left:5px;">{_card("P4")}</td>'
        f'</tr></table>'
    )
    priority_section = _section_block(
        _section_header("SUMMARY BY PRIORITY", f"{total} open", _NEUTRAL),
        priority_cards,
    )

    # ---- Due off hold today (teal) ----
    # Placed directly under the priority cards: it is the only section that is
    # actionable TODAY, so it must not sit below the long ageing tables.
    if oh["rows"]:
        off_hold_body = _data_table(
            ["Number", "Pri", "Short description", "Assigned to", "Off hold"],
            [[f'<strong>{_esc(r["number"])}</strong>', _esc(r["priority"]),
              _esc(r["short_description"][:70]), _esc(r["assigned_to"]),
              f'<strong style="color:{_TEAL["fg"]};">{_esc(r["off_hold_at"])}</strong>']
             for r in oh["rows"]],
            aligns=["left", "left", "left", "left", "right"],
        )
    else:
        note = (f"No {plural} come off hold today."
                if oh["column_present"]
                else "This upload carried no Off hold date values, so nothing "
                     "can be listed here.")
        off_hold_body = (
            f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
            f'bgcolor="{_TEAL["tint"]}" style="background-color:{_TEAL["tint"]};'
            f'border:1px solid {_TEAL["tint_border"]};border-collapse:separate;border-spacing:0;border-radius:10px;">'
            f'<tr><td style="padding:12px 14px;font-family:{_FONT};font-size:12px;'
            f'color:{_TEAL["fg"]};">{_esc(note)}</td></tr></table>')
    off_hold_section = _section_block(
        _section_header("DUE OFF HOLD TODAY",
                        f'{oh["date_label"]} &middot; {oh["count"]} of '
                        f'{oh["total_dated"]} dated', _TEAL),
        off_hold_body,
    )

    # ---- Long-pending incidents (amber) ----
    ageing_strip = (
        f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
        f'style="margin-bottom:12px;"><tr>'
        f'<td class="stat-cell" width="33%" valign="top" style="padding-right:5px;">'
        f'{_stat_card(_AMBER["tint"], "#B45309", _AMBER["fg"], ab["over_7"], "&gt; 7 DAYS")}</td>'
        f'<td class="stat-cell" width="34%" valign="top" style="padding:0 3px;">'
        f'{_stat_card(_AMBER["tint"], "#B45309", _AMBER["fg"], ab["over_15"], "&gt; 15 DAYS")}</td>'
        f'<td class="stat-cell" width="33%" valign="top" style="padding-left:5px;">'
        f'{_stat_card(_RED["tint"], _NPG_RED, _RED["fg"], ab["over_30"], "&gt; 1 MONTH")}</td>'
        f'</tr></table>'
    )
    long_rows = [
        [f'<strong>{_esc(r["number"])}</strong>', _esc(r["priority"]),
         _esc(r["short_description"][:70]), _esc(r["opened_at"]),
         f'<strong>{_esc(r["duration"])}</strong>']
        for r in report["table_rows"][:12]
    ]
    long_table = _data_table(
        ["Number", "Pri", "Short description", "Opened", "Age"],
        long_rows, aligns=["left", "left", "left", "left", "right"],
    )
    long_section = _section_block(
        _section_header(f"LONG-PENDING {plural.upper()}",
                        f"oldest {oldest.get('days_open', 0)} days", _AMBER),
        ageing_strip + long_table,
    )

    # ---- No update provided (red - visually distinct) ----
    if report["no_update_rows"]:
        nu_rows = []
        for r in report["no_update_rows"][:15]:
            dsu = r["days_since_update"]
            dsu_txt = (f'<strong style="color:{_RED["fg"]};">{dsu} days</strong>'
                       if dsu is not None else '<span style="color:%s;">no update recorded</span>' % _NPG_MUTED)
            nu_rows.append([f'<strong>{_esc(r["number"])}</strong>', _esc(r["priority"]),
                            _esc(r["short_description"][:70]), _esc(r["opened_at"]), dsu_txt])
        nu_body = _data_table(
            ["Number", "Pri", "Short description", "Opened", "Since update"],
            nu_rows, aligns=["left", "left", "left", "left", "right"],
        )
    else:
        nu_body = (f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
                   f'bgcolor="{_RED["tint"]}" style="background-color:{_RED["tint"]};border:1px solid {_RED["tint_border"]};border-collapse:separate;border-spacing:0;border-radius:10px;">'
                   f'<tr><td style="padding:12px 14px;font-family:{_FONT};font-size:12px;color:{_RED["fg"]};">'
                   f'All open {plural} have been updated within the last 6 days.</td></tr></table>')
    no_update_section = _section_block(
        _section_header("NO UPDATE PROVIDED",
                        f'{report["no_update_count"]} ({report["no_update_pct"]}%)', _RED),
        nu_body,
    )

    # ---- Assigned to member (blue) ----
    assigned_rows = [[_esc(a["name"]), f'<strong>{a["count"]}</strong>']
                     for a in report["assigned_breakdown"]]
    assigned_table = _data_table(["Member", f"Open {plural}"], assigned_rows,
                                 aligns=["left", "right"])
    assigned_section = _section_block(
        _section_header("ASSIGNED TO MEMBER", f'{len(assigned_rows)} member(s)', _BLUE),
        assigned_table,
    )

    badge_open = _badge(_CHIP_BG, "#FFFFFF", f"{total} OPEN")
    badge_when = _badge(_CHIP_BG, "#FFFFFF", report["generated_at"].upper())

    hero = hero_rows(f"NPG APP ASSIST &middot; OPEN {item_label.upper()} SUMMARY",
                     _esc(group), [badge_open, badge_when], width=640)
    footer = footer_rows("ServiceNow Analysis", width=640)

    intro = (
        f"There {'is' if total == 1 else 'are'} <strong>{total}</strong> open "
        f"{item_label if total == 1 else plural} in the <strong>{_esc(group)}</strong> queue. "
        f"<strong>{ab['over_7']}</strong> {'has' if ab['over_7'] == 1 else 'have'} been open more "
        f"than 7 days, and <strong>{report['no_update_count']}</strong> "
        f"{'has' if report['no_update_count'] == 1 else 'have'} had no recent update. "
        f"Please review and progress the items below."
    )

    return f"""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>NPG App Assist &mdash; Open {item_label} summary</title>
  <!--[if mso]>
  <xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch><o:AllowPNG/></o:OfficeDocumentSettings></xml>
  <style type="text/css">table {{border-collapse:collapse;}} td {{mso-line-height-rule:exactly;}}</style>
  <![endif]-->
  <style type="text/css">
    body, table, td {{ -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }}
    table {{ border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }}
    a {{ color:{_NPG_RED}; text-decoration:none; }}
    @media only screen and (max-width:640px) {{
      .container {{ width:100% !important; }}
      .px-32 {{ padding-left:18px !important; padding-right:18px !important; }}
      .stat-cell {{ display:block !important; width:100% !important; padding:0 0 6px 0 !important; }}
    }}
  </style>
</head>
<body style="margin:0;padding:0;background-color:{_NPG_LIGHT};font-family:{_FONT};">
<div style="display:none;font-size:1px;color:{_NPG_LIGHT};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
Open {item_label} summary for {_esc(group)} &mdash; {total} open, {ab['over_7']} over 7 days, {report['no_update_count']} with no update
</div>

<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="{_NPG_LIGHT}" style="background-color:{_NPG_LIGHT};">
  <tr><td align="center" style="padding:34px 16px 40px 16px;">
    <!--[if mso]><table role="presentation" align="center" cellpadding="0" cellspacing="0" border="0" width="640"><tr><td><![endif]-->
    <table role="presentation" class="container" cellpadding="0" cellspacing="0" border="0" width="640"
           style="width:640px;max-width:640px;background-color:#FFFFFF;border:1px solid {_NPG_BORDER};border-bottom-color:#C6D0DE;border-collapse:separate;border-spacing:0;border-radius:14px;">

      <!-- Header (shared NPG theme: flat maroon masthead) -->
      {hero}

      <!-- Intro ribbon -->
      <tr><td class="px-32" style="padding:22px 32px;">
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"
               bgcolor="{_NEUTRAL['tint']}" style="background-color:{_NEUTRAL['tint']};border:1px solid {_NEUTRAL['tint_border']};border-collapse:separate;border-spacing:0;border-radius:10px;">
          <tr>
            <td style="padding:14px 16px;font-family:{_FONT};font-size:13px;color:{_NPG_TEXT};
                       mso-line-height-rule:exactly;line-height:20px;">{intro}</td>
          </tr>
        </table>
      </td></tr>

      <!-- Sections -->
      <tr><td class="px-32" style="padding:24px 32px;">
        {priority_section}
        {off_hold_section}
        {long_section}
        {assigned_section}
        {no_update_section}
      </td></tr>

      <!-- Footer (shared NPG theme) -->
      {footer}

    </table>
    <!--[if mso]></td></tr></table><![endif]-->
  </td></tr>
</table>
</body>
</html>"""


# ---------------------------------------------------------------------------
# Delivery
# ---------------------------------------------------------------------------
def send_group_summary(group: str, report: Dict[str, Any],
                       recipients: List[str],
                       item_label: str = "incident") -> bool:
    """Send the per-group summary to `recipients`. Returns True on success."""
    if not recipients:
        return False
    try:
        msg = MIMEMultipart("alternative")
        msg["From"] = _EMAIL_FROM
        msg["To"] = ", ".join(recipients)
        msg["Subject"] = _subject(group, report, item_label)
        msg["X-Priority"] = "2" if report["ageing_bands"].get("over_7") else "3"
        msg.attach(MIMEText(build_plaintext(group, report, item_label), "plain", "utf-8"))
        msg.attach(MIMEText(build_html(group, report, item_label), "html", "utf-8"))

        with smtplib.SMTP(_SMTP_SERVER, _SMTP_PORT, timeout=30) as server:
            server.sendmail(_EMAIL_FROM, recipients, msg.as_string())

        logger.info("Open-%s summary emailed for group '%s' to %d recipient(s)",
                    item_label, group, len(recipients))
        return True
    except smtplib.SMTPException as exc:
        logger.error("SMTP error sending open-%s summary for '%s': %s",
                     item_label, group, exc)
        return False
    except Exception:
        logger.exception("Unexpected error sending open-%s summary for '%s'",
                         item_label, group)
        return False


# ---------------------------------------------------------------------------
# Management summary (consolidated email + Excel workbook attachment)
# ---------------------------------------------------------------------------
def _off_hold_totals(group_reports: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Portfolio off-hold-today roll-up, summed from the per-group sections.

    Summing the group reports rather than re-deriving from the frame keeps the
    management figure and the group emails on ONE calculation - they are built
    in the same dispatch, so they can never disagree about what "today" was.
    """
    blocks = [_off_hold(rep) for rep in group_reports]
    return {
        "date_label": (blocks[0]["date_label"] if blocks
                       else datetime.now().strftime("%d %b %Y")),
        "count": sum(b["count"] for b in blocks),
        "total_dated": sum(b["total_dated"] for b in blocks),
        "column_present": any(b["column_present"] for b in blocks),
        "groups": [{"name": rep["group"], "count": _off_hold(rep)["count"]}
                   for rep in group_reports if _off_hold(rep)["count"]],
    }


def _management_subject(overall: Dict[str, Any], n_groups: int,
                        item_label: str = "incident") -> str:
    return (f"[App Assist] Open {item_label} management summary - "
            f"{overall['total_open']} open across {n_groups} "
            f"group{'' if n_groups == 1 else 's'}")


def build_management_plaintext(overall: Dict[str, Any],
                               group_reports: List[Dict[str, Any]],
                               source_filename: str = "",
                               item_label: str = "incident") -> str:
    plural = _plural(item_label)
    pc = overall["priority_counts"]
    ab = overall["ageing_bands"]
    oht = _off_hold_totals(group_reports)
    lines = [
        f"NPG APP ASSIST - OPEN {item_label.upper()} MANAGEMENT SUMMARY",
        "=" * 56,
        f"Source file: {source_filename or '-'}",
        f"Generated: {overall['generated_at']}",
        "",
        f"Total open {plural}: {overall['total_open']} across "
        f"{len(group_reports)} assignment group(s)    "
        f"(avg age {overall['avg_days_open']} days)",
        "",
        "SUMMARY BY PRIORITY",
        "-" * 56,
        f"  P1 Critical: {pc['P1']}   P2 High: {pc['P2']}   "
        f"P3 Moderate: {pc['P3']}   P4 Low: {pc['P4']}",
        "",
        f"LONG-PENDING {plural.upper()}",
        "-" * 56,
        f"  > 7 days: {ab['over_7']}    > 15 days: {ab['over_15']}    "
        f"> 1 month: {ab['over_30']}",
        f"  No recent update: {overall['no_update_count']} "
        f"({overall['no_update_pct']}%)",
        "",
        f"DUE OFF HOLD TODAY  ({oht['date_label']})",
        "-" * 56,
    ]
    if oht["groups"]:
        lines.append(f"  {oht['count']} {plural} come off hold today:")
        for g in oht["groups"]:
            lines.append(f"    {g['name'][:44]:<46} {g['count']:>4}")
    elif oht["column_present"]:
        lines.append(f"  None - no {plural} come off hold today.")
    else:
        lines.append("  Not reported - this upload carried no Off hold date values.")
    lines += [
        "",
        "ASSIGNMENT GROUP OVERVIEW",
        "-" * 56,
    ]
    for rep in group_reports:
        gab = rep["ageing_bands"]
        lines.append(f"    {rep['group'][:36]:<38} open {rep['total_open']:>4}   "
                     f"P1 {rep['priority_counts']['P1']:>3}   "
                     f">7d {gab['over_7']:>4}   "
                     f"no-update {rep['no_update_count']:>4}")
    lines += [
        "",
        "The attached Excel workbook contains the full detail: a Summary",
        "worksheet followed by one worksheet per assignment group.",
        "NPG App Assist - ServiceNow Analysis - Generated automatically - Do not reply",
    ]
    return "\n".join(lines)


def build_management_html(overall: Dict[str, Any],
                          group_reports: List[Dict[str, Any]],
                          source_filename: str = "",
                          item_label: str = "incident") -> str:
    plural = _plural(item_label)
    pc = overall["priority_counts"]
    ab = overall["ageing_bands"]
    total = overall["total_open"]
    n_groups = len(group_reports)
    oht = _off_hold_totals(group_reports)

    # ---- Priority summary (stat cards - same design as the group email) ----
    def _card(pri: str) -> str:
        bg, big, lab = _PRIORITY_CARD[pri]
        return _stat_card(bg, big, lab, pc[pri], pri)

    priority_cards = (
        f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        f'<td class="stat-cell" width="20%" valign="top" style="padding-right:5px;">'
        f'{_stat_card("#EEF2F7", _NPG_DARK, _NPG_MUTED, total, "TOTAL OPEN")}</td>'
        f'<td class="stat-cell" width="20%" valign="top" style="padding:0 3px;">{_card("P1")}</td>'
        f'<td class="stat-cell" width="20%" valign="top" style="padding:0 3px;">{_card("P2")}</td>'
        f'<td class="stat-cell" width="20%" valign="top" style="padding:0 3px;">{_card("P3")}</td>'
        f'<td class="stat-cell" width="20%" valign="top" style="padding-left:5px;">{_card("P4")}</td>'
        f'</tr></table>'
    )
    priority_section = _section_block(
        _section_header("SUMMARY BY PRIORITY", f"{total} open", _NEUTRAL),
        priority_cards,
    )

    # ---- Ageing strip (amber/red) ----
    ageing_strip = (
        f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        f'<td class="stat-cell" width="25%" valign="top" style="padding-right:5px;">'
        f'{_stat_card(_AMBER["tint"], "#B45309", _AMBER["fg"], ab["over_7"], "&gt; 7 DAYS")}</td>'
        f'<td class="stat-cell" width="25%" valign="top" style="padding:0 3px;">'
        f'{_stat_card(_AMBER["tint"], "#B45309", _AMBER["fg"], ab["over_15"], "&gt; 15 DAYS")}</td>'
        f'<td class="stat-cell" width="25%" valign="top" style="padding:0 3px;">'
        f'{_stat_card(_RED["tint"], _NPG_RED, _RED["fg"], ab["over_30"], "&gt; 1 MONTH")}</td>'
        f'<td class="stat-cell" width="25%" valign="top" style="padding-left:5px;">'
        f'{_stat_card(_RED["tint"], _NPG_RED, _RED["fg"], overall["no_update_count"], "NO UPDATE")}</td>'
        f'</tr></table>'
    )
    ageing_section = _section_block(
        _section_header("AGEING &amp; UPDATE HYGIENE",
                        f"avg {overall['avg_days_open']} days open", _AMBER),
        ageing_strip,
    )

    # ---- Due off hold today (teal) ----
    if oht["groups"]:
        off_hold_body = _data_table(
            ["Assignment group", "Due off hold today"],
            [[_esc(g["name"]),
              f'<strong style="color:{_TEAL["fg"]};">{g["count"]}</strong>']
             for g in oht["groups"]],
            aligns=["left", "right"],
        )
    else:
        note = (f"No {plural} come off hold today."
                if oht["column_present"]
                else "This upload carried no Off hold date values, so nothing "
                     "can be listed here.")
        off_hold_body = (
            f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
            f'bgcolor="{_TEAL["tint"]}" style="background-color:{_TEAL["tint"]};'
            f'border:1px solid {_TEAL["tint_border"]};border-collapse:separate;border-spacing:0;border-radius:10px;">'
            f'<tr><td style="padding:12px 14px;font-family:{_FONT};font-size:12px;'
            f'color:{_TEAL["fg"]};">{_esc(note)}</td></tr></table>')
    off_hold_section = _section_block(
        _section_header("DUE OFF HOLD TODAY",
                        f'{oht["date_label"]} &middot; {oht["count"]} of '
                        f'{oht["total_dated"]} dated', _TEAL),
        off_hold_body,
    )

    # ---- Assignment group overview (blue) ----
    group_rows = []
    for rep in group_reports:
        gab = rep["ageing_bands"]
        gpc = rep["priority_counts"]
        group_rows.append([
            f'<strong>{_esc(rep["group"])}</strong>',
            f'<strong>{rep["total_open"]}</strong>',
            (f'<strong style="color:{_RED["fg"]};">{gpc["P1"]}</strong>'
             if gpc["P1"] else "0"),
            str(gpc["P2"]),
            str(gab["over_7"]),
            str(rep["no_update_count"]),
            (f'<strong style="color:{_TEAL["fg"]};">{_off_hold(rep)["count"]}</strong>'
             if _off_hold(rep)["count"] else "0"),
        ])
    group_table = _data_table(
        ["Assignment group", "Open", "P1", "P2", "> 7 days", "No update",
         "Off hold today"],
        group_rows,
        aligns=["left", "right", "right", "right", "right", "right", "right"],
    )
    group_section = _section_block(
        _section_header("ASSIGNMENT GROUP OVERVIEW",
                        f"{n_groups} group{'' if n_groups == 1 else 's'}", _BLUE),
        group_table,
    )

    # ---- Attachment note ----
    attachment_note = (
        f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
        f'bgcolor="{_NEUTRAL["tint"]}" style="background-color:{_NEUTRAL["tint"]};'
        f'border:1px solid {_NEUTRAL["tint_border"]};border-collapse:separate;border-spacing:0;border-radius:10px;margin-bottom:20px;"><tr>'
        f'<td style="padding:14px 16px;font-family:{_FONT};font-size:12px;'
        f'color:{_NPG_TEXT};mso-line-height-rule:exactly;line-height:18px;">'
        f'<strong>Full detail attached.</strong> The accompanying Excel workbook contains a '
        f'<strong>Summary</strong> worksheet followed by one detailed worksheet per assignment '
        f'group (per-member workload and every open {item_label}, oldest first).</td>'
        f'</tr></table>'
    )

    badge_open = _badge(_CHIP_BG, "#FFFFFF", f"{total} OPEN")
    badge_groups = _badge(_CHIP_BG, "#FFFFFF",
                          f"{n_groups} GROUP{'' if n_groups == 1 else 'S'}")
    badge_when = _badge(_CHIP_BG, "#FFFFFF", overall["generated_at"].upper())

    hero = hero_rows(f"NPG APP ASSIST &middot; OPEN {item_label.upper()} SUMMARY",
                     "Management Summary &mdash; All Assignment Groups",
                     [badge_open, badge_groups, badge_when], width=640)
    footer = footer_rows("ServiceNow Analysis", width=640)

    intro = (
        f"There {'is' if total == 1 else 'are'} <strong>{total}</strong> open "
        f"{item_label if total == 1 else plural} across <strong>{n_groups}</strong> "
        f"assignment group{'' if n_groups == 1 else 's'}. "
        f"<strong>{ab['over_7']}</strong> {'has' if ab['over_7'] == 1 else 'have'} been open more "
        f"than 7 days, and <strong>{overall['no_update_count']}</strong> "
        f"({overall['no_update_pct']}%) {'has' if overall['no_update_count'] == 1 else 'have'} "
        f"had no recent update. The attached workbook has the full breakdown."
    )

    return f"""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>NPG App Assist &mdash; Open {item_label} management summary</title>
  <!--[if mso]>
  <xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch><o:AllowPNG/></o:OfficeDocumentSettings></xml>
  <style type="text/css">table {{border-collapse:collapse;}} td {{mso-line-height-rule:exactly;}}</style>
  <![endif]-->
  <style type="text/css">
    body, table, td {{ -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }}
    table {{ border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }}
    a {{ color:{_NPG_RED}; text-decoration:none; }}
    @media only screen and (max-width:640px) {{
      .container {{ width:100% !important; }}
      .px-32 {{ padding-left:18px !important; padding-right:18px !important; }}
      .stat-cell {{ display:block !important; width:100% !important; padding:0 0 6px 0 !important; }}
    }}
  </style>
</head>
<body style="margin:0;padding:0;background-color:{_NPG_LIGHT};font-family:{_FONT};">
<div style="display:none;font-size:1px;color:{_NPG_LIGHT};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
Open {item_label} management summary &mdash; {total} open across {n_groups} groups, {ab['over_7']} over 7 days, {overall['no_update_count']} with no update
</div>

<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="{_NPG_LIGHT}" style="background-color:{_NPG_LIGHT};">
  <tr><td align="center" style="padding:34px 16px 40px 16px;">
    <!--[if mso]><table role="presentation" align="center" cellpadding="0" cellspacing="0" border="0" width="640"><tr><td><![endif]-->
    <table role="presentation" class="container" cellpadding="0" cellspacing="0" border="0" width="640"
           style="width:640px;max-width:640px;background-color:#FFFFFF;border:1px solid {_NPG_BORDER};border-bottom-color:#C6D0DE;border-collapse:separate;border-spacing:0;border-radius:14px;">

      <!-- Header (shared NPG theme: flat maroon masthead) -->
      {hero}

      <!-- Intro ribbon -->
      <tr><td class="px-32" style="padding:22px 32px;">
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"
               bgcolor="{_NEUTRAL['tint']}" style="background-color:{_NEUTRAL['tint']};border:1px solid {_NEUTRAL['tint_border']};border-collapse:separate;border-spacing:0;border-radius:10px;">
          <tr>
            <td style="padding:14px 16px;font-family:{_FONT};font-size:13px;color:{_NPG_TEXT};
                       mso-line-height-rule:exactly;line-height:20px;">{intro}</td>
          </tr>
        </table>
      </td></tr>

      <!-- Sections -->
      <tr><td class="px-32" style="padding:24px 32px;">
        {attachment_note}
        {priority_section}
        {off_hold_section}
        {ageing_section}
        {group_section}
      </td></tr>

      <!-- Footer (shared NPG theme) -->
      {footer}

    </table>
    <!--[if mso]></td></tr></table><![endif]-->
  </td></tr>
</table>
</body>
</html>"""


def send_management_summary(overall: Dict[str, Any],
                            group_reports: List[Dict[str, Any]],
                            recipients: List[str],
                            excel_path,
                            source_filename: str = "",
                            item_label: str = "incident") -> bool:
    """Send the consolidated management summary (HTML + plaintext) with the
    Excel workbook attached. Returns True on success."""
    if not recipients:
        return False
    try:
        msg = MIMEMultipart("mixed")
        msg["From"] = _EMAIL_FROM
        msg["To"] = ", ".join(recipients)
        msg["Subject"] = _management_subject(overall, len(group_reports), item_label)
        msg["X-Priority"] = "2" if overall["ageing_bands"].get("over_7") else "3"

        alt = MIMEMultipart("alternative")
        alt.attach(MIMEText(build_management_plaintext(
            overall, group_reports, source_filename, item_label), "plain", "utf-8"))
        alt.attach(MIMEText(build_management_html(
            overall, group_reports, source_filename, item_label), "html", "utf-8"))
        msg.attach(alt)

        with open(excel_path, "rb") as fh:
            part = MIMEApplication(
                fh.read(),
                _subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        part.add_header("Content-Disposition", "attachment",
                        filename=os.path.basename(str(excel_path)))
        msg.attach(part)

        with smtplib.SMTP(_SMTP_SERVER, _SMTP_PORT, timeout=30) as server:
            server.sendmail(_EMAIL_FROM, recipients, msg.as_string())

        logger.info("Open-%s management summary emailed to %d recipient(s) "
                    "(%d group sheets)", item_label, len(recipients),
                    len(group_reports))
        return True
    except smtplib.SMTPException as exc:
        logger.error("SMTP error sending open-%s management summary: %s",
                     item_label, exc)
        return False
    except Exception:
        logger.exception("Unexpected error sending open-%s management summary",
                         item_label)
        return False


def _management_recipients() -> List[str]:
    """Management address list, or [] when the option is disabled / unset."""
    from database import get_db_session
    from .guide_routes import _normalize_emails
    from .models import OpenIncidentEmailSettings

    db = get_db_session()
    try:
        settings = db.query(OpenIncidentEmailSettings).first()
    finally:
        db.close()
    if not settings or not settings.management_summary_enabled:
        return []
    return _normalize_emails(settings.management_emails)


def dispatch_management_summary(work_df, source_filename: str = "",
                                item_label: str = "incident") -> Dict[str, Any]:
    """Build and send the consolidated management summary for `work_df` -
    covering EVERY assignment group in the upload (not just the ones with
    escalation contacts). No-ops when the option is disabled or no management
    address is configured.

    Returns {"sent": bool, "reason": str | None, "recipients": n}.
    """
    from . import config
    from .open_incidents import compute_group_report, compute_overall_summary, list_groups

    recipients = _management_recipients()
    if not recipients:
        return {"sent": False, "reason": "disabled_or_no_recipients", "recipients": 0}

    overall = compute_overall_summary(work_df)
    group_reports = [r for r in (compute_group_report(work_df, g["name"])
                                 for g in list_groups(work_df)) if r]
    if not group_reports:
        return {"sent": False, "reason": "no_groups", "recipients": len(recipients)}

    try:
        from .utils.open_incident_excel import build_management_excel
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        stem = ("open_sr_management" if item_label == "service request"
                else "open_incident_management")
        excel_path = config.OUTPUT_DIR / f"{stem}_{ts}.xlsx"
        build_management_excel(excel_path, overall, group_reports,
                               {"filename": source_filename or "-",
                                "generated_at": overall["generated_at"]},
                               item_label=item_label)
    except Exception:
        logger.exception("Could not build the management Excel workbook")
        return {"sent": False, "reason": "excel_failed", "recipients": len(recipients)}

    ok = send_management_summary(overall, group_reports, recipients,
                                 excel_path, source_filename, item_label)
    return {"sent": ok, "reason": None if ok else "smtp_failed",
            "recipients": len(recipients)}


def _recipients_for(contact) -> List[str]:
    """Group DL + manager address(es) for a contact, de-duplicated (order kept)."""
    from .guide_routes import _normalize_emails
    addrs = _normalize_emails(contact.group_emails) + _normalize_emails(contact.manager_emails)
    seen, out = set(), []
    for a in addrs:
        if a.lower() not in seen:
            seen.add(a.lower())
            out.append(a)
    return out


def dispatch_open_incident_digest(work_df, only_group: str | None = None,
                                  source_filename: str = "",
                                  item_label: str = "incident") -> Dict[str, Any]:
    """Email the per-group summary for every group in `work_df` that has an
    escalation-contact mapping. Groups without a mapping (or without any usable
    address) are silently skipped - many groups won't be ours to contact.

    `item_label` selects the wording ("incident" / "service request") so the
    same dispatcher serves both open-item kinds as separate emails.

    On a FULL run (only_group is None) the consolidated management summary is
    also dispatched when enabled (see dispatch_management_summary).

    Returns {"sent": [group, ...], "total_groups": n, "management": {...}}.
    """
    from database import get_db_session
    from .models import AssignmentGroupContact
    from .open_incidents import compute_group_report, list_groups

    groups = [g["name"] for g in list_groups(work_df)]
    if only_group:
        groups = [only_group]

    db = get_db_session()
    try:
        contacts = {c.name: c for c in db.query(AssignmentGroupContact).all()}
    finally:
        db.close()

    sent: List[str] = []
    for group in groups:
        contact = contacts.get(group)
        if not contact:
            continue
        recipients = _recipients_for(contact)
        if not recipients:
            continue
        report = compute_group_report(work_df, group)
        if report and send_group_summary(group, report, recipients, item_label):
            sent.append(group)

    # The consolidated management summary accompanies full runs only - a
    # single-group send is a targeted nudge, not a portfolio view.
    if only_group is None:
        management = dispatch_management_summary(work_df, source_filename,
                                                 item_label)
    else:
        management = {"sent": False, "reason": "single_group", "recipients": 0}

    return {"sent": sent, "total_groups": len(groups), "management": management}


def dispatch_latest_open_incident_digest() -> Dict[str, Any]:
    """Scheduler entry point: email summaries for the most recent open-incident
    AND open-service-request uploads (the global 'open' / 'open_sr' latest
    pointers). Each kind goes out as its own clearly-labelled email set.
    No-ops cleanly for a kind if nothing has been uploaded or the session
    has expired."""
    from . import session_store

    results: Dict[str, Any] = {}
    for latest_key, item_label in (("open", "incident"),
                                   ("open_sr", "service request")):
        sid = session_store.get_latest(latest_key)
        if not sid:
            logger.info("Open-%s digest: no recent upload - nothing to send.",
                        item_label)
            results[latest_key] = {"sent": [], "reason": "no_upload"}
            continue
        sess = session_store.get(sid)
        if not sess or sess.get("kind") != latest_key:
            logger.info("Open-%s digest: latest session missing/expired.",
                        item_label)
            results[latest_key] = {"sent": [], "reason": "no_session"}
            continue

        result = dispatch_open_incident_digest(
            sess["work_df"], source_filename=sess.get("filename", ""),
            item_label=item_label)
        logger.info("Open-%s digest: emailed %d of %d group(s): %s | "
                    "management summary: %s",
                    item_label, len(result["sent"]), result["total_groups"],
                    ", ".join(result["sent"]) or "(none configured)",
                    "sent" if result["management"]["sent"]
                    else result["management"]["reason"])
        results[latest_key] = result

    # Backwards-compatible top-level keys (callers/logs that expect the
    # incident digest's shape keep working).
    combined = dict(results.get("open") or {"sent": [], "reason": "no_upload"})
    combined["by_kind"] = results
    return combined
