"""
Server validation and external-interface lookup for the CR Template Generator.

Given a free-text list of server names (comma / space / tab separated), this
module:

    1. Parses the list into individual server tokens.
    2. Looks each one up in the application_support.ServerDetails table.
    3. Resolves the application each server belongs to.
    4. Pulls all ExternalInterfaces for those applications.
    5. Returns structured data for the route layer to render warnings.

DEFENSIVE COLUMN ACCESS
-----------------------
The application_support models were not provided in this codebase
review.  This module therefore reads attributes via getattr() with
multiple candidate names so it works regardless of whether the column
is `server_name`, `hostname`, `name` etc.

If your column names differ from the candidates listed below, edit the
constants at the top of this file in one place - the rest of the module
will pick them up automatically.

ZERO-DEPENDENCY FAILURE MODE
----------------------------
If application_support.models cannot be imported (because the host app
is being run without that module mounted), the lookup returns a
graceful "lookup_unavailable" status rather than crashing.  The CR
template generator then continues without server warnings.
"""

from __future__ import annotations

import logging
import re
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Candidate column names (edit here if your schema differs)
# ---------------------------------------------------------------------------
SERVER_NAME_CANDIDATES        = ("server_name", "hostname", "name", "host")
SERVER_TYPE_CANDIDATES        = ("server_type", "type", "os_type", "platform")
SERVER_ENV_CANDIDATES         = ("environment", "env", "tier")
SERVER_APP_FK_CANDIDATES      = ("application_id", "app_id", "application_details_id")

APP_NAME_CANDIDATES           = ("application_name", "name", "app_name")
APP_TOWER_CANDIDATES          = ("tower_id", "app_tower_id", "support_tower_id")

INTERFACE_NAME_CANDIDATES     = ("interface_name", "name", "external_system",
                                 "system_name")
INTERFACE_CONTACT_CANDIDATES  = ("contact_details", "contact_name", "contact",
                                 "owner")
INTERFACE_EMAIL_CANDIDATES    = ("contact_email", "email", "owner_email")
INTERFACE_PHONE_CANDIDATES    = ("contact_phone", "phone", "telephone")
INTERFACE_DESC_CANDIDATES     = ("description", "interface_description",
                                 "notes", "comments")
INTERFACE_DIRECTION_CANDIDATES = ("direction", "interface_direction", "flow")
INTERFACE_APP_FK_CANDIDATES   = ("application_id", "app_id", "application_details_id")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _first_attr(obj: Any, candidates: Iterable[str], default: Any = None) -> Any:
    """Return the first attribute on obj that matches any of `candidates`."""
    for name in candidates:
        if hasattr(obj, name):
            val = getattr(obj, name)
            if val is not None and str(val).strip() != "":
                return val
    return default


_SPLIT_RE = re.compile(r"[,;\t\r\n\s]+")


def parse_server_list(raw: str) -> List[str]:
    """
    Parse a user-supplied free-text server list into a deduplicated list
    of tokens. Splits on comma, semicolon, whitespace, tab, newline.
    Tokens shorter than 2 characters or containing only digits are
    dropped (these are almost always typos, not real hostnames).
    """
    if not raw:
        return []
    tokens = [t.strip().strip(".:;,") for t in _SPLIT_RE.split(raw)]
    cleaned: List[str] = []
    seen: Set[str] = set()
    for t in tokens:
        if not t or len(t) < 2:
            continue
        if t.isdigit():
            continue
        key = t.lower()
        if key in seen:
            continue
        seen.add(key)
        cleaned.append(t)
    return cleaned


# ---------------------------------------------------------------------------
# Optional model import
# ---------------------------------------------------------------------------
def _try_import_models() -> Optional[Tuple[Any, Any, Any]]:
    """Import ServerDetails, ApplicationDetails, ExternalInterfaces.
    Returns None if application_support is not mounted on this host."""
    try:
        from modules.application_support.models import (   # type: ignore
            ServerDetails, ApplicationDetails, ExternalInterfaces,
        )
        return ServerDetails, ApplicationDetails, ExternalInterfaces
    except Exception as exc:
        logger.warning(
            "Could not import application_support models - server lookup disabled. "
            "Reason: %s", exc)
        return None


def _try_get_db_session():
    """Get a DB session via the host app's helper. Returns None on failure."""
    try:
        from database import get_db_session  # type: ignore
        return get_db_session()
    except Exception as exc:
        logger.warning("Could not obtain DB session: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Core lookup
# ---------------------------------------------------------------------------
def lookup_servers(server_list_raw: str) -> Dict[str, Any]:
    """
    Resolve a raw server-list string into application + interface info.

    Returns a dict with:
        status            : 'ok' | 'no_input' | 'lookup_unavailable' | 'error'
        servers_input     : list of parsed server tokens
        servers_found     : list of server detail dicts with resolved app
        servers_unknown   : list of tokens not found in ServerDetails
        applications      : list of unique applications touched
        external_interfaces : list of interfaces (deduplicated by name+app)
        warnings          : list of pre-rendered warning strings (UI-friendly)
    """
    tokens = parse_server_list(server_list_raw)
    if not tokens:
        return {
            "status": "no_input",
            "servers_input": [], "servers_found": [], "servers_unknown": [],
            "applications": [], "external_interfaces": [], "warnings": [],
        }

    models = _try_import_models()
    if models is None:
        return {
            "status": "lookup_unavailable",
            "servers_input": tokens, "servers_found": [], "servers_unknown": tokens,
            "applications": [], "external_interfaces": [],
            "warnings": ["Server-detail lookup is not available on this deployment "
                         "- could not check external interfaces."],
        }
    ServerDetails, ApplicationDetails, ExternalInterfaces = models

    db = _try_get_db_session()
    if db is None:
        return {
            "status": "error",
            "servers_input": tokens, "servers_found": [], "servers_unknown": tokens,
            "applications": [], "external_interfaces": [],
            "warnings": ["Could not connect to the application-support database."],
        }

    try:
        servers_found, servers_unknown = _resolve_servers(
            db, ServerDetails, tokens)
        app_ids = sorted({s["application_id"] for s in servers_found
                          if s.get("application_id")})

        applications = _resolve_applications(db, ApplicationDetails, app_ids)
        interfaces = _resolve_interfaces(db, ExternalInterfaces, app_ids,
                                         applications)

        warnings = _build_warnings(servers_unknown, interfaces)

        return {
            "status": "ok",
            "servers_input": tokens,
            "servers_found": servers_found,
            "servers_unknown": servers_unknown,
            "applications": list(applications.values()),
            "external_interfaces": interfaces,
            "warnings": warnings,
        }
    except Exception as exc:
        logger.exception("Server lookup failed: %s", exc)
        return {
            "status": "error",
            "servers_input": tokens, "servers_found": [], "servers_unknown": tokens,
            "applications": [], "external_interfaces": [],
            "warnings": [f"Server lookup failed: {exc}"],
        }
    finally:
        try:
            db.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------
def _resolve_servers(db, ServerDetails, tokens: List[str]
                     ) -> Tuple[List[Dict[str, Any]], List[str]]:
    """
    Look up each token in ServerDetails (case-insensitive). Returns
    (found_records, unknown_tokens). A single token can resolve to
    multiple rows if the same hostname exists across environments.
    """
    found: List[Dict[str, Any]] = []
    unknown: List[str] = []
    lowered_tokens = {t.lower(): t for t in tokens}

    # Fetch all candidate rows in one round-trip - for typical NPg sizes
    # this is well under 10K rows. For very large ServerDetails tables,
    # this loop could be replaced with a per-token ILIKE query, but that
    # generates N round-trips. The single-fetch approach is faster up to
    # ~50K rows and avoids relying on a database-specific ILIKE syntax.
    all_rows = db.query(ServerDetails).all()

    matched_tokens: Set[str] = set()
    for row in all_rows:
        sname = _first_attr(row, SERVER_NAME_CANDIDATES, default="")
        sname_lc = str(sname).strip().lower()
        if not sname_lc:
            continue
        # Match on full name OR short hostname (before the first dot)
        short = sname_lc.split(".", 1)[0]
        for tk_lc, original in lowered_tokens.items():
            if tk_lc == sname_lc or tk_lc == short:
                matched_tokens.add(tk_lc)
                found.append({
                    "input_token":   original,
                    "server_name":   str(sname),
                    "server_type":   str(_first_attr(row, SERVER_TYPE_CANDIDATES, "") or ""),
                    "environment":   str(_first_attr(row, SERVER_ENV_CANDIDATES, "") or ""),
                    "application_id": _first_attr(row, SERVER_APP_FK_CANDIDATES),
                })

    for tk_lc, original in lowered_tokens.items():
        if tk_lc not in matched_tokens:
            unknown.append(original)
    return found, unknown


def _resolve_applications(db, ApplicationDetails, app_ids: List[Any]
                          ) -> Dict[Any, Dict[str, Any]]:
    """Fetch ApplicationDetails rows for the given IDs. Keyed by id."""
    if not app_ids:
        return {}
    apps: Dict[Any, Dict[str, Any]] = {}
    rows = db.query(ApplicationDetails).filter(
        ApplicationDetails.id.in_(app_ids)
    ).all()
    for row in rows:
        apps[row.id] = {
            "id":               row.id,
            "application_name": str(_first_attr(row, APP_NAME_CANDIDATES, "Unknown")),
            "tower_id":         _first_attr(row, APP_TOWER_CANDIDATES),
        }
    return apps


def _resolve_interfaces(db, ExternalInterfaces, app_ids: List[Any],
                        applications: Dict[Any, Dict[str, Any]]
                        ) -> List[Dict[str, Any]]:
    """Fetch ExternalInterfaces records linked to any of the given app IDs."""
    if not app_ids:
        return []
    rows = db.query(ExternalInterfaces).filter(
        ExternalInterfaces.application_id.in_(app_ids)
        if hasattr(ExternalInterfaces, "application_id")
        else _build_app_filter(ExternalInterfaces, app_ids)
    ).all() if app_ids else []

    interfaces: List[Dict[str, Any]] = []
    seen_keys: Set[str] = set()
    for row in rows:
        app_id = _first_attr(row, INTERFACE_APP_FK_CANDIDATES)
        name = str(_first_attr(row, INTERFACE_NAME_CANDIDATES, "Unknown interface"))
        contact = str(_first_attr(row, INTERFACE_CONTACT_CANDIDATES, "") or "")
        email = str(_first_attr(row, INTERFACE_EMAIL_CANDIDATES, "") or "")
        phone = str(_first_attr(row, INTERFACE_PHONE_CANDIDATES, "") or "")
        desc = str(_first_attr(row, INTERFACE_DESC_CANDIDATES, "") or "")
        direction = str(_first_attr(row, INTERFACE_DIRECTION_CANDIDATES, "") or "")

        # Build composite contact string
        contact_parts: List[str] = []
        if contact:
            contact_parts.append(contact)
        if email:
            contact_parts.append(email)
        if phone:
            contact_parts.append(phone)
        contact_string = " - ".join(contact_parts) if contact_parts else "Contact not on file"

        app_info = applications.get(app_id, {})
        key = f"{app_id}|{name.lower()}"
        if key in seen_keys:
            continue
        seen_keys.add(key)

        interfaces.append({
            "interface_name":   name,
            "application_id":   app_id,
            "application_name": app_info.get("application_name", "Unknown"),
            "contact":          contact,
            "contact_email":    email,
            "contact_phone":    phone,
            "contact_display":  contact_string,
            "description":      desc,
            "direction":        direction,
        })
    return interfaces


def _build_app_filter(ExternalInterfaces, app_ids):
    """Fallback for when application_id isn't the FK column name. Tries app_id."""
    if hasattr(ExternalInterfaces, "app_id"):
        return ExternalInterfaces.app_id.in_(app_ids)
    if hasattr(ExternalInterfaces, "application_details_id"):
        return ExternalInterfaces.application_details_id.in_(app_ids)
    # Nothing matches - return a filter that yields no rows
    logger.warning("ExternalInterfaces has no recognised app FK column")
    return False


def _build_warnings(unknown: List[str],
                    interfaces: List[Dict[str, Any]]) -> List[str]:
    """Build the human-readable warning strings the UI surfaces in the template."""
    warnings: List[str] = []
    if unknown:
        warnings.append(
            f"WARNING: {len(unknown)} server(s) not found in the application support "
            f"database: {', '.join(unknown)}. Verify hostnames and application "
            f"ownership before submitting this CR."
        )
    for ifc in interfaces:
        warnings.append(
            f"WARNING: Check impact with external interface - "
            f"{ifc['interface_name']} | Contact: {ifc['contact_display']}"
        )
    return warnings
