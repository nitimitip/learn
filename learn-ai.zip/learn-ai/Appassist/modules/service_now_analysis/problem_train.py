"""
Quarterly retraining script for the Problem corpus.

Changes vs previous version
----------------------------
* **Semantic corpus** - after the TF-IDF corpus is built, sentence-embedding
  vectors (``problem_sem_vectors_latest.pkl``) and a BM25 index
  (``problem_bm25_latest.pkl``) are saved if the supporting libraries are
  available.  similarity.py uses these for hybrid search when surfacing
  related problems alongside similar incidents.

* **Persisted null fills** - training-time mode/median values are saved to
  ``problem_null_fills.json``.

Usage
-----
    python -m modules.service_now_analysis.problem_train \\
        --problem-input data/2025_Q4_problems.csv
"""

from __future__ import annotations

import argparse
import json
import logging
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer

from . import config
from .ml.problem_column_mapper import validate_columns as validate_problem_cols
from .ml.problem_preprocess import (
    load_export, preprocess as preprocess_problems,
    compute_null_fills, save_null_fills,
)
from .ml.embedding_utils import build_and_save_extras

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)-7s %(name)s: %(message)s")
logger = logging.getLogger("problem_train")


def _load_one_or_many(path_or_dir: str) -> pd.DataFrame:
    p = Path(path_or_dir)
    if p.is_dir():
        frames = []
        for f in sorted(p.iterdir()):
            if f.suffix.lower() in (".csv", ".xlsx", ".xls", ".tsv"):
                logger.info("Loading %s (%.1f MB)", f.name,
                            f.stat().st_size / 1024 / 1024)
                frames.append(load_export(f))
        if not frames:
            raise FileNotFoundError(f"No CSV/XLSX files found in {p}")
        return pd.concat(frames, ignore_index=True, sort=False)
    return load_export(p)


def _dedupe_keep_latest(df: pd.DataFrame) -> pd.DataFrame:
    if "number" not in df.columns:
        return df
    if "sys_updated_on" in df.columns:
        df = df.copy()
        df["_ts"] = pd.to_datetime(df["sys_updated_on"], errors="coerce")
        df = df.sort_values("_ts").drop_duplicates(
            subset=["number"], keep="last"
        ).drop(columns=["_ts"])
    else:
        df = df.drop_duplicates(subset=["number"], keep="last")
    return df.reset_index(drop=True)


def _archive_existing() -> None:
    files = list(config.MODELS_DIR.glob("problem_*"))
    if not files:
        return
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    arch_dir = config.ARCHIVE_DIR / f"problem_{stamp}"
    arch_dir.mkdir(parents=True, exist_ok=True)
    for f in files:
        try:
            shutil.move(str(f), str(arch_dir / f.name))
        except Exception:
            pass
    logger.info("Archived %d Problem artifacts to %s", len(files), arch_dir)

    archives = sorted([d for d in config.ARCHIVE_DIR.iterdir()
                       if d.is_dir() and d.name.startswith("problem_")],
                      reverse=True)
    for old in archives[config.ARCHIVE_KEEP_VERSIONS:]:
        try:
            shutil.rmtree(old)
        except Exception:
            pass


def main() -> int:
    p = argparse.ArgumentParser(description="Train Problem corpus.")
    p.add_argument("--problem-input")
    p.add_argument("--problem-input-dir")
    p.add_argument("--skip-archive", action="store_true")
    p.add_argument("--include-resolved", action="store_true",
                   help="Also include closed/resolved problems in the corpus "
                        "(default: only active/known-error problems are surfaced)")
    args = p.parse_args()

    if not (args.problem_input or args.problem_input_dir):
        p.error("Provide either --problem-input or --problem-input-dir")

    t0 = time.time()
    raw = _load_one_or_many(args.problem_input or args.problem_input_dir)
    logger.info("Raw problem rows: %d", len(raw))

    ok, missing_req, missing_rec = validate_problem_cols(raw)
    if not ok:
        logger.error("Missing required problem columns: %s", missing_req)
        return 2
    if missing_rec:
        logger.warning("Missing recommended problem columns: %s", missing_rec)

    raw = _dedupe_keep_latest(raw)
    pdf = preprocess_problems(raw, only_active=not args.include_resolved)
    logger.info("After preprocessing: %d problems for the corpus", len(pdf))

    if len(pdf) < 5:
        logger.warning("Only %d problems available - corpus will be small.", len(pdf))
        if len(pdf) == 0:
            logger.error("No problems to index; aborting.")
            return 2

    # Persist null fills
    fills = compute_null_fills(pdf)
    save_null_fills(fills, config.MODELS_DIR / "problem_null_fills.json")
    logger.info("Problem null fills persisted (%d columns)", len(fills))

    if not args.skip_archive:
        _archive_existing()

    text = pdf["text"].fillna("").astype(str).tolist()

    # TF-IDF vectorizer + corpus
    vec = TfidfVectorizer(max_features=config.TFIDF_MAX_FEATURES,
                          ngram_range=(1, config.TFIDF_NGRAM_MAX),
                          min_df=1,          # smaller corpora - allow rare terms
                          stop_words="english")
    vec.fit(text)
    corpus_vecs = vec.transform(text)

    keep_cols = ["problem_id", "title", "description_full", "category",
                 "subcategory", "priority", "state", "assignment_group",
                 "configuration_item", "business_service", "environment",
                 "opened_timestamp", "workaround", "cause_notes", "fix_notes",
                 "known_error", "major_problem", "related_incidents", "rfc"]
    keep_cols = [c for c in keep_cols if c in pdf.columns]

    joblib.dump(vec,         config.MODELS_DIR / "problem_vectorizer_latest.pkl")
    joblib.dump(corpus_vecs, config.MODELS_DIR / "problem_corpus_vectors_latest.pkl")
    joblib.dump(pdf[keep_cols].reset_index(drop=True),
                config.MODELS_DIR / "problem_corpus_dataframe_latest.pkl")

    # NEW: Semantic corpus + BM25
    # Build sentence-embedding vectors and BM25 index for the problem corpus.
    # similarity.py uses these for hybrid problem search.
    # Skipped silently if libraries / model path are unavailable.
    embedding_model_path = getattr(config, "EMBEDDING_MODEL_PATH", None)
    sem_results = build_and_save_extras(
        texts=text,
        prefix="problem",
        models_dir=config.MODELS_DIR,
        model_path=str(embedding_model_path) if embedding_model_path else None,
    )
    if sem_results["sem_ok"]:
        logger.info("Semantic problem corpus vectors saved (%d problems)", len(pdf))
    if sem_results["bm25_ok"]:
        logger.info("BM25 problem index saved (%d problems)", len(pdf))

    metrics: Dict[str, Any] = {
        "trained_at": datetime.now().isoformat(timespec="seconds"),
        "n_problems": int(len(pdf)),
        "include_resolved": bool(args.include_resolved),
        "vocab_size": int(len(vec.get_feature_names_out())),
        "semantic_corpus_built": sem_results["sem_ok"],
        "bm25_corpus_built": sem_results["bm25_ok"],
        "elapsed_seconds": round(time.time() - t0, 1),
    }
    with open(config.MODELS_DIR / "problem_metadata.json", "w") as f:
        json.dump(metrics, f, indent=2, default=str)

    logger.info("OK Problem corpus built in %.1fs (%d problems indexed).",
                metrics["elapsed_seconds"], metrics["n_problems"])
    print(json.dumps(metrics, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
