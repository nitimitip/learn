"""
open_changes_routes.py - routes for the "Open Change Request" tab of the Open
ServiceNow Items sub-module.

Registered onto the ServiceNow Analysis blueprint by
``init_open_change_routes(service_now_analysis_bp)`` (called at the end of
routes.py), so it shares the same /service-now-analysis URL prefix, standalone
layout, sidebar and module-wide context processor.

    GET  /open-change-requests                    upload page (or latest report)
    POST /open-change-requests/upload             members-only: validate + store
    GET  /open-change-requests/report/<sid>       portfolio report
    GET  /open-change-requests/report/<sid>/group per-reviewer-group report
    GET  /api/open-change-requests/<sid>          JSON payload
    POST /open-change-requests/email/<sid>        admin-only dispatch

Why a separate module rather than a third entry in open_incidents_routes._KINDS:
incidents and service requests share one analytics pipeline parameterised by
wording, whereas a change request has a different shape entirely - grouped by
Technical reviewer group, summarised by four lifecycle buckets rather than
P1-P4 ageing, and counted per Created by rather than Assigned to. Sharing the
handlers would mean a conditional in every one of them.
"""

from __future__ import annotations

import logging
import secrets
from datetime import datetime

from flask import flash, jsonify, redirect, render_template, request, url_for
from werkzeug.utils import secure_filename

from auth import get_current_user
from csrf_utils import csrf_protect

from . import config
from . import session_store
from .access import DENIED_MESSAGE, is_servicenow_member
from .ml.preprocess import load_export
from .utils.json_safe import to_json_safe
from . import open_change_email
from .open_changes import (
    compute_group_report, compute_overall_summary, normalise_change_export,
    prepare_open_changes, to_change_display_names, validate_change_columns,
)

logger = logging.getLogger(__name__)

# Session kind + "latest upload" pointer key for change-request runs.
SESSION_KIND = "open_cr"

# Mirrors open_incidents_routes._KINDS so the shared sub-tab markup and the
# report templates can be driven the same way.
CR_KIND = {
    "kind": "cr",
    "session_kind": SESSION_KIND,
    "label": "change request",
    "label_plural": "change requests",
    "title": "Open Change Requests",
    "upload_prefix": "open_cr_",
    "ep_index":  "service_now_analysis.open_crs_index",
    "ep_upload": "service_now_analysis.open_crs_upload",
    "ep_report": "service_now_analysis.open_crs_report",
    "ep_group":  "service_now_analysis.open_crs_group_report",
    "ep_email":  "service_now_analysis.open_crs_email",
}


def _allowed_file(filename: str) -> bool:
    return ("." in filename and
            filename.rsplit(".", 1)[1].lower() in config.ALLOWED_EXTENSIONS)


def init_open_change_routes(bp):
    """Register the Open Change Request routes onto the given blueprint."""

    def _get_session(sid):
        sess = session_store.get(sid)
        if sess is None or sess.get("kind") != SESSION_KIND:
            return None
        return sess

    # -------------------------------------------------------------------
    # Upload page
    # -------------------------------------------------------------------
    @bp.route("/open-change-requests")
    def open_crs_index():
        latest = session_store.get_latest(SESSION_KIND)
        if latest and request.args.get("new") != "1":
            return redirect(url_for(CR_KIND["ep_report"], sid=latest))
        return render_template("service_now_analysis/open_changes/index.html",
                               oi=CR_KIND)

    @bp.route("/open-change-requests/upload", methods=["POST"])
    @csrf_protect
    def open_crs_upload():
        # Upload replaces the org-wide latest change report and feeds the
        # reviewer-group emails, so it is restricted to ServiceNow group
        # members. Reading the report stays open to everyone.
        if not is_servicenow_member():
            logger.warning("Open-change upload denied - not a ServiceNow "
                           "group member")
            flash(DENIED_MESSAGE, "error")
            return redirect(url_for(CR_KIND["ep_index"]))

        session_store.cleanup_expired()

        file = request.files.get("file")
        if not file or not file.filename:
            flash("Please choose a file to upload", "error")
            return redirect(url_for(CR_KIND["ep_index"]))
        if not _allowed_file(file.filename):
            flash(f"Unsupported file type. Allowed: "
                  f"{', '.join(sorted(config.ALLOWED_EXTENSIONS))}", "error")
            return redirect(url_for(CR_KIND["ep_index"]))

        session_id = secrets.token_urlsafe(16)
        safe_name = secure_filename(file.filename)
        ts_prefix = datetime.now().strftime("%Y%m%d-%H%M%S")
        saved_path = (config.UPLOAD_DIR /
                      f"{CR_KIND['upload_prefix']}{ts_prefix}_"
                      f"{session_id[:8]}_{safe_name}")
        try:
            file.save(saved_path)
        except Exception:
            logger.exception("Failed to save open-change upload")
            flash("Could not save the uploaded file", "error")
            return redirect(url_for(CR_KIND["ep_index"]))

        try:
            raw = load_export(saved_path)
        except Exception as exc:
            flash(f"Could not read the file: {exc}", "error")
            return redirect(url_for(CR_KIND["ep_index"]))

        # Unlike the incident/SR uploads, BOTH header conventions go through
        # the same normaliser: snake-casing an export that already carries
        # field names is a no-op, and every rename is skipped when its target
        # column exists, so one path serves CSV and Excel alike.
        is_excel = saved_path.suffix.lower() in (".xlsx", ".xls")
        raw = normalise_change_export(raw)

        ok, missing_required, missing_recommended = validate_change_columns(raw)
        if not ok:
            if is_excel:
                missing_required = to_change_display_names(missing_required)
            flash("Required columns missing: " + ", ".join(missing_required),
                  "error")
            return redirect(url_for(CR_KIND["ep_index"]))

        try:
            work_df = prepare_open_changes(raw)
        except Exception as exc:
            logger.exception("Open-change processing failed")
            flash(f"Could not process the file: {exc}", "error")
            return redirect(url_for(CR_KIND["ep_index"]))

        if work_df.empty:
            flash("No open change requests were found in that file (every row "
                  "looked closed or cancelled). Please upload a list that "
                  "includes open changes.", "warning")
            return redirect(url_for(CR_KIND["ep_index"]))

        overall = compute_overall_summary(work_df)
        if missing_recommended:
            flash("Report built, but these optional columns were missing: " +
                  ", ".join(to_change_display_names(missing_recommended)) +
                  " - the matching columns are blank.", "warning")

        saved = session_store.set(session_id, {
            "kind": SESSION_KIND,
            "work_df": work_df,
            "overall": overall,
            "filename": safe_name,
            "uploaded_at": datetime.now().isoformat(timespec="seconds"),
            "row_count": int(len(work_df)),
            # Kept out of work_df.attrs, which does not reliably survive the
            # pickle round-trip the session store does.
            "excluded_closed": overall["excluded_closed"],
            "filepath": str(saved_path),
        })
        if not saved:
            flash("Server could not save the analysis - check server logs.",
                  "error")
            return redirect(url_for(CR_KIND["ep_index"]))

        session_store.set_latest(SESSION_KIND, session_id)
        return redirect(url_for(CR_KIND["ep_report"], sid=session_id))

    # -------------------------------------------------------------------
    # Reports
    # -------------------------------------------------------------------
    @bp.route("/open-change-requests/report/<sid>")
    def open_crs_report(sid):
        sess = _get_session(sid)
        if sess is None:
            return render_template(
                "service_now_analysis/error.html", code=404,
                message="Open change-request analysis not found or expired. "
                        "Please upload the file again."), 404
        return render_template(
            "service_now_analysis/open_changes/report.html",
            oi=CR_KIND, sid=sid, filename=sess["filename"],
            uploaded_at=sess["uploaded_at"], row_count=sess["row_count"],
            overall=sess["overall"], group=None, report=None)

    @bp.route("/open-change-requests/report/<sid>/group")
    def open_crs_group_report(sid):
        sess = _get_session(sid)
        if sess is None:
            return render_template(
                "service_now_analysis/error.html", code=404,
                message="Open change-request analysis not found or expired."), 404
        group = (request.args.get("name") or "").strip()
        report = compute_group_report(sess["work_df"], group) if group else None
        if report is None:
            flash("That technical reviewer group has no open change requests "
                  "in this upload.", "warning")
            return redirect(url_for(CR_KIND["ep_report"], sid=sid))
        return render_template(
            "service_now_analysis/open_changes/report.html",
            oi=CR_KIND, sid=sid, filename=sess["filename"],
            uploaded_at=sess["uploaded_at"], row_count=sess["row_count"],
            overall=sess["overall"], group=group, report=report)

    @bp.route("/api/open-change-requests/<sid>")
    def api_open_crs(sid):
        sess = _get_session(sid)
        if sess is None:
            return jsonify({"ok": False, "error": "Session not found"}), 404
        return jsonify({"ok": True, "data": to_json_safe(sess["overall"])})

    # -------------------------------------------------------------------
    # Email dispatch (admin only, same rule as the open-incident digest)
    # -------------------------------------------------------------------
    @bp.route("/open-change-requests/email/<sid>", methods=["POST"])
    @csrf_protect
    def open_crs_email(sid):
        user = get_current_user()
        if not user or user.role != "admin":
            flash("Admin access required to email summaries", "error")
            return redirect(url_for(CR_KIND["ep_report"], sid=sid))

        sess = _get_session(sid)
        if sess is None:
            flash("Open change-request analysis not found or expired.", "error")
            return redirect(url_for(CR_KIND["ep_index"]))

        only = (request.form.get("group") or "").strip() or None
        result = open_change_email.dispatch_open_change_digest(
            sess["work_df"], only_group=only,
            source_filename=sess.get("filename", ""))
        sent = result["sent"]

        if sent:
            flash(f"Open change-request summary emailed to {len(sent)} "
                  f"technical reviewer group{'' if len(sent) == 1 else 's'} "
                  f"({', '.join(sent)}).", "success")
        else:
            flash("No summary was sent - no escalation contacts are configured "
                  "for these technical reviewer groups yet.", "info")

        target = (url_for(CR_KIND["ep_group"], sid=sid, name=only)
                  if only else url_for(CR_KIND["ep_report"], sid=sid))
        return redirect(target)
