"""
Configuration for the ServiceNow Analysis module.

Paths are resolved relative to the *host application's* root (i.e. the
folder containing main_app.py), not the module directory. This keeps
uploads, models, and logs visible alongside other host-app data.

All values can be overridden via environment variables of the same name
prefixed with `SNOW_ML_`.
"""

from __future__ import annotations

import os
from pathlib import Path


def _env(name: str, default):
    """Read env var with type coercion based on the default value's type."""
    val = os.environ.get(name)
    if val is None:
        return default
    if isinstance(default, bool):
        return val.lower() in ("1", "true", "yes", "on")
    if isinstance(default, int):
        try:
            return int(val)
        except ValueError:
            return default
    if isinstance(default, float):
        try:
            return float(val)
        except ValueError:
            return default
    return val


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
# This file is at:  <host_root>/modules/service_now_analysis/config.py
# parents[0] -> service_now_analysis/, parents[1] -> modules/, parents[2] -> host root
MODULE_DIR = Path(__file__).resolve().parent
HOST_ROOT = MODULE_DIR.parents[1]

# All persistent DATA lives under <host_root>/data/service_now_analysis/ so it
# doesn't pollute the host app's namespace: uploads, trained models, generated
# reports, the training CSV.
_DATA_ROOT = Path(_env("SNOW_ML_DATA_ROOT", str(HOST_ROOT / "data" / "service_now_analysis")))

# LOGS, however, belong with every other log the app writes - under
# <host_root>/logs/ - not buried in the data tree. A sub-folder is required
# rather than the bare logs/ dir: this module's app.log would otherwise collide
# with the host app's own logs/app.log, with two handlers writing one file.
# (logs/scheduler_log/ already sets that precedent.)
_LOG_ROOT = Path(_env("SNOW_ML_LOG_DIR", str(HOST_ROOT / "logs" / "service_now_analysis")))

DATA_DIR    = _DATA_ROOT
UPLOAD_DIR  = _DATA_ROOT / "uploads"
MODELS_DIR  = _DATA_ROOT / "models"
ARCHIVE_DIR = MODELS_DIR / "archive"
LOG_DIR     = _LOG_ROOT
OUTPUT_DIR  = _DATA_ROOT / "outputs"   # generated Excel reports

MASTER_TRAINING_CSV = DATA_DIR / "master_training.csv"
MODEL_METADATA_FILE = MODELS_DIR / "metadata.json"

# Log FILE names are no longer fixed: routes._configure_module_logging() writes
# through log_utils.DatedFileHandler, which owns the naming
# (<prefix>_<YYYY-MM-DD>_p<pid>.log) because a fixed name plus a rotating
# rename is not safe across the eight IIS worker processes. Only the directory
# and the prefixes are configuration now.
AUDIT_LOG_PREFIX    = "audit"
ERROR_LOG_PREFIX    = "error"
APP_LOG_PREFIX      = "app"

for _d in (DATA_DIR, UPLOAD_DIR, MODELS_DIR, ARCHIVE_DIR, LOG_DIR, OUTPUT_DIR):
    _d.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Upload handling
# ---------------------------------------------------------------------------
MAX_UPLOAD_MB        = _env("SNOW_ML_MAX_UPLOAD_MB", 512)
MAX_CONTENT_LENGTH   = MAX_UPLOAD_MB * 1024 * 1024
ALLOWED_EXTENSIONS   = {"csv", "xlsx", "xls"}

# Retention for uploaded files. Files older than this are removed by the
# scheduled cleanup task. Default 1 day == "delete previous days files".
UPLOAD_RETENTION_DAYS    = _env("SNOW_ML_UPLOAD_RETENTION_DAYS", 1)
OUTPUT_RETENTION_DAYS    = _env("SNOW_ML_OUTPUT_RETENTION_DAYS", 7)
CLEANUP_INTERVAL_HOURS   = _env("SNOW_ML_CLEANUP_INTERVAL_HOURS", 6)

# TTL for a DAILY session - an Open ServiceNow Items run, which is a snapshot
# of that day and expires with that day's upload file. ServiceNow Analysis
# sessions are NOT governed by this: they are kept until the user deletes the
# upload from the Upload History page. See session_store's retention note.
SESSION_TTL_HOURS        = _env("SNOW_ML_SESSION_TTL_HOURS", 24)


# ---------------------------------------------------------------------------
# ML model parameters
# ---------------------------------------------------------------------------
TFIDF_MAX_FEATURES = _env("SNOW_ML_TFIDF_MAX_FEATURES", 5000)
TFIDF_NGRAM_MAX    = _env("SNOW_ML_TFIDF_NGRAM_MAX", 2)
TFIDF_MIN_DF       = _env("SNOW_ML_TFIDF_MIN_DF", 2)

RF_N_ESTIMATORS  = _env("SNOW_ML_RF_N_ESTIMATORS", 100)
GBR_N_ESTIMATORS = _env("SNOW_ML_GBR_N_ESTIMATORS", 100)
LR_MAX_ITER      = _env("SNOW_ML_LR_MAX_ITER", 1000)

# LightGBM classifier hyper-parameters.  n_estimators is an upper bound -
# early stopping (LGBM_EARLY_STOPPING_ROUNDS) usually halts well before it,
# so training stops once the validation metric plateaus instead of always
# running a fixed number of rounds.
LGBM_N_ESTIMATORS          = _env("SNOW_ML_LGBM_N_ESTIMATORS", 500)
LGBM_NUM_LEAVES            = _env("SNOW_ML_LGBM_NUM_LEAVES", 31)
LGBM_LEARNING_RATE         = _env("SNOW_ML_LGBM_LEARNING_RATE", 0.05)
LGBM_EARLY_STOPPING_ROUNDS = _env("SNOW_ML_LGBM_EARLY_STOPPING_ROUNDS", 30)

# Classes with fewer than this many samples are collapsed into an "Other"
# bucket before training the high-cardinality classifiers (categorisation,
# subcategorisation, routing).  This caps the per-round tree count for
# multiclass LightGBM (one tree per class per round) and removes noisy
# singleton labels.  Set to 1 to disable collapsing.
RARE_CLASS_MIN_COUNT       = _env("SNOW_ML_RARE_CLASS_MIN_COUNT", 20)

TEST_SIZE     = 0.2
RANDOM_STATE  = 42

RESOLUTION_HOURS_CLIP = 720      # 30 days
KMEANS_N_CLUSTERS     = _env("SNOW_ML_KMEANS_CLUSTERS", 12)


# ---------------------------------------------------------------------------
# Business thresholds
# ---------------------------------------------------------------------------
SLA_BREACH_HIGH_RISK   = 0.7
SLA_BREACH_MEDIUM_RISK = 0.4
SIMILARITY_GREEN       = 80
SIMILARITY_AMBER       = 60
TOP_N_AT_RISK          = 10
TOP_N_CHRONIC_CIS      = 10
TOP_N_SIMILAR          = 3
MIN_ROWS_FOR_TRAINING  = 50
MIN_ROWS_FOR_ANALYSIS  = 10

SYSTEM_CALLERS  = {"system", "auto", "servicenow", "automation", "monitoring"}
RESOLVED_STATES = {"resolved", "closed", "complete", "completed"}
OPEN_STATES     = {"new", "open", "in progress", "work in progress",
                   "on hold", "pending", "assigned", "active"}

AUTO_RESOLVE_PATTERNS = {
    "password_reset":   ["password reset", "reset password", "forgot password",
                         "password expired", "unlock account", "account locked"],
    "access_request":   ["access request", "grant access", "permission",
                         "add to group", "membership"],
    "software_install": ["install software", "software install", "deploy",
                         "application install"],
    "vpn_issue":        ["vpn", "virtual private network", "remote access"],
    "printer_issue":    ["printer", "print queue", "printing"],
}


# ---------------------------------------------------------------------------
# Performance thresholds
# ---------------------------------------------------------------------------
PERF_CATEGORY_F1_MIN          = 0.75
PERF_PRIORITY_F1_MIN          = 0.70
PERF_RESOLUTION_MAE_MAX_HOURS = 4.0
PERF_ROUTING_ACC_MIN          = 0.80


# ---------------------------------------------------------------------------
# Replacement criteria for re-trained models
# ---------------------------------------------------------------------------
CLASSIFIER_F1_IMPROVEMENT_PCT = 2.0
REGRESSOR_MAE_IMPROVEMENT_PCT = 5.0
PER_CLASS_DEGRADATION_PCT     = 3.0
ARCHIVE_KEEP_VERSIONS         = 3


# ---------------------------------------------------------------------------
# Feature flags
# ---------------------------------------------------------------------------
ENABLE_LLM_TEMPLATE_GEN = _env("SNOW_ML_ENABLE_LLM", False)
ENABLE_AUDIT_LOG        = True


# ---------------------------------------------------------------------------
# Cheap "have we trained yet?" check
#
# The nav on every ServiceNow page shows whether models exist. That used to be
# answered with ModelStore().is_trained(), which UNPICKLES the vectorizer via
# joblib - so merely opening any page in the module imported scikit-learn
# (~63 MB and ~1.2 s) in every one of the eight IIS workers, to render a
# boolean.
#
# Looking for the file answers the same question for the same purpose and
# imports nothing. It is deliberately weaker than is_trained(): a present but
# CORRUPT model reads as trained here. That is the better failure - the nav
# link stays visible and the feature page reports the real error, instead of
# the feature silently disappearing from the menu.
#
# Use ModelStore().is_trained() where you are about to run a prediction and
# genuinely need the object to load.
# ---------------------------------------------------------------------------

def models_available() -> bool:
    """True when a trained vectorizer is present on disk. Imports nothing."""
    try:
        return (MODELS_DIR / "vectorizer_latest.pkl").is_file()
    except OSError:
        return False
