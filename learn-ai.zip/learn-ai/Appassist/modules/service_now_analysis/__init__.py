"""
ServiceNow Analysis module for the NPG App Assist host application.

Provides statistical Incident / Service Request summary reports, open
incident + open service-request backlog tracking (with per-group escalation
emails), an incident-template generator, and a similar-incident finder -
the generators are backed by an offline scikit-learn pipeline.

Wire it into main_app.py with:

    from modules.service_now_analysis import service_now_analysis_bp
    app.register_blueprint(service_now_analysis_bp,
                           url_prefix='/service-now-analysis')

All persistent state (uploads, models, logs, generated reports) lives
under <host_root>/data/service_now_analysis/ by default. Override with
the SNOW_ML_DATA_ROOT environment variable.
"""

from .routes import service_now_analysis_bp

__all__ = ["service_now_analysis_bp"]
__version__ = "2.1"
