"""
access.py - one place that answers "may this user upload into the ServiceNow
Analysis module?".

The module's data screens (Analysis summaries, Open ServiceNow Items) are
readable by anyone who can reach the app, but the UPLOAD is the write side:
it replaces the org-wide "latest" report every other user then sees, refreshes
the Resource Utilization workload table, and feeds the escalation emails. That
is a custodian action, so it is restricted to the **ServiceNow group** - the
same admin-granted membership (servicenow_group_members) that already gates
editing the ServiceNow Guide - plus application admins.

Membership is granted under ServiceNow Guide -> Manage Members, by any existing
member or an admin; only an application admin can revoke it.

Why a separate module rather than another helper in guide_routes.py: routes.py
and open_incidents_routes.py both need the check, and importing guide_routes
from them would create an import cycle (guide_routes is itself attached to the
blueprint defined in routes.py). guide_routes._is_member now delegates here so
there is exactly one definition of "member".
"""

from __future__ import annotations

import logging
from functools import wraps
from typing import Optional

from flask import flash, jsonify, redirect, request, url_for

from auth import get_current_user

logger = logging.getLogger(__name__)

# Shown to the user (and returned in the JSON body) when the check fails.
DENIED_MESSAGE = (
    "Uploading ServiceNow files is restricted to ServiceNow group members. "
    "Ask an administrator to add you under ServiceNow Guide -> Manage Members."
)


def is_servicenow_member(user=None, db_session=None) -> bool:
    """True when `user` is an application admin or in the ServiceNow group.

    `user` defaults to the logged-in user. Pass `db_session` to reuse a session
    the caller already has open; otherwise one is opened and closed here.
    """
    if user is None:
        # Called outside a request (a scheduler job, a unit test) there is no
        # session to read - that is "no user", not a crash.
        try:
            user = get_current_user()
        except RuntimeError:
            return False
    if not user:
        return False
    if getattr(user, "role", None) == "admin":
        return True

    from .models import ServiceNowGroupMember

    if db_session is not None:
        return (db_session.query(ServiceNowGroupMember)
                .filter_by(user_id=user.id).first() is not None)

    from database import get_db_session
    db = get_db_session()
    try:
        return (db.query(ServiceNowGroupMember)
                .filter_by(user_id=user.id).first() is not None)
    except Exception:
        # A membership lookup that blows up must DENY, never fall open.
        logger.exception("ServiceNow group membership lookup failed")
        return False
    finally:
        db.close()


def _denied_user_label() -> str:
    user = get_current_user()
    return getattr(user, "username", None) or "anonymous"


def snow_member_required(redirect_endpoint: Optional[str] = None):
    """Guard a form-POST upload route: flash + redirect when not a member.

    `redirect_endpoint` names where to send the rejected user; when omitted the
    request falls back to the module's landing page. A callable is accepted so
    a route can compute its own target from the view args.
    """
    def decorator(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            if not is_servicenow_member():
                logger.warning("Upload denied for %s on %s - not a ServiceNow "
                               "group member", _denied_user_label(), request.path)
                flash(DENIED_MESSAGE, "error")
                target = redirect_endpoint
                if callable(target):
                    target = target(*args, **kwargs)
                return redirect(url_for(target) if target
                                else url_for("service_now_analysis.index"))
            return view(*args, **kwargs)
        return wrapper
    return decorator


def snow_member_required_json(view):
    """Guard an XHR upload route: 403 + JSON body when not a member.

    The upload pages post through JavaScript and render `error` from the JSON
    body, so a redirect would be swallowed - this returns the same message the
    form-post guard flashes.
    """
    @wraps(view)
    def wrapper(*args, **kwargs):
        if not is_servicenow_member():
            logger.warning("Upload denied for %s on %s - not a ServiceNow "
                           "group member", _denied_user_label(), request.path)
            return jsonify({"ok": False, "error": DENIED_MESSAGE,
                            "code": "not_a_member"}), 403
        return view(*args, **kwargs)
    return wrapper
