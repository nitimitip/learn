"""
Flask Blueprint for the ServiceNow Analysis module.

Mounted under /service-now-analysis by main_app.py:

    from modules.service_now_analysis import service_now_analysis_bp
    app.register_blueprint(service_now_analysis_bp,
                           url_prefix='/service-now-analysis')

All routes are defined relative to that prefix, e.g. the dashboard is at
    GET /service-now-analysis/dashboard/<session_id>

Templates live in <host_root>/templates/service_now_analysis/ and static
assets at <host_root>/static/service_now_analysis/. The blueprint also
ships its own subdir of vendor JS/CSS so it stays offline-capable.

Routes
------
GET  /                          ServiceNow Analysis upload page (incident + SR sections)
POST /upload                    Incident export upload -> statistical summary (members only)
POST /upload-service-request    Service-request export upload -> statistical summary (members only)
GET  /summary/<sid>             Incident Summary report
GET  /sr-summary/<sid>          Service Request Summary report
GET  /api/summary/<sid>         JSON summary payload (for charts, both kinds)
GET  /download/summary-excel/<sid>  Multi-sheet Excel report (both kinds)
GET  /template                  Template-generator form
POST /template/generate         JSON: predict ServiceNow fields
GET  /similar                   Similar-incident search page
POST /similar/search            JSON: top-N similar incidents
POST /similar/synthesize        JSON: combined recommendation
GET  /healthz                   Liveness check
GET  /uploads-history           List recent uploaded files (admin view)
"""

from __future__ import annotations

import logging
import secrets
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Optional

from flask import (
    Blueprint, abort, current_app, flash, jsonify, redirect, render_template,
    request, send_file, session as flask_session, url_for,
)
from werkzeug.utils import secure_filename

from auth import get_current_user
from log_utils import DatedFileHandler

from . import config
from . import session_store
from .access import is_servicenow_member, snow_member_required_json
from .ml.column_mapper import column_coverage_report, validate_columns
from .ml.preprocess import load_export, preprocess
from .ml.summary_processor import compute_summary
from .service_request import (
    apply_sr_fallbacks, normalise_display_export, to_display_names,
)
from .utils.json_safe import to_json_safe
from .utils.upload_cleanup import list_recent_uploads, start_cleanup_thread


# ---------------------------------------------------------------------------
# Logging setup (module-local - does not touch host app's logging config)
#
# These MUST NOT be TimedRotatingFileHandler. IIS hosts this app in
# maxInstances="8" separate processes, and TimedRotatingFileHandler's midnight
# rollover RENAMES the active file. On Windows that rename fails with
# WinError 32 while any other worker holds the file open, so the rollover is
# lost and with it the records around it - the audit log especially, which is
# the one we would actually need after an incident.
#
# DatedFileHandler writes audit_<date>_p<pid>.log and switches file on a date
# change rather than renaming. Retention is by deleting old dated files, which
# needs no handle on the live one. See log_utils.py.
# ---------------------------------------------------------------------------
def _configure_module_logging():
    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    formatter = logging.Formatter(fmt)

    pkg_logger = logging.getLogger("modules.service_now_analysis")
    if getattr(pkg_logger, "_snow_ml_configured", False):
        return logging.getLogger("modules.service_now_analysis.audit")

    err_handler = DatedFileHandler(config.LOG_DIR, config.ERROR_LOG_PREFIX,
                                   retention_days=14)
    err_handler.setLevel(logging.WARNING)
    err_handler.setFormatter(formatter)

    app_handler = DatedFileHandler(config.LOG_DIR, config.APP_LOG_PREFIX,
                                   retention_days=14)
    app_handler.setLevel(logging.INFO)
    app_handler.setFormatter(formatter)

    pkg_logger.setLevel(logging.INFO)
    pkg_logger.addHandler(app_handler)
    pkg_logger.addHandler(err_handler)
    # Don't suppress propagation - host app's root logger should still see records

    audit_handler = DatedFileHandler(config.LOG_DIR, config.AUDIT_LOG_PREFIX,
                                     retention_days=30)
    audit_handler.setLevel(logging.INFO)
    audit_handler.setFormatter(formatter)

    audit_logger = logging.getLogger("modules.service_now_analysis.audit")
    audit_logger.addHandler(audit_handler)
    audit_logger.propagate = False

    pkg_logger._snow_ml_configured = True
    return audit_logger


audit = _configure_module_logging()
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lazy access to the scikit-learn pipeline.
#
# scikit-learn costs ~63 MB of resident memory and ~1.2 s to import, and it is
# pulled in by ml.predict, ml.similarity and change_predict. Importing those at
# module scope meant every one of the eight IIS worker processes paid it at
# startup - about 500 MB across the pool - whether or not that worker ever
# served a template-generator or similar-incident request. Those are the least
# used pages in the application.
#
# The wrappers below defer the import to the first actual call. Call sites are
# unchanged, so this is invisible to the views; the only cost is that the FIRST
# request to a model-backed page pays the import once per worker.
#
# Everything else in this module (pandas, the summary processor, the column
# mapper) stays eagerly imported - it is on the upload path that every user
# hits, so deferring it would buy nothing and only move the latency.
# ---------------------------------------------------------------------------

def find_similar(*args, **kwargs):
    from .ml.similarity import find_similar as _impl
    return _impl(*args, **kwargs)


def find_related_problems(*args, **kwargs):
    from .ml.similarity import find_related_problems as _impl
    return _impl(*args, **kwargs)


def find_similar_with_problems(*args, **kwargs):
    from .ml.similarity import find_similar_with_problems as _impl
    return _impl(*args, **kwargs)


def synthesize_recommendation(*args, **kwargs):
    from .ml.similarity import synthesize_recommendation as _impl
    return _impl(*args, **kwargs)


def predict_template_fields(*args, **kwargs):
    from .ml.predict import predict_template_fields as _impl
    return _impl(*args, **kwargs)


def generate_cr_template(*args, **kwargs):
    from .change_predict import generate_cr_template as _impl
    return _impl(*args, **kwargs)


def cr_models_status(*args, **kwargs):
    from .change_predict import cr_models_status as _impl
    return _impl(*args, **kwargs)


def ModelStore(*args, **kwargs):
    """Construct the real ModelStore, importing it on first use.

    A function rather than the class itself. Every call site does
    `store = ModelStore()`, so this is indistinguishable from the class -
    but if anything ever needs `isinstance(x, ModelStore)` or a class
    attribute, import the real class from .ml.predict at that point.
    """
    from .ml.predict import ModelStore as _impl
    return _impl(*args, **kwargs)


# ---------------------------------------------------------------------------
# Blueprint definition
# ---------------------------------------------------------------------------
service_now_analysis_bp = Blueprint(
    "service_now_analysis",
    __name__,
    template_folder="../../templates",   # resolves to <host_root>/templates
    static_folder=None,                  # use host's /static
    url_prefix=None,                     # set when registered in main_app.py
)


# ---------------------------------------------------------------------------
# Session storage.
#
# Sessions are persisted to disk under DATA_DIR/sessions/ so that every
# IIS worker process (wfastcgi typically spawns several) can serve any
# request, regardless of which worker handled the original upload.
# Storing the cache in a process-local dict caused intermittent 404
# "Session not found" responses on IIS because a request that landed on
# a different worker - or the same worker after a recycle - would not
# see the dict entry.
#
# The session_store module is a thin file-backed key/value layer with
# the same operations the dict-style cache used to provide:
#   session_store.set(sid, data)
#   session_store.get(sid)         -> dict | None
#   session_store.contains(sid)    -> bool
#   session_store.cleanup_expired()
#   session_store.count()
# ---------------------------------------------------------------------------

def _cleanup_expired_sessions() -> None:
    """Delegated to session_store; kept for backwards compatibility."""
    session_store.cleanup_expired()


def _cr_models_status_for_template():
    """Compact status dict used to drive the 'models trained on ...' banner."""
    try:
        return cr_models_status()
    except Exception:
        return {"all_loaded": False, "trained_at": None, "n_changes": None,
                "artifacts": {}, "field_models": []}


# Key used in Flask's signed-cookie session to remember the user's
# currently-active analysis. Stored under our own namespace so it can't
# collide with anything the host app stores in `flask.session`.
_ACTIVE_SESSION_KEY = "snow_active_session_id"


def _get_active_session_id() -> Optional[str]:
    """
    Return the user's currently-active session id if (a) the cookie
    contains one, (b) it still lives in the in-memory cache, and
    (c) it hasn't expired. Otherwise return None and clear the cookie.

    This is what makes the Template Generator and Similar Incidents
    pages work without forcing the user to re-upload - they read this
    helper to discover the active analysis and link to it.
    """
    sid = flask_session.get(_ACTIVE_SESSION_KEY)
    if not sid:
        return None
    _cleanup_expired_sessions()
    if not session_store.contains(sid):
        # Session may have expired or been cleared; cookie is stale.
        flask_session.pop(_ACTIVE_SESSION_KEY, None)
        return None
    return sid


def _set_active_session_id(sid: str) -> None:
    flask_session[_ACTIVE_SESSION_KEY] = sid
    flask_session.permanent = False  # browser-session lifetime is fine


def _clear_active_session_id() -> None:
    flask_session.pop(_ACTIVE_SESSION_KEY, None)


def _allowed_file(filename: str) -> bool:
    return ("." in filename and
            filename.rsplit(".", 1)[1].lower() in config.ALLOWED_EXTENSIONS)


# ---------------------------------------------------------------------------
# Context processor - values available to all blueprint templates
# ---------------------------------------------------------------------------
@service_now_analysis_bp.app_context_processor
def _inject_module_globals():
    # Only contribute when a service_now_analysis route is being rendered
    # so we don't pollute other modules' contexts.
    if request.blueprint != "service_now_analysis":
        return {}
    # File check, NOT ModelStore().is_trained(). is_trained() unpickles the
    # vectorizer through joblib, which imports scikit-learn - so this context
    # processor, which runs on EVERY page in the module, was pulling ~63 MB
    # into every IIS worker just to decide whether to show a nav link. See
    # config.models_available().
    trained = config.models_available()
    # Expose the active analysis session to every template so the sub-nav
    # can offer "View dashboard" / "View summary" links instead of forcing
    # a re-upload. The session id lives in Flask's signed cookie; the
    # actual data lives in the session_store on disk.
    active_sid = _get_active_session_id()
    # Fall back to the newest org-wide Incident Summary upload so a user who
    # hasn't uploaded in this browser still sees the latest shared report.
    if not active_sid:
        active_sid = session_store.get_latest("batch")
    active_sess = session_store.get(active_sid) if active_sid else None
    # Newest Service Request Summary upload (org-wide) - drives the SR
    # sub-tab links in the layout and the summary pages.
    sr_sid = session_store.get_latest("sr")
    sr_sess = session_store.get(sr_sid) if sr_sid else None
    # Expose the logged-in user so the standalone Astra layout's sidebar can
    # render the user chip. The snow routes don't pass `user=` per-render the
    # way main_app.py's routes do, so we supply it here for the whole module.
    try:
        current_user = get_current_user()
    except Exception:
        current_user = None
    # Drives the upload gate in the UI: non-members see a read-only notice in
    # place of every dropzone. The route guards are the real enforcement - this
    # only stops us offering a control that would be refused (one indexed
    # lookup, and only when somebody is actually signed in).
    snow_is_member = is_servicenow_member(current_user) if current_user else False
    return {
        "snow_models_trained": trained,
        "snow_is_member": snow_is_member,
        "snow_module_version":  "2.2",
        "snow_active_session_id": active_sid,
        "snow_active_filename":  (active_sess.get("filename") if active_sess else None),
        "snow_sr_session_id": sr_sid,
        "snow_sr_filename":  (sr_sess.get("filename") if sr_sess else None),
        "user": current_user,
    }


# ---------------------------------------------------------------------------
# Module 1: ServiceNow Analysis - statistical summary reports.
#
# Two upload kinds share one pipeline:
#   * "batch" - incident exports (snake_case field-name headers), producing
#     the Incident Summary report;
#   * "sr"    - service-request exports (display headers, normalised via
#     service_request.normalise_sr_export), producing the Service Request
#     Summary report.
#
# The ML batch dashboard (6 panels) was removed - uploads now run
# load -> validate -> preprocess -> compute_summary only.
# ---------------------------------------------------------------------------
@service_now_analysis_bp.route("/")
def index():
    # If an analysis already exists, land straight on its report (display
    # mode) instead of showing the upload form with a "view report" link.
    # `?new=1` (the "New upload" buttons on the reports) reaches the form.
    # Prefer the incident report; fall back to the SR report if only that
    # exists.
    if request.args.get("new") != "1":
        active_sid = _get_active_session_id() or session_store.get_latest("batch")
        if active_sid and session_store.contains(active_sid):
            return redirect(url_for("service_now_analysis.summary",
                                    session_id=active_sid))
        sr_sid = session_store.get_latest("sr")
        if sr_sid and session_store.contains(sr_sid):
            return redirect(url_for("service_now_analysis.sr_summary",
                                    session_id=sr_sid))
    return render_template("service_now_analysis/index.html")


def _process_summary_upload(kind: str):
    """Shared upload handler for the Incident Summary ("batch") and Service
    Request Summary ("sr") sections. Returns JSON for the XHR uploader."""
    _cleanup_expired_sessions()
    label = "service request" if kind == "sr" else "incident"

    if "file" not in request.files:
        return jsonify({"ok": False, "error": "No file part in request"}), 400
    file = request.files["file"]
    if not file.filename:
        return jsonify({"ok": False, "error": "No file selected"}), 400
    if not _allowed_file(file.filename):
        return jsonify({"ok": False,
                        "error": f"Unsupported file type. Allowed: "
                                 f"{', '.join(sorted(config.ALLOWED_EXTENSIONS))}"}), 400

    session_id = secrets.token_urlsafe(16)
    safe_name = secure_filename(file.filename)
    # Timestamp prefix makes the upload folder browseable and cleanup-friendly
    ts_prefix = datetime.now().strftime("%Y%m%d-%H%M%S")
    prefix = "sr_" if kind == "sr" else ""
    saved_path = config.UPLOAD_DIR / f"{prefix}{ts_prefix}_{session_id[:8]}_{safe_name}"

    try:
        file.save(saved_path)
    except Exception as exc:
        logger.exception("Failed to save upload")
        return jsonify({"ok": False, "error": f"Could not save file: {exc}"}), 500

    # Validate columns BEFORE running the analysis
    try:
        raw_preview = load_export(saved_path)
    except Exception as exc:
        # Don't delete the upload - leave it for inspection. Cleanup will get it.
        return jsonify({"ok": False,
                        "error": f"Could not read file: {exc}"}), 400

    # Header convention follows the FILE TYPE for both kinds: CSV exports
    # carry snake_case field names (number, short_description, opened_at);
    # Excel exports carry display headers ("Number", "Short description",
    # "Opened") and are normalised onto the same field names here.
    is_excel = saved_path.suffix.lower() in (".xlsx", ".xls")
    if is_excel:
        raw_preview = normalise_display_export(raw_preview)
    if kind == "sr":
        raw_preview = apply_sr_fallbacks(raw_preview)

    ok, missing_required, missing_recommended = validate_columns(raw_preview)
    if kind == "sr":
        missing_recommended = []   # incident-flavoured hints don't apply
    if not ok:
        # Phrase the error in the vocabulary of the uploaded file.
        if is_excel:
            missing_required = to_display_names(missing_required)
        return jsonify({
            "ok": False,
            "error": "Required columns missing",
            "missing_required": missing_required,
            "hint": f"Ensure your ServiceNow {label} export includes: " +
                    ", ".join(missing_required),
        }), 400

    if len(raw_preview) < config.MIN_ROWS_FOR_ANALYSIS:
        return jsonify({"ok": False,
                        "error": f"File has only {len(raw_preview)} rows; "
                                 f"need at least {config.MIN_ROWS_FOR_ANALYSIS}."}), 400

    coverage = column_coverage_report(raw_preview)

    # Preprocess + compute the statistical summary metrics.
    t0 = time.time()
    try:
        full_df = preprocess(raw_preview)
        # raw_preview goes in alongside the preprocessed frame for the
        # same reason workload capture needs it below: the assignment-group
        # panel attributes work to teams and names request types from the
        # category text, and preprocessing fills a blank group / category
        # with the column mode. Everything else reads the preprocessed
        # frame exactly as before.
        summary_metrics = compute_summary(full_df, raw_df=raw_preview,
                                          kind=kind)
    except Exception as exc:
        logger.exception("Summary computation failed")
        return jsonify({"ok": False, "error": f"Analysis error: {exc}"}), 500
    elapsed = round(time.time() - t0, 2)

    # Persist per-person workload (ticket number -> assignee, plus the
    # ticket's descriptive attributes) so Resource Utilization can show the
    # incidents / service requests worked in the last year. raw_preview is
    # passed alongside the preprocessed frame because preprocessing fills a
    # blank category / priority with the column mode - fine for aggregate
    # analysis, wrong on an individual's ticket list. Best-effort: a
    # failure here never fails the upload.
    try:
        from .workload_capture import capture_assigned_workload
        captured = capture_assigned_workload(full_df, kind,
                                             raw_df=raw_preview)
        if captured:
            logger.info("Captured %d assigned tickets for workload tracking",
                        captured)
    except Exception as exc:
        logger.exception("Workload capture failed (non-fatal): %s", exc)

    audit.info("UPLOAD kind=%s session=%s file=%s rows=%d elapsed=%ss",
               kind, session_id, safe_name, len(raw_preview), elapsed)

    saved = session_store.set(session_id, {
        "kind": kind,
        "summary_metrics": summary_metrics,
        "filename": safe_name,
        "uploaded_at": datetime.now().isoformat(timespec="seconds"),
        "row_count": len(raw_preview),
        "elapsed_seconds": elapsed,
        "coverage": coverage,
        "missing_recommended": missing_recommended,
        "filepath": str(saved_path),
    })
    if not saved:
        logger.error("Could not persist session %s to disk", session_id)
        return jsonify({
            "ok": False,
            "error": "Server could not save session - check server logs.",
        }), 500

    if kind == "sr":
        # Record it as the newest SR Summary org-wide.
        session_store.set_latest("sr", session_id)
        redirect_url = url_for("service_now_analysis.sr_summary",
                               session_id=session_id)
    else:
        # Remember which analysis is "active" for this browser so the user
        # doesn't have to re-upload when navigating between Template
        # Generator, Similar Incidents, and the Summary Report - and record
        # it as the newest Incident Summary org-wide.
        _set_active_session_id(session_id)
        session_store.set_latest("batch", session_id)
        redirect_url = url_for("service_now_analysis.summary",
                               session_id=session_id)

    return jsonify({
        "ok": True,
        "session_id": session_id,
        "rows": len(raw_preview),
        "elapsed_seconds": elapsed,
        "missing_recommended": missing_recommended,
        "redirect": redirect_url,
    })


@service_now_analysis_bp.route("/upload", methods=["POST"])
@snow_member_required_json
def upload():
    """Incident export upload -> Incident Summary report.

    ServiceNow group members only: the upload replaces the org-wide latest
    Incident Summary and refreshes the shared workload table.
    """
    return _process_summary_upload("batch")


@service_now_analysis_bp.route("/upload-service-request", methods=["POST"])
@snow_member_required_json
def upload_service_request():
    """Service-request export upload -> Service Request Summary report.

    ServiceNow group members only (see `upload`)."""
    return _process_summary_upload("sr")


# ---------------------------------------------------------------------------
# Module 1b: Summary Report pages (statistical)
#
# Three routes per the report pattern:
#   - GET  /summary/<sid> and /sr-summary/<sid>   render the report pages
#   - GET  /api/summary/<sid>                     JSON payload (both kinds)
#   - GET  /download/summary-excel/<sid>          multi-sheet Excel (both kinds)
# Logic preserved from the donor data_processor.py / sla_calculator.py.
# ---------------------------------------------------------------------------
def _render_summary_page(session_id: str, kind: str):
    sess = session_store.get(session_id)
    if sess is None:
        return render_template(
            "service_now_analysis/error.html",
            code=404,
            message="Session not found or expired. Please upload the file again."), 404

    # Sessions written before the kind split carry no "kind" key - treat
    # them as incident summaries.
    sess_kind = sess.get("kind") or "batch"
    if sess_kind != kind:
        return render_template(
            "service_now_analysis/error.html",
            code=404,
            message="That analysis is a different report type. "
                    "Please open it from its own tab."), 404

    metrics = sess.get("summary_metrics")
    if metrics is None:
        return render_template(
            "service_now_analysis/error.html",
            code=500,
            message="Summary report could not be generated. Check application logs."), 500

    return render_template(
        "service_now_analysis/summary.html",
        session_id=session_id,
        report_kind=("sr" if kind == "sr" else "incident"),
        filename=sess["filename"],
        uploaded_at=sess["uploaded_at"],
        row_count=sess["row_count"],
        elapsed=sess["elapsed_seconds"],
        missing_recommended=sess.get("missing_recommended", []),
    )


@service_now_analysis_bp.route("/summary/<session_id>")
def summary(session_id: str):
    """Incident Summary report."""
    return _render_summary_page(session_id, "batch")


@service_now_analysis_bp.route("/sr-summary/<session_id>")
def sr_summary(session_id: str):
    """Service Request Summary report."""
    return _render_summary_page(session_id, "sr")


@service_now_analysis_bp.route("/api/summary/<session_id>")
def api_summary(session_id: str):
    sess = session_store.get(session_id)
    if sess is None:
        return jsonify({"ok": False, "error": "Session not found"}), 404
    metrics = sess.get("summary_metrics")
    if metrics is None:
        return jsonify({"ok": False, "error": "Summary metrics unavailable for this session."}), 500
    return jsonify({"ok": True, "data": to_json_safe(metrics)})


@service_now_analysis_bp.route("/download/summary-excel/<session_id>")
def download_summary_excel(session_id: str):
    """Multi-sheet Excel report for the statistical summary."""
    sess = session_store.get(session_id)
    if sess is None:
        abort(404)
    from .utils.excel_summary_report import build_summary_excel

    metrics = sess.get("summary_metrics")
    if metrics is None:
        return jsonify({"ok": False, "error": "Summary metrics unavailable"}), 500

    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    stem = "snow_sr_summary" if sess.get("kind") == "sr" else "snow_summary"
    out_path = config.OUTPUT_DIR / f"{stem}_{ts}_{session_id[:8]}.xlsx"
    try:
        build_summary_excel(
            output_path=out_path,
            metrics=metrics,
            meta={
                "filename":     sess["filename"],
                "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "elapsed_seconds": sess["elapsed_seconds"],
                "row_count":    sess["row_count"],
            },
        )
    except Exception as exc:
        logger.exception("Summary Excel build failed")
        return jsonify({"ok": False, "error": f"Report error: {exc}"}), 500

    audit.info("DOWNLOAD_SUMMARY_EXCEL session=%s size=%d",
               session_id, out_path.stat().st_size)
    download_name = f"{stem}_{Path(sess['filename']).stem}_{ts}.xlsx"
    return send_file(
        out_path,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=download_name,
    )

@service_now_analysis_bp.route("/download/cr-template-excel", methods=["POST"])
def download_cr_template_excel():
    """
    Generate a styled .xlsx for a CR template payload posted from the UI.
    The payload mirrors the response of /api/change-template, so the
    front-end can reuse the data it already has on screen rather than
    having to regenerate the template server-side.
    """
    from .utils.cr_template_excel import build_cr_template_excel

    data = request.get_json(silent=True) or {}
    template       = data.get("template") or {}
    plan_source    = data.get("plan_source") or {}
    similar_changes = data.get("similar_changes") or []
    quality        = data.get("quality") or {}

    if not template.get("title"):
        return jsonify({"ok": False,
                        "error": "Template payload is empty or missing title."}), 400

    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    safe_title = "".join(c if c.isalnum() else "_"
                         for c in (template.get("title") or "cr"))[:60]
    out_path = config.OUTPUT_DIR / f"cr_template_{safe_title}_{ts}.xlsx"

    try:
        build_cr_template_excel(template, plan_source, similar_changes,
                                quality, out_path)
    except Exception as exc:
        logger.exception("CR template Excel build failed")
        return jsonify({"ok": False,
                        "error": f"Excel build error: {exc}"}), 500

    audit.info("DOWNLOAD_CR_TEMPLATE_EXCEL title=%s size=%d",
               safe_title, out_path.stat().st_size)

    return send_file(
        out_path,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=f"cr_template_{safe_title}_{ts}.xlsx",
    )

# ---------------------------------------------------------------------------
# Module 2: Template Generator
# ---------------------------------------------------------------------------
@service_now_analysis_bp.route("/template")
def template_page():
    return render_template("service_now_analysis/template_gen.html")


@service_now_analysis_bp.route("/template/generate", methods=["POST"])
def template_generate():
    data = request.get_json(silent=True) or request.form.to_dict()
    description = (data.get("description") or "").strip()
    scope = data.get("scope", "Individual")
    environment = data.get("environment", "Production")
    caller = data.get("caller", "Unknown")

    if not description:
        return jsonify({"ok": False, "error": "Description is required"}), 400
    if len(description) < 10:
        return jsonify({"ok": False, "error": "Please provide more detail (min 10 chars)"}), 400

    try:
        result = predict_template_fields(description, scope=scope,
                                         environment=environment, caller=caller)
    except Exception as exc:
        logger.exception("Template generation failed")
        return jsonify({"ok": False, "error": str(exc)}), 500

    similar = find_similar(description, top_n=3)
    if similar.get("status") == "ok":
        synth = synthesize_recommendation(similar["matches"])
        result["suggested_resolution_steps"] = synth["recommended_steps"]
        result["likely_root_cause"] = synth["likely_root_cause"]
        result["similar_incidents"] = [
            {"id": m["incident_id"], "title": m["title"],
             "similarity": m["similarity_score"]}
            for m in similar["matches"]
        ]
    else:
        result["suggested_resolution_steps"] = []
        result["likely_root_cause"] = ""
        result["similar_incidents"] = []

    audit.info("TEMPLATE caller=%s scope=%s env=%s pri=%s cat=%s",
               caller, scope, environment,
               result.get("priority"), result.get("category"))
    return jsonify({"ok": True, "template": to_json_safe(result)})


# ---------------------------------------------------------------------------
# Module 3: Similar Incident Finder
# ---------------------------------------------------------------------------
@service_now_analysis_bp.route("/similar")
def similar_page():
    store = ModelStore()
    corpus_df = store.corpus_dataframe()
    categories = []
    if corpus_df is not None and "category" in corpus_df.columns:
        categories = sorted(corpus_df["category"].dropna().unique().tolist())
    return render_template(
        "service_now_analysis/similar.html",
        categories=categories,
        priorities=["P1", "P2", "P3", "P4"],
    )


@service_now_analysis_bp.route("/similar/search", methods=["POST"])
def similar_search():
    data = request.get_json(silent=True) or request.form.to_dict()
    description = (data.get("description") or "").strip()
    category    = (data.get("category") or "").strip() or None
    priority    = (data.get("priority") or "").strip() or None
    top_n       = int(data.get("top_n") or config.TOP_N_SIMILAR)

    if not description:
        return jsonify({"ok": False, "error": "Description is required"}), 400

    # Incident search (existing behaviour - same key in response so the
    # existing UI keeps working unchanged).
    result = find_similar(description, category_filter=category,
                          priority_filter=priority, top_n=top_n)

    # NEW - also search the Problem corpus. If the corpus hasn't been
    # trained yet this returns {status: 'no_models', matches: []} which
    # the UI quietly hides - incident search continues to work.
    problems = find_related_problems(description,
                                     category_filter=category,
                                     top_n=3)

    audit.info("SIMILAR query_len=%d category=%s priority=%s "
               "incidents=%d problems=%d",
               len(description), category, priority,
               len(result.get("matches", [])),
               len(problems.get("matches", [])))

    return jsonify({
        "ok": True,
        "result": to_json_safe(result),  # same as before - incidents
        "problems": to_json_safe(problems),  # NEW
    })


@service_now_analysis_bp.route("/similar/synthesize", methods=["POST"])
def similar_synthesize():
    data = request.get_json(silent=True) or {}
    matches = data.get("matches", [])
    if not matches:
        return jsonify({"ok": False, "error": "No matches provided"}), 400
    rec = synthesize_recommendation(matches)
    return jsonify({"ok": True, "recommendation": to_json_safe(rec)})


# ---------------------------------------------------------------------------
# Health & uploads admin
# ---------------------------------------------------------------------------
@service_now_analysis_bp.route("/healthz")
def healthz():
    try:
        store = ModelStore()
        trained = store.is_trained()
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500
    return jsonify({
        "ok": True,
        "models_trained": trained,
        "active_sessions": session_store.count(),
        "version": "2.1",
    })


@service_now_analysis_bp.route("/about")
def about():
    """About page - explains the module to end users and the support team.

    `user` and the snow_* layout globals are supplied by the module-wide
    app_context_processor, so no per-render context is needed here.
    """
    return render_template("service_now_analysis/about.html")


@service_now_analysis_bp.route("/uploads-history")
def uploads_history():
    """Read-only listing of recent uploaded files for support / audit."""
    return render_template(
        "service_now_analysis/uploads_history.html",
        uploads=list_recent_uploads(50),
        retention_days=config.UPLOAD_RETENTION_DAYS,
    )


@service_now_analysis_bp.route("/uploads-history/clear", methods=["POST"])
def uploads_history_clear():
    """
    Remove all files in the upload directory and any matching generated
    Excel reports. Also evicts every entry in the in-memory session
    cache and drops the active-session cookie. Intended as a manual
    "reset everything" action from the upload-history page.
    """
    n_files = 0
    bytes_freed = 0
    for path in list(config.UPLOAD_DIR.glob("*")):
        if path.is_file():
            try:
                bytes_freed += path.stat().st_size
                path.unlink()
                n_files += 1
            except OSError as exc:
                logger.warning("Could not delete %s: %s", path, exc)

    # Also clear generated Excel reports - they were derived from the
    # files we just deleted so keeping them around is misleading.
    n_reports = 0
    for path in list(config.OUTPUT_DIR.glob("*.xlsx")):
        try:
            path.unlink()
            n_reports += 1
        except OSError:
            pass

    # Drop persisted sessions + cookie so the user is genuinely back to "no
    # active analysis" rather than pointing at a session whose file is
    # now gone.
    n_sessions = session_store.count()
    for _p in session_store.SESSIONS_DIR.glob("*.pkl"):
        try:
            _p.unlink()
        except OSError:
            pass
    _clear_active_session_id()

    audit.info("UPLOADS_CLEARED files=%d reports=%d sessions=%d bytes=%d",
               n_files, n_reports, n_sessions, bytes_freed)
    logger.info("Manual cleanup removed %d uploads, %d reports, %d sessions",
                n_files, n_reports, n_sessions)

    if request.is_json or request.headers.get("Accept", "").startswith("application/json"):
        return jsonify({
            "ok": True,
            "files_deleted":   n_files,
            "reports_deleted": n_reports,
            "sessions_cleared": n_sessions,
            "bytes_freed":     bytes_freed,
        })
    # Browser POST: redirect back to the history page
    return redirect(url_for("service_now_analysis.uploads_history"))


@service_now_analysis_bp.route("/uploads-history/delete", methods=["POST"])
def uploads_history_delete():
    """
    Delete ONE uploaded file from the upload directory.

    Analysis uploads are no longer age-purged - neither the file nor its
    session - so this per-file action is how a user retires an upload, and it
    removes both. The filename must be a plain name (no path separators)
    resolving to an existing file directly inside UPLOAD_DIR - a tampered
    value can never reach outside it.
    """
    name = (request.form.get("filename") or "").strip()
    if not name or name != Path(name).name:
        flash("Invalid file name.", "error")
        return redirect(url_for("service_now_analysis.uploads_history"))

    target = (config.UPLOAD_DIR / name).resolve()
    if target.parent != config.UPLOAD_DIR.resolve() or not target.is_file():
        flash("File not found.", "error")
        return redirect(url_for("service_now_analysis.uploads_history"))

    try:
        size = target.stat().st_size
        target.unlink()
        # The analysis built from this file goes with it. An Analysis session
        # is kept until it is deleted (only Open Items sessions age out), so
        # without this the report would keep serving from a file the user has
        # just retired.
        n_sess = session_store.delete_by_filepath(str(config.UPLOAD_DIR / name))
        if n_sess:
            _clear_active_session_id()
        audit.info("UPLOAD_DELETED file=%s bytes=%d sessions=%d",
                   name, size, n_sess)
        flash(f"Deleted '{name}'.", "success")
    except OSError as exc:
        logger.warning("Could not delete upload %s: %s", name, exc)
        flash(f"Could not delete '{name}': {exc}", "error")

    return redirect(url_for("service_now_analysis.uploads_history"))


# ---------------------------------------------------------------------------
# Error handlers (scoped to this blueprint)
# ---------------------------------------------------------------------------
@service_now_analysis_bp.errorhandler(413)
def _too_large(_e):
    msg = (f"Upload exceeds {config.MAX_UPLOAD_MB} MB limit. "
           f"Try a smaller file or split it into chunks.")
    if request.path.startswith(("/service-now-analysis/upload",
                                "/service-now-analysis/api/")):
        return jsonify({"ok": False, "error": msg}), 413
    return render_template("service_now_analysis/error.html",
                           code=413, message=msg), 413


# ---------------------------------------------------------------------------
# Lifecycle hooks
# ---------------------------------------------------------------------------
@service_now_analysis_bp.record_once
def _on_register(state):
    """Called once when the blueprint is registered with the host app."""
    # NOTE: upload size is bounded PER-REQUEST for this blueprint by the host
    # app's centralized policy (main_app._scope_upload_limit, which reads
    # config.MAX_CONTENT_LENGTH for the 'service_now_analysis' blueprint).
    # We deliberately do NOT mutate the shared app-wide MAX_CONTENT_LENGTH
    # here - doing so raised the cap for every other module's endpoints too.

    # Start the background cleanup thread
    start_cleanup_thread()

    logger.info(
        "ServiceNow Analysis module registered at %s (data root: %s)",
        state.url_prefix or "/", config.DATA_DIR
    )




# ===========================================================================
# 3. NEW ROUTES - add anywhere in routes.py (after the similar_page block
#    is a natural place)
# ===========================================================================

@service_now_analysis_bp.route("/change-template")
def change_template_page():
    """CR Template Generator (NEW tab)."""
    return render_template(
        "service_now_analysis/change_template.html",
        snow_active="change",
        cr_status=_cr_models_status_for_template(),
    )


@service_now_analysis_bp.route("/api/change-template", methods=["POST"])
def change_template_api():
    """JSON endpoint that drives the CR template generator UI."""
    data = request.get_json(silent=True) or {}

    title          = (data.get("title") or "").strip()
    description    = (data.get("description") or "").strip()
    planned_start  = (data.get("planned_start") or "").strip()
    planned_end    = (data.get("planned_end") or "").strip()
    environment    = (data.get("environment") or "").strip()
    server_list    = (data.get("server_list") or "").strip()
    requested_by   = (data.get("requested_by") or "").strip()

    # Quick input checks (the function below also validates)
    if not title:
        return jsonify({"status": "error",
                        "message": "Title is required."}), 400
    if not description:
        return jsonify({"status": "error",
                        "message": "Description is required."}), 400
    if not planned_start or not planned_end:
        return jsonify({"status": "error",
                        "message": "Planned start and end are required."}), 400

    try:
        result = generate_cr_template(
            title=title,
            description=description,
            planned_start=planned_start,
            planned_end=planned_end,
            environment=environment or None,
            server_list=server_list or None,
            requested_by=requested_by or None,
        )
    except Exception as exc:
        current_app.logger.exception("CR template generation failed")
        return jsonify({"status": "error",
                        "message": f"Generation failed: {exc}"}), 500

    return jsonify(to_json_safe(result))


@service_now_analysis_bp.route("/api/change-status")
def change_status_api():
    """Tiny status endpoint - used by the Change Management landing banner."""
    return jsonify(to_json_safe(_cr_models_status_for_template()))


# ---------------------------------------------------------------------------
# ServiceNow Guide - in-app tutorial (intro, change management, SCTASK,
# incident) plus the editable per-change-type approvals matrix and ServiceNow
# group management. Defined in guide_routes.py and attached to this blueprint.
# ---------------------------------------------------------------------------
from .guide_routes import init_guide_routes  # noqa: E402
init_guide_routes(service_now_analysis_bp)

# ---------------------------------------------------------------------------
# Open Incident sub-module - upload an open/pending/on-hold incident list and
# produce an overall summary, per-assignment-group professional reports, and an
# admin-only email dispatch. Defined in open_incidents_routes.py.
# ---------------------------------------------------------------------------
from .open_incidents_routes import init_open_incident_routes  # noqa: E402
init_open_incident_routes(service_now_analysis_bp)

# ---------------------------------------------------------------------------
# Open Change Request sub-module - the third tab of Open ServiceNow Items.
# Upload a change_request export and produce the four action buckets (new /
# implement / review / overdue closure) per Technical reviewer group, with an
# admin-only email dispatch. Defined in open_changes_routes.py.
# ---------------------------------------------------------------------------
from .open_changes_routes import init_open_change_routes  # noqa: E402
init_open_change_routes(service_now_analysis_bp)