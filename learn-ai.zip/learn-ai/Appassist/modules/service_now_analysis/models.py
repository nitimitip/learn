"""
models.py - ServiceNow Analysis module (Guide sub-feature).

The analytics side of this module is file/ML-backed and keeps its state in the
session_store; these two relational tables back the in-app **ServiceNow Guide**:

  * servicenow_group_members  - who belongs to the ServiceNow group. A member
                                (or an admin) can ADD a member; only an
                                application admin can REMOVE one, since
                                revoking access is the half that can lock the
                                custodians out (see guide_routes).
                                A user's application role (admin /
                                project_manager / team_member) is left untouched,
                                so ServiceNow-group access is an independent grant
                                - mirrors the Security module's
                                security_group_members table.

  * servicenow_guide_pages    - the editable body content of each guide *section*.
                                The guide is a small in-app CMS. Originally each
                                page (introduction, change management, service
                                request, incident) was one row; the guide is now
                                split into independently-editable **sections**, so
                                `slug` holds a section key - for simple pages the
                                section key equals the page slug (introduction,
                                service-request, incident, problem), and Change
                                Management is composed of several sections
                                (change-overview, change-<type>-process,
                                change-<type>-approvals). Each section body is
                                seeded once from a professional default template,
                                after which any ServiceNow-group member can edit
                                it in the WYSIWYG editor. Stored as HTML.

  * servicenow_guide_documents - reference documents attached to a guide area
                                (currently the three Change types: change-normal,
                                change-standard, change-emergency). Each row has a
                                display name, short description and an uploaded
                                file (a CR template such as a Server Build
                                template). ServiceNow-group members and admins can
                                upload and delete them; everyone can download.

Everyone - including guests - can read the guide. Only ServiceNow-group members
(and admins) can edit page content; only admins manage group membership.
"""

from sqlalchemy import Boolean, Column, Integer, String, DateTime, Text, ForeignKey
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from database import Base


class ServiceNowGroupMember(Base):
    __tablename__ = 'servicenow_group_members'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False, unique=True)
    added_by = Column(Integer, ForeignKey('users.id'))
    added_at = Column(DateTime, default=func.now())

    user = relationship('User', foreign_keys=[user_id])

    def __repr__(self):
        return f'<ServiceNowGroupMember user_id={self.user_id}>'


class GuidePage(Base):
    """One editable guide *section* (its body, stored as HTML).

    `slug` is a section key: for simple pages it equals the page slug
    (introduction / service-request / incident / problem); Change Management is
    composed of several section keys (change-overview, change-normal-process,
    change-normal-approvals, ...)."""
    __tablename__ = 'servicenow_guide_pages'

    id = Column(Integer, primary_key=True)
    slug = Column(String(60), nullable=False, unique=True, index=True)  # section key
    content = Column(Text)                                             # HTML body, edited in-app

    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    updated_by = Column(String(100))

    def __repr__(self):
        return f'<GuidePage {self.slug}>'


class GuideDocument(Base):
    """A reference document attached to a guide area (e.g. a CR template).

    `category` ties the document to a guide area - currently one of the Change
    types: change-normal / change-standard / change-emergency. The file itself
    lives outside the web root under secure_uploads/service_now_guide/<category>/
    and is served only through the download route."""
    __tablename__ = 'servicenow_guide_documents'

    id = Column(Integer, primary_key=True)
    category = Column(String(60), nullable=False, index=True)  # change-normal / change-standard / change-emergency
    name = Column(String(200), nullable=False)                 # display name
    short_description = Column(String(500))
    file_path = Column(String(500), nullable=False)            # path on disk (outside static)
    original_filename = Column(String(255))

    uploaded_by = Column(Integer, ForeignKey('users.id'))
    uploaded_at = Column(DateTime, default=func.now())

    def __repr__(self):
        return f'<GuideDocument {self.category}:{self.name}>'


class AssignmentGroupContact(Base):
    """Escalation-contact directory for a ServiceNow assignment group.

    Maps an assignment-group name (as it appears in the ServiceNow export's
    ``assignment_group`` column) to the group's own distribution address(es)
    and the managing/escalation address(es). Used by the Open Incident module
    to email a professional per-group summary to the right people. Multiple
    addresses may be stored in either field, separated by comma / semicolon /
    newline - they are normalised to a clean, de-duplicated list on save.

    ONE directory serves all three open-item digests: incidents and service
    requests key on the assignment group, change requests on the Technical
    reviewer group name.

    Maintained by ServiceNow group members and application admins - the people
    who run the digests are the ones who know which list a queue really uses.
    """
    __tablename__ = 'servicenow_assignment_groups'

    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False, unique=True, index=True)  # assignment_group value
    group_emails = Column(Text)     # the group's own DL address(es)
    manager_emails = Column(Text)   # manager / escalation address(es)

    updated_by = Column(String(100))
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    def __repr__(self):
        return f'<AssignmentGroupContact {self.name}>'


class OpenIncidentEmailSettings(Base):
    """Singleton configuration for the Open Incident summary emails.

    Holds the **Management Summary** option: when enabled AND at least one
    management address is stored, every full digest run (the manual
    "Email all groups" button or the scheduled afternoon digest) additionally
    sends ONE consolidated summary email to management, with a professional
    Excel workbook attached (a Summary sheet followed by one detail sheet per
    assignment group). Per-group emails to escalation contacts are unaffected.

    Maintained by ServiceNow group members and application admins on the
    Manage Members page (mirrors AssignmentGroupContact).
    """
    __tablename__ = 'servicenow_open_incident_email_settings'

    id = Column(Integer, primary_key=True)
    management_summary_enabled = Column(Boolean, default=False, nullable=False)
    management_emails = Column(Text)    # comma-separated, normalised on save

    updated_by = Column(String(100))
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    def __repr__(self):
        return (f'<OpenIncidentEmailSettings '
                f'enabled={self.management_summary_enabled}>')


class SnowTicketWorkload(Base):
    """One assigned ServiceNow ticket captured from a Batch Analysis upload.

    Persists enough of each row (ticket number, type, assignee, opened date
    plus the descriptive attributes below) for the Resource Utilization
    module to answer "how many incidents / service requests did this person
    work in the last year", to chart that workload by priority, to group it
    into themes of a similar nature, and to hand the person's ticket list
    back as an Excel workbook. Every new Batch Analysis upload COMPLETELY
    REFRESHES this table (see workload_capture.py) - the latest dump is the
    single source of truth, so export the full window you want counted
    (e.g. last 12 months).

    ticket_type: 'incident' (INC...), 'service_request' (REQ/RITM/SCTASK...)
    or 'other' - derived from the number prefix at capture time.

    The descriptive columns (priority, category, subcategory,
    short_description, assignment_group, state) are captured ONLY when the
    export actually populated them. The ML preprocessing pipeline fills a
    blank categorical with the column's mode, which is right for aggregate
    analysis but would fabricate an attribute on an individual's ticket
    list - so workload_capture reads them from the pre-fill frame and
    leaves a genuinely empty cell NULL. A NULL therefore means "the export
    did not say", never "the modal value".
    """
    __tablename__ = 'snow_ticket_workload'

    id            = Column(Integer, primary_key=True)
    ticket_number = Column(String(60), nullable=False, unique=True, index=True)
    ticket_type   = Column(String(30), nullable=False, default='other')
    # Intentionally a display-name STRING, not a ForeignKey to users.id: the
    # value is the assignee exactly as ServiceNow exported it, and it must
    # survive even when that person has no App Assist account or is later
    # off-boarded (app-wide "preserve names on historical records" rule).
    # Indexed because the workload roll-ups group/filter by this name.
    assigned_to   = Column(String(200), index=True)   # display name, as exported
    opened_at     = Column(DateTime)                  # ticket opened timestamp
    resolved_at   = Column(DateTime)                  # resolved timestamp, if any

    # Descriptive attributes - NULL when the export left them blank.
    priority          = Column(String(10))    # canonical P1..P4
    category          = Column(String(200))
    subcategory       = Column(String(200))
    short_description = Column(String(500))   # the ticket title
    assignment_group  = Column(String(200))
    state             = Column(String(60))    # Open / In Progress / Resolved / ...

    captured_at   = Column(DateTime, default=func.now(),
                           onupdate=func.now())

    def __repr__(self):
        return (f'<SnowTicketWorkload {self.ticket_number} '
                f'{self.ticket_type} -> {self.assigned_to}>')


def classify_ticket_number(number: str) -> str:
    """'incident' / 'service_request' / 'other' from the number prefix."""
    n = (number or '').strip().upper()
    if n.startswith('INC'):
        return 'incident'
    if n.startswith(('REQ', 'RITM', 'SCTASK')):
        return 'service_request'
    return 'other'
