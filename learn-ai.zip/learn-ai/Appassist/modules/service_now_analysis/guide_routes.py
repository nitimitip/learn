"""
guide_routes.py - ServiceNow Guide, an in-app tutorial that lives inside the
ServiceNow Analysis module.

The guide is a small in-app CMS. It is organised into **pages** (introduction,
change management, service request, incident, problem); every page is made of one
or more independently-editable **sections**, each storing a body of authored HTML
in the servicenow_guide_pages table (keyed by a *section key*). On first view a
section is seeded from a professional default template; after that any
ServiceNow-group member can edit that one section in a WYSIWYG editor - they no
longer have to edit a whole page as a single blob.

  * Simple pages (introduction, service-request, incident, problem) have exactly
    one section whose key equals the page slug.
  * Change Management is composed of several sections - an overview plus, for each
    change type (normal / standard / emergency), a *process* section and an
    *approvals* section - presented as tabs. Each change type also has a list of
    reference **documents** (servicenow_guide_documents): CR templates such as a
    Server Build template, with a name, short description and a downloadable file.

These routes are registered onto the module's existing blueprint by
``init_guide_routes(service_now_analysis_bp)`` (called at the end of routes.py),
so the guide shares the same /service-now-analysis URL prefix, layout, sidebar
and module-wide context processor (which already injects ``user`` and the
``snow_*`` layout globals).

Access model
------------
  * Reading any guide page / downloading a document - everyone, including guests.
  * Editing a section / uploading & deleting documents - ServiceNow-group members
    and admins.
  * Manage members - admins only.

"ServiceNow-group member" = the user's id is in servicenow_group_members, OR the
user is an application admin. Mirrors the Security module's group model exactly.

Note on trust: section content is authored HTML rendered with |safe. Editors are
an explicit, admin-granted group of internal users (the same trust boundary the
Security module uses), so rich HTML authoring is allowed by design. Uploaded
documents are validated (extension + MIME) and stored outside the web root, then
served only through the download route - mirroring the Application Support module.
"""

import logging
import mimetypes
import os
import re
import secrets
from collections import OrderedDict
from datetime import datetime

from flask import (
    render_template, request, redirect, url_for, flash, send_file, abort,
)
from werkzeug.utils import secure_filename

from auth import get_current_user
from csrf_utils import csrf_protect
from database import get_db_session
from models import User
import file_versions
from .access import is_servicenow_member
from .models import (
    ServiceNowGroupMember, GuidePage, GuideDocument, AssignmentGroupContact,
    OpenIncidentEmailSettings,
)

logger = logging.getLogger("modules.service_now_analysis.guide")

# Key this module's rows in the shared document_versions table.
DOC_ENTITY = file_versions.ENTITY_GUIDE_DOCUMENT


# Page identity (hero) + how the page is laid out. The hero is fixed (it names
# the page); the editable content is everything below it, split into sections.
PAGE_META = OrderedDict([
    ("introduction", {
        "icon": "fa-book-open",
        "eyebrow": "ServiceNow - User Guide",
        "title": "Creating Changes, Service Requests & Incidents",
        "subtitle": "A step-by-step process reference for the ServiceNow platform - for end users, service desk agents and change implementers.",
        "nav": "Introduction",
        "tab": "Introduction",
        "layout": "simple",
    }),
    ("change-management", {
        "icon": "fa-arrows-rotate",
        "eyebrow": "ServiceNow - Change Management",
        "title": "Change Management",
        "subtitle": "Planning and submitting Normal, Standard and Expedited (Emergency) changes - each with its required approvals and templates.",
        "nav": "Change Management",
        "tab": "CR",
        "layout": "change",
    }),
    ("service-request", {
        "icon": "fa-cart-shopping",
        "eyebrow": "ServiceNow - Service Catalog",
        "title": "Raising a Service Request (Catalog Item / RITM / SCTASK)",
        "subtitle": "Order something new - access, hardware, software or an account - and track it to fulfilment.",
        "nav": "Service Request / SCTASK",
        "tab": "Service Request",
        "layout": "simple",
    }),
    ("incident", {
        "icon": "fa-triangle-exclamation",
        "eyebrow": "ServiceNow - Incident Management",
        "title": "Raising an Incident",
        "subtitle": "Report and restore an unplanned interruption or degradation of a service as quickly as possible.",
        "nav": "Incident",
        "tab": "Incident",
        "layout": "simple",
    }),
    ("problem", {
        "icon": "fa-circle-question",
        "eyebrow": "ServiceNow - Problem Management",
        "title": "Raising a Problem",
        "subtitle": "Find and remove the root cause behind recurring incidents so the same issue stops coming back.",
        "nav": "Problem",
        "tab": "Problem",
        "layout": "simple",
    }),
])

# Reading order of the guide's tabs. The guide is ONE page with a tab per
# topic rather than five separate pages, so this is the order the reader is
# offered them in - not the order PAGE_META happens to be written in.
#
# Service Request keeps a tab even though the request for the tabbed layout
# named only Introduction / Incident / CR / Problem: it is an authored page
# with real content, and dropping it from the nav would strand that content
# with no way back to it. Delete the entry here if it is genuinely not
# wanted - nothing else needs to change.
GUIDE_TABS = ("introduction", "incident", "change-management", "problem",
              "service-request")


# The three change types shown as tabs INSIDE the CR tab. Each one has
# a process section, an approvals section and a document category.
CHANGE_TYPES = OrderedDict([
    ("normal", {
        "label": "Normal Change", "pill": "amber",
        "tag": "Planned, reviewable change", "category": "change-normal",
    }),
    ("standard", {
        "label": "Standard Change", "pill": "teal",
        "tag": "Pre-approved, repeatable change", "category": "change-standard",
    }),
    ("emergency", {
        "label": "Expedited / Emergency Change", "pill": "red",
        "tag": "Urgent change, fast-track approval", "category": "change-emergency",
    }),
])

DOC_CATEGORIES = {t["category"] for t in CHANGE_TYPES.values()}

# Change material that is the SAME whichever type you raise - the state model,
# the information every change must carry, and the hold / closure rules. It is
# rendered BELOW the change-type tabs, not in the overview above them: the
# overview's job is to get the reader onto the right tab, and burying three
# screens of shared reference above the tabs pushes them off the page.
CHANGE_COMMON = OrderedDict([
    ("change-lifecycle", {
        "label": "Lifecycle & Required Information",
        "icon": "fa-diagram-project",
        "seed": "change_lifecycle",
    }),
    ("change-hold-close", {
        "label": "Hold, Close & Go / No-Go",
        "icon": "fa-circle-pause",
        "seed": "change_hold_close",
    }),
])

_SEED = "service_now_analysis/guide/seed/{name}.html"


def _build_sections():
    """section key -> {page, label, seed}. The superset of editable units."""
    sections = OrderedDict()
    # Simple pages: one section whose key equals the page slug.
    simple_seed = {
        "introduction": "introduction",
        "service-request": "service_request",
        "incident": "incident",
        "problem": "problem",
    }
    for slug, seed_name in simple_seed.items():
        sections[slug] = {
            "page": slug,
            "label": PAGE_META[slug]["title"],
            "seed": _SEED.format(name=seed_name),
        }
    # Change Management: overview + shared reference + per-type process/approvals.
    sections["change-overview"] = {
        "page": "change-management", "label": "Overview",
        "seed": _SEED.format(name="change_overview"),
    }
    for key, meta in CHANGE_COMMON.items():
        sections[key] = {
            "page": "change-management", "label": meta["label"],
            "seed": _SEED.format(name=meta["seed"]),
        }
    for key, meta in CHANGE_TYPES.items():
        sections[f"change-{key}-process"] = {
            "page": "change-management", "label": f"{meta['label']} - Process",
            "seed": _SEED.format(name=f"change_{key}_process"),
        }
        sections[f"change-{key}-approvals"] = {
            "page": "change-management", "label": f"{meta['label']} - Approvals",
            "seed": _SEED.format(name=f"change_{key}_approvals"),
        }
    return sections


SECTIONS = _build_sections()


def _section_meta(section_key):
    """A small meta dict for the editor (edit.html uses eyebrow/title/nav)."""
    section = SECTIONS[section_key]
    page_meta = PAGE_META[section["page"]]
    return {
        "eyebrow": page_meta["eyebrow"],
        "title": section["label"],
        "nav": section["label"],
        "icon": page_meta["icon"],
    }


def _is_member(db_session, user):
    """True if the user is an admin or a ServiceNow-group member.

    Thin wrapper over access.is_servicenow_member so the guide's edit gate and
    the module's upload gate can never drift apart; the caller's open session is
    reused rather than opening a second one.
    """
    return is_servicenow_member(user, db_session)


def _get_or_seed_section(db_session, section_key):
    """Return (page_row, content_html) for a section, seeding it from its default
    template the first time it is viewed."""
    page = db_session.query(GuidePage).filter_by(slug=section_key).first()
    if page is not None:
        return page, (page.content or "")

    default_html = render_template(SECTIONS[section_key]["seed"])
    try:
        page = GuidePage(slug=section_key, content=default_html, updated_by="system")
        db_session.add(page)
        db_session.commit()
    except Exception:
        db_session.rollback()
        logger.exception("Failed seeding guide section %s", section_key)
        return None, default_html
    return page, default_html


def _change_type_blocks(db_session):
    """The three change types with their process, approvals and documents.

    Read by the CR tab. Pulled out of the old per-page route because the hub
    assembles every tab in one request - two copies of this loop would drift
    the moment a fourth change type is added.
    """
    blocks = []
    for key, meta in CHANGE_TYPES.items():
        _p, process = _get_or_seed_section(db_session, "change-%s-process" % key)
        _a, approvals = _get_or_seed_section(db_session, "change-%s-approvals" % key)
        documents = (
            db_session.query(GuideDocument)
            .filter_by(category=meta["category"])
            .order_by(GuideDocument.name).all()
        )
        blocks.append({
            "key": key,
            "label": meta["label"],
            "pill": meta["pill"],
            "tag": meta["tag"],
            "category": meta["category"],
            "process_section": "change-%s-process" % key,
            "approvals_section": "change-%s-approvals" % key,
            "process": process,
            "approvals": approvals,
            "documents": documents,
        })
    return blocks


def _change_common_blocks(db_session):
    """The shared change sections, in reading order, content included.

    Read by the CR tab and by its manage page, so the two cannot drift over
    which sections exist or what they are called.
    """
    blocks = []
    for key, meta in CHANGE_COMMON.items():
        _p, content = _get_or_seed_section(db_session, key)
        blocks.append({
            "section": key,
            "label": meta["label"],
            "icon": meta["icon"],
            "content": content,
        })
    return blocks


def _guide_hub_tabs(db_session):
    """Every tab of the guide, content included, in GUIDE_TABS order.

    The guide is one page now, so one request loads the lot: four single-
    section topics plus the CR tab's overview, six change sections and three
    document lists. That is ~14 small reads of a table with one row per
    section - the page is a static reference read a few times a day, not a
    dashboard, so the simplicity is worth more than the round trips.
    """
    tabs = []
    for slug in GUIDE_TABS:
        meta = PAGE_META[slug]
        tab = {"slug": slug, "meta": meta, "layout": meta["layout"]}
        if meta["layout"] == "change":
            _o, tab["overview"] = _get_or_seed_section(db_session, "change-overview")
            tab["types"] = _change_type_blocks(db_session)
            tab["common"] = _change_common_blocks(db_session)
        else:
            _p, tab["content"] = _get_or_seed_section(db_session, slug)
        tabs.append(tab)
    return tabs


# --- Document upload helpers (mirror Application Support's file handling) ------

ALLOWED_DOC_EXTENSIONS = {
    "txt", "pdf", "png", "jpg", "jpeg", "gif", "doc", "docx",
    "xls", "xlsx", "ppt", "pptx", "csv", "zip", "7z", "md",
}
ALLOWED_DOC_MIME = {
    "text/plain", "application/pdf", "image/png", "image/jpeg", "image/gif",
    "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "text/csv", "application/zip", "application/x-zip-compressed", "application/x-7z-compressed",
    "text/markdown",
}


def _allowed_doc(filename):
    return bool(filename) and "." in filename and \
        filename.rsplit(".", 1)[1].lower() in ALLOWED_DOC_EXTENSIONS


def _validate_doc(file):
    """Validate an uploaded document by extension and (best-effort) MIME type."""
    if not file or not file.filename:
        return False, "No file selected"
    if not _allowed_doc(file.filename):
        return False, ("File type not allowed. Allowed: "
                       + ", ".join(sorted(ALLOWED_DOC_EXTENSIONS)))
    mimetype = mimetypes.guess_type(file.filename)[0]
    if mimetype and mimetype not in ALLOWED_DOC_MIME:
        return False, f"File content type '{mimetype}' not allowed"
    return True, "ok"


_GUIDE_DOC_ROOT = os.path.join("secure_uploads", "service_now_guide")


def _doc_upload_dir(category):
    """Secure upload directory (outside the static/web root)."""
    upload_dir = os.path.join(_GUIDE_DOC_ROOT, category)
    os.makedirs(upload_dir, exist_ok=True)
    return upload_dir


def _safe_guide_doc_path(stored_path):
    """Resolve a DB-stored document path, or None if it escapes the doc root.

    Paths are written server-side at upload, so this only fires on a tampered
    row - but a read or delete must never follow a path outside the root.
    """
    if not stored_path:
        return None
    root = os.path.abspath(_GUIDE_DOC_ROOT)
    path = os.path.abspath(stored_path)
    try:
        if os.path.commonpath([root, path]) != root:
            return None
    except ValueError:  # different drive on Windows
        return None
    return path


def _guide_ref(stored_path):
    """A GuideDocument.file_path expressed relative to _GUIDE_DOC_ROOT.

    That relative form (e.g. "change-normal/2026..._cr_template.docx") is what
    the version trail stores, so a version still resolves if the document is
    later re-filed under a different change category. Returns None for a path
    outside the root - a tampered row we must not follow, since a prune would
    otherwise unlink whatever it points at.
    """
    path = _safe_guide_doc_path(stored_path)
    if not path:
        return None
    return os.path.relpath(path, os.path.abspath(_GUIDE_DOC_ROOT))


def _store_guide_upload(uploaded, category):
    """Save an uploaded document. Returns (file_path, ref, original_filename).

    The random suffix is what makes versioning safe: a timestamp alone collides
    when the same document is re-uploaded twice inside one second, and two
    version rows pointing at one file on disk would let a prune of the older row
    delete the file the newer one is still serving.
    """
    filename = secure_filename(uploaded.filename) or "document"
    upload_dir = _doc_upload_dir(category)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_path = os.path.join(upload_dir, f"{stamp}_{secrets.token_hex(3)}_{filename}")
    uploaded.save(file_path)
    return file_path, _guide_ref(file_path), uploaded.filename


def _normalize_emails(raw):
    """Split a raw address string (comma / semicolon / newline separated) into a
    clean, de-duplicated, order-preserving list of trimmed addresses.

    Kept deliberately lightweight - enough to store and mail from - rather than
    doing full RFC validation. A minimal ``x@y`` shape check drops obvious junk.
    """
    if not raw:
        return []
    parts = re.split(r"[,;\n\r]+", str(raw))
    seen = set()
    out = []
    for p in parts:
        addr = p.strip()
        if not addr or "@" not in addr or "." not in addr.split("@")[-1]:
            continue
        key = addr.lower()
        if key not in seen:
            seen.add(key)
            out.append(addr)
    return out


# ---------------------------------------------------------------------------
# Manage Members - who may do what
#
# Two levels, deliberately different:
#
#   MEMBER (ServiceNow group member OR application admin)
#       - open the Manage Members page,
#       - ADD a user to the ServiceNow group,
#       - maintain the assignment-group escalation-contact directory, which is
#         the recipient list for the Open Incident, Open Service Request AND
#         Open Change Request digests (all three read the same table),
#       - maintain the consolidated management-summary configuration.
#     The people who run these digests are the ones who know which distribution
#     list a queue actually uses, so making them wait on an administrator to
#     correct an address is what got addresses left stale.
#
#   ADMIN ONLY
#       - REMOVE a user from the ServiceNow group.
#     Granting access is additive and reversible by an admin; revoking it is the
#     destructive half - it can lock the custodians out of their own module - so
#     it stays with the application administrators.
# ---------------------------------------------------------------------------
def _denied(message="Admin access required"):
    """Flash `message` and bounce back to the guide.

    Straight to the hub, not through guide_page - that one only redirects
    here anyway, and a denial should not cost the browser two hops.
    """
    flash(message, "error")
    return redirect(url_for("service_now_analysis.guide_hub"))


def _require_member():
    """None when the caller may manage members/contacts, else a redirect."""
    user = get_current_user()
    if not user or not is_servicenow_member(user):
        return _denied("ServiceNow group membership is required to manage "
                       "members and escalation contacts.")
    return None


def _require_admin():
    """None when the caller is an application admin, else a redirect."""
    user = get_current_user()
    if not user or user.role != "admin":
        return _denied()
    return None


def init_guide_routes(bp):
    """Register all ServiceNow Guide routes onto the given blueprint."""

    # --- Read (public) -----------------------------------------------------

    @bp.route("/guide")
    def guide_hub():
        """The whole guide on one page, a tab per topic.

        ?tab=<slug> selects the open tab so a link can point at one of them;
        an unknown or missing value opens the first tab rather than erroring,
        because this is a reference page and a bad tab name is not worth a
        failure.
        """
        requested = (request.args.get("tab") or "").strip()
        active = requested if requested in PAGE_META else GUIDE_TABS[0]
        db_session = get_db_session()
        try:
            return render_template(
                "service_now_analysis/guide/hub.html",
                tabs=_guide_hub_tabs(db_session),
                active_tab=active,
                is_member=_is_member(db_session, get_current_user()),
            )
        finally:
            db_session.close()

    @bp.route("/guide/page/<slug>")
    def guide_page(slug):
        """The old per-topic URL, kept as a redirect onto the hub's tab.

        Every link, bookmark and post-edit redirect in the module still names
        this endpoint - about twenty call sites - so it stays rather than
        being rewritten out. An unknown slug lands on the first tab.
        """
        if slug not in PAGE_META:
            flash("Unknown guide page", "error")
            slug = GUIDE_TABS[0]
        return redirect(url_for("service_now_analysis.guide_hub", tab=slug))

    # --- Edit a single section (ServiceNow-group members) ------------------

    @bp.route("/guide/section/<slug>/edit", methods=["GET", "POST"])
    @csrf_protect
    def guide_edit(slug):
        if slug not in SECTIONS:
            flash("Unknown guide section", "error")
            return redirect(url_for("service_now_analysis.guide_page", slug="introduction"))

        parent = SECTIONS[slug]["page"]
        db_session = get_db_session()
        try:
            user = get_current_user()
            if not _is_member(db_session, user):
                flash("ServiceNow-group access required to edit the guide", "error")
                return redirect(url_for("service_now_analysis.guide_page", slug=parent))

            page, content = _get_or_seed_section(db_session, slug)

            if request.method == "POST":
                new_content = request.form.get("content", "")
                try:
                    if page is None:
                        page = GuidePage(slug=slug)
                        db_session.add(page)
                    page.content = new_content
                    page.updated_by = user.username
                    db_session.commit()
                    flash("Guide content updated", "success")
                    if PAGE_META[parent]["layout"] == "change":
                        return redirect(url_for("service_now_analysis.guide_manage", slug=parent))
                    return redirect(url_for("service_now_analysis.guide_page", slug=parent))
                except Exception:
                    db_session.rollback()
                    logger.exception("Error saving guide section %s", slug)
                    flash("Error saving content", "error")
                    content = new_content  # keep the user's edits in the form

            return render_template(
                "service_now_analysis/guide/edit.html",
                slug=slug, parent=parent, meta=_section_meta(slug), content=content,
            )
        finally:
            db_session.close()

    @bp.route("/guide/section/<slug>/reset", methods=["POST"])
    @csrf_protect
    def guide_reset(slug):
        """Restore a section to its professional default content (members)."""
        if slug not in SECTIONS:
            flash("Unknown guide section", "error")
            return redirect(url_for("service_now_analysis.guide_page", slug="introduction"))
        parent = SECTIONS[slug]["page"]
        db_session = get_db_session()
        try:
            user = get_current_user()
            if not _is_member(db_session, user):
                flash("ServiceNow-group access required", "error")
                return redirect(url_for("service_now_analysis.guide_page", slug=parent))
            default_html = render_template(SECTIONS[slug]["seed"])
            page = db_session.query(GuidePage).filter_by(slug=slug).first()
            if page is None:
                page = GuidePage(slug=slug)
                db_session.add(page)
            page.content = default_html
            page.updated_by = user.username
            db_session.commit()
            flash("Section reset to the default content", "success")
        except Exception:
            db_session.rollback()
            logger.exception("Error resetting guide section %s", slug)
            flash("Error resetting content", "error")
        finally:
            db_session.close()
        if PAGE_META[parent]["layout"] == "change":
            return redirect(url_for("service_now_analysis.guide_manage", slug=parent))
        return redirect(url_for("service_now_analysis.guide_page", slug=parent))

    # --- Edit hub (members) - list a page's sections & documents -----------

    @bp.route("/guide/page/<slug>/manage")
    def guide_manage(slug):
        if slug not in PAGE_META:
            flash("Unknown guide page", "error")
            return redirect(url_for("service_now_analysis.guide_page", slug="introduction"))

        db_session = get_db_session()
        try:
            user = get_current_user()
            if not _is_member(db_session, user):
                flash("ServiceNow-group access required to manage the guide", "error")
                return redirect(url_for("service_now_analysis.guide_page", slug=slug))

            # Simple pages have a single section - go straight to its editor.
            if PAGE_META[slug]["layout"] != "change":
                return redirect(url_for("service_now_analysis.guide_edit", slug=slug))

            # Change Management: list sections + per-type documents.
            types = []
            all_doc_ids = []
            for key, meta in CHANGE_TYPES.items():
                documents = (
                    db_session.query(GuideDocument)
                    .filter_by(category=meta["category"])
                    .order_by(GuideDocument.name).all()
                )
                all_doc_ids += [d.id for d in documents]
                types.append({
                    "key": key,
                    "label": meta["label"],
                    "pill": meta["pill"],
                    "category": meta["category"],
                    "process_section": f"change-{key}-process",
                    "approvals_section": f"change-{key}-approvals",
                    "documents": documents,
                })
            # Version-trail size per document, for the badge on each row.
            doc_version_counts = file_versions.version_counts(
                db_session, DOC_ENTITY, all_doc_ids)

            return render_template(
                "service_now_analysis/guide/manage.html",
                slug=slug, meta=PAGE_META[slug], types=types,
                doc_version_counts=doc_version_counts,
                overview_section="change-overview",
                common_sections=[
                    {"section": key, "label": meta["label"], "icon": meta["icon"]}
                    for key, meta in CHANGE_COMMON.items()
                ],
            )
        finally:
            db_session.close()

    # --- Documents - upload / download / delete ----------------------------

    @bp.route("/guide/documents/<category>/upload", methods=["POST"])
    @csrf_protect
    def guide_doc_upload(category):
        if category not in DOC_CATEGORIES:
            flash("Unknown document category", "error")
            return redirect(url_for("service_now_analysis.guide_page", slug="change-management"))

        db_session = get_db_session()
        try:
            user = get_current_user()
            if not _is_member(db_session, user):
                flash("ServiceNow-group access required to upload documents", "error")
                return redirect(url_for("service_now_analysis.guide_page", slug="change-management"))

            name = (request.form.get("name") or "").strip()
            short_description = (request.form.get("short_description") or "").strip()
            uploaded = request.files.get("file")

            if not name:
                flash("Please give the document a name", "error")
                return redirect(url_for("service_now_analysis.guide_manage", slug="change-management"))

            ok, message = _validate_doc(uploaded)
            if not ok:
                flash(f"Upload failed: {message}", "error")
                return redirect(url_for("service_now_analysis.guide_manage", slug="change-management"))

            if not secure_filename(uploaded.filename):
                flash("Invalid filename. Please choose a different file.", "error")
                return redirect(url_for("service_now_analysis.guide_manage", slug="change-management"))

            try:
                stored_path, ref, original_name = _store_guide_upload(uploaded, category)
            except Exception:
                logger.exception("Failed saving guide document")
                flash("Failed to save the uploaded file", "error")
                return redirect(url_for("service_now_analysis.guide_manage", slug="change-management"))

            doc = GuideDocument(
                category=category, name=name, short_description=short_description,
                file_path=stored_path, original_filename=original_name,
                uploaded_by=getattr(user, "id", None),
            )
            db_session.add(doc)
            db_session.flush()          # need doc.id to key the version row
            if ref:
                file_versions.record_version(
                    db_session, DOC_ENTITY, doc.id, _GUIDE_DOC_ROOT, ref,
                    original_filename=original_name,
                    uploaded_by=getattr(user, "id", None), note="Initial upload",
                )
            db_session.commit()
            flash("Document uploaded", "success")
        except Exception:
            db_session.rollback()
            logger.exception("Error uploading guide document")
            flash("Error uploading document", "error")
        finally:
            db_session.close()
        return redirect(url_for("service_now_analysis.guide_manage", slug="change-management"))

    @bp.route("/guide/documents/<int:doc_id>/download")
    def guide_doc_download(doc_id):
        db_session = get_db_session()
        try:
            doc = db_session.query(GuideDocument).filter_by(id=doc_id).first()
            if not doc:
                abort(404)
            file_path = _safe_guide_doc_path(doc.file_path)
            if not file_path or not os.path.exists(file_path):
                flash("File not found on disk", "error")
                return redirect(url_for("service_now_analysis.guide_page", slug="change-management"))
            return send_file(
                file_path, as_attachment=True,
                download_name=doc.original_filename or os.path.basename(file_path),
            )
        finally:
            db_session.close()

    @bp.route("/guide/documents/<int:doc_id>/edit", methods=["GET", "POST"])
    @csrf_protect
    def guide_doc_edit(doc_id):
        """Edit a document's details and, optionally, upload a new version.

        Replaces the delete-and-re-upload workaround: the row keeps its identity,
        its uploader and its date, and the previous file drops into the version
        trail instead of being destroyed. The page doubles as the version history.

        Downloading the CURRENT file is public (the guide is readable by guests),
        but the history is edit-gated to ServiceNow-group members - an old draft
        of a CR template is working material, not published guidance.
        """
        db_session = get_db_session()
        stale_paths = []
        committed = False
        try:
            user = get_current_user()
            if not _is_member(db_session, user):
                flash("ServiceNow-group access required to edit documents", "error")
                return redirect(url_for("service_now_analysis.guide_page", slug="change-management"))

            doc = db_session.query(GuideDocument).filter_by(id=doc_id).first()
            if not doc:
                flash("Document not found", "error")
                return redirect(url_for("service_now_analysis.guide_manage", slug="change-management"))

            if request.method == "POST":
                name = (request.form.get("name") or "").strip()
                if not name:
                    flash("Please give the document a name", "error")
                    return redirect(url_for("service_now_analysis.guide_doc_edit", doc_id=doc_id))

                category = (request.form.get("category") or doc.category).strip()
                if category not in DOC_CATEGORIES:
                    flash("Unknown document category", "error")
                    return redirect(url_for("service_now_analysis.guide_doc_edit", doc_id=doc_id))

                uploaded = request.files.get("file")
                replacing = bool(uploaded and uploaded.filename)
                if replacing:
                    ok, message = _validate_doc(uploaded)
                    if not ok:
                        flash(f"Upload failed: {message}", "error")
                        return redirect(url_for("service_now_analysis.guide_doc_edit", doc_id=doc_id))
                    if not secure_filename(uploaded.filename):
                        flash("Invalid filename. Please choose a different file.", "error")
                        return redirect(url_for("service_now_analysis.guide_doc_edit", doc_id=doc_id))

                doc.name = name
                doc.short_description = (request.form.get("short_description") or "").strip()
                doc.category = category

                if replacing:
                    # A document uploaded before versioning existed has no trail
                    # yet. Seed its current file as v1 first, or replacing it
                    # would erase it.
                    file_versions.backfill_initial(
                        db_session, DOC_ENTITY, doc.id, _GUIDE_DOC_ROOT,
                        _guide_ref(doc.file_path),
                        original_filename=doc.original_filename,
                        uploaded_by=doc.uploaded_by, uploaded_at=doc.uploaded_at,
                    )
                    try:
                        new_path, new_ref, original_name = _store_guide_upload(
                            uploaded, category)
                    except Exception:
                        db_session.rollback()
                        logger.exception("Failed saving guide document version")
                        flash("Failed to save the uploaded file", "error")
                        return redirect(url_for("service_now_analysis.guide_doc_edit", doc_id=doc_id))

                    file_versions.record_version(
                        db_session, DOC_ENTITY, doc.id, _GUIDE_DOC_ROOT, new_ref,
                        original_filename=original_name,
                        uploaded_by=getattr(user, "id", None),
                        note=(request.form.get("version_note") or "").strip() or None,
                    )
                    doc.file_path = new_path
                    doc.original_filename = original_name
                    # Keep the newest MAX_VERSIONS (the live file among them).
                    # protect= is a belt-and-braces guard so a bookkeeping slip
                    # can never unlink the file the document is actually serving.
                    stale_paths = file_versions.prune(
                        db_session, DOC_ENTITY, doc.id, _GUIDE_DOC_ROOT,
                        protect=(new_ref,))

                db_session.commit()
                committed = True
                flash("New version uploaded." if replacing else "Document updated.",
                      "success")
                return redirect(url_for("service_now_analysis.guide_manage",
                                        slug="change-management"))

            versions = file_versions.list_versions(db_session, DOC_ENTITY, doc.id)
            names = {
                u.id: f"{u.firstname} {u.lastname}".strip()
                for u in db_session.query(User).filter(
                    User.id.in_({v.uploaded_by for v in versions if v.uploaded_by}
                                or {0})).all()
            }
            return render_template(
                "service_now_analysis/guide/edit_document.html",
                doc=doc, versions=versions, current_ref=_guide_ref(doc.file_path),
                max_versions=file_versions.MAX_VERSIONS,
                categories=sorted(DOC_CATEGORIES), uploader_names=names,
            )
        except Exception:
            db_session.rollback()
            logger.exception("Error editing guide document %s", doc_id)
            flash("Error updating document", "error")
            return redirect(url_for("service_now_analysis.guide_manage", slug="change-management"))
        finally:
            db_session.close()
            # Unlink ONLY after a successful commit. Doing it earlier - or at all
            # on a failed transaction - would destroy the file while the version
            # rows that point at it survive the rollback.
            if committed:
                file_versions.remove_files(stale_paths)

    @bp.route("/guide/documents/<int:doc_id>/version/<int:version_id>/download")
    def guide_doc_version_download(doc_id, version_id):
        """Download one historical version - ServiceNow-group members only."""
        db_session = get_db_session()
        try:
            user = get_current_user()
            if not _is_member(db_session, user):
                abort(403)

            doc = db_session.query(GuideDocument).filter_by(id=doc_id).first()
            if not doc:
                abort(404)

            # Scoped to this document, so a version id from another one 404s.
            version = file_versions.get_version(
                db_session, DOC_ENTITY, doc.id, version_id)
            if not version:
                abort(404)

            path = file_versions.resolve_path(_GUIDE_DOC_ROOT, version.stored_filename)
            if not path or not os.path.exists(path):
                flash("That version is no longer on disk", "error")
                return redirect(url_for("service_now_analysis.guide_doc_edit", doc_id=doc_id))

            name = version.original_filename or os.path.basename(version.stored_filename)
            return send_file(path, as_attachment=True,
                             download_name=f"v{version.version_no}_{name}")
        finally:
            db_session.close()

    @bp.route("/guide/documents/<int:doc_id>/delete", methods=["POST"])
    @csrf_protect
    def guide_doc_delete(doc_id):
        db_session = get_db_session()
        try:
            user = get_current_user()
            if not _is_member(db_session, user):
                flash("ServiceNow-group access required to delete documents", "error")
                return redirect(url_for("service_now_analysis.guide_page", slug="change-management"))

            doc = db_session.query(GuideDocument).filter_by(id=doc_id).first()
            if not doc:
                flash("Document not found", "error")
                return redirect(url_for("service_now_analysis.guide_manage", slug="change-management"))

            stored_path = _safe_guide_doc_path(doc.file_path)

            # The version trail is keyed by document id, not an FK (one shared
            # table serves every module), so nothing cascades it away - this
            # route owns the cleanup. Files are unlinked only after the commit.
            stale_paths = file_versions.delete_all(
                db_session, DOC_ENTITY, doc.id, _GUIDE_DOC_ROOT)
            if stored_path:
                stale_paths.append(stored_path)

            db_session.delete(doc)
            db_session.commit()
            file_versions.remove_files(stale_paths)
            flash("Document deleted", "success")
        except Exception:
            db_session.rollback()
            logger.exception("Error deleting guide document %s", doc_id)
            flash("Error deleting document", "error")
        finally:
            db_session.close()
        return redirect(url_for("service_now_analysis.guide_manage", slug="change-management"))

    # --- Group membership - members may add, only admins may remove --------

    @bp.route("/guide/members")
    def guide_members():
        denied = _require_member()
        if denied:
            return denied

        db_session = get_db_session()
        try:
            members = db_session.query(ServiceNowGroupMember).all()
            member_user_ids = {m.user_id for m in members}
            member_rows = []
            for m in members:
                u = db_session.query(User).filter_by(id=m.user_id).first()
                if u:
                    member_rows.append({"member_id": m.id, "user": u})
            available_q = db_session.query(User).filter(User.is_active == True)
            if member_user_ids:
                available_q = available_q.filter(~User.id.in_(member_user_ids))
            available_users = available_q.order_by(User.username).all()

            # Assignment-group escalation-contact directory (Open Incident emails).
            contacts = (db_session.query(AssignmentGroupContact)
                        .order_by(AssignmentGroupContact.name).all())
            contact_rows = [{
                "id": c.id,
                "name": c.name,
                "group_emails": _normalize_emails(c.group_emails),
                "manager_emails": _normalize_emails(c.manager_emails),
                "group_emails_raw": c.group_emails or "",
                "manager_emails_raw": c.manager_emails or "",
            } for c in contacts]

            # Open-incident email configuration (management summary option).
            oi_settings = db_session.query(OpenIncidentEmailSettings).first()
            mgmt_summary = {
                "enabled": bool(oi_settings.management_summary_enabled) if oi_settings else False,
                "emails": _normalize_emails(oi_settings.management_emails) if oi_settings else [],
                "emails_raw": (oi_settings.management_emails or "") if oi_settings else "",
            }

            return render_template("service_now_analysis/guide/manage_members.html",
                                   member_rows=member_rows, available_users=available_users,
                                   contact_rows=contact_rows, mgmt_summary=mgmt_summary)
        finally:
            db_session.close()

    @bp.route("/guide/members/add", methods=["POST"])
    @csrf_protect
    def guide_add_member():
        denied = _require_member()
        if denied:
            return denied
        user = get_current_user()

        db_session = get_db_session()
        try:
            target_id = request.form.get("user_id")
            if not target_id:
                flash("Please select a user", "error")
                return redirect(url_for("service_now_analysis.guide_members"))
            existing = db_session.query(ServiceNowGroupMember).filter_by(user_id=target_id).first()
            if existing:
                flash("User is already a member of the ServiceNow group", "warning")
                return redirect(url_for("service_now_analysis.guide_members"))
            db_session.add(ServiceNowGroupMember(user_id=int(target_id), added_by=user.id))
            db_session.commit()
            flash("User added to the ServiceNow group", "success")
        except Exception:
            db_session.rollback()
            logger.exception("Error adding ServiceNow group member")
            flash("Error adding member", "error")
        finally:
            db_session.close()
        return redirect(url_for("service_now_analysis.guide_members"))

    @bp.route("/guide/members/<int:member_id>/remove", methods=["POST"])
    @csrf_protect
    def guide_remove_member(member_id):
        # Revoking access stays with application administrators - see the
        # note above _require_member.
        denied = _require_admin()
        if denied:
            return denied

        db_session = get_db_session()
        try:
            member = db_session.query(ServiceNowGroupMember).filter_by(id=member_id).first()
            if member:
                db_session.delete(member)
                db_session.commit()
                flash("User removed from the ServiceNow group", "success")
            else:
                flash("Member not found", "error")
        except Exception:
            db_session.rollback()
            logger.exception("Error removing ServiceNow group member %s", member_id)
            flash("Error removing member", "error")
        finally:
            db_session.close()
        return redirect(url_for("service_now_analysis.guide_members"))

    # --- Assignment-group escalation contacts - members + admins ----------
    # Directory of assignment_group -> group DL + manager address(es). The Open
    # Incident, Open Service Request and Open Change Request digests all read
    # this one table to address their per-group summary; for changes the row's
    # name is the Technical reviewer group.

    @bp.route("/guide/assignment-groups/save", methods=["POST"])
    @csrf_protect
    def assignment_group_save():
        """Create or update one assignment-group contact record.

        ServiceNow group members and admins may edit this directory: it is the
        recipient list for the open incident, service request AND change
        request digests, all of which read this one table.

        A hidden ``contact_id`` distinguishes edit (non-empty) from add. The
        group name is unique, so an add that collides with an existing name is
        rejected with a clear message.
        """
        denied = _require_member()
        if denied:
            return denied
        user = get_current_user()

        contact_id = (request.form.get("contact_id") or "").strip()
        name = (request.form.get("name") or "").strip()
        group_emails = ", ".join(_normalize_emails(request.form.get("group_emails")))
        manager_emails = ", ".join(_normalize_emails(request.form.get("manager_emails")))

        if not name:
            flash("Assignment group name is required", "error")
            return redirect(url_for("service_now_analysis.guide_members"))

        db_session = get_db_session()
        try:
            if contact_id:
                contact = (db_session.query(AssignmentGroupContact)
                           .filter_by(id=int(contact_id)).first())
                if not contact:
                    flash("Assignment group not found", "error")
                    return redirect(url_for("service_now_analysis.guide_members"))
                # Guard the unique name against colliding with a different row.
                clash = (db_session.query(AssignmentGroupContact)
                         .filter(AssignmentGroupContact.name == name,
                                 AssignmentGroupContact.id != contact.id).first())
                if clash:
                    flash(f"Another entry already uses the name '{name}'", "error")
                    return redirect(url_for("service_now_analysis.guide_members"))
                contact.name = name
                contact.group_emails = group_emails
                contact.manager_emails = manager_emails
                contact.updated_by = user.username
                db_session.commit()
                flash(f"Updated escalation contacts for '{name}'", "success")
            else:
                existing = (db_session.query(AssignmentGroupContact)
                            .filter_by(name=name).first())
                if existing:
                    flash(f"'{name}' already exists - edit it instead", "warning")
                    return redirect(url_for("service_now_analysis.guide_members"))
                db_session.add(AssignmentGroupContact(
                    name=name, group_emails=group_emails,
                    manager_emails=manager_emails, updated_by=user.username))
                db_session.commit()
                flash(f"Added escalation contacts for '{name}'", "success")
        except Exception:
            db_session.rollback()
            logger.exception("Error saving assignment-group contact")
            flash("Error saving assignment group", "error")
        finally:
            db_session.close()
        return redirect(url_for("service_now_analysis.guide_members"))

    @bp.route("/guide/open-incident-settings/save", methods=["POST"])
    @csrf_protect
    def open_incident_settings_save():
        """Save the Open Incident email configuration (members + admins).

        Currently one option: the consolidated Management Summary - a checkbox
        plus the management address(es) it should go to. The summary is only
        actually sent when BOTH are present (enabled + at least one address).
        """
        denied = _require_member()
        if denied:
            return denied
        user = get_current_user()

        enabled = request.form.get("management_summary_enabled") == "on"
        emails = ", ".join(_normalize_emails(request.form.get("management_emails")))

        db_session = get_db_session()
        try:
            settings = db_session.query(OpenIncidentEmailSettings).first()
            if not settings:
                settings = OpenIncidentEmailSettings()
                db_session.add(settings)
            settings.management_summary_enabled = enabled
            settings.management_emails = emails
            settings.updated_by = user.username
            db_session.commit()
            if enabled and not emails:
                flash("Management summary saved, but no valid management email "
                      "address was given - nothing will be sent until one is added.",
                      "warning")
            else:
                flash("Open-incident management summary settings saved", "success")
        except Exception:
            db_session.rollback()
            logger.exception("Error saving open-incident email settings")
            flash("Error saving management summary settings", "error")
        finally:
            db_session.close()
        return redirect(url_for("service_now_analysis.guide_members"))

    @bp.route("/guide/assignment-groups/<int:contact_id>/delete", methods=["POST"])
    @csrf_protect
    def assignment_group_delete(contact_id):
        denied = _require_member()
        if denied:
            return denied

        db_session = get_db_session()
        try:
            contact = (db_session.query(AssignmentGroupContact)
                       .filter_by(id=contact_id).first())
            if contact:
                name = contact.name
                db_session.delete(contact)
                db_session.commit()
                flash(f"Removed escalation contacts for '{name}'", "success")
            else:
                flash("Assignment group not found", "error")
        except Exception:
            db_session.rollback()
            logger.exception("Error deleting assignment-group contact %s", contact_id)
            flash("Error deleting assignment group", "error")
        finally:
            db_session.close()
        return redirect(url_for("service_now_analysis.guide_members"))
