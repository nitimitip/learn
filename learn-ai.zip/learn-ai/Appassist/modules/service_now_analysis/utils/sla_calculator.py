from datetime import datetime, timedelta
import pandas as pd
import logging

logger = logging.getLogger(__name__)

class SLACalculator:
    def __init__(self):
        # Business hours: 9 AM to 5 PM (8 hours per day)
        self.business_start_hour = 9
        self.business_end_hour = 17
        self.business_hours_per_day = 8
       
        # Working days: Monday to Friday (0=Monday, 6=Sunday)
        self.working_days = [0, 1, 2, 3, 4]

    def is_sla_met(self, created_time, resolved_time, sla_hours):
        """Check if SLA was met based on business hours"""
        if pd.isna(created_time) or pd.isna(resolved_time) or pd.isna(sla_hours):
            return False
       
        try:
            business_elapsed = self.calculate_business_hours(created_time, resolved_time)
            return business_elapsed <= sla_hours
        except Exception as e:
            logger.error(f"Error calculating SLA: {str(e)}")
            return False

    def calculate_business_hours(self, start_time, end_time):
        """Calculate business hours between two timestamps"""
        if start_time >= end_time:
            return 0
       
        current = start_time
        total_hours = 0
       
        while current.date() < end_time.date():
            # Calculate hours for current day
            day_hours = self._get_business_hours_for_day(current, current.replace(hour=23, minute=59, second=59))
            total_hours += day_hours
           
            # Move to next day
            current = current.replace(hour=0, minute=0, second=0) + timedelta(days=1)
       
        # Add hours for the final day
        if current.date() == end_time.date():
            day_hours = self._get_business_hours_for_day(current, end_time)
            total_hours += day_hours
       
        return total_hours

    def _get_business_hours_for_day(self, day_start, day_end):
        """Calculate business hours for a specific day"""
        # Check if it's a working day
        if day_start.weekday() not in self.working_days:
            return 0
       
        # Get business hours boundaries for this day
        business_start = day_start.replace(hour=self.business_start_hour, minute=0, second=0)
        business_end = day_start.replace(hour=self.business_end_hour, minute=0, second=0)
       
        # Adjust boundaries based on actual start/end times
        effective_start = max(day_start, business_start)
        effective_end = min(day_end, business_end)
       
        if effective_start >= effective_end:
            return 0
       
        # Calculate hours
        duration = effective_end - effective_start
        return duration.total_seconds() / 3600

    def get_sla_target_hours(self, priority):
        """Get SLA target hours based on priority"""
        sla_targets = {
            'P1': 4,      # 4 hours
            'P2': 8,      # 8 hours  
            'P3': 72,     # 3 days (3 * 24 hours)
            'P4': 144     # 6 working days (6 * 24 hours, but calculated in business hours)
        }
       
        # For P4, convert working days to business hours
        if priority == 'P4':
            return 6 * self.business_hours_per_day  # 6 working days = 48 business hours
       
        return sla_targets.get(priority, 24)  # Default to 24 hours

    def calculate_sla_breach_time(self, created_time, sla_hours):
        """Calculate when SLA will be breached"""
        if pd.isna(created_time) or pd.isna(sla_hours):
            return None
       
        try:
            current = created_time
            remaining_hours = sla_hours
           
            while remaining_hours > 0:
                # Calculate business hours available for current day
                day_hours = self._get_max_business_hours_for_day(current)
               
                if day_hours >= remaining_hours:
                    # SLA breach will occur today
                    hours_into_day = self._get_business_hours_elapsed_today(current)
                    target_hours_into_day = hours_into_day + remaining_hours
                   
                    # Convert back to actual time
                    business_start = current.replace(hour=self.business_start_hour, minute=0, second=0)
                    breach_time = business_start + timedelta(hours=target_hours_into_day)
                    return breach_time
                else:
                    # Move to next working day
                    remaining_hours -= day_hours
                    current = self._get_next_working_day(current)
           
            return current
        except Exception as e:
            logger.error(f"Error calculating SLA breach time: {str(e)}")
            return None

    def _get_max_business_hours_for_day(self, day):
        """Get maximum business hours available for a day"""
        if day.weekday() not in self.working_days:
            return 0
       
        business_start = day.replace(hour=self.business_start_hour, minute=0, second=0)
        business_end = day.replace(hour=self.business_end_hour, minute=0, second=0)
       
        if day < business_start:
            return self.business_hours_per_day
        elif day >= business_end:
            return 0
        else:
            remaining_duration = business_end - day
            return remaining_duration.total_seconds() / 3600

    def _get_business_hours_elapsed_today(self, current_time):
        """Get business hours elapsed since start of business day"""
        if current_time.weekday() not in self.working_days:
            return 0
       
        business_start = current_time.replace(hour=self.business_start_hour, minute=0, second=0)
       
        if current_time <= business_start:
            return 0
       
        elapsed = current_time - business_start
        return min(elapsed.total_seconds() / 3600, self.business_hours_per_day)

    def _get_next_working_day(self, current):
        """Get the next working day"""
        next_day = current + timedelta(days=1)
        while next_day.weekday() not in self.working_days:
            next_day += timedelta(days=1)
        return next_day.replace(hour=self.business_start_hour, minute=0, second=0)