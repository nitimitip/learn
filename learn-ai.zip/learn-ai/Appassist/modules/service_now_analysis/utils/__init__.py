"""Utility helpers for the ServiceNow Analysis module."""
