"""
CR Template Excel exporter.
==========================

Builds a professionally formatted .xlsx file from the same template
payload that the front-end displays - i.e. the dict returned from
`change_predict.generate_cr_template`. The intent is that a CR author
can hand this file to a peer reviewer or change manager and have
something far more shareable than a Markdown blob.

Layout (single sheet, A:D)
--------------------------
    1
    2 Change Request Template <- title bar (merged A:D)
    3 Generated YYYY-MM-DD HH:MM
    4
    5 Section heading (banded section) <- e.g. "Identification"
    6 Field Value
    7 ... ...
    n
    . Source CR / disclaimer
    . Implementation plan
    . Backout plan
    . Test plan
    . Risk & impact analysis
    . Similar past changes

All styling is done with openpyxl primitives (fills, fonts, borders,
column widths, merged cells) so the file opens cleanly in Excel,
LibreOffice, and Google Sheets.
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Style palette - kept here as module-level constants so the visual look
# stays consistent across the whole workbook and is easy to tweak in one
# place. Colours mirror the on-screen npg-red / quality-pill palette.
# ---------------------------------------------------------------------------
NPG_RED            = "C8102E"
NPG_RED_LIGHT      = "FBE6E9"
NPG_NAVY           = "1D293D"
GREY_BORDER        = "D6DAE0"
GREY_HEADER_BG     = "F1F5F9"
GREY_LABEL         = "475569"
GREEN_BG, GREEN_FG = "DCFCE7", "15803D"
AMBER_BG, AMBER_FG = "FEF3C7", "92400E"
RED_BG,   RED_FG   = "FEE2E2", "B91C1C"

THIN_BORDER = Border(
    left=Side(style="thin",   color=GREY_BORDER),
    right=Side(style="thin",  color=GREY_BORDER),
    top=Side(style="thin",    color=GREY_BORDER),
    bottom=Side(style="thin", color=GREY_BORDER),
)
NO_BORDER = Border()

WRAP   = Alignment(horizontal="left", vertical="top",     wrap_text=True)
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT   = Alignment(horizontal="left", vertical="center",  wrap_text=True)


# ---------------------------------------------------------------------------
def build_cr_template_excel(template: Dict[str, Any],
                            plan_source: Optional[Dict[str, Any]],
                            similar_changes: Optional[List[Dict[str, Any]]],
                            quality: Optional[Dict[str, Any]],
                            output_path: Path) -> Path:
    """
    Render the CR template to a styled .xlsx file and return its path.

    Parameters mirror the keys returned by `generate_cr_template`:

        template        -> the full template dict (title, type, plans, ...)
        plan_source     -> mode + source CR id + disclaimer text
        similar_changes -> list of past CRs used for context
        quality         -> per-section quality scores (optional)
        output_path     -> where to write the file
    """
    template       = template       or {}
    plan_source    = plan_source    or {}
    similar_changes = similar_changes or []
    quality        = (quality or {}).get("sections", {})

    wb = Workbook()
    ws = wb.active
    ws.title = "CR Template"

    # Column widths - A is the field-label column, B-D give plenty of
    # room for free text wrapping. Excel default is 8.43, our largest
    # body text needs ~80 chars so we set wrapping + a wide value column.
    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 60
    ws.column_dimensions["C"].width = 14
    ws.column_dimensions["D"].width = 14

    row = 1
    row = _write_title(ws, row, template.get("title") or "(untitled)")
    row += 1   # spacer

    # Section 1: Identification
    row = _write_section_header(ws, row, "Identification")
    row = _write_field(ws, row, "Title",       template.get("title"),
                                                _q(quality, "title"))
    row = _write_field(ws, row, "Description", template.get("description"),
                                                _q(quality, "description"))
    row += 1

    # Section 2: Timing & environment
    row = _write_section_header(ws, row, "Timing & environment")
    row = _write_field(ws, row, "Type",          template.get("type"),
                                                  _q(quality, "type"))
    row = _write_field(ws, row, "Planned start", _fmt_date(template.get("planned_start")),
                                                  _q(quality, "planned_window"))
    row = _write_field(ws, row, "Planned end",   _fmt_date(template.get("planned_end")),
                                                  None)
    row = _write_field(ws, row, "Environment",   template.get("environment") or "-",
                                                  _q(quality, "environment"))
    row += 1

    # Section 3: Classification
    row = _write_section_header(ws, row, "Classification")
    row = _write_field(ws, row, "Category",         template.get("category"),
                                                     _q(quality, "category"))
    row = _write_field(ws, row, "Sub-category",     template.get("subcategory"),
                                                     _q(quality, "subcategory"))
    row = _write_field(ws, row, "Business service", template.get("business_service"),
                                                     _q(quality, "business_service"))
    row += 1

    # Section 4: Risk & routing
    row = _write_section_header(ws, row, "Risk & routing")
    row = _write_field(ws, row, "Risk",             template.get("risk"),
                                                     _q(quality, "risk"))
    row = _write_field(ws, row, "Priority",         template.get("priority"),
                                                     _q(quality, "priority"))
    impact_urgency = (template.get("impact") or "-") + "  /  " + (template.get("urgency") or "-")
    row = _write_field(ws, row, "Impact / Urgency", impact_urgency,
                                                     _q(quality, "impact"))
    row = _write_field(ws, row, "Assignment group", template.get("assignment_group"),
                                                     _q(quality, "assignment_group"))
    row += 1

    # Plan provenance + disclaimer banner
    row = _write_plan_source_banner(ws, row, plan_source)
    row += 1

    # Implementation plan
    row = _write_plan_section(ws, row,
                              "Implementation plan",
                              template.get("implementation_plan") or [],
                              _q(quality, "implementation_plan"),
                              accent_fg=GREEN_FG, accent_bg=GREEN_BG)
    row += 1

    # Backout plan
    row = _write_plan_section(ws, row,
                              "Backout / rollback plan",
                              template.get("backout_plan") or [],
                              _q(quality, "backout_plan"),
                              accent_fg=AMBER_FG, accent_bg=AMBER_BG)
    row += 1

    # Test plan
    row = _write_plan_section(ws, row,
                              "Test plan",
                              template.get("test_plan") or [],
                              _q(quality, "test_plan"),
                              accent_fg="1D4ED8", accent_bg="DBEAFE")
    row += 1

    # Risk & impact analysis
    ria = (template.get("risk_impact_analysis_with_warnings")
           or template.get("risk_impact_analysis")
           or "")
    row = _write_section_header(ws, row, "Risk & impact analysis",
                                 right_quality=_q(quality, "risk_impact_analysis"))
    row = _write_long_paragraph(ws, row, ria)
    row += 1

    # Similar past CRs
    if similar_changes:
        row = _write_section_header(ws, row, "Similar past changes")
        row = _write_similar_table(ws, row, similar_changes,
                                    plan_source.get("best_match_id") or "")
        row += 1

    # Footer disclaimer
    disclaimer = (plan_source.get("disclaimer") or
                  "These steps are taken from a historical CR for "
                  "reference only - please cross-validate every step "
                  "before submitting the CR.")
    row = _write_footer(ws, row, disclaimer)

    # Freeze the title row so it stays visible on scroll
    ws.freeze_panes = "A3"

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)
    return output_path


# ---------------------------------------------------------------------------
# Internal writers - each returns the next free row.
# ---------------------------------------------------------------------------

def _write_title(ws, row: int, title_text: str) -> int:
    """Two-row header: bold title + small generation timestamp."""
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
    cell = ws.cell(row=row, column=1, value=f"Change Request Template - {title_text}")
    cell.font = Font(name="Calibri", size=16, bold=True, color="FFFFFF")
    cell.fill = PatternFill("solid", fgColor=NPG_RED)
    cell.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row].height = 32

    row += 1
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
    cell = ws.cell(row=row, column=1,
                   value="Generated " + datetime.now().strftime("%Y-%m-%d %H:%M"))
    cell.font = Font(name="Calibri", size=10, italic=True, color=GREY_LABEL)
    cell.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row].height = 18
    return row + 1


def _write_section_header(ws, row: int, heading: str,
                          right_quality: Optional[Dict] = None) -> int:
    """Tinted uppercase divider - like the on-screen 'Identification' rows."""
    if right_quality:
        # Section heading + a quality pill in the right-most cell
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=2)
        cell = ws.cell(row=row, column=1, value=heading.upper())
        cell.font = Font(name="Calibri", size=11, bold=True, color=GREY_LABEL)
        cell.fill = PatternFill("solid", fgColor=GREY_HEADER_BG)
        cell.alignment = Alignment(horizontal="left", vertical="center", indent=1)

        # Quality pill in C-D
        ws.merge_cells(start_row=row, start_column=3, end_row=row, end_column=4)
        pill = ws.cell(row=row, column=3,
                       value=f"{right_quality.get('score', '-')}/100  "
                             f"{(right_quality.get('band') or '').upper()}")
        bg, fg = _band_colours(right_quality.get("band"))
        pill.fill = PatternFill("solid", fgColor=bg)
        pill.font = Font(name="Calibri", size=10, bold=True, color=fg)
        pill.alignment = CENTER
    else:
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
        cell = ws.cell(row=row, column=1, value=heading.upper())
        cell.font = Font(name="Calibri", size=11, bold=True, color=GREY_LABEL)
        cell.fill = PatternFill("solid", fgColor=GREY_HEADER_BG)
        cell.alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.row_dimensions[row].height = 22
    return row + 1


def _write_field(ws, row: int, label: str, value: Any,
                 quality: Optional[Dict]) -> int:
    """Field row: label in A, value in B, optional quality pill in C-D."""
    label_cell = ws.cell(row=row, column=1, value=label)
    label_cell.font = Font(name="Calibri", size=10, bold=True, color=GREY_LABEL)
    label_cell.alignment = Alignment(horizontal="left", vertical="top",
                                     wrap_text=True, indent=1)
    label_cell.border = THIN_BORDER

    val_text = str(value) if value not in (None, "", "-") else "-"
    val_cell = ws.cell(row=row, column=2, value=val_text)
    val_cell.font = Font(name="Calibri", size=10, color=NPG_NAVY)
    val_cell.alignment = WRAP
    val_cell.border = THIN_BORDER

    # Merge C+D for the quality pill (or empty cells)
    ws.merge_cells(start_row=row, start_column=3, end_row=row, end_column=4)
    pill_cell = ws.cell(row=row, column=3)
    pill_cell.border = THIN_BORDER
    if quality:
        bg, fg = _band_colours(quality.get("band"))
        pill_cell.value = f"{quality.get('score', '-')}/100"
        pill_cell.fill = PatternFill("solid", fgColor=bg)
        pill_cell.font = Font(name="Calibri", size=10, bold=True, color=fg)
        pill_cell.alignment = CENTER

    # Auto-grow row height for long values (every ~70 chars => +1 line)
    char_count = len(val_text)
    extra_lines = max(0, (char_count - 60) // 70)
    ws.row_dimensions[row].height = max(20, 16 + extra_lines * 14)
    return row + 1


def _write_plan_source_banner(ws, row: int, plan_source: Dict[str, Any]) -> int:
    """One-row banner saying which past CR drove the plans (or none)."""
    mode = plan_source.get("mode", "")
    if mode in ("high_confidence_match", "best_available_match"):
        cr_id = plan_source.get("best_match_id", "")
        score = plan_source.get("best_match_score", "")
        title = plan_source.get("best_match_title", "")
        bg, fg = (GREEN_BG, GREEN_FG) if mode == "high_confidence_match" \
                                      else (AMBER_BG, AMBER_FG)
        text = (f"  Plans lifted from {cr_id} ({score}% match"
                + (" - best available)" if mode == "best_available_match" else ")"))
        if title:
            text += f"  -  {title}"
    elif mode == "no_corpus_match":
        bg, fg = (GREY_HEADER_BG, GREY_LABEL)
        text = "  No similar past CR found - please draft plans manually."
    else:
        return row

    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
    cell = ws.cell(row=row, column=1, value=text)
    cell.fill = PatternFill("solid", fgColor=bg)
    cell.font = Font(name="Calibri", size=10, bold=True, color=fg)
    cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[row].height = 22
    return row + 1


def _write_plan_section(ws, row: int, heading: str, steps: List[str],
                        quality: Optional[Dict],
                        accent_fg: str, accent_bg: str) -> int:
    """Numbered steps card - one row per step, accent-coloured number chip."""
    row = _write_section_header(ws, row, heading, right_quality=quality)

    if not steps:
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
        cell = ws.cell(row=row, column=1,
                       value="  (no steps available - draft manually)")
        cell.font = Font(name="Calibri", size=10, italic=True, color=GREY_LABEL)
        cell.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        cell.border = THIN_BORDER
        ws.row_dimensions[row].height = 20
        return row + 1

    for i, step in enumerate(steps, start=1):
        # Number chip in column A
        num_cell = ws.cell(row=row, column=1, value=str(i))
        num_cell.fill = PatternFill("solid", fgColor=accent_bg)
        num_cell.font = Font(name="Calibri", size=11, bold=True, color=accent_fg)
        num_cell.alignment = CENTER
        num_cell.border = THIN_BORDER

        # Step text in B-D (merged for max width)
        ws.merge_cells(start_row=row, start_column=2, end_row=row, end_column=4)
        step_cell = ws.cell(row=row, column=2, value=str(step))
        step_cell.font = Font(name="Calibri", size=10, color=NPG_NAVY)
        step_cell.alignment = WRAP
        step_cell.border = THIN_BORDER

        char_count = len(str(step))
        extra_lines = max(0, (char_count - 60) // 70)
        ws.row_dimensions[row].height = max(20, 16 + extra_lines * 14)
        row += 1

    return row


def _write_long_paragraph(ws, row: int, text: str) -> int:
    """Single merged cell that wraps a multi-line paragraph."""
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
    cell = ws.cell(row=row, column=1, value=text or "-")
    cell.font = Font(name="Calibri", size=10, color=NPG_NAVY)
    cell.alignment = WRAP
    cell.border = THIN_BORDER
    # Approximate height: ~110 chars per line at 60-char-wide column
    line_count = max(2, len(text or "-") // 110 + 1)
    ws.row_dimensions[row].height = 14 * line_count + 6
    return row + 1


def _write_similar_table(ws, row: int, items: List[Dict[str, Any]],
                          highlight_id: str) -> int:
    """Tabular list of similar past CRs - id, title, similarity %."""
    # Header row
    headers = [("Change ID", 1), ("Title", 2), ("Match %", 3), ("Source?", 4)]
    for label, col in headers:
        c = ws.cell(row=row, column=col, value=label)
        c.font = Font(name="Calibri", size=10, bold=True, color=GREY_LABEL)
        c.fill = PatternFill("solid", fgColor=GREY_HEADER_BG)
        c.alignment = LEFT
        c.border = THIN_BORDER
    ws.row_dimensions[row].height = 20
    row += 1

    for s in items:
        cid = str(s.get("change_id", ""))
        is_source = cid == highlight_id

        ws.cell(row=row, column=1, value=cid).font = Font(
            name="Calibri", size=10, bold=is_source,
            color=NPG_RED if is_source else NPG_NAVY)
        ws.cell(row=row, column=2,
                value=str(s.get("title", "")) +
                      (f"   ({s.get('type','')} - {s.get('risk','')})"
                       if s.get("type") or s.get("risk") else "")
                ).font = Font(name="Calibri", size=10, color=NPG_NAVY)
        ws.cell(row=row, column=3,
                value=f"{s.get('similarity_score', 0)}%"
                ).font = Font(name="Calibri", size=10, color=NPG_NAVY)
        ws.cell(row=row, column=4,
                value=("OK used as source" if is_source else "")
                ).font = Font(name="Calibri", size=10, bold=is_source,
                              color=GREEN_FG if is_source else NPG_NAVY)

        for col in (1, 2, 3, 4):
            ws.cell(row=row, column=col).border = THIN_BORDER
            ws.cell(row=row, column=col).alignment = LEFT
            if is_source:
                ws.cell(row=row, column=col).fill = PatternFill(
                    "solid", fgColor=GREEN_BG)
        ws.row_dimensions[row].height = 18
        row += 1

    return row


def _write_footer(ws, row: int, disclaimer: str) -> int:
    """Italic disclaimer line spanning all four columns."""
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
    cell = ws.cell(row=row, column=1, value=disclaimer)
    cell.font = Font(name="Calibri", size=9, italic=True, color=GREY_LABEL)
    cell.alignment = WRAP
    cell.fill = PatternFill("solid", fgColor=NPG_RED_LIGHT)
    line_count = max(2, len(disclaimer) // 130 + 1)
    ws.row_dimensions[row].height = 12 * line_count + 6
    return row + 1


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _q(quality: Dict, key: str) -> Optional[Dict]:
    """Safe lookup of a per-section quality dict."""
    if not quality:
        return None
    return quality.get(key)


def _band_colours(band: Optional[str]) -> tuple:
    """Map a quality / similarity band to (background, foreground) hex."""
    band = (band or "").lower()
    if band in ("green", "high"):
        return GREEN_BG, GREEN_FG
    if band in ("amber", "medium"):
        return AMBER_BG, AMBER_FG
    if band in ("red", "low"):
        return RED_BG, RED_FG
    return GREY_HEADER_BG, GREY_LABEL


def _fmt_date(s: Any) -> str:
    """Best-effort date formatter - falls back to the input on any error."""
    if not s:
        return "-"
    try:
        # Accepts both 'YYYY-MM-DDTHH:MM' (HTML datetime-local) and ISO
        dt = datetime.fromisoformat(str(s).replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return str(s)
