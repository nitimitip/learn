"""
JSON-safe sanitisation.

Browsers' JSON.parse rejects the tokens `NaN`, `Infinity`, `-Infinity` (per
RFC 8259), but Python's json module emits them by default for float NaN/Inf.
When the back end serialises pandas / numpy values that contain missing data,
the response body is technically not valid JSON and the front end sees a
silent parse failure (`Cannot read properties of null (reading 'data')`).

`to_json_safe` walks an arbitrary nested structure and replaces any
non-finite float with `None`, while also coercing numpy scalars into plain
Python types so jsonify doesn't have to fall back to default reprs.

Use it on every payload that includes data derived from a DataFrame.
"""

from __future__ import annotations

import math
from datetime import date, datetime, time
from typing import Any

import numpy as np
import pandas as pd


def to_json_safe(obj: Any) -> Any:
    # Plain primitives
    if obj is None or isinstance(obj, (str, bool)):
        return obj

    # Numpy scalar booleans
    if isinstance(obj, np.bool_):
        return bool(obj)

    # Integers (Python or numpy)
    if isinstance(obj, (int, np.integer)) and not isinstance(obj, bool):
        return int(obj)

    # Floats - the main offenders
    if isinstance(obj, (float, np.floating)):
        f = float(obj)
        if math.isnan(f) or math.isinf(f):
            return None
        return f

    # Datetime / Timestamp / NaT
    if isinstance(obj, (pd.Timestamp, datetime, date, time, np.datetime64)):
        try:
            if pd.isna(obj):
                return None
        except (TypeError, ValueError):
            pass
        try:
            return obj.isoformat()
        except AttributeError:
            return str(obj)

    # Numpy arrays
    if isinstance(obj, np.ndarray):
        return [to_json_safe(v) for v in obj.tolist()]

    # Pandas containers (defensive - most callers will have already
    # converted these to dicts/lists, but if not, do it here).
    if isinstance(obj, pd.Series):
        return [to_json_safe(v) for v in obj.tolist()]
    if isinstance(obj, pd.DataFrame):
        return [to_json_safe(r) for r in obj.to_dict(orient="records")]

    # Containers
    if isinstance(obj, dict):
        return {str(k): to_json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set, frozenset)):
        return [to_json_safe(v) for v in obj]

    # Last-resort scalar NA check (covers pd.NA, NaT in odd contexts)
    try:
        if pd.isna(obj):
            return None
    except (TypeError, ValueError):
        pass

    # Fall through - let jsonify raise a clear error if something exotic slips
    # through, rather than silently producing invalid JSON.
    return obj
