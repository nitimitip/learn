"""
Excel report builder for the consolidated Open Incident Management Summary.

Attached to the management summary email (see open_incident_email.py) when the
Management Summary option is enabled under Manage Members.

Styling matches the Project Management workbook exports (project_excel.py) -
NPG-red title band, dark-red subtitle/column headers, bordered field rows,
banded table bodies and soft chip fills - so the two report families read as
deliverables from the same product:

  Sheet 1      - Summary                headline KPIs, priority / ageing
                                        breakdowns and an assignment-group
                                        overview table
  Sheet 2..N   - <assignment group>     one detail sheet per group: group KPIs,
                                        per-member workload and the full open
                                        incident detail table (oldest first)

No frozen panes anywhere - these sheets scroll normally.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

logger = logging.getLogger(__name__)

# Brand palette - NPG red, identical to project_management/project_excel.py.
BRAND     = "AB1236"   # NPG red - title bands & section headers
BRAND_DK  = "7E0D27"   # darker NPG red - subtitles & column-header rows
BAND      = "F1F5F9"
BORDER    = "D7DEE7"
TEXT      = "1D293D"
MUTED     = "6B7280"

# Priority -> (fill, font) chip colours (same tones as the PM task chips).
PRIORITY_FILL = {
    "P1": ("FEE2E2", "991B1B"),
    "P2": ("FFEDD5", "9A3412"),
    "P3": ("DBEAFE", "1E40AF"),
    "P4": ("E2E8F0", "475569"),
}
# "No update" flag chip (amber, like the PM "Hold" status).
FLAG_FILL = ("FEF3C7", "92400E")

_THIN = Side(style="thin", color=BORDER)
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

CENTER   = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT_TOP = Alignment(horizontal="left", vertical="top", wrap_text=True)

# Characters Excel forbids in a worksheet name, and the 31-char limit.
_SHEET_BAD_CHARS = re.compile(r"[\[\]:*?/\\]")
_SHEET_NAME_MAX = 31


def _sheet_name(name: str, used: set) -> str:
    """A valid, unique worksheet name for an assignment group."""
    clean = _SHEET_BAD_CHARS.sub(" ", str(name or "Group")).strip() or "Group"
    clean = clean[:_SHEET_NAME_MAX]
    candidate = clean
    n = 2
    while candidate.lower() in used:
        suffix = f" ({n})"
        candidate = clean[:_SHEET_NAME_MAX - len(suffix)] + suffix
        n += 1
    used.add(candidate.lower())
    return candidate


# ---------------------------------------------------------------------------
# Style helpers (project_excel.py conventions)
# ---------------------------------------------------------------------------
def _title_band(ws, title, subtitle, ncols):
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    c = ws.cell(row=1, column=1, value=title)
    c.font = Font(name="Calibri", size=15, bold=True, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=BRAND)
    c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[1].height = 30

    if subtitle:
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
        s = ws.cell(row=2, column=1, value=subtitle)
        s.font = Font(name="Calibri", size=10, italic=True, color="FFFFFF")
        s.fill = PatternFill("solid", fgColor=BRAND_DK)
        s.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        ws.row_dimensions[2].height = 20
        return 4
    return 3


def _section_band(ws, row, label, ncols):
    """Red section header row (the PM overview 'Summary' band)."""
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    h = ws.cell(row=row, column=1, value=label)
    h.font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    h.fill = PatternFill("solid", fgColor=BRAND)
    h.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row].height = 22
    return row + 1


def _field(ws, row, label, value, value_span=1, kpi=False):
    """A bordered label/value row: dark-red label cell + plain value cell(s)."""
    lc = ws.cell(row=row, column=1, value=label)
    lc.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
    lc.fill = PatternFill("solid", fgColor=BRAND_DK)
    lc.alignment = LEFT_TOP
    lc.border = _BORDER
    if value_span > 1:
        ws.merge_cells(start_row=row, start_column=2,
                       end_row=row, end_column=1 + value_span)
    vc = ws.cell(row=row, column=2, value=value if value not in (None, "") else "-")
    vc.font = Font(name="Calibri", size=11 if kpi else 10, bold=kpi, color=TEXT)
    vc.alignment = LEFT_TOP
    vc.border = _BORDER
    for col in range(3, 2 + value_span):
        ws.cell(row=row, column=col).border = _BORDER
    ws.row_dimensions[row].height = 22
    return row + 1


def _header_row(ws, row, headers):
    for col, label in enumerate(headers, start=1):
        cell = ws.cell(row=row, column=col, value=label)
        cell.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=BRAND_DK)
        cell.alignment = CENTER
        cell.border = _BORDER
    ws.row_dimensions[row].height = 26
    return row + 1


def _style_cell(cell, banded=False, center=False):
    cell.font = Font(name="Calibri", size=10, color=TEXT)
    cell.alignment = CENTER if center else LEFT_TOP
    cell.border = _BORDER
    if banded:
        cell.fill = PatternFill("solid", fgColor=BAND)


def _chip(cell, fill, font_clr):
    cell.fill = PatternFill("solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=10, bold=True, color=font_clr)
    cell.alignment = CENTER
    cell.border = _BORDER


def _autosize(ws, widths):
    for idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width


def _empty_note(ws, row, ncols, text):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=text)
    c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
    c.alignment = CENTER
    return row + 1


# ---------------------------------------------------------------------------
# Sheet builders
# ---------------------------------------------------------------------------
def _build_summary_sheet(ws, overall: Dict[str, Any],
                         group_reports: List[Dict[str, Any]],
                         meta: Dict[str, Any],
                         item_label: str = "incident") -> None:
    plural = f"{item_label}s"
    headers = ["Assignment Group", "Open", "P1", "P2", "P3", "P4",
               "> 7 Days", "> 15 Days", "> 1 Month", "No Update",
               "Off Hold Today", "Avg Days Open", "Oldest (Days)"]
    ncols = len(headers)
    _autosize(ws, [32, 8, 6, 6, 6, 6, 10, 10, 10, 11, 14, 13, 13])

    total = overall.get("total_open", 0)
    pc = overall.get("priority_counts", {}) or {}
    ab = overall.get("ageing_bands", {}) or {}
    oldest = overall.get("oldest") or {}

    row = _title_band(
        ws, f"Open {item_label.title()} Management Summary",
        f"{total} open {item_label if total == 1 else plural} across "
        f"{len(group_reports)} assignment group{'' if len(group_reports) == 1 else 's'}",
        ncols,
    )

    row = _section_band(ws, row, "Report Metadata", ncols)
    row = _field(ws, row, "Source file", meta.get("filename", "-"), value_span=4)
    row = _field(ws, row, "Generated at",
                 meta.get("generated_at",
                          datetime.now().strftime("%Y-%m-%d %H:%M")), value_span=4)
    row = _field(ws, row, f"Total open {plural}", total, value_span=4, kpi=True)
    row = _field(ws, row, "Assignment groups", len(group_reports), value_span=4, kpi=True)
    row = _field(ws, row, "Average days open",
                 overall.get("avg_days_open", 0), value_span=4, kpi=True)
    row = _field(ws, row, f"Oldest {item_label}",
                 (f"{oldest.get('number', '-')} ({oldest.get('days_open', 0)} days)"
                  if oldest else "-"), value_span=4)
    row += 1  # spacer

    row = _section_band(ws, row, f"Open {plural.title()} by Priority", ncols)
    row = _field(ws, row, "P1 - Critical", pc.get("P1", 0), value_span=4, kpi=True)
    row = _field(ws, row, "P2 - High",     pc.get("P2", 0), value_span=4, kpi=True)
    row = _field(ws, row, "P3 - Moderate", pc.get("P3", 0), value_span=4, kpi=True)
    row = _field(ws, row, "P4 - Low",      pc.get("P4", 0), value_span=4, kpi=True)
    row += 1  # spacer

    row = _section_band(ws, row, "Ageing & Update Hygiene", ncols)
    row = _field(ws, row, "Open > 7 days",  ab.get("over_7", 0), value_span=4, kpi=True)
    row = _field(ws, row, "Open > 15 days", ab.get("over_15", 0), value_span=4, kpi=True)
    row = _field(ws, row, "Open > 1 month", ab.get("over_30", 0), value_span=4, kpi=True)
    row = _field(ws, row, "No recent update",
                 f"{overall.get('no_update_count', 0)} "
                 f"({overall.get('no_update_pct', 0)}%)", value_span=4, kpi=True)
    row += 1  # spacer

    # Off-hold-today roll-up. Summed from the group reports rather than
    # recomputed, so the workbook, the management email and the per-group
    # emails built in the same dispatch always agree on what "today" was.
    off_hold_blocks = [(rep.get("off_hold") or {}) for rep in group_reports]
    off_hold_total = sum(b.get("count", 0) for b in off_hold_blocks)
    off_hold_dated = sum(b.get("total_dated", 0) for b in off_hold_blocks)
    off_hold_date = next((b.get("date_label") for b in off_hold_blocks
                          if b.get("date_label")),
                         datetime.now().strftime("%d %b %Y"))

    row = _section_band(ws, row, "Due Off Hold Today", ncols)
    row = _field(ws, row, "Off hold date", off_hold_date, value_span=4)
    row = _field(ws, row, f"{plural.title()} due off hold today",
                 off_hold_total, value_span=4, kpi=True)
    row = _field(ws, row, "Carrying an off hold date", off_hold_dated,
                 value_span=4, kpi=True)
    row += 1  # spacer

    row = _section_band(ws, row, "Assignment Group Breakdown", ncols)
    row = _header_row(ws, row, headers)
    if not group_reports:
        _empty_note(ws, row, ncols, "No assignment groups in this upload.")
        return
    for i, rep in enumerate(group_reports, start=1):
        banded = (i % 2 == 0)
        gpc = rep.get("priority_counts", {}) or {}
        gab = rep.get("ageing_bands", {}) or {}
        goldest = rep.get("oldest") or {}
        values = [
            rep.get("group", "-"), rep.get("total_open", 0),
            gpc.get("P1", 0), gpc.get("P2", 0), gpc.get("P3", 0), gpc.get("P4", 0),
            gab.get("over_7", 0), gab.get("over_15", 0), gab.get("over_30", 0),
            rep.get("no_update_count", 0),
            (rep.get("off_hold") or {}).get("count", 0),
            rep.get("avg_days_open", 0),
            goldest.get("days_open", 0) if goldest else 0,
        ]
        for col, val in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=val)
            _style_cell(cell, banded, center=(col > 1))
        row += 1


def _build_group_sheet(ws, rep: Dict[str, Any],
                       item_label: str = "incident") -> None:
    plural = f"{item_label}s"
    headers = ["Number", "Priority", "State", "Assigned To", "Short Description",
               "Opened", "Days Open", "Duration", "No Update > 6 Days"]
    ncols = len(headers)
    _autosize(ws, [16, 10, 16, 20, 55, 17, 10, 13, 18])

    total = rep.get("total_open", 0)
    pc = rep.get("priority_counts", {}) or {}
    ab = rep.get("ageing_bands", {}) or {}
    oldest = rep.get("oldest") or {}

    row = _title_band(
        ws, rep.get("group", "Assignment group"),
        f"{total} open - avg {rep.get('avg_days_open', 0)} days - "
        f"oldest {oldest.get('days_open', 0)} days",
        ncols,
    )

    row = _section_band(ws, row, "Group KPIs", ncols)
    row = _field(ws, row, "Total open", total, value_span=2, kpi=True)
    row = _field(ws, row, "P1 / P2 / P3 / P4",
                 f"{pc.get('P1', 0)} / {pc.get('P2', 0)} / "
                 f"{pc.get('P3', 0)} / {pc.get('P4', 0)}", value_span=2, kpi=True)
    row = _field(ws, row, "Open > 7 days",  ab.get("over_7", 0), value_span=2, kpi=True)
    row = _field(ws, row, "Open > 15 days", ab.get("over_15", 0), value_span=2, kpi=True)
    row = _field(ws, row, "Open > 1 month", ab.get("over_30", 0), value_span=2, kpi=True)
    row = _field(ws, row, "No recent update",
                 f"{rep.get('no_update_count', 0)} "
                 f"({rep.get('no_update_pct', 0)}%)", value_span=2, kpi=True)
    off_hold = rep.get("off_hold") or {}
    row = _field(ws, row, "Due off hold today", off_hold.get("count", 0),
                 value_span=2, kpi=True)
    row += 1  # spacer

    # Due off hold today - listed before the full backlog because it is the
    # only part of this sheet that is actionable on the day it lands.
    row = _section_band(
        ws, row,
        f"Due Off Hold Today ({off_hold.get('date_label', '-')})", ncols)
    off_hold_rows = off_hold.get("rows") or []
    if off_hold_rows:
        row = _header_row(ws, row, ["Number", "Priority", "State", "Assigned To",
                                    "Short Description", "Off Hold"])
        for i, r in enumerate(off_hold_rows, start=1):
            banded = (i % 2 == 0)
            values = [r.get("number", ""), r.get("priority", ""), r.get("state", ""),
                      r.get("assigned_to", ""), r.get("short_description", ""),
                      r.get("off_hold_at", "")]
            for col, val in enumerate(values, start=1):
                _style_cell(ws.cell(row=row, column=col, value=val),
                            banded, center=(col in (2, 6)))
            pri = str(r.get("priority", "")).strip()
            if pri in PRIORITY_FILL:
                _chip(ws.cell(row=row, column=2), *PRIORITY_FILL[pri])
            row += 1
    elif off_hold.get("column_present"):
        row = _empty_note(ws, row, ncols, f"No {plural} come off hold today.")
    else:
        row = _empty_note(ws, row, ncols,
                          "This upload carried no Off hold date values.")
    row += 1  # spacer

    assigned = rep.get("assigned_breakdown") or []
    if assigned:
        row = _section_band(ws, row, "Assigned to Member", ncols)
        row = _header_row(ws, row, ["Member", f"Open {plural.title()}"])
        for i, a in enumerate(assigned, start=1):
            banded = (i % 2 == 0)
            _style_cell(ws.cell(row=row, column=1, value=a.get("name", "-")), banded)
            _style_cell(ws.cell(row=row, column=2, value=a.get("count", 0)),
                        banded, center=True)
            row += 1
        row += 1  # spacer

    row = _section_band(ws, row, f"Open {item_label.title()} Detail (Oldest First)", ncols)
    row = _header_row(ws, row, headers)
    table_rows = rep.get("table_rows") or []
    if not table_rows:
        _empty_note(ws, row, ncols, f"No open {plural}.")
        return
    nu_numbers = {r.get("number") for r in (rep.get("no_update_rows") or [])}
    for i, r in enumerate(table_rows, start=1):
        banded = (i % 2 == 0)
        no_update = r.get("number") in nu_numbers
        values = [
            r.get("number", ""), r.get("priority", ""), r.get("state", ""),
            r.get("assigned_to", ""), r.get("short_description", ""),
            r.get("opened_at", ""), r.get("days_open", ""),
            r.get("duration", ""), "Yes" if no_update else "",
        ]
        for col, val in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=val)
            _style_cell(cell, banded, center=(col in (2, 6, 7, 8, 9)))
        # Chips: priority colour + amber no-update flag.
        pri = str(r.get("priority", "")).strip()
        if pri in PRIORITY_FILL:
            _chip(ws.cell(row=row, column=2), *PRIORITY_FILL[pri])
        if no_update:
            _chip(ws.cell(row=row, column=9), *FLAG_FILL)
        row += 1


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def build_management_excel(output_path: Path, overall: Dict[str, Any],
                           group_reports: List[Dict[str, Any]],
                           meta: Dict[str, Any],
                           item_label: str = "incident") -> Path:
    """Build the management workbook: Summary sheet first, then one detail
    sheet per assignment group (in the same order as the summary table).
    `item_label` ("incident" / "service request") drives all wording."""
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    _build_summary_sheet(ws, overall, group_reports, meta, item_label)

    used: set = {"summary"}
    for rep in group_reports:
        _build_group_sheet(wb.create_sheet(_sheet_name(rep.get("group"), used)),
                           rep, item_label)

    wb.save(output_path)
    logger.info("Open-%s management Excel written: %s (%d bytes)",
                item_label, output_path, output_path.stat().st_size)
    return output_path
