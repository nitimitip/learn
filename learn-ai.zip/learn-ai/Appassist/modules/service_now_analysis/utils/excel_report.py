"""
Professional Excel report builder for the ServiceNow Analysis module.

Generates a single multi-sheet workbook from the inference results of a
batch upload. Replaces the older PDF + raw CSV downloads.

Sheets produced:
    1. Summary           -- KPIs and run metadata
    2. Categorisation    -- mismatches detected by the model
    3. SLA Risk          -- top at-risk open tickets
    4. Resolution Time   -- ETA forecast per ticket, plus distribution
    5. Chronic Issues    -- repeat-offender CIs
    6. Routing           -- mis-routed tickets and team workload
    7. Auto-Resolve      -- auto-resolve candidates by type
    8. Enriched Data     -- full original data with all ML fields appended

The styling matches the host application's NPG brand palette so that
when the file is opened in Excel it feels like a deliverable that came
out of the same system, not a generic spreadsheet dump.
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.chart import BarChart, PieChart, Reference
from openpyxl.formatting.rule import ColorScaleRule, CellIsRule
from openpyxl.styles import (
    Alignment, Border, Color, Font, PatternFill, Side,
)
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.worksheet.worksheet import Worksheet

logger = logging.getLogger(__name__)


# NPG brand palette (matches static/npg-theme.css)
NPG_RED       = "AB1236"
NPG_RED_DARK  = "8A0E2C"
NPG_NAVY      = "1D293D"
NPG_NAVY_MID  = "2D3F58"
NPG_BG        = "F1F5F9"
NPG_BORDER    = "E5E7EB"
NPG_TEXT      = "1D293D"
NPG_MUTED     = "6B7280"
NPG_PALE      = "FFF0F3"

# Priority colours
PRIO_COLOURS = {
    "P1": "DC3545", "1": "DC3545",
    "P2": "FD7E14", "2": "FD7E14",
    "P3": "0D6EFD", "3": "0D6EFD",
    "P4": "6C757D", "4": "6C757D",
}

THIN_BORDER = Border(
    left=Side(style="thin", color=NPG_BORDER),
    right=Side(style="thin", color=NPG_BORDER),
    top=Side(style="thin", color=NPG_BORDER),
    bottom=Side(style="thin", color=NPG_BORDER),
)


# Style helpers
def _apply_header_band(ws: Worksheet, title: str, subtitle: str = "") -> int:
    """
    Write the dark navy/red gradient-style header at the top of a sheet.
    Returns the row index where data should start.
    """
    # Row 1 - title
    ws.cell(row=1, column=1, value=title).font = Font(
        name="Calibri", size=16, bold=True, color="FFFFFF"
    )
    ws.cell(row=1, column=1).fill = PatternFill("solid", fgColor=NPG_NAVY)
    ws.cell(row=1, column=1).alignment = Alignment(vertical="center", indent=1)
    ws.row_dimensions[1].height = 32
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=8)

    # Row 2 - subtitle
    if subtitle:
        ws.cell(row=2, column=1, value=subtitle).font = Font(
            name="Calibri", size=10, color="FFFFFF"
        )
        ws.cell(row=2, column=1).fill = PatternFill("solid", fgColor=NPG_NAVY_MID)
        ws.cell(row=2, column=1).alignment = Alignment(vertical="center", indent=1)
        ws.row_dimensions[2].height = 20
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=8)
        return 4
    return 3


def _style_table_header(ws: Worksheet, row: int, n_cols: int) -> None:
    for c in range(1, n_cols + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=NPG_NAVY_MID)
        cell.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        cell.border = THIN_BORDER
    ws.row_dimensions[row].height = 22


def _write_dataframe(ws: Worksheet, df: pd.DataFrame, start_row: int,
                     auto_width: bool = True,
                     priority_col: Optional[str] = None) -> int:
    """Write a DataFrame with header band + zebra striping. Returns next free row."""
    if df is None or df.empty:
        ws.cell(row=start_row, column=1, value="No data available.").font = Font(
            name="Calibri", italic=True, color=NPG_MUTED
        )
        return start_row + 2

    # Header
    for c, col_name in enumerate(df.columns, start=1):
        ws.cell(row=start_row, column=c, value=str(col_name))
    _style_table_header(ws, start_row, len(df.columns))

    # Body
    for r_offset, (_, row) in enumerate(df.iterrows()):
        excel_row = start_row + 1 + r_offset
        zebra = (r_offset % 2 == 1)
        for c, col_name in enumerate(df.columns, start=1):
            val = row[col_name]
            if pd.isna(val):
                val = ""
            elif isinstance(val, (pd.Timestamp, datetime)):
                val = val.to_pydatetime() if hasattr(val, "to_pydatetime") else val
            elif isinstance(val, (np.integer,)):
                val = int(val)
            elif isinstance(val, (np.floating,)):
                val = float(val) if np.isfinite(val) else ""
            elif isinstance(val, np.bool_):
                val = bool(val)

            cell = ws.cell(row=excel_row, column=c, value=val)
            cell.font = Font(name="Calibri", size=10, color=NPG_TEXT)
            cell.alignment = Alignment(horizontal="left", vertical="center", indent=1)
            cell.border = THIN_BORDER
            if zebra:
                cell.fill = PatternFill("solid", fgColor=NPG_BG)

            # Highlight priority cells
            if priority_col and col_name == priority_col:
                p = str(val).strip()
                if p in PRIO_COLOURS:
                    cell.fill = PatternFill("solid", fgColor=PRIO_COLOURS[p])
                    cell.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
                    cell.alignment = Alignment(horizontal="center", vertical="center")

    end_row = start_row + len(df)

    # Auto-fit columns (capped to keep things sane)
    if auto_width:
        for c, col_name in enumerate(df.columns, start=1):
            max_len = len(str(col_name))
            for r in range(start_row + 1, end_row + 1):
                v = ws.cell(row=r, column=c).value
                if v is not None:
                    max_len = max(max_len, min(len(str(v)), 60))
            ws.column_dimensions[get_column_letter(c)].width = min(max_len + 4, 60)

    ws.freeze_panes = ws.cell(row=start_row + 1, column=1)
    return end_row + 2


def _write_kpi_block(ws: Worksheet, start_row: int,
                     items: List[tuple]) -> int:
    """
    Write a 2-column KPI block: label | value.
    items is a list of (label, value) tuples.
    """
    for i, (label, value) in enumerate(items):
        row = start_row + i

        c1 = ws.cell(row=row, column=1, value=label)
        c1.font = Font(name="Calibri", size=10, bold=True, color=NPG_MUTED)
        c1.fill = PatternFill("solid", fgColor=NPG_BG)
        c1.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        c1.border = THIN_BORDER

        c2 = ws.cell(row=row, column=2, value=value)
        c2.font = Font(name="Calibri", size=11, bold=True, color=NPG_TEXT)
        c2.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        c2.border = THIN_BORDER

        ws.row_dimensions[row].height = 22

    ws.column_dimensions["A"].width = 32
    ws.column_dimensions["B"].width = 28
    return start_row + len(items) + 2


# Sheet builders
def _build_summary_sheet(ws: Worksheet, panels: Dict[str, Any],
                         summary: Dict[str, Any], meta: Dict[str, Any]) -> None:
    row = _apply_header_band(
        ws, "ServiceNow Batch Analysis", "Summary report"
    )

    # Run metadata
    ws.cell(row=row, column=1, value="RUN METADATA").font = Font(
        name="Calibri", size=11, bold=True, color=NPG_RED
    )
    row += 1
    row = _write_kpi_block(ws, row, [
        ("Source file",       meta.get("filename", "-")),
        ("Generated at",      meta.get("generated_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))),
        ("Total rows",        summary.get("total_rows", 0)),
        ("Open tickets",      summary.get("open_count", 0)),
        ("Resolved tickets",  summary.get("resolved_count", 0)),
        ("Distinct categories", summary.get("categories", 0)),
        ("Distinct teams",    summary.get("teams", 0)),
        ("Inference time",    f"{meta.get('elapsed_seconds', 0)} s"),
    ])

    # Headline numbers from panels
    p1 = panels.get("panel1", {}) or {}
    p2 = panels.get("panel2", {}) or {}
    p3 = (panels.get("panel3", {}) or {}).get("summary", {}) or {}
    p4 = panels.get("panel4", {}) or {}
    p5 = panels.get("panel5", {}) or {}
    p6 = panels.get("panel6", {}) or {}

    ws.cell(row=row, column=1, value="HEADLINE FINDINGS").font = Font(
        name="Calibri", size=11, bold=True, color=NPG_RED
    )
    row += 1
    row = _write_kpi_block(ws, row, [
        ("Categorisation mismatches",       p1.get("total_mismatches", 0)),
        ("Mismatch rate (%)",               p1.get("mismatch_pct", 0)),
        ("High-risk open tickets (%)",      p2.get("high_risk_pct", 0)),
        ("Mean predicted resolution (h)",   round(p3.get("mean", 0) or 0, 2)),
        ("Median predicted resolution (h)", round(p3.get("median", 0) or 0, 2)),
        ("Chronic CIs detected",            len(p4.get("top_chronic_cis", []) or [])),
        ("Mis-routed tickets",              p5.get("mis_routed_count", 0)),
        ("Auto-resolve candidates",         p6.get("total_count", 0)),
        ("Estimated hours saved",           round(p6.get("estimated_hours_saved", 0) or 0, 1)),
    ])


def _build_categorisation_sheet(ws: Worksheet, p1: Dict[str, Any]) -> None:
    row = _apply_header_band(
        ws, "Categorisation", f"{p1.get('total_mismatches', 0)} mismatches "
                              f"({p1.get('mismatch_pct', 0)}%)"
    )

    counts = p1.get("category_counts") or {}
    if counts:
        df_counts = pd.DataFrame(
            sorted(counts.items(), key=lambda x: -x[1]),
            columns=["Category", "Tickets"]
        )
        ws.cell(row=row, column=1, value="ML CATEGORY DISTRIBUTION").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        row = _write_dataframe(ws, df_counts, row)

    samples = p1.get("sample_mismatches") or []
    if samples:
        ws.cell(row=row, column=1, value="SAMPLE MISMATCHES").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        df_mis = pd.DataFrame(samples).rename(columns={
            "incident_id": "Incident",
            "title": "Title",
            "category": "Current category",
            "ml_category": "ML category",
            "ml_category_confidence": "Confidence",
        })
        if "Confidence" in df_mis.columns:
            df_mis["Confidence"] = (df_mis["Confidence"] * 100).round(1)
        cols = [c for c in ["Incident", "Title", "Current category",
                            "ML category", "Confidence"] if c in df_mis.columns]
        _write_dataframe(ws, df_mis[cols], row)


def _build_sla_sheet(ws: Worksheet, p2: Dict[str, Any]) -> None:
    row = _apply_header_band(
        ws, "SLA Breach Risk",
        f"{p2.get('high_risk_pct', 0)}% of open tickets at high risk"
    )

    rows = p2.get("top_at_risk") or []
    if not rows:
        ws.cell(row=row, column=1, value="No open tickets to score.").font = Font(
            name="Calibri", italic=True, color=NPG_MUTED
        )
        return

    df = pd.DataFrame(rows).rename(columns={
        "incident_id": "Incident",
        "title": "Title",
        "priority": "Priority",
        "sla_breach_risk_score": "Risk score",
        "days_until_breach": "Days until breach",
        "assignment_group": "Team",
    })
    if "Risk score" in df.columns:
        df["Risk score"] = (df["Risk score"] * 100).round(1)
    if "Days until breach" in df.columns:
        df["Days until breach"] = df["Days until breach"].round(1)

    cols = [c for c in ["Incident", "Title", "Priority", "Risk score",
                        "Days until breach", "Team"] if c in df.columns]
    end_row = _write_dataframe(ws, df[cols], row, priority_col="Priority")

    # Conditional colour scale on Risk score column
    if "Risk score" in cols:
        col_idx = cols.index("Risk score") + 1
        col_letter = get_column_letter(col_idx)
        risk_range = f"{col_letter}{row + 1}:{col_letter}{end_row - 2}"
        ws.conditional_formatting.add(
            risk_range,
            ColorScaleRule(start_type="num", start_value=0,    start_color="22C55E",
                           mid_type="num",   mid_value=50,     mid_color="F59E0B",
                           end_type="num",   end_value=100,    end_color="DC3545")
        )


def _build_eta_sheet(ws: Worksheet, p3: Dict[str, Any]) -> None:
    summary = p3.get("summary") or {}
    row = _apply_header_band(
        ws, "Predicted Resolution Time",
        f"Mean {summary.get('mean', 0):.1f}h - "
        f"Median {summary.get('median', 0):.1f}h - "
        f"P90 {summary.get('p90', 0):.1f}h"
    )

    by_team = p3.get("by_team") or []
    if by_team:
        ws.cell(row=row, column=1, value="MEAN ETA BY TEAM").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        df = pd.DataFrame(by_team).rename(columns={
            "assignment_group": "Team",
            "mean": "Mean (h)",
            "count": "Tickets",
        })
        for c in ["Mean (h)"]:
            if c in df.columns:
                df[c] = df[c].round(2)
        cols = [c for c in ["Team", "Mean (h)", "Tickets"] if c in df.columns]
        end_row = _write_dataframe(ws, df[cols], row)

        # Embedded bar chart - mean ETA per team
        chart = BarChart()
        chart.type = "bar"
        chart.style = 10
        chart.title = "Mean predicted ETA by team"
        chart.y_axis.title = "Team"
        chart.x_axis.title = "Hours"
        if "Mean (h)" in cols and len(df):
            data_col = cols.index("Mean (h)") + 1
            label_col = cols.index("Team") + 1
            data_ref = Reference(ws, min_col=data_col, max_col=data_col,
                                 min_row=row, max_row=row + len(df))
            cats_ref = Reference(ws, min_col=label_col, max_col=label_col,
                                 min_row=row + 1, max_row=row + len(df))
            chart.add_data(data_ref, titles_from_data=True)
            chart.set_categories(cats_ref)
            chart.height = 10
            chart.width = 18
            ws.add_chart(chart, f"E{row}")
        row = end_row


def _build_chronic_sheet(ws: Worksheet, p4: Dict[str, Any]) -> None:
    row = _apply_header_band(
        ws, "Chronic Issues",
        f"{len(p4.get('top_chronic_cis') or [])} chronic CIs - "
        f"{len(p4.get('clusters') or [])} clusters"
    )

    cis = p4.get("top_chronic_cis") or []
    if cis:
        ws.cell(row=row, column=1, value="TOP CHRONIC CIs").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        df = pd.DataFrame(cis).rename(columns={
            "ci": "CI",
            "incident_count": "Incident count",
            "suggested_problem_title": "Suggested problem title",
        })
        cols = [c for c in ["CI", "Incident count", "Suggested problem title"]
                if c in df.columns]
        row = _write_dataframe(ws, df[cols], row)

    clusters = p4.get("clusters") or []
    if clusters:
        ws.cell(row=row, column=1, value="DISCOVERED CLUSTERS").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        rows = [{
            "Cluster ID": c.get("cluster_id"),
            "Size": c.get("size"),
            "Top terms": ", ".join(c.get("top_terms") or []),
        } for c in clusters]
        _write_dataframe(ws, pd.DataFrame(rows), row)


def _build_routing_sheet(ws: Worksheet, p5: Dict[str, Any]) -> None:
    row = _apply_header_band(
        ws, "Routing Optimisation",
        f"{p5.get('mis_routed_count', 0)} mis-routed tickets detected"
    )

    mis = p5.get("mis_routed") or []
    if mis:
        ws.cell(row=row, column=1, value="MIS-ROUTED TICKETS").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        df = pd.DataFrame(mis).rename(columns={
            "incident_id": "Incident",
            "title": "Title",
            "assignment_group": "Current team",
            "suggested_assignment_group": "Suggested team",
            "priority": "Priority",
        })
        cols = [c for c in ["Incident", "Title", "Priority",
                            "Current team", "Suggested team"] if c in df.columns]
        row = _write_dataframe(ws, df[cols], row, priority_col="Priority")

    re_teams = p5.get("high_reassignment_teams") or []
    if re_teams:
        ws.cell(row=row, column=1, value="TEAMS WITH HIGH REASSIGNMENT").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        df = pd.DataFrame(re_teams).rename(columns={
            "assignment_group": "Team",
            "mean": "Avg reassignments",
            "sum": "Total reassignments",
        })
        for c in ["Avg reassignments"]:
            if c in df.columns:
                df[c] = df[c].round(2)
        cols = [c for c in ["Team", "Avg reassignments", "Total reassignments"]
                if c in df.columns]
        _write_dataframe(ws, df[cols], row)


def _build_auto_resolve_sheet(ws: Worksheet, p6: Dict[str, Any]) -> None:
    row = _apply_header_band(
        ws, "Auto-Resolve Candidates",
        f"{p6.get('total_count', 0)} candidates - "
        f"~{p6.get('estimated_hours_saved', 0):.1f}h saved"
    )

    by_type = p6.get("by_type") or {}
    if not by_type:
        ws.cell(row=row, column=1, value="No auto-resolve candidates identified.").font = Font(
            name="Calibri", italic=True, color=NPG_MUTED
        )
        return

    df = pd.DataFrame(
        [{"Type": k.replace("_", " ").title(), "Count": v} for k, v in by_type.items()]
    ).sort_values("Count", ascending=False)

    end_row = _write_dataframe(ws, df, row)

    # Pie chart
    if len(df):
        chart = PieChart()
        chart.title = "Auto-resolve candidates by type"
        labels = Reference(ws, min_col=1, max_col=1,
                           min_row=row + 1, max_row=row + len(df))
        data = Reference(ws, min_col=2, max_col=2,
                         min_row=row, max_row=row + len(df))
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(labels)
        chart.height = 10
        chart.width = 14
        ws.add_chart(chart, f"E{row}")


def _build_enriched_sheet(ws: Worksheet, enriched: pd.DataFrame) -> None:
    _apply_header_band(
        ws, "Enriched Data",
        f"Original ticket data with all ML predictions appended ({len(enriched)} rows)"
    )

    if enriched is None or enriched.empty:
        ws.cell(row=4, column=1, value="No enriched data available.").font = Font(
            name="Calibri", italic=True, color=NPG_MUTED
        )
        return

    # Cap to first 10,000 rows so the file stays openable. If exceeded,
    # add a note in cell A3.
    cap = 10_000
    if len(enriched) > cap:
        ws.cell(row=3, column=1,
                value=f"Showing first {cap:,} of {len(enriched):,} rows. "
                      f"For the full dataset re-run analysis with a smaller export.").font = Font(
            name="Calibri", italic=True, color=NPG_RED
        )
        ws.merge_cells(start_row=3, start_column=1, end_row=3, end_column=8)
        enriched = enriched.head(cap)

    # Pick a sensible column ordering: ID + key fields first, then ML
    # predictions, then everything else.
    preferred = [
        "incident_id", "title", "category", "ml_category", "ml_category_confidence",
        "subcategory", "ml_subcategory",
        "priority", "ml_priority", "ml_priority_confidence",
        "state", "assignment_group", "ml_suggested_assignment_group",
        "opened_timestamp", "resolved_timestamp", "due_date",
        "resolution_hours", "ml_predicted_resolution_hours",
        "sla_breach_risk_score", "days_until_breach",
        "is_auto_resolve_candidate", "auto_resolve_type",
        "is_chronic_ci", "configuration_item",
    ]
    ordered = [c for c in preferred if c in enriched.columns]
    ordered += [c for c in enriched.columns if c not in ordered]

    _write_dataframe(ws, enriched[ordered], 4, priority_col="priority")


# Public API
def build_excel_report(
    output_path: Path,
    panels: Dict[str, Any],
    summary: Dict[str, Any],
    meta: Dict[str, Any],
    enriched_df: Optional[pd.DataFrame] = None,
) -> Path:
    """
    Build a multi-sheet Excel report.

    Parameters
    ----------
    output_path : Path
        Where to write the .xlsx
    panels : dict
        The full panel payload produced by ml.predict (panel1..panel6).
    summary : dict
        Top-level summary KPIs (total_rows, open_count, resolved_count, ...).
    meta : dict
        {filename, generated_at, elapsed_seconds, ...}
    enriched_df : DataFrame, optional
        Original ticket data with ML predictions appended. If supplied,
        becomes the "Enriched Data" sheet.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    # First sheet is created by default - rename it to Summary
    ws_summary = wb.active
    ws_summary.title = "Summary"
    _build_summary_sheet(ws_summary, panels, summary, meta)

    _build_categorisation_sheet(wb.create_sheet("Categorisation"),
                                panels.get("panel1", {}) or {})
    _build_sla_sheet(wb.create_sheet("SLA Risk"),
                     panels.get("panel2", {}) or {})
    _build_eta_sheet(wb.create_sheet("Resolution Time"),
                     panels.get("panel3", {}) or {})
    _build_chronic_sheet(wb.create_sheet("Chronic Issues"),
                         panels.get("panel4", {}) or {})
    _build_routing_sheet(wb.create_sheet("Routing"),
                         panels.get("panel5", {}) or {})
    _build_auto_resolve_sheet(wb.create_sheet("Auto-Resolve"),
                              panels.get("panel6", {}) or {})

    if enriched_df is not None:
        _build_enriched_sheet(wb.create_sheet("Enriched Data"), enriched_df)

    wb.save(output_path)
    logger.info("Excel report written: %s (%d bytes)",
                output_path, output_path.stat().st_size)
    return output_path
