"""
Background cleanup of uploaded files and generated reports.

Every CLEANUP_INTERVAL_HOURS, walks UPLOAD_DIR and OUTPUT_DIR and removes
files older than the configured retention. Runs in a daemon thread so it
does not block the host application's shutdown.

Retention policy per upload type:
  * Open ServiceNow Items uploads (open_* / open_sr_*) - age-purged after
    UPLOAD_RETENTION_DAYS (previous-day files are removed automatically).
  * ServiceNow Analysis uploads (no prefix / sr_*) - NEVER auto-deleted;
    they remain until the user removes them from the Upload History page.
  * Generated reports in OUTPUT_DIR - age-purged after OUTPUT_RETENTION_DAYS.

Usage (from the blueprint init):

    from .utils.upload_cleanup import start_cleanup_thread
    start_cleanup_thread()

The first cleanup pass also runs synchronously at startup so stale files
from a previous deployment are cleared immediately.
"""

from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Tuple

from .. import config

logger = logging.getLogger(__name__)

_started = False
_lock = threading.Lock()


def _cleanup_directory(directory: Path, retention_days: int,
                       name_prefixes: Tuple[str, ...] | None = None) -> Tuple[int, int]:
    """
    Remove files in `directory` older than `retention_days`.

    When `name_prefixes` is given, ONLY files whose name starts with one of
    the prefixes are eligible - everything else is left alone regardless of
    age. Returns (n_deleted, total_bytes_freed).
    """
    if not directory.exists():
        return 0, 0
    cutoff = datetime.now() - timedelta(days=retention_days)
    cutoff_ts = cutoff.timestamp()

    n = 0
    bytes_freed = 0
    for path in directory.rglob("*"):
        if not path.is_file():
            continue
        if name_prefixes is not None and not path.name.startswith(name_prefixes):
            continue
        try:
            mtime = path.stat().st_mtime
            if mtime < cutoff_ts:
                size = path.stat().st_size
                path.unlink()
                n += 1
                bytes_freed += size
                logger.debug("Cleanup removed %s (%.1f KB, age %.1f days)",
                             path.name, size / 1024,
                             (datetime.now().timestamp() - mtime) / 86400)
        except OSError as exc:
            logger.warning("Cleanup could not remove %s: %s", path, exc)

    # Remove empty subdirectories
    for sub in sorted(directory.rglob("*"), key=lambda p: -len(p.parts)):
        if sub.is_dir() and not any(sub.iterdir()):
            try:
                sub.rmdir()
            except OSError:
                pass

    return n, bytes_freed


# Only Open ServiceNow Items uploads (open_*.csv/xlsx, incl. open_sr_*) are
# age-purged. ServiceNow Analysis uploads (no prefix / sr_) are kept until
# the user deletes them from the Upload History page.
_AUTO_PURGE_PREFIXES: Tuple[str, ...] = ("open_",)


def run_cleanup_once() -> None:
    """Run a single cleanup pass synchronously."""
    try:
        n_up, bytes_up = _cleanup_directory(
            config.UPLOAD_DIR, config.UPLOAD_RETENTION_DAYS,
            name_prefixes=_AUTO_PURGE_PREFIXES,
        )
        n_out, bytes_out = _cleanup_directory(
            config.OUTPUT_DIR, config.OUTPUT_RETENTION_DAYS
        )
        if n_up or n_out:
            logger.info(
                "Upload cleanup: removed %d open-items upload(s) (%.1f MB) older "
                "than %d days; %d report(s) (%.1f MB) older than %d days",
                n_up, bytes_up / (1024 * 1024), config.UPLOAD_RETENTION_DAYS,
                n_out, bytes_out / (1024 * 1024), config.OUTPUT_RETENTION_DAYS,
            )
        else:
            logger.debug("Upload cleanup: nothing to remove")
    except Exception as exc:
        logger.exception("Upload cleanup failed: %s", exc)


def _cleanup_loop() -> None:
    """Background loop. Sleeps between passes."""
    interval = max(1, int(config.CLEANUP_INTERVAL_HOURS)) * 3600
    while True:
        time.sleep(interval)
        run_cleanup_once()


def start_cleanup_thread() -> None:
    """
    Start the background cleanup thread (idempotent).
    Also runs one synchronous pass right away so stale files from a
    previous deployment are cleared at startup.
    """
    global _started
    with _lock:
        if _started:
            return
        _started = True

    # Initial synchronous pass
    run_cleanup_once()

    t = threading.Thread(target=_cleanup_loop,
                         name="snow_ml_upload_cleanup",
                         daemon=True)
    t.start()
    logger.info(
        "Upload cleanup thread started (interval %sh, "
        "upload retention %s days, output retention %s days)",
        config.CLEANUP_INTERVAL_HOURS,
        config.UPLOAD_RETENTION_DAYS,
        config.OUTPUT_RETENTION_DAYS,
    )


def list_recent_uploads(limit: int = 50) -> List[dict]:
    """Return metadata for recent uploaded files (for an admin view if needed)."""
    if not config.UPLOAD_DIR.exists():
        return []
    files = []
    for p in config.UPLOAD_DIR.iterdir():
        if p.is_file():
            try:
                stat = p.stat()
                files.append({
                    "name": p.name,
                    "size_bytes": stat.st_size,
                    "uploaded_at": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
                })
            except OSError:
                continue
    files.sort(key=lambda f: f["uploaded_at"], reverse=True)
    return files[:limit]
