"""
Excel report builder for the statistical Summary Report.

Mirrors the structure of utils/excel_report.py (the ML report) so both
downloads feel like they came out of the same product:

  Sheet 1 - Quality Score    headline number, rating, weight breakdown
  Sheet 2 - SLA Trends       monthly SLA met % vs breach
  Sheet 3 - Resolution Time  histogram + descriptive stats
  Sheet 4 - Priority Trends  monthly P1..P4 counts
  Sheet 5 - State Trends     monthly counts by incident state
  Sheet 6 - Incident Types   top 10 categories by count
  Sheet 7 - Reopened         distribution by reopen count
  Sheet 8 - Long-Open        distribution by age band
  Sheet 9 - Assignment Groups    per-group workload and resolution
  Sheet 10 - Group Request Types group x request type, with timings
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

import pandas as pd
from openpyxl import Workbook

from .excel_report import (
    NPG_BG, NPG_BORDER, NPG_MUTED, NPG_NAVY, NPG_NAVY_MID, NPG_RED, NPG_TEXT,
    _apply_header_band, _style_table_header, _write_dataframe, _write_kpi_block,
)
from openpyxl.chart import BarChart, LineChart, PieChart, Reference
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Sheet builders
# ---------------------------------------------------------------------------
def _build_quality_sheet(ws, quality: Dict[str, Any], support: Dict[str, Any],
                         total_incidents: int, meta: Dict[str, Any]) -> None:
    row = _apply_header_band(ws, "Service Quality Score",
                             f"Overall: {quality.get('rating', '-')}")

    # Run metadata
    ws.cell(row=row, column=1, value="REPORT METADATA").font = Font(
        name="Calibri", size=11, bold=True, color=NPG_RED
    )
    row += 1
    row = _write_kpi_block(ws, row, [
        ("Source file",       meta.get("filename", "-")),
        ("Generated at",      meta.get("generated_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))),
        ("Total incidents",   total_incidents),
        ("Inference time",    f"{meta.get('elapsed_seconds', 0)} s"),
    ])

    # Headline
    score   = quality.get("score", "-")
    rating  = quality.get("rating", "-")
    metrics = quality.get("metrics", {}) or {}

    ws.cell(row=row, column=1, value="HEADLINE QUALITY SCORE").font = Font(
        name="Calibri", size=11, bold=True, color=NPG_RED
    )
    row += 1
    row = _write_kpi_block(ws, row, [
        ("Score (out of 100)",     score),
        ("Rating",                 rating),
        ("SLA met %",              metrics.get("sla_met_pct", "-")),
        ("Average resolution (h)", metrics.get("avg_resolution_hours", "-")),
        ("Reopen rate %",          metrics.get("reopen_rate", "-")),
        ("Open incidents",         metrics.get("open_incidents", "-")),
        ("High-priority share %",  metrics.get("high_priority_pct", "-")),
    ])

    # Weight breakdown
    weights = quality.get("weightages", {}) or {}
    if weights:
        ws.cell(row=row, column=1, value="WEIGHTED CONTRIBUTION BREAKDOWN").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        rows = []
        for name in ["sla_met", "resolution_time", "reopen_rate", "incident_backlog",
                     "high_priority", "customer_feedback"]:
            w = weights.get(name, {})
            rows.append({
                "Metric":            name.replace("_", " ").title(),
                "Sub-score (0-100)": w.get("score", "-"),
                "Weight (%)":        w.get("weight", "-"),
                "Contribution":      w.get("contribution", "-"),
            })
        _write_dataframe(ws, pd.DataFrame(rows), row)


def _build_sla_trends_sheet(ws, trends: Dict[str, Any]) -> None:
    row = _apply_header_band(ws, "SLA Trends",
                             "Monthly SLA performance: met vs breached")

    table = trends.get("table_data") or []
    if not table:
        ws.cell(row=row, column=1, value="No data available.").font = Font(
            name="Calibri", italic=True, color=NPG_MUTED
        )
        return

    df = pd.DataFrame(table)
    cols = [c for c in ["Month", "SLA Met", "SLA Breach", "Total", "SLA Met %"]
            if c in df.columns]
    end_row = _write_dataframe(ws, df[cols], row)

    # Embedded line chart of SLA Met %
    if "SLA Met %" in cols and len(df) > 1:
        try:
            chart = LineChart()
            chart.title = "SLA met % by month"
            chart.y_axis.title = "%"
            data_col = cols.index("SLA Met %") + 1
            label_col = cols.index("Month") + 1
            data_ref = Reference(ws, min_col=data_col, max_col=data_col,
                                 min_row=row, max_row=row + len(df))
            cats_ref = Reference(ws, min_col=label_col, max_col=label_col,
                                 min_row=row + 1, max_row=row + len(df))
            chart.add_data(data_ref, titles_from_data=True)
            chart.set_categories(cats_ref)
            chart.height = 10
            chart.width = 18
            ws.add_chart(chart, f"G{row}")
        except Exception:
            logger.exception("Failed to add SLA trends chart")


def _build_resolution_sheet(ws, reso: Dict[str, Any]) -> None:
    stats = reso.get("stats") or {}
    row = _apply_header_band(
        ws, "Resolution Time Distribution",
        f"Mean {stats.get('mean_hours', 0)}h - Median {stats.get('median_hours', 0)}h",
    )

    if stats:
        ws.cell(row=row, column=1, value="DESCRIPTIVE STATISTICS").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        row = _write_kpi_block(ws, row, [
            ("Mean (hours)",   stats.get("mean_hours")),
            ("Median (hours)", stats.get("median_hours")),
            ("Min (hours)",    stats.get("min_hours")),
            ("Max (hours)",    stats.get("max_hours")),
        ])

    table = reso.get("table_data") or []
    if table:
        ws.cell(row=row, column=1, value="HISTOGRAM").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        df = pd.DataFrame(table)
        cols = [c for c in ["Time Range", "Count", "Percentage"] if c in df.columns]
        end_row = _write_dataframe(ws, df[cols], row)

        if "Count" in cols:
            try:
                chart = BarChart()
                chart.title = "Tickets by resolution-time band"
                chart.y_axis.title = "Tickets"
                data_col = cols.index("Count") + 1
                label_col = cols.index("Time Range") + 1
                data_ref = Reference(ws, min_col=data_col, max_col=data_col,
                                     min_row=row, max_row=row + len(df))
                cats_ref = Reference(ws, min_col=label_col, max_col=label_col,
                                     min_row=row + 1, max_row=row + len(df))
                chart.add_data(data_ref, titles_from_data=True)
                chart.set_categories(cats_ref)
                chart.height = 10
                chart.width = 16
                ws.add_chart(chart, f"E{row}")
            except Exception:
                logger.exception("Failed to add resolution-time chart")


def _build_priority_trends_sheet(ws, pri: Dict[str, Any]) -> None:
    row = _apply_header_band(ws, "Priority Trends",
                             "Monthly counts by priority")
    table = pri.get("table_data") or []
    if not table:
        ws.cell(row=row, column=1, value="No data available.").font = Font(
            name="Calibri", italic=True, color=NPG_MUTED
        )
        return
    df = pd.DataFrame(table)
    cols = [c for c in ["Month", "P1", "P2", "P3", "P4"] if c in df.columns]
    _write_dataframe(ws, df[cols], row)


def _build_state_trends_sheet(ws, st: Dict[str, Any]) -> None:
    row = _apply_header_band(ws, "Incident State Trends",
                             "Monthly counts by state")
    table = st.get("table_data") or []
    if not table:
        ws.cell(row=row, column=1, value="No data available.").font = Font(
            name="Calibri", italic=True, color=NPG_MUTED
        )
        return
    df = pd.DataFrame(table)
    _write_dataframe(ws, df, row)


def _build_incident_types_sheet(ws, types: Dict[str, Any]) -> None:
    row = _apply_header_band(ws, "Incident Types",
                             "Top 10 categories by ticket count")
    table = types.get("table_data") or []
    if not table:
        ws.cell(row=row, column=1, value="No data available.").font = Font(
            name="Calibri", italic=True, color=NPG_MUTED
        )
        return
    df = pd.DataFrame(table)
    cols = [c for c in ["Incident Type", "Count", "Percentage"] if c in df.columns]
    end_row = _write_dataframe(ws, df[cols], row)

    if "Count" in cols:
        try:
            chart = PieChart()
            chart.title = "Top incident types"
            data_col = cols.index("Count") + 1
            label_col = cols.index("Incident Type") + 1
            data_ref = Reference(ws, min_col=data_col, max_col=data_col,
                                 min_row=row, max_row=row + len(df))
            cats_ref = Reference(ws, min_col=label_col, max_col=label_col,
                                 min_row=row + 1, max_row=row + len(df))
            chart.add_data(data_ref, titles_from_data=True)
            chart.set_categories(cats_ref)
            chart.height = 10
            chart.width = 14
            ws.add_chart(chart, f"E{row}")
        except Exception:
            logger.exception("Failed to add incident-types chart")


def _build_reopened_sheet(ws, reopen: Dict[str, Any]) -> None:
    stats = reopen.get("stats") or {}
    row = _apply_header_band(
        ws, "Reopened Incidents",
        f"{stats.get('reopened_incidents', 0)} of {stats.get('total_incidents', 0)} "
        f"reopened ({stats.get('reopen_rate', 0)}%)",
    )

    if stats:
        ws.cell(row=row, column=1, value="STATISTICS").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        row = _write_kpi_block(ws, row, [
            ("Total incidents",        stats.get("total_incidents")),
            ("Reopened incidents",     stats.get("reopened_incidents")),
            ("Reopen rate (%)",        stats.get("reopen_rate")),
            ("Average reopens",        stats.get("avg_reopens")),
        ])

    table = reopen.get("table_data") or []
    if table:
        ws.cell(row=row, column=1, value="DISTRIBUTION").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        df = pd.DataFrame(table)
        cols = [c for c in ["Times Reopened", "Incident Count", "Percentage"]
                if c in df.columns]
        _write_dataframe(ws, df[cols], row)


def _build_assignment_groups_sheet(ws, groups: Dict[str, Any]) -> None:
    """Per-assignment-group workload and resolution performance."""
    totals = groups.get("totals") or {}
    row = _apply_header_band(
        ws, "Assignment Groups",
        "%s groups - %s tickets - %s resolved - avg %s h"
        % (totals.get("groups", 0), totals.get("tickets", 0),
           totals.get("resolved", 0), totals.get("avg_resolution_hours", "-")),
    )

    if not groups.get("available"):
        ws.cell(row=row, column=1,
                value=groups.get("reason", "No data available.")).font = Font(
            name="Calibri", italic=True, color=NPG_MUTED
        )
        return

    # How to read the numbers. Written into the workbook because the
    # workbook travels further than the screen does, and an average
    # resolution time with no statement of what it excludes is the single
    # easiest number in this report to quote out of context.
    ws.cell(row=row, column=1, value="HOW TO READ THIS SHEET").font = Font(
        name="Calibri", size=11, bold=True, color=NPG_RED
    )
    row += 1
    for note in _group_notes(groups):
        ws.cell(row=row, column=1, value=note).font = Font(
            name="Calibri", size=9, color=NPG_MUTED
        )
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=10)
        row += 1
    row += 1

    row = _write_kpi_block(ws, row, [
        ("Assignment groups",  totals.get("groups")),
        ("Tickets",            totals.get("tickets")),
        ("Resolved",           totals.get("resolved")),
        ("Still open",         totals.get("open")),
        ("Ageing backlog",     totals.get("ageing_backlog")),
        ("Avg resolution (h)", totals.get("avg_resolution_hours")),
        ("Median resolution (h)", totals.get("median_resolution_hours")),
        ("SLA met %",          totals.get("sla_met_pct")),
        ("Unassigned tickets", totals.get("unassigned")),
    ])

    table = groups.get("table_data") or []
    if not table:
        return
    df = pd.DataFrame(table)
    end_row = _write_dataframe(ws, df, row)

    try:
        chart = BarChart()
        chart.type = "col"
        chart.title = "Tickets by assignment group"
        data_ref = Reference(ws, min_col=2, max_col=2,
                             min_row=row, max_row=row + len(df))
        cats_ref = Reference(ws, min_col=1, max_col=1,
                             min_row=row + 1, max_row=row + len(df))
        chart.add_data(data_ref, titles_from_data=True)
        chart.set_categories(cats_ref)
        chart.height = 10
        chart.width = 20
        ws.add_chart(chart, f"A{end_row + 2}")
    except Exception:
        logger.exception("Failed to add assignment-group chart")


def _build_group_types_sheet(ws, groups: Dict[str, Any]) -> None:
    """Group x request type: volume and how long each kind takes."""
    classification = groups.get("classification") or {}
    row = _apply_header_band(
        ws, "Group Request Types",
        "What each group handles, how much of it, and how long each kind takes",
    )

    if not groups.get("available"):
        ws.cell(row=row, column=1,
                value=groups.get("reason", "No data available.")).font = Font(
            name="Calibri", italic=True, color=NPG_MUTED
        )
        return

    if classification.get("method_label"):
        ws.cell(row=row, column=1, value="HOW TYPES WERE IDENTIFIED").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        ws.cell(row=row, column=1,
                value=classification["method_label"]).font = Font(
            name="Calibri", size=9, color=NPG_MUTED
        )
        ws.cell(row=row, column=1).alignment = Alignment(wrap_text=True,
                                                         vertical="top")
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=12)
        ws.row_dimensions[row].height = 46
        row += 2

    table = groups.get("type_table_data") or []
    _write_dataframe(ws, pd.DataFrame(table), row)


def _group_notes(groups: Dict[str, Any]) -> list:
    """The caveats that belong next to the group numbers, as plain rows."""
    notes = []
    if groups.get("group_source_label"):
        notes.append(groups["group_source_label"])
    notes.append(
        "Resolution statistics cover RESOLVED tickets only - read them "
        "alongside the Open and Ageing backlog columns, never on their own.")
    notes.append(
        "Median and P90 are given because support resolution times are "
        "right-skewed; a group's mean can sit well above its typical ticket.")
    clip = groups.get("resolution_clip_hours")
    if clip:
        notes.append(
            "Resolution hours are capped at %s h (%s days) by the "
            "preprocessing step, so the longest tail is bounded."
            % (clip, round(clip / 24)))
    if groups.get("sla_basis"):
        notes.append("SLA met %% is %s." % groups["sla_basis"])
    else:
        notes.append(
            "SLA met % is blank: this export carried no SLA field and no "
            "resolved timestamp to recompute one.")
    thin = groups.get("thin_sample_below")
    if thin:
        notes.append(
            "Groups with fewer than %d tickets are shown but their averages "
            "are not a performance result." % thin)
    return notes


def _build_long_open_sheet(ws, lo: Dict[str, Any]) -> None:
    stats = lo.get("stats") or {}
    row = _apply_header_band(
        ws, "Long-Open Incidents",
        f"{stats.get('total_open', 0)} open - "
        f"avg {stats.get('avg_days_open', 0)} days - "
        f"longest {stats.get('longest_open', 0)} days",
    )

    if stats:
        ws.cell(row=row, column=1, value="STATISTICS").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        row = _write_kpi_block(ws, row, [
            ("Open incidents",     stats.get("total_open")),
            ("Average days open",  stats.get("avg_days_open")),
            ("Longest open (days)", stats.get("longest_open")),
            ("Open > 30 days",     stats.get("over_30_days")),
        ])

    table = lo.get("table_data") or []
    if table:
        ws.cell(row=row, column=1, value="DISTRIBUTION BY AGE BAND").font = Font(
            name="Calibri", size=11, bold=True, color=NPG_RED
        )
        row += 1
        df = pd.DataFrame(table)
        cols = [c for c in ["Time Range", "Count", "Percentage"] if c in df.columns]
        _write_dataframe(ws, df[cols], row)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def build_summary_excel(output_path: Path, metrics: Dict[str, Any],
                        meta: Dict[str, Any]) -> Path:
    """Build the multi-sheet summary-report workbook."""
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    ws = wb.active
    ws.title = "Quality Score"
    _build_quality_sheet(ws,
                         metrics.get("quality_score") or {},
                         metrics.get("support_quality") or {},
                         metrics.get("total_incidents", 0),
                         meta)

    _build_sla_trends_sheet(wb.create_sheet("SLA Trends"),
                            metrics.get("sla_trends") or {})
    _build_resolution_sheet(wb.create_sheet("Resolution Time"),
                            metrics.get("resolution_times") or {})
    _build_priority_trends_sheet(wb.create_sheet("Priority Trends"),
                                 metrics.get("priority_trends") or {})
    _build_state_trends_sheet(wb.create_sheet("State Trends"),
                              metrics.get("state_trends") or {})
    _build_incident_types_sheet(wb.create_sheet("Incident Types"),
                                metrics.get("incident_types") or {})
    _build_reopened_sheet(wb.create_sheet("Reopened"),
                          metrics.get("reopened_incidents") or {})
    _build_long_open_sheet(wb.create_sheet("Long-Open"),
                           metrics.get("long_open_incidents") or {})
    _build_assignment_groups_sheet(wb.create_sheet("Assignment Groups"),
                                   metrics.get("assignment_groups") or {})
    _build_group_types_sheet(wb.create_sheet("Group Request Types"),
                             metrics.get("assignment_groups") or {})

    wb.save(output_path)
    logger.info("Summary Excel report written: %s (%d bytes)",
                output_path, output_path.stat().st_size)
    return output_path
