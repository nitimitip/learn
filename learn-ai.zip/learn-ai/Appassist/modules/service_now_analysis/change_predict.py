"""
Inference module for the CR Template Generator.

Changes vs previous version
----------------------------
* **Hybrid retrieval** - the corpus search now combines TF-IDF cosine,
  sentence-embedding cosine, and BM25 via Reciprocal Rank Fusion, exactly
  mirroring the approach in similarity.py.  When semantic vectors or BM25
  are unavailable (libraries not installed, or first run before change_train
  builds them) it falls back transparently to TF-IDF alone.

* **Persisted null fills** - ``cr_null_fills.json`` is loaded at startup so
  any preprocessing done inside the template generation path uses stable
  training-time fill values rather than computing them from a single record.

Public entry point is unchanged::

    generate_cr_template(title, description, planned_start, planned_end,
                         environment=None, server_list=None, requested_by=None)
"""

from __future__ import annotations

import json
import logging
import re
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

from . import config
from .server_lookup import lookup_servers
from .section_quality import score_template, score_cr_description
from .ml.embedding_utils import (
    get_encoder,
    encode_texts,
    load_sem_vectors,
    load_bm25_index,
    bm25_scores,
    reciprocal_rank_fusion,
    load_null_fills,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Tuning knobs
# ---------------------------------------------------------------------------
TOP_K_SIMILAR_CRS    = 8
MIN_COMMONALITY_PCT  = 0.40
MAX_STEPS_PER_PLAN   = 12
PLAN_STEP_MIN_WORDS  = 2
PLAN_STEP_MAX_WORDS  = 50
MIN_MATCH_PCT_FOR_LIFT = 20.0
RECENCY_TIE_PCT        = 5.0
HIGH_CONFIDENCE_PCT    = 70.0

PLAN_DISCLAIMER = (
    "These steps are taken verbatim from a historical CR for reference "
    "only - please cross-validate every step against your environment, "
    "change scope, and current standards before submitting the CR."
)


# ---------------------------------------------------------------------------
# Artifact loading
# ---------------------------------------------------------------------------
def _load(path: Path):
    try:
        return joblib.load(path)
    except FileNotFoundError:
        return None
    except Exception as exc:
        logger.warning("Failed to load %s: %s", path, exc)
        return None


def _get_cr_null_fills() -> Optional[dict]:
    """Load persisted training-time null fills for CR preprocessing."""
    return load_null_fills(config.MODELS_DIR / "cr_null_fills.json")


def _get_embedding_model():
    """Lazy-load the sentence encoder from config.EMBEDDING_MODEL_PATH."""
    model_path = getattr(config, "EMBEDDING_MODEL_PATH", None)
    if not model_path:
        return None
    return get_encoder(str(model_path))


def cr_models_status() -> Dict[str, Any]:
    """Compact status object used by routes / templates."""
    artifacts = {
        "vectorizer": "cr_vectorizer_latest.pkl",
        "corpus":     "cr_corpus_vectors_latest.pkl",
        "corpus_df":  "cr_corpus_dataframe_latest.pkl",
    }
    status = {k: (config.MODELS_DIR / v).exists() for k, v in artifacts.items()}
    field_models = sorted(p.name for p in config.MODELS_DIR.glob("cr_field_*_latest.pkl"))

    meta_file = config.MODELS_DIR / "cr_metadata.json"
    trained_at = n_changes = None
    if meta_file.exists():
        try:
            with open(meta_file) as f:
                m = json.load(f)
                trained_at = m.get("trained_at")
                n_changes  = m.get("n_changes")
        except Exception:
            pass

    return {
        "artifacts":    status,
        "field_models": field_models,
        "all_loaded":   all(status.values()) and len(field_models) > 0,
        "trained_at":   trained_at,
        "n_changes":    n_changes,
    }


# ---------------------------------------------------------------------------
# Hybrid CR retrieval
# ---------------------------------------------------------------------------
def _cr_hybrid_scores(
    combined_query: str,
    tfidf_vec,
    tfidf_corpus_vecs,
    n_docs: int,
) -> np.ndarray:
    """
    Combine TF-IDF, semantic, and BM25 signals for CR corpus retrieval.

    Falls back to TF-IDF alone when semantic vectors / BM25 index are not
    available.  RRF with k=60 is used to merge the ranked lists.
    """
    ranked_lists: List[List[int]] = []

    # 1. TF-IDF cosine
    Xq = tfidf_vec.transform([combined_query])
    tfidf_raw = cosine_similarity(Xq, tfidf_corpus_vecs).flatten()
    above_floor = np.where(tfidf_raw >= 0.05)[0]
    if len(above_floor):
        ranked_lists.append(
            above_floor[tfidf_raw[above_floor].argsort()[::-1]].tolist()
        )

    # 2. Semantic cosine (optional)
    sem_vecs = load_sem_vectors("cr", config.MODELS_DIR)
    if sem_vecs is not None:
        enc = _get_embedding_model()
        if enc is not None:
            q_sem = encode_texts([combined_query], enc)
            if q_sem is not None:
                sem_raw = sem_vecs.dot(q_sem[0])
                ranked_lists.append(sem_raw.argsort()[::-1].tolist())

    # 3. BM25 (optional)
    bm25_idx = load_bm25_index("cr", config.MODELS_DIR)
    if bm25_idx is not None:
        bm25_raw = bm25_scores(bm25_idx, combined_query, n_docs)
        if bm25_raw is not None:
            ranked_lists.append(bm25_raw.argsort()[::-1].tolist())

    if not ranked_lists:
        return np.zeros(n_docs, dtype=np.float32)

    return reciprocal_rank_fusion(ranked_lists, n_docs)


# ---------------------------------------------------------------------------
# Step extraction & commonality logic (unchanged)
# ---------------------------------------------------------------------------
_STEP_SPLIT_RE = re.compile(
    r"(?:"
        r"[\r\n]+"
        r"|(?:^|\s)\d+\s*[\.\ )]\s+"
        r"|(?:^|[\r\n])[\-\*]\s+"
        r"|\s*•\s*"
    r")",
    re.M,
)
_NORMALISE_RE = re.compile(r"[^a-z0-9 ]+")
_FILLER_WORDS = frozenset({
    "the", "a", "an", "to", "and", "or", "of", "in", "on", "at", "by",
    "it", "is", "are", "be", "this", "that", "these", "those", "we",
    "will", "shall", "should", "must", "do", "for", "with", "from",
    "into", "onto", "as", "via", "using", "use", "step", "all", "any",
    "please", "now", "next", "first", "then", "finally",
})
_GENERIC_OBJECTS = frozenset({
    "server", "servers", "box", "boxes", "machine", "machines", "host", "hosts",
    "node", "nodes", "instance", "instances", "vm", "vms", "system", "systems",
    "device", "devices",
})


def _split_into_steps(text: str) -> List[str]:
    if not text:
        return []
    pieces = _STEP_SPLIT_RE.split(text)
    out: List[str] = []
    for p in pieces:
        p = p.strip(" -**\t.")
        if not p:
            continue
        n_words = len(p.split())
        if n_words < PLAN_STEP_MIN_WORDS or n_words > PLAN_STEP_MAX_WORDS:
            continue
        out.append(p)
    return out


def _normalise_step(step: str) -> str:
    s = step.lower().strip()
    s = _NORMALISE_RE.sub(" ", s)
    s = re.sub(r"\b\w*\d+\w*\b", " ", s)
    tokens = [w for w in s.split()
              if w not in _FILLER_WORDS and w not in _GENERIC_OBJECTS and len(w) > 1]
    return " ".join(tokens[:6])


def _plan_from_single_cr(corpus_df, cr_idx: int, plan_field: str,
                          max_steps: int = 25) -> List[str]:
    if corpus_df is None or plan_field not in corpus_df.columns:
        return []
    if cr_idx is None or cr_idx < 0 or cr_idx >= len(corpus_df):
        return []
    text = str(corpus_df.iloc[int(cr_idx)].get(plan_field) or "").strip()
    return _split_into_steps(text)[:max_steps]


def _common_steps_from_corpus(corpus_df, top_idx: List[int], plan_field: str,
                               min_commonality: float = MIN_COMMONALITY_PCT,
                               max_steps: int = MAX_STEPS_PER_PLAN) -> List[str]:
    if plan_field not in corpus_df.columns or len(top_idx) == 0:
        return []
    k = len(top_idx)
    clusters: Dict[str, List[Tuple[int, str]]] = defaultdict(list)
    for ci in top_idx:
        text = str(corpus_df.iloc[int(ci)][plan_field] or "")
        for step in _split_into_steps(text):
            key = _normalise_step(step)
            if not key or len(key) < 5:
                continue
            clusters[key].append((int(ci), step))
    common: List[Tuple[int, str, int]] = []
    for key, items in clusters.items():
        cr_count = len({ci for ci, _ in items})
        if cr_count / k < min_commonality:
            continue
        best = max((s for _, s in items), key=len)
        common.append((cr_count, best, len(items)))
    common.sort(key=lambda t: (-t[0], -t[2], t[1].lower()))
    return [c[1] for c in common[:max_steps]]


# ---------------------------------------------------------------------------
# Risk-impact analysis composer (unchanged)
# ---------------------------------------------------------------------------
def _compose_risk_impact_analysis(
    type_pred: str, risk_pred: str, environment: str,
    server_count: int, has_external_interfaces: bool,
    business_service: str, similar_count: int,
) -> str:
    parts: List[str] = []
    if environment:
        parts.append(f"Change targets the {environment} environment.")
    if server_count > 0:
        parts.append(f"{server_count} server{'s' if server_count != 1 else ''} in scope.")
    if business_service and business_service.lower() != "unknown":
        parts.append(f"Affects business service: {business_service}.")
    if has_external_interfaces:
        parts.append(
            "External interfaces are connected to the affected applications - "
            "downstream impact must be assessed and communicated.")
    if risk_pred == "High":
        parts.append("Predicted risk is HIGH; CAB review and a tested rollback are essential.")
    elif risk_pred == "Moderate":
        parts.append("Predicted risk is MODERATE; standard pre-implementation review applies.")
    else:
        parts.append("Predicted risk is LOW based on similar past changes.")
    if type_pred == "Emergency":
        parts.append(
            "This is an Emergency change - out-of-hours support and accelerated review will apply.")
    elif type_pred == "Standard":
        parts.append("This change matches a Standard pattern previously approved by CAB.")
    if similar_count == 0:
        parts.append(
            "No close matches were found in the historical CR corpus - treat "
            "as a novel change and rehearse in non-prod.")
    elif similar_count >= 5:
        parts.append(
            f"{similar_count} similar successful changes were found in history "
            f"and used to draft the implementation and backout plans.")
    return " ".join(parts)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
_PER_FIELD_MODELS = ["type", "category", "subcategory", "risk", "priority",
                     "impact", "urgency", "assignment_group", "business_service"]


def generate_cr_template(*,
                         title: str,
                         description: str,
                         planned_start: str,
                         planned_end: str,
                         environment: Optional[str] = None,
                         server_list: Optional[str] = None,
                         requested_by: Optional[str] = None,
                         ) -> Dict[str, Any]:
    """
    Generate a full CR template using hybrid retrieval for similar past CRs.

    The retrieval step now fuses TF-IDF cosine, sentence-embedding cosine,
    and BM25 via RRF so that semantically similar CRs (even when worded
    differently) are surfaced alongside lexically similar ones.
    """
    title = (title or "").strip()
    description = (description or "").strip()
    environment = (environment or "").strip() or None

    if not title or len(title) < 5:
        return {"status": "error", "message": "Title must be at least 5 characters."}
    if not description or len(description) < 10:
        return {"status": "error", "message": "Description must be at least 10 characters."}
    if not planned_start or not planned_end:
        return {"status": "error", "message": "Planned start and end dates are required."}

    status = cr_models_status()
    if not status["all_loaded"]:
        return {
            "status": "no_models",
            "message": ("CR models have not been trained yet. Run "
                        "`python -m modules.service_now_analysis.change_train "
                        "--change-input data/<latest>.csv` to train, or wait "
                        "for the next quarterly retraining."),
            "model_status": status,
        }

    # Server validation
    server_info = lookup_servers(server_list or "") if server_list else {
        "status": "no_input", "servers_input": [], "servers_found": [],
        "servers_unknown": [], "applications": [], "external_interfaces": [],
        "warnings": [],
    }

    # Vectorise the query
    vec = _load(config.MODELS_DIR / "cr_vectorizer_latest.pkl")
    if vec is None:
        return {"status": "no_models", "message": "Vectorizer not loaded."}

    combined_query = f"{title} {description}".strip()

    # Per-field predictions
    Xq_tfidf = vec.transform([combined_query])
    fields: Dict[str, Any] = {}
    confidences: Dict[str, float] = {}
    for fld in _PER_FIELD_MODELS:
        mdl = _load(config.MODELS_DIR / f"cr_field_{fld}_latest.pkl")
        if mdl is None:
            continue
        try:
            pred = mdl.predict(Xq_tfidf)[0]
            fields[fld] = str(pred)
            if hasattr(mdl, "predict_proba"):
                proba = mdl.predict_proba(Xq_tfidf)[0]
                confidences[fld] = float(np.max(proba))
        except Exception as exc:
            logger.warning("Field %s prediction failed: %s", fld, exc)

    # Hybrid retrieval of similar successful past CRs
    corpus_vecs = _load(config.MODELS_DIR / "cr_corpus_vectors_latest.pkl")
    corpus_df   = _load(config.MODELS_DIR / "cr_corpus_dataframe_latest.pkl")

    similar_changes: List[Dict[str, Any]] = []
    top_idx: List[int] = []
    top_scores: List[float] = []

    if corpus_vecs is not None and corpus_df is not None and len(corpus_df) > 0:
        n_docs = len(corpus_df)

        # Hybrid RRF scores - richer signal than TF-IDF alone
        hybrid = _cr_hybrid_scores(combined_query, vec, corpus_vecs, n_docs)
        order = hybrid.argsort()[::-1][:TOP_K_SIMILAR_CRS]

        # TF-IDF cosine for user-facing similarity percentage (consistent units)
        tfidf_scores_all = cosine_similarity(Xq_tfidf, corpus_vecs).flatten()

        for i in order:
            if hybrid[int(i)] == 0:
                continue
            sim = float(tfidf_scores_all[int(i)])
            if sim < 0.05:
                continue
            top_idx.append(int(i))
            top_scores.append(round(sim * 100, 1))
            row = corpus_df.iloc[int(i)]
            similar_changes.append({
                "change_id":          str(row.get("change_id", "")),
                "title":              str(row.get("title", "")),
                "type":               str(row.get("type", "")),
                "risk":               str(row.get("risk", "")),
                "category":           str(row.get("category", "")),
                "assignment_group":   str(row.get("assignment_group", "")),
                "configuration_item": str(row.get("configuration_item", "")),
                "similarity_score":   round(sim * 100, 1),
            })

    # Pick the source CR (always-lift policy with recency tiebreaker)
    plan_source: Dict[str, Any] = {
        "mode":               "none",
        "best_match_id":      None,
        "best_match_score":   None,
        "disclaimer":         PLAN_DISCLAIMER,
        "risk_impact_source": "none",
    }
    impl_steps: List[str] = []
    backout_steps: List[str] = []
    test_steps: List[str] = []
    risk_impact: str = ""
    chosen_idx: Optional[int] = None
    chosen_score: float = 0.0

    if corpus_df is not None and top_idx:
        top_score = top_scores[0]
        if top_score >= MIN_MATCH_PCT_FOR_LIFT:
            tie_floor = top_score - max(RECENCY_TIE_PCT, 0.0)
            candidates = [(idx, sc) for idx, sc in zip(top_idx, top_scores)
                          if sc >= tie_floor]

            date_col: Optional[str] = None
            for c in ("closed_timestamp", "end_timestamp", "opened_timestamp"):
                if c in corpus_df.columns:
                    date_col = c
                    break

            def _recency_key(idx: int):
                if date_col is not None:
                    val = corpus_df.iloc[idx].get(date_col)
                    try:
                        ts = pd.to_datetime(val, errors="coerce")
                        if ts is not pd.NaT and pd.notna(ts):
                            return ts.timestamp()
                    except Exception:
                        pass
                return float(idx)

            candidates.sort(key=lambda c: _recency_key(c[0]), reverse=True)
            chosen_idx, chosen_score = candidates[0]

    if chosen_idx is not None:
        impl_steps    = _plan_from_single_cr(corpus_df, chosen_idx, "implementation_plan")
        backout_steps = _plan_from_single_cr(corpus_df, chosen_idx, "backout_plan")
        test_steps    = _plan_from_single_cr(corpus_df, chosen_idx, "test_plan")

        if "risk_impact_analysis" in corpus_df.columns:
            candidate_ria = str(corpus_df.iloc[chosen_idx]
                                          .get("risk_impact_analysis") or "").strip()
            if len(candidate_ria.split()) >= 8:
                risk_impact = candidate_ria
                plan_source["risk_impact_source"] = "lifted_from_best_match"

        if not risk_impact:
            has_ext_ifc = len(server_info.get("external_interfaces") or []) > 0
            risk_impact = _compose_risk_impact_analysis(
                type_pred=fields.get("type", "Normal"),
                risk_pred=fields.get("risk", "Moderate"),
                environment=environment or "the target",
                server_count=len(server_info.get("servers_found") or []),
                has_external_interfaces=has_ext_ifc,
                business_service=fields.get("business_service", ""),
                similar_count=len(similar_changes),
            )
            plan_source["risk_impact_source"] = "rule_composer"

        chosen_row = corpus_df.iloc[chosen_idx]
        plan_source.update({
            "mode": ("high_confidence_match"
                     if chosen_score >= HIGH_CONFIDENCE_PCT
                     else "best_available_match"),
            "best_match_id":    str(chosen_row.get("change_id", "")),
            "best_match_title": str(chosen_row.get("title", "")),
            "best_match_score": chosen_score,
        })
    else:
        has_ext_ifc = len(server_info.get("external_interfaces") or []) > 0
        risk_impact = _compose_risk_impact_analysis(
            type_pred=fields.get("type", "Normal"),
            risk_pred=fields.get("risk", "Moderate"),
            environment=environment or "the target",
            server_count=len(server_info.get("servers_found") or []),
            has_external_interfaces=has_ext_ifc,
            business_service=fields.get("business_service", ""),
            similar_count=0,
        )
        plan_source.update({
            "mode":               "no_corpus_match",
            "fallback_reason":    "No similar past CRs were found - please draft "
                                  "the implementation, backout and test plans manually.",
            "risk_impact_source": "rule_composer",
        })

    description_quality = score_cr_description(description)

    template: Dict[str, Any] = {
        "title":               title,
        "description":         description,
        "type":                fields.get("type", "Normal"),
        "category":            fields.get("category", "Unknown"),
        "subcategory":         fields.get("subcategory", "Unknown"),
        "business_service":    fields.get("business_service", "Unknown"),
        "risk":                fields.get("risk", "Moderate"),
        "priority":            fields.get("priority", "P3"),
        "impact":              fields.get("impact", "Medium"),
        "urgency":             fields.get("urgency", "Medium"),
        "assignment_group":    fields.get("assignment_group", "Unknown"),
        "environment":         environment or "",
        "planned_start":       planned_start,
        "planned_end":         planned_end,
        "implementation_plan": impl_steps,
        "backout_plan":        backout_steps,
        "test_plan":           test_steps,
        "risk_impact_analysis": risk_impact,
        "confidences":         confidences,
        "requested_by":        requested_by or "",
    }

    quality = score_template(template)

    if server_info.get("warnings"):
        rendered_warnings = "\n".join(server_info["warnings"])
        template["risk_impact_analysis_with_warnings"] = (
            f"{risk_impact}\n\n{rendered_warnings}"
        )

    return {
        "status":              "ok",
        "template":            template,
        "quality":             quality,
        "similar_changes":     similar_changes,
        "server_lookup":       server_info,
        "description_quality": description_quality,
        "plan_source":         plan_source,
        "model_status":        status,
    }
