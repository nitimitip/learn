from .routes import resource_tracker_bp

__all__ = ['resource_tracker_bp']
