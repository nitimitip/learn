"""
Resource Tracker - the single Workforce entry point on the home page.

One landing hub that fans out to the workforce tools, each with its own
access level:

* My Timesheet          - every signed-in user (Activity Tracker)
* People Explorer       - every signed-in user (Resource Utilization)
* Utilization Dashboard - project managers / admins only
* T&M Allocations       - project managers / admins only

The hub also shows a couple of live numbers: the visitor's own hours this
week, and (for project managers) how many project-task allocations are at or
over their planned volume (allocation = the task's working days x 8h,
consumed by the timesheet hours logged against the task).
"""

import logging
from datetime import date, timedelta

from flask import Blueprint, redirect, render_template, url_for
from sqlalchemy import func

from auth import get_current_user
from database import get_db_session
from modules.activity_tracker.models import ActivityEntry
from modules.project_management.models import ProjectTask
from modules.resource_utilization.models import load_holidays, load_settings
from modules.resource_utilization.service import (allocation_band,
                                                  split_task_hours,
                                                  task_allocation)

logger = logging.getLogger(__name__)

resource_tracker_bp = Blueprint(
    'resource_tracker', __name__,
    template_folder='../../templates/resource_tracker',
)


def _my_week_hours(db_session, user_id, today):
    monday = today - timedelta(days=today.weekday())
    total = (db_session.query(func.sum(ActivityEntry.hours))
             .filter(ActivityEntry.user_id == user_id,
                     ActivityEntry.entry_date >= monday,
                     ActivityEntry.entry_date <= monday + timedelta(days=6))
             .scalar())
    return round(float(total or 0.0), 2)


def _allocation_counts(db_session, day_hours, holidays):
    """
    (tracked_count, at_or_over_limit_count) across every assigned project
    task - each task IS a T&M allocation (planned working days x the
    configured day hours, holiday calendar excluded, vs the timesheet hours
    logged against it; hours after the planned end = extended).
    """
    tasks = (db_session.query(ProjectTask)
             .filter(ProjectTask.assigned_to.isnot(None))
             .all())
    if not tasks:
        return 0, 0

    rows = (db_session.query(ActivityEntry.project_task_id,
                             ActivityEntry.entry_date,
                             func.sum(ActivityEntry.hours))
            .filter(ActivityEntry.project_task_id.in_(
                [t.id for t in tasks]))
            .group_by(ActivityEntry.project_task_id,
                      ActivityEntry.entry_date)
            .all())
    hours = {}
    for tid, d, h in rows:
        hours.setdefault(tid, {})[d] = float(h or 0.0)

    at_limit = 0
    for t in tasks:
        _, allocated_hours = task_allocation(t.start_date, t.end_date,
                                             day_hours, holidays)
        consumed, _, after_h, _ = split_task_hours(hours.get(t.id, {}),
                                                   t.end_date)
        percent = (consumed / allocated_hours * 100.0
                   if allocated_hours else None)
        if allocation_band(percent, after_h) in ('reached', 'exceeded'):
            at_limit += 1
    return len(tasks), at_limit


@resource_tracker_bp.route('/')
def index():
    user = get_current_user()
    if not user:
        return redirect(url_for('login'))
    is_pm = user.role in ('admin', 'project_manager')

    today = date.today()
    allocations = at_limit = 0
    db_session = get_db_session()
    try:
        settings = load_settings(db_session)
        week_hours = _my_week_hours(db_session, user.id, today)
        if is_pm:
            allocations, at_limit = _allocation_counts(
                db_session, settings['day_hours'],
                load_holidays(db_session))
    finally:
        db_session.close()

    return render_template(
        'resource_tracker/index.html',
        user=user, is_pm=is_pm,
        week_hours=week_hours, day_hours=settings['day_hours'],
        allocations=allocations, at_limit=at_limit,
    )


@resource_tracker_bp.route('/about')
def about():
    """About page - explains the Workforce module to end users and PMs."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        settings = load_settings(db_session)
    finally:
        db_session.close()
    return render_template('resource_tracker/about.html', user=user,
                           day_hours=settings['day_hours'],
                           under_pct=settings['under_pct'],
                           over_pct=settings['over_pct'])
