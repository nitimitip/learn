"""
User Profile module - data model and reference values.

A user's profile carries three organisational fields (columns on the shared
``users`` table, see the root ``models.py``):

* ``user_group`` - which side of the organisation they sit on
  ('application' / 'infra'),
* ``sub_group``  - the tower/discipline inside that group. The offered values
  live in the admin-managed ``user_sub_groups`` table below; the USER row
  stores the picked NAME as plain text, so an admin deleting a list value
  never breaks the users who already carry it (same philosophy as the
  app-wide "preserve names on historical records" rule),
* ``team``       - 'Project', 'BAU' or 'Project & BAU' (both worlds: the
  person runs BAU support AND takes project-task assignments, so the
  timesheet task picker and both workload contexts apply).

A profile also carries SKILLS, stored one row per skill in ``user_skills``:

* technical skills are picked from the Application Support **Technology
  Catalog** (``app_tech_catalog``) - the same list the applications record
  their stack against, so "who knows Oracle WebLogic" and "which
  applications run Oracle WebLogic" speak the same vocabulary,
* soft skills are picked from the admin-managed ``user_soft_skills`` list.

Both are multi-select. As everywhere else in the app, the skill row stores
the NAME as text: retiring or deleting a catalog/soft-skill value never
strips the skill off the people who already recorded it.
"""

from sqlalchemy import (Column, DateTime, ForeignKey, Integer, String,
                        UniqueConstraint)
from sqlalchemy.sql import func

from database import Base


# ---------------------------------------------------------------------------
# Fixed reference values (not admin-editable)
# ---------------------------------------------------------------------------

# 'guest' is the STORED value for the group now labelled "Organization
# Member" - the raw value is kept so every existing user row, drill-down URL
# and report filter carries on working; only the display label changed.
USER_GROUPS = ['application', 'infra', 'guest']

USER_GROUP_LABELS = {
    'application': 'Application',
    'infra':       'Infra',
    'guest':       'Organization Member',
}

# Organization Members always carry these fixed values - the profile form
# auto-populates them and the save route forces them, so an org member can
# never end up with an Application/Infra sub-group or team.
ORG_MEMBER_GROUP = 'guest'
ORG_SUB_GROUP    = 'Organization'
ORG_TEAM         = 'Organization'

# Teams selectable for Application / Infra users. ORG_TEAM is valid only for
# Organization Members (enforced in the update route); it is included in
# USER_TEAMS so downstream consumers (Resource Utilization drill-downs and
# people filters) treat it as a known value.
USER_TEAMS = ['Project', 'BAU', 'Project & BAU', ORG_TEAM]


def team_includes_bau(team) -> bool:
    """True when the team value carries BAU duties ('BAU', 'Project & BAU')."""
    return 'bau' in (team or '').strip().lower()


def team_includes_project(team) -> bool:
    """
    True when the team value carries project work ('Project',
    'Project & BAU'). A blank/unset team keeps the project-side view, the
    behaviour before the team field existed.
    """
    lowered = (team or '').strip().lower()
    return 'project' in lowered or not lowered

# Seed values for the admin-editable sub-group list (used only while the
# table is empty; after that the admin page is the source of truth).
DEFAULT_SUB_GROUPS = {
    'application': ['MS Tower', 'Oracle', 'GIS', 'Webops'],
    'infra':       ['Security', 'Unix', 'Windows', 'Network', 'EUC'],
    # Organization Members carry the single fixed 'Organization' sub-group.
    'guest':       [ORG_SUB_GROUP],
}


# ---------------------------------------------------------------------------
# Admin-managed sub-group values
# ---------------------------------------------------------------------------

class UserSubGroup(Base):
    """One selectable sub-group value under a user group (admin-managed)."""
    __tablename__ = 'user_sub_groups'
    __table_args__ = (
        UniqueConstraint('user_group', 'name', name='uq_user_sub_group'),
    )

    id         = Column(Integer, primary_key=True)
    user_group = Column(String(30), nullable=False)    # 'application' / 'infra'
    name       = Column(String(100), nullable=False)
    created_at = Column(DateTime, default=func.now())

    def __repr__(self):
        return f'<UserSubGroup {self.user_group}/{self.name}>'


def ensure_sub_groups_seeded(db_session) -> None:
    """Seed the default sub-group values once, while the table is empty.

    The fixed Organization Member sub-group is additionally ensured on every
    call so databases seeded before that group existed gain it too.
    """
    if db_session.query(UserSubGroup.id).first() is None:
        for group, names in DEFAULT_SUB_GROUPS.items():
            for name in names:
                db_session.add(UserSubGroup(user_group=group, name=name))
        db_session.commit()
        return
    org_row = (db_session.query(UserSubGroup.id)
               .filter_by(user_group=ORG_MEMBER_GROUP, name=ORG_SUB_GROUP)
               .first())
    if org_row is None:
        db_session.add(UserSubGroup(user_group=ORG_MEMBER_GROUP,
                                    name=ORG_SUB_GROUP))
        db_session.commit()


def sub_groups_by_group(db_session) -> dict:
    """{'application': [names...], 'infra': [names...]} in alphabetical order."""
    rows = (db_session.query(UserSubGroup)
            .order_by(UserSubGroup.user_group, UserSubGroup.name)
            .all())
    out = {g: [] for g in USER_GROUPS}
    for r in rows:
        out.setdefault(r.user_group, []).append(r.name)
    return out


# ---------------------------------------------------------------------------
# Skills
#
# Two lists hang off a profile and both are multi-select:
#
#   * TECHNICAL skills come from the Application Support Technology Catalog
#     (``app_tech_catalog``), so a person's skills and an application's stack
#     are recorded against one shared vocabulary. Nothing is duplicated here
#     - the catalog stays owned by Application Support.
#   * SOFT skills come from the admin-managed list below.
#
# A stored skill keeps the NAME as text and only remembers ``catalog_id`` as
# provenance. That is deliberate and it is why there is no foreign key to
# ``app_tech_catalog``: an admin deleting an unused catalog value must not
# take people's recorded skills with it (nor fail the delete on SQL Server
# with a constraint violation the admin cannot act on).
# ---------------------------------------------------------------------------

SKILL_TECHNICAL = 'technical'
SKILL_SOFT      = 'soft'
SKILL_TYPES     = (SKILL_TECHNICAL, SKILL_SOFT)

# Soft skills carry no category; the column is kept NOT NULL with an empty
# default so the (user, type, category, name) uniqueness works on every
# backend - SQL Server and SQLite both treat NULLs in a unique index as
# distinct, which would let duplicates through.
NO_CATEGORY = ''

# Seed values for the admin-editable soft-skill list (used only while the
# table is empty; after that the admin page is the source of truth).
DEFAULT_SOFT_SKILLS = [
    'Communication',
    'Stakeholder Management',
    'Customer Focus',
    'Problem Solving',
    'Analytical Thinking',
    'Working Under Pressure',
    'Ownership and Accountability',
    'Team Collaboration',
    'Knowledge Sharing / Mentoring',
    'Documentation Writing',
    'Time Management',
    'Adaptability',
    'Vendor Coordination',
    'Presentation Skills',
    'Leadership',
]


def skill_key(value) -> str:
    """
    The key a skill name is MATCHED on, never displayed by.

    Same fold as the Technology Catalog's ``match_key``: whitespace
    collapsed and lower-cased, so 'Oracle WebLogic', 'oracle weblogic' and
    'Oracle  WebLogic' are one skill rather than three.
    """
    return ' '.join((value or '').split()).lower()


class SoftSkill(Base):
    """One selectable soft-skill value (admin-managed)."""
    __tablename__ = 'user_soft_skills'
    __table_args__ = (
        UniqueConstraint('name', name='uq_user_soft_skill'),
    )

    id         = Column(Integer, primary_key=True)
    name       = Column(String(120), nullable=False)
    sort_order = Column(Integer, default=100)
    created_at = Column(DateTime, default=func.now())

    def __repr__(self):
        return f'<SoftSkill {self.name}>'


class UserSkill(Base):
    """One skill recorded on a user's profile."""
    __tablename__ = 'user_skills'
    __table_args__ = (
        UniqueConstraint('user_id', 'skill_type', 'category', 'item_name',
                         name='uq_user_skill'),
    )

    id         = Column(Integer, primary_key=True)
    user_id    = Column(Integer, ForeignKey('users.id'), nullable=False,
                        index=True)
    # One of SKILL_TYPES.
    skill_type = Column(String(20), nullable=False)
    # Technology Catalog category ('os' / 'database' / 'tool' / 'language')
    # for a technical skill; empty for a soft skill.
    category   = Column(String(20), nullable=False, default=NO_CATEGORY)
    # Provenance only - see the note above on why this is not a foreign key.
    catalog_id = Column(Integer)
    item_name  = Column(String(150), nullable=False)
    created_at = Column(DateTime, default=func.now())

    def __repr__(self):
        return f'<UserSkill {self.user_id} {self.skill_type}/{self.item_name}>'


def ensure_soft_skills_seeded(db_session) -> None:
    """Seed the default soft-skill values once, while the table is empty.

    Idempotent in the only sense that matters: after the first call this does
    nothing, so an admin who removes a starter value never sees it come back
    on the next page load.
    """
    if db_session.query(SoftSkill.id).first() is not None:
        return
    for index, name in enumerate(DEFAULT_SOFT_SKILLS):
        db_session.add(SoftSkill(name=name, sort_order=(index + 1) * 10))
    db_session.commit()


def soft_skill_names(db_session) -> list:
    """The offered soft-skill values, in the admin's order then by name."""
    rows = (db_session.query(SoftSkill)
            .order_by(SoftSkill.sort_order, SoftSkill.name).all())
    return [row.name for row in rows]


def load_user_skills(db_session, user_id) -> dict:
    """{'technical': [UserSkill, ...], 'soft': [UserSkill, ...]} for a user."""
    rows = (db_session.query(UserSkill)
            .filter_by(user_id=user_id)
            .order_by(UserSkill.category, UserSkill.item_name).all())
    out = {skill_type: [] for skill_type in SKILL_TYPES}
    for row in rows:
        out.setdefault(row.skill_type, []).append(row)
    return out


def _entry_key(skill_type, category, name):
    return (skill_type, (category or NO_CATEGORY), skill_key(name))


def replace_user_skills(db_session, user_id, technical, soft) -> dict:
    """
    Make a user's stored skills match the submitted selection.

    ``technical`` is an iterable of dicts carrying ``category``, ``name`` and
    optionally ``catalog_id``; ``soft`` is an iterable of names. Returns
    {'added': n, 'removed': n}.

    Rows that survive the save are LEFT ALONE rather than deleted and
    re-inserted, so ``created_at`` keeps meaning "since when has this person
    had this skill". The caller commits.
    """
    wanted = {}
    for entry in (technical or []):
        name = (entry.get('name') or '').strip()
        if not name:
            continue
        category = (entry.get('category') or NO_CATEGORY).strip()
        key = _entry_key(SKILL_TECHNICAL, category, name)
        wanted.setdefault(key, {
            'skill_type': SKILL_TECHNICAL,
            'category': category,
            'catalog_id': entry.get('catalog_id'),
            'item_name': name,
        })
    for name in (soft or []):
        name = (name or '').strip()
        if not name:
            continue
        key = _entry_key(SKILL_SOFT, NO_CATEGORY, name)
        wanted.setdefault(key, {
            'skill_type': SKILL_SOFT,
            'category': NO_CATEGORY,
            'catalog_id': None,
            'item_name': name,
        })

    existing = {}
    for row in db_session.query(UserSkill).filter_by(user_id=user_id).all():
        key = _entry_key(row.skill_type, row.category, row.item_name)
        # A duplicate that predates the uniqueness guard is dropped on save.
        if key in existing:
            db_session.delete(row)
            continue
        existing[key] = row

    removed = 0
    for key, row in existing.items():
        if key not in wanted:
            db_session.delete(row)
            removed += 1

    added = 0
    for key, entry in wanted.items():
        row = existing.get(key)
        if row is None:
            db_session.add(UserSkill(user_id=user_id, **entry))
            added += 1
        elif entry['catalog_id'] and row.catalog_id != entry['catalog_id']:
            # The catalog was reloaded and the value now points at a
            # different row; keep the provenance current.
            row.catalog_id = entry['catalog_id']

    return {'added': added, 'removed': removed}
