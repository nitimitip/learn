"""
User Access Report - the admin "Manage users" download.

One workbook, two worksheets, in the same NPg red house style as every other
App Assist download (Project Management, Application Support, Security):

  * Summary      - registration and access metrics (counts only), followed by
                   the written detail: which roles and organisation groups
                   exist, and exactly what each role / membership grant lets a
                   person do in every module.
  * User Details - one row per registered account with its role, organisation
                   placement and the resolved access level for each module.

Why the module catalogue is written down here
---------------------------------------------
Access in App Assist is not a single column. It is the product of two things:

  1. the application ROLE on the user record (admin / project_manager /
     team_member), and
  2. per-module MEMBERSHIP registers - the Application Support, Health Check
     and File Monitor tower member tables, the Security and ServiceNow group
     tables, and the Project Management project rosters.

Nothing in the schema states what those combinations mean, so MODULE_CATALOG
below is the written statement of the rules the route code actually enforces.
Change a gate in a module and the matching entry here must be updated with it -
that is the point of the report: an auditor reads one document instead of
fourteen route files.

Collection (needs a database session) is kept separate from rendering (plain
data in, bytes out) so the workbook can be built and tested without a database.
"""

from __future__ import annotations

import io
import re
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.page import PageMargins
from openpyxl.worksheet.properties import PageSetupProperties

from .models import USER_GROUP_LABELS

# Brand palette - NPg red (mirrors project_management/project_excel.py).
BRAND    = "AB1236"   # title bands & section headers
BRAND_DK = "7E0D27"   # subtitles & column-header rows
BAND     = "F1F5F9"
BORDER   = "D7DEE7"
TEXT     = "1D293D"
MUTED    = "6B7280"

# Access-level chip colours. The scale runs administrator -> elevated grant ->
# baseline -> none, so a column of them reads at a glance.
LEVEL_META = {
    "admin":    ("FEE2E2", "991B1B"),   # full administrative control
    "manage":   ("FEF3C7", "92400E"),   # edit / update inside a scope
    "member":   ("DBEAFE", "1E40AF"),   # granted through a membership register
    "standard": ("DCFCE7", "166534"),   # the same as every signed-in user
    "view":     ("F1F5F9", "334155"),   # read-only
    "none":     ("F8FAFC", "6B7280"),   # no access
}

ROLE_LABELS = {
    "admin":           "Admin",
    "project_manager": "Project Manager",
    "team_member":     "Team Member",
}

ROLE_ORDER = ("admin", "project_manager", "team_member")

ROLE_DEFINITIONS = [
    ("admin", "Application administrator",
     "Unrestricted. Manages user accounts (create, change role, reset "
     "password, disable, delete), owns every module's configuration, and is "
     "implicitly a member of every tower, group and project - so an admin can "
     "view, edit, update and delete anywhere in App Assist without being "
     "added to a membership register."),
    ("project_manager", "Delivery manager",
     "Everything a team member can do, plus owner-level rights on the "
     "projects they created (edit, baseline, close, manage the roster) and "
     "access to the manager-only Resource Tracker views - the Utilization "
     "dashboard and the T&M allocation register with their Excel reports."),
    ("team_member", "Standard user",
     "The baseline account. Signs in, uses the self-service modules in full "
     "(My To-Do, My Timesheet, Utility Tools, My Profile), reads the shared "
     "catalogues and reports, and gains edit rights only where a membership "
     "register names them."),
]

GROUP_DEFINITIONS = [
    ("application", "Application-side staff. Sub-group is the application "
                    "area they sit in; team is Project or BAU."),
    ("infra", "Infrastructure staff. Sub-group is the infrastructure "
              "discipline; team is Project or BAU."),
    ("guest", "Organization Member. Sub-group and team are both forced to "
              "'Organization' - used for colleagues outside the Application "
              "and Infra structures."),
]

# ---------------------------------------------------------------------------
# The module access catalogue
#
# `levels` is ordered most-privileged first and is what the Summary sheet
# prints as the written detail. `column` is the header used for this module on
# the User Details sheet.
# ---------------------------------------------------------------------------
MODULE_CATALOG = [
    {
        "key": "project_management",
        "name": "Project Management",
        "column": "Project Management",
        "group": "Delivery",
        "model": "Role + per-project roster",
        "baseline": "Signed-in users see the portfolio; a project opens only "
                    "for its owner or a member of its roster.",
        "levels": [
            ("Admin", "admin",
             "View, edit, update and delete every project, milestone, task, "
             "risk, baseline and document. Reopens closed projects and "
             "overrides governance sign-off."),
            ("Project owner", "project_manager who created the project",
             "Create projects, edit the plan, baseline it, run the stage "
             "gates, manage the team roster, close the project."),
            ("Project member", "any user on the project roster",
             "Open the project, add and update tasks, risks and documents, "
             "log progress. Cannot edit project settings or close it."),
            ("Portfolio view", "every other signed-in user",
             "Sees the portfolio dashboard only; project detail is blocked."),
        ],
    },
    {
        "key": "code_sentinel",
        "name": "Code Sentinel",
        "column": "Code Sentinel",
        "group": "Delivery",
        "model": "Role + scan-project ownership",
        "baseline": "Every signed-in user can start a scan and read findings.",
        "levels": [
            ("Admin", "admin",
             "Everything below, plus the engine settings and the rule "
             "catalogue toggles. Manages and deletes any scan project."),
            ("Project owner", "project_manager who created the scan project",
             "Edit the project, set its quality gate, triage findings and "
             "delete its scans."),
            ("Scan and read", "every signed-in user",
             "Create scan projects, run scans, read findings and export "
             "reports. Cannot manage projects created by other people."),
        ],
    },
    {
        "key": "todo",
        "name": "My To-Do",
        "column": "My To-Do",
        "group": "Delivery",
        "model": "Private per user",
        "baseline": "Full control of your own list; nobody else's is visible.",
        "levels": [
            ("Own list", "every signed-in user",
             "Create, edit, complete and delete their own activities and "
             "receive the daily email summary. There is no cross-user view - "
             "an admin cannot read another person's list either."),
        ],
    },
    {
        "key": "resource_tracker",
        "name": "Resource Tracker",
        "column": "Resource Tracker",
        "group": "Workforce",
        "model": "Role",
        "baseline": "My Timesheet and the People Explorer for everyone.",
        "levels": [
            ("Admin", "admin",
             "The manager views below, plus the workforce settings "
             "(capacity, holidays, working patterns)."),
            ("Manager views", "admin and project_manager",
             "Utilization dashboard with drill-down, the T&M allocation "
             "register including extension flags, the Excel reports, and "
             "anyone's utilization detail page including that person's "
             "ServiceNow ticket list (on screen and as an Excel download)."),
            ("Own timesheet", "every signed-in user",
             "Enter and update their own weekly hours, link entries to their "
             "assigned project tasks, and browse the People Explorer. A "
             "person can open their OWN utilization detail and download "
             "their own ServiceNow ticket list, but nobody else's."),
        ],
    },
    {
        "key": "people",
        "name": "People Directory",
        "column": "People",
        "group": "Workforce",
        "model": "Open to every signed-in user",
        "baseline": "Search and read; no role unlocks more and none is needed.",
        "levels": [
            ("Directory and profiles", "every signed-in user",
             "Search people by name, team, sub-group or Application Support "
             "tower and open anyone's profile. The profile is READ-ONLY and "
             "assembled from records the viewer could already reach - the "
             "Application Support roster, the ServiceNow workload capture "
             "and the project rosters - so it grants no new visibility. "
             "Organization Members ('guest' group) have the same access as "
             "everyone else; a disabled account is not listed."),
        ],
    },
    {
        "key": "rota",
        "name": "Rota",
        "column": "Rota",
        "group": "Workforce",
        "model": "Rota Admin register + per-rota roster",
        "baseline": "A rota opens only for a Rota Admin or somebody on its "
                    "roster. It names who is on call and often carries a "
                    "personal out-of-hours number, so it is not open to every "
                    "signed-in user the way the People directory is.",
        "levels": [
            ("Admin", "admin",
             "Everything a Rota Admin can do, PLUS granting and withdrawing "
             "the Rota Admin role itself. That single extra power is the only "
             "difference between the two levels."),
            ("Rota Admin", "users named in the Rota Admin register",
             "Create, edit, close and delete EVERY rota; add and remove rota "
             "members; name the rota leads; build the shifts, staff them and "
             "publish (which sends the schedule emails); decide swap and "
             "give-up requests; record attendance on a member's behalf. "
             "Cannot change who the Rota Admins are. The grant is no longer "
             "scoped to a team or tower - one grant, one meaning."),
            ("Rota Lead", "a rota member flagged as a lead",
             "Everything a rota member can do on that rota, PLUS deciding its "
             "swap and give-up requests, and is copied on every missed "
             "sign-in and missed sign-off. The flag grants no other editing "
             "rights."),
            ("Rota member", "users on a rota's roster",
             "Opens that rota, and signs in and signs off THEIR OWN shifts. "
             "Nobody - an admin included - can sign in or sign off on "
             "somebody else's behalf; an admin may RECORD attendance after "
             "the event, and the record names who entered it."),
            ("No access", "everyone else",
             "A rota they are not rostered on is not listed and cannot be "
             "opened."),
        ],
    },
    {
        "key": "application_health_check",
        "name": "Application Health Check",
        "column": "Health Check",
        "group": "Monitoring",
        "model": "Public dashboard + role and tower membership",
        "baseline": ("The status dashboard is open to everyone, including "
                     "users who are not signed in. No access to a tower's "
                     "checks themselves without membership."),
        "levels": [
            ("Admin", "admin",
             "Create and delete towers, manage tower membership, create, "
             "edit, schedule and delete health check reports, and run any "
             "check on demand."),
            ("Tower member", "users named in the tower's member list",
             "View their tower's reports, results history and trend charts, "
             "and run its checks on demand. No tower or membership changes."),
            ("Public", "everyone, signed in or not",
             "The dashboard only: the name and status of every tower and "
             "check, its score and when it last ran. Opening a tower or an "
             "individual check - and with it any hostname, database detail "
             "or account listing - still needs membership of that tower."),
        ],
    },
    {
        "key": "file_monitor",
        "name": "File Monitor",
        "column": "File Monitor",
        "group": "Monitoring",
        "model": "Role + tower membership",
        "baseline": "No access to a tower's file flows without membership.",
        "levels": [
            ("Admin", "admin",
             "Create and delete towers and reports, manage membership, edit "
             "monitor settings and exclusion rules, and see reports that are "
             "not yet attached to a tower."),
            ("Tower member", "users named in the tower's member list",
             "View their tower's report dashboards, delivery history, "
             "pending-file alerts and CSV extracts."),
            ("No access", "everyone else",
             "Other towers' file flows are hidden."),
        ],
    },
    {
        "key": "mimp_report",
        "name": "MIMP Report",
        "column": "MIMP Report",
        "group": "Reporting & Analytics",
        "model": "Role",
        "baseline": "Live incident status is readable by every signed-in user.",
        "levels": [
            ("Admin", "admin",
             "Create, edit and delete major-incident and severe-weather "
             "reports, maintain the application list on each, update "
             "statuses and schedule the stakeholder emails."),
            ("View", "every signed-in user",
             "Read the live status boards and report history."),
        ],
    },
    {
        "key": "service_now_analysis",
        "name": "ServiceNow Analysis",
        "column": "ServiceNow Analysis",
        "group": "Reporting & Analytics",
        "model": "Role + ServiceNow group membership",
        "baseline": "Reports and the guide are readable by everyone.",
        "levels": [
            ("Admin", "admin",
             "Everything a group member can do, plus removing members and "
             "clearing the upload history. Revoking access is deliberately "
             "admin-only so the custodians cannot lock each other out."),
            ("ServiceNow group member",
             "users in the ServiceNow group register",
             "Upload incident, service-request and change exports (which "
             "replaces the org-wide report), edit the in-app guide content, "
             "manage escalation contacts and add further members."),
            ("View", "every signed-in user",
             "Read the summaries, the open-item boards and the whole "
             "ServiceNow guide, and download the attached templates."),
        ],
    },
    {
        "key": "application_support",
        "name": "Application Support",
        "column": "Application Support",
        "group": "Support & Tools",
        "model": "Role + tower membership",
        "baseline": "The application catalogue is read-only for everyone.",
        "levels": [
            ("Admin", "admin",
             "Create and delete towers, set the ServiceNow assignment groups "
             "a tower answers for, name and stand down tower leads, manage "
             "tower membership and the secret-vault grant, maintain reference "
             "data and application categories, and edit every application "
             "record. Removing a tower LEAD is an admin-only action."),
            ("Tower lead", "tower members an admin has flagged as a lead",
             "Everything a tower member can do, plus adding and removing the "
             "members of their own tower. A tower may have several leads. A "
             "lead cannot name or remove another lead, nor change the "
             "secret-vault grant - those stay with an admin."),
            ("Tower member (vault)",
             "tower members with the manage-secrets grant",
             "Everything a tower member can do, plus adding, updating and "
             "deleting Secret Vault credentials for that tower."),
            ("Tower member", "users named in the tower's member list",
             "Create and update the applications in their tower - servers, "
             "interfaces, jobs, tasks, issues, documents and technical "
             "details - and read the vault without changing it."),
            ("View", "every signed-in user",
             "Browse towers, application profiles and the architecture "
             "views, read the documentation quality and tower summary status "
             "reports, and download the Excel / PDF profiles."),
        ],
    },
    {
        "key": "utility",
        "name": "Utility Tools",
        "column": "Utility Tools",
        "group": "Support & Tools",
        "model": "Open to all signed-in users",
        "baseline": "Self-service toolbox, no role gates.",
        "levels": [
            ("Full use", "every signed-in user",
             "File search and compare, split and de-duplicate, data masking, "
             "encode and decode, server lookup. Working files are temporary "
             "and cleaned up automatically."),
        ],
    },
    {
        "key": "software_inventory",
        "name": "Software Inventory",
        "column": "Software Inventory",
        "group": "Support & Tools",
        "model": "Role + software group membership + tower membership",
        "baseline": "Every signed-in user can search the catalogue and "
                    "download GENERAL packages; a RESTRICTED package needs "
                    "membership of one of its application-support towers. "
                    "Publishing is limited to the software group.",
        "levels": [
            ("Admin", "admin",
             "Everything a software group member can do, plus managing who "
             "is in the software group."),
            ("Software group member",
             "users in the software group register",
             "Publish a package, publish a new version under an existing "
             "name, set whether it is general or restricted and to which "
             "towers, delete a single version, delete a whole entry. A "
             "delete removes the file from disk permanently. Can download "
             "any package including restricted ones - they can already "
             "replace or delete the file, so withholding it would protect "
             "nothing."),
            ("Download - general", "every other signed-in user",
             "Search the catalogue and download any kept version of a "
             "general package. Cannot upload, rename or delete anything."),
            ("Download - restricted",
             "members of a tower the package was published to",
             "As above, for packages restricted to that tower. Membership "
             "is the tower_members list owned by Application Support, not a "
             "separate list here, so tower changes take effect at once. "
             "Everyone else sees the package and which towers hold it, but "
             "the download is refused."),
        ],
    },
    {
        "key": "security",
        "name": "Security",
        "column": "Security",
        "group": "Infrastructure",
        "model": "Role + security group membership",
        "baseline": "The certificate inventory is closed unless you are in "
                    "the security group.",
        "levels": [
            ("Admin", "admin",
             "Everything a security group member can do, plus managing who "
             "is in the security group."),
            ("Security group member",
             "users in the security group register",
             "View the certificate inventory and expiry dashboard, upload "
             "and refresh the inventory, add, edit and delete certificate "
             "records, and manage the expiry alerting."),
            ("No access", "everyone else",
             "The inventory and dashboard are restricted."),
        ],
    },
    {
        "key": "user_profile",
        "name": "My Profile",
        "column": "My Profile",
        "group": "Account",
        "model": "Own record + admin list management",
        "baseline": "Everyone maintains their own profile.",
        "levels": [
            ("Admin", "admin",
             "Maintains the selectable sub-group AND soft-skill values "
             "(rename cascades to the users holding them; deleting a value "
             "leaves those users' text intact). The technical-skill list is "
             "the Application Support technology catalog, administered "
             "there."),
            ("Own profile", "every signed-in user",
             "Set their organisation group, sub-group and team, record their "
             "technical and soft skills, and change their own password."),
        ],
    },
    {
        "key": "administration",
        "name": "Administration (User Management)",
        "column": "Administration",
        "group": "Account",
        "model": "Admin only",
        "baseline": "Not visible to non-admin users.",
        "levels": [
            ("Admin", "admin",
             "Register accounts, change roles, reset passwords, disable and "
             "re-enable accounts, permanently delete accounts that hold no "
             "referenced data, and download this report. Disabling preserves "
             "the person's name on historical records; a hard delete is "
             "refused while anything still references them."),
            ("No access", "everyone else",
             "The admin area is blocked and hidden from the menu."),
        ],
    },
]

MODULE_BY_KEY = dict((m["key"], m) for m in MODULE_CATALOG)


# ---------------------------------------------------------------------------
# Collection
# ---------------------------------------------------------------------------

def collect_access_data(db_session):
    """Read every user and every membership register into a plain dict.

    Imports the module models lazily: this file is imported by main_app at
    request time and must not pull a dozen module packages into the import
    graph just to exist.
    """
    from models import User

    from modules.application_support.models import AppSupportTower, TowerMember
    from modules.application_health_check.models import (
        ApplicationTower, AppTowerMember,
    )
    from modules.file_monitor.models import (
        FileMonitorTower, FileMonitorTowerMember,
    )
    from modules.security.models import SecurityGroupMember
    from modules.service_now_analysis.models import ServiceNowGroupMember
    from modules.software_inventory.models import SoftwareGroupMember
    from modules.rota.models import Rota, RotaAdmin, RotaMember
    from modules.project_management.models import Project, ProjectTeamMember

    users = db_session.query(User).order_by(User.username).all()

    # --- tower registers: user_id -> [tower name, ...] ---------------------
    def _tower_map(member_cls, tower_cls, name_attr):
        names = dict(
            (row.id, getattr(row, name_attr))
            for row in db_session.query(tower_cls).all()
        )
        out = {}
        for row in db_session.query(member_cls).all():
            out.setdefault(row.user_id, []).append(
                names.get(row.tower_id) or "Tower #%s" % row.tower_id)
        for key in out:
            out[key].sort()
        return out, len(names)

    app_support_towers, app_support_tower_count = _tower_map(
        TowerMember, AppSupportTower, "tower_name")
    health_towers, health_tower_count = _tower_map(
        AppTowerMember, ApplicationTower, "name")
    file_towers, file_tower_count = _tower_map(
        FileMonitorTowerMember, FileMonitorTower, "name")

    # Secret Vault write grant rides on the Application Support membership row.
    vault_users = set(
        row.user_id for row in db_session.query(TowerMember).all()
        if getattr(row, "can_manage_secrets", False)
    )

    security_users = set(
        row.user_id for row in db_session.query(SecurityGroupMember).all())
    servicenow_users = set(
        row.user_id for row in db_session.query(ServiceNowGroupMember).all())
    software_users = set(
        row.user_id for row in db_session.query(SoftwareGroupMember).all())

    # Rota: the admin register, plus each person's roster and lead counts.
    rota_admin_users = set(
        row.user_id for row in db_session.query(RotaAdmin).all())
    rota_member_counts = {}
    rota_lead_counts = {}
    for row in db_session.query(RotaMember).all():
        rota_member_counts[row.user_id] =             rota_member_counts.get(row.user_id, 0) + 1
        if row.is_lead:
            rota_lead_counts[row.user_id] =                 rota_lead_counts.get(row.user_id, 0) + 1
    rota_count = db_session.query(Rota).count()

    # --- project rosters ---------------------------------------------------
    project_count = db_session.query(Project).count()
    project_member_counts = {}
    for row in db_session.query(ProjectTeamMember).all():
        project_member_counts[row.user_id] = \
            project_member_counts.get(row.user_id, 0) + 1

    project_owner_counts = {}
    for owner, in db_session.query(Project.created_by).all():
        if owner is not None:
            project_owner_counts[owner] = project_owner_counts.get(owner, 0) + 1

    return {
        "generated_at": datetime.now(),
        "users": [_user_row(u) for u in users],
        "grants": {
            "app_support_towers": app_support_towers,
            "health_towers": health_towers,
            "file_towers": file_towers,
            "vault_users": vault_users,
            "security_users": security_users,
            "servicenow_users": servicenow_users,
            "software_users": software_users,
            "rota_admin_users": rota_admin_users,
            "rota_member_counts": rota_member_counts,
            "rota_lead_counts": rota_lead_counts,
            "project_member_counts": project_member_counts,
            "project_owner_counts": project_owner_counts,
        },
        "registers": {
            "app_support_tower_count": app_support_tower_count,
            "health_tower_count": health_tower_count,
            "file_tower_count": file_tower_count,
            "rota_count": rota_count,
            "project_count": project_count,
        },
    }


def _user_row(user):
    """Flatten a User ORM row - the renderer never touches the ORM."""
    return {
        "id": user.id,
        "username": user.username or "",
        "firstname": user.firstname or "",
        "lastname": user.lastname or "",
        "email": user.email or "",
        "role": user.role or "team_member",
        "user_group": user.user_group or "",
        "sub_group": user.sub_group or "",
        "team": user.team or "",
        "is_active": bool(user.is_active),
        "created_at": user.created_at,
        "updated_at": user.updated_at,
    }


# ---------------------------------------------------------------------------
# Access resolution - one user, one module -> (level tone, description)
# ---------------------------------------------------------------------------

def _join(names, limit=4):
    """Readable tower list, truncated so a cell stays a cell."""
    if not names:
        return ""
    if len(names) <= limit:
        return ", ".join(names)
    return "%s (+%d more)" % (", ".join(names[:limit]), len(names) - limit)


def resolve_access(user, grants):
    """Resolved access for every module in MODULE_CATALOG, for one user.

    Returns {module_key: (tone, text)}. `tone` is a LEVEL_META key and drives
    the cell colour; `text` is what the auditor reads.
    """
    uid = user["id"]
    admin = user["role"] == "admin"
    pm = user["role"] == "project_manager"
    out = {}

    if not user["is_active"]:
        # A disabled account cannot sign in at all (get_current_user filters
        # on is_active), so every grant below is dormant rather than live.
        for mod in MODULE_CATALOG:
            out[mod["key"]] = ("none", "Account disabled - no access")
        return out

    # Project Management
    owned = grants["project_owner_counts"].get(uid, 0)
    on_roster = grants["project_member_counts"].get(uid, 0)
    if admin:
        out["project_management"] = ("admin", "Admin - full control of all projects")
    elif pm:
        out["project_management"] = ("manage", "Owner of %d project(s); on %d roster(s)"
                                     % (owned, on_roster))
    elif on_roster:
        out["project_management"] = ("member", "Member of %d project(s)" % on_roster)
    else:
        out["project_management"] = ("view", "Portfolio view only")

    # Code Sentinel
    if admin:
        out["code_sentinel"] = ("admin", "Admin - settings, rules, all scan projects")
    elif pm:
        out["code_sentinel"] = ("manage", "Scan and read; manages own scan projects")
    else:
        out["code_sentinel"] = ("standard", "Scan and read")

    # My To-Do
    out["todo"] = ("standard", "Own list only")

    # People Directory - deliberately ungated beyond signing in.
    out["people"] = ("standard", "Search the directory; read any profile")

    # Resource Tracker
    if admin:
        out["resource_tracker"] = ("admin", "Admin - manager views + workforce settings")
    elif pm:
        out["resource_tracker"] = ("manage", "Manager views (utilization, T&M) + own timesheet")
    else:
        out["resource_tracker"] = ("standard", "Own timesheet + People Explorer")

    # Rota
    #
    # Four rungs, because the module has four and they are genuinely different
    # grants. The lead count is worth stating separately: a lead receives the
    # escalation mail for other people's shifts, which is the one thing on this
    # module that gives somebody visibility of a colleague's compliance.
    rota_on = grants["rota_member_counts"].get(uid, 0)
    rota_leading = grants["rota_lead_counts"].get(uid, 0)
    if admin:
        out["rota"] = ("admin",
                       "Admin - all rotas + grants the Rota Admin role")
    elif uid in grants["rota_admin_users"]:
        out["rota"] = ("manage",
                       "Rota Admin - creates and publishes rotas, manages "
                       "members and leads")
    elif rota_leading:
        out["rota"] = ("member",
                       "Rota lead on %d of %d rota(s) - copied on missed "
                       "acknowledgements and sign-offs"
                       % (rota_leading, rota_on))
    elif rota_on:
        out["rota"] = ("member",
                       "On %d rota(s) - acknowledges and signs off own shifts"
                       % rota_on)
    else:
        out["rota"] = ("none", "On no rota - no access")

    # Tower-gated monitoring modules
    for key, bucket in (("application_health_check", "health_towers"),
                        ("file_monitor", "file_towers")):
        towers = grants[bucket].get(uid, [])
        if admin:
            out[key] = ("admin", "Admin - all towers and reports")
        elif towers:
            out[key] = ("member", "Member of %d tower(s): %s"
                        % (len(towers), _join(towers)))
        else:
            out[key] = ("none", "No tower membership - no access")

    # MIMP Report
    out["mimp_report"] = (("admin", "Admin - manage reports and schedules")
                          if admin else ("view", "View live status"))

    # ServiceNow Analysis
    if admin:
        out["service_now_analysis"] = ("admin", "Admin - group membership + full use")
    elif uid in grants["servicenow_users"]:
        out["service_now_analysis"] = ("member", "ServiceNow group - upload and edit guide")
    else:
        out["service_now_analysis"] = ("view", "View reports and guide")

    # Application Support
    towers = grants["app_support_towers"].get(uid, [])
    if admin:
        out["application_support"] = ("admin", "Admin - all towers, members and reference data")
    elif towers and uid in grants["vault_users"]:
        out["application_support"] = ("manage", "Tower member + Secret Vault (%d): %s"
                                      % (len(towers), _join(towers)))
    elif towers:
        out["application_support"] = ("member", "Member of %d tower(s): %s"
                                      % (len(towers), _join(towers)))
    else:
        out["application_support"] = ("view", "Read-only catalogue")

    # Utility Tools
    out["utility"] = ("standard", "Full use")

    # Software Inventory
    #
    # Three rungs, because the module now has three. The tower count is worth
    # stating on the middle rung: a person's restricted downloads come from
    # their tower membership, so "no towers" is the difference between seeing
    # the whole shelf and seeing only the general part of it.
    if admin:
        out["software_inventory"] = ("admin",
                                     "Admin - publish, delete and manage the "
                                     "software group")
    elif uid in grants["software_users"]:
        out["software_inventory"] = ("member",
                                     "Software group - publish, set audience, "
                                     "download anything")
    elif towers:
        out["software_inventory"] = ("standard",
                                     "Search and download; restricted "
                                     "packages via %d tower(s)" % len(towers))
    else:
        out["software_inventory"] = ("standard",
                                     "Search and download general packages "
                                     "only - in no tower")

    # Security
    if admin:
        out["security"] = ("admin", "Admin - inventory + group membership")
    elif uid in grants["security_users"]:
        out["security"] = ("member", "Security group - inventory and alerts")
    else:
        out["security"] = ("none", "Not in security group - no access")

    # My Profile
    out["user_profile"] = (("admin", "Own profile + sub-group and "
                                     "soft-skill lists")
                           if admin else ("standard", "Own profile"))

    # Administration
    out["administration"] = (("admin", "Full user administration")
                             if admin else ("none", "No access"))

    return out


def _elevation_summary(access):
    """The short 'what is unusual about this account' cell."""
    notes = []
    for mod in MODULE_CATALOG:
        tone, text = access[mod["key"]]
        if tone in ("admin", "manage", "member"):
            notes.append("%s: %s" % (mod["column"], text))
    return "; ".join(notes) if notes else "Baseline access only"


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------

def build_metrics(data):
    """Counts for the Summary sheet, computed from the collected data."""
    users = data["users"]
    grants = data["grants"]
    total = len(users)
    active = [u for u in users if u["is_active"]]

    by_role = {}
    by_group = {}
    by_sub_group = {}
    by_team = {}
    for u in users:
        by_role[u["role"]] = by_role.get(u["role"], 0) + 1
        gkey = u["user_group"] or ""
        by_group[gkey] = by_group.get(gkey, 0) + 1
        by_sub_group[u["sub_group"] or ""] = by_sub_group.get(u["sub_group"] or "", 0) + 1
        by_team[u["team"] or ""] = by_team.get(u["team"] or "", 0) + 1

    # Per-module tallies over ACTIVE accounts - a disabled account holds no
    # live access, so counting it would overstate the estate.
    module_counts = {}
    for mod in MODULE_CATALOG:
        module_counts[mod["key"]] = {
            "admin": 0, "manage": 0, "member": 0,
            "standard": 0, "view": 0, "none": 0,
        }
    baseline_only = 0
    for u in active:
        access = resolve_access(u, grants)
        for key, pair in access.items():
            module_counts[key][pair[0]] += 1
        if not any(tone in ("admin", "manage", "member")
                   for tone, _text in access.values()):
            baseline_only += 1

    registers = [
        ("Application Support tower members", "%d tower(s)"
         % data["registers"]["app_support_tower_count"],
         sum(len(v) for v in grants["app_support_towers"].values()),
         len(grants["app_support_towers"])),
        ("Health Check tower members", "%d tower(s)"
         % data["registers"]["health_tower_count"],
         sum(len(v) for v in grants["health_towers"].values()),
         len(grants["health_towers"])),
        ("File Monitor tower members", "%d tower(s)"
         % data["registers"]["file_tower_count"],
         sum(len(v) for v in grants["file_towers"].values()),
         len(grants["file_towers"])),
        ("Secret Vault managers", "Application Support grant",
         len(grants["vault_users"]), len(grants["vault_users"])),
        ("Security group", "Certificate inventory",
         len(grants["security_users"]), len(grants["security_users"])),
        ("ServiceNow group", "Uploads and guide editing",
         len(grants["servicenow_users"]), len(grants["servicenow_users"])),
        ("Software group", "Publishing and package audience",
         len(grants["software_users"]), len(grants["software_users"])),
        ("Project rosters", "%d project(s)" % data["registers"]["project_count"],
         sum(grants["project_member_counts"].values()),
         len(grants["project_member_counts"])),
    ]

    return {
        "total": total,
        "active": len(active),
        "disabled": total - len(active),
        "by_role": by_role,
        "by_group": by_group,
        "by_sub_group": by_sub_group,
        "by_team": by_team,
        "profile_set": len([u for u in users if u["user_group"]]),
        "profile_unset": len([u for u in users if not u["user_group"]]),
        "module_counts": module_counts,
        "registers": registers,
        "baseline_only": baseline_only,
    }


# ---------------------------------------------------------------------------
# Workbook helpers - same construction as the other App Assist downloads
# ---------------------------------------------------------------------------

_THIN = Side(style="thin", color=BORDER)
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT_TOP = Alignment(horizontal="left", vertical="top", wrap_text=True)


def safe_filename(name):
    return re.sub(r"[^A-Za-z0-9._-]+", "_", (name or "").strip()) or "report"


def _fmt_datetime(value):
    if isinstance(value, datetime):
        return value.strftime("%d %b %Y %H:%M")
    return "" if value is None else str(value)


def _fmt_date(value):
    if isinstance(value, datetime):
        return value.strftime("%d %b %Y")
    return "" if value is None else str(value)


def _autosize(ws, widths):
    for idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width


def _title_band(ws, title, subtitle, ncols):
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    c = ws.cell(row=1, column=1, value=title)
    c.font = Font(name="Calibri", size=15, bold=True, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=BRAND)
    c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[1].height = 30

    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
    s = ws.cell(row=2, column=1, value=subtitle)
    s.font = Font(name="Calibri", size=10, italic=True, color="FFFFFF")
    s.fill = PatternFill("solid", fgColor=BRAND_DK)
    s.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[2].height = 20
    return 4


def _section_band(ws, row, label, ncols):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    h = ws.cell(row=row, column=1, value=label)
    h.font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    h.fill = PatternFill("solid", fgColor=BRAND)
    h.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row].height = 22
    return row + 1


def _note(ws, row, text, ncols):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=text)
    c.font = Font(name="Calibri", size=9.5, italic=True, color=MUTED)
    c.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
    ws.row_dimensions[row].height = max(16, 14 * (1 + len(text) // 160))
    return row + 1


def _header_row(ws, row, headers):
    for col, label in enumerate(headers, start=1):
        cell = ws.cell(row=row, column=col, value=label)
        cell.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=BRAND_DK)
        cell.alignment = CENTER
        cell.border = _BORDER
    ws.row_dimensions[row].height = 24
    return row + 1


def _style_cell(cell, banded=False, center=False):
    cell.font = Font(name="Calibri", size=10, color=TEXT)
    cell.alignment = CENTER if center else LEFT_TOP
    cell.border = _BORDER
    if banded:
        cell.fill = PatternFill("solid", fgColor=BAND)


def _chip(cell, tone):
    fill, font_clr = LEVEL_META.get(tone, LEVEL_META["none"])
    cell.fill = PatternFill("solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=9.5, color=font_clr)
    cell.alignment = LEFT_TOP
    cell.border = _BORDER


def _table(ws, row, headers, rows, center_cols=(), empty_msg="No data."):
    """Header row + banded body. `center_cols` is a set of 1-based columns."""
    row = _header_row(ws, row, headers)
    if not rows:
        ws.merge_cells(start_row=row, start_column=1,
                       end_row=row, end_column=len(headers))
        c = ws.cell(row=row, column=1, value=empty_msg)
        c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
        c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        c.border = _BORDER
        return row + 2
    for i, values in enumerate(rows):
        for col, value in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=value)
            _style_cell(cell, banded=(i % 2 == 1), center=(col in center_cols))
        row += 1
    return row + 1


def _print_setup(ws, orientation="landscape", repeat_rows=None):
    ws.page_setup.orientation = orientation
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    ws.page_margins = PageMargins(left=0.4, right=0.4, top=0.5, bottom=0.55,
                                  header=0.2, footer=0.25)
    if repeat_rows:
        ws.print_title_rows = repeat_rows
    ws.oddFooter.left.text = "NPg AppAssist - User Access Report"
    ws.oddFooter.left.size = 8
    ws.oddFooter.left.color = MUTED
    ws.oddFooter.right.text = "Page &P of &N"
    ws.oddFooter.right.size = 8
    ws.oddFooter.right.color = MUTED


def _pct(part, whole):
    return "0.0%" if not whole else "%.1f%%" % (100.0 * part / whole)


# ---------------------------------------------------------------------------
# Sheet 1 - Summary
# ---------------------------------------------------------------------------

def _build_summary(ws, data, metrics, generated_by):
    NC = 6
    _autosize(ws, [34, 28, 16, 46, 46, 34])
    row = _title_band(
        ws, "User Access Report",
        "NPg App Assist  |  generated %s by %s"
        % (_fmt_datetime(data["generated_at"]), generated_by or "system"),
        NC)

    # --- Registration metrics ---------------------------------------------
    row = _section_band(ws, row, "1. Registration metrics", NC)
    reg_rows = [
        ("Registered users", metrics["total"], "100.0%",
         "Every account in the users table, active or not.", "", ""),
        ("Active users", metrics["active"],
         _pct(metrics["active"], metrics["total"]),
         "Can sign in today.", "", ""),
        ("Disabled users", metrics["disabled"],
         _pct(metrics["disabled"], metrics["total"]),
         "Sign-in blocked; their name is preserved on historical records.",
         "", ""),
        ("Organisation profile completed", metrics["profile_set"],
         _pct(metrics["profile_set"], metrics["total"]),
         "Group, sub-group and team are set on My Profile.", "", ""),
        ("Organisation profile not set", metrics["profile_unset"],
         _pct(metrics["profile_unset"], metrics["total"]),
         "Shows as 'Not set' on the user management page.", "", ""),
        ("Active users with baseline access only", metrics["baseline_only"],
         _pct(metrics["baseline_only"], max(metrics["active"], 1)),
         "No admin role and no membership grant in any module.", "", ""),
    ]
    row = _table(ws, row, ["Metric", "Count", "Share", "Note", "", ""],
                 reg_rows, center_cols={2, 3})

    # --- Roles -------------------------------------------------------------
    row = _section_band(ws, row, "2. Users by application role", NC)
    role_rows = []
    for key in ROLE_ORDER:
        count = metrics["by_role"].get(key, 0)
        active_count = len([u for u in data["users"]
                            if u["role"] == key and u["is_active"]])
        role_rows.append((ROLE_LABELS[key], count, active_count,
                          _pct(count, metrics["total"]), "", ""))
    for key in sorted(metrics["by_role"]):
        if key not in ROLE_LABELS:      # a role value outside the known three
            count = metrics["by_role"][key]
            role_rows.append((key, count, "", _pct(count, metrics["total"]),
                              "Unrecognised role value", ""))
    row = _table(ws, row, ["Role", "Users", "Active", "Share", "", ""],
                 role_rows, center_cols={2, 3, 4})

    # --- Organisation placement -------------------------------------------
    row = _section_band(ws, row, "3. Users by organisation placement", NC)
    group_rows = []
    for key, count in sorted(metrics["by_group"].items(),
                             key=lambda kv: (-kv[1], kv[0])):
        label = USER_GROUP_LABELS.get(key, key or "Not set")
        group_rows.append(("Group", label, count,
                           _pct(count, metrics["total"]), "", ""))
    for key, count in sorted(metrics["by_sub_group"].items(),
                             key=lambda kv: (-kv[1], kv[0])):
        group_rows.append(("Sub-group", key or "Not set", count,
                           _pct(count, metrics["total"]), "", ""))
    for key, count in sorted(metrics["by_team"].items(),
                             key=lambda kv: (-kv[1], kv[0])):
        group_rows.append(("Team", key or "Not set", count,
                           _pct(count, metrics["total"]), "", ""))
    row = _table(ws, row, ["Dimension", "Value", "Users", "Share", "", ""],
                 group_rows, center_cols={3, 4})

    # --- Module access counts ---------------------------------------------
    row = _section_band(ws, row, "4. Module access - counts", NC)
    mod_rows = []
    for mod in MODULE_CATALOG:
        c = metrics["module_counts"][mod["key"]]
        elevated = c["admin"] + c["manage"] + c["member"]
        baseline = c["standard"] + c["view"]
        mod_rows.append((mod["name"], mod["group"], mod["model"],
                         "Admin %d / Manage %d / Member %d"
                         % (c["admin"], c["manage"], c["member"]),
                         "Standard or view %d / No access %d"
                         % (baseline, c["none"]),
                         "%d of %d active" % (elevated, metrics["active"])))
    row = _table(ws, row,
                 ["Module", "Group", "Access model", "Elevated access",
                  "Baseline", "Elevated share"],
                 mod_rows, center_cols={6})
    row = _note(ws, row,
                "Counts cover ACTIVE accounts only - a disabled account "
                "cannot sign in, so its grants are dormant. Admins are "
                "counted as Admin in every module because administrator "
                "rights are implicit and are never recorded in a membership "
                "register.", NC)
    row += 1

    # --- Membership registers ---------------------------------------------
    row = _section_band(ws, row, "5. Access registers", NC)
    register_rows = [(name, scope, grant_count, people,
                      _pct(people, max(metrics["active"], 1)), "")
                     for name, scope, grant_count, people
                     in metrics["registers"]]
    row = _table(ws, row,
                 ["Register", "Scope", "Grants", "Distinct users",
                  "Share of active users", ""],
                 register_rows, center_cols={3, 4, 5})

    # --- Roles explained ---------------------------------------------------
    row = _section_band(ws, row, "6. What each role grants", NC)
    role_detail = [(ROLE_LABELS[key], summary,
                    "%d user(s)" % metrics["by_role"].get(key, 0),
                    detail, "", "")
                   for key, summary, detail in ROLE_DEFINITIONS]
    row = _table(ws, row,
                 ["Role", "In short", "Users", "Rights", "", ""],
                 role_detail, center_cols={3})

    # --- Groups explained --------------------------------------------------
    row = _section_band(ws, row, "7. Organisation groups", NC)
    group_detail = [(USER_GROUP_LABELS.get(key, key), meaning,
                     "%d user(s)" % metrics["by_group"].get(key, 0), "", "", "")
                    for key, meaning in GROUP_DEFINITIONS]
    group_detail.append(("Not set",
                         "The user has not completed My Profile yet.",
                         "%d user(s)" % metrics["by_group"].get("", 0),
                         "", "", ""))
    row = _table(ws, row, ["Group", "Meaning", "Users", "", "", ""],
                 group_detail, center_cols={3})
    row = _note(ws, row,
                "Organisation placement describes where a person sits in the "
                "business. It drives Resource Tracker reporting and the "
                "people directory - it does NOT grant access to anything. "
                "Access comes from the application role and the membership "
                "registers in section 5.", NC)
    row += 1

    # --- The detail matrix -------------------------------------------------
    row = _section_band(
        ws, row,
        "8. Module access in detail - who can view, edit and update", NC)
    detail_rows = []
    for mod in MODULE_CATALOG:
        for i, level in enumerate(mod["levels"]):
            label, who, what = level
            detail_rows.append((
                mod["name"] if i == 0 else "",
                label,
                mod["model"] if i == 0 else "",
                who,
                what,
                mod["baseline"] if i == 0 else "",
            ))
        # blank spacer keeps a long matrix readable in print
        detail_rows.append(("", "", "", "", "", ""))
    row = _table(ws, row,
                 ["Module", "Access level", "Access model", "Who gets it",
                  "What they can do", "Default for everyone else"],
                 detail_rows)

    _note(ws, row,
          "Administrator, in one line: an admin bypasses every membership "
          "register in every module. They manage user accounts and roles, own "
          "each module's configuration, and can view, create, edit, update "
          "and delete any record - the only exception is My To-Do, which is "
          "private to its owner. Permanent deletion of a user account is "
          "refused while any record still references that person; disabling "
          "is the supported off-boarding step and preserves their name on "
          "history.", NC)
    _print_setup(ws, "landscape")


# ---------------------------------------------------------------------------
# Sheet 2 - User Details
# ---------------------------------------------------------------------------

BASE_HEADERS = [
    "#", "Username", "First name", "Last name", "Email", "Role", "Status",
    "Group", "Sub-group", "Team", "Registered", "Last updated",
]


def _build_details(ws, data, generated_by):
    module_headers = [m["column"] for m in MODULE_CATALOG]
    headers = BASE_HEADERS + module_headers + ["Elevated access summary"]
    NC = len(headers)

    widths = [5, 18, 16, 16, 30, 16, 10, 20, 20, 14, 14, 14]
    widths += [30] * len(module_headers)
    widths += [60]
    _autosize(ws, widths)

    row = _title_band(
        ws, "User Details - role and module access",
        "NPg App Assist  |  %d account(s)  |  generated %s by %s"
        % (len(data["users"]), _fmt_datetime(data["generated_at"]),
           generated_by or "system"),
        NC)

    header_row = row
    row = _header_row(ws, row, headers)
    first_data_row = row

    grants = data["grants"]
    for i, user in enumerate(data["users"]):
        access = resolve_access(user, grants)
        base = [
            i + 1,
            user["username"],
            user["firstname"],
            user["lastname"],
            user["email"],
            ROLE_LABELS.get(user["role"], user["role"]),
            "Active" if user["is_active"] else "Disabled",
            USER_GROUP_LABELS.get(user["user_group"],
                                  user["user_group"] or "Not set"),
            user["sub_group"] or "Not set",
            user["team"] or "Not set",
            _fmt_date(user["created_at"]),
            _fmt_date(user["updated_at"]),
        ]
        banded = (i % 2 == 1)
        for col, value in enumerate(base, start=1):
            cell = ws.cell(row=row, column=col, value=value)
            _style_cell(cell, banded=banded, center=(col == 1))

        # Role and status chips - the two columns an auditor scans first.
        role_cell = ws.cell(row=row, column=6)
        _chip(role_cell, "admin" if user["role"] == "admin"
              else ("manage" if user["role"] == "project_manager"
                    else "standard"))
        role_cell.alignment = CENTER

        status_cell = ws.cell(row=row, column=7)
        _chip(status_cell, "standard" if user["is_active"] else "none")
        status_cell.alignment = CENTER

        col = len(BASE_HEADERS) + 1
        for mod in MODULE_CATALOG:
            tone, text = access[mod["key"]]
            _chip(ws.cell(row=row, column=col, value=text), tone)
            col += 1

        _style_cell(ws.cell(row=row, column=col,
                            value=_elevation_summary(access)), banded=banded)
        row += 1

    last_data_row = row - 1
    if not data["users"]:
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=NC)
        c = ws.cell(row=row, column=1, value="No users registered.")
        c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
        c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        row += 1

    row += 1
    _note(ws, row,
          "Access level key - Admin: unrestricted administrator. Manage: edit "
          "and update inside a scope the person owns. Member: rights granted "
          "by a membership register (tower, group or project roster). "
          "Standard: the same self-service access every signed-in user has. "
          "View: read-only. No access: the module is closed to this account. "
          "A disabled account cannot sign in, so every grant it still holds "
          "is dormant.", NC)

    # Coordinate string, not a cell object: on an empty estate the "No users
    # registered." banner is merged across this row and a MergedCell is not a
    # coordinate openpyxl can freeze on.
    ws.freeze_panes = "C%d" % first_data_row
    ws.auto_filter.ref = "A%d:%s%d" % (
        header_row, get_column_letter(NC), max(last_data_row, first_data_row))
    _print_setup(ws, "landscape",
                 repeat_rows="%d:%d" % (header_row, header_row))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def build_user_access_workbook(data, generated_by=None):
    """`data` is the dict from collect_access_data(). Returns .xlsx bytes."""
    metrics = build_metrics(data)

    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    _build_summary(ws, data, metrics, generated_by)

    _build_details(wb.create_sheet("User Details"), data, generated_by)

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
