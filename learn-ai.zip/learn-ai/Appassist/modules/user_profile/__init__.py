from .routes import user_profile_bp

__all__ = ['user_profile_bp']
