#!/usr/bin/env python
"""Standalone health CLI; the Windows service is the normal scheduler owner.

Examples:
    python modules/application_health_check/run_health_checks.py
    python modules/application_health_check/run_health_checks.py --report 1 --force
    python modules/application_health_check/run_health_checks.py --readiness
    python modules/application_health_check/run_health_checks.py --notifications-only

Exit 0 means the runner completed, not that all monitored applications are
healthy. Exit 1 indicates runner/delivery failure (or unavailable readiness),
and exit 2 indicates fatal/import/storage failure. Results describe target health.
Apply the additive schema upgrade before launching the new CLI or IIS workers.
"""

import argparse
import logging
import os
import sys
from pathlib import Path

# APP_ROOT is the folder holding main_app.py / database.py - three levels up
# from this file (appassist/modules/application_health_check/).
#
# Two things have to be true before anything below can import, and both are
# easy to get wrong:
#
#  1. APP_ROOT must be on sys.path, because the imports go through the package
#     path `modules.application_health_check.*`, and because auth.py does a
#     bare `from models import User` meaning APP_ROOT/models.py.
#
#  2. This file's OWN directory must NOT come first. Python automatically puts
#     the script's directory at sys.path[0] for a script invoked by path, and
#     this directory contains its own models.py. With it ahead of APP_ROOT,
#     `from models import User` finds the health-check models instead and dies
#     with "cannot import name 'User' from 'models'".
#
# Testing membership alone is not enough for (1): PYTHONPATH already carries
# APP_ROOT in production (web.config sets it), so a `not in sys.path` guard
# skips the insert and leaves APP_ROOT sitting *behind* the script directory -
# which is exactly failure (2). So drop the script directory and force
# APP_ROOT to the front unconditionally.
APP_ROOT = Path(__file__).resolve().parents[2]
_SCRIPT_DIR = str(Path(__file__).resolve().parent)
sys.path[:] = [p for p in sys.path if p not in (_SCRIPT_DIR, '', '.')]
if str(APP_ROOT) in sys.path:
    sys.path.remove(str(APP_ROOT))
sys.path.insert(0, str(APP_ROOT))

# Load .env before importing any project module. database.py reads DATABASE_URL
# at IMPORT time and freezes its choice of engine; without this a detached run
# would quietly write to a local SQLite file instead of the production server.
# override=False so a real OS environment variable always wins over the file.
try:
    from dotenv import load_dotenv
    load_dotenv(str(APP_ROOT / '.env'), override=False)
except ImportError:
    pass


def _setup_logging() -> None:
    """Dated file log + stderr - Task Scheduler captures both.

    Dated rather than rotating: several copies of this script can be alive at
    once (Task Scheduler's own trigger, plus one detached process per manual
    "Run Check" click), and RotatingFileHandler's rename-based rollover fails
    with WinError 32 whenever a sibling still holds the file. log_utils gives
    each process its own dated file instead. See log_utils.py.
    """
    from log_utils import DatedFileHandler, has_dated_handler

    log_dir = APP_ROOT / "logs"
    log_dir.mkdir(exist_ok=True)

    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")

    stderr_handler = logging.StreamHandler(sys.stderr)
    stderr_handler.setFormatter(fmt)

    root = logging.getLogger()
    root.setLevel(logging.INFO)
    if not has_dated_handler(root, "health_check_runner"):
        file_handler = DatedFileHandler(log_dir, "health_check_runner",
                                        retention_days=14)
        file_handler.setFormatter(fmt)
        root.addHandler(file_handler)
    if not any(isinstance(h, logging.StreamHandler) and h.stream is sys.stderr for h in root.handlers):
        root.addHandler(stderr_handler)


def _run_as_job(report_id: int, log) -> int:
    """Run one report, reporting progress into its manual_run_* columns.

    This is the body of the detached process the "Run Check" button spawns.
    The report is ALWAYS moved out of an in-flight state before returning -
    including when the run raises - because a row stuck at 'running' would
    block the button for that report until the staleness reaper noticed.

    A daemon thread stamps the heartbeat while the probes run. Without it a
    long-but-healthy run (several servers at 4x60s of SSH commands each) would
    look dead to the reaper and get failed out from under itself.
    """
    import threading

    from modules.application_health_check import manual_run
    from modules.application_health_check.health_monitor import run_health_check_force

    manual_run.mark_running(report_id)
    log.info("Job mode: running report id=%s (detached, pid=%s).",
             report_id, os.getpid())

    stop_beating = threading.Event()

    def _heartbeat():
        while not stop_beating.wait(manual_run.HEARTBEAT_INTERVAL_SECONDS):
            manual_run.beat(report_id)

    beater = threading.Thread(target=_heartbeat, name="manual-run-heartbeat",
                              daemon=True)
    beater.start()

    try:
        with manual_run.get_db_session() as db:
            user_id = db.query(manual_run.HealthCheckReport).filter_by(id=report_id).one().manual_run_by
        result = run_health_check_force(report_id, executed_by=user_id)
    except Exception as exc:
        log.exception("Job mode: report %s crashed.", report_id)
        manual_run.mark_failed(
            report_id,
            "The check failed with %s. See the application log for details."
            % type(exc).__name__,
        )
        return 1
    finally:
        stop_beating.set()

    if result is None:
        log.error("Job mode: report %s produced no result.", report_id)
        manual_run.mark_failed(
            report_id,
            "The check did not complete. The report may have been deactivated, "
            "or another run claimed it first.",
        )
        return 1

    summary = "%s - score %.0f%%, completed in %.1fs." % (
        (result.overall_status or "unknown").capitalize(),
        result.overall_score or 0.0,
        result.execution_time_seconds or 0.0,
    )
    log.info("Job mode: report %s -> %s", report_id, summary)
    manual_run.mark_done(report_id, summary)
    return 0


def _main() -> int:
    parser = argparse.ArgumentParser(description="Run application health checks.")
    parser.add_argument(
        "--force", action="store_true",
        help="With --report: run that report immediately regardless of "
             "next_run_time. Without --report: sweep every active report, "
             "ignoring next_run_time.",
    )
    parser.add_argument(
        "--purge", action="store_true",
        help="Run the 5-day retention purge.",
    )
    parser.add_argument(
        "--job", action="store_true",
        help="Report progress into the report's manual_run_* columns so the "
             "web UI can poll it. Set by the 'Run Check' button, which spawns "
             "this script detached; not needed for Task Scheduler runs.",
    )
    parser.add_argument(
        "--report", type=int, default=None,
        help="Run a single report by ID (manual one-off).",
    )
    parser.add_argument('--readiness', action='store_true', help='Print monitoring readiness JSON; exit 1 when unhealthy.')
    parser.add_argument('--notifications-only', action='store_true', help='Retry pending notifications without probing targets.')
    parser.add_argument('--upgrade-schema', action='store_true', help='Apply only the additive health-monitor schema upgrade, then exit.')
    parser.add_argument('--retry-notification', metavar='EVENT_ID', help='Requeue one failed email after the underlying problem is fixed.')
    args = parser.parse_args()
    if args.retry_notification:
        from modules.application_health_check.notifications import retry_failed_notification
        return 0 if retry_failed_notification(args.retry_notification) else 1
    if args.upgrade_schema:
        from database import engine
        from modules.application_health_check.schema import ensure_health_schema
        ensure_health_schema(engine)
        return 0
    if args.readiness:
        import json
        try:
            from modules.application_health_check.observability import monitoring_readiness
            state = monitoring_readiness()
            print(json.dumps(state))
            return 0 if state['status'] == 'ok' else 1
        except Exception:
            print(json.dumps({'status': 'unavailable', 'reason': 'Monitoring storage unavailable'}))
            return 2
    if args.notifications_only:
        from modules.application_health_check.notifications import deliver_pending_notifications
        stats = deliver_pending_notifications()
        print(stats)
        return 1 if stats['failed'] or stats['retry'] else 0

    _setup_logging()
    log = logging.getLogger("run_health_checks")

    # ---- Import the application modules ----------------------------------
    # Done after logging is set up so that any import-time failures get
    # captured to the rotating log file (and not just to a Task Scheduler
    # error popup nobody reads).
    try:
        from modules.application_health_check.health_monitor import (
            run_due_checks,
            run_health_check,
            run_health_check_force,
            _run_health_check_with_outcome,
            purge_old_executions,
        )
    except Exception as exc:
        log.exception("Fatal: failed to import application modules: %s", exc)
        return 2

    exit_code = 0

    # ---- Mode 1: single-report run ---------------------------------------
    if args.report is not None and args.job:
        return _run_as_job(args.report, log)

    if args.report is not None:
        if args.force:
            log.info("Running single report id=%s (FORCED - bypassing next_run_time).",
                     args.report)
            runner = run_health_check_force
        else:
            log.info("Running single report id=%s (only if due).", args.report)
            runner = run_health_check
        try:
            result, outcome = _run_health_check_with_outcome(args.report, bypass_due_check=args.force)
            if result is None:
                if outcome == 'error' or args.force:
                    log.error("Report %s did not produce a result (forced run).",
                              args.report)
                    exit_code = 1
                else:
                    log.warning(
                        "Report %s produced no result - most likely it is not "
                        "yet due. Use --force to override its next_run_time.",
                        args.report,
                    )
            else:
                log.info("Report %s -> %s (%.1f%%) in %.2fs.",
                         args.report, result.overall_status,
                         result.overall_score, result.execution_time_seconds)
        except Exception:
            log.exception("Single-report run crashed.")
            exit_code = 1

    # ---- Mode 2: full sweep ---------------------------------------------
    elif not args.purge:
        try:
            stats = run_due_checks(force=args.force)
            # stats keys: total, ran, skipped, failed
            log.info(
                "Due-check sweep: total=%d ran=%d skipped=%d failed=%d "
                "(force=%s).",
                stats.get('total',   0),
                stats.get('ran',     0),
                stats.get('skipped', 0),
                stats.get('failed',  0),
                args.force,
            )
            if stats.get('failed', 0) > 0:
                exit_code = 1
        except Exception:
            log.exception("Due-check sweep crashed.")
            return 2

    # ---- Optional: retention purge --------------------------------------
    # Allowed in combination with any other mode, but typically run on
    # its own from a separate Task Scheduler trigger.
    if args.purge:
        try:
            deleted = purge_old_executions()
            log.info("Retention purge: removed %d row(s).", deleted)
        except Exception:
            log.exception("Retention purge crashed.")
            exit_code = exit_code or 1

    return exit_code


def main() -> int:
    code = _main()
    # The Windows service also drains every 30 seconds. One-shot CLI/manual
    # runs attempt delivery immediately; stored retries survive process exit.
    if not any(flag in sys.argv for flag in ('--readiness', '--notifications-only', '--upgrade-schema')):
        try:
            from modules.application_health_check.notifications import deliver_pending_notifications
            stats = deliver_pending_notifications()
            if stats['failed'] or stats['retry']:
                code = code or 1
        except Exception:
            logging.exception('Health notification delivery failed.')
            code = code or 2
    return code


if __name__ == "__main__":
    sys.exit(main())
