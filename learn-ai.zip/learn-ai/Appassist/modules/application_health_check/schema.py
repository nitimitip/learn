"""Idempotent, additive health-monitor upgrade for SQLite and SQL Server.

Run with old workers stopped. Fail loudly if the service account lacks DDL
permission; never reset tables or delete data on migration failure.
"""
from sqlalchemy import inspect, text
from .models import HealthNotification, HealthMonitorHeartbeat

REPORT_COLUMNS = {
    'run_token': 'VARCHAR(36) NULL',
    'run_lease_until': 'DATETIME NULL',
    'config_version': 'INTEGER NOT NULL DEFAULT 0',
    'last_notification_status': 'VARCHAR(20) NULL',
    'last_notification_at': 'DATETIME NULL',
}


def ensure_health_schema(engine):
    columns = {c['name'] for c in inspect(engine).get_columns('health_check_reports')}
    with engine.begin() as connection:
        for name, definition in REPORT_COLUMNS.items():
            if name not in columns:
                keyword = 'ADD' if engine.dialect.name == 'mssql' else 'ADD COLUMN'
                connection.execute(text('ALTER TABLE health_check_reports %s %s %s' % (
                    keyword, name, definition)))
    HealthNotification.__table__.create(engine, checkfirst=True)
    HealthMonitorHeartbeat.__table__.create(engine, checkfirst=True)
    actual = {c['name'] for c in inspect(engine).get_columns('health_check_reports')}
    if not REPORT_COLUMNS.keys() <= actual:
        raise RuntimeError('Health-monitor schema upgrade incomplete.')
