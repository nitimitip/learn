# Health monitor backend update

This update preserves the existing UI files and layouts. It changes the runner, probes, notification delivery, read authorization, and schema. It has been tested against an isolated SQLite database and mocked remote endpoints; live IIS/Windows service, Oracle, SQL Server, WinRM, and SMTP deployment validation remains required.

## What changed

- A shared renewable execution lease prevents scheduled/manual overlap. Claims check due time, activity and pause state; result writes check the lease token and configuration version. Expired workers cannot overwrite newer results. Manual runs preserve a future scheduled slot.
- Report sweeps use a bounded worker pool, default four workers. A 15-minute report budget stops starting remaining probes; lease renewal stops after that budget. This is cooperative cancellation: an already-blocked driver/network call is not forcibly killed. Native connection/read/query timeouts still apply. Do not interpret this as a hard wall-clock termination guarantee.
- Missing server CPU/memory/disk data produces an incomplete-collection warning, not healthy zero usage. Empty monitoring coverage produces a warning and new/edited empty configurations are rejected.
- Database aggregation includes recovery-area capacity, archive/log warnings, job collection failures, expired-account counts and Data Guard error/gap signals. Connection/authentication errors are preserved. Oracle size calculations use the actual block size; SQL Agent's 24-hour filter uses date and time.
- Results and notification events are persisted together. A separate job delivers emails every 30 seconds, retries with backoff, tracks terminal failures, and retries only refused recipients after partial delivery. SMTP remains at-least-once: an interruption after acceptance can produce a duplicate with the same Message-ID.
- Alert-only reports send state changes, hourly reminders by default, and recovery notifications. Existing summary-email settings still send each run. This is notification state, not a full incident acknowledgment/escalation system.
- Sweep/storage errors propagate. Readiness reports stale/missing sweep heartbeat, overdue reports, runner failures and delayed/failed notifications. Read-only views show stale healthy results as warnings without rewriting historical data.
- Sensitive health read routes now require login and tower membership (or admin). Creating/editing reports updates scheduling; edits invalidate old in-flight results.
- URL connections validate and pin destination addresses, disable automatic redirects and environment proxies, scope NTLM to approved HTTPS hosts, limit response size, and support optional response-content/latency rules. Certificate inspection failures generate warnings.
- SSH requires trusted host keys. WinRM HTTPS and SQL Server verify server certificates. New monitoring credentials require an explicit encryption configuration; existing legacy decryption remains compatible until a planned data/key migration.

## Deployment sequence

1. Back up the configuration database and retain the current encryption keys. Stop the old scheduler/Task Scheduler triggers and IIS workers before deploying the updated backend; mixed old/new workers do not share the new lease protocol. Do not restore old workers while new workers are running.
2. Deploy the updated health module plus `database.py`, `mssql_database.py`, and `health_monitor_app_sched.py`. No template, JavaScript, or CSS replacement is needed. Source backups from this edit are in `artifacts/health-monitor-review/before/`.
3. Review the environment/trust settings below. These are deliberate behavior changes: targets using untrusted certificates/host keys, unapproved private URL networks, automatic redirects, or environment proxies will need configuration or corrected target URLs. The default mail transport now requires STARTTLS.
4. With the production interpreter and the application's configured environment, run the script by **file path**, from the project root:

   ```powershell
   python modules/application_health_check/run_health_checks.py --upgrade-schema
   ```

   This adds five report columns (`run_token`, `run_lease_until`, `config_version`, `last_notification_status`, `last_notification_at`) and two tables (`health_notification_outbox`, `health_monitor_heartbeat`). It preserves existing rows and can be rerun. The normal database/service initialization also ensures this schema and fails if it cannot be established. Use a deployment identity with DDL permission if the runtime identity is restricted. This command assumes the existing application database already exists.

5. Start exactly one dedicated scheduler service and IIS with `RUN_SCHEDULERS_IN_APP=false`. The service now honors `.env` cadence settings before applying defaults. Probe sweeps default to one minute; **existing report intervals remain 30 minutes–4 hours**. A faster sweep does not itself make each report a one-minute monitor.
6. Verify a representative report, its actual target permissions/trust, and alert plus recovery delivery in staging. Run the readiness command after a sweep finishes. Configure your existing independent monitoring platform to invoke it periodically and alert on a nonzero exit or failure to invoke it. Merely adding this endpoint does not configure an external watchdog.

   ```powershell
   python modules/application_health_check/run_health_checks.py --readiness
   python modules/application_health_check/run_health_checks.py --notifications-only
   ```

   `/application-health-check/monitoring-readiness` offers the same state over HTTP to an authenticated admin and returns 503 when unavailable. The existing `/health` remains a web liveness endpoint.

## Settings

| Setting | Default / purpose |
| --- | --- |
| `HEALTH_SWEEP_INTERVAL_MIN` | `1`; sweep cadence. Report intervals are unchanged. |
| `HEALTH_WORKERS` | `4`, bounded to 1–16; concurrent reports. Start at 1 if target capacity is uncertain. |
| `HEALTH_SWEEP_BATCH` | `50`, bounded to 1–1000; maximum reports selected per sweep. |
| `HEALTH_REPORT_BUDGET_SECONDS` | `900`, minimum 60; cooperative per-report budget. |
| `HEALTH_STALE_GRACE_SECONDS` | `300`; overdue and delayed-email grace. |
| `HEALTH_HEARTBEAT_MAX_AGE_SECONDS` | `300`; maximum age of the last completed sweep. Tune against measured batch duration; long sweeps remain visible as stale. |
| `HEALTH_EMAIL_MAX_ATTEMPTS` | `5`; delivery attempt limit. Backoff starts at 60 seconds and caps at one hour. |
| `HEALTH_ALERT_REMINDER_SECONDS` | `3600`; repeat an unchanged warning/failure when alert-only emails are enabled. |
| `HEALTH_SMTP_TLS` | `starttls`; also supports `ssl` or explicitly configured `none` for an approved trusted relay. Credentials are rejected with `none`. |
| `SMTP_SERVER`, `SMTP_PORT`, `EMAIL_FROM` | Existing sender/relay settings remain supported. Set explicitly for deployment. |
| `SMTP_USERNAME`, `SMTP_PASSWORD` | Optional authenticated SMTP. |
| `CORPORATE_CA_BUNDLE` | Trusted PEM bundle for URL/SMTP verification. Install the appropriate corporate CA in the SQL Server driver's OS trust store as well. |
| `HEALTH_SSH_KNOWN_HOSTS` | Optional path to verified SSH host keys, in addition to the service account's system known-hosts file. Obtain fingerprints through a trusted channel. |
| `HEALTH_SSH_AUTO_ADD_HOST_KEYS` | Unset (strict). `1` accepts an unknown SSH host key on the FIRST connection and remembers it - written back to `HEALTH_SSH_KNOWN_HOSTS` when that path is set, otherwise held only for the life of the check. Use only where a man-in-the-middle at enrolment time is out of scope; every run logs a warning while it is on. |
| `HEALTH_ALLOWED_NETWORKS` | Comma-separated approved private CIDRs for URL monitoring. Empty rejects private URL targets. Loopback, link-local, multicast, unspecified and reserved destinations remain blocked. |
| `HEALTH_ALLOWED_HOSTS` | Optional exact hostname allowlist for all URL targets; private hosts still require approved networks. |
| `HEALTH_NTLM_ALLOWED_HOSTS` | Exact HTTPS hostnames allowed to receive the existing `URL_NTLM_USER`/`URL_NTLM_PASS` credentials. Requires TLS verification. |
| `HEALTH_HTTP_MAX_BODY_BYTES` | `1048576`; use lightweight health endpoints. |
| `HEALTH_URL_RULES_JSON` | Optional rules keyed by exact URL, e.g. `{"https://app.example/ready":{"contains":"ready","warning_latency_ms":1000}}`. Configure via the environment; no UI change. |
| `ENCRYPTION_KEY` / `SESSION_SECRET` | Explicit existing encryption configuration required for new nonempty health credentials. Prefer a managed Fernet key; do not replace keys without migrating stored data. |

The existing `DISABLE_SSL_VERIFY=1` remains compatible for URL monitoring, but now produces a warning and disables NTLM credential use. Use corporate CA trust instead for production verification. WinRM uses its normal trusted CA configuration; SQL Server uses its driver's trusted certificate setup.

## Notification operations and retention

Inspect `health_notification_outbox` for `state`, `attempts`, `last_error`, and the event ID when readiness reports a delivery failure. After repairing the relay, requeue a failed deliverable message:

```powershell
python modules/application_health_check/run_health_checks.py --retry-notification EVENT_ID
```

Rendering/recipient-configuration failures have no deliverable payload; correct the report and run a new check instead. A valid new event supersedes the earlier preparation failure. Sent and superseded payloads are purged with the five-day history retention job. Pending/failed events remain for action. The CLI attempts delivery after a normal or manual run; deployments using only Task Scheduler must also schedule `--notifications-only` frequently enough for their delivery target.

## Verification and limits

Final local validation: **44 regression tests passed**. The existing health UI file hashes match their pre-update values. No live target probes, email sends, service restarts, or production schema upgrades were performed during implementation.

The adjacent `constraints.txt` records the core dependency versions exercised by these tests. Use it alongside the application's requirements when preparing a validated deployment environment:

```powershell
python -m pip install -r requirements.txt -c modules/application_health_check/constraints.txt
```

`artifacts/health-monitor-review/test_backend.py` imports the real backend modules using a test database and stubbed target drivers. It checks concurrency, expired/config-invalidated workers, result persistence, missing metrics, database aggregation, email retry/dedup/recovery, partial delivery, schema upgrades, authorization, stale-view behavior, HTTP target restrictions and UI file hashes. The earlier `verify_findings.py` now runs only against the saved pre-update source to preserve the historical reproductions.

Test runtime: Python 3.12.14, SQLAlchemy 2.0.50, Flask 3.1.3, Requests 2.34.2, urllib3 2.7.0, APScheduler 3.11.3, Paramiko 4.0.0, tzlocal 5.4.4. Test-only packages live under the review artifacts; they do not replace the production interpreter or installed packages. Pin and validate the production dependency set against its Python 3.13 runtime and actual database/OS drivers before rollout.

Remaining product work includes per-application faster probe policies, hard process-level deadlines, application-specific synthetic transactions, capacity trend prediction, recovery-objective/backup policies, comprehensive dependency modeling, external watchdog integration, incident ownership/escalation/acknowledgment, and a controlled legacy-key migration. Existing schedule/history timestamps remain local for compatibility; new leases/outbox/heartbeat use UTC. The score remains a diagnostic score, not an uptime/SLA percentage. These changes do not by themselves certify production readiness.
