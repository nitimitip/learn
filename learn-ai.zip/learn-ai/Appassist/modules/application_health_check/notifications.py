"""Transactional notification outbox. Never send SMTP inside result transactions."""
import logging
import os
import smtplib
import ssl
import uuid
from datetime import datetime, timedelta, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formatdate

from database import get_db_session
from .models import HealthNotification


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def enqueue_health_email(report, execution, db):
    """Rendering/configuration failures are observable without losing health data."""
    try:
        return _enqueue_health_email(report, execution, db)
    except (ValueError, TypeError, KeyError, AttributeError) as exc:
        logging.error('Cannot prepare health email for report %s: %s', report.id, type(exc).__name__)
        now = utcnow()
        existing = db.query(HealthNotification).filter_by(report_id=report.id, state='failed').first()
        if existing is None:
            db.add(HealthNotification(id=str(uuid.uuid4()), report_id=report.id,
                                     created_at=now, state='failed', attempts=0,
                                     next_attempt_at=now, recipients=[], message='',
                                     last_error='Notification configuration/rendering failed: ' + type(exc).__name__))
        return None


def _enqueue_health_email(report, execution, db):
    from .utils.reporting import _build_html_email
    config = report.email_config
    alerts = config.send_failure_alerts if config else True
    summaries = config.send_summary_reports if config else False
    status = execution.overall_status
    previous = report.last_notification_status
    now = utcnow()
    reminder = max(60, int(os.environ.get('HEALTH_ALERT_REMINDER_SECONDS', '3600')))
    elapsed = (now - report.last_notification_at).total_seconds() if report.last_notification_at else reminder
    recovery = status == 'healthy' and previous in ('warning', 'failed')
    if not (summaries or (alerts and (recovery or (
            status in ('warning', 'failed') and (status != previous or elapsed >= reminder))))):
        return None
    raw = (config.recipients if config else '') or (report.tower.email_addresses if report.tower else '')
    recipients = list(dict.fromkeys(e.strip() for e in (raw or '').split(',') if e.strip()))
    if not recipients:
        raise ValueError('Email alerts are enabled but no recipients are configured.')
    if any('\r' in e or '\n' in e or '@' not in e for e in recipients):
        raise ValueError('Invalid health notification recipient.')
    event_id = str(uuid.uuid4())
    msg = MIMEMultipart('alternative')
    msg['From'] = os.environ.get('EMAIL_FROM', 'NPgAppAssist@northernpowergrid.com')
    msg['To'] = ', '.join(recipients)
    msg['Date'] = formatdate(localtime=False)
    msg['Message-ID'] = '<' + event_id + '@appassist.health>'
    msg['Subject'] = '[%s] NPG Health Check - %s' % (
        'RECOVERED' if recovery else status.upper(), report.application_name)
    msg.attach(MIMEText('Application: %s\nHealth: %s\nChecked: %s\n' % (
        report.application_name, status, execution.executed_at), 'plain', 'utf-8'))
    msg.attach(MIMEText(_build_html_email(report, execution), 'html', 'utf-8'))
    # A newly valid event replaces prior preparation failures for this report.
    db.query(HealthNotification).filter_by(report_id=report.id, state='failed', message='').update(
        {'state': 'superseded', 'sent_at': now}, synchronize_session=False)
    db.add(HealthNotification(id=event_id, report_id=report.id, created_at=now,
                             state='pending', attempts=0, next_attempt_at=now,
                             recipients=recipients, message=msg.as_string()))
    report.last_notification_status = status
    report.last_notification_at = now
    return event_id


def _send(message, recipients):
    from email import message_from_string
    host = os.environ.get('SMTP_SERVER', 'mail1.northernpowergrid.com')
    port = int(os.environ.get('SMTP_PORT', '25'))
    mode = os.environ.get('HEALTH_SMTP_TLS', 'starttls').lower()
    if mode not in ('starttls', 'ssl', 'none'):
        raise ValueError('HEALTH_SMTP_TLS must be starttls, ssl, or none')
    context = ssl.create_default_context(cafile=os.environ.get('CORPORATE_CA_BUNDLE') or None)
    transport = smtplib.SMTP_SSL if mode == 'ssl' else smtplib.SMTP
    kwargs = {'context': context} if mode == 'ssl' else {}
    with transport(host, port, timeout=30, **kwargs) as smtp:
        if mode == 'starttls':
            smtp.starttls(context=context)
        username = os.environ.get('SMTP_USERNAME')
        if username:
            if mode == 'none':
                raise ValueError('SMTP credentials require TLS.')
            smtp.login(username, os.environ['SMTP_PASSWORD'])
        refused = smtp.send_message(message_from_string(message), to_addrs=recipients)
        if refused:
            # Some recipients may have received it. Retry only rejected addresses.
            return list(refused)
    return []


def deliver_pending_notifications():
    """Claim a bounded batch. SMTP delivery is at-least-once, with stable IDs."""
    now = utcnow()
    max_attempts = max(1, int(os.environ.get('HEALTH_EMAIL_MAX_ATTEMPTS', '5')))
    with get_db_session() as db:
        ids = [r[0] for r in db.query(HealthNotification.id).filter(
            ((HealthNotification.state == 'pending') & (HealthNotification.next_attempt_at <= now)) |
            ((HealthNotification.state == 'sending') & (HealthNotification.lease_until < now)),
        ).order_by(HealthNotification.next_attempt_at).limit(20).all()]
    stats = {'sent': 0, 'retry': 0, 'failed': 0}
    for event_id in ids:
        token = str(uuid.uuid4())
        with get_db_session() as db:
            rows = db.query(HealthNotification).filter(
                HealthNotification.id == event_id,
                ((HealthNotification.state == 'pending') & (HealthNotification.next_attempt_at <= utcnow())) |
                ((HealthNotification.state == 'sending') & (HealthNotification.lease_until < utcnow())),
            ).update({'state': 'sending', 'owner_token': token,
                      'lease_until': utcnow() + timedelta(minutes=10),
                      'attempts': HealthNotification.attempts + 1}, synchronize_session=False)
            if not rows:
                db.rollback()
                continue
            row = db.get(HealthNotification, event_id)
            message, recipients, attempts = row.message, row.recipients, row.attempts
            db.commit()
        error = None
        rejected = None
        try:
            if not message or not recipients:
                raise ValueError('Notification has no deliverable payload; correct the report and run a new check.')
            rejected = _send(message, recipients)
            if rejected:
                error = 'SMTP refused %d recipient(s).' % len(rejected)
        except Exception as exc:
            # Store exception class, not server replies which can contain secrets.
            error = 'Delivery failed: ' + type(exc).__name__
            logging.error('Health email %s: %s', event_id, error)
        state = 'sent' if error is None else ('failed' if attempts >= max_attempts else 'pending')
        values = {'state': state, 'owner_token': None, 'lease_until': None,
                  'last_error': error, 'sent_at': utcnow() if state == 'sent' else None,
                  'next_attempt_at': utcnow() + timedelta(seconds=min(3600, 30 * 2 ** min(attempts, 7)))}
        if rejected:
            values['recipients'] = rejected
        with get_db_session() as db:
            updated = db.query(HealthNotification).filter_by(id=event_id, owner_token=token).update(
                values, synchronize_session=False)
            db.commit()
        if updated:
            stats['retry' if state == 'pending' else state] += 1
    return stats


def retry_failed_notification(event_id):
    """Explicit operator retry after fixing the relay/recipient configuration."""
    with get_db_session() as db:
        rows = db.query(HealthNotification).filter(
            HealthNotification.id == event_id, HealthNotification.state == 'failed',
            HealthNotification.message != '',
        ).update({
            'state': 'pending', 'attempts': 0, 'next_attempt_at': utcnow(),
            'last_error': None, 'owner_token': None, 'lease_until': None,
        }, synchronize_session=False)
        db.commit()
        return bool(rows)
