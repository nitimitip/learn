"""Machine-readable monitoring readiness for an independent observer."""
import os
from datetime import datetime, timedelta, timezone
# `col == sql_true()` rather than `col.is_(True)`: SQLAlchemy renders
# the latter as `col IS 1`, which SQLite accepts and SQL SERVER REJECTS
# - T-SQL allows IS only with NULL. Both compile `== true()` to `= 1`.
from sqlalchemy import true as sql_true, false as sql_false
from sqlalchemy.exc import IntegrityError
from database import get_db_session
from .models import HealthCheckReport, HealthMonitorHeartbeat, HealthNotification


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def record_sweep(stats):
    with get_db_session() as db:
        row = db.get(HealthMonitorHeartbeat, 'sweep')
        if row is None:
            db.add(HealthMonitorHeartbeat(name='sweep'))
            try:
                db.commit()
            except IntegrityError:
                db.rollback()
        row = db.get(HealthMonitorHeartbeat, 'sweep')
        row.last_success_at = utcnow()
        row.details = stats
        db.commit()


def monitoring_readiness():
    """Raises on storage errors; callers must return unavailable, never healthy."""
    grace = max(60, int(os.environ.get('HEALTH_STALE_GRACE_SECONDS', '300')))
    heartbeat_limit = max(120, int(os.environ.get('HEALTH_HEARTBEAT_MAX_AGE_SECONDS', '300')))
    with get_db_session() as db:
        beat = db.get(HealthMonitorHeartbeat, 'sweep')
        beat_age = (utcnow() - beat.last_success_at).total_seconds() if beat and beat.last_success_at else None
        overdue = db.query(HealthCheckReport).filter(
            HealthCheckReport.is_active == sql_true(), HealthCheckReport.schedule_paused == sql_false(),
            (HealthCheckReport.next_run_time.is_(None)) |
            (HealthCheckReport.next_run_time < datetime.now() - timedelta(seconds=grace)),
        ).count()
        failed = db.query(HealthNotification).filter_by(state='failed').count()
        delayed = db.query(HealthNotification).filter(
            HealthNotification.state.in_(('pending', 'sending')),
            HealthNotification.created_at < utcnow() - timedelta(seconds=grace),
        ).count()
        runner_failures = int((beat.details or {}).get('failed', 0)) if beat else 0
        healthy = beat_age is not None and beat_age <= heartbeat_limit and not (
            overdue or failed or delayed or runner_failures)
        return {'status': 'ok' if healthy else 'unavailable', 'sweep_age_seconds': beat_age,
                'overdue_reports': overdue, 'failed_notifications': failed,
                'delayed_notifications': delayed, 'runner_failures': runner_failures}


def apply_freshness(report):
    """Overlay stale status for read-only views without altering stored history.

    Uses set_committed_value so a later session flush cannot persist this view.
    """
    from sqlalchemy.orm.attributes import set_committed_value
    grace = max(60, int(os.environ.get('HEALTH_STALE_GRACE_SECONDS', '300')))
    if not report.is_active or report.schedule_paused or not report.last_run_time:
        return
    if report.next_run_time is None or report.next_run_time < datetime.now() - timedelta(seconds=grace):
        if report.last_run_status == 'healthy':
            set_committed_value(report, 'last_run_status', 'warning')
        for kind in ('url', 'server', 'database'):
            key = 'latest_' + kind + '_results'
            results = []
            for result in getattr(report, key) or []:
                result = dict(result)
                if result.get('status') in ('success', 'healthy'):
                    result['status'] = 'warning'
                # Staleness is an ADDITIONAL reason, never a replacement. A
                # result that already explains itself - a slow endpoint, a
                # certificate about to expire, a filling disk - keeps that
                # reason, or the overlay would hide the very thing the check
                # found and leave only "this is old".
                stale_note = 'Monitoring result is stale; the next check is overdue.'
                existing = (result.get('warning_reason') or '').strip()
                if not existing:
                    result['warning_reason'] = stale_note
                elif stale_note in existing:
                    result['warning_reason'] = existing
                else:
                    joiner = ' ' if existing.endswith(('.', '!', '?')) else '; '
                    result['warning_reason'] = existing + joiner + stale_note
                results.append(result)
            set_committed_value(report, key, results)
