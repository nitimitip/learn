from flask import Blueprint

application_health_check_bp = Blueprint('application_health_check', __name__)

from . import routes
