"""Require configured encryption for new health-monitor credentials.

Existing decryption remains compatible; rotate legacy data separately with a
backup and the existing key available. Never silently generate a replacement.
"""
import os
from crypto_utils import encrypt_data


def encrypt_credential(value):
    if value and not (os.environ.get('ENCRYPTION_KEY') or
                      (os.environ.get('SESSION_SECRET') and
                       os.environ['SESSION_SECRET'] != 'default-secret-key')):
        raise ValueError('Configure ENCRYPTION_KEY before saving monitoring credentials.')
    return encrypt_data(value)
