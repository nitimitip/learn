"""
server_check.py - Server (AIX / Linux / Windows) health probe.

Contains the top-level check_server_health dispatcher, the SSH (Paramiko) and
WinRM transport helpers, and every OS-metric collector (uptime, CPU, memory,
disk, load, network, processes, services, critical events, OS info).
"""

import logging
import os
import re
import socket
from datetime import datetime

import paramiko

# Per-command timeout (seconds) for SSH-executed collectors. Without it a
# hung remote command (classic case: `df` blocking on a stale NFS mount)
# blocks the sweep thread forever while holding an SSH session open on the
# monitored production server.
_SSH_COMMAND_TIMEOUT: int = int(os.environ.get('SSH_COMMAND_TIMEOUT', '60'))

# Optional: WinRM for native Windows checks without SSH (pip install pywinrm).
try:
    import winrm  # pywinrm
    _HAS_WINRM = True
except ImportError:
    _HAS_WINRM = False

from crypto_utils import decrypt_data
from .common import _sanitise_process_name

# ---------------------------------------------------------------------------
# Server health check
# ---------------------------------------------------------------------------

def check_server_health(server_monitor) -> dict:
    """Check health of an AIX, Linux, or Windows server."""
    connection  = None
    server_type = getattr(server_monitor, 'server_type', '').lower().strip()
    # Declared out here so whatever was collected before an unexpected
    # failure still reaches the report instead of dying with the exception.
    result: dict = {}

    # Decrypt password immediately - never store plain text beyond this scope
    try:
        password = decrypt_data(server_monitor.password) if server_monitor.password else ''
    except Exception as exc:
        logging.error(
            f"Failed to decrypt password for server '{server_monitor.hostname}': {exc}"
        )
        return {
            'hostname':      server_monitor.hostname,
            'server_type':   server_monitor.server_type,
            'status':        'failed',
            'error_message': 'Credential decryption error - check server configuration.',
        }

    try:
        if server_type not in ('aix', 'linux', 'windows'):
            return {
                'hostname':      server_monitor.hostname,
                'server_type':   server_monitor.server_type,
                'status':        'failed',
                'error_message': (
                    f"Unsupported server type '{server_monitor.server_type}'. "
                    f"Supported: AIX, Linux, Windows."
                ),
            }

        result.update({
            'hostname':           server_monitor.hostname,
            'server_type':        server_monitor.server_type,
            'status':             'success',
            'uptime':             '',
            'cpu_usage':          None,
            'memory_usage':       None,
            'disk_usage':         [],
            'processes':          [],
            'services':           [],   # Windows services (template reads this)
            'load_average':       '',
            'network_connections': 0,
            'connection_type':    '',
            'warning_reason':     None,
            'error_message':      None,
            # Additive fields from the bigger bundle
            'os_info':         '',                # flat string for template
            'os_info_struct':  {},                # structured form for emails/JSON
            'critical_events': [],                # Windows event-log
        })

        if server_type in ('aix', 'linux'):
            connection = establish_ssh_connection(server_monitor, password)
            result['connection_type'] = 'SSH'
        else:
            connection = establish_windows_connection(server_monitor, password)
            result['connection_type'] = (
                connection['type'] if isinstance(connection, dict) else 'Unknown'
            )

        if not connection:
            result['status']        = 'failed'
            result['error_message'] = 'Failed to establish connection.'
            return result

        # ---- Core metrics ---------------------------------------------
        # Each collector is isolated: one that blows up (a dropped channel, a
        # parse the helper did not anticipate) is recorded and skipped, and
        # every OTHER metric is still collected and still reported. Before
        # this, the first failure aborted the sweep for the whole server and
        # the report showed the exception alone.
        collection_errors: list[str] = []

        def _collect(label, key, fn, default):
            try:
                result[key] = fn()
            except Exception as exc:
                logging.warning(
                    f"Could not collect {label} for '{server_monitor.hostname}': {exc}"
                )
                result[key] = default
                collection_errors.append(label)

        _collect('uptime', 'uptime', lambda: get_uptime(connection, server_type), 'Unknown')
        _collect('disk usage', 'disk_usage', lambda: get_disk_usage(connection, server_type), [])

        try:
            cpu_data = get_cpu_usage(connection, server_type)
            if isinstance(cpu_data, dict):
                result['cpu_usage'] = cpu_data.get('cpu_usage')
            else:
                result['cpu_usage'] = cpu_data
        except Exception as exc:
            logging.warning(
                f"Could not collect CPU usage for '{server_monitor.hostname}': {exc}"
            )
            result['cpu_usage'] = None
            collection_errors.append('CPU usage')

        _collect('memory usage', 'memory_usage',
                 lambda: get_memory_usage(connection, server_type), None)
        _collect('load average', 'load_average',
                 lambda: get_load_average(connection, server_type), 'Unknown')
        _collect('network connections', 'network_connections',
                 lambda: get_network_connections(connection, server_type), 0)

        # ---- OS information (best-effort; never fails the check)
        try:
            result['os_info']        = get_os_info(connection, server_type)
            result['os_info_struct'] = get_os_info_struct(connection, server_type)
        except Exception as exc:
            logging.debug(
                f"OS info collection failed for '{server_monitor.hostname}': {exc}"
            )

        warning_reasons: list[str] = []
        error_reasons:   list[str] = []
        missing = [name for name in ('cpu_usage', 'memory_usage') if result[name] is None]
        if not result['disk_usage']:
            missing.append('disk_usage')
        result['collection_status'] = 'incomplete' if (missing or collection_errors) else 'complete'
        result['missing_metrics'] = missing
        result['missing_checks']  = collection_errors
        if missing:
            warning_reasons.append('Could not collect required metrics: ' + ', '.join(missing))

        for disk in result['disk_usage']:
            if disk['status'] == 'critical':
                error_reasons.append(f"{disk['filesystem']} at {disk['used_percent']}%")
            elif disk['status'] == 'warning':
                warning_reasons.append(f"{disk['filesystem']} at {disk['used_percent']}%")

        # CPU / memory thresholds - 90% warns, 95% fails
        try:
            cpu_pct = float(result.get('cpu_usage') or 0)
        except (TypeError, ValueError):
            cpu_pct = 0
        try:
            mem_pct = float(result.get('memory_usage') or 0)
        except (TypeError, ValueError):
            mem_pct = 0

        # ---- Transient-spike guard ------------------------------------
        # The health check's own footprint (SSH + vmstat/ps) can briefly push
        # CPU/memory over the line. Before raising a CRITICAL (which fails the
        # check), confirm the breach with a second reading and use the average
        # of the two. A genuine, sustained overload stays high and still fails;
        # a one-off spike averages back down to at most a warning, so it no
        # longer raises a false error.
        # A failed confirmation read must not abort the sweep - keep the first
        # reading and carry on grading everything else.
        if cpu_pct >= 95:
            try:
                cpu_confirm = get_cpu_usage(connection, server_type)
                cpu_confirm_val = (
                    cpu_confirm.get('cpu_usage', cpu_pct)
                    if isinstance(cpu_confirm, dict) else cpu_confirm
                )
                cpu_pct = round((cpu_pct + float(cpu_confirm_val)) / 2, 1)
            except Exception as exc:
                logging.debug(f"CPU confirmation read failed: {exc}")
            result['cpu_usage'] = cpu_pct
        if mem_pct >= 95:
            try:
                mem_confirm = float(get_memory_usage(connection, server_type))
                mem_pct = round((mem_pct + mem_confirm) / 2, 1)
            except Exception as exc:
                logging.debug(f"Memory confirmation read failed: {exc}")
            result['memory_usage'] = mem_pct

        if cpu_pct >= 95:
            error_reasons.append(f"CPU at {cpu_pct:.0f}%")
        elif cpu_pct >= 90:
            warning_reasons.append(f"CPU at {cpu_pct:.0f}%")
        if mem_pct >= 95:
            error_reasons.append(f"Memory at {mem_pct:.0f}%")
        elif mem_pct >= 90:
            warning_reasons.append(f"Memory at {mem_pct:.0f}%")

        # ---- Process / service checks ----------------------------------
        # On Windows, processes_to_monitor names are interpreted as service
        # names. Populate BOTH 'services' (template's dedicated card) AND
        # 'processes' (template's process-health card) so existing rendering
        # is not broken.
        if server_monitor.processes_to_monitor:
            try:
                if server_type == 'windows':
                    services = check_windows_services(
                        connection, server_monitor.processes_to_monitor
                    )
                    result['services']  = services
                    result['processes'] = services   # mirror for legacy block
                else:
                    result['processes'] = check_processes(
                        connection, server_monitor.processes_to_monitor, server_type
                    )
            except Exception as exc:
                label = 'service checks' if server_type == 'windows' else 'process checks'
                logging.warning(
                    f"Could not run {label} for '{server_monitor.hostname}': {exc}"
                )
                collection_errors.append(label)
            for proc in result['processes']:
                if proc['status'] == 'not_running':
                    error_reasons.append(
                        f"{'Service' if server_type == 'windows' else 'Process'} "
                        f"'{proc['name']}' not running."
                    )
                elif proc['status'] in ('warning', 'error', 'unknown'):
                    detail = proc.get('error') or 'has issues.'
                    warning_reasons.append(
                        f"{'Service' if server_type == 'windows' else 'Process'} "
                        f"'{proc['name']}' check problem: {detail}"
                    )

        # ---- Windows critical event-log entries ------------------------
        if server_type == 'windows':
            try:
                events = get_windows_critical_events(connection)
                result['critical_events'] = events
                crit_count = sum(1 for e in events if e.get('level') == 'Critical')
                if crit_count > 0:
                    warning_reasons.append(
                        f"{crit_count} critical event(s) in last hour"
                    )
            except Exception as exc:
                logging.warning(
                    f"Event-log query failed for '{server_monitor.hostname}': {exc}"
                )
                collection_errors.append('critical event log')

        # Recomputed here so collectors that errored AFTER the first pass
        # (processes/services, event log) are counted too. "Not collected"
        # and "collected but came back empty" are different problems, so the
        # errored collectors are named separately from `missing_metrics`.
        result['missing_checks']    = collection_errors
        result['collection_status'] = (
            'incomplete' if (missing or collection_errors) else 'complete'
        )
        if collection_errors:
            warning_reasons.append('Checks that errored: ' + ', '.join(collection_errors))

        if error_reasons:
            result['status']        = 'failed'
            result['error_message'] = '; '.join(error_reasons)
        elif warning_reasons:
            result['status'] = 'warning'

        # Warning-level findings are kept even when the server is FAILED. A
        # critical disk used to swallow every other warning (missing metrics,
        # a service check that errored, critical events) - the report and the
        # email show the error box and the warning box separately.
        if warning_reasons:
            result['warning_reason'] = '; '.join(warning_reasons)

        return result

    except Exception as exc:
        logging.exception(f"Error checking server '{server_monitor.hostname}'.")
        # RuntimeError is what this module raises for its OWN diagnostics, and
        # those are already written for whoever reads the report - putting
        # 'RuntimeError:' in front of them only makes an actionable sentence
        # look like a crash. Every other exception type keeps its name, where
        # it is a genuine clue.
        if isinstance(exc, RuntimeError) and str(exc):
            message = str(exc)
        else:
            message = f"{type(exc).__name__}: {exc}" if str(exc) else type(exc).__name__
        # Keep every metric collected before the failure - the report marks
        # the server failed but still shows disks, CPU, memory and processes
        # that WERE read, instead of showing the error alone.
        result['hostname']          = server_monitor.hostname
        result['server_type']       = server_monitor.server_type
        result['status']            = 'failed'
        result['error_message']     = message
        result['collection_status'] = 'incomplete'
        return result
    finally:
        # Ensure password does not linger in any local scope
        password = None  # noqa: F841 (intentional)
        close_connection(connection, server_type)


# ---------------------------------------------------------------------------
# SSH / WinRM connection helpers
# ---------------------------------------------------------------------------

def _safe_close_ssh(ssh) -> None:
    """Close a paramiko SSHClient, swallowing any error.

    Used to tear down a client whose connect() failed so a failed attempt
    never leaks its socket / transport thread on the long-running monitor.
    """
    try:
        if ssh is not None:
            ssh.close()
    except Exception:
        pass


def establish_ssh_connection(server_monitor, password):
    """Open a Paramiko SSH connection.

    On any connection failure the partially-initialised SSHClient is closed
    before the error is re-raised, so a failed connect never leaks a socket
    or transport thread.
    """
    ssh = paramiko.SSHClient()
    _configure_ssh_trust(ssh)
    try:
        ssh.connect(
            hostname=server_monitor.hostname,
            port=getattr(server_monitor, 'port', 22),
            username=server_monitor.username,
            password=password,
            timeout=30,
            banner_timeout=30,
            auth_timeout=30,
        )
        return ssh
    except paramiko.AuthenticationException:
        _safe_close_ssh(ssh)
        raise RuntimeError('SSH authentication failed - invalid credentials.')
    except paramiko.SSHException as exc:
        _safe_close_ssh(ssh)
        raise RuntimeError(_ssh_error_message(exc, server_monitor.hostname))
    except socket.timeout:
        _safe_close_ssh(ssh)
        raise RuntimeError('SSH connection timed out.')
    except Exception:
        # DNS failure, network unreachable, etc. - still must not leak.
        _safe_close_ssh(ssh)
        raise


def establish_windows_connection(server_monitor, password):
    """Connect to a Windows server.

    Tries WinRM first (recommended for Windows); falls back to SSH if
    WinRM is unavailable, the library isn't installed, or the WinRM port
    isn't listening. Backward-compatible with hosts running OpenSSH for
    Windows.
    """
    port = getattr(server_monitor, 'port', 5985)

    # ---- 1. WinRM (preferred) ----------------------------------------
    if _HAS_WINRM and port in (5985, 5986):
        use_ssl = (port == 5986)
        scheme  = 'https' if use_ssl else 'http'
        target  = f'{scheme}://{server_monitor.hostname}:{port}/wsman'
        try:
            session = winrm.Session(
                target=target,
                auth=(server_monitor.username, password),
                transport='ntlm',
                server_cert_validation='validate',
                operation_timeout_sec=30,
                read_timeout_sec=35,
            )
            probe = session.run_ps('$PSVersionTable.PSVersion.Major')
            if probe.status_code == 0:
                return {'session': session, 'type': 'WinRM'}
            logging.warning(
                f"WinRM probe to '{server_monitor.hostname}' returned "
                f"status {probe.status_code}: "
                f"{probe.std_err.decode(errors='replace')[:120]}"
            )
        except Exception as exc:
            logging.warning(
                f"WinRM connection to '{server_monitor.hostname}' failed: "
                f"{exc} - trying SSH fallback."
            )

    # ---- 2. SSH fallback (OpenSSH for Windows) -----------------------
    ssh = None
    ssh_reason = 'SSH was not attempted.'
    try:
        ssh      = paramiko.SSHClient()
        ssh_port = 22 if port in (5985, 5986) else port
        _configure_ssh_trust(ssh)
        ssh.connect(
            hostname=server_monitor.hostname,
            port=ssh_port,
            username=server_monitor.username,
            password=password,
            timeout=30,
            banner_timeout=30,
            auth_timeout=30,
        )
        return {'session': ssh, 'type': 'SSH'}
    except Exception as exc:
        _safe_close_ssh(ssh)
        logging.warning(
            f"SSH fallback to Windows host '{server_monitor.hostname}' "
            f"failed: {exc}"
        )
        # Carry the SSH reason into the failure the operator actually sees.
        # 'Failed to connect via WinRM or SSH.' on its own names neither the
        # transport that was tried last nor why it refused.
        ssh_reason = _ssh_error_message(exc, server_monitor.hostname)

    raise RuntimeError(f'Failed to connect via WinRM or SSH. {ssh_reason}')


def close_connection(connection, server_type: str) -> None:
    """Close an SSH or WinRM connection, ignoring errors."""
    try:
        if server_type in ('aix', 'linux') and connection:
            connection.close()
        elif server_type == 'windows' and isinstance(connection, dict):
            session = connection.get('session')
            if session and hasattr(session, 'close'):
                session.close()
    except Exception as exc:
        logging.debug(f"Non-fatal error closing connection: {exc}")


def _ssh_trust_on_first_use() -> bool:
    """True when the operator has opted into trust-on-first-use host keys.

    Off by default: the monitor verifies SSH host keys strictly, so a host
    whose key it has never seen is refused rather than trusted blindly.
    HEALTH_SSH_AUTO_ADD_HOST_KEYS=1 relaxes that to accept-and-remember on
    the FIRST connection, which is only appropriate on a network where a
    man-in-the-middle at enrolment time is not part of the threat model.
    """
    return os.environ.get(
        'HEALTH_SSH_AUTO_ADD_HOST_KEYS', ''
    ).strip().lower() in ('1', 'true', 'yes', 'on')


def _configure_ssh_trust(ssh):
    ssh.load_system_host_keys()
    known_hosts = os.environ.get('HEALTH_SSH_KNOWN_HOSTS')
    if known_hosts:
        # load_host_keys() records the path before reading it, so a file that
        # does not exist yet still becomes the destination that a
        # trust-on-first-use key is written back to. A missing file is
        # therefore a normal first-run state, not an error - but an
        # unreadable one is worth saying out loud, because the silent effect
        # is that every host looks untrusted.
        try:
            ssh.load_host_keys(known_hosts)
        except FileNotFoundError:
            logging.info(
                f"HEALTH_SSH_KNOWN_HOSTS file '{known_hosts}' does not exist yet."
            )
        except Exception as exc:
            logging.warning(
                f"HEALTH_SSH_KNOWN_HOSTS file '{known_hosts}' could not be "
                f"read ({exc}); continuing with system host keys only."
            )
    if _ssh_trust_on_first_use():
        logging.warning(
            'HEALTH_SSH_AUTO_ADD_HOST_KEYS is set: unknown SSH host keys are '
            'accepted on first connection and are NOT verified.'
        )
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    else:
        ssh.set_missing_host_key_policy(paramiko.RejectPolicy())


def _ssh_error_message(exc, hostname: str) -> str:
    """Turn a Paramiko SSHException into something an operator can act on.

    The one worth translating is the strict host-key refusal. Paramiko words
    it as "Server 'x' not found in known_hosts", which reads like the SERVER
    is missing - operators check DNS and the hostname spelling, both of which
    are fine. What is actually missing is our copy of that server's host key.
    """
    text = str(exc)
    if 'not found in known_hosts' in text:
        known_hosts = os.environ.get('HEALTH_SSH_KNOWN_HOSTS')
        where = (f"HEALTH_SSH_KNOWN_HOSTS ({known_hosts})" if known_hosts
                 else "the service account's ~/.ssh/known_hosts file")
        return (
            f"SSH host key for '{hostname}' is not trusted yet. The monitor "
            f"verifies host keys strictly and has no key for this host in "
            f"{where}. Add its fingerprint - obtained through a trusted "
            f"channel, e.g. 'ssh-keyscan {hostname}' verified against the "
            f"server team's record - to that file, or set "
            f"HEALTH_SSH_AUTO_ADD_HOST_KEYS=1 to trust the key presented on "
            f"the first connection."
        )
    return f'SSH connection error: {exc}'


def execute_command(connection, command: str, server_type: str):
    """Run a command over the given connection; return stdout or None."""
    try:
        if server_type in ('aix', 'linux'):
            # timeout= bounds channel reads; read stdout to EOF BEFORE asking
            # for the exit status - recv_exit_status() has no timeout of its
            # own and would block forever on a hung remote command.
            _, stdout, _ = connection.exec_command(
                command, timeout=_SSH_COMMAND_TIMEOUT)
            output       = stdout.read().decode('utf-8').strip()
            exit_code    = stdout.channel.recv_exit_status()
            return output if exit_code == 0 else None

        elif server_type == 'windows' and isinstance(connection, dict):
            session         = connection['session']
            connection_type = connection['type']

            if 'WinRM' in connection_type:
                result = (
                    session.run_ps(command[11:])
                    if command.startswith('powershell ')
                    else session.run_cmd(command)
                )
                return result.std_out.decode('utf-8').strip() if result.status_code == 0 else None

            elif connection_type == 'SSH':
                _, stdout, _ = session.exec_command(
                    command, timeout=_SSH_COMMAND_TIMEOUT)
                output       = stdout.read().decode('utf-8').strip()
                exit_code    = stdout.channel.recv_exit_status()
                return output if exit_code == 0 else None

    except Exception as exc:
        logging.debug(f"Command execution error on '{server_type}': {exc}")
    return None


def execute_command_ex(connection, command: str, server_type: str):
    """Run a command and return ``(exit_code, stdout)``.

    Unlike execute_command(), a non-zero exit still returns the output and
    the real exit code, so callers can distinguish "command ran and found
    nothing" from "command/transport failed". Returns ``(None, '')`` when
    the command could not be executed at all.
    """
    try:
        if server_type in ('aix', 'linux'):
            # Same read-before-exit-status ordering as execute_command() so a
            # hung command times out instead of blocking the sweep forever.
            _, stdout, _ = connection.exec_command(
                command, timeout=_SSH_COMMAND_TIMEOUT)
            output       = stdout.read().decode('utf-8', errors='replace').strip()
            exit_code    = stdout.channel.recv_exit_status()
            return exit_code, output

        elif server_type == 'windows' and isinstance(connection, dict):
            session         = connection['session']
            connection_type = connection['type']

            if 'WinRM' in connection_type:
                result = (
                    session.run_ps(command[11:])
                    if command.startswith('powershell ')
                    else session.run_cmd(command)
                )
                return result.status_code, result.std_out.decode('utf-8', errors='replace').strip()

            elif connection_type == 'SSH':
                _, stdout, _ = session.exec_command(
                    command, timeout=_SSH_COMMAND_TIMEOUT)
                output       = stdout.read().decode('utf-8', errors='replace').strip()
                exit_code    = stdout.channel.recv_exit_status()
                return exit_code, output

    except Exception as exc:
        logging.warning(f"Command execution error on '{server_type}': {exc}")
    return None, ''


# ---------------------------------------------------------------------------
# Server metric helpers
# ---------------------------------------------------------------------------

def get_uptime(connection, server_type: str) -> str:
    if server_type == 'aix':
        output = execute_command(connection, 'uptime', server_type)
        if output and 'up' in output:
            return output.split('up')[1].split(',')[0].strip()
    elif server_type == 'linux':
        output = execute_command(connection, 'uptime -p', server_type)
        if output:
            return output.replace('up ', '')
    elif server_type == 'windows':
        output = execute_command(
            connection,
            'powershell (Get-CimInstance -ClassName Win32_OperatingSystem).LastBootUpTime',
            server_type,
        )
        if output:
            try:
                boot_time    = datetime.strptime(output.split('.')[0], '%m/%d/%Y %I:%M:%S %p')
                delta        = datetime.now() - boot_time
                hours, rem   = divmod(delta.seconds, 3600)
                minutes, _   = divmod(rem, 60)
                return f"{delta.days}d {hours}h {minutes:02d}m"
            except Exception as exc:
                logging.debug(f"Could not parse Windows boot time: {exc}")
    return 'Unknown'


def get_cpu_usage(connection, server_type: str):
    if server_type in ('aix', 'linux'):
        # Sample several 1-second intervals and AVERAGE them instead of
        # trusting a single sample. A one-shot `vmstat 1 2 | tail -1` reading
        # is very noisy and frequently catches the transient spike caused by
        # the health check's OWN work (SSH login + spawning vmstat/ps), which
        # produced false "CPU critical" failures. `vmstat 1 4` gives 1
        # since-boot row plus 3 one-second samples; we drop the since-boot row
        # and average the rest (~3s) for a representative figure.
        output = execute_command(connection, 'vmstat 1 4', server_type)
        if output:
            # The CPU columns sit at the END of the vmstat row, but their
            # absolute positions differ by OS because the memory/page columns
            # in front of them differ:
            #   Linux (procps): r b swpd free buff cache si so bi bo in cs
            #                   us sy id wa st          -> idle=14, wait=15
            #   AIX:            r b avm fre re pi po fr sr cy in sy cs
            #                   us sy id wa [pc ec]     -> idle=15, wait=16
            # Using the Linux offsets on AIX read the system-time column as
            # "idle" and over-reported AIX CPU usage, so index per-OS.
            if server_type == 'aix':
                idle_idx, wait_idx, min_len = 15, 16, 17
            else:
                idle_idx, wait_idx, min_len = 14, 15, 16

            # Keep only real data rows (first column = run-queue integer),
            # which also skips vmstat's two header lines.
            rows = [
                f for f in (line.split() for line in output.split('\n'))
                if len(f) >= min_len and f[0].isdigit()
            ]
            # Drop the first data row - it is the cumulative since-boot
            # average, not a current sample.
            samples = rows[1:] if len(rows) > 1 else rows

            idles, waits, rqs = [], [], []
            for f in samples:
                try:
                    idles.append(float(f[idle_idx]))
                    waits.append(float(f[wait_idx]))
                    rqs.append(float(f[0]))
                except (ValueError, IndexError):
                    continue
            if idles:
                avg_idle = sum(idles) / len(idles)
                return {
                    'cpu_idle':  round(avg_idle, 1),
                    'io_wait':   round(sum(waits) / len(waits), 1) if waits else 0.0,
                    'run_queue': round(sum(rqs) / len(rqs), 1) if rqs else 0.0,
                    'cpu_usage': round(100 - avg_idle, 1),
                    'samples':   len(idles),
                }
    elif server_type == 'windows':
        output = execute_command(
            connection,
            'powershell Get-Counter "\\Processor(_Total)\\% Processor Time" | '
            'Select-Object -ExpandProperty CounterSamples | '
            'Select-Object -ExpandProperty CookedValue',
            server_type,
        )
        if output:
            try:
                return round(float(output), 1)
            except ValueError:
                pass
    return None


def get_memory_usage(connection, server_type: str) -> float:
    if server_type == 'aix':
        output = execute_command(connection, 'svmon -G | grep memory', server_type)
        if output:
            fields = output.split()
            if len(fields) >= 3:
                try:
                    total = int(fields[1]) * 4
                    used  = int(fields[2]) * 4
                    return round((used / total) * 100, 1)
                except (ValueError, IndexError, ZeroDivisionError):
                    pass
    elif server_type == 'linux':
        output = execute_command(connection, 'free | grep Mem', server_type)
        if output:
            fields = output.split()
            if len(fields) >= 3:
                try:
                    return round((int(fields[2]) / int(fields[1])) * 100, 1)
                except (ValueError, IndexError, ZeroDivisionError):
                    pass
    elif server_type == 'windows':
        output = execute_command(
            connection,
            'powershell $m=Get-CimInstance Win32_OperatingSystem; '
            '[math]::Round((($m.TotalVisibleMemorySize-$m.FreePhysicalMemory)/$m.TotalVisibleMemorySize)*100,1)',
            server_type,
        )
        if output:
            try:
                return float(output)
            except ValueError:
                pass
    return None


def get_disk_usage(connection, server_type: str) -> list:
    if server_type == 'aix':
        output = execute_command(connection, "df -k | grep -v '^Filesystem'", server_type)
    elif server_type == 'linux':
        output = execute_command(connection, "df -h | grep -v '^Filesystem'", server_type)
    elif server_type == 'windows':
        output = execute_command(
            connection,
            'powershell Get-CimInstance -ClassName Win32_LogicalDisk | '
            'Select-Object DeviceID, @{Name="UsedPercent";Expression={'
            '[math]::Round((($_.Size-$_.FreeSpace)/$_.Size)*100,0)}} | '
            'Format-Table -HideTableHeaders',
            server_type,
        )
    else:
        return []

    disk_usage = []
    if not output:
        return disk_usage

    for line in output.split('\n'):
        if not line.strip():
            continue
        try:
            fields = line.split()
            if server_type in ('aix', 'linux'):
                if len(fields) < 6:
                    continue
                mount_point  = fields[6] if server_type == 'aix' and len(fields) > 6 else fields[5]
                used_percent = int(fields[3].rstrip('%') if server_type == 'aix' else fields[4].rstrip('%'))
            else:  # windows
                if len(fields) < 2:
                    continue
                mount_point  = fields[0]
                used_percent = int(fields[1])

            status = 'critical' if used_percent >= 95 else ('warning' if used_percent >= 85 else 'ok')
            disk_usage.append({'filesystem': mount_point, 'used_percent': used_percent, 'status': status})
        except (ValueError, IndexError):
            continue

    return disk_usage


def get_load_average(connection, server_type: str) -> str:
    if server_type in ('aix', 'linux'):
        output = execute_command(connection, 'uptime', server_type)
        if output and 'load average' in output:
            return output.split('load average:')[1].strip()
    return 'N/A' if server_type == 'windows' else 'Unknown'


def get_network_connections(connection, server_type: str) -> int:
    if server_type in ('aix', 'linux'):
        output = execute_command(connection, 'netstat -an | grep ESTABLISHED | wc -l', server_type)
    elif server_type == 'windows':
        output = execute_command(
            connection,
            'powershell (Get-NetTCPConnection -State Established).Count',
            server_type,
        )
    else:
        return 0

    if output:
        try:
            return int(output.strip())
        except ValueError:
            pass
    return 0


def check_processes(connection, processes_to_monitor: str, server_type: str) -> list:
    """Check whether the specified comma-separated processes are running.

    AIX / Linux flow: the full process table is fetched ONCE with
    ``ps -e -o pid,args`` (full argument list - WebLogic & co. run as
    ``java`` and are only identifiable by their arguments) and the
    configured names are matched in Python, case-insensitively. Nothing
    user-supplied is interpolated into the shell command, and a failed
    ``ps`` is reported as a check *error* instead of being mistaken for
    "process not running".
    """
    processes = []
    raw_names = [p.strip() for p in processes_to_monitor.split(',') if p.strip()]
    if not raw_names:
        return processes

    # ---- Fetch the process table once (AIX / Linux) --------------------
    ps_lines = None   # None -> table unavailable; every check becomes 'error'
    ps_error = ''
    if server_type in ('aix', 'linux'):
        exit_code, output = execute_command_ex(
            connection, 'ps -e -o pid,args', server_type
        )
        if exit_code == 0 and output:
            # Keep only real process rows (line begins with a numeric PID).
            # This drops the "PID COMMAND" header so it can never be counted
            # as a match or mistaken for a PID, which kept process counts and
            # PIDs accurate when monitoring multiple processes.
            ps_lines = [
                l for l in output.split('\n')
                if l.strip() and l.split()[0].isdigit()
            ]
        else:
            ps_error = (
                'Could not read the process table - '
                + ('command did not run (connection/transport error).'
                   if exit_code is None
                   else f"'ps -e -o pid,args' exited with code {exit_code}.")
            )
            logging.warning(
                f"Process check on '{server_type}' server failed: {ps_error}"
            )

    for raw_name in raw_names:
        try:
            process_name = _sanitise_process_name(raw_name)
        except ValueError as exc:
            processes.append({
                'name':   raw_name,
                'status': 'error',
                'pid':    None,
                'count':  0,
                'error':  str(exc),
            })
            continue

        try:
            if server_type in ('aix', 'linux'):
                if ps_lines is None:
                    processes.append({
                        'name': process_name, 'status': 'error',
                        'pid': None, 'count': 0, 'error': ps_error,
                    })
                    continue

                needle  = process_name.lower()
                matches = [l for l in ps_lines if needle in l.lower()]
                if matches:
                    pids = [l.split()[0] for l in matches if l.split()]
                    processes.append({
                        'name':   process_name,
                        'status': 'running',
                        'pid':    pids[0] if pids else 'Unknown',
                        'count':  len(matches),
                    })
                else:
                    processes.append({'name': process_name, 'status': 'not_running', 'pid': None, 'count': 0})
                continue

            if server_type == 'windows':
                command = (
                    f'powershell Get-Process -Name "*{process_name}*" '
                    f'-ErrorAction SilentlyContinue | Select-Object Id, ProcessName'
                )
            else:
                processes.append({
                    'name': process_name, 'status': 'unknown',
                    'pid': None, 'count': 0,
                    'error': f'Process checking unsupported for server type: {server_type}',
                })
                continue

            output = execute_command(connection, command, server_type)

            if output and output.strip():
                lines = [l for l in output.split('\n') if l.strip()]
                pids  = [l.split()[0] for l in lines if l.split()]
                processes.append({
                    'name':   process_name,
                    'status': 'running',
                    'pid':    pids[0] if pids else 'Unknown',
                    'count':  len(lines),
                })
            else:
                processes.append({'name': process_name, 'status': 'not_running', 'pid': None, 'count': 0})

        except Exception as exc:
            logging.warning(f"Error checking process '{process_name}': {exc}")
            processes.append({'name': process_name, 'status': 'error', 'pid': None, 'count': 0,
                              'error': f'{type(exc).__name__}: {exc}'})

    return processes


def determine_overall_status(result: dict) -> str:
    critical_disks   = [d for d in result.get('disk_usage', []) if d['status'] == 'critical']
    warning_disks    = [d for d in result.get('disk_usage', []) if d['status'] == 'warning']
    failed_processes = [p for p in result.get('processes',  []) if p['status'] == 'not_running']

    if critical_disks or failed_processes:
        return 'failed'
    elif warning_disks:
        return 'warning'
    return 'success'


# ---------------------------------------------------------------------------
# OS information - flat string for template, structured for emails/JSON
# ---------------------------------------------------------------------------
def get_os_info(connection, server_type: str) -> str:
    """Return a one-line OS description (e.g. 'Ubuntu 22.04 (5.15.0)').

    Templates render {{ server_result.os_info }} directly so this MUST
    return a string. Use get_os_info_struct() if you need fields.
    """
    s = get_os_info_struct(connection, server_type)
    name    = s.get('name')    or 'Unknown'
    version = s.get('version') or ''
    kernel  = s.get('kernel')  or ''
    out = version if (version and version != name) else name
    if kernel and kernel not in out:
        out = f"{out} ({kernel})"
    return out


def get_os_info_struct(connection, server_type: str) -> dict:
    """OS information as a dict - used by the email renderer / JSON payload."""
    info = {'name': 'Unknown', 'version': 'Unknown', 'kernel': 'Unknown'}

    if server_type == 'linux':
        out = execute_command(connection, 'uname -s', server_type)
        if out: info['name'] = out.strip()
        out = execute_command(connection, 'uname -r', server_type)
        if out: info['kernel'] = out.strip()
        out = execute_command(connection, 'cat /etc/os-release 2>/dev/null', server_type)
        if out:
            m = re.search(r'^PRETTY_NAME="?([^"\n]+)"?', out, re.MULTILINE)
            if m: info['version'] = m.group(1).strip()

    elif server_type == 'aix':
        out = execute_command(connection, 'uname -s', server_type)
        info['name'] = (out.strip() if out else 'AIX')
        out = execute_command(connection, 'oslevel -s 2>/dev/null', server_type)
        if out: info['version'] = f"AIX {out.strip()}"
        out = execute_command(connection, 'uname -r', server_type)
        if out: info['kernel'] = out.strip()

    elif server_type == 'windows':
        out = execute_command(
            connection,
            'powershell (Get-CimInstance Win32_OperatingSystem | '
            'Select-Object Caption,Version,BuildNumber | Format-List | Out-String).Trim()',
            server_type,
        )
        if out:
            cap = re.search(r'Caption\s*:\s*(.+)', out)
            ver = re.search(r'Version\s*:\s*(.+)', out)
            bld = re.search(r'BuildNumber\s*:\s*(.+)', out)
            if cap:
                info['name']    = cap.group(1).strip()
                info['version'] = cap.group(1).strip()
            if ver:
                info['kernel']  = ver.group(1).strip()
            if bld and info['version'] != 'Unknown':
                info['version'] = f"{info['version']} (build {bld.group(1).strip()})"

    return info


# ---------------------------------------------------------------------------
# External port connectivity - TCP test from the monitoring host
# ---------------------------------------------------------------------------
def check_external_ports(targets_csv: str) -> list:
    """Comma-separated 'host:port' list. Returns one row per target."""
    if not targets_csv:
        return []

    results = []
    for target in (t.strip() for t in targets_csv.split(',') if t.strip()):
        if ':' not in target:
            results.append({'target': target, 'status': 'error',
                            'error': 'Expected host:port format'})
            continue
        host, _, port_s = target.partition(':')
        try:
            port = int(port_s)
        except ValueError:
            results.append({'target': target, 'status': 'error',
                            'error': f'Invalid port: {port_s}'})
            continue
        try:
            with socket.create_connection((host.strip(), port), timeout=5):
                results.append({'target': target, 'status': 'ok', 'error': None})
        except Exception as exc:
            results.append({'target': target, 'status': 'failed', 'error': str(exc)})
    return results


# ---------------------------------------------------------------------------
# Windows services (Get-Service)
# ---------------------------------------------------------------------------
def check_windows_services(connection, services_csv: str) -> list:
    """For each comma-separated service name, return its run-state.

    Row shape matches check_processes() so it can populate either
    result['services'] or result['processes'] for template compatibility.
    """
    if not services_csv:
        return []

    results = []
    for raw_name in (s.strip() for s in services_csv.split(',') if s.strip()):
        try:
            safe_name = _sanitise_process_name(raw_name)
        except ValueError as exc:
            results.append({'name': raw_name, 'status': 'error',
                            'pid': None, 'count': 0, 'error': str(exc)})
            continue

        cmd = (
            f'powershell $s = Get-Service -Name "{safe_name}" -ErrorAction SilentlyContinue; '
            f'if ($s) {{ $s.Status.ToString() }} else {{ "NotFound" }}'
        )
        out = execute_command(connection, cmd, 'windows')

        if not out:
            results.append({'name': safe_name, 'status': 'error',
                            'pid': None, 'count': 0})
            continue

        out = out.strip()
        if out == 'NotFound':
            results.append({'name': safe_name, 'status': 'not_running',
                            'pid': None, 'count': 0,
                            'error': 'Service not found'})
        elif out.lower() == 'running':
            results.append({'name': safe_name, 'status': 'running',
                            'pid': None, 'count': 1})
        else:
            results.append({'name': safe_name, 'status': 'not_running',
                            'pid': None, 'count': 0,
                            'error': f'Service state: {out}'})
    return results


# ---------------------------------------------------------------------------
# Windows event log - Critical (Level 1) and Error (Level 2) in last hour
# ---------------------------------------------------------------------------
def get_windows_critical_events(connection,
                                lookback_hours: int = 1,
                                max_rows: int = 10) -> list:
    """Recent Critical/Error events from System and Application logs."""
    cmd = (
        'powershell '
        '$ErrorActionPreference="SilentlyContinue"; '
        f'$since=(Get-Date).AddHours(-{int(lookback_hours)}); '
        '$ev = Get-WinEvent -FilterHashtable @{LogName="System","Application";'
        f' Level=1,2; StartTime=$since}} -MaxEvents {int(max_rows)}; '
        'if ($ev) { foreach ($e in $ev) { '
        '$lvl = if ($e.Level -eq 1) {"Critical"} else {"Error"}; '
        '$msg = ($e.Message -split "`n")[0].Trim(); '
        '"$($e.TimeCreated.ToString(''yyyy-MM-dd HH:mm:ss''))|$($e.LogName)|$lvl|$($e.ProviderName)|$msg" '
        '} }'
    )
    out = execute_command(connection, cmd, 'windows')
    if not out:
        return []

    events = []
    for line in out.splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split('|', 4)
        if len(parts) < 5:
            continue
        events.append({
            'time':    parts[0],
            'log':     parts[1],
            'level':   parts[2],
            'source':  parts[3],
            'message': parts[4][:200],
        })
    return events
