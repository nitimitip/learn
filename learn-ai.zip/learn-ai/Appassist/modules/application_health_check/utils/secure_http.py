"""HTTP transport which validates and pins each connection's destination IP.

TLS SNI and hostname verification still use the original hostname. Automatic
redirects and environment proxies are disabled by the caller.
"""
import ipaddress
import os
import socket
from urllib.parse import urlparse

import requests
from requests.adapters import HTTPAdapter
from urllib3 import PoolManager
from urllib3.connection import HTTPConnection, HTTPSConnection
from urllib3.connectionpool import HTTPConnectionPool, HTTPSConnectionPool
from urllib3.util.connection import create_connection


def approved_addresses(host, port):
    allowed_hosts = {h.strip().lower().rstrip('.') for h in os.environ.get('HEALTH_ALLOWED_HOSTS', '').split(',') if h.strip()}
    networks = [ipaddress.ip_network(n.strip()) for n in os.environ.get('HEALTH_ALLOWED_NETWORKS', '').split(',') if n.strip()]
    rows = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    addresses = list(dict.fromkeys(row[4][0] for row in rows))
    if not addresses:
        raise ValueError('Target has no resolved addresses.')
    for address in addresses:
        ip = ipaddress.ip_address(address)
        # Metadata, local host and multicast targets are never monitoring targets.
        if ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_unspecified or ip.is_reserved:
            raise ValueError('Target resolves to a prohibited address.')
        permitted_network = any(ip in network for network in networks)
        if not ip.is_global and not permitted_network:
            raise ValueError('Private target requires HEALTH_ALLOWED_NETWORKS.')
        if allowed_hosts and host.lower().rstrip('.') not in allowed_hosts:
            raise ValueError('Host is outside HEALTH_ALLOWED_HOSTS.')
    return addresses


def validate_url(url):
    parsed = urlparse(url)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname:
        raise ValueError('Use an HTTP or HTTPS URL with a hostname.')
    if parsed.username or parsed.password:
        raise ValueError('Credentials must not be embedded in URLs.')
    port = parsed.port or (443 if parsed.scheme == 'https' else 80)
    if not 1 <= port <= 65535:
        raise ValueError('Invalid target port.')
    approved_addresses(parsed.hostname, port)
    return parsed


class _PinnedConnection:
    def _new_conn(self):
        last_error = None
        for address in approved_addresses(self.host, self.port):
            try:
                return create_connection((address, self.port), timeout=self.timeout,
                                         source_address=self.source_address,
                                         socket_options=self.socket_options)
            except OSError as exc:
                last_error = exc
        raise last_error or OSError('Unable to connect to approved target.')


class _HTTP(_PinnedConnection, HTTPConnection):
    pass


class _HTTPS(_PinnedConnection, HTTPSConnection):
    pass


class _HTTPPool(HTTPConnectionPool):
    ConnectionCls = _HTTP


class _HTTPSPool(HTTPSConnectionPool):
    ConnectionCls = _HTTPS


class _Adapter(HTTPAdapter):
    def init_poolmanager(self, connections, maxsize, block=False, **kwargs):
        self.poolmanager = PoolManager(num_pools=connections, maxsize=maxsize, block=block, **kwargs)
        self.poolmanager.pool_classes_by_scheme = {'http': _HTTPPool, 'https': _HTTPSPool}


def new_session():
    session = requests.Session()
    session.trust_env = False
    session.mount('http://', _Adapter())
    session.mount('https://', _Adapter())
    return session
