"""
url_check.py - URL / HTTP(S) endpoint health probe.

Covers the HTTP request, SSL-certificate inspection (incl. expiry tracking for
self-signed corporate certs) and the optional NTLM retry path for AD-protected
endpoints. SSL verification mode comes from common._CA_BUNDLE.
"""

import logging
import json
import os
import socket
import ssl
import time
from datetime import datetime
from urllib.parse import urlparse

import requests

# Optional: NTLM auth for AD-protected URLs (pip install requests-ntlm).
try:
    from requests_ntlm import HttpNtlmAuth
    _HAS_NTLM = True
except ImportError:
    _HAS_NTLM = False

from .common import _CA_BUNDLE
from .secure_http import validate_url, approved_addresses, new_session


def _read_body(response, started, timeout):
    """Cap body size and check elapsed budget between streamed chunks."""
    limit = max(1024, int(os.environ.get('HEALTH_HTTP_MAX_BODY_BYTES', '1048576')))
    chunks, size = [], 0
    for chunk in response.iter_content(chunk_size=16384):
        if time.monotonic() - started > timeout:
            raise requests.exceptions.Timeout('HTTP response exceeded its time budget.')
        size += len(chunk)
        if size > limit:
            raise ValueError('Response exceeds the health probe size limit; use a lightweight endpoint.')
        chunks.append(chunk)
    return b''.join(chunks)

# ---------------------------------------------------------------------------
# SSL certificate inspection
# ---------------------------------------------------------------------------

def get_ssl_certificate_info(url: str) -> dict:
    """Return SSL certificate metadata for an HTTPS URL.

    When DISABLE_SSL_VERIFY=1 is set the cert chain is not validated, but
    the cert itself is still fetched so we can extract its expiry date.
    This is essential for self-signed corporate certs - we still want to
    know when they expire even if we can't verify the chain.
    """
    try:
        parsed   = validate_url(url)
        hostname = parsed.hostname
        port     = parsed.port or 443

        if not hostname:
            return {'valid': False, 'error': 'Could not extract hostname from URL.', 'status': 'error'}

        # If SSL verification is disabled globally, relax this context too
        # so we can still read the cert metadata (for expiry tracking).
        if _CA_BUNDLE is False:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode    = ssl.CERT_NONE
        else:
            context = ssl.create_default_context()
            # If a custom CA bundle is configured, use it for the metadata
            # check too so we stay consistent with the HTTP check.
            if isinstance(_CA_BUNDLE, str):
                try:
                    context.load_verify_locations(_CA_BUNDLE)
                except Exception:
                    pass   # fall back to default CAs

        address = approved_addresses(hostname, port)[0]
        with socket.create_connection((address, port), timeout=10) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()

        # When verify_mode=CERT_NONE the dict may be empty - fetch the
        # raw DER and parse it manually for the expiry info.
        if not cert and _CA_BUNDLE is False:
            with socket.create_connection((address, port), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    der = ssock.getpeercert(binary_form=True)
            from cryptography import x509
            from cryptography.hazmat.backends import default_backend
            x = x509.load_der_x509_certificate(der, default_backend())
            expiry_date = x.not_valid_after
            cn_attr = x.subject.get_attributes_for_oid(x509.NameOID.COMMON_NAME)
            issuer_attr = x.issuer.get_attributes_for_oid(x509.NameOID.ORGANIZATION_NAME) or \
                          x.issuer.get_attributes_for_oid(x509.NameOID.COMMON_NAME)
            subject_cn = cn_attr[0].value if cn_attr else 'Unknown'
            issuer_org = issuer_attr[0].value if issuer_attr else 'Unknown'
        else:
            subject    = dict(x[0] for x in cert['subject'])
            issuer     = dict(x[0] for x in cert['issuer'])
            expiry_date = datetime.strptime(cert['notAfter'], '%b %d %H:%M:%S %Y %Z')
            subject_cn = subject.get('commonName', 'Unknown')
            issuer_org = issuer.get('organizationName', issuer.get('commonName', 'Unknown'))

        days_until_expiry = (expiry_date - datetime.utcnow()).days

        cert_status = 'valid'
        reason      = None
        if days_until_expiry <= 10:
            cert_status = 'critical'
            reason = f"SSL certificate expires in {days_until_expiry} days."
        elif days_until_expiry <= 30:
            cert_status = 'warning'
            reason = f"SSL certificate expires in {days_until_expiry} days."

        return {
            'valid':              True,
            'hostname':           hostname,
            'port':               port,
            'subject_cn':         subject_cn,
            'issuer':             issuer_org,
            'expiry_date':        expiry_date.isoformat(),
            'days_until_expiry':  days_until_expiry,
            'status':             cert_status,
            'reason':             reason,
        }
    except Exception as exc:
        return {'valid': False, 'error': str(exc), 'status': 'error'}


# ---------------------------------------------------------------------------
# URL health check
# ---------------------------------------------------------------------------

def check_url_health(url_monitor) -> dict:
    """Check health of a URL endpoint.

    Behaviour:
    1. Make an anonymous GET request first.
    2. If the server returns 401 with an NTLM challenge AND the env vars
       URL_NTLM_USER + URL_NTLM_PASS are set, retry the request with
       NTLM auth.
    3. If the URL needs NTLM but credentials aren't configured, surface
       a clear diagnostic message instead of a generic "HTTP 401" error.

    Resource management:
    * All HTTP connections are explicitly closed in the `finally` block
      regardless of outcome. This is important on a long-running monitor
      because requests' connection-pool will otherwise hold sockets open
      against every target indefinitely.

    Configuration:
        URL_NTLM_USER  Service account username, in DOMAIN\\user form
        URL_NTLM_PASS  Service account password
        requests-ntlm  Must be installed (pip install requests-ntlm)

    SSL verification uses the corporate CA bundle for HTTPS endpoints.
    """
    start_time = time.monotonic()
    response   = None
    session = None

    try:
        # ---- Stage 1: anonymous request --------------------------------
        validate_url(url_monitor.url)
        session = new_session()
        response = session.get(
            url_monitor.url,
            timeout=(min(10, max(1, url_monitor.timeout_seconds)), max(1, min(60, url_monitor.timeout_seconds))),
            verify=_CA_BUNDLE,
            allow_redirects=False,
            stream=True,
        )

        # ---- Stage 2: NTLM retry if challenged -------------------------
        if response.status_code == 401:
            new_response = _maybe_retry_with_ntlm(url_monitor, response, start_time, session)
            # If a retry was actually performed, close the original and
            # adopt the new one for the rest of the function.
            if new_response is not response:
                try:
                    response.close()
                except Exception:
                    pass
                response = new_response

        body = _read_body(response, start_time, max(1, min(120, url_monitor.timeout_seconds)))
        rules = json.loads(os.environ.get('HEALTH_URL_RULES_JSON', '{}'))
        rule = rules.get(url_monitor.url, {})
        response_time_ms = (time.monotonic() - start_time) * 1000
        status           = 'success'
        warning_reason   = None
        error_message    = None

        if response.status_code == url_monitor.expected_status_code:
            expected_text = rule.get('contains')
            if expected_text and expected_text.encode('utf-8') not in body:
                status = 'failed'
                error_message = 'Expected application response content was not found.'
            elif response_time_ms > float(rule.get('warning_latency_ms', 5000)):
                status         = 'warning'
                warning_reason = f"Slow response: {response_time_ms:.0f} ms"
        elif response.status_code == 401:
            # Still 401 after our retry attempt - surface why
            status        = 'failed'
            error_message = _describe_401(response)
        else:
            status        = 'failed'
            error_message = (
                f"HTTP {response.status_code} (expected {url_monitor.expected_status_code})."
            )

        result = {
            'name':                 url_monitor.name,
            'url':                  url_monitor.url,
            'status':               status,
            'status_code':          response.status_code,
            'response_time_ms':     response_time_ms,
            'expected_status_code': url_monitor.expected_status_code,
            'warning_reason':       warning_reason,
            'error_message':        error_message,
        }

        # SSL certificate check for HTTPS endpoints
        if urlparse(url_monitor.url).scheme == 'https':
            cert_info = get_ssl_certificate_info(url_monitor.url)
            result['ssl_certificate'] = cert_info

            if cert_info.get('status') == 'critical':
                result['status']        = 'failed'
                result['error_message'] = cert_info.get('reason', 'SSL certificate critical issue.')
            elif cert_info.get('status') == 'warning' and result['status'] == 'success':
                result['status']        = 'warning'
                result['warning_reason'] = cert_info.get('reason', 'SSL certificate warning.')
            elif cert_info.get('status') == 'error' and result['status'] == 'success':
                result['status'] = 'warning'
                result['warning_reason'] = 'Certificate metadata could not be verified.'
            if _CA_BUNDLE is False and result['status'] == 'success':
                result['status'] = 'warning'
                result['warning_reason'] = 'TLS certificate verification is disabled.'

        return result

    except requests.exceptions.SSLError as exc:
        return {
            'name':             url_monitor.name,
            'url':              url_monitor.url,
            'status':           'failed',
            'error_message':    (
                f"SSL error: {exc}. "
                f"For on-prem self-signed certs set DISABLE_SSL_VERIFY=1, "
                f"or point CORPORATE_CA_BUNDLE at a PEM file."
            ),
            'response_time_ms': (time.monotonic() - start_time) * 1000,
        }
    except requests.exceptions.Timeout:
        return {
            'name':             url_monitor.name,
            'url':              url_monitor.url,
            'status':           'failed',
            'error_message':    'Request timed out.',
            'response_time_ms': (time.monotonic() - start_time) * 1000,
        }
    except requests.exceptions.ConnectionError as exc:
        return {
            'name':             url_monitor.name,
            'url':              url_monitor.url,
            'status':           'failed',
            'error_message':    f"Connection error: {exc}",
            'response_time_ms': (time.monotonic() - start_time) * 1000,
        }
    except Exception as exc:
        logging.exception(f"Unexpected error checking URL '{url_monitor.url}'.")
        return {
            'name':             url_monitor.name,
            'url':              url_monitor.url,
            'status':           'failed',
            'error_message':    f"{type(exc).__name__}: {exc}" if str(exc) else type(exc).__name__,
            'response_time_ms': (time.monotonic() - start_time) * 1000,
        }
    finally:
        # Release the socket back to the pool - important on a long-
        # running monitor where many URLs are polled in sequence.
        if response is not None:
            try:
                response.close()
            except Exception:
                pass
        if session is not None:
            session.close()


# ---------------------------------------------------------------------------
# NTLM helpers - single-service-account model
# ---------------------------------------------------------------------------

def _ntlm_credentials_configured() -> bool:
    """True iff URL_NTLM_USER and URL_NTLM_PASS are both set."""
    return bool(os.environ.get('URL_NTLM_USER') and os.environ.get('URL_NTLM_PASS'))


def _server_offers_ntlm(response) -> bool:
    """Inspect WWW-Authenticate header to confirm the server wants NTLM."""
    header = (response.headers.get('WWW-Authenticate') or '').upper()
    return 'NTLM' in header


def _maybe_retry_with_ntlm(url_monitor, original_response, start_time, session):
    """Retry the GET with NTLM auth if conditions are right.

    Returns either the new response (success or another 401), or the
    original 401 response if NTLM retry isn't applicable.

    Conditions for retry:
      * Server's WWW-Authenticate header advertises NTLM
      * requests-ntlm is installed
      * URL_NTLM_USER and URL_NTLM_PASS env vars are set
    Otherwise the original 401 is returned unchanged so the caller can
    surface a clear diagnostic via _describe_401().
    """
    if not _server_offers_ntlm(original_response):
        return original_response   # Not NTLM - could be Basic, Bearer, etc.

    parsed = urlparse(url_monitor.url)
    auth_hosts = {h.strip().lower() for h in os.environ.get('HEALTH_NTLM_ALLOWED_HOSTS', '').split(',') if h.strip()}
    if parsed.scheme != 'https' or parsed.hostname.lower() not in auth_hosts or _CA_BUNDLE is False:
        logging.warning('NTLM requires verified HTTPS and an explicitly approved target.')
        return original_response

    if not _HAS_NTLM:
        logging.warning(
            "URL '%s' requires NTLM but the requests-ntlm library is not "
            "installed. Run: pip install requests-ntlm",
            url_monitor.url,
        )
        return original_response

    if not _ntlm_credentials_configured():
        logging.warning(
            "URL '%s' requires NTLM but URL_NTLM_USER / URL_NTLM_PASS env "
            "vars are not configured.",
            url_monitor.url,
        )
        return original_response

    # All good - retry with NTLM
    try:
        ntlm_user = os.environ['URL_NTLM_USER']
        ntlm_pass = os.environ['URL_NTLM_PASS']
        logging.info(
            "Retrying URL '%s' with NTLM auth (user=%s).",
            url_monitor.url, ntlm_user,
        )
        return session.get(
            url_monitor.url,
            timeout=(min(10, max(1, url_monitor.timeout_seconds)), max(1, min(60, url_monitor.timeout_seconds))),
            verify=_CA_BUNDLE,
            auth=HttpNtlmAuth(ntlm_user, ntlm_pass),
            allow_redirects=False,
            stream=True,
        )
    except Exception as exc:
        logging.warning(
            "NTLM retry for '%s' failed: %s. Returning original 401.",
            url_monitor.url, exc,
        )
        return original_response


def _describe_401(response) -> str:
    """Build a clear diagnostic for a 401 response.

    Distinguishes:
      * Server requires NTLM, retry-with-NTLM library missing
      * Server requires NTLM, credentials not configured
      * Server requires NTLM, credentials provided but wrong
      * Server requires Basic / Bearer / something else
      * Server returned 401 with no auth challenge at all
    """
    auth_header = (response.headers.get('WWW-Authenticate') or '').strip()
    auth_upper  = auth_header.upper()

    if 'NTLM' in auth_upper:
        if not _HAS_NTLM:
            return (
                "HTTP 401 Unauthorized - site requires NTLM auth but the "
                "requests-ntlm library is not installed on the monitoring "
                "host. Run: pip install requests-ntlm"
            )
        if not _ntlm_credentials_configured():
            return (
                "HTTP 401 Unauthorized - site requires NTLM auth but "
                "URL_NTLM_USER / URL_NTLM_PASS env vars are not configured."
            )
        return (
            "HTTP 401 Unauthorized - NTLM auth attempted with the configured "
            "service account but rejected by the server. Check the account "
            "credentials and that it has access to this URL."
        )

    if 'NEGOTIATE' in auth_upper:
        return (
            "HTTP 401 Unauthorized - site requires Negotiate (Kerberos) auth "
            "which is not currently supported. Configure the IIS site to "
            "accept NTLM as well."
        )

    if 'BASIC' in auth_upper:
        return (
            "HTTP 401 Unauthorized - site requires Basic auth which is not "
            "configured for URL monitoring."
        )

    if 'BEARER' in auth_upper:
        return (
            "HTTP 401 Unauthorized - site requires Bearer-token auth which "
            "is not configured for URL monitoring."
        )

    if not auth_header:
        return "HTTP 401 Unauthorized - no auth challenge provided by the server."

    return f"HTTP 401 Unauthorized - server requires auth scheme: {auth_header}"
