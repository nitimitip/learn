"""
utils/ - Health-check utilities package.

This package replaces the former single 2,800-line utils.py. It is split into
cohesive probes plus shared helpers and reporting, but the public surface is
unchanged: everything the rest of the module imported from `.utils` is
re-exported here, so `from .utils import check_url_health` (etc.) keeps working.

  common.py          shared helpers (is_safe_url, _esc/_fmt_dt, SSL bundle)
  url_check.py       URL / HTTP(S) + SSL + NTLM probe
  server_check.py    server probe + SSH/WinRM transport + metric collectors
  database_check.py  Oracle / SQL Server probes
  reporting.py       health-report email + chart hook
"""

from .common import is_safe_url
from .url_check import get_ssl_certificate_info, check_url_health
from .server_check import (
    check_server_health,
    establish_ssh_connection,
    establish_windows_connection,
    close_connection,
    execute_command,
    execute_command_ex,
    get_uptime,
    get_cpu_usage,
    get_memory_usage,
    get_disk_usage,
    get_load_average,
    get_network_connections,
    check_processes,
    determine_overall_status,
    get_os_info,
    get_os_info_struct,
    check_external_ports,
    check_windows_services,
    get_windows_critical_events,
)
from .database_check import (
    check_database_health,
    check_oracle_health,
    check_mssql_health,
)
from .reporting import send_health_report_email, generate_health_chart

__all__ = [
    "is_safe_url",
    "get_ssl_certificate_info",
    "check_url_health",
    "check_server_health",
    "establish_ssh_connection",
    "establish_windows_connection",
    "close_connection",
    "execute_command",
    "execute_command_ex",
    "get_uptime",
    "get_cpu_usage",
    "get_memory_usage",
    "get_disk_usage",
    "get_load_average",
    "get_network_connections",
    "check_processes",
    "determine_overall_status",
    "get_os_info",
    "get_os_info_struct",
    "check_external_ports",
    "check_windows_services",
    "get_windows_critical_events",
    "check_database_health",
    "check_oracle_health",
    "check_mssql_health",
    "send_health_report_email",
    "generate_health_chart",
]
