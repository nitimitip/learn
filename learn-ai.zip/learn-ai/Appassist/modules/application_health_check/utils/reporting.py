"""
reporting.py - Health-report email composition + delivery, and chart hook.

Builds the NPG-themed HTML report email, queues durable notifications and exposes the
generate_health_chart hook used by the web layer. HTML-escaping and datetime
formatting come from common.
"""

import logging
import os
import smtplib
import threading
import time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from email_theme import hero_rows, footer_rows

from ..models import EmailNotificationConfig
from .common import _esc, _fmt_dt

_SMTP_SERVER: str = os.environ.get('SMTP_SERVER', 'mail1.northernpowergrid.com')
_SMTP_PORT:   int = int(os.environ.get('SMTP_PORT',   '25'))
_EMAIL_FROM:  str = os.environ.get('EMAIL_FROM', 'NPgAppAssist@northernpowergrid.com')
# ---------------------------------------------------------------------------
# Email
# ---------------------------------------------------------------------------

def send_health_report_email(report, execution, db_session):
    """Compatibility entry point: enqueue; the caller owns the transaction.

    SMTP is performed by notifications.deliver_pending_notifications after
    commit. This also prevents direct callers from bypassing durable delivery.
    """
    from ..notifications import enqueue_health_email
    return enqueue_health_email(report, execution, db_session)


# ---------------------------------------------------------------------------
# Email rendering helpers - kept private (prefixed with `_`)
# ---------------------------------------------------------------------------

# NPG palette - imported from the shared email theme so a colour is
# defined ONCE for the whole application (email_theme.py). The private
# aliases keep this module's f-strings unchanged.
from email_theme import (                             # noqa: E402
    NPG_RED as _NPG_RED, NPG_RED_DARK as _NPG_RED_DARK, NPG_DARK as _NPG_DARK,
    NPG_LIGHT as _NPG_LIGHT, NPG_BORDER as _NPG_BORDER, NPG_TEXT as _NPG_TEXT,
    NPG_TEXT_MUTED as _NPG_TEXT_MUTED, CHIP_BG as _CHIP_BG,
    FONT as _FONT,
)

# Masthead and footer come from the shared NPG theme (email_theme.py): a flat
# maroon banner closed by a graphite rule, and a graphite footer band. Flat, not
# a gradient - the Word engine behind desktop Outlook cannot render one.

# Status -> palette mapping. Three keys: bg (left-border + accent), tint
# (soft fill for the detail box), pill_bg / pill_fg (status pill colours).
_STATUS_PALETTE = {
    'success': {
        'border': '#16A34A', 'tint': '#F0FDF4', 'tint_border': '#BBF7D0',
        'pill_bg': '#DCFCE7', 'pill_fg': '#15803D',
        'detail_fg': '#166534',
        'label': 'HEALTHY',
    },
    'healthy': {  # alias used by overall_status
        'border': '#16A34A', 'tint': '#F0FDF4', 'tint_border': '#BBF7D0',
        'pill_bg': '#DCFCE7', 'pill_fg': '#15803D',
        'detail_fg': '#166534',
        'label': 'HEALTHY',
    },
    'warning': {
        'border': '#F59E0B', 'tint': '#FFFBEB', 'tint_border': '#FDE68A',
        'pill_bg': '#FEF3C7', 'pill_fg': '#92400E',
        'detail_fg': '#92400E',
        'label': 'WARNING',
    },
    'failed': {
        'border': _NPG_RED,  'tint': '#FEF2F2', 'tint_border': '#FECACA',
        'pill_bg': '#FEE2E2', 'pill_fg': '#991B1B',
        'detail_fg': '#991B1B',
        'label': 'FAILED',
    },
}


def _build_html_email(report, execution) -> str:
    """Top-level email builder. Returns a complete HTML document.

    Outlook compatibility notes
    ---------------------------
    Outlook for Windows uses Word's HTML rendering engine, which:
      * Ignores most modern CSS (flexbox, grid, rgba, text-transform,
        letter-spacing, opacity, border-radius on most elements).
      * Strips <style> blocks in many configurations.
      * Mis-renders margins on <div> blocks (collapses or doubles them).
      * Ignores `background-image: linear-gradient(...)`.

    The rules followed here:
      1. Layout is 100% nested <table>s - no <div>s used for structure.
      2. Status badges are tiny <table>s, not <span style="display:inline-block">.
      3. The status accent "bar" is a real <td> cell of fixed width, not
         a CSS border-left on the wrapper table.
      4. Text-transform is applied in Python (PRE-UPPERCASED labels).
      5. Solid background color - no gradients, no rgba alphas. Where a
         translucent look was desired (e.g. the header chips), pre-blended
         hex values approximate the original on the navy base.
      6. mso-line-height-rule: exactly + explicit pixel line-heights so
         Outlook respects the leading.
      7. Fixed-width 600px container - desktop Outlook is not responsive
         and a 680px container blows out 96 DPI mailbox panes.
      8. Web-safe font stack - Arial first; Segoe UI is preferred when
         present (most Windows desktops have it).
    """
    overall   = (execution.overall_status or 'healthy').lower()
    palette   = _STATUS_PALETTE.get(overall, _STATUS_PALETTE['healthy'])

    # Counts for the stat strip
    all_results = (
        list(execution.url_results or []) +
        list(execution.server_results or []) +
        list(execution.database_results or [])
    )
    healthy_count = sum(1 for r in all_results if r.get('status') == 'success')
    warning_count = sum(1 for r in all_results if r.get('status') == 'warning')
    failed_count  = sum(1 for r in all_results if r.get('status') == 'failed')

    # Alert ribbon copy
    app_name_esc = _esc(report.application_name)
    when_str     = _fmt_dt(execution.executed_at)
    if overall == 'failed':
        ribbon_title = 'Critical issues detected &mdash; immediate attention required'
        problem_areas = _summarise_problems(execution)
        ribbon_body  = (
            f"<strong>{app_name_esc}</strong> reports "
            f"<strong>CRITICAL</strong> status as of {when_str}. "
            f"Problem areas: {problem_areas or 'see component breakdown below'}."
        )
    elif overall == 'warning':
        ribbon_title = 'Some components have warnings &mdash; please review'
        problem_areas = _summarise_problems(execution)
        ribbon_body  = (
            f"<strong>{app_name_esc}</strong> reports "
            f"<strong>WARNING</strong> status as of {when_str}. "
            f"Issues: {problem_areas or 'see component breakdown below'}."
        )
    else:
        ribbon_title = 'All systems healthy &mdash; no action required'
        ribbon_body  = (
            f"All monitored components for "
            f"<strong>{app_name_esc}</strong> are healthy as of {when_str}."
        )

    sections_html  = _render_section('URL MONITORING',      execution.url_results,      'name')
    sections_html += _render_section('SERVER MONITORING',   execution.server_results,   'hostname')
    sections_html += _render_section('DATABASE MONITORING', execution.database_results, 'database_name')

    if not sections_html:
        sections_html = (
            f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
            f'<tr><td align="center" style="padding:24px 0;font-family:{_FONT};'
            f'font-size:14px;color:{_NPG_TEXT_MUTED};mso-line-height-rule:exactly;line-height:18px;">'
            f'No monitored components for this report.'
            f'</td></tr></table>'
        )

    generated_at = when_str

    # Pre-blended approximations of rgba(255,255,255,0.18) over _NPG_DARK
    # (#1D293D) and over _NPG_RED (#AB1236) so chips appear "lifted" in
    # Outlook, which ignores rgba(). Computed once here:
    #   blended = round(base + (255 - base) * 0.18) for each channel.
    _CHIP_TEXT             = '#FFFFFF'

    # Outlook-compatible status badge (pre-uppercased label).
    def _status_badge(bg: str, fg: str, label: str) -> str:
        return (
            f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
            f'style="display:inline-table;">'
            f'<tr><td bgcolor="{bg}" style="background-color:{bg};padding:5px 12px;'
            f'font-family:{_FONT};font-size:11px;font-weight:bold;color:{fg};'
            f'mso-line-height-rule:exactly;line-height:14px;letter-spacing:1px;'
            f'border-collapse:separate;border-spacing:0;border-radius:20px;">{label}</td></tr>'
            f'</table>'
        )

    badge_status = _status_badge(palette['pill_bg'], palette['pill_fg'], palette['label'])
    badge_score  = _status_badge(_CHIP_BG, _CHIP_TEXT,
                                  f"SCORE {execution.overall_score:.1f}%")
    badge_when   = _status_badge(_CHIP_BG, _CHIP_TEXT,
                                  generated_at.upper())

    hero = hero_rows('NPG APP ASSIST &middot; APPLICATION HEALTH REPORT',
                     app_name_esc, [badge_status, badge_score, badge_when])
    footer = footer_rows('Application Health Check')

    # ---- Document --------------------------------------------------------
    # <style> is included as progressive enhancement for clients that DO
    # respect it (Gmail web, Apple Mail). Outlook will strip it; every
    # critical style is also inlined.
    return f"""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>NPG Health Check &mdash; {app_name_esc}</title>
  <!--[if mso]>
  <xml>
    <o:OfficeDocumentSettings>
      <o:PixelsPerInch>96</o:PixelsPerInch>
      <o:AllowPNG/>
    </o:OfficeDocumentSettings>
  </xml>
  <style type="text/css">
    table {{border-collapse:collapse;}}
    td   {{mso-line-height-rule:exactly;}}
  </style>
  <![endif]-->
  <style type="text/css">
    body, table, td {{ -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }}
    table {{ border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }}
    img   {{ -ms-interpolation-mode:bicubic; border:0; outline:none; text-decoration:none; }}
    a     {{ color:{_NPG_RED}; text-decoration:none; }}
    @media only screen and (max-width:620px) {{
      .container {{ width:100% !important; }}
      .px-32     {{ padding-left:18px !important; padding-right:18px !important; }}
      .stat-cell {{ display:block !important; width:100% !important; padding:0 0 6px 0 !important; }}
    }}
  </style>
</head>
<body style="margin:0;padding:0;background-color:{_NPG_LIGHT};font-family:{_FONT};">
<!-- Preheader (hidden in the body, shown in inbox preview) -->
<div style="display:none;font-size:1px;color:{_NPG_LIGHT};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
NPG Health Check &mdash; {app_name_esc} &mdash; {palette['label']} ({execution.overall_score:.1f}%)
</div>

<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="{_NPG_LIGHT}" style="background-color:{_NPG_LIGHT};">
  <tr>
    <td align="center" style="padding:34px 16px 40px 16px;">

      <!--[if mso]>
      <table role="presentation" align="center" cellpadding="0" cellspacing="0" border="0" width="600">
      <tr><td>
      <![endif]-->

      <table role="presentation" class="container" cellpadding="0" cellspacing="0" border="0" width="600"
             style="width:600px;max-width:600px;background-color:#FFFFFF;border:1px solid {_NPG_BORDER};border-bottom-color:#C6D0DE;border-collapse:separate;border-spacing:0;border-radius:14px;">

        <!-- ========== Header (shared NPG theme: flat maroon masthead) ========== -->
        {hero}

        <!-- ========== Alert ribbon (border-left rendered as a cell) ========== -->
        <tr>
          <td class="px-32" style="padding:24px 32px;">
            <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"
                   bgcolor="{palette['tint']}"
                   style="background-color:{palette['tint']};border:1px solid {palette['tint_border']};border-collapse:separate;border-spacing:0;border-radius:10px;">
              <tr>
                <td style="padding:14px 16px;font-family:{_FONT};
                           color:{palette['detail_fg']};">
                  <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                    <tr>
                      <td style="font-size:13px;font-weight:bold;mso-line-height-rule:exactly;
                                 line-height:18px;padding-bottom:4px;color:{palette['detail_fg']};">
                        {ribbon_title}
                      </td>
                    </tr>
                    <tr>
                      <td style="font-size:13px;mso-line-height-rule:exactly;line-height:20px;
                                 color:{palette['detail_fg']};">
                        {ribbon_body}
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>

        <!-- ========== Stat strip (3 columns, mobile-collapsing) ========== -->
        <tr>
          <td class="px-32" style="padding:20px 32px;">
            <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
              <tr>
                <td class="stat-cell" width="33%" valign="top" style="padding-right:6px;">
                  {_stat_card('#F0FDF4', '#15803D', '#166534', healthy_count, 'HEALTHY')}
                </td>
                <td class="stat-cell" width="34%" valign="top" style="padding:0 3px;">
                  {_stat_card('#FFFBEB', '#B45309', '#92400E', warning_count, 'WARNING')}
                </td>
                <td class="stat-cell" width="33%" valign="top" style="padding-left:6px;">
                  {_stat_card('#FEF2F2', _NPG_RED, '#991B1B', failed_count, 'FAILED')}
                </td>
              </tr>
            </table>
          </td>
        </tr>

        <!-- ========== Component sections ========== -->
        <tr>
          <td class="px-32" style="padding:24px 32px;">
            {sections_html}
            <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"
                   style="border-top:1px solid {_NPG_LIGHT};margin-top:18px;">
              <tr>
                <td style="padding-top:14px;font-family:{_FONT};font-size:12px;
                           color:{_NPG_TEXT_MUTED};mso-line-height-rule:exactly;line-height:16px;">
                  <strong style="color:{_NPG_TEXT};">Execution duration:</strong>
                  {execution.execution_time_seconds:.2f}s
                </td>
              </tr>
            </table>
          </td>
        </tr>

        <!-- ========== Footer (shared NPG theme) ========== -->
        {footer}

      </table>

      <!--[if mso]>
      </td></tr>
      </table>
      <![endif]-->

    </td>
  </tr>
</table>
</body>
</html>"""


def _stat_card(bg: str, big_fg: str, label_fg: str, value: int, label: str,
               border: str = _NPG_BORDER) -> str:
    """One Healthy/Warning/Failed card in the stat strip - Outlook-safe."""
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
        f'width="100%" bgcolor="{bg}" style="background-color:{bg};'
        f'border:1px solid {border};border-collapse:separate;border-spacing:0;border-radius:10px;">'
        f'<tr><td align="center" style="padding:16px 12px;font-family:{_FONT};">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0">'
        f'<tr><td align="center" style="font-size:28px;font-weight:bold;color:{big_fg};'
        f'letter-spacing:-0.4px;mso-line-height-rule:exactly;line-height:32px;">{value}</td></tr>'
        f'<tr><td align="center" style="font-size:10px;font-weight:bold;color:{label_fg};'
        f'mso-line-height-rule:exactly;line-height:14px;letter-spacing:1px;padding-top:6px;">'
        f'{label}</td></tr>'
        f'</table>'
        f'</td></tr></table>'
    )


def _render_section(title: str, results: list, name_key: str) -> str:
    """Render one component section (URL / Server / Database) or '' if empty.

    Title is pre-uppercased by the caller. Outlook ignores text-transform.
    """
    if not results:
        return ''

    rows_html = ''
    for r in results:
        rows_html += _render_component_card(r, name_key)

    count_word = 'components' if len(results) != 1 else 'component'

    return f"""
            <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"
                   style="margin-bottom:18px;">
              <tr>
                <td style="border-bottom:1px solid {_NPG_DARK};padding-bottom:8px;">
                  <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                    <tr>
                      <td style="font-family:{_FONT};font-size:13px;font-weight:bold;
                                 color:{_NPG_DARK};mso-line-height-rule:exactly;line-height:16px;
                                 letter-spacing:1px;">{title}</td>
                      <td align="right" style="font-family:{_FONT};font-size:11px;
                                 font-weight:bold;color:{_NPG_TEXT_MUTED};
                                 mso-line-height-rule:exactly;line-height:14px;">
                        {len(results)} {count_word}
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
              <tr>
                <td style="padding-top:12px;">{rows_html}</td>
              </tr>
            </table>"""


def _render_component_card(r: dict, name_key: str) -> str:
    """Render one component (URL/server/database) as a card with a coloured
    left bar. The bar is a real <td> of fixed width so Outlook renders it
    reliably (CSS border-left on a wrapper table is unreliable there).
    """
    status   = (r.get('status') or 'success').lower()
    palette  = _STATUS_PALETTE.get(status, _STATUS_PALETTE['success'])

    name = r.get(name_key) or r.get('host') or r.get('hostname') or 'Unknown'
    name = _esc(str(name))

    subtitle = _build_subtitle(r)

    # The status badge (mini-table).
    badge_html = (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
        f'style="display:inline-table;">'
        f'<tr><td bgcolor="{palette["pill_bg"]}" '
        f'style="background-color:{palette["pill_bg"]};padding:3px 9px;'
        f'font-family:{_FONT};font-size:10px;font-weight:bold;'
        f'color:{palette["pill_fg"]};mso-line-height-rule:exactly;line-height:13px;'
        f'letter-spacing:1px;border-collapse:separate;border-spacing:0;border-radius:20px;">{palette["label"]}</td></tr>'
        f'</table>'
    )

    subtitle_row = ''
    if subtitle:
        subtitle_row = (
            f'<tr><td colspan="2" style="font-family:{_FONT};font-size:12px;'
            f'color:{_NPG_TEXT_MUTED};mso-line-height-rule:exactly;line-height:16px;'
            f'padding-top:4px;">{subtitle}</td></tr>'
        )

    # Detail box (error / warning) - Outlook-safe table with its own
    # background colour rather than CSS-only styling.
    detail_row = ''
    if r.get('error_message'):
        detail_row = (
            f'<tr><td colspan="2" style="padding-top:8px;">'
            f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
            f'bgcolor="{palette["tint"]}" '
            f'style="background-color:{palette["tint"]};border:1px solid {palette["tint_border"]};border-collapse:separate;border-spacing:0;border-radius:10px;">'
            f'<tr><td style="padding:8px 10px;font-family:{_FONT};font-size:12px;'
            f'color:{palette["detail_fg"]};mso-line-height-rule:exactly;line-height:18px;">'
            f'<strong>Error:</strong> {_esc(str(r["error_message"]))}'
            f'</td></tr></table></td></tr>'
        )
    elif r.get('warning_reason'):
        detail_row = (
            f'<tr><td colspan="2" style="padding-top:8px;">'
            f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
            f'bgcolor="{palette["tint"]}" '
            f'style="background-color:{palette["tint"]};border:1px solid {palette["tint_border"]};border-collapse:separate;border-spacing:0;border-radius:10px;">'
            f'<tr><td style="padding:8px 10px;font-family:{_FONT};font-size:12px;'
            f'color:{palette["detail_fg"]};mso-line-height-rule:exactly;line-height:18px;">'
            f'<strong>Warning:</strong> {_esc(str(r["warning_reason"]))}'
            f'</td></tr></table></td></tr>'
        )

    # Outer card: 4-px left bar cell + content cell.
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
        f'bgcolor="{palette["tint"]}" '
        f'style="background-color:{palette["tint"]};border:1px solid {palette["tint_border"]};border-collapse:separate;border-spacing:0;border-radius:10px;'
        f'margin-bottom:8px;">'
        f'<tr>'
        f'<td style="padding:12px 14px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr>'
        f'<td style="font-family:{_FONT};font-size:14px;font-weight:bold;'
        f'color:{_NPG_TEXT};mso-line-height-rule:exactly;line-height:18px;">{name}</td>'
        f'<td align="right">{badge_html}</td>'
        f'</tr>'
        f'{subtitle_row}'
        f'{detail_row}'
        f'</table>'
        f'</td>'
        f'</tr></table>'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr><td style="font-size:0;line-height:0;height:8px;">&nbsp;</td></tr>'
        f'</table>'
    )


def _build_subtitle(r: dict) -> str:
    """Build a one-line subtitle for a component card based on what fields exist."""
    parts: list[str] = []

    # URL: show URL + response time
    if r.get('url'):
        url_text = _esc(str(r['url']))
        if r.get('response_time_ms'):
            try:
                url_text += f" &middot; {int(float(r['response_time_ms']))}ms"
            except (TypeError, ValueError):
                pass
        parts.append(url_text)
        ssl = r.get('ssl_certificate') or {}
        if ssl.get('days_until_expiry') is not None:
            parts.append(f"SSL: {ssl['days_until_expiry']} day(s) left")
        return ' &middot; '.join(parts)

    # Server: type + connection + uptime if available
    if r.get('server_type'):
        parts.append(_esc(str(r['server_type']).title()))
    if r.get('connection_type'):
        parts.append(_esc(str(r['connection_type'])))
    if r.get('uptime'):
        parts.append(f"Uptime: {_esc(str(r['uptime']))}")
    if parts:
        return ' &middot; '.join(parts)

    # Database: type + size if available
    if r.get('database_type'):
        parts.append(_esc(str(r['database_type']).upper()))
    if r.get('database_size_gb'):
        parts.append(f"{r['database_size_gb']} GB")
    if r.get('host'):
        parts.append(f"on {_esc(str(r['host']))}")
    return ' &middot; '.join(parts)


def _summarise_problems(execution) -> str:
    """Build a short comma-separated list of problem areas for the alert ribbon."""
    parts: list[str] = []

    def _collect(results, name_key, label):
        warn = [str(r.get(name_key) or '?') for r in (results or []) if r.get('status') == 'warning']
        fail = [str(r.get(name_key) or '?') for r in (results or []) if r.get('status') == 'failed']
        if fail:
            parts.append(f"{label} failures ({_esc(', '.join(fail))})")
        if warn:
            parts.append(f"{label} warnings ({_esc(', '.join(warn))})")

    _collect(execution.url_results,      'name',          'URLs')
    _collect(execution.server_results,   'hostname',      'Servers')
    _collect(execution.database_results, 'database_name', 'Databases')
    return '; '.join(parts)
def generate_health_chart(towers, db_session):
    """Placeholder - implement chart generation here when required."""
    pass
