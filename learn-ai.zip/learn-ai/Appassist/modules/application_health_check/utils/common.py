"""
common.py - Shared, dependency-light helpers for the health-check probes.

Holds the pieces that more than one probe (or the web layer) needs, so the
url / server / database / reporting modules can import from here instead of
from each other:

  * SSL verification mode resolution (_resolve_ssl_verify / _CA_BUNDLE)
  * is_safe_url            - SSRF guard, also used by routes.py at save time
  * _sanitise_process_name - input validation for server process checks
  * _esc / _fmt_dt         - HTML-escape and datetime formatting for emails
"""

import ipaddress
import logging
import os
import re
import socket
from urllib.parse import urlparse

# ---------------------------------------------------------------------------
# SSL verification - three modes controlled by env vars
# ---------------------------------------------------------------------------
# 1. DISABLE_SSL_VERIFY=1       -> verify=False (skips cert validation entirely)
#                                  Use for on-prem self-signed certs when you
#                                  can't add the corporate CA to a trust store.
# 2. CORPORATE_CA_BUNDLE=/path  -> verify=<path to PEM file>
#                                  Use when you have the corporate root CA
#                                  exported as a PEM. Strict cryptographic
#                                  verification against that bundle.
# 3. Neither set                -> verify=True (certifi's default trust store)
#                                  Works for public CAs (Let's Encrypt, etc).
#
# Note: when DISABLE_SSL_VERIFY=1 is in effect, urllib3's InsecureRequestWarning
# is suppressed to keep the log readable. This is the SAME warning you'd get
# from `curl -k` and is expected on private networks with self-signed certs.
# ---------------------------------------------------------------------------
def _resolve_ssl_verify():
    """Return the value to pass as requests' verify= argument.

    Returns:
        False  -> if DISABLE_SSL_VERIFY=1
        str    -> path to corporate CA bundle if CORPORATE_CA_BUNDLE set
        True   -> default (certifi trust store)
    """
    if os.environ.get('DISABLE_SSL_VERIFY', '').strip() == '1':
        # Suppress the very noisy urllib3 InsecureRequestWarning that would
        # otherwise log on EVERY URL check.
        try:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        except Exception:
            pass
        return False
    bundle = os.environ.get('CORPORATE_CA_BUNDLE', '').strip()
    if bundle:
        return bundle
    return True


_CA_BUNDLE = _resolve_ssl_verify()
# ---------------------------------------------------------------------------
# SSRF guard - block RFC-1918, loopback, link-local targets
# ---------------------------------------------------------------------------

def is_safe_url(url: str) -> tuple[bool, str]:
    """Return (True, '') if the URL target is routable on the public/corporate
    internet, or (False, reason) if it resolves to a private/loopback address.

    Call this before saving a URLMonitor and before making any outbound
    request so that a compromised or malicious user cannot use the monitoring
    server as a pivot to reach internal services.
    """
    from .secure_http import validate_url
    try:
        validate_url(url)
        return True, ''
    except Exception as exc:
        return False, str(exc)


def _sanitise_process_name(name: str) -> str:
    """Validate a user-supplied process/service name for use in checks.

    Allows alphanumerics, spaces, hyphens, underscores, and dots. Anything
    else (shell metacharacters, quotes, slashes, ...) is REJECTED with a
    clear error instead of being silently stripped - stripping made the
    check look for a different string than the one configured, which
    produced permanent false "not running" alerts.
    """
    name = name.strip()
    if not name:
        raise ValueError('Process name is empty.')
    bad = sorted(set(re.findall(r'[^A-Za-z0-9 ._-]', name)))
    if bad:
        raise ValueError(
            f"Process name '{name}' contains unsupported character(s): "
            f"{', '.join(repr(c) for c in bad)}. Allowed: letters, digits, "
            f"spaces, dots, hyphens, underscores."
        )
    return name
def _esc(text: str) -> str:
    """Minimal HTML escape - keeps & < > " safe in the rendered email."""
    if text is None:
        return ''
    return (str(text)
            .replace('&',  '&amp;')
            .replace('<',  '&lt;')
            .replace('>',  '&gt;')
            .replace('"',  '&quot;'))


def _fmt_dt(dt) -> str:
    """Format a datetime for the header - fall back to str() if unparsable."""
    try:
        return dt.strftime('%d %b %Y - %H:%M')
    except Exception:
        return str(dt)
