"""
database_check.py -- Database (Oracle / SQL Server) health probe.

Holds the MSSQL ODBC driver auto-discovery, the short TCP pre-check timeout,
the check_database_health dispatcher and the Oracle / MSSQL specific probes.
Passwords are decrypted immediately before connecting and discarded after.
"""

import logging
import os
import socket
from datetime import datetime

import pyodbc

from crypto_utils import decrypt_data
# get_oracle_driver() prefers python-oracledb (auto thick/thin - thin mode
# needs no Oracle Client install, avoiding DPI-1047) with cx_Oracle fallback.
from oracle_client import get_oracle_driver

# ---------------------------------------------------------------------------
# MSSQL ODBC driver auto-discovery (override with MSSQL_ODBC_DRIVER env var)
# ---------------------------------------------------------------------------
def _detect_mssql_driver() -> str:
    explicit = os.environ.get('MSSQL_ODBC_DRIVER')
    if explicit:
        return explicit
    try:
        drivers = pyodbc.drivers()
    except Exception:
        return 'ODBC Driver 17 for SQL Server'
    for candidate in (
        'ODBC Driver 18 for SQL Server',
        'ODBC Driver 17 for SQL Server',
        'SQL Server Native Client 11.0',
        'SQL Server',
    ):
        if candidate in drivers:
            return candidate
    return 'ODBC Driver 17 for SQL Server'


_MSSQL_DRIVER: str = _detect_mssql_driver()

# How long (seconds) to wait for the initial TCP handshake to a monitored
# database before giving up. The Oracle drivers' call_timeout only applies
# AFTER a session is established, so without this a firewalled/unreachable
# Oracle host could block the sweep thread at the OS TCP timeout (often
# 30-120s+). A short socket pre-check before connect() bounds that wait.
_DB_TCP_CONNECT_TIMEOUT: int = int(os.environ.get('DB_TCP_CONNECT_TIMEOUT', '10'))


def _odbc_value(value):
    return '{' + str(value).replace('}', '}}') + '}'
# ---------------------------------------------------------------------------
# Database health check
# ---------------------------------------------------------------------------

def check_database_health(db_monitor) -> dict:
    """Dispatch to the appropriate DB-specific health check function."""
    try:
        result = {
            'host':          db_monitor.host,
            'database_type': db_monitor.database_type,
            'database_name': db_monitor.database_name,
            'status':        'success',
            'warning_reason': None,
            'error_message':  None,
        }

        db_type = (db_monitor.database_type or '').lower()
        if db_type == 'oracle':
            result.update(check_oracle_health(db_monitor))
        elif db_type in ('mssql', 'sqlserver'):
            result.update(check_mssql_health(db_monitor))
        else:
            raise ValueError(
                f"Unsupported DB type '{db_monitor.database_type}'. Only Oracle & MSSQL supported."
            )

        critical_conditions: list[str] = []
        warning_conditions:  list[str] = []

        # A probe-level failure (connection, authentication, decryption, or a
        # query that blew up part-way through collection) is recorded as the
        # FIRST critical condition rather than short-circuiting the grading.
        # Every other check that did return data is still evaluated and still
        # rendered, so one failed area (a Data Guard destination, say) no
        # longer blanks out tablespaces, backups and jobs on the report.
        if result.get('status') == 'failed' and result.get('error_message'):
            critical_conditions.append(str(result['error_message']))

        # Did the probe get far enough to report on anything? When a connect
        # fails outright there is nothing to grade, and "could not be verified"
        # warnings below would just be noise on top of the real error.
        probe_collected = any(
            key in result
            for key in ('version', 'tablespaces', 'backup_status',
                        'archive_log_status', 'failed_jobs_status',
                        'long_running_queries')
        )

        for ts in result.get('tablespaces', []):
            if ts.get('status') == 'critical':
                critical_conditions.append(f"Tablespace {ts['name']} at {ts['used_percent']}%")
            elif ts.get('status') == 'warning':
                warning_conditions.append(f"Tablespace {ts['name']} at {ts['used_percent']}%")

        long_q = result.get('long_running_queries', 0)
        if long_q > 5:
            critical_conditions.append(f"{long_q} long-running queries detected.")
        elif long_q > 1:
            warning_conditions.append(f"{long_q} long-running queries detected.")

        if result.get('backup_status') == 'failed':
            critical_conditions.append("Backup issues detected.")
        elif probe_collected and result.get('backup_status') not in ('success', 'ok'):
            warning_conditions.append('Backup status could not be verified.')

        for area in result.get('archivelog_summary', []):
            detail = 'Recovery area at %s%%' % area.get('USED_PERCENT', '?')
            if area.get('status') == 'critical':
                critical_conditions.append(detail)
            elif area.get('status') == 'warning':
                warning_conditions.append(detail)
        if result.get('archive_log_status') in ('warning', 'unknown'):
            warning_conditions.append('Archive/transaction log protection requires attention: ' + result['archive_log_status'])
        if result.get('failed_jobs_status') == 'unknown':
            warning_conditions.append('Database job status could not be verified.')
        for destination in result.get('dataguard_summary', []):
            if str(destination.get('status', '')).upper() in ('ERROR', 'DISABLED', 'BAD PARAM'):
                critical_conditions.append('Data Guard destination is not healthy.')
            if str(destination.get('gap_status', '')).upper() not in ('', 'NO GAP', 'N/A', 'NONE'):
                warning_conditions.append('Data Guard reports a redo gap.')
        if result.get('expired_accounts', 0):
            warning_conditions.append('%s database account password(s) expired.' % result['expired_accounts'])

        # Checks the probe could not collect (permission denied, view missing,
        # query error). They are named so the report says WHICH area is blind
        # rather than silently reporting the rest as healthy.
        missing_checks = result.get('missing_checks') or []
        if missing_checks:
            warning_conditions.append(
                'Could not collect: ' + ', '.join(missing_checks)
            )

        # Any database job whose latest run failed (the per-job latest-run
        # filtering happens in the DB-specific queries) is a warning so it
        # surfaces on the report and in the failure alert email.
        failed_jobs = result.get('failed_jobs') or []
        if failed_jobs:
            job_names = ', '.join(str(j.get('job_name') or '?') for j in failed_jobs)
            warning_conditions.append(
                f"{len(failed_jobs)} database job(s) failed in latest run: {job_names}"
            )

        if critical_conditions:
            result['status']        = 'failed'
            result['error_message'] = '; '.join(critical_conditions)
        elif result.get('status') == 'failed':
            # Probe failed without a message - never downgrade it to warning.
            result['error_message'] = result.get('error_message') or 'Database check failed.'
        elif warning_conditions:
            result['status'] = 'warning'

        # Warning-level findings are recorded even when the overall status is
        # failed. The report and the email show the error and the warning box
        # separately, so a critical area no longer swallows everything else
        # that also needs attention.
        if warning_conditions:
            result['warning_reason'] = '; '.join(warning_conditions)

        return result

    except Exception as exc:
        logging.exception(f"DB health check error for '{db_monitor.host}'.")
        return {
            'host':          db_monitor.host,
            'database_type': db_monitor.database_type,
            'database_name': db_monitor.database_name,
            'status':        'failed',
            'error_message': f"{type(exc).__name__}: {exc}" if str(exc) else type(exc).__name__,
        }
# ---------------------------------------------------------------------------
# Oracle health check
# ---------------------------------------------------------------------------

def check_oracle_health(db_monitor) -> dict:
    """Check Oracle database health.  Password is decrypted here and
    discarded immediately after the connection is opened.

    Resource management:
      * Cursor and connection are both closed in `finally`, regardless
        of which query failed.
      * All queries are read-only SELECTs against system views.
      * Connection has no `commit()` calls -- Oracle's autocommit is OFF
        by default in cx_Oracle, so nothing is ever persisted on the
        target. We do not modify any DBA tables.
    """
    try:
        password = decrypt_data(db_monitor.password) if db_monitor.password else ''
    except Exception as exc:
        logging.error(f"Failed to decrypt Oracle password for '{db_monitor.host}': {exc}")
        return {'status': 'failed', 'error_message': 'Credential decryption error.'}

    port = db_monitor.port or 1521

    # Fail fast if the Oracle listener isn't reachable. connect() has no
    # bounded connect-level timeout here (call_timeout only applies once a
    # session exists), so an unreachable/firewalled host would otherwise
    # block this thread at the OS TCP timeout. A short socket pre-check
    # bounds the wait.
    try:
        with socket.create_connection(
            (db_monitor.host, port), timeout=_DB_TCP_CONNECT_TIMEOUT
        ):
            pass
    except Exception as exc:
        password = None  # discard the decrypted secret before returning
        return {
            'status':        'failed',
            'error_message': (
                f"Cannot reach Oracle listener at {db_monitor.host}:{port} "
                f"within {_DB_TCP_CONNECT_TIMEOUT}s ({exc})."
            ),
        }

    # Resolve the Oracle driver (thick/thin decided once per process) BEFORE
    # the first connect -- under the SCM/IIS the process PATH lacks the
    # Instant Client and a thick-only connect would die with DPI-1047.
    oracle = get_oracle_driver()

    dsn = oracle.makedsn(db_monitor.host, port, service_name=db_monitor.database_name)
    # Applies during connection negotiation in both supported driver modes.
    dsn = dsn.replace('(DESCRIPTION=', '(DESCRIPTION=(CONNECT_TIMEOUT=15)(TRANSPORT_CONNECT_TIMEOUT=10)(RETRY_COUNT=0)', 1)

    connection = None
    cursor     = None
    # Declared OUTSIDE the try so anything collected before an unexpected
    # failure is still returned to the caller (and so still rendered on the
    # report) instead of being thrown away with the exception.
    result: dict = {}
    collection_errors: list[str] = []
    try:
        # No `encoding` kwarg: python-oracledb rejects it (always UTF-8),
        # and cx_Oracle 8+ already defaults to UTF-8.
        connection = oracle.connect(
            user=db_monitor.username,
            password=password,
            dsn=dsn,
        )
        password = None  # discard immediately after connect
        # Use a generous-but-bounded call timeout so a stuck DB never
        # holds our monitoring host hostage. Both drivers expose this in
        # milliseconds; 60 s is well above any healthy query time but
        # short enough to fail the check cleanly.
        try:
            connection.call_timeout = 60_000   # ms
        except Exception:
            # Older cx_Oracle versions don't support call_timeout - ignore.
            pass

        cursor = connection.cursor()

        try:
            cursor.execute("SELECT banner FROM v$version WHERE rownum = 1")
            row = cursor.fetchone()
            result['version'] = row[0] if row else 'Unknown'
        except Exception as exc:
            logging.warning(f"Could not query Oracle version: {exc}")
            result['version'] = 'Unknown'
            collection_errors.append('version')

        try:
            cursor.execute("SELECT ROUND(SUM(bytes)/1024/1024/1024, 2) FROM dba_data_files")
            row = cursor.fetchone()
            result['database_size_gb'] = row[0] if row else 0
        except Exception as exc:
            logging.warning(f"Could not query Oracle database size: {exc}")
            result['database_size_gb'] = 0
            collection_errors.append('database size')

        # Tablespaces
        try:
            cursor.execute("""
            SELECT m.tablespace_name,
                   ROUND(m.used_space * t.block_size / 1024 / 1024, 2) AS used_mb,
                   ROUND((m.tablespace_size - m.used_space) * t.block_size / 1024 / 1024, 2) AS free_mb,
                   ROUND(m.tablespace_size * t.block_size / 1024 / 1024, 2) AS total_mb,
                   ROUND((m.used_space / NULLIF(m.tablespace_size, 0)) * 100, 2) AS used_percent
            FROM   dba_tablespace_usage_metrics m
            JOIN   dba_tablespaces t ON t.tablespace_name = m.tablespace_name
            ORDER  BY used_percent DESC
            """)
            tablespaces = []
            for ts_name, used_mb, free_mb, total_mb, used_percent in cursor.fetchall():
                status = 'critical' if used_percent >= 95 else ('warning' if used_percent >= 85 else 'ok')
                tablespaces.append({
                    'name': ts_name,
                    'used_mb':    int(used_mb    or 0),
                    'free_mb':    int(free_mb    or 0),
                    'total_mb':   int(total_mb   or 0),
                    'used_percent': int(used_percent or 0),
                    'status': status,
                })
            result['tablespaces'] = tablespaces
        except Exception as exc:
            logging.warning(f"Could not query Oracle tablespaces: {exc}")
            result['tablespaces'] = []
            collection_errors.append('tablespaces')

        # Long-running queries
        try:
            cursor.execute("""
                SELECT COUNT(*)
                FROM   v$session s, v$sql q
                WHERE  s.sql_id = q.sql_id
                AND    s.status = 'ACTIVE'
                AND    s.last_call_et > 1800
                AND    s.username IS NOT NULL
            """)
            result['long_running_queries'] = cursor.fetchone()[0]

            cursor.execute("""
                SELECT s.sid, s.username,
                       ROUND(s.last_call_et/60, 0) AS duration_minutes,
                       SUBSTR(q.sql_text, 1, 100) AS sql_text, s.status
                FROM   v$session s, v$sql q
                WHERE  s.sql_id = q.sql_id
                AND    s.status = 'ACTIVE'
                AND    s.last_call_et > 1800
                AND    s.username IS NOT NULL
                AND    rownum <= 10
                ORDER  BY s.last_call_et DESC
            """)
            result['long_running_query_details'] = [
                {
                    'session_id':       sid,
                    'username':         username or 'Unknown',
                    'duration_minutes': int(duration or 0),
                    'sql_text':         sql_text or '',
                    'status':           status or 'UNKNOWN',
                }
                for sid, username, duration, sql_text, status in cursor.fetchall()
            ]
        except Exception as exc:
            logging.warning(f"Could not query Oracle long-running sessions: {exc}")
            result['long_running_queries']       = 0
            result['long_running_query_details'] = []
            collection_errors.append('long-running queries')

        # Account status
        _sys_users = (
            "'ANONYMOUS','CTXSYS','DBSNMP','EXFSYS','LBACSYS','MDSYS','MGMT_VIEW',"
            "'OLAPSYS','ORDDATA','OWBSYS','ORDPLUGINS','ORDSYS','OUTLN',"
            "'SI_INFORMTN_SCHEMA','SYS','SYSMAN','SYSTEM','TSMSYS','WK_TEST',"
            "'WKSYS','WKPROXY','WMSYS','XDB','APEX_PUBLIC_USER','FLOWS_FILES',"
            "'APEX_030200','OWBSYS_AUDIT','SCOTT'"
        )
        try:
            cursor.execute(f"SELECT COUNT(*) FROM dba_users WHERE account_status LIKE '%LOCKED%' AND username NOT IN ({_sys_users})")
            result['locked_accounts'] = cursor.fetchone()[0]

            cursor.execute(f"SELECT COUNT(1) FROM dba_users WHERE account_status LIKE '%EXPIRED%' AND username NOT IN ({_sys_users})")
            result['expired_accounts'] = cursor.fetchone()[0]

            cursor.execute(f"""
                SELECT username, account_status, lock_date, expiry_date, profile
                FROM   dba_users
                WHERE  account_status NOT IN ('OPEN')
                AND    username NOT IN ({_sys_users})
                ORDER  BY expiry_date, lock_date DESC
            """)
            result['account_details'] = [
                {
                    'username':    username,
                    'status':      acc_status,
                    'lock_date':   lock_date.strftime('%Y-%m-%d') if lock_date else None,
                    'expiry_date': expiry_date.strftime('%Y-%m-%d') if expiry_date else None,
                    'profile':     profile or 'DEFAULT',
                }
                for username, acc_status, lock_date, expiry_date, profile in cursor.fetchall()
            ]
        except Exception as exc:
            logging.warning(f"Could not query Oracle account status: {exc}")
            result.setdefault('locked_accounts', 0)
            result.setdefault('expired_accounts', 0)
            result['account_details'] = []
            collection_errors.append('account status')

        # Backup status
        try:
            cursor.execute("""
                SELECT CASE WHEN COUNT(*) > 0 THEN 'success' ELSE 'failed' END,
                       MAX(completion_time)
                FROM   v$backup_set
                WHERE  completion_time > SYSDATE - 7
                AND    backup_type = 'D'
            """)
            row = cursor.fetchone()
            result['backup_status']   = row[0] if row else 'unknown'
            result['backup_last_run'] = row[1].strftime('%Y-%m-%d %H:%M:%S') if row and row[1] else None
        except Exception as exc:
            logging.warning(f"Could not query Oracle backup status: {exc}")
            result['backup_status']   = 'unknown'
            result['backup_last_run'] = None

        # RMAN backup job details
        try:
            cursor.execute("""
                SELECT TO_CHAR(start_time,'DD-MM-YYYY HH24:MI:SS'), input_type, status,
                       ROUND(elapsed_seconds/3600,1),
                       ROUND(INPUT_BYTES/1024/1024/1024),
                       ROUND(OUTPUT_BYTES/1024/1024/1024),
                       OUTPUT_DEVICE_TYPE
                FROM   v$rman_backup_job_details
                WHERE  START_TIME > SYSDATE - 3
                ORDER  BY start_time DESC
            """)
            result['backup_summary'] = [
                {
                    'start_time': r[0], 'input_type': r[1], 'status': r[2],
                    'time_hr': r[3], 'IN_GB': r[4], 'OUT_GB': r[5],
                    'OUTPUT_DEVICE_TYPE': r[6],
                }
                for r in cursor.fetchall()
            ]
        except Exception as exc:
            logging.warning(f"Could not query RMAN backup details: {exc}")
            result['backup_summary'] = []

        # Archive log mode
        try:
            cursor.execute("SELECT log_mode FROM v$database")
            row = cursor.fetchone()
            result['archive_log_status'] = 'ok' if row and row[0] == 'ARCHIVELOG' else 'warning'
        except Exception as exc:
            logging.warning(f"Could not query archive log mode: {exc}")
            result['archive_log_status'] = 'unknown'

        # Recovery file destination usage
        try:
            cursor.execute("""
                SELECT name,
                       space_limit/1024/1024/1024 AS total_gb,
                       space_used/1024/1024/1024  AS used_gb,
                       (space_limit-space_used)/1024/1024/1024 AS free_gb,
                       ROUND((space_used/space_limit)*100,2) AS used_percent
                FROM   v$recovery_file_dest
            """)
            archivelog_summary = []
            for name, total, used, free, pct in cursor.fetchall():
                status = 'critical' if pct >= 95 else ('warning' if pct >= 85 else 'ok')
                archivelog_summary.append({
                    'RECOVERY_AREA':  name,
                    'TOTAL_SPACE_GB': int(total or 0),
                    'USED_SPACE_GB':  int(used  or 0),
                    'FREE_SPACE_GB':  int(free  or 0),
                    'USED_PERCENT':   int(pct   or 0),
                    'status': status,
                })
            result['archivelog_summary'] = archivelog_summary
        except Exception as exc:
            logging.warning(f"Could not query recovery file destination: {exc}")
            result['archivelog_summary'] = []

        # Data Guard
        try:
            cursor.execute(
                "SELECT status, type, database_mode, destination, gap_status "
                "FROM v$archive_dest_status WHERE db_unique_name <> 'NONE'"
            )
            result['dataguard_summary'] = [
                {'status': r[0], 'type': r[1], 'database_mode': r[2],
                 'destination': r[3], 'gap_status': r[4]}
                for r in cursor.fetchall()
            ]
        except Exception as exc:
            logging.warning(f"Could not query DataGuard status: {exc}")
            result['dataguard_summary'] = []

        try:
            cursor.execute(
                "SELECT database_role, protection_mode FROM v$database"
            )
            row = cursor.fetchone()
            result['dataguard_status'] = (
                'ok' if row and row[0] in ('PRIMARY', 'PHYSICAL STANDBY') else 'not_configured'
            )
        except Exception as exc:
            logging.warning(f"Could not query DataGuard role: {exc}")
            result['dataguard_status'] = 'unknown'

        # ---- Jobs whose LATEST run (per job) failed in the last 24h ---
        # Rank each job's runs and keep only the most recent one; report it
        # only if that latest run did not succeed (and is not still running).
        try:
            cursor.execute("""
                SELECT job_name, status, error_no, actual_start_date,
                       run_duration
                  FROM (
                    SELECT job_name,
                           status,
                           error#            AS error_no,
                           actual_start_date,
                           run_duration,
                           ROW_NUMBER() OVER (PARTITION BY job_name
                                              ORDER BY actual_start_date DESC) AS rn
                      FROM dba_scheduler_job_run_details
                     WHERE actual_start_date > SYSTIMESTAMP - 1
                  )
                 WHERE rn = 1
                   AND status NOT IN ('SUCCEEDED', 'RUNNING')
                 ORDER BY actual_start_date DESC
                 FETCH FIRST 20 ROWS ONLY
            """)
            failed = []
            for row in cursor.fetchall():
                failed.append({
                    'job_name':           row[0],
                    'status':             row[1],
                    'error_code':         row[2],
                    'actual_start_date':  row[3].strftime('%Y-%m-%d %H:%M:%S') if row[3] else None,
                    'run_duration':       str(row[4]) if row[4] is not None else None,
                })
            result['failed_jobs']        = failed
            result['failed_jobs_status'] = 'failed' if failed else 'ok'
        except Exception as exc:
            logging.warning(f"Could not query Oracle scheduler jobs: {exc}")
            result['failed_jobs']        = []
            result['failed_jobs_status'] = 'unknown'

        # ---- Scheduled jobs (enabled, with a computed next run) -------
        try:
            cursor.execute("""
                SELECT job_name, state, next_run_date, repeat_interval,
                       last_start_date
                  FROM dba_scheduler_jobs
                 WHERE enabled = 'TRUE' AND next_run_date IS NOT NULL
                 ORDER BY next_run_date
                 FETCH FIRST 50 ROWS ONLY
            """)
            scheduled = []
            for row in cursor.fetchall():
                scheduled.append({
                    'job_name': row[0],
                    'state':    row[1] or 'SCHEDULED',
                    'next_run': row[2].strftime('%Y-%m-%d %H:%M:%S') if row[2] else None,
                    'schedule': (str(row[3])[:120] if row[3] else None),
                    'last_run': row[4].strftime('%Y-%m-%d %H:%M:%S') if row[4] else None,
                })
            result['scheduled_jobs'] = scheduled
        except Exception as exc:
            logging.warning(f"Could not query Oracle scheduled jobs: {exc}")
            result['scheduled_jobs'] = []

        # ---- Unscheduled jobs (disabled, or no next run) --------------
        try:
            cursor.execute("""
                SELECT job_name, state, enabled
                  FROM dba_scheduler_jobs
                 WHERE enabled = 'FALSE' OR next_run_date IS NULL
                 ORDER BY job_name
                 FETCH FIRST 50 ROWS ONLY
            """)
            unscheduled = []
            for row in cursor.fetchall():
                is_enabled = (row[2] or '').upper() == 'TRUE'
                unscheduled.append({
                    'job_name': row[0],
                    'state':    row[1] or 'N/A',
                    'reason':   'No next run scheduled' if is_enabled else 'Disabled',
                })
            result['unscheduled_jobs'] = unscheduled
        except Exception as exc:
            logging.warning(f"Could not query Oracle unscheduled jobs: {exc}")
            result['unscheduled_jobs'] = []

        # The dispatcher turns missing_checks into a warning condition; the
        # probe only reports WHAT it could not collect.
        result['collection_status'] = 'incomplete' if collection_errors else 'complete'
        result['missing_checks']    = collection_errors
        return result

    except Exception as exc:
        # Connection-level or otherwise unexpected failure. Return whatever
        # was collected before it happened, flagged as failed, so the report
        # keeps every check that did complete.
        logging.exception(f"Oracle health check failed for '{db_monitor.host}'.")
        result['status']         = 'failed'
        result['error_message']  = (
            f"{type(exc).__name__}: {exc}" if str(exc) else type(exc).__name__
        )
        result['missing_checks']    = collection_errors
        result['collection_status'] = 'incomplete'
        return result

    finally:
        if cursor is not None:
            try:
                cursor.close()
            except Exception:
                pass
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass


# ---------------------------------------------------------------------------
# MSSQL health check
# ---------------------------------------------------------------------------

def check_mssql_health(db_monitor) -> dict:
    """Check MSSQL database health via pyodbc (native ODBC driver).

    Replaces the previous pymssql implementation. The ODBC driver name
    is auto-detected (override with the MSSQL_ODBC_DRIVER env var).

    All result keys produced by the previous implementation are preserved
    so the report_detail.html template renders without modification:
        version, database_size_gb, tablespaces[], long_running_queries,
        long_running_query_details[], locked_accounts, expired_accounts,
        account_details[], backup_status, backup_last_run,
        archive_log_status

    New in this version:
        failed_jobs[], failed_jobs_status   (SQL Agent failed jobs in
                                             the last 24 hours)
    """
    try:
        password = decrypt_data(db_monitor.password) if db_monitor.password else ''
    except Exception as exc:
        logging.error(f"Failed to decrypt MSSQL password for '{db_monitor.host}': {exc}")
        return {'status': 'failed', 'error_message': 'Credential decryption error.'}

    port       = db_monitor.port or 1433
    connection = None
    cursor     = None
    # Declared OUTSIDE the try so partial collection survives a failure
    # part-way through - see the Oracle probe for the same pattern.
    result: dict = {}
    collection_errors: list[str] = []
    try:
        # Encrypt=yes with TrustServerCertificate=no: the server's certificate
        # is verified, so the credentials below cannot be handed to an
        # impostor. A monitored instance with a self-signed certificate needs
        # its issuing CA added to the monitoring host's trust store - do NOT
        # relax this to TrustServerCertificate=yes to work around that.
        conn_str = (
            f"DRIVER={{{_MSSQL_DRIVER}}};"
            f"SERVER={_odbc_value(str(db_monitor.host) + ',' + str(port))};"
            f"DATABASE={_odbc_value(db_monitor.database_name)};"
            f"UID={_odbc_value(db_monitor.username)};"
            f"PWD={_odbc_value(password)};"
            f"Encrypt=yes;"
            f"TrustServerCertificate=no;"
        )
        connection = pyodbc.connect(conn_str, timeout=30)
        password   = None  # discard immediately after connect
        # Read-only intent - we only run SELECTs. Setting autocommit=True
        # avoids any chance of an implicit transaction being left open on
        # the target server when this connection is closed.
        try:
            connection.autocommit = True
        except Exception:
            pass
        # Per-statement query timeout (seconds). A misbehaving target
        # cannot tie up our monitor indefinitely.
        try:
            connection.timeout = 60
        except Exception:
            pass

        cursor = connection.cursor()

        # ---- Version --------------------------------------------------
        try:
            cursor.execute("SELECT @@VERSION")
            row = cursor.fetchone()
            result['version'] = (row[0].split('\n')[0] if row and row[0] else 'Unknown')
        except Exception as exc:
            logging.warning(f"Could not query MSSQL version: {exc}")
            result['version'] = 'Unknown'
            collection_errors.append('version')

        # ---- Database size --------------------------------------------
        try:
            cursor.execute("""
                SELECT ROUND(SUM(CAST(size AS BIGINT)*8.0/1024/1024),2)
                  FROM sys.master_files WHERE database_id = DB_ID()
            """)
            row = cursor.fetchone()
            result['database_size_gb'] = float(row[0]) if row and row[0] is not None else 0
        except Exception as exc:
            logging.warning(f"Could not query MSSQL database size: {exc}")
            result['database_size_gb'] = 0
            collection_errors.append('database size')

        # ---- Tablespaces (file-group + log usage) ---------------------
        try:
            cursor.execute("""
            SELECT COALESCE(fg.name,'LOG')                                                AS name,
                   ROUND(SUM(CAST(mf.size AS BIGINT)*8.0/1024),0)                         AS total_mb,
                   ROUND(SUM(CAST(FILEPROPERTY(mf.name,'SpaceUsed') AS BIGINT)*8.0/1024),0)            AS used_mb,
                   ROUND(SUM(CAST((mf.size-FILEPROPERTY(mf.name,'SpaceUsed')) AS BIGINT)*8.0/1024),0)  AS free_mb,
                   ROUND(SUM(CAST(FILEPROPERTY(mf.name,'SpaceUsed') AS BIGINT))*100.0
                         / NULLIF(SUM(CAST(mf.size AS BIGINT)),0), 0)                     AS used_percent
              FROM sys.master_files mf
         LEFT JOIN sys.filegroups   fg ON mf.data_space_id = fg.data_space_id
             WHERE mf.database_id = DB_ID()
                 GROUP BY fg.name, mf.type_desc
                 ORDER BY used_percent DESC
            """)
            tablespaces = []
            for row in cursor.fetchall():
                pct    = int(row[4] or 0)
                status = 'critical' if pct >= 95 else ('warning' if pct >= 85 else 'ok')
                tablespaces.append({
                    'name':         row[0] or 'LOG',
                    'total_mb':     int(row[1] or 0),
                    'used_mb':      int(row[2] or 0),
                    'free_mb':      int(row[3] or 0),
                    'used_percent': pct,
                    'status':       status,
                })
            result['tablespaces'] = tablespaces
        except Exception as exc:
            logging.warning(f"Could not query MSSQL file usage: {exc}")
            result['tablespaces'] = []
            collection_errors.append('file usage')

        # ---- Long-running queries (count + details) -------------------
        try:
            cursor.execute("""
                SELECT COUNT(*)
                  FROM sys.dm_exec_requests r
                  CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) st
                 WHERE r.total_elapsed_time > 1800000 AND r.session_id > 50
            """)
            row = cursor.fetchone()
            result['long_running_queries'] = int(row[0]) if row and row[0] is not None else 0

            cursor.execute("""
                SELECT TOP 10 r.session_id, s.login_name AS username,
                       ROUND(r.total_elapsed_time/60000.0,0) AS duration_minutes,
                       LEFT(st.text,100) AS sql_text, r.status
                  FROM sys.dm_exec_requests r
            INNER JOIN sys.dm_exec_sessions s ON r.session_id = s.session_id
                  CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) st
                 WHERE r.total_elapsed_time > 1800000 AND r.session_id > 50
                 ORDER BY r.total_elapsed_time DESC
            """)
            result['long_running_query_details'] = [
                {
                    'session_id':       row[0],
                    'username':         row[1] or 'Unknown',
                    'duration_minutes': int(row[2] or 0),
                    'sql_text':         row[3] or '',
                    'status':           row[4] or 'UNKNOWN',
                }
                for row in cursor.fetchall()
            ]
        except Exception as exc:
            logging.warning(f"Could not query MSSQL long-running requests: {exc}")
            result['long_running_queries']       = 0
            result['long_running_query_details'] = []
            collection_errors.append('long-running queries')

        # ---- Locked / disabled accounts -------------------------------
        try:
            cursor.execute("SELECT COUNT(*) FROM sys.sql_logins WHERE is_disabled=1")
            row = cursor.fetchone()
            result['locked_accounts']  = int(row[0]) if row else 0
            cursor.execute("SELECT COUNT(*) FROM sys.sql_logins WHERE LOGINPROPERTY(name, 'IsExpired') = 1")
            row = cursor.fetchone()
            result['expired_accounts'] = int(row[0]) if row else 0

            cursor.execute("""
                SELECT name AS username,
                       CASE WHEN is_disabled=1 THEN 'DISABLED' ELSE 'ENABLED' END AS status,
                       create_date, modify_date
                  FROM sys.sql_logins WHERE is_disabled=1 ORDER BY name
            """)
            result['account_details'] = [
                {
                    'username':    row[0],
                    'status':      row[1],
                    'lock_date':   row[3].strftime('%Y-%m-%d') if row[3] else None,
                    'expiry_date': None,
                    'profile':     'DEFAULT',
                }
                for row in cursor.fetchall()
            ]
        except Exception as exc:
            logging.warning(f"Could not query MSSQL login status: {exc}")
            result.setdefault('locked_accounts', 0)
            result.setdefault('expired_accounts', 0)
            result['account_details'] = []
            collection_errors.append('account status')

        # ---- Backup status (full backup in last 7 days) ---------------
        try:
            cursor.execute("""
                SELECT TOP 1
                       CASE WHEN backup_finish_date IS NOT NULL THEN 'success' ELSE 'failed' END,
                       backup_finish_date
                  FROM msdb.dbo.backupset
                 WHERE database_name = DB_NAME() AND type='D'
                   AND backup_finish_date > DATEADD(day,-7,GETDATE())
                 ORDER BY backup_finish_date DESC
            """)
            row = cursor.fetchone()
            if row:
                result['backup_status']   = row[0]
                result['backup_last_run'] = row[1].strftime('%Y-%m-%d %H:%M:%S') if row[1] else None
            else:
                result['backup_status']   = 'failed'
                result['backup_last_run'] = None
        except Exception as exc:
            logging.warning(f"Could not query MSSQL backup status: {exc}")
            result['backup_status']   = 'unknown'
            result['backup_last_run'] = None

        # ---- Transaction log status (analogue of "archive log") ------
        try:
            cursor.execute("""
                SELECT CASE
                    WHEN recovery_model_desc = 'SIMPLE' THEN 'ok'
                    WHEN EXISTS (
                        SELECT 1 FROM msdb.dbo.backupset
                         WHERE database_name=DB_NAME() AND type='L'
                           AND backup_finish_date > DATEADD(hour,-24,GETDATE())
                    ) THEN 'ok'
                    ELSE 'warning'
                END
                  FROM sys.databases WHERE name = DB_NAME()
            """)
            row = cursor.fetchone()
            result['archive_log_status'] = row[0] if row else 'unknown'
        except Exception as exc:
            logging.warning(f"Could not query MSSQL log status: {exc}")
            result['archive_log_status'] = 'unknown'

        # ---- SQL Agent jobs whose LATEST run (per job) failed in 24h --
        # step_id = 0 is the job-level outcome row. Rank each job's outcome
        # rows and keep only the most recent; report it only if that latest
        # run did not succeed (run_status <> 1).
        try:
            cursor.execute("""
                SELECT TOP 20
                       job_name, run_status, run_date, run_time,
                       run_duration, message
                  FROM (
                    SELECT j.name               AS job_name,
                           h.run_status         AS run_status,
                           h.run_date           AS run_date,
                           h.run_time           AS run_time,
                           h.run_duration       AS run_duration,
                           LEFT(h.message, 200) AS message,
                           ROW_NUMBER() OVER (PARTITION BY h.job_id
                                              ORDER BY h.run_date DESC,
                                                       h.run_time DESC) AS rn
                      FROM msdb.dbo.sysjobs   j
                      JOIN msdb.dbo.sysjobhistory h ON j.job_id = h.job_id
                     WHERE h.step_id = 0
                       AND msdb.dbo.agent_datetime(h.run_date, h.run_time)
                           > DATEADD(DAY, -1, GETDATE())
                  ) t
                 WHERE t.rn = 1
                   AND t.run_status <> 1
                 ORDER BY t.run_date DESC, t.run_time DESC
            """)
            failed = []
            for row in cursor.fetchall():
                failed.append({
                    'job_name':     row[0],
                    'run_status':   int(row[1]) if row[1] is not None else None,
                    'run_date':     int(row[2]) if row[2] is not None else None,
                    'run_time':     int(row[3]) if row[3] is not None else None,
                    'run_duration': int(row[4]) if row[4] is not None else None,
                    'message':      row[5] or '',
                })
            result['failed_jobs']        = failed
            result['failed_jobs_status'] = 'failed' if failed else 'ok'
        except Exception as exc:
            logging.warning(f"Could not query SQL Agent jobs: {exc}")
            result['failed_jobs']        = []
            result['failed_jobs_status'] = 'unknown'

        # ---- Scheduled jobs (enabled, with a computed next run) -------
        # next_scheduled_run_date lives in sysjobactivity as a real datetime;
        # take the latest agent session so we read current schedule state.
        try:
            cursor.execute("""
                SELECT j.name,
                       ja.next_scheduled_run_date,
                       ja.start_execution_date
                  FROM msdb.dbo.sysjobs j
                  JOIN msdb.dbo.sysjobactivity ja ON ja.job_id = j.job_id
                 WHERE j.enabled = 1
                   AND ja.next_scheduled_run_date IS NOT NULL
                   AND ja.session_id = (SELECT MAX(session_id)
                                          FROM msdb.dbo.sysjobactivity)
                 ORDER BY ja.next_scheduled_run_date
            """)
            scheduled = []
            for row in cursor.fetchall():
                scheduled.append({
                    'job_name': row[0],
                    'state':    'ENABLED',
                    'next_run': row[1].strftime('%Y-%m-%d %H:%M:%S') if row[1] else None,
                    'schedule': None,
                    'last_run': row[2].strftime('%Y-%m-%d %H:%M:%S') if row[2] else None,
                })
            result['scheduled_jobs'] = scheduled
        except Exception as exc:
            logging.warning(f"Could not query SQL Agent scheduled jobs: {exc}")
            result['scheduled_jobs'] = []

        # ---- Unscheduled jobs (disabled, or no active schedule) -------
        try:
            cursor.execute("""
                SELECT j.name,
                       CASE WHEN j.enabled = 1 THEN 'ENABLED' ELSE 'DISABLED' END,
                       CASE WHEN j.enabled = 0 THEN 'Disabled'
                            ELSE 'No active schedule' END
                  FROM msdb.dbo.sysjobs j
                 WHERE j.enabled = 0
                    OR NOT EXISTS (
                         SELECT 1
                           FROM msdb.dbo.sysjobschedules s
                           JOIN msdb.dbo.sysschedules sch
                                ON sch.schedule_id = s.schedule_id
                          WHERE s.job_id = j.job_id AND sch.enabled = 1)
                 ORDER BY j.name
            """)
            unscheduled = []
            for row in cursor.fetchall():
                unscheduled.append({
                    'job_name': row[0],
                    'state':    row[1],
                    'reason':   row[2],
                })
            result['unscheduled_jobs'] = unscheduled
        except Exception as exc:
            logging.warning(f"Could not query SQL Agent unscheduled jobs: {exc}")
            result['unscheduled_jobs'] = []

        result['collection_status'] = 'incomplete' if collection_errors else 'complete'
        result['missing_checks']    = collection_errors
        return result

    except Exception as exc:
        # Connection-level or otherwise unexpected failure - return the
        # partial result so completed checks still reach the report.
        logging.exception(f"MSSQL health check failed for '{db_monitor.host}'.")
        result['status']        = 'failed'
        result['error_message'] = (
            f"{type(exc).__name__}: {exc}" if str(exc) else type(exc).__name__
        )
        result['missing_checks']    = collection_errors
        result['collection_status'] = 'incomplete'
        return result

    finally:
        if cursor is not None:
            try:
                cursor.close()
            except Exception:
                pass
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass
