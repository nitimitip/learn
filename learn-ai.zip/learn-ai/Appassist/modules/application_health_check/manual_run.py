"""
manual_run.py - detached execution for the "Run Check" button.

WHY
---
A manual health check used to run INSIDE the HTTP request. A single report can
legitimately take minutes: each URL costs up to ~90s (two 30s TLS socket probes
plus the request timeout), each server 30s to connect plus four commands at 60s
each, each Oracle instance a 10s TCP pre-check plus several 60s queries. IIS
hosts the app with maxInstances="8" single-threaded workers, so one click could
hold 1/8th of the entire concurrency budget for the whole run - and a big report
could outlive requestTimeout="600" in web.config, handing the user a 502 while
the work carried on invisibly.

HOW
---
Same shape Code Sentinel uses for scans - enqueue, return immediately, poll -
but the work goes to a DETACHED CHILD PROCESS rather than a thread in the web
worker. That difference matters here: a background thread produces no FastCGI
activity, so IIS reaps its host process on activityTimeout/idleTimeout and
kills the thread with it. A detached process is not IIS's to reap.

The child is `run_health_checks.py --report N --force --job`, which already
knows how to run one report; --job adds the state transitions and heartbeat.

State machine, held on the HealthCheckReport row (one manual run per report at
a time, which the pre-existing cooldown already assumed):

    (NULL) --enqueue--> queued --child starts--> running --+--> done
                                                           +--> failed
                          |                                     ^
                          +--- process died, heartbeat stale ---+

Every transition is a short DB write; no session is held while the checks run.
"""

import logging
import os
import subprocess
import sys
from datetime import datetime, timedelta

from database import get_db_session
from .models import HealthCheckReport

logger = logging.getLogger(__name__)

# States that mean "a job is in flight for this report".
ACTIVE_STATES = ('queued', 'running')

# A job whose heartbeat has not been stamped for this long is treated as dead.
# The child stamps every HEARTBEAT_INTERVAL_SECONDS, so this is a wide margin -
# it only has to outlast a paused/swapped-out process, not a slow probe.
STALE_AFTER_SECONDS = int(os.environ.get('HEALTH_MANUAL_STALE_SECONDS', '300'))

# How often the detached child stamps manual_run_heartbeat.
HEARTBEAT_INTERVAL_SECONDS = int(
    os.environ.get('HEALTH_MANUAL_HEARTBEAT_SECONDS', '30'))

# The runner script the child process executes.
_RUNNER = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       'run_health_checks.py')


# ---------------------------------------------------------------------------
# Enqueue
# ---------------------------------------------------------------------------

def enqueue(report_id, user_id):
    """Claim the report and spawn the detached runner.

    Returns (ok, message). ok=False means nothing was started and `message`
    explains why, in words suitable for a flash message.

    The claim is a conditional UPDATE: the state only moves to 'queued' when
    no job is already in flight. Two users clicking at the same moment - even
    on different IIS workers - therefore produce exactly one run, because the
    database, not the application, decides who won.
    """
    db_session = get_db_session()
    try:
        report = db_session.query(HealthCheckReport).filter_by(id=report_id).first()
        if not report:
            return False, 'Report not found.'

        # Retire a job whose process died before claiming, so a crashed run can
        # never block the button for ever.
        _expire_if_stale(db_session, report)

        if report.manual_run_state in ACTIVE_STATES:
            started = report.manual_run_started_at
            since = ''
            if started:
                since = ' (started %s)' % started.strftime('%H:%M:%S')
            return False, 'A check is already running for this report%s.' % since

        claimed = (
            db_session.query(HealthCheckReport)
            .filter(
                HealthCheckReport.id == report_id,
                # NOT IN would miss NULL rows on every backend, so spell the
                # "no job in flight" condition out explicitly.
                (HealthCheckReport.manual_run_state.is_(None)) |
                (~HealthCheckReport.manual_run_state.in_(ACTIVE_STATES)),
            )
            .update(
                {
                    'manual_run_state':      'queued',
                    'manual_run_started_at': datetime.now(),
                    'manual_run_by':         user_id,
                    'manual_run_message':    None,
                    'manual_run_heartbeat':  datetime.now(),
                },
                synchronize_session=False,
            )
        )
        db_session.commit()
        if not claimed:
            return False, 'A check is already running for this report.'
    except Exception:
        db_session.rollback()
        logger.exception('Could not claim report %s for a manual run.', report_id)
        return False, 'Could not start the check - see the application log.'
    finally:
        db_session.close()

    try:
        _spawn(report_id)
    except Exception:
        logger.exception('Failed to spawn the runner for report %s.', report_id)
        _finish(report_id, 'failed',
                'The check process could not be started. See the application log.')
        return False, 'Could not start the check process - see the application log.'

    return True, 'Check started. This page updates by itself as it runs.'


def _spawn(report_id):
    """Start run_health_checks.py in a process IIS does not own.

    DETACHED_PROCESS + CREATE_NEW_PROCESS_GROUP cut the child loose from this
    worker's console and process group, so an app-pool recycle does not take
    it down with the parent. stdin/stdout/stderr go to DEVNULL: the child logs
    to its own dated file, and leaving a pipe attached would block the child
    once nobody drains it.
    """
    cmd = [sys.executable, _RUNNER, '--report', str(report_id), '--force', '--job']

    kwargs = {
        'stdin':  subprocess.DEVNULL,
        'stdout': subprocess.DEVNULL,
        'stderr': subprocess.DEVNULL,
        'cwd':    os.path.dirname(os.path.dirname(os.path.dirname(
                      os.path.abspath(__file__)))),
        'close_fds': True,
    }
    if os.name == 'nt':
        kwargs['creationflags'] = (
            getattr(subprocess, 'DETACHED_PROCESS', 0x00000008) |
            getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0x00000200) |
            getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000)
        )
    else:
        kwargs['start_new_session'] = True

    proc = subprocess.Popen(cmd, **kwargs)
    logger.info('Manual health check for report %s dispatched to pid %s.',
                report_id, proc.pid)


# ---------------------------------------------------------------------------
# State transitions - called from inside the detached child
# ---------------------------------------------------------------------------

def mark_running(report_id):
    """Child announces it has started the probes."""
    _update(report_id, {
        'manual_run_state':     'running',
        'manual_run_heartbeat': datetime.now(),
    })


def beat(report_id):
    """Child stamps liveness. Called on a timer while the probes run."""
    _update(report_id, {'manual_run_heartbeat': datetime.now()})


def _finish(report_id, state, message):
    _update(report_id, {
        'manual_run_state':     state,
        'manual_run_message':   (message or '')[:2000],
        'manual_run_heartbeat': datetime.now(),
    })


def mark_done(report_id, message):
    _finish(report_id, 'done', message)


def mark_failed(report_id, message):
    _finish(report_id, 'failed', message)


def _update(report_id, values):
    db_session = get_db_session()
    try:
        db_session.query(HealthCheckReport) \
                  .filter(HealthCheckReport.id == report_id) \
                  .update(values, synchronize_session=False)
        db_session.commit()
    except Exception:
        db_session.rollback()
        # Never let a status write break the run it is describing.
        logger.exception('Could not update manual-run state for report %s.',
                         report_id)
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Status, for the polling endpoint
# ---------------------------------------------------------------------------

def status(report_id):
    """Current job state as a plain dict, or None when the report is gone.

    Reaps a dead job as a side effect, so simply watching the page is enough
    to clear a run whose process was killed - no separate sweeper needed.
    """
    db_session = get_db_session()
    try:
        report = db_session.query(HealthCheckReport).filter_by(id=report_id).first()
        if not report:
            return None
        if _expire_if_stale(db_session, report):
            db_session.commit()

        started = report.manual_run_started_at
        elapsed = None
        if started and report.manual_run_state in ACTIVE_STATES:
            elapsed = int((datetime.now() - started).total_seconds())

        return {
            'state':      report.manual_run_state or 'idle',
            'active':     report.manual_run_state in ACTIVE_STATES,
            'message':    report.manual_run_message,
            'started_at': started.isoformat(timespec='seconds') if started else None,
            'elapsed_seconds': elapsed,
            'last_run_time':   (report.last_run_time.isoformat(timespec='seconds')
                                if report.last_run_time else None),
            'last_run_status': report.last_run_status,
            'last_run_score':  report.last_run_score,
        }
    finally:
        db_session.close()


def _expire_if_stale(db_session, report):
    """Flip an in-flight job to 'failed' when its heartbeat has gone quiet.

    Mutates `report` in the caller's session; the caller commits. Returns True
    when something changed.
    """
    if report.manual_run_state not in ACTIVE_STATES:
        return False
    beat_at = report.manual_run_heartbeat or report.manual_run_started_at
    if beat_at is None:
        return False
    if datetime.now() - beat_at <= timedelta(seconds=STALE_AFTER_SECONDS):
        return False

    logger.warning(
        'Manual run for report %s went quiet after %s - marking it failed.',
        report.id, beat_at,
    )
    report.manual_run_state = 'failed'
    report.manual_run_message = (
        'The check process stopped responding and was marked failed. '
        'It may have been ended by a server restart. Try running it again.'
    )
    report.manual_run_heartbeat = datetime.now()
    return True
