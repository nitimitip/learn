# Password Encryption Fix — Deployment Guide

## What this fixes

Three related bugs:

1. **Passwords were saved as plaintext.** `routes.py` never called `encrypt_data()` when creating or editing server/database monitors. The DB column had encrypted-looking data only by accident; in reality the `password` field held whatever the user typed.
2. **`decrypt_data()` silently returned `''` on any failure.** That meant a missing encryption key, corrupt data, or legacy plaintext rows all looked the same: connection attempts went out with an empty password and the target system replied "incorrect password" — masking the actual problem.
3. **`health_monitor.py` showed a generic "Unexpected error — see application logs" message.** The real exception text was being thrown away, making troubleshooting hard.

## Files changed

| File | What changed |
|------|--------------|
| `routes.py` | Imports `encrypt_data`. All 4 password-save sites now wrap the form value. |
| `crypto_utils.py` | New `CredentialDecryptionError` exception. `decrypt_data()` raises with a clear message instead of silently returning empty string. |
| `modules/application_health_check/health_monitor.py` | All 3 exception handlers (URL / Server / Database) now bind the exception and surface its real text in `error_message`. |
| `encrypt_existing_passwords.py` | **NEW** — one-shot migration script for legacy plaintext rows. |

## Deployment order — do these steps in sequence

### Step 1 — Stop the schedulers

Stop the Flask app pool in IIS, AND temporarily disable the Windows Task Scheduler job that runs `run_health_checks.py`. You don't want a check firing mid-migration.

### Step 2 — Deploy the three patched files

Copy these to their existing locations:
- `crypto_utils.py` → project root (replace existing)
- `routes.py` → `modules/application_health_check/` (replace existing)
- `health_monitor.py` → `modules/application_health_check/` (replace existing)

Also copy the new file:
- `encrypt_existing_passwords.py` → project root

### Step 3 — Run the migration (DRY RUN first)

From the project root:

```cmd
python encrypt_existing_passwords.py --dry-run
```

Review the output. You should see one log line per legacy plaintext row, e.g.:

```
ServerMonitor id=3 host=appserver01 -> encrypting password (plaintext length=12)
DatabaseMonitor id=1 host=db01 db=PROD -> encrypting password (plaintext length=10)
```

If the count looks right, run for real:

```cmd
python encrypt_existing_passwords.py
```

This is **idempotent** — already-encrypted rows are detected and skipped, so it's safe to re-run if anything goes wrong.

### Step 4 — Restart everything

1. Start the Flask app pool in IIS.
2. Re-enable the Windows Task Scheduler job.
3. Open the Flask UI and trigger a manual health check on one report.

You should see actual error text now (e.g. `pyodbc.OperationalError: Login failed for user 'X'`) instead of "Unexpected error — see application logs".

## Important: ENCRYPTION_KEY / SESSION_SECRET

The encryption key is derived from these env vars (priority: `ENCRYPTION_KEY` > `SESSION_SECRET` > a hardcoded default).

**If you ever change `ENCRYPTION_KEY` or `SESSION_SECRET` after running the migration, every existing encrypted password becomes unreadable.** You'd see `CredentialDecryptionError: Stored credential failed Fernet integrity check — the encryption key may have changed`.

To recover from that, you'd need to:
1. Change the env var back to the old value, OR
2. Manually re-save every monitor through the UI (which encrypts under the new key).

For production stability, set `ENCRYPTION_KEY` explicitly in your `.env` file and never rotate it without a planned password re-entry exercise.

## Rolling back

If the migration causes problems:

1. Restore `crypto_utils.py`, `routes.py`, `health_monitor.py` from your previous deployment (or git).
2. The encrypted password values in the DB are no longer readable by the old `decrypt_data()` (which would silently return `''`). Re-enter the affected passwords through the UI.

There's no clean automated rollback because the old code can't read encrypted data — that's the point of the fix.

## Verification checklist after deployment

- [ ] Migration ran without errors. Output showed reasonable encrypt counts.
- [ ] Manual health check on a known-good monitor: shows status `success`.
- [ ] Manual health check on a deliberately-bad monitor (e.g. wrong password): shows specific error like "Login failed" or "Authentication failed", NOT "Unexpected error".
- [ ] Edit a monitor through the UI, save, and re-check — still works.
- [ ] Create a new monitor through the UI, save, and check — still works.
- [ ] No `CredentialDecryptionError` entries appear in `app.log` after the migration.
