from sqlalchemy import (
    Column, Integer, String, DateTime, Text, Boolean,
    ForeignKey, JSON, Float, CheckConstraint, Index, UniqueConstraint,
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from database import Base


# ---------------------------------------------------------------------------
# Application Tower
# ---------------------------------------------------------------------------

class ApplicationTower(Base):
    __tablename__ = 'application_towers'

    __table_args__ = (
        Index('ix_tower_is_active', 'is_active'),
    )

    id              = Column(Integer, primary_key=True)
    name            = Column(String(100), nullable=False)
    description     = Column(Text)
    email_addresses = Column(Text)          # Comma-separated
    created_at      = Column(DateTime, default=func.now())
    created_by      = Column(Integer, ForeignKey('users.id'))
    is_active       = Column(Boolean, default=True, nullable=False)

    # cascade="all, delete-orphan" makes ORM-level delete handle children so
    # routes.delete_tower no longer needs the manual cascade loop.
    reports = relationship(
        "HealthCheckReport",
        back_populates="tower",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    tower_members = relationship(
        "AppTowerMember",
        back_populates="tower",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )


class AppTowerMember(Base):
    __tablename__ = 'health_check_tower_members'

    __table_args__ = (
        # A user can only be added to a given tower once.
        UniqueConstraint('tower_id', 'user_id', name='uq_tower_member_tower_user'),
        Index('ix_tower_member_tower_id', 'tower_id'),
        Index('ix_tower_member_user_id',  'user_id'),
    )

    id       = Column(Integer, primary_key=True)
    tower_id = Column(Integer, ForeignKey('application_towers.id', ondelete='CASCADE'), nullable=False)
    user_id  = Column(Integer, ForeignKey('users.id'),                                  nullable=False)
    added_at = Column(DateTime, default=func.now())
    added_by = Column(Integer, ForeignKey('users.id'))

    tower = relationship("ApplicationTower", back_populates="tower_members")


# ---------------------------------------------------------------------------
# Health Check Report
# ---------------------------------------------------------------------------

class HealthCheckReport(Base):
    __tablename__ = 'health_check_reports'

    __table_args__ = (
        CheckConstraint(
            "check_duration IN ('30min','1hr','2hr','3hr','4hr')",
            name='ck_report_check_duration',
        ),
        # Heavy-hit indexes - scheduler sweeps & dashboard reads.
        Index('ix_report_tower_id',     'tower_id'),
        Index('ix_report_is_active',    'is_active'),
        Index('ix_report_next_run',     'is_active', 'next_run_time'),  # composite for run_due_checks
    )

    id               = Column(Integer, primary_key=True)
    tower_id         = Column(Integer, ForeignKey('application_towers.id', ondelete='CASCADE'))
    application_name = Column(String(100), nullable=False)
    description      = Column(Text)
    check_duration   = Column(String(20))   # 30min | 1hr | 2hr | 3hr | 4hr

    # Monitoring feature toggles
    url_monitoring_enabled      = Column(Boolean, default=False, nullable=False)
    server_monitoring_enabled   = Column(Boolean, default=False, nullable=False)
    database_monitoring_enabled = Column(Boolean, default=False, nullable=False)
    email_alerts_enabled        = Column(Boolean, default=False, nullable=False)

    created_at = Column(DateTime, default=func.now())
    created_by = Column(Integer, ForeignKey('users.id'))
    is_active  = Column(Boolean, default=True, nullable=False)

    # When True the scheduled sweep skips this report (a temporary "pause"):
    # the report stays active and can still be run manually, but no automatic
    # checks fire until it is resumed. See run_due_checks() in health_monitor.
    schedule_paused = Column(Boolean, default=False, nullable=False)

    # Latest-run snapshot (overwrite approach - for fast dashboard display)
    last_run_time   = Column(DateTime)
    next_run_time   = Column(DateTime)
    last_run_status = Column(String(20))    # healthy | warning | failed
    last_run_score  = Column(Float)         # 0-100

    latest_url_results      = Column(JSON)
    latest_server_results   = Column(JSON)
    latest_database_results = Column(JSON)

    # ---- Manual "Run Check" job state --------------------------------
    # A manual run used to execute INSIDE the HTTP request. One report can
    # legitimately take minutes (URL 90s each, SSH 30s connect + 4x60s of
    # commands, Oracle 10s connect + several 60s queries), which pinned one
    # of the eight IIS workers for the whole time and could outlive the
    # requestTimeout=600 in web.config. The run is now handed to a detached
    # process and these columns are how the UI follows it.
    #
    # There is at most ONE manual run per report in flight - the same thing
    # the pre-existing cooldown already assumed - so the state lives on the
    # report rather than in a separate jobs table.
    #
    #   manual_run_state:     queued | running | done | failed | (NULL = never run)
    #   manual_run_heartbeat: stamped every 30s by the detached process, so a
    #                         job whose process was killed can be recognised
    #                         as dead instead of showing "running" for ever.
    manual_run_state      = Column(String(20))
    manual_run_started_at = Column(DateTime)
    manual_run_by         = Column(Integer, ForeignKey('users.id'))
    manual_run_message    = Column(Text)
    manual_run_heartbeat  = Column(DateTime)

    # Execution ownership is independent from the scheduled slot. UTC is
    # used for leases; existing schedule/display timestamps remain local.
    run_token = Column(String(36))
    run_lease_until = Column(DateTime)
    config_version = Column(Integer, nullable=False, default=0, server_default='0')
    last_notification_status = Column(String(20))
    last_notification_at = Column(DateTime)

    # Relationships - passive_deletes lets the DB-side ON DELETE CASCADE
    # do the heavy lifting instead of Python-side per-row deletes.
    tower             = relationship("ApplicationTower",        back_populates="reports")
    url_monitors      = relationship("URLMonitor",              back_populates="report",
                                     cascade="all, delete-orphan", passive_deletes=True)
    server_monitors   = relationship("ServerMonitor",           back_populates="report",
                                     cascade="all, delete-orphan", passive_deletes=True)
    database_monitors = relationship("DatabaseMonitor",         back_populates="report",
                                     cascade="all, delete-orphan", passive_deletes=True)
    email_config      = relationship("EmailNotificationConfig", back_populates="report",
                                     uselist=False,
                                     cascade="all, delete-orphan", passive_deletes=True)
    executions        = relationship("HealthCheckExecution",    back_populates="report",
                                     cascade="all, delete-orphan", passive_deletes=True)


# ---------------------------------------------------------------------------
# Monitor targets
# ---------------------------------------------------------------------------

class URLMonitor(Base):
    __tablename__ = 'url_monitors'

    __table_args__ = (
        Index('ix_url_monitor_report_id', 'report_id'),
    )

    id                   = Column(Integer, primary_key=True)
    report_id            = Column(Integer, ForeignKey('health_check_reports.id', ondelete='CASCADE'))
    name                 = Column(String(100), nullable=False)
    url                  = Column(String(500), nullable=False)
    expected_status_code = Column(Integer, default=200)
    timeout_seconds      = Column(Integer, default=30)
    created_at           = Column(DateTime, default=func.now())

    report = relationship("HealthCheckReport", back_populates="url_monitors")


class ServerMonitor(Base):
    __tablename__ = 'server_monitors'

    __table_args__ = (
        Index('ix_server_monitor_report_id', 'report_id'),
    )

    id                    = Column(Integer, primary_key=True)
    report_id             = Column(Integer, ForeignKey('health_check_reports.id', ondelete='CASCADE'))
    server_type           = Column(String(20))    # windows | aix | linux
    hostname              = Column(String(100), nullable=False)
    username              = Column(String(50))
    password              = Column(String(500))   # Encrypted at rest
    port                  = Column(Integer, default=22)
    processes_to_monitor  = Column(Text)          # Comma-separated process names
    created_at            = Column(DateTime, default=func.now())

    report = relationship("HealthCheckReport", back_populates="server_monitors")


class DatabaseMonitor(Base):
    __tablename__ = 'database_monitors'

    __table_args__ = (
        Index('ix_database_monitor_report_id', 'report_id'),
    )

    id            = Column(Integer, primary_key=True)
    report_id     = Column(Integer, ForeignKey('health_check_reports.id', ondelete='CASCADE'))
    database_type = Column(String(20))    # oracle | mssql
    host          = Column(String(100), nullable=False)
    port          = Column(Integer)
    database_name = Column(String(100))
    username      = Column(String(50))
    password      = Column(String(500))   # Encrypted at rest
    created_at    = Column(DateTime, default=func.now())

    report = relationship("HealthCheckReport", back_populates="database_monitors")


# ---------------------------------------------------------------------------
# Email notification config
# ---------------------------------------------------------------------------

class EmailNotificationConfig(Base):
    __tablename__ = 'email_notification_configs'

    __table_args__ = (
        Index('ix_email_config_report_id', 'report_id'),
    )

    id                   = Column(Integer, primary_key=True)
    report_id            = Column(Integer, ForeignKey('health_check_reports.id', ondelete='CASCADE'))
    recipients           = Column(Text)           # Comma-separated emails
    send_summary_reports = Column(Boolean, default=True)
    send_failure_alerts  = Column(Boolean, default=True)
    created_at           = Column(DateTime, default=func.now())

    report = relationship("HealthCheckReport", back_populates="email_config")


# ---------------------------------------------------------------------------
# Execution history - every run is persisted here for audit and trending
# ---------------------------------------------------------------------------

class HealthCheckExecution(Base):
    __tablename__ = 'health_check_executions'

    __table_args__ = (
        # Retention purge filters by executed_at; reporting filters by report_id.
        Index('ix_execution_executed_at',     'executed_at'),
        Index('ix_execution_report_id',       'report_id'),
        Index('ix_execution_report_executed', 'report_id', 'executed_at'),  # trending
    )

    id             = Column(Integer, primary_key=True)
    report_id      = Column(Integer, ForeignKey('health_check_reports.id', ondelete='CASCADE'))
    executed_at    = Column(DateTime, default=func.now())
    executed_by    = Column(Integer, ForeignKey('users.id'))  # NULL for scheduled runs
    overall_status = Column(String(20))   # healthy | warning | failed
    overall_score  = Column(Float)        # 0-100

    url_results      = Column(JSON)
    server_results   = Column(JSON)
    database_results = Column(JSON)

    execution_time_seconds = Column(Float)

    report = relationship("HealthCheckReport", back_populates="executions")


# ---------------------------------------------------------------------------
# NOTE: HealthCheckHistory is retained for reference but currently unused.
# If per-target history trending is not required, this table and all
# references to it (including the delete in routes.delete_tower) can be
# safely removed in a future migration.
# ---------------------------------------------------------------------------

class HealthCheckHistory(Base):
    __tablename__ = 'health_check_history'

    __table_args__ = (
        Index('ix_history_report_id',  'report_id'),
        Index('ix_history_checked_at', 'checked_at'),
    )

    id               = Column(Integer, primary_key=True)
    report_id        = Column(Integer, ForeignKey('health_check_reports.id', ondelete='CASCADE'))
    check_type       = Column(String(20))     # url | server | database
    target_name      = Column(String(100))
    status           = Column(String(20))     # success | warning | failed
    response_time_ms = Column(Float)
    error_message    = Column(Text)
    checked_at       = Column(DateTime, default=func.now())
    check_metadata   = Column(JSON)


class HealthNotification(Base):
    """Durable email outbox; payload survives execution-history retention."""
    __tablename__ = 'health_notification_outbox'
    id = Column(String(36), primary_key=True)
    report_id = Column(Integer, ForeignKey('health_check_reports.id', ondelete='CASCADE'), nullable=False)
    created_at = Column(DateTime, nullable=False)
    state = Column(String(20), nullable=False, default='pending')
    attempts = Column(Integer, nullable=False, default=0)
    next_attempt_at = Column(DateTime, nullable=False, index=True)
    lease_until = Column(DateTime)
    owner_token = Column(String(36))
    sent_at = Column(DateTime)
    last_error = Column(Text)
    recipients = Column(JSON, nullable=False)
    message = Column(Text, nullable=False)


class HealthMonitorHeartbeat(Base):
    __tablename__ = 'health_monitor_heartbeat'
    name = Column(String(40), primary_key=True)
    last_success_at = Column(DateTime)
    details = Column(JSON)
