from flask import render_template, redirect, url_for, flash, request, jsonify
from datetime import datetime
from database import get_db_session
from auth import get_current_user, require_auth
from modules.mimp_report.models import (
    MIMPReport,
    MIMPApplicationTower,
    MIMPApplication,
    MIMPApplicationStatus,
)
from modules.mimp_report.crypto import encrypt_secret
from modules.mimp_report.probes import sanitise_service_name
from . import mimp_report_bp
from modules.mimp_report.scheduler import (schedule_mimp_reports,
                                            scheduled_next_run)
import logging

logger = logging.getLogger(__name__)


# Helpers

def _to_int_or_none(raw):
    """Form fields come as strings - turn empty/blank into None for nullable cols."""
    if raw is None:
        return None
    raw = str(raw).strip()
    if raw == "":
        return None
    try:
        return int(raw)
    except ValueError:
        return None


def _to_str_or_none(raw):
    if raw is None:
        return None
    raw = str(raw).strip()
    return raw or None


def _collect_app_fields_from_form(form, *, for_edit=False):
    """
    Pull all MIMPApplication fields from a request.form into a dict.
    Encrypts passwords. For edit, missing password fields mean
    'don't change' - caller should handle that by checking the dict key.

    Raises ValueError if server_service_name contains characters that are
    unsafe to embed in the remote SSH / PowerShell service check (see
    probes.sanitise_service_name). Callers surface this as a form error.
    """
    data = {
        "name":                _to_str_or_none(form.get("name")),
        "url":                 _to_str_or_none(form.get("url")),

        # Server (optional)
        "server_type":         _to_str_or_none(form.get("server_type")),
        "server_hostname":     _to_str_or_none(form.get("server_hostname")),
        "server_port":         _to_int_or_none(form.get("server_port")),
        "server_username":     _to_str_or_none(form.get("server_username")),
        "server_service_name": _to_str_or_none(form.get("server_service_name")),

        # Database (optional)
        "db_type":             _to_str_or_none(form.get("db_type")),
        "db_host":             _to_str_or_none(form.get("db_host")),
        "db_port":             _to_int_or_none(form.get("db_port")),
        "db_name":             _to_str_or_none(form.get("db_name")),
        "db_username":         _to_str_or_none(form.get("db_username")),
    }

    # The service name ends up inside a remote shell / PowerShell command on
    # the monitored server - reject anything with metacharacters at the door.
    if data["server_service_name"]:
        data["server_service_name"] = sanitise_service_name(
            data["server_service_name"]
        )

    # Tower id only on create
    if not for_edit:
        data["tower_id"] = _to_int_or_none(form.get("tower_id"))

    # Passwords - only set if a value was actually supplied.
    server_pw = form.get("server_password")
    if server_pw is not None and server_pw != "":
        data["server_password"] = encrypt_secret(server_pw)
    elif not for_edit:
        # On create, store None for an empty password field.
        data["server_password"] = None

    db_pw = form.get("db_password")
    if db_pw is not None and db_pw != "":
        data["db_password"] = encrypt_secret(db_pw)
    elif not for_edit:
        data["db_password"] = None

    return data


# Index, dashboard, manage_reports, create/edit/delete report - UNCHANGED
# (kept verbatim from the working version)

@mimp_report_bp.route('/')
@require_auth()
def index():
    user = get_current_user()
    db_session = get_db_session()
    try:
        reports = db_session.query(MIMPReport).order_by(
            MIMPReport.start_time.desc()
        ).all()

        reports_data = []
        for report in reports:
            now = datetime.now()

            last_4_runs = db_session.query(MIMPApplicationStatus.timestamp).filter(
                MIMPApplicationStatus.report_id == report.id
            ).distinct().order_by(
                MIMPApplicationStatus.timestamp.desc()
            ).limit(4).all()

            last_runs = [run[0] for run in last_4_runs]

            # The scheduler's own answer, read from the report row - NOT a
            # second copy of the scheduling maths. This page used to
            # recompute it from the newest status timestamp, which meant it
            # showed a "next run" that moved every time somebody edited a
            # status by hand and disagreed with what the scheduler would
            # actually do. See the note at the top of scheduler.py.
            next_run = scheduled_next_run(report, now)

            reports_data.append({
                'report':    report,
                'last_runs': last_runs,
                'next_run':  next_run,
            })

        return render_template(
            'mimp_report/index.html',
            user=user, reports_data=reports_data,
        )
    finally:
        db_session.close()


@mimp_report_bp.route('/dashboard/<int:report_id>')
@require_auth()
def dashboard(report_id):
    user = get_current_user()
    db_session = get_db_session()
    try:
        report = db_session.query(MIMPReport).filter_by(id=report_id).first()
        if not report:
            flash('Report not found', 'error')
            return redirect(url_for('mimp_report.index'))

        towers = db_session.query(MIMPApplicationTower).filter_by(
            is_active=True
        ).all()

        timestamps_query = db_session.query(
            MIMPApplicationStatus.timestamp
        ).filter(
            MIMPApplicationStatus.report_id == report_id
        ).distinct().order_by(MIMPApplicationStatus.timestamp.desc()).limit(10).all()

        time_columns = []
        seen = set()
        for ts in timestamps_query:
            ts_value = ts[0]
            ts_key = ts_value.strftime('%Y-%m-%d %H:%M:%S')
            if ts_key not in seen:
                time_columns.append(ts_value)
                seen.add(ts_key)

        time_columns = time_columns[:5]
        time_columns.reverse()

        # Fetch all apps and all visible statuses up front (2 queries) instead
        # of one query per tower x application x time column.
        apps_by_tower = {}
        for app in db_session.query(MIMPApplication).filter_by(is_active=True).all():
            apps_by_tower.setdefault(app.tower_id, []).append(app)

        # Ascending id order means the highest id per (app, timestamp) wins,
        # matching the previous .order_by(id.desc()).first() per cell.
        status_by_app_time = {}
        if time_columns:
            for s in db_session.query(MIMPApplicationStatus).filter(
                MIMPApplicationStatus.report_id == report_id,
                MIMPApplicationStatus.timestamp.in_(time_columns),
            ).order_by(MIMPApplicationStatus.id).all():
                status_by_app_time[(s.application_id, s.timestamp)] = s

        tower_data = []
        for tower in towers:
            apps_status = [
                {
                    'application': app,
                    'statuses': {
                        ts: status_by_app_time.get((app.id, ts))
                        for ts in time_columns
                    },
                }
                for app in apps_by_tower.get(tower.id, [])
            ]
            tower_data.append({
                'tower':        tower,
                'applications': apps_status,
            })

        now = datetime.now()
        # One source of truth - see the note in index().
        next_run = scheduled_next_run(report, now)

        return render_template(
            'mimp_report/dashboard.html',
            user=user, report=report,
            tower_data=tower_data, time_columns=time_columns,
            next_run=next_run,
        )
    finally:
        db_session.close()


@mimp_report_bp.route('/manage-reports')
def manage_reports():
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('mimp_report.index'))

    db_session = get_db_session()
    try:
        reports = db_session.query(MIMPReport).all()
        return render_template(
            'mimp_report/manage_reports.html',
            user=user, reports=reports,
        )
    finally:
        db_session.close()


@mimp_report_bp.route('/create-report', methods=['GET', 'POST'])
def create_report():
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('mimp_report.index'))

    if request.method == 'POST':
        db_session = get_db_session()
        try:
            report = MIMPReport(
                name=request.form['name'],
                description=request.form.get('description'),
                start_time=datetime.strptime(
                    request.form['start_time'], '%Y-%m-%dT%H:%M'
                ),
                end_time=datetime.strptime(
                    request.form['end_time'], '%Y-%m-%dT%H:%M'
                ),
                frequency_minutes=max(1, int(request.form['frequency_minutes'])),
                email_list=request.form.get('email_list'),
                created_by=user.id,
            )
            db_session.add(report)
            db_session.commit()
            schedule_mimp_reports()
            flash('MIMP report created successfully', 'success')
            return redirect(url_for('mimp_report.index'))
        except Exception as e:
            logger.error(f"Error creating report: {e}")
            flash('Error creating report', 'error')
            db_session.rollback()
        finally:
            db_session.close()

    return render_template('mimp_report/create_report.html', user=user)


@mimp_report_bp.route('/edit-report/<int:report_id>', methods=['GET', 'POST'])
def edit_report(report_id):
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('mimp_report.index'))

    db_session = get_db_session()
    try:
        report = db_session.query(MIMPReport).filter_by(id=report_id).first()
        if not report:
            flash('Report not found', 'error')
            return redirect(url_for('mimp_report.index'))

        if request.method == 'POST':
            report.name = request.form['name']
            report.description = request.form.get('description')
            report.start_time = datetime.strptime(
                request.form['start_time'], '%Y-%m-%dT%H:%M'
            )
            report.end_time = datetime.strptime(
                request.form['end_time'], '%Y-%m-%dT%H:%M'
            )
            report.frequency_minutes = max(
                1, int(request.form['frequency_minutes']))
            report.email_list = request.form.get('email_list')
            report.is_active = 'is_active' in request.form

            db_session.commit()
            schedule_mimp_reports()
            flash('Report updated successfully', 'success')
            return redirect(url_for('mimp_report.index'))

        return render_template(
            'mimp_report/edit_report.html', user=user, report=report,
        )
    finally:
        db_session.close()


@mimp_report_bp.route('/delete-report/<int:report_id>', methods=['POST'])
def delete_report(report_id):
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('mimp_report.index'))

    db_session = get_db_session()
    try:
        report = db_session.query(MIMPReport).filter_by(id=report_id).first()
        if report:
            db_session.delete(report)
            db_session.commit()
            schedule_mimp_reports()
            flash('Report deleted successfully', 'success')
        else:
            flash('Report not found', 'error')
    except Exception as e:
        logger.error(f"Error deleting report: {e}")
        flash('Error deleting report', 'error')
        db_session.rollback()
    finally:
        db_session.close()

    return redirect(url_for('mimp_report.index'))


# Tower management - UNCHANGED

@mimp_report_bp.route('/manage-applications')
def manage_applications():
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('mimp_report.index'))

    db_session = get_db_session()
    try:
        towers = db_session.query(MIMPApplicationTower).all()
        return render_template(
            'mimp_report/manage_applications.html',
            user=user, towers=towers,
        )
    finally:
        db_session.close()


@mimp_report_bp.route('/create-tower', methods=['POST'])
def create_tower():
    user = get_current_user()
    if not user or user.role != 'admin':
        return jsonify({'success': False, 'message': 'Admin access required'}), 403

    db_session = get_db_session()
    try:
        tower = MIMPApplicationTower(
            name=request.form['name'],
            description=request.form.get('description'),
            created_by=user.id,
        )
        db_session.add(tower)
        db_session.commit()
        return jsonify({'success': True, 'message': 'Tower created successfully'})
    except Exception as e:
        logger.error(f"Error creating tower: {e}")
        db_session.rollback()
        return jsonify({'success': False, 'message': 'Error creating tower'}), 500
    finally:
        db_session.close()


@mimp_report_bp.route('/delete-tower/<int:tower_id>', methods=['POST'])
def delete_tower(tower_id):
    user = get_current_user()
    if not user or user.role != 'admin':
        return jsonify({'success': False, 'message': 'Admin access required'}), 403

    db_session = get_db_session()
    try:
        tower = db_session.query(MIMPApplicationTower).filter_by(id=tower_id).first()
        if tower:
            db_session.delete(tower)
            db_session.commit()
            return jsonify({'success': True, 'message': 'Tower deleted successfully'})
        return jsonify({'success': False, 'message': 'Tower not found'}), 404
    except Exception as e:
        logger.error(f"Error deleting tower: {e}")
        db_session.rollback()
        return jsonify({'success': False, 'message': 'Error deleting tower'}), 500
    finally:
        db_session.close()


# Application management - CHANGED to handle server + db config

@mimp_report_bp.route('/create-application', methods=['POST'])
def create_application():
    """
    Create a new application under a tower.

    The form now carries optional server and database probe configuration.
    Passwords are encrypted before persistence (see crypto.py).
    """
    user = get_current_user()
    if not user or user.role != 'admin':
        return jsonify({'success': False, 'message': 'Admin access required'}), 403

    db_session = get_db_session()
    try:
        data = _collect_app_fields_from_form(request.form, for_edit=False)

        if not data["name"] or not data["url"] or not data.get("tower_id"):
            return jsonify({
                'success': False,
                'message': 'Application name, URL and tower are required',
            }), 400

        app = MIMPApplication(
            tower_id            = data["tower_id"],
            name                = data["name"],
            url                 = data["url"],
            server_type         = data["server_type"],
            server_hostname     = data["server_hostname"],
            server_port         = data["server_port"],
            server_username     = data["server_username"],
            server_password     = data["server_password"],
            server_service_name = data["server_service_name"],
            db_type             = data["db_type"],
            db_host             = data["db_host"],
            db_port             = data["db_port"],
            db_name             = data["db_name"],
            db_username         = data["db_username"],
            db_password         = data["db_password"],
            created_by          = user.id,
        )
        db_session.add(app)
        db_session.commit()
        return jsonify({
            'success': True,
            'message': 'Application created successfully',
        })

    except ValueError as ve:
        # Bad form input (e.g. unsafe service name) - client error, not a bug.
        db_session.rollback()
        return jsonify({'success': False, 'message': str(ve)}), 400
    except Exception:
        # The exception text can carry database, driver and path detail.
        # It goes to the log; the caller gets a generic message.
        logger.exception("Error creating application")
        db_session.rollback()
        return jsonify({
            'success': False,
            'message': 'Error creating application - see the application log.',
        }), 500
    finally:
        db_session.close()


@mimp_report_bp.route('/edit-application/<int:app_id>', methods=['GET', 'POST'])
def edit_application(app_id):
    """
    Full-page edit screen - chosen over a modal because the new
    server / DB sections make the form too tall for a comfortable modal.

    Empty password fields on submit are interpreted as "no change" so
    admins don't have to re-type credentials on every minor edit.
    """
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('mimp_report.index'))

    db_session = get_db_session()
    try:
        app = db_session.query(MIMPApplication).filter_by(id=app_id).first()
        if not app:
            flash('Application not found', 'error')
            return redirect(url_for('mimp_report.manage_applications'))

        if request.method == 'POST':
            try:
                data = _collect_app_fields_from_form(request.form, for_edit=True)
            except ValueError as ve:
                # Bad form input (e.g. unsafe service name) - show it on the form.
                flash(str(ve), 'error')
                return render_template(
                    'mimp_report/edit_application.html',
                    user=user, app=app,
                )

            if not data["name"] or not data["url"]:
                flash('Application name and URL are required', 'error')
                return render_template(
                    'mimp_report/edit_application.html',
                    user=user, app=app,
                )

            app.name                = data["name"]
            app.url                 = data["url"]
            app.server_type         = data["server_type"]
            app.server_hostname     = data["server_hostname"]
            app.server_port         = data["server_port"]
            app.server_username     = data["server_username"]
            app.server_service_name = data["server_service_name"]
            app.db_type             = data["db_type"]
            app.db_host             = data["db_host"]
            app.db_port             = data["db_port"]
            app.db_name             = data["db_name"]
            app.db_username         = data["db_username"]

            # Passwords: only overwrite if the admin actually entered something.
            if "server_password" in data:
                app.server_password = data["server_password"]
            if "db_password" in data:
                app.db_password = data["db_password"]

            try:
                db_session.commit()
                flash('Application updated successfully', 'success')
                return redirect(url_for('mimp_report.manage_applications'))
            except Exception:
                logger.exception("Error updating application")
                db_session.rollback()
                flash('Error updating application - see the application log.',
                      'error')

        return render_template(
            'mimp_report/edit_application.html',
            user=user, app=app,
        )
    finally:
        db_session.close()


@mimp_report_bp.route('/delete-application/<int:app_id>', methods=['POST'])
def delete_application(app_id):
    user = get_current_user()
    if not user or user.role != 'admin':
        return jsonify({'success': False, 'message': 'Admin access required'}), 403

    db_session = get_db_session()
    try:
        app = db_session.query(MIMPApplication).filter_by(id=app_id).first()
        if app:
            db_session.delete(app)
            db_session.commit()
            return jsonify({
                'success': True, 'message': 'Application deleted successfully',
            })
        return jsonify({'success': False, 'message': 'Application not found'}), 404
    except Exception as e:
        logger.error(f"Error deleting application: {e}")
        db_session.rollback()
        return jsonify({
            'success': False, 'message': 'Error deleting application',
        }), 500
    finally:
        db_session.close()


# Manual status update - UNCHANGED

# The set of verdicts the rest of the module understands. The dashboard maps
# the status straight onto a CSS class and the email renderer looks it up in a
# palette, so an unrecognised value renders as an unstyled cell everywhere.
# The column is VARCHAR(20), which SQL Server enforces and SQLite does not -
# so an over-long value would work in test and fail in production.
VALID_STATUSES = frozenset({'good', 'warning', 'down'})

# Ceiling for the free-text note. Generous for a real operator comment, but it
# stops an unbounded body being persisted and then re-rendered on every
# dashboard load.
MAX_NOTE_CHARS = 2000


@mimp_report_bp.route('/update-status', methods=['POST'])
def update_status():
    user = get_current_user()
    if not user:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    db_session = get_db_session()
    try:
        data = request.get_json(silent=True) or {}

        # Validate before writing. Previously application_id / report_id /
        # status went into the row exactly as posted, so a malformed or
        # hand-crafted request could attach an observation to an application
        # that is not in the report - or store a status value nothing renders.
        try:
            application_id = int(data['application_id'])
            report_id = int(data['report_id'])
        except (KeyError, TypeError, ValueError):
            return jsonify({
                'success': False,
                'message': 'application_id and report_id are required',
            }), 400

        status = str(data.get('status') or '').strip().lower()
        if status not in VALID_STATUSES:
            return jsonify({
                'success': False,
                'message': 'Status must be one of: %s' % ', '.join(sorted(VALID_STATUSES)),
            }), 400

        note = data.get('note')
        if note is not None:
            note = str(note)[:MAX_NOTE_CHARS]

        # Both parents must exist - an orphaned status row would never be
        # displayed and would survive the report-scoped cascade delete.
        if not db_session.query(MIMPApplication.id).filter_by(
                id=application_id).first():
            return jsonify({'success': False,
                            'message': 'Application not found'}), 404
        if not db_session.query(MIMPReport.id).filter_by(
                id=report_id).first():
            return jsonify({'success': False,
                            'message': 'Report not found'}), 404

        now = datetime.now()
        timestamp = now.replace(second=0, microsecond=0)

        status_record = MIMPApplicationStatus(
            application_id  = application_id,
            report_id       = report_id,
            status          = status,
            note            = note,
            updated_by      = user.id,
            updated_by_name = user.username,
            timestamp       = timestamp,
            updated_at      = timestamp,
        )
        db_session.add(status_record)
        db_session.commit()
        return jsonify({'success': True, 'message': 'Status updated successfully'})
    except Exception as e:
        logger.error(f"Error updating status: {e}")
        db_session.rollback()
        return jsonify({'success': False, 'message': 'Error updating status'}), 500
    finally:
        db_session.close()


# About  (public - explains the module to end users and the support team)

@mimp_report_bp.route('/about')
def about():
    user = get_current_user()
    return render_template('mimp_report/about.html', user=user)