from flask import Blueprint

mimp_report_bp = Blueprint('mimp_report', __name__, template_folder='templates')

from . import routes
