"""
modules/mimp_report/email_utils.py
Professional NPG-themed HTML email for MIMP storm-day status reports.

Design language is intentionally aligned with the
application_health_check email so MIMP looks like a sibling product
rather than a different application:

    * Header  : solid NPG navy with status / count / timestamp chips,
                plus an NPG-red accent strip beneath it
    * Ribbon  : status-coloured banner with one-line summary
    * Stats   : Healthy / Warning / Down counts as a 3-column strip
    * Towers  : grouped section per ApplicationTower
    * Cards   : one card per app - real left-accent cell, status pill,
                per-layer probe note in a tinted detail box
    * Footer  : NPG red bar

Outlook compatibility
Outlook for Windows renders with Word's HTML engine, which ignores most
modern CSS. The previous version of this email used `<div>` structure,
`border-left` accents, `text-transform`, `opacity`, `border-radius` and
`<span style="display:inline-block">` pills - Word drops or mis-renders
all of those, so the accent bars vanished, labels stayed lower-case and
spacing collapsed. This version follows the same rules as the health
check email:

  1. Layout is 100% nested <table>s - no <div>s for structure.
  2. State is a tint fill plus a hairline on ALL FOUR sides - never a
     coloured stripe down one edge (matches the web theme).
  3. Status pills are tiny <table>s, not inline-block spans.
  4. Labels are PRE-UPPERCASED in Python (Word ignores text-transform).
  5. Solid colours only - no gradients, no rgba/opacity. Translucent
     chips are pre-blended to a flat hex over the navy base.
  6. `bgcolor` attributes accompany every background-color.
  7. `mso-line-height-rule:exactly` + explicit pixel line-heights.
  8. Fixed 600px container with an [if mso] ghost table.
A multipart/alternative plain-text part is included for completeness and
deliverability.
"""

from __future__ import annotations

import logging
import os
import smtplib
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

logger = logging.getLogger(__name__)


# SMTP (kept identical so deployment doesn't change)

_SMTP_SERVER = os.environ.get('SMTP_SERVER', 'mail876.northernpowergrid.com')
_SMTP_PORT   = int(os.environ.get('SMTP_PORT', '25'))
_EMAIL_FROM  = os.environ.get('MIMP_EMAIL_FROM',
                              'NPgAppAssist@northernpowergrid.com')


# NPG palette (self-contained)

from email_theme import (                             # noqa: E402
    NPG_RED as _NPG_RED, NPG_RED_DARK as _NPG_RED_DARK, NPG_DARK as _NPG_DARK,
    NPG_LIGHT as _NPG_LIGHT, NPG_BORDER as _NPG_BORDER, NPG_TEXT as _NPG_TEXT,
    NPG_TEXT_MUTED as _NPG_TEXT_MUTED, CHIP_BG as _CHIP_BG,
    FONT as _FONT,
)

_CHIP_TEXT         = '#FFFFFF'

# Masthead and footer come from the shared NPG theme (email_theme.py): a flat
# maroon banner closed by a graphite rule, and a graphite footer band. Flat, not
# a gradient - the Word engine behind desktop Outlook cannot render one.
# Masthead (header/footer) comes from the shared NPG theme (email_theme.py).
from email_theme import hero_rows, footer_rows

# Status palette - 'good' / 'warning' / 'down'.
_STATUS_PALETTE = {
    'good': {
        'border':      '#16A34A',
        'tint':        '#F0FDF4',
        'tint_border': '#BBF7D0',
        'pill_bg':     '#DCFCE7',
        'pill_fg':     '#15803D',
        'detail_fg':   '#166534',
        'label':       'HEALTHY',
    },
    'warning': {
        'border':      '#F59E0B',
        'tint':        '#FFFBEB',
        'tint_border': '#FDE68A',
        'pill_bg':     '#FEF3C7',
        'pill_fg':     '#92400E',
        'detail_fg':   '#92400E',
        'label':       'WARNING',
    },
    'down': {
        'border':      _NPG_RED,
        'tint':        '#FEF2F2',
        'tint_border': '#FECACA',
        'pill_bg':     '#FEE2E2',
        'pill_fg':     '#991B1B',
        'detail_fg':   '#991B1B',
        'label':       'DOWN',
    },
}


# Public entry point - signature unchanged

def send_mimp_email_report(report, status_data: list, check_time: datetime) -> None:
    """
    Send the HTML status report email for *report*.

    Args:
        report      : the MIMPReport row
        status_data : list of dicts {application, status, note}
                      produced by scheduler.run_mimp_check()
        check_time  : datetime of this run cycle
    """
    if not report.email_list:
        logger.warning(f"Report '{report.name}' has no email list - skipping email.")
        return

    recipients = [e.strip() for e in report.email_list.split(',') if e.strip()]
    if not recipients:
        logger.warning(f"Report '{report.name}' has empty email list - skipping email.")
        return

    # Reject anything that could forge headers. msg['To'] is built by joining
    # this list, and Python's compat32 email policy writes a header value
    # verbatim - so a stored recipient containing CR/LF would let whoever can
    # edit the report's email list inject Bcc/Reply-To or a second message
    # body. Same check notifications.py applies for health-check alerts.
    bad = [e for e in recipients if '\r' in e or '\n' in e or '@' not in e]
    if bad:
        logger.error(
            "Report '%s' has %d invalid recipient(s) in its email list - "
            "refusing to send. Fix the recipient list on the report.",
            report.name, len(bad),
        )
        return

    overall = _overall_status(status_data)

    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = (
            f"[MIMP] {_STATUS_PALETTE[overall]['label']} - "
            f"{report.name}  |  {check_time.strftime('%d %b %Y  %H:%M')}"
        )
        msg['From']       = _EMAIL_FROM
        msg['To']         = ', '.join(recipients)
        msg['X-Priority'] = '1' if overall == 'down' else '3'

        # Plain-text part first, HTML second (clients pick the richest they
        # can render; a text fallback also helps deliverability).
        text_body = _build_text_email(report, status_data, check_time, overall)
        html_body = _build_html_email(report, status_data, check_time, overall)
        msg.attach(MIMEText(text_body, 'plain', 'utf-8'))
        msg.attach(MIMEText(html_body, 'html', 'utf-8'))

        with smtplib.SMTP(_SMTP_SERVER, _SMTP_PORT, timeout=30) as server:
            server.send_message(msg)

        logger.info(
            f"MIMP report '{report.name}' sent to {len(recipients)} "
            f"recipient(s) ({overall.upper()})."
        )

    except smtplib.SMTPException as exc:
        logger.error(f"SMTP error sending MIMP email: {exc}")
    except Exception:
        logger.exception(f"Unexpected error sending MIMP email for report '{report.name}'.")


# Backward-compatible alias - older callers / tests may still use this name.
def generate_email_html(report, status_data, check_time):
    return _build_html_email(report, status_data, check_time,
                             _overall_status(status_data))


# Outlook-safe building blocks

def _status_badge(bg: str, fg: str, label: str) -> str:
    """A pill rendered as a tiny <table> (Outlook-safe; label pre-uppercased)."""
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
        f'style="display:inline-table;"><tr>'
        f'<td bgcolor="{bg}" style="background-color:{bg};padding:5px 12px;'
        f'font-family:{_FONT};font-size:11px;font-weight:bold;color:{fg};'
        f'mso-line-height-rule:exactly;line-height:14px;letter-spacing:1px;'
        f'border-collapse:separate;border-spacing:0;border-radius:20px;">{label}</td></tr></table>'
    )


def _stat_card(bg: str, big_fg: str, label_fg: str, value: int, label: str,
               border: str = _NPG_BORDER) -> str:
    """One Healthy/Warning/Down card in the stat strip - Outlook-safe."""
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
        f'width="100%" bgcolor="{bg}" style="background-color:{bg};'
        f'border:1px solid {border};border-collapse:separate;border-spacing:0;border-radius:10px;">'
        f'<tr><td align="center" style="padding:16px 12px;font-family:{_FONT};">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0">'
        f'<tr><td align="center" style="font-size:28px;font-weight:bold;color:{big_fg};'
        f'letter-spacing:-0.4px;mso-line-height-rule:exactly;line-height:32px;">{value}</td></tr>'
        f'<tr><td align="center" style="font-size:10px;font-weight:bold;color:{label_fg};'
        f'mso-line-height-rule:exactly;line-height:14px;letter-spacing:1px;padding-top:6px;">'
        f'{label}</td></tr></table>'
        f'</td></tr></table>'
    )


# HTML composition

def _build_html_email(report, status_data: list,
                      check_time: datetime, overall: str) -> str:
    """Assemble the complete Outlook-safe HTML document."""
    palette = _STATUS_PALETTE[overall]

    healthy_count = sum(1 for s in status_data if s['status'] == 'good')
    warning_count = sum(1 for s in status_data if s['status'] == 'warning')
    down_count    = sum(1 for s in status_data if s['status'] == 'down')
    total_count   = len(status_data)

    by_tower = _group_by_tower(status_data)
    when_str = _fmt_dt(check_time)
    name_esc = _esc(report.name)

    # Ribbon copy (titles pre-cased; Word ignores text-transform)
    if overall == 'down':
        ribbon_title = 'Critical issues detected &mdash; immediate attention required'
        problems = _summarise_problems(status_data)
        ribbon_body = (
            f"<strong>{name_esc}</strong> reports <strong>DOWN</strong> status as of "
            f"{when_str}. Problem applications: {problems or 'see breakdown below'}."
        )
    elif overall == 'warning':
        ribbon_title = 'Some applications report warnings &mdash; please review'
        problems = _summarise_problems(status_data)
        ribbon_body = (
            f"<strong>{name_esc}</strong> reports <strong>WARNING</strong> status as of "
            f"{when_str}. Issues: {problems or 'see breakdown below'}."
        )
    else:
        ribbon_title = 'All applications healthy &mdash; no action required'
        ribbon_body = (
            f"All {total_count} monitored application{'s' if total_count != 1 else ''} for "
            f"<strong>{name_esc}</strong> are healthy as of {when_str}."
        )

    # Tower sections
    if by_tower:
        sections_html = ''.join(
            _render_tower_section(tower_name, items) for tower_name, items in by_tower
        )
    else:
        sections_html = (
            f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
            f'<tr><td align="center" style="padding:24px 0;font-family:{_FONT};'
            f'font-size:14px;color:{_NPG_TEXT_MUTED};mso-line-height-rule:exactly;line-height:18px;">'
            f'No applications were checked in this run.</td></tr></table>'
        )

    # Header chips
    badge_status = _status_badge(palette['pill_bg'], palette['pill_fg'], palette['label'])
    badge_count  = _status_badge(_CHIP_BG, _CHIP_TEXT,
                                 f"{total_count} APP{'S' if total_count != 1 else ''} CHECKED")
    badge_when   = _status_badge(_CHIP_BG, _CHIP_TEXT, when_str.upper())

    hero = hero_rows('NPG APP ASSIST &middot; MIMP STATUS REPORT', name_esc,
                     [badge_status, badge_count, badge_when])
    footer = footer_rows('MIMP Storm-Day Monitoring')

    return f"""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>NPG MIMP Status Report &mdash; {name_esc}</title>
  <!--[if mso]>
  <xml>
    <o:OfficeDocumentSettings>
      <o:PixelsPerInch>96</o:PixelsPerInch>
      <o:AllowPNG/>
    </o:OfficeDocumentSettings>
  </xml>
  <style type="text/css">
    table {{border-collapse:collapse;}}
    td    {{mso-line-height-rule:exactly;}}
  </style>
  <![endif]-->
  <style type="text/css">
    body, table, td {{ -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }}
    table {{ border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }}
    img   {{ -ms-interpolation-mode:bicubic; border:0; outline:none; text-decoration:none; }}
    a     {{ color:{_NPG_RED}; text-decoration:none; }}
    @media only screen and (max-width:620px) {{
      .container {{ width:100% !important; }}
      .px-32     {{ padding-left:18px !important; padding-right:18px !important; }}
      .stat-cell {{ display:block !important; width:100% !important; padding:0 0 6px 0 !important; }}
    }}
  </style>
</head>
<body style="margin:0;padding:0;background-color:{_NPG_LIGHT};font-family:{_FONT};">
<!-- Preheader (hidden; shown in inbox preview) -->
<div style="display:none;font-size:1px;color:{_NPG_LIGHT};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
NPG MIMP Status Report &mdash; {name_esc} &mdash; {palette['label']} ({total_count} app{'s' if total_count != 1 else ''})
</div>

<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="{_NPG_LIGHT}" style="background-color:{_NPG_LIGHT};">
  <tr>
    <td align="center" style="padding:34px 16px 40px 16px;">

      <!--[if mso]>
      <table role="presentation" align="center" cellpadding="0" cellspacing="0" border="0" width="600">
      <tr><td>
      <![endif]-->

      <table role="presentation" class="container" cellpadding="0" cellspacing="0" border="0" width="600"
             style="width:600px;max-width:600px;background-color:#FFFFFF;border:1px solid {_NPG_BORDER};border-bottom-color:#C6D0DE;border-collapse:separate;border-spacing:0;border-radius:14px;">

        <!-- ========== Header (shared NPG theme: flat maroon masthead) ========== -->
        {hero}

        <!-- ========== Alert ribbon (accent rendered as a cell) ========== -->
        <tr>
          <td class="px-32" style="padding:24px 32px;">
            <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"
                   bgcolor="{palette['tint']}"
                   style="background-color:{palette['tint']};border:1px solid {palette['tint_border']};border-collapse:separate;border-spacing:0;border-radius:10px;">
              <tr>
                <td style="padding:14px 16px;font-family:{_FONT};color:{palette['detail_fg']};">
                  <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                    <tr>
                      <td style="font-size:13px;font-weight:bold;mso-line-height-rule:exactly;line-height:18px;
                                 padding-bottom:4px;color:{palette['detail_fg']};">{ribbon_title}</td>
                    </tr>
                    <tr>
                      <td style="font-size:13px;mso-line-height-rule:exactly;line-height:20px;
                                 color:{palette['detail_fg']};">{ribbon_body}</td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>

        <!-- ========== Stat strip (3 columns, mobile-collapsing) ========== -->
        <tr>
          <td class="px-32" style="padding:20px 32px;">
            <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
              <tr>
                <td class="stat-cell" width="33%" valign="top" style="padding-right:6px;">
                  {_stat_card('#F0FDF4', '#15803D', '#166534', healthy_count, 'HEALTHY')}
                </td>
                <td class="stat-cell" width="34%" valign="top" style="padding:0 3px;">
                  {_stat_card('#FFFBEB', '#B45309', '#92400E', warning_count, 'WARNING')}
                </td>
                <td class="stat-cell" width="33%" valign="top" style="padding-left:6px;">
                  {_stat_card('#FEF2F2', _NPG_RED, '#991B1B', down_count, 'DOWN')}
                </td>
              </tr>
            </table>
          </td>
        </tr>

        <!-- ========== Tower / app sections ========== -->
        <tr>
          <td class="px-32" style="padding:24px 32px;">
            {sections_html}
            <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"
                   style="border-top:1px solid {_NPG_LIGHT};">
              <tr>
                <td style="padding-top:14px;font-family:{_FONT};font-size:12px;color:{_NPG_TEXT_MUTED};
                           mso-line-height-rule:exactly;line-height:18px;">
                  <strong style="color:{_NPG_TEXT};">Monitoring window:</strong>
                  {_fmt_dt(report.start_time)} &ndash; {_fmt_dt(report.end_time)}
                  &nbsp;&middot;&nbsp;
                  <strong style="color:{_NPG_TEXT};">Frequency:</strong>
                  every {report.frequency_minutes} min
                </td>
              </tr>
            </table>
          </td>
        </tr>

        <!-- ========== Footer (shared NPG theme) ========== -->
        {footer}

      </table>

      <!--[if mso]>
      </td></tr>
      </table>
      <![endif]-->

    </td>
  </tr>
</table>
</body>
</html>"""


# Section + card rendering (Outlook-safe)

def _render_tower_section(tower_name: str, items: list) -> str:
    """Render one tower section with all its application cards."""
    cards_html = ''.join(_render_app_card(item) for item in items)

    counts = {'good': 0, 'warning': 0, 'down': 0}
    for it in items:
        counts[it['status']] = counts.get(it['status'], 0) + 1

    bits = []
    if counts['good']:
        bits.append(f'<span style="color:#15803D;">{counts["good"]} healthy</span>')
    if counts['warning']:
        bits.append(f'<span style="color:#92400E;">{counts["warning"]} warning</span>')
    if counts['down']:
        bits.append(f'<span style="color:#991B1B;">{counts["down"]} down</span>')
    summary = ' &middot; '.join(bits) if bits else f'{len(items)} apps'

    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
        f'style="margin-bottom:18px;">'
        f'<tr><td style="border-bottom:1px solid {_NPG_DARK};padding-bottom:8px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"><tr>'
        f'<td style="font-family:{_FONT};font-size:13px;font-weight:bold;color:{_NPG_DARK};'
        f'letter-spacing:0.4px;mso-line-height-rule:exactly;line-height:17px;">{_esc(str(tower_name).upper())}</td>'
        f'<td align="right" style="font-family:{_FONT};font-size:11px;color:{_NPG_TEXT_MUTED};'
        f'font-weight:bold;mso-line-height-rule:exactly;line-height:15px;">{summary}</td>'
        f'</tr></table></td></tr>'
        f'<tr><td style="padding-top:12px;">{cards_html}</td></tr>'
        f'</table>'
    )


def _render_app_card(item: dict) -> str:
    """
    Render one application as a card with a real left-accent cell.

    `item['note']` is the pipe-separated per-layer probe summary, e.g.
        "URL good: HTTP 200 OK (412 ms) | Server good: ... | DB good: ..."
    We split on ' | ' so each layer renders on its own line.
    """
    app    = item['application']
    status = item['status']
    note   = item.get('note') or ''
    palette = _STATUS_PALETTE.get(status, _STATUS_PALETTE['good'])

    note_lines = [ln.strip() for ln in note.split(' | ') if ln.strip()]
    note_html = ''
    if note_lines:
        rows = ''
        for ln in note_lines:
            if ': ' in ln:
                label, rest = ln.split(': ', 1)
                rendered = (f'<strong style="color:{palette["detail_fg"]};">{_esc(label)}:</strong> '
                            f'{_esc(rest)}')
            else:
                rendered = _esc(ln)
            rows += (
                f'<tr><td style="padding:3px 0;font-family:{_FONT};font-size:12px;'
                f'color:{palette["detail_fg"]};mso-line-height-rule:exactly;line-height:17px;">'
                f'{rendered}</td></tr>'
            )
        note_html = (
            f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
            f'bgcolor="{palette["tint"]}" style="background-color:{palette["tint"]};'
            f'border:1px solid {palette["tint_border"]};border-collapse:separate;border-spacing:0;border-radius:10px;margin-top:8px;">'
            f'<tr><td style="padding:8px 12px;">'
            f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">{rows}</table>'
            f'</td></tr></table>'
        )

    subtitle_html = ''
    if getattr(app, 'url', None):
        subtitle_html = (
            f'<tr><td colspan="2" style="padding-top:4px;font-family:{_FONT};font-size:12px;'
            f'color:{_NPG_TEXT_MUTED};mso-line-height-rule:exactly;line-height:16px;">'
            f'{_esc(app.url)}</td></tr>'
        )

    badge = _status_badge(palette['pill_bg'], palette['pill_fg'], palette['label'])

    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
        f'bgcolor="{palette["tint"]}" style="background-color:{palette["tint"]};'
        f'border:1px solid {palette["tint_border"]};border-collapse:separate;border-spacing:0;border-radius:10px;'
        f'margin-bottom:8px;">'
        f'<tr>'
        f'<td style="padding:12px 14px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr>'
        f'<td style="font-family:{_FONT};font-size:14px;font-weight:bold;color:{_NPG_TEXT};'
        f'mso-line-height-rule:exactly;line-height:18px;">{_esc(app.name)}</td>'
        f'<td align="right" valign="top">{badge}</td>'
        f'</tr>'
        f'{subtitle_html}'
        f'</table>'
        f'{note_html}'
        f'</td></tr></table>'
    )


# Plain-text alternative

def _build_text_email(report, status_data: list,
                      check_time: datetime, overall: str) -> str:
    """A clean plain-text rendition for clients that prefer text."""
    label = _STATUS_PALETTE[overall]['label']
    lines = [
        'NPG MIMP STATUS REPORT',
        '=' * 50,
        f'Report   : {report.name}',
        f'Status   : {label}',
        f'Checked  : {_fmt_dt(check_time)}',
        f'Window   : {_fmt_dt(report.start_time)} - {_fmt_dt(report.end_time)}',
        f'Frequency: every {report.frequency_minutes} min',
        '',
    ]
    for tower_name, items in _group_by_tower(status_data):
        lines.append(f'{str(tower_name).upper()}')
        lines.append('-' * 50)
        for it in items:
            app = it['application']
            st  = _STATUS_PALETTE.get(it['status'], _STATUS_PALETTE['good'])['label']
            lines.append(f'  [{st}] {app.name}')
            if getattr(app, 'url', None):
                lines.append(f'         {app.url}')
            for ln in (it.get('note') or '').split(' | '):
                ln = ln.strip()
                if ln:
                    lines.append(f'         - {ln}')
        lines.append('')
    lines.append('NPG App Assist - MIMP Storm-Day Monitoring')
    lines.append('Generated automatically - Do not reply to this message')
    return '\n'.join(lines)


# Helpers

def _overall_status(status_data: list) -> str:
    """down > warning > good (worst-wins) for the report header."""
    if not status_data:
        return 'good'
    statuses = [s['status'] for s in status_data]
    if 'down' in statuses:
        return 'down'
    if 'warning' in statuses:
        return 'warning'
    return 'good'


def _group_by_tower(status_data: list):
    """
    Return list of (tower_name, [items]) preserving each app's tower
    relationship. Apps without a tower fall under 'Unassigned'.
    """
    grouped: dict[str, list] = {}
    order: list[str] = []
    for item in status_data:
        app = item['application']
        tower_name = (
            app.tower.name if getattr(app, 'tower', None) and app.tower
            else 'Unassigned'
        )
        if tower_name not in grouped:
            grouped[tower_name] = []
            order.append(tower_name)
        grouped[tower_name].append(item)

    return [(name, grouped[name]) for name in order]


def _summarise_problems(status_data: list) -> str:
    """Comma-separated list of problem app names for the ribbon."""
    down = [_esc(s['application'].name) for s in status_data if s['status'] == 'down']
    warn = [_esc(s['application'].name) for s in status_data if s['status'] == 'warning']
    parts = []
    if down:
        parts.append(f"DOWN: {', '.join(down)}")
    if warn:
        parts.append(f"WARNING: {', '.join(warn)}")
    return ' &middot; '.join(parts)


def _esc(text) -> str:
    """Minimal HTML escape - keeps & < > " safe."""
    if text is None:
        return ''
    return (str(text)
            .replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;'))


def _fmt_dt(dt) -> str:
    """Format a datetime for header / ribbon - fall back gracefully.

    Uses a literal middot (UTF-8) so it renders correctly in both the HTML
    and plain-text parts (an HTML entity would show verbatim in text).
    """
    try:
        return dt.strftime('%d %b %Y - %H:%M')
    except Exception:
        return str(dt)
