"""
modules/mimp_report/crypto.py
Symmetric encryption for credentials stored in MIMPApplication
(server_password, db_password).

Why Fernet?
    * AES-128 in CBC + HMAC-SHA256 - authenticated encryption out of the box.
    * Standard library of `cryptography`, well-audited, no DIY crypto.
    * Tokens are URL-safe base64 strings -> safe in VARCHAR(500) columns.

Key management - IMPORTANT
The key is resolved in priority order:

    1. MIMP_CREDENTIAL_KEY   - module-specific override, if an operator wants
                               MIMP credentials under their own key.
    2. ENCRYPTION_KEY        - the deployment-wide Fernet key already used by
                               crypto_utils.py for the Secret Vault, the
                               health-check monitors and the file-monitor
                               connections. This is what production sets, so
                               MIMP now inherits it with no extra config.
    3. _LEGACY_KEY           - the key that used to be hardcoded here.

(3) is a DECRYPT-ONLY fallback. It exists so credentials written by earlier
builds stay readable with no migration step; nothing is ever encrypted under
it again. A key committed to source is obfuscation, not encryption - anyone
with read access to the repository could recover every stored server and
database password - so as soon as (1) or (2) is configured the module writes
under a real secret and the legacy key only ever reads.

Re-saving an application from the UI rewrites its passwords under the primary
key. To retire the legacy key entirely, re-save every application that has
server or database credentials, then delete _LEGACY_KEY from this file.
"""

from __future__ import annotations

import logging
import os
from typing import Optional

from cryptography.fernet import Fernet, InvalidToken

logger = logging.getLogger(__name__)

# Legacy key - DECRYPT ONLY.
# This value used to be the sole key protecting every stored MIMP credential.
# It is retained so existing ciphertext stays readable; it is never used to
# encrypt anything new. See the module docstring for how to retire it.
_LEGACY_KEY: str = "AdDJdNkm2fdT5eHS2BAA30jlgj7ZafEr7pD85lbdKPU="

# Primary key sources, highest priority first.
_ENV_VAR = "MIMP_CREDENTIAL_KEY"
_SHARED_ENV_VAR = "ENCRYPTION_KEY"

_fernet: Optional[Fernet] = None


def _primary_key() -> str:
    """The key every NEW value is encrypted under.

    Falls back to the legacy in-source key only when neither environment
    variable is set, and warns loudly when it does - in that state the stored
    credentials are protected by a value that is in the source tree.
    """
    key = os.environ.get(_ENV_VAR) or os.environ.get(_SHARED_ENV_VAR)
    if key:
        return key
    logger.warning(
        "MIMP credentials are being written under the legacy key committed in "
        "source - anyone with repository access can decrypt them. Set %s (or "
        "the deployment-wide %s) and re-save each application to fix this.",
        _ENV_VAR, _SHARED_ENV_VAR,
    )
    return _LEGACY_KEY


def _build(key) -> Fernet:
    try:
        return Fernet(key.encode() if isinstance(key, str) else key)
    except (ValueError, TypeError) as e:
        # A malformed env var should produce a clear error rather than a
        # cryptic crash inside `cryptography`.
        raise RuntimeError(
            f"MIMP encryption key is invalid (must be 32 url-safe "
            f"base64-encoded bytes). Error: {e}"
        ) from e


def _get_fernet() -> Fernet:
    """Lazy singleton for the primary (write) key."""
    global _fernet
    if _fernet is None:
        _fernet = _build(_primary_key())
    return _fernet


def _decrypt_candidates() -> list:
    """Every key a stored value may have been written under, primary first.

    Makes decryption self-healing across key-configuration changes, exactly
    like crypto_utils._candidate_keys() does for the rest of the application.
    """
    keys, seen = [], set()
    for candidate in (os.environ.get(_ENV_VAR),
                      os.environ.get(_SHARED_ENV_VAR),
                      _LEGACY_KEY):
        if candidate and candidate not in seen:
            seen.add(candidate)
            keys.append(candidate)
    return keys


def encrypt_secret(plain: Optional[str]) -> Optional[str]:
    """
    Encrypt a plain-text credential. Returns None for None/empty input
    so the column can stay NULL when no credential is configured.
    """
    if plain is None or plain == "":
        return None
    token = _get_fernet().encrypt(plain.encode("utf-8"))
    return token.decode("utf-8")


def decrypt_secret(token: Optional[str]) -> Optional[str]:
    """
    Decrypt a stored credential. Returns None for None/empty.

    Raises RuntimeError on tamper / wrong-key - callers should catch it
    and degrade the relevant probe to a clear failure rather than crash
    the whole check sweep.
    """
    if token is None or token == "":
        return None
    raw = token.encode("utf-8")
    for key in _decrypt_candidates():
        try:
            return _build(key).decrypt(raw).decode("utf-8")
        except InvalidToken:
            continue
    logger.error("Failed to decrypt credential - wrong key or tampered data.")
    raise RuntimeError("Stored credential could not be decrypted.")


def is_key_configured() -> bool:
    """True when a real (non-source) key is configured for new writes."""
    return bool(os.environ.get(_ENV_VAR) or os.environ.get(_SHARED_ENV_VAR))
