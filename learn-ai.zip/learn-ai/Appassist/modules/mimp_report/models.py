from sqlalchemy import (
    Column, Integer, String, DateTime, Text, Boolean, ForeignKey, UniqueConstraint
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from database import Base


class MIMPSchedulerLock(Base):
    __tablename__ = 'mimp_scheduler_locks'

    id        = Column(Integer, primary_key=True)
    lock_key  = Column(String(255), nullable=False, unique=True)
    locked_at = Column(DateTime, default=func.now())

    __table_args__ = (UniqueConstraint('lock_key', name='uq_lock_key'),)


class MIMPReport(Base):
    __tablename__ = 'mimp_reports'

    id                = Column(Integer, primary_key=True)
    name              = Column(String(100), nullable=False)
    description       = Column(Text)
    start_time        = Column(DateTime, nullable=False)
    end_time          = Column(DateTime, nullable=False)
    frequency_minutes = Column(Integer, nullable=False)
    email_list        = Column(Text)
    created_at        = Column(DateTime, default=func.now())
    created_by        = Column(Integer, ForeignKey('users.id'))
    is_active         = Column(Boolean, default=True)

    # ------------------------------------------------------------------
    # Schedule state - owned by the scheduler, and the ONLY answer to
    # "when does this report run next?".
    #
    # It used to be derived instead: the sweep took the newest
    # MIMPApplicationStatus.timestamp for the report and called that the
    # last run. But that table is ALSO written by the dashboard whenever a
    # person edits an application's status by hand, so a human note moved
    # the schedule - the next scheduled run slipped by a whole frequency
    # every time somebody touched the page, and on a busy report it could
    # be starved indefinitely. Observations are evidence of what was seen;
    # they were never a record of when the scheduler ran.
    #
    # `next_run_at` is the authoritative due time and is advanced to the
    # NEXT SLOT when a run is claimed - stepped from the slot that came
    # due, never from the wall clock at claim time, so a late sweep cannot
    # drag the whole schedule later permanently.
    #
    # `last_run_at` is when the last scheduled run started. It is for the
    # UI and for diagnostics; nothing schedules off it.
    # ------------------------------------------------------------------
    last_run_at       = Column(DateTime)
    next_run_at       = Column(DateTime, index=True)

    status_updates = relationship(
        "MIMPApplicationStatus",
        back_populates="report",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )


class MIMPApplicationTower(Base):
    __tablename__ = 'mimp_application_towers'

    id          = Column(Integer, primary_key=True)
    name        = Column(String(100), nullable=False)
    description = Column(Text)
    created_at  = Column(DateTime, default=func.now())
    created_by  = Column(Integer, ForeignKey('users.id'))
    is_active   = Column(Boolean, default=True)

    applications = relationship(
        "MIMPApplication",
        back_populates="tower",
        cascade="all, delete-orphan",
    )


class MIMPApplication(Base):
    """
    A monitored application.

    A check consists of up to THREE independent probes - URL (mandatory),
    Server (optional), and Database (optional). For an app to be reported
    'good', every CONFIGURED probe must pass.

    Apps without server/db config keep the existing URL-only behaviour
    so legacy rows are unaffected.
    """
    __tablename__ = 'mimp_applications'

    # Core (existing)
    id         = Column(Integer, primary_key=True)
    tower_id   = Column(Integer, ForeignKey('mimp_application_towers.id'))
    name       = Column(String(100), nullable=False)
    url        = Column(String(500), nullable=False)
    created_at = Column(DateTime, default=func.now())
    created_by = Column(Integer, ForeignKey('users.id'))
    is_active  = Column(Boolean, default=True)

    # Server check (NEW, all optional)
    # If server_type is NULL, the server probe is skipped entirely.
    # If server_service_name is NULL, the probe only verifies that
    # SSH/WinRM login succeeds (a much weaker but still useful signal).
    server_type         = Column(String(20))    # 'windows' | 'linux' | 'aix' | NULL
    server_hostname     = Column(String(255))
    server_port         = Column(Integer)       # 22 (linux/aix) or 5985 (windows)
    server_username     = Column(String(100))
    server_password     = Column(String(500))   # ENCRYPTED at rest (Fernet)
    server_service_name = Column(String(200))   # optional; NULL -> login-only check

    # Database check (NEW, all optional)
    # If db_type is NULL, the DB probe is skipped entirely.
    db_type     = Column(String(20))    # 'oracle' | 'mssql' | NULL
    db_host     = Column(String(255))
    db_port     = Column(Integer)       # 1521 (Oracle) / 1433 (MSSQL)
    db_name     = Column(String(100))   # service name (Oracle) / db name (MSSQL)
    db_username = Column(String(100))
    db_password = Column(String(500))   # ENCRYPTED at rest (Fernet)

    tower          = relationship("MIMPApplicationTower", back_populates="applications")
    status_updates = relationship(
        "MIMPApplicationStatus",
        back_populates="application",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )


class MIMPApplicationStatus(Base):
    """
    A single health-check observation for one application within one report.

    Lifecycle / cascade rules (production-critical):
        * Deleting a MIMPReport deletes ALL of its status rows
          (report_id FK has ondelete='CASCADE') but NEVER touches the
          application catalogue (mimp_applications) - the app list is
          master data and survives report deletion.
        * Deleting a MIMPApplication deletes that app's status history
          (application_id FK has ondelete='CASCADE').
    Both the DB-level ondelete and the ORM-level cascade are declared so
    the behaviour is correct whether a row is removed via the ORM session
    or via a raw SQL / bulk DELETE.
    """
    __tablename__ = 'mimp_application_status'

    id              = Column(Integer, primary_key=True)
    application_id  = Column(
        Integer,
        ForeignKey('mimp_applications.id', ondelete='CASCADE'),
        index=True,
    )
    report_id       = Column(
        Integer,
        ForeignKey('mimp_reports.id', ondelete='CASCADE'),
        index=True,
    )
    status          = Column(String(20), nullable=False)   # 'good' | 'warning' | 'down'
    note            = Column(Text)
    updated_by      = Column(Integer, ForeignKey('users.id'))
    updated_by_name = Column(String(80))
    updated_at      = Column(DateTime, default=func.now())
    timestamp       = Column(DateTime, nullable=False, index=True)

    application = relationship("MIMPApplication", back_populates="status_updates")
    report      = relationship("MIMPReport",      back_populates="status_updates")