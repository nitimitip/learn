"""
modules/mimp_report/scheduler.py
APScheduler-based MIMP scheduler.

Why APScheduler instead of the `schedule` library?
    * `schedule` is single-threaded and silently drops a tick whenever the
      previous run is still in flight.
    * `schedule` has zero memory of missed firings - process restarts lose them.
    * APScheduler offers misfire_grace_time, coalesce, max_instances,
      SQLAlchemyJobStore (persistence), and a real thread-pool executor.

Scheduling model - SWEEP (changed)
Previously every report had its own IntervalTrigger job. That made
"is this report due?" implicit and fragile: a process restart lost the
phase, and there was no single place that compared a report's *next
execution time* against *now*.

The model is ONE sweep job that runs every minute:

    For each active report:
        if next_run_at <= now  AND  start_time <= now <= end_time:
            queue it on the report pool, which claims the slot
            (advancing next_run_at to the following one) and probes

The sweep only QUEUES. Probing happens on a separate, size-capped thread
pool, so a report whose probes take ten minutes no longer stops every other
report from being evaluated for ten minutes - which was its own source of
missed runs. See _MAX_CONCURRENT_REPORTS for why that cap is not just a
performance knob.

This implements the required rule literally - "if the next execution
date/time is less than (or equal to) the current time, execute" - and is
restart-safe and reloader-safe. A daily maintenance job runs alongside it
(report purge + status cleanup + stale-lock cleanup).

Where the schedule lives - READ THIS BEFORE CHANGING IT
-------------------------------------------------------
In `mimp_reports.next_run_at`, and nowhere else.

It used to be recomputed on every sweep from the newest
`mimp_application_status.timestamp` for the report. Two things were wrong
with that, and both showed up as "the report sometimes does not run on its
interval":

  1. That table is ALSO written by the dashboard when somebody edits an
     application's status by hand. A human note therefore re-anchored the
     schedule and pushed the next scheduled run a full frequency into the
     future. On a report people actually watch it could be starved
     indefinitely - an operator touching a status every 10 minutes held a
     30-minute report to ONE run in two hours.
  2. The anchor was the run's start time, so a sweep that fired seven
     minutes late moved every later slot seven minutes later, for good.
     Slots never recovered the intended clock times.

Observations are evidence of what was seen. They were never a record of
when the scheduler ran, and nothing here may treat them as one again.
"""

from __future__ import annotations

import concurrent.futures
import logging
import os
import sys
import threading
import time
from datetime import datetime, timedelta

from apscheduler.executors.pool import ThreadPoolExecutor
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.triggers.cron import CronTrigger
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import joinedload

from database import get_db_session, engine
from modules.mimp_report.email_utils import send_mimp_email_report
from modules.mimp_report.models import (
    MIMPApplication,
    MIMPApplicationStatus,
    MIMPReport,
    MIMPSchedulerLock,
)
from modules.mimp_report.probes import run_all_probes

# NOTE: no logging.basicConfig() here. This module is imported by the Flask
# app, and basicConfig installs a handler and a level on the ROOT logger -
# it would reconfigure logging for the whole process (main_app / log_utils
# own that) as a side effect of importing the MIMP scheduler.
logger = logging.getLogger(__name__)

# Tunables

_MISFIRE_GRACE_SEC = 5 * 60     # late runs still execute up to N seconds late
_MAX_INSTANCES     = 1          # never overlap the same job
_THREAD_POOL_SIZE  = 4          # parallel jobs ceiling (kept small on purpose)

# How often the sweep runs. One minute gives minute-resolution scheduling
# without hammering the DB. Report frequencies are in whole minutes anyway.
# Overridable via env so the dedicated Windows service can run a coarser
# sweep (e.g. 30 min) without changing the in-process Flask default.
_SWEEP_INTERVAL_SEC = int(os.environ.get('MIMP_SWEEP_INTERVAL_SEC', '60'))

# Pause between probing consecutive applications inside one report run.
# Spreads server / DB load instead of opening every connection at once.
# This paces WITHIN a report; _MAX_CONCURRENT_REPORTS paces ACROSS reports.
_PER_APP_DELAY_SEC = 0.5

# How many reports may be probing at the same time.
#
# Due reports used to run inline in the sweep, one after another, so the
# sweep was blocked for as long as every due report took - minutes each -
# and no other report was even evaluated in the meantime. They now run on
# their own thread pool and the sweep returns immediately.
#
# The cap matters more here than it looks. The application catalogue is
# GLOBAL: mimp_applications has no report_id, and run_mimp_check probes
# every active application. Two reports running at once therefore probe the
# whole estate twice at once, not two disjoint halves of it. This number is
# the multiplier on the load every monitored host sees.
#
# Database connections are NOT the constraint: the probes deliberately hold
# no session (see run_mimp_check), so a concurrent report only takes a
# connection for the short claim, write and lock-release steps - a handful
# against a pool of DB_POOL_SIZE + DB_POOL_OVERFLOW. The monitored hosts are
# the constraint, which is why this is capped by what THEY can take.
#
# 4 is deliberately modest. Set MIMP_MAX_CONCURRENT_REPORTS=1 to get the
# old strictly-serial behaviour back without a code change.
_MAX_CONCURRENT_REPORTS = max(
    1, int(os.environ.get('MIMP_MAX_CONCURRENT_REPORTS', '4'))
)

# Status-row retention (daily cleanup of old health-check observations).
_STATUS_RETENTION_DAYS = 7

# Report retention - a report whose monitoring window ended more than this
# many days ago is finished business and gets removed. Its status rows go
# with it via ON DELETE CASCADE; the application catalogue is untouched.
_REPORT_RETENTION_DAYS = 2

_CLEANUP_HOUR = 2
_CLEANUP_MIN  = 0

_SWEEP_JOB_ID   = 'mimp_sweep'
_CLEANUP_JOB_ID = 'mimp_cleanup_daily'

# Legacy per-report job prefix - kept so schedule_mimp_reports() can clean
# up any IntervalTrigger jobs left in the jobstore by an older deployment.
_LEGACY_REPORT_JOB_PREFIX = 'mimp_report_'

# Locks older than this are considered stale (owner crashed mid-run) and
# may be force-removed so a report is not blocked forever.
_LOCK_STALE_MINUTES = 30


# Timezone resolution - IMPORTANT
#
# APScheduler MUST agree with the rest of the app about what time it is.
# The rest of MIMP (routes.py, scheduler's run_mimp_check, models default
# `func.now()`, comparisons against report.start_time / end_time) all use
# naive `datetime.now()`, which returns LOCAL time on the host.
#
# If we tell APScheduler to use UTC while everything else uses local time,
# the scheduler thinks "fire at 12:51 UTC" = 13:51 BST and sleeps an extra
# hour. That is exactly what the runtime logs showed.
#
# Solution: use the host's local timezone. We try in order:
#   1. tzlocal  (most accurate - reads OS / /etc/localtime / Win registry)
#   2. system   (BackgroundScheduler default - usually fine)
#   3. 'UTC'    (last-resort fallback if tz lookup blows up)
def _resolve_local_timezone():
    try:
        import tzlocal
        # tzlocal >= 4 returns zoneinfo.ZoneInfo, < 4 returns pytz tz.
        # APScheduler accepts both - we just hand it through.
        tz = tzlocal.get_localzone()
        logger.info(f"MIMP scheduler timezone: {tz}")
        return tz
    except Exception as e:
        logger.warning(
            f"tzlocal unavailable ({e}); falling back to APScheduler default. "
            f"Install with `pip install tzlocal` for guaranteed correctness."
        )
        return None  # let APScheduler pick its default


# Scheduler singleton

_scheduler: BackgroundScheduler | None = None
_scheduler_lock = threading.Lock()


# Report-run thread pool
#
# Separate from the APScheduler executor ON PURPOSE. If report runs shared
# the scheduler's pool, four concurrent reports would occupy every worker
# and the sweep itself - the job that notices anything is due at all -
# would have nowhere to run. The two must not be able to starve each other.
#
# Not APScheduler one-off jobs either: those are written to the SQLAlchemy
# jobstore, so every dispatch would be an INSERT and a DELETE against the
# database for a task that is meaningless after the process exits.

_report_pool = None
_report_pool_lock = threading.Lock()

# Report ids queued or running right now, so a sweep cannot queue the same
# report twice while its probes are still going. The compare-and-swap in
# _claim_due_run is what makes a double run IMPOSSIBLE (and it works across
# processes, which this set cannot); this is just to stop the pool filling
# with tasks that would immediately discover they had lost the race.
_in_flight = set()
_in_flight_lock = threading.Lock()


def _get_report_pool():
    global _report_pool
    if _report_pool is None:
        with _report_pool_lock:
            if _report_pool is None:
                _report_pool = concurrent.futures.ThreadPoolExecutor(
                    max_workers=_MAX_CONCURRENT_REPORTS,
                    thread_name_prefix='mimp-report',
                )
                logger.info(
                    "MIMP report pool started (%d concurrent report(s) max).",
                    _MAX_CONCURRENT_REPORTS,
                )
    return _report_pool


def _dispatch_report(report_id: int) -> bool:
    """Queue a due report to run off the sweep thread.

    Returns False when the report is already queued or still probing, which
    is the normal outcome for a report whose run takes longer than the sweep
    interval - it is not an error and the sweep just moves on.

    The in-flight marker is cleared in a `finally`, so a probe that blows up
    cannot wedge a report out of its schedule for the life of the process.
    """
    with _in_flight_lock:
        if report_id in _in_flight:
            return False
        _in_flight.add(report_id)

    def _run():
        try:
            run_mimp_check(report_id)
        except Exception:
            logger.exception(
                "MIMP report %s failed in the report pool.", report_id)
        finally:
            with _in_flight_lock:
                _in_flight.discard(report_id)

    try:
        _get_report_pool().submit(_run)
        return True
    except Exception:
        # Pool already shut down (process is stopping), or it refused the
        # task. Drop the marker so a later sweep can try again.
        with _in_flight_lock:
            _in_flight.discard(report_id)
        logger.exception(
            "Could not queue MIMP report %s for execution.", report_id)
        return False


def _shutdown_report_pool(wait: bool = False) -> None:
    """Stop the report pool. wait=False by design - see shutdown_scheduler."""
    global _report_pool
    with _report_pool_lock:
        pool, _report_pool = _report_pool, None
    if pool is not None:
        # cancel_futures drops tasks that have not started; the ones already
        # probing are left to finish or die with the process, exactly as the
        # scheduler's own shutdown(wait=False) treats a running job.
        pool.shutdown(wait=wait, cancel_futures=True)
        logger.info("MIMP report pool shut down.")
    with _in_flight_lock:
        _in_flight.clear()


def _build_scheduler() -> BackgroundScheduler:
    # NOTE: MIMP gets its OWN jobstore table, distinct from the health-check
    # scheduler's 'apscheduler_jobs'. When both schedulers run inside the same
    # process (the Windows service), a shared table would make each scheduler
    # load and fire the OTHER's jobs - every sweep would run twice. Separate
    # tables keep each scheduler owning only its own jobs.
    jobstores = {
        'default': SQLAlchemyJobStore(
            engine=engine,
            tablename=os.environ.get('MIMP_APSCHEDULER_TABLE', 'apscheduler_jobs_mimp'),
        ),
    }
    executors = {
        'default': ThreadPoolExecutor(_THREAD_POOL_SIZE),
    }
    job_defaults = {
        'coalesce':           True,   # collapse a backlog of missed sweeps into one
        'max_instances':      _MAX_INSTANCES,
        'misfire_grace_time': _MISFIRE_GRACE_SEC,
    }

    kwargs = dict(
        jobstores    = jobstores,
        executors    = executors,
        job_defaults = job_defaults,
    )
    tz = _resolve_local_timezone()
    if tz is not None:
        kwargs['timezone'] = tz

    return BackgroundScheduler(**kwargs)


def _get_scheduler() -> BackgroundScheduler:
    global _scheduler
    if _scheduler is None:
        with _scheduler_lock:
            if _scheduler is None:
                _scheduler = _build_scheduler()
    return _scheduler


# Due-time calculation - the core of the scheduling rule
#
# The schedule lives in mimp_reports.next_run_at and NOWHERE else.
#
# It used to be derived, every sweep, from the newest
# MIMPApplicationStatus.timestamp for the report. That table is also
# written by the dashboard's "update status" action, so a person adding a
# note was indistinguishable from a scheduler run: the report's next
# execution slipped a whole frequency every time somebody touched the
# page. On a report people actually watch, that starved the schedule -
# an operator editing a status every 10 minutes kept a 30-minute report
# down to one run in two hours. That is the "sometimes does not run on
# its interval" symptom.
#
# Deriving it also drifted. The anchor was the run's START time, so a
# sweep that fired seven minutes late moved every subsequent slot seven
# minutes later, permanently, with no way back to the intended clock
# times.
#
# Both are fixed by storing the slot: `next_run_at` is advanced from the
# SLOT THAT CAME DUE, not from the wall clock, at the moment a run is
# claimed. See _advance_slot and _claim_due_run.


def _machine_last_run(db_session, report_id: int) -> datetime | None:
    """The newest observation written by the SCHEDULER, ignoring people.

    Only used to seed `next_run_at` on a report that predates the column -
    see _seed_next_run_at. `updated_by` is the discriminator: the scheduler
    leaves it NULL (it writes updated_by_name='System'), while the
    dashboard route always stamps the signed-in user's id. Testing the id
    rather than the name means a user who happens to be called "System"
    still cannot be mistaken for the scheduler.
    """
    row = (db_session.query(MIMPApplicationStatus.timestamp)
           .filter(MIMPApplicationStatus.report_id == report_id,
                   MIMPApplicationStatus.updated_by.is_(None))
           .order_by(MIMPApplicationStatus.timestamp.desc())
           .first())
    return row[0] if row else None


def _advance_slot(slot: datetime, freq_minutes: int,
                  now: datetime) -> datetime:
    """The first slot strictly after *now*, stepping from *slot*.

    Stepping from the slot rather than from `now` is what keeps the period
    exact: a run that started late still hands the next run the intended
    clock time. The step cap stops a misconfigured start_time (years in
    the past, one-minute frequency) from spinning.
    """
    step = timedelta(minutes=max(1, int(freq_minutes or 1)))
    nxt = slot + step
    steps = 0
    while nxt <= now and steps < 100_000:
        nxt += step
        steps += 1
    return nxt


def _first_slot(report: MIMPReport, now: datetime) -> datetime:
    """Where a report's schedule starts when it has never run.

    One frequency after start_time, then advanced past now. Advancing
    matters on a report whose window opened while the service was down: it
    starts at the next real slot instead of firing once for every slot it
    missed, and without the advance a long-idle report would sit
    permanently "due" and run on every single sweep.
    """
    freq = max(1, int(report.frequency_minutes or 1))
    first = report.start_time + timedelta(minutes=freq)
    if first > now:
        return first
    return _advance_slot(first, freq, now)


def _seed_next_run_at(db_session, report: MIMPReport,
                      now: datetime) -> datetime:
    """Give a report a next_run_at if it has none, and return it.

    Runs for reports created before this column existed. Seeding from the
    last SCHEDULER-written observation (never a human one) keeps continuity
    across the upgrade: a report that ran at 10:00 with a 30-minute
    frequency comes back with 10:30, exactly where the old derivation would
    have put it - rather than every report on the shelf firing at once on
    the first sweep after deployment.

    Not committed here; the caller owns the transaction.
    """
    if report.next_run_at is not None:
        return report.next_run_at

    last_machine_run = _machine_last_run(db_session, report.id)
    if last_machine_run is None:
        seeded = _first_slot(report, now)
    else:
        seeded = _advance_slot(last_machine_run,
                               report.frequency_minutes, now)
        # _advance_slot always lands in the future. If the report is
        # genuinely overdue - the service was down over its slot - it
        # should run on this sweep rather than waiting another period.
        overdue = last_machine_run + timedelta(
            minutes=max(1, int(report.frequency_minutes or 1)))
        if overdue <= now:
            seeded = overdue

    report.next_run_at = seeded
    logger.info(
        "Seeded next_run_at=%s for report '%s' (id=%s) - no schedule state "
        "stored yet.", seeded, report.name, report.id)
    return seeded


def _is_report_due(report: MIMPReport, now: datetime) -> bool:
    """A report is due when its stored next_run_at has arrived.

    Still gated on the report being active and inside its monitoring
    window - the window is the user's statement of when this report is
    allowed to run at all, and it outranks any stored slot.
    """
    if not report.is_active:
        return False
    if not (report.start_time <= now <= report.end_time):
        return False
    if report.next_run_at is None:
        # Un-seeded; _seed_next_run_at will have filled it in before this
        # is called. Treating it as NOT due is the fail-safe answer - a
        # missing slot must never mean "run on every sweep".
        return False
    return report.next_run_at <= now


def _claim_due_run(report_id: int, now: datetime) -> datetime | None:
    """Take ownership of a report's due slot. Returns the slot, or None.

    A compare-and-swap, not a read-then-write: the UPDATE matches on the
    `next_run_at` value that was read a moment ago, so if a second worker
    (another process, or the dedicated Windows service running alongside
    the web app) claimed the same slot in between, this one's UPDATE
    matches no rows and it backs off. Exactly one worker runs the slot.

    The new `next_run_at` is stepped from THE SLOT, not from `now`. That is
    the difference between a report that keeps its intended clock times and
    one that drifts later every time a sweep runs late - which, with the
    sweep running due reports inline and probes taking minutes, it
    routinely does.

    Advancing BEFORE the probes also means an in-flight run is not due, so
    a report whose probes take longer than its own frequency is not
    dispatched again on top of itself.
    """
    db_session = get_db_session()
    try:
        report = db_session.query(MIMPReport).filter_by(id=report_id).first()
        if report is None:
            return None

        # Seed a report that predates the schedule columns, and COMMIT the
        # seed before going any further. These sessions run autoflush=False,
        # so an unflushed assignment is invisible to the UPDATE below - its
        # WHERE would compare against the NULL still in the table and match
        # nothing, and the report would never manage to claim its first
        # slot. Committing first puts the row and this session's view of it
        # back in agreement.
        if report.next_run_at is None:
            _seed_next_run_at(db_session, report, now)
            db_session.commit()
            report = db_session.query(MIMPReport).filter_by(
                id=report_id).first()
            if report is None:
                return None

        observed = report.next_run_at

        if not _is_report_due(report, now):
            return None

        freq = report.frequency_minutes
        following = _advance_slot(observed, freq, now)

        rows = (db_session.query(MIMPReport)
                .filter(MIMPReport.id == report_id,
                        MIMPReport.next_run_at == observed)
                .update({MIMPReport.next_run_at: following,
                         MIMPReport.last_run_at: now},
                        synchronize_session=False))
        db_session.commit()

        if not rows:
            logger.info(
                f"Report {report_id}: slot {observed} was claimed by another "
                f"worker first."
            )
            return None

        logger.info(
            f"Report {report_id}: claimed slot {observed}; next run {following}."
        )
        return observed
    except Exception:
        db_session.rollback()
        logger.exception(f"Failed to claim a run slot for report {report_id}.")
        return None
    finally:
        db_session.close()


def scheduled_next_run(report: MIMPReport,
                       now: datetime | None = None) -> datetime | None:
    """When this report will next run, for DISPLAY. Read-only.

    The UI asks the scheduler rather than recomputing the schedule itself.
    Two pages used to carry their own copy of the maths, which meant the
    "Next run" on screen could disagree with what the scheduler would
    actually do - and both copies inherited the bug that a hand-edited
    status moved the schedule.

    Returns None when the report will not run again: inactive, past its
    end_time, or with a next slot that falls outside the window. A report
    that has never been swept yet has no stored slot, so the first slot is
    computed the same way the sweep would seed it - without writing, since
    a page render must not have side effects.
    """
    now = now or datetime.now()
    if not report.is_active or now > report.end_time:
        return None

    slot = report.next_run_at or _first_slot(report, now)
    # A slot already in the past means the sweep has not reached it yet
    # (it is busy, or the service is down). "Due now" is the honest answer.
    if slot > report.end_time:
        return None
    return slot


# Core task runner

def run_mimp_check(report_id: int) -> None:
    """
    Run the health check for a single report.

    Two independent guards, because they stop different things:

      * `_claim_due_run` - a compare-and-swap on mimp_reports.next_run_at.
        This is the real fence. It advances the slot BEFORE the probes
        start, so a run that takes longer than one frequency cannot be
        dispatched again by the next sweep, and a crash mid-run costs one
        period rather than turning into a retry loop.
      * MIMPSchedulerLock - the per-(report, minute) row. Kept as a second
        line of defence across processes; the CAS alone is sufficient, but
        the lock also makes a double dispatch inside one minute visible in
        the log rather than silent.

    Connection discipline (production-critical)
    -------------------------------------------
    The probes are SLOW by design: per application they can spend ~20s on two
    HTTP attempts plus a 3s debounce, 10s on SSH, 15s on WinRM and 10s on a
    database connect. A report with a dozen applications therefore runs for
    minutes.

    So no database session is held while they run. The configuration is read
    and the rows are detached, the session is CLOSED, the probes run against
    nothing but their own remote connections, and a second short-lived session
    writes the results. The earlier version kept one session - and one open
    write transaction, accumulating pending INSERTs - for the whole loop,
    which pinned a pooled connection and, on SQL Server, held that
    transaction's locks for the entire run.

    Each probe still opens and closes its own remote connection in a `finally`
    block; see probes.py.
    """
    timestamp = datetime.now().replace(second=0, microsecond=0)
    lock_key = f"mimp_report_check_{report_id}_{timestamp.strftime('%Y%m%d%H%M')}"

    # ---- 0. Claim the SLOT ----------------------------------------------
    # Before anything else, and before any probe runs: move next_run_at on
    # to the following slot. Whoever wins this update owns the run.
    slot = _claim_due_run(report_id, timestamp)
    if slot is None:
        logger.info(
            f"Report {report_id} was not due, or another worker claimed the "
            f"slot first - nothing to do."
        )
        return

    # ---- 1. Claim the per-(report, minute) lock -------------------------
    db_session = get_db_session()
    try:
        db_session.add(MIMPSchedulerLock(lock_key=lock_key,
                                         locked_at=datetime.now()))
        db_session.commit()
        logger.info(f"Lock acquired: {lock_key}")
    except IntegrityError:
        # Another worker already inserted this exact lock_key - it owns the
        # run for this minute. This is the normal multi-worker outcome.
        db_session.rollback()
        db_session.close()
        logger.info(
            f"Lock contention on {lock_key} - another worker is handling it."
        )
        return
    except Exception as e:
        db_session.rollback()
        db_session.close()
        logger.error(f"Could not acquire lock {lock_key}: {e}", exc_info=True)
        return

    try:
        # ---- 2. Read the configuration, then let the connection go ------
        try:
            report = db_session.query(MIMPReport).filter_by(
                id=report_id, is_active=True
            ).first()
            if not report or not (report.start_time <= timestamp <= report.end_time):
                logger.info(
                    f"Report {report_id} inactive or outside time window. Skipping."
                )
                return

            # joinedload(tower): the email renderer groups applications by
            # tower name, so without it every application would trigger its
            # own SELECT later - after this session is gone.
            applications = db_session.query(MIMPApplication).options(
                joinedload(MIMPApplication.tower)
            ).filter_by(is_active=True).all()
            if not applications:
                logger.warning(
                    f"No active applications to monitor for report '{report.name}'."
                )
                return

            report_name = report.name
            # Detach everything the probe loop and the email renderer touch,
            # so already-loaded values stay readable with no session behind
            # them - and no lazy load can silently reopen a connection.
            db_session.expunge_all()
        finally:
            db_session.close()

        # ---- 3. Probe every application with NO database session held ----
        status_data = []
        for idx, app in enumerate(applications):
            try:
                # Probes are self-contained: each opens its own HTTP / SSH /
                # WinRM / DB connection, enforces an explicit timeout, and
                # closes it in a `finally` block before returning. No probe
                # is allowed to raise. See probes.py.
                overall_status, note = run_all_probes(app)
            except Exception as e:
                logger.exception(
                    f"Unhandled error probing app '{app.name}' (id={app.id})"
                )
                overall_status = "down"
                note = f"Internal probe error: {str(e)[:200]}"

            status_data.append({
                "application": app,
                "status": overall_status,
                "note": note,
            })

            # Gentle pacing so we don't open every server / DB connection
            # in the same instant - protects monitored hosts during a storm.
            if idx < len(applications) - 1 and _PER_APP_DELAY_SEC > 0:
                time.sleep(_PER_APP_DELAY_SEC)

        # ---- 4. Persist the observations in one short transaction --------
        write_session = get_db_session()
        try:
            for item in status_data:
                write_session.add(MIMPApplicationStatus(
                    application_id=item["application"].id,
                    report_id=report_id,
                    status=item["status"],
                    note=item["note"],
                    updated_by_name="System",
                    timestamp=timestamp,
                    updated_at=timestamp,
                ))
            write_session.commit()
        except Exception:
            write_session.rollback()
            logger.exception(
                f"Failed to persist MIMP status rows for report '{report_name}'."
            )
            return
        finally:
            write_session.close()

        logger.info(
            f"MIMP check complete for '{report_name}' - "
            f"{len(status_data)} apps checked."
        )

        # ---- 5. Email is best-effort and happens after the commit --------
        # A send failure must not roll back the status rows above, and no
        # database connection is held across the SMTP conversation.
        try:
            send_mimp_email_report(report, status_data, timestamp)
        except Exception:
            logger.exception(f"Email send failed for report '{report_name}'")

    except Exception as e:
        logger.error(f"Error during MIMP check ({lock_key}): {e}", exc_info=True)
    finally:
        # Release our lock in its own short session - the one above is closed.
        release_session = get_db_session()
        try:
            release_session.query(MIMPSchedulerLock).filter_by(
                lock_key=lock_key
            ).delete(synchronize_session=False)
            release_session.commit()
            logger.info(f"Lock released: {lock_key}")
        except Exception as e:
            release_session.rollback()
            logger.error(f"CRITICAL: Failed to release lock {lock_key}: {e}")
        finally:
            # The session is ALWAYS closed - connection returned to the pool.
            release_session.close()


# Sweep job - finds due reports and runs them (implements the new rule)

def mimp_sweep() -> None:
    """
    Runs every minute. For each active report, work out whether its next
    execution time has passed; if so, run it.

    This is the single place the "next run <= now => execute" rule lives.
    It is restart-safe: after a process restart the next run is recomputed
    from the last status row in the DB, so nothing is permanently lost.
    """
    now = datetime.now().replace(second=0, microsecond=0)
    db_session = get_db_session()
    due_report_ids: list[int] = []

    try:
        active_reports = db_session.query(MIMPReport).filter_by(
            is_active=True
        ).all()

        seeded_any = False
        for report in active_reports:
            # The schedule is read from the report row, never derived from
            # the observation table - see the note above _machine_last_run.
            # A report created before those columns existed is seeded here,
            # once, and is authoritative from then on.
            if report.next_run_at is None:
                _seed_next_run_at(db_session, report, now)
                seeded_any = True

            if _is_report_due(report, now):
                due_report_ids.append(report.id)
                logger.info(
                    f"Sweep: report '{report.name}' (id={report.id}) is DUE "
                    f"(slot: {report.next_run_at}, "
                    f"last run: {report.last_run_at})."
                )

        if seeded_any:
            db_session.commit()
    except Exception as e:
        logger.error(f"MIMP sweep failed to evaluate reports: {e}", exc_info=True)
        db_session.rollback()
        return
    finally:
        # Close the read session BEFORE running checks so we are not
        # holding a pooled connection while probes run for minutes.
        db_session.close()

    # Hand each due report to the report pool and RETURN.
    #
    # These used to run inline and in series, so the sweep stayed busy for as
    # long as every due report's probes took - minutes each - and with
    # max_instances=1 the minute ticks in between were dropped. A report that
    # came due behind a slow one was not even looked at until the slow one
    # finished. Dispatching keeps the sweep to a few milliseconds of database
    # work, so every report is evaluated on the minute it is due.
    #
    # _MAX_CONCURRENT_REPORTS caps how many probe at once - the application
    # catalogue is global, so each concurrent report probes the whole estate.
    #
    # Safety across the two layers, since neither alone is enough:
    #   * _dispatch_report skips a report already queued or probing, so the
    #     pool cannot fill with tasks that would lose the race anyway.
    #   * run_mimp_check claims the slot with a compare-and-swap, which is
    #     what actually makes a double run impossible - including against a
    #     second scheduler in another process, which no in-process set can
    #     see.
    queued = 0
    for report_id in due_report_ids:
        if _dispatch_report(report_id):
            queued += 1
        else:
            logger.info(
                f"Sweep: report {report_id} is still running from an earlier "
                f"slot - not queued again."
            )
    if queued:
        logger.info(f"Sweep: queued {queued} report(s) for execution.")

    # Keep the is_active flag honest: a report whose end_time has passed is
    # treated as inactive. Done here (not just in the 02:00 daily job) so a
    # report that expires mid-day is reflected within one sweep cycle.
    # Runs straight away now rather than behind every due report's probes.
    deactivate_expired_reports()


# Cleanup - old status rows

def cleanup_old_data() -> None:
    """Delete health-check observations older than the retention window.

    Bulk DELETE (no per-row ORM load) keeps memory flat even when there
    are millions of rows.
    """
    db_session = get_db_session()
    try:
        cutoff = datetime.now() - timedelta(days=_STATUS_RETENTION_DAYS)
        deleted = db_session.query(MIMPApplicationStatus).filter(
            MIMPApplicationStatus.timestamp < cutoff
        ).delete(synchronize_session=False)
        db_session.commit()
        if deleted:
            logger.info(f"Cleaned up {deleted} old MIMP status records.")
    except Exception as e:
        logger.error(f"Error during data cleanup: {e}")
        db_session.rollback()
    finally:
        db_session.close()


def deactivate_expired_reports() -> None:
    """
    Flip is_active -> False for any report whose monitoring window has
    already ended (end_time < now) but which has not yet reached the
    2-day purge cutoff.

    Rationale: a report whose end_time has passed is finished business and
    should be considered inactive immediately - the UI (manage_reports,
    index) reads is_active, so the flag must reflect reality, not just the
    admin's last manual toggle. The scheduler already refuses to run such
    a report (see _is_report_due), so this is purely about keeping the
    stored flag honest in the window between expiry and purge.
    """
    db_session = get_db_session()
    try:
        now = datetime.now()
        updated = db_session.query(MIMPReport).filter(
            MIMPReport.end_time < now,
            MIMPReport.is_active == True,   # noqa: E712 - SQL boolean compare
        ).update(
            {MIMPReport.is_active: False},
            synchronize_session=False,
        )
        db_session.commit()
        if updated:
            logger.info(
                f"Deactivated {updated} report(s) whose end_time has passed."
            )
    except Exception as e:
        logger.error(f"Error deactivating expired reports: {e}", exc_info=True)
        db_session.rollback()
    finally:
        db_session.close()


def purge_expired_reports() -> None:
    """
    Remove MIMP reports whose monitoring window ended more than
    _REPORT_RETENTION_DAYS days ago.

    Deleting the MIMPReport row cascades to its MIMPApplicationStatus
    rows (report_id FK is ON DELETE CASCADE) - the per-report health-check
    history is removed with the report. The application catalogue
    (mimp_applications) and the towers are master data and are NOT touched.

    Deletes are done one report at a time via session.delete() so the ORM
    cascade / delete-orphan rules fire correctly regardless of how the
    underlying DB enforces the constraint.
    """
    db_session = get_db_session()
    try:
        cutoff = datetime.now() - timedelta(days=_REPORT_RETENTION_DAYS)
        expired = db_session.query(MIMPReport).filter(
            MIMPReport.end_time < cutoff
        ).all()

        if not expired:
            logger.info("Report purge: no reports past the retention window.")
            return

        purged_names = []
        for report in expired:
            purged_names.append(f"'{report.name}' (id={report.id})")
            db_session.delete(report)   # cascades to status rows only

        db_session.commit()
        logger.info(
            f"Report purge: removed {len(purged_names)} expired report(s) "
            f"and their status history - {', '.join(purged_names)}. "
            f"Application catalogue left intact."
        )
    except Exception as e:
        logger.error(f"Error purging expired reports: {e}", exc_info=True)
        db_session.rollback()
    finally:
        db_session.close()


def cleanup_stale_locks() -> None:
    """Remove scheduler locks whose owner appears to have crashed.

    A lock row is normally deleted by the worker that created it. If a
    process is killed mid-run the row is orphaned and would block that
    report's slot. We sweep anything older than the stale window.
    """
    db_session = get_db_session()
    try:
        cutoff = datetime.now() - timedelta(minutes=_LOCK_STALE_MINUTES)
        deleted = db_session.query(MIMPSchedulerLock).filter(
            MIMPSchedulerLock.locked_at < cutoff
        ).delete(synchronize_session=False)
        db_session.commit()
        if deleted:
            logger.warning(f"Removed {deleted} stale scheduler lock(s).")
    except Exception as e:
        logger.error(f"Error cleaning up stale locks: {e}")
        db_session.rollback()
    finally:
        db_session.close()


def daily_maintenance() -> None:
    """Single daily maintenance entry point: deactivate expired reports,
    purge long-expired reports, trim old status rows, and clear stale
    locks. Each step is independent and isolated so one failure does not
    block the others."""
    deactivate_expired_reports()
    purge_expired_reports()
    cleanup_old_data()
    cleanup_stale_locks()


# Schedule (re)load

def schedule_mimp_reports() -> None:
    """
    (Re)register the fixed set of MIMP jobs: the sweep and the daily
    maintenance job.

    With the sweep model there is no longer one job per report - adding,
    editing or deleting a report needs no scheduler change at all, because
    the sweep reads the report table fresh every minute. This function is
    still safe to call from routes.py after a report change; it just
    re-asserts the standing jobs and clears any legacy per-report
    IntervalTrigger jobs left over from the old design.
    """
    sched = _get_scheduler()

    # Drop any legacy per-report jobs from a previous deployment.
    for job in list(sched.get_jobs()):
        if (job.id.startswith(_LEGACY_REPORT_JOB_PREFIX)
                and job.id not in (_SWEEP_JOB_ID, _CLEANUP_JOB_ID)):
            try:
                sched.remove_job(job.id)
                logger.info(f"Removed legacy per-report job '{job.id}'.")
            except Exception:
                pass

    # The sweep - runs every minute, evaluates all reports
    sched.add_job(
        func             = mimp_sweep,
        trigger          = IntervalTrigger(seconds=_SWEEP_INTERVAL_SEC),
        id               = _SWEEP_JOB_ID,
        name             = "MIMP sweep (due-report scan)",
        replace_existing = True,
        next_run_time    = datetime.now() + timedelta(seconds=10),
    )
    logger.info(
        f"Scheduled MIMP sweep every {_SWEEP_INTERVAL_SEC}s "
        f"(job={_SWEEP_JOB_ID})."
    )

    # Daily maintenance: report purge + status cleanup + lock cleanup
    sched.add_job(
        func             = daily_maintenance,
        trigger          = CronTrigger(hour=_CLEANUP_HOUR, minute=_CLEANUP_MIN),
        id               = _CLEANUP_JOB_ID,
        name             = "MIMP daily maintenance",
        replace_existing = True,
    )
    logger.info(
        f"Scheduled daily maintenance at {_CLEANUP_HOUR:02d}:{_CLEANUP_MIN:02d} "
        f"(report retention {_REPORT_RETENTION_DAYS}d, "
        f"status retention {_STATUS_RETENTION_DAYS}d)."
    )


# Lifecycle - RELOADER-AWARE

def _is_reloader_parent() -> bool:
    """
    Detect Werkzeug's debug reloader parent process.

    When Flask runs with debug=True, Werkzeug spawns TWO Python processes:
        Parent : watches files, restarts child on change.
                 WERKZEUG_RUN_MAIN env var is NOT set in this process.
        Child  : actually serves requests.
                 WERKZEUG_RUN_MAIN=true is set by the parent before exec().

    If we let BOTH processes start the APScheduler, you get two competing
    schedulers writing to the same SQLAlchemy jobstore.

    Returns True if we're in the parent (i.e. should NOT start scheduler).
    """
    if os.environ.get('WERKZEUG_RUN_MAIN') == 'true':
        return False

    in_flask_cli = (
        'flask' in os.path.basename(sys.argv[0]).lower()
        or os.environ.get('FLASK_RUN_FROM_CLI') == 'true'
    )
    if in_flask_cli and os.environ.get('WERKZEUG_RUN_MAIN') is None:
        return True

    return False


def start_scheduler() -> None:
    """Idempotent - safe to call multiple times during app startup."""
    sched = _get_scheduler()
    if not sched.running:
        sched.start()
        logger.info("MIMP APScheduler started.")
    schedule_mimp_reports()


def shutdown_scheduler(wait: bool = False) -> None:
    """Stop the scheduler and the report pool.

    wait=False by design so a hung probe cannot block process shutdown - the
    SQLAlchemy jobstore still flushes. The pool is stopped FIRST so no new
    report run can be queued while the scheduler is coming down.
    """
    _shutdown_report_pool(wait=wait)
    global _scheduler
    if _scheduler is not None and _scheduler.running:
        _scheduler.shutdown(wait=wait)
        logger.info("MIMP APScheduler shut down.")


# Alias so health_monitor_app_sched.py's best-effort
# `from ... import shutdown_mimp_monitoring` hook also works.
def shutdown_mimp_monitoring(wait: bool = False) -> None:
    shutdown_scheduler(wait=wait)


def init_mimp_monitoring(app) -> None:
    """
    Flask-app-context bootstrap. Skips the Werkzeug reloader parent so we
    don't end up with two competing scheduler instances racing each other.
    """
    if _is_reloader_parent():
        logger.info(
            "MIMP scheduler not starting in Werkzeug reloader parent process "
            "(will start in child process)."
        )
        return

    with app.app_context():
        start_scheduler()
