"""
migration_mimp_cascade.py
ONE-OFF migration - run once, after deploying the updated models.py.

Why this is needed
------------------
models.py now declares:

    application_id FK  ->  ON DELETE CASCADE   (NEW)
    report_id      FK  ->  ON DELETE CASCADE   (already present)

SQLAlchemy's `ForeignKey(..., ondelete='CASCADE')` only affects DDL that
SQLAlchemy *generates*. It does NOT alter a table that already exists in
the database. If mimp_application_status was created by an older build,
its application_id foreign key still has the default ON DELETE NO ACTION,
so deleting an application would fail (or orphan rows) and the ORM-side
cascade would have to load every child row into memory.

This script rebuilds the foreign keys with the correct ON DELETE rule.
It is idempotent-ish: safe to run again, it just recreates the same keys.

It also adds the helpful indexes models.py now declares
(application_id, report_id, timestamp) if they are missing.

Usage
-----
    python migration_mimp_cascade.py            # apply
    python migration_mimp_cascade.py --dry-run  # print SQL only

Supported engines: SQLite, PostgreSQL, MySQL/MariaDB, SQL Server.
TAKE A DATABASE BACKUP FIRST.
"""

from __future__ import annotations

import sys

from sqlalchemy import inspect, text

from database import engine


STATUS_TABLE = 'mimp_application_status'


def _dialect() -> str:
    return engine.dialect.name.lower()


# Per-dialect FK rebuild

def _statements_postgres():
    # Postgres: drop existing FKs on the two columns, recreate with CASCADE.
    return [
        # Discover-and-drop is awkward in pure SQL; we drop by the usual
        # auto-generated names and ignore failures via the runner.
        f"ALTER TABLE {STATUS_TABLE} "
        f"DROP CONSTRAINT IF EXISTS {STATUS_TABLE}_application_id_fkey;",
        f"ALTER TABLE {STATUS_TABLE} "
        f"DROP CONSTRAINT IF EXISTS {STATUS_TABLE}_report_id_fkey;",
        f"ALTER TABLE {STATUS_TABLE} "
        f"ADD CONSTRAINT {STATUS_TABLE}_application_id_fkey "
        f"FOREIGN KEY (application_id) REFERENCES mimp_applications(id) "
        f"ON DELETE CASCADE;",
        f"ALTER TABLE {STATUS_TABLE} "
        f"ADD CONSTRAINT {STATUS_TABLE}_report_id_fkey "
        f"FOREIGN KEY (report_id) REFERENCES mimp_reports(id) "
        f"ON DELETE CASCADE;",
    ]


def _statements_mysql():
    # MySQL FK names vary; the runner discovers them via information_schema.
    return None  # handled specially in run()


def _statements_mssql():
    return None  # handled specially in run()


def _index_statements():
    """CREATE INDEX statements - guarded so re-runs don't error."""
    d = _dialect()
    if d in ('postgresql', 'sqlite'):
        return [
            f"CREATE INDEX IF NOT EXISTS ix_{STATUS_TABLE}_application_id "
            f"ON {STATUS_TABLE} (application_id);",
            f"CREATE INDEX IF NOT EXISTS ix_{STATUS_TABLE}_report_id "
            f"ON {STATUS_TABLE} (report_id);",
            f"CREATE INDEX IF NOT EXISTS ix_{STATUS_TABLE}_timestamp "
            f"ON {STATUS_TABLE} (timestamp);",
        ]
    # MySQL / MSSQL: created in run() only if absent.
    return []


def _existing_indexes() -> set[str]:
    insp = inspect(engine)
    return {ix['name'] for ix in insp.get_indexes(STATUS_TABLE)}


# SQLite note
# SQLite cannot ALTER a FK in place. The pragmatic, low-risk path for a
# small monitoring DB is the 12-step table rebuild. Because that is risky
# to automate blind, this script DETECTS SQLite and prints clear manual
# guidance instead of silently doing a destructive rebuild.

_SQLITE_GUIDANCE = f"""
SQLite detected.
SQLite cannot alter a foreign key in place. Either:

  (a) If this database has little/no data you care about, simply let
      database.init_db() recreate the schema from the new models.py, OR

  (b) Do the standard table rebuild manually:

        PRAGMA foreign_keys=OFF;
        BEGIN;
        ALTER TABLE {STATUS_TABLE} RENAME TO {STATUS_TABLE}_old;
        -- recreate {STATUS_TABLE} from the new models.py
        -- (run init_db(), or paste the CREATE TABLE with the
        --  'ON DELETE CASCADE' clauses on both FKs)
        INSERT INTO {STATUS_TABLE}
            SELECT * FROM {STATUS_TABLE}_old;
        DROP TABLE {STATUS_TABLE}_old;
        COMMIT;
        PRAGMA foreign_keys=ON;

  Also ensure the SQLite connection enables FK enforcement
  ('PRAGMA foreign_keys=ON') - SQLAlchemy does this per-connection
  only if configured to.
"""


def run(dry_run: bool = False) -> None:
    d = _dialect()
    print(f"Database dialect: {d}")

    if d == 'sqlite':
        print(_SQLITE_GUIDANCE)
        return

    stmts: list[str] = []

    if d == 'postgresql':
        stmts = _statements_postgres()

    elif d in ('mysql', 'mariadb'):
        # Discover the real FK constraint names.
        with engine.connect() as conn:
            rows = conn.execute(text(
                "SELECT constraint_name, column_name "
                "FROM information_schema.key_column_usage "
                "WHERE table_name = :t AND table_schema = DATABASE() "
                "AND referenced_table_name IS NOT NULL"
            ), {'t': STATUS_TABLE}).fetchall()
        for cname, col in rows:
            if col in ('application_id', 'report_id'):
                stmts.append(f"ALTER TABLE {STATUS_TABLE} DROP FOREIGN KEY {cname};")
        stmts.append(
            f"ALTER TABLE {STATUS_TABLE} "
            f"ADD CONSTRAINT fk_{STATUS_TABLE}_application "
            f"FOREIGN KEY (application_id) REFERENCES mimp_applications(id) "
            f"ON DELETE CASCADE;"
        )
        stmts.append(
            f"ALTER TABLE {STATUS_TABLE} "
            f"ADD CONSTRAINT fk_{STATUS_TABLE}_report "
            f"FOREIGN KEY (report_id) REFERENCES mimp_reports(id) "
            f"ON DELETE CASCADE;"
        )

    elif d in ('mssql', 'pyodbc', 'sql server'):
        with engine.connect() as conn:
            rows = conn.execute(text(
                "SELECT fk.name, c.name "
                "FROM sys.foreign_keys fk "
                "JOIN sys.foreign_key_columns fkc "
                "  ON fk.object_id = fkc.constraint_object_id "
                "JOIN sys.columns c "
                "  ON c.object_id = fkc.parent_object_id "
                " AND c.column_id = fkc.parent_column_id "
                "WHERE fk.parent_object_id = OBJECT_ID(:t)"
            ), {'t': STATUS_TABLE}).fetchall()
        for cname, col in rows:
            if col in ('application_id', 'report_id'):
                stmts.append(f"ALTER TABLE {STATUS_TABLE} DROP CONSTRAINT {cname};")
        stmts.append(
            f"ALTER TABLE {STATUS_TABLE} "
            f"ADD CONSTRAINT fk_{STATUS_TABLE}_application "
            f"FOREIGN KEY (application_id) REFERENCES mimp_applications(id) "
            f"ON DELETE CASCADE;"
        )
        stmts.append(
            f"ALTER TABLE {STATUS_TABLE} "
            f"ADD CONSTRAINT fk_{STATUS_TABLE}_report "
            f"FOREIGN KEY (report_id) REFERENCES mimp_reports(id) "
            f"ON DELETE CASCADE;"
        )
    else:
        print(f"Unsupported dialect '{d}'. Apply the ON DELETE CASCADE "
              f"change manually.")
        return

    # Indexes
    have = _existing_indexes()
    for s in _index_statements():
        stmts.append(s)
    if d in ('mysql', 'mariadb', 'mssql'):
        for col in ('application_id', 'report_id', 'timestamp'):
            ixname = f"ix_{STATUS_TABLE}_{col}"
            if ixname not in have:
                stmts.append(
                    f"CREATE INDEX {ixname} ON {STATUS_TABLE} ({col});"
                )

    print("\nPlanned SQL:\n" + "\n".join(f"  {s}" for s in stmts))

    if dry_run:
        print("\n--dry-run: nothing applied.")
        return

    with engine.begin() as conn:
        for s in stmts:
            try:
                conn.execute(text(s))
                print(f"OK  : {s}")
            except Exception as e:
                # DROP of a non-existent constraint etc. - log and continue.
                print(f"SKIP: {s}\n      ({e})")

    print("\nMigration complete.")


if __name__ == '__main__':
    run(dry_run='--dry-run' in sys.argv)
