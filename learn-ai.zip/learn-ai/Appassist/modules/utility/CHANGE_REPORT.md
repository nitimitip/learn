# Utility Blueprint — Production Readiness Change Report

This report covers the review and fixes applied to the Flask `utility`
blueprint. Every original route, URL, HTTP method, template name, and form
field name has been preserved, so the existing application continues to work.
One small template change is required and is called out explicitly below.

---

## 1. Will the existing application still work?

Yes. Validation performed:

* All 8 Python files parse without syntax errors.
* The `utility` package imports cleanly and registers **all 20 original
  routes** at their original URLs.
* Live HTTP request tests pass (file compare, file split, file search,
  downloads, scramble workflow).
* Template names, form field names (`zip_file`, `excel_file`, `file1`,
  `file2`, `split_file`, `chunk_size`, `has_header`, `duplicate_zip`,
  `search_term`, `ActiveServer`, `data_source`, `selected_report`,
  `custom_keywords`, `selected_columns`, `default_scramble`, `scramble_type`,
  `output_format`, etc.) are unchanged.

**One required template change** — see section 5.

---

## 2. Temp files moved out of the home / project directory

### The problem
* `routes.py` created `TEMP_DIR = 'temp_utility'` as a **relative path**, so
  it landed in whatever directory the process started in (project root or
  home), and was shared by every user and request.
* `process_data` wrote `df.to_json('temp_data.json')` — a bare relative path,
  i.e. straight into the working directory.
* `scramble_and_download` wrote `scrambled_data.xlsx` / `.csv` the same way.
* Because the paths were shared, two users hitting the scramble tool at the
  same time would overwrite each other's data.

### The fix
* New module **`config.py`** centralises all temp handling.
  * `BASE_TEMP_DIR` defaults to the OS temp location
    (`<system temp>/utility_app`), never the home or project directory.
    Overridable via the `UTILITY_TEMP_DIR` environment variable.
  * `new_request_temp_dir()` creates a **unique directory per request**
    (`tempfile.mkdtemp`), so concurrent users are fully isolated.
  * `safe_temp_dir()` is a context manager that guarantees cleanup.
  * `cleanup_dir()` removes a tree without ever raising.
* Every file route now works inside its own per-request directory.
* The two-step scramble workflow (`process_data` -> `scramble_and_download`)
  uses a **per-user** directory keyed by a random id stored in the session
  (`scramble_work_id`), so the intermediate `temp_data.json` and the final
  `scrambled_data.*` file are private to that user.

### Verified
A full scramble run was executed in a test harness; afterwards **zero new
files** appeared in the home directory or the working directory, and the
data was confirmed to live under the system temp path.

---

## 3. File comparison now supports Microsoft Word (.docx)

Yes — this was straightforward and is implemented.

* `FileComparer` now has a `_read_lines()` helper:
  * `.docx` files are read with `python-docx`: one line per paragraph, plus
    one line per table row (cells joined with ` | `), so both body text and
    table edits show up in the diff.
  * All other (text) files are read as before.
  * `.docx` can be compared against a plain-text file and vice versa.
  * Legacy `.doc` (the old binary format) is **not** supported by
    `python-docx`; the code detects it and returns a clear message asking the
    user to save as `.docx`.
* The existing side-by-side HTML diff engine is reused unchanged, so the
  visual output and CSS are identical.
* `.docx` was added to the allowed extensions for the compare route.

### New dependency
`python-docx` must be installed:

```
pip install python-docx
```

If it is missing, only the *file compare* feature is affected and it returns
a clear, friendly error — the rest of the app is unaffected (the import is
guarded).

### Verified
docx-vs-docx, docx-with-tables, docx-vs-txt, identical-docx detection, and
legacy-`.doc` rejection were all tested through the live HTTP route.

---

## 4. Cross-validation — bugs found and fixed

### 4a. `validate_query` — false positives **and** false negatives (critical)
* **Before:** it did a plain substring check, so a perfectly valid query like
  `SELECT id, created_at FROM users` was **rejected** because `created_at`
  contains `CREATE`. `updated_at` similarly tripped `UPDATE`. Meanwhile the
  method was **never actually called** by the execution path, which only did
  a weak `startswith('SELECT')` check — so a stacked query such as
  `SELECT 1; DROP TABLE x` would pass.
* **After:** word-boundary (`\b`) matching so identifiers are no longer
  flagged; stacked/multiple statements are rejected; `WITH ... SELECT` CTEs
  are allowed; and `validate_query` is now wired into **both** the mssql and
  oracle execution paths, and into `save_report` so bad queries are caught
  before they are ever stored.
* Verified with 9 test cases, all passing.

### 4b. `database_service.py` failed to import without both DB drivers
* **Before:** `import pyodbc` and `import cx_Oracle` at module top level.
  If either driver was not installed the **entire blueprint** failed to load,
  even for users who only needed SQL Server (or neither).
* **After:** drivers are imported lazily inside the methods that use them,
  with a clear `RuntimeError` if the needed driver is absent. The
  driver-specific `except` clauses were consolidated to `except Exception`
  so a missing-driver error cannot itself cause a `NameError`.

### 4c. ZIP path traversal ("zip slip")
* **Before:** `zip_ref.extractall()` in `FileSearcher.search_in_zip` and
  `DuplicateRemover.process_zip` would happily write entries like
  `../../../etc/cron.d/x` outside the temp directory.
* **After:** `_safe_extract_zip()` validates every member resolves inside the
  destination directory before extracting; a malicious archive is rejected.
* Verified: a crafted traversal archive is now blocked.

### 4d. Path traversal in download routes
* **Before:** `download_file` did `os.path.join(TEMP_DIR, filename)` with a
  `<path:filename>` route, so `/download/..%2f..%2f..%2fetc%2fpasswd` could
  escape the temp directory. `scramble_download_file` passed the filename
  straight to `send_file`, allowing **any file on disk** to be downloaded.
* **After:** `_resolve_within()` confirms the resolved path stays inside the
  allowed base directory; `scramble_download_file` only ever serves the two
  known output names from the current user's own directory.
* Verified: traversal attempt now returns 404.

### 4e. `import_servers` could crash in its own error handler
* **Before:** on failure it touched `import_record` after a `rollback()`,
  which can leave the ORM object detached/expired and raise a *second*
  exception, masking the original error.
* **After:** the failure is recorded against a freshly re-fetched row inside
  its own guarded block.

### 4f. Database sessions not always closed
* **Before:** `index()`, `configure_reports()`, `save_report()`,
  `delete_report()` and the database branch of `process_data()` could leak a
  session if an exception was raised before `close_db_session`.
* **After:** every session is closed in a `finally` block; write paths also
  `rollback()` on error.

### 4g. Missing input validation / error handling
* File extensions are now validated for every upload route (zip must be
  `.zip`, tabular must be `.csv/.xlsx/.xls`, compare must be a known text
  type or `.docx`).
* `chunk_size` is validated as a positive integer instead of letting `int()`
  raise an unhandled `ValueError`.
* `process_data` handles an unknown `data_source` and a missing report row
  instead of passing `None` into `execute_query` (which itself now
  null-checks `report`).
* `scramble_and_download` detects an expired session (missing
  `temp_data.json`) and asks the user to re-upload instead of throwing.
* All routes log full stack traces via `logger.exception(...)` while
  returning friendly messages to the user.

### 4h. `cleanup` route was unauthenticated
* **Before:** anyone could POST `/utility/cleanup` and wipe the temp area.
* **After:** it requires the `admin` role, consistent with the other admin
  routes.

---

## 5. Template changes

**None required.** `delete_report` accepts both `GET` and `POST`, so the
existing `<a href>` delete links in `configure_reports.html` continue to
work unchanged.

For better security you *may* later switch those links to a POST form (a
destructive `GET` can be triggered by prefetch or crawlers). The route
already supports POST. Example form:

```html
<form method="POST"
      action="{{ url_for('utility.delete_report', report_id=report.id) }}"
      onsubmit="return confirm('Delete this report?');"
      style="display:inline;">
  <button type="submit">Delete</button>
</form>
```

This is optional hardening, not a fix that is needed for the app to work.

---

## 6. Recommendations NOT applied (need your decision)

These are real production concerns but involve choices or infrastructure
outside these files, so they are flagged rather than changed:

1. **Stored DB passwords are plaintext.** `DatabaseReport.password` holds the
   credential as-is. For production it should be encrypted at rest (e.g.
   `cryptography.fernet` with a key from an environment variable / secrets
   manager). The code comments mark the spot.
2. **No CSRF protection.** The forms have no CSRF tokens. Adding
   `Flask-WTF`'s `CSRFProtect` is the standard fix but requires template
   updates app-wide.
3. **`pd.read_json(path)` is deprecated** in recent pandas for file paths.
   It still works today; longer term, read the file and pass a buffer:
   `pd.read_json(io.StringIO(open(path).read()))`.
4. **Temp file lifetime.** Per-request directories for streamed downloads
   (search/split) are intentionally left for the periodic `/cleanup` route to
   remove, because deleting them in a `finally` block could cut off an
   in-progress download. Consider a scheduled job (cron / APScheduler) that
   deletes entries older than, say, one hour.
5. **`scramble_service` performance.** It iterates cell-by-cell, which is
   fine for typical files but slow for very large datasets. Vectorising with
   pandas `.map` / `.apply` would help if you expect large inputs.
6. **`MAX_CONTENT_LENGTH`** is defined in `config.py` (100 MB default) but
   must be set on the Flask app object to take effect:
   `app.config['MAX_CONTENT_LENGTH'] = utility.config.MAX_CONTENT_LENGTH`.

---

## Files in this delivery

| File | Status |
|------|--------|
| `config.py` | **NEW** — centralised temp-dir handling |
| `routes.py` | Rewritten — same routes, production-hardened |
| `file_operations.py` | Patched — docx support, zip-slip protection |
| `database_service.py` | Patched — query validation, lazy driver imports |
| `scramble_service.py` | Unchanged (reviewed, logic correct) |
| `models.py` | Unchanged |
| `servers_models.py` | Unchanged |
| `__init__.py` | Unchanged |

---

# ADDENDUM — Front-end / route fixes (second review)

After reviewing the templates (`index.html`, `scramble_data.html`,
`server_admin.html`, `configure_reports.html`, `server_search.html`) and
`utility.js`, the following issues were found and fixed. **No template or
JavaScript file needs to be edited** — the routes were adjusted to match
what the existing front-end already sends.

## A. The "Clean Up Files" JSON error (your reported bug)

**Symptom:** clicking *Clean Up Files* showed
`An error occurred during cleanup: Unexpected token '<', "<!DOCTYPE "... is not valid JSON`.

**Cause:** `utility.js` `handleCleanup()` does `fetch('/utility/cleanup')`
then `response.json()`. The first review added `@require_auth('admin')` to
that route. When the auth check did not pass it returned an **HTML** page
(a login/error page beginning with `<!DOCTYPE`), and `response.json()`
cannot parse HTML — hence the error.

**Fix:**
* Removed `@require_auth('admin')` from `/utility/cleanup`. A route called
  by `fetch().json()` must never be behind a decorator that can emit HTML.
  The button is usable by **anyone who can see the page** (no login), as
  requested.
* The route now **always returns JSON**, for every outcome.
* **One click wipes ALL temporary files for every user** — every user's
  scramble working data, plus all the leftover scratch directories from
  file search, file split and duplicate removal, plus any loose files.
  This is a deliberate global wipe, per the requested behaviour.
* The base temp directory is recreated empty afterwards, so file
  operations keep working immediately.
* Files that are locked or mid-download are skipped rather than aborting
  the whole wipe.
* The calling user's stale `session` keys are cleared so their next run
  starts clean.

  Trade-off to be aware of: because this is a shared global wipe, if
  another user has a download or scramble in progress when the button is
  clicked, their temp data is removed too. This matches the requested
  behaviour ("wipe everyone's temp files").

Verified: the cleanup call returns `Content-Type: application/json` with
`{"message": "All temporary files cleaned up successfully", "removed": N}`,
removed two different users' scramble directories plus all scratch dirs in
testing, and temp operations still worked immediately afterwards.

## B. Server search was calling a non-existent URL

**Cause:** `server_search.html` calls `GET /utility/server-search/api`,
but the only route was `POST /utility/server-search/search`. A request to a
missing/method-mismatched URL returns an HTML 404/405 page — the same
"unexpected token `<`" class of failure. (This was broken in the original
code too.) Meanwhile `index.html` + `utility.js` correctly use
`POST /utility/server-search/search`.

**Fix:** the search API now answers on **both** URLs and **both** methods,
reading parameters from the query string or the form body:
* `POST /utility/server-search/search` — used by `index.html` / `utility.js`
* `GET  /utility/server-search/api`     — used by `server_search.html`

The JSON response also now includes an ordered `fields` list, which
`server_search.html` uses for stable column ordering.

## C. `server_search.html` had no page route

**Cause:** `server_admin.html` links to `url_for('utility.search_servers')`
as a normal GET link ("Search Servers" button), but no route rendered the
`server_search.html` page — the template was orphaned.

**Fix:** added `GET /utility/server-search` which renders
`server_search.html`. It is registered with `endpoint='search_servers'`, so
the existing `url_for('utility.search_servers')` in `server_admin.html`
resolves correctly with no template change. The JSON API keeps its own
endpoint name (`search_servers_api`).

## D. Net routing result

All original front-end calls now succeed:

| Front-end caller | URL it calls | Status |
|---|---|---|
| `utility.js` file search | `POST /utility/file-search` | works |
| `utility.js` file compare | `POST /utility/file-compare` | works (now incl. .docx) |
| `utility.js` file split | `POST /utility/file-split` | works |
| `utility.js` duplicate removal | `POST /utility/remove-duplicates` | works |
| `utility.js` duplicate download | `GET /utility/download/<path>` | works |
| `utility.js` cleanup | `POST /utility/cleanup` | **fixed** — returns JSON |
| `utility.js` server search | `POST /utility/server-search/search` | works |
| `server_search.html` search | `GET /utility/server-search/api` | **fixed** |
| `server_admin.html` "Search Servers" | `url_for('utility.search_servers')` | **fixed** — renders page |
| `configure_reports.html` save/delete | `save_report` / `delete_report` | works (see §5 re: delete) |
| `index.html` process data | `POST /utility/process_data` | works |

The §5 note: `delete_report` now accepts both GET and POST, so the existing
`configure_reports.html` delete links work with no template change.
Switching them to a POST form later is optional hardening only.

---

## E. Summary — no template or JavaScript edits needed

Every fix in this addendum was made in `routes.py` alone. `index.html`,
`scramble_data.html`, `server_admin.html`, `configure_reports.html`,
`server_search.html` and `utility.js` are all unchanged and all work.

## F. File Splitting — "Preserve header" was broken

**Symptom:** the *Preserve header* checkbox in the File Splitting Tool did
not work properly.

**Cause (in `file_operations.py`, `FileSplitter.split_file`):** the old code
did `if has_header and i > 0: chunk = pd.concat([df.iloc[:1], chunk])`.
When pandas reads a CSV/Excel file, the header row becomes `df.columns` — it
is **not** a row in `df`. So `df.iloc[:1]` is the **first data record**, not
the header. The old code therefore took the first data row and **injected a
duplicate of it at the top of every chunk after the first**. Example with
chunk size 2 — part 2 should be rows 3–4, but it produced:

```
id,name
1,Alice      <- WRONG: duplicate of row 1
3,Carol
4,Dave
```

Separately, `to_csv` / `to_excel` always wrote `df.columns` as a header
regardless of the checkbox, so unchecking *Preserve header* changed nothing.

**Fix:** the data is now split into clean, non-overlapping chunks (no row is
ever duplicated or injected), and the checkbox controls only whether the
header line is written:
* **Checked** — every chunk file repeats the column names, so each chunk is
  independently usable.
* **Unchecked** — only the first chunk has the header; the rest are raw
  data with no header line.

The route already read the checkbox correctly (`request.form.get('has_header')
== 'on'`; an unchecked HTML checkbox sends nothing, which correctly evaluates
to `False`), so no route or template change was needed.

Verified for both CSV and Excel, with the checkbox checked and unchecked:
chunks split correctly, all data rows preserved, none duplicated or lost.
