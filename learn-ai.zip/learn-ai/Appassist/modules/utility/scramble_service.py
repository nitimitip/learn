import pandas as pd
import os
import re
import random
import string
from datetime import datetime
import hashlib

class ScrambleService:
  def __init__(self):
    # Common patterns for intelligent scrambling
    self.email_pattern = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
    # Enhanced phone pattern to match various formats including UK numbers
    self.phone_pattern = re.compile(r'''
      (?:
        # UK mobile format: 07XXX XXX XXX
        \b0\d{4}\s?\d{3}\s?\d{3}\b
        |
        # International format: +44 XXX XXX XXXX
        \+\d{1,3}\s?\d{1,4}\s?\d{1,4}\s?\d{1,4}\b
        |
        # US/CA format: (XXX) XXX-XXXX or XXX-XXX-XXXX
        (?:\+?1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}
        |
        # General international: +XX XXXX XXXXXX
        \+\d{1,3}[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,6}
        |
        # Context-aware phone numbers (after "phone", "call", "contact", etc.)
        (?:phone|call|contact|tel|telephone)\s*[:\-]?\s*(?:\+?\d{1,3}[-.\s]?)?\d{3,4}[-.\s]?\d{3,4}[-.\s]?\d{3,6}
      )
    ''', re.VERBOSE | re.IGNORECASE)
    self.name_patterns = [
      re.compile(r'\b[A-Z][a-z]+\s+[A-Z][a-z]+\b'), # First Last
      re.compile(r'\b(Mr|Mrs|Ms|Dr|Prof)\.?\s+[A-Z][a-z]+\b'), # Title Name
    ]
    
    # Address keywords for intelligent detection
    self.address_keywords = ['street', 'st', 'avenue', 'ave', 'road', 'rd', 'lane', 'ln', 
                'drive', 'dr', 'circle', 'cir', 'court', 'ct', 'place', 'pl',
                'boulevard', 'blvd', 'highway', 'hwy', 'apartment', 'apt', 'suite']
  
  def scramble_data(self, df, custom_keywords, selected_columns, use_default_scramble, scramble_type='randomizing'):
    """
    Main scrambling function that applies different scrambling patterns
    """
    original_df = df.copy()
    stats = {
      'total_records': len(df),
      'keyword_scrambled': 0,
      'column_scrambled': 0,
      'default_scrambled': 0
    }
    
    # Apply custom keyword scrambling
    if custom_keywords:
      df, keyword_count = self._apply_keyword_scrambling(df, custom_keywords, scramble_type)
      stats['keyword_scrambled'] = keyword_count
    
    # Apply column scrambling
    if selected_columns:
      df, column_count = self._apply_column_scrambling(df, selected_columns, scramble_type)
      stats['column_scrambled'] = column_count
    
    # Apply default intelligent scrambling
    if use_default_scramble:
      df, default_count = self._apply_default_scrambling(df, scramble_type)
      stats['default_scrambled'] = default_count
    
    return df, stats
  
  def _apply_keyword_scrambling(self, df, custom_keywords, scramble_type='randomizing'):
    """
    Scramble data based on custom keywords
    """
    keywords = [k.strip().lower() for k in custom_keywords.split(',') if k.strip()]
    scrambled_count = 0
    
    for col in df.columns:
      for idx, value in df[col].items():
        if pd.isna(value):
          continue
          
        str_value = str(value).lower()
        
        # Check if any keyword is present
        for keyword in keywords:
          if keyword in str_value:
            # Find keyword position and scramble next words
            original_value = str(df.loc[idx, col])
            scrambled_value = self._scramble_next_words(original_value, keyword, scramble_type)
            if scrambled_value != original_value:
              df.loc[idx, col] = scrambled_value
              scrambled_count += 1
            break
    
    return df, scrambled_count
  
  def _scramble_next_words(self, text, keyword, scramble_type='randomizing'):
    """
    Find keyword and scramble the next two words or numbers
    """
    pattern = rf'\b{re.escape(keyword)}\b\s*[:\-\s]*\s*([A-Za-z0-9]+)(?:\s+([A-Za-z0-9]+))?'
    
    def replace_match(match):
      prefix = match.group(0)[:match.start(1) - match.start(0)]
      word1 = match.group(1)
      word2 = match.group(2) if match.group(2) else ''
      
      scrambled1 = self._scramble_word(word1, scramble_type)
      scrambled2 = self._scramble_word(word2, scramble_type) if word2 else ''
      
      result = prefix + scrambled1
      if scrambled2:
        result += ' ' + scrambled2
      
      return result
    
    return re.sub(pattern, replace_match, text, flags=re.IGNORECASE)
  
  def _apply_column_scrambling(self, df, selected_columns, scramble_type='randomizing'):
    """
    Scramble entire columns
    """
    scrambled_count = 0
    
    for col in selected_columns:
      if col in df.columns:
        for idx, value in df[col].items():
          if pd.isna(value):
            continue
          
          original_value = str(value)
          scrambled_value = self._scramble_word(original_value, scramble_type)
          df.loc[idx, col] = scrambled_value
          scrambled_count += 1
    
    return df, scrambled_count
  
  def _apply_default_scrambling(self, df, scramble_type='randomizing'):
    """
    Apply intelligent scrambling for emails, phones, names, addresses
    """
    scrambled_count = 0
    
    for col in df.columns:
      for idx, value in df[col].items():
        if pd.isna(value):
          continue
        
        str_value = str(value)
        original_value = str_value
        
        # Check for email addresses
        if self.email_pattern.search(str_value):
          str_value = self._scramble_emails(str_value, scramble_type)
          scrambled_count += 1
        
        # Check for phone numbers
        elif self.phone_pattern.search(str_value):
          str_value = self._scramble_phones(str_value, scramble_type)
          scrambled_count += 1
        
        # Check for names
        elif any(pattern.search(str_value) for pattern in self.name_patterns):
          str_value = self._scramble_names(str_value, scramble_type)
          scrambled_count += 1
        
        # Check for addresses
        elif any(keyword in str_value.lower() for keyword in self.address_keywords):
          str_value = self._scramble_addresses(str_value, scramble_type)
          scrambled_count += 1
        
        if str_value != original_value:
          df.loc[idx, col] = str_value
    
    return df, scrambled_count
  
  def _scramble_word(self, word, scramble_type='randomizing'):
    """
    Basic word scrambling function with different patterns
    """
    if not word or len(word) < 2:
      return word
    
    # Check if it's a number
    if word.isdigit():
      return self._scramble_number(word, scramble_type)
    
    # Check if it's mixed alphanumeric
    if any(c.isdigit() for c in word) and any(c.isalpha() for c in word):
      return self._scramble_alphanumeric(word, scramble_type)
    
    # Apply scrambling based on type
    if scramble_type == 'masking':
      return self._apply_masking(word)
    elif scramble_type == 'partial_hiding':
      return self._apply_partial_hiding(word)
    else: # randomizing (default)
      return self._apply_randomizing(word)
  
  def _apply_masking(self, word):
    """
    Replace characters with asterisks (*) or X
    """
    if len(word) <= 2:
      return '*' * len(word)
    
    # Keep first character, mask the rest
    return word[0] + '*' * (len(word) - 1)
  
  def _apply_partial_hiding(self, word):
    """
    Show only first and last characters, hide middle
    """
    if len(word) <= 2:
      return word
    elif len(word) == 3:
      return word[0] + '*' + word[-1]
    else:
      middle_length = len(word) - 2
      return word[0] + '*' * middle_length + word[-1]
  
  def _apply_randomizing(self, word):
    """
    Randomize character order (original behavior)
    """
    word_chars = list(word)
    
    # Keep first and last character if word is long enough
    if len(word) > 3:
      middle = word_chars[1:-1]
      random.shuffle(middle)
      return word_chars[0] + ''.join(middle) + word_chars[-1]
    else:
      # For short words, just scramble
      random.shuffle(word_chars)
      return ''.join(word_chars)
  
  def _scramble_number(self, number_str, scramble_type='randomizing'):
    """
    Scramble numeric values while maintaining format
    """
    if scramble_type == 'masking':
      # Mask all digits except first
      result = []
      first_digit_shown = False
      for char in number_str:
        if char.isdigit():
          if not first_digit_shown:
            result.append(char)
            first_digit_shown = True
          else:
            result.append('*')
        else:
          result.append(char)
      return ''.join(result)
    
    elif scramble_type == 'partial_hiding':
      # Show first and last digit, hide middle
      digits_positions = [(i, char) for i, char in enumerate(number_str) if char.isdigit()]
      if len(digits_positions) <= 2:
        return number_str
      
      result = list(number_str)
      for i, (pos, _) in enumerate(digits_positions[1:-1], 1):
        result[pos] = '*'
      return ''.join(result)
    
    else: # randomizing
      digits = [d for d in number_str if d.isdigit()]
      non_digits = [d for d in number_str if not d.isdigit()]
      
      # Scramble digits
      random.shuffle(digits)
      
      # Reconstruct
      result = []
      digit_idx = 0
      for char in number_str:
        if char.isdigit():
          result.append(digits[digit_idx])
          digit_idx += 1
        else:
          result.append(char)
      
      return ''.join(result)
  
  def _scramble_alphanumeric(self, text, scramble_type='randomizing'):
    """
    Scramble alphanumeric text
    """
    if scramble_type == 'masking':
      # Mask all except first character
      if len(text) <= 1:
        return text
      return text[0] + '*' * (len(text) - 1)
    
    elif scramble_type == 'partial_hiding':
      # Show first and last, hide middle
      if len(text) <= 2:
        return text
      return text[0] + '*' * (len(text) - 2) + text[-1]
    
    else: # randomizing
      result = []
      for char in text:
        if char.isalpha():
          if char.isupper():
            result.append(random.choice(string.ascii_uppercase))
          else:
            result.append(random.choice(string.ascii_lowercase))
        elif char.isdigit():
          result.append(random.choice(string.digits))
        else:
          result.append(char)
      return ''.join(result)
  
  def _scramble_emails(self, text, scramble_type='randomizing'):
    """
    Scramble email addresses while maintaining format
    """
    def scramble_email_match(match):
      email = match.group(0)
      local, domain = email.split('@')
      
      if scramble_type == 'masking':
        # Mask local part but keep first char and domain
        scrambled_local = local[0] + '*' * (len(local) - 1) if len(local) > 1 else local
        return f"{scrambled_local}@{domain}"
      
      elif scramble_type == 'partial_hiding':
        # Show first and last char of local part
        if len(local) <= 2:
          scrambled_local = local
        else:
          scrambled_local = local[0] + '*' * (len(local) - 2) + local[-1]
        return f"{scrambled_local}@{domain}"
      
      else: # randomizing
        # Scramble local part
        scrambled_local = self._scramble_word(local, scramble_type) if len(local) > 2 else 'user'
        
        # Keep domain structure but scramble
        domain_parts = domain.split('.')
        scrambled_domain = '.'.join([
          self._scramble_word(part, scramble_type) if i < len(domain_parts) - 1 else part
          for i, part in enumerate(domain_parts)
        ])
        
        return f"{scrambled_local}@{scrambled_domain}"
    
    return self.email_pattern.sub(scramble_email_match, text)
  
  def _scramble_phones(self, text, scramble_type='randomizing'):
    """
    Scramble phone numbers while maintaining format
    """
    def scramble_phone_match(match):
      phone = match.group(0)
      
      if scramble_type == 'masking':
        # Mask all digits except first few
        result = []
        digit_count = 0
        for char in phone:
          if char.isdigit():
            if digit_count < 3: # Show first 3 digits
              result.append(char)
            else:
              result.append('*')
            digit_count += 1
          else:
            result.append(char)
        return ''.join(result)
      
      elif scramble_type == 'partial_hiding':
        # Show first 3 and last 4 digits, hide middle
        digits = [char for char in phone if char.isdigit()]
        if len(digits) <= 7:
          return phone # Too short to hide
        
        result = []
        digit_index = 0
        for char in phone:
          if char.isdigit():
            if digit_index < 3 or digit_index >= len(digits) - 4:
              result.append(char)
            else:
              result.append('*')
            digit_index += 1
          else:
            result.append(char)
        return ''.join(result)
      
      else: # randomizing
        # Replace digits with random digits
        result = []
        for char in phone:
          if char.isdigit():
            result.append(random.choice(string.digits))
          else:
            result.append(char)
        return ''.join(result)
    
    return self.phone_pattern.sub(scramble_phone_match, text)
  
  def _scramble_names(self, text, scramble_type='randomizing'):
    """
    Scramble person names
    """
    words = text.split()
    scrambled_words = []
    
    for word in words:
      if word[0].isupper() and len(word) > 1: # Likely a name
        scrambled = self._scramble_word(word, scramble_type)
        # Ensure first letter remains uppercase for readability
        if scramble_type != 'masking': # Don't modify masking format
          scrambled = scrambled[0].upper() + scrambled[1:].lower()
        scrambled_words.append(scrambled)
      else:
        scrambled_words.append(word)
    
    return ' '.join(scrambled_words)
  
  def _scramble_addresses(self, text, scramble_type='randomizing'):
    """
    Scramble address information
    """
    words = text.split()
    scrambled_words = []
    
    for word in words:
      word_lower = word.lower()
      
      # Don't scramble address keywords themselves
      if word_lower not in self.address_keywords:
        # Check if it's a number (house number, etc.)
        if word.isdigit():
          scrambled_words.append(self._scramble_number(word, scramble_type))
        elif any(c.isdigit() for c in word): # Mixed
          scrambled_words.append(self._scramble_alphanumeric(word, scramble_type))
        else:
          scrambled_words.append(self._scramble_word(word, scramble_type))
      else:
        scrambled_words.append(word)
    
    return ' '.join(scrambled_words)