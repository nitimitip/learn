"""
Centralised configuration for the utility blueprint.

All temporary file handling goes through here so that:
  * Every upload and processed output lands in one known folder (utility_temp/).
  * Each request gets its own isolated working directory (multi-worker safe).
  * Temp data is reliably cleaned up via the /cleanup route or on demand.
"""
import os
import shutil
import tempfile
import logging

logger = logging.getLogger(__name__)

# Project root: appassist/modules/utility/config.py -> go up three levels.
_PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
)

# Base temp directory - a single, named folder inside the project root so
# the location is always predictable and easy to inspect / clean.
# Override with UTILITY_TEMP_DIR env-var if you need a different location
# (e.g. on a server where the project dir is read-only).
BASE_TEMP_DIR = os.environ.get(
    'UTILITY_TEMP_DIR',
    os.path.join(_PROJECT_ROOT, 'utility_temp'),
)

# Upload limits / allowed extensions (used for validation in routes).
MAX_CONTENT_LENGTH = int(os.environ.get('UTILITY_MAX_UPLOAD_BYTES', 100 * 1024 * 1024))  # 100 MB

ALLOWED_ZIP_EXT = {'.zip'}
ALLOWED_TABULAR_EXT = {'.csv', '.xlsx', '.xls'}
ALLOWED_COMPARE_EXT = {'.txt', '.csv', '.log', '.json', '.xml', '.html', '.md',
                       '.py', '.js', '.docx'}


def ensure_base_temp_dir():
    """Make sure the base temp directory exists. Safe to call repeatedly."""
    os.makedirs(BASE_TEMP_DIR, exist_ok=True)
    return BASE_TEMP_DIR


def new_request_temp_dir(prefix='req_'):
    """
    Create and return a fresh, unique temp directory for a single request.

    The caller is responsible for removing it (use cleanup_dir in a
    finally block, or the safe_temp_dir context manager).
    """
    ensure_base_temp_dir()
    return tempfile.mkdtemp(prefix=prefix, dir=BASE_TEMP_DIR)


def cleanup_dir(path):
    """Remove a directory tree, never raising on failure.

    Refuses to delete anything outside BASE_TEMP_DIR: every legitimate
    caller passes a per-request dir from new_request_temp_dir(), so a path
    that resolves elsewhere is a bug - log it instead of deleting.
    """
    if not path:
        return
    try:
        base = os.path.abspath(BASE_TEMP_DIR)
        target = os.path.abspath(path)
        if os.path.commonpath([base, target]) == base and target != base:
            if os.path.isdir(target):
                shutil.rmtree(target, ignore_errors=True)
        else:
            logger.error("cleanup_dir refused path outside temp area: %s", path)
    except ValueError:  # different drive on Windows
        logger.error("cleanup_dir refused path outside temp area: %s", path)
    except Exception as exc:  # pragma: no cover - defensive only
        logger.warning("Failed to clean up temp dir %s: %s", path, exc)


class safe_temp_dir:
    """
    Context manager that yields a unique per-request temp directory and
    guarantees cleanup afterwards.

        with safe_temp_dir() as tmp:
            ...  # use tmp
        # tmp is deleted here, even on exception
    """

    def __init__(self, prefix='req_'):
        self.prefix = prefix
        self.path = None

    def __enter__(self):
        self.path = new_request_temp_dir(self.prefix)
        return self.path

    def __exit__(self, exc_type, exc_val, exc_tb):
        cleanup_dir(self.path)
        return False  # never suppress exceptions
