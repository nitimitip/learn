from flask import Blueprint

# Create blueprint
utility_bp = Blueprint(
    'utility',
    __name__,
    static_folder='static',
    url_prefix='/utility'
)

# Import routes
from . import routes