import os
import shutil
import tempfile
import zipfile
import hashlib
import difflib
import logging
from typing import List, Dict, Tuple
import pandas as pd
from werkzeug.utils import secure_filename

logger = logging.getLogger(__name__)

# Optional dependency: python-docx. Used by FileComparer to read .docx files.
try:
    from docx import Document as _DocxDocument
    _DOCX_AVAILABLE = True
except Exception:  # pragma: no cover - import guard
    _DocxDocument = None
    _DOCX_AVAILABLE = False


def _safe_extract_zip(zip_ref, dest_dir):
    """
    Extract a ZIP archive while protecting against path-traversal
    ('zip slip') entries that would write outside dest_dir.
    """
    dest_root = os.path.realpath(dest_dir)
    for member in zip_ref.namelist():
        target = os.path.realpath(os.path.join(dest_dir, member))
        if not (target == dest_root or target.startswith(dest_root + os.sep)):
            raise Exception(f"Unsafe path in ZIP archive: {member}")
    zip_ref.extractall(dest_dir)


class FileSearcher:
    """Handles file search operations"""

    def __init__(self, temp_dir: str):
        self.temp_dir = temp_dir
        self.extract_dir = os.path.join(temp_dir, 'extracted')
        os.makedirs(self.extract_dir, exist_ok=True)

    def extract_search_terms_from_excel(self, excel_path: str) -> List[str]:
        """Extract search terms from Excel file"""
        try:
            df = pd.read_excel(excel_path)
            terms = []
            for column in df.columns:
                column_values = df[column].dropna().astype(str).tolist()
                terms.extend(column_values)
            terms = list(set([term.strip() for term in terms if term.strip()]))
            return terms
        except Exception as e:
            raise Exception(f"Failed to read Excel file: {str(e)}")

    def search_in_zip(self, zip_path: str, search_terms: List[str]) -> List[str]:
        """Search for terms in ZIP file contents"""
        matching_files = []
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                _safe_extract_zip(zip_ref, self.extract_dir)

            for root, dirs, files in os.walk(self.extract_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read().lower()
                        for term in search_terms:
                            if term.lower() in content:
                                matching_files.append(file_path)
                                break
                    except Exception:
                        continue
            return matching_files
        except Exception as e:
            raise Exception(f"Failed to search in ZIP file: {str(e)}")

    def create_result_zip(self, file_paths: List[str]) -> str:
        """Create ZIP file from matching files"""
        result_zip_path = os.path.join(self.temp_dir, 'search_results.zip')
        with zipfile.ZipFile(result_zip_path, 'w') as zip_ref:
            for file_path in file_paths:
                archive_name = os.path.relpath(file_path, self.extract_dir)
                zip_ref.write(file_path, archive_name)
        return result_zip_path


class FileComparer:
    """Handles file comparison operations with professional side-by-side diff.

    Supports plain-text formats and Microsoft Word (.docx) documents.
    """

    @staticmethod
    def _read_lines(file_path: str) -> List[str]:
        """
        Read a file into a list of lines suitable for diffing.

        .docx files are converted to text (one line per paragraph and one
        line per table cell). All other files are read as text.
        """
        ext = os.path.splitext(file_path)[1].lower()

        if ext == '.docx':
            if not _DOCX_AVAILABLE:
                raise Exception(
                    "Comparing Word (.docx) files requires the 'python-docx' "
                    "package. Install it with: pip install python-docx"
                )
            try:
                document = _DocxDocument(file_path)
            except Exception as exc:
                raise Exception(f"Could not open Word document: {exc}")

            lines: List[str] = []
            for para in document.paragraphs:
                lines.append(para.text + '\n')
            # Include table content so table edits are also surfaced.
            for table in document.tables:
                for row in table.rows:
                    cells = [cell.text.replace('\n', ' ') for cell in row.cells]
                    lines.append(' | '.join(cells) + '\n')
            return lines

        if ext == '.doc':
            raise Exception(
                "Legacy .doc files are not supported. Please save the document "
                "as .docx and try again."
            )

        with open(file_path, 'r', encoding='utf-8', errors='ignore') as fh:
            return fh.readlines()

    def compare_files(self, file1_path: str, file2_path: str) -> str:
        """Compare two files and return professional side-by-side HTML diff.

        Accepts plain-text files and Word (.docx) documents in any
        combination (e.g. a .docx vs a .txt).
        """
        try:
            lines1 = self._read_lines(file1_path)
            lines2 = self._read_lines(file2_path)

            return self._generate_professional_diff_html(
                lines1, lines2,
                os.path.basename(file1_path),
                os.path.basename(file2_path)
            )
        except Exception as e:
            raise Exception(f"Failed to compare files: {str(e)}")

    def _generate_professional_diff_html(self, lines1, lines2, file1_name, file2_name):
        """
        Generate professional side-by-side HTML diff using SequenceMatcher.
        Uses CSS variables defined in appTowerCard.css and custom.css.
        Embeds scoped styles so the output is self-contained when injected via JS.
        """
        # Build aligned row list
        matcher = difflib.SequenceMatcher(None, lines1, lines2, autojunk=False)
        rows = []

        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == 'equal':
                for k in range(i2 - i1):
                    rows.append({
                        'left_num':     i1 + k + 1,
                        'right_num':    j1 + k + 1,
                        'left_text':    lines1[i1 + k].rstrip('\n'),
                        'right_text':   lines2[j1 + k].rstrip('\n'),
                        'row_class':    'diff-equal',
                        'left_class':   '',
                        'right_class':  '',
                    })

            elif tag == 'replace':
                left_block  = [lines1[i].rstrip('\n') for i in range(i1, i2)]
                right_block = [lines2[j].rstrip('\n') for j in range(j1, j2)]
                span = max(len(left_block), len(right_block))
                for k in range(span):
                    has_left  = k < len(left_block)
                    has_right = k < len(right_block)
                    rows.append({
                        'left_num':    (i1 + k + 1) if has_left  else '',
                        'right_num':   (j1 + k + 1) if has_right else '',
                        'left_text':   left_block[k]  if has_left  else '',
                        'right_text':  right_block[k] if has_right else '',
                        'row_class':   'diff-modified',
                        'left_class':  'cell-deleted' if has_left  else 'cell-empty',
                        'right_class': 'cell-added'   if has_right else 'cell-empty',
                    })

            elif tag == 'delete':
                for k in range(i2 - i1):
                    rows.append({
                        'left_num':    i1 + k + 1,
                        'right_num':   '',
                        'left_text':   lines1[i1 + k].rstrip('\n'),
                        'right_text':  '',
                        'row_class':   'diff-deleted',
                        'left_class':  'cell-deleted',
                        'right_class': 'cell-empty',
                    })

            elif tag == 'insert':
                for k in range(j2 - j1):
                    rows.append({
                        'left_num':    '',
                        'right_num':   j1 + k + 1,
                        'left_text':   '',
                        'right_text':  lines2[j1 + k].rstrip('\n'),
                        'row_class':   'diff-added',
                        'left_class':  'cell-empty',
                        'right_class': 'cell-added',
                    })

        # Statistics
        total_lines  = len(rows)
        added_lines  = sum(1 for r in rows if r['row_class'] in ('diff-added',)   or r['right_class'] == 'cell-added')
        deleted_lines= sum(1 for r in rows if r['row_class'] in ('diff-deleted',) or r['left_class']  == 'cell-deleted')
        modified_lines = sum(1 for r in rows if r['row_class'] == 'diff-modified'
                             and r['left_class'] == 'cell-deleted' and r['right_class'] == 'cell-added')
        unchanged_lines = sum(1 for r in rows if r['row_class'] == 'diff-equal')
        has_diff = any(r['row_class'] != 'diff-equal' for r in rows)

        # Embedded scoped CSS
        # Uses --custom-* variables from appTowerCard.css where available,
        # with hardcoded fallbacks so the diff renders even without the vars.
        scoped_css = """
<style>
  .fc-wrap          { font-family: 'DM Sans', system-ui, sans-serif; }
  /* Stats bar */
  .fc-stats         { display:flex; gap:12px; flex-wrap:wrap; margin-bottom:16px; }
  .fc-stat-pill     { display:inline-flex; align-items:center; gap:6px;
                      padding:4px 14px; border-radius:999px; font-size:12px;
                      font-weight:600; letter-spacing:.3px; }
  .fc-stat-added    { background:var(--custom-healthy-backgroud,#DCFCE7);
                      color:var(--custom-healthy-text,#166534); }
  .fc-stat-deleted  { background:var(--custom-error-background,#FFE2E2);
                      color:var(--custom-error-text,#991b1b); }
  .fc-stat-modified { background:var(--custom-warning-background,#FEF3C6);
                      color:var(--custom-warning-text,#92400e); }
  .fc-stat-equal    { background:var(--custom-buttom-secondary-background,#F1F5F9);
                      color:var(--custom-secondary-text,#45556C); }
  /* File header bar */
  .fc-header        { display:grid; grid-template-columns:1fr 1fr;
                      border-radius:12px 12px 0 0; overflow:hidden;
                      border:1px solid var(--custom-border-color,#e9ecef);
                      border-bottom:none; }
  .fc-file-label    { padding:10px 16px; font-size:13px; font-weight:600;
                      display:flex; align-items:center; gap:8px; }
  .fc-file-label.left  { background:var(--custom-error-background,#FFE2E2);
                          color:var(--custom-error-text,#991b1b);
                          border-right:1px solid var(--custom-border-color,#e9ecef); }
  .fc-file-label.right { background:var(--custom-healthy-backgroud,#DCFCE7);
                          color:var(--custom-healthy-text,#166534); }
  .fc-file-label svg   { flex-shrink:0; }
  /* Diff table */
  .fc-table-wrap    { border:1px solid var(--custom-border-color,#e9ecef);
                      border-radius:0 0 12px 12px; overflow:auto;
                      max-height:620px; }
  .fc-table         { width:100%; border-collapse:collapse;
                      table-layout:fixed; font-size:12.5px; }
  .fc-table col.num { width:46px; }
  .fc-table col.code{ width:50%; }
  /* Line number cells */
  .fc-ln            { width:46px; min-width:46px; text-align:right;
                      padding:2px 8px; user-select:none;
                      font-size:11px; vertical-align:top; white-space:nowrap;
                      color:var(--custom-secondary-text,#45556C);
                      background:var(--custom-buttom-secondary-background,#F1F5F9);
                      border-right:1px solid var(--custom-border-color,#e9ecef); }
  /* Code cells */
  .fc-code          { padding:2px 10px; vertical-align:top;
                      word-break:break-all; white-space:pre-wrap; }
  .fc-code pre      { margin:0; padding:0; font-family:'Courier New',monospace;
                      font-size:12px; line-height:1.6; white-space:pre-wrap;
                      word-break:break-all; }
  /* Row colours */
  .diff-equal   .fc-code { background:#fff; }
  .diff-equal   .fc-ln   { background:var(--custom-buttom-secondary-background,#F1F5F9); }

  .cell-deleted      { background:var(--custom-error-background,#FFE2E2) !important; }
  .cell-deleted.fc-ln{ background:#fecaca !important; color:#991b1b !important; }

  .cell-added        { background:var(--custom-healthy-backgroud,#DCFCE7) !important; }
  .cell-added.fc-ln  { background:#bbf7d0 !important; color:#166534 !important; }

  .cell-empty        { background:var(--custom-buttom-secondary-background,#f8fafc) !important;
                       opacity:.55; }
  /* Divider between left and right panels */
  .fc-divider-ln, .fc-divider-code {
    border-left:2px solid var(--custom-border-color,#e9ecef) !important; }
  /* Legend */
  .fc-legend        { display:flex; gap:16px; flex-wrap:wrap;
                      padding:10px 16px; border-top:1px solid var(--custom-border-color,#e9ecef);
                      background:var(--custom-buttom-secondary-background,#F1F5F9);
                      border-radius:0 0 12px 12px; }
  .fc-legend-item   { display:flex; align-items:center; gap:6px;
                      font-size:12px; font-weight:500;
                      color:var(--custom-secondary-dark-text,#1D293D); }
  .fc-legend-dot    { width:12px; height:12px; border-radius:3px; flex-shrink:0; }
  .fc-no-diff       { padding:32px; text-align:center;
                      color:var(--custom-healthy-text,#166534);
                      font-weight:600; font-size:14px; }
</style>
"""

        # Identical-file short-circuit
        if not has_diff:
            return scoped_css + f"""
<div class="fc-wrap">
  <div class="fc-stats">
    <span class="fc-stat-pill fc-stat-equal">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
      {total_lines} identical lines
    </span>
  </div>
  <div class="fc-header">
    <div class="fc-file-label left">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm4 18H6V4h7v5h5v11z"/></svg>
      {self._escape_html(file1_name)}
    </div>
    <div class="fc-file-label right">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm4 18H6V4h7v5h5v11z"/></svg>
      {self._escape_html(file2_name)}
    </div>
  </div>
  <div class="fc-table-wrap">
    <div class="fc-no-diff">
      OK Files are identical - no differences found.
    </div>
  </div>
</div>"""

        # Stats bar
        stats_html = '<div class="fc-stats">'
        if added_lines:
            stats_html += f'<span class="fc-stat-pill fc-stat-added">+ {added_lines} added</span>'
        if deleted_lines:
            stats_html += f'<span class="fc-stat-pill fc-stat-deleted">- {deleted_lines} deleted</span>'
        if modified_lines:
            stats_html += f'<span class="fc-stat-pill fc-stat-modified">~ {modified_lines} modified</span>'
        if unchanged_lines:
            stats_html += f'<span class="fc-stat-pill fc-stat-equal">= {unchanged_lines} unchanged</span>'
        stats_html += '</div>'

        # File header bar
        file_icon = '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm4 18H6V4h7v5h5v11z"/></svg>'
        header_html = f"""
<div class="fc-header">
  <div class="fc-file-label left">{file_icon} {self._escape_html(file1_name)}</div>
  <div class="fc-file-label right">{file_icon} {self._escape_html(file2_name)}</div>
</div>"""

        # Diff table rows
        row_html_parts = []
        for row in rows:
            l_ln   = self._escape_html(str(row['left_num']))
            r_ln   = self._escape_html(str(row['right_num']))
            l_text = self._escape_html(row['left_text'])
            r_text = self._escape_html(row['right_text'])
            lc     = row['left_class']
            rc     = row['right_class']
            rc_cls = row['row_class']

            row_html_parts.append(f"""<tr class="{rc_cls}">
  <td class="fc-ln {lc}">{l_ln}</td>
  <td class="fc-code {lc}"><pre>{l_text}</pre></td>
  <td class="fc-ln {rc} fc-divider-ln">{r_ln}</td>
  <td class="fc-code {rc} fc-divider-code"><pre>{r_text}</pre></td>
</tr>""")

        table_html = f"""
<div class="fc-table-wrap">
  <table class="fc-table">
    <colgroup>
      <col class="num"><col class="code"><col class="num"><col class="code">
    </colgroup>
    <tbody>
{''.join(row_html_parts)}
    </tbody>
  </table>
</div>"""

        # Legend
        legend_html = """
<div class="fc-legend">
  <span class="fc-legend-item">
    <span class="fc-legend-dot" style="background:var(--custom-healthy-backgroud,#DCFCE7);border:1px solid #bbf7d0"></span>Added
  </span>
  <span class="fc-legend-item">
    <span class="fc-legend-dot" style="background:var(--custom-error-background,#FFE2E2);border:1px solid #fecaca"></span>Deleted
  </span>
  <span class="fc-legend-item">
    <span class="fc-legend-dot" style="background:var(--custom-warning-background,#FEF3C6);border:1px solid #fde68a"></span>Modified
  </span>
  <span class="fc-legend-item">
    <span class="fc-legend-dot" style="background:var(--custom-buttom-secondary-background,#F1F5F9);border:1px solid #e2e8f0"></span>Unchanged
  </span>
</div>"""

        return scoped_css + f"""
<div class="fc-wrap">
  {stats_html}
  {header_html}
  {table_html}
  {legend_html}
</div>"""

    def _escape_html(self, text):
        """Escape HTML special characters"""
        return (str(text)
                .replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;')
                .replace('"', '&quot;')
                .replace("'", '&#x27;'))


class FileSplitter:
    """Handles file splitting operations"""

    def __init__(self, temp_dir: str):
        self.temp_dir = temp_dir
        self.split_dir = os.path.join(temp_dir, 'split_files')
        os.makedirs(self.split_dir, exist_ok=True)

    def split_file(self, file_path: str, chunk_size: int, has_header: bool) -> str:
        """Split an Excel/CSV file into chunks.

        The uploaded file is assumed to have a header row, which pandas
        consumes into the column names (it is NOT one of the data rows).

        has_header controls how that header appears in the output chunks:
          * True  - every chunk file repeats the column names as its own
                    header row, so each chunk is independently usable.
          * False - only the first chunk keeps the header row; the
                    remaining chunks contain raw data with no header.

        Note: the data rows themselves are split identically either way -
        only the presence of the header line in chunks 2..N changes.
        """
        file_ext  = os.path.splitext(file_path)[1].lower()
        base_name = os.path.splitext(os.path.basename(file_path))[0]

        try:
            if file_ext in ['.xlsx', '.xls']:
                df = pd.read_excel(file_path)
            elif file_ext == '.csv':
                df = pd.read_csv(file_path)
            else:
                raise Exception("Unsupported file format. Please use Excel or CSV files.")

            total_rows = len(df)
            if total_rows == 0:
                raise Exception("The uploaded file contains no data rows to split.")

            # Build (index, chunk) pairs. Each chunk is a clean slice of the
            # data - no rows are duplicated or injected.
            chunks = [
                (idx, df.iloc[i:i + chunk_size])
                for idx, i in enumerate(range(0, total_rows, chunk_size))
            ]

            split_files = []
            for idx, chunk in chunks:
                chunk_filename = f"{base_name}_part_{idx + 1:03d}{file_ext}"
                chunk_path     = os.path.join(self.split_dir, chunk_filename)

                # Decide whether THIS chunk gets a header row.
                #   has_header == True  -> every chunk gets one
                #   has_header == False -> only the first chunk gets one
                write_header = has_header or (idx == 0)

                if file_ext in ['.xlsx', '.xls']:
                    chunk.to_excel(chunk_path, index=False, header=write_header)
                else:
                    chunk.to_csv(chunk_path, index=False, header=write_header)
                split_files.append(chunk_path)

            zip_path = os.path.join(self.temp_dir, f"{base_name}_split.zip")
            with zipfile.ZipFile(zip_path, 'w') as zip_ref:
                for fp in split_files:
                    zip_ref.write(fp, os.path.basename(fp))

            return zip_path

        except Exception as e:
            raise Exception(f"Failed to split file: {str(e)}")


class DuplicateRemover:
    """Handles duplicate file removal operations"""

    def __init__(self, temp_dir: str):
        self.temp_dir       = temp_dir
        self.extract_dir    = os.path.join(temp_dir, 'duplicate_check')
        self.unique_dir     = os.path.join(temp_dir, 'unique_files')
        self.duplicate_dir  = os.path.join(temp_dir, 'duplicate_files')

        os.makedirs(self.extract_dir,   exist_ok=True)
        os.makedirs(self.unique_dir,    exist_ok=True)
        os.makedirs(self.duplicate_dir, exist_ok=True)

    def calculate_file_hash(self, file_path: str) -> str:
        """Calculate SHA-256 hash of file content"""
        hash_sha256 = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_sha256.update(chunk)
            return hash_sha256.hexdigest()
        except Exception:
            return None

    def process_zip(self, zip_path: str) -> Tuple[str, str, List[Dict]]:
        """Process ZIP file to identify and separate duplicates"""
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                _safe_extract_zip(zip_ref, self.extract_dir)

            file_hashes    = {}
            duplicate_list = []

            for root, dirs, files in os.walk(self.extract_dir):
                for file in files:
                    file_path  = os.path.join(root, file)
                    file_hash  = self.calculate_file_hash(file_path)
                    if not file_hash:
                        continue

                    relative_path = os.path.relpath(file_path, self.extract_dir)

                    if file_hash in file_hashes:
                        duplicate_list.append({
                            'original':  file_hashes[file_hash],
                            'duplicate': relative_path,
                            'hash':      file_hash,
                        })
                        dup_dest = os.path.join(self.duplicate_dir, relative_path)
                        os.makedirs(os.path.dirname(dup_dest), exist_ok=True)
                        shutil.copy2(file_path, dup_dest)
                    else:
                        file_hashes[file_hash] = relative_path
                        uniq_dest = os.path.join(self.unique_dir, relative_path)
                        os.makedirs(os.path.dirname(uniq_dest), exist_ok=True)
                        shutil.copy2(file_path, uniq_dest)

            unique_zip_path    = os.path.join(self.temp_dir, 'unique_files.zip')
            duplicate_zip_path = os.path.join(self.temp_dir, 'duplicate_files.zip')

            with zipfile.ZipFile(unique_zip_path, 'w') as zip_ref:
                for root, dirs, files in os.walk(self.unique_dir):
                    for file in files:
                        fp = os.path.join(root, file)
                        zip_ref.write(fp, os.path.relpath(fp, self.unique_dir))

            with zipfile.ZipFile(duplicate_zip_path, 'w') as zip_ref:
                for root, dirs, files in os.walk(self.duplicate_dir):
                    for file in files:
                        fp = os.path.join(root, file)
                        zip_ref.write(fp, os.path.relpath(fp, self.duplicate_dir))

            return (
                os.path.basename(unique_zip_path),
                os.path.basename(duplicate_zip_path) if duplicate_list else None,
                duplicate_list,
            )

        except Exception as e:
            raise Exception(f"Failed to process duplicates: {str(e)}")