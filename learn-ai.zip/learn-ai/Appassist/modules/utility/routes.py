import io
import json
import os
import shutil
import logging

from flask import (render_template, request, flash, redirect, url_for,
                   send_file, jsonify, session, abort)
from werkzeug.utils import secure_filename

import pandas as pd
from sqlalchemy import or_
from sqlalchemy.exc import SQLAlchemyError

from auth import get_current_user, require_auth
from crypto_utils import encrypt_data
from database import get_db_session, close_db_session
from . import utility_bp
from .file_operations import (
    FileSearcher, FileComparer, FileSplitter, DuplicateRemover
)
from .servers_models import ServerData, FieldMapping, ServerImport, DatabaseReport
from .scramble_service import ScrambleService
from .database_service import DatabaseService
from . import encoder_service
from . import data_analysis_service
from .config import (BASE_TEMP_DIR, ALLOWED_ZIP_EXT, ALLOWED_TABULAR_EXT,
                     ALLOWED_COMPARE_EXT, ensure_base_temp_dir,
                     new_request_temp_dir, cleanup_dir, safe_temp_dir)

logger = logging.getLogger(__name__)

# Initialise services (stateless, safe to share across requests).
scramble_service = ScrambleService()
database_service = DatabaseService()


# DATA-SAFETY HELPERS

def _df_to_safe_records(df_slice):
    """
    Convert a DataFrame slice to plain-Python dicts that are safe for both
    Jinja2 rendering and Flask's JSON-based session serialisation.

    Problems this solves:
      * pandas / numpy scalar types (int64, float64 ...) are NOT JSON-serialisable.
        Flask's cookie-session uses json.dumps; any numpy type in the session
        raises TypeError and replaces the response with a 500 error BEFORE the
        page is sent to the browser - so the preview never appears.
      * float NaN / Inf values also fail JSON serialisation and render as the
        string 'nan' in Jinja (because ``nan is not none`` is True).

    Conversions applied:
      numpy scalar  -> Python native int / float  (via .item())
      NaN / Inf     -> None                       (JSON null; Jinja renders as '')
      all dict keys -> str                        (guards against numpy string types)
    """
    result = []
    for row in df_slice.to_dict('records'):
        safe = {}
        for k, v in row.items():
            safe[str(k)] = _json_safe_value(v)
        result.append(safe)
    return result


def _json_safe_value(v):
    """
    Convert a single pandas/numpy scalar into a plain-Python value that both
    json.dumps and SQLAlchemy's JSON column can serialise.

      pandas/Python datetime -> ISO-8601 string  (Timestamp is NOT JSON-serialisable)
      numpy scalar           -> Python native int / float (via .item())
      NaN / NaT / Inf        -> None
      everything else        -> unchanged
    """
    import math
    import datetime as _dt

    # pandas NaT / NaN / None -> None (pd.isna raises on array-likes, so guard).
    try:
        if v is None or (pd.api.types.is_scalar(v) and pd.isna(v)):
            return None
    except (TypeError, ValueError):
        pass

    # pandas Timestamp / datetime / date -> ISO string.
    if isinstance(v, (pd.Timestamp, _dt.datetime, _dt.date)):
        return v.isoformat()

    if hasattr(v, 'item'):               # numpy scalar -> Python native
        v = v.item()

    if isinstance(v, float) and not math.isfinite(v):  # NaN / Inf -> None
        v = None

    return v

# Make sure the base temp directory exists at import time. All per-request
# work happens in unique sub-directories created via new_request_temp_dir().
ensure_base_temp_dir()


# HELPERS

def _ext(filename):
    """Lower-case file extension including the leading dot."""
    return os.path.splitext(filename or '')[1].lower()


def _save_upload(file_storage, dest_dir):
    """
    Save an uploaded file into dest_dir using a sanitised name and return
    the full path. Rejects empty / unnamed uploads.
    """
    if not file_storage or not file_storage.filename:
        raise ValueError("No file provided")
    safe_name = secure_filename(file_storage.filename)
    if not safe_name:
        raise ValueError("Invalid file name")
    path = os.path.join(dest_dir, safe_name)
    file_storage.save(path)
    return path


def _resolve_within(base_dir, filename):
    """
    Safely resolve `filename` inside `base_dir`, defending against
    path-traversal. Returns the absolute path or None if it escapes base_dir.
    """
    base_real = os.path.realpath(base_dir)
    candidate = os.path.realpath(os.path.join(base_dir, filename))
    if candidate == base_real or candidate.startswith(base_real + os.sep):
        return candidate
    return None


def _user_data_dir():
    """
    Per-user persistent temp directory for the scramble workflow, which
    spans two requests (process_data -> scramble_and_download).

    Keyed by a value stored in the session so concurrent users never
    overwrite each other's intermediate data.
    """
    import uuid
    work_id = session.get('scramble_work_id')
    if not work_id:
        work_id = uuid.uuid4().hex
        session['scramble_work_id'] = work_id
    path = os.path.join(BASE_TEMP_DIR, 'scramble', secure_filename(work_id))
    os.makedirs(path, exist_ok=True)
    return path


# INDEX

@utility_bp.route('/')
@require_auth()
def index():
    """Utility tools main page"""
    user = get_current_user()
    db_session = get_db_session()
    try:
        reports = db_session.query(DatabaseReport).all()
    finally:
        close_db_session(db_session)
    return render_template('utility/index.html', user=user, reports=reports)


# FILE OPERATIONS

@utility_bp.route('/file-search', methods=['POST'])
@require_auth()
def file_search():
    """Handle file search operation"""
    work_dir = None
    try:
        zip_file = request.files.get('zip_file')
        excel_file = request.files.get('excel_file')
        search_text = request.form.get('search_text', '').strip()

        if not zip_file or zip_file.filename == '':
            return jsonify({'error': 'No ZIP file provided'}), 400
        if _ext(zip_file.filename) not in ALLOWED_ZIP_EXT:
            return jsonify({'error': 'Uploaded file must be a .zip archive'}), 400

        work_dir = new_request_temp_dir('search_')
        temp_zip = _save_upload(zip_file, work_dir)

        search_terms = []
        if search_text:
            search_terms.append(search_text)

        if excel_file and excel_file.filename != '':
            if _ext(excel_file.filename) not in ALLOWED_TABULAR_EXT:
                return jsonify({'error': 'Search term file must be CSV or Excel'}), 400
            temp_excel = _save_upload(excel_file, work_dir)
            searcher = FileSearcher(work_dir)
            excel_terms = searcher.extract_search_terms_from_excel(temp_excel)
            search_terms.extend(excel_terms)

        if not search_terms:
            return jsonify({'error': 'No search terms provided'}), 400

        searcher = FileSearcher(work_dir)
        results = searcher.search_in_zip(temp_zip, search_terms)

        if not results:
            return jsonify({'message': 'No files found containing the search terms'})

        if len(results) == 1:
            result_file = results[0]
            return send_file(result_file, as_attachment=True,
                             download_name=os.path.basename(result_file))
        zip_path = searcher.create_result_zip(results)
        return send_file(zip_path, as_attachment=True,
                         download_name='search_results.zip')

    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.exception("File search failed")
        return jsonify({'error': f'Search failed: {str(e)}'}), 500
    finally:
        # send_file streams the response before this runs; for large files
        # consider Flask's send_file(..., conditional=True). Cleanup is
        # deferred to the periodic /cleanup route to avoid deleting a file
        # mid-stream. We only remove the uploaded zip copy here.
        pass


@utility_bp.route('/file-compare', methods=['POST'])
@require_auth()
def file_compare():
    """Handle file comparison operation.

    Supports plain-text files and Microsoft Word (.docx) documents.
    """
    try:
        file1 = request.files.get('file1')
        file2 = request.files.get('file2')

        if not file1 or not file2 or file1.filename == '' or file2.filename == '':
            return jsonify({'error': 'Two files are required for comparison'}), 400

        for f in (file1, file2):
            if _ext(f.filename) not in ALLOWED_COMPARE_EXT:
                return jsonify({
                    'error': (f"Unsupported file type '{_ext(f.filename)}'. "
                              f"Allowed: {', '.join(sorted(ALLOWED_COMPARE_EXT))}")
                }), 400

        with safe_temp_dir('compare_') as work_dir:
            temp_file1 = _save_upload(file1, work_dir)
            temp_file2 = _save_upload(file2, work_dir)

            comparer = FileComparer()
            comparison_html = comparer.compare_files(temp_file1, temp_file2)

        return jsonify({'html': comparison_html})

    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.exception("File comparison failed")
        return jsonify({'error': f'Comparison failed: {str(e)}'}), 500


@utility_bp.route('/file-split', methods=['POST'])
@require_auth()
def file_split():
    """Handle file splitting operation"""
    try:
        upload_file = request.files.get('split_file')

        try:
            chunk_size = int(request.form.get('chunk_size', 1000))
        except (TypeError, ValueError):
            return jsonify({'error': 'Chunk size must be a whole number'}), 400
        if chunk_size < 1:
            return jsonify({'error': 'Chunk size must be at least 1'}), 400

        has_header = request.form.get('has_header') == 'on'

        if not upload_file or upload_file.filename == '':
            return jsonify({'error': 'No file provided for splitting'}), 400
        if _ext(upload_file.filename) not in ALLOWED_TABULAR_EXT:
            return jsonify({'error': 'File to split must be CSV or Excel'}), 400

        work_dir = new_request_temp_dir('split_')
        temp_file = _save_upload(upload_file, work_dir)

        splitter = FileSplitter(work_dir)
        result_zip = splitter.split_file(temp_file, chunk_size, has_header)

        return send_file(result_zip, as_attachment=True,
                         download_name='split_files.zip')

    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.exception("File splitting failed")
        return jsonify({'error': f'File splitting failed: {str(e)}'}), 500


@utility_bp.route('/remove-duplicates', methods=['POST'])
@require_auth()
def remove_duplicates():
    """Handle duplicate file removal operation"""
    try:
        zip_file = request.files.get('duplicate_zip')

        if not zip_file or zip_file.filename == '':
            return jsonify({'error': 'No ZIP file provided'}), 400
        if _ext(zip_file.filename) not in ALLOWED_ZIP_EXT:
            return jsonify({'error': 'Uploaded file must be a .zip archive'}), 400

        work_dir = new_request_temp_dir('dedup_')
        temp_zip = _save_upload(zip_file, work_dir)

        remover = DuplicateRemover(work_dir)
        unique_zip, duplicate_zip, duplicate_list = remover.process_zip(temp_zip)

        # The download route needs to find these files. Return paths
        # relative to BASE_TEMP_DIR so /download can resolve them safely.
        rel_dir = os.path.relpath(work_dir, BASE_TEMP_DIR)
        return jsonify({
            'unique_zip': os.path.join(rel_dir, unique_zip),
            'duplicate_zip': (os.path.join(rel_dir, duplicate_zip)
                              if duplicate_zip else None),
            'duplicates': duplicate_list,
        })

    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.exception("Duplicate removal failed")
        return jsonify({'error': f'Duplicate removal failed: {str(e)}'}), 500


@utility_bp.route('/download/<path:filename>')
@require_auth()
def download_file(filename):
    """Download processed files (path-traversal safe)."""
    try:
        file_path = _resolve_within(BASE_TEMP_DIR, filename)
        if file_path and os.path.isfile(file_path):
            return send_file(file_path, as_attachment=True,
                             download_name=os.path.basename(file_path))
        return jsonify({'error': 'File not found'}), 404
    except Exception as e:
        logger.exception("Download failed")
        return jsonify({'error': f'Download failed: {str(e)}'}), 500


@utility_bp.route('/temp-status')
@require_auth()
def temp_status():
    """
    Return a JSON summary of what is currently sitting in the temp folder.
    Used by the frontend to show the file count / size next to Clean Up Files.
    """
    try:
        total_files = 0
        total_bytes = 0
        if os.path.isdir(BASE_TEMP_DIR):
            for root, dirs, files in os.walk(BASE_TEMP_DIR):
                for fname in files:
                    try:
                        total_bytes += os.path.getsize(os.path.join(root, fname))
                        total_files += 1
                    except OSError:
                        pass
        return jsonify({
            'files': total_files,
            'bytes': total_bytes,
            'path':  BASE_TEMP_DIR,
        })
    except Exception as e:
        logger.exception("temp-status failed")
        return jsonify({'error': str(e)}), 500


@utility_bp.route('/cleanup', methods=['POST'])
@require_auth()
def cleanup_files():
    """
    Clean up ALL temporary files for every user, in one click.

    This route is called by JavaScript (fetch -> response.json()), so it
    MUST always return JSON - never an HTML page. It therefore uses no auth
    decorator that could redirect to a login/error page; it handles every
    outcome itself and always responds with JSON.

    It removes everything under the base temp directory:
      * every user's scramble working data,
      * all leftover per-request scratch directories from the file tools
        (search / split / dedup / import), and
      * any loose files.
    The base temp directory itself is recreated empty afterwards.

    NOTE: this is a shared, global wipe by design. If another user has a
    download or scramble in progress when this is clicked, their temp data
    is removed too. Files that are locked / mid-stream are skipped rather
    than causing the whole operation to fail.
    """
    try:
        removed = 0

        if os.path.isdir(BASE_TEMP_DIR):
            for name in os.listdir(BASE_TEMP_DIR):
                path = os.path.join(BASE_TEMP_DIR, name)
                try:
                    if os.path.isfile(path) or os.path.islink(path):
                        os.remove(path)
                        removed += 1
                    elif os.path.isdir(path):
                        # ignore_errors=True skips any file currently locked
                        # (e.g. mid-download) instead of aborting the wipe.
                        shutil.rmtree(path, ignore_errors=True)
                        removed += 1
                except OSError:
                    # Locked / in-use entry - skip it, keep going.
                    continue

        # Recreate the base temp directory so subsequent operations work.
        ensure_base_temp_dir()

        # Clear this user's stale session state too, so their next run
        # starts cleanly (other users' sessions are untouched - that is
        # not something a single request can reach).
        for key in ('scramble_work_id', 'original_preview',
                    'total_records', 'columns'):
            session.pop(key, None)

        return jsonify({
            'message': 'All temporary files cleaned up successfully',
            'removed': removed,
        })
    except Exception as e:
        logger.exception("Cleanup failed")
        return jsonify({'error': f'Cleanup failed: {str(e)}'}), 500


# SERVER SEARCH

@utility_bp.route('/server-search', methods=['GET'], endpoint='search_servers')
@require_auth()
def server_search_page():
    """Render the standalone Server Search page.

    server_admin.html links here via url_for('utility.search_servers').
    The actual searching is done by JavaScript calling the API route below.
    """
    user = get_current_user()
    return render_template('utility/server_search.html', user=user)


@utility_bp.route('/server-search/search', methods=['POST', 'GET'])
@utility_bp.route('/server-search/api', methods=['GET', 'POST'])
@require_auth()
def search_servers_api():
    """Server search JSON API.

    Both URLs and both HTTP methods are accepted so every existing
    front-end keeps working:
      * index.html / utility.js  -> POST /utility/server-search/search
      * server_search.html       -> GET  /utility/server-search/api
    Parameters are read from the form body or the query string,
    whichever is present.
    """
    search_term = (request.values.get('search_term') or '').strip()
    active_server = request.values.get('ActiveServer')
    logger.info("Server search requested (active_server=%s)", active_server)

    if not search_term:
        return jsonify({'error': 'Please enter a search term'}), 400

    db_session = get_db_session()
    try:
        search_conditions = []

        if '.' in search_term or ':' in search_term:
            search_conditions.append(ServerData.ip_address.ilike(f'%{search_term}%'))

        search_conditions.append(ServerData.server_name.ilike(f'%{search_term}%'))

        if search_term.endswith('*'):
            app_search = search_term[:-1]
            search_conditions.append(ServerData.application_name.ilike(f'{app_search}%'))
        else:
            search_conditions.append(ServerData.application_name.ilike(f'%{search_term}%'))

        query = db_session.query(ServerData).filter(or_(*search_conditions))
        if active_server:
            query = query.filter(ServerData.status == active_server)

        results = query.all()
        display_mappings = (db_session.query(FieldMapping)
                            .filter_by(is_displayed=True)
                            .order_by(FieldMapping.display_order)
                            .all())

        formatted_results = []
        for server in results:
            server_data = {}
            for mapping in display_mappings:
                field_value = None
                if hasattr(server, mapping.mapped_field):
                    field_value = getattr(server, mapping.mapped_field)
                if field_value is None and server.raw_data:
                    field_value = server.raw_data.get(mapping.mapped_field)
                server_data[mapping.display_name] = field_value or 'N/A'
            formatted_results.append(server_data)

        # 'fields' gives the front-end a stable, ordered column list
        # (server_search.html uses data.fields; utility.js ignores it).
        fields = [m.display_name for m in display_mappings]

        return jsonify({
            'results': formatted_results,
            'count': len(formatted_results),
            'fields': fields,
        })

    except Exception as e:
        logger.exception("Server search failed")
        return jsonify({'error': f'Search failed: {str(e)}'}), 500
    finally:
        close_db_session(db_session)


@utility_bp.route('/server-search/admin')
@require_auth('admin')
def server_admin():
    """Admin configuration page"""
    db_session = get_db_session()
    try:
        mappings = db_session.query(FieldMapping).order_by(FieldMapping.display_order).all()
        imports = (db_session.query(ServerImport)
                   .order_by(ServerImport.created_at.desc())
                   .limit(10)
                   .all())
        return render_template('utility/server_admin.html',
                               mappings=mappings, imports=imports,
                               user=get_current_user())
    finally:
        close_db_session(db_session)


@utility_bp.route('/server-search/admin/field-mapping', methods=['POST'])
@require_auth('admin')
def add_field_mapping():
    """Add or update field mapping"""
    display_name = request.form.get('display_name', '').strip()
    mapped_field = request.form.get('mapped_field', '').strip()
    is_searchable = request.form.get('is_searchable') == 'on'
    is_displayed = request.form.get('is_displayed') == 'on'

    try:
        display_order = int(request.form.get('display_order', 0))
    except (TypeError, ValueError):
        display_order = 0

    mapping_id = request.form.get('mapping_id')

    if not display_name or not mapped_field:
        flash('Display name and mapped field are required', 'error')
        return redirect(url_for('utility.server_admin'))

    db_session = get_db_session()
    try:
        if mapping_id:
            mapping = db_session.query(FieldMapping).filter_by(id=mapping_id).first()
            if mapping:
                mapping.display_name = display_name
                mapping.mapped_field = mapped_field
                mapping.is_searchable = is_searchable
                mapping.is_displayed = is_displayed
                mapping.display_order = display_order
                flash('Field mapping updated successfully', 'success')
            else:
                flash('Field mapping not found', 'error')
        else:
            mapping = FieldMapping(
                display_name=display_name,
                mapped_field=mapped_field,
                is_searchable=is_searchable,
                is_displayed=is_displayed,
                display_order=display_order,
            )
            db_session.add(mapping)
            flash('Field mapping added successfully', 'success')
        db_session.commit()
    except SQLAlchemyError as e:
        db_session.rollback()
        logger.exception("Field mapping save failed")
        flash(f'Database error: {str(e)}', 'error')
    finally:
        close_db_session(db_session)

    return redirect(url_for('utility.server_admin'))


@utility_bp.route('/server-search/admin/field-mapping/<int:mapping_id>/delete', methods=['POST'])
@require_auth('admin')
def delete_field_mapping(mapping_id):
    """Delete field mapping"""
    db_session = get_db_session()
    try:
        mapping = db_session.query(FieldMapping).filter_by(id=mapping_id).first()
        if mapping:
            db_session.delete(mapping)
            db_session.commit()
            flash('Field mapping deleted successfully', 'success')
        else:
            flash('Field mapping not found', 'error')
    except SQLAlchemyError as e:
        db_session.rollback()
        logger.exception("Field mapping delete failed")
        flash(f'Database error: {str(e)}', 'error')
    finally:
        close_db_session(db_session)
    return redirect(url_for('utility.server_admin'))


def _sync_application_support(db_session):
    """Push the current estate into Application Support's Server Details and
    return the flash message describing what moved.

    Imported inside the function on purpose: modules.application_support
    imports servers_models from this package at import time, so a top-level
    import here would close the circle.

    A failure here must never lose the import that just succeeded, so the
    error is reported rather than raised.
    """
    try:
        from modules.application_support.server_sync import sync_server_details
        result = sync_server_details(db_session)
    except Exception as exc:
        db_session.rollback()
        logger.exception("Application Support server sync failed")
        return f'Server records imported, but Application Support could not be refreshed: {exc}'
    return (f"Application Support refreshed: {result['updated']} server "
            f"row(s) updated of {result['matched']} matched; "
            f"{result['external']} external row(s) left unchanged.")


@utility_bp.route('/server-search/admin/import', methods=['POST'])
@require_auth('admin')
def import_servers():
    """Import server data from Excel file"""
    if 'file' not in request.files:
        flash('No file selected', 'error')
        return redirect(url_for('utility.server_admin'))

    file = request.files['file']
    if file.filename == '':
        flash('No file selected', 'error')
        return redirect(url_for('utility.server_admin'))

    if _ext(file.filename) not in {'.xlsx', '.xls'}:
        flash('Please upload an Excel file (.xlsx or .xls)', 'error')
        return redirect(url_for('utility.server_admin'))

    work_dir = new_request_temp_dir('import_')
    filename = secure_filename(file.filename)
    upload_path = os.path.join(work_dir, filename)
    file.save(upload_path)

    db_session = get_db_session()
    import_record = None
    try:
        import_record = ServerImport(
            filename=filename,
            imported_by=get_current_user().username,
            import_status='pending',
        )
        db_session.add(import_record)
        db_session.commit()

        df = pd.read_excel(upload_path)
        db_session.query(ServerData).delete()

        records_imported = 0
        for _, row in df.iterrows():
            row_data = row.to_dict()
            cleaned_data = {str(k): _json_safe_value(v) for k, v in row_data.items()}
            server = ServerData(
                raw_data=cleaned_data,
                ip_address=cleaned_data.get('ip_address') or cleaned_data.get('IP Address'),
                server_name=cleaned_data.get('Name') or cleaned_data.get('hostname'),
                OS=str(cleaned_data.get('Operating System', '')) if cleaned_data.get('Operating System') else None,
                os_version=str(cleaned_data.get('OS Version', '')) if cleaned_data.get('OS Version') else None,
                application_name=cleaned_data.get('Description') or cleaned_data.get('app_name'),
                location=cleaned_data.get('Location') or cleaned_data.get('datacenter'),
                environment=cleaned_data.get('environment') or cleaned_data.get('Environment'),
                domain=cleaned_data.get('DNS Domain') or cleaned_data.get('domain'),
                status=cleaned_data.get('Install Status') or cleaned_data.get('status'),
                system_type=cleaned_data.get('Manufacturer') or cleaned_data.get('manufacturer'),
            )
            db_session.add(server)
            records_imported += 1

        import_record.records_imported = records_imported
        import_record.import_status = 'success'
        db_session.commit()
        flash(f'Successfully imported {records_imported} server records', 'success')

        # The estate is the system of record for Location / OS / Environment,
        # so every Application Support server row that names a host in the
        # new file is refreshed from it. Rows the estate does not know about
        # (external servers) are left alone - see server_sync.
        flash(_sync_application_support(db_session), 'info')

    except Exception as e:
        db_session.rollback()
        logger.exception("Server import failed")
        # Record the failure on a fresh, consistent state.
        try:
            if import_record is not None and import_record.id is not None:
                failed = db_session.query(ServerImport).get(import_record.id)
                if failed:
                    failed.import_status = 'failed'
                    failed.error_message = str(e)
                    db_session.commit()
        except Exception:
            db_session.rollback()
            logger.exception("Could not record import failure")
        flash(f'Import failed: {str(e)}', 'error')
    finally:
        close_db_session(db_session)
        cleanup_dir(work_dir)

    return redirect(url_for('utility.server_admin'))


@utility_bp.route('/server-search/admin/sync-application-support', methods=['POST'])
@require_auth('admin')
def sync_application_support():
    """Re-run the Application Support refresh against the estate as it stands.

    The import already does this; this is the button for when the estate was
    changed some other way, or an application was added after the last
    import.
    """
    db_session = get_db_session()
    try:
        flash(_sync_application_support(db_session), 'info')
    finally:
        close_db_session(db_session)
    return redirect(url_for('utility.server_admin'))


@utility_bp.route('/server-search/admin/initialize-defaults', methods=['POST'])
@require_auth('admin')
def initialize_defaults():
    """Initialize default field mappings"""
    db_session = get_db_session()
    try:
        existing_count = db_session.query(FieldMapping).count()
        if existing_count > 0:
            flash('Field mappings already exist', 'warning')
            return redirect(url_for('utility.server_admin'))

        default_mappings = [
            {'display_name': 'IP Address',       'mapped_field': 'ip_address',       'is_searchable': True,  'is_displayed': True, 'display_order': 1},
            {'display_name': 'Host Name',        'mapped_field': 'server_name',      'is_searchable': True,  'is_displayed': True, 'display_order': 2},
            {'display_name': 'Application Name', 'mapped_field': 'application_name', 'is_searchable': True,  'is_displayed': True, 'display_order': 3},
            {'display_name': 'Data Center',      'mapped_field': 'location',         'is_searchable': False, 'is_displayed': True, 'display_order': 4},
            {'display_name': 'Environment',      'mapped_field': 'environment',      'is_searchable': False, 'is_displayed': True, 'display_order': 5},
            {'display_name': 'RAM',              'mapped_field': 'ram',              'is_searchable': False, 'is_displayed': True, 'display_order': 6},
            {'display_name': 'Disk Size',        'mapped_field': 'disk_size',        'is_searchable': False, 'is_displayed': True, 'display_order': 7},
            {'display_name': 'OS Version',       'mapped_field': 'os_version',       'is_searchable': False, 'is_displayed': True, 'display_order': 8},
        ]
        for md in default_mappings:
            db_session.add(FieldMapping(**md))

        db_session.commit()
        flash('Default field mappings initialised successfully', 'success')

    except SQLAlchemyError as e:
        db_session.rollback()
        logger.exception("Initialize defaults failed")
        flash(f'Database error: {str(e)}', 'error')
    finally:
        close_db_session(db_session)

    return redirect(url_for('utility.server_admin'))


# DATA SCRAMBLING

@utility_bp.route('/scramble_data')
@require_auth()
def scramble_data():
    """Data scrambling landing page"""
    reports = []
    db_session = get_db_session()
    try:
        if session.get('admin'):
            reports = db_session.query(DatabaseReport).all()
    finally:
        close_db_session(db_session)
    return render_template('utility/scramble_data.html', reports=reports,
                           user=get_current_user())


@utility_bp.route('/configure_reports')
@require_auth('admin')
def configure_reports():
    db_session = get_db_session()
    try:
        reports = db_session.query(DatabaseReport).all()
    finally:
        close_db_session(db_session)
    return render_template('utility/configure_reports.html', reports=reports,
                           user=get_current_user())


@utility_bp.route('/save_report', methods=['POST'])
@require_auth('admin')
def save_report():
    db_session = get_db_session()
    try:
        required = ['report_name', 'database_type', 'connection_host',
                    'connection_port', 'database_name', 'username',
                    'password', 'sql_query']
        missing = [f for f in required if not request.form.get(f, '').strip()]
        if missing:
            flash(f"Missing required fields: {', '.join(missing)}", 'danger')
            return redirect(url_for('utility.configure_reports'))

        # Reject queries that are not safe read-only statements up front.
        is_valid, message = database_service.validate_query(
            request.form['sql_query'])
        if not is_valid:
            flash(f'Invalid SQL query: {message}', 'danger')
            return redirect(url_for('utility.configure_reports'))

        report = DatabaseReport(
            report_name=request.form['report_name'],
            database_type=request.form['database_type'],
            connection_host=request.form['connection_host'],
            connection_port=request.form['connection_port'],
            database_name=request.form['database_name'],
            username=request.form['username'],
            password=encrypt_data(request.form['password']),  # encrypted at rest
            sql_query=request.form['sql_query'],
        )
        db_session.add(report)
        db_session.commit()
        flash('Report configuration saved successfully', 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception("Save report failed")
        flash(f'Error saving report: {str(e)}', 'danger')
    finally:
        close_db_session(db_session)
    return redirect(url_for('utility.configure_reports'))


@utility_bp.route('/delete_report/<int:report_id>', methods=['POST'])
@require_auth('admin')
def delete_report(report_id):
    # POST only. The application-wide CSRF gate (csrf_utils.enforce_csrf)
    # covers POST/PUT/PATCH/DELETE and NOT GET, so a GET-deletable route sits
    # outside it: any page an administrator opened could fire this with an
    # <img src>. configure_reports.html posts a token-carrying form.
    db_session = get_db_session()
    try:
        report = db_session.query(DatabaseReport).filter_by(id=report_id).first()
        if report:
            db_session.delete(report)
            db_session.commit()
            flash('Report deleted successfully', 'success')
        else:
            flash('Report not found', 'warning')
    except Exception as e:
        db_session.rollback()
        logger.exception("Delete report failed")
        flash(f'Error deleting report: {str(e)}', 'danger')
    finally:
        close_db_session(db_session)
    return redirect(url_for('utility.configure_reports'))


@utility_bp.route('/process_data', methods=['POST'])
@require_auth()
def process_data():
    try:
        data_source = request.form.get('data_source')
        df = None

        if data_source == 'file':
            if 'file' not in request.files:
                flash('No file selected', 'danger')
                return redirect(url_for('utility.scramble_data'))

            file = request.files['file']
            if file.filename == '':
                flash('No file selected', 'danger')
                return redirect(url_for('utility.scramble_data'))

            ext = _ext(file.filename)
            if ext not in ALLOWED_TABULAR_EXT:
                flash('Unsupported file format. Please use CSV or Excel files.', 'danger')
                return redirect(url_for('utility.scramble_data'))

            work_dir = new_request_temp_dir('scr_in_')
            try:
                filepath = _save_upload(file, work_dir)
                if ext == '.csv':
                    try:
                        df = pd.read_csv(filepath, encoding='utf-8')
                    except UnicodeDecodeError:
                        df = pd.read_csv(filepath, encoding='ISO-8859-1')
                else:
                    df = pd.read_excel(filepath)
            finally:
                cleanup_dir(work_dir)

        elif data_source == 'database':
            report_id = request.form.get('selected_report')
            if not report_id:
                flash('Please select a database report', 'danger')
                return redirect(url_for('utility.scramble_data'))

            db_session = get_db_session()
            try:
                report = db_session.query(DatabaseReport).filter_by(id=report_id).first()
            finally:
                close_db_session(db_session)

            if report is None:
                flash('Selected database report was not found', 'danger')
                return redirect(url_for('utility.scramble_data'))

            df = database_service.execute_query(report)
            if df is None:
                flash('Failed to retrieve data from database', 'danger')
                return redirect(url_for('utility.scramble_data'))
        else:
            flash('Please choose a valid data source', 'danger')
            return redirect(url_for('utility.scramble_data'))

        if df is None or df.empty:
            flash('No data found to process', 'warning')
            return redirect(url_for('utility.scramble_data'))

        original_preview = _df_to_safe_records(df.head(10))
        columns       = [str(c) for c in df.columns.tolist()]
        total_records = int(len(df))

        # Store preview metadata on disk, NOT in the session cookie
        # The cookie limit is ~4 KB; 10 preview rows can easily exceed that,
        # causing browsers to silently drop the cookie and lose session state.
        # Only `scramble_work_id` (a 32-char hex) lives in the cookie; all
        # larger data goes into the per-user temp directory.
        user_dir  = _user_data_dir()   # ensures work_id is created & saved
        meta_path = os.path.join(user_dir, 'preview_meta.json')
        with open(meta_path, 'w', encoding='utf-8') as _fh:
            json.dump({'original_preview': original_preview,
                       'total_records':    total_records,
                       'columns':          columns}, _fh)

        # Persist the working dataset in a per-user temp file (NOT the
        # project directory). It is reloaded by /scramble_and_download.
        data_path = os.path.join(user_dir, 'temp_data.json')
        df.to_json(data_path, orient='records')

        db_session = get_db_session()
        try:
            reports = db_session.query(DatabaseReport).all() if session.get('admin') else []
        finally:
            close_db_session(db_session)

        return render_template('utility/scramble_data.html',
                               original_preview=original_preview,
                               columns=columns,
                               total_records=total_records,
                               show_preview=True,
                               reports=reports,
                               user=get_current_user())

    except Exception as e:
        logger.exception("Process data failed")
        flash(f'Error processing data: {str(e)}', 'danger')
        return redirect(url_for('utility.scramble_data'))


@utility_bp.route('/scramble_and_download', methods=['POST'])
@require_auth()
def scramble_and_download():
    try:
        data_path = os.path.join(_user_data_dir(), 'temp_data.json')
        if not os.path.isfile(data_path):
            flash('Your session expired. Please upload the data again.', 'warning')
            return redirect(url_for('utility.scramble_data'))

        df = pd.read_json(data_path, orient='records')

        custom_keywords = request.form.get('custom_keywords', '').strip()
        selected_columns = request.form.getlist('selected_columns')
        use_default_scramble = 'default_scramble' in request.form
        scramble_type = request.form.get('scramble_type', 'randomizing')

        scrambled_df, stats = scramble_service.scramble_data(
            df.copy(), custom_keywords, selected_columns,
            use_default_scramble, scramble_type
        )

        scrambled_preview = _df_to_safe_records(scrambled_df.head(10))
        output_format = request.form.get('output_format', 'excel')

        # Load original preview + metadata from the file written by process_data.
        # (We no longer store these in the session cookie to stay under 4 KB.)
        out_dir   = _user_data_dir()
        meta_path = os.path.join(out_dir, 'preview_meta.json')
        _meta = {}
        if os.path.isfile(meta_path):
            with open(meta_path, 'r', encoding='utf-8') as _fh:
                _meta = json.load(_fh)
        original_preview = _meta.get('original_preview', [])
        _columns         = _meta.get('columns', session.get('columns', []))
        _total_records   = _meta.get('total_records', session.get('total_records', 0))

        # Write the scrambled result into the per-user temp directory.
        if output_format == 'excel':
            output_name = 'scrambled_data.xlsx'
            scrambled_df.to_excel(os.path.join(out_dir, output_name), index=False)
        else:
            output_name = 'scrambled_data.csv'
            scrambled_df.to_csv(os.path.join(out_dir, output_name), index=False)

        db_session = get_db_session()
        try:
            reports = db_session.query(DatabaseReport).all() if session.get('admin') else []
        finally:
            close_db_session(db_session)

        return render_template('utility/scramble_data.html',
                               original_preview=original_preview,
                               scrambled_preview=scrambled_preview,
                               columns=_columns,
                               total_records=_total_records,
                               stats=stats,
                               show_preview=True,
                               show_results=True,
                               download_file=output_name,
                               reports=reports,
                               user=get_current_user())

    except Exception as e:
        logger.exception("Scramble and download failed")
        flash(f'Error scrambling data: {str(e)}', 'danger')
        return redirect(url_for('utility.scramble_data'))


@utility_bp.route('/scrambledownload/<filename>')
@require_auth()
def scramble_download_file(filename):
    try:
        # Only ever serve from the current user's own scramble directory,
        # and only the known output names. Defends against path traversal.
        safe_name = secure_filename(filename)
        if safe_name not in {'scrambled_data.xlsx', 'scrambled_data.csv'}:
            abort(404)

        file_path = _resolve_within(_user_data_dir(), safe_name)
        if not file_path or not os.path.isfile(file_path):
            flash('File not found or session expired', 'warning')
            return redirect(url_for('utility.scramble_data'))

        return send_file(file_path, as_attachment=True,
                         download_name=safe_name)
    except Exception as e:
        logger.exception("Scramble download failed")
        flash(f'Error downloading file: {str(e)}', 'danger')
        return redirect(url_for('utility.scramble_data'))


# About  (explains the module to end users and the support team)

@utility_bp.route('/about')
@require_auth()
def about():
    user = get_current_user()
    return render_template('utility/about.html', user=user)


# ENCODER / DECODER

# Shared sub-folder under the utility temp dir: uploads AND generated downloads
# both live here, so the single "Clean Up Files" button clears everything.
ENCODER_DIR_NAME = 'encoder'


def _encoder_dir():
    """Return (and create) the shared encoder upload/output directory."""
    path = os.path.join(BASE_TEMP_DIR, ENCODER_DIR_NAME)
    os.makedirs(path, exist_ok=True)
    return path


@utility_bp.route('/encoder-decoder')
@require_auth()
def encoder_decoder():
    """Render the standalone Encoder / Decoder page."""
    user = get_current_user()
    return render_template(
        'utility/encoder_decoder.html',
        user=user,
        schemes=encoder_service.SCHEMES,
    )


@utility_bp.route('/encoder-decoder/run', methods=['POST'])
@require_auth()
def encoder_decoder_run():
    """
    Encode or decode either a typed-in string or an uploaded file.

    Always returns JSON (called via fetch). On success it writes the result
    to the shared encoder temp folder and returns a preview plus a download
    URL pointing at the existing /download route.
    """
    work_path = None
    try:
        mode   = (request.form.get('mode') or '').strip().lower()
        scheme = (request.form.get('scheme') or '').strip().lower()
        source = (request.form.get('source') or 'text').strip().lower()

        if mode not in ('encode', 'decode'):
            return jsonify({'error': 'Choose Encode or Decode.'}), 400
        if not encoder_service.is_valid_scheme(scheme):
            return jsonify({'error': 'Unknown encoding type selected.'}), 400

        enc_dir = _encoder_dir()
        origin_name = 'input.txt'

        # Gather raw input bytes
        if source == 'file':
            file = request.files.get('file')
            if not file or not file.filename:
                return jsonify({'error': 'No file selected.'}), 400
            work_path = _save_upload(file, enc_dir)
            origin_name = os.path.basename(work_path)
            data = encoder_service.read_input_bytes(work_path)
        else:
            text = request.form.get('text_input', '')
            if text == '':
                return jsonify({'error': 'Enter some text to process.'}), 400
            data = text.encode('utf-8')

        # Transform
        result = encoder_service.transform(scheme, mode, data)

        # Build a text preview (binary-safe)
        try:
            preview = result.decode('utf-8')
            is_binary = False
        except UnicodeDecodeError:
            preview = ''
            is_binary = True

        PREVIEW_LIMIT = 100_000  # chars
        truncated = len(preview) > PREVIEW_LIMIT
        if truncated:
            preview = preview[:PREVIEW_LIMIT]

        # Persist the output so it can be downloaded
        ext = '.bin' if is_binary else '.txt'
        custom_name = (request.form.get('output_name') or '').strip()
        if custom_name:
            # User-supplied name wins. Respect their extension; if they gave
            # none, fall back to the binary/text default so the file is usable.
            out_name = secure_filename(custom_name)
            if not out_name:
                return jsonify({'error': 'Invalid output filename.'}), 400
            if not os.path.splitext(out_name)[1]:
                out_name += ext
        else:
            stem = os.path.splitext(origin_name)[0] or 'input'
            out_name = secure_filename(f"{stem}_{mode}d{ext}") or f"{mode}d_output{ext}"
        out_path = os.path.join(enc_dir, out_name)
        with open(out_path, 'wb') as fh:
            fh.write(result)

        # /download resolves paths relative to BASE_TEMP_DIR.
        rel_name = f"{ENCODER_DIR_NAME}/{out_name}"
        return jsonify({
            'ok': True,
            'mode': mode,
            'scheme': scheme,
            'preview': preview,
            'is_binary': is_binary,
            'truncated': truncated,
            'bytes': len(result),
            'download_url': url_for('utility.download_file', filename=rel_name),
            'download_name': out_name,
        })

    except encoder_service.EncoderError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.exception("Encoder/decoder failed")
        return jsonify({'error': f'Operation failed: {str(e)}'}), 500


# DATA ANALYSIS
#
# Stateless by design: files are parsed inside a per-request temp dir that is
# deleted before the response returns. The browser keeps the parsed dataset and
# sends it back for pivot operations; charts are rendered client-side. Nothing
# is written to the database or persisted on the server.

def _display_name(user):
    """'First Last' for the export's Summary sheet; falls back to username."""
    if not user:
        return None
    fn = (getattr(user, 'firstname', '') or '').strip().title()
    ln = (getattr(user, 'lastname', '') or '').strip().title()
    return f"{fn} {ln}".strip() or getattr(user, 'username', None)


@utility_bp.route('/data-analysis')
@require_auth()
def data_analysis():
    """Render the Data Analysis page."""
    user = get_current_user()
    return render_template(
        'utility/data_analysis.html',
        user=user,
        aggfuncs=data_analysis_service.PIVOT_AGGFUNCS,
        chart_types=data_analysis_service.CHART_TYPES,
        chart_hints=data_analysis_service.CHART_HINTS,
        filter_ops=data_analysis_service.FILTER_OPS,
        filter_ops_no_value=list(data_analysis_service.FILTER_OPS_NO_VALUE),
        dedupe_keep=data_analysis_service.DEDUPE_KEEP,
        vlookup_hows=data_analysis_service.VLOOKUP_HOWS,
        text_ops=data_analysis_service.TEXT_OPS,
        text_op_hints=data_analysis_service.TEXT_OP_HINTS,
        text_op_fields=data_analysis_service.TEXT_OP_FIELDS,
        text_ops_multi=list(data_analysis_service.TEXT_OPS_MULTI),
    )


@utility_bp.route('/data-analysis/analyze', methods=['POST'])
@require_auth()
def data_analysis_analyze():
    """
    Parse an uploaded CSV / Excel file and return the auto-generated basic
    analysis, column metadata and the (row-capped) dataset as JSON.

    Excel multi-sheet handling: if no sheet is chosen and the workbook has more
    than one sheet, the list of sheet names is returned (HTTP 200, needs_sheet)
    so the browser can prompt the user, then re-submit with the same file plus
    the chosen ``sheet_name``.
    """
    try:
        file = request.files.get('file')
        if not file or not file.filename:
            return jsonify({'error': 'No file selected.'}), 400

        if _ext(file.filename) not in ALLOWED_TABULAR_EXT:
            return jsonify({
                'error': 'Unsupported file type. Upload a .csv, .xlsx or .xls file.'
            }), 400

        sheet_name = (request.form.get('sheet_name') or '').strip() or None

        with safe_temp_dir(prefix='da_') as tmp:
            path = _save_upload(file, tmp)

            # For a multi-sheet workbook with no sheet chosen yet, ask first.
            if data_analysis_service.is_excel(file.filename) and not sheet_name:
                sheets = data_analysis_service.list_excel_sheets(path)
                if len(sheets) > 1:
                    return jsonify({'needs_sheet': True, 'sheets': sheets})

            df, sheets = data_analysis_service.read_tabular(
                path, file.filename, sheet_name=sheet_name
            )

            payload = {
                'ok': True,
                'filename': file.filename,
                'sheet': sheet_name,
                'sheets': sheets,
                'analysis': data_analysis_service.basic_analysis(df),
                'columns': data_analysis_service.column_meta(df),
                'records': data_analysis_service.df_to_records(df),
                'row_cap': data_analysis_service.MAX_CLIENT_ROWS,
            }
        return jsonify(payload)

    except data_analysis_service.DataAnalysisError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.exception("Data analysis upload failed")
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500


@utility_bp.route('/data-analysis/pivot', methods=['POST'])
@require_auth()
def data_analysis_pivot():
    """
    Build a pivot table from data the browser sends back. Accepts JSON:
        { records: [...], column_order: [...], index: [...], columns: [...],
          values: "col", aggfunc: "sum" }
    Returns the pivot rendered as an HTML table. No server-side state.
    """
    try:
        body = request.get_json(silent=True) or {}
        df = data_analysis_service.records_to_df(
            body.get('records'), body.get('column_order'))
        html = data_analysis_service.build_pivot(
            df,
            index=body.get('index'),
            columns=body.get('columns'),
            values=body.get('values'),
            aggfunc=(body.get('aggfunc') or '').strip().lower(),
        )
        return jsonify({'ok': True, 'html': html})

    except data_analysis_service.DataAnalysisError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.exception("Pivot table build failed")
        return jsonify({'error': f'Pivot failed: {str(e)}'}), 500


@utility_bp.route('/data-analysis/filter', methods=['POST'])
@require_auth()
def data_analysis_filter():
    """
    Filter the dataset the browser sends back. Accepts JSON:
        { records: [...], column_order: [...],
          filters: [{column, op, value}, ...], match: "all"|"any" }
    Returns the matching rows (capped) plus a preview table and match counts.
    No server-side state.
    """
    try:
        body = request.get_json(silent=True) or {}
        df = data_analysis_service.records_to_df(
            body.get('records'), body.get('column_order'))
        out = data_analysis_service.apply_filters(
            df, body.get('filters'), body.get('match') or 'all'
        )
        return jsonify({
            'ok': True,
            'matched': int(len(out)),
            'total': int(len(df)),
            'records': data_analysis_service.df_to_records(out),
            'preview': data_analysis_service.preview_html(out),
        })
    except data_analysis_service.DataAnalysisError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.exception("Data filter failed")
        return jsonify({'error': f'Filter failed: {str(e)}'}), 500


@utility_bp.route('/data-analysis/export', methods=['POST'])
@require_auth()
def data_analysis_export():
    """
    Stream the supplied records back as a downloadable CSV or Excel file.
    Accepts JSON:
        { records: [...], column_order: [...], format: "csv"|"xlsx",
          filename: "name", sheet: "Sheet1", step: "VLOOKUP",
          lookup_columns: [...] }
    The Excel branch renders a themed workbook; `lookup_columns` shades the
    columns a VLOOKUP brought across differently from the master data.
    """
    try:
        body = request.get_json(silent=True) or {}
        df = data_analysis_service.records_to_df(
            body.get('records'), body.get('column_order'))
        stem = os.path.splitext(os.path.basename(body.get('filename') or 'data'))[0]
        user = get_current_user()
        content, mimetype, ext = data_analysis_service.export_bytes(
            df, body.get('format'),
            title=f"Data Export - {stem or 'data'}",
            lookup_columns=body.get('lookup_columns'),
            meta={
                'filename': body.get('filename'),
                'sheet': body.get('sheet'),
                'step': body.get('step'),
                'prepared_by': _display_name(user),
            },
        )
        return send_file(
            io.BytesIO(content),
            mimetype=mimetype,
            as_attachment=True,
            download_name=f"{stem or 'data'}_export.{ext}",
        )
    except data_analysis_service.DataAnalysisError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.exception("Data export failed")
        return jsonify({'error': f'Export failed: {str(e)}'}), 500


def _result_payload(df, **extra):
    """Standard JSON result for a transform op: records + preview + column meta."""
    payload = {
        'ok': True,
        'rows': int(len(df)),
        'columns': data_analysis_service.column_meta(df),
        'records': data_analysis_service.df_to_records(df),
        'preview': data_analysis_service.preview_html(df),
    }
    payload.update(extra)
    return payload


@utility_bp.route('/data-analysis/parse', methods=['POST'])
@require_auth()
def data_analysis_parse():
    """
    Lightweight parse for a *second* (lookup) file used by VLOOKUP: return its
    columns + (row-capped) records so the browser can hold it client-side and
    run the merge statelessly. Mirrors the multi-sheet handling of /analyze.
    """
    try:
        file = request.files.get('file')
        if not file or not file.filename:
            return jsonify({'error': 'No file selected.'}), 400
        if _ext(file.filename) not in ALLOWED_TABULAR_EXT:
            return jsonify({'error': 'Unsupported file type. Upload a .csv, .xlsx or .xls file.'}), 400

        sheet_name = (request.form.get('sheet_name') or '').strip() or None
        with safe_temp_dir(prefix='da_lookup_') as tmp:
            path = _save_upload(file, tmp)
            if data_analysis_service.is_excel(file.filename) and not sheet_name:
                sheets = data_analysis_service.list_excel_sheets(path)
                if len(sheets) > 1:
                    return jsonify({'needs_sheet': True, 'sheets': sheets})
            df, sheets = data_analysis_service.read_tabular(path, file.filename, sheet_name=sheet_name)
            return jsonify({
                'ok': True,
                'filename': file.filename,
                'sheet': sheet_name,
                'sheets': sheets,
                'columns': data_analysis_service.column_meta(df),
                'records': data_analysis_service.df_to_records(df),
            })
    except data_analysis_service.DataAnalysisError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.exception("Lookup file parse failed")
        return jsonify({'error': f'Could not read the file: {str(e)}'}), 500


@utility_bp.route('/data-analysis/dedupe', methods=['POST'])
@require_auth()
def data_analysis_dedupe():
    """
    Remove duplicate rows. JSON:
        { records, column_order, subset: [...], keep: "first"|"last"|"none" }.
    Returns the deduped dataset + before/after/removed counts. No server state.
    """
    try:
        body = request.get_json(silent=True) or {}
        df = data_analysis_service.records_to_df(
            body.get('records'), body.get('column_order'))
        out, stats = data_analysis_service.remove_duplicates(
            df, subset=body.get('subset'), keep=(body.get('keep') or 'first').strip().lower()
        )
        return jsonify(_result_payload(out, stats=stats))
    except data_analysis_service.DataAnalysisError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.exception("Remove duplicates failed")
        return jsonify({'error': f'Remove duplicates failed: {str(e)}'}), 500


@utility_bp.route('/data-analysis/sort', methods=['POST'])
@require_auth()
def data_analysis_sort():
    """Sort the dataset. JSON: { records, column_order, by: [...], ascending: bool }."""
    try:
        body = request.get_json(silent=True) or {}
        df = data_analysis_service.records_to_df(
            body.get('records'), body.get('column_order'))
        out = data_analysis_service.sort_dataset(
            df, by=body.get('by'), ascending=bool(body.get('ascending', True))
        )
        return jsonify(_result_payload(out))
    except data_analysis_service.DataAnalysisError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.exception("Sort failed")
        return jsonify({'error': f'Sort failed: {str(e)}'}), 500


@utility_bp.route('/data-analysis/text', methods=['POST'])
@require_auth()
def data_analysis_text():
    """
    Excel-style text function (LEFT / RIGHT / MID / TRIM / CONCAT / SUBSTITUTE /
    FIND ...) that derives a new column - typically the clean key a VLOOKUP
    then matches on. JSON:
        { records: [...], column_order: [...], op: "left", columns: [...],
          target: "New col", mode: "new"|"replace", params: {...} }
    Returns the updated dataset + a sample of before/after values.
    """
    try:
        body = request.get_json(silent=True) or {}
        df = data_analysis_service.records_to_df(
            body.get('records'), body.get('column_order'))
        out, stats = data_analysis_service.apply_text_op(
            df,
            op=body.get('op'),
            columns=body.get('columns'),
            target=body.get('target'),
            params=body.get('params') or {},
            mode=(body.get('mode') or 'new'),
        )
        return jsonify(_result_payload(out, stats=stats))
    except data_analysis_service.DataAnalysisError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.exception("Text operation failed")
        return jsonify({'error': f'Text operation failed: {str(e)}'}), 500


@utility_bp.route('/data-analysis/vlookup', methods=['POST'])
@require_auth()
def data_analysis_vlookup():
    """
    Excel-style VLOOKUP / merge. JSON:
        { records: [...], column_order: [...],
          lookup_records: [...], lookup_column_order: [...],
          left_on, right_on, bring: [...], how: "left"|"inner" }
    Returns the merged dataset + match stats. No server-side state.
    """
    try:
        body = request.get_json(silent=True) or {}
        left = data_analysis_service.records_to_df(
            body.get('records'), body.get('column_order'))
        right = data_analysis_service.records_to_df(
            body.get('lookup_records'), body.get('lookup_column_order'))
        out, stats = data_analysis_service.vlookup(
            left, right,
            left_on=body.get('left_on'),
            right_on=body.get('right_on'),
            bring=body.get('bring'),
            how=(body.get('how') or 'left').strip().lower(),
        )
        return jsonify(_result_payload(out, stats=stats))
    except data_analysis_service.DataAnalysisError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.exception("VLOOKUP failed")
        return jsonify({'error': f'VLOOKUP failed: {str(e)}'}), 500
