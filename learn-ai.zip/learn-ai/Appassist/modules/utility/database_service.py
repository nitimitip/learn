import os
import logging
import pandas as pd

# Database drivers are imported lazily inside the methods that need them.
# This keeps the module importable on machines where only one driver
# (or neither) is installed - for example a deployment that only ever
# talks to SQL Server should not require an Oracle driver to be present.
from crypto_utils import decrypt_data, CredentialDecryptionError
from .servers_models import DatabaseReport


def _report_password(report):
  """Plain-text password for a report connection.

  New rows store the password encrypted (routes.save_report). Rows saved
  before that fix hold plain text, so fall back to the stored value when
  no known key can decrypt it -- those rows keep working until re-saved.
  """
  stored = report.password or ''
  try:
    return decrypt_data(stored)
  except CredentialDecryptionError:
    return stored


def _import_pyodbc():
    try:
        import pyodbc
        return pyodbc
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise RuntimeError(
            "The 'pyodbc' package is required for SQL Server connections. "
            "Install it with: pip install pyodbc"
        ) from exc


def _import_oracle():
    # get_oracle_driver() prefers python-oracledb (auto thick/thin - thin
    # needs no Oracle Client install, avoiding DPI-1047) and falls back to
    # cx_Oracle where oracledb is not installed.
    try:
        from oracle_client import get_oracle_driver
        return get_oracle_driver()
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise RuntimeError(
            "An Oracle driver is required for Oracle connections. "
            "Install one with: pip install oracledb"
        ) from exc


class DatabaseService:
  def __init__(self):
    self.logger = logging.getLogger(__name__)
  
  def execute_query(self, report):
    """
    Execute SQL query from database report configuration
    """
    try:
      if report is None:
        self.logger.error("execute_query called with no report")
        return None
      if report.database_type == 'mssql':
        return self._execute_mssql_query(report)
      elif report.database_type == 'oracle':
        return self._execute_oracle_query(report)
      else:
        self.logger.error(f"Unsupported database type: {report.database_type}")
        return None
    except Exception as e:
      self.logger.error(f"Database query execution failed: {str(e)}")
      return None
  
  def _execute_mssql_query(self, report):
    """
    Execute query on SQL Server database
    """
    try:
      # Validate that the query is a safe, single SELECT statement.
      query = report.sql_query.strip()
      is_valid, message = self.validate_query(query)
      if not is_valid:
        raise ValueError(message)
      
      pyodbc = _import_pyodbc()

      # Build connection string
      connection_string = (
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={report.connection_host},{report.connection_port};"
        f"DATABASE={report.database_name};"
        f"UID={report.username};"
        f"PWD={_report_password(report)};"
        f"TrustServerCertificate=yes;"
      )

      # Connect and execute query.
      #
      # `with pyodbc.connect(...)` commits or rolls back the TRANSACTION and
      # leaves the connection OPEN - that is documented pyodbc behaviour, not
      # a bug in it. Without the explicit close below, every report run leaked
      # a connection in the long-lived IIS worker until garbage collection,
      # which shows up as pool exhaustion on the SQL Server side.
      conn = pyodbc.connect(connection_string, timeout=30)
      try:
        df = pd.read_sql(query, conn)
        self.logger.info(f"Successfully executed MSSQL query, returned {len(df)} rows")
        return df
      finally:
        try:
          conn.close()
        except Exception:
          self.logger.debug("Closing the MSSQL connection failed", exc_info=True)
        
    except Exception as e:
      self.logger.error(f"MSSQL query execution error: {str(e)}")
      return None
  
  def _execute_oracle_query(self, report):
    """
    Execute query on Oracle database
    """
    try:
      # Validate that the query is a safe, single SELECT statement.
      query = report.sql_query.strip()
      is_valid, message = self.validate_query(query)
      if not is_valid:
        raise ValueError(message)
      
      oracle = _import_oracle()

      # Build connection string (TNS format)
      dsn = f"{report.connection_host}:{report.connection_port}/{report.database_name}"

      # Connect and execute query
      with oracle.connect(
        user=report.username,
        password=_report_password(report),
        dsn=dsn
      ) as conn:
        df = pd.read_sql(query, conn)
        self.logger.info(f"Successfully executed Oracle query, returned {len(df)} rows")
        return df
        
    except Exception as e:
      self.logger.error(f"Oracle query execution error: {str(e)}")
      return None
  
  def test_connection(self, report):
    """
    Test database connection without executing the main query
    """
    try:
      if report.database_type == 'mssql':
        return self._test_mssql_connection(report)
      elif report.database_type == 'oracle':
        return self._test_oracle_connection(report)
      else:
        return False, f"Unsupported database type: {report.database_type}"
    except Exception as e:
      return False, str(e)
  
  def _test_mssql_connection(self, report):
    """
    Test SQL Server connection
    """
    try:
      pyodbc = _import_pyodbc()
      connection_string = (
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={report.connection_host},{report.connection_port};"
        f"DATABASE={report.database_name};"
        f"UID={report.username};"
        f"PWD={_report_password(report)};"
        f"TrustServerCertificate=yes;"
      )

      # Same leak as _execute_mssql_query: pyodbc's context manager ends the
      # transaction, not the connection.
      conn = pyodbc.connect(connection_string, timeout=10)
      try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.fetchone()
        return True, "Connection successful"
      finally:
        try:
          conn.close()
        except Exception:
          self.logger.debug("Closing the MSSQL test connection failed",
                            exc_info=True)
        
    except Exception as e:
      return False, f"Connection failed: {str(e)}"
  
  def _test_oracle_connection(self, report):
    """
    Test Oracle connection
    """
    try:
      oracle = _import_oracle()
      dsn = f"{report.connection_host}:{report.connection_port}/{report.database_name}"

      with oracle.connect(
        user=report.username,
        password=_report_password(report),
        dsn=dsn
      ) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM DUAL")
        cursor.fetchone()
        return True, "Connection successful"
        
    except Exception as e:
      return False, f"Connection failed: {str(e)}"
  
  def validate_query(self, query):
    """
    Validate SQL query for security.

    Uses word-boundary matching so legitimate identifiers such as
    'created_at' or 'updated_by' are NOT mistaken for the keywords
    CREATE / UPDATE. Also rejects stacked queries (multiple statements).
    """
    import re

    if not query or not query.strip():
      return False, "Query is empty"

    raw = query.strip()
    upper = raw.upper()

    # Only allow SELECT statements (also allow a leading CTE: WITH ... SELECT).
    if not (upper.startswith('SELECT') or upper.startswith('WITH')):
      return False, "Only SELECT statements are allowed"

    # Reject stacked / multiple statements. Allow a single optional
    # trailing semicolon, but nothing meaningful after it.
    without_trailing = raw.rstrip().rstrip(';').rstrip()
    if ';' in without_trailing:
      return False, "Multiple SQL statements are not allowed"

    # Block dangerous keywords using whole-word matching so substrings
    # inside identifiers (created_at, updated_at, ...) are not flagged.
    dangerous_keywords = [
      'INSERT', 'UPDATE', 'DELETE', 'DROP', 'CREATE', 'ALTER',
      'TRUNCATE', 'EXEC', 'EXECUTE', 'MERGE', 'GRANT', 'REVOKE',
      'COMMIT', 'ROLLBACK', 'CALL'
    ]
    for keyword in dangerous_keywords:
      if re.search(rf'\b{keyword}\b', upper):
        return False, f"Keyword '{keyword}' is not allowed"

    return True, "Query is valid"