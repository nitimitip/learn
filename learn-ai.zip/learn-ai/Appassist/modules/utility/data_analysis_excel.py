"""
Data Analysis exports -> professional NPg-themed Excel workbook.

The Data Analysis workbench used to hand back a bare ``df.to_excel`` dump. This
module renders the same rows as a finished deliverable, using the NPG (Northern
Powergrid) red palette shared with the Project Management exports:

    1. Data    - title band, styled header, frozen panes, auto-filter, banded
                 rows, real numeric / date formats and print-ready page setup.
    2. Summary - dataset provenance plus a per-column profile (type, blanks,
                 unique values, min / max / average).

VLOOKUP results additionally colour the columns that came from the lookup file
differently from the master (current-data) columns, with a legend strip, so it
is obvious at a glance which side of the join each value came from.

Performance note: styling is applied through workbook-level named styles, which
is roughly twice as fast as setting font/fill/border per cell. Very large
exports fall back to values-only rows beyond ``MAX_STYLED_ROWS`` so a download
never stalls.
"""

import io
import math
import re
import datetime as _dt

import pandas as pd

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, NamedStyle, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.page import PageMargins
from openpyxl.worksheet.properties import PageSetupProperties

# Brand palette - NPG (Northern Powergrid) red, same tokens as project_excel.py
BRAND    = "AB1236"   # NPG red - title bands
BRAND_DK = "7E0D27"   # darker NPG red - subtitles & master column headers
BORDER   = "D7DEE7"
TEXT     = "1D293D"
MUTED    = "6B7280"
BAND     = "F1F5F9"

# Per-section cell colours: (header fill, header font, row fill, banded row fill).
# "master" = columns of the current dataset, "lookup" = columns merged in from a
# VLOOKUP lookup file.
SECTIONS = {
    'master': (BRAND_DK, "FFFFFF", "FFFFFF", "EEF3FA"),
    'lookup': ("0F766E", "FFFFFF", "F3FBF9", "DFF1EC"),
}
SECTION_LABELS = {
    'master': "Columns from the master (current) data",
    'lookup': "Columns brought in from the lookup file",
}

# Number formats used by the body styles.
_FORMATS = {
    'text':  'General',
    'int':   '#,##0',
    'float': '#,##0.00',
    'date':  'dd-mmm-yyyy',
    'stamp': 'dd-mmm-yyyy hh:mm',
}

# Rows beyond this get values only (no per-cell styling) to keep the download
# responsive; the header, widths, filter and freeze panes still apply.
MAX_STYLED_ROWS = 20000

# Widest / narrowest auto-fitted column, in Excel width units.
_MIN_WIDTH = 10
_MAX_WIDTH = 45

# ISO date / timestamp text, as produced when a parsed date is round-tripped
# through the browser as JSON. Matched strictly so ordinary text is left alone.
_ISO_DATE = re.compile(r'^\d{4}-\d{2}-\d{2}$')
_ISO_STAMP = re.compile(r'^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?$')

_THIN = Side(style="thin", color=BORDER)
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT = Alignment(horizontal="left", vertical="center")
RIGHT = Alignment(horizontal="right", vertical="center")
LEFT_TOP = Alignment(horizontal="left", vertical="top", wrap_text=True)


# STYLES

def _style_name(section, banded, kind):
    return "da_%s%d_%s" % (section[0], 1 if banded else 0, kind)


def _register_body_styles(wb):
    """Register one named style per (section, band, value kind) combination."""
    for section, (_, _, fill_a, fill_b) in SECTIONS.items():
        for banded in (False, True):
            fill = fill_b if banded else fill_a
            for kind, number_format in _FORMATS.items():
                ns = NamedStyle(name=_style_name(section, banded, kind))
                ns.font = Font(name="Calibri", size=10, color=TEXT)
                ns.fill = PatternFill("solid", fgColor=fill)
                ns.border = _BORDER
                ns.number_format = number_format
                if kind in ('int', 'float'):
                    ns.alignment = RIGHT
                elif kind in ('date', 'stamp'):
                    ns.alignment = CENTER
                else:
                    ns.alignment = LEFT
                wb.add_named_style(ns)


def _title_band(ws, title, subtitle, ncols):
    """Brand title (+ optional subtitle) band. Returns the next free row."""
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=max(ncols, 1))
    c = ws.cell(row=1, column=1, value=title)
    c.font = Font(name="Calibri", size=15, bold=True, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=BRAND)
    c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[1].height = 30

    if subtitle:
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=max(ncols, 1))
        s = ws.cell(row=2, column=1, value=subtitle)
        s.font = Font(name="Calibri", size=10, italic=True, color="FFFFFF")
        s.fill = PatternFill("solid", fgColor=BRAND_DK)
        s.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        ws.row_dimensions[2].height = 20
        return 4
    return 3


def _print_setup(ws, orientation="landscape", repeat_rows=None):
    """Print-ready page setup so the sheet prints as a deliverable."""
    ws.page_setup.orientation = orientation
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    ws.page_margins = PageMargins(left=0.4, right=0.4, top=0.5, bottom=0.55,
                                  header=0.2, footer=0.25)
    if repeat_rows:
        ws.print_title_rows = repeat_rows
    ws.oddFooter.left.text = "NPg AppAssist - Data Analysis"
    ws.oddFooter.left.size = 8
    ws.oddFooter.left.color = MUTED
    ws.oddFooter.right.text = "Page &P of &N"
    ws.oddFooter.right.size = 8
    ws.oddFooter.right.color = MUTED


# VALUE PREPARATION

def _looks_like(series, pattern, sample=400):
    """True when every non-blank value in a sample matches `pattern`."""
    seen = 0
    for v in series:
        if not isinstance(v, str):
            if v is None:
                continue
            try:
                if pd.isna(v):
                    continue
            except (TypeError, ValueError):
                pass
            return False                  # a real non-text value: leave alone
        text = v.strip()
        if not text:
            continue
        if not pattern.match(text):
            return False
        seen += 1
        if seen >= sample:
            break
    return seen > 0


def _coerce_iso_dates(df):
    """Turn ISO date/timestamp *text* back into real datetimes.

    Dates make a round trip through the browser as ISO strings, so without this
    an exported date column would land in Excel as left-aligned text that will
    not sort or filter as a date. Returns (df, {column: 'date'|'stamp'}).
    """
    kinds = {}
    out = None
    for col in df.columns:
        s = df[col]
        # Text columns only. Checked by kind rather than "dtype == object" so it
        # holds for both the legacy object dtype and pandas' newer str dtype.
        if (pd.api.types.is_numeric_dtype(s)
                or pd.api.types.is_datetime64_any_dtype(s)
                or pd.api.types.is_bool_dtype(s)):
            continue
        if _looks_like(s, _ISO_STAMP):
            kind = 'stamp'
        elif _looks_like(s, _ISO_DATE):
            kind = 'date'
        else:
            continue
        converted = pd.to_datetime(s, errors='coerce')
        if converted.notna().sum() == 0:
            continue
        if out is None:
            out = df.copy()
        out[col] = converted
        kinds[col] = kind
    return (out if out is not None else df), kinds


def _cell_kind(value, date_kind):
    """Body style kind for one value."""
    if isinstance(value, (_dt.datetime, _dt.date, pd.Timestamp)):
        return date_kind or 'date'
    if isinstance(value, bool):
        return 'text'
    if isinstance(value, int):
        return 'int'
    if isinstance(value, float):
        return 'float' if not float(value).is_integer() else 'int'
    return 'text'


def _excel_value(value):
    """Convert one pandas/numpy scalar into something openpyxl can write."""
    if value is None:
        return None
    if isinstance(value, float) and not math.isfinite(value):
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, pd.Timestamp):
        value = value.to_pydatetime()
    if isinstance(value, _dt.datetime) and value.tzinfo is not None:
        value = value.replace(tzinfo=None)   # Excel has no tz-aware datetimes
    if hasattr(value, 'item'):               # numpy scalar -> Python native
        try:
            value = value.item()
        except (ValueError, AttributeError):
            value = str(value)
    if isinstance(value, (list, tuple, dict, set)):
        return str(value)
    return value


def _display_len(value):
    if value is None:
        return 0
    if isinstance(value, (_dt.datetime, pd.Timestamp)):
        return 18
    if isinstance(value, _dt.date):
        return 12
    if isinstance(value, float):
        return len("{:,.2f}".format(value))
    return len(str(value))


def _column_widths(df, sample=200):
    """Auto-fit widths from the header plus a sample of the values."""
    widths = []
    head = df.head(sample)
    for col in df.columns:
        longest = len(str(col))
        for v in head[col]:
            longest = max(longest, _display_len(_excel_value(v)))
        widths.append(min(_MAX_WIDTH, max(_MIN_WIDTH, longest + 3)))
    return widths


# DATA SHEET

def _legend(ws, row, ncols):
    """Master / lookup colour key, shown only on VLOOKUP exports."""
    lc = ws.cell(row=row, column=1, value="Colour key:")
    lc.font = Font(name="Calibri", size=9, italic=True, color=MUTED)
    lc.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    col = 2
    for section in ('master', 'lookup'):
        header_fill, _, row_fill, _ = SECTIONS[section]
        span = min(4, max(2, ncols - col))
        end = min(ncols, col + span - 1)
        if end < col:
            break
        ws.merge_cells(start_row=row, start_column=col, end_row=row, end_column=end)
        c = ws.cell(row=row, column=col, value=SECTION_LABELS[section])
        c.fill = PatternFill("solid", fgColor=row_fill)
        c.font = Font(name="Calibri", size=9, bold=True, color=header_fill)
        c.alignment = Alignment(horizontal="center", vertical="center")
        c.border = _BORDER
        col = end + 2
        if col > ncols:
            break
    ws.row_dimensions[row].height = 18


def _build_data_sheet(ws, df, title, subtitle, sections, date_kinds, styled):
    ncols = max(len(df.columns), 1)
    row = _title_band(ws, title, subtitle, ncols)

    if any(s == 'lookup' for s in sections):
        _legend(ws, row, ncols)
        row += 1

    header_row = row
    for idx, col in enumerate(df.columns, start=1):
        header_fill, header_font, _, _ = SECTIONS[sections[idx - 1]]
        cell = ws.cell(row=header_row, column=idx, value=str(col))
        cell.font = Font(name="Calibri", size=10, bold=True, color=header_font)
        cell.fill = PatternFill("solid", fgColor=header_fill)
        cell.alignment = CENTER
        cell.border = _BORDER
    ws.row_dimensions[header_row].height = 26

    for idx, width in enumerate(_column_widths(df), start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width

    row = header_row + 1
    if df.empty:
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
        c = ws.cell(row=row, column=1, value="No rows to export.")
        c.font = Font(name="Calibri", size=10, italic=True, color=MUTED)
        c.alignment = CENTER
        last_row = row
    else:
        kinds = [date_kinds.get(c) for c in df.columns]
        for i, record in enumerate(df.itertuples(index=False, name=None)):
            banded = (i % 2 == 1)
            style_row = styled and i < MAX_STYLED_ROWS
            for idx, raw in enumerate(record, start=1):
                value = _excel_value(raw)
                cell = ws.cell(row=row, column=idx, value=value)
                if style_row:
                    cell.style = _style_name(
                        sections[idx - 1], banded,
                        _cell_kind(value, kinds[idx - 1]),
                    )
            row += 1
        last_row = row - 1

    ws.freeze_panes = ws.cell(row=header_row + 1, column=1)
    ws.auto_filter.ref = "A%d:%s%d" % (
        header_row, get_column_letter(ncols), max(last_row, header_row))
    _print_setup(ws, repeat_rows="1:%d" % header_row)


# SUMMARY SHEET

def _profile_rows(df, sections):
    """One profile row per column: type, blanks, unique values, min/max/avg."""
    rows = []
    total = len(df)
    for i, col in enumerate(df.columns):
        s = df[col]
        filled = int(s.notna().sum())
        if pd.api.types.is_numeric_dtype(s):
            kind = 'Number'
        elif pd.api.types.is_datetime64_any_dtype(s):
            kind = 'Date'
        elif pd.api.types.is_bool_dtype(s):
            kind = 'True/False'
        else:
            kind = 'Text'
            filled = int((s.notna() & (s.astype(str).str.strip() != '')).sum())
        low = high = avg = '-'
        if kind in ('Number', 'Date') and filled:
            try:
                low = _excel_value(s.min())
                high = _excel_value(s.max())
                if kind == 'Number':
                    avg = round(float(s.mean()), 4)
            except (TypeError, ValueError):
                low = high = avg = '-'
        try:
            unique = int(s.nunique(dropna=True))
        except TypeError:                      # unhashable values in the column
            unique = '-'
        rows.append([
            i + 1, str(col),
            'Lookup file' if sections[i] == 'lookup' else 'Master data',
            kind, filled, total - filled, unique, low, high, avg,
        ])
    return rows


def _build_summary_sheet(ws, df, meta, sections):
    headers = ["#", "Column", "Source", "Type", "Non-empty", "Blank",
               "Unique", "Minimum", "Maximum", "Average"]
    for idx, width in enumerate([5, 34, 14, 12, 11, 9, 10, 18, 18, 14], start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width

    row = _title_band(ws, "Data Export - Summary",
                      "Dataset provenance and a per-column profile", len(headers))

    def field(label, value):
        lc = ws.cell(row=row, column=1, value=label)
        lc.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        lc.fill = PatternFill("solid", fgColor=BRAND_DK)
        lc.alignment = LEFT
        lc.border = _BORDER
        ws.merge_cells(start_row=row, start_column=2, end_row=row, end_column=4)
        vc = ws.cell(row=row, column=2, value=value if value not in (None, '') else '-')
        vc.font = Font(name="Calibri", size=10, color=TEXT)
        vc.alignment = LEFT
        for c in range(2, 5):
            ws.cell(row=row, column=c).border = _BORDER
        ws.row_dimensions[row].height = 20

    for label, value in (
        ("Source file", meta.get('filename')),
        ("Sheet", meta.get('sheet')),
        ("Applied step", meta.get('step')),
        ("Rows exported", len(df)),
        ("Columns exported", len(df.columns)),
        ("Prepared by", meta.get('prepared_by')),
        ("Generated", (meta.get('generated') or _dt.datetime.now())
                      .strftime("%d %b %Y %H:%M")),
    ):
        if value in (None, ''):
            continue
        field(label, value)
        row += 1
    row += 1

    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=len(headers))
    h = ws.cell(row=row, column=1, value="Column profile")
    h.font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    h.fill = PatternFill("solid", fgColor=BRAND)
    h.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.row_dimensions[row].height = 22
    row += 1

    for idx, label in enumerate(headers, start=1):
        cell = ws.cell(row=row, column=idx, value=label)
        cell.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=BRAND_DK)
        cell.alignment = CENTER
        cell.border = _BORDER
    ws.row_dimensions[row].height = 26
    row += 1

    for i, values in enumerate(_profile_rows(df, sections)):
        banded = (i % 2 == 1)
        for idx, value in enumerate(values, start=1):
            cell = ws.cell(row=row, column=idx, value=value)
            cell.font = Font(name="Calibri", size=10, color=TEXT)
            cell.alignment = LEFT_TOP if idx == 2 else CENTER
            cell.border = _BORDER
            if banded:
                cell.fill = PatternFill("solid", fgColor=BAND)
        if sections[i] == 'lookup':
            sc = ws.cell(row=row, column=3)
            sc.fill = PatternFill("solid", fgColor=SECTIONS['lookup'][2])
            sc.font = Font(name="Calibri", size=10, bold=True,
                           color=SECTIONS['lookup'][0])
        row += 1

    # Deliberately no frozen panes here: the provenance block sits above the
    # column profile, so freezing pinned most of the page and left a sliver to
    # scroll in. The whole Summary sheet scrolls freely. (The Data sheet still
    # freezes its header row, where it earns its keep.)
    _print_setup(ws, orientation="portrait")


# ENTRY POINT

def build_data_workbook(df, title=None, subtitle=None, lookup_columns=None,
                        meta=None, sheet_name='Data'):
    """Return the .xlsx bytes for an exported dataset.

    `lookup_columns` names the columns that came from a VLOOKUP lookup file;
    those are coloured differently from the master columns and get a legend.
    `meta` carries optional provenance for the Summary sheet: filename, sheet,
    step, prepared_by, generated.
    """
    meta = dict(meta or {})
    lookup = {str(c) for c in (lookup_columns or [])}
    frame, date_kinds = _coerce_iso_dates(df)
    sections = ['lookup' if str(c) in lookup else 'master' for c in frame.columns]

    wb = Workbook()
    _register_body_styles(wb)

    data_ws = wb.active
    data_ws.title = (sheet_name or 'Data')[:31]
    data_ws.sheet_view.showGridLines = False

    rows = len(frame)
    bits = ["%s rows x %s columns" % ("{:,}".format(rows), len(frame.columns))]
    if meta.get('filename'):
        bits.append("source: %s" % meta['filename'])
    if meta.get('step'):
        bits.append(meta['step'])
    bits.append((meta.get('generated') or _dt.datetime.now())
                .strftime("generated %d %b %Y %H:%M"))
    if rows > MAX_STYLED_ROWS:
        bits.append("row shading limited to the first %s rows"
                    % "{:,}".format(MAX_STYLED_ROWS))

    _build_data_sheet(
        data_ws, frame,
        title or "Data Export",
        subtitle or " - ".join(bits),
        sections, date_kinds, styled=True,
    )

    summary_ws = wb.create_sheet("Summary")
    summary_ws.sheet_view.showGridLines = False
    _build_summary_sheet(summary_ws, frame, meta, sections)

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()
