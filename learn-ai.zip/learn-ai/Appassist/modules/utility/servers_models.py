from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, JSON
from sqlalchemy.sql import func
from database import Base

class ServerData(Base):
    __tablename__ = 'server_data'
   
    id = Column(Integer, primary_key=True)
    raw_data = Column(JSON, nullable=False)  # Store the raw Excel data as JSON
    ip_address = Column(String(45), nullable=True, index=True)  # IPv4/IPv6
    server_name = Column(String(100), nullable=True, index=True)
    system_type = Column(String(50), nullable=True)
    OS = Column(String(50), nullable=True)
    os_version = Column(String(50), nullable=True)
    application_name = Column(String(255), nullable=True, index=True)
    location = Column(String(255), nullable=True)
    environment = Column(String(100), nullable=True)
    domain = Column(String(50), nullable=True)
    status = Column(String(50), nullable=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
   
    def __repr__(self):
        return f'<ServerData {self.server_name}>'

class FieldMapping(Base):
    __tablename__ = 'field_mappings'
   
    id = Column(Integer, primary_key=True)
    display_name = Column(String(255), nullable=False)
    mapped_field = Column(String(255), nullable=False)
    is_searchable = Column(Boolean, default=False)
    is_displayed = Column(Boolean, default=True)
    display_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
   
    def __repr__(self):
        return f'<FieldMapping {self.display_name} -> {self.mapped_field}>'

class ServerImport(Base):
    __tablename__ = 'server_imports'
   
    id = Column(Integer, primary_key=True)
    filename = Column(String(255), nullable=False)
    records_imported = Column(Integer, default=0)
    import_status = Column(String(50), default='pending')  # pending, success, failed
    error_message = Column(Text, nullable=True)
    imported_by = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=func.now())
   
    def __repr__(self):
        return f'<ServerImport {self.filename}>'
    
class DatabaseReport(Base):
  __tablename__ = 'database_report'
   
  id = Column(Integer, primary_key=True)
  report_name = Column(String(100), nullable=False)
  database_type = Column(String(20), nullable=False) # 'mssql' or 'oracle'
  connection_host = Column(String(100), nullable=False)
  connection_port = Column(String(10), nullable=False)
  database_name = Column(String(100), nullable=False)
  username = Column(String(100), nullable=False)
  password = Column(String(256), nullable=False)  # encrypted at rest (crypto_utils); legacy rows may be plaintext until re-saved
  sql_query = Column(Text, nullable=False)
  created_at = Column(DateTime, default=func.now())
  updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

  def to_dict(self):
    return {
      'id': self.id,
      'report_name': self.report_name,
      'database_type': self.database_type,
      'connection_host': self.connection_host,
      'connection_port': self.connection_port,
      'database_name': self.database_name,
      'username': self.username,
      'sql_query': self.sql_query,
      'created_at': self.created_at.isoformat()
    }
