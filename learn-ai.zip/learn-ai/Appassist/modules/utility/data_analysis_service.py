"""
Stateless data-analysis helpers for the Utility blueprint.

Design constraint: NOTHING is stored in a database or persisted on the server.
Every function here is pure / request-scoped:

  * Uploads are parsed in-memory (or from a per-request temp file that the
    caller deletes immediately) into a DataFrame.
  * The browser keeps the parsed dataset and sends it back as JSON for any
    follow-up pivot operation, so the server holds no state between requests.
  * Charts are rendered client-side from that same JSON.

The HTML produced by ``df.to_html`` is given Bootstrap table classes so it
drops straight into the existing Utility design system.
"""
import io
import math
import re
import datetime as _dt

import numpy as np
import pandas as pd

from . import data_analysis_excel

# Aggregation functions exposed in the pivot-table UI. Keep the keys in sync
# with the <select> options in templates/utility/data_analysis.html.
PIVOT_AGGFUNCS = {
    'sum': 'Sum',
    'mean': 'Mean (average)',
    'count': 'Count',
    'min': 'Minimum',
    'max': 'Maximum',
    'median': 'Median',
}

# Chart types offered in the UI (rendered client-side with Plotly).
CHART_TYPES = {
    'bar': 'Bar',
    'line': 'Line',
    'area': 'Area',
    'scatter': 'Scatter',
    'pie': 'Pie',
    'histogram': 'Histogram',
    'box': 'Box',
    'heatmap': 'Heatmap',
}

# Short "best used for" guidance shown under the chart-type picker so users
# pick the right visualisation. Keys must match CHART_TYPES.
CHART_HINTS = {
    'bar':       'Compare a numeric value across categories (e.g. sales by region).',
    'line':      'Show how a value changes over an ordered axis like time or sequence.',
    'area':      'Like a line chart, but emphasises cumulative magnitude or volume over time.',
    'scatter':   'Reveal the relationship or correlation between two numeric columns.',
    'pie':       'Show parts of a whole as proportions - best with only a few categories.',
    'histogram': 'See the distribution and spread of a single numeric column.',
    'box':       'Compare spread, median and outliers of a numeric value across groups.',
    'heatmap':   'Show magnitude across two categorical dimensions using colour intensity.',
}

# Filter operators offered in the Filter & Export UI. Keep the keys in sync
# with the operator <select> in templates/utility/data_analysis.html. The
# numeric/text grouping drives how each operator coerces its operand.
FILTER_OPS = {
    'eq':           'equals',
    'ne':           'does not equal',
    'gt':           'greater than',
    'ge':           'greater than or equal',
    'lt':           'less than',
    'le':           'less than or equal',
    'contains':     'contains text',
    'not_contains': 'does not contain',
    'startswith':   'starts with',
    'endswith':     'ends with',
    'isnull':       'is empty',
    'notnull':      'is not empty',
}

# Operators that need no operand value (the value box is hidden for these).
FILTER_OPS_NO_VALUE = {'isnull', 'notnull'}

# Export formats offered after filtering.
EXPORT_FORMATS = {'csv', 'xlsx'}

# Cap how much raw data we hand to the browser. A utility tool does not need
# to ship millions of rows to the client for charting / pivoting; this keeps
# the JSON payload (and the browser) responsive.
MAX_CLIENT_ROWS = 50_000

# Bootstrap classes applied to every generated table.
_TABLE_CLASSES = 'table table-sm table-striped table-bordered da-table'


class DataAnalysisError(Exception):
    """Raised for user-facing problems (bad file, empty sheet, bad column)."""


# JSON-SAFETY

def _json_safe_value(v):
    """Convert one pandas/numpy scalar into a plain JSON-serialisable value."""
    try:
        if v is None or (pd.api.types.is_scalar(v) and pd.isna(v)):
            return None
    except (TypeError, ValueError):
        pass

    if isinstance(v, (pd.Timestamp, _dt.datetime, _dt.date)):
        return v.isoformat()

    if hasattr(v, 'item'):          # numpy scalar -> Python native
        v = v.item()

    if isinstance(v, float) and not math.isfinite(v):  # NaN / Inf -> None
        v = None

    return v


def df_to_records(df):
    """Return JSON-safe list-of-dicts for the (row-capped) DataFrame."""
    capped = df.head(MAX_CLIENT_ROWS)
    return [
        {str(k): _json_safe_value(v) for k, v in row.items()}
        for row in capped.to_dict('records')
    ]


# READING

def is_excel(filename):
    return (filename or '').lower().endswith(('.xlsx', '.xls'))


def list_excel_sheets(path):
    """Return the list of sheet names in an Excel workbook."""
    try:
        xls = pd.ExcelFile(path)
        return list(xls.sheet_names)
    except Exception as exc:
        raise DataAnalysisError(f"Could not read the Excel workbook: {exc}")


def read_tabular(path, filename, sheet_name=None):
    """
    Parse a CSV or Excel file into a DataFrame.

    Returns (df, sheets) where ``sheets`` is the list of sheet names for an
    Excel file (empty list for CSV). Raises DataAnalysisError on any parse
    failure or if the resulting frame is empty.
    """
    try:
        if is_excel(filename):
            sheets = list_excel_sheets(path)
            if not sheets:
                raise DataAnalysisError("The Excel workbook has no sheets.")
            target = sheet_name if (sheet_name and sheet_name in sheets) else sheets[0]
            df = pd.read_excel(path, sheet_name=target)
        else:
            sheets = []
            df = pd.read_csv(path)
    except DataAnalysisError:
        raise
    except UnicodeDecodeError:
        raise DataAnalysisError(
            "The file could not be decoded as text. If it is an Excel file, "
            "make sure it has a .xlsx or .xls extension."
        )
    except Exception as exc:
        raise DataAnalysisError(f"The file could not be parsed: {exc}")

    if df is None or df.empty:
        raise DataAnalysisError("The file parsed successfully but contains no rows.")

    # Stringify column names so downstream JSON / Jinja never trips on numbers.
    df.columns = [str(c) for c in df.columns]
    return df, sheets


# COLUMN METADATA

def column_meta(df):
    """
    Describe every column so the UI can populate dropdowns intelligently
    (numeric columns for chart Y-axes / pivot values, etc.).
    """
    meta = []
    for col in df.columns:
        s = df[col]
        if pd.api.types.is_numeric_dtype(s):
            kind = 'numeric'
        elif pd.api.types.is_datetime64_any_dtype(s):
            kind = 'datetime'
        else:
            kind = 'categorical'
        meta.append({
            'name': col,
            'dtype': str(s.dtype),
            'kind': kind,
        })
    return meta


# BASIC ANALYSIS

def _info_html(df):
    """Capture df.info() (which prints to a stream) and wrap it in <pre>."""
    buf = io.StringIO()
    df.info(buf=buf)
    text = buf.getvalue()
    # Escape the few HTML-significant chars; info() output is plain text.
    text = (text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;'))
    return f'<pre class="da-info">{text}</pre>'


def basic_analysis(df):
    """
    Build the auto-generated overview rendered on upload. Every value is an
    HTML fragment ready to drop into the page.
    """
    n_rows, n_cols = df.shape

    # head()
    head_html = df.head(10).to_html(classes=_TABLE_CLASSES, border=0, na_rep='')

    # describe() - include all columns so categorical summaries show too.
    try:
        desc = df.describe(include='all').round(4)
    except Exception:
        desc = df.describe().round(4)
    describe_html = desc.to_html(classes=_TABLE_CLASSES, border=0, na_rep='')

    # dtypes
    dtypes_df = (
        df.dtypes.astype(str)
        .rename('dtype')
        .rename_axis('column')
        .reset_index()
    )
    dtypes_html = dtypes_df.to_html(classes=_TABLE_CLASSES, border=0, index=False)

    # null counts (+ percentage)
    nulls = df.isnull().sum()
    null_df = pd.DataFrame({
        'column': nulls.index.astype(str),
        'null_count': nulls.values,
        'null_pct': (nulls.values / n_rows * 100).round(2),
    })
    nulls_html = null_df.to_html(classes=_TABLE_CLASSES, border=0, index=False)

    # correlations (numeric only)
    numeric = df.select_dtypes(include=[np.number])
    if numeric.shape[1] >= 2:
        corr_html = numeric.corr().round(4).to_html(
            classes=_TABLE_CLASSES, border=0, na_rep=''
        )
    else:
        corr_html = (
            '<div class="da-empty">Need at least two numeric columns to '
            'compute correlations.</div>'
        )

    return {
        'shape': {'rows': int(n_rows), 'cols': int(n_cols)},
        'head': head_html,
        'describe': describe_html,
        'dtypes': dtypes_html,
        'nulls': nulls_html,
        'info': _info_html(df),
        'correlations': corr_html,
    }


# PIVOT TABLES

def apply_column_order(df, column_order):
    """Restore the caller's column order on a rebuilt DataFrame.

    A JSON *object* does not keep its key order in the browser: JavaScript
    hoists keys that look like array indices ("2024", "10", "1") to the front in
    numeric order, so a sheet whose headers are years or codes comes back
    shuffled on every round trip. The page therefore also sends the column order
    as a JSON *array* - which does keep its order - and we re-apply it here.

    Unknown names are ignored and any column the caller did not mention keeps
    its current relative position at the end.
    """
    order = [str(c) for c in (column_order or []) if c is not None]
    if not order:
        return df
    existing = set(df.columns)
    seen = set()
    ordered = []
    for name in order:
        if name in existing and name not in seen:
            seen.add(name)
            ordered.append(name)
    if not ordered:
        return df
    ordered += [c for c in df.columns if c not in seen]
    return df[ordered]


def records_to_df(records, column_order=None):
    """Rebuild a DataFrame from JSON records sent back by the browser.

    `column_order` is the browser's column list; see apply_column_order for why
    it is needed to keep the uploaded sheet's column sequence intact.
    """
    if not records:
        raise DataAnalysisError("No data was provided to pivot.")
    df = pd.DataFrame.from_records(records)
    if df.empty:
        raise DataAnalysisError("The provided data is empty.")
    df.columns = [str(c) for c in df.columns]
    return apply_column_order(df, column_order)


def build_pivot(df, index, columns, values, aggfunc):
    """
    Build a pivot table with pd.pivot_table and return it as an HTML table.

    ``index`` and ``columns`` are lists of column names (columns may be empty);
    ``values`` is a single column; ``aggfunc`` is a key of PIVOT_AGGFUNCS.
    """
    index = [c for c in (index or []) if c]
    columns = [c for c in (columns or []) if c]

    if not index:
        raise DataAnalysisError("Pick at least one column for the pivot rows.")
    if not values:
        raise DataAnalysisError("Pick a column to aggregate (values).")
    if aggfunc not in PIVOT_AGGFUNCS:
        raise DataAnalysisError("Unknown aggregation function.")

    missing = [c for c in index + columns + [values] if c not in df.columns]
    if missing:
        raise DataAnalysisError(f"Column(s) not found: {', '.join(missing)}")

    # 'count' works on any dtype; every other aggregation needs numbers.
    if aggfunc != 'count':
        df = df.copy()
        df[values] = pd.to_numeric(df[values], errors='coerce')
        if df[values].notna().sum() == 0:
            raise DataAnalysisError(
                f"Column '{values}' has no numeric data to "
                f"{PIVOT_AGGFUNCS[aggfunc].lower()}."
            )

    try:
        pivot = pd.pivot_table(
            df,
            index=index,
            columns=columns or None,
            values=values,
            aggfunc=aggfunc,
            margins=True,
            margins_name='Total',
        )
    except Exception as exc:
        raise DataAnalysisError(f"Could not build the pivot table: {exc}")

    if isinstance(pivot, pd.DataFrame):
        pivot = pivot.round(4)
    html = pivot.to_html(classes=_TABLE_CLASSES, border=0, na_rep='')
    return html


# FILTER  (structured row filtering - no raw query strings, so no code injection)

def preview_html(df, rows=100):
    """Render the first `rows` of a DataFrame as a Bootstrap-styled HTML table."""
    return df.head(rows).to_html(classes=_TABLE_CLASSES, border=0, na_rep='')


def _filter_mask(df, f):
    """Boolean mask for a single {column, op, value} filter clause."""
    col = f.get('column')
    op = f.get('op')
    value = f.get('value', '')

    if not col or col not in df.columns:
        raise DataAnalysisError(f"Filter column not found: {col!r}")
    if op not in FILTER_OPS:
        raise DataAnalysisError(f"Unknown filter operator: {op!r}")

    s = df[col]

    if op == 'isnull':
        return s.isna()
    if op == 'notnull':
        return s.notna()

    # Numeric comparisons - coerce both sides to numbers; non-numeric cells drop out.
    if op in ('gt', 'ge', 'lt', 'le'):
        col_num = pd.to_numeric(s, errors='coerce')
        try:
            operand = float(value)
        except (TypeError, ValueError):
            raise DataAnalysisError(
                f"'{FILTER_OPS[op]}' needs a number for column '{col}'."
            )
        mask = {
            'gt': col_num > operand,
            'ge': col_num >= operand,
            'lt': col_num < operand,
            'le': col_num <= operand,
        }[op]
        return mask.fillna(False)

    # Equality - numeric-aware for numeric columns, else case-insensitive text.
    if op in ('eq', 'ne'):
        if pd.api.types.is_numeric_dtype(s):
            operand = pd.to_numeric(pd.Series([value]), errors='coerce').iloc[0]
            base = (s == operand)
        else:
            base = s.astype(str).str.strip().str.casefold() == str(value).strip().casefold()
        base = base.fillna(False)
        return ~base if op == 'ne' else base

    # Text predicates - literal (regex disabled), case-insensitive, null-safe.
    text = s.astype(str)
    not_null = s.notna()
    needle = str(value)
    if op == 'contains':
        mask = text.str.contains(needle, case=False, na=False, regex=False)
    elif op == 'not_contains':
        return ~text.str.contains(needle, case=False, na=False, regex=False) & not_null
    elif op == 'startswith':
        mask = text.str.casefold().str.startswith(needle.casefold())
    elif op == 'endswith':
        mask = text.str.casefold().str.endswith(needle.casefold())
    else:  # pragma: no cover - guarded above
        raise DataAnalysisError(f"Unknown filter operator: {op!r}")
    return mask.fillna(False) & not_null


def apply_filters(df, filters, match='all'):
    """Return the subset of `df` matching the filter clauses.

    `filters` is a list of {column, op, value} dicts; `match` is 'all' (AND, the
    default) or 'any' (OR). Empty/blank clauses are ignored - with no usable
    clause the frame is returned unchanged.
    """
    clauses = [f for f in (filters or []) if f and f.get('column') and f.get('op')]
    if not clauses:
        return df

    combine_any = str(match).lower() == 'any'
    combined = None
    for clause in clauses:
        mask = _filter_mask(df, clause)
        if combined is None:
            combined = mask
        else:
            combined = (combined | mask) if combine_any else (combined & mask)
    return df[combined]


# REMOVE DUPLICATES

# Which duplicate to keep. Keep the keys in sync with the <select> in
# templates/utility/data_analysis.html.
DEDUPE_KEEP = {
    'first': 'Keep first occurrence',
    'last':  'Keep last occurrence',
    'none':  'Drop every duplicated row',
}


def remove_duplicates(df, subset=None, keep='first'):
    """Drop duplicate rows. `subset` limits the comparison to those columns
    (empty/None => compare whole rows); `keep` is a key of DEDUPE_KEEP.

    Returns (deduped_df, stats) where stats has before/after/removed counts.
    """
    subset = [c for c in (subset or []) if c] or None
    if subset:
        missing = [c for c in subset if c not in df.columns]
        if missing:
            raise DataAnalysisError(f"Column(s) not found: {', '.join(missing)}")
    if keep not in DEDUPE_KEEP:
        raise DataAnalysisError("Unknown 'keep' option for remove duplicates.")

    keep_arg = False if keep == 'none' else keep   # pandas: False drops all dupes
    before = len(df)
    out = df.drop_duplicates(subset=subset, keep=keep_arg).reset_index(drop=True)
    after = len(out)
    return out, {'before': int(before), 'after': int(after), 'removed': int(before - after)}


# SORT

def sort_dataset(df, by, ascending=True):
    """Sort by one or more columns (stable sort, missing values last)."""
    by = [c for c in (by or []) if c]
    if not by:
        raise DataAnalysisError("Pick at least one column to sort by.")
    missing = [c for c in by if c not in df.columns]
    if missing:
        raise DataAnalysisError(f"Column(s) not found: {', '.join(missing)}")
    out = df.sort_values(
        by=by, ascending=bool(ascending), kind='mergesort', na_position='last'
    ).reset_index(drop=True)
    return out


# TEXT OPERATIONS  (Excel-style LEFT / RIGHT / MID / TRIM / CONCAT / SUBSTITUTE / FIND)
#
# Each operation reads one (or several) source columns and writes the result
# into a NEW column, so the typical workflow is: derive a clean key here ->
# "Apply to dataset" -> run VLOOKUP on that derived key.
#
# Everything is literal: no regular expressions or formula strings are accepted
# from the browser, so there is nothing to inject.

# Keep the keys in sync with the <select> in templates/utility/data_analysis.html.
TEXT_OPS = {
    'left':       'LEFT - first N characters',
    'right':      'RIGHT - last N characters',
    'mid':        'MID - N characters from a position',
    'trim':       'TRIM - strip and collapse spaces',
    'upper':      'UPPER - UPPERCASE',
    'lower':      'LOWER - lowercase',
    'proper':     'PROPER - Title Case',
    'len':        'LEN - number of characters',
    'substitute': 'SUBSTITUTE - replace text with other text',
    'find':       'FIND / SEARCH - position of text (0 = not found)',
    'before':     'TEXT BEFORE - part before a delimiter',
    'after':      'TEXT AFTER - part after a delimiter',
    'concat':     'CONCATENATE / TEXTJOIN - join several columns',
    'pad':        'PAD - pad to a fixed width (e.g. 42 -> 00042)',
}

# Operations that read more than one source column.
TEXT_OPS_MULTI = {'concat'}

# Short "what this does" guidance shown under the operation picker.
TEXT_OP_HINTS = {
    'left':       'Reads the first N characters, e.g. "IN-4471" -> "IN-".',
    'right':      'Reads the last N characters, e.g. "IN-4471" -> "471".',
    'mid':        'Reads N characters starting at a position (1 = first character).',
    'trim':       'Removes leading/trailing spaces and collapses repeated spaces - fixes keys that will not match.',
    'upper':      'Converts the text to UPPERCASE.',
    'lower':      'Converts the text to lowercase.',
    'proper':     'Capitalises The First Letter Of Each Word.',
    'len':        'Counts the characters - useful to spot ragged codes before a lookup.',
    'substitute': 'Replaces every occurrence of one piece of text with another (literal, not a pattern).',
    'find':       'Returns the 1-based position of the text, or 0 when it is not present.',
    'before':     'Keeps everything before the first delimiter; keeps the whole value when the delimiter is absent.',
    'after':      'Keeps everything after the first delimiter; blank when the delimiter is absent.',
    'concat':     'Joins the selected columns in the order you pick them, with an optional separator.',
    'pad':        'Left-pads short values so every key is the same width (never truncates).',
}

# Per-operation input fields. The browser renders these dynamically, so adding
# an operation here is all it takes to expose it in the UI.
#   type: 'number' | 'text' | 'check'
TEXT_OP_FIELDS = {
    'left':  [{'key': 'count', 'label': 'Number of characters', 'type': 'number', 'default': 3, 'min': 1}],
    'right': [{'key': 'count', 'label': 'Number of characters', 'type': 'number', 'default': 3, 'min': 1}],
    'mid': [
        {'key': 'start', 'label': 'Start position (1 = first)', 'type': 'number', 'default': 1, 'min': 1},
        {'key': 'count', 'label': 'Number of characters', 'type': 'number', 'default': 3, 'min': 1},
    ],
    'substitute': [
        {'key': 'find', 'label': 'Text to find', 'type': 'text', 'placeholder': 'e.g. -'},
        {'key': 'replace', 'label': 'Replace with', 'type': 'text', 'placeholder': 'leave blank to delete it'},
        {'key': 'match_case', 'label': 'Match case', 'type': 'check', 'default': False},
    ],
    'find': [
        {'key': 'find', 'label': 'Text to find', 'type': 'text', 'placeholder': 'e.g. -'},
        {'key': 'match_case', 'label': 'Match case (FIND, not SEARCH)', 'type': 'check', 'default': False},
    ],
    'before': [{'key': 'delimiter', 'label': 'Delimiter', 'type': 'text', 'placeholder': 'e.g. -'}],
    'after':  [{'key': 'delimiter', 'label': 'Delimiter', 'type': 'text', 'placeholder': 'e.g. -'}],
    'concat': [
        {'key': 'separator', 'label': 'Separator', 'type': 'text', 'placeholder': 'e.g. - (blank = no separator)'},
        {'key': 'skip_empty', 'label': 'Skip empty values (TEXTJOIN)', 'type': 'check', 'default': True},
    ],
    'pad': [
        {'key': 'width', 'label': 'Total width', 'type': 'number', 'default': 5, 'min': 1},
        {'key': 'fill', 'label': 'Pad with', 'type': 'text', 'default': '0'},
    ],
}

# Suffix used when the user does not name the output column.
_TEXT_OP_SUFFIX = {
    'left': 'LEFT', 'right': 'RIGHT', 'mid': 'MID', 'trim': 'TRIM',
    'upper': 'UPPER', 'lower': 'LOWER', 'proper': 'PROPER', 'len': 'LEN',
    'substitute': 'SUBSTITUTE', 'find': 'FIND', 'before': 'BEFORE',
    'after': 'AFTER', 'concat': 'JOINED', 'pad': 'PAD',
}


def _text_series(s):
    """Coerce any column to clean text.

    Nulls become '' (not the string 'nan'), and whole numbers lose their float
    tail so LEFT(3) on an ID column reads "104" rather than "104.0" - which is
    what an Excel user expects.
    """
    if pd.api.types.is_numeric_dtype(s):
        def fmt(x):
            if pd.isna(x):
                return ''
            f = float(x)
            return str(int(f)) if f.is_integer() else repr(f)
        return s.map(fmt)
    return s.astype(str).where(s.notna(), '')


def _int_param(params, key, label, default, minimum):
    """Read a whole-number operand with a user-facing error message."""
    raw = (params or {}).get(key, default)
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        raw = default
    try:
        val = int(str(raw).strip())
    except (TypeError, ValueError):
        raise DataAnalysisError(f"'{label}' must be a whole number.")
    if val < minimum:
        raise DataAnalysisError(f"'{label}' must be {minimum} or more.")
    return val


def _flag(params, key, default=False):
    """Read a checkbox operand (accepts JSON booleans or 'true'/'1'/'yes')."""
    v = (params or {}).get(key, default)
    if isinstance(v, str):
        return v.strip().lower() in ('1', 'true', 'yes', 'on')
    return bool(v)


def _text_param(params, key, label, required=True):
    v = (params or {}).get(key, '')
    v = '' if v is None else str(v)
    if required and not v:
        raise DataAnalysisError(f"'{label}' is required for this operation.")
    return v


def _unique_column(df, name):
    """Return `name`, suffixed if needed, so nothing is silently overwritten."""
    if name not in df.columns:
        return name
    i = 2
    while f"{name} ({i})" in df.columns:
        i += 1
    return f"{name} ({i})"


def _compute_text(df, op, cols, params):
    """Return the result Series for one text operation."""
    src = cols[0]

    if op == 'concat':
        sep = params.get('separator', '')
        sep = '' if sep is None else str(sep)
        skip_empty = _flag(params, 'skip_empty', True)
        texts = [_text_series(df[c]) for c in cols]
        if not len(df):
            return pd.Series([], dtype='object', index=df.index)
        rows = zip(*[t.tolist() for t in texts])
        joined = [
            sep.join([v for v in row if v != ''] if skip_empty else list(row))
            for row in rows
        ]
        return pd.Series(joined, index=df.index, dtype='object')

    t = _text_series(df[src])

    if op == 'left':
        n = _int_param(params, 'count', 'Number of characters', 3, 1)
        return t.str.slice(0, n)
    if op == 'right':
        n = _int_param(params, 'count', 'Number of characters', 3, 1)
        return t.str.slice(start=-n)
    if op == 'mid':
        start = _int_param(params, 'start', 'Start position', 1, 1)
        n = _int_param(params, 'count', 'Number of characters', 3, 1)
        return t.str.slice(start - 1, start - 1 + n)
    if op == 'trim':
        # Excel TRIM: strip the ends AND collapse runs of whitespace inside.
        return t.str.replace(r'\s+', ' ', regex=True).str.strip()
    if op == 'upper':
        return t.str.upper()
    if op == 'lower':
        return t.str.lower()
    if op == 'proper':
        return t.str.title()
    if op == 'len':
        return t.str.len().fillna(0).astype('int64')

    if op == 'substitute':
        needle = _text_param(params, 'find', 'Text to find')
        repl = _text_param(params, 'replace', 'Replace with', required=False)
        if _flag(params, 'match_case'):
            return t.str.replace(needle, repl, regex=False)
        # Case-insensitive literal replace: escape the needle, and use a
        # callable replacement so backslashes in `repl` stay literal.
        return t.str.replace(
            re.escape(needle), lambda m: repl, regex=True, flags=re.IGNORECASE
        )

    if op == 'find':
        needle = _text_param(params, 'find', 'Text to find')
        if _flag(params, 'match_case'):
            hay, pin = t, needle
        else:
            hay, pin = t.str.lower(), needle.lower()
        return (hay.str.find(pin) + 1).astype('int64')   # 0 when not found

    if op in ('before', 'after'):
        delim = _text_param(params, 'delimiter', 'Delimiter')
        parts = t.str.partition(delim)
        # No delimiter found -> partition returns (whole, '', ''), so BEFORE
        # keeps the value untouched and AFTER comes back blank.
        return parts.iloc[:, 0] if op == 'before' else parts.iloc[:, 2]

    if op == 'pad':
        width = _int_param(params, 'width', 'Total width', 5, 1)
        fill = _text_param(params, 'fill', 'Pad with', required=False) or '0'
        return t.str.pad(width, side='left', fillchar=fill[0])

    raise DataAnalysisError(f"Unknown text operation: {op!r}")   # pragma: no cover


def apply_text_op(df, op, columns, target=None, params=None, mode='new'):
    """Apply one Excel-style text function and return (new_df, stats).

    `columns` is a list (only CONCAT uses more than the first entry); `mode` is
    'new' (add a column, placed right after the source) or 'replace' (write
    back over the source column). `target` names the new column - blank gives
    an automatic name like "Account Code (LEFT)".
    """
    params = params or {}
    op = (op or '').strip().lower()
    if op not in TEXT_OPS:
        raise DataAnalysisError(f"Unknown text operation: {op!r}")

    cols = [c for c in (columns or []) if c]
    if not cols:
        raise DataAnalysisError("Pick at least one column to work on.")
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise DataAnalysisError(f"Column(s) not found: {', '.join(missing)}")
    if op not in TEXT_OPS_MULTI:
        cols = cols[:1]

    result = _compute_text(df, op, cols, params)

    out = df.copy()
    replace = str(mode).strip().lower() == 'replace' and op not in TEXT_OPS_MULTI
    if replace:
        name = cols[0]
        out[name] = result
    else:
        name = (target or '').strip() or f"{cols[0]} ({_TEXT_OP_SUFFIX[op]})"
        name = _unique_column(out, name)
        # Drop the derived column next to the column it came from.
        pos = max(out.columns.get_loc(c) for c in cols) + 1
        out.insert(pos, name, result)

    # A few before/after examples so the user can sanity-check the operation.
    src_text = _text_series(df[cols[0]])
    samples = []
    for i in range(min(len(out), 200)):        # scan a slice, not the whole file
        if len(samples) >= 5:
            break
        before = src_text.iloc[i]
        if before == '':
            continue
        samples.append([before, _json_safe_value(result.iloc[i])])

    blank = int((result.astype(str) == '').sum()) if result.dtype == object else 0
    stats = {
        'op': op,
        'op_label': TEXT_OPS[op],
        'source': cols if op in TEXT_OPS_MULTI else cols[0],
        'target': name,
        'replaced': bool(replace),
        'rows': int(len(out)),
        'blank': blank,
        'samples': samples,
    }
    return out, stats


# VLOOKUP  (merge a lookup table into the current dataset on a key column)

# Join strategies offered in the UI. Keep keys in sync with the template.
VLOOKUP_HOWS = {
    'left':  'Keep every current row (classic VLOOKUP)',
    'inner': 'Keep only rows that found a match',
}


def _norm_key(series):
    """Tolerant join key: trimmed, case-insensitive text. Numbers like 1 and
    1.0 collapse to the same key so Excel-style value matching works."""
    s = series.copy()
    if pd.api.types.is_numeric_dtype(s):
        # 1.0 -> "1" but 1.5 -> "1.5"
        def fmt(x):
            if pd.isna(x):
                return ''
            f = float(x)
            return str(int(f)) if f.is_integer() else repr(f)
        return s.map(fmt)
    return s.astype(str).str.strip().str.casefold().where(s.notna(), '')


def vlookup(left_df, right_df, left_on, right_on, bring=None, how='left'):
    """Excel-style lookup: for each row of `left_df`, find the matching row in
    `right_df` (first match wins) and bring across the chosen columns.

    Returns (merged_df, stats).
    """
    if not left_on or left_on not in left_df.columns:
        raise DataAnalysisError(f"Lookup key not found in current data: {left_on!r}")
    if not right_on or right_on not in right_df.columns:
        raise DataAnalysisError(f"Lookup key not found in the lookup file: {right_on!r}")
    if how not in VLOOKUP_HOWS:
        how = 'left'

    # Columns to bring across: default to everything in the lookup file except
    # its key column.
    bring = [c for c in (bring or []) if c and c in right_df.columns and c != right_on]
    if not bring:
        bring = [c for c in right_df.columns if c != right_on]
    if not bring:
        raise DataAnalysisError("The lookup file has no columns to bring across.")

    # Suffix any brought column that already exists on the left so nothing is
    # silently overwritten.
    rename = {c: f"{c} (lookup)" for c in bring if c in left_df.columns}
    right_small = right_df[[right_on] + bring].rename(columns=rename)
    bring_out = [rename.get(c, c) for c in bring]

    # First match wins (like VLOOKUP); report how many lookup keys were dropped.
    right_small = right_small.assign(__k__=_norm_key(right_df[right_on]))
    dup_keys = int(right_small.duplicated(subset=['__k__']).sum())
    right_small = right_small.drop_duplicates(subset=['__k__'], keep='first')
    right_small = right_small.drop(columns=[right_on])

    left_tmp = left_df.assign(__k__=_norm_key(left_df[left_on]))
    merged = left_tmp.merge(right_small, on='__k__', how=how, indicator=True)
    matched = int((merged['_merge'] == 'both').sum())
    merged = merged.drop(columns=['__k__', '_merge']).reset_index(drop=True)

    stats = {
        'left_rows':   int(len(left_df)),
        'result_rows': int(len(merged)),
        'matched':     matched,
        'unmatched':   int(len(left_df) - matched),
        'brought':     bring_out,
        'dup_keys_in_lookup': dup_keys,
    }
    return merged, stats


# EXPORT

def export_bytes(df, fmt, title=None, lookup_columns=None, meta=None):
    """Serialise a DataFrame to downloadable bytes.

    Returns (data_bytes, mimetype, extension). `fmt` is 'csv' or 'xlsx'.

    The Excel branch renders a themed, print-ready workbook (see
    data_analysis_excel). `lookup_columns` names the columns a VLOOKUP brought
    across, so they can be shaded differently from the master data; `meta`
    carries provenance (filename, sheet, step, prepared_by, generated) for the
    workbook's Summary sheet.
    """
    fmt = (fmt or 'csv').lower()
    if fmt == 'csv':
        # utf-8-sig so Excel opens accented characters correctly.
        return df.to_csv(index=False).encode('utf-8-sig'), 'text/csv', 'csv'
    if fmt == 'xlsx':
        content = data_analysis_excel.build_data_workbook(
            df, title=title, lookup_columns=lookup_columns, meta=meta,
        )
        return (
            content,
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'xlsx',
        )
    raise DataAnalysisError("Unsupported export format - choose CSV or Excel.")
