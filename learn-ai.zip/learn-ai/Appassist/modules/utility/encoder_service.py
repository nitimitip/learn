"""
Encoder / Decoder service for the Utility blueprint.

Pure, stateless transforms between raw bytes and a chosen text encoding
scheme. Everything works on ``bytes`` internally so the same code path
handles both typed-in strings and uploaded files. Uploaded files are read
as raw bytes regardless of type (PDF, Word, images, archives, ...), so any
file can be encoded and decoded back byte-for-byte.

Supported schemes (encode and decode both ways):
    base64, base32, hex, url (percent-encoding), html (entities), rot13,
    gzip, zlib (compress), json (minify <-> prettify), brotli (if installed)
"""
import base64
import binascii
import codecs
import gzip
import html
import json
import urllib.parse
import zlib

# Optional dependency: brotli compression. Only offered when installed.
try:
    import brotli as _brotli
    _BROTLI_AVAILABLE = True
except ImportError:  # pragma: no cover - depends on environment
    _brotli = None
    _BROTLI_AVAILABLE = False


# Display name -> internal key. Order is the order shown in the dropdown.
SCHEMES = [
    ('base64', 'Base64'),
    ('base32', 'Base32'),
    ('hex',    'Hexadecimal'),
    ('url',    'URL (percent-encoding)'),
    ('html',   'HTML entities'),
    ('rot13',  'ROT13'),
    ('gzip',   'Gzip (compress / decompress)'),
    ('zlib',   'Zlib / Deflate (compress / decompress)'),
    ('json',   'JSON (encode = minify - decode = prettify)'),
]
# Brotli is only available when the optional package is installed.
if _BROTLI_AVAILABLE:
    SCHEMES.append(('brotli', 'Brotli (compress / decompress)'))

_VALID = {key for key, _ in SCHEMES}


class EncoderError(Exception):
    """Raised for user-facing encode/decode problems (bad input, etc.)."""


def is_valid_scheme(scheme):
    return scheme in _VALID


def read_input_bytes(path):
    """
    Read an uploaded file as raw bytes for encoding/decoding.

    Every file type (PDF, Word, images, archives, plain text, ...) is read
    verbatim so the full file round-trips byte-for-byte through encode/decode.
    """
    with open(path, 'rb') as fh:
        return fh.read()


def encode(scheme, data):
    """Encode raw ``bytes`` into the chosen scheme. Returns ``bytes``."""
    if scheme == 'base64':
        return base64.b64encode(data)
    if scheme == 'base32':
        return base64.b32encode(data)
    if scheme == 'hex':
        return binascii.hexlify(data)
    if scheme == 'url':
        return urllib.parse.quote_from_bytes(data).encode('ascii')
    if scheme == 'html':
        return html.escape(_as_text(data)).encode('utf-8')
    if scheme == 'rot13':
        return codecs.encode(_as_text(data), 'rot_13').encode('utf-8')
    if scheme == 'gzip':
        return gzip.compress(data)
    if scheme == 'zlib':
        return zlib.compress(data)
    if scheme == 'json':
        return _json_reformat(data, pretty=False)
    if scheme == 'brotli':
        return _brotli.compress(data)
    raise EncoderError(f"Unknown encoding scheme: {scheme}")


def decode(scheme, data):
    """Decode ``bytes`` (the encoded form) back to raw ``bytes``."""
    if scheme == 'base64':
        return _b64_decode(data)
    if scheme == 'base32':
        try:
            return base64.b32decode(_strip(data), casefold=True)
        except (binascii.Error, ValueError) as exc:
            raise EncoderError(f"Invalid Base32 input: {exc}")
    if scheme == 'hex':
        try:
            return binascii.unhexlify(_compact_hex(data))
        except (binascii.Error, ValueError) as exc:
            raise EncoderError(f"Invalid hexadecimal input: {exc}")
    if scheme == 'url':
        return urllib.parse.unquote_to_bytes(_as_text(data))
    if scheme == 'html':
        return html.unescape(_as_text(data)).encode('utf-8')
    if scheme == 'rot13':
        return codecs.decode(_as_text(data), 'rot_13').encode('utf-8')
    if scheme == 'gzip':
        try:
            return gzip.decompress(data)
        except (OSError, EOFError, zlib.error) as exc:
            raise EncoderError(f"Invalid Gzip input: {exc}")
    if scheme == 'zlib':
        try:
            return zlib.decompress(data)
        except zlib.error as exc:
            raise EncoderError(f"Invalid Zlib input: {exc}")
    if scheme == 'json':
        return _json_reformat(data, pretty=True)
    if scheme == 'brotli':
        try:
            return _brotli.decompress(data)
        except Exception as exc:
            raise EncoderError(f"Invalid Brotli input: {exc}")
    raise EncoderError(f"Unknown encoding scheme: {scheme}")


def transform(scheme, mode, data):
    """Dispatch to encode/decode. ``mode`` is 'encode' or 'decode'."""
    if not is_valid_scheme(scheme):
        raise EncoderError(f"Unknown encoding scheme: {scheme}")
    if mode == 'encode':
        return encode(scheme, data)
    if mode == 'decode':
        return decode(scheme, data)
    raise EncoderError(f"Unknown mode: {mode}")


# internal helpers

def _as_text(data):
    """Best-effort decode of bytes to text for text-oriented schemes."""
    if isinstance(data, str):
        return data
    return data.decode('utf-8', errors='replace')


def _strip(data):
    """Drop surrounding whitespace from encoded text input."""
    text = _as_text(data).strip()
    return text.encode('ascii', errors='ignore')


def _compact_hex(data):
    """Remove all whitespace from hex input so '48 65' and '4865' both work."""
    return ''.join(_as_text(data).split())


def _b64_decode(data):
    text = _as_text(data).strip()
    # Tolerate missing padding, a common copy/paste problem.
    padding = (-len(text)) % 4
    try:
        return base64.b64decode(text + ('=' * padding))
    except (binascii.Error, ValueError) as exc:
        raise EncoderError(f"Invalid Base64 input: {exc}")


def _json_reformat(data, pretty):
    """
    Validate JSON and re-serialise it.

    Encode  -> compact / minified (no extra whitespace).
    Decode  -> pretty-printed with 2-space indentation.
    """
    text = _as_text(data)
    try:
        obj = json.loads(text)
    except (json.JSONDecodeError, ValueError) as exc:
        raise EncoderError(f"Invalid JSON input: {exc}")
    if pretty:
        out = json.dumps(obj, indent=2, ensure_ascii=False)
    else:
        out = json.dumps(obj, separators=(',', ':'), ensure_ascii=False)
    return out.encode('utf-8')
