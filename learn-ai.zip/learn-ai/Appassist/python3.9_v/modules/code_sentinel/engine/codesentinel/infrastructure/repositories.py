"""
Repository layer: every SQL statement in the application lives here.

Repositories speak domain objects on the outside and SQL on the inside,
keeping persistence swappable and the rest of the codebase testable.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from ..domain.models import (
    FileAnalysis, Finding, IssueStatus, ScanResult, Severity,
    assign_fingerprints, relative_to_root,
)
from ..domain.scoring import QualityGateResult, ScoreCard
from ..domain.serialization import analysis_from_dict, analysis_to_dict
from .database import Database

_TIME_FORMAT = "%Y-%m-%d %H:%M:%S"


@dataclass(frozen=True)
class ProjectRecord:
    id: int
    name: str
    root_path: str
    created_at: str


@dataclass(frozen=True)
class ScanRecord:
    """One historical scan row (the dashboard trend feed)."""

    id: int
    project_id: int
    started_at: str
    finished_at: str | None
    files_scanned: int
    files_cached: int
    total_lines: int
    code_lines: int
    total_findings: int
    severity_counts: dict[Severity, int]
    duplication: float
    scores: dict[str, int]
    grade: str
    debt_minutes: int
    gate_passed: bool
    gate_reasons: list[str]


class ProjectRepository:
    def __init__(self, db: Database) -> None:
        self._db = db

    def get_or_create(self, root: Path, name: str | None = None) -> ProjectRecord:
        conn = self._db.connection()
        root_str = str(root.resolve())
        row = conn.execute(
            "SELECT * FROM projects WHERE root_path = ?", (root_str,)
        ).fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO projects (name, root_path) VALUES (?, ?)",
                (name or root.name or root_str, root_str),
            )
            conn.commit()
            row = conn.execute(
                "SELECT * FROM projects WHERE root_path = ?", (root_str,)
            ).fetchone()
        return self._record(row)

    def all(self) -> list[ProjectRecord]:
        rows = self._db.connection().execute(
            "SELECT * FROM projects ORDER BY name COLLATE NOCASE"
        ).fetchall()
        return [self._record(r) for r in rows]

    def rename(self, project_id: int, name: str) -> None:
        conn = self._db.connection()
        conn.execute("UPDATE projects SET name = ? WHERE id = ?", (name, project_id))
        conn.commit()

    def delete(self, project_id: int) -> None:
        conn = self._db.connection()
        conn.execute("DELETE FROM projects WHERE id = ?", (project_id,))
        conn.commit()

    @staticmethod
    def _record(row) -> ProjectRecord:
        return ProjectRecord(
            id=row["id"], name=row["name"],
            root_path=row["root_path"], created_at=row["created_at"],
        )


class ScanRepository:
    def __init__(self, db: Database) -> None:
        self._db = db

    def save(
        self,
        project_id: int,
        result: ScanResult,
        scorecard: ScoreCard,
        gate: QualityGateResult,
    ) -> int:
        """Persist scan summary + every finding; returns the scan id."""
        severities = result.severity_totals()
        conn = self._db.connection()
        cursor = conn.execute(
            """
            INSERT INTO scans (
                project_id, started_at, finished_at, files_scanned, files_cached,
                total_lines, code_lines, total_findings,
                blocker, critical, high, medium, low, info,
                duplication, security_score, reliability_score,
                maintainability_score, performance_score, overall_score,
                grade, debt_minutes, gate_passed, gate_reasons
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                project_id,
                result.started_at.strftime(_TIME_FORMAT),
                result.finished_at.strftime(_TIME_FORMAT) if result.finished_at else None,
                len(result.analyses),
                result.files_from_cache,
                result.total_lines,
                result.total_code_lines,
                result.total_findings,
                severities.get(Severity.BLOCKER, 0),
                severities.get(Severity.CRITICAL, 0),
                severities.get(Severity.HIGH, 0),
                severities.get(Severity.MEDIUM, 0),
                severities.get(Severity.LOW, 0),
                severities.get(Severity.INFO, 0),
                result.duplication_ratio,
                scorecard.security,
                scorecard.reliability,
                scorecard.maintainability,
                scorecard.performance,
                scorecard.overall,
                scorecard.grade,
                scorecard.technical_debt_minutes,
                1 if gate.passed else 0,
                json.dumps(gate.reasons),
            ),
        )
        scan_id = int(cursor.lastrowid)

        rows = []
        for analysis in result.analyses:
            rel = relative_to_root(analysis.path, result.root)
            fingerprints = assign_fingerprints(analysis.findings, rel)
            for finding, fingerprint in zip(analysis.findings, fingerprints):
                rows.append((
                    scan_id, fingerprint, rel, finding.line,
                    finding.tool, finding.rule_id, finding.severity.value,
                    finding.category, finding.cwe, finding.owasp,
                    finding.confidence, finding.message, finding.remediation,
                    finding.snippet,
                ))
        conn.executemany(
            """
            INSERT INTO issues (
                scan_id, fingerprint, file_path, line, tool, rule_id,
                severity, category, cwe, owasp, confidence, message,
                remediation, snippet
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            rows,
        )
        conn.commit()
        return scan_id

    def history(self, project_id: int, limit: int = 50) -> list[ScanRecord]:
        rows = self._db.connection().execute(
            "SELECT * FROM scans WHERE project_id = ? "
            "ORDER BY started_at DESC, id DESC LIMIT ?",
            (project_id, limit),
        ).fetchall()
        return [self._record(r) for r in rows]

    def latest(self, project_id: int) -> ScanRecord | None:
        records = self.history(project_id, limit=1)
        return records[0] if records else None

    def delete(self, scan_id: int) -> None:
        conn = self._db.connection()
        conn.execute("DELETE FROM scans WHERE id = ?", (scan_id,))
        conn.commit()

    @staticmethod
    def _record(row) -> ScanRecord:
        return ScanRecord(
            id=row["id"],
            project_id=row["project_id"],
            started_at=row["started_at"],
            finished_at=row["finished_at"],
            files_scanned=row["files_scanned"],
            files_cached=row["files_cached"],
            total_lines=row["total_lines"],
            code_lines=row["code_lines"],
            total_findings=row["total_findings"],
            severity_counts={
                Severity.BLOCKER: row["blocker"],
                Severity.CRITICAL: row["critical"],
                Severity.HIGH: row["high"],
                Severity.MEDIUM: row["medium"],
                Severity.LOW: row["low"],
                Severity.INFO: row["info"],
            },
            duplication=row["duplication"],
            scores={
                "security": row["security_score"],
                "reliability": row["reliability_score"],
                "maintainability": row["maintainability_score"],
                "performance": row["performance_score"],
                "overall": row["overall_score"],
            },
            grade=row["grade"],
            debt_minutes=row["debt_minutes"],
            gate_passed=bool(row["gate_passed"]),
            gate_reasons=json.loads(row["gate_reasons"] or "[]"),
        )


class TriageRepository:
    """False-positive / accepted-risk decisions, keyed by fingerprint."""

    def __init__(self, db: Database) -> None:
        self._db = db

    def set_status(
        self,
        project_id: int,
        fingerprint: str,
        status: IssueStatus,
        note: str = "",
    ) -> None:
        conn = self._db.connection()
        if status is IssueStatus.OPEN:
            conn.execute(
                "DELETE FROM triage WHERE project_id = ? AND fingerprint = ?",
                (project_id, fingerprint),
            )
        else:
            conn.execute(
                """
                INSERT INTO triage (project_id, fingerprint, status, note, decided_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT (project_id, fingerprint)
                DO UPDATE SET status = excluded.status, note = excluded.note,
                              decided_at = excluded.decided_at
                """,
                (project_id, fingerprint, status.value, note,
                 datetime.now().strftime(_TIME_FORMAT)),
            )
        conn.commit()

    def statuses(self, project_id: int) -> dict[str, IssueStatus]:
        rows = self._db.connection().execute(
            "SELECT fingerprint, status FROM triage WHERE project_id = ?",
            (project_id,),
        ).fetchall()
        out: dict[str, IssueStatus] = {}
        for row in rows:
            try:
                out[row["fingerprint"]] = IssueStatus(row["status"])
            except ValueError:
                continue
        return out

    def notes(self, project_id: int) -> dict[str, str]:
        rows = self._db.connection().execute(
            "SELECT fingerprint, note FROM triage WHERE project_id = ?",
            (project_id,),
        ).fetchall()
        return {row["fingerprint"]: row["note"] for row in rows}


class SettingsRepository:
    """Simple typed key/value store for application preferences."""

    def __init__(self, db: Database) -> None:
        self._db = db

    def get(self, key: str, default: str = "") -> str:
        row = self._db.connection().execute(
            "SELECT value FROM settings WHERE key = ?", (key,)
        ).fetchone()
        return row["value"] if row else default

    def set(self, key: str, value: str) -> None:
        conn = self._db.connection()
        conn.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) "
            "ON CONFLICT (key) DO UPDATE SET value = excluded.value",
            (key, value),
        )
        conn.commit()

    def get_json(self, key: str, default):
        raw = self.get(key)
        if not raw:
            return default
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return default

    def set_json(self, key: str, value) -> None:
        self.set(key, json.dumps(value))


class FileCacheRepository:
    """Incremental-scan cache backing `AnalysisEngine` (AnalysisCache protocol)."""

    def __init__(self, db: Database) -> None:
        self._db = db

    def get(self, path: str, content_hash: str, engine_key: str) -> FileAnalysis | None:
        row = self._db.connection().execute(
            "SELECT payload, content_hash FROM file_cache "
            "WHERE path = ? AND engine_key = ?",
            (path, engine_key),
        ).fetchone()
        if row is None or row["content_hash"] != content_hash:
            return None
        try:
            return analysis_from_dict(json.loads(row["payload"]))
        except (json.JSONDecodeError, KeyError, ValueError):
            return None

    def put(self, path: str, content_hash: str, engine_key: str,
            analysis: FileAnalysis) -> None:
        conn = self._db.connection()
        conn.execute(
            """
            INSERT INTO file_cache (path, content_hash, engine_key, payload)
            VALUES (?, ?, ?, ?)
            ON CONFLICT (path, engine_key)
            DO UPDATE SET content_hash = excluded.content_hash,
                          payload = excluded.payload,
                          cached_at = datetime('now', 'localtime')
            """,
            (path, content_hash, engine_key, json.dumps(analysis_to_dict(analysis))),
        )
        conn.commit()

    def clear(self) -> None:
        conn = self._db.connection()
        conn.execute("DELETE FROM file_cache")
        conn.commit()


def apply_triage(
    result: ScanResult,
    statuses: dict[str, IssueStatus],
) -> int:
    """
    Remove findings whose fingerprint is triaged as FP/accepted-risk.

    Returns the number of suppressed findings and records it on the result.
    """
    suppressed = 0
    for analysis in result.analyses:
        rel = relative_to_root(analysis.path, result.root)
        fingerprints = assign_fingerprints(analysis.findings, rel)
        kept: list[Finding] = []
        for finding, fingerprint in zip(analysis.findings, fingerprints):
            status = statuses.get(fingerprint)
            if status is not None and status.suppresses:
                suppressed += 1
            else:
                kept.append(finding)
        analysis.findings = kept
    result.suppressed_count = suppressed
    return suppressed
