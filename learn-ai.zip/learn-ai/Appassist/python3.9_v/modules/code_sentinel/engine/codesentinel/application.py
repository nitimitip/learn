"""
Application service layer - the one place that wires domain, analysis,
infrastructure, and reporting together. Both the GUI and the CLI drive
scans exclusively through `ScanService`, so behaviour is identical in
interactive and headless use.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Sequence

from .analysis.engine import AnalysisEngine, ProgressCallback
from .analysis.languages import registry as language_registry
from .analysis.scanner import DiscoveryResult, FileScanner
from .domain.models import IssueStatus, ScanResult
from .domain.scoring import (
    QualityGate, QualityGateConfig, QualityGateResult, ScoreCard, compute_scorecard,
)
from .infrastructure.database import Database
from .infrastructure.paths import plugins_dir, user_rules_dir
from .infrastructure.repositories import (
    FileCacheRepository, ProjectRecord, ProjectRepository, ScanRepository,
    SettingsRepository, TriageRepository, apply_triage,
)
from .plugins.api import PluginContext
from .plugins.manager import PluginManager
from .reporting.base import ExporterRegistry, ReportContext, build_default_registry

logger = logging.getLogger(__name__)


@dataclass
class ScanOutcome:
    """Everything a caller needs after a completed scan."""

    project: ProjectRecord
    scan_id: int
    result: ScanResult
    scorecard: ScoreCard
    gate: QualityGateResult
    discovery: DiscoveryResult

    def report_context(self) -> ReportContext:
        return ReportContext(
            result=self.result,
            scorecard=self.scorecard,
            gate=self.gate,
            project_name=self.project.name,
        )


class ApplicationServices:
    """Composition root: builds and owns every long-lived component."""

    def __init__(self, db: Database | None = None) -> None:
        self.db = db or Database()
        self.projects = ProjectRepository(self.db)
        self.scans = ScanRepository(self.db)
        self.triage = TriageRepository(self.db)
        self.settings = SettingsRepository(self.db)
        self.file_cache = FileCacheRepository(self.db)
        self.languages = language_registry
        self.exporters: ExporterRegistry = build_default_registry()

        # Plugins may add languages, rule packs, and exporters.
        self.plugin_context = PluginContext(
            languages=self.languages,
            register_exporter=self.exporters.register,
        )
        self.plugins = PluginManager(self.plugin_context)
        self.plugins.load_directory(plugins_dir())

        self.scan_service = ScanService(self)

    # ---- Settings-backed configuration -------------------------------------

    def disabled_rule_ids(self) -> list[str]:
        return self.settings.get_json("rules.disabled", [])

    def set_rule_enabled(self, rule_id: str, enabled: bool) -> None:
        disabled = set(self.disabled_rule_ids())
        if enabled:
            disabled.discard(rule_id)
        else:
            disabled.add(rule_id)
        self.settings.set_json("rules.disabled", sorted(disabled))

    def gate_config(self) -> QualityGateConfig:
        stored = self.settings.get_json("gate.config", {})
        defaults = QualityGateConfig()
        return QualityGateConfig(
            max_blocker=int(stored.get("max_blocker", defaults.max_blocker)),
            max_critical=int(stored.get("max_critical", defaults.max_critical)),
            max_high=int(stored.get("max_high", defaults.max_high)),
            max_duplication=float(stored.get("max_duplication", defaults.max_duplication)),
            min_security_score=int(stored.get("min_security_score",
                                              defaults.min_security_score)),
            fail_on_analysis_errors=bool(stored.get('fail_on_analysis_errors', True)),
            require_language_parsers=bool(stored.get('require_language_parsers', False)),
            min_language_security_score=int(stored.get('min_language_security_score', 0)),
        )

    def max_workers(self) -> int:
        try:
            return int(self.settings.get("scan.max_workers", "0"))
        except ValueError:
            return 0

    def rule_pack_dirs(self) -> list[Path]:
        return [user_rules_dir(), *self.plugin_context.rule_pack_dirs]


class ScanService:
    """Runs a complete scan: discovery -> analysis -> triage -> scoring -> persist."""

    def __init__(self, services: ApplicationServices) -> None:
        self._services = services
        self._engine: AnalysisEngine | None = None

    def build_engine(self, use_cache: bool = True) -> AnalysisEngine:
        services = self._services
        self._engine = AnalysisEngine(
            cache=services.file_cache if use_cache else None,
            max_workers=services.max_workers(),
            extra_rule_dirs=services.rule_pack_dirs(),
            disabled_rule_ids=services.disabled_rule_ids(),
        )
        return self._engine

    def cancel(self) -> None:
        if self._engine is not None:
            self._engine.cancel()

    def scan(
        self,
        root: Path,
        progress: ProgressCallback | None = None,
        log: Callable[[str], None] | None = None,
        use_cache: bool = True,
        persist: bool = True,
    ) -> ScanOutcome:
        services = self._services
        emit = log or (lambda message: None)
        root = root.resolve()

        project = services.projects.get_or_create(root)
        engine = self.build_engine(use_cache)
        emit(f"Rule set: {len(engine.rule_set.all_rules())} rules "
             f"({len([r for r in engine.rule_set.all_rules() if r.enabled])} enabled)")

        scanner = FileScanner(services.languages)
        discovery = scanner.discover(root)
        emit(f"Discovered {len(discovery.files)} analysable file(s)"
             + (f", skipped {discovery.skipped_large} oversized" if discovery.skipped_large else "")
             + (" - LIMIT REACHED, scan truncated" if discovery.truncated else ""))

        result = engine.run(discovery.files, root, progress)
        emit(f"Analysed {len(result.analyses)} file(s) "
             f"({result.files_from_cache} from cache) in "
             f"{result.duration_seconds:.1f}s")

        # Apply persisted triage decisions (FP / accepted risk).
        statuses = services.triage.statuses(project.id)
        if statuses:
            suppressed = apply_triage(result, statuses)
            if suppressed:
                emit(f"Suppressed {suppressed} finding(s) per triage decisions")

        scorecard = compute_scorecard(result)
        gate = QualityGate(services.gate_config()).evaluate(result)
        emit(f"QUALITY GATE: {gate.verdict}")
        for reason in gate.reasons:
            emit(f"  X {reason}")

        scan_id = 0
        if persist:
            scan_id = services.scans.save(project.id, result, scorecard, gate)
            emit(f"Scan #{scan_id} saved to history")

        return ScanOutcome(
            project=project, scan_id=scan_id, result=result,
            scorecard=scorecard, gate=gate, discovery=discovery,
        )
