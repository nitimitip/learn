"""
Language registry.

Every supported language is described by a `LanguageSpec` - extensions,
comment syntax, and complexity heuristics - and registered in a single
registry that the scanner, rule engine, metrics calculator, and UI all
share. New languages can be contributed by plugins without touching this
module (see `codesentinel.plugins`).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

#: PL/SQL markers used to disambiguate .sql files during auto-detection.
_PLSQL_MARKERS = re.compile(
    r"CREATE\s+OR\s+REPLACE\s+(PACKAGE|PROCEDURE|FUNCTION|TRIGGER|TYPE)"
    r"|\bELSIF\b|EXECUTE\s+IMMEDIATE|\bDBMS_\w+|%TYPE\b|%ROWTYPE\b|:=",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class LanguageSpec:
    """Everything the platform needs to know about one language."""

    id: str
    display_name: str
    extensions: frozenset[str]
    #: Exact filenames (lowercase) claimed regardless of extension.
    filenames: frozenset[str] = frozenset()
    #: Line-comment prefixes, e.g. ("#",) or ("//",).
    comment_prefixes: tuple[str, ...] = ()
    #: Block-comment delimiter pairs, e.g. (("/*", "*/"),). Content is
    #: masked out before non-secret rules run (secrets still checked).
    block_comments: tuple[tuple[str, str], ...] = ()
    #: Multi-line string delimiter pairs (triple quotes, template literals,
    #: here-strings). Tracked so comment openers inside them are ignored;
    #: a span opening at line start is documentation (docstring) and is
    #: masked like a comment, one opening mid-line is data and stays visible.
    string_spans: tuple[tuple[str, str], ...] = ()
    #: Regex counting decision points for cyclomatic complexity.
    decision_pattern: re.Pattern[str] | None = None
    #: Regex matching function/method definitions.
    function_pattern: re.Pattern[str] | None = None


def _rx(expr: str, ignore_case: bool = False) -> re.Pattern[str]:
    return re.compile(expr, re.IGNORECASE if ignore_case else 0)


_C_DECISIONS = _rx(r"\b(if|for|while|case|catch)\b|&&|\|\||\?\s")
_C_FUNCTIONS = _rx(r"^\s*(public|private|protected|internal|static|[\w:<>~*&]+)\s.*\)\s*(const)?\s*\{?\s*$")

_BUILTIN_SPECS: tuple[LanguageSpec, ...] = (
    LanguageSpec(
        "python", "Python", frozenset({".py", ".pyw"}),
        comment_prefixes=("#",),
        string_spans=(('"""', '"""'), ("'''", "'''")),
        decision_pattern=_rx(r"\b(if|elif|for|while|except|case|and|or)\b"),
        function_pattern=_rx(r"^\s*(async\s+)?def\s+\w+"),
    ),
    LanguageSpec(
        "java", "Java", frozenset({".java"}),
        comment_prefixes=("//",),
        block_comments=(("/*", "*/"),),
        string_spans=(('"""', '"""'),),
        decision_pattern=_rx(r"\b(if|for|while|case|catch)\b|&&|\|\||\?\s"),
        function_pattern=_rx(r"^\s*(public|private|protected|static).*\)\s*\{?\s*$"),
    ),
    LanguageSpec(
        "javascript", "JavaScript", frozenset({".js", ".jsx", ".mjs", ".cjs"}),
        comment_prefixes=("//",),
        block_comments=(("/*", "*/"),),
        string_spans=(("`", "`"),),
        decision_pattern=_rx(r"\b(if|for|while|case|catch)\b|&&|\|\||\?\?"),
        function_pattern=_rx(r"\bfunction\s*\w*\s*\(|=>|^\s*(async\s+)?\w+\s*\([^)]*\)\s*\{\s*$"),
    ),
    LanguageSpec(
        "typescript", "TypeScript", frozenset({".ts", ".tsx", ".mts", ".cts"}),
        comment_prefixes=("//",),
        block_comments=(("/*", "*/"),),
        string_spans=(("`", "`"),),
        decision_pattern=_rx(r"\b(if|for|while|case|catch)\b|&&|\|\||\?\?"),
        function_pattern=_rx(r"\bfunction\s*\w*\s*\(|=>|^\s*(async\s+)?\w+\s*\([^)]*\)\s*\{\s*$"),
    ),
    LanguageSpec(
        "c", "C", frozenset({".c", ".h"}),
        comment_prefixes=("//",),
        block_comments=(("/*", "*/"),),
        decision_pattern=_C_DECISIONS,
        function_pattern=_rx(r"^[\w*\s]+\s+\**\w+\s*\([^;]*\)\s*\{?\s*$"),
    ),
    LanguageSpec(
        "cpp", "C++", frozenset({".cpp", ".cc", ".cxx", ".hpp", ".hh", ".hxx"}),
        comment_prefixes=("//",),
        block_comments=(("/*", "*/"),),
        decision_pattern=_C_DECISIONS,
        function_pattern=_C_FUNCTIONS,
    ),
    LanguageSpec(
        "csharp", "C#", frozenset({".cs"}),
        comment_prefixes=("//",),
        block_comments=(("/*", "*/"),),
        string_spans=(('@"', '"'),),
        decision_pattern=_rx(r"\b(if|for|foreach|while|case|catch)\b|&&|\|\||\?\?|\?\s"),
        function_pattern=_rx(r"^\s*(public|private|protected|internal|static).*\)\s*\{?\s*$"),
    ),
    LanguageSpec(
        "go", "Go", frozenset({".go"}),
        comment_prefixes=("//",),
        block_comments=(("/*", "*/"),),
        decision_pattern=_rx(r"\b(if|for|case|select)\b|&&|\|\|"),
        function_pattern=_rx(r"^\s*func\s+(\(\w+\s+\*?\w+\)\s+)?\w+\s*\("),
    ),
    LanguageSpec(
        "rust", "Rust", frozenset({".rs"}),
        comment_prefixes=("//",),
        block_comments=(("/*", "*/"),),
        decision_pattern=_rx(r"\b(if|for|while|loop|match)\b|&&|\|\|"),
        function_pattern=_rx(r"^\s*(pub\s+)?(async\s+)?fn\s+\w+"),
    ),
    LanguageSpec(
        "php", "PHP", frozenset({".php", ".phtml"}),
        comment_prefixes=("//", "#"),
        block_comments=(("/*", "*/"),),
        decision_pattern=_rx(r"\b(if|elseif|for|foreach|while|case|catch)\b|&&|\|\||\?\?"),
        function_pattern=_rx(r"\bfunction\s+\w+\s*\(", ignore_case=True),
    ),
    LanguageSpec(
        "kotlin", "Kotlin", frozenset({".kt", ".kts"}),
        comment_prefixes=("//",),
        block_comments=(("/*", "*/"),),
        decision_pattern=_rx(r"\b(if|for|while|when|catch)\b|&&|\|\||\?:"),
        function_pattern=_rx(r"^\s*(override\s+|private\s+|public\s+|internal\s+)*fun\s+\w+"),
    ),
    LanguageSpec(
        "swift", "Swift", frozenset({".swift"}),
        comment_prefixes=("//",),
        block_comments=(("/*", "*/"),),
        decision_pattern=_rx(r"\b(if|for|while|switch|catch|guard)\b|&&|\|\||\?\?"),
        function_pattern=_rx(r"^\s*(public\s+|private\s+|internal\s+|open\s+)*func\s+\w+"),
    ),
    LanguageSpec(
        "dart", "Dart", frozenset({".dart"}),
        comment_prefixes=("//",),
        block_comments=(("/*", "*/"),),
        decision_pattern=_rx(r"\b(if|for|while|switch|catch)\b|&&|\|\||\?\?"),
        function_pattern=_rx(r"^\s*[\w<>,\s]+\s+\w+\s*\([^;]*\)\s*(async\s*)?\{?\s*$"),
    ),
    LanguageSpec(
        "sql", "SQL", frozenset({".sql"}),
        comment_prefixes=("--",),
        block_comments=(("/*", "*/"),),
        decision_pattern=_rx(r"\b(WHEN|AND|OR)\b", ignore_case=True),
        function_pattern=_rx(r"^\s*CREATE\s+(OR\s+REPLACE\s+)?(PROCEDURE|FUNCTION)", ignore_case=True),
    ),
    LanguageSpec(
        "plsql", "PL/SQL", frozenset({".pks", ".pkb", ".plb", ".prc", ".fnc"}),
        comment_prefixes=("--",),
        block_comments=(("/*", "*/"),),
        decision_pattern=_rx(r"\b(IF|ELSIF|LOOP|WHILE|FOR|WHEN|AND|OR)\b", ignore_case=True),
        function_pattern=_rx(r"^\s*(PROCEDURE|FUNCTION)\s+\w+", ignore_case=True),
    ),
    LanguageSpec(
        "shell", "Shell", frozenset({".sh", ".bash", ".ksh", ".zsh"}),
        comment_prefixes=("#",),
        decision_pattern=_rx(r"\b(if|elif|for|while|until|case)\b|&&|\|\|"),
        function_pattern=_rx(r"^\s*(function\s+\w+|\w+\s*\(\)\s*\{?)"),
    ),
    LanguageSpec(
        "powershell", "PowerShell", frozenset({".ps1", ".psm1", ".psd1"}),
        comment_prefixes=("#",),
        block_comments=(("<#", "#>"),),
        string_spans=(("@'", "'@"), ('@"', '"@')),
        decision_pattern=_rx(r"\b(if|elseif|for|foreach|while|switch|catch)\b|-and\b|-or\b", ignore_case=True),
        function_pattern=_rx(r"^\s*function\s+[\w-]+", ignore_case=True),
    ),
    LanguageSpec(
        # Windows batch. Comments: 'rem'/'REM' and the ':: ' label-comment;
        # cased variants are listed because comment matching is exact-case.
        "batch", "Batch", frozenset({".bat", ".cmd"}),
        comment_prefixes=("::", "rem ", "REM ", "Rem ", "@rem ", "@REM "),
        decision_pattern=_rx(r"\b(if|for|goto)\b|&&|\|\|", ignore_case=True),
        function_pattern=_rx(r"^\s*:\w+"),      # :label subroutines
    ),
    LanguageSpec(
        "html", "HTML", frozenset({".html", ".htm"}),
        comment_prefixes=("<!--",),
        block_comments=(("<!--", "-->"),),
        decision_pattern=_rx(r"\b(if|for|while|case|catch)\b|&&|\|\|"),
        function_pattern=_rx(r"\bfunction\s+\w+|\w+\s*=\s*(\([^)]*\)|\w+)\s*=>"),
    ),
    LanguageSpec(
        "jinja", "Jinja2", frozenset({".jinja", ".j2", ".jinja2"}),
        comment_prefixes=(),          # Jinja uses {# #}, not a line comment
        block_comments=(("{#", "#}"),),
    ),
    LanguageSpec(
        "razor", "Razor", frozenset({".cshtml", ".razor"}),
        comment_prefixes=(),          # Razor uses @* *@, not a line comment
        block_comments=(("@*", "*@"),),
    ),
    LanguageSpec(
        "css", "CSS", frozenset({".css", ".scss", ".less"}),
        comment_prefixes=(),
        block_comments=(("/*", "*/"),),
    ),
    LanguageSpec(
        "xml", "XML", frozenset({".xml", ".xsd", ".xsl", ".config", ".csproj", ".vbproj"}),
        comment_prefixes=("<!--",),
        block_comments=(("<!--", "-->"),),
    ),
    LanguageSpec(
        "yaml", "YAML", frozenset({".yml", ".yaml"}),
        comment_prefixes=("#",),
    ),
    LanguageSpec(
        "json", "JSON", frozenset({".json"}),
        comment_prefixes=(),
    ),
    LanguageSpec(
        "terraform", "Terraform", frozenset({".tf", ".tfvars"}),
        comment_prefixes=("#", "//"),
        block_comments=(("/*", "*/"),),
        decision_pattern=_rx(r"\b(for|if)\b"),
    ),
    LanguageSpec(
        "dockerfile", "Dockerfile", frozenset({".dockerfile"}),
        filenames=frozenset({"dockerfile", "containerfile"}),
        comment_prefixes=("#",),
    ),
    LanguageSpec(
        # KEY=value configuration files - the classic home of unquoted
        # credentials that language-scoped source rules never see.
        "config", "Config file",
        frozenset({".env", ".ini", ".properties", ".cfg", ".conf", ".toml"}),
        filenames=frozenset({
            ".env", ".env.local", ".env.development", ".env.production",
            ".env.test", ".env.staging", ".env.example", ".flaskenv",
        }),
        comment_prefixes=("#", ";"),
    ),
)


class LanguageRegistry:
    """Registry mapping ids/extensions/filenames to `LanguageSpec`s."""

    def __init__(self, specs: tuple[LanguageSpec, ...] = _BUILTIN_SPECS) -> None:
        self._by_id: dict[str, LanguageSpec] = {}
        self._by_extension: dict[str, str] = {}
        self._by_filename: dict[str, str] = {}
        for spec in specs:
            self.register(spec)

    def register(self, spec: LanguageSpec) -> None:
        """Add or replace a language. Later registrations win on conflicts."""
        self._by_id[spec.id] = spec
        for ext in spec.extensions:
            self._by_extension[ext.lower()] = spec.id
        for name in spec.filenames:
            self._by_filename[name.lower()] = spec.id

    def get(self, language_id: str) -> LanguageSpec | None:
        return self._by_id.get(language_id)

    def display_name(self, language_id: str) -> str:
        spec = self._by_id.get(language_id)
        return spec.display_name if spec else language_id

    def all_specs(self) -> list[LanguageSpec]:
        return sorted(self._by_id.values(), key=lambda s: s.display_name.lower())

    def known_extensions(self) -> set[str]:
        return set(self._by_extension)

    def detect(self, path: Path) -> LanguageSpec | None:
        """
        Map a file to its language.

        Filename matches (Dockerfile) win over extensions. `.sql` files are
        content-sniffed to distinguish PL/SQL from ANSI SQL.
        """
        name = path.name.lower()
        if name in self._by_filename:
            return self._by_id[self._by_filename[name]]

        suffix = path.suffix.lower()
        if suffix == ".sql":
            try:
                head = path.read_text(encoding="utf-8", errors="replace")[:8192]
            except OSError:
                return self._by_id.get("sql")
            target = "plsql" if _PLSQL_MARKERS.search(head) else "sql"
            return self._by_id.get(target)

        language_id = self._by_extension.get(suffix)
        return self._by_id.get(language_id) if language_id else None


#: Process-wide default registry. Plugins may register additional languages.
registry = LanguageRegistry()
