"""Recursive source-file discovery with noise pruning."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from .languages import LanguageRegistry

#: Directories pruned during recursive scans - VCS metadata, build artefacts,
#: virtual environments, and vendored dependencies.
IGNORED_DIRS: frozenset[str] = frozenset({
    ".git", ".svn", ".hg",
    "__pycache__", ".mypy_cache", ".pytest_cache", ".ruff_cache", ".tox",
    ".venv", "venv", "env",
    "node_modules", "bower_components",
    "bin", "obj", "dist", "build", "target", "out",
    ".idea", ".vs", ".vscode",
})

#: Files above this size are treated as generated/vendored and skipped.
MAX_FILE_BYTES = 2 * 1024 * 1024


@dataclass
class DiscoveryResult:
    """Outcome of a discovery walk."""

    files: list[Path]
    truncated: bool
    skipped_large: int


class FileScanner:
    """Walks a tree collecting every file the language registry claims."""

    def __init__(
        self,
        registry: LanguageRegistry,
        ignored_dirs: frozenset[str] = IGNORED_DIRS,
        max_files: int = 100_000,
    ) -> None:
        self._registry = registry
        self._ignored = ignored_dirs
        self._max_files = max_files

    def discover(self, root: Path) -> DiscoveryResult:
        """
        Walk `root` and return every analysable file.

        A single file input is returned as-is when the registry claims it.
        `truncated` is True when `max_files` was reached, letting the caller
        warn the user rather than silently analysing an arbitrary subset.
        """
        if root.is_file():
            claimed = self._registry.detect(root) is not None
            return DiscoveryResult([root] if claimed else [], False, 0)

        matches: list[Path] = []
        skipped_large = 0

        for dirpath, dirnames, filenames in os.walk(root, onerror=None):
            # Mutating dirnames in place prunes the walk before descent.
            dirnames[:] = [
                d for d in dirnames
                if d not in self._ignored and
                (not d.startswith(".") or d in {'.github', '.gitlab', '.circleci'})
                and not (Path(dirpath) / d).is_symlink()
            ]

            for filename in sorted(filenames):
                candidate = Path(dirpath) / filename
                if candidate.is_symlink():
                    continue
                if self._registry.detect(candidate) is None:
                    continue
                try:
                    size = candidate.stat().st_size
                except OSError:
                    continue  # broken symlink, permission denied, etc.
                if size == 0:
                    continue
                if size > MAX_FILE_BYTES:
                    skipped_large += 1
                    continue

                matches.append(candidate)
                if len(matches) >= self._max_files:
                    return DiscoveryResult(matches, True, skipped_large)

        return DiscoveryResult(matches, False, skipped_large)
