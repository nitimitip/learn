"""
Shared document version history
===============================
One generic version trail for every module that keeps an uploaded file as a
*durable artifact* - a file the user comes back to download later:

    project_management  -> ProjectDocument   (entity_type 'project_document')
    application_support -> FileInventory     (entity_type 'app_support_file')
    service_now_analysis-> GuideDocument     (entity_type 'servicenow_guide_doc')

It deliberately does NOT cover *ingest* uploads (ServiceNow exports, the
certificate workbook, the holiday calendar, Code Sentinel packages, the utility
converters). There the file is consumed into rows and thrown away - re-uploading
already replaces the data, so a version trail would carry no meaning.

Model
-----
`document_versions` is keyed by (entity_type, entity_id) rather than a foreign
key, so a single table serves every module without one table per owner. The
trade-off is that the database cannot cascade-delete versions when the owning
row goes: **the owning module must call `delete_all()` in its own delete
route**. Both PM's delete_document and any future integration do exactly that.

The owning row keeps pointing at the *current* file (e.g.
``ProjectDocument.filename``); the version trail holds that same current file as
its highest version_no, plus the previous ones. So "the last 4 versions"
includes the one in use - matching what the Versions panel shows.

Commit / unlink ordering
------------------------
Pruning is a two-step dance and the order is not cosmetic. `prune()` and
`delete_all()` remove the DB rows and RETURN the disk paths - they never unlink.
The caller commits first, then calls `remove_files()` on what came back:

    stale = file_versions.prune(db, ENTITY, doc.id, UPLOAD_FOLDER)
    db.commit()
    file_versions.remove_files(stale)

Unlinking before the commit would destroy the file and then, on a rollback,
leave a surviving row pointing at nothing.
"""

import hashlib
import logging
import os

from sqlalchemy import (
    Column, Integer, String, DateTime, ForeignKey, UniqueConstraint, Index,
)
from sqlalchemy.sql import func

from database import Base

logger = logging.getLogger(__name__)


# How many versions to keep per document, INCLUDING the current one. Older
# versions beyond this are pruned (row + file) on every new upload.
MAX_VERSIONS = int(os.environ.get('DOCUMENT_MAX_VERSIONS', '4'))

# Deeper retention for documents an audit may need to walk back through - the
# SDLC phase groups in project_management, whose gates depend on them. A prune
# destroys the dropped version permanently, so gate-bearing documents keep more
# history than a working attachment does.
SDLC_MAX_VERSIONS = int(os.environ.get('DOCUMENT_MAX_VERSIONS_SDLC', '10'))

# entity_type -> {category: keep}. Owning modules register their own overrides at
# import (see project_management.routes), so retention policy lives with the
# module that understands what its categories mean, not in a table here.
_RETENTION_OVERRIDES = {}


def register_retention(entity_type, categories, keep):
    """Keep `keep` versions of documents in `categories`, instead of MAX_VERSIONS."""
    bucket = _RETENTION_OVERRIDES.setdefault(entity_type, {})
    for category in categories:
        bucket[category] = keep


def retention_for(entity_type, category=None):
    """How many versions to keep for this document. MAX_VERSIONS unless overridden.

    `category` should be the NORMALISED group (project_management passes
    `doc.display_group`), so a legacy category name that maps onto an SDLC group
    still earns the deeper retention.
    """
    return _RETENTION_OVERRIDES.get(entity_type, {}).get(category, MAX_VERSIONS)

# Entity-type keys. Each owning module gets one; keep them stable - they are
# stored in the table and a rename would orphan every existing version row.
ENTITY_PROJECT_DOCUMENT = 'project_document'
ENTITY_APP_SUPPORT_FILE = 'app_support_file'
ENTITY_GUIDE_DOCUMENT = 'servicenow_guide_doc'


class DocumentVersion(Base):
    """One historical revision of an uploaded document."""
    __tablename__ = 'document_versions'

    id = Column(Integer, primary_key=True)

    # Owner, addressed generically (see module docstring - no FK on purpose).
    entity_type = Column(String(50), nullable=False)
    entity_id = Column(Integer, nullable=False)

    version_no = Column(Integer, nullable=False)        # 1-based, ascending
    stored_filename = Column(String(255), nullable=False)   # name on disk
    original_filename = Column(String(255))                 # what the user uploaded
    size_bytes = Column(Integer)
    sha256 = Column(String(64))                             # identical re-upload detection
    note = Column(String(500))                              # optional "what changed"

    uploaded_by = Column(Integer, ForeignKey('users.id'))
    uploaded_at = Column(DateTime, default=func.now())

    __table_args__ = (
        UniqueConstraint('entity_type', 'entity_id', 'version_no',
                         name='uq_document_version_no'),
        Index('ix_document_versions_entity', 'entity_type', 'entity_id'),
    )

    def __repr__(self):
        return (f'<DocumentVersion {self.entity_type}:{self.entity_id} '
                f'v{self.version_no}>')


# ---------------------------------------------------------------------------
# Path safety
# ---------------------------------------------------------------------------

def resolve_path(upload_dir, filename):
    """Absolute path of `filename` inside `upload_dir`, or None if it escapes.

    Stored names are secure_filename()-sanitised at upload, so this only fires
    on a tampered DB value - but an unlink must never follow a path out of the
    uploads directory.
    """
    if not filename:
        return None
    base = os.path.abspath(upload_dir)
    path = os.path.abspath(os.path.join(base, filename))
    try:
        if os.path.commonpath([base, path]) != base:
            return None
    except ValueError:      # different drive on Windows
        return None
    return path


def file_stats(path):
    """(size_bytes, sha256) for a file on disk; (None, None) if unreadable."""
    try:
        digest = hashlib.sha256()
        size = 0
        with open(path, 'rb') as fh:
            for chunk in iter(lambda: fh.read(65536), b''):
                digest.update(chunk)
                size += len(chunk)
        return size, digest.hexdigest()
    except OSError:
        logger.warning('Could not stat/hash uploaded file: %s', path)
        return None, None


def remove_files(paths):
    """Unlink files pruned by prune()/delete_all(). Call AFTER the commit.

    Best-effort: a file that is already gone, or locked by another process on
    Windows, must not blow up the request whose DB work has already landed.
    """
    for path in paths or ():
        if not path:
            continue
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            logger.warning('Could not remove pruned document file: %s', path,
                           exc_info=True)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------

def list_versions(db_session, entity_type, entity_id):
    """Every stored version, newest first."""
    return (db_session.query(DocumentVersion)
            .filter_by(entity_type=entity_type, entity_id=entity_id)
            .order_by(DocumentVersion.version_no.desc())
            .all())


def get_version(db_session, entity_type, entity_id, version_id):
    """One version, scoped to its owner so an id from another document 404s."""
    return (db_session.query(DocumentVersion)
            .filter_by(id=version_id, entity_type=entity_type, entity_id=entity_id)
            .first())


def version_counts(db_session, entity_type, entity_ids):
    """{entity_id: count} for a batch of owners - one query for a whole page."""
    ids = [i for i in (entity_ids or []) if i]
    if not ids:
        return {}
    rows = (db_session.query(DocumentVersion.entity_id,
                             func.count(DocumentVersion.id))
            .filter(DocumentVersion.entity_type == entity_type,
                    DocumentVersion.entity_id.in_(ids))
            .group_by(DocumentVersion.entity_id)
            .all())
    return {entity_id: count for entity_id, count in rows}


def _next_version_no(db_session, entity_type, entity_id):
    highest = (db_session.query(func.max(DocumentVersion.version_no))
               .filter_by(entity_type=entity_type, entity_id=entity_id)
               .scalar())
    return (highest or 0) + 1


# ---------------------------------------------------------------------------
# Writes  (none of these commit - the caller owns the transaction)
# ---------------------------------------------------------------------------

def record_version(db_session, entity_type, entity_id, upload_dir,
                   stored_filename, original_filename=None, uploaded_by=None,
                   note=None, uploaded_at=None):
    """Append the file now on disk as the next version. Returns the row.

    Does not commit and does not prune - call `prune()` next when this is a
    replacement rather than a first upload.
    """
    path = resolve_path(upload_dir, stored_filename)
    size, sha = file_stats(path) if path else (None, None)

    version = DocumentVersion(
        entity_type=entity_type,
        entity_id=entity_id,
        version_no=_next_version_no(db_session, entity_type, entity_id),
        stored_filename=stored_filename,
        original_filename=original_filename or stored_filename,
        size_bytes=size,
        sha256=sha,
        note=(note or '')[:500] or None,
        uploaded_by=uploaded_by,
    )
    if uploaded_at is not None:
        version.uploaded_at = uploaded_at
    db_session.add(version)

    # The app's sessions run with autoflush=False, so a pending row is invisible
    # to the next query. Flush now or a backfill-then-append (legacy doc gets v1,
    # new file gets v2) would compute version_no=1 twice and trip the unique
    # constraint - and prune() would not see the row it must keep. Still inside
    # the caller's transaction: a rollback undoes this.
    db_session.flush()
    return version


def backfill_initial(db_session, entity_type, entity_id, upload_dir,
                     stored_filename, original_filename=None, uploaded_by=None,
                     uploaded_at=None):
    """Seed v1 from a document uploaded before versioning existed.

    Idempotent: a document that already has any version row is left alone. This
    runs on the first *edit* of a legacy document, so its current file becomes
    v1 instead of vanishing from the trail when v2 lands.
    """
    if not stored_filename:
        return None
    existing = (db_session.query(DocumentVersion.id)
                .filter_by(entity_type=entity_type, entity_id=entity_id)
                .first())
    if existing:
        return None
    return record_version(
        db_session, entity_type, entity_id, upload_dir, stored_filename,
        original_filename=original_filename, uploaded_by=uploaded_by,
        uploaded_at=uploaded_at,
    )


def prune(db_session, entity_type, entity_id, upload_dir, keep=None, protect=()):
    """Drop versions beyond the newest `keep`. Returns paths to unlink AFTER commit.

    `protect` guards filenames that must survive whatever the trail says - the
    caller passes the document's *current* filename, so a bookkeeping slip can
    never delete the file the document is actually serving.
    """
    keep = MAX_VERSIONS if keep is None else keep
    protected = {f for f in protect if f}

    versions = list_versions(db_session, entity_type, entity_id)   # newest first
    stale_paths = []
    for version in versions[keep:]:
        if version.stored_filename not in protected:
            path = resolve_path(upload_dir, version.stored_filename)
            if path:
                stale_paths.append(path)
        db_session.delete(version)
    return stale_paths


def delete_all(db_session, entity_type, entity_id, upload_dir, protect=()):
    """Drop the whole trail (the owning document is going). Returns paths to unlink."""
    return prune(db_session, entity_type, entity_id, upload_dir, keep=0,
                 protect=protect)
