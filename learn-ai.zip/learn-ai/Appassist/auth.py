import logging
import os
import secrets

from flask import session
from database import get_db_session
from models import User

logger = logging.getLogger(__name__)


def create_admin_user():
    """Create the bootstrap admin account if no admin exists yet.

    The password comes from the ADMIN_INITIAL_PASSWORD env var (.env). When
    it is not set, a random one is generated and logged ONCE - there is no
    hardcoded default an attacker could look up in the source. Existing
    databases already have an admin row, so this never runs there.
    """
    db_session = get_db_session()
    try:
        admin_user = db_session.query(User).filter_by(role='admin').first()
        if not admin_user:
            password = os.environ.get('ADMIN_INITIAL_PASSWORD')
            generated = False
            if not password:
                password = secrets.token_urlsafe(12)
                generated = True
            admin = User(
                username='admin',
                firstname='admin',
                lastname='admin',
                email='admin@example.com',
                role='admin'
            )
            admin.set_password(password)
            db_session.add(admin)
            db_session.commit()
            if generated:
                logger.warning(
                    "Bootstrap admin user 'admin' created with GENERATED "
                    "password: %s - sign in and change it immediately "
                    "(or set ADMIN_INITIAL_PASSWORD before first start).",
                    password,
                )
            else:
                logger.info("Bootstrap admin user 'admin' created with the "
                            "password from ADMIN_INITIAL_PASSWORD.")
    finally:
        db_session.close()

def get_current_user():
    """Get current logged-in user"""
    user_id = session.get('user_id')
    if not user_id:
        return None
    
    db_session = get_db_session()
    try:
        user = db_session.query(User).filter_by(id=user_id, is_active=True).first()
        return user
    finally:
        db_session.close()

def check_auth(required_role=None):
    """Check if user is authenticated and has required role"""
    user = get_current_user()
    if not user:
        return False
    
    if required_role is None:
        return True
    
    if required_role == 'admin' and user.role != 'admin':
        return False
    
    if required_role == 'project_manager' and user.role not in ['admin', 'project_manager']:
        return False
    
    return True

def require_auth(required_role=None):
    """Decorator to require authentication"""
    def decorator(f):
        def decorated_function(*args, **kwargs):
            if not check_auth(required_role):
                from flask import flash, redirect, url_for
                flash('Authentication required', 'error')
                return redirect(url_for('login'))
            return f(*args, **kwargs)
        decorated_function.__name__ = f.__name__
        return decorated_function
    return decorator
