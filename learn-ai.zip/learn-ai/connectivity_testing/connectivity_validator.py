#!/usr/bin/env python3
"""Enterprise connectivity validation framework.

Validates every configured connection and reports the outcome. Intended to be
run after infrastructure change: server patching, operating system upgrades,
SSH algorithm or cipher changes, OpenSSL updates, certificate renewal,
firewall changes, authentication changes and migrations.

Usage::

    python connectivity_validator.py --config config/production_connectivity.json

Exit codes, which are a contract with enterprise schedulers::

    0    all enabled interfaces passed
    1    one or more interfaces failed
    2    configuration error; nothing was validated
    99   unexpected application error

This module is a launcher. The orchestration lives in :mod:`core.engine` and
the command line handling in :mod:`core.cli`, so that both the documented
``python connectivity_validator.py`` invocation and the
``connectivity-validator`` console script installed by ``pip`` execute exactly
the same code.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Allow execution from any working directory. A scheduler routinely starts a
# job from a directory unrelated to the deployment, and the documented
# invocation must work regardless.
_PROJECT_ROOT = Path(__file__).resolve().parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from core.cli import main  # noqa: E402 - import follows sys.path setup

if __name__ == "__main__":
    sys.exit(main())
