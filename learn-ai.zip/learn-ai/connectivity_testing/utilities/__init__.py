"""Shared, dependency-light helper utilities.

    masking      -- redaction of secrets for safe logging and reporting
    platform_info -- host, operating system and interpreter fingerprinting
    timing       -- monotonic stopwatch helpers for latency measurement
    validators   -- reusable input validators for the configuration wizard
    fs           -- cross-platform filesystem helpers and permission hardening
    ssh_discovery -- discovery of local SSH private keys and client config

Modules in this package must not import from ``connectors`` or ``core.engine``
so they remain safe to use from any layer, including the wizard.
"""

from __future__ import annotations

__all__: list[str] = []
