"""Discovery of local SSH private keys and OpenSSH client configuration.

When an SFTP, SCP or SSH interface is configured with neither a password nor
an explicit private key, the framework falls back to the same material the
system ``ssh`` client would use. That is what makes the validation result
meaningful: it exercises the credential path the actual batch jobs use.

Search order, highest confidence first:

1. ``~/.ssh/config`` -- an ``IdentityFile`` matching the target host is the
   strongest signal, because an operator stated it explicitly. Host patterns,
   ``HostName``, ``User`` and ``Port`` overrides are honoured.
2. ``~/.ssh/id_ed25519``, ``~/.ssh/id_ecdsa``, ``~/.ssh/id_rsa`` -- the
   conventional default identities, preferred in modern-algorithm order. This
   ordering matters after an SSH algorithm update, where an RSA/SHA-1 key may
   have been retired while an Ed25519 key still works.

The module parses ``~/.ssh/config`` itself rather than depending on paramiko,
so the wizard can offer discovery on a host where paramiko is not installed.
Key *files* are never read beyond their PEM header, and no key material is
returned, logged or stored: only paths and metadata.
"""

from __future__ import annotations

import fnmatch
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Final

__all__ = [
    "DEFAULT_KEY_FILENAMES",
    "DiscoveredKey",
    "IdentityFileEntry",
    "KeySource",
    "SshConfigHostSettings",
    "discover_ssh_keys",
    "parse_ssh_config",
    "ssh_directory",
]

#: Conventional identity filenames, in preferred order. Ed25519 first: it is
#: the algorithm most likely to survive a hardening change, and DSA is omitted
#: entirely because current OpenSSH releases reject it.
DEFAULT_KEY_FILENAMES: Final[tuple[str, ...]] = (
    "id_ed25519",
    "id_ecdsa",
    "id_rsa",
)

#: PEM header fragment marking a passphrase-protected key in the legacy format.
_LEGACY_ENCRYPTED_MARKER: Final[str] = "ENCRYPTED"

#: Number of bytes of the key file inspected. Enough for the PEM armour and
#: the OpenSSH cipher name, far short of the key material itself.
_HEADER_INSPECTION_BYTES: Final[int] = 256

_KEY_TYPE_BY_FILENAME: Final[dict[str, str]] = {
    "id_ed25519": "Ed25519",
    "id_ecdsa": "ECDSA",
    "id_rsa": "RSA",
    "id_dsa": "DSA",
}


class KeySource(StrEnum):
    """Where a discovered key came from, recorded in the validation result."""

    SSH_CONFIG = "ssh_config"
    """Named by an IdentityFile entry in ~/.ssh/config for this host."""

    DEFAULT_LOCATION = "default_location"
    """Found at a conventional ~/.ssh/id_* path."""

    EXPLICIT = "explicit"
    """Supplied directly in the interface configuration; not discovered."""


@dataclass(frozen=True, slots=True)
class DiscoveredKey:
    """A private key candidate found on the local host.

    No key material is held: ``path`` is the only reference, and it is what
    gets handed to paramiko at connect time.
    """

    path: Path
    key_type: str
    source: KeySource
    is_passphrase_protected: bool
    matched_host_pattern: str | None = None
    """The ~/.ssh/config Host pattern that selected this key, when applicable."""

    def to_dict(self) -> dict[str, str | bool | None]:
        """Return a JSON-serialisable representation for reports and config."""
        return {
            "path": str(self.path),
            "key_type": self.key_type,
            "source": self.source.value,
            "is_passphrase_protected": self.is_passphrase_protected,
            "matched_host_pattern": self.matched_host_pattern,
        }


@dataclass(frozen=True, slots=True)
class IdentityFileEntry:
    """An ``IdentityFile`` path together with the ``Host`` block that named it.

    The pattern is retained per entry rather than per host because a single
    lookup routinely matches several blocks: a specific ``Host server01`` and a
    catch-all ``Host *``. Reporting that a key came from ``*`` when it did is
    the difference between a report an operator can act on and one that sends
    them looking for a host-specific entry that does not exist.
    """

    path: Path
    host_pattern: str


@dataclass(frozen=True, slots=True)
class SshConfigHostSettings:
    """Effective ``~/.ssh/config`` settings for one target host."""

    hostname: str | None = None
    user: str | None = None
    port: int | None = None
    identity_files: tuple[IdentityFileEntry, ...] = ()
    matched_patterns: tuple[str, ...] = ()

    @property
    def identity_paths(self) -> tuple[Path, ...]:
        """Return just the identity file paths, in configuration order."""
        return tuple(entry.path for entry in self.identity_files)


def ssh_directory(home: Path | None = None) -> Path:
    """Return the ``.ssh`` directory for the current or supplied home."""
    base = home if home is not None else Path.home()
    return base / ".ssh"


def _expand(path_text: str, home: Path) -> Path:
    """Expand ``~`` and OpenSSH's ``%d`` home token against ``home``."""
    text = path_text.strip().strip('"')
    text = text.replace("%d", str(home))
    if text.startswith("~"):
        return Path(text.replace("~", str(home), 1))
    candidate = Path(text)
    return candidate if candidate.is_absolute() else home / ".ssh" / candidate


def _classify_key_type(path: Path) -> str:
    """Infer the key algorithm from the filename, defaulting to ``Unknown``."""
    return _KEY_TYPE_BY_FILENAME.get(path.name, "Unknown")


def _is_passphrase_protected(path: Path) -> bool:
    """Report whether a key file appears to be encrypted at rest.

    Only the PEM armour is inspected. Legacy PEM keys advertise
    ``Proc-Type: 4,ENCRYPTED``; modern OpenSSH keys name a cipher other than
    ``none`` shortly after the header. A best-effort answer is sufficient: it
    only decides whether the wizard prompts for a passphrase.
    """
    try:
        with path.open("rb") as handle:
            header = handle.read(_HEADER_INSPECTION_BYTES)
    except OSError:
        return False

    text = header.decode("ascii", errors="ignore")
    if _LEGACY_ENCRYPTED_MARKER in text:
        return True
    if "OPENSSH PRIVATE KEY" in text:
        # The binary blob names the KDF cipher; "none" means unencrypted.
        return b"none" not in header
    return False


def parse_ssh_config(
    host: str,
    *,
    config_path: Path | None = None,
    home: Path | None = None,
) -> SshConfigHostSettings:
    """Return the effective ``~/.ssh/config`` settings for ``host``.

    Implements the subset of OpenSSH semantics that matters here: ``Host``
    pattern matching including wildcards and ``!`` negation, first-value-wins
    precedence, and the ``HostName``, ``User``, ``Port`` and ``IdentityFile``
    keywords. ``Include`` directives and ``Match`` blocks are not followed; a
    configuration relying on those should name the key explicitly in the
    wizard.

    A missing or unreadable config file yields empty settings rather than an
    error: absence of an SSH client config is the normal case on a server.
    """
    resolved_home = home if home is not None else Path.home()
    path = config_path if config_path is not None else ssh_directory(resolved_home) / "config"

    try:
        raw_lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return SshConfigHostSettings()

    hostname: str | None = None
    user: str | None = None
    port: int | None = None
    identity_files: list[IdentityFileEntry] = []
    matched_patterns: list[str] = []
    seen_identity_paths: set[Path] = set()

    section_applies = False
    current_pattern: str | None = None

    for raw_line in raw_lines:
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue

        # OpenSSH accepts both "Key value" and "Key=value".
        if "=" in line and not line.split(None, 1)[0].endswith("="):
            keyword, _, value = line.partition("=")
            keyword, value = keyword.strip(), value.strip()
        else:
            parts = line.split(None, 1)
            keyword, value = parts[0], (parts[1].strip() if len(parts) > 1 else "")

        keyword_lower = keyword.lower()

        if keyword_lower == "host":
            patterns = value.split()
            section_applies = _patterns_match(host, patterns)
            current_pattern = next(
                (p for p in patterns if not p.startswith("!") and fnmatch.fnmatch(host, p)),
                None,
            )
            if section_applies and current_pattern:
                matched_patterns.append(current_pattern)
            continue

        if keyword_lower == "match":
            # Match blocks are not evaluated; stop applying the previous Host.
            section_applies = False
            continue

        if not section_applies or not value:
            continue

        # OpenSSH honours the first occurrence of each keyword.
        if keyword_lower == "hostname" and hostname is None:
            hostname = value
        elif keyword_lower == "user" and user is None:
            user = value
        elif keyword_lower == "port" and port is None:
            try:
                port = int(value)
            except ValueError:
                port = None
        elif keyword_lower == "identityfile":
            candidate = _expand(value, resolved_home)
            if candidate not in seen_identity_paths:
                seen_identity_paths.add(candidate)
                identity_files.append(
                    IdentityFileEntry(path=candidate, host_pattern=current_pattern or "*")
                )

    return SshConfigHostSettings(
        hostname=hostname,
        user=user,
        port=port,
        identity_files=tuple(identity_files),
        matched_patterns=tuple(matched_patterns),
    )


def _patterns_match(host: str, patterns: list[str]) -> bool:
    """Apply OpenSSH ``Host`` pattern matching, honouring ``!`` negation."""
    matched = False
    for pattern in patterns:
        if pattern.startswith("!"):
            if fnmatch.fnmatch(host, pattern[1:]):
                return False
        elif fnmatch.fnmatch(host, pattern):
            matched = True
    return matched


def discover_ssh_keys(
    host: str | None = None,
    *,
    home: Path | None = None,
    config_path: Path | None = None,
) -> list[DiscoveredKey]:
    """Discover usable private keys for ``host`` on the local machine.

    Args:
        host: Target host. When supplied, ``~/.ssh/config`` is consulted for a
            host-specific ``IdentityFile``. When ``None``, only the default
            identity locations are scanned.
        home: Override the home directory. Injected by the test suite so that
            discovery is exercised against a fixture tree rather than the
            developer's real ``~/.ssh``.
        config_path: Override the client configuration path.

    Returns:
        Candidate keys ordered by confidence: ``ssh_config`` matches first,
        then default identities in modern-algorithm order. Non-existent and
        unreadable paths are omitted; duplicates are collapsed.
    """
    resolved_home = home if home is not None else Path.home()
    discovered: list[DiscoveredKey] = []
    seen: set[Path] = set()

    if host:
        settings = parse_ssh_config(host, config_path=config_path, home=resolved_home)
        for entry in settings.identity_files:
            if entry.path in seen or not entry.path.is_file():
                continue
            seen.add(entry.path)
            discovered.append(
                DiscoveredKey(
                    path=entry.path,
                    key_type=_classify_key_type(entry.path),
                    source=KeySource.SSH_CONFIG,
                    is_passphrase_protected=_is_passphrase_protected(entry.path),
                    matched_host_pattern=entry.host_pattern,
                )
            )

    ssh_dir = ssh_directory(resolved_home)
    for filename in DEFAULT_KEY_FILENAMES:
        candidate = ssh_dir / filename
        if candidate in seen or not candidate.is_file():
            continue
        seen.add(candidate)
        discovered.append(
            DiscoveredKey(
                path=candidate,
                key_type=_classify_key_type(candidate),
                source=KeySource.DEFAULT_LOCATION,
                is_passphrase_protected=_is_passphrase_protected(candidate),
            )
        )

    return discovered
