"""Cross-platform filesystem helpers.

Everything here is built on :mod:`pathlib` and :mod:`os` so that the same code
runs unmodified on AIX, Linux and Windows. No shell command is ever spawned.

Two behaviours are worth knowing about:

* :func:`atomic_write_text` writes through a temporary file in the destination
  directory and then calls :func:`os.replace`. A scheduler that kills the job
  mid-write therefore leaves the previous file intact rather than a truncated
  configuration.
* :func:`harden_permissions` restricts a file to its owner. On POSIX this is
  ``chmod 0600``. On Windows the POSIX mode bits are largely advisory, so the
  function reports whether hardening was actually effective and the caller
  warns rather than silently assuming the file is protected.
"""

from __future__ import annotations

import os
import stat
import tempfile
import time
from collections.abc import Iterator
from contextlib import suppress
from pathlib import Path

from core.constants import SECURE_DIRECTORY_MODE, SECURE_FILE_MODE
from utilities.platform_info import is_windows

__all__ = [
    "atomic_write_bytes",
    "atomic_write_text",
    "ensure_directory",
    "file_age_days",
    "harden_permissions",
    "human_readable_size",
    "iter_files",
    "permissions_are_world_readable",
    "resolve_under",
    "safe_filename",
]

#: Characters that are invalid in a Windows filename and awkward everywhere.
_UNSAFE_FILENAME_CHARACTERS = '<>:"/\\|?*'

_SIZE_UNITS = ("B", "KB", "MB", "GB", "TB")


def ensure_directory(path: Path, *, secure: bool = False) -> Path:
    """Create ``path`` and any missing parents, returning the resolved path.

    Args:
        path: Directory to create. Existing directories are accepted.
        secure: When ``True`` the directory is restricted to its owner
            (``0700`` on POSIX). Used for directories holding key material.

    Raises:
        OSError: if the directory cannot be created.
    """
    path.mkdir(parents=True, exist_ok=True)
    if secure and not is_windows():
        # Best effort: NFS mounts and some AIX filesystems refuse the change.
        # Failing to tighten permissions must not stop the run.
        with suppress(OSError):
            path.chmod(SECURE_DIRECTORY_MODE)
    return path


def harden_permissions(path: Path) -> bool:
    """Restrict ``path`` to its owner and report whether that was effective.

    Returns:
        ``True`` when owner-only permissions were applied and verified.
        ``False`` on Windows, where POSIX mode bits do not express an ACL, and
        on any filesystem that silently ignores the change. Callers should log
        a warning on ``False`` rather than assume the file is protected.
    """
    if is_windows():
        # os.chmod on Windows only toggles the read-only attribute; it does not
        # restrict other principals. Report honestly instead of pretending.
        return False
    try:
        path.chmod(SECURE_FILE_MODE)
    except OSError:  # pragma: no cover - depends on filesystem
        return False
    return not permissions_are_world_readable(path)


def permissions_are_world_readable(path: Path) -> bool:
    """Return ``True`` when group or other principals can read ``path``.

    Always ``False`` on Windows, where the POSIX bits carry no meaning and a
    positive answer would be misleading.
    """
    if is_windows():
        return False
    try:
        mode = path.stat().st_mode
    except OSError:  # pragma: no cover - race with deletion
        return False
    return bool(mode & (stat.S_IRGRP | stat.S_IROTH | stat.S_IWGRP | stat.S_IWOTH))


def atomic_write_bytes(path: Path, data: bytes, *, secure: bool = False) -> Path:
    """Write ``data`` to ``path`` atomically.

    The temporary file is created in the destination directory so that the
    final :func:`os.replace` is a same-filesystem rename, which is atomic on
    every supported platform.

    Args:
        path: Destination file.
        data: Payload to write.
        secure: Apply owner-only permissions to the file before it is moved
            into place, so the secret is never briefly world readable.

    Returns:
        The destination path.
    """
    ensure_directory(path.parent)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent)
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        if secure:
            harden_permissions(temporary_path)
        temporary_path.replace(path)
    except BaseException:
        temporary_path.unlink(missing_ok=True)
        raise
    return path


def atomic_write_text(
    path: Path, text: str, *, encoding: str = "utf-8", secure: bool = False
) -> Path:
    """Write ``text`` to ``path`` atomically using ``encoding``.

    UTF-8 is used everywhere by default. Relying on the platform default would
    produce cp1252 on Windows and a mojibake report the moment a hostname or an
    error message carries a non-ASCII byte.
    """
    return atomic_write_bytes(path, text.encode(encoding), secure=secure)


def iter_files(directory: Path, *, pattern: str = "*") -> Iterator[Path]:
    """Yield regular files directly inside ``directory``.

    Sub-directories are deliberately not traversed: the report cleanup routine
    uses this helper and must never descend into a directory an operator
    created inside the reports folder.
    """
    if not directory.is_dir():
        return
    for entry in sorted(directory.glob(pattern)):
        if entry.is_file():
            yield entry


def file_age_days(path: Path, *, now_timestamp: float | None = None) -> float:
    """Return the age of ``path`` in days, based on its modification time.

    Modification time is used rather than creation time because ``st_ctime``
    means "inode change time" on POSIX and "creation time" on Windows; only
    ``st_mtime`` carries the same meaning on all supported platforms.

    Args:
        path: File to inspect.
        now_timestamp: Reference epoch seconds. Injectable so that retention
            tests are deterministic instead of depending on the wall clock.

    Raises:
        OSError: if the file cannot be stat'ed.
    """
    reference = now_timestamp if now_timestamp is not None else time.time()
    age_seconds = reference - path.stat().st_mtime
    return max(0.0, age_seconds / 86400.0)


def safe_filename(name: str, *, replacement: str = "_", max_length: int = 120) -> str:
    """Return ``name`` reduced to characters valid on every supported platform.

    Path separators, Windows reserved characters and control characters are
    replaced. The result is truncated to ``max_length`` so that deeply nested
    deployment directories cannot breach the Windows path limit.
    """
    cleaned = []
    for character in name.strip():
        if character in _UNSAFE_FILENAME_CHARACTERS or ord(character) < 32:
            cleaned.append(replacement)
        else:
            cleaned.append(character)
    result = "".join(cleaned).strip(" .")
    result = result or "unnamed"
    return result[:max_length]


def resolve_under(base_directory: Path, candidate: Path | str) -> Path:
    """Resolve ``candidate`` relative to ``base_directory`` when it is relative.

    Absolute candidates are returned untouched. This keeps configured
    directories portable: a configuration written on a developer workstation
    with ``reports`` resolves correctly under the deployment root on the
    server without being edited.
    """
    candidate_path = Path(candidate)
    if candidate_path.is_absolute():
        return candidate_path
    return (base_directory / candidate_path).resolve()


def human_readable_size(size_bytes: int) -> str:
    """Render a byte count for reports and e-mail attachment summaries."""
    size = float(max(0, size_bytes))
    for unit in _SIZE_UNITS:
        if size < 1024.0 or unit == _SIZE_UNITS[-1]:
            precision = 0 if unit == "B" else 1
            return f"{size:.{precision}f} {unit}"
        size /= 1024.0
    return f"{size:.1f} {_SIZE_UNITS[-1]}"  # pragma: no cover - unreachable
