"""Latency measurement and duration formatting.

Two clocks are used deliberately and must not be interchanged:

* :func:`utc_now` uses the wall clock and produces the timezone-aware
  timestamps recorded as start and end time. Wall clock values are what an
  operator correlates against a change window.
* :class:`Stopwatch` uses :func:`time.monotonic`, which is immune to NTP
  steps and daylight saving transitions. Every reported duration and latency
  comes from the monotonic clock, so a clock correction during a run can never
  produce a negative or wildly inflated latency.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from types import TracebackType

__all__ = ["Stopwatch", "format_duration", "utc_now"]


def utc_now() -> datetime:
    """Return the current time as a timezone-aware UTC datetime."""
    return datetime.now(UTC)


@dataclass(slots=True)
class Stopwatch:
    """Context manager measuring elapsed time on the monotonic clock.

    Usage::

        with Stopwatch() as watch:
            client.connect(...)
        latency_ms = watch.elapsed_ms

    The stopwatch stops on exit whether the block completes or raises, so a
    failed connection still reports how long it took to fail. That number
    distinguishes an immediate connection refusal from a firewall drop that
    burned the whole timeout.
    """

    started_at: datetime = field(default_factory=utc_now)
    ended_at: datetime | None = None
    _start_monotonic: float = field(default_factory=time.monotonic, repr=False)
    _end_monotonic: float | None = field(default=None, repr=False)

    def __enter__(self) -> Stopwatch:
        self.started_at = utc_now()
        self._start_monotonic = time.monotonic()
        self.ended_at = None
        self._end_monotonic = None
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        self.stop()

    def stop(self) -> float:
        """Stop the stopwatch if running and return the elapsed seconds."""
        if self._end_monotonic is None:
            self._end_monotonic = time.monotonic()
            self.ended_at = utc_now()
        return self.elapsed_seconds

    @property
    def is_running(self) -> bool:
        """Return ``True`` while the stopwatch has not been stopped."""
        return self._end_monotonic is None

    @property
    def elapsed_seconds(self) -> float:
        """Return elapsed seconds; reads live while the stopwatch runs."""
        end = self._end_monotonic if self._end_monotonic is not None else time.monotonic()
        return max(0.0, end - self._start_monotonic)

    @property
    def elapsed_ms(self) -> float:
        """Return elapsed milliseconds rounded to three decimal places."""
        return round(self.elapsed_seconds * 1000.0, 3)

    def __str__(self) -> str:
        return format_duration(self.elapsed_seconds)


def format_duration(seconds: float) -> str:
    """Render a duration for human consumption.

    Sub-second durations are reported in milliseconds because most healthy
    connections complete there, and rendering them as ``0.00s`` would hide the
    difference between a 4 ms and a 400 ms handshake.

    Examples:
        >>> format_duration(0.0421)
        '42 ms'
        >>> format_duration(7.5)
        '7.50 s'
        >>> format_duration(195.0)
        '3 m 15 s'
    """
    if seconds < 0:
        seconds = 0.0
    if seconds < 1.0:
        return f"{seconds * 1000.0:.0f} ms"
    if seconds < 60.0:
        return f"{seconds:.2f} s"

    total_seconds = int(round(seconds))
    minutes, remaining_seconds = divmod(total_seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours} h {minutes} m {remaining_seconds} s"
    return f"{minutes} m {remaining_seconds} s"
