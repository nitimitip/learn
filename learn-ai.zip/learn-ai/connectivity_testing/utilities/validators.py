"""Reusable input validators shared by the wizard and the configuration models.

Each validator follows one convention: it returns the *normalised* value and
raises :class:`ValueError` with an operator-friendly message when the input is
unacceptable. Normalising inside the validator is what stops a trailing space
pasted into a hostname from becoming a 3 a.m. connection failure.

:func:`as_prompt_validator` adapts any of these into the callable shape the
``questionary`` library expects, so the wizard and the pydantic models enforce
exactly the same rules and can never drift apart.
"""

from __future__ import annotations

import ipaddress
import re
from collections.abc import Callable, Iterable
from pathlib import Path
from typing import Any, Final
from urllib.parse import urlparse

from core.constants import (
    MAX_DB_LINKS,
    MAX_RETRY_COUNT,
    MAX_TIMEOUT_SECONDS,
    MIN_TIMEOUT_SECONDS,
    SUPPORTED_HTTP_METHODS,
)

__all__ = [
    "as_prompt_validator",
    "validate_db_link_count",
    "validate_email_address",
    "validate_email_list",
    "validate_existing_file",
    "validate_host",
    "validate_http_method",
    "validate_http_status_code",
    "validate_interface_name",
    "validate_port",
    "validate_retry_count",
    "validate_timeout",
    "validate_url",
]

#: Interface names become worksheet fragments, log fields and report anchors,
#: so they are restricted to a portable character set.
_INTERFACE_NAME_PATTERN: Final[re.Pattern[str]] = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._-]{0,63}$")

#: Pragmatic RFC 5322 subset: deliberately stricter than the standard, which
#: permits addresses no enterprise mail relay would accept.
_EMAIL_PATTERN: Final[re.Pattern[str]] = re.compile(
    r"^[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?"
    r"(\.[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?)+$"
)

#: RFC 1123 host label rules, applied per dot-separated label.
_HOSTNAME_LABEL_PATTERN: Final[re.Pattern[str]] = re.compile(
    r"^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?$"
)

_MAX_HOSTNAME_LENGTH: Final[int] = 253
_MIN_PORT: Final[int] = 1
_MAX_PORT: Final[int] = 65535
_MIN_HTTP_STATUS: Final[int] = 100
_MAX_HTTP_STATUS: Final[int] = 599


def validate_interface_name(value: str) -> str:
    """Validate and normalise a unique interface name.

    Returns:
        The name with surrounding whitespace removed.

    Raises:
        ValueError: when the name is empty or contains characters that would
            be unsafe in a report anchor or an Excel worksheet reference.
    """
    name = (value or "").strip()
    if not name:
        raise ValueError("Interface name is required.")
    if not _INTERFACE_NAME_PATTERN.match(name):
        raise ValueError(
            "Interface name must start with a letter or digit and may contain "
            "only letters, digits, spaces, dots, underscores and hyphens "
            "(maximum 64 characters)."
        )
    return name


def validate_host(value: str) -> str:
    """Validate a hostname, FQDN, IPv4 or IPv6 literal.

    Returns:
        The host, lower-cased and stripped. IPv6 literals are returned without
        the surrounding brackets; connectors add them where the protocol needs
        them.

    Raises:
        ValueError: when the value is empty or is not a resolvable shape.
    """
    host = (value or "").strip()
    if not host:
        raise ValueError("Host is required.")

    if host.startswith("[") and host.endswith("]"):
        host = host[1:-1]

    try:
        return str(ipaddress.ip_address(host))
    except ValueError:
        pass  # Not an IP literal; fall through to hostname validation.

    if len(host) > _MAX_HOSTNAME_LENGTH:
        raise ValueError(f"Host name must not exceed {_MAX_HOSTNAME_LENGTH} characters.")

    candidate = host.rstrip(".")
    labels = candidate.split(".")
    if not all(_HOSTNAME_LABEL_PATTERN.match(label) for label in labels):
        raise ValueError(
            f"'{host}' is not a valid host name or IP address. Use a host name, "
            "a fully qualified domain name, or an IPv4/IPv6 address."
        )
    return candidate.lower()


def validate_port(value: Any) -> int:
    """Validate a TCP port number.

    Raises:
        ValueError: when the value is not an integer in 1-65535.
    """
    try:
        port = int(str(value).strip())
    except (TypeError, ValueError) as error:
        raise ValueError(f"Port must be a whole number, received '{value}'.") from error
    if not _MIN_PORT <= port <= _MAX_PORT:
        raise ValueError(f"Port must be between {_MIN_PORT} and {_MAX_PORT}, received {port}.")
    return port


def validate_timeout(value: Any) -> int:
    """Validate a timeout in seconds.

    The upper bound matters operationally: a validation job scheduled every
    fifteen minutes must not be able to hang for hours on one unreachable
    endpoint because someone typed an extra zero.
    """
    try:
        timeout = int(str(value).strip())
    except (TypeError, ValueError) as error:
        raise ValueError(
            f"Timeout must be a whole number of seconds, received '{value}'."
        ) from error
    if not MIN_TIMEOUT_SECONDS <= timeout <= MAX_TIMEOUT_SECONDS:
        raise ValueError(
            f"Timeout must be between {MIN_TIMEOUT_SECONDS} and "
            f"{MAX_TIMEOUT_SECONDS} seconds, received {timeout}."
        )
    return timeout


def validate_retry_count(value: Any) -> int:
    """Validate a retry count in 0-``MAX_RETRY_COUNT``."""
    try:
        retries = int(str(value).strip())
    except (TypeError, ValueError) as error:
        raise ValueError(f"Retry count must be a whole number, received '{value}'.") from error
    if not 0 <= retries <= MAX_RETRY_COUNT:
        raise ValueError(
            f"Retry count must be between 0 and {MAX_RETRY_COUNT}, received {retries}."
        )
    return retries


def validate_db_link_count(value: Any) -> int:
    """Validate the maximum number of Oracle database links to probe.

    Bounded to the same range as the interface model so that an answer typed
    into the wizard cannot build a configuration the loader would then reject.
    """
    try:
        count = int(str(value).strip())
    except (TypeError, ValueError) as error:
        raise ValueError(
            f"The database link limit must be a whole number, received '{value}'."
        ) from error
    if not 1 <= count <= MAX_DB_LINKS:
        raise ValueError(
            f"The database link limit must be between 1 and {MAX_DB_LINKS}, "
            f"received {count}."
        )
    return count


def validate_email_address(value: str) -> str:
    """Validate a single e-mail address and return it stripped."""
    address = (value or "").strip()
    if not address:
        raise ValueError("E-mail address is required.")
    if not _EMAIL_PATTERN.match(address):
        raise ValueError(f"'{address}' is not a valid e-mail address.")
    return address


def validate_email_list(value: str | Iterable[str], *, allow_empty: bool = False) -> list[str]:
    """Validate a comma or semicolon separated list of e-mail addresses.

    Duplicates are removed while preserving the order in which the operator
    entered them, so a copy-paste of an overlapping distribution list does not
    produce duplicate deliveries.

    Args:
        value: Raw separated string, or an iterable of addresses.
        allow_empty: When ``True`` an empty input yields an empty list rather
            than raising. Used for optional CC and BCC fields.
    """
    if isinstance(value, str):
        raw_parts: list[str] = re.split(r"[,;]", value)
    else:
        raw_parts = list(value)

    addresses: list[str] = []
    seen: set[str] = set()
    for part in raw_parts:
        candidate = part.strip()
        if not candidate:
            continue
        address = validate_email_address(candidate)
        if address.lower() not in seen:
            seen.add(address.lower())
            addresses.append(address)

    if not addresses and not allow_empty:
        raise ValueError("At least one e-mail address is required.")
    return addresses


def validate_url(value: str, *, require_https: bool = False) -> str:
    """Validate an absolute HTTP or HTTPS URL.

    Args:
        value: Candidate URL.
        require_https: Reject plain HTTP. Left ``False`` by default because
            internal endpoints are legitimately validated over HTTP; the
            wizard warns instead of refusing.

    Raises:
        ValueError: when the URL is relative, malformed or uses another scheme.
    """
    url = (value or "").strip()
    if not url:
        raise ValueError("URL is required.")

    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError(f"URL must start with http:// or https://, received '{url}'.")
    if not parsed.netloc:
        raise ValueError(f"URL is missing a host component: '{url}'.")
    if require_https and parsed.scheme != "https":
        raise ValueError(f"URL must use https://, received '{url}'.")
    return url


def validate_http_method(value: str) -> str:
    """Validate an HTTP method and return it upper-cased."""
    method = (value or "").strip().upper()
    if method not in SUPPORTED_HTTP_METHODS:
        supported = ", ".join(SUPPORTED_HTTP_METHODS)
        raise ValueError(f"HTTP method must be one of: {supported}. Received '{value}'.")
    return method


def validate_http_status_code(value: Any) -> int:
    """Validate an expected HTTP status code in 100-599."""
    try:
        status = int(str(value).strip())
    except (TypeError, ValueError) as error:
        raise ValueError(f"HTTP status code must be a whole number, received '{value}'.") from error
    if not _MIN_HTTP_STATUS <= status <= _MAX_HTTP_STATUS:
        raise ValueError(
            f"HTTP status code must be between {_MIN_HTTP_STATUS} and "
            f"{_MAX_HTTP_STATUS}, received {status}."
        )
    return status


def validate_existing_file(value: str, *, description: str = "File") -> str:
    """Validate that a path exists and is a readable regular file.

    The user-supplied ``~`` is expanded so that ``~/.ssh/id_rsa`` behaves the
    same way it does in an SSH client.

    Returns:
        The expanded absolute path as a string.
    """
    raw = (value or "").strip()
    if not raw:
        raise ValueError(f"{description} path is required.")

    path = Path(raw).expanduser()
    if not path.exists():
        raise ValueError(f"{description} does not exist: {path}")
    if not path.is_file():
        raise ValueError(f"{description} is not a regular file: {path}")
    try:
        with path.open("rb") as handle:
            handle.read(1)
    except OSError as error:
        raise ValueError(f"{description} cannot be read: {path} ({error.strerror})") from error
    return str(path)


def as_prompt_validator(
    validator: Callable[[str], Any], *, allow_empty: bool = False
) -> Callable[[str], bool | str]:
    """Adapt a validator into the callable ``questionary`` expects.

    ``questionary`` treats a returned ``True`` as valid input and a returned
    string as the error message to display inline. Wrapping the shared
    validators keeps the wizard's rules identical to the model's rules.

    Args:
        validator: Any validator from this module.
        allow_empty: When ``True`` blank input is accepted, which is how
            optional fields fall back to their default.
    """

    def _validate(value: str) -> bool | str:
        if allow_empty and not (value or "").strip():
            return True
        try:
            validator(value)
        except ValueError as error:
            return str(error)
        return True

    return _validate
