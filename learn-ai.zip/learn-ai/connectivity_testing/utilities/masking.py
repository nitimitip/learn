"""Redaction of secrets for logs, reports and console output.

The framework applies defence in depth so that a credential never reaches a
log file, a report or an e-mail body:

1. **Structural redaction** -- :func:`redact_mapping` walks a configuration
   dictionary and masks any value whose key looks like a secret. This is what
   protects report payloads and debug dumps of configuration.
2. **Pattern redaction** -- :func:`redact_text` masks credentials embedded in
   free text such as connection strings and URLs, which structural redaction
   cannot see.
3. **Value redaction** -- every plaintext secret the framework decrypts is
   registered with :data:`secret_registry`, and
   :class:`SecretRedactingFilter` removes those exact values from every log
   record. This is the backstop that catches a driver exception message that
   happens to echo the password back.

All three are cheap; the registry lookup is a substring scan over a small set
of values and only runs on records that are actually emitted.
"""

from __future__ import annotations

import re
import threading
from collections.abc import Iterable, Mapping, Sequence
from logging import Filter, LogRecord
from typing import Any, Final

from core.constants import MASK_PLACEHOLDER

__all__ = [
    "SECRET_KEY_HINTS",
    "SecretRedactingFilter",
    "SecretRegistry",
    "mask_secret",
    "mask_url_credentials",
    "redact_mapping",
    "redact_text",
    "secret_registry",
]


#: Substrings that mark a configuration key as holding a secret. Matching is
#: case-insensitive and substring based, so ``smtp_password``, ``SecretKey``
#: and ``api_token`` are all caught.
SECRET_KEY_HINTS: Final[frozenset[str]] = frozenset(
    {
        "password",
        "passwd",
        "pwd",
        "passphrase",
        "secret",
        "token",
        "api_key",
        "apikey",
        "access_key",
        "secret_key",
        "client_secret",
        "connection_string",
        "conn_str",
        "credential",
        "authorization",
        "auth_header",
        "private_key_data",
        "sas_token",
        "session_token",
    }
)

#: Header names whose values must never be logged, regardless of key shape.
SENSITIVE_HEADER_NAMES: Final[frozenset[str]] = frozenset(
    {"authorization", "proxy-authorization", "x-api-key", "api-key", "cookie", "set-cookie"}
)

#: Minimum length before a registered secret is worth scanning for. Very short
#: values would match innocuous substrings and turn logs into noise.
MIN_REGISTERED_SECRET_LENGTH: Final[int] = 4


# ---------------------------------------------------------------------------
# Pattern based redaction
# ---------------------------------------------------------------------------

_URL_CREDENTIALS_PATTERN: Final[re.Pattern[str]] = re.compile(
    r"(?P<scheme>[a-zA-Z][a-zA-Z0-9+.\-]*://)(?P<user>[^:/@\s]+):(?P<password>[^@\s]+)@"
)

#: Credential-bearing HTTP headers. The value runs to the end of the header,
#: so the whole of it is masked rather than only its first token. Applied
#: before the generic rule below, which would otherwise match ``authorization``
#: and consume just the scheme word, leaving the token itself exposed.
_AUTH_HEADER_PATTERN: Final[re.Pattern[str]] = re.compile(
    r"(?i)\b(?P<key>authorization|proxy-authorization|x-api-key|api-key|"
    r"set-cookie|cookie)\b(?P<separator>\s*[=:]\s*)(?P<value>[^\r\n;]+)"
)

#: HTTP authentication values appearing without their header name, such as a
#: bare ``Bearer eyJhbGciOi...`` inside a driver exception message.
_BEARER_PATTERN: Final[re.Pattern[str]] = re.compile(
    r"(?i)\b(?P<scheme>bearer|basic|token)\s+(?P<value>[A-Za-z0-9\-._~+/=]{8,})"
)

#: ``key=value`` and ``key: value`` pairs inside connection strings and free
#: text, for example ``AccountKey=abc123;`` or ``Password: hunter2``.
_KEYWORD_ASSIGNMENT_PATTERN: Final[re.Pattern[str]] = re.compile(
    r"(?i)\b(?P<key>password|passwd|pwd|passphrase|accountkey|sharedaccesskey|"
    r"secret|secretkey|client_secret|clientsecret|token|sas|apikey|api_key|"
    r"access_key|accesskey)\b"
    r"(?P<separator>\s*[=:]\s*)"
    r"(?P<value>\"[^\"]*\"|'[^']*'|[^;,&\s\"']+)"
)


def mask_secret(value: Any, *, reveal_length: bool = False) -> str:
    """Return a masked placeholder for ``value``.

    Args:
        value: The secret. ``None`` and empty values are reported as absent so
            that a report can distinguish "not configured" from "configured".
        reveal_length: When ``True`` the placeholder records the length of the
            original value, which helps diagnose trailing whitespace or a
            truncated paste without disclosing the value itself.

    Returns:
        A constant placeholder, never any portion of the original secret.
    """
    if value is None:
        return ""
    text = str(value)
    if not text:
        return ""
    if reveal_length:
        return f"{MASK_PLACEHOLDER} ({len(text)} chars)"
    return MASK_PLACEHOLDER


def is_secret_key(key: str) -> bool:
    """Return ``True`` when a configuration key name denotes a secret."""
    lowered = key.lower()
    if lowered in SENSITIVE_HEADER_NAMES:
        return True
    return any(hint in lowered for hint in SECRET_KEY_HINTS)


def mask_url_credentials(url: str) -> str:
    """Mask the ``user:password@`` component of a URL, keeping it readable."""
    return _URL_CREDENTIALS_PATTERN.sub(
        lambda match: f"{match.group('scheme')}{match.group('user')}:{MASK_PLACEHOLDER}@",
        url,
    )


def redact_text(text: str) -> str:
    """Mask credentials embedded in free text.

    Handles URL userinfo, ``key=value`` secrets typical of database and cloud
    connection strings, and HTTP authorization values. Applied to log messages
    and to any driver error text before it is persisted.
    """
    if not text:
        return text

    redacted = mask_url_credentials(text)

    # Order matters. The whole-header rule runs first so that a header value is
    # masked in full; the generic key=value rule would otherwise match the
    # header name and mask only the scheme word, leaving the credential behind.
    redacted = _AUTH_HEADER_PATTERN.sub(
        lambda match: f"{match.group('key')}{match.group('separator')}{MASK_PLACEHOLDER}",
        redacted,
    )
    redacted = _BEARER_PATTERN.sub(
        lambda match: f"{match.group('scheme')} {MASK_PLACEHOLDER}",
        redacted,
    )
    return _KEYWORD_ASSIGNMENT_PATTERN.sub(
        lambda match: f"{match.group('key')}{match.group('separator')}{MASK_PLACEHOLDER}",
        redacted,
    )


def redact_mapping(data: Any, *, reveal_length: bool = False) -> Any:
    """Return a deep copy of ``data`` with every secret-shaped value masked.

    Walks mappings and sequences recursively. String values are additionally
    passed through :func:`redact_text` so that a non-secret key holding a
    connection string is still cleaned.

    Args:
        data: Any JSON-like structure. Non-container values are returned as is.
        reveal_length: Forwarded to :func:`mask_secret`.

    Returns:
        A structure of the same shape that is safe to log or serialise.
    """
    if isinstance(data, Mapping):
        result: dict[str, Any] = {}
        for raw_key, value in data.items():
            key = str(raw_key)
            if is_secret_key(key):
                result[key] = mask_secret(value, reveal_length=reveal_length)
            else:
                result[key] = redact_mapping(value, reveal_length=reveal_length)
        return result
    if isinstance(data, (list, tuple, set)):
        redacted_items = [redact_mapping(item, reveal_length=reveal_length) for item in data]
        if isinstance(data, tuple):
            return tuple(redacted_items)
        return type(data)(redacted_items)
    if isinstance(data, str):
        return redact_text(data)
    return data


# ---------------------------------------------------------------------------
# Value based redaction
# ---------------------------------------------------------------------------


class SecretRegistry:
    """Thread-safe set of plaintext secrets to scrub from emitted text.

    Every secret the framework decrypts is registered here. The registry never
    exposes its contents; the only readable operation is
    :meth:`scrub`, which replaces occurrences with the mask placeholder.
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._secrets: set[str] = set()

    def register(self, value: str | None) -> None:
        """Add ``value`` to the set of strings scrubbed from output."""
        if not value or len(value) < MIN_REGISTERED_SECRET_LENGTH:
            return
        with self._lock:
            self._secrets.add(value)

    def register_all(self, values: Iterable[str | None]) -> None:
        """Register every value in ``values``."""
        for value in values:
            self.register(value)

    def clear(self) -> None:
        """Forget every registered secret. Used between tests and runs."""
        with self._lock:
            self._secrets.clear()

    def __len__(self) -> int:
        with self._lock:
            return len(self._secrets)

    def scrub(self, text: str) -> str:
        """Replace every registered secret found in ``text`` with the mask."""
        if not text:
            return text
        with self._lock:
            # Longest first so that a secret which contains another secret as a
            # substring is masked as a whole rather than partially.
            candidates = sorted(self._secrets, key=len, reverse=True)
        for secret in candidates:
            if secret in text:
                text = text.replace(secret, MASK_PLACEHOLDER)
        return text


#: Process-wide registry. The engine populates it as secrets are decrypted.
secret_registry: Final[SecretRegistry] = SecretRegistry()


class SecretRedactingFilter(Filter):
    """Logging filter that removes secrets from every record it passes.

    Attached to all handlers by :mod:`core.logging_setup`. It rewrites the
    record's message, its formatting arguments and any attached exception text,
    which means a connector cannot leak a credential by accident even when a
    driver embeds it in an exception message.
    """

    def __init__(self, registry: SecretRegistry | None = None, name: str = "") -> None:
        super().__init__(name)
        self._registry = registry if registry is not None else secret_registry

    def _clean(self, text: str) -> str:
        return self._registry.scrub(redact_text(text))

    def _clean_value(self, value: Any) -> Any:
        if isinstance(value, str):
            return self._clean(value)
        if isinstance(value, Mapping):
            return {key: self._clean_value(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            cleaned = [self._clean_value(item) for item in value]
            return cleaned if isinstance(value, list) else tuple(cleaned)
        return value

    def filter(self, record: LogRecord) -> bool:
        """Redact ``record`` in place and always allow it through."""
        if isinstance(record.msg, str):
            record.msg = self._clean(record.msg)

        if record.args:
            if isinstance(record.args, Mapping):
                record.args = {
                    key: self._clean_value(value) for key, value in record.args.items()
                }
            elif isinstance(record.args, Sequence):
                record.args = tuple(self._clean_value(value) for value in record.args)

        interface_name = getattr(record, "interface_name", None)
        if isinstance(interface_name, str):
            record.interface_name = self._clean(interface_name)

        return True
