"""Host, operating system and interpreter fingerprinting.

Every report records where it was produced. After a patching window the same
configuration is frequently validated from several jump hosts, and the first
question asked of a failure report is "which host produced this". The values
collected here answer that without any platform specific shell command: only
:mod:`platform`, :mod:`socket`, :mod:`os` and :mod:`sys` are used, all of
which behave consistently on AIX, Linux and Windows.
"""

from __future__ import annotations

import getpass
import os
import platform
import socket
import sys
from dataclasses import dataclass, field
from datetime import UTC, datetime
from functools import lru_cache
from pathlib import Path
from typing import Any

__all__ = ["PlatformInfo", "collect_platform_info", "is_aix", "is_windows"]

#: Hostname resolution can block on a misconfigured resolver. The lookup is
#: guarded and degrades to the short hostname rather than delaying a run.
_FQDN_TIMEOUT_SECONDS = 2.0


@dataclass(frozen=True, slots=True)
class PlatformInfo:
    """Immutable snapshot of the execution environment."""

    hostname: str
    fqdn: str
    ip_address: str
    operating_system: str
    os_release: str
    os_version: str
    platform_summary: str
    architecture: str
    processor: str
    python_version: str
    python_implementation: str
    python_executable: str
    username: str
    process_id: int
    working_directory: str
    collected_at_utc: datetime = field(default_factory=lambda: datetime.now(UTC))

    @property
    def is_windows(self) -> bool:
        """Return ``True`` when running on Microsoft Windows."""
        return self.operating_system.lower() == "windows"

    @property
    def is_aix(self) -> bool:
        """Return ``True`` when running on IBM AIX."""
        return self.operating_system.lower() == "aix"

    @property
    def is_linux(self) -> bool:
        """Return ``True`` when running on Linux."""
        return self.operating_system.lower() == "linux"

    @property
    def python_version_short(self) -> str:
        """Return the ``major.minor.micro`` interpreter version."""
        return self.python_version.split()[0]

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serialisable representation for reports."""
        return {
            "hostname": self.hostname,
            "fqdn": self.fqdn,
            "ip_address": self.ip_address,
            "operating_system": self.operating_system,
            "os_release": self.os_release,
            "os_version": self.os_version,
            "platform_summary": self.platform_summary,
            "architecture": self.architecture,
            "processor": self.processor,
            "python_version": self.python_version_short,
            "python_implementation": self.python_implementation,
            "python_executable": self.python_executable,
            "username": self.username,
            "process_id": self.process_id,
            "working_directory": self.working_directory,
            "collected_at_utc": self.collected_at_utc.isoformat(),
        }


def _safe_hostname() -> str:
    """Return the short hostname, degrading to ``unknown`` rather than raising."""
    try:
        return socket.gethostname() or "unknown"
    except OSError:  # pragma: no cover - depends on host resolver state
        return "unknown"


def _safe_fqdn(hostname: str) -> str:
    """Return the fully qualified name, degrading to ``hostname``."""
    previous_timeout = socket.getdefaulttimeout()
    try:
        socket.setdefaulttimeout(_FQDN_TIMEOUT_SECONDS)
        return socket.getfqdn(hostname) or hostname
    except OSError:  # pragma: no cover - depends on host resolver state
        return hostname
    finally:
        socket.setdefaulttimeout(previous_timeout)


def _safe_ip_address(hostname: str) -> str:
    """Return the primary IP address, degrading to ``unknown``."""
    try:
        return socket.gethostbyname(hostname)
    except OSError:  # pragma: no cover - depends on host resolver state
        return "unknown"


def _safe_username() -> str:
    """Return the effective user name without raising on service accounts.

    ``getpass.getuser`` reads the environment first and can raise when a
    scheduler runs the job with no ``USERNAME``/``LOGNAME`` set, which is the
    normal case for a Windows service account.
    """
    try:
        return getpass.getuser()
    except (OSError, KeyError, ImportError):  # pragma: no cover - service accounts
        return os.environ.get("USERNAME") or os.environ.get("LOGNAME") or "unknown"


@lru_cache(maxsize=1)
def collect_platform_info() -> PlatformInfo:
    """Collect and cache the execution environment fingerprint.

    The result is cached for the lifetime of the process: the values cannot
    change during a run, and hostname resolution is the slowest thing the
    framework does before it opens its first connection.
    """
    hostname = _safe_hostname()
    return PlatformInfo(
        hostname=hostname,
        fqdn=_safe_fqdn(hostname),
        ip_address=_safe_ip_address(hostname),
        operating_system=platform.system() or "unknown",
        os_release=platform.release(),
        os_version=platform.version(),
        platform_summary=platform.platform(),
        architecture=platform.machine() or "unknown",
        processor=platform.processor() or "unknown",
        python_version=sys.version.replace("\n", " "),
        python_implementation=platform.python_implementation(),
        python_executable=sys.executable,
        username=_safe_username(),
        process_id=os.getpid(),
        working_directory=str(Path.cwd()),
    )


def is_windows() -> bool:
    """Return ``True`` when running on Microsoft Windows."""
    return os.name == "nt"


def is_aix() -> bool:
    """Return ``True`` when running on IBM AIX."""
    return sys.platform.startswith("aix")
