"""Per connectivity-type configuration models.

Every interface in the configuration file is parsed into exactly one of these
models through a pydantic discriminated union keyed on ``type``. Three
consequences matter in production:

* A typo in a field name is rejected at load time (``extra="forbid"``) rather
  than being silently ignored and producing a validation run that tests
  something other than what the operator intended.
* Cross-field rules are enforced centrally. An Oracle interface without either
  a service name or a SID cannot reach a connector.
* Each model declares ``SECRET_FIELDS``, so the wizard knows what to encrypt
  and the loader knows what to audit, without either of them carrying a
  hard-coded list that drifts as connectors are added.

Secrets are held here in their stored envelope form (``ENC(...)`` /
``ENV(...)``), never as plaintext. Connectors resolve them through
:class:`core.encryption.SecretCipher` at connect time.
"""

from __future__ import annotations

from enum import StrEnum, unique
from typing import Annotated, Any, ClassVar, Literal
from urllib.parse import urlparse

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from core.constants import (
    DEFAULT_DB_LINK_BUDGET_SECONDS,
    DEFAULT_DB_LINK_MAX_LINKS,
    DEFAULT_DB_LINK_TIMEOUT_SECONDS,
    DEFAULT_EXPECTED_HTTP_STATUS,
    DEFAULT_HTTP_METHOD,
    DEFAULT_MSSQL_VALIDATION_QUERY,
    DEFAULT_ORACLE_VALIDATION_QUERY,
    DEFAULT_RETRY_COUNT,
    DEFAULT_TIMEOUT_SECONDS,
    MAX_DB_LINKS,
    MAX_RETRY_COUNT,
    MAX_TIMEOUT_SECONDS,
    MIN_TIMEOUT_SECONDS,
    AuthMethod,
    InterfaceCategory,
    InterfaceType,
    spec_for,
)
from utilities.validators import (
    validate_host,
    validate_http_method,
    validate_interface_name,
    validate_url,
)

__all__ = [
    "AnyInterfaceConfig",
    "AwsS3InterfaceConfig",
    "AzureBlobInterfaceConfig",
    "BaseInterfaceConfig",
    "DbLinkScope",
    "FtpFamilyInterfaceConfig",
    "FtpInterfaceConfig",
    "FtpsInterfaceConfig",
    "FtpsMode",
    "HostKeyPolicy",
    "HostPortInterfaceConfig",
    "MssqlInterfaceConfig",
    "OracleInterfaceConfig",
    "RestInterfaceConfig",
    "ScpInterfaceConfig",
    "SftpInterfaceConfig",
    "SoapInterfaceConfig",
    "SshFamilyInterfaceConfig",
    "SshInterfaceConfig",
]


# ---------------------------------------------------------------------------
# Supporting enumerations
# ---------------------------------------------------------------------------


@unique
class HostKeyPolicy(StrEnum):
    """How an unknown or changed SSH host key is treated.

    Post-change validation is precisely when a host key legitimately changes
    (a rebuilt server) and also when it illegitimately changes (an interception
    on a re-pointed firewall rule). The default is :attr:`WARN`, which connects
    and records the fingerprint plus a warning in the result, so the report
    tells an operator the key changed instead of either failing the whole run
    or silently trusting it.
    """

    REJECT = "reject"
    """Fail the interface unless the key is already in the known_hosts file."""

    WARN = "warn"
    """Connect, but record the fingerprint and flag the key as unverified."""

    AUTO_ADD = "auto_add"
    """Connect and persist the key to the known_hosts file."""


@unique
class FtpsMode(StrEnum):
    """TLS negotiation mode for FTPS."""

    EXPLICIT = "explicit"
    """AUTH TLS on the standard FTP port. RFC 4217, the common case."""

    IMPLICIT = "implicit"
    """TLS from connect, historically on port 990."""


@unique
class DbLinkScope(StrEnum):
    """Which Oracle database links a check considers.

    ``USER`` reads ``USER_DB_LINKS``: the links the connecting schema owns, and
    the ones a batch job running as that schema actually uses. ``ALL`` reads
    ``ALL_DB_LINKS``, which adds public links and links owned by other schemas;
    only the public ones can be opened by this session, so the rest are
    reported as present but unchecked rather than as failures.
    """

    USER = "user"
    """Links owned by the connecting schema."""

    ALL = "all"
    """Everything visible in ALL_DB_LINKS, including public links."""


@unique
class MssqlAuthentication(StrEnum):
    """Microsoft SQL Server authentication mode."""

    SQL = "sql"
    """SQL Server login with an explicit username and password."""

    WINDOWS = "windows"
    """Integrated Windows authentication using the calling process identity."""


@unique
class AzureAuthMethod(StrEnum):
    """Azure Blob Storage authentication mechanism."""

    CONNECTION_STRING = "connection_string"
    SERVICE_PRINCIPAL = "service_principal"
    MANAGED_IDENTITY = "managed_identity"


@unique
class AwsAuthMethod(StrEnum):
    """Amazon S3 authentication mechanism."""

    ACCESS_KEY = "access_key"
    """Explicit access key id and secret access key."""

    IAM_ROLE = "iam_role"
    """The default credential chain: instance profile, IRSA, or a named profile."""


@unique
class RestAuthMethod(StrEnum):
    """REST API authentication mechanism."""

    NONE = "none"
    BASIC = "basic"
    BEARER = "bearer"
    API_KEY = "api_key"


# ---------------------------------------------------------------------------
# Base model
# ---------------------------------------------------------------------------


class BaseInterfaceConfig(BaseModel):
    """Fields shared by every connectivity type.

    Attributes:
        SECRET_FIELDS: Names of fields on this model that hold credentials.
            The wizard encrypts them on save and the loader audits them on
            load. Subclasses extend, never replace, the inherited tuple.
    """

    model_config = ConfigDict(
        extra="forbid",
        str_strip_whitespace=True,
        validate_assignment=True,
        use_enum_values=False,
        populate_by_name=True,
    )

    SECRET_FIELDS: ClassVar[tuple[str, ...]] = ()

    name: str = Field(
        ...,
        description="Unique, human readable identifier used in reports and logs.",
    )
    enabled: bool = Field(
        default=True,
        description="Disabled interfaces are reported as SKIPPED and never dialled.",
    )
    description: str = Field(
        default="",
        max_length=500,
        description="Free text noting the business system behind this interface.",
    )
    timeout_seconds: int = Field(
        default=DEFAULT_TIMEOUT_SECONDS,
        ge=MIN_TIMEOUT_SECONDS,
        le=MAX_TIMEOUT_SECONDS,
        description="Per-attempt timeout applied to connect and to the probe.",
    )
    tags: list[str] = Field(
        default_factory=list,
        description="Labels for grouping in reports, for example 'payments' or 'tier-1'.",
    )

    @field_validator("name")
    @classmethod
    def _validate_name(cls, value: str) -> str:
        return validate_interface_name(value)

    @property
    def interface_type(self) -> InterfaceType:
        """Return the connectivity type of this interface.

        The discriminator field ``type`` is declared by each concrete subclass
        rather than here, because each one narrows it to a distinct
        :class:`~typing.Literal` for the pydantic discriminated union. It is
        therefore read dynamically, with an explicit failure if a subclass ever
        omits it.
        """
        declared_type = getattr(self, "type", None)
        if declared_type is None:
            raise NotImplementedError(
                f"{type(self).__name__} does not declare a 'type' discriminator field."
            )
        return InterfaceType(declared_type)

    @property
    def category(self) -> InterfaceCategory:
        """Return the reporting category this interface belongs to."""
        return spec_for(self.interface_type).category

    @property
    def endpoint(self) -> str:
        """Return a display endpoint such as ``host:port`` or a URL.

        Subclasses that are addressed by URL rather than host and port
        override this.
        """
        host = getattr(self, "host", None)
        port = getattr(self, "port", None)
        if host and port:
            return f"{host}:{port}"
        return str(host or "")

    @property
    def display_host(self) -> str:
        """Return the host column value used in reports."""
        return str(getattr(self, "host", "") or "")

    @property
    def display_port(self) -> int | None:
        """Return the port column value used in reports."""
        port = getattr(self, "port", None)
        return int(port) if isinstance(port, int) else None

    @property
    def auth_method(self) -> AuthMethod:
        """Return the authentication mechanism this interface will use."""
        return AuthMethod.NONE

    def secret_values(self) -> dict[str, str]:
        """Return the configured secrets keyed by field name.

        Values are returned in stored envelope form. Empty fields are omitted
        so callers can distinguish "not configured" from "configured empty".
        """
        values: dict[str, str] = {}
        for field_name in self.SECRET_FIELDS:
            value = getattr(self, field_name, None)
            if isinstance(value, str) and value:
                values[field_name] = value
        return values


# ---------------------------------------------------------------------------
# File transfer
# ---------------------------------------------------------------------------


class HostPortInterfaceConfig(BaseInterfaceConfig):
    """Shared base for interfaces addressed by host and TCP port."""

    host: str = Field(..., description="Target host name, FQDN or IP address.")
    port: int = Field(..., ge=1, le=65535, description="Target TCP port.")

    @field_validator("host")
    @classmethod
    def _validate_host(cls, value: str) -> str:
        return validate_host(value)


class SshFamilyInterfaceConfig(HostPortInterfaceConfig):
    """Shared configuration for SFTP, SCP and SSH.

    The algorithm preference fields exist specifically for post-change
    validation. After an SSH hardening change, pinning ``preferred_ciphers``
    to the newly mandated cipher proves the server actually offers it, which a
    default negotiation would hide by silently falling back to an older one
    that is still enabled.
    """

    SECRET_FIELDS: ClassVar[tuple[str, ...]] = ("password", "key_passphrase")

    username: str = Field(..., min_length=1, description="Login account name.")
    password: str | None = Field(
        default=None,
        description="Stored encrypted. Omit to authenticate with a private key.",
    )
    private_key_path: str | None = Field(
        default=None,
        description="Path to the private key file. Omit to auto-discover.",
    )
    key_passphrase: str | None = Field(
        default=None, description="Stored encrypted. Passphrase protecting the private key."
    )
    known_hosts_path: str | None = Field(
        default=None,
        description="known_hosts file used to verify the server host key.",
    )
    host_key_policy: HostKeyPolicy = Field(
        default=HostKeyPolicy.WARN,
        description="Treatment of an unknown or changed server host key.",
    )
    auto_discovered_key: bool = Field(
        default=False,
        description=(
            "True when the wizard resolved the key from ~/.ssh rather than the "
            "operator naming it. Recorded so a report explains where the "
            "credential came from."
        ),
    )
    preferred_kex_algorithms: list[str] = Field(
        default_factory=list,
        description="Key exchange algorithms to offer, highest preference first.",
    )
    preferred_ciphers: list[str] = Field(
        default_factory=list,
        description="Symmetric ciphers to offer, highest preference first.",
    )
    preferred_host_key_algorithms: list[str] = Field(
        default_factory=list, description="Host key algorithms to accept."
    )
    preferred_macs: list[str] = Field(
        default_factory=list, description="MAC algorithms to offer."
    )
    remote_path: str | None = Field(
        default=None,
        description=(
            "Optional remote directory to list after authenticating. Turns a "
            "login check into a genuine authorisation check."
        ),
    )

    @property
    def auth_method(self) -> AuthMethod:
        """Return the credential the connector will present."""
        if self.password:
            return AuthMethod.PASSWORD
        if self.private_key_path:
            return (
                AuthMethod.AUTO_DISCOVERED_KEY
                if self.auto_discovered_key
                else AuthMethod.PRIVATE_KEY
            )
        return AuthMethod.AUTO_DISCOVERED_KEY


class SftpInterfaceConfig(SshFamilyInterfaceConfig):
    """SFTP interface: authenticate over SSH and open an SFTP subsystem."""

    type: Literal[InterfaceType.SFTP] = InterfaceType.SFTP
    port: int = Field(default=22, ge=1, le=65535)


class ScpInterfaceConfig(SshFamilyInterfaceConfig):
    """SCP interface: authenticate over SSH and verify the SCP channel."""

    type: Literal[InterfaceType.SCP] = InterfaceType.SCP
    port: int = Field(default=22, ge=1, le=65535)


class SshInterfaceConfig(SshFamilyInterfaceConfig):
    """SSH interface: authenticate and optionally execute a validation command."""

    type: Literal[InterfaceType.SSH] = InterfaceType.SSH
    port: int = Field(default=22, ge=1, le=65535)
    validation_command: str | None = Field(
        default=None,
        description=(
            "Optional command executed after authentication, for example "
            "'echo connectivity-ok'. A non-zero exit status fails the interface."
        ),
    )


class FtpFamilyInterfaceConfig(HostPortInterfaceConfig):
    """Shared configuration for plain FTP and FTPS.

    Both protocols share a login, a passive-mode setting and an optional
    remote directory, and their connector shares the same probe. Modelling the
    common shape once lets that connector be typed against this base instead
    of re-declaring the fields per protocol.
    """

    SECRET_FIELDS: ClassVar[tuple[str, ...]] = ("password",)

    port: int = Field(default=21, ge=1, le=65535)
    username: str = Field(default="anonymous", description="Login account name.")
    password: str | None = Field(default=None, description="Stored encrypted.")
    passive_mode: bool = Field(
        default=True,
        description=(
            "Passive mode. Almost always required through a firewall, and the "
            "first thing to check after a firewall change."
        ),
    )
    remote_path: str | None = Field(
        default=None, description="Optional remote directory listed after login."
    )

    @property
    def auth_method(self) -> AuthMethod:
        """Return PASSWORD, or ANONYMOUS for the conventional guest login."""
        if self.username.lower() == "anonymous" and not self.password:
            return AuthMethod.ANONYMOUS
        return AuthMethod.PASSWORD


class FtpInterfaceConfig(FtpFamilyInterfaceConfig):
    """Plain FTP interface.

    FTP transmits credentials in clear text. The framework validates it because
    estates still run it, and the report flags it as an insecure protocol so it
    surfaces during a security review rather than staying invisible.
    """

    type: Literal[InterfaceType.FTP] = InterfaceType.FTP


class FtpsInterfaceConfig(FtpFamilyInterfaceConfig):
    """FTP over TLS.

    A frequent casualty of OpenSSL upgrades: the control channel negotiates but
    the data channel fails, or session reuse is newly required. Both are
    exercised here.
    """

    type: Literal[InterfaceType.FTPS] = InterfaceType.FTPS
    ftps_mode: FtpsMode = Field(
        default=FtpsMode.EXPLICIT, description="Explicit (AUTH TLS) or implicit TLS."
    )
    verify_ssl: bool = Field(
        default=True, description="Verify the server certificate chain and host name."
    )
    ca_bundle_path: str | None = Field(
        default=None, description="PEM bundle used to verify the server certificate."
    )


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------


class OracleInterfaceConfig(HostPortInterfaceConfig):
    """Oracle Database interface.

    python-oracledb runs in thin mode by default, which needs no Oracle client
    installed. Thick mode is available for estates that require it, for example
    to use an Oracle Wallet.
    """

    SECRET_FIELDS: ClassVar[tuple[str, ...]] = ("password",)

    type: Literal[InterfaceType.ORACLE] = InterfaceType.ORACLE
    port: int = Field(default=1521, ge=1, le=65535)
    service_name: str | None = Field(
        default=None, description="Oracle service name. Mutually exclusive with sid."
    )
    sid: str | None = Field(
        default=None, description="Oracle SID, for legacy listeners. Prefer service_name."
    )
    username: str = Field(..., min_length=1, description="Database account name.")
    password: str | None = Field(default=None, description="Stored encrypted.")
    use_ssl: bool = Field(
        default=False, description="Connect with TCPS rather than TCP."
    )
    ssl_server_dn_match: bool = Field(
        default=True, description="Verify the server certificate distinguished name."
    )
    wallet_location: str | None = Field(
        default=None, description="Oracle Wallet directory. Requires thick mode."
    )
    use_thick_mode: bool = Field(
        default=False,
        description="Initialise the Oracle Client library instead of thin mode.",
    )
    validation_query: str = Field(
        default=DEFAULT_ORACLE_VALIDATION_QUERY,
        min_length=1,
        description="Query executed to prove the session is usable.",
    )
    check_db_links: bool = Field(
        default=False,
        description=(
            "After the validation query, enumerate this account's database links "
            "and open each one with SELECT 'X' FROM dual@<link>. A link is opened "
            "by the database server, so this exercises a network path no check "
            "run from this host can otherwise reach."
        ),
    )
    db_link_scope: DbLinkScope = Field(
        default=DbLinkScope.USER,
        description="Read USER_DB_LINKS (the schema's own links) or ALL_DB_LINKS.",
    )
    db_link_names: list[str] = Field(
        default_factory=list,
        description=(
            "Optional list restricting the check to these link names, matched "
            "case-insensitively. A name listed here but absent from the data "
            "dictionary fails the interface, which is how a link dropped during a "
            "schema refresh is caught. Empty means check every link found."
        ),
    )
    db_link_timeout_seconds: int = Field(
        default=DEFAULT_DB_LINK_TIMEOUT_SECONDS,
        ge=1,
        le=MAX_TIMEOUT_SECONDS,
        description="Ceiling for one link probe, applied as the session call timeout.",
    )
    db_link_budget_seconds: int = Field(
        default=DEFAULT_DB_LINK_BUDGET_SECONDS,
        ge=1,
        le=MAX_TIMEOUT_SECONDS,
        description=(
            "Wall-clock ceiling for probing every link on this interface. Links not "
            "reached within it are reported as unchecked."
        ),
    )
    db_link_max_links: int = Field(
        default=DEFAULT_DB_LINK_MAX_LINKS,
        ge=1,
        le=MAX_DB_LINKS,
        description="Maximum number of links probed on this interface.",
    )
    fail_on_broken_db_link: bool = Field(
        default=True,
        description=(
            "Treat a link that cannot be opened as a failure of this interface. "
            "Set False to record broken links as warnings instead, for an estate "
            "where some links are known to be decommissioned."
        ),
    )

    @model_validator(mode="after")
    def _require_service_name_or_sid(self) -> OracleInterfaceConfig:
        """Ensure exactly one of ``service_name`` and ``sid`` is supplied."""
        if not self.service_name and not self.sid:
            raise ValueError(
                "Oracle interface requires either 'service_name' or 'sid'. "
                "Prefer service_name; SID is retained for legacy listeners."
            )
        if self.service_name and self.sid:
            raise ValueError(
                "Oracle interface must not set both 'service_name' and 'sid'. "
                "Remove whichever the listener does not use."
            )
        return self

    @field_validator("db_link_names")
    @classmethod
    def _normalise_db_link_names(cls, value: list[str]) -> list[str]:
        """Fold configured link names to the data dictionary's case.

        Oracle stores link names upper-cased unless they were created quoted,
        so an operator who writes ``sales_link`` means the ``SALES_LINK`` the
        dictionary holds. Normalising once here means the connector compares
        like with like instead of every call site remembering to.
        """
        seen: dict[str, None] = {}
        for raw_name in value:
            name = raw_name.strip().upper()
            if name:
                seen[name] = None
        return list(seen)

    @model_validator(mode="after")
    def _check_db_link_budget(self) -> OracleInterfaceConfig:
        """Reject a budget too small for even one link probe."""
        if self.db_link_timeout_seconds > self.db_link_budget_seconds:
            raise ValueError(
                "Oracle interface has 'db_link_timeout_seconds' greater than "
                "'db_link_budget_seconds', so the budget would stop the check before "
                "even one link could time out. Raise the budget or lower the timeout."
            )
        return self

    @property
    def auth_method(self) -> AuthMethod:
        """Return the database authentication mechanism."""
        return AuthMethod.PASSWORD if self.password else AuthMethod.NONE

    @property
    def dsn(self) -> str:
        """Return the Easy Connect descriptor for this interface."""
        protocol = "tcps" if self.use_ssl else "tcp"
        target = self.service_name or self.sid or ""
        separator = "/" if self.service_name else ":"
        return f"{protocol}://{self.host}:{self.port}{separator}{target}"


class MssqlInterfaceConfig(HostPortInterfaceConfig):
    """Microsoft SQL Server interface.

    ``encrypt`` defaults to ``True`` to match the behaviour of ODBC Driver 18,
    whose changed default is itself a common cause of connection failures
    immediately after a driver upgrade.
    """

    SECRET_FIELDS: ClassVar[tuple[str, ...]] = ("password",)

    type: Literal[InterfaceType.MSSQL] = InterfaceType.MSSQL
    port: int = Field(default=1433, ge=1, le=65535)
    database: str = Field(..., min_length=1, description="Target database name.")
    username: str | None = Field(
        default=None, description="Required for SQL authentication."
    )
    password: str | None = Field(default=None, description="Stored encrypted.")
    authentication: MssqlAuthentication = Field(
        default=MssqlAuthentication.SQL, description="SQL login or integrated Windows."
    )
    odbc_driver: str = Field(
        default="ODBC Driver 18 for SQL Server",
        description="Installed ODBC driver name, as listed by the driver manager.",
    )
    encrypt: bool = Field(default=True, description="Request an encrypted connection.")
    trust_server_certificate: bool = Field(
        default=False,
        description=(
            "Accept a server certificate that does not chain to a trusted root. "
            "Leave False in production; True only masks a certificate problem."
        ),
    )
    validation_query: str = Field(
        default=DEFAULT_MSSQL_VALIDATION_QUERY,
        min_length=1,
        description="Query executed to prove the session is usable.",
    )

    @model_validator(mode="after")
    def _require_credentials_for_sql_auth(self) -> MssqlInterfaceConfig:
        """Ensure SQL authentication carries a username."""
        if self.authentication is MssqlAuthentication.SQL and not self.username:
            raise ValueError(
                "SQL Server interface using SQL authentication requires 'username'. "
                "Set authentication to 'windows' to use the process identity instead."
            )
        return self

    @property
    def auth_method(self) -> AuthMethod:
        """Return the SQL Server authentication mechanism."""
        if self.authentication is MssqlAuthentication.WINDOWS:
            return AuthMethod.WINDOWS_AUTHENTICATION
        return AuthMethod.SQL_AUTHENTICATION


# ---------------------------------------------------------------------------
# Cloud
# ---------------------------------------------------------------------------


class AzureBlobInterfaceConfig(BaseInterfaceConfig):
    """Azure Blob Storage interface."""

    SECRET_FIELDS: ClassVar[tuple[str, ...]] = ("connection_string", "client_secret")

    type: Literal[InterfaceType.AZURE_BLOB] = InterfaceType.AZURE_BLOB
    auth_method_type: AzureAuthMethod = Field(
        default=AzureAuthMethod.CONNECTION_STRING,
        description="Connection string, service principal, or managed identity.",
    )
    account_url: str | None = Field(
        default=None,
        description=(
            "https://<account>.blob.core.windows.net. Required for service "
            "principal and managed identity authentication."
        ),
    )
    connection_string: str | None = Field(
        default=None, description="Stored encrypted. Carries the account key."
    )
    tenant_id: str | None = Field(default=None, description="Entra ID tenant identifier.")
    client_id: str | None = Field(
        default=None,
        description=(
            "Application id for a service principal, or the user-assigned "
            "managed identity client id."
        ),
    )
    client_secret: str | None = Field(default=None, description="Stored encrypted.")
    container_name: str | None = Field(
        default=None,
        description=(
            "Container whose properties are read as the probe. Omit to list "
            "containers at account level instead."
        ),
    )
    verify_ssl: bool = Field(default=True, description="Verify the TLS certificate chain.")

    @model_validator(mode="after")
    def _validate_auth_requirements(self) -> AzureBlobInterfaceConfig:
        """Ensure the fields required by the chosen auth method are present."""
        if self.auth_method_type is AzureAuthMethod.CONNECTION_STRING:
            if not self.connection_string:
                raise ValueError(
                    "Azure Blob interface using connection string authentication requires "
                    "'connection_string'."
                )
        elif self.auth_method_type is AzureAuthMethod.SERVICE_PRINCIPAL:
            missing = [
                field_name
                for field_name in ("account_url", "tenant_id", "client_id", "client_secret")
                if not getattr(self, field_name)
            ]
            if missing:
                raise ValueError(
                    "Azure Blob interface using service principal authentication requires: "
                    + ", ".join(missing)
                )
        elif not self.account_url:
            raise ValueError(
                "Azure Blob interface using managed identity requires 'account_url'."
            )
        return self

    @field_validator("account_url")
    @classmethod
    def _validate_account_url(cls, value: str | None) -> str | None:
        return validate_url(value) if value else value

    @property
    def auth_method(self) -> AuthMethod:
        """Return the Azure authentication mechanism."""
        return {
            AzureAuthMethod.CONNECTION_STRING: AuthMethod.CONNECTION_STRING,
            AzureAuthMethod.SERVICE_PRINCIPAL: AuthMethod.SERVICE_PRINCIPAL,
            AzureAuthMethod.MANAGED_IDENTITY: AuthMethod.MANAGED_IDENTITY,
        }[self.auth_method_type]

    @property
    def endpoint(self) -> str:
        """Return the storage endpoint, including the container when set."""
        base = self.account_url or "azure-blob-storage"
        return f"{base}/{self.container_name}" if self.container_name else base

    @property
    def display_host(self) -> str:
        """Return the storage account host for the report host column."""
        if not self.account_url:
            return "azure-blob-storage"
        return urlparse(self.account_url).netloc or self.account_url

    @property
    def display_port(self) -> int | None:
        """Return 443: Azure Storage is reachable over HTTPS only."""
        return 443


class AwsS3InterfaceConfig(BaseInterfaceConfig):
    """Amazon S3 interface.

    ``endpoint_url`` also covers S3-compatible object stores, which are common
    on-premises and behave identically for connectivity purposes.
    """

    SECRET_FIELDS: ClassVar[tuple[str, ...]] = ("secret_access_key", "session_token")

    type: Literal[InterfaceType.AWS_S3] = InterfaceType.AWS_S3
    auth_method_type: AwsAuthMethod = Field(
        default=AwsAuthMethod.ACCESS_KEY,
        description="Explicit access key, or the ambient IAM role credential chain.",
    )
    region: str = Field(default="us-east-1", min_length=1, description="AWS region name.")
    access_key_id: str | None = Field(
        default=None, description="Required for access key authentication."
    )
    secret_access_key: str | None = Field(default=None, description="Stored encrypted.")
    session_token: str | None = Field(
        default=None, description="Stored encrypted. For temporary STS credentials."
    )
    profile_name: str | None = Field(
        default=None, description="Named profile from the shared AWS credentials file."
    )
    role_arn: str | None = Field(
        default=None, description="Role assumed after the base credential resolves."
    )
    bucket_name: str | None = Field(
        default=None,
        description=(
            "Bucket whose metadata is read as the probe. Omit to list buckets "
            "at account level instead."
        ),
    )
    prefix: str | None = Field(
        default=None, description="Key prefix listed inside the bucket as a deeper probe."
    )
    endpoint_url: str | None = Field(
        default=None, description="Override endpoint for S3-compatible object stores."
    )
    verify_ssl: bool = Field(default=True, description="Verify the TLS certificate chain.")

    @model_validator(mode="after")
    def _validate_auth_requirements(self) -> AwsS3InterfaceConfig:
        """Ensure explicit key authentication carries both key components."""
        if self.auth_method_type is AwsAuthMethod.ACCESS_KEY and not self.access_key_id:
            raise ValueError(
                "S3 interface using access key authentication requires 'access_key_id'. "
                "Set auth_method_type to 'iam_role' to use the ambient credential chain."
            )
        if self.prefix and not self.bucket_name:
            raise ValueError("S3 interface sets 'prefix' but no 'bucket_name' to list it in.")
        return self

    @field_validator("endpoint_url")
    @classmethod
    def _validate_endpoint_url(cls, value: str | None) -> str | None:
        return validate_url(value) if value else value

    @property
    def auth_method(self) -> AuthMethod:
        """Return the AWS authentication mechanism."""
        if self.auth_method_type is AwsAuthMethod.IAM_ROLE:
            return AuthMethod.IAM_ROLE
        return AuthMethod.ACCESS_KEY

    @property
    def endpoint(self) -> str:
        """Return the S3 endpoint, including the bucket when set."""
        base = self.endpoint_url or f"s3.{self.region}.amazonaws.com"
        return f"{base}/{self.bucket_name}" if self.bucket_name else base

    @property
    def display_host(self) -> str:
        """Return the S3 host for the report host column."""
        if self.endpoint_url:
            return urlparse(self.endpoint_url).netloc or self.endpoint_url
        return f"s3.{self.region}.amazonaws.com"

    @property
    def display_port(self) -> int | None:
        """Return the endpoint port, defaulting to HTTPS."""
        return 443


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------


class RestInterfaceConfig(BaseInterfaceConfig):
    """REST API interface."""

    SECRET_FIELDS: ClassVar[tuple[str, ...]] = ("password", "bearer_token", "api_key_value")

    type: Literal[InterfaceType.REST] = InterfaceType.REST
    base_url: str = Field(..., description="Absolute URL of the endpoint to call.")
    method: str = Field(default=DEFAULT_HTTP_METHOD, description="HTTP method.")
    auth_method_type: RestAuthMethod = Field(
        default=RestAuthMethod.NONE, description="Authentication scheme."
    )
    username: str | None = Field(default=None, description="Basic authentication user.")
    password: str | None = Field(default=None, description="Stored encrypted.")
    bearer_token: str | None = Field(default=None, description="Stored encrypted.")
    api_key_header: str = Field(
        default="X-API-Key", description="Header carrying the API key."
    )
    api_key_value: str | None = Field(default=None, description="Stored encrypted.")
    headers: dict[str, str] = Field(
        default_factory=dict, description="Additional request headers."
    )
    request_body: str | None = Field(
        default=None, description="Raw request body for POST, PUT and PATCH."
    )
    expected_status_codes: list[int] = Field(
        default_factory=lambda: [DEFAULT_EXPECTED_HTTP_STATUS],
        min_length=1,
        description="Any of these response codes is treated as success.",
    )
    expected_body_contains: str | None = Field(
        default=None,
        description=(
            "Substring the response body must contain. Catches the load "
            "balancer that returns 200 with a maintenance page."
        ),
    )
    retry_count: int = Field(
        default=DEFAULT_RETRY_COUNT,
        ge=0,
        le=MAX_RETRY_COUNT,
        description="Retries on transport failure, with exponential backoff.",
    )
    verify_ssl: bool = Field(default=True, description="Verify the TLS certificate chain.")
    ca_bundle_path: str | None = Field(
        default=None, description="PEM bundle used to verify the server certificate."
    )
    follow_redirects: bool = Field(default=True, description="Follow HTTP redirects.")
    proxy_url: str | None = Field(default=None, description="Explicit proxy URL.")

    @field_validator("base_url")
    @classmethod
    def _validate_base_url(cls, value: str) -> str:
        return validate_url(value)

    @field_validator("method")
    @classmethod
    def _validate_method(cls, value: str) -> str:
        return validate_http_method(value)

    @field_validator("expected_status_codes")
    @classmethod
    def _validate_status_codes(cls, value: list[int]) -> list[int]:
        for status in value:
            if not 100 <= status <= 599:
                raise ValueError(f"Expected HTTP status code out of range: {status}")
        return value

    @model_validator(mode="after")
    def _validate_auth_requirements(self) -> RestInterfaceConfig:
        """Ensure the fields required by the chosen auth scheme are present."""
        if self.auth_method_type is RestAuthMethod.BASIC and not self.username:
            raise ValueError("REST interface using basic authentication requires 'username'.")
        if self.auth_method_type is RestAuthMethod.BEARER and not self.bearer_token:
            raise ValueError("REST interface using bearer authentication requires 'bearer_token'.")
        if self.auth_method_type is RestAuthMethod.API_KEY and not self.api_key_value:
            raise ValueError(
                "REST interface using API key authentication requires 'api_key_value'."
            )
        return self

    @property
    def auth_method(self) -> AuthMethod:
        """Return the HTTP authentication mechanism."""
        return {
            RestAuthMethod.NONE: AuthMethod.NONE,
            RestAuthMethod.BASIC: AuthMethod.BASIC,
            RestAuthMethod.BEARER: AuthMethod.BEARER_TOKEN,
            RestAuthMethod.API_KEY: AuthMethod.API_KEY,
        }[self.auth_method_type]

    @property
    def endpoint(self) -> str:
        """Return the method and URL being exercised."""
        return f"{self.method} {self.base_url}"

    @property
    def display_host(self) -> str:
        """Return the URL host for the report host column."""
        return urlparse(self.base_url).netloc or self.base_url

    @property
    def display_port(self) -> int | None:
        """Return the explicit URL port, or the scheme default."""
        parsed = urlparse(self.base_url)
        if parsed.port:
            return parsed.port
        return 443 if parsed.scheme == "https" else 80


class SoapInterfaceConfig(BaseInterfaceConfig):
    """SOAP web service interface.

    With no ``operation`` configured the probe retrieves and parses the WSDL,
    which already exercises DNS, TCP, TLS and authentication. Naming an
    operation additionally invokes it, which exercises the service itself.
    """

    SECRET_FIELDS: ClassVar[tuple[str, ...]] = ("password",)

    type: Literal[InterfaceType.SOAP] = InterfaceType.SOAP
    wsdl_url: str = Field(..., description="Absolute URL of the WSDL document.")
    endpoint_url: str | None = Field(
        default=None,
        description="Override for the service address published inside the WSDL.",
    )
    username: str | None = Field(default=None, description="WS-Security / basic auth user.")
    password: str | None = Field(default=None, description="Stored encrypted.")
    soap_action: str | None = Field(default=None, description="SOAPAction header value.")
    operation: str | None = Field(
        default=None, description="Operation invoked as the probe. Omit to only load the WSDL."
    )
    operation_arguments: dict[str, Any] = Field(
        default_factory=dict, description="Keyword arguments passed to the operation."
    )
    verify_ssl: bool = Field(default=True, description="Verify the TLS certificate chain.")
    ca_bundle_path: str | None = Field(
        default=None, description="PEM bundle used to verify the server certificate."
    )

    @field_validator("wsdl_url")
    @classmethod
    def _validate_wsdl_url(cls, value: str) -> str:
        return validate_url(value)

    @field_validator("endpoint_url")
    @classmethod
    def _validate_endpoint_url(cls, value: str | None) -> str | None:
        return validate_url(value) if value else value

    @model_validator(mode="after")
    def _validate_operation_arguments(self) -> SoapInterfaceConfig:
        """Reject arguments configured without an operation to pass them to."""
        if self.operation_arguments and not self.operation:
            raise ValueError(
                "SOAP interface sets 'operation_arguments' but no 'operation' to invoke."
            )
        return self

    @property
    def auth_method(self) -> AuthMethod:
        """Return the authentication mechanism."""
        return AuthMethod.BASIC if self.username else AuthMethod.NONE

    @property
    def endpoint(self) -> str:
        """Return the effective service address."""
        return self.endpoint_url or self.wsdl_url

    @property
    def display_host(self) -> str:
        """Return the URL host for the report host column."""
        return urlparse(self.endpoint).netloc or self.endpoint

    @property
    def display_port(self) -> int | None:
        """Return the explicit URL port, or the scheme default."""
        parsed = urlparse(self.endpoint)
        if parsed.port:
            return parsed.port
        return 443 if parsed.scheme == "https" else 80


# ---------------------------------------------------------------------------
# Discriminated union
# ---------------------------------------------------------------------------

#: The union pydantic uses to parse each entry of the ``interfaces`` array.
#: ``type`` selects the model, so an unknown value produces a precise error
#: naming the field rather than a cascade of failures against every model.
AnyInterfaceConfig = Annotated[
    SftpInterfaceConfig
    | ScpInterfaceConfig
    | SshInterfaceConfig
    | FtpInterfaceConfig
    | FtpsInterfaceConfig
    | OracleInterfaceConfig
    | MssqlInterfaceConfig
    | AzureBlobInterfaceConfig
    | AwsS3InterfaceConfig
    | RestInterfaceConfig
    | SoapInterfaceConfig,
    Field(discriminator="type"),
]
