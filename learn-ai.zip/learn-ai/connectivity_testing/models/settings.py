"""Application, e-mail, logging, reporting and execution settings.

:class:`ApplicationConfig` is the root of the configuration file. It owns the
interface list plus every operational knob, and it enforces the rules that
span sections, such as interface name uniqueness.

Directory settings accept relative paths. They are resolved against the
directory holding the configuration file, not the process working directory,
so a job started by a scheduler from an arbitrary cwd still writes its reports
and logs where the operator expects.
"""

from __future__ import annotations

from enum import StrEnum, unique
from typing import Any, ClassVar

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from core.constants import (
    APP_VERSION,
    CONFIG_SCHEMA_VERSION,
    DEFAULT_LOG_BACKUP_COUNT,
    DEFAULT_LOG_LEVEL,
    DEFAULT_LOG_MAX_BYTES,
    DEFAULT_LOGS_DIRECTORY,
    DEFAULT_MAX_WORKERS,
    DEFAULT_REPORT_RETENTION_DAYS,
    DEFAULT_REPORTS_DIRECTORY,
    DEFAULT_SMTP_TIMEOUT_SECONDS,
    DEFAULT_SMTP_TLS_PORT,
    MAX_WORKERS_LIMIT,
    SUPPORTED_LOG_LEVELS,
)
from models.interfaces import AnyInterfaceConfig, BaseInterfaceConfig
from utilities.validators import validate_email_address, validate_email_list, validate_host

__all__ = [
    "ApplicationConfig",
    "EmailSettings",
    "ExecutionSettings",
    "LoggingSettings",
    "ReportSettings",
    "SmtpSecurity",
]


@unique
class SmtpSecurity(StrEnum):
    """Transport security used when talking to the SMTP relay."""

    NONE = "none"
    """Plain SMTP. Common for an internal relay that restricts by source IP."""

    STARTTLS = "starttls"
    """Connect in clear, then upgrade with STARTTLS. The usual choice."""

    SSL = "ssl"
    """TLS from connect, historically on port 465."""


class EmailSettings(BaseModel):
    """SMTP delivery settings for the notification e-mail."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, validate_assignment=True)

    SECRET_FIELDS: ClassVar[tuple[str, ...]] = ("password",)

    enabled: bool = Field(
        default=False, description="Send a notification e-mail after every run."
    )
    smtp_server: str | None = Field(default=None, description="SMTP relay host name.")
    smtp_port: int = Field(default=DEFAULT_SMTP_TLS_PORT, ge=1, le=65535)
    security: SmtpSecurity = Field(
        default=SmtpSecurity.STARTTLS, description="Transport security for the SMTP session."
    )
    username: str | None = Field(
        default=None, description="Optional. Omit for a relay that authenticates by IP."
    )
    password: str | None = Field(default=None, description="Stored encrypted.")
    sender: str | None = Field(default=None, description="From address.")
    sender_display_name: str = Field(
        default="Connectivity Validation", description="From display name."
    )
    recipients: list[str] = Field(default_factory=list, description="To addresses.")
    cc: list[str] = Field(default_factory=list, description="Cc addresses.")
    bcc: list[str] = Field(default_factory=list, description="Bcc addresses.")
    subject_prefix: str = Field(
        default="Enterprise Connectivity Validation Report",
        description="Leading text of the subject line, followed by the run outcome.",
    )
    timeout_seconds: int = Field(default=DEFAULT_SMTP_TIMEOUT_SECONDS, ge=1, le=600)
    attach_reports: bool = Field(
        default=True, description="Attach the PDF, Excel and JSON reports."
    )
    attach_log_file: bool = Field(
        default=True, description="Attach the application log for this run."
    )
    max_attachment_mb: int = Field(
        default=15,
        ge=1,
        le=100,
        description=(
            "Total attachment budget. Attachments beyond it are dropped and "
            "named in the e-mail body rather than risking rejection by the relay."
        ),
    )
    send_on_success: bool = Field(
        default=True, description="Send when every interface passed."
    )
    send_on_failure: bool = Field(
        default=True,
        description=(
            "Send when any interface failed. Leaving this False and "
            "send_on_success True would silence exactly the alert that matters."
        ),
    )
    verify_ssl: bool = Field(
        default=True, description="Verify the SMTP server certificate when TLS is used."
    )

    @field_validator("smtp_server")
    @classmethod
    def _validate_smtp_server(cls, value: str | None) -> str | None:
        return validate_host(value) if value else value

    @field_validator("sender")
    @classmethod
    def _validate_sender(cls, value: str | None) -> str | None:
        return validate_email_address(value) if value else value

    @field_validator("recipients", "cc", "bcc", mode="before")
    @classmethod
    def _validate_addresses(cls, value: Any) -> list[str]:
        """Accept either a list or a comma/semicolon separated string."""
        if value in (None, ""):
            return []
        return validate_email_list(value, allow_empty=True)

    @model_validator(mode="after")
    def _validate_enabled_requirements(self) -> EmailSettings:
        """Ensure an enabled e-mail configuration is actually deliverable."""
        if not self.enabled:
            return self

        missing = [
            field_name
            for field_name in ("smtp_server", "sender")
            if not getattr(self, field_name)
        ]
        if missing:
            raise ValueError(
                "E-mail notification is enabled but is missing: " + ", ".join(missing)
            )
        if not self.recipients:
            raise ValueError(
                "E-mail notification is enabled but no recipients are configured."
            )
        if self.username and not self.password:
            raise ValueError(
                "SMTP username is set without a password. Supply the password, or clear the "
                "username if the relay authenticates by source address."
            )
        return self

    @property
    def all_recipients(self) -> list[str]:
        """Return every envelope recipient, deduplicated across To, Cc and Bcc."""
        seen: set[str] = set()
        combined: list[str] = []
        for address in [*self.recipients, *self.cc, *self.bcc]:
            key = address.lower()
            if key not in seen:
                seen.add(key)
                combined.append(address)
        return combined

    def should_send(self, *, has_failures: bool) -> bool:
        """Return whether an e-mail should be sent for this run outcome."""
        if not self.enabled:
            return False
        return self.send_on_failure if has_failures else self.send_on_success


class LoggingSettings(BaseModel):
    """Rotating file logging configuration."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, validate_assignment=True)

    directory: str = Field(
        default=DEFAULT_LOGS_DIRECTORY,
        description="Log directory. Relative paths resolve against the config file.",
    )
    level: str = Field(
        default=DEFAULT_LOG_LEVEL, description="Threshold for the console and application log."
    )
    max_bytes: int = Field(
        default=DEFAULT_LOG_MAX_BYTES,
        ge=64 * 1024,
        description="Size at which a log file rolls over.",
    )
    backup_count: int = Field(
        default=DEFAULT_LOG_BACKUP_COUNT, ge=1, le=100, description="Rolled files retained."
    )
    console_enabled: bool = Field(
        default=True, description="Also write to stdout, which schedulers capture."
    )
    debug_log_enabled: bool = Field(
        default=True,
        description=(
            "Write the verbose debug log. Keep enabled: it is the only record "
            "of a transient failure that has already cleared by the time "
            "someone investigates."
        ),
    )

    @field_validator("level")
    @classmethod
    def _validate_level(cls, value: str) -> str:
        level = value.strip().upper()
        if level not in SUPPORTED_LOG_LEVELS:
            supported = ", ".join(SUPPORTED_LOG_LEVELS)
            raise ValueError(f"Log level must be one of: {supported}. Received '{value}'.")
        return level


class ReportSettings(BaseModel):
    """Report generation and retention configuration."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, validate_assignment=True)

    directory: str = Field(
        default=DEFAULT_REPORTS_DIRECTORY,
        description="Report directory. Relative paths resolve against the config file.",
    )
    generate_pdf: bool = Field(default=True, description="Produce the executive PDF report.")
    generate_excel: bool = Field(default=True, description="Produce the Excel workbook.")
    generate_json: bool = Field(default=True, description="Produce the machine-readable report.")
    retention_days: int = Field(
        default=DEFAULT_REPORT_RETENTION_DAYS,
        ge=1,
        le=3650,
        description=(
            "Reports older than this are deleted before each run. Only files "
            "this framework generated are ever considered."
        ),
    )
    cleanup_enabled: bool = Field(
        default=True, description="Run retention cleanup before validation."
    )
    include_environment_details: bool = Field(
        default=True,
        description="Record host, OS and interpreter details in the report header.",
    )

    @model_validator(mode="after")
    def _require_one_format(self) -> ReportSettings:
        """Ensure at least one report format is produced."""
        if not (self.generate_pdf or self.generate_excel or self.generate_json):
            raise ValueError(
                "At least one report format must be enabled, otherwise a run leaves no "
                "evidence of what was validated."
            )
        return self


class ExecutionSettings(BaseModel):
    """Engine behaviour: concurrency, retries and failure handling."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, validate_assignment=True)

    parallel_enabled: bool = Field(
        default=True,
        description=(
            "Validate interfaces concurrently. Connectors are I/O bound, so a "
            "thread pool cuts a large estate from minutes to seconds."
        ),
    )
    max_workers: int = Field(
        default=DEFAULT_MAX_WORKERS,
        ge=1,
        le=MAX_WORKERS_LIMIT,
        description="Thread pool size when parallel execution is enabled.",
    )
    global_timeout_seconds: int | None = Field(
        default=None,
        ge=1,
        description=(
            "Optional ceiling for the whole run. Interfaces not finished by "
            "then are recorded as failed, so a scheduler slot cannot overrun."
        ),
    )
    strict_secrets: bool = Field(
        default=False,
        description=(
            "Refuse to use any secret stored as plaintext. Enable at sites "
            "whose policy forbids credentials on disk in unprotected form."
        ),
    )
    fail_on_warning: bool = Field(
        default=False,
        description=(
            "Treat a warning, such as an unverified SSH host key, as a failure."
        ),
    )

    @property
    def effective_max_workers(self) -> int:
        """Return the worker count the engine should actually use.

        Derived rather than normalised in place, so that toggling
        ``parallel_enabled`` back on restores the configured pool size instead
        of silently leaving it pinned at one.
        """
        return self.max_workers if self.parallel_enabled else 1


class ApplicationConfig(BaseModel):
    """Root configuration model: the parsed contents of the JSON file."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, validate_assignment=True)

    schema_version: str = Field(
        default=CONFIG_SCHEMA_VERSION,
        description="Configuration schema version, for forward compatibility.",
    )
    generated_by: str = Field(
        default=f"generate_config.py {APP_VERSION}",
        description="Provenance of this file.",
    )
    generated_at: str | None = Field(
        default=None, description="ISO-8601 timestamp of the last wizard save."
    )
    environment: str = Field(
        default="production",
        description="Environment label shown in reports, for example 'production' or 'dr'.",
    )
    description: str = Field(
        default="", max_length=500, description="Free text describing this configuration."
    )

    email: EmailSettings = Field(default_factory=EmailSettings)
    logging: LoggingSettings = Field(default_factory=LoggingSettings)
    reports: ReportSettings = Field(default_factory=ReportSettings)
    execution: ExecutionSettings = Field(default_factory=ExecutionSettings)

    interfaces: list[AnyInterfaceConfig] = Field(
        default_factory=list, description="Connectivity interfaces to validate."
    )

    @model_validator(mode="after")
    def _validate_interface_names_are_unique(self) -> ApplicationConfig:
        """Reject duplicate interface names.

        Names key the report rows, the log fields and the e-mail summary. Two
        interfaces sharing a name produces a report where a failure cannot be
        traced back to a single endpoint.
        """
        seen: dict[str, int] = {}
        duplicates: list[str] = []
        for interface in self.interfaces:
            key = interface.name.strip().lower()
            seen[key] = seen.get(key, 0) + 1
            if seen[key] == 2:
                duplicates.append(interface.name)
        if duplicates:
            raise ValueError(
                "Interface names must be unique. Duplicated: " + ", ".join(sorted(duplicates))
            )
        return self

    @property
    def enabled_interfaces(self) -> list[BaseInterfaceConfig]:
        """Return only the interfaces that will actually be validated."""
        return [interface for interface in self.interfaces if interface.enabled]

    @property
    def disabled_interfaces(self) -> list[BaseInterfaceConfig]:
        """Return the interfaces that are configured but switched off."""
        return [interface for interface in self.interfaces if not interface.enabled]

    def interface_by_name(self, name: str) -> BaseInterfaceConfig | None:
        """Return the interface with ``name``, matched case-insensitively."""
        target = name.strip().lower()
        for interface in self.interfaces:
            if interface.name.strip().lower() == target:
                return interface
        return None
