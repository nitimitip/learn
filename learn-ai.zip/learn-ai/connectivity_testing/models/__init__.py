"""Typed data models for the Enterprise Connectivity Validation Framework.

All configuration objects and all execution results are represented by
explicit, validated models rather than free-form dictionaries.  The models
are the contract between the configuration wizard, the validation engine,
the connectors and the reporting layer.

    interfaces  -- per connectivity-type configuration models
    settings    -- application, e-mail and runtime settings models
    results     -- validation result and execution summary models
"""

from __future__ import annotations

__all__: list[str] = []
