"""Validation result and execution summary models.

Results are plain dataclasses rather than pydantic models: they are produced
by the framework itself, not parsed from untrusted input, so validation would
buy nothing and the allocation cost is paid once per interface.

Two rules govern everything here:

* **A result is always produced.** Whatever a connector does, including
  raising an exception the framework has never seen, the engine records a
  result for that interface. A missing row in a connectivity report is
  indistinguishable from a passing one to a tired operator at 3 a.m., which
  makes silence the worst possible outcome.
* **A result is safe to serialise.** Nothing placed on a result may contain a
  live credential. Connectors put endpoint and driver context in ``details``
  and let the masking layer handle anything borderline.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from core.constants import (
    DEGRADED_THRESHOLD_PERCENT,
    HEALTHY_THRESHOLD_PERCENT,
    AuthMethod,
    InterfaceCategory,
    InterfaceType,
    SeverityBand,
    ValidationStatus,
)
from utilities.masking import redact_mapping, redact_text, secret_registry
from utilities.platform_info import PlatformInfo
from utilities.timing import format_duration, utc_now

__all__ = ["ExecutionSummary", "ValidationResult"]


def _scrub(text: str) -> str:
    """Apply pattern redaction followed by registered-secret scrubbing."""
    return secret_registry.scrub(redact_text(text))


@dataclass(slots=True)
class ValidationResult:
    """Outcome of validating one interface.

    Attributes:
        interface_name: Unique name from the configuration.
        interface_type: Connectivity type validated.
        category: Reporting group the type belongs to.
        host: Endpoint host, or the URL host for URL-addressed services.
        port: Endpoint port, when the type is addressed by port.
        endpoint: Full endpoint description shown in reports.
        auth_method: Credential mechanism actually presented.
        status: SUCCESS, FAILED or SKIPPED.
        started_at: Wall clock start, timezone aware.
        ended_at: Wall clock end, timezone aware.
        duration_seconds: Total time from the monotonic clock, including
            retries. This is the number a scheduler slot is budgeted against.
        latency_ms: Time to establish the connection, excluding the probe and
            excluding retries. This is the number that moves when a network
            path changes.
        error_message: One-line operator-facing failure summary.
        error_code: Stable machine-readable label for dashboards.
        exception_type: Class name of the originating exception.
        exception_details: Full exception text, already redacted.
        stack_trace: Formatted traceback, retained for the debug log and the
            JSON report only.
        remediation: The concrete next action, carried from the exception.
        warnings: Non-fatal observations, such as an unverified host key.
        attempts: Number of attempts made, including the successful one.
        details: Connector-specific evidence, for example the negotiated
            cipher, the server banner or the certificate expiry date. This is
            what turns "SFTP failed" into "SFTP failed because the server no
            longer offers the pinned cipher".
    """

    interface_name: str
    interface_type: InterfaceType
    category: InterfaceCategory
    status: ValidationStatus
    host: str = ""
    port: int | None = None
    endpoint: str = ""
    auth_method: AuthMethod = AuthMethod.NONE
    started_at: datetime = field(default_factory=utc_now)
    ended_at: datetime = field(default_factory=utc_now)
    duration_seconds: float = 0.0
    latency_ms: float | None = None
    error_message: str | None = None
    error_code: str | None = None
    exception_type: str | None = None
    exception_details: str | None = None
    stack_trace: str | None = None
    remediation: str | None = None
    warnings: list[str] = field(default_factory=list)
    attempts: int = 1
    details: dict[str, Any] = field(default_factory=dict)
    tags: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Redact every field populated at construction time."""
        self.redact()

    def redact(self) -> None:
        """Scrub credentials from every free-text and structured field.

        Must be re-applied after any post-construction mutation. The connector
        framework populates ``error_message``, ``details`` and ``stack_trace``
        *after* the result is built, from driver exceptions and from probe
        evidence, and those assignments bypass ``__post_init__`` entirely. A
        redaction that only ran at construction would therefore protect
        nothing that actually matters.

        Two passes are applied to text: pattern redaction, which catches
        ``password=...`` and URL userinfo, and registry scrubbing, which
        removes the exact plaintext values the framework decrypted for this
        run. The second pass is what catches a driver that echoes a credential
        back without any recognisable prefix.

        Idempotent: masked text contains nothing further to mask.
        """
        if self.error_message:
            self.error_message = _scrub(self.error_message)
        if self.exception_details:
            self.exception_details = _scrub(self.exception_details)
        if self.stack_trace:
            self.stack_trace = _scrub(self.stack_trace)
        if self.remediation:
            self.remediation = _scrub(self.remediation)
        if self.details:
            self.details = redact_mapping(self.details)
            for key, value in self.details.items():
                if isinstance(value, str):
                    self.details[key] = secret_registry.scrub(value)
        if self.warnings:
            self.warnings = [_scrub(warning) for warning in self.warnings]

    @property
    def is_success(self) -> bool:
        """Return ``True`` when the interface validated cleanly."""
        return self.status is ValidationStatus.SUCCESS

    @property
    def is_failure(self) -> bool:
        """Return ``True`` when the interface failed and must fail the run."""
        return self.status is ValidationStatus.FAILED

    @property
    def is_skipped(self) -> bool:
        """Return ``True`` when the interface was disabled and not dialled."""
        return self.status is ValidationStatus.SKIPPED

    @property
    def has_warnings(self) -> bool:
        """Return ``True`` when non-fatal observations were recorded."""
        return bool(self.warnings)

    @property
    def duration_display(self) -> str:
        """Return the total duration formatted for a report."""
        return format_duration(self.duration_seconds)

    @property
    def latency_display(self) -> str:
        """Return the connect latency formatted for a report."""
        if self.latency_ms is None:
            return "n/a"
        return f"{self.latency_ms:.0f} ms"

    def add_warning(self, message: str) -> None:
        """Record a non-fatal observation, redacted on the way in."""
        self.warnings.append(_scrub(message))

    def to_dict(self, *, include_stack_trace: bool = True) -> dict[str, Any]:
        """Return a JSON-serialisable representation.

        Args:
            include_stack_trace: Omit the traceback for the PDF report and the
                e-mail body, where it is noise; keep it for the JSON report,
                where it is the payload an engineer actually wants.
        """
        payload: dict[str, Any] = {
            "interface_name": self.interface_name,
            "interface_type": self.interface_type.value,
            "category": self.category.value,
            "status": self.status.value,
            "host": self.host,
            "port": self.port,
            "endpoint": self.endpoint,
            "auth_method": self.auth_method.value,
            "started_at": self.started_at.isoformat(),
            "ended_at": self.ended_at.isoformat(),
            "duration_seconds": round(self.duration_seconds, 3),
            "duration_display": self.duration_display,
            "latency_ms": self.latency_ms,
            "attempts": self.attempts,
            "warnings": list(self.warnings),
            "tags": list(self.tags),
            "details": dict(self.details),
        }
        if self.error_message:
            payload["error"] = {
                "message": self.error_message,
                "code": self.error_code,
                "exception_type": self.exception_type,
                "details": self.exception_details,
                "remediation": self.remediation,
            }
            if include_stack_trace and self.stack_trace:
                payload["error"]["stack_trace"] = self.stack_trace
        return payload

    def to_row(self) -> dict[str, Any]:
        """Return a flat representation for the Excel worksheets."""
        return {
            "Interface Name": self.interface_name,
            "Type": self.interface_type.value,
            "Category": self.category.value,
            "Host": self.host,
            "Port": self.port if self.port is not None else "",
            "Endpoint": self.endpoint,
            "Authentication": self.auth_method.value,
            "Status": self.status.value,
            "Start Time": self.started_at.replace(tzinfo=None),
            "End Time": self.ended_at.replace(tzinfo=None),
            "Duration (s)": round(self.duration_seconds, 3),
            "Latency (ms)": self.latency_ms if self.latency_ms is not None else "",
            "Attempts": self.attempts,
            "Error Code": self.error_code or "",
            "Error Message": self.error_message or "",
            "Remediation": self.remediation or "",
            "Warnings": "; ".join(self.warnings),
            "Tags": ", ".join(self.tags),
        }


@dataclass(slots=True)
class ExecutionSummary:
    """Aggregate outcome of one validation run.

    The summary is what the executive dashboard, the e-mail subject line and
    the process exit code are all derived from, so the counting rules live here
    once rather than being re-implemented per consumer.
    """

    run_id: str
    started_at: datetime
    ended_at: datetime
    duration_seconds: float
    results: list[ValidationResult] = field(default_factory=list)
    platform: PlatformInfo | None = None
    config_path: str = ""
    environment: str = "production"
    cleanup_deleted_files: int = 0
    cleanup_errors: list[str] = field(default_factory=list)
    report_paths: dict[str, str] = field(default_factory=dict)
    notification_sent: bool = False
    notification_error: str | None = None

    # -- counts -------------------------------------------------------------

    @property
    def total_interfaces(self) -> int:
        """Return the number of interfaces present in the configuration."""
        return len(self.results)

    @property
    def validated_interfaces(self) -> int:
        """Return the number of interfaces actually dialled.

        Skipped interfaces are excluded so that disabling an interface cannot
        quietly improve the success percentage.
        """
        return sum(1 for result in self.results if not result.is_skipped)

    @property
    def passed(self) -> int:
        """Return the number of interfaces that validated cleanly."""
        return sum(1 for result in self.results if result.is_success)

    @property
    def failed(self) -> int:
        """Return the number of interfaces that failed."""
        return sum(1 for result in self.results if result.is_failure)

    @property
    def skipped(self) -> int:
        """Return the number of disabled interfaces."""
        return sum(1 for result in self.results if result.is_skipped)

    @property
    def with_warnings(self) -> int:
        """Return the number of interfaces that recorded a warning."""
        return sum(1 for result in self.results if result.has_warnings)

    @property
    def has_failures(self) -> bool:
        """Return ``True`` when at least one interface failed."""
        return self.failed > 0

    # -- derived indicators -------------------------------------------------

    @property
    def success_percentage(self) -> float:
        """Return the pass rate over dialled interfaces, 0-100.

        A run in which every interface is disabled reports 100 percent: nothing
        was asked of the estate and nothing failed. The report shows the
        skipped count alongside, so the number is never read without context.
        """
        if self.validated_interfaces == 0:
            return 100.0
        return round((self.passed / self.validated_interfaces) * 100.0, 2)

    @property
    def severity(self) -> SeverityBand:
        """Return the colour band for the executive summary."""
        if not self.has_failures:
            return SeverityBand.HEALTHY
        if self.success_percentage >= DEGRADED_THRESHOLD_PERCENT:
            return SeverityBand.DEGRADED
        return SeverityBand.CRITICAL

    @property
    def is_healthy(self) -> bool:
        """Return ``True`` when the pass rate is a clean sweep."""
        return self.success_percentage >= HEALTHY_THRESHOLD_PERCENT and not self.has_failures

    @property
    def status_word(self) -> str:
        """Return SUCCESS or FAILED, used in the e-mail subject line."""
        return "FAILED" if self.has_failures else "SUCCESS"

    @property
    def duration_display(self) -> str:
        """Return the run duration formatted for a report."""
        return format_duration(self.duration_seconds)

    # -- breakdowns ---------------------------------------------------------

    @property
    def failed_results(self) -> list[ValidationResult]:
        """Return failures, slowest first: the worst offender leads the report."""
        return sorted(
            (result for result in self.results if result.is_failure),
            key=lambda result: result.duration_seconds,
            reverse=True,
        )

    @property
    def successful_results(self) -> list[ValidationResult]:
        """Return successes, slowest first, surfacing latency creep."""
        return sorted(
            (result for result in self.results if result.is_success),
            key=lambda result: result.duration_seconds,
            reverse=True,
        )

    @property
    def skipped_results(self) -> list[ValidationResult]:
        """Return the disabled interfaces."""
        return [result for result in self.results if result.is_skipped]

    def counts_by_type(self) -> dict[str, dict[str, int]]:
        """Return pass/fail/skip counts grouped by connectivity type."""
        breakdown: dict[str, dict[str, int]] = {}
        for result in self.results:
            entry = breakdown.setdefault(
                result.interface_type.value,
                {"total": 0, "passed": 0, "failed": 0, "skipped": 0},
            )
            entry["total"] += 1
            if result.is_success:
                entry["passed"] += 1
            elif result.is_failure:
                entry["failed"] += 1
            else:
                entry["skipped"] += 1
        return breakdown

    def counts_by_category(self) -> dict[str, dict[str, int]]:
        """Return pass/fail/skip counts grouped by category."""
        breakdown: dict[str, dict[str, int]] = {}
        for result in self.results:
            entry = breakdown.setdefault(
                result.category.value,
                {"total": 0, "passed": 0, "failed": 0, "skipped": 0},
            )
            entry["total"] += 1
            if result.is_success:
                entry["passed"] += 1
            elif result.is_failure:
                entry["failed"] += 1
            else:
                entry["skipped"] += 1
        return breakdown

    def counts_by_error_code(self) -> dict[str, int]:
        """Return failure counts grouped by error code, most frequent first.

        A single dominant code across many interfaces is the signature of one
        infrastructure change rather than several unrelated faults, which is
        the first thing worth knowing after a patching window.
        """
        counter = Counter(
            result.error_code or "UNCLASSIFIED"
            for result in self.results
            if result.is_failure
        )
        return dict(counter.most_common())

    @property
    def slowest_result(self) -> ValidationResult | None:
        """Return the interface that took longest, if any ran."""
        dialled = [result for result in self.results if not result.is_skipped]
        return max(dialled, key=lambda result: result.duration_seconds, default=None)

    @property
    def average_latency_ms(self) -> float | None:
        """Return the mean connect latency across successful interfaces."""
        latencies = [
            result.latency_ms
            for result in self.results
            if result.is_success and result.latency_ms is not None
        ]
        if not latencies:
            return None
        return round(sum(latencies) / len(latencies), 2)

    # -- serialisation ------------------------------------------------------

    def to_dict(self, *, include_stack_trace: bool = True) -> dict[str, Any]:
        """Return the complete JSON report payload."""
        return {
            "run_id": self.run_id,
            "environment": self.environment,
            "config_path": self.config_path,
            "started_at": self.started_at.isoformat(),
            "ended_at": self.ended_at.isoformat(),
            "duration_seconds": round(self.duration_seconds, 3),
            "duration_display": self.duration_display,
            "summary": {
                "total_interfaces": self.total_interfaces,
                "validated": self.validated_interfaces,
                "passed": self.passed,
                "failed": self.failed,
                "skipped": self.skipped,
                "with_warnings": self.with_warnings,
                "success_percentage": self.success_percentage,
                "severity": self.severity.value,
                "status": self.status_word,
                "average_latency_ms": self.average_latency_ms,
            },
            "statistics": {
                "by_type": self.counts_by_type(),
                "by_category": self.counts_by_category(),
                "by_error_code": self.counts_by_error_code(),
                "slowest_interface": (
                    self.slowest_result.interface_name if self.slowest_result else None
                ),
            },
            "environment_details": (self.platform.to_dict() if self.platform else None),
            "housekeeping": {
                "reports_deleted": self.cleanup_deleted_files,
                "cleanup_errors": list(self.cleanup_errors),
            },
            "notification": {
                "sent": self.notification_sent,
                "error": self.notification_error,
            },
            "reports": dict(self.report_paths),
            "results": [
                result.to_dict(include_stack_trace=include_stack_trace)
                for result in self.results
            ],
        }
