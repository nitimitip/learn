# Enterprise Connectivity Validation Framework

Validates every configured external connection after an infrastructure change,
and tells you which ones broke and what to do about each.

Built for the hour after a change window: server patching, operating system
upgrades, SSH algorithm and cipher changes, OpenSSL updates, certificate
renewal, firewall changes, authentication changes and migrations. It runs as an
unattended batch job, produces evidence in three formats, e-mails the outcome,
and returns an exit code a scheduler can branch on.

| | |
|---|---|
| **Python** | 3.11+ (tested on 3.11, 3.12, 3.13) |
| **Platforms** | IBM AIX, Linux (RHEL, Oracle Linux, Ubuntu, SUSE, CentOS), Windows |
| **Connectivity types** | 11 across File Transfer, Database, Cloud and API |
| **Interface** | Command line only; no GUI, no daemon |
| **Tests** | 386 passing, 77% statement coverage |

---

## Table of contents

1. [What it actually checks](#what-it-actually-checks)
2. [Installation](#installation)
3. [Quick start](#quick-start)
4. [Architecture overview](#architecture-overview)
5. [Supported connectivity types](#supported-connectivity-types)
6. [Configuration guide](#configuration-guide)
7. [Encryption guide](#encryption-guide)
8. [Execution guide](#execution-guide)
9. [Scheduler integration](#scheduler-integration)
10. [Reports](#reports)
11. [E-mail notification](#e-mail-notification)
12. [Logging](#logging)
13. [Report retention](#report-retention)
14. [Troubleshooting](#troubleshooting)
15. [FAQ](#faq)
16. [Security best practices](#security-best-practices)
17. [Adding a new connectivity type](#adding-a-new-connectivity-type)
18. [Development](#development)

---

## What it actually checks

Connecting is not the same as working. Every connector performs a **probe**
after the connection succeeds, because the gap between the two is where
post-change failures live:

| Type | Connecting proves | The probe additionally proves |
|---|---|---|
| SFTP | SSH authentication succeeded | The SFTP subsystem opens and the directory is readable |
| SSH | The account authenticated | A session channel opens; the validation command exits zero |
| FTP / FTPS | The control channel works | The **data channel** works — `NLST` forces one |
| Oracle | The listener answered | The instance is open and the validation query returns; optionally, that every **database link** still opens |
| SQL Server | The login succeeded | The target database is reachable by this account |
| Azure Blob | The credential is valid | It is authorised for **the container the job uses** |
| S3 | The credential resolves | It is authorised for **the bucket the job uses** |
| REST | A load balancer answered | The status code matches *and* the body contains what it should |
| SOAP | The endpoint responded | The WSDL parses and declares a real service |

Three examples of what that catches, all of which would pass a naive check:

- An FTP firewall rule that opened port 21 but not the passive data range.
- An HTTP 200 that is a maintenance page, not the application.
- A WSDL URL returning a login portal that is well-formed enough to parse.

Successful runs also record **evidence**: the negotiated SSH cipher and MAC,
the TLS version and certificate expiry, the server banner and version. That is
what makes a *passing* run meaningful after a cipher change — it proves which
algorithms were actually used, not merely that something connected.

---

## Installation

### 1. Core installation

```bash
git clone <your-internal-repository> connectivity-validator
cd connectivity-validator

python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

pip install -r requirements.txt
```

The core requirements are pure Python or ship broad wheels, which keeps
installation viable on AIX where compilers are often unavailable:

`cryptography`, `pydantic`, `rich`, `questionary`, `Jinja2`, `XlsxWriter`,
`reportlab`.

> **No pandas.** Excel reports use `XlsxWriter` alone. `pandas` carries
> compiled NumPy binaries that frequently have no AIX wheel, and would make a
> supported platform an install fight for no functional gain.

### 2. Connectivity drivers — install only what you validate

Drivers are optional and imported lazily. A site validating only SFTP and REST
must not be blocked by a `pyodbc` build failure.

| You validate | Install |
|---|---|
| SFTP, SCP, SSH | `pip install "paramiko>=3.4,<4.0"` |
| FTP, FTPS | *(nothing — standard library)* |
| Oracle | `pip install "oracledb>=2.1,<4.0"` |
| SQL Server | `pip install "pyodbc>=5.1,<6.0"` + platform ODBC driver |
| Azure Blob | `pip install "azure-storage-blob>=12.19,<13.0" "azure-identity>=1.16,<2.0"` |
| Amazon S3 | `pip install "boto3>=1.34,<2.0"` |
| REST | `pip install "requests>=2.31,<3.0"` |
| SOAP | `pip install "zeep>=4.2,<5.0"` |

Or use extras:

```bash
pip install ".[ssh,oracle,rest]"
pip install ".[all]"
pip install -r requirements-optional.txt
```

A missing driver fails **that one interface** with the exact `pip` command
needed — it never stops the run.

### 3. Platform notes

**Oracle** — `python-oracledb` runs in *thin* mode by default and needs **no
Oracle Instant Client**. Thick mode is available for wallet-based
authentication (`use_thick_mode: true`) and does require the client libraries.

**SQL Server** — `pyodbc` needs a driver manager (`unixODBC` on Linux/AIX) plus
Microsoft ODBC Driver 17 or 18. If the driver is missing, the framework reports
`DRIVER_NOT_AVAILABLE` **and lists the drivers actually installed**.

**AIX** — everything in the core set installs. `pyodbc` and `cryptography` need
a compiler if no wheel is published for your AIX/Python combination.

---

## Quick start

```bash
# 1. Build a configuration interactively. Secrets are encrypted on save.
python generate_config.py

# 2. Confirm it is valid without contacting anything.
python connectivity_validator.py --config config/production_connectivity.json --dry-run

# 3. Run it for real.
python connectivity_validator.py --config config/production_connectivity.json
```

---

## Architecture overview

```
generate_config.py                connectivity_validator.py
        |                                    |
   core/wizard*                          core/cli
        |                                    |
        |                            core/config_loader  --> core/encryption
        |                                    |
        +------> config/*.json <-------------+
                                             |
                                        core/engine
                                             |
                                    connectors/factory
                                             |
                        +--------------------+--------------------+
                        |          |         |         |          |
                  file_transfer  database  cloud     api      (future)
                        |          |         |         |
                        +----------+---------+---------+
                                   |
                          models/results.py
                                   |
              +--------------------+--------------------+
              |                    |                    |
       core/reporting        core/notifier         core/cleanup
      (PDF/Excel/JSON)        (SMTP e-mail)      (15-day retention)
```

**Layering rule:** `connectors -> core -> models -> utilities`. Nothing in
`core` imports `connectors` at module load; the engine reaches connectors only
through the factory. `utilities` depends on nothing internal, so the wizard can
reuse it freely.

### Package responsibilities

| Package | Contains |
|---|---|
| `core/` | constants, exceptions, encryption, logging, config loader, engine, reporting, `pdf_report`, `theme` (brand palette), notifier, cleanup, CLI, wizard |
| `models/` | `interfaces` (per-type config), `settings` (app/email/logging/reports/execution), `results` |
| `connectors/` | `base` (template method), `factory` (registry), `support` (shared), `oracle_links` (database link probing), and one module per category |
| `utilities/` | masking, platform info, timing, filesystem, validators, SSH discovery |
| `templates/` | Jinja2 template for the HTML e-mail (the PDF report is built in `core/pdf_report.py`) |

### Design patterns

- **Template Method** — `BaseConnector.validate()` owns timing, retries,
  classification, redaction and logging. Subclasses implement three hooks:
  `_open()`, `_probe()`, `_close()`.
- **Factory + Registry** — connectors self-register with `@register`; the
  engine contains no per-type branch. Modules are imported lazily, so
  `connectors.database` (and therefore `oracledb`/`pyodbc`) is never loaded by
  a site that validates only SFTP.
- **Strategy** — the discriminated union in `models/interfaces.py` selects the
  configuration model, and therefore the connector, from the `type` field.
- **Dependency injection** — the engine receives a `LoadedConfiguration`;
  connectors receive already-resolved secrets. Connectors never decrypt, so a
  key problem is reported once against the run, not as an apparently unrelated
  failure on each interface.

### Guarantees

1. **Every configured interface produces exactly one result.** Disabled ones
   are `SKIPPED`; ones with an undecryptable secret or no connector are
   `FAILED` with that reason. An interface can never silently vanish from a
   report — a missing row is indistinguishable from a passing one.
2. **A failure never stops the run.** `validate()` never raises.
3. **Results are ordered as configured**, not by completion order, so two runs
   across a change window diff cleanly.
4. **The run is bounded.** Each interface has a hard backstop deadline, and the
   whole run has an optional ceiling.

---

## Supported connectivity types

| Category | Type | `type` value | Default port | Driver |
|---|---|---|---|---|
| File Transfer | SFTP | `SFTP` | 22 | paramiko |
| | SCP | `SCP` | 22 | paramiko |
| | SSH | `SSH` | 22 | paramiko |
| | FTP | `FTP` | 21 | *stdlib* |
| | FTPS | `FTPS` | 21 | *stdlib* |
| Database | Oracle | `ORACLE` | 1521 | oracledb |
| | SQL Server | `MSSQL` | 1433 | pyodbc |
| Cloud | Azure Blob | `AZURE_BLOB` | 443 | azure-storage-blob, azure-identity |
| | Amazon S3 | `AWS_S3` | 443 | boto3 |
| API | REST | `REST` | from URL | requests |
| | SOAP | `SOAP` | from URL | zeep |

**Authentication supported:** password; SSH private key (explicit or
auto-discovered) with passphrase; SSH agent; anonymous FTP; SQL and Windows
authentication; Azure connection string, service principal and managed
identity; AWS access key and IAM role (with optional `assume_role`); HTTP
basic, bearer and API-key header; SOAP basic.

---

## Configuration guide

**Configuration is generated, never hand-edited.** The wizard applies the same
validators the loader enforces, so a value it accepts cannot be rejected later.

```bash
python generate_config.py
python generate_config.py --config-dir /opt/connectivity/config
```

### Wizard flow

1. **Configuration file name.** If it already exists you may overwrite it,
   choose another name, or **add** to it — appending reuses the existing key so
   previously stored secrets keep working and are never re-prompted.
2. **E-mail notification** — relay, port, security, optional credentials,
   sender, recipients, Cc, Bcc.
3. **Interfaces** — pick a category, then a type, answer its questions, then
   `1. Yes` / `2. Done`.
4. **Advanced settings** (optional) — reports, logging, execution.
5. **Review and save.**

### Configuration file shape

```jsonc
{
  "schema_version": "1.0",
  "environment": "production",
  "email":    { "enabled": true, "smtp_server": "...", "recipients": ["..."] },
  "logging":  { "directory": "logs", "level": "INFO" },
  "reports":  { "directory": "reports", "retention_days": 15 },
  "execution": {
    "parallel_enabled": true,
    "max_workers": 8,
    "global_timeout_seconds": 900,
    "strict_secrets": false,
    "fail_on_warning": false
  },
  "interfaces": [
    {
      "type": "SFTP",
      "name": "Payments SFTP",
      "host": "sftp.bank.example",
      "port": 22,
      "username": "svc_payments",
      "password": null,
      "private_key_path": "/opt/connectivity/keys/id_ed25519",
      "key_passphrase": "ENC(gAAAAAB...)",
      "known_hosts_path": "/opt/connectivity/keys/known_hosts",
      "host_key_policy": "reject",
      "preferred_ciphers": ["aes256-gcm@openssh.com"],
      "remote_path": "/outbound",
      "timeout_seconds": 30,
      "enabled": true,
      "tags": ["tier-1", "payments"]
    }
  ]
}
```

Relative `directory` values resolve **against the configuration file's project
root**, not the process working directory — so a scheduler starting the job
from `/` still writes reports where you expect.

A complete example covering all eleven types is in
[`samples/sample_connectivity.json`](samples/sample_connectivity.json).

### Settings worth knowing

| Setting | Default | Why you would change it |
|---|---|---|
| `execution.parallel_enabled` | `true` | Sequential makes a large estate slow but the log easier to follow |
| `execution.max_workers` | `8` | Raise for a large estate; connectors are I/O bound |
| `execution.global_timeout_seconds` | none | Set it to protect a fixed scheduler window |
| `execution.strict_secrets` | `false` | `true` refuses to run if any secret is stored in plaintext |
| `execution.fail_on_warning` | `false` | `true` treats an unverified host key or expiring certificate as a failure |
| `reports.retention_days` | `15` | Retention for generated reports |
| `host_key_policy` | `warn` | `reject` for pinned production endpoints |
| `verify_ssl` | `true` | Leave on — disabling hides the certificate failures you scheduled this to catch |
| `trust_server_certificate` (MSSQL) | `false` | Leave off for the same reason |
| `check_db_links` (Oracle) | `false` | `true` also opens every database link the account owns |

### Oracle database links

A database link is the one hop nothing else in this framework can see. The
listener answers, the account logs in, `SELECT 1 FROM DUAL` returns — and the
overnight reconciliation still fails, because the link it reads through points
at a database that was rebuilt, a remote password that was rotated, or a TNS
alias that no longer resolves **on the database server**.

That last point is why the check is worth running: the link is opened by the
Oracle server process, not by this host, so it exercises a path no probe run
from here can reach.

With `check_db_links` enabled the connector reads `USER_DB_LINKS` (or
`ALL_DB_LINKS`) after the validation query and opens each link it finds with
`SELECT 'X' FROM dual@<link>`. Listing a link proves only that a row exists;
the row outlives the remote database indefinitely, so each one is opened.

```jsonc
{
  "type": "ORACLE",
  "name": "Core Banking Oracle",
  "host": "ora-core01.corp.example",
  "service_name": "COREPDB1",
  "username": "app_reconciliation",
  "password": "ENV(CONNVAL_ORACLE_PASSWORD)",
  "validation_query": "SELECT 1 FROM DUAL",

  "check_db_links": true,          // off by default
  "db_link_scope": "user",         // "user" = USER_DB_LINKS, "all" = ALL_DB_LINKS
  "db_link_names": [],             // [] checks every link found
  "db_link_timeout_seconds": 15,   // ceiling for one link
  "db_link_budget_seconds": 120,   // ceiling for all links on this interface
  "db_link_max_links": 25,
  "fail_on_broken_db_link": true   // false records broken links as warnings
}
```

| Setting | Default | Why you would change it |
|---|---|---|
| `db_link_scope` | `user` | `all` adds public links and links owned by other schemas. Only public ones can be opened by this session; the rest are reported **present but unchecked**, never as false failures |
| `db_link_names` | `[]` | Name the links the job actually uses. A name listed here but **absent** from the data dictionary fails the interface — which is how a link dropped during a schema refresh is caught |
| `db_link_timeout_seconds` | `15` | Applied as the session `call_timeout`. A dead remote listener costs this many seconds, not the run |
| `db_link_budget_seconds` | `120` | Wall-clock ceiling for the whole sweep. Links not reached within it are reported as unchecked |
| `db_link_max_links` | `25` | Raise for a schema with many links; the excess is reported, not silently dropped |
| `fail_on_broken_db_link` | `true` | `false` for an estate with known-decommissioned links: they become warnings and the interface still passes |

A link failure gets its own error code, **`DB_LINK_FAILED`**, so the report's
*Failures by cause* breakdown separates it from a local database problem. The
interface reports the whole picture either way: the links that passed are
listed alongside the ones that did not, which is what distinguishes one dead
remote database from a name resolution failure on the server.

Two things the check will not do: probe a link private to another schema (this
session cannot open it), and keep going after a cancelled call leaves the
session unusable — the remaining links are reported as unchecked, because a
cascade of identical errors would bury the first real one.

---

## Encryption guide

Secrets are stored in one of three envelope forms:

```jsonc
"password": "ENC(gAAAAABm...)"      // Fernet ciphertext, unlocked by encryption.key
"password": "ENV(SFTP_PASSWORD)"    // read from the process environment at run time
"password": "hunter2"               // plaintext: warned about, refused in strict mode
```

- **Algorithm** — Fernet (AES-128-CBC + HMAC-SHA256) via `cryptography`.
  Ciphertext is authenticated, so a tampered configuration fails loudly rather
  than silently yielding a wrong credential.
- **Key file** — `encryption.key`, written beside the configuration with
  owner-only permissions (`0600` on POSIX).

> **Back up `encryption.key` together with the configuration it protects.**
> A configuration without its key cannot be recovered; the secrets must be
> re-entered.

### Key rotation

The key file holds one key per line. The first is the primary (used to
encrypt); the rest are retired keys kept so existing secrets stay readable.

```python
from pathlib import Path
from core.config_loader import load_configuration, save_configuration
from core.encryption import EncryptionKeyManager

config_path = Path("config/production_connectivity.json")
loaded  = load_configuration(config_path)
rotated = EncryptionKeyManager(loaded.key_path).rotate()   # prepends a new key

for interface in loaded.config.interfaces:
    for field in interface.SECRET_FIELDS:
        current = getattr(interface, field, None)
        if current:
            setattr(interface, field, rotated.reencrypt(current))

save_configuration(loaded.config, config_path, create_key=False)
# Once every secret is migrated, the retired key lines can be removed.
```

### The `ENV()` form

For sites whose policy forbids credentials on disk in any form. An external
vault injects the secret into the scheduler's process environment and the
configuration records only the variable name. Combine with
`execution.strict_secrets: true`.

### Partial vs total decryption failure

- **All** protected secrets fail → **fatal, exit 2.** The configuration and key
  do not belong together (usually copied without `encryption.key`). Nothing
  can be tested, and a run that dialled nothing must not look like a run that
  found nothing wrong.
- **Some** fail → warning; those interfaces fail individually while the rest
  still run. Aborting would discard the verdict on every healthy interface.

---

## Execution guide

```bash
python connectivity_validator.py --config config/production_connectivity.json
```

| Option | Purpose |
|---|---|
| `--config PATH` | **Required.** The JSON configuration. |
| `--key PATH` | Encryption key override. Defaults to `encryption.key` beside the config. |
| `--interface NAME` | Validate only this interface. Repeatable. |
| `--tag TAG` | Validate only interfaces carrying this tag. Repeatable. |
| `--dry-run` | Validate the configuration and decrypt every secret; contact nothing. |
| `--list` | List configured interfaces and exit. |
| `--log-level LEVEL` | Override the configured level. |
| `--quiet` | Suppress the console summary; logs and reports still written. |
| `--no-color` | Disable ANSI, for job logs that do not render it. |
| `--version` | Print the version. |

### Exit codes

| Code | Meaning | Scheduler should |
|---|---|---|
| `0` | All enabled interfaces passed | Nothing |
| `1` | One or more interfaces failed | **Raise an incident** — the estate has a problem |
| `2` | Configuration error; **nothing was validated** | **Alert the owning team** — the job is misconfigured |
| `99` | Unexpected application error | Raise a defect; treat every interface as unverified |

The `1` / `2` distinction matters: `2` means the run proved nothing. A filter
matching no interface (`--interface "Typo"`) also exits `2`, because a green
job that silently tested nothing is the worst possible outcome.

### Troubleshooting one endpoint

```bash
python connectivity_validator.py --config config/prod.json \
    --interface "Payments SFTP" --log-level DEBUG
```

---

## Scheduler integration

### cron (Linux / AIX)

```cron
# Daily at 06:15. cron gives you almost no environment, so be explicit.
15 6 * * * cd /opt/connectivity && /opt/connectivity/.venv/bin/python \
    connectivity_validator.py --config config/production_connectivity.json \
    --no-color >> /var/log/connectivity/cron.log 2>&1
```

### Windows Task Scheduler

```
Program:    C:\connectivity\.venv\Scripts\python.exe
Arguments:  connectivity_validator.py --config config\production_connectivity.json --no-color
Start in:   C:\connectivity
```

Run as a service account with **Run whether user is logged on or not**.

### Control-M / AutoSys / IBM Workload Scheduler / UC4

Branch on the exit code. A typical mapping:

```
0   -> OK
1   -> ABEND, notify the integration on-call group
2   -> ABEND, notify the platform team (configuration fault)
99  -> ABEND, raise a defect
```

### Jenkins

```groovy
stage('Connectivity validation') {
    steps {
        script {
            def code = sh(returnStatus: true, script: '''
                . .venv/bin/activate
                python connectivity_validator.py --config config/prod.json --no-color
            ''')
            if (code == 2 || code == 99) { error("Validation could not run (exit ${code})") }
            if (code == 1) { unstable("One or more interfaces failed") }
        }
    }
    post { always { archiveArtifacts artifacts: 'reports/*', allowEmptyArchive: true } }
}
```

### Azure DevOps

```yaml
- script: |
    python connectivity_validator.py --config config/prod.json --no-color
  displayName: Connectivity validation
  continueOnError: true
- task: PublishBuildArtifacts@1
  inputs: { PathtoPublish: reports, ArtifactName: connectivity-reports }
  condition: always()
```

### Scheduler checklist

- Use an **absolute** interpreter path; the service account's `PATH` differs.
- The job's environment is **not** your interactive shell — `ENV()` secrets and
  proxy variables must be set in the job definition.
- Under a scheduler there is normally **no SSH agent**; configure a password or
  a key path rather than relying on ambient credentials.
- Set `execution.global_timeout_seconds` below the scheduler's own timeout.

---

## Reports

Three formats for three audiences, written to `reports/`:

| Format | Audience | Notes |
|---|---|---|
| **PDF** | Read first, printed, filed against a change record | Northern Powergrid house style, fixed pagination, `Page X of Y`. **Failures print before successes.** |
| **Excel** | The working document | Summary / Successful / Failed / Statistics, plus **Database Links** when any were checked; autofilter, frozen panes, colour-coded status |
| **JSON** | Monitoring pipelines and diffs | Complete record **including stack traces**, which the PDF deliberately omits |

Filenames: `connectivity_report_<environment>_<timestamp>_<runid>.<ext>`.

Every report records the executive summary (total / passed / failed / skipped /
success rate / duration), the hostname, OS, Python version, timestamp and run
identifier, and the per-interface evidence.

Real examples are in [`samples/reports/`](samples/reports/).

**A report is evidence about a run, not part of it.** Each format is generated
independently; if one fails the others are still produced and the exit code is
unchanged.

---

## E-mail notification

Sent after every run, subject to `send_on_success` / `send_on_failure`.

```
Enterprise Connectivity Validation Report - FAILED | PRODUCTION | 2 of 11 failed
Enterprise Connectivity Validation Report - SUCCESS | PRODUCTION
```

The body is `multipart/alternative` — **plain text first**, then HTML. The text
part is not a courtesy: relays that strip HTML, terminal clients and pager
gateways all show it. The HTML is nested tables with inline styles, because
desktop Outlook renders with the Word engine and ignores modern CSS.

It carries the same Northern Powergrid masthead as the attached PDF — a flat
maroon banner and a *text* wordmark, never an image, because Outlook blocks
images by default. Both come from `core/theme.py`, which is the single source
of colour for the PDF, the workbook and the e-mail alike.

Attached in priority order — PDF, Excel, JSON, log — until
`max_attachment_mb` (default 15) is reached. Anything omitted is **named in the
body along with the host it remains on**. When the log alone will not fit, its
**tail** is attached rather than dropping it: the end of the log is where the
failure is. Reports are never truncated — a partial report is misleading
evidence.

Sample output: [`samples/email/`](samples/email/).

> **A delivery failure never changes the exit code.** The verdict is already
> established and on disk; letting SMTP fail the job would raise a connectivity
> incident that does not exist.

---

## Logging

Four rotating logs in `logs/`:

| File | Level | Purpose |
|---|---|---|
| `application.log` | INFO+ | The operational narrative |
| `error.log` | ERROR+ | Failures only — open this first |
| `audit.log` | INFO | Who ran what, against which configuration, with what outcome |
| `debug.log` | DEBUG | Everything, including driver detail |

Every record carries timestamp, level, correlation ID, interface name, logger,
module, function, line and message. Correlation ID and interface name live in
`contextvars`, so grepping one interface out of a parallel run is a single
`grep`.

**Secrets are never logged.** Three layers: structural redaction of
secret-shaped keys, pattern redaction of `password=`, URL userinfo and
`Authorization` headers, and a registry that scrubs the exact plaintext values
the framework decrypted — which catches a credential echoed back by a
third-party driver.

---

## Report retention

Reports older than `retention_days` (default 15) are deleted **before** each
run, so a run always begins by making room for its own output.

Deletion requires **all five** conditions: the file sits directly in the
reports directory (never a subdirectory), its name starts with
`connectivity_report_`, its extension is `.pdf`/`.xlsx`/`.json` (or a legacy
`.html` report from an earlier version), it is a regular file (never a
symlink), and it is older than the retention period.

The prefix **and** extension together are the safety gate — the framework can
only delete files it demonstrably created. `connectivity_report_notes.docx`
survives; so does anything else you put there. Every deletion is logged.
Cleanup failures are recorded and never block validation.

---

## Troubleshooting

### Configuration and startup

| Symptom | Cause | Fix |
|---|---|---|
| `Encryption key file not found` | Config copied without its key | Copy `encryption.key` alongside it, or regenerate on this host |
| `None of the N stored secrets could be decrypted` | Config and key do not match | As above — they are a pair |
| `Configuration file is not valid JSON` | Hand-edited | Regenerate with `generate_config.py` |
| Exit 2 with `No interface matches` | Typo in `--interface` | `--list` shows the configured names |
| Wizard says it needs an interactive terminal | Started by a scheduler | The wizard is interactive by design; only the validator is for schedulers |

### Connectivity

| Error code | Most likely cause |
|---|---|
| `CONNECTION_FAILED` "refused" | Service did not restart after the patch |
| `TIMEOUT` | Firewall **dropping** rather than rejecting — the classic firewall-change symptom |
| `CONNECTION_FAILED` "could not be resolved" | DNS works elsewhere but not on this host |
| `AUTHENTICATION_FAILED` | Credential rejected — **never retried**, to avoid account lockout |
| `CERTIFICATE_VALIDATION_FAILED` | Certificate renewed, or an OpenSSL/cipher policy change |
| `VALIDATION_PROBE_FAILED` | Connected but not usable: missing path, wrong status, lost grant |
| `DRIVER_NOT_AVAILABLE` | Optional driver missing on this host (message names the `pip` command) |
| `GLOBAL_TIMEOUT` | Run ceiling hit; isolate with `--interface` |

### Type-specific

**`ORA-28040: No matching authentication protocol`** — appears after an Oracle
upgrade when the server stops accepting the older protocol the client offers.
**It reads exactly like a wrong password and is not one.** Set
`SQLNET.ALLOWED_LOGON_VERSION_SERVER`, or upgrade the client.

**`DB_LINK_FAILED` with `ORA-02019` or `ORA-12154`** — the local database is
healthy; the connect descriptor stored in the link does not resolve **on the
database server**. Check `tnsnames.ora` on that server, not on the host running
this framework.

**`DB_LINK_FAILED` with `ORA-01017`** — the remote password was rotated. The
credential is stored inside the link, so the link has to be recreated; nothing
in this configuration can fix it.

**SQL Server certificate error after an upgrade** — ODBC Driver 18 changed
`Encrypt` to `yes` by default. Nothing about the database changed. Install the
issuing CA into the host trust store; use `trust_server_certificate` only if
the network is genuinely trusted.

**FTP passes but files do not transfer** — the control channel is fine and the
data channel is blocked. The framework catches this because its probe runs
`NLST`; make sure the firewall permits the passive port range.

**`Managed identity is not available on this host`** — managed identity exists
only inside Azure. Off-cloud, use a service principal or connection string.

**`No AWS credentials could be resolved`** — an instance profile exists only on
EC2/EKS. On-premises, configure an access key or a named profile available to
the account that runs the job.

**SSH: `host key ... has CHANGED`** — refused under **every** policy, including
`auto_add`. If the server was legitimately rebuilt, remove the stale
`known_hosts` entry. If it was not, escalate before connecting.

**SSH: `algorithm negotiation failed`** — the expected symptom after SSH
hardening. Compare the algorithms the server now offers with your pinned list.

---

## FAQ

**Does it modify anything on the remote systems?**
No. Every probe is read-only: directory listings, `SELECT 1`, metadata reads,
HTTP requests as configured. SCP uses source mode, which only reads.

**Can I run it against production?**
That is the intended use. It opens one connection per interface and closes it.
Be aware that a wrong password *is* a failed login attempt on the target, which
is exactly why authentication failures are never retried.

**Why is a passing interface showing a warning?**
Warnings surface things a bare pass would hide: an unverified SSH host key, a
certificate expiring within 30 days, clear-text FTP credentials, or a probe
that proved less than it could (no container/bucket named). Set
`execution.fail_on_warning: true` to treat them as failures.

**Why did a disabled interface not improve my success rate?**
Skipped interfaces are excluded from the denominator, so disabling one cannot
quietly improve the percentage. The skipped count always appears alongside.

**Can I validate a subset?**
`--interface NAME` (repeatable) or `--tag TAG`. Both exit `2` if nothing
matches.

**How long does a run take?**
Parallel by default; the estate takes about as long as its slowest interface.
Bound it with `execution.global_timeout_seconds`.

**Does it need inbound firewall access, or a daemon?**
Neither. It is an outbound-only batch process with no listening socket.

**Can two runs overlap?**
Yes — each writes uniquely named reports and appends to the rotating logs. If
you would rather they did not, use your scheduler's concurrency control.

**Is the PDF report safe to open?**
Yes. It is a plain document: no JavaScript, no embedded files and no external
asset, and every value is escaped before it is typeset, so a hostile server
banner prints as text rather than reaching the layout engine.

**Why no GUI or database?**
It is a batch job. Its state is the configuration file and its output is the
reports; adding either would create operational burden without adding evidence.

---

## Security best practices

1. **Protect the key file.** `chmod 600 config/encryption.key`, owned by the
   service account. Back it up with the configuration; it is useless apart.
2. **Prefer `ENV()` with a vault** where policy forbids credentials on disk,
   and set `execution.strict_secrets: true`.
3. **Use a dedicated, least-privilege service account** per endpoint. The
   probes need only read access.
4. **Leave `verify_ssl` on** and `trust_server_certificate` off. Disabling them
   hides exactly the certificate failures this framework exists to catch.
5. **Pin SSH host keys** (`host_key_policy: reject` with a `known_hosts` file)
   for production endpoints.
6. **Pin SSH algorithms** after a hardening change. Without pinning the client
   silently negotiates down to whatever is still enabled and the run proves
   nothing.
7. **Restrict the reports directory** — reports contain hostnames, usernames
   and topology. They contain no credentials, by design and by test.
8. **Rotate the encryption key** on the same schedule as other secrets.
9. **Ship `audit.log` to your SIEM.** It is kept free of operational chatter
   precisely so it can be forwarded on its own.
10. **Review warnings.** An expiring certificate is a warning today and an
    outage in two weeks.

---

## Adding a new connectivity type

Four steps; nothing in the engine, reporting or notification layer changes.

**1. Declare the type** in `core/constants.py`:

```python
class InterfaceType(StrEnum):
    ...
    KAFKA = "KAFKA"

INTERFACE_REGISTRY = {
    ...
    InterfaceType.KAFKA: InterfaceSpec(
        InterfaceType.KAFKA, InterfaceCategory.API, "Apache Kafka",
        9092, ("confluent-kafka",), "kafka", True,
    ),
}

INTERFACES_BY_CATEGORY[InterfaceCategory.API] += (InterfaceType.KAFKA,)
```

**2. Add the configuration model** in `models/interfaces.py`, then add it to
the `AnyInterfaceConfig` union:

```python
class KafkaInterfaceConfig(HostPortInterfaceConfig):
    """Kafka broker interface."""

    SECRET_FIELDS: ClassVar[tuple[str, ...]] = ("password",)

    type: Literal[InterfaceType.KAFKA] = InterfaceType.KAFKA
    port: int = Field(default=9092, ge=1, le=65535)
    username: str | None = None
    password: str | None = None
    topic: str | None = None

    @property
    def auth_method(self) -> AuthMethod:
        return AuthMethod.PASSWORD if self.password else AuthMethod.NONE
```

**3. Write the connector.** Implement `_open` and `_probe`; the base class
handles timing, retries, redaction, the deadline and logging.

```python
@register
class KafkaConnector(BaseConnector[KafkaInterfaceConfig]):
    interface_type: ClassVar[InterfaceType] = InterfaceType.KAFKA
    driver_packages: ClassVar[tuple[str, ...]] = ("confluent-kafka",)

    def _open(self) -> Any:
        kafka = require_driver("confluent-kafka", self.interface_type,
                               module_name="confluent_kafka.admin")
        try:
            return kafka.AdminClient({"bootstrap.servers": self.interface.endpoint})
        except OSError as error:
            raise classify_transport_error(
                error, host=self.interface.host, port=self.interface.port,
                timeout_seconds=self.timeout,
            ) from error

    def _probe(self, handle: Any) -> dict[str, Any]:
        metadata = handle.list_topics(timeout=self.timeout)
        if self.interface.topic and self.interface.topic not in metadata.topics:
            raise ValidationProbeError(
                f"Topic '{self.interface.topic}' does not exist on this cluster.",
                remediation="Check the topic name and the account's ACLs.",
            )
        return {"broker_count": len(metadata.brokers),
                "topic_count": len(metadata.topics)}
```

**4. Register the module** in `connectors/factory.py`:

```python
_MODULE_BY_TYPE = {..., InterfaceType.KAFKA: "connectors.messaging"}
```

Optionally add a wizard builder in `core/wizard.py` and register it in
`_BUILDERS`.

### What a good connector does

- **Import its driver lazily**, inside `_open`, via `require_driver`, so a
  missing dependency degrades one interface rather than the framework.
- **Probe beyond the connection.** Ask what the batch job asks.
- **Classify failures.** Map driver errors onto the framework hierarchy with
  remediation that names the likely cause.
- **Mark only transient errors retryable.** Never authentication failures.
- **Record evidence** in the returned dict — negotiated crypto, versions,
  counts. Never secrets.

---

## Development

```bash
pip install -r requirements.txt -r requirements-dev.txt

pytest                                   # 386 tests
pytest -m unit                           # fast, hermetic
pytest -m integration                    # against in-process stub servers
pytest --cov=core --cov=connectors --cov=models --cov=utilities

ruff check core connectors models utilities tests samples *.py
mypy core connectors models utilities connectivity_validator.py generate_config.py
```

The integration tests run **real servers** on loopback ports — SSH/SFTP, FTP,
HTTP with a parseable WSDL, S3 and SMTP — so a pass means a genuine protocol
exchange completed, not that a mock was called.

Regenerate the sample artifacts:

```bash
python samples/generate_samples.py
```

### Project layout

```
connectivity-validator/
├── connectivity_validator.py   Validation entry point
├── generate_config.py          Configuration wizard entry point
├── requirements*.txt           Core / optional / dev dependencies
├── pyproject.toml              Packaging, pytest, ruff, mypy
├── config/                     Generated configuration + encryption.key (git-ignored)
├── reports/                    Generated reports (15-day retention)
├── logs/                       Rotating logs
├── templates/                  HTML e-mail template
├── core/                       Framework services
├── models/                     Configuration and result models
├── connectors/                 One module per connectivity category
├── utilities/                  Dependency-light helpers
├── samples/                    Sample configuration, reports and e-mail
├── docs/                       User guide (Word)
└── tests/                      unit/ and integration/
```

---

## Licence

Proprietary. Internal enterprise use.
