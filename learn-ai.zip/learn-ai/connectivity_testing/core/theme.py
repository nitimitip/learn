"""The Northern Powergrid brand theme, shared by every artefact a run emits.

One identity, three media
------------------------
A validation run produces a PDF report, an Excel workbook and a notification
e-mail. They are read side by side -- the e-mail in Outlook, the PDF attached
to it, the workbook pasted into a change record -- so they must look like
three views of one document rather than three tools that happened to run.
Every colour used by any of them is therefore defined here once, and nowhere
else.

The palette and the e-mail furniture below mirror the NPg App Assist estate
(``email_theme.py`` and the Application Support exports), so a connectivity
report sits alongside those deliverables without looking foreign.

Outlook compatibility
---------------------
The business standard is Outlook, whose desktop client renders HTML with the
Word engine: no external or embedded stylesheets, no flexbox, no grid, no
gradients, no ``rgba()``, no reliable ``border-radius``. The e-mail helpers
here therefore emit nested tables with inline styles, a flat ``bgcolor``
banner rather than a gradient, and a *text* wordmark rather than an image,
because images are blocked by default in many Outlook configurations while
text always renders.

Escaping
--------
:func:`hero_rows` and :func:`footer_rows` return raw HTML fragments that the
caller marks safe. Any value interpolated into them must therefore be escaped
first -- use :func:`esc`. This mirrors the convention in the NPg estate: the
theme owns the markup, the caller owns the data.
"""

from __future__ import annotations

from html import escape as _html_escape

from core.constants import SeverityBand

__all__ = [
    "BAND",
    "BORDER",
    "BRAND_MAROON",
    "BRAND_RED",
    "BRAND_RED_DARK",
    "CHIP_BG",
    "EYEBROW_FG",
    "FAIL",
    "INK",
    "MUTED",
    "ORGANISATION",
    "PASS",
    "SEVERITY_COLOR",
    "SKIP",
    "WARN",
    "WARN_BG",
    "WARN_BORDER",
    "ZEBRA",
    "badge",
    "esc",
    "footer_rows",
    "hero_rows",
    "wordmark",
]

# ---------------------------------------------------------------------------
# Palette (the single source of truth for colour in this framework)
# ---------------------------------------------------------------------------

#: The corporate masthead maroon, matched to NPg's own broadcast e-mails.
BRAND_MAROON: str = "#7A1215"

#: Brand red, used for section bands in the PDF and the Excel title band.
BRAND_RED: str = "#AB1236"

#: The darker brand red, used for column-header rows beneath a section band.
BRAND_RED_DARK: str = "#7E0D27"

#: Eyebrow and footer subtext on the maroon banner: a warm brand pink that
#: stays legible against the deep red.
EYEBROW_FG: str = "#F5A9BE"

#: Pre-blended approximation of rgba(255,255,255,0.18) over the masthead
#: maroon, so chips appear lifted in Outlook, which ignores rgba().
CHIP_BG: str = "#923D3F"

INK: str = "#1D293D"
MUTED: str = "#6B7280"
BAND: str = "#F1F5F9"
ZEBRA: str = "#F8FAFC"
BORDER: str = "#D7DEE7"

# Outcome colours. These stay semantic rather than brand-tinted: a reader must
# be able to tell pass from fail at a glance, and both a maroon header and a
# maroon failure would defeat that.
PASS: str = "#1A7F37"
FAIL: str = "#B3261E"
WARN: str = "#9A6700"
SKIP: str = "#6B7280"

#: Amber callout used for the warnings block.
WARN_BG: str = "#FFF8E6"
WARN_BORDER: str = "#E8D08A"

#: Verdict colour per severity band, shared by the PDF banner, the Excel
#: verdict cell and the e-mail chip.
SEVERITY_COLOR: dict[SeverityBand, str] = {
    SeverityBand.HEALTHY: PASS,
    SeverityBand.DEGRADED: WARN,
    SeverityBand.CRITICAL: FAIL,
}

#: The owning organisation, printed on the masthead and in every footer.
ORGANISATION: str = "Northern Powergrid"

_FONT = "Arial,sans-serif"


# ---------------------------------------------------------------------------
# Escaping
# ---------------------------------------------------------------------------


def esc(value: object) -> str:
    """Return ``value`` as HTML-escaped text, safe to embed in the fragments
    below. Quotes are escaped too, so the result is also attribute-safe."""
    return _html_escape(str(value), quote=True)


# ---------------------------------------------------------------------------
# E-mail building blocks (Outlook-safe: nested tables, inline styles only)
# ---------------------------------------------------------------------------


def badge(bg: str, fg: str, label: str) -> str:
    """Return a chip badge as a tiny table.

    Args:
        bg: Chip background colour.
        fg: Chip text colour.
        label: Pre-escaped, pre-uppercased text. ``border-radius`` is
            progressive enhancement only; Outlook renders a rectangle.
    """
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
        f'style="display:inline-table;">'
        f'<tr><td bgcolor="{bg}" style="background-color:{bg};padding:5px 12px;'
        f"font-family:{_FONT};font-size:11px;font-weight:bold;color:{fg};"
        f"mso-line-height-rule:exactly;line-height:14px;letter-spacing:1px;"
        f'border-radius:20px;">{label}</td></tr>'
        f"</table>"
    )


def wordmark(*, small: bool = False) -> str:
    """Return the NORTHERN POWERGRID wordmark as styled text.

    Never an image: embedded and hosted images are blocked by default in many
    Outlook configurations, and a masthead that disappears in the client the
    business actually uses is not a masthead.
    """
    size, line_height = (10, 12) if small else (13, 15)
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0">'
        f'<tr><td align="right" style="font-family:{_FONT};font-size:{size}px;'
        f"font-weight:bold;font-style:italic;color:#FFFFFF;letter-spacing:2px;"
        f'mso-line-height-rule:exactly;line-height:{line_height}px;">NORTHERN</td></tr>'
        f'<tr><td align="right" style="font-family:{_FONT};font-size:{size}px;'
        f"font-weight:bold;font-style:italic;color:#FFFFFF;letter-spacing:1px;"
        f'mso-line-height-rule:exactly;line-height:{line_height}px;">POWERGRID.</td></tr>'
        f"</table>"
    )


def _banner_td(inner_html: str) -> str:
    """Return a ``<td>`` painted flat masthead maroon.

    ``bgcolor`` is the attribute every engine honours, including desktop
    Outlook's Word renderer; the inline style repeats it for clients that
    prefer CSS. A flat fill is deliberate -- a gradient needs a VML fallback
    and still degrades inconsistently between desktop Outlook and OWA.
    """
    return (
        f'<td bgcolor="{BRAND_MAROON}" '
        f'style="background-color:{BRAND_MAROON};padding:0;">{inner_html}</td>'
    )


def hero_rows(eyebrow: str, title: str, chips: tuple[str, ...] | list[str] = ()) -> str:
    """Return the themed e-mail masthead as ``<tr>`` rows.

    Flat maroon banner, eyebrow and title on the left, the wordmark top right,
    optional chip badges below.

    Args:
        eyebrow: Pre-escaped kicker text, conventionally uppercase.
        title: Pre-escaped headline.
        chips: :func:`badge` fragments; empty entries are dropped.
    """
    kept = [chip for chip in chips if chip]
    chips_html = ""
    if kept:
        cells = "".join(
            f'<td style="padding-right:8px;">{chip}</td>' if index < len(kept) - 1
            else f"<td>{chip}</td>"
            for index, chip in enumerate(kept)
        )
        chips_html = (
            f'<tr><td colspan="2" style="padding-top:14px;">'
            f'<table role="presentation" cellpadding="0" cellspacing="0" '
            f"border=\"0\"><tr>{cells}</tr></table></td></tr>"
        )

    inner = (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr><td style="padding:26px 32px 24px 32px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f"<tr>"
        f'<td style="font-family:{_FONT};font-size:11px;font-weight:bold;'
        f"color:{EYEBROW_FG};mso-line-height-rule:exactly;line-height:14px;"
        f'letter-spacing:2px;padding-bottom:8px;">{eyebrow}</td>'
        f'<td align="right" valign="top" style="padding-left:16px;white-space:nowrap;">'
        f"{wordmark()}</td>"
        f"</tr>"
        f'<tr><td colspan="2" style="font-family:{_FONT};font-size:26px;font-weight:bold;'
        f'color:#FFFFFF;mso-line-height-rule:exactly;line-height:33px;">'
        f"{title}</td></tr>"
        f"{chips_html}"
        f"</table>"
        f"</td></tr></table>"
    )
    return f"<tr>{_banner_td(inner)}</tr>"


def footer_rows(module_line: str) -> str:
    """Return the themed e-mail footer as a ``<tr>`` row.

    A flat maroon band mirroring the masthead, naming the sending module.

    Args:
        module_line: Pre-escaped module description, for example
            ``'Connectivity Validation &middot; production'``.
    """
    inner = (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'<tr><td style="padding:18px 32px;">'
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
        f"<tr>"
        f'<td style="font-family:{_FONT};font-size:12px;font-weight:bold;'
        f"color:#FFFFFF;mso-line-height-rule:exactly;line-height:16px;"
        f'letter-spacing:0.4px;padding-bottom:4px;">{module_line}</td>'
        f'<td align="right" valign="top" rowspan="2" '
        f'style="padding-left:16px;white-space:nowrap;">{wordmark(small=True)}</td>'
        f"</tr>"
        f'<tr><td style="font-family:{_FONT};font-size:11px;color:{EYEBROW_FG};'
        f'mso-line-height-rule:exactly;line-height:15px;">'
        f"Generated automatically &middot; Do not reply to this message</td></tr>"
        f"</table>"
        f"</td></tr></table>"
    )
    return f"<tr>{_banner_td(inner)}</tr>"
