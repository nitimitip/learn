"""Framework-wide constants, enumerations and the connectivity type registry.

This module is the single source of truth for anything that must stay
consistent across the wizard, the engine, the connectors and the reports:
supported connectivity types, their category, their default port, their
driver requirement and the process exit codes.

The module deliberately has no imports outside the standard library so that
every other module in the framework can depend on it without creating a
cycle.

Adding a new connectivity type is a two-step change: add a member to
:class:`InterfaceType` and add its entry to :data:`INTERFACE_REGISTRY`.
"""

from __future__ import annotations

from enum import IntEnum, StrEnum, unique
from typing import Final, NamedTuple

# ---------------------------------------------------------------------------
# Application identity
# ---------------------------------------------------------------------------

APP_NAME: Final[str] = "Enterprise Connectivity Validation Framework"
APP_SHORT_NAME: Final[str] = "connectivity-validator"
APP_VERSION: Final[str] = "1.0.0"
CONFIG_SCHEMA_VERSION: Final[str] = "1.0"

MIN_PYTHON_VERSION: Final[tuple[int, int]] = (3, 11)


# ---------------------------------------------------------------------------
# Process exit codes
# ---------------------------------------------------------------------------


@unique
class ExitCode(IntEnum):
    """Process exit codes contracted with enterprise schedulers.

    Schedulers such as Control-M, AutoSys and Windows Task Scheduler branch on
    these values, therefore they are part of the framework's public interface
    and must never be renumbered.
    """

    SUCCESS = 0
    """Every configured and enabled interface passed validation."""

    VALIDATION_FAILED = 1
    """The run completed but one or more interfaces failed validation."""

    CONFIGURATION_ERROR = 2
    """Configuration could not be read, decrypted or validated; nothing ran."""

    UNEXPECTED_ERROR = 99
    """An unanticipated fault escaped the orchestration layer."""


# ---------------------------------------------------------------------------
# Connectivity taxonomy
# ---------------------------------------------------------------------------


@unique
class InterfaceCategory(StrEnum):
    """High level grouping used by the wizard menu and the report layout."""

    FILE_TRANSFER = "File Transfer"
    DATABASE = "Database"
    CLOUD = "Cloud"
    API = "API"


@unique
class InterfaceType(StrEnum):
    """Every connectivity type the framework supports.

    The string values are the stable identifiers persisted in the JSON
    configuration file; renaming one is a breaking configuration change.
    """

    # File transfer
    SFTP = "SFTP"
    FTP = "FTP"
    FTPS = "FTPS"
    SCP = "SCP"
    SSH = "SSH"

    # Database
    ORACLE = "ORACLE"
    MSSQL = "MSSQL"

    # Cloud
    AZURE_BLOB = "AZURE_BLOB"
    AWS_S3 = "AWS_S3"

    # API
    REST = "REST"
    SOAP = "SOAP"


@unique
class ValidationStatus(StrEnum):
    """Outcome of validating a single interface."""

    SUCCESS = "SUCCESS"
    """The connection was established and the validation probe succeeded."""

    FAILED = "FAILED"
    """The connection or the validation probe failed. Counts against the run."""

    SKIPPED = "SKIPPED"
    """The interface is disabled in configuration. Never counts as a failure."""

    @property
    def is_failure(self) -> bool:
        """Return ``True`` when this status must fail the overall run."""
        return self is ValidationStatus.FAILED


@unique
class AuthMethod(StrEnum):
    """Authentication mechanism actually used to reach an endpoint.

    Recorded per result so that an operator reading a failure report can tell
    a credential problem from a network problem without opening the config.
    """

    NONE = "None"
    PASSWORD = "Password"
    PRIVATE_KEY = "Private Key"
    AUTO_DISCOVERED_KEY = "Auto-Discovered Private Key"
    SSH_AGENT = "SSH Agent"
    ANONYMOUS = "Anonymous"
    SQL_AUTHENTICATION = "SQL Authentication"
    WINDOWS_AUTHENTICATION = "Windows Authentication"
    CONNECTION_STRING = "Connection String"
    SERVICE_PRINCIPAL = "Service Principal"
    MANAGED_IDENTITY = "Managed Identity"
    ACCESS_KEY = "Access Key"
    IAM_ROLE = "IAM Role"
    BASIC = "Basic"
    BEARER_TOKEN = "Bearer Token"
    API_KEY = "API Key"


@unique
class SeverityBand(StrEnum):
    """Colour band applied to the executive summary of a run."""

    HEALTHY = "HEALTHY"
    """All interfaces passed. Rendered green."""

    DEGRADED = "DEGRADED"
    """Some interfaces failed but most passed. Rendered amber."""

    CRITICAL = "CRITICAL"
    """A large share of interfaces failed. Rendered red."""


#: Success percentage at or above which a run is HEALTHY.
HEALTHY_THRESHOLD_PERCENT: Final[float] = 100.0

#: Success percentage at or above which a partially failing run is DEGRADED
#: rather than CRITICAL.
DEGRADED_THRESHOLD_PERCENT: Final[float] = 80.0


# ---------------------------------------------------------------------------
# Connectivity type registry
# ---------------------------------------------------------------------------


class InterfaceSpec(NamedTuple):
    """Static metadata describing one connectivity type."""

    interface_type: InterfaceType
    category: InterfaceCategory
    display_name: str
    default_port: int | None
    driver_packages: tuple[str, ...]
    """Distribution names required at runtime; empty when stdlib only."""
    install_extra: str | None
    """The ``pip install ".[extra]"`` name that provides the driver."""
    uses_network_port: bool
    """False for endpoint-addressed services (cloud, API) that carry a URL."""


INTERFACE_REGISTRY: Final[dict[InterfaceType, InterfaceSpec]] = {
    InterfaceType.SFTP: InterfaceSpec(
        InterfaceType.SFTP,
        InterfaceCategory.FILE_TRANSFER,
        "SFTP (SSH File Transfer Protocol)",
        22,
        ("paramiko",),
        "ssh",
        True,
    ),
    InterfaceType.FTP: InterfaceSpec(
        InterfaceType.FTP,
        InterfaceCategory.FILE_TRANSFER,
        "FTP (File Transfer Protocol)",
        21,
        (),
        None,
        True,
    ),
    InterfaceType.FTPS: InterfaceSpec(
        InterfaceType.FTPS,
        InterfaceCategory.FILE_TRANSFER,
        "FTPS (FTP over explicit TLS)",
        21,
        (),
        None,
        True,
    ),
    InterfaceType.SCP: InterfaceSpec(
        InterfaceType.SCP,
        InterfaceCategory.FILE_TRANSFER,
        "SCP (Secure Copy)",
        22,
        ("paramiko",),
        "ssh",
        True,
    ),
    InterfaceType.SSH: InterfaceSpec(
        InterfaceType.SSH,
        InterfaceCategory.FILE_TRANSFER,
        "SSH (Secure Shell)",
        22,
        ("paramiko",),
        "ssh",
        True,
    ),
    InterfaceType.ORACLE: InterfaceSpec(
        InterfaceType.ORACLE,
        InterfaceCategory.DATABASE,
        "Oracle Database",
        1521,
        ("oracledb",),
        "oracle",
        True,
    ),
    InterfaceType.MSSQL: InterfaceSpec(
        InterfaceType.MSSQL,
        InterfaceCategory.DATABASE,
        "Microsoft SQL Server",
        1433,
        ("pyodbc",),
        "mssql",
        True,
    ),
    InterfaceType.AZURE_BLOB: InterfaceSpec(
        InterfaceType.AZURE_BLOB,
        InterfaceCategory.CLOUD,
        "Azure Blob Storage",
        443,
        ("azure-storage-blob", "azure-identity"),
        "azure",
        False,
    ),
    InterfaceType.AWS_S3: InterfaceSpec(
        InterfaceType.AWS_S3,
        InterfaceCategory.CLOUD,
        "Amazon S3",
        443,
        ("boto3",),
        "aws",
        False,
    ),
    InterfaceType.REST: InterfaceSpec(
        InterfaceType.REST,
        InterfaceCategory.API,
        "REST API",
        None,
        ("requests",),
        "rest",
        False,
    ),
    InterfaceType.SOAP: InterfaceSpec(
        InterfaceType.SOAP,
        InterfaceCategory.API,
        "SOAP Web Service",
        None,
        ("zeep",),
        "soap",
        False,
    ),
}

#: Connectivity types grouped by category, in wizard presentation order.
INTERFACES_BY_CATEGORY: Final[dict[InterfaceCategory, tuple[InterfaceType, ...]]] = {
    InterfaceCategory.FILE_TRANSFER: (
        InterfaceType.SFTP,
        InterfaceType.FTP,
        InterfaceType.FTPS,
        InterfaceType.SCP,
        InterfaceType.SSH,
    ),
    InterfaceCategory.DATABASE: (InterfaceType.ORACLE, InterfaceType.MSSQL),
    InterfaceCategory.CLOUD: (InterfaceType.AZURE_BLOB, InterfaceType.AWS_S3),
    InterfaceCategory.API: (InterfaceType.REST, InterfaceType.SOAP),
}

#: Connectivity types that authenticate over SSH and share key discovery.
SSH_INTERFACE_TYPES: Final[frozenset[InterfaceType]] = frozenset(
    {InterfaceType.SFTP, InterfaceType.SCP, InterfaceType.SSH}
)


def spec_for(interface_type: InterfaceType) -> InterfaceSpec:
    """Return the static metadata for ``interface_type``.

    Raises:
        KeyError: if the registry is missing an entry for a declared type,
            which indicates an incomplete connectivity type addition.
    """
    return INTERFACE_REGISTRY[interface_type]


def default_port_for(interface_type: InterfaceType) -> int | None:
    """Return the conventional port for ``interface_type``, or ``None``."""
    return INTERFACE_REGISTRY[interface_type].default_port


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_TIMEOUT_SECONDS: Final[int] = 30
MIN_TIMEOUT_SECONDS: Final[int] = 1
MAX_TIMEOUT_SECONDS: Final[int] = 3600

DEFAULT_RETRY_COUNT: Final[int] = 0
MAX_RETRY_COUNT: Final[int] = 10
DEFAULT_RETRY_BACKOFF_SECONDS: Final[float] = 2.0

DEFAULT_MAX_WORKERS: Final[int] = 8
MAX_WORKERS_LIMIT: Final[int] = 64

DEFAULT_ORACLE_VALIDATION_QUERY: Final[str] = "SELECT 1 FROM DUAL"
DEFAULT_MSSQL_VALIDATION_QUERY: Final[str] = "SELECT 1"

#: Per-link ceiling for an Oracle database link probe. A link is opened by the
#: database server, so a dead remote listener is discovered at the server's
#: timeout, not this host's; without an explicit ceiling one broken link can
#: consume the whole run.
DEFAULT_DB_LINK_TIMEOUT_SECONDS: Final[int] = 15

#: Wall-clock ceiling for checking every link on one interface. Reached only
#: when several links are broken at once, which is exactly when the run must
#: still finish and report.
DEFAULT_DB_LINK_BUDGET_SECONDS: Final[int] = 120

#: Links probed on one interface. A schema with hundreds of links is a data
#: modelling decision, not a connectivity check; the excess is reported as
#: unchecked rather than silently ignored.
DEFAULT_DB_LINK_MAX_LINKS: Final[int] = 25
MAX_DB_LINKS: Final[int] = 500

DEFAULT_SMTP_PORT: Final[int] = 25
DEFAULT_SMTP_TLS_PORT: Final[int] = 587
DEFAULT_SMTP_TIMEOUT_SECONDS: Final[int] = 30

DEFAULT_EXPECTED_HTTP_STATUS: Final[int] = 200
DEFAULT_HTTP_METHOD: Final[str] = "GET"
SUPPORTED_HTTP_METHODS: Final[tuple[str, ...]] = (
    "GET",
    "POST",
    "PUT",
    "PATCH",
    "DELETE",
    "HEAD",
    "OPTIONS",
)


# ---------------------------------------------------------------------------
# Filesystem layout and retention
# ---------------------------------------------------------------------------

DEFAULT_CONFIG_DIRECTORY: Final[str] = "config"
DEFAULT_REPORTS_DIRECTORY: Final[str] = "reports"
DEFAULT_LOGS_DIRECTORY: Final[str] = "logs"
DEFAULT_TEMPLATES_DIRECTORY: Final[str] = "templates"

DEFAULT_ENCRYPTION_KEY_FILENAME: Final[str] = "encryption.key"

#: Reports older than this many days are removed before each run.
DEFAULT_REPORT_RETENTION_DAYS: Final[int] = 15

#: Only files matching this prefix are eligible for automatic cleanup, so the
#: framework can never delete an unrelated file placed in the reports folder.
REPORT_FILENAME_PREFIX: Final[str] = "connectivity_report_"

#: Extensions the framework itself produces, used together with the prefix as
#: the second half of the cleanup safety gate. ``.html`` is retained although
#: the framework no longer writes it: installations upgraded from the HTML
#: report still hold prefixed .html files, and cleanup must be able to retire
#: them rather than leaving them to accumulate forever.
REPORT_FILE_EXTENSIONS: Final[frozenset[str]] = frozenset(
    {".pdf", ".xlsx", ".json", ".html"}
)

#: Timestamp fragment embedded in generated report file names.
REPORT_TIMESTAMP_FORMAT: Final[str] = "%Y%m%d_%H%M%S"

#: Human readable timestamp used in reports and e-mail bodies.
DISPLAY_TIMESTAMP_FORMAT: Final[str] = "%Y-%m-%d %H:%M:%S %Z"

#: Restrictive permission bits applied to generated files holding secrets.
SECURE_FILE_MODE: Final[int] = 0o600
SECURE_DIRECTORY_MODE: Final[int] = 0o700


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

LOGGER_ROOT_NAME: Final[str] = "connectivity"
AUDIT_LOGGER_NAME: Final[str] = "connectivity.audit"

LOG_FILENAME_APPLICATION: Final[str] = "application.log"
LOG_FILENAME_ERROR: Final[str] = "error.log"
LOG_FILENAME_AUDIT: Final[str] = "audit.log"
LOG_FILENAME_DEBUG: Final[str] = "debug.log"

DEFAULT_LOG_MAX_BYTES: Final[int] = 10 * 1024 * 1024
DEFAULT_LOG_BACKUP_COUNT: Final[int] = 10
DEFAULT_LOG_LEVEL: Final[str] = "INFO"
SUPPORTED_LOG_LEVELS: Final[tuple[str, ...]] = (
    "DEBUG",
    "INFO",
    "WARNING",
    "ERROR",
    "CRITICAL",
)


# ---------------------------------------------------------------------------
# Secret envelopes
# ---------------------------------------------------------------------------

#: Wrapper marking a Fernet encrypted value inside the JSON configuration.
ENCRYPTED_PREFIX: Final[str] = "ENC("
ENCRYPTED_SUFFIX: Final[str] = ")"

#: Wrapper marking an indirection to an environment variable, for sites that
#: inject secrets from an external vault at scheduler runtime.
ENV_PREFIX: Final[str] = "ENV("
ENV_SUFFIX: Final[str] = ")"

#: Replacement emitted wherever a secret would otherwise be rendered.
MASK_PLACEHOLDER: Final[str] = "********"
