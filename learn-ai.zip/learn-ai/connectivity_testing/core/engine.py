"""The connectivity validation engine.

Responsibilities
----------------
The engine turns a loaded configuration into an
:class:`~models.results.ExecutionSummary`. It resolves secrets, builds
connectors through the factory, executes them, and accounts for every single
interface in the configuration.

Guarantees
----------
1. **Every configured interface produces exactly one result.** Disabled ones
   are ``SKIPPED``; ones whose secret cannot be decrypted, or whose type has no
   connector, are ``FAILED`` with that reason. There is no path on which an
   interface silently disappears from the report, because a missing row is
   indistinguishable from a passing one to a tired operator.
2. **A failure never stops the run.** Each interface is isolated; the engine
   catches everything a connector could raise, including the things it should
   not raise.
3. **Results are ordered as configured.** Parallel execution completes in
   arbitrary order, but the report is rendered in the order the operator wrote
   the configuration, so two runs are directly comparable.
4. **The run is bounded.** Connectors enforce a per-interface deadline, and the
   engine enforces an optional whole-run ceiling, so a scheduler window cannot
   be overrun by an endpoint that accepts connections and then goes quiet.

Concurrency
-----------
Connectors are I/O bound, so a thread pool cuts a large estate from minutes to
seconds. Thread safety is achieved by construction rather than by locking:
each worker owns its own connector instance and returns a fresh result object,
and the only shared state is the logging context, which lives in
:mod:`contextvars` and is therefore per-thread by definition.
"""

from __future__ import annotations

from collections.abc import Sequence
from concurrent.futures import ALL_COMPLETED, Future, ThreadPoolExecutor, wait
from typing import Any

from connectors.factory import ConnectorFactory
from core.config_loader import LoadedConfiguration
from core.constants import (
    APP_NAME,
    APP_VERSION,
    AuthMethod,
    ValidationStatus,
)
from core.exceptions import ConnectivityFrameworkError
from core.logging_setup import get_audit_logger, get_logger, interface_scope
from models.interfaces import BaseInterfaceConfig
from models.results import ExecutionSummary, ValidationResult
from utilities.platform_info import collect_platform_info
from utilities.timing import Stopwatch, utc_now

__all__ = ["ValidationEngine"]

_logger = get_logger(__name__)


class ValidationEngine:
    """Executes the interfaces in a configuration and summarises the outcome."""

    def __init__(
        self,
        loaded: LoadedConfiguration,
        *,
        run_id: str,
        interface_names: Sequence[str] | None = None,
        tags: Sequence[str] | None = None,
    ) -> None:
        """Initialise the engine.

        Args:
            loaded: The validated configuration and its cipher.
            run_id: Correlation identifier for this run, used in the report and
                in every log record.
            interface_names: Restrict the run to these interface names, matched
                case-insensitively. Used when troubleshooting one endpoint.
            tags: Restrict the run to interfaces carrying any of these tags.
        """
        self.loaded = loaded
        self.config = loaded.config
        self.run_id = run_id
        self._interface_names = {name.strip().lower() for name in (interface_names or ())}
        self._tags = {tag.strip().lower() for tag in (tags or ())}
        self._audit = get_audit_logger()

    # ------------------------------------------------------------------
    # Selection
    # ------------------------------------------------------------------

    @property
    def is_filtered(self) -> bool:
        """Return ``True`` when a subset of the configuration was requested."""
        return bool(self._interface_names or self._tags)

    def selected_interfaces(self) -> list[BaseInterfaceConfig]:
        """Return the interfaces this run will account for.

        Filtering removes interfaces from the run entirely rather than marking
        them skipped: a filtered run is a troubleshooting exercise, and padding
        its report with rows the operator deliberately excluded would obscure
        the one they care about.
        """
        interfaces: list[BaseInterfaceConfig] = list(self.config.interfaces)
        if not self.is_filtered:
            return interfaces

        selected: list[BaseInterfaceConfig] = []
        for interface in interfaces:
            if self._interface_names and interface.name.strip().lower() in self._interface_names:
                selected.append(interface)
                continue
            if self._tags and {tag.lower() for tag in interface.tags} & self._tags:
                selected.append(interface)
        return selected

    def unmatched_filters(self) -> list[str]:
        """Return requested interface names that match nothing in the config.

        A typo in ``--interface`` would otherwise produce a clean run that
        validated nothing at all and exited zero.
        """
        if not self._interface_names:
            return []
        known = {interface.name.strip().lower() for interface in self.config.interfaces}
        return sorted(name for name in self._interface_names if name not in known)

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def run(self) -> ExecutionSummary:
        """Validate every selected interface and return the summary."""
        platform = collect_platform_info()
        interfaces = self.selected_interfaces()
        enabled = [interface for interface in interfaces if interface.enabled]

        self._log_run_start(interfaces, enabled, platform)

        stopwatch = Stopwatch()
        results: list[ValidationResult] = [
            self._skipped_result(interface)
            for interface in interfaces
            if not interface.enabled
        ]

        if enabled:
            execution = self.config.execution
            if execution.parallel_enabled and len(enabled) > 1:
                results.extend(self._run_parallel(enabled))
            else:
                results.extend(self._run_sequential(enabled))

        stopwatch.stop()

        ordered = self._in_configuration_order(interfaces, results)
        summary = ExecutionSummary(
            run_id=self.run_id,
            started_at=stopwatch.started_at,
            ended_at=stopwatch.ended_at or utc_now(),
            duration_seconds=stopwatch.elapsed_seconds,
            results=ordered,
            platform=platform,
            config_path=str(self.loaded.config_path),
            environment=self.config.environment,
        )

        self._log_run_end(summary)
        return summary

    def _run_sequential(self, interfaces: list[BaseInterfaceConfig]) -> list[ValidationResult]:
        """Validate interfaces one at a time."""
        _logger.info("Validating %d interface(s) sequentially.", len(interfaces))
        return [self._validate_one(interface) for interface in interfaces]

    def _run_parallel(self, interfaces: list[BaseInterfaceConfig]) -> list[ValidationResult]:
        """Validate interfaces concurrently, honouring the global timeout."""
        execution = self.config.execution
        workers = min(execution.effective_max_workers, len(interfaces))
        timeout = execution.global_timeout_seconds

        _logger.info(
            "Validating %d interface(s) with %d worker(s)%s.",
            len(interfaces),
            workers,
            f", global timeout {timeout}s" if timeout else "",
        )

        pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="validate")
        futures: dict[Future[ValidationResult], BaseInterfaceConfig] = {}
        try:
            for interface in interfaces:
                futures[pool.submit(self._validate_one, interface)] = interface

            done, pending = wait(futures, timeout=timeout, return_when=ALL_COMPLETED)

            results = [self._collect(future, futures[future]) for future in done]

            for future in pending:
                interface = futures[future]
                future.cancel()
                _logger.error(
                    "%s did not finish within the global timeout of %s seconds.",
                    interface.name,
                    timeout,
                )
                results.append(self._global_timeout_result(interface, timeout))
            return results
        finally:
            # Never wait on the pool: a worker may still be blocked in a driver
            # that ignored its own timeout, and waiting would reintroduce
            # exactly the overrun the global timeout exists to prevent.
            pool.shutdown(wait=False, cancel_futures=True)

    def _collect(
        self, future: Future[ValidationResult], interface: BaseInterfaceConfig
    ) -> ValidationResult:
        """Return a completed future's result, converting a fault into one.

        ``_validate_one`` is written not to raise, so reaching the except block
        means the framework itself failed. That is still recorded against the
        interface rather than allowed to abort the run.
        """
        try:
            return future.result()
        except Exception as error:  # noqa: BLE001 - accountability boundary
            _logger.exception("Worker for %s failed unexpectedly.", interface.name)
            return self._failed_result(
                interface,
                message=(
                    f"The validation worker for '{interface.name}' failed unexpectedly: "
                    f"{type(error).__name__}: {error}"
                ),
                error_code="ENGINE_ERROR",
                remediation=(
                    "This is a defect in the framework rather than a connectivity problem. "
                    "The interface was not validated and must be treated as unverified."
                ),
                cause=error,
            )

    def _validate_one(self, interface: BaseInterfaceConfig) -> ValidationResult:
        """Validate a single interface. Never raises.

        Secret resolution and connector construction happen here rather than up
        front, so that a problem with one interface's credential or type fails
        only that interface.
        """
        with interface_scope(interface.name):
            try:
                secrets = self.loaded.resolve_interface_secrets(interface)
            except ConnectivityFrameworkError as error:
                # Logged without a traceback on purpose: this is a classified,
                # expected condition that already carries an actionable message
                # and remediation. A stack trace per occurrence would bury the
                # line the operator actually needs. The trace still reaches the
                # debug log below.
                _logger.error(  # noqa: TRY400
                    "%s: credentials could not be resolved: %s", interface.name, error.message
                )
                _logger.debug("Credential resolution traceback", exc_info=True)
                return self._failed_result(
                    interface,
                    message=error.message,
                    error_code=error.error_code,
                    remediation=error.remediation,
                    cause=error,
                )

            try:
                connector = ConnectorFactory.create(
                    interface, secrets, self.config.execution
                )
            except ConnectivityFrameworkError as error:
                _logger.error(  # noqa: TRY400 - classified condition, see above
                    "%s: no connector available: %s", interface.name, error.message
                )
                _logger.debug("Connector construction traceback", exc_info=True)
                return self._failed_result(
                    interface,
                    message=error.message,
                    error_code=error.error_code,
                    remediation=error.remediation,
                    cause=error,
                )

            _logger.info("Validating %s", connector.describe())
            result = connector.validate()
            self._audit_result(result)
            return result

    # ------------------------------------------------------------------
    # Result construction
    # ------------------------------------------------------------------

    def _base_result(
        self, interface: BaseInterfaceConfig, status: ValidationStatus
    ) -> ValidationResult:
        """Return a result carrying this interface's identity."""
        try:
            auth_method = interface.auth_method
        except Exception as error:  # noqa: BLE001 - identity must never fail a report
            # Derived from configuration, so this should be unreachable. If it
            # ever is reached, the interface still gets a row in the report;
            # the anomaly goes to the debug log rather than vanishing.
            _logger.debug(
                "Authentication method could not be derived for %s: %s: %s",
                interface.name,
                type(error).__name__,
                error,
            )
            auth_method = AuthMethod.NONE

        now = utc_now()
        return ValidationResult(
            interface_name=interface.name,
            interface_type=interface.interface_type,
            category=interface.category,
            status=status,
            host=interface.display_host,
            port=interface.display_port,
            endpoint=interface.endpoint,
            auth_method=auth_method,
            started_at=now,
            ended_at=now,
            tags=list(interface.tags),
        )

    def _skipped_result(self, interface: BaseInterfaceConfig) -> ValidationResult:
        """Return the result recorded for a disabled interface."""
        _logger.info("%s is disabled in configuration; skipping.", interface.name)
        result = self._base_result(interface, ValidationStatus.SKIPPED)
        result.details["reason"] = "Interface is disabled in the configuration."
        return result

    def _failed_result(
        self,
        interface: BaseInterfaceConfig,
        *,
        message: str,
        error_code: str,
        remediation: str | None = None,
        cause: BaseException | None = None,
    ) -> ValidationResult:
        """Return a failed result for a problem detected before connecting."""
        result = self._base_result(interface, ValidationStatus.FAILED)
        result.error_message = message
        result.error_code = error_code
        result.remediation = remediation
        if cause is not None:
            result.exception_type = type(cause).__name__
            result.exception_details = str(cause)
        result.redact()
        return result

    def _global_timeout_result(
        self, interface: BaseInterfaceConfig, timeout: int | None
    ) -> ValidationResult:
        """Return the result recorded for an interface cut off by the run ceiling."""
        return self._failed_result(
            interface,
            message=(
                f"'{interface.name}' was still running when the global timeout of "
                f"{timeout} seconds expired, so its outcome is unknown."
            ),
            error_code="GLOBAL_TIMEOUT",
            remediation=(
                "The run was stopped to protect the scheduler window. Either this endpoint "
                "is much slower than the rest, or it accepts connections and then stops "
                "responding. Validate it on its own with --interface to see where it "
                "stalls, then raise execution.global_timeout_seconds if the delay is "
                "legitimate."
            ),
        )

    @staticmethod
    def _in_configuration_order(
        interfaces: list[BaseInterfaceConfig], results: list[ValidationResult]
    ) -> list[ValidationResult]:
        """Return ``results`` ordered as the interfaces appear in the config.

        Parallel execution finishes in arbitrary order. Reporting in
        configuration order keeps two runs directly comparable, which is what
        makes a before-and-after diff across a change window readable.
        """
        position = {
            interface.name.strip().lower(): index
            for index, interface in enumerate(interfaces)
        }
        return sorted(
            results,
            key=lambda result: position.get(result.interface_name.strip().lower(), 1_000_000),
        )

    # ------------------------------------------------------------------
    # Audit trail
    # ------------------------------------------------------------------

    def _log_run_start(
        self,
        interfaces: list[BaseInterfaceConfig],
        enabled: list[BaseInterfaceConfig],
        platform: Any,
    ) -> None:
        """Record the start of the run in the application and audit logs."""
        _logger.info("%s %s starting run %s", APP_NAME, APP_VERSION, self.run_id)
        _logger.info(
            "Configuration: %s (environment '%s')",
            self.loaded.config_path,
            self.config.environment,
        )
        _logger.info(
            "Host %s (%s %s), Python %s",
            platform.hostname,
            platform.operating_system,
            platform.os_release,
            platform.python_version_short,
        )
        _logger.info(
            "%d interface(s) selected, %d enabled, %d disabled.",
            len(interfaces),
            len(enabled),
            len(interfaces) - len(enabled),
        )

        for finding in self.loaded.findings:
            if finding.severity == "warning":
                _logger.warning("Configuration finding [%s]: %s", finding.code, finding.message)
            else:
                _logger.info("Configuration note [%s]: %s", finding.code, finding.message)

        self._audit.info(
            "RUN START run_id=%s config=%s environment=%s interfaces=%d enabled=%d",
            self.run_id,
            self.loaded.config_path,
            self.config.environment,
            len(interfaces),
            len(enabled),
        )

    def _audit_result(self, result: ValidationResult) -> None:
        """Record one interface outcome in the audit log."""
        self._audit.info(
            "INTERFACE name=%s type=%s endpoint=%s status=%s duration=%.3fs attempts=%d%s",
            result.interface_name,
            result.interface_type.value,
            result.endpoint,
            result.status.value,
            result.duration_seconds,
            result.attempts,
            f" error={result.error_code}" if result.error_code else "",
        )

    def _log_run_end(self, summary: ExecutionSummary) -> None:
        """Record the end of the run in the application and audit logs."""
        _logger.info(
            "Run %s complete in %s: %d passed, %d failed, %d skipped (%.2f%% of %d validated).",
            summary.run_id,
            summary.duration_display,
            summary.passed,
            summary.failed,
            summary.skipped,
            summary.success_percentage,
            summary.validated_interfaces,
        )

        if summary.has_failures:
            for result in summary.failed_results:
                _logger.error(
                    "FAILED %s (%s) [%s] %s",
                    result.interface_name,
                    result.endpoint,
                    result.error_code,
                    result.error_message,
                )

        self._audit.info(
            "RUN END run_id=%s status=%s passed=%d failed=%d skipped=%d duration=%.3fs",
            summary.run_id,
            summary.status_word,
            summary.passed,
            summary.failed,
            summary.skipped,
            summary.duration_seconds,
        )
