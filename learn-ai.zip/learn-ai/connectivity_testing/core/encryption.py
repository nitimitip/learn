"""Secret encryption, key management and secret resolution.

Design
------
Secrets are stored in the JSON configuration wrapped in an envelope so that a
reader can tell at a glance what is protected::

    "password": "ENC(gAAAAABm...)"     Fernet encrypted with encryption.key
    "password": "ENV(SFTP_PASSWORD)"   Read from the environment at run time
    "password": "hunter2"              Plaintext: rejected unless explicitly
                                       permitted, and always warned about

Fernet (AES-128-CBC with an HMAC-SHA256 authentication tag) is used through
the ``cryptography`` package. Because the ciphertext is authenticated, a
tampered configuration fails loudly at decryption instead of silently
producing a wrong credential.

Key rotation
------------
The key file holds one key per line. The first line is the *primary* key and
is the only one used to encrypt. Remaining lines are retired keys retained for
decryption, which is what :class:`cryptography.fernet.MultiFernet` implements.
Rotating therefore means prepending a new key, then re-running
:meth:`SecretCipher.reencrypt` over the configuration; existing secrets stay
readable throughout.

The ``ENV()`` envelope exists for sites whose policy forbids credentials on
disk in any form. It lets an external vault inject the secret into the
scheduler's process environment, with the configuration recording only the
variable name.
"""

from __future__ import annotations

import base64
import os
from dataclasses import dataclass
from enum import StrEnum, unique
from pathlib import Path
from typing import Final

from cryptography.fernet import Fernet, InvalidToken, MultiFernet

from core.constants import (
    ENCRYPTED_PREFIX,
    ENCRYPTED_SUFFIX,
    ENV_PREFIX,
    ENV_SUFFIX,
)
from core.exceptions import DecryptionError, EncryptionKeyError
from utilities.fs import atomic_write_bytes, ensure_directory, permissions_are_world_readable
from utilities.masking import secret_registry

__all__ = [
    "EncryptionKeyManager",
    "EnvelopeKind",
    "KeyFileStatus",
    "SecretCipher",
    "envelope_kind",
    "is_encrypted_value",
    "is_env_reference",
]

#: Marker line written into a generated key file. Ignored on read.
_KEY_FILE_BANNER: Final[bytes] = (
    b"# Enterprise Connectivity Validation Framework encryption key.\n"
    b"# The FIRST key line is the primary key used for encryption.\n"
    b"# Additional key lines are retired keys kept only so that secrets\n"
    b"# encrypted before a rotation remain readable.\n"
    b"#\n"
    b"# PROTECT THIS FILE. Anyone holding it can decrypt every secret in the\n"
    b"# configuration. Back it up together with the configuration it protects:\n"
    b"# a configuration without its key cannot be recovered.\n"
)

#: A Fernet key is 32 raw bytes rendered as urlsafe base64, always 44 chars.
_FERNET_KEY_LENGTH: Final[int] = 44


@unique
class EnvelopeKind(StrEnum):
    """How a configured secret is stored, as reported by :func:`envelope_kind`."""

    ENCRYPTED = "encrypted"
    """Fernet ciphertext in an ENC(...) envelope."""

    ENVIRONMENT = "environment"
    """An ENV(NAME) indirection resolved from the process environment."""

    PLAINTEXT = "plaintext"
    """An unprotected literal. Warned about, and refused in strict mode."""

    EMPTY = "empty"
    """Not configured. Distinct from plaintext so optional fields stay optional."""


def is_encrypted_value(value: object) -> bool:
    """Return ``True`` when ``value`` carries the ``ENC(...)`` envelope."""
    return (
        isinstance(value, str)
        and value.startswith(ENCRYPTED_PREFIX)
        and value.endswith(ENCRYPTED_SUFFIX)
    )


def is_env_reference(value: object) -> bool:
    """Return ``True`` when ``value`` carries the ``ENV(...)`` envelope."""
    return isinstance(value, str) and value.startswith(ENV_PREFIX) and value.endswith(ENV_SUFFIX)


def envelope_kind(value: str | None) -> EnvelopeKind:
    """Classify a configured secret value without decrypting it."""
    if value is None or value == "":
        return EnvelopeKind.EMPTY
    if is_encrypted_value(value):
        return EnvelopeKind.ENCRYPTED
    if is_env_reference(value):
        return EnvelopeKind.ENVIRONMENT
    return EnvelopeKind.PLAINTEXT


@dataclass(frozen=True, slots=True)
class KeyFileStatus:
    """Result of loading a key file, used to warn about unsafe deployments."""

    path: Path
    key_count: int
    was_created: bool
    permissions_are_unsafe: bool

    @property
    def has_retired_keys(self) -> bool:
        """Return ``True`` when retired keys are retained for decryption."""
        return self.key_count > 1


class EncryptionKeyManager:
    """Creates, loads and rotates the Fernet key file.

    The manager owns the key file and nothing else; producing a usable cipher
    is delegated to :class:`SecretCipher`. Separating them keeps key handling
    in one auditable place and lets tests build a cipher from an in-memory key
    without touching the filesystem.
    """

    def __init__(self, key_path: Path) -> None:
        self.key_path = Path(key_path)
        self._status: KeyFileStatus | None = None
        # Remembered separately because load_or_create() creates the file and
        # then loads it; without this the subsequent load would overwrite the
        # status and report was_created as False for a key it just generated.
        self._created_this_session = False

    @property
    def status(self) -> KeyFileStatus | None:
        """Return the status recorded by the most recent load, if any."""
        return self._status

    @staticmethod
    def generate_key() -> bytes:
        """Return a new cryptographically random Fernet key."""
        return Fernet.generate_key()

    def exists(self) -> bool:
        """Return ``True`` when the key file is present."""
        return self.key_path.is_file()

    def load_or_create(self) -> SecretCipher:
        """Load the key file, creating it with a fresh key when absent.

        Returns:
            A cipher bound to the loaded keys.

        Raises:
            EncryptionKeyError: if the file cannot be created or read, or if
                it contains no syntactically valid key.
        """
        if not self.exists():
            self._create_key_file()
        return self.load()

    def load(self) -> SecretCipher:
        """Load the key file and return a cipher.

        Raises:
            EncryptionKeyError: if the key file is missing, unreadable or does
                not contain a valid key.
        """
        if not self.exists():
            raise EncryptionKeyError(
                f"Encryption key file not found: {self.key_path}",
                remediation=(
                    "Run 'python generate_config.py' to create a configuration and its key, "
                    "or copy the encryption.key that belongs to this configuration into "
                    f"{self.key_path.parent}. A configuration cannot be decrypted without "
                    "the key it was encrypted with."
                ),
                details={"key_path": str(self.key_path)},
            )

        try:
            raw = self.key_path.read_bytes()
        except OSError as error:
            raise EncryptionKeyError(
                f"Encryption key file cannot be read: {self.key_path}",
                remediation=(
                    "Check that the account running the job has read permission on the key "
                    "file. Under a scheduler this is often a service account rather than the "
                    "account that generated the configuration."
                ),
                details={"key_path": str(self.key_path)},
                cause=error,
            ) from error

        keys = self._parse_keys(raw)
        unsafe_permissions = permissions_are_world_readable(self.key_path)
        self._status = KeyFileStatus(
            path=self.key_path,
            key_count=len(keys),
            was_created=self._created_this_session,
            permissions_are_unsafe=unsafe_permissions,
        )
        return SecretCipher(keys)

    def _parse_keys(self, raw: bytes) -> list[bytes]:
        """Extract key lines from the file contents.

        Raises:
            EncryptionKeyError: when no valid key line is present.
        """
        keys: list[bytes] = []
        malformed_lines = 0

        for line in raw.splitlines():
            candidate = line.strip()
            if not candidate or candidate.startswith(b"#"):
                continue
            if self._is_valid_fernet_key(candidate):
                keys.append(candidate)
            else:
                malformed_lines += 1

        if not keys:
            raise EncryptionKeyError(
                f"Encryption key file contains no valid key: {self.key_path}",
                remediation=(
                    "The key file is corrupt or was overwritten. Restore it from backup. "
                    "If no backup exists, regenerate the configuration with "
                    "'python generate_config.py'; stored secrets will have to be re-entered."
                ),
                details={
                    "key_path": str(self.key_path),
                    "malformed_lines": malformed_lines,
                },
            )
        return keys

    @staticmethod
    def _is_valid_fernet_key(candidate: bytes) -> bool:
        """Return ``True`` when ``candidate`` decodes as a 32-byte Fernet key."""
        if len(candidate) != _FERNET_KEY_LENGTH:
            return False
        try:
            return len(base64.urlsafe_b64decode(candidate)) == 32
        except (ValueError, TypeError):
            return False

    def _create_key_file(self) -> None:
        """Write a new key file with owner-only permissions.

        Raises:
            EncryptionKeyError: if the file cannot be written.
        """
        try:
            ensure_directory(self.key_path.parent, secure=True)
            payload = _KEY_FILE_BANNER + self.generate_key() + b"\n"
            atomic_write_bytes(self.key_path, payload, secure=True)
        except OSError as error:
            raise EncryptionKeyError(
                f"Encryption key file could not be created: {self.key_path}",
                remediation=(
                    "Check that the directory exists and is writable by the account running "
                    "the configuration wizard."
                ),
                details={"key_path": str(self.key_path)},
                cause=error,
            ) from error

        self._created_this_session = True
        self._status = KeyFileStatus(
            path=self.key_path,
            key_count=1,
            was_created=True,
            permissions_are_unsafe=permissions_are_world_readable(self.key_path),
        )

    def rotate(self) -> SecretCipher:
        """Prepend a freshly generated primary key, retaining existing keys.

        Secrets encrypted with a retired key remain decryptable, so rotation is
        safe to perform before re-encrypting a configuration.

        Returns:
            A cipher whose primary key is the newly generated one.

        Raises:
            EncryptionKeyError: if the current key file cannot be read or the
                rotated file cannot be written.
        """
        existing = self._parse_keys(self.key_path.read_bytes()) if self.exists() else []
        new_key = self.generate_key()
        payload = _KEY_FILE_BANNER + b"\n".join([new_key, *existing]) + b"\n"
        try:
            atomic_write_bytes(self.key_path, payload, secure=True)
        except OSError as error:
            raise EncryptionKeyError(
                f"Encryption key file could not be rotated: {self.key_path}",
                remediation="Check filesystem permissions and free space, then retry.",
                details={"key_path": str(self.key_path)},
                cause=error,
            ) from error

        self._status = KeyFileStatus(
            path=self.key_path,
            key_count=len(existing) + 1,
            was_created=False,
            permissions_are_unsafe=permissions_are_world_readable(self.key_path),
        )
        return SecretCipher([new_key, *existing])


class SecretCipher:
    """Encrypts, decrypts and resolves configuration secrets.

    Every plaintext this cipher produces is registered with the process-wide
    secret registry, which means the logging filter will scrub that exact value
    out of any log line for the rest of the run, including one emitted from
    deep inside a third-party driver.
    """

    def __init__(self, keys: list[bytes] | bytes) -> None:
        key_list = [keys] if isinstance(keys, bytes) else list(keys)
        if not key_list:
            raise EncryptionKeyError(
                "At least one encryption key is required to build a cipher.",
                remediation="Regenerate the key file with 'python generate_config.py'.",
            )
        try:
            fernets = [Fernet(key) for key in key_list]
        except (ValueError, TypeError) as error:
            raise EncryptionKeyError(
                "Encryption key is not a valid Fernet key.",
                remediation=(
                    "Restore the key file from backup. A Fernet key is 44 urlsafe-base64 "
                    "characters encoding 32 random bytes."
                ),
                cause=error,
            ) from error

        self._multi = MultiFernet(fernets)
        self._key_count = len(fernets)

    @property
    def key_count(self) -> int:
        """Return the number of keys available for decryption."""
        return self._key_count

    # -- encryption ---------------------------------------------------------

    def encrypt(self, plaintext: str | None) -> str | None:
        """Encrypt ``plaintext`` and return it wrapped in the ``ENC()`` envelope.

        Empty and ``None`` inputs are returned unchanged so that optional
        credential fields stay empty rather than becoming an encrypted empty
        string that later reads as a configured-but-blank password.

        Values already carrying an ``ENC()`` or ``ENV()`` envelope are returned
        unchanged, which makes the operation idempotent and lets the wizard
        re-save a configuration without double-encrypting it.
        """
        if plaintext is None or plaintext == "":
            return plaintext
        if is_encrypted_value(plaintext) or is_env_reference(plaintext):
            return plaintext

        token = self._multi.encrypt(plaintext.encode("utf-8")).decode("ascii")
        secret_registry.register(plaintext)
        return f"{ENCRYPTED_PREFIX}{token}{ENCRYPTED_SUFFIX}"

    def reencrypt(self, value: str | None) -> str | None:
        """Re-encrypt an ``ENC()`` value under the current primary key.

        Used after :meth:`EncryptionKeyManager.rotate` to migrate a
        configuration onto the new key. Non-encrypted values pass through
        unchanged.
        """
        if value is None or not is_encrypted_value(value):
            return value
        token = value[len(ENCRYPTED_PREFIX) : -len(ENCRYPTED_SUFFIX)]
        try:
            rotated = self._multi.rotate(token.encode("ascii")).decode("ascii")
        except (InvalidToken, ValueError) as error:
            raise DecryptionError(
                "A stored secret could not be re-encrypted during key rotation.",
                remediation=(
                    "The value was encrypted with a key that is no longer present in the key "
                    "file. Restore the retired key line, or re-enter the secret with "
                    "'python generate_config.py'."
                ),
                cause=error,
            ) from error
        return f"{ENCRYPTED_PREFIX}{rotated}{ENCRYPTED_SUFFIX}"

    # -- decryption ---------------------------------------------------------

    def decrypt(self, value: str | None, *, field_name: str = "secret") -> str | None:
        """Decrypt an ``ENC()`` value.

        Args:
            value: The stored value. Must carry the ``ENC()`` envelope.
            field_name: Field being decrypted, used only in the error message
                so an operator knows which credential failed.

        Raises:
            DecryptionError: when the token is invalid or was produced by a key
                that is not in the key file.
        """
        if value is None or value == "":
            return value
        if not is_encrypted_value(value):
            raise DecryptionError(
                f"Value for '{field_name}' is not an encrypted value.",
                remediation=(
                    "Re-run 'python generate_config.py' so the value is stored encrypted."
                ),
                details={"field": field_name},
            )

        token = value[len(ENCRYPTED_PREFIX) : -len(ENCRYPTED_SUFFIX)]
        try:
            plaintext = self._multi.decrypt(token.encode("ascii")).decode("utf-8")
        except (InvalidToken, ValueError) as error:
            raise DecryptionError(
                f"Stored secret for '{field_name}' could not be decrypted.",
                remediation=(
                    "This almost always means the configuration and the encryption.key no "
                    "longer match: the configuration was copied to another host, or the key "
                    "was regenerated. Copy the original encryption.key alongside the "
                    "configuration, or re-run 'python generate_config.py' on this host."
                ),
                details={"field": field_name},
                cause=error,
            ) from error

        secret_registry.register(plaintext)
        return plaintext

    def resolve(
        self,
        value: str | None,
        *,
        field_name: str = "secret",
        allow_plaintext: bool = True,
    ) -> str | None:
        """Resolve any secret envelope to its plaintext.

        This is the single entry point the connectors use. It handles all three
        storage forms so that no connector needs to know how a secret was
        stored:

        * ``ENC(...)`` -- decrypted with the key file.
        * ``ENV(NAME)`` -- read from the process environment.
        * anything else -- returned as-is when ``allow_plaintext`` is set.

        Args:
            value: The stored value.
            field_name: Used in error messages.
            allow_plaintext: When ``False``, a plaintext secret raises instead
                of being used. Sites with a no-plaintext-credentials policy set
                this through the ``strict_secrets`` application setting.

        Raises:
            DecryptionError: on an undecryptable token, an unset environment
                variable, or plaintext when it is not permitted.
        """
        kind = envelope_kind(value)

        if kind is EnvelopeKind.EMPTY or value is None:
            return value
        if kind is EnvelopeKind.ENCRYPTED:
            return self.decrypt(value, field_name=field_name)
        if kind is EnvelopeKind.ENVIRONMENT:
            variable_name = value[len(ENV_PREFIX) : -len(ENV_SUFFIX)].strip()
            resolved = os.environ.get(variable_name)
            if resolved is None:
                raise DecryptionError(
                    f"Environment variable '{variable_name}' referenced by '{field_name}' "
                    "is not set.",
                    remediation=(
                        f"Export {variable_name} in the environment that runs the job. Under "
                        "a scheduler, the job definition owns the environment, not the "
                        "interactive shell used for testing."
                    ),
                    details={"field": field_name, "variable": variable_name},
                )
            secret_registry.register(resolved)
            return resolved

        if not allow_plaintext:
            raise DecryptionError(
                f"Value for '{field_name}' is stored in plaintext, which this deployment "
                "does not permit.",
                remediation=(
                    "Re-run 'python generate_config.py' to store the secret encrypted, or "
                    "replace it with an ENV(VARIABLE_NAME) reference."
                ),
                details={"field": field_name},
            )

        if value:
            secret_registry.register(value)
        return value
