"""Report generation: PDF, Excel and JSON.

Three audiences, three formats
------------------------------
================  ===========================================================
PDF               The executive report and the document of record. Opened
                  first, printed, signed off against a change record and
                  filed. Fixed pagination, so it reads identically for every
                  recipient, and it carries the Northern Powergrid identity
                  shared with the notification e-mail.
Excel             The working document. Filterable, sortable, and pasted into
                  change records and incident tickets.
JSON              The machine-readable record. Complete, including stack
                  traces, for a monitoring pipeline or a later diff.
================  ===========================================================

Failure policy
--------------
A report is evidence *about* a run; it is not the run. If one format cannot be
written -- a locked file, a full disk, a missing dependency -- the others are
still produced and the validation verdict is unchanged. Losing the Excel file
must never turn a clean connectivity result into a failed job.

Naming
------
Every generated file starts with :data:`~core.constants.REPORT_FILENAME_PREFIX`
and carries a run timestamp. The prefix is half of the safety gate used by the
retention cleanup, which is how the framework guarantees it can never delete a
file it did not create.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from core import theme
from core.constants import (
    APP_NAME,
    APP_VERSION,
    DISPLAY_TIMESTAMP_FORMAT,
    REPORT_FILENAME_PREFIX,
    REPORT_TIMESTAMP_FORMAT,
)
from core.exceptions import ReportGenerationError
from core.logging_setup import get_logger
from models.results import ExecutionSummary, ValidationResult
from models.settings import ReportSettings
from utilities.fs import atomic_write_bytes, atomic_write_text, ensure_directory, safe_filename

__all__ = ["GeneratedReport", "ReportGenerator"]

_logger = get_logger(__name__)

#: Excel fills, taken from the shared brand theme so the workbook, the PDF and
#: the notification e-mail read as one deliverable rather than three tools.
_EXCEL_COLOURS = {
    "pass": theme.PASS,
    "fail": theme.FAIL,
    "warn": theme.WARN,
    "skip": theme.SKIP,
    "brand": theme.BRAND_RED,
    "header": theme.BRAND_RED_DARK,
}

#: Excel refuses a sheet name longer than this, or containing []:*?/\\
_MAX_SHEET_NAME = 31


@dataclass(frozen=True, slots=True)
class GeneratedReport:
    """One report file that was successfully written."""

    format: str
    path: Path
    size_bytes: int

    @property
    def name(self) -> str:
        """Return the file name."""
        return self.path.name


class ReportGenerator:
    """Produces the configured report formats for one execution summary."""

    def __init__(
        self,
        summary: ExecutionSummary,
        settings: ReportSettings,
        directory: Path,
    ) -> None:
        """Initialise the generator.

        Args:
            summary: The completed run to report on.
            settings: Which formats to produce.
            directory: Destination directory, created if absent.
        """
        self.summary = summary
        self.settings = settings
        self.directory = Path(directory)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate(self) -> list[GeneratedReport]:
        """Produce every enabled format.

        Never raises. Each format is attempted independently; a failure is
        logged, recorded on the summary, and the remaining formats still run.

        Returns:
            The reports that were written, in PDF, Excel, JSON order.
        """
        try:
            ensure_directory(self.directory)
        except OSError as error:
            message = f"Report directory could not be created: {self.directory} ({error})"
            _logger.exception(message)
            self.summary.cleanup_errors.append(message)
            return []

        produced: list[GeneratedReport] = []
        builders = (
            ("pdf", self.settings.generate_pdf, self._generate_pdf),
            ("excel", self.settings.generate_excel, self._generate_excel),
            ("json", self.settings.generate_json, self._generate_json),
        )

        for name, enabled, builder in builders:
            if not enabled:
                continue
            try:
                path = builder()
            except Exception as error:  # noqa: BLE001 - one format must not lose the others
                _logger.exception("The %s report could not be generated.", name.upper())
                self.summary.cleanup_errors.append(
                    f"{name.upper()} report generation failed: {type(error).__name__}: {error}"
                )
                continue

            report = GeneratedReport(
                format=name, path=path, size_bytes=path.stat().st_size
            )
            produced.append(report)
            self.summary.report_paths[name] = str(path)
            _logger.info(
                "%s report written: %s (%d bytes)", name.upper(), path, report.size_bytes
            )

        return produced

    # ------------------------------------------------------------------
    # Naming
    # ------------------------------------------------------------------

    def _report_path(self, extension: str) -> Path:
        """Return the destination path for one format.

        The name always begins with the framework's report prefix, which is
        what makes automatic cleanup safe.
        """
        timestamp = self.summary.started_at.strftime(REPORT_TIMESTAMP_FORMAT)
        environment = safe_filename(self.summary.environment or "run", max_length=32)
        filename = (
            f"{REPORT_FILENAME_PREFIX}{environment}_{timestamp}_"
            f"{self.summary.run_id}.{extension}"
        )
        return self.directory / filename

    # ------------------------------------------------------------------
    # PDF
    # ------------------------------------------------------------------

    def _generate_pdf(self) -> Path:
        """Render the executive PDF report.

        The document is built entirely in memory and only then written, so a
        LayoutError or a full disk leaves no half-formed document that a
        scheduler or an operator could mistake for evidence.

        Raises:
            ReportGenerationError: if ReportLab is unavailable or the document
                cannot be laid out.
        """
        try:
            from core.pdf_report import render_pdf
        except ImportError as error:  # pragma: no cover - declared as a core dependency
            raise ReportGenerationError(
                "ReportLab is required to produce the PDF report but is not installed.",
                remediation='Install it: pip install "reportlab>=4.0,<5.1"',
                cause=error,
            ) from error

        try:
            document = render_pdf(
                self.summary, app_name=APP_NAME, app_version=APP_VERSION
            )
        except Exception as error:  # noqa: BLE001 - classified for the operator
            raise ReportGenerationError(
                f"The PDF report could not be laid out: {type(error).__name__}: {error}",
                remediation=(
                    "This is usually a single pathological value, such as an error "
                    "message or a server banner many pages long. The same run is fully "
                    "recorded in the Excel and JSON reports."
                ),
                details={"run_id": self.summary.run_id},
                cause=error,
            ) from error

        path = self._report_path("pdf")
        atomic_write_bytes(path, document)
        return path

    # ------------------------------------------------------------------
    # Excel
    # ------------------------------------------------------------------

    def _generate_excel(self) -> Path:
        """Build the Excel workbook.

        Raises:
            ReportGenerationError: if XlsxWriter is unavailable.
        """
        try:
            import xlsxwriter
        except ImportError as error:  # pragma: no cover - declared as a core dependency
            raise ReportGenerationError(
                "XlsxWriter is required to produce the Excel report but is not installed.",
                remediation='Install it: pip install "XlsxWriter>=3.2,<4.0"',
                cause=error,
            ) from error

        path = self._report_path("xlsx")
        # XlsxWriter streams to a file handle, so the workbook is built in a
        # temporary file and moved into place only once it is complete. A
        # half-written workbook must never be left where a scheduler or an
        # operator could pick it up as evidence.
        temporary = path.with_suffix(".xlsx.part")
        workbook = xlsxwriter.Workbook(
            str(temporary), {"constant_memory": False, "default_date_format": "yyyy-mm-dd hh:mm:ss"}
        )
        try:
            formats = self._excel_formats(workbook)
            self._excel_summary_sheet(workbook, formats)
            self._excel_results_sheet(
                workbook, formats, "Successful Connections", self.summary.successful_results
            )
            self._excel_results_sheet(
                workbook, formats, "Failed Connections", self.summary.failed_results
            )
            self._excel_database_links_sheet(workbook, formats)
            self._excel_statistics_sheet(workbook, formats)
        finally:
            workbook.close()

        atomic_write_bytes(path, temporary.read_bytes())
        temporary.unlink(missing_ok=True)
        return path

    @staticmethod
    def _excel_formats(workbook: Any) -> dict[str, Any]:
        """Return the shared cell formats."""
        return {
            "title": workbook.add_format(
                {"bold": True, "font_size": 15, "font_color": _EXCEL_COLOURS["brand"]}
            ),
            "subtitle": workbook.add_format({"font_size": 10, "font_color": theme.MUTED}),
            "header": workbook.add_format(
                {
                    "bold": True,
                    "font_color": "#FFFFFF",
                    "bg_color": _EXCEL_COLOURS["header"],
                    "border": 1,
                    "text_wrap": True,
                    "valign": "vcenter",
                }
            ),
            "label": workbook.add_format(
                {"bold": True, "bg_color": theme.BAND, "border": 1, "font_color": theme.INK}
            ),
            "value": workbook.add_format({"border": 1}),
            "cell": workbook.add_format({"border": 1, "valign": "top", "text_wrap": True}),
            "number": workbook.add_format({"border": 1, "num_format": "#,##0.000"}),
            "integer": workbook.add_format({"border": 1, "num_format": "#,##0"}),
            "percent": workbook.add_format({"border": 1, "num_format": "0.0\\%", "bold": True}),
            "datetime": workbook.add_format(
                {"border": 1, "num_format": "yyyy-mm-dd hh:mm:ss"}
            ),
            "pass": workbook.add_format(
                {"border": 1, "bold": True, "font_color": "#FFFFFF",
                 "bg_color": _EXCEL_COLOURS["pass"], "align": "center"}
            ),
            "fail": workbook.add_format(
                {"border": 1, "bold": True, "font_color": "#FFFFFF",
                 "bg_color": _EXCEL_COLOURS["fail"], "align": "center"}
            ),
            "skip": workbook.add_format(
                {"border": 1, "bold": True, "font_color": "#FFFFFF",
                 "bg_color": _EXCEL_COLOURS["skip"], "align": "center"}
            ),
        }

    def _excel_summary_sheet(self, workbook: Any, formats: Mapping[str, Any]) -> None:
        """Write the executive summary sheet."""
        summary = self.summary
        sheet = workbook.add_worksheet("Summary")
        sheet.set_column("A:A", 34)
        sheet.set_column("B:B", 62)
        sheet.hide_gridlines(2)

        sheet.write("A1", "Enterprise Connectivity Validation Report", formats["title"])
        sheet.write(
            "A2",
            f"{theme.ORGANISATION} - {summary.environment} - run {summary.run_id} - "
            f"{summary.ended_at.strftime(DISPLAY_TIMESTAMP_FORMAT)}",
            formats["subtitle"],
        )

        verdict_format = formats["pass"] if not summary.has_failures else formats["fail"]
        row = 3
        sheet.write(row, 0, "Overall result", formats["label"])
        sheet.write(row, 1, f"{summary.status_word} ({summary.severity.value})", verdict_format)

        rows: list[tuple[str, Any, Any]] = [
            ("Total interfaces", summary.total_interfaces, formats["integer"]),
            ("Validated", summary.validated_interfaces, formats["integer"]),
            ("Passed", summary.passed, formats["integer"]),
            ("Failed", summary.failed, formats["integer"]),
            ("Skipped (disabled)", summary.skipped, formats["integer"]),
            ("With warnings", summary.with_warnings, formats["integer"]),
            ("Success percentage", summary.success_percentage, formats["percent"]),
            ("Execution duration", summary.duration_display, formats["value"]),
            (
                "Average connect latency",
                f"{summary.average_latency_ms} ms" if summary.average_latency_ms else "n/a",
                formats["value"],
            ),
            ("Started", summary.started_at.replace(tzinfo=None), formats["datetime"]),
            ("Finished", summary.ended_at.replace(tzinfo=None), formats["datetime"]),
            ("Configuration", summary.config_path, formats["value"]),
        ]

        platform = summary.platform
        if platform is not None:
            rows.extend(
                [
                    ("Hostname", f"{platform.hostname} ({platform.fqdn})", formats["value"]),
                    ("IP address", platform.ip_address, formats["value"]),
                    (
                        "Operating system",
                        f"{platform.operating_system} {platform.os_release} "
                        f"({platform.architecture})",
                        formats["value"],
                    ),
                    (
                        "Python",
                        f"{platform.python_implementation} {platform.python_version_short}",
                        formats["value"],
                    ),
                    ("Executed by", platform.username, formats["value"]),
                ]
            )

        for offset, (label, value, cell_format) in enumerate(rows, start=row + 1):
            sheet.write(offset, 0, label, formats["label"])
            if isinstance(value, (int, float)) or hasattr(value, "year"):
                sheet.write(offset, 1, value, cell_format)
            else:
                sheet.write(offset, 1, str(value), cell_format)

        sheet.freeze_panes(3, 0)
        sheet.set_landscape()
        sheet.fit_to_pages(1, 0)

    def _excel_results_sheet(
        self,
        workbook: Any,
        formats: Mapping[str, Any],
        title: str,
        results: Sequence[ValidationResult],
    ) -> None:
        """Write one result worksheet with a filter and frozen header."""
        sheet = workbook.add_worksheet(title[:_MAX_SHEET_NAME])
        columns = [
            ("Interface Name", 28),
            ("Type", 12),
            ("Category", 15),
            ("Host", 30),
            ("Port", 8),
            ("Endpoint", 42),
            ("Authentication", 24),
            ("Status", 11),
            ("Start Time", 20),
            ("End Time", 20),
            ("Duration (s)", 13),
            ("Latency (ms)", 13),
            ("Attempts", 10),
            ("Error Code", 26),
            ("Error Message", 60),
            ("Remediation", 60),
            ("Warnings", 40),
            ("Tags", 20),
        ]

        for index, (heading, width) in enumerate(columns):
            sheet.write(0, index, heading, formats["header"])
            sheet.set_column(index, index, width)
        sheet.set_row(0, 28)

        status_formats = {
            "SUCCESS": formats["pass"],
            "FAILED": formats["fail"],
            "SKIPPED": formats["skip"],
        }

        for row_index, result in enumerate(results, start=1):
            row = result.to_row()
            values = [row[heading] for heading, _ in columns]
            for column_index, value in enumerate(values):
                heading = columns[column_index][0]
                if heading == "Status":
                    sheet.write(
                        row_index, column_index, value,
                        status_formats.get(str(value), formats["cell"]),
                    )
                elif heading in ("Start Time", "End Time"):
                    sheet.write_datetime(row_index, column_index, value, formats["datetime"])
                elif heading == "Duration (s)":
                    sheet.write_number(row_index, column_index, float(value), formats["number"])
                elif heading in ("Latency (ms)", "Port", "Attempts") and value != "":
                    sheet.write_number(row_index, column_index, float(value), formats["integer"])
                else:
                    sheet.write(row_index, column_index, value, formats["cell"])

        if results:
            sheet.autofilter(0, 0, len(results), len(columns) - 1)
        else:
            sheet.write(1, 0, "No interfaces in this category.", formats["cell"])

        sheet.freeze_panes(1, 1)
        sheet.set_landscape()
        sheet.fit_to_pages(1, 0)
        sheet.repeat_rows(0)

    def _excel_database_links_sheet(
        self, workbook: Any, formats: Mapping[str, Any]
    ) -> None:
        """Write the Oracle database link sheet, when any link was checked.

        Omitted entirely when no interface checks links, so an estate that does
        not use them never sees an empty sheet it has to explain. Where links
        are checked this is usually the sheet that gets pasted into the ticket:
        one row per link, filterable by status.
        """
        entries = [
            (result.interface_name, link)
            for result in self.summary.results
            for link in self._database_links(result)
        ]
        if not entries:
            return

        sheet = workbook.add_worksheet("Database Links")
        columns = [
            ("Interface Name", 28),
            ("Link", 30),
            ("Status", 13),
            ("Remote User", 20),
            ("Target", 46),
            ("Latency (ms)", 13),
            ("ORA Code", 11),
            ("Detail", 70),
        ]
        for index, (heading, width) in enumerate(columns):
            sheet.write(0, index, heading, formats["header"])
            sheet.set_column(index, index, width)
        sheet.set_row(0, 28)

        status_formats = {
            "OK": formats["pass"],
            "FAILED": formats["fail"],
            "NOT CHECKED": formats["skip"],
        }

        for row_index, (interface_name, link) in enumerate(entries, start=1):
            status = str(link.get("status", ""))
            latency = link.get("latency_ms")
            sheet.write(row_index, 0, interface_name, formats["cell"])
            sheet.write(row_index, 1, str(link.get("name", "")), formats["cell"])
            sheet.write(
                row_index, 2, status, status_formats.get(status, formats["cell"])
            )
            sheet.write(row_index, 3, str(link.get("remote_user") or ""), formats["cell"])
            sheet.write(row_index, 4, str(link.get("target") or ""), formats["cell"])
            if isinstance(latency, (int, float)):
                sheet.write_number(row_index, 5, float(latency), formats["number"])
            else:
                sheet.write(row_index, 5, "", formats["cell"])
            ora_code = link.get("ora_code")
            if isinstance(ora_code, int):
                sheet.write_number(row_index, 6, ora_code, formats["integer"])
            else:
                sheet.write(row_index, 6, "", formats["cell"])
            sheet.write(row_index, 7, str(link.get("message") or ""), formats["cell"])

        sheet.autofilter(0, 0, len(entries), len(columns) - 1)
        sheet.freeze_panes(1, 1)
        sheet.set_landscape()
        sheet.fit_to_pages(1, 0)
        sheet.repeat_rows(0)

    @staticmethod
    def _database_links(result: ValidationResult) -> list[Mapping[str, Any]]:
        """Return the database link records recorded on one result."""
        links = result.details.get("db_links")
        if not isinstance(links, (list, tuple)):
            return []
        return [link for link in links if isinstance(link, Mapping)]

    def _excel_statistics_sheet(self, workbook: Any, formats: Mapping[str, Any]) -> None:
        """Write the statistics sheet."""
        summary = self.summary
        sheet = workbook.add_worksheet("Statistics")
        sheet.set_column("A:A", 30)
        sheet.set_column("B:E", 14)

        row = 0
        for title, breakdown in (
            ("By connectivity type", summary.counts_by_type()),
            ("By category", summary.counts_by_category()),
        ):
            sheet.write(row, 0, title, formats["title"])
            row += 1
            for index, heading in enumerate(
                ["Name", "Total", "Passed", "Failed", "Skipped"]
            ):
                sheet.write(row, index, heading, formats["header"])
            row += 1
            for name, counts in breakdown.items():
                sheet.write(row, 0, name, formats["cell"])
                sheet.write_number(row, 1, counts["total"], formats["integer"])
                sheet.write_number(row, 2, counts["passed"], formats["integer"])
                sheet.write_number(row, 3, counts["failed"], formats["integer"])
                sheet.write_number(row, 4, counts["skipped"], formats["integer"])
                row += 1
            row += 1

        error_counts = summary.counts_by_error_code()
        sheet.write(row, 0, "Failures by cause", formats["title"])
        row += 1
        sheet.write(
            row, 0,
            "One cause dominating many interfaces indicates a single change, not many faults.",
            formats["subtitle"],
        )
        row += 1
        for index, heading in enumerate(["Error code", "Interfaces affected"]):
            sheet.write(row, index, heading, formats["header"])
        row += 1
        if error_counts:
            for code, count in error_counts.items():
                sheet.write(row, 0, code, formats["cell"])
                sheet.write_number(row, 1, count, formats["integer"])
                row += 1
        else:
            sheet.write(row, 0, "No failures recorded.", formats["cell"])
            row += 1

        row += 1
        slowest = summary.slowest_result
        sheet.write(row, 0, "Slowest interface", formats["label"])
        sheet.write(
            row, 1,
            f"{slowest.interface_name} ({slowest.duration_display})" if slowest else "n/a",
            formats["value"],
        )

    # ------------------------------------------------------------------
    # JSON
    # ------------------------------------------------------------------

    def _generate_json(self) -> Path:
        """Write the machine-readable report, including stack traces."""
        payload = {
            "generator": {"name": APP_NAME, "version": APP_VERSION},
            **self.summary.to_dict(include_stack_trace=True),
        }
        path = self._report_path("json")
        atomic_write_text(
            path, json.dumps(payload, indent=2, ensure_ascii=False, default=str) + "\n"
        )
        return path
