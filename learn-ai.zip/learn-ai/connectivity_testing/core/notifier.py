"""HTML e-mail notification with report attachments.

Delivery policy
---------------
Notification is a downstream side effect of a run whose verdict is already
established and already written to disk. **A delivery failure therefore never
changes the exit code.** If it did, an SMTP relay outage would raise a
connectivity incident that does not exist, and would keep doing so until
somebody noticed the reports on disk were clean all along. The failure is
logged, recorded on the summary and surfaced on the console instead.

Attachment budget
-----------------
Mail relays reject oversized messages, usually by silently dropping them.
Attachments are therefore added in priority order -- PDF, Excel, JSON, then
the log -- until the configured budget is reached. Anything omitted is named
in the body along with the host it remains on, so the recipient is never left
wondering whether a report was produced. The application log is the one
attachment that grows without bound, so when it alone exceeds the remaining
budget its tail is attached instead of dropping it entirely: the end of the
log is where the failure is.

Client compatibility
--------------------
The body is sent as ``multipart/alternative`` with a plain-text part first.
The text part is not a courtesy: relays that strip HTML, terminal mail clients
and pager gateways all show it, and it is what an on-call engineer reads from
a phone notification.

Identity
--------
The HTML part carries the Northern Powergrid masthead defined in
:mod:`core.theme` -- the same banner, wordmark and palette as the attached PDF
report -- so the message and its attachment are recognisably one deliverable.
"""

from __future__ import annotations

import mimetypes
import smtplib
import ssl
from collections.abc import Sequence
from dataclasses import dataclass
from email.message import EmailMessage
from email.utils import formataddr, formatdate, make_msgid
from pathlib import Path

from core import theme
from core.constants import (
    APP_NAME,
    APP_VERSION,
    DISPLAY_TIMESTAMP_FORMAT,
)
from core.exceptions import NotificationError
from core.logging_setup import get_audit_logger, get_logger
from core.reporting import GeneratedReport
from models.results import ExecutionSummary
from models.settings import EmailSettings, SmtpSecurity
from utilities.fs import human_readable_size
from utilities.platform_info import collect_platform_info

__all__ = ["EmailNotifier", "PreparedAttachment"]

_logger = get_logger(__name__)

#: Media types for extensions the platform mimetypes database does not know,
#: or gets wrong for our purposes.
_EXPLICIT_MEDIA_TYPES: dict[str, str] = {
    ".log": "text/plain",
    ".json": "application/json",
    ".pdf": "application/pdf",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
}

#: Bytes of the log tail attached when the whole log will not fit.
_LOG_TAIL_BYTES = 256 * 1024

#: Below this remaining budget a truncated log is not worth attaching.
_MIN_TAIL_BUDGET = 32 * 1024


@dataclass(frozen=True, slots=True)
class PreparedAttachment:
    """A file selected for attachment, with its payload already read."""

    name: str
    data: bytes
    maintype: str
    subtype: str
    truncated: bool = False

    @property
    def size_bytes(self) -> int:
        """Return the attached payload size."""
        return len(self.data)

    @property
    def size_display(self) -> str:
        """Return the size formatted for the e-mail body."""
        suffix = " (truncated)" if self.truncated else ""
        return f"{human_readable_size(self.size_bytes)}{suffix}"


class EmailNotifier:
    """Composes and delivers the post-run notification e-mail."""

    def __init__(
        self,
        settings: EmailSettings,
        *,
        smtp_password: str | None = None,
        template_directory: Path | None = None,
    ) -> None:
        """Initialise the notifier.

        Args:
            settings: Validated e-mail configuration.
            smtp_password: The already-decrypted SMTP password. Resolved by the
                caller so that decryption stays in one place, exactly as it
                does for connectors.
            template_directory: Override the template location.
        """
        self.settings = settings
        self.smtp_password = smtp_password
        self.template_directory = template_directory or (
            Path(__file__).resolve().parent.parent / "templates"
        )
        self._audit = get_audit_logger()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def notify(
        self,
        summary: ExecutionSummary,
        reports: Sequence[GeneratedReport] = (),
        log_files: Sequence[Path] = (),
    ) -> bool:
        """Send the notification if configuration and outcome call for one.

        Never raises. The outcome is recorded on ``summary`` so it appears in
        the JSON report and on the console.

        Returns:
            ``True`` when a message was handed to the relay.
        """
        if not self.settings.should_send(has_failures=summary.has_failures):
            reason = (
                "e-mail notification is disabled"
                if not self.settings.enabled
                else (
                    "send_on_failure is false"
                    if summary.has_failures
                    else "send_on_success is false"
                )
            )
            _logger.info("No notification sent: %s.", reason)
            summary.notification_sent = False
            return False

        try:
            attachments, omitted = self._select_attachments(summary, reports, log_files)
            message = self._build_message(summary, attachments, omitted)
            self._deliver(message)
        except NotificationError as error:
            # Logged without a traceback: this is a classified condition that
            # already carries an actionable message. The traceback goes to the
            # debug log for whoever needs it.
            _logger.error("Notification failed: %s", error.message)  # noqa: TRY400
            if error.remediation:
                _logger.error("Remediation: %s", error.remediation)  # noqa: TRY400
            _logger.debug("Notification failure traceback", exc_info=True)
            summary.notification_sent = False
            summary.notification_error = error.message
            self._audit.info(
                "NOTIFICATION run_id=%s status=FAILED error=%s", summary.run_id, error.error_code
            )
            return False
        except Exception as error:  # noqa: BLE001 - delivery must never abort a run
            _logger.exception("Notification failed unexpectedly.")
            summary.notification_sent = False
            summary.notification_error = f"{type(error).__name__}: {error}"
            self._audit.info("NOTIFICATION run_id=%s status=FAILED", summary.run_id)
            return False

        recipients = self.settings.all_recipients
        _logger.info(
            "Notification sent to %d recipient(s) with %d attachment(s).",
            len(recipients),
            len(attachments),
        )
        summary.notification_sent = True
        summary.notification_error = None
        self._audit.info(
            "NOTIFICATION run_id=%s status=SENT recipients=%d attachments=%d",
            summary.run_id,
            len(recipients),
            len(attachments),
        )
        return True

    # ------------------------------------------------------------------
    # Attachments
    # ------------------------------------------------------------------

    def _select_attachments(
        self,
        summary: ExecutionSummary,
        reports: Sequence[GeneratedReport],
        log_files: Sequence[Path],
    ) -> tuple[list[PreparedAttachment], list[str]]:
        """Choose attachments within the size budget.

        Returns:
            The attachments to include, and a description of each file left
            out so the body can name it.
        """
        budget = self.settings.max_attachment_mb * 1024 * 1024
        used = 0
        attachments: list[PreparedAttachment] = []
        omitted: list[str] = []

        candidates: list[Path] = []
        if self.settings.attach_reports:
            # PDF first: it is the one a recipient opens.
            order = {"pdf": 0, "excel": 1, "json": 2}
            candidates.extend(
                report.path
                for report in sorted(reports, key=lambda item: order.get(item.format, 9))
            )
        if self.settings.attach_log_file:
            candidates.extend(log_files)

        for path in candidates:
            try:
                size = path.stat().st_size
            except OSError as error:
                _logger.warning("Attachment unavailable: %s (%s)", path, error)
                omitted.append(f"{path} (unreadable)")
                continue

            remaining = budget - used
            if size <= remaining:
                try:
                    data = path.read_bytes()
                except OSError as error:
                    _logger.warning("Attachment could not be read: %s (%s)", path, error)
                    omitted.append(f"{path} (unreadable)")
                    continue
                attachments.append(self._prepare(path, data))
                used += len(data)
                continue

            tail = self._prepare_tail(path, remaining)
            if tail is not None:
                attachments.append(tail)
                used += tail.size_bytes
                omitted.append(f"{path} (full file, {human_readable_size(size)})")
            else:
                _logger.info(
                    "Attachment omitted, over the %d MB budget: %s (%s)",
                    self.settings.max_attachment_mb,
                    path,
                    human_readable_size(size),
                )
                omitted.append(f"{path} ({human_readable_size(size)})")

        summary.report_paths.setdefault("attachments", str(len(attachments)))
        return attachments, omitted

    @staticmethod
    def _prepare(path: Path, data: bytes) -> PreparedAttachment:
        """Build an attachment with a sensible MIME type.

        ``.log`` has no registered media type, so :mod:`mimetypes` would fall
        back to ``application/octet-stream`` and mail clients would offer the
        log as a download rather than previewing it. Naming it as text is what
        lets an engineer read the tail of the log without leaving the message.
        """
        guessed = _EXPLICIT_MEDIA_TYPES.get(path.suffix.lower())
        if guessed is None:
            guessed, _ = mimetypes.guess_type(path.name)
        maintype, _, subtype = (guessed or "application/octet-stream").partition("/")
        return PreparedAttachment(
            name=path.name, data=data, maintype=maintype, subtype=subtype or "octet-stream"
        )

    def _prepare_tail(self, path: Path, remaining: int) -> PreparedAttachment | None:
        """Return the tail of a log that will not fit whole, if worthwhile.

        Only logs are truncated. A partial report would be misleading evidence,
        whereas the end of a log is precisely the part that explains a failure.
        """
        if path.suffix.lower() not in (".log", ".txt"):
            return None
        if remaining < _MIN_TAIL_BUDGET:
            return None

        window = min(_LOG_TAIL_BYTES, remaining - 1024)
        try:
            with path.open("rb") as handle:
                handle.seek(max(0, path.stat().st_size - window))
                data = handle.read()
        except OSError as error:
            _logger.warning("Log tail could not be read: %s (%s)", path, error)
            return None

        header = (
            f"--- TRUNCATED: last {human_readable_size(len(data))} of {path.name}. "
            f"The complete log remains on the executing host at {path}. ---\n"
        ).encode()
        return PreparedAttachment(
            name=f"{path.stem}.tail{path.suffix}",
            data=header + data,
            maintype="text",
            subtype="plain",
            truncated=True,
        )

    # ------------------------------------------------------------------
    # Composition
    # ------------------------------------------------------------------

    def _subject(self, summary: ExecutionSummary) -> str:
        """Return the subject line.

        The outcome comes first after the configured prefix, so it is legible
        in a phone notification and in a mailbox rule.
        """
        parts = [f"{self.settings.subject_prefix} - {summary.status_word}"]
        if summary.environment:
            parts.append(summary.environment.upper())
        if summary.has_failures:
            parts.append(f"{summary.failed} of {summary.validated_interfaces} failed")
        return " | ".join(parts)

    def _headline(self, summary: ExecutionSummary) -> str:
        """Return the opening sentence of the body."""
        if not summary.has_failures:
            if summary.validated_interfaces == 0:
                return (
                    "No interface was validated in this run: every configured interface is "
                    "disabled. Nothing was tested, so this result confirms nothing about "
                    "the estate."
                )
            return (
                f"All {summary.passed} validated connection(s) succeeded in "
                f"{summary.duration_display}. No action is required."
            )
        return (
            f"{summary.failed} of {summary.validated_interfaces} validated connection(s) "
            f"failed. The failing endpoints and the recommended action for each are listed "
            f"below; full detail is in the attached reports."
        )

    def _build_message(
        self,
        summary: ExecutionSummary,
        attachments: Sequence[PreparedAttachment],
        omitted: Sequence[str],
    ) -> EmailMessage:
        """Compose the multipart message.

        Raises:
            NotificationError: if the body cannot be rendered.
        """
        settings = self.settings
        platform = collect_platform_info()

        message = EmailMessage()
        message["Subject"] = self._subject(summary)
        message["From"] = formataddr((settings.sender_display_name, settings.sender or ""))
        message["To"] = ", ".join(settings.recipients)
        if settings.cc:
            message["Cc"] = ", ".join(settings.cc)
        # Bcc is deliberately not written as a header: it is an envelope
        # recipient only, and adding the header would disclose the list.
        message["Date"] = formatdate(localtime=True)
        message["Message-ID"] = make_msgid(domain=platform.hostname or None)
        message["X-Connectivity-Run-Id"] = summary.run_id
        message["X-Connectivity-Status"] = summary.status_word
        message["X-Connectivity-Environment"] = summary.environment
        message["Auto-Submitted"] = "auto-generated"

        text_body = self._render_text(summary, attachments, omitted, platform.hostname)
        message.set_content(text_body)

        # The HTML body is presentation; the alert is the payload. If rendering
        # fails -- a missing template on a partial install being the likeliest
        # cause -- the plain-text part is complete on its own and is sent
        # rather than withholding notice of a failing estate over styling.
        html_body: str | None
        try:
            html_body = self._render_html(summary, attachments, omitted, platform.hostname)
        except Exception as error:  # noqa: BLE001 - never lose the alert over presentation
            _logger.warning(
                "HTML body could not be rendered (%s: %s); sending the plain-text "
                "alternative only.",
                type(error).__name__,
                error,
            )
            _logger.debug("HTML rendering traceback", exc_info=True)
            html_body = None

        if html_body:
            message.add_alternative(html_body, subtype="html")

        for attachment in attachments:
            message.add_attachment(
                attachment.data,
                maintype=attachment.maintype,
                subtype=attachment.subtype,
                filename=attachment.name,
            )

        return message

    def _render_html(
        self,
        summary: ExecutionSummary,
        attachments: Sequence[PreparedAttachment],
        omitted: Sequence[str],
        hostname: str,
    ) -> str:
        """Render the HTML body.

        Raises:
            NotificationError: if Jinja2 or the template is unavailable.
        """
        try:
            from jinja2 import Environment, FileSystemLoader, StrictUndefined, select_autoescape
        except ImportError as error:  # pragma: no cover - declared as a core dependency
            raise NotificationError(
                "Jinja2 is required to render the notification e-mail but is not installed.",
                remediation='Install it: pip install "Jinja2>=3.1,<4.0"',
                cause=error,
            ) from error

        template_file = self.template_directory / "email.html.j2"
        if not template_file.is_file():
            raise NotificationError(
                f"E-mail template not found: {template_file}",
                remediation=(
                    "The installation is incomplete. Restore the 'templates' directory."
                ),
                details={"template": str(template_file)},
            )

        environment = Environment(
            loader=FileSystemLoader(str(self.template_directory)),
            autoescape=select_autoescape(default_for_string=True, default=True),
            undefined=StrictUndefined,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        generated_at = summary.ended_at.strftime(DISPLAY_TIMESTAMP_FORMAT)
        severity_color = theme.SEVERITY_COLOR[summary.severity]

        # The theme owns the markup and the caller owns the data, so every
        # value interpolated into a fragment is escaped here first.
        hero_html = theme.hero_rows(
            "CONNECTIVITY VALIDATION",
            f"Validation {theme.esc(summary.status_word)}",
            chips=[
                theme.badge(
                    severity_color,
                    "#FFFFFF",
                    theme.esc(summary.severity.value.upper()),
                ),
                theme.badge(
                    theme.CHIP_BG, "#FFFFFF", theme.esc(summary.environment.upper())
                ),
                theme.badge(
                    theme.CHIP_BG,
                    "#FFFFFF",
                    theme.esc(f"{summary.passed}/{summary.validated_interfaces} PASSED"),
                ),
            ],
        )
        footer_html = theme.footer_rows(
            f"Connectivity Validation &middot; {theme.esc(summary.environment)}"
        )

        return environment.get_template("email.html.j2").render(
            summary=summary,
            subject=self._subject(summary),
            headline=self._headline(summary),
            environment=summary.environment,
            severity_color=severity_color,
            hero_html=hero_html,
            footer_html=footer_html,
            palette=theme,
            generated_at=generated_at,
            hostname=hostname,
            attachments=list(attachments),
            omitted=list(omitted),
            max_attachment_mb=self.settings.max_attachment_mb,
            warnings=[
                (result.interface_name, warning)
                for result in summary.results
                for warning in result.warnings
            ],
            app_name=APP_NAME,
            app_version=APP_VERSION,
        )

    def _render_text(
        self,
        summary: ExecutionSummary,
        attachments: Sequence[PreparedAttachment],
        omitted: Sequence[str],
        hostname: str,
    ) -> str:
        """Render the plain-text alternative.

        Built by hand rather than templated: it must never fail, because it is
        the part that survives a relay stripping HTML and the part a pager
        gateway forwards.
        """
        lines = [
            f"{APP_NAME}",
            f"{summary.status_word} - {summary.environment}",
            "=" * 64,
            "",
            self._headline(summary),
            "",
            f"Total interfaces : {summary.total_interfaces}",
            f"Passed           : {summary.passed}",
            f"Failed           : {summary.failed}",
            f"Skipped          : {summary.skipped}",
            f"Success rate     : {summary.success_percentage:.1f}% of "
            f"{summary.validated_interfaces} validated",
            f"Duration         : {summary.duration_display}",
            f"Executed on      : {hostname}",
            f"Run identifier   : {summary.run_id}",
            f"Configuration    : {summary.config_path}",
            "",
        ]

        if summary.failed_results:
            lines.append(f"FAILED CONNECTIONS ({len(summary.failed_results)})")
            lines.append("-" * 64)
            for result in summary.failed_results:
                lines.append(f"  {result.interface_name} [{result.interface_type.value}]")
                lines.append(f"    endpoint : {result.endpoint}")
                lines.append(f"    error    : [{result.error_code}] {result.error_message}")
                if result.remediation:
                    lines.append(f"    action   : {result.remediation}")
                lines.append("")

        warnings = [
            (result.interface_name, warning)
            for result in summary.results
            for warning in result.warnings
        ]
        if warnings:
            lines.append(f"WARNINGS ({len(warnings)})")
            lines.append("-" * 64)
            lines.extend(f"  {name}: {warning}" for name, warning in warnings)
            lines.append("")

        if summary.successful_results:
            lines.append(f"SUCCESSFUL CONNECTIONS ({len(summary.successful_results)})")
            lines.append("-" * 64)
            lines.extend(
                f"  {result.interface_name} -> {result.endpoint} ({result.latency_display})"
                for result in summary.successful_results
            )
            lines.append("")

        lines.append("ATTACHMENTS")
        lines.append("-" * 64)
        if attachments:
            lines.extend(
                f"  {attachment.name} ({attachment.size_display})" for attachment in attachments
            )
        else:
            lines.append("  none")
        if omitted:
            lines.append("")
            lines.append(
                f"  Not attached (over the {self.settings.max_attachment_mb} MB limit); "
                f"these remain on {hostname}:"
            )
            lines.extend(f"    {item}" for item in omitted)

        lines.extend(["", "-" * 64, f"{APP_NAME} {APP_VERSION}. Automated message; do not reply."])
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Delivery
    # ------------------------------------------------------------------

    def _deliver(self, message: EmailMessage) -> None:
        """Hand the message to the configured SMTP relay.

        Raises:
            NotificationError: on any connection, TLS, authentication or
                delivery failure, each with its own remediation.
        """
        settings = self.settings
        host = settings.smtp_server or ""
        port = settings.smtp_port
        recipients = settings.all_recipients

        context: ssl.SSLContext | None = None
        if settings.security in (SmtpSecurity.STARTTLS, SmtpSecurity.SSL):
            context = ssl.create_default_context()
            if not settings.verify_ssl:
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
                _logger.warning(
                    "SMTP certificate verification is disabled for %s.", host
                )

        try:
            if settings.security is SmtpSecurity.SSL:
                client: smtplib.SMTP = smtplib.SMTP_SSL(
                    host, port, timeout=settings.timeout_seconds, context=context
                )
            else:
                client = smtplib.SMTP(host, port, timeout=settings.timeout_seconds)

            with client:
                client.ehlo()
                if settings.security is SmtpSecurity.STARTTLS:
                    client.starttls(context=context)
                    client.ehlo()

                if settings.username:
                    client.login(settings.username, self.smtp_password or "")

                client.send_message(message, from_addr=settings.sender, to_addrs=recipients)

        except smtplib.SMTPAuthenticationError as error:
            raise NotificationError(
                f"The SMTP server rejected the credentials for '{settings.username}': {error}",
                remediation=(
                    "Verify the SMTP username and password. Many relays require an "
                    "application password rather than the account password, and some "
                    "accept mail from an allow-listed host with no credentials at all, in "
                    "which case clear the username."
                ),
                details={"smtp_server": host, "smtp_port": port},
                cause=error,
            ) from error

        except smtplib.SMTPRecipientsRefused as error:
            raise NotificationError(
                f"Every recipient was refused by {host}: {error.recipients}",
                remediation=(
                    "Check the recipient addresses and whether the relay permits delivery "
                    "to external domains from this host."
                ),
                details={"smtp_server": host},
                cause=error,
            ) from error

        except smtplib.SMTPSenderRefused as error:
            raise NotificationError(
                f"The sender address '{settings.sender}' was refused by {host}: {error}",
                remediation=(
                    "The relay does not accept this From address. Use an address the relay "
                    "is configured to allow, commonly a no-reply mailbox in your own domain."
                ),
                details={"smtp_server": host},
                cause=error,
            ) from error

        except ssl.SSLError as error:
            raise NotificationError(
                f"TLS negotiation with the SMTP server {host}:{port} failed: {error}",
                remediation=(
                    "The relay's certificate is not trusted by this host, or the configured "
                    "security mode does not match. STARTTLS upgrades a plain connection, "
                    "usually on 587; SSL expects TLS from connect, usually on 465."
                ),
                details={"smtp_server": host, "smtp_port": port},
                cause=error,
            ) from error

        except (OSError, smtplib.SMTPException) as error:
            raise NotificationError(
                f"The SMTP server {host}:{port} could not be reached: "
                f"{type(error).__name__}: {error}",
                remediation=(
                    "Check the relay host and port, and that this host is permitted to send "
                    "mail. Relays commonly restrict submission by source address, so a "
                    "configuration proven on a workstation can fail on a batch server."
                ),
                details={"smtp_server": host, "smtp_port": port},
                cause=error,
            ) from error
