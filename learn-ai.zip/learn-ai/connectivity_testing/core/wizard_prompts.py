"""Console rendering and prompt primitives for the configuration wizard.

Every prompt in the wizard goes through this module rather than calling
``questionary`` directly. That buys three things:

* **One validation path.** Prompts reuse the validators from
  :mod:`utilities.validators`, which are the same functions the pydantic
  models enforce on load. A value the wizard accepts cannot be rejected later
  by the loader.
* **Consistent abort handling.** ``questionary`` returns ``None`` when the
  operator presses Ctrl-C. Left unchecked that ``None`` flows into the
  configuration as a real value. Every helper here converts it into
  :class:`WizardAbortedError` instead.
* **Terminal portability.** Tables and panels are drawn with ASCII box
  characters. The wizard is routinely run over an SSH session to an AIX host
  where the terminal is not UTF-8, and Unicode box drawing renders there as
  mojibake.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import Any, TypeVar

import questionary
from questionary import Choice
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from core.constants import APP_NAME, APP_VERSION
from utilities.validators import as_prompt_validator

__all__ = [
    "WizardAbortedError",
    "ask_bool",
    "ask_choice",
    "ask_int",
    "ask_secret",
    "ask_text",
    "console",
    "print_banner",
    "print_error",
    "print_info",
    "print_key_values",
    "print_section",
    "print_success",
    "print_warning",
]

T = TypeVar("T")

#: Shared console. ``highlight`` is disabled so that host names and paths are
#: not re-coloured by rich's automatic syntax detection, which makes an IP
#: address look like a value the operator is meant to act on.
console: Console = Console(highlight=False, soft_wrap=False)

#: Prompt styling. Deliberately restrained: a batch tool's configuration
#: wizard is read by an engineer under change-window pressure, not admired.
WIZARD_STYLE = questionary.Style(
    [
        ("qmark", "fg:#00afaf bold"),
        ("question", "bold"),
        ("answer", "fg:#00afaf bold"),
        ("pointer", "fg:#00afaf bold"),
        ("highlighted", "fg:#00afaf bold"),
        ("selected", "fg:#00af00"),
        ("separator", "fg:#6c6c6c"),
        ("instruction", "fg:#6c6c6c italic"),
        ("text", ""),
        ("disabled", "fg:#6c6c6c italic"),
    ]
)


class WizardAbortedError(Exception):
    """The operator cancelled the wizard with Ctrl-C or EOF.

    Raised instead of returning ``None`` so that an abort can never be
    mistaken for a supplied value and silently written into a configuration.
    """


def _require(value: T | None) -> T:
    """Return ``value``, converting a cancelled prompt into an abort.

    Raises:
        WizardAbortedError: when ``questionary`` reported a cancellation.
    """
    if value is None:
        raise WizardAbortedError("Configuration cancelled by the operator.")
    return value


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------


def print_banner() -> None:
    """Print the wizard title panel."""
    title = Text(APP_NAME, style="bold cyan")
    subtitle = Text(
        f"Configuration Wizard  |  version {APP_VERSION}", style="dim"
    )
    body = Text.assemble(title, "\n", subtitle)
    console.print()
    console.print(Panel(body, box=box.ASCII, border_style="cyan", padding=(1, 4)))
    console.print(
        "  Answer the prompts to build a validated configuration file.\n"
        "  Press [bold]Ctrl-C[/bold] at any point to abort without writing anything.\n",
        style="dim",
    )


def print_section(number: str, title: str, description: str = "") -> None:
    """Print a numbered section heading."""
    console.print()
    console.rule(f"[bold cyan]Step {number}[/bold cyan]  {title}", style="cyan", align="left")
    if description:
        console.print(f"  {description}", style="dim")
    console.print()


def print_success(message: str) -> None:
    """Print a confirmation message."""
    console.print(f"  [bold green][ OK ][/bold green] {message}")


def print_warning(message: str) -> None:
    """Print a non-fatal warning."""
    console.print(f"  [bold yellow][WARN][/bold yellow] {message}")


def print_error(message: str) -> None:
    """Print an error message."""
    console.print(f"  [bold red][FAIL][/bold red] {message}")


def print_info(message: str) -> None:
    """Print an informational note."""
    console.print(f"  [bold blue][INFO][/bold blue] {message}")


def print_key_values(title: str, rows: Sequence[tuple[str, str]]) -> None:
    """Print a two-column summary table.

    Callers must mask secrets before passing them here; this function does not
    inspect values, and printing a credential to a shared terminal is exactly
    the kind of leak the framework exists to avoid.
    """
    table = Table(
        title=title,
        box=box.ASCII,
        title_style="bold cyan",
        title_justify="left",
        show_header=False,
        padding=(0, 1),
    )
    table.add_column("Field", style="bold", no_wrap=True)
    table.add_column("Value", overflow="fold")
    for label, value in rows:
        table.add_row(label, value)
    console.print(table)


# ---------------------------------------------------------------------------
# Input
# ---------------------------------------------------------------------------


def ask_text(
    message: str,
    *,
    default: str = "",
    validator: Callable[[str], Any] | None = None,
    allow_empty: bool = False,
    instruction: str | None = None,
) -> str:
    """Prompt for a line of text.

    Args:
        message: Prompt text.
        default: Pre-filled value, accepted by pressing Enter.
        validator: A validator from :mod:`utilities.validators`. Applied both
            interactively and to the returned value, so the normalised form is
            what gets stored.
        allow_empty: Permit an empty answer, which the caller treats as "not
            configured".
        instruction: Grey hint shown after the prompt.

    Returns:
        The normalised value, or an empty string when empty input is allowed.

    Raises:
        WizardAbortedError: if the operator cancels.
    """
    def require_non_empty(value: str) -> bool | str:
        return True if value.strip() else "A value is required."

    prompt_validator: Callable[[str], bool | str] | None
    if validator is not None:
        # An answer that is empty but has a default is valid: pressing Enter
        # accepts the default rather than submitting a blank value.
        prompt_validator = as_prompt_validator(
            validator, allow_empty=allow_empty or bool(default)
        )
    elif allow_empty:
        prompt_validator = None
    else:
        prompt_validator = require_non_empty

    raw: str = _require(
        questionary.text(
            message,
            default=default,
            validate=prompt_validator,
            instruction=instruction,
            style=WIZARD_STYLE,
        ).ask()
    )

    answer = raw.strip() or default.strip()
    if not answer:
        return ""
    if validator is not None:
        # Normalise through the validator so the stored value is the canonical
        # form: a lower-cased host, a stripped path, an upper-cased method.
        return str(validator(answer))
    return answer


def ask_secret(
    message: str,
    *,
    allow_empty: bool = True,
    confirm: bool = False,
    instruction: str | None = None,
) -> str:
    """Prompt for a credential without echoing it to the terminal.

    Args:
        message: Prompt text.
        allow_empty: Permit an empty answer for an optional credential.
        confirm: Ask twice and require the answers to match. Used where a typo
            would only surface as an authentication failure during the next
            change window.
        instruction: Grey hint shown after the prompt.

    Returns:
        The secret in plaintext, or an empty string. The caller is responsible
        for encrypting it before it reaches a model or the disk.

    Raises:
        WizardAbortedError: if the operator cancels.
    """

    def _validate(value: str) -> bool | str:
        if not value and not allow_empty:
            return "A value is required."
        return True

    first: str = _require(
        questionary.password(
            message, validate=_validate, instruction=instruction, style=WIZARD_STYLE
        ).ask()
    )
    if not first:
        return ""

    if confirm:
        second: str = _require(
            questionary.password("Re-enter to confirm:", style=WIZARD_STYLE).ask()
        )
        if first != second:
            print_error("The values do not match. Please enter the credential again.")
            return ask_secret(
                message, allow_empty=allow_empty, confirm=confirm, instruction=instruction
            )
    return first


def ask_int(
    message: str,
    *,
    default: int,
    validator: Callable[[Any], int] | None = None,
) -> int:
    """Prompt for a whole number.

    Raises:
        WizardAbortedError: if the operator cancels.
    """

    def _validate(value: str) -> bool | str:
        candidate = value.strip()
        if not candidate:
            return True  # Empty accepts the default.
        try:
            if validator is not None:
                validator(candidate)
            else:
                int(candidate)
        except ValueError as error:
            return str(error)
        return True

    answer = _require(
        questionary.text(
            message, default=str(default), validate=_validate, style=WIZARD_STYLE
        ).ask()
    ).strip()

    if not answer:
        return default
    return validator(answer) if validator is not None else int(answer)


def ask_bool(message: str, *, default: bool = True) -> bool:
    """Prompt for a yes/no answer.

    Raises:
        WizardAbortedError: if the operator cancels.
    """
    return bool(
        _require(questionary.confirm(message, default=default, style=WIZARD_STYLE).ask())
    )


def ask_choice(
    message: str,
    choices: Sequence[tuple[str, T]],
    *,
    default: T | None = None,
    instruction: str | None = None,
) -> T:
    """Prompt for one option from a list.

    Args:
        message: Prompt text.
        choices: ``(label, value)`` pairs in presentation order.
        default: Value pre-selected when the list opens.
        instruction: Grey hint shown after the prompt.

    Returns:
        The value associated with the selected label.

    Raises:
        WizardAbortedError: if the operator cancels.
    """
    options = [Choice(title=label, value=value) for label, value in choices]
    selected_default = None
    if default is not None:
        selected_default = next(
            (option for option in options if option.value == default), None
        )

    selected: T = _require(
        questionary.select(
            message,
            choices=options,
            default=selected_default,
            instruction=instruction,
            style=WIZARD_STYLE,
            use_shortcuts=False,
            use_indicator=True,
        ).ask()
    )
    return selected
