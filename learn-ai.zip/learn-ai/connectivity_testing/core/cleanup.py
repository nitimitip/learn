"""Retention based housekeeping for generated reports.

The framework runs daily under a scheduler and writes three files per run.
Left alone the reports directory grows without bound and eventually fills the
filesystem, which turns a monitoring tool into an outage. Cleanup runs before
each validation so that a run always begins by making room for its own output.

Deleting files automatically is a dangerous capability, so the authority to do
it is deliberately narrow. A file is removed only when **all** of these hold:

1. it sits directly in the configured reports directory, never a subdirectory;
2. its name begins with :data:`~core.constants.REPORT_FILENAME_PREFIX`;
3. its extension is one this framework produces;
4. it is a regular file, not a symbolic link or a directory;
5. its modification time is older than the retention period.

Conditions 2 and 3 together are the safety gate: the framework can only delete
files it demonstrably created. An operator who drops ``notes.txt`` or a
manually saved ``evidence.html`` into the reports folder keeps it, because
neither carries the framework's prefix.

Failure policy
--------------
Cleanup is housekeeping, not validation. Every failure -- a locked file, a
permission denial, a missing directory -- is logged and recorded, and the run
proceeds. Refusing to validate connectivity because an old report could not be
deleted would withhold exactly the information the run exists to produce.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path

from core.constants import (
    REPORT_FILE_EXTENSIONS,
    REPORT_FILENAME_PREFIX,
)
from core.logging_setup import get_audit_logger, get_logger
from utilities.fs import human_readable_size

__all__ = ["CleanupOutcome", "ReportCleaner"]

_logger = get_logger(__name__)


@dataclass(slots=True)
class CleanupOutcome:
    """What a cleanup pass did, for the report and the audit trail."""

    directory: Path
    retention_days: int
    deleted_files: list[str] = field(default_factory=list)
    bytes_reclaimed: int = 0
    examined: int = 0
    protected: int = 0
    """Files left alone because they were not produced by this framework."""
    errors: list[str] = field(default_factory=list)
    skipped_reason: str | None = None
    """Set when cleanup did not run at all, for example because it is disabled."""

    @property
    def deleted_count(self) -> int:
        """Return the number of files removed."""
        return len(self.deleted_files)

    @property
    def succeeded(self) -> bool:
        """Return ``True`` when the pass completed without error."""
        return not self.errors

    def summary_line(self) -> str:
        """Return a one-line description for the console and the log."""
        if self.skipped_reason:
            return f"Report cleanup skipped: {self.skipped_reason}"
        parts = [
            f"Report cleanup: {self.deleted_count} file(s) older than "
            f"{self.retention_days} day(s) removed"
        ]
        if self.bytes_reclaimed:
            parts.append(f"{human_readable_size(self.bytes_reclaimed)} reclaimed")
        if self.protected:
            parts.append(f"{self.protected} unrelated file(s) left untouched")
        if self.errors:
            parts.append(f"{len(self.errors)} error(s)")
        return ", ".join(parts) + "."


class ReportCleaner:
    """Removes expired reports from the reports directory."""

    def __init__(self, directory: Path, retention_days: int, *, enabled: bool = True) -> None:
        """Initialise the cleaner.

        Args:
            directory: The reports directory. Only its immediate contents are
                considered.
            retention_days: Files older than this are eligible for removal.
            enabled: When ``False`` the pass reports itself as skipped.
        """
        self.directory = Path(directory)
        self.retention_days = retention_days
        self.enabled = enabled
        self._audit = get_audit_logger()

    def run(self, *, dry_run: bool = False, now: float | None = None) -> CleanupOutcome:
        """Delete expired reports. Never raises.

        Args:
            dry_run: Report what would be deleted without deleting anything.
            now: Reference epoch seconds, injectable so retention behaviour is
                deterministic in tests rather than dependent on the wall clock.

        Returns:
            A :class:`CleanupOutcome` describing the pass.
        """
        outcome = CleanupOutcome(directory=self.directory, retention_days=self.retention_days)

        if not self.enabled:
            outcome.skipped_reason = "disabled in the configuration"
            _logger.info(outcome.summary_line())
            return outcome

        if not self.directory.exists():
            # Nothing to clean is a normal first run, not a problem.
            outcome.skipped_reason = f"the reports directory does not exist yet ({self.directory})"
            _logger.info(outcome.summary_line())
            return outcome

        if not self.directory.is_dir():
            message = f"The configured reports path is not a directory: {self.directory}"
            outcome.errors.append(message)
            _logger.error(message)
            return outcome

        reference = now if now is not None else time.time()
        cutoff_seconds = self.retention_days * 86400

        try:
            entries = list(self.directory.iterdir())
        except OSError as error:
            message = f"The reports directory could not be listed: {self.directory} ({error})"
            outcome.errors.append(message)
            _logger.exception(message)
            return outcome

        for entry in sorted(entries):
            self._consider(entry, outcome, reference, cutoff_seconds, dry_run=dry_run)

        _logger.info(outcome.summary_line())
        if outcome.deleted_count and not dry_run:
            self._audit.info(
                "CLEANUP directory=%s retention_days=%d deleted=%d bytes=%d",
                self.directory,
                self.retention_days,
                outcome.deleted_count,
                outcome.bytes_reclaimed,
            )
        return outcome

    def _consider(
        self,
        entry: Path,
        outcome: CleanupOutcome,
        reference: float,
        cutoff_seconds: float,
        *,
        dry_run: bool,
    ) -> None:
        """Evaluate one directory entry against the safety gate."""
        # A symlink is never followed and never removed. Its target may sit
        # anywhere on the filesystem, and an operator who placed it there did
        # so deliberately.
        if entry.is_symlink():
            outcome.protected += 1
            _logger.debug("Cleanup ignoring symbolic link: %s", entry)
            return

        if not entry.is_file():
            outcome.protected += 1
            return

        outcome.examined += 1

        if not self._is_framework_report(entry):
            outcome.protected += 1
            _logger.debug(
                "Cleanup ignoring a file this framework did not create: %s", entry.name
            )
            return

        try:
            stat_result = entry.stat()
        except OSError as error:
            message = f"Report could not be inspected: {entry.name} ({error})"
            outcome.errors.append(message)
            _logger.warning(message)
            return

        age_seconds = reference - stat_result.st_mtime
        if age_seconds < cutoff_seconds:
            return

        age_days = age_seconds / 86400.0
        if dry_run:
            _logger.info(
                "Report cleanup (dry run) would delete %s (%.1f days old, %s).",
                entry.name,
                age_days,
                human_readable_size(stat_result.st_size),
            )
            outcome.deleted_files.append(str(entry))
            outcome.bytes_reclaimed += stat_result.st_size
            return

        try:
            entry.unlink()
        except OSError as error:
            # A locked file on Windows, or an antivirus holding a handle, is
            # common and harmless. Record it and move on.
            message = f"Report could not be deleted: {entry.name} ({error.strerror or error})"
            outcome.errors.append(message)
            _logger.warning(message)
            return

        outcome.deleted_files.append(str(entry))
        outcome.bytes_reclaimed += stat_result.st_size
        _logger.info(
            "Deleted expired report %s (%.1f days old, %s).",
            entry.name,
            age_days,
            human_readable_size(stat_result.st_size),
        )

    @staticmethod
    def _is_framework_report(path: Path) -> bool:
        """Return ``True`` when this framework demonstrably produced the file.

        Both halves of the gate must hold. The prefix alone is not enough: a
        ``connectivity_report_notes.docx`` an operator saved beside the reports
        would otherwise be eligible for deletion.
        """
        return (
            path.name.startswith(REPORT_FILENAME_PREFIX)
            and path.suffix.lower() in REPORT_FILE_EXTENSIONS
        )
