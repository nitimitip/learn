"""Command line entry point for the configuration wizard.

Owns argument parsing, the top-level exception boundary and the process exit
code. The wizard itself contains no ``sys.exit`` call, which keeps it callable
from a test without terminating the interpreter.

Exit codes match the framework contract:

* ``0``  the configuration was written,
* ``2``  the operator aborted, or the environment cannot support the wizard,
* ``99`` an unexpected fault.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from core.constants import (
    APP_NAME,
    APP_VERSION,
    DEFAULT_CONFIG_DIRECTORY,
    MIN_PYTHON_VERSION,
    ExitCode,
)
from core.exceptions import ConnectivityFrameworkError
from core.wizard import ConfigurationWizard
from core.wizard_prompts import (
    WizardAbortedError,
    console,
    print_error,
    print_info,
    print_warning,
)
from utilities.fs import ensure_directory

__all__ = ["build_parser", "main"]


def build_parser() -> argparse.ArgumentParser:
    """Return the argument parser for ``generate_config.py``."""
    parser = argparse.ArgumentParser(
        prog="generate_config.py",
        description=(
            f"{APP_NAME} - interactive configuration wizard. Generates a validated "
            "JSON configuration with every credential encrypted."
        ),
        epilog=(
            "Examples:\n"
            "  python generate_config.py\n"
            "  python generate_config.py --config-dir /opt/connectivity/config\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--config-dir",
        type=Path,
        default=None,
        help=(
            "Directory for the generated configuration and its encryption key "
            f"(default: ./{DEFAULT_CONFIG_DIRECTORY})"
        ),
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable coloured output, for terminals or job logs that do not render ANSI.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"{APP_NAME} {APP_VERSION}",
    )
    return parser


def _check_python_version() -> None:
    """Abort early on an unsupported interpreter.

    Raises:
        SystemExit: when the interpreter predates the supported minimum.
    """
    if sys.version_info < MIN_PYTHON_VERSION:
        required = ".".join(str(part) for part in MIN_PYTHON_VERSION)
        current = ".".join(str(part) for part in sys.version_info[:3])
        print_error(f"Python {required} or later is required; this is Python {current}.")
        raise SystemExit(ExitCode.CONFIGURATION_ERROR)


def _check_interactive() -> bool:
    """Return ``True`` when the process has an interactive terminal.

    The wizard is interactive by definition. Started from a scheduler or a
    pipeline it would otherwise block forever on the first prompt, presenting
    as a hung job rather than a clear error.
    """
    return sys.stdin.isatty() and sys.stdout.isatty()


def main(argv: list[str] | None = None) -> int:
    """Run the configuration wizard.

    Args:
        argv: Argument list. Defaults to :data:`sys.argv` when omitted.

    Returns:
        A process exit code.
    """
    parser = build_parser()
    arguments = parser.parse_args(argv)

    if arguments.no_color:
        console.no_color = True

    _check_python_version()

    if not _check_interactive():
        print_error("The configuration wizard requires an interactive terminal.")
        print_info(
            "It appears to have been started by a scheduler or with redirected input. "
            "Run it from a terminal to generate a configuration, then let the scheduler "
            "run 'connectivity_validator.py' against the generated file."
        )
        return int(ExitCode.CONFIGURATION_ERROR)

    config_directory = arguments.config_dir or Path.cwd() / DEFAULT_CONFIG_DIRECTORY

    try:
        ensure_directory(config_directory, secure=True)
    except OSError as error:
        print_error(f"Configuration directory cannot be created: {config_directory}")
        print_info(f"{error.strerror or error}")
        return int(ExitCode.CONFIGURATION_ERROR)

    try:
        ConfigurationWizard(config_directory.resolve()).run()

    except WizardAbortedError as abort:
        console.print()
        print_warning(f"{abort} Nothing was written.")
        return int(ExitCode.CONFIGURATION_ERROR)

    except KeyboardInterrupt:
        console.print()
        print_warning("Cancelled by the operator. Nothing was written.")
        return int(ExitCode.CONFIGURATION_ERROR)

    except ConnectivityFrameworkError as error:
        console.print()
        print_error(error.message)
        if error.remediation:
            print_info(error.remediation)
        return int(error.exit_code)

    except Exception as error:  # noqa: BLE001 - top-level boundary
        console.print()
        print_error(f"The wizard failed unexpectedly: {type(error).__name__}: {error}")
        print_info(
            "This is a defect. Re-run with the traceback below attached to the report."
        )
        console.print_exception(show_locals=False)
        return int(ExitCode.UNEXPECTED_ERROR)

    return int(ExitCode.SUCCESS)


if __name__ == "__main__":  # pragma: no cover - module entry point
    sys.exit(main())
