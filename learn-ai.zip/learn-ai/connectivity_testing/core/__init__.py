"""Core framework services for the Enterprise Connectivity Validation Framework.

This package holds cross-cutting infrastructure that every other package
depends on:

    constants      -- immutable framework-wide constants and enumerations
    exceptions     -- the framework exception hierarchy
    encryption     -- Fernet based secret encryption / decryption
    logging_setup  -- rotating enterprise loggers (app, error, audit, debug)
    config_loader  -- configuration load, validation and secret resolution
    engine         -- the connectivity validation orchestration engine
    theme          -- the Northern Powergrid palette and e-mail furniture
    reporting      -- PDF / Excel / JSON report generation
    pdf_report     -- the executive PDF document (ReportLab)
    notifier       -- HTML e-mail notification with report attachments
    cleanup        -- retention based housekeeping of generated reports

Nothing in this package may import from ``connectors`` at module import time;
the dependency direction is always ``connectors -> core``.
"""

from __future__ import annotations

__all__: list[str] = []
