"""The interactive configuration wizard.

Flow
----
1. Configuration file name, with overwrite handling.
2. E-mail notification settings.
3. Connectivity interfaces, added one at a time until the operator is done.
4. Optional advanced settings (reports, logging, execution).
5. Review and save.

Secret handling
---------------
Credentials are encrypted the moment they are collected, inside
:meth:`ConfigurationWizard._encrypt`. No plaintext credential is ever assigned
to a model field, held in a local beyond that call, or printed. This is the
only place in the framework where plaintext is converted for storage, which
keeps the audit surface to a single method.

Adding a connectivity type
--------------------------
Add the member to :class:`~core.constants.InterfaceType`, add its registry
entry, then add a builder method here and register it in
:attr:`ConfigurationWizard._BUILDERS`. Nothing else in the wizard changes.
"""

from __future__ import annotations

import importlib.util
from collections.abc import Callable
from pathlib import Path
from typing import Any

from core.config_loader import load_configuration, resolve_key_path, save_configuration
from core.constants import (
    DEFAULT_DB_LINK_BUDGET_SECONDS,
    DEFAULT_DB_LINK_MAX_LINKS,
    DEFAULT_DB_LINK_TIMEOUT_SECONDS,
    DEFAULT_EXPECTED_HTTP_STATUS,
    DEFAULT_MAX_WORKERS,
    DEFAULT_MSSQL_VALIDATION_QUERY,
    DEFAULT_ORACLE_VALIDATION_QUERY,
    DEFAULT_REPORT_RETENTION_DAYS,
    DEFAULT_RETRY_COUNT,
    DEFAULT_SMTP_PORT,
    DEFAULT_SMTP_TLS_PORT,
    DEFAULT_TIMEOUT_SECONDS,
    INTERFACES_BY_CATEGORY,
    MAX_WORKERS_LIMIT,
    SUPPORTED_HTTP_METHODS,
    SUPPORTED_LOG_LEVELS,
    InterfaceType,
    default_port_for,
    spec_for,
)
from core.encryption import EncryptionKeyManager, SecretCipher
from core.exceptions import ConfigurationError
from core.wizard_prompts import (
    WizardAbortedError,
    ask_bool,
    ask_choice,
    ask_int,
    ask_secret,
    ask_text,
    console,
    print_banner,
    print_error,
    print_info,
    print_key_values,
    print_section,
    print_success,
    print_warning,
)
from models.interfaces import (
    AwsAuthMethod,
    AwsS3InterfaceConfig,
    AzureAuthMethod,
    AzureBlobInterfaceConfig,
    BaseInterfaceConfig,
    DbLinkScope,
    FtpInterfaceConfig,
    FtpsInterfaceConfig,
    FtpsMode,
    HostKeyPolicy,
    MssqlAuthentication,
    MssqlInterfaceConfig,
    OracleInterfaceConfig,
    RestAuthMethod,
    RestInterfaceConfig,
    ScpInterfaceConfig,
    SftpInterfaceConfig,
    SoapInterfaceConfig,
    SshInterfaceConfig,
)
from models.settings import (
    ApplicationConfig,
    EmailSettings,
    ExecutionSettings,
    LoggingSettings,
    ReportSettings,
    SmtpSecurity,
)
from utilities.masking import mask_secret
from utilities.ssh_discovery import DiscoveredKey, discover_ssh_keys
from utilities.validators import (
    validate_db_link_count,
    validate_email_address,
    validate_email_list,
    validate_existing_file,
    validate_host,
    validate_http_status_code,
    validate_interface_name,
    validate_port,
    validate_retry_count,
    validate_timeout,
    validate_url,
)

__all__ = ["ConfigurationWizard"]


class ConfigurationWizard:
    """Builds a validated configuration file through interactive prompts."""

    def __init__(self, config_directory: Path) -> None:
        """Initialise the wizard.

        Args:
            config_directory: Directory that generated configurations and the
                encryption key are written to.
        """
        self.config_directory = config_directory
        self._cipher: SecretCipher | None = None
        self._interfaces: list[BaseInterfaceConfig] = []
        self._existing_names: set[str] = set()
        self._environment: str = "production"
        self._description: str = ""

    # ------------------------------------------------------------------
    # Secret handling
    # ------------------------------------------------------------------

    @property
    def cipher(self) -> SecretCipher:
        """Return the cipher, creating the key file on first use.

        Raises:
            EncryptionKeyError: if the key file cannot be created or read.
        """
        if self._cipher is None:
            key_path = self.config_directory / "encryption.key"
            existed = key_path.exists()
            self._cipher = EncryptionKeyManager(key_path).load_or_create()
            if existed:
                print_info(f"Using the existing encryption key: {key_path}")
            else:
                print_success(f"Encryption key created: {key_path}")
                print_warning(
                    "Back this key up with the configuration. A configuration cannot be "
                    "decrypted without it."
                )
        return self._cipher

    def _encrypt(self, plaintext: str | None) -> str | None:
        """Encrypt a collected secret, or return ``None`` when not supplied.

        The single conversion point from plaintext to stored form. Empty input
        yields ``None`` rather than an encrypted empty string, so an optional
        credential stays genuinely absent.
        """
        if not plaintext:
            return None
        return self.cipher.encrypt(plaintext)

    # ------------------------------------------------------------------
    # Entry point
    # ------------------------------------------------------------------

    def run(self) -> Path:
        """Run the wizard end to end and write the configuration.

        Returns:
            The path of the configuration file written.

        Raises:
            WizardAbortedError: if the operator cancels.
            ConfigurationError: if the file cannot be written.
        """
        print_banner()

        config_path = self._step_config_file()
        email = self._step_email()
        interfaces = self._step_interfaces()
        reports, logging_settings, execution = self._step_advanced_settings()

        config = ApplicationConfig(
            environment=self._environment,
            description=self._description,
            email=email,
            logging=logging_settings,
            reports=reports,
            execution=execution,
            interfaces=interfaces,
        )

        return self._step_review_and_save(config, config_path)

    # ------------------------------------------------------------------
    # Step 1: configuration file
    # ------------------------------------------------------------------

    def _step_config_file(self) -> Path:
        """Ask for the configuration file name, handling an existing file."""
        print_section(
            "1", "Configuration File", "The file this wizard will generate."
        )

        while True:
            filename = ask_text(
                "Configuration file name:",
                default="production_connectivity.json",
                instruction="(saved under the config directory)",
            )
            if not filename.lower().endswith(".json"):
                filename = f"{filename}.json"

            candidate = self.config_directory / filename

            if not candidate.exists():
                print_success(f"Configuration will be written to: {candidate}")
                return candidate

            print_warning(f"Configuration already exists: {candidate}")
            action = ask_choice(
                "Overwrite?",
                [
                    ("No  - choose a different file name", "rename"),
                    ("Yes - replace the existing configuration", "overwrite"),
                    ("Add - keep it and append new interfaces to it", "extend"),
                ],
                default="rename",
            )

            if action == "overwrite":
                if ask_bool(
                    f"Confirm: permanently replace {candidate.name}?", default=False
                ):
                    return candidate
                continue

            if action == "extend" and self._load_existing(candidate):
                return candidate

    def _load_existing(self, path: Path) -> bool:
        """Load an existing configuration so new interfaces can be appended.

        Returns:
            ``True`` when the file was loaded and its interfaces adopted.
        """
        try:
            loaded = load_configuration(path, verify_secrets=False)
        except ConfigurationError as error:
            print_error(f"The existing configuration could not be read: {error.message}")
            print_info("Choose a different file name, or overwrite it.")
            return False

        self._cipher = loaded.cipher
        self._interfaces = list(loaded.config.interfaces)
        self._existing_names = {i.name.strip().lower() for i in self._interfaces}
        print_success(
            f"Loaded {len(self._interfaces)} existing interface(s) from {path.name}."
        )
        print_info("Existing secrets are kept as they are; they are never re-prompted.")
        return True

    # ------------------------------------------------------------------
    # Step 2: e-mail
    # ------------------------------------------------------------------

    def _step_email(self) -> EmailSettings:
        """Collect SMTP notification settings."""
        print_section(
            "2",
            "E-mail Notification",
            "Who is told about the outcome of each validation run.",
        )

        if not ask_bool("Enable e-mail alert?", default=True):
            print_info("E-mail disabled. Results will be written to the reports directory only.")
            return EmailSettings(enabled=False)

        smtp_server = ask_text("SMTP server:", validator=validate_host)

        security = ask_choice(
            "Transport security:",
            [
                (
                    "STARTTLS - connect in clear, then upgrade (most common)",
                    SmtpSecurity.STARTTLS,
                ),
                ("SSL/TLS  - encrypted from connect", SmtpSecurity.SSL),
                (
                    "None     - plain SMTP (relay that trusts the source address)",
                    SmtpSecurity.NONE,
                ),
            ],
            default=SmtpSecurity.STARTTLS,
        )

        default_port = {
            SmtpSecurity.STARTTLS: DEFAULT_SMTP_TLS_PORT,
            SmtpSecurity.SSL: 465,
            SmtpSecurity.NONE: DEFAULT_SMTP_PORT,
        }[security]
        smtp_port = ask_int("SMTP port:", default=default_port, validator=validate_port)

        username = ask_text(
            "SMTP username:",
            allow_empty=True,
            instruction="(optional - leave blank if the relay authenticates by IP)",
        )
        password = ""
        if username:
            password = ask_secret(
                "SMTP password:", allow_empty=False, confirm=True
            )
        else:
            print_info("No SMTP username given, so no password is required.")

        sender = ask_text("Sender e-mail address:", validator=validate_email_address)
        sender_display_name = ask_text(
            "Sender display name:", default="Connectivity Validation", allow_empty=True
        )

        recipients = validate_email_list(
            ask_text(
                "Recipient e-mail list:",
                instruction="(comma separated)",
                validator=lambda v: ", ".join(validate_email_list(v)),
            )
        )
        cc = self._ask_optional_email_list("CC list:")
        bcc = self._ask_optional_email_list("BCC list:")

        attach_reports = ask_bool("Attach the generated reports to the e-mail?", default=True)
        attach_log = ask_bool("Attach the application log to the e-mail?", default=True)
        send_on_success = ask_bool("Send an e-mail when every interface passes?", default=True)

        settings = EmailSettings(
            enabled=True,
            smtp_server=smtp_server,
            smtp_port=smtp_port,
            security=security,
            username=username or None,
            password=self._encrypt(password),
            sender=sender,
            sender_display_name=sender_display_name or "Connectivity Validation",
            recipients=recipients,
            cc=cc,
            bcc=bcc,
            attach_reports=attach_reports,
            attach_log_file=attach_log,
            send_on_success=send_on_success,
            send_on_failure=True,
        )
        print_success(f"E-mail configured for {len(settings.all_recipients)} recipient(s).")
        return settings

    def _ask_optional_email_list(self, message: str) -> list[str]:
        """Prompt for an optional comma separated address list."""
        raw = ask_text(
            message,
            allow_empty=True,
            instruction="(optional, comma separated)",
            validator=lambda v: ", ".join(validate_email_list(v, allow_empty=True)),
        )
        return validate_email_list(raw, allow_empty=True) if raw else []

    # ------------------------------------------------------------------
    # Step 3: interfaces
    # ------------------------------------------------------------------

    def _step_interfaces(self) -> list[BaseInterfaceConfig]:
        """Collect connectivity interfaces until the operator is done."""
        print_section(
            "3",
            "Connectivity Interfaces",
            "Add each connection that must be validated after an infrastructure change.",
        )

        while True:
            interface_type = self._choose_interface_type()
            if interface_type is None:
                if self._interfaces:
                    break
                print_warning(
                    "No interfaces have been added. A configuration with no interfaces "
                    "validates nothing."
                )
                if ask_bool("Continue without any interface?", default=False):
                    break
                continue

            try:
                interface = self._build_interface(interface_type)
            except WizardAbortedError:
                raise
            except ValueError as error:
                # A cross-field rule rejected the combination. Nothing has been
                # committed, so the operator simply re-enters this interface.
                print_error(f"That interface is not valid: {error}")
                print_info("Nothing was saved. Please enter the interface again.")
                continue

            self._interfaces.append(interface)
            self._existing_names.add(interface.name.strip().lower())
            print_success(f"Added '{interface.name}' ({interface.interface_type.value}).")

            choice = ask_choice(
                "Do you want to add another connectivity?",
                [("1. Yes", "yes"), ("2. Done", "done")],
                default="yes",
            )
            if choice == "done":
                break

        self._print_interface_summary()
        return self._interfaces

    def _choose_interface_type(self) -> InterfaceType | None:
        """Present the category menu, then the type menu.

        Returns:
            The chosen type, or ``None`` when the operator selected Done.
        """
        category_choices: list[tuple[str, Any]] = [
            (f"{category.value}", category) for category in INTERFACES_BY_CATEGORY
        ]
        if self._interfaces:
            category_choices.append(("Done - finish adding interfaces", None))

        category = ask_choice(
            "Select a connectivity category:", category_choices, instruction=None
        )
        if category is None:
            return None

        type_choices: list[tuple[str, Any]] = [
            (spec_for(interface_type).display_name, interface_type)
            for interface_type in INTERFACES_BY_CATEGORY[category]
        ]
        type_choices.append(("Back - choose a different category", None))

        selected: InterfaceType | None = ask_choice(
            f"Select a {category.value} type:", type_choices
        )
        if selected is None:
            return self._choose_interface_type()
        return selected

    def _build_interface(self, interface_type: InterfaceType) -> BaseInterfaceConfig:
        """Dispatch to the builder for ``interface_type``."""
        console.print()
        console.rule(
            f"[bold]{spec_for(interface_type).display_name}[/bold]", style="dim", align="left"
        )

        driver_packages = spec_for(interface_type).driver_packages
        if driver_packages and not self._drivers_available(driver_packages):
            print_warning(
                f"The driver for this type is not installed on this host: "
                f"{', '.join(driver_packages)}."
            )
            print_info(
                "The interface can still be configured now; install the driver on the host "
                "that runs the validation."
            )

        builder = self._BUILDERS[interface_type]
        interface: BaseInterfaceConfig = builder(self, interface_type)
        return interface

    @staticmethod
    def _drivers_available(packages: tuple[str, ...]) -> bool:
        """Return ``True`` when every named distribution is importable."""
        module_names = {
            "azure-storage-blob": "azure.storage.blob",
            "azure-identity": "azure.identity",
        }
        for package in packages:
            module = module_names.get(package, package)
            try:
                if importlib.util.find_spec(module) is None:
                    return False
            except (ImportError, ValueError):
                return False
        return True

    # -- shared prompts -------------------------------------------------

    def _ask_interface_name(self, interface_type: InterfaceType) -> str:
        """Prompt for a name that is unique within this configuration."""
        while True:
            name = ask_text(
                "Interface name:",
                validator=validate_interface_name,
                instruction=f"(unique identifier, e.g. 'Payments {interface_type.value}')",
            )
            if name.strip().lower() in self._existing_names:
                print_error(f"An interface named '{name}' already exists. Names must be unique.")
                continue
            return name

    def _ask_common_fields(self, interface_type: InterfaceType) -> dict[str, Any]:
        """Collect the fields every interface carries."""
        return {
            "name": self._ask_interface_name(interface_type),
            "description": ask_text(
                "Description:", allow_empty=True, instruction="(optional)"
            ),
            "timeout_seconds": ask_int(
                "Timeout (seconds):",
                default=DEFAULT_TIMEOUT_SECONDS,
                validator=validate_timeout,
            ),
        }

    def _ask_host_and_port(self, interface_type: InterfaceType) -> dict[str, Any]:
        """Collect host and port, defaulting the port from the registry."""
        return {
            "host": ask_text("Host:", validator=validate_host),
            "port": ask_int(
                "Port:",
                default=default_port_for(interface_type) or 0,
                validator=validate_port,
            ),
        }

    def _ask_tls_verification(self) -> dict[str, Any]:
        """Collect certificate verification settings."""
        verify_ssl = ask_bool("Verify the TLS certificate?", default=True)
        if not verify_ssl:
            print_warning(
                "Certificate verification is disabled. The run will not detect an expired "
                "or mis-issued certificate, which is one of the failures this framework "
                "exists to catch."
            )
            return {"verify_ssl": False, "ca_bundle_path": None}

        ca_bundle = ask_text(
            "CA bundle path:",
            allow_empty=True,
            instruction="(optional - for a private certificate authority)",
        )
        return {
            "verify_ssl": True,
            "ca_bundle_path": validate_existing_file(ca_bundle, description="CA bundle")
            if ca_bundle
            else None,
        }

    # -- SSH family -----------------------------------------------------

    def _ask_ssh_credentials(self, host: str) -> dict[str, Any]:
        """Collect SSH credentials, auto-discovering keys when none are given.

        When neither a password nor a key path is supplied, the local SSH
        client configuration and the conventional ``~/.ssh`` identities are
        searched, and the operator picks from what was found. The choice is
        recorded with ``auto_discovered_key`` so the report can explain where
        the credential came from.
        """
        password = ask_secret(
            "Password:",
            allow_empty=True,
            instruction="(optional - leave blank to authenticate with a private key)",
        )

        private_key_path = ""
        key_passphrase = ""
        auto_discovered = False

        if not password:
            private_key_path = ask_text(
                "Private key file:",
                allow_empty=True,
                instruction="(optional - leave blank to auto-discover from ~/.ssh)",
            )
            if private_key_path:
                private_key_path = validate_existing_file(
                    private_key_path, description="Private key"
                )
            else:
                discovered = self._auto_discover_key(host)
                if discovered is not None:
                    private_key_path = str(discovered.path)
                    auto_discovered = True

            if private_key_path:
                key_passphrase = ask_secret(
                    "Key passphrase:",
                    allow_empty=True,
                    instruction="(optional - leave blank if the key is not encrypted)",
                )

        if not password and not private_key_path:
            print_warning(
                "Neither a password nor a private key is configured. The connector will fall "
                "back to the SSH agent and the default identities of the account that runs "
                "the job."
            )

        known_hosts = ask_text(
            "Known hosts file:",
            allow_empty=True,
            instruction="(optional - used to verify the server host key)",
        )
        if known_hosts:
            known_hosts = validate_existing_file(known_hosts, description="Known hosts file")

        host_key_policy = ask_choice(
            "How should an unknown or changed server host key be treated?",
            [
                (
                    "Warn   - connect, record the fingerprint, flag it in the report",
                    HostKeyPolicy.WARN,
                ),
                (
                    "Reject - fail unless the key is already trusted (strictest)",
                    HostKeyPolicy.REJECT,
                ),
                (
                    "Add    - connect and add the key to the known hosts file",
                    HostKeyPolicy.AUTO_ADD,
                ),
            ],
            default=HostKeyPolicy.REJECT if known_hosts else HostKeyPolicy.WARN,
        )

        return {
            "password": self._encrypt(password),
            "private_key_path": private_key_path or None,
            "key_passphrase": self._encrypt(key_passphrase),
            "auto_discovered_key": auto_discovered,
            "known_hosts_path": known_hosts or None,
            "host_key_policy": host_key_policy,
        }

    def _auto_discover_key(self, host: str) -> DiscoveredKey | None:
        """Search the local host for a usable private key."""
        print_info(f"Searching for SSH keys usable with {host} ...")
        discovered = discover_ssh_keys(host)

        if not discovered:
            print_warning("No private key was found in ~/.ssh.")
            return None

        choices: list[tuple[str, Any]] = []
        for key in discovered:
            source = (
                f"from ~/.ssh/config, Host {key.matched_host_pattern}"
                if key.matched_host_pattern
                else "default location"
            )
            protection = ", passphrase protected" if key.is_passphrase_protected else ""
            choices.append((f"{key.path}  [{key.key_type}, {source}{protection}]", key))
        choices.append(("None - rely on the SSH agent at run time", None))

        print_success(f"Found {len(discovered)} candidate key(s).")
        selected: DiscoveredKey | None = ask_choice(
            "Select the private key to use:", choices, default=discovered[0]
        )
        if selected is not None:
            print_info(f"Recorded as an auto-discovered key: {selected.path}")
        return selected

    def _ask_ssh_algorithms(self) -> dict[str, Any]:
        """Collect optional algorithm and cipher pinning.

        Pinning is what makes a post-hardening validation meaningful: without
        it a client silently negotiates down to a legacy algorithm that is
        still enabled, and the run passes while proving nothing about the
        change that was just made.
        """
        if not ask_bool(
            "Pin specific SSH algorithms or ciphers?",
            default=False,
        ):
            return {}

        print_info(
            "Pinning proves the server actually offers the algorithm. Without it, the "
            "client may negotiate an older one and the test would still pass."
        )
        kex = ask_text(
            "Preferred SSH key exchange algorithms:",
            allow_empty=True,
            instruction="(optional, comma separated, e.g. curve25519-sha256)",
        )
        ciphers = ask_text(
            "Preferred ciphers:",
            allow_empty=True,
            instruction="(optional, comma separated, e.g. aes256-gcm@openssh.com)",
        )
        macs = ask_text(
            "Preferred MAC algorithms:",
            allow_empty=True,
            instruction="(optional, comma separated)",
        )
        host_key_algorithms = ask_text(
            "Preferred host key algorithms:",
            allow_empty=True,
            instruction="(optional, comma separated, e.g. ssh-ed25519)",
        )

        return {
            "preferred_kex_algorithms": _split_csv(kex),
            "preferred_ciphers": _split_csv(ciphers),
            "preferred_macs": _split_csv(macs),
            "preferred_host_key_algorithms": _split_csv(host_key_algorithms),
        }

    def _build_sftp(self, interface_type: InterfaceType) -> SftpInterfaceConfig:
        """Collect an SFTP interface."""
        common = self._ask_common_fields(interface_type)
        endpoint = self._ask_host_and_port(interface_type)
        username = ask_text("Username:")
        credentials = self._ask_ssh_credentials(endpoint["host"])
        algorithms = self._ask_ssh_algorithms()
        remote_path = ask_text(
            "Remote directory to list:",
            allow_empty=True,
            instruction="(optional - turns a login check into an authorisation check)",
        )
        return SftpInterfaceConfig(
            **common,
            **endpoint,
            username=username,
            **credentials,
            **algorithms,
            remote_path=remote_path or None,
        )

    def _build_scp(self, interface_type: InterfaceType) -> ScpInterfaceConfig:
        """Collect an SCP interface."""
        common = self._ask_common_fields(interface_type)
        endpoint = self._ask_host_and_port(interface_type)
        username = ask_text("Username:")
        credentials = self._ask_ssh_credentials(endpoint["host"])
        algorithms = self._ask_ssh_algorithms()
        remote_path = ask_text(
            "Remote file to verify:",
            allow_empty=True,
            instruction=(
                "(optional - must be a readable FILE; blank checks only that scp exists)"
            ),
        )
        return ScpInterfaceConfig(
            **common,
            **endpoint,
            username=username,
            **credentials,
            **algorithms,
            remote_path=remote_path or None,
        )

    def _build_ssh(self, interface_type: InterfaceType) -> SshInterfaceConfig:
        """Collect an SSH interface."""
        common = self._ask_common_fields(interface_type)
        endpoint = self._ask_host_and_port(interface_type)
        username = ask_text("Username:")
        credentials = self._ask_ssh_credentials(endpoint["host"])
        algorithms = self._ask_ssh_algorithms()
        command = ask_text(
            "Validation command:",
            allow_empty=True,
            instruction="(optional - a non-zero exit status fails the interface)",
        )
        return SshInterfaceConfig(
            **common,
            **endpoint,
            username=username,
            **credentials,
            **algorithms,
            validation_command=command or None,
        )

    def _build_ftp(self, interface_type: InterfaceType) -> FtpInterfaceConfig:
        """Collect a plain FTP interface."""
        common = self._ask_common_fields(interface_type)
        endpoint = self._ask_host_and_port(interface_type)
        print_warning(
            "FTP transmits credentials in clear text. The report will flag this interface "
            "as an insecure protocol."
        )
        username = ask_text("Username:", default="anonymous")
        password = ask_secret("Password:", allow_empty=True, instruction="(optional)")
        passive = ask_bool(
            "Use passive mode?", default=True
        )
        remote_path = ask_text(
            "Remote directory to list:", allow_empty=True, instruction="(optional)"
        )
        return FtpInterfaceConfig(
            **common,
            **endpoint,
            username=username,
            password=self._encrypt(password),
            passive_mode=passive,
            remote_path=remote_path or None,
        )

    def _build_ftps(self, interface_type: InterfaceType) -> FtpsInterfaceConfig:
        """Collect an FTPS interface."""
        common = self._ask_common_fields(interface_type)
        endpoint = self._ask_host_and_port(interface_type)
        username = ask_text("Username:", default="anonymous")
        password = ask_secret("Password:", allow_empty=True, instruction="(optional)")
        ftps_mode = ask_choice(
            "TLS mode:",
            [
                (
                    "Explicit - AUTH TLS on the standard port (RFC 4217, most common)",
                    FtpsMode.EXPLICIT,
                ),
                ("Implicit - TLS from connect, historically port 990", FtpsMode.IMPLICIT),
            ],
            default=FtpsMode.EXPLICIT,
        )
        passive = ask_bool("Use passive mode?", default=True)
        tls = self._ask_tls_verification()
        remote_path = ask_text(
            "Remote directory to list:", allow_empty=True, instruction="(optional)"
        )
        return FtpsInterfaceConfig(
            **common,
            **endpoint,
            username=username,
            password=self._encrypt(password),
            ftps_mode=ftps_mode,
            passive_mode=passive,
            **tls,
            remote_path=remote_path or None,
        )

    def _build_oracle(self, interface_type: InterfaceType) -> OracleInterfaceConfig:
        """Collect an Oracle Database interface."""
        common = self._ask_common_fields(interface_type)
        endpoint = self._ask_host_and_port(interface_type)

        identifier_kind = ask_choice(
            "Identify the database by:",
            [("Service name (recommended)", "service_name"), ("SID (legacy listeners)", "sid")],
            default="service_name",
        )
        identifier = ask_text(
            "Service name:" if identifier_kind == "service_name" else "SID:"
        )

        username = ask_text("Username:")
        password = ask_secret("Password:", allow_empty=True, confirm=True)

        use_ssl = ask_bool("Connect using SSL/TLS (TCPS)?", default=False)
        ssl_dn_match = True
        if use_ssl:
            ssl_dn_match = ask_bool(
                "Verify the server certificate distinguished name?", default=True
            )

        use_thick = ask_bool(
            "Use Oracle thick mode?",
            default=False,
        )
        if use_thick:
            print_info("Thick mode requires the Oracle Client libraries on the executing host.")
        wallet = ""
        if use_thick:
            wallet = ask_text(
                "Oracle Wallet directory:", allow_empty=True, instruction="(optional)"
            )

        query = ask_text(
            "Validation query:", default=DEFAULT_ORACLE_VALIDATION_QUERY
        )

        return OracleInterfaceConfig(
            **common,
            **endpoint,
            service_name=identifier if identifier_kind == "service_name" else None,
            sid=identifier if identifier_kind == "sid" else None,
            username=username,
            password=self._encrypt(password),
            use_ssl=use_ssl,
            ssl_server_dn_match=ssl_dn_match,
            use_thick_mode=use_thick,
            wallet_location=wallet or None,
            validation_query=query,
            **self._ask_database_links(),
        )

    def _ask_database_links(self) -> dict[str, Any]:
        """Collect the optional database link check for an Oracle interface.

        Returns:
            Keyword arguments for :class:`OracleInterfaceConfig`. Everything
            except the on/off switch is left at its default unless the operator
            asks to review it, because the defaults are the right answer for
            almost every estate and a long interrogation discourages turning
            the check on at all.
        """
        check_links = ask_bool(
            "Also check this account's database links?",
            default=False,
        )
        if not check_links:
            return {"check_db_links": False}

        print_info(
            "Each link found is opened with SELECT 'X' FROM dual@<link>. The link is "
            "opened by the database server, so this tests the path from that server to "
            "the remote database."
        )

        scope = ask_choice(
            "Which links should be checked?",
            [
                ("Links this account owns (USER_DB_LINKS)", DbLinkScope.USER),
                ("Every visible link, including public (ALL_DB_LINKS)", DbLinkScope.ALL),
            ],
            default=DbLinkScope.USER,
        )

        names_input = ask_text(
            "Restrict to specific link names:",
            allow_empty=True,
            instruction="(optional, comma separated; blank checks every link found)",
        )
        names = [part.strip() for part in names_input.split(",") if part.strip()]
        if names:
            print_info(
                "A link named here but missing from the data dictionary will fail the "
                "interface, which is how a link dropped in a refresh is caught."
            )

        settings: dict[str, Any] = {
            "check_db_links": True,
            "db_link_scope": scope,
            "db_link_names": names,
            "fail_on_broken_db_link": ask_bool(
                "Treat a link that cannot be opened as a failure?", default=True
            ),
        }

        if ask_bool("Review the database link timeouts and limits?", default=False):
            settings["db_link_timeout_seconds"] = ask_int(
                "Timeout for one link (seconds):",
                default=DEFAULT_DB_LINK_TIMEOUT_SECONDS,
                validator=validate_timeout,
            )
            budget = ask_int(
                "Total time allowed for all links (seconds):",
                default=DEFAULT_DB_LINK_BUDGET_SECONDS,
                validator=validate_timeout,
            )
            # A budget below the per-link timeout would stop the check before a
            # single link could time out, which the model rejects. Raising it
            # here keeps the wizard from ending in a validation error over an
            # answer the operator can only have meant one way.
            if budget < settings["db_link_timeout_seconds"]:
                budget = settings["db_link_timeout_seconds"]
                print_warning(
                    f"The total budget was raised to {budget} seconds so that at least "
                    "one link probe can run to its timeout."
                )
            settings["db_link_budget_seconds"] = budget
            settings["db_link_max_links"] = ask_int(
                "Maximum number of links to check:",
                default=DEFAULT_DB_LINK_MAX_LINKS,
                validator=validate_db_link_count,
            )
        return settings

    def _build_mssql(self, interface_type: InterfaceType) -> MssqlInterfaceConfig:
        """Collect a Microsoft SQL Server interface."""
        common = self._ask_common_fields(interface_type)
        endpoint = self._ask_host_and_port(interface_type)
        database = ask_text("Database name:")

        authentication = ask_choice(
            "Authentication type:",
            [
                ("SQL Server authentication (username and password)", MssqlAuthentication.SQL),
                (
                    "Windows authentication (the identity running the job)",
                    MssqlAuthentication.WINDOWS,
                ),
            ],
            default=MssqlAuthentication.SQL,
        )

        username = ""
        password = ""
        if authentication is MssqlAuthentication.SQL:
            username = ask_text("Username:")
            password = ask_secret("Password:", allow_empty=True, confirm=True)
        else:
            print_info(
                "Windows authentication uses the account the scheduler runs the job as, "
                "which is often a service account rather than your own."
            )

        odbc_driver = ask_text(
            "ODBC driver name:",
            default="ODBC Driver 18 for SQL Server",
            instruction="(as listed by the ODBC driver manager)",
        )
        encrypt = ask_bool("Encrypt the connection?", default=True)
        trust_certificate = False
        if encrypt:
            trust_certificate = ask_bool(
                "Trust the server certificate without validating it?", default=False
            )
            if trust_certificate:
                print_warning(
                    "Trusting the certificate hides exactly the certificate failures this "
                    "framework is meant to detect."
                )

        query = ask_text("Validation query:", default=DEFAULT_MSSQL_VALIDATION_QUERY)

        return MssqlInterfaceConfig(
            **common,
            **endpoint,
            database=database,
            authentication=authentication,
            username=username or None,
            password=self._encrypt(password),
            odbc_driver=odbc_driver,
            encrypt=encrypt,
            trust_server_certificate=trust_certificate,
            validation_query=query,
        )

    def _build_azure_blob(self, interface_type: InterfaceType) -> AzureBlobInterfaceConfig:
        """Collect an Azure Blob Storage interface."""
        common = self._ask_common_fields(interface_type)

        auth_method = ask_choice(
            "Authentication method:",
            [
                ("Connection string", AzureAuthMethod.CONNECTION_STRING),
                (
                    "Service principal (tenant, client id, client secret)",
                    AzureAuthMethod.SERVICE_PRINCIPAL,
                ),
                ("Managed identity (no credential stored)", AzureAuthMethod.MANAGED_IDENTITY),
            ],
            default=AzureAuthMethod.CONNECTION_STRING,
        )

        account_url = ""
        connection_string = ""
        tenant_id = ""
        client_id = ""
        client_secret = ""

        if auth_method is AzureAuthMethod.CONNECTION_STRING:
            connection_string = ask_secret(
                "Connection string:",
                allow_empty=False,
                instruction="(contains the account key - stored encrypted)",
            )
        else:
            account_url = ask_text(
                "Account URL:",
                validator=validate_url,
                instruction="(https://<account>.blob.core.windows.net)",
            )
            if auth_method is AzureAuthMethod.SERVICE_PRINCIPAL:
                tenant_id = ask_text("Tenant ID:")
                client_id = ask_text("Client ID:")
                client_secret = ask_secret("Client secret:", allow_empty=False, confirm=True)
            else:
                client_id = ask_text(
                    "User-assigned managed identity client ID:",
                    allow_empty=True,
                    instruction="(optional - leave blank for the system-assigned identity)",
                )

        container = ask_text(
            "Container name:",
            allow_empty=True,
            instruction="(optional - leave blank to probe at account level)",
        )

        return AzureBlobInterfaceConfig(
            **common,
            auth_method_type=auth_method,
            account_url=account_url or None,
            connection_string=self._encrypt(connection_string),
            tenant_id=tenant_id or None,
            client_id=client_id or None,
            client_secret=self._encrypt(client_secret),
            container_name=container or None,
        )

    def _build_aws_s3(self, interface_type: InterfaceType) -> AwsS3InterfaceConfig:
        """Collect an Amazon S3 interface."""
        common = self._ask_common_fields(interface_type)

        auth_method = ask_choice(
            "Authentication method:",
            [
                ("Access key (access key id and secret access key)", AwsAuthMethod.ACCESS_KEY),
                ("IAM role (instance profile or named profile)", AwsAuthMethod.IAM_ROLE),
            ],
            default=AwsAuthMethod.ACCESS_KEY,
        )

        region = ask_text("AWS region:", default="us-east-1")

        access_key_id = ""
        secret_access_key = ""
        session_token = ""
        profile_name = ""
        role_arn = ""

        if auth_method is AwsAuthMethod.ACCESS_KEY:
            access_key_id = ask_text("Access key ID:")
            secret_access_key = ask_secret(
                "Secret access key:", allow_empty=False, confirm=True
            )
            session_token = ask_secret(
                "Session token:",
                allow_empty=True,
                instruction="(optional - only for temporary STS credentials)",
            )
        else:
            profile_name = ask_text(
                "Named profile:",
                allow_empty=True,
                instruction="(optional - leave blank for the default credential chain)",
            )
            role_arn = ask_text(
                "Role ARN to assume:", allow_empty=True, instruction="(optional)"
            )

        bucket = ask_text(
            "Bucket name:",
            allow_empty=True,
            instruction="(optional - leave blank to list buckets at account level)",
        )
        prefix = ""
        if bucket:
            prefix = ask_text(
                "Key prefix to list:", allow_empty=True, instruction="(optional, deeper probe)"
            )

        endpoint_url = ask_text(
            "Endpoint URL:",
            allow_empty=True,
            instruction="(optional - for an S3-compatible object store)",
            validator=validate_url,
        )

        return AwsS3InterfaceConfig(
            **common,
            auth_method_type=auth_method,
            region=region,
            access_key_id=access_key_id or None,
            secret_access_key=self._encrypt(secret_access_key),
            session_token=self._encrypt(session_token),
            profile_name=profile_name or None,
            role_arn=role_arn or None,
            bucket_name=bucket or None,
            prefix=prefix or None,
            endpoint_url=endpoint_url or None,
        )

    def _build_rest(self, interface_type: InterfaceType) -> RestInterfaceConfig:
        """Collect a REST API interface."""
        common = self._ask_common_fields(interface_type)
        base_url = ask_text("Base URL:", validator=validate_url)
        method = ask_choice(
            "HTTP method:",
            [(m, m) for m in SUPPORTED_HTTP_METHODS],
            default="GET",
        )

        auth_method = ask_choice(
            "Authentication:",
            [
                ("None", RestAuthMethod.NONE),
                ("Basic (username and password)", RestAuthMethod.BASIC),
                ("Bearer token", RestAuthMethod.BEARER),
                ("API key header", RestAuthMethod.API_KEY),
            ],
            default=RestAuthMethod.NONE,
        )

        username = ""
        password = ""
        bearer_token = ""
        api_key_header = "X-API-Key"
        api_key_value = ""

        if auth_method is RestAuthMethod.BASIC:
            username = ask_text("Username:")
            password = ask_secret("Password:", allow_empty=False, confirm=True)
        elif auth_method is RestAuthMethod.BEARER:
            bearer_token = ask_secret("Bearer token:", allow_empty=False)
        elif auth_method is RestAuthMethod.API_KEY:
            api_key_header = ask_text("API key header name:", default="X-API-Key")
            api_key_value = ask_secret("API key value:", allow_empty=False)

        headers = self._ask_headers()

        request_body = ""
        if method in {"POST", "PUT", "PATCH"}:
            request_body = ask_text(
                "Request body:", allow_empty=True, instruction="(optional, raw payload)"
            )

        expected_status = ask_int(
            "Expected HTTP status code:",
            default=DEFAULT_EXPECTED_HTTP_STATUS,
            validator=validate_http_status_code,
        )
        expected_body = ask_text(
            "Response must contain:",
            allow_empty=True,
            instruction="(optional - catches a 200 that returns a maintenance page)",
        )
        retry_count = ask_int(
            "Retry count:", default=DEFAULT_RETRY_COUNT, validator=validate_retry_count
        )
        tls = self._ask_tls_verification()
        proxy = ask_text("Proxy URL:", allow_empty=True, instruction="(optional)")

        return RestInterfaceConfig(
            **common,
            base_url=base_url,
            method=method,
            auth_method_type=auth_method,
            username=username or None,
            password=self._encrypt(password),
            bearer_token=self._encrypt(bearer_token),
            api_key_header=api_key_header,
            api_key_value=self._encrypt(api_key_value),
            headers=headers,
            request_body=request_body or None,
            expected_status_codes=[expected_status],
            expected_body_contains=expected_body or None,
            retry_count=retry_count,
            **tls,
            proxy_url=proxy or None,
        )

    def _build_soap(self, interface_type: InterfaceType) -> SoapInterfaceConfig:
        """Collect a SOAP web service interface."""
        common = self._ask_common_fields(interface_type)
        wsdl_url = ask_text("WSDL URL:", validator=validate_url)
        endpoint_url = ask_text(
            "Endpoint URL:",
            allow_empty=True,
            instruction="(optional - overrides the address published in the WSDL)",
            validator=validate_url,
        )
        username = ask_text("Username:", allow_empty=True, instruction="(optional)")
        password = ""
        if username:
            password = ask_secret("Password:", allow_empty=False, confirm=True)

        soap_action = ask_text("SOAP action:", allow_empty=True, instruction="(optional)")
        operation = ask_text(
            "Operation to invoke:",
            allow_empty=True,
            instruction="(optional - leave blank to only retrieve and parse the WSDL)",
        )
        tls = self._ask_tls_verification()

        return SoapInterfaceConfig(
            **common,
            wsdl_url=wsdl_url,
            endpoint_url=endpoint_url or None,
            username=username or None,
            password=self._encrypt(password),
            soap_action=soap_action or None,
            operation=operation or None,
            **tls,
        )

    def _ask_headers(self) -> dict[str, str]:
        """Collect optional additional HTTP headers."""
        headers: dict[str, str] = {}
        if not ask_bool("Add custom HTTP headers?", default=False):
            return headers

        while True:
            name = ask_text("Header name:", allow_empty=True, instruction="(blank to finish)")
            if not name:
                break
            value = ask_text(f"Value for {name}:", allow_empty=True)
            headers[name] = value
            print_success(f"Header added: {name}")
        return headers

    #: Dispatch table from connectivity type to builder method.
    _BUILDERS: dict[InterfaceType, Callable[[ConfigurationWizard, InterfaceType], Any]] = {
        InterfaceType.SFTP: _build_sftp,
        InterfaceType.SCP: _build_scp,
        InterfaceType.SSH: _build_ssh,
        InterfaceType.FTP: _build_ftp,
        InterfaceType.FTPS: _build_ftps,
        InterfaceType.ORACLE: _build_oracle,
        InterfaceType.MSSQL: _build_mssql,
        InterfaceType.AZURE_BLOB: _build_azure_blob,
        InterfaceType.AWS_S3: _build_aws_s3,
        InterfaceType.REST: _build_rest,
        InterfaceType.SOAP: _build_soap,
    }

    # ------------------------------------------------------------------
    # Step 4: advanced settings
    # ------------------------------------------------------------------

    def _step_advanced_settings(
        self,
    ) -> tuple[ReportSettings, LoggingSettings, ExecutionSettings]:
        """Collect reporting, logging and execution settings."""
        print_section(
            "4",
            "Advanced Settings",
            "Reporting, logging and execution behaviour. Defaults suit most deployments.",
        )

        self._environment = ask_text(
            "Environment label:",
            default="production",
            instruction="(shown in reports, e.g. production, dr, uat)",
        )
        self._description = ask_text(
            "Configuration description:", allow_empty=True, instruction="(optional)"
        )

        if not ask_bool("Review advanced settings?", default=False):
            print_info(
                "Using defaults: PDF, Excel and JSON reports, 15-day retention, "
                "parallel execution, INFO logging."
            )
            return ReportSettings(), LoggingSettings(), ExecutionSettings()

        while True:
            generate_pdf = ask_bool("Generate the PDF report?", default=True)
            generate_excel = ask_bool("Generate the Excel report?", default=True)
            generate_json = ask_bool("Generate the JSON report?", default=True)
            if generate_pdf or generate_excel or generate_json:
                break
            print_error(
                "At least one report format must be enabled, otherwise a run leaves no "
                "evidence of what was validated."
            )

        reports = ReportSettings(
            directory=ask_text("Reports directory:", default="reports"),
            generate_pdf=generate_pdf,
            generate_excel=generate_excel,
            generate_json=generate_json,
            retention_days=ask_int(
                "Delete reports older than (days):",
                default=DEFAULT_REPORT_RETENTION_DAYS,
                validator=_bounded_int("Retention", 1, 3650),
            ),
            cleanup_enabled=ask_bool("Clean up old reports before each run?", default=True),
        )

        logging_settings = LoggingSettings(
            directory=ask_text("Logs directory:", default="logs"),
            level=ask_choice(
                "Log level:",
                [(level, level) for level in SUPPORTED_LOG_LEVELS],
                default="INFO",
            ),
            console_enabled=ask_bool("Also log to the console?", default=True),
            debug_log_enabled=ask_bool("Write the debug log?", default=True),
        )

        parallel = ask_bool("Validate interfaces in parallel?", default=True)
        max_workers = DEFAULT_MAX_WORKERS
        if parallel:
            max_workers = ask_int(
                "Maximum parallel workers:",
                default=DEFAULT_MAX_WORKERS,
                validator=_bounded_int("Worker count", 1, MAX_WORKERS_LIMIT),
            )

        execution = ExecutionSettings(
            parallel_enabled=parallel,
            max_workers=max_workers,
            strict_secrets=ask_bool(
                "Refuse to run if any secret is stored in plaintext?", default=False
            ),
            fail_on_warning=ask_bool(
                "Treat warnings (such as an unverified host key) as failures?", default=False
            ),
        )

        return reports, logging_settings, execution

    # ------------------------------------------------------------------
    # Step 5: review and save
    # ------------------------------------------------------------------

    def _print_interface_summary(self) -> None:
        """Print the interfaces collected so far."""
        if not self._interfaces:
            return
        rows = [
            (
                interface.name,
                f"{interface.interface_type.value} -> {interface.endpoint} "
                f"[{interface.auth_method.value}]",
            )
            for interface in self._interfaces
        ]
        print_key_values(f"Interfaces ({len(rows)})", rows)

    def _step_review_and_save(self, config: ApplicationConfig, config_path: Path) -> Path:
        """Show the final configuration and write it after confirmation."""
        print_section("5", "Review and Save", "Confirm before anything is written to disk.")

        email_summary = "Disabled"
        if config.email.enabled:
            email_summary = (
                f"{config.email.smtp_server}:{config.email.smtp_port} "
                f"({config.email.security.value}) -> "
                f"{len(config.email.all_recipients)} recipient(s)"
            )

        execution_summary = (
            f"parallel, {config.execution.effective_max_workers} workers"
            if config.execution.parallel_enabled
            else "sequential"
        )
        interfaces_summary = (
            f"{len(config.interfaces)} configured, {len(config.enabled_interfaces)} enabled"
        )
        reports_summary = (
            f"{config.reports.directory} (retention {config.reports.retention_days} days)"
        )

        print_key_values(
            "Configuration Summary",
            [
                ("File", str(config_path)),
                ("Encryption key", str(resolve_key_path(config_path))),
                ("Environment", config.environment),
                ("Interfaces", interfaces_summary),
                ("E-mail", email_summary),
                ("SMTP password", mask_secret(config.email.password) or "not set"),
                ("Reports", reports_summary),
                ("Logs", f"{config.logging.directory} (level {config.logging.level})"),
                ("Execution", execution_summary),
            ],
        )
        self._print_interface_summary()

        if not ask_bool("Save this configuration?", default=True):
            raise WizardAbortedError("Configuration discarded at the review step.")

        written = save_configuration(config, config_path, create_key=True)

        print_success(f"Configuration written: {written}")
        print_success(f"Encryption key: {resolve_key_path(written)}")
        console.print()
        print_info("Validate the configuration with:")
        console.print(
            f"    python connectivity_validator.py --config {written}",
            style="bold cyan",
        )
        console.print()
        return written


def _split_csv(value: str) -> list[str]:
    """Split a comma separated answer into a clean list."""
    return [item.strip() for item in value.split(",") if item.strip()]


def _bounded_int(label: str, minimum: int, maximum: int) -> Callable[[Any], int]:
    """Return a validator accepting an integer within an inclusive range.

    Used for the prompts whose bounds live on the pydantic model. Validating at
    the prompt turns a would-be crash at model construction, after the operator
    has answered thirty questions, into an inline correction.
    """

    def _validate(value: Any) -> int:
        try:
            number = int(str(value).strip())
        except (TypeError, ValueError) as error:
            raise ValueError(f"{label} must be a whole number, received '{value}'.") from error
        if not minimum <= number <= maximum:
            raise ValueError(f"{label} must be between {minimum} and {maximum}.")
        return number

    return _validate
