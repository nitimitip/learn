"""Configuration loading, validation, saving and secret resolution.

:class:`LoadedConfiguration` is what the rest of the framework consumes. It
bundles four things that always travel together:

* the validated :class:`~models.settings.ApplicationConfig`,
* the :class:`~core.encryption.SecretCipher` that unlocks its secrets,
* the resolved report and log directories, and
* any advisory findings raised while loading, such as a plaintext credential.

Path resolution
---------------
Relative directories in the configuration resolve against the directory
holding the configuration file, never the process working directory. A
Control-M or cron job launched from ``/`` therefore writes its reports beside
the configuration exactly as it did during interactive testing.

Failure policy
--------------
Configuration problems are fatal and raise
:class:`~core.exceptions.ConfigurationError` (exit code 2). This is deliberate:
a run against a half-understood configuration would report a clean bill of
health for interfaces it never actually attempted, which is worse than not
running at all.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from core.constants import (
    APP_VERSION,
    CONFIG_SCHEMA_VERSION,
    DEFAULT_ENCRYPTION_KEY_FILENAME,
)
from core.encryption import (
    EncryptionKeyManager,
    EnvelopeKind,
    SecretCipher,
    envelope_kind,
)
from core.exceptions import (
    ConfigurationFileError,
    ConfigurationValidationError,
    DecryptionError,
)
from models.interfaces import BaseInterfaceConfig
from models.settings import ApplicationConfig
from utilities.fs import atomic_write_text, ensure_directory, permissions_are_world_readable
from utilities.masking import redact_mapping, secret_registry

__all__ = [
    "ConfigurationFinding",
    "LoadedConfiguration",
    "load_configuration",
    "redacted_config_dump",
    "resolve_key_path",
    "save_configuration",
]

#: Maximum accepted configuration size. A configuration is a few tens of
#: kilobytes; anything vastly larger is a wrong file, and parsing it would
#: mean loading an arbitrary payload into memory.
_MAX_CONFIG_BYTES = 8 * 1024 * 1024


@dataclass(frozen=True, slots=True)
class ConfigurationFinding:
    """An advisory raised while loading, not severe enough to refuse the run.

    Findings are logged, shown in the console banner and carried into the
    report so that a weak deployment is visible rather than merely survivable.
    """

    severity: str
    """``warning`` or ``info``."""

    code: str
    """Stable label, for example ``PLAINTEXT_SECRET``."""

    message: str
    """Operator-facing description."""

    remediation: str | None = None

    def __str__(self) -> str:
        text = f"[{self.severity.upper()}] {self.message}"
        return f"{text} Remediation: {self.remediation}" if self.remediation else text


@dataclass(slots=True)
class LoadedConfiguration:
    """A validated configuration together with everything needed to run it."""

    config: ApplicationConfig
    config_path: Path
    key_path: Path
    cipher: SecretCipher
    base_directory: Path
    reports_directory: Path
    logs_directory: Path
    findings: list[ConfigurationFinding] = field(default_factory=list)

    @property
    def has_warnings(self) -> bool:
        """Return ``True`` when at least one warning-level finding was raised."""
        return any(finding.severity == "warning" for finding in self.findings)

    def resolve_secret(
        self,
        value: str | None,
        *,
        field_name: str = "secret",
    ) -> str | None:
        """Resolve one stored secret to plaintext.

        Honours the ``strict_secrets`` execution setting, so a site that
        forbids on-disk plaintext gets a hard failure rather than a warning.
        """
        return self.cipher.resolve(
            value,
            field_name=field_name,
            allow_plaintext=not self.config.execution.strict_secrets,
        )

    def resolve_interface_secrets(self, interface: BaseInterfaceConfig) -> dict[str, str | None]:
        """Resolve every secret declared by ``interface``.

        Returns:
            Field name to plaintext. Fields that are not configured are
            omitted, so a connector can distinguish an absent password from an
            empty one.

        Raises:
            DecryptionError: if any secret cannot be resolved.
        """
        resolved: dict[str, str | None] = {}
        for field_name, stored in interface.secret_values().items():
            resolved[field_name] = self.cipher.resolve(
                stored,
                field_name=f"{interface.name}.{field_name}",
                allow_plaintext=not self.config.execution.strict_secrets,
            )
        return resolved


def resolve_key_path(config_path: Path, key_path: Path | str | None = None) -> Path:
    """Return the encryption key path for ``config_path``.

    The key lives beside the configuration it protects by default, which keeps
    the pair together when a configuration is promoted between environments.
    """
    if key_path is not None:
        candidate = Path(key_path)
        return candidate if candidate.is_absolute() else config_path.parent / candidate
    return config_path.parent / DEFAULT_ENCRYPTION_KEY_FILENAME


def _read_config_bytes(config_path: Path) -> bytes:
    """Read the configuration file with clear, actionable failure messages."""
    if not config_path.exists():
        raise ConfigurationFileError(
            f"Configuration file not found: {config_path}",
            remediation=(
                "Create one with 'python generate_config.py', or correct the --config path. "
                "Under a scheduler, remember that a relative path resolves against the job's "
                "working directory, not the script location."
            ),
            details={"config_path": str(config_path)},
        )
    if not config_path.is_file():
        raise ConfigurationFileError(
            f"Configuration path is not a file: {config_path}",
            remediation="Point --config at the JSON configuration file itself.",
            details={"config_path": str(config_path)},
        )

    try:
        size = config_path.stat().st_size
    except OSError as error:
        raise ConfigurationFileError(
            f"Configuration file cannot be inspected: {config_path}",
            remediation="Check filesystem permissions for the account running the job.",
            details={"config_path": str(config_path)},
            cause=error,
        ) from error

    if size > _MAX_CONFIG_BYTES:
        raise ConfigurationFileError(
            f"Configuration file is implausibly large ({size} bytes): {config_path}",
            remediation=(
                "Confirm --config points at the connectivity configuration and not at a "
                "data file."
            ),
            details={"config_path": str(config_path), "size_bytes": size},
        )

    try:
        return config_path.read_bytes()
    except OSError as error:
        raise ConfigurationFileError(
            f"Configuration file cannot be read: {config_path}",
            remediation=(
                "Check that the account running the job has read permission. Under a "
                "scheduler this is usually a service account, not the account that created "
                "the file."
            ),
            details={"config_path": str(config_path)},
            cause=error,
        ) from error


def _parse_json(raw: bytes, config_path: Path) -> dict[str, Any]:
    """Parse the configuration JSON, reporting the exact offending position."""
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError as error:
        raise ConfigurationFileError(
            f"Configuration file is not valid UTF-8: {config_path}",
            remediation=(
                "Re-save the file as UTF-8, or regenerate it with "
                "'python generate_config.py'."
            ),
            details={"config_path": str(config_path)},
            cause=error,
        ) from error

    try:
        parsed = json.loads(text)
    except json.JSONDecodeError as error:
        raise ConfigurationFileError(
            f"Configuration file is not valid JSON: {config_path} "
            f"(line {error.lineno}, column {error.colno}: {error.msg})",
            remediation=(
                "Repair the JSON syntax, or regenerate the file with "
                "'python generate_config.py' rather than editing it by hand."
            ),
            details={
                "config_path": str(config_path),
                "line": error.lineno,
                "column": error.colno,
            },
            cause=error,
        ) from error

    if not isinstance(parsed, dict):
        raise ConfigurationFileError(
            f"Configuration root must be a JSON object, found {type(parsed).__name__}: "
            f"{config_path}",
            remediation="Regenerate the file with 'python generate_config.py'.",
            details={"config_path": str(config_path)},
        )
    return parsed


def _format_validation_issues(error: ValidationError) -> list[str]:
    """Render pydantic errors as one readable line per offending field."""
    issues: list[str] = []
    for item in error.errors():
        location = ".".join(str(part) for part in item.get("loc", ())) or "<root>"
        message = item.get("msg", "invalid value")
        issues.append(f"{location}: {message}")
    return issues


def _validate_model(payload: dict[str, Any], config_path: Path) -> ApplicationConfig:
    """Validate the parsed payload against the application model."""
    try:
        return ApplicationConfig.model_validate(payload)
    except ValidationError as error:
        issues = _format_validation_issues(error)
        raise ConfigurationValidationError(
            f"Configuration is not valid: {config_path} ({len(issues)} problem(s))",
            issues=issues,
            details={"config_path": str(config_path)},
            cause=error,
        ) from error


def _collect_findings(
    config: ApplicationConfig,
    config_path: Path,
    key_path: Path,
) -> list[ConfigurationFinding]:
    """Raise advisories about a weak but workable deployment."""
    findings: list[ConfigurationFinding] = []

    plaintext_fields: list[str] = []
    for interface in config.interfaces:
        for field_name, stored in interface.secret_values().items():
            if envelope_kind(stored) is EnvelopeKind.PLAINTEXT:
                plaintext_fields.append(f"{interface.name}.{field_name}")
    if envelope_kind(config.email.password) is EnvelopeKind.PLAINTEXT:
        plaintext_fields.append("email.password")

    if plaintext_fields:
        findings.append(
            ConfigurationFinding(
                severity="warning",
                code="PLAINTEXT_SECRET",
                message=(
                    f"{len(plaintext_fields)} secret(s) are stored in plaintext: "
                    + ", ".join(sorted(plaintext_fields))
                ),
                remediation=(
                    "Re-run 'python generate_config.py' to store them encrypted, or set "
                    "execution.strict_secrets to true to refuse plaintext outright."
                ),
            )
        )

    if permissions_are_world_readable(key_path):
        findings.append(
            ConfigurationFinding(
                severity="warning",
                code="KEY_FILE_PERMISSIONS",
                message=f"Encryption key file is readable by other accounts: {key_path}",
                remediation=f"Restrict it: chmod 600 {key_path}",
            )
        )

    if permissions_are_world_readable(config_path):
        findings.append(
            ConfigurationFinding(
                severity="warning",
                code="CONFIG_FILE_PERMISSIONS",
                message=f"Configuration file is readable by other accounts: {config_path}",
                remediation=f"Restrict it: chmod 600 {config_path}",
            )
        )

    if not config.interfaces:
        findings.append(
            ConfigurationFinding(
                severity="warning",
                code="NO_INTERFACES",
                message="The configuration defines no interfaces, so the run validates nothing.",
                remediation="Add interfaces with 'python generate_config.py'.",
            )
        )
    elif not config.enabled_interfaces:
        findings.append(
            ConfigurationFinding(
                severity="warning",
                code="ALL_INTERFACES_DISABLED",
                message=(
                    f"All {len(config.interfaces)} interfaces are disabled, so the run "
                    "validates nothing and will report success."
                ),
                remediation="Enable at least one interface in the configuration.",
            )
        )

    if config.schema_version != CONFIG_SCHEMA_VERSION:
        findings.append(
            ConfigurationFinding(
                severity="info",
                code="SCHEMA_VERSION_MISMATCH",
                message=(
                    f"Configuration declares schema version {config.schema_version}; this "
                    f"build expects {CONFIG_SCHEMA_VERSION}."
                ),
                remediation="Regenerate the configuration if fields appear to be ignored.",
            )
        )

    if not config.email.enabled:
        findings.append(
            ConfigurationFinding(
                severity="info",
                code="EMAIL_DISABLED",
                message="E-mail notification is disabled; results are written to disk only.",
                remediation=None,
            )
        )

    return findings


def load_configuration(
    config_path: Path | str,
    *,
    key_path: Path | str | None = None,
    verify_secrets: bool = True,
) -> LoadedConfiguration:
    """Load, validate and prepare a configuration for execution.

    Args:
        config_path: Path to the JSON configuration file.
        key_path: Override the encryption key location. Defaults to
            ``encryption.key`` beside the configuration.
        verify_secrets: Decrypt every stored secret during loading so that a
            key mismatch fails immediately with a clear message, rather than
            surfacing later as an apparently unrelated connection failure on
            one interface. Every secret is also registered with the masking
            layer during this pass, which is what lets the log filter scrub
            credentials that a third-party driver echoes back.

    Returns:
        A :class:`LoadedConfiguration`.

    Raises:
        ConfigurationFileError: the file is missing, unreadable or malformed.
        ConfigurationValidationError: the file violates the schema.
        EncryptionKeyError: the key file is missing or invalid.
        DecryptionError: a stored secret cannot be decrypted and
            ``verify_secrets`` is set.
    """
    resolved_config_path = Path(config_path).expanduser().resolve()
    raw = _read_config_bytes(resolved_config_path)
    payload = _parse_json(raw, resolved_config_path)
    config = _validate_model(payload, resolved_config_path)

    resolved_key_path = resolve_key_path(resolved_config_path, key_path)
    cipher = EncryptionKeyManager(resolved_key_path).load()

    base_directory = resolved_config_path.parent.parent
    if resolved_config_path.parent.name != "config":
        # The configuration is not in a conventional config/ folder, so resolve
        # relative directories against the folder holding it instead.
        base_directory = resolved_config_path.parent

    reports_directory = Path(config.reports.directory)
    if not reports_directory.is_absolute():
        reports_directory = base_directory / reports_directory

    logs_directory = Path(config.logging.directory)
    if not logs_directory.is_absolute():
        logs_directory = base_directory / logs_directory

    findings = _collect_findings(config, resolved_config_path, resolved_key_path)

    loaded = LoadedConfiguration(
        config=config,
        config_path=resolved_config_path,
        key_path=resolved_key_path,
        cipher=cipher,
        base_directory=base_directory,
        reports_directory=reports_directory,
        logs_directory=logs_directory,
        findings=findings,
    )

    if verify_secrets:
        _verify_all_secrets(loaded)

    return loaded


def _verify_all_secrets(loaded: LoadedConfiguration) -> None:
    """Decrypt every stored secret and decide how severe any failure is.

    The distinction drawn here matters operationally:

    * **Every** protected secret failing means the configuration and the key do
      not belong together -- almost always a configuration copied to another
      host without its ``encryption.key``. Nothing can be validated, so this is
      fatal and the process exits with the configuration error code. A run that
      dialled nothing must not look like a run that found nothing wrong.
    * **Some** failing means those particular values are damaged. Aborting the
      whole run would then throw away the verdict on every healthy interface.
      Instead a warning is recorded and each affected interface fails on its
      own at run time, so the report names exactly which credential is broken
      while still reporting the rest of the estate.

    Plaintext values are registered with the masking layer but never rejected
    here; ``strict_secrets`` is enforced at resolution time by the connectors,
    so that a policy violation is attributed to the interface it belongs to.
    """
    strict = loaded.config.execution.strict_secrets
    protected = 0
    failed: list[str] = []

    def _verify(stored: str | None, field_name: str) -> None:
        nonlocal protected
        if not stored:
            return
        if envelope_kind(stored) is EnvelopeKind.PLAINTEXT:
            secret_registry.register(stored)
            return
        protected += 1
        try:
            loaded.cipher.resolve(
                stored, field_name=field_name, allow_plaintext=not strict
            )
        except DecryptionError:
            failed.append(field_name)

    for interface in loaded.config.interfaces:
        for field_name, stored in interface.secret_values().items():
            _verify(stored, f"{interface.name}.{field_name}")

    _verify(loaded.config.email.password, "email.password")

    if not failed:
        return

    if len(failed) == protected:
        raise DecryptionError(
            f"None of the {protected} stored secrets in {loaded.config_path.name} could be "
            "decrypted with the available key.",
            remediation=(
                "The configuration and the encryption key do not belong together. Copy the "
                f"encryption.key that was generated alongside this configuration into "
                f"{loaded.key_path.parent}, or regenerate the configuration on this host "
                "with 'python generate_config.py'."
            ),
            details={
                "config_path": str(loaded.config_path),
                "key_path": str(loaded.key_path),
                "secret_count": protected,
            },
        )

    loaded.findings.append(
        ConfigurationFinding(
            severity="warning",
            code="SECRET_DECRYPTION_FAILED",
            message=(
                f"{len(failed)} of {protected} stored secrets could not be decrypted: "
                + ", ".join(sorted(failed))
                + ". The affected interfaces will fail individually; the rest still run."
            ),
            remediation=(
                "Re-enter the affected credentials with 'python generate_config.py'. If the "
                "encryption key was rotated, restore the retired key line so existing "
                "values remain readable."
            ),
        )
    )


def save_configuration(
    config: ApplicationConfig,
    config_path: Path | str,
    *,
    key_path: Path | str | None = None,
    create_key: bool = True,
) -> Path:
    """Serialise a configuration to disk with restrictive permissions.

    Secrets must already be encrypted by the caller; this function does not
    encrypt, so that the wizard owns exactly one place where plaintext is
    converted, and no code path can accidentally persist a raw credential by
    forgetting a step here.

    Args:
        config: The configuration to write.
        config_path: Destination path. Parent directories are created.
        key_path: Encryption key location, created when missing.
        create_key: Create the key file if it does not exist.

    Returns:
        The path written.

    Raises:
        ConfigurationFileError: if the file cannot be written.
    """
    destination = Path(config_path).expanduser()
    ensure_directory(destination.parent)

    resolved_key_path = resolve_key_path(destination, key_path)
    if create_key and not resolved_key_path.exists():
        EncryptionKeyManager(resolved_key_path).load_or_create()

    stamped = config.model_copy(
        update={
            "generated_at": datetime.now(UTC).isoformat(),
            "generated_by": f"generate_config.py {APP_VERSION}",
            "schema_version": CONFIG_SCHEMA_VERSION,
        }
    )

    payload = stamped.model_dump(mode="json", exclude_none=False)
    text = json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=False) + "\n"

    try:
        atomic_write_text(destination, text, secure=True)
    except OSError as error:
        raise ConfigurationFileError(
            f"Configuration file could not be written: {destination}",
            remediation="Check directory permissions and available disk space.",
            details={"config_path": str(destination)},
            cause=error,
        ) from error

    return destination


def redacted_config_dump(config: ApplicationConfig) -> dict[str, Any]:
    """Return a fully redacted configuration dump for debug logging.

    Used when the debug log records what was loaded. Every secret-shaped field
    is masked structurally, and free-text values are additionally scrubbed for
    embedded credentials.
    """
    redacted: dict[str, Any] = redact_mapping(config.model_dump(mode="json"))
    return redacted
