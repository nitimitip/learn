"""The executive PDF report (ReportLab).

Why PDF
-------
This is the artefact a run is judged by. It is attached to the notification
e-mail, filed against a change record, and forwarded to people who will never
open a terminal. A PDF pages, prints and archives identically everywhere,
which an HTML file does not: HTML reflows differently in every client, cannot
be signed off as a fixed document, and is routinely stripped or quarantined by
mail gateways.

Structure
---------
The document answers the reader's questions in the order they ask them:

1. **Masthead and verdict** - what happened, in one band and one bar.
2. **Indicators** - the six numbers an executive reads and stops.
3. **Warnings** - what passed but should not be ignored.
4. **Failed connections** - the failing endpoint, why, and the action to take,
   each with its diagnostic evidence. Failures lead the document; nobody
   should have to page past a wall of successes to find them.
5. **Successful connections** - the proof, with connect latency.
6. **Oracle database links** - present only when links were checked. The one
   table whose failures are not about the endpoint beside them: the link is
   opened by the database server, so the broken path leads somewhere else.
7. **Skipped interfaces** - what was *not* tested, so a clean verdict is never
   read as broader than it is.
8. **Statistics** - the distribution, and failures grouped by cause, which is
   what distinguishes one infrastructure change from many unrelated faults.
9. **Execution environment** - where and how the run happened.

Layout notes
------------
Long free-text values (an error message, a remediation, a server banner) can
exceed a page on their own. Every table that can carry such a value is built
with ``splitInRow`` so ReportLab breaks the row mid-cell instead of aborting
the build with a LayoutError, which is how a single verbose driver message
would otherwise lose the entire report.

The stack trace is deliberately absent: it belongs in the JSON report and the
debug log, not in the document a manager reads.
"""

from __future__ import annotations

import io
from collections.abc import Mapping, Sequence
from functools import partial
from typing import Any
from xml.sax.saxutils import escape as _xml_escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import (
    Flowable,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from core import theme
from core.constants import DISPLAY_TIMESTAMP_FORMAT
from models.results import ExecutionSummary, ValidationResult

__all__ = ["render_pdf"]

# ---------------------------------------------------------------------------
# Geometry
# ---------------------------------------------------------------------------

_PAGE_SIZE = A4
_MARGIN = 14 * mm
_TOP_MARGIN = 12 * mm
_BOTTOM_MARGIN = 18 * mm

#: SimpleDocTemplate pads its frame by 6pt on each side, so a flowable gets
#: 12pt less than (page width - margins). Building tables at the full margin
#: width overflows the frame and eats the slack ReportLab needs when deciding
#: whether a row fits, which makes an oversized-row failure likelier.
_FRAME_PAD = 6
_CONTENT_WIDTH = _PAGE_SIZE[0] - 2 * _MARGIN - 2 * _FRAME_PAD

# ---------------------------------------------------------------------------
# Palette, resolved once from the shared theme
# ---------------------------------------------------------------------------

_MAROON = colors.HexColor(theme.BRAND_MAROON)
_BRAND = colors.HexColor(theme.BRAND_RED)
_BRAND_DK = colors.HexColor(theme.BRAND_RED_DARK)
_BAND = colors.HexColor(theme.BAND)
_ZEBRA = colors.HexColor(theme.ZEBRA)
_BORDER = colors.HexColor(theme.BORDER)
_INK = colors.HexColor(theme.INK)
_MUTED = colors.HexColor(theme.MUTED)
_PASS = colors.HexColor(theme.PASS)
_FAIL = colors.HexColor(theme.FAIL)
_WARN = colors.HexColor(theme.WARN)
_SKIP = colors.HexColor(theme.SKIP)
_WARN_BG = colors.HexColor(theme.WARN_BG)
_WARN_BORDER = colors.HexColor(theme.WARN_BORDER)
_EYEBROW = colors.HexColor(theme.EYEBROW_FG)
_METER_TRACK = colors.HexColor("#E6EAEF")

# ---------------------------------------------------------------------------
# Paragraph styles
# ---------------------------------------------------------------------------

_BODY = ParagraphStyle(
    "body", fontName="Helvetica", fontSize=8.5, leading=11.5, textColor=_INK
)
_BODY_B = ParagraphStyle("body-b", parent=_BODY, fontName="Helvetica-Bold")
_MONO = ParagraphStyle("mono", parent=_BODY, fontName="Courier", fontSize=8)
_SMALL = ParagraphStyle("small", parent=_BODY, fontSize=7.8, leading=10, textColor=_MUTED)
_HEAD = ParagraphStyle(
    "head", fontName="Helvetica-Bold", fontSize=8.5, leading=11, textColor=colors.white
)
_TITLE = ParagraphStyle(
    "title", fontName="Helvetica-Bold", fontSize=17, leading=21, textColor=colors.white
)
_EYEBROW_STYLE = ParagraphStyle(
    "eyebrow", fontName="Helvetica-Bold", fontSize=7.5, leading=10, textColor=_EYEBROW
)
_MASTHEAD_SUB = ParagraphStyle(
    "masthead-sub", fontName="Helvetica", fontSize=8.5, leading=12, textColor=colors.white
)
_WORDMARK = ParagraphStyle(
    "wordmark",
    fontName="Helvetica-BoldOblique",
    fontSize=10,
    leading=12.5,
    textColor=colors.white,
    alignment=2,  # right
)
_SECTION = ParagraphStyle(
    "section", fontName="Helvetica-Bold", fontSize=10.5, leading=13, textColor=colors.white
)
_LEAD = ParagraphStyle("lead", parent=_BODY, fontSize=9.5, leading=13.5)
#: Sub-heading inside a section, bound to the table it introduces.
_SUBHEAD = ParagraphStyle("subhead", parent=_BODY_B, spaceAfter=3, keepWithNext=1)
_SUBNOTE = ParagraphStyle(
    "subnote", fontName="Helvetica", fontSize=7.8, leading=10,
    textColor=_MUTED, spaceAfter=3, keepWithNext=1,
)
_EMPTY = ParagraphStyle(
    "empty", fontName="Helvetica-Oblique", fontSize=8.5, leading=11, textColor=_MUTED
)
_KPI_NUMBER = ParagraphStyle(
    "kpi", fontName="Helvetica-Bold", fontSize=16, leading=19, textColor=_INK, alignment=1
)
_KPI_LABEL = ParagraphStyle(
    "kpi-label", fontName="Helvetica", fontSize=6.8, leading=9, textColor=_MUTED, alignment=1
)
_VERDICT = ParagraphStyle(
    "verdict", fontName="Helvetica-Bold", fontSize=12, leading=15, textColor=colors.white
)
_VERDICT_SUB = ParagraphStyle(
    "verdict-sub",
    fontName="Helvetica",
    fontSize=9,
    leading=13,
    textColor=colors.white,
    alignment=2,
)

_STATUS_COLOUR = {"SUCCESS": _PASS, "FAILED": _FAIL, "SKIPPED": _SKIP}


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------


def _p(text: Any, style: ParagraphStyle = _BODY) -> Paragraph:
    """Return an escaped paragraph, with newlines honoured.

    Every value reaching this function originates from a remote endpoint or an
    operator-supplied configuration, so it is escaped without exception: an
    error message containing ``<b>`` must print as text, not restyle the
    report, and an unbalanced angle bracket must not abort the build.
    """
    if text is None or text == "":
        text = "-"
    safe = _xml_escape(str(text)).replace("\r\n", "\n").replace("\n", "<br/>")
    return Paragraph(safe, style)


#: Detail key holding the per-link records. It is excluded from the inline
#: evidence lines and given its own section instead: a list of link records
#: rendered as one comma-joined string is unreadable, and it is the one piece
#: of evidence a reader may need to compare across interfaces.
_DB_LINKS_KEY = "db_links"

#: Status word to the colour it is printed in, in the database link table.
_DB_LINK_STATUS_COLOURS: dict[str, Any] = {
    "OK": _PASS,
    "FAILED": _FAIL,
    "NOT CHECKED": _MUTED,
}


def _render_value(value: Any) -> str:
    """Render one diagnostic detail value for the report.

    Kept out of the layout code so that formatting decisions stay testable.
    """
    if value is None:
        return ""
    if isinstance(value, bool):
        return "yes" if value else "no"
    if isinstance(value, (list, tuple)):
        return ", ".join(str(item) for item in value) if value else "(none)"
    if isinstance(value, Mapping):
        return ", ".join(f"{key}={item}" for key, item in value.items())
    return str(value)


def _details_line(details: Mapping[str, Any]) -> str:
    """Return connector evidence as one compact ``key: value`` line."""
    return "   ".join(
        f"{key}: {_render_value(value)}"
        for key, value in details.items()
        if key != _DB_LINKS_KEY
    )


class _Meter(Flowable):
    """A success-rate bar, drawn rather than tabulated.

    Immediately under the verdict band it answers "how bad is it?" before the
    reader has parsed a single number.
    """

    def __init__(self, percentage: float, colour: colors.Color, width: float) -> None:
        super().__init__()
        self.percentage = max(0.0, min(100.0, float(percentage)))
        self.colour = colour
        self.width = width
        self.height = 8.0

    def wrap(self, _available_width: float, _available_height: float) -> tuple[float, float]:
        """Report the fixed size this flowable occupies.

        ReportLab calls ``wrap`` positionally, so the available space is
        accepted and ignored: the meter is always exactly as wide as the
        content frame.
        """
        return self.width, self.height

    def draw(self) -> None:
        """Paint the track and the filled portion."""
        canvas = self.canv
        canvas.setFillColor(_METER_TRACK)
        canvas.rect(0, 0, self.width, self.height, stroke=0, fill=1)
        filled = self.width * self.percentage / 100.0
        if filled > 0:
            canvas.setFillColor(self.colour)
            canvas.rect(0, 0, filled, self.height, stroke=0, fill=1)


class _NumberedCanvas(Canvas):
    """Canvas that stamps ``Page X of Y`` and the brand footer on every page.

    The total page count is unknown until the document is built, so pages are
    held back and the footer is painted during :meth:`save`, once the total is
    finally known.
    """

    def __init__(self, *args: Any, footer_left: str = "", **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._footer_left = footer_left
        self._saved_states: list[dict[str, Any]] = []

    def showPage(self) -> None:  # noqa: N802 - ReportLab API
        """Hold the finished page instead of emitting it."""
        self._saved_states.append(dict(self.__dict__))
        self._startPage()

    def save(self) -> None:
        """Emit every held page with its footer completed."""
        total = len(self._saved_states)
        for state in self._saved_states:
            self.__dict__.update(state)
            self._draw_footer(total)
            super().showPage()
        super().save()

    def _draw_footer(self, total_pages: int) -> None:
        self.saveState()
        self.setStrokeColor(_BORDER)
        self.setLineWidth(0.5)
        self.line(_MARGIN, 12 * mm, _PAGE_SIZE[0] - _MARGIN, 12 * mm)
        self.setFont("Helvetica", 7.5)
        self.setFillColor(_MUTED)
        self.drawString(_MARGIN, 8.5 * mm, self._footer_left)
        self.drawRightString(
            _PAGE_SIZE[0] - _MARGIN,
            8.5 * mm,
            f"Page {int(self.getPageNumber())} of {total_pages}",
        )
        self.restoreState()


# ---------------------------------------------------------------------------
# Reusable blocks
# ---------------------------------------------------------------------------


def _masthead(summary: ExecutionSummary, generated_at: str) -> Table:
    """Return the flat-maroon brand banner: the printed twin of the e-mail."""
    left = [
        _p("CONNECTIVITY VALIDATION", _EYEBROW_STYLE),
        Spacer(0, 3),
        _p("Enterprise Connectivity Validation Report", _TITLE),
        Spacer(0, 4),
        _p(
            f"Environment {summary.environment}   |   {generated_at}   |   "
            f"run {summary.run_id}",
            _MASTHEAD_SUB,
        ),
    ]
    right = [Paragraph("NORTHERN<br/>POWERGRID.", _WORDMARK)]

    table = Table(
        [[left, right]], colWidths=[_CONTENT_WIDTH * 0.74, _CONTENT_WIDTH * 0.26]
    )
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), _MAROON),
                ("VALIGN", (0, 0), (0, 0), "MIDDLE"),
                ("VALIGN", (1, 0), (1, 0), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 12),
                ("RIGHTPADDING", (0, 0), (-1, -1), 12),
                ("TOPPADDING", (0, 0), (-1, -1), 12),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 12),
            ]
        )
    )
    return table


def _verdict_band(summary: ExecutionSummary) -> list[Flowable]:
    """Return the verdict strip and its success-rate meter."""
    colour = colors.HexColor(theme.SEVERITY_COLOR[summary.severity])
    verdict = Table(
        [
            [
                _p(f"{summary.status_word} - {summary.severity.value}", _VERDICT),
                _p(
                    f"{summary.success_percentage:.1f}% of "
                    f"{summary.validated_interfaces} validated interface(s) passed",
                    _VERDICT_SUB,
                ),
            ]
        ],
        colWidths=[_CONTENT_WIDTH * 0.45, _CONTENT_WIDTH * 0.55],
    )
    verdict.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colour),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 12),
                ("RIGHTPADDING", (0, 0), (-1, -1), 12),
                ("TOPPADDING", (0, 0), (-1, -1), 7),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
            ]
        )
    )
    return [verdict, _Meter(summary.success_percentage, colour, _CONTENT_WIDTH)]


def _indicators(summary: ExecutionSummary) -> Table:
    """Return the six-cell indicator row: the numbers read first, and often only."""
    cells = [
        (str(summary.total_interfaces), "INTERFACES", _INK),
        (str(summary.passed), "PASSED", _PASS),
        (str(summary.failed), "FAILED", _FAIL),
        (str(summary.skipped), "SKIPPED", _SKIP),
        (f"{summary.success_percentage:.1f}%", "SUCCESS RATE", _INK),
        (summary.duration_display, "DURATION", _INK),
    ]
    numbers = [
        Paragraph(
            _xml_escape(value),
            ParagraphStyle(f"kpi-{index}", parent=_KPI_NUMBER, textColor=colour),
        )
        for index, (value, _, colour) in enumerate(cells)
    ]
    labels = [_p(label, _KPI_LABEL) for _, label, _ in cells]

    width = _CONTENT_WIDTH / len(cells)
    table = Table([numbers, labels], colWidths=[width] * len(cells))
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), _BAND),
                ("BOX", (0, 0), (-1, -1), 0.5, _BORDER),
                ("INNERGRID", (0, 0), (-1, -1), 0.5, _BORDER),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING", (0, 0), (-1, 0), 8),
                ("BOTTOMPADDING", (0, 0), (-1, 0), 0),
                ("TOPPADDING", (0, 1), (-1, 1), 1),
                ("BOTTOMPADDING", (0, 1), (-1, 1), 8),
            ]
        )
    )
    return table


def _section(label: str) -> list[Flowable]:
    """Return a brand section band.

    The band is bound to whatever follows it (``keepWithNext``) and its spacing
    is carried as style rather than as separate spacer flowables, because a
    spacer between the two would be what the page break lands on -- leaving a
    section heading stranded at the foot of a page above an empty gap.
    """
    table = Table(
        [[_p(label, _SECTION)]],
        colWidths=[_CONTENT_WIDTH],
        spaceBefore=12,
        spaceAfter=5,
    )
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), _BRAND),
                ("LEFTPADDING", (0, 0), (-1, -1), 10),
                ("RIGHTPADDING", (0, 0), (-1, -1), 10),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    table.keepWithNext = 1
    return [table]


def _data_table(
    headers: Sequence[str],
    rows: Sequence[Sequence[Any]],
    column_widths: Sequence[float],
    empty_message: str,
    *,
    styles: Sequence[ParagraphStyle] | None = None,
    extra_style: Sequence[tuple[Any, ...]] = (),
) -> list[Flowable]:
    """Return a banded data table, or a note when there is nothing to show."""
    if not rows:
        return [_note(empty_message)]

    body: list[list[Any]] = [[_p(head, _HEAD) for head in headers]]
    for values in rows:
        body.append(
            [
                value if isinstance(value, Flowable)
                else _p(value, styles[index] if styles else _BODY)
                for index, value in enumerate(values)
            ]
        )

    # splitInRow: one verbose error message or server banner can be taller than
    # a page on its own, and a row that cannot be split aborts the whole build.
    table = Table(body, colWidths=list(column_widths), repeatRows=1, splitInRow=1)
    style: list[tuple[Any, ...]] = [
        ("BACKGROUND", (0, 0), (-1, 0), _BRAND_DK),
        ("GRID", (0, 0), (-1, -1), 0.5, _BORDER),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]
    style.extend(
        ("BACKGROUND", (0, index), (-1, index), _ZEBRA)
        for index in range(2, len(body), 2)
    )
    style.extend(extra_style)
    table.setStyle(TableStyle(style))
    return [table]


def _fields(pairs: Sequence[tuple[str, Any]]) -> list[Flowable]:
    """Return a label/value block."""
    label_width = _CONTENT_WIDTH * 0.28
    body = [[_p(label, _HEAD), _p(value)] for label, value in pairs]
    table = Table(
        body, colWidths=[label_width, _CONTENT_WIDTH - label_width], splitInRow=1
    )
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (0, -1), _BRAND_DK),
                ("GRID", (0, 0), (-1, -1), 0.5, _BORDER),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    return [table]


def _note(message: str) -> Table:
    """Return a bordered 'nothing to report' note."""
    table = Table([[_p(message, _EMPTY)]], colWidths=[_CONTENT_WIDTH])
    table.setStyle(
        TableStyle(
            [
                ("BOX", (0, 0), (-1, -1), 0.5, _BORDER),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    return table


# ---------------------------------------------------------------------------
# Sections
# ---------------------------------------------------------------------------


def _headline(summary: ExecutionSummary) -> str:
    """Return the executive sentence that opens the document."""
    if not summary.has_failures:
        if summary.validated_interfaces == 0:
            return (
                "No interface was validated in this run: every configured interface is "
                "disabled. Nothing was tested, so this result confirms nothing about the "
                "estate."
            )
        return (
            f"All {summary.passed} validated connection(s) succeeded in "
            f"{summary.duration_display}. No action is required."
        )
    return (
        f"{summary.failed} of {summary.validated_interfaces} validated connection(s) "
        f"failed. The failing endpoints and the recommended action for each are listed "
        f"below, with the diagnostic evidence recorded at the time of failure."
    )


def _warnings_block(summary: ExecutionSummary) -> list[Flowable]:
    """Return the amber warnings callout, or nothing when the run was clean."""
    warnings = [
        (result.interface_name, warning)
        for result in summary.results
        for warning in result.warnings
    ]
    if not warnings:
        return []

    lines = [
        _p(f"Warnings ({len(warnings)})", ParagraphStyle(
            "warn-title", parent=_BODY_B, textColor=_WARN, fontSize=9, leading=12
        )),
    ]
    lines.extend(_p(f"{name} - {warning}") for name, warning in warnings)

    table = Table([[lines]], colWidths=[_CONTENT_WIDTH])
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), _WARN_BG),
                ("BOX", (0, 0), (-1, -1), 0.5, _WARN_BORDER),
                ("LEFTPADDING", (0, 0), (-1, -1), 10),
                ("RIGHTPADDING", (0, 0), (-1, -1), 10),
                ("TOPPADDING", (0, 0), (-1, -1), 7),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
            ]
        )
    )
    return [Spacer(0, 10), table]


def _failure_block(result: ValidationResult) -> list[Flowable]:
    """Return one failure card: endpoint, cause, action, evidence.

    The coloured header is bound to the rows beneath it rather than the card
    being kept whole. Keeping a whole card together strands a third of a page
    of white space whenever the next failure does not fit, and a long
    remediation could not be honoured anyway; binding just the header is
    enough to guarantee an interface name is never left dangling alone at the
    foot of a page.
    """
    label_width = _CONTENT_WIDTH * 0.20
    value_width = _CONTENT_WIDTH - label_width

    header = Table(
        [
            [
                _p(result.interface_name, ParagraphStyle(
                    "fail-name", parent=_HEAD, fontSize=9.5, leading=12
                )),
                _p(
                    f"{result.interface_type.value}  |  {result.duration_display}"
                    f"  |  attempt(s): {result.attempts}",
                    ParagraphStyle(
                        "fail-meta", parent=_HEAD, fontName="Helvetica", fontSize=8,
                        alignment=2,
                    ),
                ),
            ]
        ],
        colWidths=[_CONTENT_WIDTH * 0.5, _CONTENT_WIDTH * 0.5],
        spaceBefore=6,
    )
    header.keepWithNext = 1
    header.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), _FAIL),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )

    rows: list[list[Any]] = [
        [_p("Endpoint", _BODY_B), _p(result.endpoint, _MONO)],
        [_p("Authentication", _BODY_B), _p(result.auth_method.value)],
        [
            _p("Failure", _BODY_B),
            _p(
                f"[{result.error_code or 'UNCLASSIFIED'}] {result.error_message or '-'}",
                ParagraphStyle("fail-msg", parent=_BODY, textColor=_FAIL),
            ),
        ],
    ]
    if result.remediation:
        rows.append([_p("Action", _BODY_B), _p(result.remediation)])
    for key, value in result.details.items():
        if key == _DB_LINKS_KEY:
            # Every link is listed in its own section, where the columns fit.
            continue
        rows.append([_p(key, _SMALL), _p(_render_value(value), _MONO)])

    body = Table(rows, colWidths=[label_width, value_width], splitInRow=1)
    body.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.5, _BORDER),
                ("BACKGROUND", (0, 0), (0, -1), _BAND),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )

    return [header, body]


def _successes(summary: ExecutionSummary) -> list[Flowable]:
    """Return the successful-connection table, with evidence beneath each row."""
    results = summary.successful_results
    if not results:
        return [_note("No interface passed in this run.")]

    widths = [
        _CONTENT_WIDTH * 0.21,
        _CONTENT_WIDTH * 0.09,
        _CONTENT_WIDTH * 0.34,
        _CONTENT_WIDTH * 0.14,
        _CONTENT_WIDTH * 0.11,
        _CONTENT_WIDTH * 0.11,
    ]
    headers = ["Interface", "Type", "Endpoint", "Authentication", "Latency", "Duration"]
    body: list[list[Any]] = [[_p(head, _HEAD) for head in headers]]
    evidence_rows: list[int] = []

    for result in results:
        body.append(
            [
                _p(result.interface_name, _BODY_B),
                _p(result.interface_type.value),
                _p(result.endpoint, _MONO),
                _p(result.auth_method.value),
                _p(result.latency_display),
                _p(result.duration_display),
            ]
        )
        if result.details:
            evidence_rows.append(len(body))
            body.append([_p(_details_line(result.details), _SMALL), "", "", "", "", ""])

    table = Table(body, colWidths=widths, repeatRows=1, splitInRow=1)
    style: list[tuple[Any, ...]] = [
        ("BACKGROUND", (0, 0), (-1, 0), _BRAND_DK),
        ("GRID", (0, 0), (-1, -1), 0.5, _BORDER),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("ALIGN", (4, 1), (5, -1), "RIGHT"),
    ]
    # Evidence spans the full width beneath its interface: a cramped extra
    # column would truncate exactly the value that explains a slow connection.
    for row in evidence_rows:
        style.extend(
            [
                ("SPAN", (0, row), (-1, row)),
                ("BACKGROUND", (0, row), (-1, row), _ZEBRA),
            ]
        )
    table.setStyle(TableStyle(style))
    return [table]


def _database_link_entries(
    summary: ExecutionSummary,
) -> list[tuple[ValidationResult, Mapping[str, Any]]]:
    """Return every database link recorded in this run, with its interface.

    Read from ``details`` rather than from the configuration so that the table
    reports what was actually probed, including a link found at run time that
    nobody knew the account owned.
    """
    entries: list[tuple[ValidationResult, Mapping[str, Any]]] = []
    for result in summary.results:
        links = result.details.get(_DB_LINKS_KEY)
        if not isinstance(links, (list, tuple)):
            continue
        entries.extend(
            (result, link) for link in links if isinstance(link, Mapping)
        )
    return entries


def _database_links(summary: ExecutionSummary) -> list[Flowable]:
    """Return the database link section, or nothing when none were checked.

    The section exists because a link failure is the one result in this report
    that is not about the endpoint named in the row above it. The endpoint is
    healthy; the path from it to somewhere else is not, and an operator needs
    to see which remote databases those were before deciding who to call.
    """
    entries = _database_link_entries(summary)
    if not entries:
        return []

    failed = sum(1 for _, link in entries if str(link.get("status")) == "FAILED")
    note = (
        "Each link was opened with a one-row probe against dual through the link. The "
        "database server opens the link, so a failure here is on the path from that "
        "server to the remote database, not on the path from this host."
    )
    if failed:
        note = f"{note} {failed} link(s) could not be opened."

    story: list[Flowable] = _section(f"Oracle database links ({len(entries)})")
    story.append(_p(note, _SUBNOTE))

    widths = [
        _CONTENT_WIDTH * 0.17,
        _CONTENT_WIDTH * 0.17,
        _CONTENT_WIDTH * 0.12,
        _CONTENT_WIDTH * 0.20,
        _CONTENT_WIDTH * 0.11,
        _CONTENT_WIDTH * 0.23,
    ]
    rows: list[list[Any]] = []
    status_colours: list[tuple[Any, ...]] = []

    for index, (result, link) in enumerate(entries, start=1):
        status = str(link.get("status", "-"))
        latency = link.get("latency_ms")
        detail = str(link.get("message") or "")
        if not detail and latency is not None:
            detail = f"opened in {latency:.0f} ms" if isinstance(latency, (int, float)) else ""
        rows.append(
            [
                result.interface_name,
                str(link.get("name", "-")),
                str(link.get("remote_user") or "-"),
                str(link.get("target") or "-"),
                status,
                detail or "-",
            ]
        )
        colour = _DB_LINK_STATUS_COLOURS.get(status)
        if colour is not None:
            status_colours.append(("TEXTCOLOR", (4, index), (4, index), colour))

    story.extend(
        _data_table(
            ["Interface", "Link", "Remote user", "Target", "Status", "Detail"],
            rows,
            widths,
            "No database link was checked in this run.",
            styles=[_BODY_B, _MONO, _BODY, _MONO, _BODY_B, _SMALL],
            extra_style=status_colours,
        )
    )
    return story


def _statistics(summary: ExecutionSummary) -> list[Flowable]:
    """Return the distribution tables and the failure-cause breakdown."""
    story: list[Flowable] = []
    widths = [
        _CONTENT_WIDTH * 0.40,
        _CONTENT_WIDTH * 0.15,
        _CONTENT_WIDTH * 0.15,
        _CONTENT_WIDTH * 0.15,
        _CONTENT_WIDTH * 0.15,
    ]
    numeric = ("ALIGN", (1, 1), (-1, -1), "RIGHT")

    for title, breakdown in (
        ("By connectivity type", summary.counts_by_type()),
        ("By category", summary.counts_by_category()),
    ):
        story.append(_p(title, _SUBHEAD))
        story.extend(
            _data_table(
                ["Name", "Total", "Passed", "Failed", "Skipped"],
                [
                    [
                        name,
                        counts["total"],
                        counts["passed"],
                        counts["failed"],
                        counts["skipped"],
                    ]
                    for name, counts in breakdown.items()
                ],
                widths,
                "Nothing was recorded.",
                extra_style=[numeric],
            )
        )
        story.append(Spacer(0, 8))

    error_counts = summary.counts_by_error_code()
    story.append(_p("Failures by cause", _SUBHEAD))
    story.append(
        _p(
            "One cause dominating many interfaces is the signature of a single "
            "infrastructure change rather than several unrelated faults.",
            _SUBNOTE,
        )
    )
    story.extend(
        _data_table(
            ["Error code", "Interfaces affected"],
            [[code, count] for code, count in error_counts.items()],
            [_CONTENT_WIDTH * 0.7, _CONTENT_WIDTH * 0.3],
            "No failures were recorded in this run.",
            extra_style=[("ALIGN", (1, 1), (-1, -1), "RIGHT")],
        )
    )

    slowest = summary.slowest_result
    if slowest is not None:
        story.append(Spacer(0, 6))
        story.append(
            _p(
                f"Slowest interface: {slowest.interface_name} "
                f"({slowest.duration_display}).",
                _SMALL,
            )
        )
    return story


def _environment_block(
    summary: ExecutionSummary, started_at: str, ended_at: str
) -> list[Flowable]:
    """Return the execution-environment field block."""
    pairs: list[tuple[str, Any]] = [
        ("Configuration", summary.config_path),
        ("Environment", summary.environment),
        ("Run identifier", summary.run_id),
        ("Started", started_at),
        ("Finished", ended_at),
        ("Duration", summary.duration_display),
    ]
    if summary.average_latency_ms is not None:
        pairs.append(("Average connect latency", f"{summary.average_latency_ms} ms"))

    platform = summary.platform
    if platform is not None:
        pairs.extend(
            [
                ("Hostname", f"{platform.hostname} ({platform.fqdn})"),
                ("IP address", platform.ip_address),
                (
                    "Operating system",
                    f"{platform.operating_system} {platform.os_release} "
                    f"({platform.architecture})",
                ),
                (
                    "Python",
                    f"{platform.python_implementation} {platform.python_version_short}",
                ),
                ("Executed by", f"{platform.username} (pid {platform.process_id})"),
            ]
        )
    return _fields(pairs)


# ---------------------------------------------------------------------------
# Document
# ---------------------------------------------------------------------------


def render_pdf(summary: ExecutionSummary, *, app_name: str, app_version: str) -> bytes:
    """Render the executive PDF report for one run.

    Args:
        summary: The completed run to report on.
        app_name: Product name, printed in the document properties.
        app_version: Product version, printed in the closing line.

    Returns:
        The complete PDF document. The caller writes it atomically, so a
        half-built document never reaches the reports directory.
    """
    generated_at = summary.ended_at.strftime(DISPLAY_TIMESTAMP_FORMAT)
    started_at = summary.started_at.strftime(DISPLAY_TIMESTAMP_FORMAT)

    story: list[Flowable] = [_masthead(summary, generated_at)]
    story.extend(_verdict_band(summary))
    story.append(Spacer(0, 12))
    story.append(_indicators(summary))
    story.append(Spacer(0, 12))
    story.append(_p(_headline(summary), _LEAD))
    story.extend(_warnings_block(summary))

    if summary.failed_results:
        story.extend(_section(f"Failed connections ({len(summary.failed_results)})"))
        for result in summary.failed_results:
            story.extend(_failure_block(result))

    story.extend(_section(f"Successful connections ({len(summary.successful_results)})"))
    story.extend(_successes(summary))
    story.extend(_database_links(summary))

    if summary.skipped_results:
        story.extend(_section(f"Skipped interfaces ({len(summary.skipped_results)})"))
        story.extend(
            _data_table(
                ["Interface", "Type", "Endpoint", "Reason"],
                [
                    [
                        result.interface_name,
                        result.interface_type.value,
                        result.endpoint,
                        result.details.get("reason", "Disabled in configuration."),
                    ]
                    for result in summary.skipped_results
                ],
                [
                    _CONTENT_WIDTH * 0.24,
                    _CONTENT_WIDTH * 0.10,
                    _CONTENT_WIDTH * 0.36,
                    _CONTENT_WIDTH * 0.30,
                ],
                "No interface was skipped.",
                styles=[_BODY_B, _BODY, _MONO, _BODY],
            )
        )

    story.extend(_section("Statistics"))
    story.extend(_statistics(summary))

    story.extend(_section("Execution environment"))
    story.extend(_environment_block(summary, started_at, generated_at))
    story.append(Spacer(0, 10))
    story.append(
        _p(
            f"{app_name} {app_version}   |   {theme.ORGANISATION}   |   "
            f"generated {generated_at}",
            _SMALL,
        )
    )

    buffer = io.BytesIO()
    document = SimpleDocTemplate(
        buffer,
        pagesize=_PAGE_SIZE,
        leftMargin=_MARGIN,
        rightMargin=_MARGIN,
        topMargin=_TOP_MARGIN,
        bottomMargin=_BOTTOM_MARGIN,
        title=(
            f"Connectivity Validation Report - {summary.status_word} - "
            f"{summary.environment}"
        ),
        author=f"{theme.ORGANISATION} - {app_name}",
        subject=f"Run {summary.run_id}",
    )
    footer_left = (
        f"{theme.ORGANISATION} - Connectivity Validation - "
        f"{summary.environment} - run {summary.run_id}"
    )
    document.build(story, canvasmaker=partial(_NumberedCanvas, footer_left=footer_left))
    return buffer.getvalue()
