"""Enterprise logging: four rotating logs, correlation IDs and secret masking.

Log estate
----------
=================  ========  ==================================================
File               Level     Purpose
=================  ========  ==================================================
application.log    INFO+     The operational narrative of a run.
error.log          ERROR+    Failures only. This is the file to open first.
audit.log          INFO      Who ran what, against which configuration, with
                             what outcome. Written through a dedicated logger
                             so it stays free of operational chatter and can be
                             shipped to a SIEM on its own.
debug.log          DEBUG     Everything, including driver-level detail. Often
                             the only surviving evidence of a transient fault.
=================  ========  ==================================================

Correlation
-----------
Every record carries a ``correlation_id`` identifying the run and an
``interface_name`` identifying the endpoint being validated. Both are held in
:mod:`contextvars`, so a worker thread validating one interface stamps its own
name on every record it emits without any connector having to pass context
around. Grepping one interface out of a parallel run is therefore a single
grep.

Safety
------
:class:`utilities.masking.SecretRedactingFilter` is attached to every handler,
not to the loggers. Filters on a logger do not apply to records propagated
from child loggers, so handler-level attachment is what guarantees a record
originating in a third-party driver is still redacted.
"""

from __future__ import annotations

import contextvars
import logging
import logging.handlers
import sys
import uuid
from collections.abc import Iterator
from contextlib import contextmanager, suppress
from dataclasses import dataclass, field
from pathlib import Path

from core.constants import (
    AUDIT_LOGGER_NAME,
    DEFAULT_LOG_BACKUP_COUNT,
    LOG_FILENAME_APPLICATION,
    LOG_FILENAME_AUDIT,
    LOG_FILENAME_DEBUG,
    LOG_FILENAME_ERROR,
    LOGGER_ROOT_NAME,
)
from models.settings import LoggingSettings
from utilities.fs import ensure_directory
from utilities.masking import SecretRedactingFilter

__all__ = [
    "LoggingContext",
    "configure_logging",
    "correlation_scope",
    "current_correlation_id",
    "get_audit_logger",
    "get_logger",
    "interface_scope",
    "new_correlation_id",
]


#: Correlation identifier for the current run. Defaults to a placeholder so
#: that a record emitted before configuration still formats cleanly.
_correlation_id: contextvars.ContextVar[str] = contextvars.ContextVar(
    "correlation_id", default="-"
)

#: Name of the interface currently being validated on this thread.
_interface_name: contextvars.ContextVar[str] = contextvars.ContextVar(
    "interface_name", default="-"
)

#: Detailed format. Module, function and line are what let an operator jump
#: straight to the code path that produced a line.
_DETAILED_FORMAT = (
    "%(asctime)s | %(levelname)-8s | %(correlation_id)s | %(interface_name)s | "
    "%(name)s | %(module)s.%(funcName)s:%(lineno)d | %(message)s"
)

#: Console format. Deliberately terser: a scheduler captures stdout into a job
#: log that an operator reads as narrative, not as forensic evidence.
_CONSOLE_FORMAT = "%(asctime)s | %(levelname)-8s | %(interface_name)s | %(message)s"

_AUDIT_FORMAT = "%(asctime)s | %(correlation_id)s | %(user)s@%(host)s | %(message)s"

_TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M:%S"


def new_correlation_id() -> str:
    """Return a short, unique correlation identifier for a run."""
    return uuid.uuid4().hex[:12]


class ContextInjectingFilter(logging.Filter):
    """Stamp the current correlation ID and interface name onto each record.

    Implemented as a filter rather than a :class:`logging.LoggerAdapter` so
    that records emitted by third-party drivers, which know nothing about this
    framework, are also stamped and remain greppable alongside our own.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        """Attach context attributes and always allow the record through."""
        if not hasattr(record, "correlation_id"):
            record.correlation_id = _correlation_id.get()
        if not hasattr(record, "interface_name"):
            record.interface_name = _interface_name.get()
        return True


class AuditContextFilter(logging.Filter):
    """Add the acting user and host to every audit record."""

    def __init__(self, user: str, host: str) -> None:
        super().__init__()
        self._user = user
        self._host = host

    def filter(self, record: logging.LogRecord) -> bool:
        """Attach identity attributes and always allow the record through."""
        record.user = self._user
        record.host = self._host
        if not hasattr(record, "correlation_id"):
            record.correlation_id = _correlation_id.get()
        return True


@dataclass(slots=True)
class LoggingContext:
    """Handles and paths produced by :func:`configure_logging`.

    Retained by the caller so that the run can report where it logged, and so
    the notifier can attach the application log for exactly this run.
    """

    correlation_id: str
    directory: Path
    application_log: Path
    error_log: Path
    audit_log: Path
    debug_log: Path | None
    handlers: list[logging.Handler] = field(default_factory=list)
    degraded_reason: str | None = None
    """Set when file logging could not be established and the run continued
    with console logging only."""

    @property
    def file_logging_enabled(self) -> bool:
        """Return ``True`` when logs are being written to disk."""
        return self.degraded_reason is None

    def attachable_log_files(self) -> list[Path]:
        """Return existing log files worth attaching to a notification."""
        candidates = [self.application_log, self.error_log]
        return [path for path in candidates if path.is_file()]

    def shutdown(self) -> None:
        """Flush and close every handler this context installed.

        Called before the process exits so that a scheduler killing the job
        immediately afterwards cannot truncate the final records, and so the
        notifier can attach a complete log file.
        """
        root = logging.getLogger(LOGGER_ROOT_NAME)
        audit = logging.getLogger(AUDIT_LOGGER_NAME)
        for handler in list(self.handlers):
            # A handler whose stream is already closed must not prevent the
            # remaining handlers from being flushed and detached.
            with suppress(OSError, ValueError):
                handler.flush()
            for logger in (root, audit):
                if handler in logger.handlers:
                    logger.removeHandler(handler)
            with suppress(OSError, ValueError):
                handler.close()
        self.handlers.clear()


def _build_rotating_handler(
    path: Path,
    level: int,
    formatter: logging.Formatter,
    *,
    max_bytes: int,
    backup_count: int,
) -> logging.handlers.RotatingFileHandler:
    """Create a size-rotating file handler with the shared filters attached."""
    handler = logging.handlers.RotatingFileHandler(
        filename=str(path),
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8",
        delay=False,
    )
    handler.setLevel(level)
    handler.setFormatter(formatter)
    handler.addFilter(ContextInjectingFilter())
    handler.addFilter(SecretRedactingFilter())
    return handler


def configure_logging(
    settings: LoggingSettings,
    *,
    base_directory: Path,
    correlation_id: str | None = None,
    user: str = "-",
    host: str = "-",
) -> LoggingContext:
    """Install the framework's logging handlers and return the context.

    Idempotent: existing handlers on the framework loggers are removed first,
    so calling this twice in one process (the wizard, then a validation run)
    does not duplicate every log line.

    File logging failure is deliberately not fatal. A read-only log directory
    is an infrastructure problem, and refusing to validate connectivity because
    of it would withhold exactly the information the operator needs. The run
    continues with console logging and records the reason on the context, which
    is then reported.

    Args:
        settings: Logging configuration from the config file.
        base_directory: Directory that relative log paths resolve against.
        correlation_id: Run identifier. Generated when omitted.
        user: Acting user, recorded on every audit record.
        host: Executing host, recorded on every audit record.

    Returns:
        The installed :class:`LoggingContext`.
    """
    run_id = correlation_id or new_correlation_id()
    _correlation_id.set(run_id)

    log_directory = Path(settings.directory)
    if not log_directory.is_absolute():
        log_directory = base_directory / log_directory

    level = getattr(logging, settings.level, logging.INFO)

    root_logger = logging.getLogger(LOGGER_ROOT_NAME)
    audit_logger = logging.getLogger(AUDIT_LOGGER_NAME)

    # Rebuild from a clean slate so repeated configuration cannot duplicate output.
    for logger in (root_logger, audit_logger):
        for handler in list(logger.handlers):
            logger.removeHandler(handler)
            handler.close()

    # The framework's root logger must capture DEBUG regardless of the console
    # threshold, otherwise the debug log would be filtered before reaching it.
    root_logger.setLevel(logging.DEBUG)
    root_logger.propagate = False
    audit_logger.setLevel(logging.INFO)
    audit_logger.propagate = False

    detailed_formatter = logging.Formatter(_DETAILED_FORMAT, datefmt=_TIMESTAMP_FORMAT)
    console_formatter = logging.Formatter(_CONSOLE_FORMAT, datefmt=_TIMESTAMP_FORMAT)
    audit_formatter = logging.Formatter(_AUDIT_FORMAT, datefmt=_TIMESTAMP_FORMAT)

    handlers: list[logging.Handler] = []
    degraded_reason: str | None = None

    if settings.console_enabled:
        console_handler = logging.StreamHandler(stream=sys.stdout)
        console_handler.setLevel(level)
        console_handler.setFormatter(console_formatter)
        console_handler.addFilter(ContextInjectingFilter())
        console_handler.addFilter(SecretRedactingFilter())
        root_logger.addHandler(console_handler)
        handlers.append(console_handler)

    application_log = log_directory / LOG_FILENAME_APPLICATION
    error_log = log_directory / LOG_FILENAME_ERROR
    audit_log = log_directory / LOG_FILENAME_AUDIT
    debug_log = log_directory / LOG_FILENAME_DEBUG if settings.debug_log_enabled else None

    try:
        ensure_directory(log_directory)

        application_handler = _build_rotating_handler(
            application_log,
            max(level, logging.INFO),
            detailed_formatter,
            max_bytes=settings.max_bytes,
            backup_count=settings.backup_count,
        )
        root_logger.addHandler(application_handler)
        handlers.append(application_handler)

        error_handler = _build_rotating_handler(
            error_log,
            logging.ERROR,
            detailed_formatter,
            max_bytes=settings.max_bytes,
            backup_count=settings.backup_count,
        )
        root_logger.addHandler(error_handler)
        handlers.append(error_handler)

        if debug_log is not None:
            debug_handler = _build_rotating_handler(
                debug_log,
                logging.DEBUG,
                detailed_formatter,
                max_bytes=settings.max_bytes,
                backup_count=settings.backup_count,
            )
            root_logger.addHandler(debug_handler)
            handlers.append(debug_handler)

        audit_handler = logging.handlers.RotatingFileHandler(
            filename=str(audit_log),
            maxBytes=settings.max_bytes,
            backupCount=max(settings.backup_count, DEFAULT_LOG_BACKUP_COUNT),
            encoding="utf-8",
        )
        audit_handler.setLevel(logging.INFO)
        audit_handler.setFormatter(audit_formatter)
        audit_handler.addFilter(AuditContextFilter(user=user, host=host))
        audit_handler.addFilter(SecretRedactingFilter())
        audit_logger.addHandler(audit_handler)
        handlers.append(audit_handler)

    except OSError as error:
        degraded_reason = (
            f"File logging is unavailable ({error.strerror or error}); "
            f"directory: {log_directory}. The run continued with console logging only."
        )
        # Guarantee the run is not silent even when both file and console
        # logging were unavailable.
        if not settings.console_enabled:
            fallback = logging.StreamHandler(stream=sys.stderr)
            fallback.setLevel(logging.WARNING)
            fallback.setFormatter(console_formatter)
            fallback.addFilter(ContextInjectingFilter())
            fallback.addFilter(SecretRedactingFilter())
            root_logger.addHandler(fallback)
            handlers.append(fallback)
        root_logger.warning(degraded_reason)

    return LoggingContext(
        correlation_id=run_id,
        directory=log_directory,
        application_log=application_log,
        error_log=error_log,
        audit_log=audit_log,
        debug_log=debug_log,
        handlers=handlers,
        degraded_reason=degraded_reason,
    )


def get_logger(name: str) -> logging.Logger:
    """Return a framework logger.

    Args:
        name: Usually ``__name__``. A name already inside the framework
            namespace is returned unchanged; anything else is nested under it
            so that third-party output cannot escape the handler chain.
    """
    if name == LOGGER_ROOT_NAME or name.startswith(f"{LOGGER_ROOT_NAME}."):
        return logging.getLogger(name)
    return logging.getLogger(f"{LOGGER_ROOT_NAME}.{name}")


def get_audit_logger() -> logging.Logger:
    """Return the dedicated audit logger."""
    return logging.getLogger(AUDIT_LOGGER_NAME)


@contextmanager
def correlation_scope(correlation_id: str) -> Iterator[str]:
    """Bind ``correlation_id`` for the duration of the block."""
    token = _correlation_id.set(correlation_id)
    try:
        yield correlation_id
    finally:
        _correlation_id.reset(token)


@contextmanager
def interface_scope(interface_name: str) -> Iterator[str]:
    """Bind ``interface_name`` for the duration of the block.

    Entered by the engine around each interface. Because the value lives in a
    :class:`contextvars.ContextVar`, concurrent workers each see their own
    binding and cannot overwrite one another.
    """
    token = _interface_name.set(interface_name)
    try:
        yield interface_name
    finally:
        _interface_name.reset(token)


def current_correlation_id() -> str:
    """Return the correlation ID bound to the current context."""
    return _correlation_id.get()
