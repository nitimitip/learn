"""The framework exception hierarchy.

Every error raised deliberately by this framework derives from
:class:`ConnectivityFrameworkError`.  Three properties make these exceptions
operationally useful rather than merely descriptive:

* ``remediation`` -- the concrete next action for the on-call engineer, which
  is surfaced verbatim in the failure report instead of a raw stack trace.
* ``details`` -- structured, already redacted context (host, port, driver)
  that is carried into the JSON report and the log record.
* ``exit_code`` -- the process exit code a scheduler should observe when the
  error reaches the top level.

Connector authors should raise the specific subclass that matches the failure
mode. The engine converts any other exception into a failed result rather than
allowing it to abort the run.
"""

from __future__ import annotations

from typing import Any

from core.constants import ExitCode

__all__ = [
    "AuthenticationError",
    "CertificateValidationError",
    "ConfigurationError",
    "ConfigurationFileError",
    "ConfigurationValidationError",
    "ConnectionFailedError",
    "ConnectivityFrameworkError",
    "ConnectivityTimeoutError",
    "ConnectorError",
    "DatabaseLinkError",
    "DecryptionError",
    "DriverNotAvailableError",
    "EncryptionError",
    "EncryptionKeyError",
    "NotificationError",
    "ReportGenerationError",
    "ReportingError",
    "UnsupportedInterfaceTypeError",
    "ValidationProbeError",
]


class ConnectivityFrameworkError(Exception):
    """Base class for every error raised by the framework.

    Args:
        message: Operator facing description of what went wrong.
        remediation: The concrete action that resolves the error.
        details: Structured context. Callers must pass values that are already
            safe to persist; secrets must be masked before they reach here.
        cause: The originating exception, when this error wraps a lower level
            driver fault.
    """

    #: Exit code a scheduler observes when this error terminates the process.
    exit_code: ExitCode = ExitCode.UNEXPECTED_ERROR

    #: Short, stable machine-readable label used in reports and dashboards.
    error_code: str = "FRAMEWORK_ERROR"

    def __init__(
        self,
        message: str,
        *,
        remediation: str | None = None,
        details: dict[str, Any] | None = None,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.remediation = remediation
        self.details: dict[str, Any] = dict(details or {})
        self.cause = cause
        if cause is not None and self.__cause__ is None:
            self.__cause__ = cause

    @property
    def cause_summary(self) -> str | None:
        """Return a one-line ``TypeName: message`` summary of the cause."""
        if self.cause is None:
            return None
        cause_message = str(self.cause).strip()
        cause_type = type(self.cause).__name__
        return f"{cause_type}: {cause_message}" if cause_message else cause_type

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serialisable representation for reports and logs."""
        payload: dict[str, Any] = {
            "error_code": self.error_code,
            "error_type": type(self).__name__,
            "message": self.message,
            "exit_code": int(self.exit_code),
        }
        if self.remediation:
            payload["remediation"] = self.remediation
        if self.details:
            payload["details"] = dict(self.details)
        cause = self.cause_summary
        if cause:
            payload["cause"] = cause
        return payload

    def __str__(self) -> str:
        parts = [self.message]
        cause = self.cause_summary
        if cause:
            parts.append(f"Cause: {cause}")
        if self.remediation:
            parts.append(f"Remediation: {self.remediation}")
        return " | ".join(parts)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


class ConfigurationError(ConnectivityFrameworkError):
    """The configuration could not be read, parsed or validated.

    Configuration faults are fatal by design: running a partial validation
    against a configuration the framework does not fully understand would
    report a false clean bill of health.
    """

    exit_code = ExitCode.CONFIGURATION_ERROR
    error_code = "CONFIG_ERROR"


class ConfigurationFileError(ConfigurationError):
    """The configuration file is missing, unreadable or is not valid JSON."""

    error_code = "CONFIG_FILE_ERROR"


class ConfigurationValidationError(ConfigurationError):
    """The configuration parsed as JSON but violates the schema.

    Args:
        message: Summary of the validation failure.
        issues: One human readable string per offending field, in the form
            ``interfaces.2.port: input should be less than or equal to 65535``.
    """

    error_code = "CONFIG_VALIDATION_ERROR"

    def __init__(
        self,
        message: str,
        *,
        issues: list[str] | None = None,
        remediation: str | None = None,
        details: dict[str, Any] | None = None,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(
            message,
            remediation=remediation
            or "Regenerate the configuration with 'python generate_config.py' "
            "rather than editing the JSON by hand.",
            details=details,
            cause=cause,
        )
        self.issues: list[str] = list(issues or [])
        if self.issues:
            self.details.setdefault("issues", list(self.issues))

    def __str__(self) -> str:
        base = super().__str__()
        if not self.issues:
            return base
        listed = "; ".join(self.issues)
        return f"{base} | Issues: {listed}"


class UnsupportedInterfaceTypeError(ConfigurationError):
    """The configuration names a connectivity type with no registered connector."""

    error_code = "UNSUPPORTED_INTERFACE_TYPE"


# ---------------------------------------------------------------------------
# Encryption
# ---------------------------------------------------------------------------


class EncryptionError(ConnectivityFrameworkError):
    """Base class for key management and cryptographic faults."""

    exit_code = ExitCode.CONFIGURATION_ERROR
    error_code = "ENCRYPTION_ERROR"


class EncryptionKeyError(EncryptionError):
    """The encryption key is missing, malformed or has unsafe permissions."""

    error_code = "ENCRYPTION_KEY_ERROR"


class DecryptionError(EncryptionError):
    """A stored secret could not be decrypted with the available key.

    The overwhelmingly common cause is a configuration file that was copied to
    another host without its matching ``encryption.key``.
    """

    error_code = "DECRYPTION_ERROR"


# ---------------------------------------------------------------------------
# Connectors
# ---------------------------------------------------------------------------


class ConnectorError(ConnectivityFrameworkError):
    """Base class for a failure while validating one interface.

    A connector error fails exactly one interface. The engine records it and
    continues with the remaining interfaces.

    Attributes:
        retryable: Whether re-attempting could plausibly succeed. Only
            transient transport faults set this. It is deliberately ``False``
            by default so that a new error class must opt in rather than
            inherit retry behaviour by accident.
    """

    exit_code = ExitCode.VALIDATION_FAILED
    error_code = "CONNECTOR_ERROR"
    retryable: bool = False


class DriverNotAvailableError(ConnectorError):
    """The third-party driver required by this connector is not installed.

    Args:
        message: Summary naming the connectivity type and the missing driver.
        package: Distribution name of the missing driver.
        install_extra: The ``pip install ".[extra]"`` name that provides it.
    """

    error_code = "DRIVER_NOT_AVAILABLE"

    def __init__(
        self,
        message: str,
        *,
        package: str,
        install_extra: str | None = None,
        details: dict[str, Any] | None = None,
        cause: BaseException | None = None,
    ) -> None:
        install_hint = (
            f'pip install "{package}"'
            if install_extra is None
            else f'pip install "{package}"   (or: pip install ".[{install_extra}]")'
        )
        super().__init__(
            message,
            remediation=f"Install the driver on this host: {install_hint}",
            details={**(details or {}), "package": package},
            cause=cause,
        )
        self.package = package
        self.install_extra = install_extra


class ConnectionFailedError(ConnectorError):
    """The transport level connection to the endpoint could not be established.

    Covers DNS resolution failure, connection refused, no route to host and a
    firewall silently dropping the packets. Distinct from
    :class:`AuthenticationError`, which means the endpoint was reached.
    """

    error_code = "CONNECTION_FAILED"
    retryable = True


class AuthenticationError(ConnectorError):
    """The endpoint was reachable but rejected the supplied credentials.

    Never retried. Repeating a rejected credential is the fastest way to trip
    an account lockout policy, which would turn a reporting problem into an
    outage of the very batch account the interface exists to serve.
    """

    error_code = "AUTHENTICATION_FAILED"
    retryable = False


class ConnectivityTimeoutError(ConnectorError):
    """The endpoint did not respond within the configured timeout.

    Named for the domain rather than as ``TimeoutError`` so that it cannot be
    confused with, or accidentally shadow, the builtin of that name.
    """

    error_code = "TIMEOUT"
    retryable = True


class CertificateValidationError(ConnectorError):
    """TLS negotiation failed: certificate, cipher or protocol mismatch.

    This is the error that most often appears immediately after an OpenSSL
    upgrade or a cipher policy change, so it is called out separately from a
    generic connection failure.
    """

    error_code = "CERTIFICATE_VALIDATION_FAILED"


class DatabaseLinkError(ConnectorError):
    """The session opened but one or more Oracle database links did not.

    Separated from :class:`ValidationProbeError` because the failure is one
    hop further out: the local database is healthy and it is the path from
    *that server* to a remote database that is broken. The distinct error code
    is what makes the pattern visible in the report's failure breakdown, where
    several interfaces failing on links after a change window points at the
    remote database rather than at any of the local ones.
    """

    error_code = "DB_LINK_FAILED"
    retryable = False


class ValidationProbeError(ConnectorError):
    """The connection succeeded but the post-connect probe did not.

    Examples: the validation query returned no row, the expected HTTP status
    was not returned, or the configured remote path does not exist.
    """

    error_code = "VALIDATION_PROBE_FAILED"


# ---------------------------------------------------------------------------
# Reporting and notification
# ---------------------------------------------------------------------------


class ReportingError(ConnectivityFrameworkError):
    """Base class for report generation faults."""

    exit_code = ExitCode.UNEXPECTED_ERROR
    error_code = "REPORTING_ERROR"


class ReportGenerationError(ReportingError):
    """One report format could not be produced.

    Failing to write a report never invalidates the validation results, so the
    engine logs this error and continues with the remaining formats.
    """

    error_code = "REPORT_GENERATION_FAILED"


class NotificationError(ConnectivityFrameworkError):
    """The notification e-mail could not be composed or delivered.

    Notification is a downstream side effect. A delivery failure is logged and
    reported but never changes the connectivity exit code, because the
    connectivity outcome itself is already recorded on disk.
    """

    exit_code = ExitCode.UNEXPECTED_ERROR
    error_code = "NOTIFICATION_FAILED"
