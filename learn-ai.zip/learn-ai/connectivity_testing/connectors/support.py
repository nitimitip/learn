"""Shared helpers used by every connector.

Two responsibilities dominate this module, and both exist to make a failure
report actionable rather than merely accurate.

Driver loading
--------------
:func:`require_driver` imports an optional third-party driver on demand and
converts a missing one into a :class:`~core.exceptions.DriverNotAvailableError`
naming the exact ``pip install`` command. Importing lazily is what allows a
site that validates only SFTP to run without ``pyodbc`` compiled.

Error classification
--------------------
:func:`classify_transport_error` maps a raw socket or TLS exception onto the
framework's exception hierarchy. This is the single most valuable thing the
framework does after a change window: ``ConnectionRefusedError`` and
``socket.timeout`` look similar in a stack trace but mean opposite things. A
refusal proves the packet reached a host that had nothing listening; a timeout
usually means a firewall dropped it silently. The remediation text differs
accordingly, and it is what the on-call engineer reads first.
"""

from __future__ import annotations

import errno
import importlib
import socket
import ssl
from collections.abc import Iterator, Mapping
from datetime import UTC, datetime
from types import ModuleType
from typing import Any

from core.constants import InterfaceType, spec_for
from core.exceptions import (
    CertificateValidationError,
    ConnectionFailedError,
    ConnectivityTimeoutError,
    ConnectorError,
    DriverNotAvailableError,
)

__all__ = [
    "CERTIFICATE_EXPIRY_WARNING_DAYS",
    "backoff_delays",
    "build_ssl_context",
    "certificate_expiry_warning",
    "classify_transport_error",
    "describe_endpoint",
    "describe_tls_socket",
    "require_driver",
]

#: A certificate expiring within this many days raises a warning on an
#: otherwise passing interface. Chosen to give an enterprise change process
#: time to renew: catching it at expiry is too late to be useful.
CERTIFICATE_EXPIRY_WARNING_DAYS: int = 30

#: Distribution name to importable module name, where they differ.
_MODULE_BY_PACKAGE: dict[str, str] = {
    "azure-storage-blob": "azure.storage.blob",
    "azure-identity": "azure.identity",
}

#: ``errno`` values that mean the packet never reached a listening service.
_UNREACHABLE_ERRNOS = frozenset(
    value
    for value in (
        getattr(errno, name, None)
        for name in ("EHOSTUNREACH", "ENETUNREACH", "ENETDOWN", "EHOSTDOWN")
    )
    if value is not None
)


def describe_endpoint(host: str, port: int | None) -> str:
    """Return ``host:port`` for an error message, tolerating a missing port."""
    return f"{host}:{port}" if port else host


def require_driver(
    package: str,
    interface_type: InterfaceType,
    *,
    module_name: str | None = None,
) -> ModuleType:
    """Import an optional driver, or raise an actionable error.

    Args:
        package: Distribution name, as it appears on PyPI.
        interface_type: The connectivity type needing the driver, used to name
            the ``pip install ".[extra]"`` alternative in the error.
        module_name: Import name, when it differs from the distribution name.

    Returns:
        The imported module.

    Raises:
        DriverNotAvailableError: when the driver is not installed, or is
            installed but cannot be initialised. The second case is common on
            AIX and in locked-down estates, where a compiled driver imports
            but fails to load its shared library.
    """
    target = module_name or _MODULE_BY_PACKAGE.get(package, package)
    install_extra = spec_for(interface_type).install_extra

    try:
        return importlib.import_module(target)
    except ImportError as error:
        raise DriverNotAvailableError(
            f"{interface_type.value} requires the '{package}' driver, which is not "
            f"installed on this host.",
            package=package,
            install_extra=install_extra,
            details={"interface_type": interface_type.value, "module": target},
            cause=error,
        ) from error
    except Exception as error:  # noqa: BLE001 - driver init failures vary widely
        # A compiled driver that imports but cannot load its shared library
        # raises anything from OSError to a vendor-specific exception.
        raise DriverNotAvailableError(
            f"{interface_type.value} driver '{package}' is installed but failed to "
            f"initialise: {type(error).__name__}.",
            package=package,
            install_extra=install_extra,
            details={"interface_type": interface_type.value, "module": target},
            cause=error,
        ) from error


def backoff_delays(
    retry_count: int, *, base_seconds: float = 2.0, maximum_seconds: float = 30.0
) -> Iterator[float]:
    """Yield exponential backoff delays for ``retry_count`` retries.

    Capped so that a generous retry count on a slow endpoint cannot push a run
    past its scheduler window.

    Examples:
        >>> list(backoff_delays(3))
        [2.0, 4.0, 8.0]
    """
    for attempt in range(retry_count):
        yield min(base_seconds * (2**attempt), maximum_seconds)


def build_ssl_context(
    *, verify: bool, ca_bundle_path: str | None = None
) -> ssl.SSLContext:
    """Return an SSL context for a client connection.

    Args:
        verify: Verify the certificate chain and host name. When ``False`` the
            context still negotiates TLS but accepts any certificate; callers
            must warn, because the run then cannot detect the expired or
            mis-issued certificate it was probably scheduled to catch.
        ca_bundle_path: PEM bundle for a private certificate authority.

    Returns:
        A configured :class:`ssl.SSLContext`.

    Raises:
        CertificateValidationError: if the CA bundle cannot be loaded.
    """
    context = ssl.create_default_context()

    if ca_bundle_path:
        try:
            context.load_verify_locations(cafile=ca_bundle_path)
        except (OSError, ssl.SSLError) as error:
            raise CertificateValidationError(
                f"CA bundle could not be loaded: {ca_bundle_path}",
                remediation=(
                    "Check that the file exists, is readable by the account running the job, "
                    "and contains PEM encoded certificates."
                ),
                details={"ca_bundle_path": ca_bundle_path},
                cause=error,
            ) from error

    if not verify:
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE

    return context


def describe_tls_socket(sock: Any) -> dict[str, Any]:
    """Return the negotiated TLS parameters and certificate facts.

    This is the evidence that makes a post-OpenSSL-upgrade report useful: it
    records the protocol version and cipher actually negotiated, so a
    successful run still proves *which* algorithms the server offered.

    Never raises: a socket that cannot report its own parameters yields an
    empty mapping rather than failing an otherwise healthy interface.
    """
    details: dict[str, Any] = {}
    try:
        version = sock.version()
        if version:
            details["tls_version"] = version

        cipher = sock.cipher()
        if cipher:
            details["tls_cipher"] = cipher[0]
            details["tls_protocol"] = cipher[1]
            details["tls_secret_bits"] = cipher[2]

        certificate = sock.getpeercert()
        if certificate:
            details.update(_describe_certificate(certificate))
    except (AttributeError, ValueError, OSError):
        return details
    return details


def _describe_certificate(certificate: Mapping[str, Any]) -> dict[str, Any]:
    """Extract the reportable fields from a peer certificate."""
    details: dict[str, Any] = {}

    def _flatten(field: Any) -> str:
        # getpeercert returns subject/issuer as a tuple of tuples of pairs.
        try:
            return ", ".join(
                f"{name}={value}" for group in field for name, value in group
            )
        except (TypeError, ValueError):
            return str(field)

    if certificate.get("subject"):
        details["certificate_subject"] = _flatten(certificate["subject"])
    if certificate.get("issuer"):
        details["certificate_issuer"] = _flatten(certificate["issuer"])

    not_after = certificate.get("notAfter")
    if not_after:
        details["certificate_expires"] = not_after
        expiry = _parse_certificate_date(not_after)
        if expiry is not None:
            remaining = (expiry - datetime.now(UTC)).days
            details["certificate_days_remaining"] = remaining

    return details


def _parse_certificate_date(value: str) -> datetime | None:
    """Parse an OpenSSL ``notAfter`` timestamp, or return ``None``."""
    for fmt in ("%b %d %H:%M:%S %Y %Z", "%b %d %H:%M:%S %Y"):
        try:
            return datetime.strptime(value, fmt).replace(tzinfo=UTC)
        except ValueError:
            continue
    return None


def certificate_expiry_warning(
    details: Mapping[str, Any], *, threshold_days: int = CERTIFICATE_EXPIRY_WARNING_DAYS
) -> str | None:
    """Return a warning when the peer certificate is close to expiry.

    Args:
        details: The mapping returned by :func:`describe_tls_socket`.
        threshold_days: Warn when fewer than this many days remain.

    Returns:
        A warning message, or ``None`` when the certificate is comfortably
        valid or its expiry could not be determined.
    """
    remaining = details.get("certificate_days_remaining")
    if not isinstance(remaining, int):
        return None

    if remaining < 0:
        return (
            f"The server certificate EXPIRED {abs(remaining)} day(s) ago "
            f"(notAfter {details.get('certificate_expires')}). It is being accepted only "
            "because certificate verification is disabled for this interface."
        )
    if remaining <= threshold_days:
        return (
            f"The server certificate expires in {remaining} day(s) "
            f"(notAfter {details.get('certificate_expires')}). Renew it before it fails."
        )
    return None


def classify_transport_error(
    error: BaseException,
    *,
    host: str,
    port: int | None = None,
    timeout_seconds: int | float | None = None,
    operation: str = "connect",
) -> ConnectorError:
    """Convert a raw transport exception into a framework exception.

    The returned exception carries remediation text specific to the failure
    mode, which is what distinguishes a useful report from a stack trace.

    Args:
        error: The originating exception from the driver or the socket layer.
        host: Endpoint host, for the message.
        port: Endpoint port, when applicable.
        timeout_seconds: The configured timeout, quoted in a timeout message.
        operation: What was being attempted, for example ``connect`` or
            ``TLS handshake``.

    Returns:
        A :class:`~core.exceptions.ConnectorError` subclass. Never raises.
    """
    try:
        return _classify(
            error,
            host=host,
            port=port,
            timeout_seconds=timeout_seconds,
            operation=operation,
        )
    except Exception:  # noqa: BLE001 - classification must never itself fail
        # Reached only if a driver exception behaves unlike anything expected.
        # Degrading to a generic classification still preserves the original
        # error as the cause, which is what the report needs.
        return ConnectionFailedError(
            f"{operation.capitalize()} to {describe_endpoint(host, port)} failed: "
            f"{type(error).__name__}",
            remediation=(
                "The driver raised an error the framework could not classify. The original "
                "exception and stack trace are recorded in the JSON report and debug log."
            ),
            details={"host": host, "port": port, "operation": operation},
            cause=error,
        )


def _classify(
    error: BaseException,
    *,
    host: str,
    port: int | None,
    timeout_seconds: int | float | None,
    operation: str,
) -> ConnectorError:
    """Perform the classification. See :func:`classify_transport_error`."""
    endpoint = describe_endpoint(host, port)
    details: dict[str, Any] = {"host": host, "port": port, "operation": operation}

    # --- TLS -------------------------------------------------------------
    # Attributes are read with getattr throughout: this function runs on the
    # error path, and a classifier that raises while classifying would destroy
    # the very diagnostic it exists to produce. Not every SSLError carries
    # 'reason' or 'verify_message', notably when a driver re-raises its own.
    if isinstance(error, ssl.SSLCertVerificationError):
        verify_message = getattr(error, "verify_message", None) or str(error)
        return CertificateValidationError(
            f"TLS certificate verification failed for {endpoint}: {verify_message}",
            remediation=(
                "The server certificate is expired, not yet valid, issued for a different "
                "host name, or signed by an authority this host does not trust. Compare the "
                "certificate presented by the server with the trust store on this host, and "
                "check whether the certificate was rotated during the change window."
            ),
            details={**details, "verify_code": getattr(error, "verify_code", None)},
            cause=error,
        )

    if isinstance(error, ssl.SSLError):
        reason = getattr(error, "reason", None) or str(error)
        return CertificateValidationError(
            f"TLS handshake failed for {endpoint}: {reason}",
            remediation=(
                "The client and server could not agree on a TLS version or cipher suite. "
                "This is the expected symptom after an OpenSSL upgrade or a cipher policy "
                "change. Compare the protocols and ciphers the server now offers with those "
                "this host supports."
            ),
            details={**details, "reason": getattr(error, "reason", None)},
            cause=error,
        )

    # --- Timeouts --------------------------------------------------------
    # socket.timeout is an alias of TimeoutError from Python 3.10 onward.
    if isinstance(error, TimeoutError):
        return ConnectivityTimeoutError(
            f"Timed out after {timeout_seconds} seconds during {operation} to {endpoint}."
            if timeout_seconds
            else f"Timed out during {operation} to {endpoint}.",
            remediation=(
                "No response arrived within the timeout. A silent drop usually means a "
                "firewall rule is discarding the packets rather than rejecting them, which "
                "is the classic symptom of a firewall change. Confirm the rule permits this "
                "source address, then raise the timeout only if the path is genuinely slow."
            ),
            details={**details, "timeout_seconds": timeout_seconds},
            cause=error,
        )

    # --- Name resolution -------------------------------------------------
    if isinstance(error, socket.gaierror):
        return ConnectionFailedError(
            f"Host name '{host}' could not be resolved.",
            remediation=(
                "DNS did not return an address. Check the resolver configuration and any "
                "hosts file entry on this host. After a migration the name often resolves "
                "everywhere except the host running the batch job."
            ),
            details={**details, "errno": getattr(error, "errno", None)},
            cause=error,
        )

    # --- Connection level ------------------------------------------------
    if isinstance(error, ConnectionRefusedError):
        return ConnectionFailedError(
            f"Connection to {endpoint} was refused.",
            remediation=(
                "The host is reachable but nothing is listening on that port, and the "
                "refusal was immediate. Confirm the service is running and bound to the "
                "expected port. After a patch, a service that failed to restart presents "
                "exactly this way."
            ),
            details=details,
            cause=error,
        )

    if isinstance(error, ConnectionResetError):
        return ConnectionFailedError(
            f"Connection to {endpoint} was reset by the peer.",
            remediation=(
                "The peer accepted the connection and then closed it abruptly. Common "
                "causes are a TLS version mismatch, a load balancer health check closing "
                "idle connections, or an access control list rejecting the source address "
                "after the handshake."
            ),
            details=details,
            cause=error,
        )

    if isinstance(error, ConnectionAbortedError):
        return ConnectionFailedError(
            f"Connection to {endpoint} was aborted.",
            remediation=(
                "The connection was terminated by the local network stack or an "
                "intermediate device. Check for a proxy or an inspection appliance in the "
                "path."
            ),
            details=details,
            cause=error,
        )

    if isinstance(error, OSError):
        error_number = getattr(error, "errno", None)
        if error_number in _UNREACHABLE_ERRNOS:
            return ConnectionFailedError(
                f"No network route to {endpoint}.",
                remediation=(
                    "The network stack has no route to the destination. Check routing, the "
                    "default gateway and any VPN or direct-connect tunnel that may not have "
                    "come back up after the change."
                ),
                details={**details, "errno": error_number},
                cause=error,
            )
        return ConnectionFailedError(
            f"Network error during {operation} to {endpoint}: "
            f"{error.strerror or type(error).__name__}",
            remediation=(
                "The operating system reported a network error. Check host connectivity "
                "and the details recorded with this result."
            ),
            details={**details, "errno": error_number},
            cause=error,
        )

    # --- Anything else ---------------------------------------------------
    return ConnectionFailedError(
        f"{operation.capitalize()} to {endpoint} failed: {type(error).__name__}: {error}",
        remediation=(
            "The driver reported an error the framework does not classify specifically. "
            "The full exception and stack trace are recorded in the JSON report and the "
            "debug log."
        ),
        details=details,
        cause=error,
    )
