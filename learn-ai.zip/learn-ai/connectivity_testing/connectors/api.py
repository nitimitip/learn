"""API connectors: REST and SOAP web services.

Both are built on :mod:`requests`, and neither installs an HTTP adapter with
urllib3 retry logic. Plain ``requests`` does not retry, which is what this
framework wants: retry policy belongs to the engine, and a hidden retry inside
the transport would multiply the timeout and hide the intermittency an
operator needs to see after a change.

Proving more than a status code
-------------------------------
An HTTP 200 proves a load balancer answered. It does not prove the application
behind it is healthy: a maintenance page, a captive portal and a proxy error
page are all returned with a 200 by something in the path. The REST connector
therefore supports asserting on the response body as well as the status, and
records the redirect chain so that a silent redirect to a login page is
visible in the report rather than passing as success.

For SOAP, retrieving and *parsing* the WSDL already exercises DNS, TCP, TLS,
authentication and the service's own document generation. The single most
common failure is a WSDL URL that returns an HTML error or login page, which
XML parsing rejects with an opaque error; that case is detected and named.
"""

from __future__ import annotations

import socket
import ssl
from typing import Any, ClassVar
from urllib.parse import urlparse

from connectors.base import BaseConnector
from connectors.factory import register
from connectors.support import (
    certificate_expiry_warning,
    describe_tls_socket,
    require_driver,
)
from core.constants import InterfaceType
from core.exceptions import (
    AuthenticationError,
    CertificateValidationError,
    ConnectionFailedError,
    ConnectivityTimeoutError,
    ConnectorError,
    ValidationProbeError,
)
from models.interfaces import RestAuthMethod, RestInterfaceConfig, SoapInterfaceConfig

__all__ = ["RestConnector", "SoapConnector"]

#: Characters of a response body retained on the result. Enough to identify a
#: maintenance page or an error payload, bounded so a large response cannot
#: bloat the report.
_MAX_BODY_SAMPLE = 512

#: Response headers worth recording. An exhaustive dump would be noise, and
#: some headers carry session material.
_REPORTABLE_HEADERS = (
    "server",
    "content-type",
    "content-length",
    "x-request-id",
    "x-correlation-id",
    "via",
    "age",
)

#: HTTP status codes worth retrying: the endpoint is reachable and is asking
#: the caller to come back.
_TRANSIENT_STATUS_CODES = frozenset({429, 502, 503, 504})

#: Markers that identify a response as HTML rather than the expected payload.
_HTML_MARKERS = ("<!doctype html", "<html", "<head>", "<title>")


def _looks_like_html(text: str) -> bool:
    """Return ``True`` when a payload appears to be an HTML page."""
    sample = text[:512].lstrip().lower()
    return any(marker in sample for marker in _HTML_MARKERS)


class _HttpConnectorMixin:
    """Shared HTTP transport concerns for the REST and SOAP connectors."""

    def _tls_details(self, url: str) -> dict[str, Any]:
        """Return the peer certificate facts for an HTTPS endpoint.

        Implemented as a short dedicated TLS handshake rather than by reaching
        into the response object, because the socket is not reliably reachable
        through ``requests`` across urllib3 versions and a report must not
        depend on a private attribute.

        Verification is deliberately *not* enforced here: the real request has
        already applied the interface's verification policy, and this handshake
        exists only to read the certificate's dates. That means an expiring
        certificate is still reported on an interface that has verification
        switched off, which is exactly where the warning is most needed.

        Never raises: certificate metadata is report decoration and must not
        fail an otherwise healthy interface.
        """
        parsed = urlparse(url)
        if parsed.scheme != "https" or not parsed.hostname:
            return {}

        port = parsed.port or 443
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE

        try:
            with socket.create_connection(
                (parsed.hostname, port), timeout=self.timeout  # type: ignore[attr-defined]
            ) as raw_socket, context.wrap_socket(
                raw_socket, server_hostname=parsed.hostname
            ) as tls_socket:
                return describe_tls_socket(tls_socket)
        except (OSError, ssl.SSLError, ValueError):
            return {}

    def _classify_requests_error(
        self,
        error: BaseException,
        requests_exceptions: Any,
        *,
        url: str,
        operation: str = "HTTP request",
    ) -> ConnectorError:
        """Map a :mod:`requests` exception onto the framework hierarchy."""
        parsed = urlparse(url)
        host = parsed.hostname or url
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        details: dict[str, Any] = {"url": url, "host": host, "port": port}
        message = str(error).strip()[:400]
        timeout = getattr(self, "timeout", None)

        if isinstance(error, requests_exceptions.SSLError):
            return CertificateValidationError(
                f"TLS negotiation with {host} failed: {message}",
                remediation=(
                    "The certificate is expired, issued for a different host name, or "
                    "signed by an authority this host does not trust. A TLS inspecting "
                    "proxy re-signs traffic and must have its authority installed in the "
                    "host trust store. This is the expected symptom after a certificate "
                    "renewal or an OpenSSL upgrade."
                ),
                details=details,
                cause=error,
            )

        if isinstance(error, requests_exceptions.ProxyError):
            return ConnectionFailedError(
                f"The proxy could not be reached or refused the request to {host}: "
                f"{message}",
                remediation=(
                    "Check the proxy URL and credentials, and whether this destination is "
                    "permitted by the proxy's policy. Under a scheduler the job may not "
                    "inherit the proxy environment variables set in an interactive shell."
                ),
                details=details,
                cause=error,
            )

        if isinstance(
            error, (requests_exceptions.ConnectTimeout, requests_exceptions.ReadTimeout)
        ):
            phase = (
                "connecting to"
                if isinstance(error, requests_exceptions.ConnectTimeout)
                else "reading the response from"
            )
            return ConnectivityTimeoutError(
                f"Timed out after {timeout} seconds while {phase} {host}.",
                remediation=(
                    "A connect timeout usually means a firewall is dropping the packets "
                    "silently. A read timeout means the endpoint accepted the request and "
                    "did not answer in time, which points at the application rather than "
                    "the network."
                ),
                details=details,
                cause=error,
            )

        if isinstance(error, requests_exceptions.TooManyRedirects):
            return ValidationProbeError(
                f"The request to {host} exceeded the redirect limit: {message}",
                remediation=(
                    "The endpoint is redirecting in a loop, which commonly indicates an "
                    "authentication portal the batch account cannot satisfy."
                ),
                details=details,
                cause=error,
            )

        if isinstance(
            error, (requests_exceptions.MissingSchema, requests_exceptions.InvalidURL)
        ):
            return ConnectorError(
                f"The configured URL is not valid: {message}",
                remediation="Correct the URL with 'python generate_config.py'.",
                details=details,
                cause=error,
            )

        if isinstance(error, requests_exceptions.ConnectionError):
            lowered = message.lower()
            if "name or service not known" in lowered or "nodename nor servname" in lowered or (
                "getaddrinfo failed" in lowered
            ):
                return ConnectionFailedError(
                    f"Host name '{host}' could not be resolved.",
                    remediation=(
                        "DNS did not return an address. Check the resolver configuration "
                        "and any hosts file entry on this host."
                    ),
                    details=details,
                    cause=error,
                )
            return ConnectionFailedError(
                f"Could not connect to {host}:{port}: {message}",
                remediation=(
                    "Check that the service is listening on that port and that outbound "
                    "access is permitted. A connection refused immediately usually means "
                    "the service did not restart after the change."
                ),
                details=details,
                cause=error,
            )

        return ConnectionFailedError(
            f"{operation} to {host} failed: {type(error).__name__}: {message}",
            remediation=(
                "The HTTP client reported an error the framework does not classify "
                "specifically. The full exception is recorded in the JSON report."
            ),
            details=details,
            cause=error,
        )


# ---------------------------------------------------------------------------
# REST
# ---------------------------------------------------------------------------


@register
class RestConnector(_HttpConnectorMixin, BaseConnector[RestInterfaceConfig]):
    """Validates a REST API endpoint."""

    interface_type: ClassVar[InterfaceType] = InterfaceType.REST
    driver_packages: ClassVar[tuple[str, ...]] = ("requests",)

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._requests: Any = None
        self._requests_exceptions: Any = None

    def _open(self) -> Any:
        """Build a configured :class:`requests.Session`.

        Returns:
            A session carrying the interface's authentication, headers, proxy
            and verification settings. No request is sent yet, so the reported
            latency for REST is measured across the request itself in the
            probe rather than here.
        """
        requests = require_driver("requests", self.interface_type)
        self._requests = requests
        self._requests_exceptions = require_driver(
            "requests", self.interface_type, module_name="requests.exceptions"
        )
        interface = self.interface

        session = requests.Session()
        # No HTTPAdapter with urllib3 Retry is installed: the engine owns the
        # retry policy, and a transport-level retry would hide intermittency.
        session.headers.update(interface.headers)
        session.headers.setdefault("User-Agent", "enterprise-connectivity-validator/1.0")

        if interface.auth_method_type is RestAuthMethod.BASIC:
            session.auth = (interface.username or "", self.secret("password") or "")
        elif interface.auth_method_type is RestAuthMethod.BEARER:
            session.headers["Authorization"] = f"Bearer {self.secret('bearer_token') or ''}"
        elif interface.auth_method_type is RestAuthMethod.API_KEY:
            session.headers[interface.api_key_header] = self.secret("api_key_value") or ""

        if interface.proxy_url:
            session.proxies = {"http": interface.proxy_url, "https": interface.proxy_url}

        if interface.ca_bundle_path:
            session.verify = interface.ca_bundle_path
        else:
            session.verify = interface.verify_ssl
            if not interface.verify_ssl:
                self.add_warning(
                    "TLS certificate verification is disabled for this interface, so an "
                    "expired or mis-issued certificate cannot be detected."
                )

        return session

    def _probe(self, handle: Any) -> dict[str, Any]:
        """Send the configured request and assert on the response."""
        interface = self.interface
        exceptions = self._requests_exceptions

        try:
            response = handle.request(
                method=interface.method,
                url=interface.base_url,
                data=interface.request_body,
                timeout=(self.timeout, self.timeout),
                allow_redirects=interface.follow_redirects,
            )
        except Exception as error:  # noqa: BLE001 - requests raises varied types
            raise self._classify_requests_error(
                error, exceptions, url=interface.base_url
            ) from error

        details = self._describe_response(response)
        details.update(self._tls_details(response.url))

        warning = certificate_expiry_warning(details)
        if warning:
            self.add_warning(warning)

        self._assert_status(response, details)
        self._assert_body(response, details)
        return details

    def _describe_response(self, response: Any) -> dict[str, Any]:
        """Collect the reportable facts about a response."""
        interface = self.interface
        details: dict[str, Any] = {
            "request_method": interface.method,
            "request_url": interface.base_url,
            "status_code": response.status_code,
            "reason": response.reason,
            "response_time_ms": round(response.elapsed.total_seconds() * 1000, 2),
            "response_bytes": len(response.content or b""),
            "auth_method": interface.auth_method_type.value,
        }

        headers = {
            name: response.headers[name]
            for name in _REPORTABLE_HEADERS
            if name in response.headers
        }
        if headers:
            details["response_headers"] = headers

        if response.history:
            # A silent redirect to a portal is a common way for a check to
            # "pass" while proving nothing, so the chain is always recorded.
            details["redirect_chain"] = [
                f"{hop.status_code} {hop.url}" for hop in response.history
            ]
            details["final_url"] = response.url
            if response.url != interface.base_url:
                self.add_warning(
                    f"The request was redirected to {response.url}. Confirm this is the "
                    "intended endpoint and not an authentication portal."
                )
        return details

    def _assert_status(self, response: Any, details: dict[str, Any]) -> None:
        """Fail the interface when the status code is not an expected one."""
        interface = self.interface
        status = response.status_code
        if status in interface.expected_status_codes:
            return

        expected = ", ".join(str(code) for code in interface.expected_status_codes)
        body_sample = self._body_sample(response)
        context = {**details, "response_body_sample": body_sample}

        if status in (401, 407):
            raise AuthenticationError(
                f"The endpoint returned {status} {response.reason}; expected {expected}.",
                remediation=(
                    "The credential was rejected. Check the token or key, and whether it "
                    "expired or was rotated during the change window. A 407 means the "
                    "proxy, not the endpoint, wants credentials."
                ),
                details=context,
            )

        if status == 403:
            raise AuthenticationError(
                f"The endpoint returned 403 Forbidden; expected {expected}.",
                remediation=(
                    "The credential is recognised but not authorised for this resource. "
                    "Check the API permissions, and any source-address allow-list that may "
                    "not include this host."
                ),
                details=context,
            )

        error = ValidationProbeError(
            f"The endpoint returned {status} {response.reason}; expected {expected}.",
            remediation=(
                "The endpoint answered but not as configured. A 404 usually means the path "
                "moved; a 5xx means the application behind the load balancer is unhealthy "
                "even though the network path is fine."
            ),
            details=context,
        )
        if status in _TRANSIENT_STATUS_CODES:
            # The endpoint is reachable and asking us to come back, so a retry
            # is meaningful here where it is not for a 404.
            error.retryable = True
        raise error

    def _assert_body(self, response: Any, details: dict[str, Any]) -> None:
        """Fail the interface when the body assertion is not satisfied."""
        interface = self.interface
        if not interface.expected_body_contains:
            return

        try:
            body = response.text or ""
        except (UnicodeDecodeError, ValueError):
            body = ""

        if interface.expected_body_contains in body:
            details["body_assertion"] = "satisfied"
            return

        sample = self._body_sample(response)
        hint = (
            "The response is an HTML page rather than the expected payload, which usually "
            "means a proxy error page, a maintenance page or a login portal was returned "
            "with a success status."
            if _looks_like_html(body)
            else "Confirm the expected text and that the endpoint returns the payload the "
            "batch job depends on."
        )
        raise ValidationProbeError(
            f"The response status was acceptable but the body did not contain the "
            f"expected text: {interface.expected_body_contains!r}",
            remediation=hint,
            details={**details, "response_body_sample": sample},
        )

    @staticmethod
    def _body_sample(response: Any) -> str:
        """Return a bounded, printable sample of the response body."""
        try:
            return (response.text or "")[:_MAX_BODY_SAMPLE]
        except (UnicodeDecodeError, ValueError):
            return "<binary response>"


# ---------------------------------------------------------------------------
# SOAP
# ---------------------------------------------------------------------------


@register
class SoapConnector(_HttpConnectorMixin, BaseConnector[SoapInterfaceConfig]):
    """Validates a SOAP web service.

    With no ``operation`` configured the probe retrieves and parses the WSDL,
    which already exercises DNS, TCP, TLS, authentication and the service's own
    document generation. Naming an operation additionally invokes it, which
    exercises the service implementation behind the contract.
    """

    interface_type: ClassVar[InterfaceType] = InterfaceType.SOAP
    driver_packages: ClassVar[tuple[str, ...]] = ("zeep",)

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._zeep: Any = None
        self._zeep_exceptions: Any = None
        self._requests_exceptions: Any = None
        self._session: Any = None

    def _open(self) -> Any:
        """Retrieve and parse the WSDL, returning a zeep client.

        Returns:
            A ``zeep.Client``. Constructing it fetches and parses the WSDL, so
            the reported latency covers the document retrieval, which is the
            meaningful connect cost for a SOAP service.
        """
        zeep = require_driver("zeep", self.interface_type)
        transport_module = require_driver(
            "zeep", self.interface_type, module_name="zeep.transports"
        )
        self._zeep = zeep
        self._zeep_exceptions = require_driver(
            "zeep", self.interface_type, module_name="zeep.exceptions"
        )
        requests = require_driver("requests", self.interface_type)
        self._requests_exceptions = require_driver(
            "requests", self.interface_type, module_name="requests.exceptions"
        )
        interface = self.interface

        session = requests.Session()
        if interface.username:
            session.auth = (interface.username, self.secret("password") or "")
        if interface.soap_action:
            session.headers["SOAPAction"] = interface.soap_action

        if interface.ca_bundle_path:
            session.verify = interface.ca_bundle_path
        else:
            session.verify = interface.verify_ssl
            if not interface.verify_ssl:
                self.add_warning(
                    "TLS certificate verification is disabled for this interface, so an "
                    "expired or mis-issued certificate cannot be detected."
                )
        self._session = session

        transport = transport_module.Transport(
            session=session, timeout=self.timeout, operation_timeout=self.timeout
        )

        try:
            return zeep.Client(wsdl=interface.wsdl_url, transport=transport)
        except Exception as error:  # noqa: BLE001 - zeep raises varied types
            raise self._classify_wsdl_error(error) from error

    def _close(self, handle: Any) -> None:  # noqa: ARG002
        """Close the underlying HTTP session.

        ``zeep.Client`` holds no closable resource of its own; the connection
        pool belongs to the requests session, so that is what is released.
        """
        if self._session is not None:
            try:
                self._session.close()
            except Exception as error:  # noqa: BLE001 - teardown only
                self.logger.debug("Ignoring session close error: %s", error)
            self._session = None

    def _probe(self, handle: Any) -> dict[str, Any]:
        """Inspect the parsed contract and optionally invoke an operation."""
        interface = self.interface
        details: dict[str, Any] = {
            "wsdl_url": interface.wsdl_url,
            "endpoint": interface.endpoint,
        }
        details.update(self._describe_contract(handle))
        self._assert_usable_contract(details)
        details.update(self._tls_details(interface.endpoint))

        warning = certificate_expiry_warning(details)
        if warning:
            self.add_warning(warning)

        if not interface.operation:
            details["probe"] = "WSDL retrieval and parse"
            return details

        service = self._service_proxy(handle)
        operation = getattr(service, interface.operation, None)
        if operation is None:
            available = details.get("operations_sample", [])
            raise ValidationProbeError(
                f"The WSDL does not define an operation named "
                f"'{interface.operation}'.",
                remediation=(
                    "Correct the operation name. Operations defined by this service "
                    f"include: {', '.join(available) if available else 'none discovered'}."
                ),
                details=details,
            )

        try:
            response = operation(**interface.operation_arguments)
        except self._zeep_exceptions.Fault as error:
            raise ValidationProbeError(
                f"The service returned a SOAP fault for operation "
                f"'{interface.operation}': {error.message or error}",
                remediation=(
                    "The transport and contract are fine; the service rejected the call. "
                    "A fault often means the arguments are wrong or the account is not "
                    "authorised for the operation."
                ),
                details={
                    **details,
                    "soap_fault_code": str(getattr(error, "code", "")),
                    "soap_fault_message": str(getattr(error, "message", ""))[:400],
                },
                cause=error,
            ) from error
        except Exception as error:  # noqa: BLE001 - zeep raises varied types
            raise self._classify_requests_error(
                error,
                self._requests_exceptions,
                url=interface.endpoint,
                operation="SOAP operation",
            ) from error

        details["probe"] = "WSDL parse and operation invocation"
        details["operation_invoked"] = interface.operation
        details["operation_response_sample"] = str(response)[:_MAX_BODY_SAMPLE]
        return details

    def _assert_usable_contract(self, details: dict[str, Any]) -> None:
        """Fail when the retrieved document is not a usable WSDL.

        XML well-formedness is a weaker test than it looks. An HTML
        maintenance page or login portal is frequently well-formed enough for
        the parser to accept, leaving a client with no services at all. Without
        this check such a response would validate as a healthy SOAP endpoint,
        which is precisely the false pass this framework must not produce.

        Raises:
            ValidationProbeError: when the document declares no service and no
                binding.
        """
        service_count = details.get("service_count")
        binding_count = details.get("binding_count")

        if service_count is None:
            # The contract could not be summarised at all, which means the
            # document did not present as a WSDL.
            raise ValidationProbeError(
                f"The document at {self.interface.wsdl_url} was retrieved but is not a "
                "readable WSDL.",
                remediation=(
                    "Fetch the URL manually from this host. A proxy error page, a "
                    "maintenance page or a login portal is usually what comes back, and "
                    "all of them are returned with a success status."
                ),
                details=details,
            )

        if not service_count and not binding_count:
            raise ValidationProbeError(
                f"The document at {self.interface.wsdl_url} parsed as XML but declares no "
                "SOAP service or binding, so it is not a usable contract.",
                remediation=(
                    "The URL returned something other than a WSDL. An HTML maintenance "
                    "page or login portal often parses as XML without error, which is why "
                    "this fails here rather than at the parse step. Fetch the URL manually "
                    "from this host to see what is actually being served."
                ),
                details=details,
            )

        if not service_count:
            self.add_warning(
                "The WSDL declares bindings but no service address. This is an "
                "interface-only contract, so no endpoint was contacted; configure "
                "'endpoint_url' to validate an actual service."
            )

    def _service_proxy(self, client: Any) -> Any:
        """Return the service proxy, honouring an endpoint override."""
        interface = self.interface
        if not interface.endpoint_url:
            return client.service

        try:
            binding = next(
                iter(client.wsdl.bindings)
            )  # Qualified name of the first binding.
            return client.create_service(binding, interface.endpoint_url)
        except Exception as error:  # noqa: BLE001 - zeep raises varied types
            raise ValidationProbeError(
                f"The endpoint override '{interface.endpoint_url}' could not be applied "
                f"to the service: {error}",
                remediation=(
                    "Remove 'endpoint_url' to use the address published in the WSDL, or "
                    "confirm the override is a valid endpoint for this binding."
                ),
                details={"endpoint_url": interface.endpoint_url},
                cause=error,
            ) from error

    def _describe_contract(self, client: Any) -> dict[str, Any]:
        """Summarise the parsed WSDL for the report.

        Never raises: an unusual but valid contract must not fail an interface
        whose transport is healthy.
        """
        details: dict[str, Any] = {}
        try:
            services = list(client.wsdl.services)
            details["service_count"] = len(services)
            details["services"] = [str(name) for name in services][:5]
            details["binding_count"] = len(list(client.wsdl.bindings))

            operations: list[str] = []
            for service in client.wsdl.services.values():
                for port in service.ports.values():
                    operations.extend(str(name) for name in port.binding._operations)
            details["operation_count"] = len(operations)
            details["operations_sample"] = sorted(set(operations))[:10]
        except Exception as error:  # noqa: BLE001 - informational only
            self.logger.debug("Could not summarise the WSDL: %s", error)
        return details

    def _classify_wsdl_error(self, error: BaseException) -> ConnectorError:
        """Classify a failure to retrieve or parse the WSDL."""
        interface = self.interface
        message = str(error).strip()[:400]
        lowered = message.lower()

        # An XML parse failure almost always means the URL returned something
        # that is not a WSDL. Saying so is far more useful than relaying lxml's
        # description of where the document stopped being valid.
        is_parse_error = (
            "xmlsyntaxerror" in type(error).__name__.lower()
            or "syntaxerror" in type(error).__name__.lower()
            or "start tag" in lowered
            or "document is empty" in lowered
            or "not well-formed" in lowered
        )
        if is_parse_error:
            return ValidationProbeError(
                f"The WSDL at {interface.wsdl_url} is not valid XML: {message}",
                remediation=(
                    "The URL returned something other than a WSDL. A proxy error page, a "
                    "maintenance page or an authentication portal are the usual causes, "
                    "and all of them are returned with a success status. Fetch the URL "
                    "manually from this host to see what actually comes back."
                ),
                details={"wsdl_url": interface.wsdl_url},
                cause=error,
            )

        if self._zeep_exceptions is not None and isinstance(
            error, getattr(self._zeep_exceptions, "XMLSyntaxError", ())
        ):
            return ValidationProbeError(
                f"The WSDL at {interface.wsdl_url} could not be parsed: {message}",
                remediation=(
                    "The document retrieved is not a well-formed WSDL. Fetch the URL "
                    "manually from this host to see what is being returned."
                ),
                details={"wsdl_url": interface.wsdl_url},
                cause=error,
            )

        if "404" in message or "not found" in lowered:
            return ValidationProbeError(
                f"The WSDL was not found at {interface.wsdl_url}: {message}",
                remediation=(
                    "Check the WSDL URL. Many stacks publish it at a '?wsdl' suffix that "
                    "changes between releases."
                ),
                details={"wsdl_url": interface.wsdl_url},
                cause=error,
            )

        if "401" in message or "unauthor" in lowered or "403" in message:
            return AuthenticationError(
                f"Access to the WSDL at {interface.wsdl_url} was refused: {message}",
                remediation=(
                    "The service requires credentials to publish its contract. Configure "
                    "the username and password for this interface."
                ),
                details={"wsdl_url": interface.wsdl_url},
                cause=error,
            )

        return self._classify_requests_error(
            error,
            self._requests_exceptions,
            url=interface.wsdl_url,
            operation="WSDL retrieval",
        )
