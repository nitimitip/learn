"""File transfer connectors: SFTP, SCP, SSH, FTP and FTPS.

The SSH family (SFTP, SCP, SSH) is built directly on
:class:`paramiko.Transport` rather than the higher level ``SSHClient``. That
is a deliberate trade: ``SSHClient`` hides the negotiation, and the negotiated
key exchange, cipher, MAC and host key algorithm are precisely the evidence
this framework exists to capture after an SSH hardening change. Working at the
transport level also allows the configured algorithms to be pinned, so the
run proves the server offers them instead of silently falling back to a legacy
algorithm that happens to still be enabled.

FTP and FTPS use the standard library :mod:`ftplib`, so neither requires a
third-party driver on any platform.

Host key policy
---------------
A *changed* host key is treated far more seriously than an *unknown* one. An
unknown key is the normal state on first contact; a changed key is either a
rebuilt server or an interception. ``auto_add`` therefore adds an unknown key
but still refuses a changed one, because silently overwriting a changed key
would defeat the only control that detects the second case.
"""

from __future__ import annotations

import base64
import errno
import ftplib
import hashlib
import shlex
import socket
import ssl
from abc import ABC
from pathlib import Path
from typing import Any, ClassVar, TypeVar

from connectors.base import BaseConnector
from connectors.factory import register
from connectors.support import (
    build_ssl_context,
    certificate_expiry_warning,
    classify_transport_error,
    describe_tls_socket,
    require_driver,
)
from core.constants import InterfaceType
from core.exceptions import (
    AuthenticationError,
    ConnectionFailedError,
    ConnectorError,
    ValidationProbeError,
)
from models.interfaces import (
    FtpFamilyInterfaceConfig,
    FtpInterfaceConfig,
    FtpsInterfaceConfig,
    FtpsMode,
    HostKeyPolicy,
    ScpInterfaceConfig,
    SftpInterfaceConfig,
    SshFamilyInterfaceConfig,
    SshInterfaceConfig,
)

__all__ = [
    "FtpConnector",
    "FtpsConnector",
    "ScpConnector",
    "SftpConnector",
    "SshConnector",
]

#: Connector families are generic over their interface model so that each
#: concrete connector reads its own fields with full type checking.
SshFamilyT = TypeVar("SshFamilyT", bound=SshFamilyInterfaceConfig)
FtpFamilyT = TypeVar("FtpFamilyT", bound=FtpFamilyInterfaceConfig)

#: Maximum bytes read from a probe response. Enough for a directory listing
#: header or an SCP control message, bounded so a hostile or broken endpoint
#: cannot stream unbounded data into memory.
_MAX_PROBE_BYTES = 8192

#: Every error ftplib can raise, plus the socket errors underneath it.
#: Declared once as a typed constant because mypy cannot verify an
#: unpacked tuple written inline in an ``except`` clause.
_FTP_ERRORS: tuple[type[BaseException], ...] = (OSError, *ftplib.all_errors)

#: Entries listed from a remote directory before the listing is truncated. The
#: probe proves access, it does not inventory the directory.
_MAX_LISTED_ENTRIES = 20


# ---------------------------------------------------------------------------
# SSH family
# ---------------------------------------------------------------------------


def _fingerprint_sha256(key: Any) -> str:
    """Return the OpenSSH style ``SHA256:...`` fingerprint of a host key."""
    digest = hashlib.sha256(key.asbytes()).digest()
    return "SHA256:" + base64.b64encode(digest).decode("ascii").rstrip("=")


class _SshFamilyConnector(BaseConnector[SshFamilyT], ABC):
    """Shared SSH transport handling for the SFTP, SCP and SSH connectors."""

    driver_packages: ClassVar[tuple[str, ...]] = ("paramiko",)

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._socket: socket.socket | None = None
        self._paramiko: Any = None
        self._host_key_details: dict[str, Any] = {}

    # -- connection -----------------------------------------------------

    def _open(self) -> Any:
        """Open the TCP socket, negotiate SSH, verify the host key, authenticate.

        Returns:
            A connected and authenticated :class:`paramiko.Transport`.
        """
        paramiko = require_driver("paramiko", self.interface_type)
        self._paramiko = paramiko

        host = self.interface.host
        port = self.interface.port

        try:
            self._socket = socket.create_connection((host, port), timeout=self.timeout)
        except OSError as error:
            raise classify_transport_error(
                error, host=host, port=port, timeout_seconds=self.timeout
            ) from error

        transport = paramiko.Transport(self._socket)
        transport.banner_timeout = self.timeout
        transport.handshake_timeout = self.timeout
        transport.auth_timeout = self.timeout

        try:
            self._apply_algorithm_preferences(transport)
        except ConnectorError:
            transport.close()
            raise

        try:
            transport.start_client(timeout=self.timeout)
        except paramiko.SSHException as error:
            transport.close()
            raise self._classify_ssh_error(error, operation="SSH handshake") from error
        except OSError as error:
            transport.close()
            raise classify_transport_error(
                error, host=host, port=port, timeout_seconds=self.timeout,
                operation="SSH handshake",
            ) from error

        try:
            self._verify_host_key(transport)
            self._authenticate(transport)
        except ConnectorError:
            transport.close()
            raise

        return transport

    def _close(self, handle: Any) -> None:
        """Close the transport and the underlying socket."""
        if handle is not None:
            handle.close()
        if self._socket is not None:
            self._socket.close()
            self._socket = None

    # -- negotiation ----------------------------------------------------

    def _apply_algorithm_preferences(self, transport: Any) -> None:
        """Pin the configured algorithms before the handshake begins.

        Raises:
            ConnectorError: when a configured algorithm name is not supported
                by the locally installed paramiko and OpenSSL. Reported as a
                configuration fault rather than a connectivity failure, because
                the endpoint was never consulted.
        """
        interface = self.interface
        options = transport.get_security_options()

        preferences = (
            ("kex", "preferred_kex_algorithms", "key exchange algorithm"),
            ("ciphers", "preferred_ciphers", "cipher"),
            ("digests", "preferred_macs", "MAC algorithm"),
            ("key_types", "preferred_host_key_algorithms", "host key algorithm"),
        )

        for option_name, field_name, description in preferences:
            configured = getattr(interface, field_name, None)
            if not configured:
                continue
            try:
                setattr(options, option_name, tuple(configured))
            except ValueError as error:
                available = ", ".join(sorted(getattr(options, option_name)))
                raise ConnectorError(
                    f"Configured {description} is not supported by the SSH library on "
                    f"this host: {', '.join(configured)}",
                    remediation=(
                        f"Correct '{field_name}' in the configuration, or upgrade paramiko "
                        f"and OpenSSL on this host. Locally available: {available}"
                    ),
                    details={field_name: list(configured)},
                    cause=error,
                ) from error

    def _verify_host_key(self, transport: Any) -> None:
        """Verify the server host key according to the configured policy.

        Raises:
            ConnectorError: when the policy requires the key to be trusted and
                it is unknown, or when the key has changed.
        """
        paramiko = self._paramiko
        interface = self.interface
        remote_key = transport.get_remote_server_key()
        fingerprint = _fingerprint_sha256(remote_key)
        key_type = remote_key.get_name()

        self._host_key_details = {
            "host_key_type": key_type,
            "host_key_fingerprint": fingerprint,
        }

        known_hosts_path = self._resolve_known_hosts_path()
        host_keys = paramiko.HostKeys()
        if known_hosts_path is not None and known_hosts_path.is_file():
            try:
                host_keys.load(str(known_hosts_path))
            except (OSError, paramiko.SSHException) as error:
                self.add_warning(
                    f"known_hosts file could not be parsed ({known_hosts_path}): {error}"
                )

        trusted = self._lookup_known_host(host_keys, key_type)
        policy = interface.host_key_policy

        if trusted is not None:
            if trusted.asbytes() == remote_key.asbytes():
                self._host_key_details["host_key_verified"] = True
                return

            # A changed key is refused under every policy, including auto_add.
            # Overwriting it silently would remove the only signal that
            # distinguishes a rebuilt server from an interception.
            self._host_key_details["host_key_verified"] = False
            raise AuthenticationError(
                f"The host key for {interface.host} has CHANGED. Expected "
                f"{_fingerprint_sha256(trusted)}, the server presented {fingerprint}.",
                remediation=(
                    "If the server was rebuilt or re-keyed during the change window, remove "
                    "the stale entry from the known_hosts file and re-run. If it was not, "
                    "treat this as a potential interception and escalate before connecting."
                ),
                details=dict(self._host_key_details),
            )

        self._host_key_details["host_key_verified"] = False

        if policy is HostKeyPolicy.REJECT:
            raise AuthenticationError(
                f"The host key for {interface.host} is not trusted "
                f"({key_type} {fingerprint}).",
                remediation=(
                    "Add the server's key to the configured known_hosts file, or set "
                    "host_key_policy to 'warn' if this endpoint is deliberately validated "
                    "without host key pinning."
                ),
                details=dict(self._host_key_details),
            )

        if policy is HostKeyPolicy.AUTO_ADD:
            self._add_known_host(host_keys, known_hosts_path, key_type, remote_key)
            return

        self.add_warning(
            f"Server host key is not verified: {key_type} {fingerprint}. "
            "The connection proceeded because host_key_policy is 'warn'."
        )

    def _resolve_known_hosts_path(self) -> Path | None:
        """Return the known_hosts file to consult, if any."""
        configured = self.interface.known_hosts_path
        if configured:
            return Path(configured).expanduser()
        default = Path.home() / ".ssh" / "known_hosts"
        return default if default.is_file() else None

    def _lookup_known_host(self, host_keys: Any, key_type: str) -> Any:
        """Return the trusted key for this host and key type, or ``None``.

        OpenSSH records a non-default port as ``[host]:port``, so both forms
        are consulted; otherwise an interface on port 2222 would report an
        unknown key even though the operator had trusted it.
        """
        interface = self.interface
        candidates = [interface.host]
        if interface.port != 22:
            candidates.insert(0, f"[{interface.host}]:{interface.port}")

        for candidate in candidates:
            entry = host_keys.lookup(candidate)
            if entry is not None:
                key = entry.get(key_type)
                if key is not None:
                    return key
        return None

    def _add_known_host(
        self, host_keys: Any, path: Path | None, key_type: str, remote_key: Any
    ) -> None:
        """Persist a newly seen host key under the ``auto_add`` policy."""
        interface = self.interface
        entry = (
            f"[{interface.host}]:{interface.port}" if interface.port != 22 else interface.host
        )
        target = path or (Path.home() / ".ssh" / "known_hosts")

        try:
            host_keys.add(entry, key_type, remote_key)
            target.parent.mkdir(parents=True, exist_ok=True)
            host_keys.save(str(target))
            self.add_warning(
                f"Server host key was not known and has been added to {target} "
                f"({key_type} {self._host_key_details['host_key_fingerprint']})."
            )
        except OSError as error:
            self.add_warning(
                f"Server host key could not be written to {target} ({error}); the "
                "connection proceeded but the key remains untrusted."
            )

    # -- authentication -------------------------------------------------

    def _authenticate(self, transport: Any) -> None:
        """Authenticate the transport using the configured credential.

        Raises:
            AuthenticationError: when every configured method is rejected.
        """
        interface = self.interface
        username = interface.username
        password = self.secret("password")

        if password:
            self._auth_password(transport, username, password)
            return

        if interface.private_key_path:
            key = self._load_private_key(interface.private_key_path)
            self._auth_public_key(transport, username, key)
            return

        self._auth_agent(transport, username)

    def _auth_password(self, transport: Any, username: str, password: str) -> None:
        """Authenticate with a password."""
        paramiko = self._paramiko
        try:
            transport.auth_password(username, password)
        except paramiko.AuthenticationException as error:
            raise AuthenticationError(
                f"Password authentication failed for '{username}' at {self.interface.endpoint}.",
                remediation=(
                    "Verify the account and password. If the password is correct, check "
                    "whether the account is locked or expired, and whether the server now "
                    "requires public key authentication after the change."
                ),
                details={"username": username, "method": "password"},
                cause=error,
            ) from error
        except paramiko.SSHException as error:
            raise self._classify_ssh_error(error, operation="password authentication") from error

    def _auth_public_key(self, transport: Any, username: str, key: Any) -> None:
        """Authenticate with a private key."""
        paramiko = self._paramiko
        try:
            transport.auth_publickey(username, key)
        except paramiko.AuthenticationException as error:
            raise AuthenticationError(
                f"Public key authentication failed for '{username}' at "
                f"{self.interface.endpoint} using {self.interface.private_key_path}.",
                remediation=(
                    "Confirm the matching public key is present in the account's "
                    "authorized_keys on the server. After an SSH hardening change, an "
                    "RSA/SHA-1 key may have been retired while the file still lists it."
                ),
                details={
                    "username": username,
                    "method": "publickey",
                    "key_type": key.get_name(),
                },
                cause=error,
            ) from error
        except paramiko.SSHException as error:
            raise self._classify_ssh_error(error, operation="public key authentication") from error

    def _auth_agent(self, transport: Any, username: str) -> None:
        """Authenticate with keys offered by the local SSH agent.

        Reached when the configuration names neither a password nor a key,
        which the wizard records as relying on the ambient credentials of the
        account that runs the job.
        """
        paramiko = self._paramiko
        try:
            agent_keys = paramiko.Agent().get_keys()
        except paramiko.SSHException:
            agent_keys = ()

        for key in agent_keys:
            try:
                transport.auth_publickey(username, key)
            except (paramiko.AuthenticationException, paramiko.SSHException):
                continue
            self.add_warning(
                f"Authenticated using a key offered by the SSH agent ({key.get_name()}). "
                "The credential therefore depends on the agent available to the account "
                "running the job, which a scheduler may not provide."
            )
            return

        raise AuthenticationError(
            f"No usable credential for '{username}' at {self.interface.endpoint}: no "
            f"password, no private key, and the SSH agent offered "
            f"{len(agent_keys)} usable key(s).",
            remediation=(
                "Configure a password or a private key with 'python generate_config.py'. "
                "Relying on an SSH agent is fragile under a scheduler, which normally runs "
                "without one."
            ),
            details={"username": username, "method": "agent"},
        )

    def _load_private_key(self, key_path: str) -> Any:
        """Load a private key, trying each supported algorithm.

        Raises:
            AuthenticationError: when the key cannot be read, is encrypted with
                no passphrase configured, or is in an unrecognised format.
        """
        paramiko = self._paramiko
        path = Path(key_path).expanduser()
        passphrase = self.secret("key_passphrase") or None

        if not path.is_file():
            raise AuthenticationError(
                f"Private key file not found: {path}",
                remediation=(
                    "Correct the path, or confirm the key exists on the host that runs the "
                    "job. A key present on a workstation is often absent on the server."
                ),
                details={"private_key_path": str(path)},
            )

        key_classes = [
            getattr(paramiko, name)
            for name in ("Ed25519Key", "ECDSAKey", "RSAKey", "DSSKey")
            if hasattr(paramiko, name)
        ]

        password_required = False
        for key_class in key_classes:
            try:
                return key_class.from_private_key_file(str(path), password=passphrase)
            except paramiko.PasswordRequiredException:
                password_required = True
            except (paramiko.SSHException, ValueError):
                continue
            except OSError as error:
                raise AuthenticationError(
                    f"Private key file could not be read: {path}",
                    remediation=(
                        "Check the file permissions for the account running the job."
                    ),
                    details={"private_key_path": str(path)},
                    cause=error,
                ) from error

        if password_required:
            passphrase_state = (
                "the configured passphrase is incorrect"
                if passphrase
                else "no passphrase is configured"
            )
            raise AuthenticationError(
                f"Private key {path} is protected by a passphrase, and {passphrase_state}.",
                remediation=(
                    "Re-run 'python generate_config.py' and supply the key passphrase, or "
                    "use an unencrypted key dedicated to this batch account."
                ),
                details={"private_key_path": str(path)},
            )

        raise AuthenticationError(
            f"Private key {path} is not in a recognised format.",
            remediation=(
                "Supply an OpenSSH or PEM private key. A PuTTY .ppk file must be converted "
                "first, and a public key (.pub) is not a private key."
            ),
            details={"private_key_path": str(path)},
        )

    # -- diagnostics ----------------------------------------------------

    def _classify_ssh_error(self, error: Exception, *, operation: str) -> ConnectorError:
        """Convert a paramiko SSHException into a framework exception."""
        message = str(error)
        lowered = message.lower()

        if "no acceptable" in lowered or "incompatible" in lowered or "negotiat" in lowered:
            return ConnectorError(
                f"SSH algorithm negotiation failed with {self.interface.endpoint}: {message}",
                remediation=(
                    "The client and server share no acceptable algorithm. This is the "
                    "expected symptom after an SSH hardening change. Compare the algorithms "
                    "the server now offers with those this host supports, and update the "
                    "pinned algorithms in the configuration."
                ),
                details={"operation": operation},
                cause=error,
            )

        return classify_transport_error(
            error,
            host=self.interface.host,
            port=self.interface.port,
            timeout_seconds=self.timeout,
            operation=operation,
        )

    def _transport_details(self, transport: Any) -> dict[str, Any]:
        """Collect the negotiated transport parameters for the report.

        This is the payload that makes a *successful* run meaningful after a
        cipher change: it records what was actually negotiated, not merely
        that something was.
        """
        details: dict[str, Any] = dict(self._host_key_details)
        details["server_banner"] = getattr(transport, "remote_version", None)

        for label, attribute in (
            ("cipher_client_to_server", "local_cipher"),
            ("cipher_server_to_client", "remote_cipher"),
            ("mac_client_to_server", "local_mac"),
            ("mac_server_to_client", "remote_mac"),
            ("compression_client_to_server", "local_compression"),
        ):
            value = getattr(transport, attribute, None)
            if value:
                details[label] = value

        kex_engine = getattr(transport, "kex_engine", None)
        if kex_engine is not None:
            details["key_exchange"] = getattr(kex_engine, "name", type(kex_engine).__name__)

        details["username"] = self.interface.username
        return {key: value for key, value in details.items() if value is not None}


@register
class SftpConnector(_SshFamilyConnector[SftpInterfaceConfig]):
    """Validates an SFTP endpoint.

    The probe opens the SFTP subsystem, which is a distinct step from SSH
    authentication: a hardened server frequently authenticates the account and
    then refuses the subsystem, and only opening it proves file transfer will
    work.
    """

    interface_type: ClassVar[InterfaceType] = InterfaceType.SFTP

    def _probe(self, handle: Any) -> dict[str, Any]:
        """Open the SFTP subsystem and list the configured directory."""
        paramiko = self._paramiko
        interface = self.interface
        details = self._transport_details(handle)

        try:
            sftp = paramiko.SFTPClient.from_transport(handle, window_size=None)
        except paramiko.SSHException as error:
            raise ValidationProbeError(
                f"SSH authentication succeeded but the SFTP subsystem could not be opened "
                f"on {interface.endpoint}.",
                remediation=(
                    "The account is valid but the server is not offering the SFTP "
                    "subsystem. Check the 'Subsystem sftp' directive in sshd_config and "
                    "whether the account is restricted to a shell-only session."
                ),
                details=details,
                cause=error,
            ) from error

        if sftp is None:
            raise ValidationProbeError(
                f"The SFTP subsystem could not be opened on {interface.endpoint}.",
                remediation="Check the 'Subsystem sftp' directive in the server's sshd_config.",
                details=details,
            )

        try:
            details["sftp_protocol_version"] = getattr(sftp, "_version", None)
            target = interface.remote_path or "."
            try:
                entries = sftp.listdir(target)
            except OSError as error:
                # paramiko surfaces SFTP status codes as a plain OSError with
                # errno set, not as FileNotFoundError or PermissionError.
                # Branching on the exception subclass would therefore collapse
                # "does not exist" and "not permitted" into one vague message,
                # which are very different findings after a migration.
                raise self._classify_listing_error(error, target, details) from error

            details["remote_path"] = target
            details["remote_entry_count"] = len(entries)
            details["remote_entries_sample"] = sorted(entries)[:_MAX_LISTED_ENTRIES]
            return details
        finally:
            sftp.close()

    def _classify_listing_error(
        self, error: OSError, target: str, details: dict[str, Any]
    ) -> ValidationProbeError:
        """Turn an SFTP listing failure into a specific, actionable error."""
        interface = self.interface
        code = getattr(error, "errno", None)

        if code == errno.ENOENT:
            return ValidationProbeError(
                f"Remote directory '{target}' does not exist on {interface.host}.",
                remediation=(
                    "Correct 'remote_path', or create the directory. After a migration the "
                    "account's home directory or chroot base often changes, which makes a "
                    "previously valid relative path resolve somewhere else."
                ),
                details=details,
                cause=error,
            )

        if code in (errno.EACCES, errno.EPERM):
            return ValidationProbeError(
                f"Remote directory '{target}' is not readable by '{interface.username}' "
                f"on {interface.host}.",
                remediation=(
                    "Grant the account read and execute permission on the directory. "
                    "Authentication succeeded, so this is an authorisation problem rather "
                    "than a credential problem."
                ),
                details=details,
                cause=error,
            )

        return ValidationProbeError(
            f"Remote directory '{target}' could not be listed on {interface.host}: {error}",
            remediation="Check the path and the account's permissions on it.",
            details=details,
            cause=error,
        )


@register
class SshConnector(_SshFamilyConnector[SshInterfaceConfig]):
    """Validates an SSH endpoint, optionally executing a command."""

    interface_type: ClassVar[InterfaceType] = InterfaceType.SSH

    def _probe(self, handle: Any) -> dict[str, Any]:
        """Open a session channel and run the optional validation command."""
        paramiko = self._paramiko
        interface = self.interface
        details = self._transport_details(handle)

        try:
            channel = handle.open_session(timeout=self.timeout)
        except paramiko.SSHException as error:
            raise ValidationProbeError(
                f"SSH authentication succeeded but a session channel could not be opened "
                f"on {interface.endpoint}.",
                remediation=(
                    "The account authenticated but cannot open a session. Check for a "
                    "ForceCommand directive, a restricted shell, or an account configured "
                    "for file transfer only."
                ),
                details=details,
                cause=error,
            ) from error

        try:
            channel.settimeout(self.timeout)

            if not interface.validation_command:
                details["session_channel"] = "opened"
                details["command_executed"] = None
                return details

            try:
                channel.exec_command(interface.validation_command)
                stdout = self._read_channel(channel)
                exit_status = channel.recv_exit_status()
            except paramiko.SSHException as error:
                raise ValidationProbeError(
                    f"The server closed the channel while running the validation command "
                    f"on {interface.host}: {error}",
                    remediation=(
                        "The account authenticated but the server would not run the "
                        "command. Check for a ForceCommand directive, a restricted shell, "
                        "or an account permitted to transfer files but not to execute."
                    ),
                    details={**details, "command": interface.validation_command},
                    cause=error,
                ) from error

            details["command_executed"] = interface.validation_command
            details["command_exit_status"] = exit_status
            details["command_output"] = stdout.strip()[:512]

            if exit_status != 0:
                stderr = ""
                if channel.recv_stderr_ready():
                    stderr = channel.recv_stderr(_MAX_PROBE_BYTES).decode(
                        "utf-8", errors="replace"
                    )
                raise ValidationProbeError(
                    f"Validation command exited with status {exit_status} on "
                    f"{interface.host}: {interface.validation_command}",
                    remediation=(
                        "The connection and authentication succeeded; the command itself "
                        "failed. Run it manually as this account to see why."
                    ),
                    details={**details, "command_stderr": stderr.strip()[:512]},
                )
            return details
        finally:
            channel.close()

    @staticmethod
    def _read_channel(channel: Any) -> str:
        """Read bounded output from a channel."""
        chunks: list[bytes] = []
        received = 0
        while received < _MAX_PROBE_BYTES:
            data = channel.recv(_MAX_PROBE_BYTES - received)
            if not data:
                break
            chunks.append(data)
            received += len(data)
        return b"".join(chunks).decode("utf-8", errors="replace")


@register
class ScpConnector(_SshFamilyConnector[ScpInterfaceConfig]):
    """Validates an SCP endpoint.

    SCP is not a separate service: it is the ``scp`` binary invoked over an SSH
    exec channel. Validation therefore has two levels, both strictly read-only:

    * With ``remote_path`` set, the SCP source-mode handshake is performed
      against that path. The server's control message proves both that the
      remote ``scp`` binary exists and that the account can read the file.
    * Without it, ``scp`` is invoked with no arguments and its usage response
      is taken as proof the binary is present and executable.

    ``remote_path`` should name a readable *file*. Source mode rejects a
    directory without ``-r``, and the resulting error is reported with that
    explanation rather than as an opaque failure.
    """

    interface_type: ClassVar[InterfaceType] = InterfaceType.SCP

    def _probe(self, handle: Any) -> dict[str, Any]:
        """Verify the remote SCP binary, and the path when one is configured."""
        paramiko = self._paramiko
        interface = self.interface
        details = self._transport_details(handle)

        try:
            channel = handle.open_session(timeout=self.timeout)
        except paramiko.SSHException as error:
            raise ValidationProbeError(
                f"SSH authentication succeeded but a session channel could not be opened "
                f"on {interface.endpoint}, so SCP cannot be exercised.",
                remediation=(
                    "Check for a ForceCommand directive or a restricted shell on the "
                    "account."
                ),
                details=details,
                cause=error,
            ) from error

        try:
            channel.settimeout(self.timeout)
            if interface.remote_path:
                return self._probe_source_mode(channel, details, interface.remote_path)
            return self._probe_binary_present(channel, details)
        finally:
            channel.close()

    def _probe_source_mode(
        self, channel: Any, details: dict[str, Any], remote_path: str
    ) -> dict[str, Any]:
        """Perform an SCP source-mode handshake for ``remote_path``."""
        paramiko = self._paramiko
        details["scp_mode"] = "source"
        details["remote_path"] = remote_path

        try:
            channel.exec_command(f"scp -f {shlex.quote(remote_path)}")
            channel.sendall(b"\x00")  # Ready signal that starts the transfer.
            response = channel.recv(_MAX_PROBE_BYTES)
        except (paramiko.SSHException, OSError) as error:
            raise ValidationProbeError(
                f"The server closed the channel while starting scp on "
                f"{self.interface.host}: {error}",
                remediation=(
                    "The account authenticated but the server would not run scp. Check for "
                    "a ForceCommand directive or a restricted shell on the account."
                ),
                details=details,
                cause=error,
            ) from error

        if not response:
            raise ValidationProbeError(
                f"The remote scp binary produced no response on {self.interface.host}.",
                remediation=(
                    "Confirm 'scp' is installed and on the PATH of the account's "
                    "non-interactive shell. A login-only PATH is a common cause."
                ),
                details=details,
            )

        marker = response[0:1]
        if marker in (b"\x01", b"\x02"):
            message = response[1:].decode("utf-8", errors="replace").strip()
            hint = (
                "SCP source mode cannot read a directory. Point 'remote_path' at a file, "
                "or leave it blank to verify only that the scp binary is present."
                if "not a regular file" in message.lower()
                else "Check the path exists and the account can read it."
            )
            raise ValidationProbeError(
                f"SCP refused '{remote_path}' on {self.interface.host}: {message}",
                remediation=hint,
                details={**details, "scp_error": message},
            )

        header = response.decode("utf-8", errors="replace").strip()
        details["scp_response"] = header[:256]
        if marker == b"C":
            parts = header.split(None, 2)
            if len(parts) == 3:
                details["remote_file_mode"] = parts[0].lstrip("C")
                details["remote_file_size_bytes"] = parts[1]
                details["remote_file_name"] = parts[2]
        return details

    def _probe_binary_present(self, channel: Any, details: dict[str, Any]) -> dict[str, Any]:
        """Confirm the remote ``scp`` binary exists by reading its usage output."""
        paramiko = self._paramiko
        try:
            channel.exec_command("scp")
            stdout = channel.recv(_MAX_PROBE_BYTES).decode("utf-8", errors="replace")
            stderr = ""
            if channel.recv_stderr_ready():
                stderr = channel.recv_stderr(_MAX_PROBE_BYTES).decode("utf-8", errors="replace")
            exit_status = channel.recv_exit_status()
        except (paramiko.SSHException, OSError) as error:
            raise ValidationProbeError(
                f"The server closed the channel while checking for scp on "
                f"{self.interface.host}: {error}",
                remediation=(
                    "The account authenticated but the server would not execute a command. "
                    "Check for a ForceCommand directive or a restricted shell."
                ),
                details=details,
                cause=error,
            ) from error

        combined = f"{stdout}\n{stderr}".lower()
        details["scp_mode"] = "binary-check"
        details["scp_exit_status"] = exit_status
        details["scp_response"] = (stdout or stderr).strip()[:256]

        if "usage" in combined or "scp" in combined:
            return details

        raise ValidationProbeError(
            f"The remote scp binary does not appear to be available on "
            f"{self.interface.host} (exit status {exit_status}).",
            remediation=(
                "Install OpenSSH client tools on the server, or confirm 'scp' is on the "
                "PATH for a non-interactive session of this account."
            ),
            details=details,
        )


# ---------------------------------------------------------------------------
# FTP family
# ---------------------------------------------------------------------------


class _ImplicitFtpTls(ftplib.FTP_TLS):
    """FTP_TLS variant that negotiates TLS immediately on connect.

    :mod:`ftplib` implements explicit FTPS (RFC 4217) only: it connects in
    clear and issues ``AUTH TLS``. Implicit FTPS, historically on port 990,
    expects the TLS handshake before any FTP command. Wrapping the socket at
    connect time is the standard way to support it.
    """

    #: Class-level default. Declared here rather than in ``__init__`` because
    #: ``ftplib.FTP.__init__`` assigns ``self.sock`` and therefore triggers the
    #: setter below before any subclass ``__init__`` body could run.
    _wrapped_socket: ssl.SSLSocket | None = None

    @property
    def sock(self) -> Any:
        """Return the TLS wrapped socket."""
        return self._wrapped_socket

    @sock.setter
    def sock(self, value: Any) -> None:
        """Wrap the socket in TLS as soon as ftplib assigns it."""
        if value is not None and not isinstance(value, ssl.SSLSocket):
            value = self.context.wrap_socket(value, server_hostname=self.host)
        self._wrapped_socket = value


class _FtpFamilyConnector(BaseConnector[FtpFamilyT], ABC):
    """Shared connection and probe handling for FTP and FTPS."""

    driver_packages: ClassVar[tuple[str, ...]] = ()

    def _build_client(self) -> ftplib.FTP:
        """Return an unconnected client. Overridden by the FTPS connector."""
        # S321: using plain FTP is the entire point of this connector. The
        # estate runs it, so the framework must be able to validate it; the
        # connector records a warning on the result so the exposure is visible
        # in the report rather than silently accepted here.
        return ftplib.FTP(timeout=self.timeout)  # noqa: S321

    def _secure_after_login(self, client: ftplib.FTP) -> None:
        """Hook for FTPS to protect the data channel after authentication."""

    def _open(self) -> ftplib.FTP:
        """Connect and log in.

        Returns:
            The connected and authenticated client.
        """
        interface = self.interface
        client = self._build_client()

        try:
            client.connect(host=interface.host, port=interface.port, timeout=self.timeout)
        except _FTP_ERRORS as error:
            raise classify_transport_error(
                error, host=interface.host, port=interface.port, timeout_seconds=self.timeout
            ) from error

        try:
            self._before_login(client)
            username = interface.username or "anonymous"
            password = self.secret("password") or ""
            client.login(user=username, passwd=password)
            self._secure_after_login(client)
        except ftplib.error_perm as error:
            client.close()
            raise AuthenticationError(
                f"FTP login failed for '{interface.username}' at {interface.endpoint}: "
                f"{error}",
                remediation=(
                    "Verify the account and password. A '530' response means the "
                    "credentials were rejected; a '534' usually means the server now "
                    "requires TLS, which is a common change after a security review."
                ),
                details={"username": interface.username, "server_response": str(error)},
                cause=error,
            ) from error
        except _FTP_ERRORS as error:
            client.close()
            raise classify_transport_error(
                error,
                host=interface.host,
                port=interface.port,
                timeout_seconds=self.timeout,
                operation="FTP login",
            ) from error

        client.set_pasv(interface.passive_mode)
        return client

    def _before_login(self, client: ftplib.FTP) -> None:
        """Hook for FTPS to establish TLS before credentials are sent."""

    def _probe(self, handle: ftplib.FTP) -> dict[str, Any]:
        """Verify the session by listing the working or configured directory."""
        interface = self.interface
        details: dict[str, Any] = {
            "server_banner": (handle.getwelcome() or "").strip()[:256],
            "passive_mode": interface.passive_mode,
            "username": interface.username,
        }
        details.update(self._tls_details(handle))

        try:
            if interface.remote_path:
                handle.cwd(interface.remote_path)
                details["remote_path"] = interface.remote_path
            details["working_directory"] = handle.pwd()

            # NLST exercises the data channel, which is the part that actually
            # breaks after a firewall change: the control channel can be
            # perfectly healthy while the data connection is blocked.
            entries = handle.nlst()
            details["remote_entry_count"] = len(entries)
            details["remote_entries_sample"] = sorted(entries)[:_MAX_LISTED_ENTRIES]
        except ftplib.error_perm as error:
            response = str(error)
            if response.startswith("550"):
                raise ValidationProbeError(
                    f"Remote directory '{interface.remote_path or '.'}' is not accessible "
                    f"on {interface.host}: {response}",
                    remediation=(
                        "Correct 'remote_path', or grant the account access to it. "
                        "Authentication succeeded, so this is an authorisation problem."
                    ),
                    details=details,
                    cause=error,
                ) from error
            raise ValidationProbeError(
                f"FTP command was refused by {interface.host}: {response}",
                remediation="Check the account's permissions and the server configuration.",
                details=details,
                cause=error,
            ) from error
        except _FTP_ERRORS as error:
            raise ValidationProbeError(
                f"The FTP data connection to {interface.host} failed: {error}",
                remediation=(
                    "The control connection worked but the data connection did not. In "
                    "passive mode the server returns a high port that the firewall must "
                    "also permit; this is the classic symptom of a firewall change that "
                    "opened only port 21."
                ),
                details=details,
                cause=error,
            ) from error

        return details

    def _tls_details(self, client: ftplib.FTP) -> dict[str, Any]:  # noqa: ARG002
        """Return TLS details for the session. Empty for plain FTP.

        A hook: the FTPS connector overrides it and uses ``client``.
        """
        return {}

    def _close(self, handle: ftplib.FTP) -> None:
        """Send QUIT, falling back to closing the socket."""
        if handle is None:
            return
        try:
            handle.quit()
        except _FTP_ERRORS:
            handle.close()


@register
class FtpConnector(_FtpFamilyConnector[FtpInterfaceConfig]):
    """Validates a plain FTP endpoint.

    FTP sends credentials in clear text. The connector records that fact as a
    warning so it appears in the report rather than remaining invisible.
    """

    interface_type: ClassVar[InterfaceType] = InterfaceType.FTP

    def _probe(self, handle: ftplib.FTP) -> dict[str, Any]:
        """Run the shared probe and flag the protocol as insecure."""
        interface = self.interface
        details = super()._probe(handle)
        details["encryption"] = "none"

        if self.secret("password"):
            self.add_warning(
                "Credentials for this interface are transmitted in clear text over plain "
                "FTP. Consider migrating it to FTPS or SFTP."
            )
        elif interface.username.lower() == "anonymous":
            details["anonymous_login"] = True
        return details


@register
class FtpsConnector(_FtpFamilyConnector[FtpsInterfaceConfig]):
    """Validates an FTPS endpoint over explicit or implicit TLS.

    Both channels are exercised. The control channel is protected first, then
    ``PROT P`` protects the data channel, and the probe's directory listing
    forces a data connection. A frequent post-upgrade failure is a control
    channel that negotiates cleanly while the data channel fails, which a
    control-only check would report as healthy.
    """

    interface_type: ClassVar[InterfaceType] = InterfaceType.FTPS

    def _build_client(self) -> ftplib.FTP:
        """Return an explicit or implicit FTPS client with a TLS context."""
        interface = self.interface
        context = build_ssl_context(
            verify=interface.verify_ssl, ca_bundle_path=interface.ca_bundle_path
        )
        if not interface.verify_ssl:
            self.add_warning(
                "TLS certificate verification is disabled for this interface, so an "
                "expired or mis-issued certificate cannot be detected."
            )

        client_class = (
            _ImplicitFtpTls if interface.ftps_mode is FtpsMode.IMPLICIT else ftplib.FTP_TLS
        )
        return client_class(context=context, timeout=self.timeout)

    def _before_login(self, client: ftplib.FTP) -> None:
        """Protect the control channel before credentials are sent."""
        interface = self.interface
        if interface.ftps_mode is FtpsMode.IMPLICIT:
            return  # Already wrapped at connect time.

        try:
            client.auth()  # type: ignore[attr-defined]
        except ftplib.error_perm as error:
            raise ConnectionFailedError(
                f"The server at {interface.endpoint} refused AUTH TLS: {error}",
                remediation=(
                    "The endpoint does not offer explicit FTPS on this port. Use implicit "
                    "mode (historically port 990), or plain FTP if the server genuinely "
                    "does not support TLS."
                ),
                details={"ftps_mode": interface.ftps_mode.value},
                cause=error,
            ) from error
        except ssl.SSLError as error:
            raise classify_transport_error(
                error,
                host=interface.host,
                port=interface.port,
                timeout_seconds=self.timeout,
                operation="FTPS control channel TLS handshake",
            ) from error

    def _secure_after_login(self, client: ftplib.FTP) -> None:
        """Request encryption of the data channel."""
        try:
            client.prot_p()  # type: ignore[attr-defined]
        except (ftplib.error_perm, ssl.SSLError) as error:
            self.add_warning(
                f"The data channel could not be protected with PROT P ({error}); file "
                "contents would transfer unencrypted."
            )

    def _tls_details(self, client: ftplib.FTP) -> dict[str, Any]:
        """Return the negotiated TLS parameters and certificate facts."""
        interface = self.interface
        details = describe_tls_socket(client.sock)
        details["ftps_mode"] = interface.ftps_mode.value
        details["encryption"] = "tls"

        warning = certificate_expiry_warning(details)
        if warning:
            self.add_warning(warning)
        return details
