"""Connector registry and factory.

Connectors register themselves with the :func:`register` decorator and are
resolved by :class:`ConnectorFactory` from the interface's ``type``
discriminator. The engine therefore never imports a connector directly and
never contains a branch per connectivity type.

Lazy module loading
-------------------
Connector modules are imported the first time their type is requested, not at
package import. This matters operationally: importing
:mod:`connectors.database` pulls in ``oracledb`` and ``pyodbc``, and a site
that validates only SFTP must not need either installed. The mapping from type
to module lives in :data:`_MODULE_BY_TYPE`.

Adding a connectivity type
--------------------------
1. Add the member to :class:`~core.constants.InterfaceType` and its entry to
   ``INTERFACE_REGISTRY``.
2. Write the connector, decorated with ``@register``.
3. Add its module to :data:`_MODULE_BY_TYPE`.

Neither the engine, the reporting layer nor the wizard changes.
"""

from __future__ import annotations

import importlib
import threading
from collections.abc import Mapping
from typing import TypeVar

from connectors.base import BaseConnector
from core.constants import InterfaceType
from core.exceptions import UnsupportedInterfaceTypeError
from core.logging_setup import get_logger
from models.interfaces import BaseInterfaceConfig
from models.settings import ExecutionSettings

__all__ = ["ConnectorFactory", "register", "registered_types"]

_logger = get_logger(__name__)

ConnectorT = TypeVar("ConnectorT", bound=type[BaseConnector])

#: Populated by the ``register`` decorator as connector modules are imported.
_REGISTRY: dict[InterfaceType, type[BaseConnector]] = {}

#: Guards registry mutation and lazy import. Interfaces are validated
#: concurrently, so two worker threads can request the same unimported
#: connector module at the same moment.
_LOCK = threading.RLock()

#: Connectivity type to the module that implements it. Grouped by category so
#: that one import pulls in the drivers for related types only.
_MODULE_BY_TYPE: dict[InterfaceType, str] = {
    InterfaceType.SFTP: "connectors.file_transfer",
    InterfaceType.SCP: "connectors.file_transfer",
    InterfaceType.SSH: "connectors.file_transfer",
    InterfaceType.FTP: "connectors.file_transfer",
    InterfaceType.FTPS: "connectors.file_transfer",
    InterfaceType.ORACLE: "connectors.database",
    InterfaceType.MSSQL: "connectors.database",
    InterfaceType.AZURE_BLOB: "connectors.cloud",
    InterfaceType.AWS_S3: "connectors.cloud",
    InterfaceType.REST: "connectors.api",
    InterfaceType.SOAP: "connectors.api",
}


def register(connector_class: ConnectorT) -> ConnectorT:
    """Register a connector class under its declared ``interface_type``.

    Args:
        connector_class: A concrete :class:`~connectors.base.BaseConnector`
            subclass declaring ``interface_type``.

    Returns:
        The class unchanged, so the decorator composes.

    Raises:
        TypeError: if the class does not declare ``interface_type``.
    """
    interface_type = getattr(connector_class, "interface_type", None)
    if not isinstance(interface_type, InterfaceType):
        raise TypeError(
            f"{connector_class.__name__} must declare a class-level "
            f"'interface_type: ClassVar[InterfaceType]' to be registered."
        )

    with _LOCK:
        existing = _REGISTRY.get(interface_type)
        if existing is not None and existing is not connector_class:
            _logger.debug(
                "Replacing the registered connector for %s: %s -> %s",
                interface_type.value,
                existing.__name__,
                connector_class.__name__,
            )
        _REGISTRY[interface_type] = connector_class

    return connector_class


def registered_types() -> frozenset[InterfaceType]:
    """Return the connectivity types currently registered.

    Only reflects modules imported so far; use
    :meth:`ConnectorFactory.load_all` first for a complete picture.
    """
    with _LOCK:
        return frozenset(_REGISTRY)


class ConnectorFactory:
    """Creates the connector that validates a given interface."""

    @staticmethod
    def _ensure_loaded(interface_type: InterfaceType) -> None:
        """Import the module implementing ``interface_type``, if needed.

        Raises:
            UnsupportedInterfaceTypeError: if no module is mapped for the type,
                or the module imports but does not register a connector.
        """
        with _LOCK:
            if interface_type in _REGISTRY:
                return

            module_name = _MODULE_BY_TYPE.get(interface_type)
            if module_name is None:
                raise UnsupportedInterfaceTypeError(
                    f"No connector is mapped for connectivity type "
                    f"'{interface_type.value}'.",
                    remediation=(
                        "This indicates an incomplete connectivity type addition. Register "
                        "the connector module in connectors/factory.py."
                    ),
                    details={"interface_type": interface_type.value},
                )

            # A failure here is a defect in the framework, not a missing
            # third-party driver: connector modules import their drivers
            # lazily inside _open() precisely so that this import cannot fail
            # because of an absent optional dependency.
            try:
                importlib.import_module(module_name)
            except ImportError as error:
                raise UnsupportedInterfaceTypeError(
                    f"The connector module '{module_name}' for "
                    f"'{interface_type.value}' could not be imported.",
                    remediation=(
                        "The installation appears to be incomplete. Reinstall the "
                        "framework, or verify that the connectors package is intact."
                    ),
                    details={
                        "interface_type": interface_type.value,
                        "module": module_name,
                    },
                    cause=error,
                ) from error

            if interface_type not in _REGISTRY:
                raise UnsupportedInterfaceTypeError(
                    f"Module '{module_name}' was imported but registered no connector for "
                    f"'{interface_type.value}'.",
                    remediation=(
                        "Decorate the connector class with '@register' and set its "
                        "'interface_type' class attribute."
                    ),
                    details={
                        "interface_type": interface_type.value,
                        "module": module_name,
                    },
                )

    @classmethod
    def create(
        cls,
        interface: BaseInterfaceConfig,
        secrets: Mapping[str, str | None],
        execution: ExecutionSettings,
    ) -> BaseConnector:
        """Return a connector instance for ``interface``.

        Args:
            interface: The validated interface configuration.
            secrets: Resolved plaintext secrets, keyed by field name.
            execution: Engine execution settings.

        Returns:
            A ready-to-use connector.

        Raises:
            UnsupportedInterfaceTypeError: if no connector serves the type.
        """
        interface_type = interface.interface_type
        cls._ensure_loaded(interface_type)

        with _LOCK:
            connector_class = _REGISTRY[interface_type]

        return connector_class(interface, secrets, execution)

    @classmethod
    def load_all(cls) -> frozenset[InterfaceType]:
        """Import every connector module and return the registered types.

        Used by the self-test and by the test suite to assert that every
        declared connectivity type actually has a connector behind it. Not
        called on the normal execution path, where lazy loading is the point.
        """
        for module_name in dict.fromkeys(_MODULE_BY_TYPE.values()):
            try:
                importlib.import_module(module_name)
            except ImportError:  # pragma: no cover - incomplete installation
                _logger.exception("Connector module '%s' could not be imported.", module_name)
        return registered_types()

    @classmethod
    def supports(cls, interface_type: InterfaceType) -> bool:
        """Return ``True`` when a connector is available for the type."""
        try:
            cls._ensure_loaded(interface_type)
        except UnsupportedInterfaceTypeError:
            return False
        return True
