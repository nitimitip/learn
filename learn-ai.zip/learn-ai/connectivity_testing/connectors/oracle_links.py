"""Oracle database link enumeration and probing.

Why this exists
---------------
A database link is the one hop no host-level check can see. The listener
answers, the account logs in, the validation query returns its row -- and the
overnight job still fails, because the link it reads through points at a
database that was rebuilt, a remote password that was rotated, or a TNS alias
that no longer resolves *on the database server*. That last point is what makes
this check worth running: a link is opened by the Oracle server process, not by
this host, so it exercises a network path this framework can reach in no other
way.

What the check proves
---------------------
Enumerating links from the data dictionary proves only that rows exist, and a
row survives the remote database indefinitely. So every link found is opened
with ``SELECT 'X' FROM dual@<link>``, the cheapest statement that forces the
server to actually establish the remote session.

Safety
------
Three properties stop an enthusiastic link check from becoming the incident:

* **Nothing is interpolated unchecked.** Link names come from the data
  dictionary, but they are still matched against a strict pattern and quoted
  before they reach a statement.
* **Every probe is bounded.** ``call_timeout`` bounds one link and a
  wall-clock budget bounds the set, so a dead remote database costs a known
  number of seconds rather than the run.
* **A lost session stops the sweep.** When a cancelled call leaves the session
  unusable, the remaining links are reported as unchecked rather than as
  failures: a cascade of identical errors would bury the first real one.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from enum import StrEnum, unique
from logging import Logger
from typing import Any

from core.constants import (
    DEFAULT_DB_LINK_BUDGET_SECONDS,
    DEFAULT_DB_LINK_MAX_LINKS,
    DEFAULT_DB_LINK_TIMEOUT_SECONDS,
)
from core.exceptions import DatabaseLinkError
from core.logging_setup import get_logger
from models.interfaces import DbLinkScope
from utilities.timing import Stopwatch

__all__ = [
    "DatabaseLink",
    "DatabaseLinkProbe",
    "DatabaseLinkReport",
    "DbLinkStatus",
    "check_database_links",
    "list_database_links",
    "quote_link_name",
]

_logger = get_logger(__name__)

#: The connecting schema's own links. ``HOST`` holds the TNS alias or full
#: connect descriptor the server resolves, which is usually the field that
#: explains a failure.
_USER_LINK_QUERY = (
    "SELECT db_link, username, host, created FROM user_db_links ORDER BY db_link"
)

#: Every visible link, including public ones. ``ALL_DB_LINKS`` is granted to
#: PUBLIC on a standard database, so this needs no privilege beyond CREATE
#: SESSION.
_ALL_LINK_QUERY = (
    "SELECT owner, db_link, username, host, created "
    "FROM all_db_links ORDER BY owner, db_link"
)

#: The probe. ``dual`` is chosen because it exists in every schema on every
#: Oracle database, so a failure is always about the link and never about the
#: object the probe happened to name.
_PROBE_TEMPLATE = "SELECT 'X' FROM dual@{link}"

#: An unquoted Oracle identifier, optionally domain-qualified as links usually
#: are (``SALES_LINK.WORLD``). Anything matching this is safe to interpolate
#: verbatim; anything else is double-quoted, and anything containing a quote
#: character is refused outright rather than escaped.
_SAFE_LINK_NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_$#]*(?:\.[A-Za-z0-9_$#]+)*$")

#: Longest connect descriptor recorded per link. A full descriptor can run to
#: several hundred characters and would swamp the report.
_MAX_TARGET_LENGTH = 200

#: Longest remote error message recorded per link.
_MAX_LINK_MESSAGE = 300

#: ORA code to the sentence that turns it into an action. These are the codes
#: that appear on a link specifically, as opposed to on a local session: each
#: names something on the *remote* side or on the path to it.
_LINK_HINTS: dict[int, str] = {
    1017: (
        "ORA-01017: the remote database rejected the credentials stored in the link. "
        "The remote password was almost certainly rotated; the link must be recreated "
        "with the new one."
    ),
    1031: (
        "ORA-01031: the link connected but the remote account lacks privileges. Grants "
        "are commonly lost when the remote schema is refreshed from another environment."
    ),
    1035: "ORA-01035: the remote database is open in restricted mode.",
    2019: (
        "ORA-02019: the connect descriptor in the link does not resolve on the database "
        "server. Check tnsnames.ora on the server, not on this host."
    ),
    2068: (
        "ORA-02068: the remote database returned a fatal error through the link. The "
        "remote alert log is the place to look."
    ),
    2085: (
        "ORA-02085: the link name does not match the remote global name, which the "
        "remote database is enforcing because GLOBAL_NAMES is TRUE."
    ),
    3113: "ORA-03113: the remote session ended unexpectedly during the probe.",
    3135: (
        "ORA-03135: the connection through the link was lost, which typically means an "
        "idle timeout on a firewall between the two database servers."
    ),
    12154: (
        "ORA-12154: the TNS alias named by the link cannot be resolved by the database "
        "server. This is a server-side name resolution problem, not a client one."
    ),
    12170: (
        "ORA-12170: the remote listener did not answer within the timeout, which usually "
        "means a firewall between the two database servers is dropping the packets."
    ),
    12505: "ORA-12505: the remote listener does not know the SID named by the link.",
    12514: (
        "ORA-12514: the remote listener is running but the remote database has not "
        "registered the service the link asks for."
    ),
    12541: "ORA-12541: no listener is running on the remote database server.",
    12545: (
        "ORA-12545: the host named by the link does not exist as far as the database "
        "server is concerned."
    ),
    28000: "ORA-28000: the remote account used by the link is locked.",
    28001: "ORA-28001: the password of the remote account used by the link has expired.",
}


@unique
class DbLinkStatus(StrEnum):
    """Outcome of probing one database link."""

    OK = "OK"
    """``SELECT 'X' FROM dual@link`` returned a row."""

    FAILED = "FAILED"
    """The link exists but could not be opened, or was configured and is absent."""

    NOT_CHECKED = "NOT CHECKED"
    """The link was found but not probed. Never counted as a failure."""


@dataclass(frozen=True, slots=True)
class DatabaseLink:
    """One row of ``USER_DB_LINKS`` or ``ALL_DB_LINKS``."""

    name: str
    owner: str | None = None
    remote_user: str | None = None
    target: str | None = None
    created: str | None = None

    @property
    def display_name(self) -> str:
        """Return the name as an operator would write it, owner included."""
        return f"{self.owner}.{self.name}" if self.owner else self.name

    @property
    def is_public(self) -> bool:
        """Return whether this is a public link, usable by every session."""
        return (self.owner or "").upper() == "PUBLIC"


@dataclass(frozen=True, slots=True)
class DatabaseLinkProbe:
    """The verdict on one link."""

    link: DatabaseLink
    status: DbLinkStatus
    latency_ms: float | None = None
    ora_code: int | None = None
    message: str | None = None

    @property
    def is_failure(self) -> bool:
        """Return whether this probe counts against the interface."""
        return self.status is DbLinkStatus.FAILED

    def to_dict(self) -> dict[str, Any]:
        """Return the JSON-serialisable record carried into the reports."""
        payload: dict[str, Any] = {
            "name": self.link.display_name,
            "status": self.status.value,
            "remote_user": self.link.remote_user,
            "target": self.link.target,
        }
        if self.link.created:
            payload["created"] = self.link.created
        if self.latency_ms is not None:
            payload["latency_ms"] = round(self.latency_ms, 1)
        if self.ora_code is not None:
            payload["ora_code"] = self.ora_code
        if self.message:
            payload["message"] = self.message
        return payload

    def summary_line(self) -> str:
        """Return the one-line form used in compact report views."""
        if self.status is DbLinkStatus.OK:
            latency = f" ({self.latency_ms:.0f} ms)" if self.latency_ms is not None else ""
            return f"OK {self.link.display_name}{latency}"
        return f"{self.status.value} {self.link.display_name}: {self.message or '-'}"


@dataclass(slots=True)
class DatabaseLinkReport:
    """Everything one interface learned about its database links."""

    scope: DbLinkScope
    probes: list[DatabaseLinkProbe] = field(default_factory=list)
    found: int = 0
    truncated: int = 0
    budget_exhausted: bool = False
    session_lost: bool = False

    @property
    def failures(self) -> list[DatabaseLinkProbe]:
        """Return the probes that failed."""
        return [probe for probe in self.probes if probe.is_failure]

    @property
    def passed(self) -> list[DatabaseLinkProbe]:
        """Return the probes that succeeded."""
        return [probe for probe in self.probes if probe.status is DbLinkStatus.OK]

    @property
    def unchecked(self) -> list[DatabaseLinkProbe]:
        """Return the links that were found but not probed."""
        return [probe for probe in self.probes if probe.status is DbLinkStatus.NOT_CHECKED]

    def to_details(self) -> dict[str, Any]:
        """Return the evidence recorded on the validation result."""
        return {
            "db_link_scope": self.scope.value,
            "db_links_found": self.found,
            "db_links_ok": len(self.passed),
            "db_links_failed": len(self.failures),
            "db_links_unchecked": len(self.unchecked),
            "db_links": [probe.to_dict() for probe in self.probes],
        }

    def warnings(self) -> list[str]:
        """Return the non-fatal observations worth raising to an operator."""
        messages: list[str] = []
        if self.found == 0:
            messages.append(
                "Database link checking is enabled but this account owns no links. If it "
                "should own some, they were dropped -- a schema refresh from another "
                "environment is the usual reason."
            )
        if self.truncated:
            messages.append(
                f"{self.truncated} database link(s) were not probed because the "
                "configured maximum was reached. Raise 'db_link_max_links' to cover them."
            )
        if self.budget_exhausted:
            messages.append(
                "The database link time budget was exhausted before every link was "
                "probed. The unchecked links are listed in the report; a broken link "
                "consuming its full timeout is the usual cause."
            )
        if self.session_lost:
            messages.append(
                "The database session became unusable while probing links, so the "
                "remaining links were not checked. This follows a cancelled call that "
                "the driver could not recover."
            )
        for probe in self.unchecked:
            if probe.message:
                messages.append(f"Database link {probe.link.display_name}: {probe.message}")
        return messages

    def remediation(self) -> str:
        """Return the remediation text for a failing set of links."""
        hints = []
        for probe in self.failures:
            hint = _LINK_HINTS.get(probe.ora_code) if probe.ora_code is not None else None
            if hint and hint not in hints:
                hints.append(hint)
        if not hints:
            hints.append(
                "The database opened the session but could not open the link. The full "
                "remote error is recorded against each link in this report."
            )
        hints.append(
            "A database link is opened by the database server, so investigate the path "
            "from that server to the remote database, not from this host."
        )
        return " ".join(hints)


def quote_link_name(name: str) -> str:
    """Return ``name`` in a form safe to place in a statement.

    Link names are read from the data dictionary rather than supplied by an
    operator, which makes injection unlikely -- but "unlikely" is not a control.
    A name of the ordinary shape is used verbatim; anything else is quoted; a
    name containing a quote character is refused, because escaping it would be
    the one path where a mistake becomes an injected statement.

    Args:
        name: The link name as the data dictionary holds it.

    Returns:
        The name, quoted if it needs to be.

    Raises:
        ValueError: if the name cannot be represented safely.
    """
    candidate = name.strip()
    if not candidate:
        raise ValueError("A database link name cannot be empty.")
    if _SAFE_LINK_NAME.match(candidate):
        return candidate
    if '"' in candidate or "\n" in candidate or "\x00" in candidate:
        raise ValueError(
            f"Database link name {candidate!r} contains characters that cannot be "
            "quoted safely, so it was not probed."
        )
    return f'"{candidate}"'


def oracle_error_code(error: BaseException) -> int | None:
    """Return the numeric ORA/DPY code carried by a driver exception."""
    for argument in getattr(error, "args", ()):
        code = getattr(argument, "code", None)
        if isinstance(code, int):
            return code
    return None


def oracle_error_message(error: BaseException, *, limit: int = _MAX_LINK_MESSAGE) -> str:
    """Return a readable message from a driver exception."""
    for argument in getattr(error, "args", ()):
        message = getattr(argument, "message", None)
        if isinstance(message, str) and message:
            return message.strip()[:limit]
    return str(error).strip()[:limit]


def list_database_links(
    connection: Any, oracledb: Any, *, scope: DbLinkScope = DbLinkScope.USER
) -> list[DatabaseLink]:
    """Read the account's database links from the data dictionary.

    Args:
        connection: An open ``oracledb.Connection``.
        oracledb: The driver module, used for its exception type.
        scope: Which dictionary view to read.

    Returns:
        One :class:`DatabaseLink` per row, in dictionary order.

    Raises:
        DatabaseLinkError: if the view cannot be read.
    """
    query = _ALL_LINK_QUERY if scope is DbLinkScope.ALL else _USER_LINK_QUERY
    view = "ALL_DB_LINKS" if scope is DbLinkScope.ALL else "USER_DB_LINKS"

    try:
        with connection.cursor() as cursor:
            cursor.execute(query)
            rows = cursor.fetchall()
    except oracledb.Error as error:
        code = oracle_error_code(error)
        raise DatabaseLinkError(
            f"The database links could not be listed from {view}: "
            f"{oracle_error_message(error)}",
            remediation=(
                f"The session opened but {view} could not be read. On a standard database "
                "this view is granted to PUBLIC, so a refusal here usually means a "
                "hardened environment. Grant SELECT on the view, or switch "
                "'db_link_scope' to 'user', which needs no grant."
            ),
            details={"db_link_scope": scope.value, "view": view, "ora_code": code},
            cause=error,
        ) from error

    return [_row_to_link(row, scope=scope) for row in rows]


def check_database_links(
    connection: Any,
    oracledb: Any,
    *,
    scope: DbLinkScope = DbLinkScope.USER,
    names: Sequence[str] = (),
    session_user: str | None = None,
    per_link_timeout_seconds: int = DEFAULT_DB_LINK_TIMEOUT_SECONDS,
    budget_seconds: float = DEFAULT_DB_LINK_BUDGET_SECONDS,
    max_links: int = DEFAULT_DB_LINK_MAX_LINKS,
    logger: Logger | None = None,
) -> DatabaseLinkReport:
    """Enumerate the account's database links and open each one.

    Args:
        connection: An open ``oracledb.Connection``.
        oracledb: The driver module, used for its exception type.
        scope: Which dictionary view to enumerate from.
        names: Optional upper-cased link names to restrict the check to. A name
            listed here but absent from the dictionary is reported as a failure.
        session_user: The connected schema. Under ``ALL`` scope it decides which
            links this session can actually open; the rest are reported as
            present but unchecked instead of as false failures.
        per_link_timeout_seconds: Ceiling for one probe.
        budget_seconds: Wall-clock ceiling for the whole sweep.
        max_links: Most links probed on this interface.
        logger: Logger for progress; the module logger is used when omitted.

    Returns:
        A :class:`DatabaseLinkReport`. Individual link failures are recorded in
        it rather than raised, because a report naming which links broke is
        worth more than an exception naming the first.

    Raises:
        DatabaseLinkError: only if the links could not be enumerated at all.
    """
    log = logger or _logger
    links = list_database_links(connection, oracledb, scope=scope)
    report = DatabaseLinkReport(scope=scope, found=len(links))

    selected, missing = _select_links(links, names)
    if len(selected) > max_links:
        report.truncated = len(selected) - max_links
        selected = selected[:max_links]

    for name in missing:
        report.probes.append(
            DatabaseLinkProbe(
                link=DatabaseLink(name=name),
                status=DbLinkStatus.FAILED,
                message=(
                    "The link is named in the configuration but does not exist in "
                    f"{'ALL_DB_LINKS' if scope is DbLinkScope.ALL else 'USER_DB_LINKS'}."
                ),
            )
        )

    if not selected:
        return report

    log.info(
        "Probing %d database link(s) on the current session (scope %s).",
        len(selected),
        scope.value,
    )

    previous_timeout = _set_call_timeout(connection, per_link_timeout_seconds * 1000, log)
    elapsed = Stopwatch()
    try:
        for index, link in enumerate(selected):
            if report.session_lost:
                report.probes.append(_unchecked(link, "The database session was lost earlier."))
                continue
            if elapsed.elapsed_seconds >= budget_seconds:
                report.budget_exhausted = True
                report.probes.append(
                    _unchecked(link, "The database link time budget was already exhausted.")
                )
                continue

            probe = _probe_link(connection, oracledb, link, session_user=session_user, log=log)
            report.probes.append(probe)

            if probe.is_failure and not _session_is_usable(connection):
                report.session_lost = True
                log.warning(
                    "The session became unusable after probing %s; %d link(s) will not "
                    "be checked.",
                    link.display_name,
                    len(selected) - index - 1,
                )
    finally:
        _set_call_timeout(connection, previous_timeout, log)

    return report


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


def _row_to_link(row: Sequence[Any], *, scope: DbLinkScope) -> DatabaseLink:
    """Convert one dictionary row into a :class:`DatabaseLink`."""
    values = list(row)
    owner = str(values.pop(0)) if scope is DbLinkScope.ALL and values else None
    name = str(values[0]) if values else ""
    remote_user = _text(values[1]) if len(values) > 1 else None
    target = _text(values[2], limit=_MAX_TARGET_LENGTH) if len(values) > 2 else None
    created = _text(values[3]) if len(values) > 3 else None
    return DatabaseLink(
        name=name, owner=owner, remote_user=remote_user, target=target, created=created
    )


def _text(value: Any, *, limit: int = 120) -> str | None:
    """Return a trimmed string for a dictionary column, or ``None``."""
    if value is None:
        return None
    text = str(value).strip()
    return text[:limit] if text else None


def _select_links(
    links: Sequence[DatabaseLink], names: Sequence[str]
) -> tuple[list[DatabaseLink], list[str]]:
    """Return the links to probe, and any configured name that is absent."""
    if not names:
        return list(links), []

    wanted = {name.strip().upper() for name in names if name.strip()}
    selected = [link for link in links if link.name.upper() in wanted]
    present = {link.name.upper() for link in selected}
    return selected, sorted(wanted - present)


def _unchecked(link: DatabaseLink, reason: str) -> DatabaseLinkProbe:
    """Return a NOT CHECKED probe carrying its reason."""
    return DatabaseLinkProbe(link=link, status=DbLinkStatus.NOT_CHECKED, message=reason)


def _probe_link(
    connection: Any,
    oracledb: Any,
    link: DatabaseLink,
    *,
    session_user: str | None,
    log: Logger,
) -> DatabaseLinkProbe:
    """Open one link and return the verdict. Never raises."""
    if not _is_usable_by_session(link, session_user):
        return _unchecked(
            link,
            f"The link is private to {link.owner}, so this session cannot open it. "
            "Connect as that schema to validate it.",
        )

    try:
        quoted = quote_link_name(link.name)
    except ValueError as error:
        return _unchecked(link, str(error))

    statement = _PROBE_TEMPLATE.format(link=quoted)
    timer = Stopwatch()
    try:
        with connection.cursor() as cursor:
            cursor.execute(statement)
            cursor.fetchone()
    except oracledb.Error as error:
        timer.stop()
        code = oracle_error_code(error)
        log.warning("Database link %s failed: %s", link.display_name, oracle_error_message(error))
        return DatabaseLinkProbe(
            link=link,
            status=DbLinkStatus.FAILED,
            latency_ms=timer.elapsed_ms,
            ora_code=code,
            message=oracle_error_message(error),
        )
    except Exception as error:  # noqa: BLE001 - one link must not fail the sweep
        timer.stop()
        log.warning(
            "Database link %s raised an unclassified error: %s: %s",
            link.display_name,
            type(error).__name__,
            error,
        )
        return DatabaseLinkProbe(
            link=link,
            status=DbLinkStatus.FAILED,
            latency_ms=timer.elapsed_ms,
            message=f"{type(error).__name__}: {error}"[:_MAX_LINK_MESSAGE],
        )

    timer.stop()
    return DatabaseLinkProbe(
        link=link, status=DbLinkStatus.OK, latency_ms=timer.elapsed_ms
    )


def _is_usable_by_session(link: DatabaseLink, session_user: str | None) -> bool:
    """Return whether this session could open ``link`` at all.

    Under ``ALL`` scope the dictionary also lists links private to other
    schemas. This session cannot open those, and probing one would resolve to a
    different link or fail with an error about the wrong thing entirely -- a
    false failure that would send an operator after the wrong problem.
    """
    if not link.owner or link.is_public:
        return True
    if session_user is None:
        return True
    return link.owner.upper() == session_user.strip().upper()


def _set_call_timeout(connection: Any, milliseconds: int | None, log: Logger) -> int | None:
    """Set the session call timeout, returning the previous value.

    Best effort in both directions: an older driver may not expose the
    attribute, and a check that refuses to run because it cannot set a timeout
    would be worse than one that runs under the interface deadline alone.
    """
    previous = getattr(connection, "call_timeout", None)
    if milliseconds is None:
        return previous
    try:
        connection.call_timeout = int(milliseconds)
    except Exception as error:  # noqa: BLE001 - driver support varies
        log.debug(
            "The driver did not accept a call timeout, so link probes are bounded only "
            "by the interface deadline: %s: %s",
            type(error).__name__,
            error,
        )
    return previous


def _session_is_usable(connection: Any) -> bool:
    """Return whether the session survived the last failure.

    A cancelled call can leave python-oracledb holding a connection that is
    open in name only. Every subsequent link would then fail with the same
    misleading error, so the sweep stops instead.
    """
    is_healthy = getattr(connection, "is_healthy", None)
    if not callable(is_healthy):
        return True
    try:
        return bool(is_healthy())
    except Exception:  # noqa: BLE001 - an unanswerable session is a lost one
        return False
