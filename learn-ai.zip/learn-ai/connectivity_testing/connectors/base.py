"""The abstract base connector.

Contract
--------
:meth:`BaseConnector.validate` is a template method with one absolute
guarantee: **it always returns a** :class:`~models.results.ValidationResult`
**and never raises.** Whatever a driver does, including raising something the
framework has never seen, the interface is accounted for. A missing row in a
connectivity report is indistinguishable from a passing one to an engineer
reading it at 3 a.m., which makes silence the worst possible outcome.

Subclasses implement three hooks and nothing else:

===============  ==========================================================
``_open()``      Establish the connection and return a handle. Time spent
                 here becomes the reported *latency*.
``_probe()``     Prove the connection is usable: run the validation query,
                 list the directory, check the HTTP status. Returns evidence.
``_close()``     Release the handle. Best effort; failures here never fail
                 the interface, because the validation already succeeded.
===============  ==========================================================

Timing
------
Two numbers are recorded and they mean different things:

* **latency** is the duration of ``_open()`` alone, excluding retries. This is
  the number that moves when a network path changes.
* **duration** is the whole attempt sequence including retries, backoff and
  the probe. This is the number a scheduler slot is budgeted against.

Retries
-------
Only errors marked ``retryable`` are re-attempted, which by design excludes
authentication failures: repeating a rejected credential is the fastest route
to an account lockout.
"""

from __future__ import annotations

import time
import traceback
from abc import ABC, abstractmethod
from collections.abc import Mapping
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturesTimeoutError
from typing import Any, ClassVar, Generic, TypeVar

from connectors.support import backoff_delays
from core.constants import InterfaceType, ValidationStatus
from core.exceptions import ConnectivityTimeoutError, ConnectorError, DecryptionError
from core.logging_setup import get_logger
from models.interfaces import BaseInterfaceConfig
from models.results import ValidationResult
from models.settings import ExecutionSettings
from utilities.timing import Stopwatch, utc_now

__all__ = ["BaseConnector", "InterfaceT"]

#: The interface model a connector validates. Parameterising the base class on
#: it means a connector reads its own configuration fields with full type
#: checking, instead of casting or reaching through ``getattr``.
InterfaceT = TypeVar("InterfaceT", bound=BaseInterfaceConfig)


class BaseConnector(ABC, Generic[InterfaceT]):
    """Base class for every connectivity connector.

    Attributes:
        interface_type: The connectivity type this connector validates.
            Declared by each subclass and used by the factory registry.
        driver_packages: Distribution names imported by this connector.
            Informational; the actual import happens lazily in ``_open``.
    """

    interface_type: ClassVar[InterfaceType]
    driver_packages: ClassVar[tuple[str, ...]] = ()

    def __init__(
        self,
        interface: InterfaceT,
        secrets: Mapping[str, str | None],
        execution: ExecutionSettings,
    ) -> None:
        """Initialise the connector.

        Args:
            interface: The validated interface configuration.
            secrets: Field name to plaintext, already resolved by the caller.
                Connectors never decrypt: keeping resolution in the engine
                means a key problem is reported once, against the run, rather
                than as an unrelated-looking failure on each interface.
            execution: Engine-level execution settings.
        """
        self.interface: InterfaceT = interface
        self.secrets = dict(secrets)
        self.execution = execution
        self.logger = get_logger(f"connectors.{self.interface_type.value.lower()}")
        self._warnings: list[str] = []
        self._last_latency_ms: float | None = None

    # ------------------------------------------------------------------
    # Subclass hooks
    # ------------------------------------------------------------------

    @abstractmethod
    def _open(self) -> Any:
        """Establish the connection and return a driver handle.

        Implementations must raise a :class:`~core.exceptions.ConnectorError`
        subclass, normally by passing the driver's exception through
        :func:`~connectors.support.classify_transport_error`.

        Returns:
            A handle passed unchanged to :meth:`_probe` and :meth:`_close`.
        """

    @abstractmethod
    def _probe(self, handle: Any) -> dict[str, Any]:
        """Prove the established connection is actually usable.

        Connecting is not the same as working. A TCP session to an Oracle
        listener proves nothing about whether the service is mounted, and an
        HTTP 200 from a load balancer proves nothing about the application
        behind it. The probe is what closes that gap.

        Args:
            handle: The value returned by :meth:`_open`.

        Returns:
            Evidence to record on the result, such as the negotiated cipher,
            the server banner or the row the validation query returned. Keys
            appear verbatim in the JSON report, so they must not hold secrets.
        """

    def _close(self, handle: Any) -> None:
        """Release the connection. Best effort.

        The default implementation calls ``close()`` when the handle exposes
        one. Errors are logged and swallowed: the validation verdict has
        already been decided, and failing an interface because the teardown
        was untidy would be a false negative.
        """
        if handle is None:
            return
        close = getattr(handle, "close", None)
        if callable(close):
            try:
                close()
            except Exception as error:  # noqa: BLE001 - teardown must not fail a run
                self.logger.debug(
                    "Ignoring error while closing the connection to %s: %s: %s",
                    self.interface.endpoint,
                    type(error).__name__,
                    error,
                )

    # ------------------------------------------------------------------
    # Helpers for subclasses
    # ------------------------------------------------------------------

    def secret(self, field_name: str) -> str | None:
        """Return a resolved secret, or ``None`` when it is not configured."""
        return self.secrets.get(field_name)

    def add_warning(self, message: str) -> None:
        """Record a non-fatal observation about this interface.

        Warnings appear in the report and, when ``fail_on_warning`` is set,
        turn a passing interface into a failure.
        """
        self.logger.warning(message)
        self._warnings.append(message)

    @property
    def timeout(self) -> int:
        """Return the configured per-attempt timeout in seconds."""
        return self.interface.timeout_seconds

    @property
    def deadline_seconds(self) -> float:
        """Return the hard ceiling for one attempt, in seconds.

        This is a *backstop*, not the primary timeout. Every driver is given
        its own timeout first, because a driver's own error message is far
        more specific than "deadline exceeded". The margin here is deliberately
        generous so that in normal operation the driver always wins the race
        and the watchdog never fires.

        It exists because not every driver honours its own timeout. python-
        oracledb's ``tcp_connect_timeout`` bounds the TCP connect but not the
        protocol handshake that follows, so an endpoint that accepts the
        connection and then never speaks -- precisely what a half-open
        firewall rule produces -- will otherwise block forever. Without this
        ceiling a single such endpoint hangs the entire scheduled run.
        """
        return float(self.timeout) * 2 + 10.0

    @property
    def retry_count(self) -> int:
        """Return the retry count configured for this interface.

        Only the REST connector currently exposes retries in configuration;
        every other type reports the first outcome, because a connectivity
        check that silently retries hides intermittency that an operator needs
        to see.
        """
        return int(getattr(self.interface, "retry_count", 0))

    # ------------------------------------------------------------------
    # Template method
    # ------------------------------------------------------------------

    def validate(self) -> ValidationResult:
        """Validate the interface. Never raises.

        Returns:
            A fully populated :class:`~models.results.ValidationResult`.
        """
        result = self._new_result()
        total = Stopwatch()
        attempt = 0
        last_error: ConnectorError | None = None

        delays = [0.0, *backoff_delays(self.retry_count)]

        for delay in delays:
            if delay:
                self.logger.info(
                    "Retrying %s in %.1f seconds (attempt %d of %d).",
                    self.interface.name,
                    delay,
                    attempt + 1,
                    len(delays),
                )
                time.sleep(delay)

            attempt += 1
            try:
                latency_ms, evidence = self._run_attempt_with_deadline()
                result.latency_ms = latency_ms

                result.status = ValidationStatus.SUCCESS
                result.details.update(evidence)
                last_error = None
                break

            except ConnectorError as error:
                last_error = error
                self.logger.warning(
                    "Attempt %d for %s failed: %s", attempt, self.interface.name, error.message
                )
                if not error.retryable or attempt > self.retry_count:
                    break

            except DecryptionError as error:
                # A secret that could not be unlocked is a configuration fault,
                # not a connectivity fault. Retrying cannot help.
                last_error = ConnectorError(
                    error.message,
                    remediation=error.remediation,
                    details=error.details,
                    cause=error,
                )
                last_error.error_code = error.error_code
                break

            except Exception as error:  # noqa: BLE001 - the guarantee lives here
                last_error = ConnectorError(
                    f"Unexpected {type(error).__name__} while validating "
                    f"{self.interface.name}: {error}",
                    remediation=(
                        "This is an unclassified fault. The full stack trace is in the JSON "
                        "report and the debug log. Treat the interface as unverified."
                    ),
                    details={"endpoint": self.interface.endpoint},
                    cause=error,
                )
                last_error.error_code = "UNEXPECTED_ERROR"
                break

        total.stop()
        result.attempts = attempt
        result.ended_at = total.ended_at or utc_now()
        result.duration_seconds = total.elapsed_seconds
        if result.latency_ms is None:
            result.latency_ms = self._last_latency_ms

        if last_error is not None:
            self._apply_error(result, last_error)

        for warning in self._warnings:
            result.add_warning(warning)

        if (
            result.status is ValidationStatus.SUCCESS
            and result.warnings
            and self.execution.fail_on_warning
        ):
            result.status = ValidationStatus.FAILED
            result.error_code = "WARNING_ESCALATED"
            result.error_message = (
                "Validation succeeded but raised warnings, and this deployment treats "
                "warnings as failures: " + "; ".join(result.warnings)
            )
            result.remediation = (
                "Resolve the warnings above, or set execution.fail_on_warning to false."
            )

        # Everything above assigns to the result after construction: driver
        # error text, probe evidence and stack traces. Redaction is re-applied
        # here so that no credential can reach a report through those paths.
        result.redact()

        self._log_outcome(result)
        return result

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _attempt(self) -> tuple[float, dict[str, Any]]:
        """Perform one open-probe-close cycle.

        Returns:
            The connect latency in milliseconds, and the probe evidence.
        """
        handle: Any = None
        try:
            connect_timer = Stopwatch()
            handle = self._open()
            connect_timer.stop()

            # Recorded on the instance as well as returned, so that a probe
            # failure still reports how long the connection itself took. That
            # number is what separates "the network is fine, the permissions
            # are wrong" from "the network is slow".
            self._last_latency_ms = connect_timer.elapsed_ms

            self.logger.debug(
                "Connected to %s in %.0f ms; running probe.",
                self.interface.endpoint,
                connect_timer.elapsed_ms,
            )
            evidence = self._probe(handle) or {}
            return connect_timer.elapsed_ms, evidence
        finally:
            self._safe_close(handle)

    def _run_attempt_with_deadline(self) -> tuple[float, dict[str, Any]]:
        """Run one attempt under a hard deadline.

        The attempt executes on a worker thread so that a driver ignoring its
        own timeout cannot block the run. If the deadline expires the worker is
        abandoned rather than killed, because Python cannot safely interrupt a
        thread blocked in a C extension. The thread is a daemon and dies with
        the process; the run continues and the interface is reported as timed
        out, which is the correct verdict either way.

        Raises:
            ConnectivityTimeoutError: if the deadline expires.
            ConnectorError: whatever the attempt itself raised, unchanged, so
                driver-specific classification is preserved.
        """
        executor = ThreadPoolExecutor(
            max_workers=1, thread_name_prefix=f"probe-{self.interface.name[:24]}"
        )
        try:
            future = executor.submit(self._attempt)
            try:
                return future.result(timeout=self.deadline_seconds)
            except FuturesTimeoutError as error:
                raise ConnectivityTimeoutError(
                    f"{self.interface.name} exceeded its hard deadline of "
                    f"{self.deadline_seconds:.0f} seconds against "
                    f"{self.interface.endpoint}.",
                    remediation=(
                        "The endpoint accepted the connection and then stopped responding, "
                        "and the driver did not honour its own timeout. A half-open "
                        "firewall rule, which permits the TCP handshake but drops the "
                        "traffic that follows, produces exactly this behaviour. Verify the "
                        "rule covers the full session, not only the initial connection."
                    ),
                    details={
                        "endpoint": self.interface.endpoint,
                        "deadline_seconds": self.deadline_seconds,
                        "configured_timeout_seconds": self.timeout,
                    },
                    cause=error,
                ) from error
        finally:
            # Never wait: the point of the deadline is that the worker may
            # still be blocked, and shutdown(wait=True) would re-introduce the
            # hang this method exists to prevent.
            executor.shutdown(wait=False)

    def _safe_close(self, handle: Any) -> None:
        """Call :meth:`_close` without letting teardown break the contract.

        The default :meth:`_close` already guards the driver's ``close()``,
        but a subclass may legitimately override the whole method. Guarding at
        the call site is what actually enforces "validate never raises":
        without it, a teardown fault would escape from the ``finally`` block
        and lose the result that had already been determined.
        """
        try:
            self._close(handle)
        except Exception as error:  # noqa: BLE001 - teardown must never escape
            self.logger.debug(
                "Ignoring error while releasing the connection for %s: %s: %s",
                self.interface.name,
                type(error).__name__,
                error,
            )

    def _new_result(self) -> ValidationResult:
        """Return a result pre-populated with this interface's identity."""
        return ValidationResult(
            interface_name=self.interface.name,
            interface_type=self.interface.interface_type,
            category=self.interface.category,
            status=ValidationStatus.FAILED,
            host=self.interface.display_host,
            port=self.interface.display_port,
            endpoint=self.interface.endpoint,
            auth_method=self.interface.auth_method,
            started_at=utc_now(),
            tags=list(self.interface.tags),
        )

    def _apply_error(self, result: ValidationResult, error: ConnectorError) -> None:
        """Copy an error's diagnostic payload onto the result."""
        result.status = ValidationStatus.FAILED
        result.error_message = error.message
        result.error_code = error.error_code
        result.remediation = error.remediation
        result.exception_type = type(error.cause).__name__ if error.cause else type(error).__name__
        result.exception_details = str(error.cause) if error.cause else error.message

        source = error.cause if error.cause is not None else error
        if source.__traceback__ is not None:
            result.stack_trace = "".join(
                traceback.format_exception(type(source), source, source.__traceback__)
            )

        for key, value in error.details.items():
            result.details.setdefault(key, value)

    def _log_outcome(self, result: ValidationResult) -> None:
        """Emit the one-line outcome for this interface."""
        if result.is_success:
            self.logger.info(
                "%s: SUCCESS in %s (latency %s)",
                result.interface_name,
                result.duration_display,
                result.latency_display,
            )
            return

        self.logger.error(
            "%s: FAILED after %s [%s] %s",
            result.interface_name,
            result.duration_display,
            result.error_code,
            result.error_message,
        )
        if result.remediation:
            self.logger.error("%s: remediation: %s", result.interface_name, result.remediation)

    def describe(self) -> str:
        """Return a short identification string for logs."""
        return (
            f"{self.interface.interface_type.value} '{self.interface.name}' "
            f"-> {self.interface.endpoint}"
        )

    def __repr__(self) -> str:  # pragma: no cover - diagnostic aid
        return f"<{type(self).__name__} {self.describe()}>"
