"""Cloud connectors: Azure Blob Storage and Amazon S3.

Both SDKs bring their own retry machinery, and both are configured here to
**stop retrying**. That is deliberate. This framework owns the retry policy,
and a hidden SDK retry loop would do three unwanted things: multiply the
configured timeout by the SDK's attempt count so a single interface can
overrun its scheduler window, mask exactly the intermittency an operator needs
to see after a change, and re-present a rejected credential several times.

Probe depth
-----------
Listing at account level proves the credential works. Naming a container or
bucket proves the credential is *authorised for the thing the batch job
actually uses*, which is a materially stronger statement and the one worth
making after a permissions change. Both connectors therefore prefer the
narrower probe whenever the configuration names a target.
"""

from __future__ import annotations

from typing import Any, ClassVar

from connectors.base import BaseConnector
from connectors.factory import register
from connectors.support import require_driver
from core.constants import InterfaceType
from core.exceptions import (
    AuthenticationError,
    CertificateValidationError,
    ConnectionFailedError,
    ConnectivityTimeoutError,
    ConnectorError,
    ValidationProbeError,
)
from models.interfaces import (
    AwsAuthMethod,
    AwsS3InterfaceConfig,
    AzureAuthMethod,
    AzureBlobInterfaceConfig,
)

__all__ = ["AwsS3Connector", "AzureBlobConnector"]

#: Containers, buckets or object keys listed by a probe. Enough to prove the
#: listing works; this is a connectivity check, not an inventory.
_MAX_LISTED_ITEMS = 10


# ---------------------------------------------------------------------------
# Azure Blob Storage
# ---------------------------------------------------------------------------


@register
class AzureBlobConnector(BaseConnector[AzureBlobInterfaceConfig]):
    """Validates an Azure Blob Storage endpoint.

    Managed identity deserves particular care. It is the preferred credential
    inside Azure and is simply unavailable outside it, so the same
    configuration that passes on an Azure VM fails on an on-premises jump host
    with an error that reads like a network fault. That case is detected and
    named explicitly.
    """

    interface_type: ClassVar[InterfaceType] = InterfaceType.AZURE_BLOB
    driver_packages: ClassVar[tuple[str, ...]] = ("azure-storage-blob", "azure-identity")

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._azure_exceptions: Any = None
        self._credential: Any = None

    def _open(self) -> Any:
        """Build an authenticated ``BlobServiceClient``.

        Returns:
            A configured client. Azure clients are lazy, so the first network
            call happens in the probe; connect latency therefore measures
            credential acquisition, which for a service principal is a real
            round trip to Entra ID.
        """
        blob_module = require_driver(
            "azure-storage-blob", self.interface_type, module_name="azure.storage.blob"
        )
        self._azure_exceptions = require_driver(
            "azure-core", self.interface_type, module_name="azure.core.exceptions"
        )
        interface = self.interface

        if not interface.verify_ssl:
            self.add_warning(
                "TLS certificate verification is disabled for this interface, so an "
                "expired or mis-issued certificate cannot be detected."
            )

        common: dict[str, Any] = {
            "connection_timeout": self.timeout,
            "read_timeout": self.timeout,
            # The framework owns retries; see the module docstring.
            "retry_total": 0,
            "connection_verify": interface.verify_ssl,
        }

        try:
            if interface.auth_method_type is AzureAuthMethod.CONNECTION_STRING:
                return blob_module.BlobServiceClient.from_connection_string(
                    self.secret("connection_string") or "", **common
                )

            self._credential = self._build_credential()
            return blob_module.BlobServiceClient(
                account_url=interface.account_url or "",
                credential=self._credential,
                **common,
            )
        except ValueError as error:
            # Raised for a malformed connection string or account URL before
            # any network call is made.
            raise ConnectorError(
                f"The Azure client could not be built for '{interface.name}': {error}",
                remediation=(
                    "Check the account URL and the connection string. Re-run "
                    "'python generate_config.py' to re-enter the credential."
                ),
                details={"auth_method": interface.auth_method_type.value},
                cause=error,
            ) from error
        except Exception as error:  # noqa: BLE001 - SDK raises varied types
            raise self._classify_azure_error(error, operation="client construction") from error

    def _build_credential(self) -> Any:
        """Return the credential object for the configured authentication."""
        identity = require_driver(
            "azure-identity", self.interface_type, module_name="azure.identity"
        )
        interface = self.interface

        if interface.auth_method_type is AzureAuthMethod.SERVICE_PRINCIPAL:
            return identity.ClientSecretCredential(
                tenant_id=interface.tenant_id or "",
                client_id=interface.client_id or "",
                client_secret=self.secret("client_secret") or "",
            )

        # Managed identity: a user-assigned identity needs its client id; the
        # system-assigned identity takes none.
        if interface.client_id:
            return identity.ManagedIdentityCredential(client_id=interface.client_id)
        return identity.ManagedIdentityCredential()

    def _probe(self, handle: Any) -> dict[str, Any]:
        """Read container properties, or list containers at account level."""
        interface = self.interface
        details: dict[str, Any] = {
            "account_url": getattr(handle, "url", interface.account_url),
            "account_name": getattr(handle, "account_name", None),
            "auth_method": interface.auth_method_type.value,
        }

        try:
            details.update(self._execute_probe(handle))
        except Exception as error:  # noqa: BLE001 - SDK raises varied types
            raise self._classify_azure_error(
                error, operation="blob storage probe", details=details
            ) from error
        return details

    def _execute_probe(self, handle: Any) -> dict[str, Any]:
        """Perform the Azure probe and return the evidence gathered."""
        interface = self.interface

        if interface.container_name:
            container = handle.get_container_client(interface.container_name)
            properties = container.get_container_properties(timeout=self.timeout)
            evidence: dict[str, Any] = {
                "container": interface.container_name,
                "container_last_modified": str(getattr(properties, "last_modified", "")),
                "container_etag": str(getattr(properties, "etag", "")),
                "probe": "container properties",
            }
            lease = getattr(properties, "lease", None)
            if lease is not None:
                evidence["container_lease_state"] = str(getattr(lease, "state", ""))
            return evidence

        names: list[str] = []
        for container_item in handle.list_containers(
            results_per_page=_MAX_LISTED_ITEMS, timeout=self.timeout
        ):
            names.append(container_item.name)
            if len(names) >= _MAX_LISTED_ITEMS:
                break

        self.add_warning(
            "No container is configured, so this interface only proves the credential "
            "reaches the storage account. Naming the container the batch job uses "
            "would also prove it is authorised for it."
        )
        return {
            "probe": "account container listing",
            "container_count_sampled": len(names),
            "containers_sample": names,
        }

    def _close(self, handle: Any) -> None:
        """Close the client and any credential that holds a session."""
        super()._close(handle)
        if self._credential is not None:
            close = getattr(self._credential, "close", None)
            if callable(close):
                try:
                    close()
                except Exception as error:  # noqa: BLE001 - teardown only
                    self.logger.debug("Ignoring credential close error: %s", error)
            self._credential = None

    def _classify_azure_error(
        self, error: BaseException, *, operation: str, details: dict[str, Any] | None = None
    ) -> ConnectorError:
        """Map an Azure SDK exception onto the framework hierarchy."""
        interface = self.interface
        exceptions = self._azure_exceptions
        context = dict(details or {})
        context["auth_method"] = interface.auth_method_type.value
        message = str(error).strip().splitlines()[0][:400] if str(error) else type(error).__name__
        lowered = str(error).lower()

        status_code = getattr(error, "status_code", None)
        if status_code is not None:
            context["http_status"] = status_code

        # Managed identity outside Azure is the single most common
        # configuration surprise, and its error text reads like a timeout.
        if "managedidentitycredential" in lowered or "credentialunavailable" in lowered or (
            exceptions is not None
            and isinstance(error, getattr(exceptions, "ClientAuthenticationError", ()))
            and interface.auth_method_type is AzureAuthMethod.MANAGED_IDENTITY
        ):
            return AuthenticationError(
                f"Managed identity is not available on this host: {message}",
                remediation=(
                    "Managed identity only exists inside Azure. If this job runs on-premises "
                    "or on another cloud, switch the interface to a service principal or a "
                    "connection string. If it does run in Azure, confirm the identity is "
                    "assigned to this resource."
                ),
                details=context,
                cause=error,
            )

        if exceptions is not None:
            if isinstance(error, getattr(exceptions, "ClientAuthenticationError", ())):
                return AuthenticationError(
                    f"Azure rejected the credential for '{interface.name}': {message}",
                    remediation=(
                        "Verify the credential. A service principal secret that expired, or "
                        "a storage account key rotated during the change window, both "
                        "present exactly this way."
                    ),
                    details=context,
                    cause=error,
                )

            if isinstance(error, getattr(exceptions, "ResourceNotFoundError", ())):
                return ValidationProbeError(
                    f"The container '{interface.container_name}' does not exist in this "
                    f"storage account: {message}",
                    remediation=(
                        "Check the container name and that the interface points at the "
                        "correct storage account."
                    ),
                    details=context,
                    cause=error,
                )

            if isinstance(error, getattr(exceptions, "ServiceRequestError", ())):
                if "certificate" in lowered or "ssl" in lowered:
                    return CertificateValidationError(
                        f"TLS negotiation with Azure Storage failed: {message}",
                        remediation=(
                            "The certificate chain is not trusted by this host. A TLS "
                            "inspecting proxy re-signs traffic and must have its authority "
                            "installed in the host trust store."
                        ),
                        details=context,
                        cause=error,
                    )
                if "timed out" in lowered or "timeout" in lowered:
                    return ConnectivityTimeoutError(
                        f"The request to Azure Storage timed out after {self.timeout} "
                        f"seconds: {message}",
                        remediation=(
                            "No response within the timeout. Check egress rules and any "
                            "proxy on the path; blob endpoints are frequently missed when "
                            "an allow-list is rebuilt."
                        ),
                        details=context,
                        cause=error,
                    )
                return ConnectionFailedError(
                    f"Azure Storage could not be reached: {message}",
                    remediation=(
                        "Check DNS resolution for the storage endpoint and outbound access "
                        "on port 443, including any proxy configuration."
                    ),
                    details=context,
                    cause=error,
                )

        if status_code == 403:
            return AuthenticationError(
                f"Azure returned 403 Forbidden for '{interface.name}': {message}",
                remediation=(
                    "The credential is valid but not authorised for this container. Check "
                    "the role assignment, and whether a storage firewall or private "
                    "endpoint policy excludes this host's source address."
                ),
                details=context,
                cause=error,
            )
        if status_code == 404:
            return ValidationProbeError(
                f"Azure returned 404 Not Found for '{interface.name}': {message}",
                remediation="Check the storage account URL and the container name.",
                details=context,
                cause=error,
            )

        return ConnectionFailedError(
            f"Azure Blob Storage {operation} failed for '{interface.name}': {message}",
            remediation=(
                "The SDK reported an error the framework does not classify specifically. "
                "The full exception is recorded in the JSON report and the debug log."
            ),
            details=context,
            cause=error,
        )


# ---------------------------------------------------------------------------
# Amazon S3
# ---------------------------------------------------------------------------

#: botocore error codes that mean the credential itself was rejected.
_S3_CREDENTIAL_CODES = frozenset(
    {
        "InvalidAccessKeyId",
        "SignatureDoesNotMatch",
        "InvalidToken",
        "ExpiredToken",
        "TokenRefreshRequired",
        "InvalidClientTokenId",
        "UnrecognizedClientException",
        "AuthFailure",
    }
)

#: botocore error codes that mean the target does not exist.
_S3_NOT_FOUND_CODES = frozenset({"NoSuchBucket", "NoSuchKey", "404", "NotFound"})


@register
class AwsS3Connector(BaseConnector[AwsS3InterfaceConfig]):
    """Validates an Amazon S3 endpoint, or an S3-compatible object store.

    ``endpoint_url`` covers on-premises object stores, which behave identically
    for connectivity purposes and are common in enterprise estates.
    """

    interface_type: ClassVar[InterfaceType] = InterfaceType.AWS_S3
    driver_packages: ClassVar[tuple[str, ...]] = ("boto3",)

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._botocore_exceptions: Any = None

    def _open(self) -> Any:
        """Build an S3 client and resolve credentials.

        Returns:
            A configured ``boto3`` S3 client.
        """
        boto3 = require_driver("boto3", self.interface_type)
        botocore_config = require_driver(
            "botocore", self.interface_type, module_name="botocore.config"
        )
        self._botocore_exceptions = require_driver(
            "botocore", self.interface_type, module_name="botocore.exceptions"
        )
        interface = self.interface

        if not interface.verify_ssl:
            self.add_warning(
                "TLS certificate verification is disabled for this interface, so an "
                "expired or mis-issued certificate cannot be detected."
            )

        try:
            session = self._build_session(boto3)
            configuration = botocore_config.Config(
                connect_timeout=self.timeout,
                read_timeout=self.timeout,
                # The framework owns retries; botocore's default would
                # multiply the timeout by its own attempt count.
                retries={"max_attempts": 0, "mode": "standard"},
                signature_version="s3v4",
            )
            return session.client(
                "s3",
                region_name=interface.region,
                endpoint_url=interface.endpoint_url,
                verify=interface.verify_ssl,
                config=configuration,
            )
        except Exception as error:  # noqa: BLE001 - SDK raises varied types
            raise self._classify_s3_error(error, operation="client construction") from error

    def _build_session(self, boto3: Any) -> Any:
        """Return a boto3 session for the configured authentication."""
        interface = self.interface

        if interface.auth_method_type is AwsAuthMethod.ACCESS_KEY:
            session = boto3.session.Session(
                aws_access_key_id=interface.access_key_id,
                aws_secret_access_key=self.secret("secret_access_key"),
                aws_session_token=self.secret("session_token"),
                region_name=interface.region,
            )
        else:
            session = boto3.session.Session(
                profile_name=interface.profile_name or None,
                region_name=interface.region,
            )

        if interface.role_arn:
            session = self._assume_role(boto3, session)
        return session

    def _assume_role(self, boto3: Any, session: Any) -> Any:
        """Return a session for the assumed role.

        Raises:
            AuthenticationError: when the role cannot be assumed.
        """
        interface = self.interface
        try:
            sts = session.client("sts", region_name=interface.region)
            assumed = sts.assume_role(
                RoleArn=interface.role_arn,
                RoleSessionName=f"connectivity-validation-{interface.name[:32]}".replace(
                    " ", "-"
                ),
            )
            credentials = assumed["Credentials"]
        except Exception as error:  # noqa: BLE001 - SDK raises varied types
            raise AuthenticationError(
                f"The role '{interface.role_arn}' could not be assumed: {error}",
                remediation=(
                    "Check the role ARN, and that the base credential is permitted to "
                    "assume it. The role's trust policy must name this principal."
                ),
                details={"role_arn": interface.role_arn},
                cause=error,
            ) from error

        return boto3.session.Session(
            aws_access_key_id=credentials["AccessKeyId"],
            aws_secret_access_key=credentials["SecretAccessKey"],
            aws_session_token=credentials["SessionToken"],
            region_name=interface.region,
        )

    def _probe(self, handle: Any) -> dict[str, Any]:
        """Head the configured bucket, or list buckets at account level."""
        interface = self.interface
        details: dict[str, Any] = {
            "region": interface.region,
            "auth_method": interface.auth_method_type.value,
            "endpoint": interface.endpoint,
        }
        if interface.role_arn:
            details["assumed_role"] = interface.role_arn

        try:
            details.update(self._execute_probe(handle))
        except Exception as error:  # noqa: BLE001 - SDK raises varied types
            raise self._classify_s3_error(
                error, operation="S3 probe", details=details
            ) from error
        return details

    def _execute_probe(self, handle: Any) -> dict[str, Any]:
        """Perform the S3 probe and return the evidence gathered."""
        interface = self.interface

        if interface.bucket_name:
            handle.head_bucket(Bucket=interface.bucket_name)
            evidence: dict[str, Any] = {
                "bucket": interface.bucket_name,
                "probe": "bucket metadata",
            }
            if interface.prefix:
                listing = handle.list_objects_v2(
                    Bucket=interface.bucket_name,
                    Prefix=interface.prefix,
                    MaxKeys=_MAX_LISTED_ITEMS,
                )
                keys = [item["Key"] for item in listing.get("Contents", [])]
                evidence["prefix"] = interface.prefix
                evidence["object_count_sampled"] = len(keys)
                evidence["objects_sample"] = keys
                evidence["probe"] = "bucket metadata and prefix listing"
            return evidence

        response = handle.list_buckets()
        names = [bucket["Name"] for bucket in response.get("Buckets", [])]
        evidence = {
            "probe": "account bucket listing",
            "bucket_count": len(names),
            "buckets_sample": names[:_MAX_LISTED_ITEMS],
        }
        owner = response.get("Owner", {})
        if owner.get("DisplayName"):
            evidence["account_owner"] = owner["DisplayName"]

        self.add_warning(
            "No bucket is configured, so this interface only proves the credential "
            "reaches S3. Naming the bucket the batch job uses would also prove it is "
            "authorised for it."
        )
        return evidence

    def _classify_s3_error(
        self, error: BaseException, *, operation: str, details: dict[str, Any] | None = None
    ) -> ConnectorError:
        """Map a botocore exception onto the framework hierarchy."""
        interface = self.interface
        exceptions = self._botocore_exceptions
        context = dict(details or {})
        message = str(error).strip().splitlines()[0][:400] if str(error) else type(error).__name__
        lowered = str(error).lower()

        if exceptions is not None:
            no_credentials = (
                getattr(exceptions, "NoCredentialsError", ()),
                getattr(exceptions, "PartialCredentialsError", ()),
            )
            if isinstance(error, no_credentials):
                return AuthenticationError(
                    f"No AWS credentials could be resolved for '{interface.name}': {message}",
                    remediation=(
                        "The credential chain found nothing. An instance profile only "
                        "exists on EC2 or EKS, so a configuration that works there fails "
                        "on an on-premises host. Configure an access key, or a named "
                        "profile available to the account that runs the job."
                    ),
                    details=context,
                    cause=error,
                )

            if isinstance(error, getattr(exceptions, "ProfileNotFound", ())):
                return ConnectorError(
                    f"The AWS profile '{interface.profile_name}' does not exist on this "
                    f"host: {message}",
                    remediation=(
                        "Create the profile in the shared AWS credentials file for the "
                        "account that runs the job. Under a scheduler that is usually a "
                        "service account with its own home directory."
                    ),
                    details=context,
                    cause=error,
                )

            if isinstance(error, getattr(exceptions, "EndpointConnectionError", ())):
                return ConnectionFailedError(
                    f"The S3 endpoint could not be reached: {message}",
                    remediation=(
                        "Check DNS resolution for the endpoint and outbound access on port "
                        "443. For a VPC endpoint, confirm the route and its policy."
                    ),
                    details=context,
                    cause=error,
                )

            timeouts = (
                getattr(exceptions, "ConnectTimeoutError", ()),
                getattr(exceptions, "ReadTimeoutError", ()),
            )
            if isinstance(error, timeouts):
                return ConnectivityTimeoutError(
                    f"The S3 request timed out after {self.timeout} seconds: {message}",
                    remediation=(
                        "No response within the timeout, which usually means traffic is "
                        "being dropped rather than rejected. Check egress rules and any "
                        "proxy on the path."
                    ),
                    details=context,
                    cause=error,
                )

            if isinstance(error, getattr(exceptions, "SSLError", ())):
                return CertificateValidationError(
                    f"TLS negotiation with the S3 endpoint failed: {message}",
                    remediation=(
                        "The certificate chain is not trusted by this host. A TLS "
                        "inspecting proxy re-signs traffic and must have its authority "
                        "installed in the host trust store."
                    ),
                    details=context,
                    cause=error,
                )

            client_error = getattr(exceptions, "ClientError", None)
            if client_error is not None and isinstance(error, client_error):
                return self._classify_client_error(error, context)

        if "certificate" in lowered or "ssl" in lowered:
            return CertificateValidationError(
                f"TLS negotiation with the S3 endpoint failed: {message}",
                remediation="Install the issuing authority into this host's trust store.",
                details=context,
                cause=error,
            )

        return ConnectionFailedError(
            f"S3 {operation} failed for '{interface.name}': {message}",
            remediation=(
                "The SDK reported an error the framework does not classify specifically. "
                "The full exception is recorded in the JSON report and the debug log."
            ),
            details=context,
            cause=error,
        )

    def _classify_client_error(self, error: Any, context: dict[str, Any]) -> ConnectorError:
        """Classify a botocore ``ClientError`` by its S3 error code."""
        interface = self.interface
        response = getattr(error, "response", {}) or {}
        error_body = response.get("Error", {})
        code = str(error_body.get("Code", "")) or "Unknown"
        http_status = response.get("ResponseMetadata", {}).get("HTTPStatusCode")
        request_id = response.get("ResponseMetadata", {}).get("RequestId")

        context = {**context, "s3_error_code": code}
        if http_status:
            context["http_status"] = http_status
        if request_id:
            # Worth recording: AWS support will ask for it first.
            context["aws_request_id"] = request_id

        if code in _S3_CREDENTIAL_CODES:
            return AuthenticationError(
                f"AWS rejected the credential for '{interface.name}' ({code}).",
                remediation=(
                    "Verify the access key and secret. An expired session token or a key "
                    "rotated during the change window both present this way."
                ),
                details=context,
                cause=error,
            )

        # A bucket in another region answers with a redirect rather than a
        # useful message, and the SDK surfaces it as an opaque 301.
        if code in ("PermanentRedirect", "AuthorizationHeaderMalformed", "301"):
            return ValidationProbeError(
                f"The bucket '{interface.bucket_name}' is not in region "
                f"'{interface.region}' ({code}).",
                remediation=(
                    f"S3 redirected the request, which means the bucket lives in a "
                    f"different region. Correct 'region' for this interface; buckets are "
                    f"region-bound and '{interface.region}' is not where this one is."
                ),
                details=context,
                cause=error,
            )

        if code in ("AccessDenied", "403"):
            return AuthenticationError(
                f"AWS returned Access Denied for '{interface.name}' ({code}).",
                remediation=(
                    "The credential is valid but not authorised for this operation. Check "
                    "the IAM policy, and any bucket policy or VPC endpoint policy that may "
                    "exclude this host's source address."
                ),
                details=context,
                cause=error,
            )

        if code in _S3_NOT_FOUND_CODES:
            return ValidationProbeError(
                f"The bucket '{interface.bucket_name}' does not exist or is not visible to "
                f"this credential ({code}).",
                remediation=(
                    "Check the bucket name. S3 returns the same response for a bucket that "
                    "does not exist and one the credential may not see, so confirm the IAM "
                    "policy as well."
                ),
                details=context,
                cause=error,
            )

        return ConnectionFailedError(
            f"S3 returned an error for '{interface.name}': {code}",
            remediation=(
                "The service reported an error the framework does not classify "
                "specifically. The error code and AWS request id are recorded with this "
                "result; AWS support will ask for the request id."
            ),
            details=context,
            cause=error,
        )
