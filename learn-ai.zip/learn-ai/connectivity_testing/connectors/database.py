"""Database connectors: Oracle Database and Microsoft SQL Server.

Both connectors do more than open a session. Connecting to a database proves
the listener answered; it does not prove the instance is mounted, the account
is unexpired, or the default schema is reachable. The probe runs the
configured validation query, so a passing result means a batch job could
actually have done work.

Error classification
--------------------
The value of these connectors after a patching window is almost entirely in
their error mapping. Both drivers report failures as one opaque exception
type, and the difference between "the listener is down", "the service is not
registered yet", "the password expired" and "the server no longer accepts
your authentication protocol" is buried in a numeric code. Each is mapped to a
distinct framework exception with its own remediation, because each is a
different job for a different team.

Two mappings are worth calling out specifically:

* **ORA-28040** appears immediately after an Oracle upgrade, when the server
  stops accepting the older authentication protocol the client still offers.
  It looks like a credential failure and is not one.
* **SQLSTATE 08001 with a certificate message** appears after upgrading to
  ODBC Driver 18, whose ``Encrypt`` default changed to ``yes``. Nothing about
  the database changed; the driver did.

Database links
--------------
An Oracle interface can optionally go one hop further and open every database
link the account owns (:mod:`connectors.oracle_links`). That hop is invisible
to every other check in this framework, because the link is opened by the
database *server*: it exercises the path from the database to a remote
database, which no probe run from this host can reach.
"""

from __future__ import annotations

from typing import Any, ClassVar

from connectors.base import BaseConnector
from connectors.factory import register
from connectors.oracle_links import (
    DatabaseLinkReport,
    check_database_links,
    oracle_error_code,
    oracle_error_message,
)
from connectors.support import classify_transport_error, describe_endpoint, require_driver
from core.constants import InterfaceType
from core.exceptions import (
    AuthenticationError,
    CertificateValidationError,
    ConnectionFailedError,
    ConnectivityTimeoutError,
    ConnectorError,
    DatabaseLinkError,
    DriverNotAvailableError,
    ValidationProbeError,
)
from models.interfaces import (
    MssqlAuthentication,
    MssqlInterfaceConfig,
    OracleInterfaceConfig,
)

__all__ = ["MssqlConnector", "OracleConnector"]

#: Rows fetched from the validation query. The probe proves the session works;
#: it is not a data extract, and an operator who points it at a large table
#: should not blow out the memory of the batch host.
_MAX_PROBE_ROWS = 5

#: Characters of a driver message retained on the result.
_MAX_DRIVER_MESSAGE = 400


# ---------------------------------------------------------------------------
# Oracle
# ---------------------------------------------------------------------------

#: ORA error code to (exception class, remediation). The codes chosen are the
#: ones that actually appear after infrastructure change, not an exhaustive
#: transcription of the error manual.
_ORACLE_ERRORS: dict[int, tuple[type[ConnectorError], str]] = {
    1017: (
        AuthenticationError,
        "The username or password was rejected (ORA-01017). Verify the credential, and "
        "check whether the account was recreated or its password rotated during the "
        "change window.",
    ),
    28000: (
        AuthenticationError,
        "The account is locked (ORA-28000). Ask the DBA to unlock it. Repeated failed "
        "logins from another job are the usual cause, so confirm the credential "
        "everywhere before unlocking.",
    ),
    28001: (
        AuthenticationError,
        "The password has expired (ORA-28001). Reset it, then re-run "
        "'python generate_config.py' to store the new password.",
    ),
    28040: (
        AuthenticationError,
        "No matching authentication protocol (ORA-28040). This appears after a database "
        "upgrade: the server no longer accepts the older protocol this client offers. Set "
        "SQLNET.ALLOWED_LOGON_VERSION_SERVER on the server, or upgrade the client. The "
        "credential itself is not the problem.",
    ),
    1005: (
        AuthenticationError,
        "A null password was supplied (ORA-01005). Configure the password with "
        "'python generate_config.py'.",
    ),
    12154: (
        ConnectionFailedError,
        "The connect identifier could not be resolved (ORA-12154). Check the service name "
        "or SID, and any tnsnames.ora the client is reading.",
    ),
    12514: (
        ConnectionFailedError,
        "The listener does not know the requested service (ORA-12514). The listener is "
        "running but the database has not registered with it. After a restart this "
        "resolves once the instance registers; if it persists, check the service name and "
        "that the instance is open.",
    ),
    12505: (
        ConnectionFailedError,
        "The listener does not know the requested SID (ORA-12505). Confirm the SID, or "
        "switch the interface to a service name, which is preferred.",
    ),
    12541: (
        ConnectionFailedError,
        "No listener is running on the target port (ORA-12541). The listener did not come "
        "back up after the change. Start it and confirm it is bound to the expected port.",
    ),
    12170: (
        ConnectivityTimeoutError,
        "The connection timed out (ORA-12170). The packets are most likely being dropped "
        "by a firewall rather than rejected. Confirm the rule permits this source host.",
    ),
    12537: (
        ConnectionFailedError,
        "The connection was closed by the server (ORA-12537). Common causes are a "
        "connection manager, a firewall idle timeout, or the server refusing the client "
        "protocol version.",
    ),
    12547: (
        ConnectionFailedError,
        "Contact with the server was lost (ORA-12547). This usually indicates the server "
        "process terminated during the handshake. Check the alert log and listener log.",
    ),
    12560: (
        ConnectionFailedError,
        "Protocol adapter error (ORA-12560). Check that the protocol, host and port are "
        "correct, and that the database is running.",
    ),
    1033: (
        ConnectionFailedError,
        "The instance is starting up or shutting down (ORA-01033). If the change window "
        "is still in progress this will clear on its own; re-run once startup completes.",
    ),
    1034: (
        ConnectionFailedError,
        "The database is not available (ORA-01034). The instance is down. Start it, then "
        "confirm it is open rather than merely mounted.",
    ),
    3113: (
        ConnectionFailedError,
        "End-of-file on the communication channel (ORA-03113). The server closed the "
        "connection unexpectedly. Check the alert log for a crash or a resource limit.",
    ),
    29024: (
        CertificateValidationError,
        "Certificate validation failed (ORA-29024). The server certificate is not trusted "
        "by this client. Check the wallet contents and whether the certificate was "
        "rotated during the change window.",
    ),
    12660: (
        CertificateValidationError,
        "Encryption or checksumming parameters are incompatible (ORA-12660). The server "
        "now requires native encryption settings this client does not offer. Align "
        "SQLNET.ENCRYPTION_CLIENT and SQLNET.CRYPTO_CHECKSUM_CLIENT with the server.",
    ),
    12518: (
        ConnectionFailedError,
        "The listener could not hand off the client connection (ORA-12518). The instance "
        "is at its process limit or a dispatcher is unavailable.",
    ),
}


@register
class OracleConnector(BaseConnector[OracleInterfaceConfig]):
    """Validates an Oracle Database endpoint.

    Uses python-oracledb in thin mode by default, which speaks the protocol
    natively and requires no Oracle Client installation. That matters on AIX
    and in container images, where installing Instant Client is often the
    single largest obstacle to running a check at all. Thick mode remains
    available for estates that need it, typically for wallet based
    authentication.
    """

    interface_type: ClassVar[InterfaceType] = InterfaceType.ORACLE
    driver_packages: ClassVar[tuple[str, ...]] = ("oracledb",)

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._oracledb: Any = None

    @property
    def deadline_seconds(self) -> float:
        """Return the hard ceiling for one attempt, in seconds.

        Checking database links adds work the base deadline knows nothing
        about: the link probes are bounded by their own budget, and the
        watchdog must sit outside it or it would fire on a check that is
        behaving exactly as configured.
        """
        base = super().deadline_seconds
        if not self.interface.check_db_links:
            return base
        return base + float(self.interface.db_link_budget_seconds) + 10.0

    def _open(self) -> Any:
        """Establish a database session.

        Returns:
            An open ``oracledb.Connection``.
        """
        oracledb = require_driver("oracledb", self.interface_type)
        self._oracledb = oracledb
        interface = self.interface

        if interface.use_thick_mode:
            self._initialise_thick_mode(oracledb)

        try:
            params = oracledb.ConnectParams(
                host=interface.host,
                port=interface.port,
                protocol="tcps" if interface.use_ssl else "tcp",
                tcp_connect_timeout=float(self.timeout),
                **(
                    {"service_name": interface.service_name}
                    if interface.service_name
                    else {"sid": interface.sid}
                ),
            )
            if interface.use_ssl:
                params.set(ssl_server_dn_match=interface.ssl_server_dn_match)
            if interface.wallet_location:
                params.set(
                    wallet_location=interface.wallet_location,
                    config_dir=interface.wallet_location,
                )
        except Exception as error:  # noqa: BLE001 - driver validates parameters
            raise ConnectorError(
                f"Oracle connection parameters were rejected by the driver: {error}",
                remediation=(
                    "Check the host, port, and service name or SID in the configuration."
                ),
                details={"endpoint": interface.endpoint},
                cause=error,
            ) from error

        try:
            return oracledb.connect(
                user=interface.username,
                password=self.secret("password"),
                params=params,
            )
        except oracledb.Error as error:
            raise self._classify_oracle_error(error) from error
        except OSError as error:
            raise classify_transport_error(
                error,
                host=interface.host,
                port=interface.port,
                timeout_seconds=self.timeout,
            ) from error

    def _initialise_thick_mode(self, oracledb: Any) -> None:
        """Load the Oracle Client libraries for thick mode.

        Raises:
            DriverNotAvailableError: when the client libraries are absent.
        """
        try:
            oracledb.init_oracle_client()
        except Exception as error:  # noqa: BLE001 - driver raises several types
            # Already initialised is not a failure: the libraries load once per
            # process and every subsequent interface reuses them.
            if "already" in str(error).lower():
                return
            raise DriverNotAvailableError(
                "Oracle thick mode was requested but the Oracle Client libraries could "
                f"not be loaded: {error}",
                package="Oracle Instant Client",
                install_extra=None,
                details={"endpoint": self.interface.endpoint},
                cause=error,
            ) from error

    def _probe(self, handle: Any) -> dict[str, Any]:
        """Run the validation query and record what the session reports."""
        interface = self.interface
        oracledb = self._oracledb

        details: dict[str, Any] = {
            "dsn": interface.dsn,
            "username": interface.username,
            "driver_mode": "thin" if getattr(handle, "thin", True) else "thick",
            "driver_version": getattr(oracledb, "__version__", None),
            "validation_query": interface.validation_query,
        }
        server_version = getattr(handle, "version", None)
        if server_version:
            details["server_version"] = server_version
        if interface.use_ssl:
            details["encryption"] = "tcps"
            details["ssl_server_dn_match"] = interface.ssl_server_dn_match

        try:
            with handle.cursor() as cursor:
                cursor.execute(interface.validation_query)
                rows = cursor.fetchmany(_MAX_PROBE_ROWS) if cursor.description else []
        except oracledb.Error as error:
            raise self._classify_query_error(error, details) from error

        details["rows_returned"] = len(rows)
        if rows:
            details["first_row"] = [str(value) for value in rows[0]]
        elif "select" in interface.validation_query.lower():
            raise ValidationProbeError(
                f"The validation query returned no rows on {interface.endpoint}: "
                f"{interface.validation_query}",
                remediation=(
                    "The session opened but the query produced nothing. Confirm the query "
                    "is correct and that the account can see the objects it references."
                ),
                details=details,
            )

        if interface.check_db_links:
            self._validate_database_links(handle, details)
        return details

    def _validate_database_links(self, handle: Any, details: dict[str, Any]) -> None:
        """Open every database link the account owns, and judge the result.

        The evidence is merged into ``details`` before any verdict is reached,
        so a run that fails on links still reports every link it checked --
        including the ones that passed, which is what tells an operator whether
        one remote database is down or the server's name resolution is.

        Raises:
            DatabaseLinkError: if a link could not be opened and the interface
                treats that as a failure.
        """
        interface = self.interface
        report: DatabaseLinkReport = check_database_links(
            handle,
            self._oracledb,
            scope=interface.db_link_scope,
            names=interface.db_link_names,
            session_user=interface.username,
            per_link_timeout_seconds=interface.db_link_timeout_seconds,
            budget_seconds=float(interface.db_link_budget_seconds),
            max_links=interface.db_link_max_links,
            logger=self.logger,
        )
        details.update(report.to_details())

        for warning in report.warnings():
            self.add_warning(warning)

        failures = report.failures
        if not failures:
            self.logger.info(
                "%s: %d database link(s) opened successfully.",
                interface.name,
                len(report.passed),
            )
            return

        listed = "; ".join(
            f"{probe.link.display_name}: {probe.message or 'no detail reported'}"
            for probe in failures
        )
        summary = (
            f"{len(failures)} of {report.found} database link(s) on {interface.endpoint} "
            f"could not be opened: {listed}"
        )

        # The local database is healthy either way -- the session opened and the
        # validation query ran. Whether a broken link fails the interface is
        # therefore a policy question, and it belongs to the operator.
        if not interface.fail_on_broken_db_link:
            self.add_warning(summary)
            return

        raise DatabaseLinkError(
            summary, remediation=report.remediation(), details=details
        )

    def _classify_query_error(self, error: Exception, details: dict[str, Any]) -> ConnectorError:
        """Classify a failure of the validation query itself."""
        code = self._oracle_error_code(error)
        message = self._oracle_error_message(error)

        # The session was established, so a failure here is about privileges or
        # the query, not connectivity. ORA-00942 in particular is the signature
        # of a grant that was not reapplied after a refresh.
        if code in (942, 1031):
            return ValidationProbeError(
                f"The validation query was refused on {self.interface.endpoint}: {message}",
                remediation=(
                    "The account connected but lacks privileges on the objects the query "
                    "references. Grants are frequently lost when a schema is refreshed "
                    "from another environment."
                ),
                details={**details, "ora_code": code},
                cause=error,
            )

        return ValidationProbeError(
            f"The validation query failed on {self.interface.endpoint}: {message}",
            remediation=(
                "The connection succeeded but the query did not. Run it manually as this "
                "account to see why."
            ),
            details={**details, "ora_code": code},
            cause=error,
        )

    @staticmethod
    def _oracle_error_code(error: BaseException) -> int | None:
        """Extract the numeric ORA/DPY code from a driver exception."""
        return oracle_error_code(error)

    @staticmethod
    def _oracle_error_message(error: BaseException) -> str:
        """Extract a readable message from a driver exception."""
        return oracle_error_message(error, limit=_MAX_DRIVER_MESSAGE)

    def _classify_oracle_error(self, error: Exception) -> ConnectorError:
        """Map a driver exception onto the framework exception hierarchy."""
        interface = self.interface
        code = self._oracle_error_code(error)
        message = self._oracle_error_message(error)
        endpoint = describe_endpoint(interface.host, interface.port)
        details: dict[str, Any] = {
            "ora_code": code,
            "dsn": interface.dsn,
            "username": interface.username,
        }

        mapped = _ORACLE_ERRORS.get(code) if code is not None else None
        if mapped is not None:
            exception_class, remediation = mapped
            return exception_class(
                f"Oracle connection to {endpoint} failed: {message}",
                remediation=remediation,
                details=details,
                cause=error,
            )

        lowered = message.lower()
        if "timeout" in lowered or "timed out" in lowered:
            return ConnectivityTimeoutError(
                f"Oracle connection to {endpoint} timed out after {self.timeout} seconds: "
                f"{message}",
                remediation=(
                    "No response within the timeout. A silent drop usually means a firewall "
                    "is discarding the packets rather than rejecting them."
                ),
                details=details,
                cause=error,
            )
        if "certificate" in lowered or "ssl" in lowered or "wallet" in lowered:
            return CertificateValidationError(
                f"Oracle TLS negotiation with {endpoint} failed: {message}",
                remediation=(
                    "Check the wallet location and its contents, and whether the server "
                    "certificate was rotated. With ssl_server_dn_match enabled, the "
                    "certificate distinguished name must also match the server."
                ),
                details=details,
                cause=error,
            )

        return ConnectionFailedError(
            f"Oracle connection to {endpoint} failed: {message}",
            remediation=(
                "The driver reported an error the framework does not classify "
                "specifically. The full driver message is recorded with this result."
            ),
            details=details,
            cause=error,
        )


# ---------------------------------------------------------------------------
# Microsoft SQL Server
# ---------------------------------------------------------------------------

#: SQLSTATE prefix to (exception class, remediation). SQLSTATE is checked
#: before the free-text message because it is stable across driver versions
#: and locales, whereas the message is neither.
_MSSQL_SQLSTATES: dict[str, tuple[type[ConnectorError], str]] = {
    "28000": (
        AuthenticationError,
        "The login was rejected (SQLSTATE 28000). Verify the account and password. For "
        "Windows authentication, remember the job runs as the scheduler's service "
        "account, not as the account that created the configuration.",
    ),
    "42000": (
        ValidationProbeError,
        "The login succeeded but the database could not be opened (SQLSTATE 42000). Grant "
        "the account access to the database, or correct the database name.",
    ),
    "08001": (
        ConnectionFailedError,
        "The client could not establish a connection (SQLSTATE 08001). Check the host, "
        "the port, and that the SQL Server service and its TCP listener are running.",
    ),
    "08S01": (
        ConnectionFailedError,
        "The communication link failed (SQLSTATE 08S01). The connection was established "
        "and then dropped, which commonly indicates a TLS mismatch or a device in the "
        "path closing the session.",
    ),
    "08004": (
        ConnectionFailedError,
        "The server rejected the connection (SQLSTATE 08004). The instance may be in "
        "single-user mode, or at its connection limit.",
    ),
    "HYT00": (
        ConnectivityTimeoutError,
        "The login timeout expired (SQLSTATE HYT00). No response within the timeout, which "
        "usually means a firewall is dropping the packets silently.",
    ),
    "HYT01": (
        ConnectivityTimeoutError,
        "The connection timeout expired (SQLSTATE HYT01). Raise the timeout only if the "
        "path is genuinely slow; otherwise investigate the network.",
    ),
}


@register
class MssqlConnector(BaseConnector[MssqlInterfaceConfig]):
    """Validates a Microsoft SQL Server endpoint.

    Encryption defaults to on, matching ODBC Driver 18. That changed default is
    itself one of the most common post-upgrade failures: nothing about the
    database changed, but a connection that worked under Driver 17 now fails
    certificate validation. The connector detects that case specifically and
    says so, rather than reporting a generic connection failure.
    """

    interface_type: ClassVar[InterfaceType] = InterfaceType.MSSQL
    driver_packages: ClassVar[tuple[str, ...]] = ("pyodbc",)

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._pyodbc: Any = None

    def _build_connection_string(self) -> str:
        """Assemble the ODBC connection string.

        The returned string contains the password and must never be logged,
        stored on a result, or included in an exception message.
        """
        interface = self.interface
        parts = [
            f"DRIVER={{{interface.odbc_driver}}}",
            f"SERVER={interface.host},{interface.port}",
            f"DATABASE={interface.database}",
            f"Encrypt={'yes' if interface.encrypt else 'no'}",
            f"TrustServerCertificate={'yes' if interface.trust_server_certificate else 'no'}",
            f"Connection Timeout={self.timeout}",
        ]

        if interface.authentication is MssqlAuthentication.WINDOWS:
            parts.append("Trusted_Connection=yes")
        else:
            password = self.secret("password") or ""
            parts.append(f"UID={interface.username}")
            parts.append(f"PWD={password}")

        return ";".join(parts) + ";"

    def _safe_connection_summary(self) -> dict[str, Any]:
        """Return the connection parameters that are safe to record."""
        interface = self.interface
        return {
            "server": f"{interface.host},{interface.port}",
            "database": interface.database,
            "odbc_driver": interface.odbc_driver,
            "authentication": interface.authentication.value,
            "encrypt": interface.encrypt,
            "trust_server_certificate": interface.trust_server_certificate,
            "username": interface.username,
        }

    def _open(self) -> Any:
        """Establish a database session.

        Returns:
            An open ``pyodbc.Connection``.
        """
        pyodbc = require_driver("pyodbc", self.interface_type)
        self._pyodbc = pyodbc
        interface = self.interface

        if interface.trust_server_certificate:
            self.add_warning(
                "TrustServerCertificate is enabled, so the server certificate is not "
                "validated. An expired or mis-issued certificate cannot be detected on "
                "this interface."
            )

        try:
            return pyodbc.connect(self._build_connection_string(), timeout=self.timeout)
        except pyodbc.Error as error:
            raise self._classify_pyodbc_error(error) from error

    def _probe(self, handle: Any) -> dict[str, Any]:
        """Run the validation query and record what the session reports."""
        interface = self.interface
        pyodbc = self._pyodbc
        details = self._safe_connection_summary()
        details["validation_query"] = interface.validation_query
        details.update(self._server_information(handle, pyodbc))


        try:
            cursor = handle.cursor()
            try:
                cursor.execute(interface.validation_query)
                rows = cursor.fetchmany(_MAX_PROBE_ROWS) if cursor.description else []
            finally:
                cursor.close()
        except pyodbc.Error as error:
            raise ValidationProbeError(
                f"The validation query failed on {interface.endpoint}: "
                f"{self._pyodbc_message(error)}",
                remediation=(
                    "The connection succeeded but the query did not. Confirm the account "
                    "has permission on the objects it references; grants are often lost "
                    "when a database is restored from another environment."
                ),
                details={**details, "sqlstate": self._pyodbc_sqlstate(error)},
                cause=error,
            ) from error

        details["rows_returned"] = len(rows)
        if rows:
            details["first_row"] = [str(value) for value in rows[0]]
        elif "select" in interface.validation_query.lower():
            raise ValidationProbeError(
                f"The validation query returned no rows on {interface.endpoint}: "
                f"{interface.validation_query}",
                remediation=(
                    "The session opened but the query produced nothing. Confirm the query "
                    "is correct for this database."
                ),
                details=details,
            )
        return details

    def _server_information(self, handle: Any, pyodbc: Any) -> dict[str, Any]:
        """Return server identity from the driver, without issuing a query.

        ``getinfo`` reads values the driver already negotiated, so it needs no
        privileges and cannot fail because of a restricted account. Any value
        the driver declines to supply is skipped: this is report decoration,
        and it must never fail an otherwise healthy interface.
        """
        information: dict[str, Any] = {}
        for label, attribute in (
            ("server_product", "SQL_DBMS_NAME"),
            ("server_version", "SQL_DBMS_VER"),
            ("odbc_driver_version", "SQL_DRIVER_VER"),
        ):
            constant = getattr(pyodbc, attribute, None)
            if constant is None:
                continue
            try:
                value = handle.getinfo(constant)
            except Exception as error:  # noqa: BLE001 - informational only
                self.logger.debug(
                    "Driver did not supply %s: %s: %s", label, type(error).__name__, error
                )
                continue
            if value:
                information[label] = str(value)
        return information

    @staticmethod
    def _pyodbc_sqlstate(error: BaseException) -> str | None:
        """Return the five character SQLSTATE, when the driver supplied one.

        pyodbc raises ``Error(sqlstate, message)``, but a driver that fails
        before ODBC is reached can raise with fewer arguments, so the shape is
        checked rather than assumed.
        """
        arguments: tuple[Any, ...] = getattr(error, "args", ())
        if arguments and isinstance(arguments[0], str):
            return arguments[0]
        return None

    @staticmethod
    def _pyodbc_message(error: BaseException) -> str:
        """Return the driver's message text."""
        arguments: tuple[Any, ...] = getattr(error, "args", ())
        if len(arguments) > 1 and isinstance(arguments[1], str):
            return arguments[1].strip()[:_MAX_DRIVER_MESSAGE]
        return str(error).strip()[:_MAX_DRIVER_MESSAGE]

    def _classify_pyodbc_error(self, error: Exception) -> ConnectorError:
        """Map a pyodbc exception onto the framework exception hierarchy."""
        interface = self.interface
        sqlstate = self._pyodbc_sqlstate(error)
        message = self._pyodbc_message(error)
        lowered = message.lower()
        details = {**self._safe_connection_summary(), "sqlstate": sqlstate}

        # A missing ODBC driver is an installation fault on this host, not a
        # connectivity failure. Naming the drivers that *are* installed turns a
        # dead end into a one-line fix.
        if sqlstate == "IM002" or "data source name not found" in lowered:
            return DriverNotAvailableError(
                f"The ODBC driver '{interface.odbc_driver}' is not installed on this host.",
                package=f"ODBC driver: {interface.odbc_driver}",
                install_extra=None,
                details={**details, "installed_drivers": self._installed_drivers()},
                cause=error,
            )

        # ODBC Driver 18 changed the Encrypt default to yes. A configuration
        # that worked under Driver 17 then fails here with a certificate error
        # although nothing about the database changed.
        if "certificate" in lowered or "ssl security error" in lowered or "ssl provider" in lowered:
            return CertificateValidationError(
                f"TLS negotiation with {interface.endpoint} failed: {message}",
                remediation=(
                    "The server certificate is not trusted by this host. ODBC Driver 18 "
                    "encrypts by default, so a connection that worked under Driver 17 can "
                    "fail here with nothing changed on the database. Install the issuing "
                    "authority into the host trust store, or, only if the network is "
                    "genuinely trusted, set trust_server_certificate."
                ),
                details=details,
                cause=error,
            )

        if sqlstate:
            mapped = _MSSQL_SQLSTATES.get(sqlstate)
            if mapped is not None:
                exception_class, remediation = mapped
                return exception_class(
                    f"SQL Server connection to {interface.endpoint} failed: {message}",
                    remediation=remediation,
                    details=details,
                    cause=error,
                )

        if "timeout" in lowered:
            return ConnectivityTimeoutError(
                f"SQL Server connection to {interface.endpoint} timed out after "
                f"{self.timeout} seconds: {message}",
                remediation=(
                    "No response within the timeout, which usually means a firewall is "
                    "dropping the packets rather than rejecting them."
                ),
                details=details,
                cause=error,
            )

        if "login failed" in lowered:
            return AuthenticationError(
                f"SQL Server login failed for {interface.endpoint}: {message}",
                remediation=(
                    "Verify the account and password, and that the login is enabled and "
                    "mapped to a user in the target database."
                ),
                details=details,
                cause=error,
            )

        return ConnectionFailedError(
            f"SQL Server connection to {interface.endpoint} failed: {message}",
            remediation=(
                "The driver reported an error the framework does not classify "
                "specifically. The SQLSTATE and driver message are recorded with this "
                "result."
            ),
            details=details,
            cause=error,
        )

    def _installed_drivers(self) -> list[str]:
        """Return the ODBC drivers registered on this host."""
        try:
            return list(self._pyodbc.drivers())
        except Exception:  # noqa: BLE001 - informational only
            return []
