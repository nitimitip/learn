"""Connectivity connectors for the Enterprise Connectivity Validation Framework.

Every supported connectivity type is implemented as a self-contained connector
that inherits from ``connectors.base.BaseConnector`` and is published through
``connectors.factory.ConnectorFactory``.  Adding a new connectivity type never
requires changes to the validation engine or the reporting layer.

Third-party drivers (paramiko, oracledb, pyodbc, boto3, azure-storage-blob,
requests, zeep) are imported lazily inside the connector that needs them so
that a missing optional dependency degrades a single interface instead of
preventing the whole framework from starting.
"""

from __future__ import annotations

__all__: list[str] = []
