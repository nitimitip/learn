#!/usr/bin/env python3
"""Interactive configuration wizard for the connectivity validation framework.

Usage::

    python generate_config.py
    python generate_config.py --config-dir /opt/connectivity/config

Generates a validated JSON configuration and an ``encryption.key`` beside it.
Every credential is encrypted before it reaches the disk; nothing in the file
needs to be, or should be, edited by hand afterwards.

This module is a launcher. The implementation lives in :mod:`core.wizard`, and
the command line handling in :mod:`core.wizard_cli`, so that both the
``python generate_config.py`` invocation used by operators and the
``connectivity-config`` console script installed by ``pip`` execute exactly
the same code.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Allow execution from any working directory: a scheduler or an operator in
# another directory must be able to run "python /opt/app/generate_config.py".
_PROJECT_ROOT = Path(__file__).resolve().parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from core.wizard_cli import main  # noqa: E402 - import follows sys.path setup

if __name__ == "__main__":
    sys.exit(main())
