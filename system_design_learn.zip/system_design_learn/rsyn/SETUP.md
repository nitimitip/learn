# rsync_fordr - setup on AIX 7.2 without root logins

Do every step on **all three nodes** (sv76543, sv78964, sv76987). Any node
can become the primary after a failover, so the nodes are set up the same way.

## Why some privilege is still needed

Only a privileged process can create a file owned by another user (chown).
If the receiving rsync runs as a normal user, every file it writes is owned
by that user. So "keep owners exactly" across many application users needs
privilege on both ends: reading everyone's files on the primary, and
chown on the target.

What security usually objects to is root logging in, and root-to-root ssh
trust. This setup removes both:

| Before | After |
|---|---|
| operator logs in as root | operator runs `sudo rsync_fordr ...` as themselves (sudo logs it) |
| root ssh key trusted on DR nodes | key for `drsync` only, `PermitRootLogin no` |
| remote side runs any command as root | key's forced command allows only `rsync --server` (receiving), only into listed dirs |

## 1. Packages (AIX Toolbox)

```sh
dnf install rsync sudo          # same rsync version on all nodes, 3.2 or newer
/opt/freeware/bin/rsync --version
```

## 2. Service account `drsync` (no password, ssh key only)

```sh
mkuser pgrp=staff home=/home/drsync shell=/usr/bin/ksh login=false drsync
mkdir -p /home/drsync/.ssh
chown drsync:staff /home/drsync/.ssh && chmod 700 /home/drsync/.ssh
```

Don't give it a password. `login=false` blocks console login. Leave
`rlogin=true`, because AIX sshd checks that attribute and key logins would fail
without it.

## 3. Files

```sh
cp rsync_fordr rsync_fordr_remote /usr/local/bin/
chown root:system /usr/local/bin/rsync_fordr /usr/local/bin/rsync_fordr_remote
chmod 755        /usr/local/bin/rsync_fordr /usr/local/bin/rsync_fordr_remote

# your existing lists, same names as before, same content on all nodes
cp rsync_fordr.include rsync_fordr.exclude /usr/local/bin/
chown root:system /usr/local/bin/rsync_fordr.include /usr/local/bin/rsync_fordr.exclude
chmod 644        /usr/local/bin/rsync_fordr.include /usr/local/bin/rsync_fordr.exclude

mkdir -p /var/adm/rsync_fordr/logs /var/adm/rsync_fordr/locks
chmod 1777 /var/adm/rsync_fordr/logs /var/adm/rsync_fordr/locks
```

If your old script had another name (for example `rsunc_fordr`), the include
and exclude files are looked up by the script's own name, so keep both names
the same.

## 4. ssh key (root-owned, so drsync itself cannot use it to bypass the script)

```sh
mkdir -p /etc/rsync_fordr && chmod 700 /etc/rsync_fordr
ssh-keygen -t ed25519 -N "" -C "rsync_fordr@$(hostname)" -f /etc/rsync_fordr/id_ed25519
ssh-keyscan -t ed25519 sv76543 sv78964 sv76987 > /etc/rsync_fordr/known_hosts
# check the fingerprints against each node: ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub
```

Put each node's `id_ed25519.pub` into `/home/drsync/.ssh/authorized_keys` on
the **other two** nodes, all on one line:

```
from="10.1.1.11,10.1.1.12,10.1.1.13",command="/usr/local/bin/rsync_fordr_remote",no-pty,no-agent-forwarding,no-port-forwarding,no-X11-forwarding ssh-ed25519 AAAA... rsync_fordr@sv76543
```

Use the nodes' IP addresses in `from=`. Host names there only work if reverse DNS works.

```sh
chown drsync:staff /home/drsync/.ssh/authorized_keys && chmod 600 /home/drsync/.ssh/authorized_keys
```

Set `PermitRootLogin no` in `/etc/ssh/sshd_config`, then restart sshd with
`stopsrc -s sshd; startsrc -s sshd`.

## 5. sudoers (`visudo`)

```
Cmnd_Alias DRSYNC_RUN  = /usr/local/bin/rsync_fordr
Cmnd_Alias DRSYNC_RECV = /opt/freeware/bin/rsync --server *, \
                         !/opt/freeware/bin/rsync --server --sender *
Defaults:drsync !requiretty

drsync      ALL = (root) NOPASSWD: DRSYNC_RUN, DRSYNC_RECV
%drsyncops  ALL = (root) NOPASSWD: DRSYNC_RUN
```

`drsyncops` is the group of the people who may start a replication. Create it with
`mkgroup drsyncops`, then add members with `chgrpmem -m + user1,user2 drsyncops`.

## 6. Test, then run

```sh
# as drsync on the primary
sudo -n /usr/local/bin/rsync_fordr -n sv76543 sv78964 sv76987   # dry run
sudo -n /usr/local/bin/rsync_fordr    sv76543 sv78964 sv76987   # real run
```

Cron (drsync's crontab, **on the primary only**):

```
0 * * * * /opt/freeware/bin/sudo -n /usr/local/bin/rsync_fordr sv76543 sv78964 sv76987 >/dev/null 2>&1
```

After a failover, put the new primary first in the arguments. The script refuses to run when
the host it is on is not the first argument, so a DR node can never push its
older copy over live data.

Logs are in `/var/adm/rsync_fordr/logs`: one run log, plus one detail log per
target with rsync's file list and `--stats`. Refused connections on the targets
go to syslog under the tag `rsync_fordr_remote`.

## Optional: user mode (no sudo at all)

If a directory and everything in it belongs to one application user, that
user can replicate it alone with the same script:

```sh
# as appuser, with appuser's own ssh key trusted by appuser on the targets
/usr/local/bin/rsync_fordr sv76543 sv78964 sv76987
```

It copies only the directories in the include file that `appuser` owns. Mode
and times are kept, and files arrive owned by `appuser`. Different users can run at
the same time. Each directory is locked while it is copied, so no directory
is copied twice in parallel. Use privileged mode for any tree that holds files
of more than one owner.

## Things to check once

* **AIX ACLs:** rsync on AIX does not copy JFS2 extended ACLs (AIXC/NFS4). To check a tree,
  run `aclget` on a few files. If they have extended ACLs, copy them separately
  (`aclget file | aclput -f - file` over ssh) or drop them.
* **UIDs/GIDs:** by default rsync matches owners by name. Set
  `NUMERIC_IDS=yes` in `rsync_fordr.conf` only if the numbers are the same on
  all nodes and the names are not.
* **Exclude patterns:** the old script copied `/data` into `host:/`, and this
  one copies `/data/` into `host:/data/`. Anchored patterns such as
  `/data/tmp` are rewritten to `/tmp` automatically. An unanchored pattern
  that names the top directory, such as `data/tmp`, should be rewritten
  as `/data/tmp`.
* **Safety stops:** a directory is skipped (with an alert) when it is empty,
  or when it is a filesystem that is not mounted. A run that would delete more than
  `MAX_DELETE` (10000) files in one directory stops with rsync code 25.
