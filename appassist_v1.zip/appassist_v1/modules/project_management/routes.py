"""
Project Management Routes
=========================
All Flask route handlers for the project management blueprint.

Permission model
----------------
* admin          - full access to everything
* project_manager - can create projects; admin rights only on projects they created
* team_member    - read-only on projects they belong to, PLUS can:
                     * create / edit tasks inside their project
                     * upload documents
                     * add / edit risk log entries
"""

from flask import (
    render_template, redirect, url_for, flash, request,
    jsonify, session, send_from_directory, abort, Response,
)
from datetime import datetime, date, timedelta
from sqlalchemy.orm import joinedload, selectinload
from sqlalchemy import or_, and_, func
import os
import logging
import secrets
import plotly.graph_objs as go
import plotly.utils
import json
from werkzeug.utils import secure_filename

from auth import get_current_user, require_auth

logger = logging.getLogger(__name__)
from database import get_db_session
import file_versions
from .models import (
    Project, ProjectStatus,
    ProjectStakeholder, ProjectStatusRecipient,
    ProjectMilestone, MilestoneStatus,
    ProjectTeamMember,
    ProjectTask, TaskStatus,
    TaskDependency,
    TaskNote,
    ProjectRiskLog, RiskSeverity, RiskStatus,
    RISK_PROBABILITY_LABELS, RISK_IMPACT_LABELS, risk_band,
    ProjectDocument,
    ProjectBaseline, BaselineMilestone, BaselineTask,
    ProjectActivity,
    TASK_CATEGORIES, DOCUMENT_CATEGORIES, STAKEHOLDER_ROLES,
    TEAM_MEMBER_ROLES, TEAM_MEMBER_GROUPS, normalize_document_category,
    TASK_PRIORITIES, TASK_PRIORITY_DEFAULT,
    GoLivePlan, GoLiveTask, GoLiveConnectivity, GoLiveContact,
    GOLIVE_TASK_SECTIONS, GOLIVE_TASK_SECTION_KEYS, GOLIVE_SECTION_LABELS,
    GOLIVE_ALL_SECTIONS, GOLIVE_DEPARTMENTS, GOLIVE_TASK_STATUSES,
    GOLIVE_CONNECTION_DIRECTIONS,
    HLDTemplateSection, HLDTemplateColumn,
    ProjectHLD, ProjectHLDSection, ProjectHLDRow,
    hld_default_intro, ensure_hld_template_seeded, ensure_brd_template_seeded,
    ensure_ssia_template_seeded,
    resequence_hld_template, flatten_hld_tree, seed_hld_default_content,
    GUEST_PREFILL_ROWS,
    EffortResourceDefault, EFFORT_LOCATIONS,
    ensure_effort_defaults_seeded, load_effort_defaults,
    SDLCPhaseTemplate, ProjectSDLCPhase, SDLCPhaseMilestone,
    ensure_sdlc_templates_seeded,
)
from .sdlc import (
    METHODOLOGIES, METHODOLOGY_LABELS,
    SDLC_QUESTIONS, SDLC_SCORE_MAX, SDLC_AGILE_THRESHOLD,
    score_answers, recommend_methodology,
    split_window, evaluate_phases, collect_flags,
)
from .governance import load_gate, gate_view, evidence_stamp

from .cpm import (
    compute_cpm, layout_network, find_cycle,
    DEPENDENCY_TYPES, DEPENDENCY_TYPE_LABELS, MAX_LAG_DAYS,
)
from .golive_excel import build_golive_workbook
from .effort_excel import build_effort_workbook, export_filename
from .planning_excel import build_plan_workbook, plan_export_filename
from .hld_docx import build_hld_document, build_hld_document_from_payload
from .sample_docs import SAMPLE_PROJECT_NAME, build_sample_payload
from .proposal_decks import build_deck_html, TEMPLATES, TEMPLATE_IDS, SLIDES, META_FIELDS, default_data, slides_for
from .project_excel import build_project_workbook, build_portfolio_workbook
from .status_email import send_status_report
from models import User
from . import project_management_bp

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

UPLOAD_FOLDER    = os.path.join('secure_uploads', 'project_documents')
ALLOWED_EXTENSIONS = {
    'txt', 'pdf', 'doc', 'docx', 'xls', 'xlsx',
    'ppt', 'pptx', 'jpg', 'jpeg', 'png', 'csv', 'zip',
}

# Key this module's rows in the shared document_versions table.
DOC_ENTITY = file_versions.ENTITY_PROJECT_DOCUMENT

# Every project document is filed under one of the six SDLC phase groups, and the
# phase gates depend on them - a pruned version of a gate-bearing document is gone
# for good, so these keep a deeper history than the app-wide default. Documents
# that fall outside a group (legacy rows that map to "Other") keep MAX_VERSIONS.
file_versions.register_retention(
    DOC_ENTITY, DOCUMENT_CATEGORIES, file_versions.SDLC_MAX_VERSIONS)

STATUS_COLORS = {
    'Not Started': '#8695a4',
    'In Progress': '#2196F3',
    'Hold':        '#FF9800',
    'Completed':   '#4CAF50',
    'Overdue':     '#f44336',
}

MILESTONE_BADGE_COLORS = ['#6f42c1', '#0d6efd', '#198754', '#fd7e14', '#dc3545']

# Kanban sort: highest priority first within a column.
PRIORITY_ORDER = {p: i for i, p in enumerate(TASK_PRIORITIES)}


def _upload_file_path(filename):
    """Resolve a stored document filename inside UPLOAD_FOLDER, or None.

    Filenames are secure_filename()-sanitised at upload, so this containment
    check only fires on a tampered DB value - but a delete must never follow
    a path that escapes the uploads directory.
    """
    if not filename:
        return None
    base = os.path.abspath(UPLOAD_FOLDER)
    path = os.path.abspath(os.path.join(base, filename))
    try:
        if os.path.commonpath([base, path]) != base:
            return None
    except ValueError:  # different drive on Windows
        return None
    return path


def _store_upload(file):
    """Save an uploaded file under a unique, sanitised name.

    Returns (stored_filename, original_filename).

    The random suffix is what makes versioning safe: a timestamp alone collides
    when the same document is re-uploaded twice inside one second, and two
    version rows pointing at one file on disk would let a prune of the older
    row delete the file the newer one is still serving.
    """
    orig = secure_filename(file.filename) or 'document'
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    stored = f'{stamp}_{secrets.token_hex(3)}_{orig}'
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    file.save(os.path.join(UPLOAD_FOLDER, stored))
    return stored, file.filename


def _full_name(u) -> str:
    """Display name as initial-caps 'First Last'; falls back to username."""
    fn = (u.firstname or '').strip().title()
    ln = (u.lastname or '').strip().title()
    return f"{fn} {ln}".strip() or u.username


def _user_name_map(db_session, user_ids) -> dict:
    """{user_id: display name} for a batch of ids - one query, not one per row."""
    ids = {uid for uid in (user_ids or []) if uid}
    if not ids:
        return {}
    users = db_session.query(User).filter(User.id.in_(ids)).all()
    return {u.id: _full_name(u) for u in users}


def _task_priority(task) -> str:
    """A task's priority, defaulting legacy/blank rows to Medium."""
    p = getattr(task, 'priority', None)
    return p if p in PRIORITY_ORDER else TASK_PRIORITY_DEFAULT


def _parse_percent(raw, fallback=0) -> int:
    """Clamp a submitted % complete to 0-100; bad input keeps the fallback."""
    try:
        return max(0, min(100, int(raw)))
    except (TypeError, ValueError):
        return fallback


def allowed_file(filename: str) -> bool:
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# ---------------------------------------------------------------------------
# Never serve a stale project page
# ---------------------------------------------------------------------------

@project_management_bp.after_request
def _no_store(response):
    """
    Project pages render live state - a project's status, the status-distribution
    chart, task progress. These are produced by plain GET requests, so a browser's
    back/forward cache (or a corporate caching proxy) can re-show a frozen copy:
    you edit a project's status, the detail page shows the new value, but the
    dashboard card and status graph still display the old one.

    Force revalidation on every HTML response from this blueprint. JSON (AJAX)
    and static assets are untouched - static files are served by Flask's own
    `static` endpoint, not by this blueprint.
    """
    if response.mimetype == 'text/html':
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        response.headers['Pragma']        = 'no-cache'
        response.headers['Expires']        = '0'
    return response


# ---------------------------------------------------------------------------
# CSRF protection
#
# Every state-changing route in this blueprint is POST-only but, until now,
# accepted requests with no anti-forgery token - unlike the application_support
# module, which already guards its POSTs. We mirror that same per-session token
# scheme here: a hidden `csrf_token` field on classic forms, or an
# `X-CSRFToken` header on the fetch()/AJAX calls.
# ---------------------------------------------------------------------------

def generate_csrf_token():
    """Return the session's CSRF token, creating one on first use."""
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_hex(16)
    return session['csrf_token']


def validate_csrf_token(token):
    """Constant-time compare of a submitted token against the session token."""
    if not token or 'csrf_token' not in session:
        return False
    return secrets.compare_digest(session['csrf_token'], token)


@project_management_bp.context_processor
def inject_csrf_token():
    """Expose `csrf_token` to every template rendered by this blueprint."""
    return {'csrf_token': generate_csrf_token()}


def _valid_csrf() -> bool:
    """
    True when the request carries a valid token. Looks in (in order) the form
    body, the X-CSRFToken header, then a JSON body - covering classic form
    posts, multipart uploads and the fetch() helpers alike.
    """
    token = request.form.get('csrf_token') or request.headers.get('X-CSRFToken')
    if not token and request.is_json:
        data = request.get_json(silent=True) or {}
        token = data.get('csrf_token')
    return validate_csrf_token(token)


def _csrf_json_error():
    """Standard rejection for AJAX/JSON endpoints."""
    return jsonify({'error': 'Invalid or missing security token. Please refresh the page and try again.'}), 400


# ---------------------------------------------------------------------------
# Permission helpers
# ---------------------------------------------------------------------------

def _get_member_record(project_id: int, user_id: int, db_session):
    """Return the ProjectTeamMember row or None."""
    return db_session.query(ProjectTeamMember).filter_by(
        project_id=project_id, user_id=user_id
    ).first()


def is_project_owner(project, user) -> bool:
    """
    True when the user has *owner-level* rights on this project:
      admin  ->  always True
      project_manager who created this project  ->  True
    """
    if user.role == 'admin':
        return True
    if user.role == 'project_manager' and project.created_by == user.id:
        return True
    return False


def is_project_member(project, user, db_session=None) -> bool:
    """
    True when the user can *access* the project (view, add tasks, add docs ...).
    Owners are implicitly members.
    """
    if is_project_owner(project, user):
        return True

    # Otherwise check team membership
    close_session = False
    if db_session is None:
        db_session = get_db_session()
        close_session = True
    try:
        return _get_member_record(project.id, user.id, db_session) is not None
    finally:
        if close_session:
            db_session.close()


def require_project_owner(project, user):
    """Flash + redirect if user is not the project owner."""
    if not is_project_owner(project, user):
        flash('Only the project manager who created this project (or an admin) can perform that action.', 'error')
        return redirect(url_for('project_management.view_project', id=project.id))
    return None


def is_team_lead(project, user, db_session=None) -> bool:
    """True when the user is on this project's team in the **Lead** group."""
    if not user:
        return False
    close_session = False
    if db_session is None:
        db_session = get_db_session()
        close_session = True
    try:
        return db_session.query(ProjectTeamMember).filter_by(
            project_id=project.id, user_id=user.id, member_group='Lead',
        ).first() is not None
    finally:
        if close_session:
            db_session.close()


def can_signoff_sdlc(project, user, db_session=None) -> bool:
    """
    SDLC gate sign-off rights: team **Leads**, plus the project owner (the
    creating PM or an admin) as a bypass. Either way the signature carries the
    signer's name for accountability.
    """
    return (is_project_owner(project, user) if user else False) \
        or is_team_lead(project, user, db_session)


def require_project_member(project, user, db_session=None):
    """Flash + redirect if user is not a member of the project."""
    if not is_project_member(project, user, db_session):
        flash('You do not have access to this project.', 'error')
        return redirect(url_for('project_management.dashboard'))
    return None


def _maybe_autosend_status(db_session, project, milestone, prev_status):
    """Auto-send the status report when a milestone *transitions* into Completed.

    Call AFTER `db_session.commit()`, passing the milestone's status captured
    *before* `update_status_based_on_tasks()` ran. Sends only when the project's
    auto-email toggle is on and at least one recipient is configured. Best-effort:
    every error is swallowed so a notification failure never breaks the task
    update (or its JSON response).
    """
    try:
        if prev_status == MilestoneStatus.COMPLETED:
            return                                   # was already complete
        if milestone.status != MilestoneStatus.COMPLETED:
            return                                   # didn't just complete
        if not getattr(project, 'auto_status_email', True):
            return                                   # auto-send disabled
        if not project.status_recipients:
            return                                   # nobody to send to
        ok, msg = send_status_report(
            project, db_session, trigger='milestone', milestone_name=milestone.name)
        if not ok:
            logger.info("Auto status report not sent for project %s: %s", project.id, msg)
    except Exception:
        logger.exception("Auto status report failed for project %s",
                         getattr(project, 'id', '?'))


CLOSED_LOCK_MESSAGE = 'This project is closed and can no longer be edited.'


def _closed_json_guard(project):
    """For AJAX/JSON endpoints: reject mutations on a closed project."""
    if project.is_closed:
        return jsonify({'error': CLOSED_LOCK_MESSAGE}), 403
    return None


def _closed_redirect_guard(project):
    """For classic form endpoints: flash + redirect when the project is closed."""
    if project.is_closed:
        flash(CLOSED_LOCK_MESSAGE, 'error')
        return redirect(url_for('project_management.view_project', id=project.id))
    return None


def _validate_task_window(start, end, milestone):
    """
    Requirement 2: a task must sit entirely inside its milestone window.

    Returns an error message string, or None when the dates are valid.
    """
    if start > end:
        return 'Task start date must be on or before its end date.'
    if milestone.start_date and start < milestone.start_date:
        return (f'Task start date ({start:%d %b %Y}) cannot be before the '
                f'milestone start ({milestone.start_date:%d %b %Y}).')
    if milestone.end_date and end > milestone.end_date:
        return (f'Task end date ({end:%d %b %Y}) cannot be after the '
                f'milestone deadline ({milestone.end_date:%d %b %Y}).')
    return None


def _parse_optional_date(value):
    """Return a date for a 'YYYY-MM-DD' string, or None for blank/invalid input."""
    if not value:
        return None
    try:
        return datetime.strptime(value, '%Y-%m-%d').date()
    except ValueError:
        return None


def _log_activity(db_session, project_id, user, action, detail=''):
    """
    Append a single audit-trail row. Best-effort: an activity-log failure must
    never break the action it is recording, so callers add it inside the same
    transaction and any error is swallowed (logged by SQLAlchemy on commit).
    """
    db_session.add(ProjectActivity(
        project_id = project_id,
        user_id    = user.id if user else None,
        action     = action,
        detail     = detail or '',
    ))


# ---------------------------------------------------------------------------
# SDLC governance - phase seeding + soft-gate evaluation
#
# Governance is SOFT: unmet gates raise red flags on the project page and
# the dashboard, but never block any action.
# ---------------------------------------------------------------------------

def _seed_sdlc_phases(db_session, project, methodology, form=None) -> int:
    """
    Instantiate the methodology's stage templates onto a new project and map
    them onto milestones.

    Two paths:

    * The PM defined milestones on the create form (`milestone_names[]`) and
      picked which SDLC stages fall under each (`milestone_<i>_stages[]`,
      holding template ids). Stages are grouped exactly as chosen - several
      stages may share one milestone (e.g. a 'Design Doc' milestone holding
      Requirements + Design) - and each stage's default tasks are seeded into
      its milestone. Stages the PM left unmapped stay unassigned; the
      Process tab flags them until they are assigned.

    * No milestones defined: auto-generate one milestone per stage, windowed
      across the project's start..target dates proportionally to the
      template weights (a repeatable stage starts as 'Sprint 1').

    Each ProjectSDLCPhase row snapshots its template (incl. default tasks,
    which also seed every later sprint) so template edits never rewrite a
    running project. Returns the number of stages created.
    """
    ensure_sdlc_templates_seeded(db_session)
    templates = (db_session.query(SDLCPhaseTemplate)
                 .filter_by(methodology=methodology)
                 .order_by(SDLCPhaseTemplate.position, SDLCPhaseTemplate.id)
                 .all())
    if not templates:
        return 0

    # The PM picks which of the standard stages APPLY to this project
    # (sdlc_stage_ids[]) - many projects don't need the full process. Only
    # the ticked stages are instantiated; an empty/absent selection keeps
    # every stage (older forms, and the conservative default).
    if form is not None:
        selected_ids = set()
        for raw in form.getlist('sdlc_stage_ids[]'):
            try:
                selected_ids.add(int(raw))
            except (TypeError, ValueError):
                continue
        if selected_ids:
            picked = [t for t in templates if t.id in selected_ids]
            if picked:
                templates = picked

    phase_by_template = {}
    for i, tpl in enumerate(templates):
        phase = ProjectSDLCPhase(
            project_id=project.id, position=i, name=tpl.name,
            description=tpl.description, exit_criteria=tpl.exit_criteria,
            doc_categories=tpl.doc_categories,
            default_tasks=tpl.default_tasks,
            repeatable=tpl.repeatable,
        )
        db_session.add(phase)
        phase_by_template[tpl.id] = phase
    db_session.flush()

    ms_names = form.getlist('milestone_names[]') if form is not None else []
    if any(n.strip() for n in ms_names):
        # PM-defined milestones + stage grouping.
        ms_descs  = form.getlist('milestone_descriptions[]')
        ms_starts = form.getlist('milestone_start_dates[]')
        ms_ends   = form.getlist('milestone_end_dates[]')
        for i, name in enumerate(ms_names):
            if not name.strip():
                continue
            end = _parse_optional_date(ms_ends[i] if i < len(ms_ends) else None)
            if not end:
                raise ValueError(f"Milestone '{name}' needs an end date.")
            start = (_parse_optional_date(ms_starts[i] if i < len(ms_starts) else None)
                     or project.start_date or end)
            if start > end:
                start = end
            milestone = ProjectMilestone(
                project_id=project.id, name=name.strip(),
                description=ms_descs[i] if i < len(ms_descs) else '',
                start_date=start, end_date=end,
            )
            db_session.add(milestone)
            db_session.flush()
            for raw_tid in form.getlist(f'milestone_{i}_stages[]'):
                try:
                    phase = phase_by_template.get(int(raw_tid))
                except (TypeError, ValueError):
                    phase = None
                if phase:
                    _assign_phase_to_milestone(db_session, phase, milestone)
        return len(templates)

    # Auto-generated plan: one milestone per stage across the project window.
    if (project.start_date and project.target_end_date
            and project.start_date <= project.target_end_date):
        windows = split_window(project.start_date, project.target_end_date,
                               [t.weight for t in templates])
        for i, tpl in enumerate(templates):
            w_start, w_end = windows[i]
            phase = phase_by_template[tpl.id]
            milestone = ProjectMilestone(
                project_id=project.id,
                name=(f'{_iteration_label(phase)} 1' if tpl.repeatable
                      else tpl.name),
                description=tpl.description,
                start_date=w_start, end_date=w_end,
            )
            db_session.add(milestone)
            db_session.flush()
            _assign_phase_to_milestone(db_session, phase_by_template[tpl.id],
                                       milestone)
    return len(templates)


def _seed_simple_plan(db_session, project, form):
    """
    Manual plan for a SIMPLE project (no SDLC process): create the PM's
    milestones exactly as entered on the create form - name + deadline,
    optional start date and description - and the tasks typed under each
    (milestone_<i>_task_names[]). Task windows default to the milestone
    window; assignee, priority, dependencies etc. are managed later from
    the project page. Returns (milestone_count, task_count).
    """
    ms_names  = form.getlist('milestone_names[]')
    ms_descs  = form.getlist('milestone_descriptions[]')
    ms_starts = form.getlist('milestone_start_dates[]')
    ms_ends   = form.getlist('milestone_end_dates[]')
    ms_count = task_count = 0
    for i, name in enumerate(ms_names):
        if not name.strip():
            continue
        end = _parse_optional_date(ms_ends[i] if i < len(ms_ends) else None)
        if not end:
            raise ValueError(f"Milestone '{name}' needs a deadline.")
        start = (_parse_optional_date(ms_starts[i] if i < len(ms_starts) else None)
                 or project.start_date or end)
        if start > end:
            start = end
        milestone = ProjectMilestone(
            project_id=project.id, name=name.strip(),
            description=ms_descs[i] if i < len(ms_descs) else '',
            start_date=start, end_date=end,
        )
        db_session.add(milestone)
        db_session.flush()
        ms_count += 1
        for tname in form.getlist(f'milestone_{i}_task_names[]'):
            if not tname.strip():
                continue
            db_session.add(ProjectTask(
                milestone_id=milestone.id, name=tname.strip(),
                start_date=start, end_date=end,
                status=TaskStatus.NOT_STARTED,
            ))
            task_count += 1
    return ms_count, task_count


def _iteration_label(phase) -> str:
    """
    What one increment of a repeatable stage is called: 'Sprint' for sprint
    stages, 'Release' for release/go-live stages, otherwise 'Iteration'.
    Drives the auto-names Sprint 1 / Release 2 / ... for iteration milestones.
    """
    name = (phase.name or '').lower()
    if 'sprint' in name:
        return 'Sprint'
    if 'release' in name or 'go-live' in name or 'golive' in name:
        return 'Release'
    return 'Iteration'


def _assign_phase_to_milestone(db_session, phase, milestone):
    """
    Link a stage to a milestone and seed the stage's default tasks into it
    (windowed to the milestone). The PM's grouping decision - several stages
    may point at one milestone, and a repeatable stage at several milestones.
    """
    db_session.add(SDLCPhaseMilestone(phase_id=phase.id,
                                      milestone_id=milestone.id))
    start = milestone.start_date or milestone.end_date
    # Don't duplicate a default task the milestone already carries (e.g. the
    # stage was unlinked and re-linked, or two stages share a task name).
    existing_names = {t.name for t in milestone.tasks}
    for tname, cat, sub in phase.task_specs():
        if tname in existing_names:
            continue
        db_session.add(ProjectTask(
            milestone_id=milestone.id, name=tname,
            category=cat or None, sub_category=sub or None,
            start_date=start, end_date=milestone.end_date,
            status=TaskStatus.NOT_STARTED,
        ))


def _sync_milestone_stages(db_session, project, milestone, selected_ids):
    """
    Make `milestone`'s stage links match `selected_ids` (ProjectSDLCPhase
    ids from the add/edit-milestone modal). Newly selected stages are linked
    and their default tasks seeded; deselected stages are unlinked (their
    tasks stay in the milestone - unlinking is a grouping change, not a
    delete). Returns an error message, or None on success.
    """
    phases = {p.id: p for p in db_session.query(ProjectSDLCPhase)
              .filter_by(project_id=project.id).all()}
    selected = {pid for pid in selected_ids if pid in phases}
    current = {l.phase_id: l for l in db_session.query(SDLCPhaseMilestone)
               .filter_by(milestone_id=milestone.id).all()
               if l.phase_id in phases}

    for pid in selected - set(current):
        phase = phases[pid]
        if not phase.repeatable:
            elsewhere = (db_session.query(SDLCPhaseMilestone)
                         .filter(SDLCPhaseMilestone.phase_id == pid,
                                 SDLCPhaseMilestone.milestone_id != milestone.id)
                         .first())
            if elsewhere:
                return (f"Stage '{phase.name}' is already grouped under "
                        f"another milestone - remove it there first.")
        _assign_phase_to_milestone(db_session, phase, milestone)

    for pid in set(current) - selected:
        db_session.delete(current[pid])
    return None


def _sdlc_phase_inputs(project):
    """
    Build evaluate_phases() input from ORM state (see sdlc.py contract).

    A stage may span several milestones (agile sprints) and a milestone may
    hold several stages (PM grouping); the gate looks at the AGGREGATE -
    every task across every assigned milestone - and the stage window ends
    with its latest milestone.
    """
    ms_by_id = {m.id: m for m in project.milestones}

    inputs = []
    for phase in project.sdlc_phases:
        milestones = [ms_by_id[l.milestone_id] for l in phase.milestone_links
                      if l.milestone_id in ms_by_id]
        ms = None
        if milestones:
            tasks = [t for m in milestones for t in m.tasks]
            ms = {
                'end_date':    max(m.end_date for m in milestones),
                'tasks_total': len(tasks),
                'tasks_done':  sum(1 for t in tasks
                                   if t.status == TaskStatus.COMPLETED),
                'tasks_started': sum(1 for t in tasks
                                     if t.status != TaskStatus.NOT_STARTED),
            }
        inputs.append({
            'name':           phase.name,
            'signed_off':     phase.is_signed_off,
            # Phase snapshots taken before the document groups were renamed
            # still require the old category names - normalise them so the
            # gate compares like with like (unmapped names pass through).
            'doc_categories': [normalize_document_category(c) or c
                               for c in phase.doc_category_list()],
            'repeatable':     bool(phase.repeatable),
            'milestone':      ms,
            'milestone_ids':  [m.id for m in milestones],
            'iteration_label': _iteration_label(phase),
            # Carried through evaluate_phases untouched, for the template.
            'phase':          phase,
            'milestones_obj': milestones,
            'window_start':   min((m.start_date for m in milestones
                                   if m.start_date), default=None),
            'window_end':     (max(m.end_date for m in milestones)
                               if milestones else None),
        })
    return inputs


def _sdlc_context(project):
    """Phase states + red flags for a governed project, or None (legacy)."""
    if not project.methodology or not project.sdlc_phases:
        return None
    # Present both the raw and the normalised (legacy -> new group) category
    # of every document, so gates match regardless of when either side was
    # written.
    doc_cats = set()
    for d in project.documents:
        if d.category:
            doc_cats.add(d.category)
            normalized = normalize_document_category(d.category)
            if normalized:
                doc_cats.add(normalized)
    inputs = _sdlc_phase_inputs(project)
    eligible = {m.user_id for m in project.team_members if m.user_id} | {project.created_by}
    reviewers = {m.user_id for m in project.team_members if m.member_group == 'Lead' and m.user_id} | {project.created_by}
    for item in inputs:
        g = gate_view(item['phase'], item['milestones_obj'], project.documents, eligible, reviewers)
        item['governance'] = g
        if g['enabled']:
            item['signed_off'] = g['status'] == 'approved' and not g['blockers']
    states = evaluate_phases(inputs, doc_cats)
    for state in states:
        g = state['governance']
        if g['enabled']:
            if not state['milestone'] or not state['milestone']['tasks_total'] or not state['tasks_complete']:
                g['blockers'].append('Complete the tasks in the assigned milestone(s).')
            if state['docs_missing']:
                g['blockers'].append('Upload required documents: ' + ', '.join(state['docs_missing']))
            if g['blockers']:
                state['gate_passed'] = False
                if state['state'] in ('passed', 'ready'):
                    state['state'] = 'active'
                g['next_action'] = g['blockers'][0]
            if g['overdue']:
                state['flags'].append('The target review date is overdue.')
            if g['stale']:
                state['flags'].append('The reviewed schedule or evidence changed; re-review is required.')
    flags = collect_flags(states)
    return {
        'methodology':       project.methodology,
        'methodology_label': METHODOLOGY_LABELS.get(project.methodology,
                                                    project.methodology),
        'states': states,
        'flags':  flags,
        'passed': sum(1 for s in states if s['gate_passed']),
        'total':  len(states),
    }


# ---------------------------------------------------------------------------
# Baselines - plan snapshots and planned-vs-actual variance
# ---------------------------------------------------------------------------

def _snapshot_plan(db_session, project, user, name):
    """Freeze the current plan into a new ProjectBaseline (caller commits)."""
    baseline = ProjectBaseline(
        project_id=project.id, name=name, created_by=user.id if user else None)
    db_session.add(baseline)
    db_session.flush()
    for ms in project.milestones:
        db_session.add(BaselineMilestone(
            baseline_id=baseline.id, milestone_id=ms.id, name=ms.name,
            start_date=ms.start_date, end_date=ms.end_date))
        for t in ms.tasks:
            db_session.add(BaselineTask(
                baseline_id=baseline.id, task_id=t.id, name=t.name,
                milestone_name=ms.name, start_date=t.start_date,
                end_date=t.end_date, priority=_task_priority(t),
                status=t.status.value))
    return baseline


def _baseline_variance(project, baseline):
    """
    Compare the live plan against a baseline snapshot.

    Matching is by the live task's row id (captured as BaselineTask.task_id):
    a live task with no snapshot row was added after the baseline; a snapshot
    row whose task no longer exists was removed. Variance is in calendar days,
    positive = later than baselined (slipped).
    """
    live_tasks = {t.id: t for t in project.get_all_tasks()}
    base_tasks = {bt.task_id: bt for bt in baseline.tasks if bt.task_id}

    rows, added, removed = [], [], []
    slipped = ahead = on_plan = 0

    for tid, t in live_tasks.items():
        bt = base_tasks.get(tid)
        if not bt:
            added.append(t)
            continue
        end_var = (t.end_date - bt.end_date).days
        start_var = (t.start_date - bt.start_date).days
        if end_var > 0:
            slipped += 1
        elif end_var < 0:
            ahead += 1
        else:
            on_plan += 1
        rows.append({
            'task': t,
            'baseline_start': bt.start_date,
            'baseline_end': bt.end_date,
            'start_var': start_var,
            'end_var': end_var,
        })
    for tid, bt in base_tasks.items():
        if tid not in live_tasks:
            removed.append(bt)

    # Show the biggest slips first; on-plan rows sort by current end date.
    rows.sort(key=lambda r: (-r['end_var'], r['task'].end_date))

    live_ends = [t.end_date for t in live_tasks.values()]
    base_ends = [bt.end_date for bt in baseline.tasks]
    finish_var = None
    if live_ends and base_ends:
        finish_var = (max(live_ends) - max(base_ends)).days

    return {
        'rows': rows,
        'added': added,
        'removed': removed,
        'slipped': slipped,
        'ahead': ahead,
        'on_plan': on_plan,
        'finish_var': finish_var,
        'baseline_finish': max(base_ends) if base_ends else None,
        'current_finish': max(live_ends) if live_ends else None,
    }


# ---------------------------------------------------------------------------
# Resource workload
# ---------------------------------------------------------------------------

def _peak_concurrency(windows):
    """
    Sweep-line maximum overlap over inclusive (start, end) date windows.
    Returns (peak, peak_start_date) - the highest number of simultaneously
    active windows and the first date it occurs.
    """
    if not windows:
        return 0, None
    events = []
    for s, e in windows:
        events.append((s, 1))
        events.append((e + timedelta(days=1), -1))
    events.sort()
    depth = peak = 0
    peak_at = None
    for day, delta in events:
        depth += delta
        if depth > peak:
            peak = depth
            peak_at = day
    return peak, peak_at


def _workload_data(project, user_map):
    """
    Per-assignee workload rollup for the Workload tab.

    Peak load = maximum number of that person's *open* (non-completed) tasks
    whose date windows overlap - the classic overallocation signal. Only
    open tasks count toward load; completed work is history.
    """
    per_user = {}
    unassigned_open = []
    for t in project.get_all_tasks():
        if not t.assigned_to:
            if t.status != TaskStatus.COMPLETED:
                unassigned_open.append(t)
            continue
        per_user.setdefault(t.assigned_to, []).append(t)

    members = []
    for uid, tasks in per_user.items():
        open_tasks = [t for t in tasks if t.status != TaskStatus.COMPLETED]
        overdue = [t for t in open_tasks if t.is_overdue()]
        peak, peak_at = _peak_concurrency(
            [(t.start_date, t.end_date) for t in open_tasks])
        remaining_days = sum(
            max(1, (t.end_date - max(t.start_date, date.today())).days + 1)
            for t in open_tasks if t.end_date >= date.today())
        members.append({
            'user_id': uid,
            'name': user_map.get(uid, f'User #{uid}'),
            'total': len(tasks),
            'open': len(open_tasks),
            'completed': len(tasks) - len(open_tasks),
            'overdue': len(overdue),
            'peak': peak,
            'peak_at': peak_at,
            'remaining_days': remaining_days,
            'open_tasks': sorted(open_tasks, key=lambda t: t.end_date),
        })
    # Heaviest load first.
    members.sort(key=lambda m: (-m['open'], -m['peak'], m['name']))
    max_open = max((m['open'] for m in members), default=0)

    return {
        'members': members,
        'max_open': max_open,
        'unassigned_open': sorted(unassigned_open, key=lambda t: t.end_date),
    }


# ---------------------------------------------------------------------------
# CPM - task dependencies, critical path, network diagram
# ---------------------------------------------------------------------------

def _load_project_dependencies(db_session, task_ids):
    """All dependency rows whose successor belongs to this project."""
    if not task_ids:
        return []
    return (db_session.query(TaskDependency)
            .filter(TaskDependency.successor_id.in_(task_ids))
            .all())


def _save_task_dependencies(db_session, task, raw_json, project):
    """
    Replace `task`'s predecessor links with the submitted set.

    raw_json is the task form's `dependencies` field: a JSON array of
    {"predecessor_id": int, "type": "FS|SS|FF|SF", "lag": int}. Returns an
    error message string (nothing is written) or None on success. Validates:
    same-project predecessors only, no self/duplicate links, known link type,
    bounded lag, and - against every other link in the project - acyclicity.
    """
    try:
        entries = json.loads(raw_json) if raw_json else []
        if not isinstance(entries, list):
            raise ValueError
    except (ValueError, TypeError):
        return 'Invalid dependency payload.'

    project_task_ids = {t.id for t in project.get_all_tasks()}
    task_by_id = {t.id: t for t in project.get_all_tasks()}

    cleaned = []
    seen = set()
    for e in entries:
        try:
            pred_id = int(e.get('predecessor_id'))
            dep_type = str(e.get('type', 'FS')).upper()
            lag = int(e.get('lag') or 0)
        except (TypeError, ValueError, AttributeError):
            return 'Invalid dependency entry.'
        if pred_id == task.id:
            return 'A task cannot depend on itself.'
        if pred_id not in project_task_ids:
            return 'Dependencies must reference tasks in the same project.'
        if dep_type not in DEPENDENCY_TYPES:
            return f'Unknown dependency type "{dep_type}".'
        if not (-MAX_LAG_DAYS <= lag <= MAX_LAG_DAYS):
            return f'Lag must be between -{MAX_LAG_DAYS} and {MAX_LAG_DAYS} days.'
        if pred_id in seen:
            return f'Duplicate predecessor "{task_by_id[pred_id].name}".'
        seen.add(pred_id)
        cleaned.append({'predecessor_id': pred_id, 'type': dep_type, 'lag': lag})

    # Acyclicity: every project edge except this task's current incoming ones,
    # plus the proposed set, must still form a DAG.
    other_edges = [
        (d.predecessor_id, d.successor_id)
        for d in _load_project_dependencies(db_session, list(project_task_ids))
        if d.successor_id != task.id
    ]
    proposed = other_edges + [(c['predecessor_id'], task.id) for c in cleaned]
    cycle = find_cycle(proposed)
    if cycle:
        names = ' -> '.join(task_by_id[t].name for t in cycle if t in task_by_id)
        return f'This would create a circular dependency ({names}).'

    (db_session.query(TaskDependency)
     .filter_by(successor_id=task.id)
     .delete(synchronize_session=False))
    for c in cleaned:
        db_session.add(TaskDependency(
            predecessor_id=c['predecessor_id'], successor_id=task.id,
            dep_type=c['type'], lag_days=c['lag']))
    return None


def _cpm_analysis(project, db_session):
    """
    Run CPM for a project and package everything the page needs.

    Returns (cpm_result_or_None, dependencies, context) where context is a
    template-ready dict: per-task chips, the network-diagram payload, the
    summary strip and schedule warnings. cpm_result is None when the project
    has no dependencies (CPM is meaningless without a network).
    """
    all_tasks = project.get_all_tasks()
    deps = _load_project_dependencies(db_session, [t.id for t in all_tasks])

    empty = {
        'has_network': False, 'task_info': {}, 'deps_by_task': {},
        'network_data': None, 'summary': None, 'warnings': [],
        'critical_ids': [],
    }
    if not deps:
        return None, [], empty

    dep_dicts = [{'predecessor_id': d.predecessor_id,
                  'successor_id': d.successor_id,
                  'type': d.dep_type, 'lag': d.lag_days} for d in deps]
    task_dicts = [{'id': t.id, 'name': t.name,
                   'start': t.start_date, 'end': t.end_date} for t in all_tasks]

    result = compute_cpm(task_dicts, dep_dicts)
    if not result.get('ok'):
        # A cycle in stored data (should be impossible) - degrade gracefully.
        logger.warning('CPM failed for project %s: %s',
                       project.id, result.get('error'))
        return None, deps, empty

    task_by_id = {t.id: t for t in all_tasks}

    # Per-task info for badges on the task table + modal prefill.
    task_info = {}
    for tid, info in result['tasks'].items():
        task_info[tid] = {
            'is_critical': info['is_critical'],
            'total_float': info['total_float'],
        }
    deps_by_task = {}
    for d in deps:
        deps_by_task.setdefault(d.successor_id, []).append({
            'predecessor_id': d.predecessor_id,
            'type': d.dep_type,
            'lag': d.lag_days,
        })

    # Warnings: entered-date conflicts + overdue critical work.
    warnings = [c['message'] for c in result['date_conflicts']]
    overdue_critical = [
        task_by_id[tid].name for tid in result['critical_path']
        if tid in task_by_id and task_by_id[tid].is_overdue()
    ]
    if overdue_critical:
        shown = ', '.join(f'"{n}"' for n in overdue_critical[:3])
        more = f' (+{len(overdue_critical) - 3} more)' if len(overdue_critical) > 3 else ''
        warnings.insert(0,
            f'Critical-path task(s) overdue: {shown}{more} - the project end '
            f'date is at risk.')

    # Network diagram payload (only tasks that take part in a dependency).
    layout = layout_network(result, dep_dicts)
    nodes = []
    for tid, pos in layout['nodes'].items():
        t = task_by_id.get(tid)
        info = result['tasks'][tid]
        if not t:
            continue
        nodes.append({
            'id': tid,
            'name': t.name,
            'status': t.status.value,
            'layer': pos['layer'],
            'row': pos['row'],
            'es': info['es'], 'ef': info['ef'],
            'ls': info['ls'], 'lf': info['lf'],
            'duration': info['duration'],
            'float': info['total_float'],
            'critical': info['is_critical'],
            'start': info['es_date'].strftime('%d %b'),
            'end': info['ef_date'].strftime('%d %b %Y'),
        })
    critical_edge_set = set(result['critical_edges'])
    edges = [{
        'from': d.predecessor_id, 'to': d.successor_id,
        'type': d.dep_type, 'lag': d.lag_days,
        'critical': (d.predecessor_id, d.successor_id) in critical_edge_set,
    } for d in deps
        if d.predecessor_id in layout['nodes'] and d.successor_id in layout['nodes']]

    critical_names = [task_by_id[tid].name for tid in result['critical_path']
                      if tid in task_by_id]
    summary = {
        'duration': result['project_duration'],
        'end_date': result['project_end_date'].strftime('%d %b %Y'),
        'critical_count': len(result['critical_path']),
        'critical_names': critical_names,
        'link_count': len(deps),
    }

    context = {
        'has_network': bool(nodes),
        'task_info': task_info,
        'deps_by_task': deps_by_task,
        # The TEMPLATE serialises this (|tojson), which escapes <, > and &
        # to unicode escapes. Pre-dumping it here and marking it |safe in
        # the template is what let a task name containing a closing
        # script tag break out of the script element.
        'network_data': {'nodes': nodes, 'edges': edges},
        'summary': summary,
        'warnings': warnings,
        'critical_ids': result['critical_path'],
    }
    return result, deps, context


# ---------------------------------------------------------------------------
# Gantt chart generator - task detail
#
# Milestone header bars (navy, showing the milestone window + its SDLC
# stages) followed by indented task bars coloured by status, with baseline
# ghost bars, a red edge on critical-path tasks and a Today line.
# ---------------------------------------------------------------------------

def _build_gantt(project, user_map=None, cpm_ctx=None,
                 baseline_map=None, stage_names_by_ms=None) -> str | None:
    user_map = user_map or {}
    baseline_map = baseline_map or {}
    stage_names_by_ms = stage_names_by_ms or {}
    task_info = (cpm_ctx or {}).get('task_info') or {}

    milestones = sorted(
        (m for m in project.milestones if m.end_date),
        key=lambda m: (m.start_date or m.end_date, m.end_date, m.id))
    if not milestones:
        return None

    DAY = 86400000
    labels, bases, xs, colors, lines, hovers, texts = [], [], [], [], [], [], []
    ghost_labels, ghost_bases, ghost_xs = [], [], []
    seen = set()

    def _label(text):
        while text in seen:
            text += ' '
        seen.add(text)
        return text

    for m in milestones:
        m_start = m.start_date or m.end_date
        stages = ', '.join(stage_names_by_ms.get(m.id, []))
        lab = _label(f'<b>{m.name}</b>')
        labels.append(lab)
        bases.append(m_start)
        xs.append(((m.end_date - m_start).days + 1) * DAY)
        colors.append('#1f3a5f')
        lines.append(dict(width=0))
        texts.append(stages)
        hovers.append(f"<b>{m.name}</b> (milestone)<br>"
                      f"{('SDLC stages: ' + stages + '<br>') if stages else ''}"
                      f"{m_start:%d %b %Y} -> {m.end_date:%d %b %Y}<br>"
                      f"{m.completion_percentage}% complete - {m.status.value}"
                      f"<extra></extra>")
        for t in m.tasks:
            info = task_info.get(t.id) or {}
            critical = bool(info.get('is_critical'))
            status = 'Overdue' if t.is_overdue() else t.status.value
            lab = _label('   ' + (t.name if len(t.name) <= 42 else t.name[:41] + '...'))
            labels.append(lab)
            bases.append(t.start_date)
            xs.append(((t.end_date - t.start_date).days + 1) * DAY)
            colors.append(STATUS_COLORS.get(status, '#8695a4'))
            lines.append(dict(color='#dc3545', width=2) if critical else dict(width=0))
            texts.append('')
            assignee = user_map.get(t.assigned_to, 'Unassigned') if t.assigned_to else 'Unassigned'
            flt = ('critical path' if critical else
                   (f"float {info.get('total_float')}d" if info.get('total_float') is not None else ''))
            hovers.append(f"<b>{t.name}</b><br>{assignee} - {_task_priority(t)}<br>"
                          f"{t.start_date:%d %b %Y} -> {t.end_date:%d %b %Y}<br>"
                          f"{t.effective_percent()}% - {status}"
                          f"{('<br>' + flt) if flt else ''}<extra></extra>")
            if t.id in baseline_map:
                b_start, b_end = baseline_map[t.id]
                ghost_labels.append(lab)
                ghost_bases.append(b_start)
                ghost_xs.append(((b_end - b_start).days + 1) * DAY)

    fig = go.Figure()
    if ghost_labels:      # baseline ghosts sit slightly below their live bar
        fig.add_trace(go.Bar(
            y=ghost_labels, x=ghost_xs, base=ghost_bases, orientation='h',
            width=0.24, offset=0.12, marker=dict(color='rgba(134,149,164,0.38)'),
            hoverinfo='skip', showlegend=False))
    fig.add_trace(go.Bar(
        y=labels, x=xs, base=bases, orientation='h',
        width=0.55, offset=-0.28,
        marker=dict(color=colors, line=dict(
            color=[l.get('color', 'rgba(0,0,0,0)') for l in lines],
            width=[l.get('width', 0) for l in lines])),
        text=texts, textposition='inside', insidetextanchor='start',
        textfont=dict(size=10.5, color='white'),
        hovertemplate=hovers, showlegend=False))

    today = date.today()
    fig.add_shape(type='line', x0=today, x1=today, y0=-0.5, y1=len(labels) - 0.5,
                  line=dict(color='#dc3545', width=1.6, dash='dot'))
    fig.add_annotation(x=today, y=len(labels) - 0.5, yshift=14, text='Today',
                       showarrow=False, font=dict(size=10.5, color='#dc3545'))

    fig.update_layout(
        height=max(280, 96 + 27 * len(labels)),
        margin=dict(l=10, r=24, t=28, b=36),
        barmode='overlay',
        plot_bgcolor='rgba(249,250,251,0.9)',
        paper_bgcolor='white',
        xaxis=dict(type='date', showgrid=True,
                   gridcolor='rgba(200,206,211,0.45)', tickfont=dict(size=11)),
        yaxis=dict(autorange='reversed', automargin=True,
                   tickfont=dict(size=11.5, color='#374151')),
        bargap=0.25,
    )
    return json.dumps(
        {'figure': fig, 'config': {'responsive': True, 'displayModeBar': False}},
        cls=plotly.utils.PlotlyJSONEncoder,
    )


# ---------------------------------------------------------------------------
# RAG health labels (dashboard facets + export metadata)
# ---------------------------------------------------------------------------

HEALTH_BAR_LABELS = {
    'green': 'On track', 'amber': 'At risk', 'red': 'Off track', 'neutral': '-',
}


# ---------------------------------------------------------------------------
# Dashboard search helpers
#
# The dashboard supports three independent, optional conditions:
#   - project name  - wildcard search (`*` = many chars, `?` = one char;
#                     a plain term is matched as a substring)
#   - created from  - Project.created_at on/after this date
#   - created to    - Project.created_at on/before this date (whole day)
# A `match` mode decides how the supplied conditions combine:
#   - all (AND, default) - every supplied condition must match
#   - any (OR)           - at least one supplied condition must match
# Omitting a field drops that condition, so "name only", "date only" and
# "name + dates" all work, under either AND or OR.
# ---------------------------------------------------------------------------

def _name_search_clause(q):
    """Wildcard name match. `*`/`?` become SQL `%`/`_`; otherwise a substring
    match. Any literal `%`/`_`/`\\` the user types is escaped first."""
    if not q:
        return None
    esc = q.replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')
    if '*' in q or '?' in q:
        pattern = esc.replace('*', '%').replace('?', '_')
    else:
        pattern = f'%{esc}%'
    return Project.name.ilike(pattern, escape='\\')


def _created_range_clause(start_dt, end_dt):
    """A single combined clause for the created-date range, or None."""
    clauses = []
    if start_dt:
        clauses.append(Project.created_at >= start_dt)
    if end_dt:
        # include the whole chosen end day
        clauses.append(Project.created_at < end_dt + timedelta(days=1))
    return and_(*clauses) if clauses else None


def _apply_dashboard_search(query, q, start_dt, end_dt, match):
    """Apply the name + date conditions to `query` using AND (all) or OR (any)."""
    conditions = [c for c in (_name_search_clause(q),
                              _created_range_clause(start_dt, end_dt)) if c is not None]
    if not conditions:
        return query
    combiner = or_ if match == 'any' else and_
    return query.filter(combiner(*conditions))


OPEN_PROJECT_STATUSES = (ProjectStatus.PLANNING, ProjectStatus.IN_PROGRESS,
                         ProjectStatus.ON_HOLD)


def _four_quarter_window_start() -> datetime:
    """Start of the quarter three quarters before the current one, so the
    window spans the current quarter plus the previous three (4 in total)."""
    today = date.today()
    month = 3 * ((today.month - 1) // 3) + 1 - 9
    year = today.year
    while month <= 0:
        month += 12
        year -= 1
    return datetime(year, month, 1)


def _apply_portfolio_scope(query):
    """Default dashboard scope: projects initiated in the last 4 quarters,
    plus every open project regardless of age."""
    return query.filter(or_(
        Project.created_at >= _four_quarter_window_start(),
        Project.status.in_(OPEN_PROJECT_STATUSES),
    ))


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------

@project_management_bp.route('/')
def dashboard():
    # The project list is publicly viewable, read-only. Login is NOT required.
    # Anonymous visitors see all projects; logged-in non-admins see the subset
    # they own / belong to. Create / edit / delete remain gated in the template
    # and in each endpoint.
    user = get_current_user()   # may be None (anonymous visitor)

    q          = (request.args.get('q') or '').strip()
    page       = request.args.get('page', 1, type=int)
    per_page   = 12
    # Dates are optional - no forced default, so a name-only search spans all dates.
    start_date = (request.args.get('start_date') or '').strip()
    end_date   = (request.args.get('end_date') or '').strip()
    match      = request.args.get('match', 'all')
    if match not in ('all', 'any'):
        match = 'all'
    # Optional status filter (Projects tab). Invalid values are ignored.
    # 'done' is a combined facet used by the Completed KPI tile: the tile
    # counts Completed + Closed together, so its filter matches both.
    status_sel = (request.args.get('status') or '').strip()
    status_multi = None
    status_enum = None
    if status_sel == 'done':
        status_multi = [ProjectStatus.COMPLETED, ProjectStatus.CLOSED]
    else:
        try:
            status_enum = ProjectStatus(status_sel) if status_sel else None
        except ValueError:
            status_enum, status_sel = None, ''
    # "Only projects I created" - meaningful for PMs/admins, who otherwise
    # also see projects they merely belong to.
    mine = request.args.get('mine') == '1'
    # Health (RAG) facet. Health is derived per project, not stored, so this
    # filters in Python after the query. Invalid values are ignored.
    health_sel = (request.args.get('health') or '').strip()
    if health_sel not in ('green', 'amber', 'red', 'neutral'):
        health_sel = ''
    # Attention facet used by the Overdue Tasks / Open High Risks tiles.
    # Like health, it is derived per project, so it filters in Python.
    flag_sel = (request.args.get('flag') or '').strip()
    if flag_sel not in ('overdue', 'highrisk'):
        flag_sel = ''
    # Which tab to show active on load ('dashboard' or 'projects').
    tab        = request.args.get('tab', 'dashboard')
    if tab not in ('dashboard', 'projects'):
        tab = 'dashboard'

    start_dt = end_dt = None
    try:
        if start_date:
            start_dt = datetime.strptime(start_date, '%Y-%m-%d')
        if end_date:
            end_dt = datetime.strptime(end_date, '%Y-%m-%d')
    except ValueError:
        flash('Invalid date format.', 'error')
        return redirect(url_for('project_management.dashboard'))

    db_session = get_db_session()
    try:
        query = db_session.query(Project).options(
            selectinload(Project.team_members),
            # Tasks are iterated for every matching project (avg completion,
            # health, the new portfolio timeline) - load them in one IN-query
            # instead of lazily per milestone.
            selectinload(Project.milestones).selectinload(ProjectMilestone.tasks),
            selectinload(Project.stakeholders),
            # SDLC governance flags need each project's phases (+ their
            # milestone assignments) and document categories - same IN-query
            # pattern, so no per-row lazy loads.
            selectinload(Project.sdlc_phases)
                .selectinload(ProjectSDLCPhase.milestone_links),
            selectinload(Project.documents),
            # Open High/Critical risks are aggregated portfolio-wide for the
            # KPI tiles (and per row for the Flags column) - eager-load them.
            selectinload(Project.risk_logs),
        )

        # Anonymous visitors and admins see every project; other roles see the
        # projects they own or belong to.
        if user and user.role == 'team_member':
            team_projects = db_session.query(ProjectTeamMember.project_id).filter_by(user_id=user.id)
            query = query.filter(Project.id.in_(team_projects))
        elif user and user.role == 'project_manager':
            team_projects = db_session.query(ProjectTeamMember.project_id).filter_by(user_id=user.id)
            query = query.filter(or_(
                Project.created_by == user.id,
                Project.id.in_(team_projects),
            ))

        # "Only projects I created" narrows the PM/admin view further.
        if mine and user and user.role in ('admin', 'project_manager'):
            query = query.filter(Project.created_by == user.id)

        # Name (wildcard) + created-date range, combined with AND or OR.
        query = _apply_dashboard_search(query, q, start_dt, end_dt, match)

        # Status is a hard filter, never part of the AND/OR matching.
        if status_enum:
            query = query.filter(Project.status == status_enum)
        elif status_multi:
            query = query.filter(Project.status.in_(status_multi))

        # Default scope: last-4-quarter initiations + all open projects.
        # An explicit created-date search - or an explicit status filter,
        # so e.g. old Closed projects stay reachable - overrides it.
        if not start_dt and not end_dt and not status_enum and not status_multi:
            query = _apply_portfolio_scope(query)

        all_projects = query.order_by(Project.created_at.desc()).all()

        # Health facet counts describe the search result BEFORE the health
        # filter is applied, so the RAG tiles remain stable navigation
        # targets (clicking "Off Track" doesn't zero the other tiles).
        health_counts = {'green': 0, 'amber': 0, 'red': 0, 'neutral': 0}
        for p in all_projects:
            health_counts[p.get_health_state()] += 1
        if health_sel:
            all_projects = [p for p in all_projects
                            if p.get_health_state() == health_sel]

        # Portfolio-wide attention aggregates for the KPI tiles - computed
        # BEFORE the flag facet is applied, so the Overdue / High-Risk tiles
        # stay stable navigation targets (same rule as the health facet).
        overdue_total   = sum(len(p.get_overdue_tasks()) for p in all_projects)
        high_risk_total = sum(len(p.get_open_high_risks()) for p in all_projects)
        if flag_sel == 'overdue':
            all_projects = [p for p in all_projects if p.get_overdue_tasks()]
        elif flag_sel == 'highrisk':
            all_projects = [p for p in all_projects if p.get_open_high_risks()]

        # Metrics/chart reflect every matching project; the table is paginated.
        total_projects = len(all_projects)
        status_counts  = {s.value: 0 for s in ProjectStatus}
        for p in all_projects:
            status_counts[p.status.value] += 1

        avg_completion = (
            sum(p.get_completion_percentage() for p in all_projects) / total_projects
            if total_projects else 0
        )

        total_pages = max(1, (total_projects + per_page - 1) // per_page)
        page        = min(max(page, 1), total_pages)
        projects    = all_projects[(page - 1) * per_page: page * per_page]

        # SDLC soft-governance: red-flag count per listed project (0 for
        # legacy projects with no governed process). Open projects only -
        # a closed project's process history is no longer actionable.
        sdlc_flag_counts = {}
        for p in projects:
            if p.is_closed:
                continue
            ctx = _sdlc_context(p)
            if ctx and ctx['flags']:
                sdlc_flag_counts[p.id] = len(ctx['flags'])

        # Status distribution - vertical columns, one hue per status.
        #
        # COLUMNS, NOT BARS. A count per status is a comparison of six
        # magnitudes, and a column reads as "how much" far faster than a row
        # does: the baseline is shared, the eye compares heights against it,
        # and the status names sit under the thing they name instead of in a
        # left-hand gutter. (It was horizontal so long labels could not
        # overlap; `automargin` and a 340px plot handle that on the category
        # axis, and the b=50 bottom margin in the template gives them room.)
        #
        # ONE HUE PER STATUS, AND THE HUE MEANS THE STATUS. These were stock
        # Bootstrap colours once, matching nothing else in the application.
        # Every one of the six now comes from the App Assist ramps and says
        # what the status says, so a bar here reads exactly like a pill of the
        # same state anywhere else in the product:
        #
        #   Planning     --info     queued, nothing wrong, nothing running
        #   In Progress  module violet - the one state that IS this module
        #   On Hold      --warn     stopped, needs a decision
        #   Completed    --ok       delivered
        #   Failed       --stop     delivered badly
        #   Closed       --ink-3    finished and filed; ink, not a status
        #
        # Planning used to be a pale tint of the In Progress violet, so the
        # two busiest columns on most portfolios were one hue at two
        # strengths. They are now separate hues, which is the whole job of
        # this chart. The status PILLS in the portfolio table were split the
        # same way at the same time - the pill ramp is in pm_delivery.css and
        # the two have to stay in step, or the table and the chart will name
        # the same project in two different colours.
        status_colors = {
            'Planning':    '#175cd3',   # --info
            'In Progress': '#6f5fd8',   # module violet
            'On Hold':     '#b45309',   # --warn
            'Completed':   '#0f7050',   # --ok
            'Failed':      '#b42318',   # --stop
            'Closed':      '#5a6478',   # --ink-3
        }
        statuses = list(status_counts.keys())
        counts = [status_counts[s] for s in statuses]
        # Headroom for the value above each column. The template replaces the
        # margin dict, so the labels have to fit INSIDE the plot area rather
        # than rely on the top margin.
        top = max(counts) if counts else 0
        fig = go.Figure(data=[go.Bar(
            x=statuses,
            y=counts,
            marker=dict(
                color=[status_colors.get(s, '#5a6478') for s in statuses],
                # A hairline of the bar's own hue, darkened - it keeps the
                # column's edge crisp once the gradient lightens its top.
                line=dict(width=0),
                cornerradius=5,
            ),
            text=counts,
            textposition='outside',
            textfont=dict(size=12, color='#333e52'),
            cliponaxis=False,
            hovertemplate='<b>%{x}</b>: %{y} project(s)<extra></extra>',
        )])
        fig.update_layout(
            # No explicit height: Plotly honours `layout.height` over the
            # element it is drawn into, so a fixed 340 here drew a 340px plot
            # inside the template's shorter card body and spilled the
            # category labels out past the card's bottom edge. Left unset,
            # the plot is exactly as tall as the container the template
            # gives it.
            autosize=True,
            margin=dict(l=10, r=10, t=16, b=40),
            xaxis=dict(showgrid=False, automargin=True,
                       tickfont=dict(size=11, color='#333e52')),
            yaxis=dict(title='Projects', rangemode='tozero',
                       range=[0, (top * 1.22) if top else 1],
                       # Whole projects only: a "2.5 projects" gridline is a
                       # lie the axis should not be able to tell.
                       dtick=1 if top <= 6 else None,
                       showgrid=True, gridcolor='rgba(16,22,38,0.09)',
                       zerolinecolor='rgba(16,22,38,0.16)',
                       tickfont=dict(size=11, color='#5a6478')),
            plot_bgcolor='rgba(249,250,251,0.9)',
            paper_bgcolor='white',
            bargap=0.42,
        )
        chart_json = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

        return render_template(
            'project_management/dashboard.html',
            user=user,
            metrics={
                'total_projects': total_projects,
                'status_counts':  status_counts,
                'avg_completion': round(avg_completion, 1),
                'projects':       projects,
                'health_counts':  health_counts,
                'overdue_total':  overdue_total,
                'high_risk_total': high_risk_total,
            },
            chart_json=chart_json,
            sdlc_flag_counts=sdlc_flag_counts,
            methodology_labels=METHODOLOGY_LABELS,
            start_date=start_date,
            end_date=end_date,
            q=q,
            match=match,
            status_sel=status_sel,
            statuses=[s.value for s in ProjectStatus],
            mine=mine,
            health_sel=health_sel,
            flag_sel=flag_sel,
            health_labels=HEALTH_BAR_LABELS,
            today=date.today(),
            tab=tab,
            page=page,
            total_pages=total_pages,
        )
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Portfolio report export  (date-filtered dashboard -> professional Excel)
# ---------------------------------------------------------------------------

def _dashboard_project_query(db_session, user):
    """The same role-based visibility the dashboard applies, as a base query."""
    query = db_session.query(Project).options(
        selectinload(Project.team_members),
        selectinload(Project.milestones).selectinload(ProjectMilestone.tasks),
        selectinload(Project.risk_logs),
    )
    if user and user.role == 'team_member':
        team_projects = db_session.query(ProjectTeamMember.project_id).filter_by(user_id=user.id)
        query = query.filter(Project.id.in_(team_projects))
    elif user and user.role == 'project_manager':
        team_projects = db_session.query(ProjectTeamMember.project_id).filter_by(user_id=user.id)
        query = query.filter(or_(
            Project.created_by == user.id,
            Project.id.in_(team_projects),
        ))
    return query


@project_management_bp.route('/export/portfolio.xlsx')
def export_portfolio_xlsx():
    """Download the portfolio Excel report (executive summary, enriched
    portfolio sheet, upcoming milestones) honouring every dashboard filter:
    search, created-date range, AND/OR mode, status, health and "mine".
    Mirrors the dashboard's read-only visibility (anonymous sees all;
    non-admins see their own / team projects)."""
    user = get_current_user()   # may be None (public dashboard)

    q          = (request.args.get('q') or '').strip()
    start_date = (request.args.get('start_date') or '').strip()
    end_date   = (request.args.get('end_date') or '').strip()
    match      = request.args.get('match', 'all')
    if match not in ('all', 'any'):
        match = 'all'
    status_sel = (request.args.get('status') or '').strip()
    try:
        status_enum = ProjectStatus(status_sel) if status_sel else None
    except ValueError:
        status_enum, status_sel = None, ''
    mine = request.args.get('mine') == '1'
    health_sel = (request.args.get('health') or '').strip()
    if health_sel not in ('green', 'amber', 'red', 'neutral'):
        health_sel = ''

    start_dt = end_dt = None
    try:
        if start_date:
            start_dt = datetime.strptime(start_date, '%Y-%m-%d')
        if end_date:
            end_dt = datetime.strptime(end_date, '%Y-%m-%d')
    except ValueError:
        flash('Invalid date format.', 'error')
        return redirect(url_for('project_management.dashboard'))

    db_session = get_db_session()
    try:
        query = _dashboard_project_query(db_session, user)
        # Mirror the dashboard's filters exactly, in the same order.
        if mine and user and user.role in ('admin', 'project_manager'):
            query = query.filter(Project.created_by == user.id)
        query = _apply_dashboard_search(query, q, start_dt, end_dt, match)
        if status_enum:
            query = query.filter(Project.status == status_enum)
        if not start_dt and not end_dt and not status_enum:
            query = _apply_portfolio_scope(query)

        projects = query.order_by(Project.created_at.desc()).all()
        if health_sel:
            projects = [p for p in projects
                        if p.get_health_state() == health_sel]

        # Build a human-readable filter label for the report subtitle.
        if start_date and end_date:
            range_label = f'created {start_date} to {end_date}'
        elif start_date:
            range_label = f'created from {start_date}'
        elif end_date:
            range_label = f'created up to {end_date}'
        elif status_enum:
            range_label = 'all dates'
        else:
            range_label = 'last 4 quarters + all open projects'
        if q:
            joiner = ' OR ' if (match == 'any' and (start_date or end_date)) else ' - '
            range_label += f'{joiner}search "{q}"'
        for extra in ((f'status: {status_sel}' if status_sel else None),
                      (f'health: {HEALTH_BAR_LABELS[health_sel]}' if health_sel else None),
                      ('only my projects' if mine else None)):
            if extra:
                range_label += f' - {extra}'

        # PM display names for the Project Manager column.
        owner_ids = {p.created_by for p in projects if p.created_by}
        owner_names = {}
        if owner_ids:
            for u in db_session.query(User).filter(User.id.in_(owner_ids)):
                owner_names[u.id] = _full_name(u)

        meta = {
            'range_label': range_label,
            'owner_names': owner_names,
            'prepared_by': _full_name(user) if user else 'Public dashboard',
            'generated':   datetime.now(),
        }
        workbook_bytes = build_portfolio_workbook(projects, meta)
        filename = f'portfolio_report_{date.today():%Y-%m-%d}.xlsx'
        return Response(
            workbook_bytes,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            headers={'Content-Disposition': f'attachment; filename="{filename}"'},
        )
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Create Project  (project_manager / admin only)
# ---------------------------------------------------------------------------

@project_management_bp.route('/create', methods=['GET', 'POST'])
def create_project():
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))
    # Creation is a project-manager action only - admins administer (delete,
    # templates, closed projects) but never create or edit projects.
    if user.role != 'project_manager':
        flash('Only project managers can create projects.', 'error')
        return redirect(url_for('project_management.dashboard'))

    if request.method == 'POST':
        if not _valid_csrf():
            flash('Invalid security token. Please try again.', 'error')
            return redirect(url_for('project_management.create_project'))

        db_session = get_db_session()
        try:
            # Project type: 'sdlc' attaches the governed process below;
            # 'simple' is a lightweight (infra-style) project whose plan the
            # PM defines manually. Anything unexpected falls back to 'sdlc'.
            project_type = (request.form.get('project_type') or 'sdlc').strip().lower()
            if project_type not in ('sdlc', 'simple'):
                project_type = 'sdlc'
            is_simple = project_type == 'simple'

            # SDLC governance: score the delivery-method questionnaire
            # server-side (never trust the client's arithmetic) and record
            # both the recommendation and the PM's choice for the audit
            # trail. A SIMPLE project has no questionnaire / methodology.
            if is_simple:
                sdlc_score, recommended, methodology, override_reason = None, None, None, ''
            else:
                answers = {q['key']: request.form.get('sdlc_q_' + q['key'])
                           for q in SDLC_QUESTIONS}
                sdlc_score  = score_answers(answers)
                recommended = recommend_methodology(sdlc_score)
                methodology = (request.form.get('methodology') or '').strip().lower()
                if methodology not in METHODOLOGIES:
                    methodology = recommended
                override_reason = (request.form.get('methodology_override_reason') or '').strip()

            project = Project(
                name=request.form['name'],
                goal_objective=request.form.get('goal_objective', ''),
                description=request.form.get('description', ''),
                status=ProjectStatus.PLANNING,
                start_date=_parse_optional_date(request.form.get('start_date')),
                target_end_date=_parse_optional_date(request.form.get('target_end_date')),
                project_type=project_type,
                methodology=methodology,
                sdlc_score=sdlc_score,
                sdlc_recommended=recommended,
                sdlc_override_reason=(override_reason
                                      if methodology != recommended else ''),
                created_by=user.id,
            )
            db_session.add(project)
            db_session.flush()

            _save_stakeholders(project.id, request.form, db_session)
            _save_team_members(project.id, request.form, db_session)
            # For SDLC projects, milestones/tasks are NOT captured freehand:
            # the SDLC phases below ARE the milestone plan. SIMPLE projects
            # take the PM's manual milestones + tasks from the same form.
            # Risks are intentionally NOT captured at creation time - the
            # project manager and team members log them from the Risks tab.
            _save_documents(project.id, request.form, request.files, user.id, db_session)
            _log_activity(db_session, project.id, user, 'Project created')

            if is_simple:
                # Manual plan: the PM's milestones + tasks, exactly as typed.
                ms_count, task_count = _seed_simple_plan(db_session, project,
                                                         request.form)
                _log_activity(
                    db_session, project.id, user, 'Simple plan created',
                    f'{ms_count} milestone(s) and {task_count} task(s) '
                    f'defined manually; no SDLC process attached')
            else:
                # Attach the governed SDLC process. The PM's milestones group
                # the stages as chosen on the form; with no milestones defined,
                # one milestone per stage is generated across the project window.
                phase_count = _seed_sdlc_phases(db_session, project, methodology,
                                                form=request.form)
                detail = (f"{METHODOLOGY_LABELS[methodology]} process attached "
                          f"({phase_count} phases; questionnaire score "
                          f"{sdlc_score}/{SDLC_SCORE_MAX} recommended "
                          f"{METHODOLOGY_LABELS[recommended]})")
                if methodology != recommended:
                    detail += ('; recommendation overridden'
                               + (f' - {override_reason}' if override_reason else
                                  ' without a stated reason'))
                _log_activity(db_session, project.id, user, 'SDLC process attached', detail)

            db_session.commit()
            flash('Project created successfully!', 'success')
            return redirect(url_for('project_management.view_project', id=project.id))

        except Exception as exc:
            db_session.rollback()
            flash(f'Error creating project: {exc}', 'error')
        finally:
            db_session.close()

    db_session = get_db_session()
    try:
        # Stage list per methodology for the milestone builder's checkboxes
        # (the PM decides which stage falls under which milestone). Seeding
        # may COMMIT, which expires previously loaded ORM objects - so the
        # users the template iterates are queried afterwards.
        ensure_sdlc_templates_seeded(db_session)
        tpls = (db_session.query(SDLCPhaseTemplate)
                .order_by(SDLCPhaseTemplate.position, SDLCPhaseTemplate.id)
                .all())
        sdlc_stages = {m: [{'id': t.id, 'name': t.name,
                            'repeatable': bool(t.repeatable)}
                           for t in tpls if t.methodology == m]
                       for m in METHODOLOGIES}
        users = db_session.query(User).filter_by(is_active=True).all()
    finally:
        db_session.close()

    return render_template(
        'project_management/create_project.html',
        user=user, users=users,
        document_categories=DOCUMENT_CATEGORIES,
        stakeholder_roles=STAKEHOLDER_ROLES,
        team_member_roles=TEAM_MEMBER_ROLES,
        team_member_groups=TEAM_MEMBER_GROUPS,
        sdlc_questions=SDLC_QUESTIONS,
        sdlc_score_max=SDLC_SCORE_MAX,
        sdlc_agile_threshold=SDLC_AGILE_THRESHOLD,
        methodology_labels=METHODOLOGY_LABELS,
        sdlc_stages=sdlc_stages,
    )


# ---------------------------------------------------------------------------
# View Project
# ---------------------------------------------------------------------------

@project_management_bp.route('/project/<int:id>')
def view_project(id):
    # Project detail is public, read-only: login is NOT required to view.
    # Every editing action is gated separately (in the template and in each
    # mutating endpoint) on membership / ownership.
    user = get_current_user()   # may be None (anonymous visitor)

    db_session = get_db_session()
    try:
        # IMPORTANT: load each one-to-many collection with selectinload, NOT
        # joinedload. Chaining joinedload across sibling collections builds a
        # single query whose row count is the *product* of every collection's
        # size (stakeholders x tasks x notes x team x risks x activities x
        # golive tasks x connectivities x contacts). On a populated project that
        # Cartesian explosion made this view take ~30s. selectinload issues one
        # extra IN-query per collection instead, keeping it well under a second.
        project = db_session.query(Project).options(
            selectinload(Project.stakeholders),
            selectinload(Project.milestones).selectinload(ProjectMilestone.tasks)
                .selectinload(ProjectTask.notes),
            selectinload(Project.team_members),
            selectinload(Project.risk_logs),
            selectinload(Project.documents),
            selectinload(Project.activities),
            selectinload(Project.status_recipients),
            selectinload(Project.baselines).selectinload(ProjectBaseline.tasks),
            selectinload(Project.sdlc_phases)
                .selectinload(ProjectSDLCPhase.milestone_links),
            joinedload(Project.golive_plan).selectinload(GoLivePlan.tasks),
            joinedload(Project.golive_plan).selectinload(GoLivePlan.connectivities),
            joinedload(Project.golive_plan).selectinload(GoLivePlan.contacts),
        ).filter_by(id=id).first()

        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard') if user else url_for('index'))

        # Read-only access for everyone; interactive controls require membership.
        is_owner  = is_project_owner(project, user)  if user else False
        is_member = is_project_member(project, user, db_session) if user else False
        # SDLC gate sign-off: team Leads + project owner (name shown on the gate).
        is_lead   = can_signoff_sdlc(project, user, db_session) if user else False

        # Recent activity (most recent first; the relationship is already ordered).
        recent_activities = project.activities[:20]

        # Resolve every user referenced on the page in ONE query rather than a
        # per-row lookup (team roster, task-note authors, activity authors).
        needed_ids = {m.user_id for m in project.team_members if m.user_id} | {project.created_by}
        for task in project.get_all_tasks():
            if task.assigned_to:
                needed_ids.add(task.assigned_to)
            for note in task.notes:
                if note.user_id:
                    needed_ids.add(note.user_id)
        for act in recent_activities:
            if act.user_id:
                needed_ids.add(act.user_id)
        for ph in project.sdlc_phases:
            g = load_gate(ph)
            needed_ids.update(uid for uid in (g.get('owner_id'), g.get('reviewer_id')) if uid)
            if ph.signed_off_by:
                needed_ids.add(ph.signed_off_by)

        user_map: dict[int, str] = {}
        user_emails: dict[int, str] = {}
        if needed_ids:
            for u in db_session.query(User).filter(User.id.in_(needed_ids)).all():
                user_map[u.id] = _full_name(u)
                user_emails[u.id] = u.email or ''

        # CPM: dependency network, critical path, schedule warnings.
        cpm_result, dependencies, cpm_ctx = _cpm_analysis(project, db_session)

        # Baseline tracking: the newest snapshot is the active one.
        active_baseline = project.baselines[0] if project.baselines else None
        baseline_variance = (_baseline_variance(project, active_baseline)
                             if active_baseline else None)

        # Resource workload rollup.
        workload = _workload_data(project, user_map)

        # Version-trail size per document, for the Documents tab badges, plus how
        # many versions each one is allowed to keep (deeper for SDLC groups).
        doc_version_counts = file_versions.version_counts(
            db_session, DOC_ENTITY, [d.id for d in project.documents])
        doc_retention = {
            d.id: file_versions.retention_for(DOC_ENTITY, d.display_group)
            for d in project.documents
        }

        # 5x5 risk matrix: OPEN risks with both scales set, keyed by
        # (impact, probability) -> list of risk names for the cell tooltip.
        risk_matrix = {}
        unscored_open_risks = 0
        for r in project.risk_logs:
            if r.status != RiskStatus.OPEN:
                continue
            if r.probability and r.impact:
                risk_matrix.setdefault((r.impact, r.probability), []).append(r.name)
            else:
                unscored_open_risks += 1

        # Flat task list for the predecessor picker in the task modal.
        all_tasks_flat = [
            {'id': t.id, 'name': t.name, 'milestone': t.milestone.name}
            for t in project.get_all_tasks()
        ]

        # SDLC process: phase gate states + soft-governance red flags
        # (None for legacy projects created before governance existed).
        sdlc = _sdlc_context(project)

        # Milestones are logical groupings of SDLC stages: map each milestone
        # to its stage names (drives the Gantt labels and the Overview
        # milestones card) and expose the stage list for the add/edit modal.
        ms_stage_names = {}
        sdlc_stage_opts = []
        if sdlc:
            for s in sdlc['states']:
                for m in s['milestones_obj']:
                    ms_stage_names.setdefault(m.id, []).append(s['name'])
                sdlc_stage_opts.append({
                    'id': s['phase'].id, 'name': s['name'],
                    'repeatable': bool(s['phase'].repeatable),
                    'ms_ids': [m.id for m in s['milestones_obj']],
                })

        baseline_map = ({bt.task_id: (bt.start_date, bt.end_date)
                         for bt in active_baseline.tasks if bt.task_id}
                        if active_baseline else None)
        gantt_json = _build_gantt(project, user_map, cpm_ctx,
                                  baseline_map, ms_stage_names)

        # Kanban board: one column per task status, cards ordered by
        # priority (Critical first), then due date.
        kanban_columns = []
        for s in TaskStatus:
            col_tasks = sorted(
                (t for t in project.get_all_tasks() if t.status == s),
                key=lambda t: (PRIORITY_ORDER[_task_priority(t)], t.end_date, t.id))
            kanban_columns.append({'status': s.value, 'tasks': col_tasks})

        return render_template(
            'project_management/view_project.html',
            user=user,
            project=project,
            recent_activities=recent_activities,
            gantt_json=gantt_json,
            cpm=cpm_ctx,
            dependency_types=DEPENDENCY_TYPE_LABELS,
            all_tasks_flat=all_tasks_flat,
            kanban_columns=kanban_columns,
            task_priorities=TASK_PRIORITIES,
            task_priority_default=TASK_PRIORITY_DEFAULT,
            active_baseline=active_baseline,
            baseline_variance=baseline_variance,
            sdlc=sdlc,
            ms_stage_names=ms_stage_names,
            sdlc_stage_opts=sdlc_stage_opts,
            workload=workload,
            risk_matrix=risk_matrix,
            unscored_open_risks=unscored_open_risks,
            risk_prob_labels=RISK_PROBABILITY_LABELS,
            risk_impact_labels=RISK_IMPACT_LABELS,
            is_owner=is_owner,
            is_member=is_member,
            is_lead=is_lead,
            user_map=user_map,
            user_emails=user_emails,
            today=date.today(),
            task_categories=TASK_CATEGORIES,
            document_categories=DOCUMENT_CATEGORIES,
            doc_version_counts=doc_version_counts,
            doc_retention=doc_retention,
            doc_max_versions=file_versions.MAX_VERSIONS,
            sdlc_max_versions=file_versions.SDLC_MAX_VERSIONS,
            team_member_groups=TEAM_MEMBER_GROUPS,
            risk_severities=[s.value for s in RiskSeverity],
            risk_statuses=[s.value for s in RiskStatus],
            TaskStatus=TaskStatus,
            task_statuses=[s.value for s in TaskStatus],
            golive_task_sections=GOLIVE_TASK_SECTIONS,
            golive_section_labels=GOLIVE_SECTION_LABELS,
            golive_statuses=GOLIVE_TASK_STATUSES,
        )
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Status report - recipient list, manual send, auto-send toggle (owner only)
#
# The recipient list and these actions are managed only by the project owner
# (the creating PM or an admin). Reading the project is unaffected.
# ---------------------------------------------------------------------------

def _clean_email(raw) -> str:
    return (raw or '').strip()


def _looks_like_email(addr: str) -> bool:
    """Lightweight sanity check - full RFC validation is overkill here."""
    return ('@' in addr and ' ' not in addr
            and '.' in addr.rsplit('@', 1)[-1])


@project_management_bp.route('/project/<int:id>/status-recipients', methods=['POST'])
def save_status_recipients(id):
    """Replace the project's status-report recipient list (owner only)."""
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))
    if not _valid_csrf():
        flash('Invalid or missing security token. Please try again.', 'error')
        return redirect(url_for('project_management.view_project', id=id))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            selectinload(Project.status_recipients)
        ).filter_by(id=id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))
        guard = require_project_owner(project, user)
        if guard:
            return guard

        names  = request.form.getlist('recipient_name[]')
        emails = request.form.getlist('recipient_email[]')

        seen, rebuilt, skipped = set(), [], 0
        for i, raw in enumerate(emails):
            addr = _clean_email(raw)
            if not addr:
                continue
            if not _looks_like_email(addr):
                skipped += 1
                continue
            if addr.lower() in seen:
                continue
            seen.add(addr.lower())
            nm = names[i].strip() if i < len(names) else ''
            rebuilt.append((nm, addr))

        for r in list(project.status_recipients):       # replace-all
            db_session.delete(r)
        db_session.flush()
        for nm, addr in rebuilt:
            db_session.add(ProjectStatusRecipient(
                project_id=project.id, name=nm or None, email=addr))
        _log_activity(db_session, project.id, user,
                      'Status recipients updated', f'{len(rebuilt)} recipient(s)')
        db_session.commit()

        message = f'Saved {len(rebuilt)} recipient(s).'
        if skipped:
            message += f' Skipped {skipped} invalid address(es).'
        flash(message, 'warning' if skipped else 'success')
    except Exception as exc:
        db_session.rollback()
        flash(f'Could not save recipients: {exc}', 'error')
    finally:
        db_session.close()
    return redirect(url_for('project_management.view_project', id=id) + '#status-report')


@project_management_bp.route('/project/<int:id>/status-recipients/import-stakeholders',
                             methods=['POST'])
def import_stakeholder_recipients(id):
    """Append project stakeholders' emails to the recipient list (owner only)."""
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))
    if not _valid_csrf():
        flash('Invalid or missing security token. Please try again.', 'error')
        return redirect(url_for('project_management.view_project', id=id))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            selectinload(Project.status_recipients),
            selectinload(Project.stakeholders),
        ).filter_by(id=id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))
        guard = require_project_owner(project, user)
        if guard:
            return guard

        existing = {r.email.lower() for r in project.status_recipients if r.email}
        added = 0
        for s in project.stakeholders:
            addr = _clean_email(s.email)
            if not addr or not _looks_like_email(addr) or addr.lower() in existing:
                continue
            existing.add(addr.lower())
            db_session.add(ProjectStatusRecipient(
                project_id=project.id, name=s.name or None, email=addr))
            added += 1
        if added:
            _log_activity(db_session, project.id, user,
                          'Status recipients imported', f'{added} stakeholder(s)')
        db_session.commit()
        flash(f'Imported {added} stakeholder email(s).' if added
              else 'No new stakeholder emails to import.',
              'success' if added else 'info')
    except Exception as exc:
        db_session.rollback()
        flash(f'Could not import stakeholders: {exc}', 'error')
    finally:
        db_session.close()
    return redirect(url_for('project_management.view_project', id=id) + '#status-report')


@project_management_bp.route('/project/<int:id>/status-report/auto-toggle', methods=['POST'])
def toggle_auto_status(id):
    """Flip the per-project auto-send-on-milestone-completion toggle (owner only)."""
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))
    if not _valid_csrf():
        flash('Invalid or missing security token. Please try again.', 'error')
        return redirect(url_for('project_management.view_project', id=id))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).filter_by(id=id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))
        guard = require_project_owner(project, user)
        if guard:
            return guard
        project.auto_status_email = not bool(project.auto_status_email)
        _log_activity(db_session, project.id, user,
                      'Auto status email ' + ('enabled' if project.auto_status_email else 'disabled'))
        db_session.commit()
        flash('Auto-send on milestone completion is now '
              + ('ON.' if project.auto_status_email else 'OFF.'), 'success')
    except Exception as exc:
        db_session.rollback()
        flash(f'Could not update the setting: {exc}', 'error')
    finally:
        db_session.close()
    return redirect(url_for('project_management.view_project', id=id) + '#status-report')


@project_management_bp.route('/project/<int:id>/status-report/send', methods=['POST'])
def send_status_report_now(id):
    """Manually send the status report to the configured recipients (owner only)."""
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))
    if not _valid_csrf():
        flash('Invalid or missing security token. Please try again.', 'error')
        return redirect(url_for('project_management.view_project', id=id))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            selectinload(Project.status_recipients),
            selectinload(Project.milestones).selectinload(ProjectMilestone.tasks),
            selectinload(Project.risk_logs),
        ).filter_by(id=id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))
        guard = require_project_owner(project, user)
        if guard:
            return guard

        ok, message = send_status_report(project, db_session, trigger='manual')
        if ok:
            _log_activity(db_session, project.id, user, 'Status report sent', message)
            db_session.commit()
            flash(message, 'success')
        else:
            flash(message, 'warning')
    except Exception as exc:
        db_session.rollback()
        flash(f'Could not send the status report: {exc}', 'error')
    finally:
        db_session.close()
    return redirect(url_for('project_management.view_project', id=id) + '#status-report')


# ---------------------------------------------------------------------------
# Edit Project  (owner only)
# ---------------------------------------------------------------------------

@project_management_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_project(id):
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            selectinload(Project.stakeholders),
            selectinload(Project.milestones).selectinload(ProjectMilestone.tasks),
            selectinload(Project.team_members),
            selectinload(Project.risk_logs),
        ).filter_by(id=id).first()

        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))

        # Editing is reserved for the project manager who created the project
        # - admins have NO create/edit rights (delete/admin duties only).
        if not (user.role == 'project_manager' and project.created_by == user.id):
            flash('Only the project manager who created this project can edit it.', 'error')
            return redirect(url_for('project_management.view_project', id=project.id))

        # A closed project is read-only - no further edits are permitted.
        locked = _closed_redirect_guard(project)
        if locked:
            return locked

        if request.method == 'POST':
            if not _valid_csrf():
                flash('Invalid security token. Please try again.', 'error')
                return redirect(url_for('project_management.edit_project', id=project.id))
            try:
                old_status             = project.status
                project.name           = request.form['name']
                project.goal_objective = request.form.get('goal_objective', '')
                project.description    = request.form.get('description', '')
                project.status         = ProjectStatus(request.form['status'])
                project.start_date     = _parse_optional_date(request.form.get('start_date'))
                project.target_end_date = _parse_optional_date(request.form.get('target_end_date'))
                # Keep the closed flag in step with the status: re-opening a
                # closed project (status moved away from Closed) clears it,
                # and a manual move to Closed sets it.
                project.is_closed      = (project.status == ProjectStatus.CLOSED)

                # Replace stakeholders
                for s in list(project.stakeholders):
                    db_session.delete(s)
                db_session.flush()
                _save_stakeholders(project.id, request.form, db_session)

                # Replace team members
                for tm in list(project.team_members):
                    db_session.delete(tm)
                db_session.flush()
                _save_team_members(project.id, request.form, db_session)

                if old_status != project.status:
                    _log_activity(db_session, project.id, user, 'Status changed',
                                  f'{old_status.value} -> {project.status.value}')
                else:
                    _log_activity(db_session, project.id, user, 'Project edited')

                db_session.commit()
                flash('Project updated successfully!', 'success')
                return redirect(url_for('project_management.view_project', id=project.id))

            except Exception as exc:
                db_session.rollback()
                flash(f'Error updating project: {exc}', 'error')

        users = db_session.query(User).filter_by(is_active=True).all()
        return render_template(
            'project_management/edit_project.html',
            stakeholder_roles=STAKEHOLDER_ROLES,
            team_member_roles=TEAM_MEMBER_ROLES,
            team_member_groups=TEAM_MEMBER_GROUPS,
            user=user, project=project, users=users,
        )
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Delete Project
#   open project   -> owner (creating PM) or admin
#   closed project -> admin only
# Deleting a project removes ALL of its data: every relationship below carries
# cascade="all, delete-orphan" (milestones->tasks->notes, stakeholders, team,
# risks, documents, activities, the Go-Live plan->tasks/connectivity/contacts),
# so the single db_session.delete(project) wipes the lot. We also remove the
# documents' physical files so nothing is orphaned on disk.
# ---------------------------------------------------------------------------

@project_management_bp.route('/delete/<int:id>', methods=['POST'])
def delete_project(id):
    user = get_current_user()
    if not user:
        return redirect(url_for('login'))

    if not _valid_csrf():
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('project_management.view_project', id=id))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            joinedload(Project.documents)
        ).filter_by(id=id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))

        deny = require_project_owner(project, user)
        if deny:
            return deny

        # A closed project may only be deleted by an administrator - the
        # project manager loses the delete option once it is closed.
        if project.is_closed and user.role != 'admin':
            flash('A closed project can only be deleted by an administrator.', 'error')
            return redirect(url_for('project_management.view_project', id=id))

        project_name = project.name
        # Capture document file paths before the rows are cascade-deleted.
        doc_files = [d.filename for d in project.documents if d.filename]

        # The version trail is keyed by document id, not an FK, so the cascade
        # does not reach it - drop each document's history explicitly and add
        # its files to the same post-commit cleanup.
        stale_paths = []
        for doc in project.documents:
            stale_paths += file_versions.delete_all(
                db_session, DOC_ENTITY, doc.id, UPLOAD_FOLDER)

        db_session.delete(project)
        db_session.commit()

        # Best-effort cleanup of the uploaded files (after the DB commit, so a
        # file-system hiccup never blocks the delete or leaves dangling rows).
        for fname in doc_files:
            path = _upload_file_path(fname)
            if path:
                stale_paths.append(path)
        file_versions.remove_files(stale_paths)

        flash(f'Project "{project_name}" deleted successfully!', 'success')
    except Exception as exc:
        db_session.rollback()
        flash(f'Error deleting project: {exc}', 'error')
    finally:
        db_session.close()

    return redirect(url_for('project_management.dashboard'))


# ---------------------------------------------------------------------------
# Close Project  (owner only)
# ---------------------------------------------------------------------------

@project_management_bp.route('/close/<int:id>', methods=['POST'])
def close_project(id):
    user = get_current_user()
    if not user:
        return redirect(url_for('login'))

    if not _valid_csrf():
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('project_management.view_project', id=id))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            joinedload(Project.milestones).joinedload(ProjectMilestone.tasks)
        ).filter_by(id=id).first()

        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))

        deny = require_project_owner(project, user)
        if deny:
            return deny

        blockers = project.closure_blockers()
        if blockers:
            flash('Cannot close project: ' + '; '.join(blockers) + '.', 'error')
            return redirect(url_for('project_management.view_project', id=id))

        project.status    = ProjectStatus.CLOSED
        project.is_closed = True
        _log_activity(db_session, project.id, user, 'Project closed')
        db_session.commit()
        flash('Project closed successfully!', 'success')
    except Exception as exc:
        db_session.rollback()
        flash(f'Error closing project: {exc}', 'error')
    finally:
        db_session.close()

    return redirect(url_for('project_management.view_project', id=id))


# ---------------------------------------------------------------------------
# SDLC gate sign-off  (team leads + project owner, soft governance)
#
# Sign-off is reserved for team members in the **Lead** group, with the
# project owner (creating PM / admin) as a bypass - the signature is displayed
# with the signer's name for accountability. It is deliberately never blocked
# on the gate criteria: a signer may sign off a phase with open tasks or
# missing documents (the confirm dialog warns them), because governance here
# is soft - the flags tell the story.
# ---------------------------------------------------------------------------

@project_management_bp.route('/project/<int:id>/sdlc/phase/<int:phase_id>/signoff',
                             methods=['POST'])
def signoff_sdlc_phase(id, phase_id):
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))
    if not _valid_csrf():
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('project_management.view_project', id=id, tab='process'))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).filter_by(id=id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))
        if not can_signoff_sdlc(project, user, db_session):
            flash('Only a team Lead or the project manager can sign off (or revoke) '
                  'an SDLC gate - the sign-off carries their name for accountability.',
                  'error')
            return redirect(url_for('project_management.view_project', id=id, tab='process'))
        locked = _closed_redirect_guard(project)
        if locked:
            return locked

        phase = db_session.query(ProjectSDLCPhase).filter_by(
            id=phase_id, project_id=id).first()
        if not phase:
            flash('SDLC phase not found.', 'error')
            return redirect(url_for('project_management.view_project', id=id, tab='process'))

        if load_gate(phase):
            flash('Use the structured review controls for this stage.', 'error')
            return redirect(url_for('project_management.view_project', id=id, tab='process'))

        revoke = request.form.get('revoke') == '1'
        if revoke:
            phase.signed_off_by = None
            phase.signed_off_at = None
            phase.signoff_note  = None
            _log_activity(db_session, id, user, 'SDLC gate sign-off revoked',
                          f"Phase '{phase.name}'")
            msg = f"Sign-off revoked for phase '{phase.name}'."
        else:
            phase.signed_off_by = user.id
            phase.signed_off_at = datetime.now()
            phase.signoff_note  = (request.form.get('note') or '').strip()
            detail = f"Phase '{phase.name}' gate signed off"
            if phase.signoff_note:
                detail += f" - {phase.signoff_note}"
            _log_activity(db_session, id, user, 'SDLC gate signed off', detail)
            msg = f"Phase '{phase.name}' gate signed off."

        db_session.commit()
        flash(msg, 'success')
    except Exception as exc:
        db_session.rollback()
        flash(f'Error updating phase sign-off: {exc}', 'error')
    finally:
        db_session.close()

    return redirect(url_for('project_management.view_project', id=id, tab='process'))


@project_management_bp.route('/project/<int:id>/sdlc/phase/<int:phase_id>/sprint/add',
                             methods=['POST'])
def add_sdlc_sprint(id, phase_id):
    """
    Add the next iteration milestone to a repeatable stage - 'Sprint N' under
    Sprint Cycles. Each sprint is seeded with the stage's default tasks (the
    full loop: plan, build & test, review, release to production, retrospect),
    so Sprint 1 can ship before Sprint 2 starts with nothing special to model.
    Further tasks are added per sprint from the Process or Plan tab.
    """
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))
    if not _valid_csrf():
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('project_management.view_project', id=id, tab='process'))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).filter_by(id=id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))
        deny = require_project_owner(project, user)
        if deny:
            return deny
        locked = _closed_redirect_guard(project)
        if locked:
            return locked

        phase = db_session.query(ProjectSDLCPhase).filter_by(
            id=phase_id, project_id=id).first()
        if not phase or not phase.repeatable:
            flash('Iterations can only be added to a repeatable stage '
                  '(e.g. Sprint Cycles).', 'error')
            return redirect(url_for('project_management.view_project', id=id, tab='process'))

        start = _parse_optional_date(request.form.get('start_date'))
        end   = _parse_optional_date(request.form.get('end_date'))
        if not start or not end or start > end:
            flash('An iteration needs a valid start and end date (start on or before end).', 'error')
            return redirect(url_for('project_management.view_project', id=id, tab='process'))

        existing = (db_session.query(SDLCPhaseMilestone)
                    .filter_by(phase_id=phase.id).count())
        sprint_name = ((request.form.get('name') or '').strip()
                       or f'{_iteration_label(phase)} {existing + 1}')
        milestone = ProjectMilestone(
            project_id=id, name=sprint_name, description=phase.description,
            start_date=start, end_date=end,
        )
        db_session.add(milestone)
        db_session.flush()
        _assign_phase_to_milestone(db_session, phase, milestone)
        _log_activity(db_session, id, user, f'{_iteration_label(phase)} added',
                      f"{sprint_name} ({start:%d %b %Y} - {end:%d %b %Y}) "
                      f"under '{phase.name}'")
        db_session.commit()
        flash(f'{sprint_name} added with its standard tasks.', 'success')
    except Exception as exc:
        db_session.rollback()
        flash(f'Error adding sprint: {exc}', 'error')
    finally:
        db_session.close()

    return redirect(url_for('project_management.view_project', id=id, tab='process'))


@project_management_bp.route('/project/<int:id>/sdlc/phase/<int:phase_id>/assign',
                             methods=['POST'])
def assign_sdlc_phase(id, phase_id):
    """
    Assign an SDLC stage to one of the project's milestones (the PM's
    grouping decision). Seeds the stage's default tasks into the milestone.
    A non-repeatable stage can be assigned once; a repeatable stage may be
    assigned to further milestones (extra sprints).
    """
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))
    if not _valid_csrf():
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('project_management.view_project', id=id, tab='process'))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).filter_by(id=id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))
        deny = require_project_owner(project, user)
        if deny:
            return deny
        locked = _closed_redirect_guard(project)
        if locked:
            return locked

        phase = db_session.query(ProjectSDLCPhase).filter_by(
            id=phase_id, project_id=id).first()
        milestone = db_session.query(ProjectMilestone).filter_by(
            id=request.form.get('milestone_id', type=int), project_id=id).first()
        if not phase or not milestone:
            flash('Stage or milestone not found.', 'error')
            return redirect(url_for('project_management.view_project', id=id, tab='process'))

        links = db_session.query(SDLCPhaseMilestone).filter_by(phase_id=phase.id).all()
        if any(l.milestone_id == milestone.id for l in links):
            flash(f"'{phase.name}' is already grouped under '{milestone.name}'.", 'error')
            return redirect(url_for('project_management.view_project', id=id, tab='process'))
        if links and not phase.repeatable:
            flash(f"'{phase.name}' is already assigned to a milestone.", 'error')
            return redirect(url_for('project_management.view_project', id=id, tab='process'))

        _assign_phase_to_milestone(db_session, phase, milestone)
        _log_activity(db_session, id, user, 'SDLC stage assigned',
                      f"Stage '{phase.name}' grouped under milestone "
                      f"'{milestone.name}'")
        db_session.commit()
        flash(f"Stage '{phase.name}' assigned to '{milestone.name}' "
              f"with its standard tasks.", 'success')
    except Exception as exc:
        db_session.rollback()
        flash(f'Error assigning stage: {exc}', 'error')
    finally:
        db_session.close()

    return redirect(url_for('project_management.view_project', id=id, tab='process'))


# ---------------------------------------------------------------------------
# Milestone management  (owner / admin only)
#
# Milestones can be added, edited and removed for the lifetime of the project
# (not just at creation time) so the project manager keeps full flexibility.
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Baseline endpoints (owner only)
# ---------------------------------------------------------------------------

@project_management_bp.route('/project/<int:id>/baseline/set', methods=['POST'])
def set_baseline(id):
    """Freeze the current plan as a new baseline."""
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))
    if not _valid_csrf():
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('project_management.view_project', id=id))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            selectinload(Project.milestones).selectinload(ProjectMilestone.tasks),
            selectinload(Project.baselines),
        ).filter_by(id=id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))
        deny = require_project_owner(project, user)
        if deny:
            return deny
        locked = _closed_redirect_guard(project)
        if locked:
            return locked
        if not project.get_all_tasks():
            flash('Add at least one task before setting a baseline.', 'error')
            return redirect(url_for('project_management.view_project', id=id))

        name = (request.form.get('name') or '').strip()
        if not name:
            name = f'Baseline {len(project.baselines) + 1} - {date.today():%d %b %Y}'
        _snapshot_plan(db_session, project, user, name)
        _log_activity(db_session, project.id, user, 'Baseline set', f'"{name}"')
        db_session.commit()
        flash(f'Baseline "{name}" saved. The plan is now tracked against it.', 'success')
    except Exception as exc:
        db_session.rollback()
        flash(f'Error setting baseline: {exc}', 'error')
    finally:
        db_session.close()
    return redirect(url_for('project_management.view_project', id=id))


@project_management_bp.route('/baseline/<int:baseline_id>/delete', methods=['POST'])
def delete_baseline(baseline_id):
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))
    if not _valid_csrf():
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('project_management.dashboard'))

    db_session = get_db_session()
    try:
        baseline = db_session.query(ProjectBaseline).filter_by(id=baseline_id).first()
        if not baseline:
            flash('Baseline not found.', 'error')
            return redirect(url_for('project_management.dashboard'))
        project = db_session.query(Project).filter_by(id=baseline.project_id).first()
        deny = require_project_owner(project, user)
        if deny:
            return deny

        name = baseline.name
        db_session.delete(baseline)
        _log_activity(db_session, project.id, user, 'Baseline deleted', f'"{name}"')
        db_session.commit()
        flash(f'Baseline "{name}" deleted.', 'success')
        return redirect(url_for('project_management.view_project', id=project.id))
    except Exception as exc:
        db_session.rollback()
        flash(f'Error deleting baseline: {exc}', 'error')
        return redirect(url_for('project_management.dashboard'))
    finally:
        db_session.close()


@project_management_bp.route('/milestone/add/<int:project_id>', methods=['POST'])
def add_milestone(project_id):
    """Add a milestone to an existing project.  Project owner / admin only."""
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    if not _valid_csrf():
        return _csrf_json_error()

    db_session = get_db_session()
    try:
        project = db_session.query(Project).filter_by(id=project_id).first()
        if not project:
            return jsonify({'error': 'Project not found'}), 404
        if not is_project_owner(project, user):
            return jsonify({'error': 'Only the project manager who created this project can add milestones.'}), 403
        lock = _closed_json_guard(project)
        if lock:
            return lock

        name = request.form.get('name', '').strip()
        if not name:
            return jsonify({'error': 'Milestone name is required.'}), 400

        try:
            end = datetime.strptime(request.form['end_date'], '%Y-%m-%d').date()
        except (KeyError, ValueError) as exc:
            return jsonify({'error': f'Invalid milestone deadline: {exc}'}), 400
        start = _parse_optional_date(request.form.get('start_date'))
        if start and start > end:
            return jsonify({'error': 'Milestone start date must be on or before its deadline.'}), 400

        ms = ProjectMilestone(
            project_id  = project.id,
            name        = name,
            description = request.form.get('description', '').strip(),
            start_date  = start,
            end_date    = end,
            status      = MilestoneStatus.NOT_STARTED,
        )
        db_session.add(ms)
        db_session.flush()

        # The SDLC stages the PM grouped under this milestone.
        err = _sync_milestone_stages(
            db_session, project, ms,
            {int(v) for v in request.form.getlist('stages[]') if v.isdigit()})
        if err:
            db_session.rollback()
            return jsonify({'error': err}), 400

        _log_activity(db_session, project.id, user, 'Milestone added', f'"{ms.name}"')
        db_session.commit()

        return jsonify({
            'success': True,
            'redirect': url_for('project_management.view_project',
                                id=project.id, tab='overview'),
        })

    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


@project_management_bp.route('/milestone/<int:milestone_id>/edit', methods=['POST'])
def edit_milestone(milestone_id):
    """Edit a milestone's name / description / window.  Owner / admin only.

    The window can only be tightened to a range that still contains every
    existing task, so a date change can never strand a task outside its
    milestone (the same invariant `_validate_task_window` enforces the other
    way round)."""
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    if not _valid_csrf():
        return _csrf_json_error()

    db_session = get_db_session()
    try:
        milestone = db_session.query(ProjectMilestone).options(
            joinedload(ProjectMilestone.tasks)
        ).filter_by(id=milestone_id).first()
        if not milestone:
            return jsonify({'error': 'Milestone not found'}), 404

        project = db_session.query(Project).filter_by(id=milestone.project_id).first()
        if not is_project_owner(project, user):
            return jsonify({'error': 'Only the project manager who created this project can edit milestones.'}), 403
        lock = _closed_json_guard(project)
        if lock:
            return lock

        name = request.form.get('name', '').strip()
        if not name:
            return jsonify({'error': 'Milestone name is required.'}), 400

        try:
            end = datetime.strptime(request.form['end_date'], '%Y-%m-%d').date()
        except (KeyError, ValueError) as exc:
            return jsonify({'error': f'Invalid milestone deadline: {exc}'}), 400
        start = _parse_optional_date(request.form.get('start_date'))
        if start and start > end:
            return jsonify({'error': 'Milestone start date must be on or before its deadline.'}), 400

        # The new window must still contain every existing task.
        for t in milestone.tasks:
            if start and t.start_date < start:
                return jsonify({'error': (
                    f'Cannot move the start to {start:%d %b %Y}: task '
                    f'"{t.name}" starts earlier ({t.start_date:%d %b %Y}).')}), 400
            if t.end_date > end:
                return jsonify({'error': (
                    f'Cannot move the deadline to {end:%d %b %Y}: task '
                    f'"{t.name}" ends later ({t.end_date:%d %b %Y}).')}), 400

        milestone.name        = name
        milestone.description = request.form.get('description', '').strip()
        milestone.start_date  = start
        milestone.end_date    = end

        # Re-group the SDLC stages under this milestone as selected.
        err = _sync_milestone_stages(
            db_session, project, milestone,
            {int(v) for v in request.form.getlist('stages[]') if v.isdigit()})
        if err:
            db_session.rollback()
            return jsonify({'error': err}), 400

        _log_activity(db_session, project.id, user, 'Milestone edited', f'"{milestone.name}"')
        db_session.commit()

        return jsonify({
            'success': True,
            'redirect': url_for('project_management.view_project',
                                id=project.id, tab='overview'),
        })

    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


@project_management_bp.route('/milestone/<int:milestone_id>/delete', methods=['POST'])
def delete_milestone(milestone_id):
    """Delete a milestone and all of its tasks.  Owner / admin only."""
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    if not _valid_csrf():
        return _csrf_json_error()

    db_session = get_db_session()
    try:
        milestone = db_session.query(ProjectMilestone).filter_by(id=milestone_id).first()
        if not milestone:
            return jsonify({'error': 'Milestone not found'}), 404

        project = db_session.query(Project).filter_by(id=milestone.project_id).first()
        if not is_project_owner(project, user):
            return jsonify({'error': 'Only the project owner can delete milestones.'}), 403
        lock = _closed_json_guard(project)
        if lock:
            return lock

        ms_name = milestone.name
        db_session.delete(milestone)            # cascade removes its tasks + notes
        db_session.flush()                      # so the rollups don't count the deleted tasks
        project.update_status_based_on_tasks()
        _log_activity(db_session, project.id, user, 'Milestone deleted', f'"{ms_name}"')
        db_session.commit()

        return jsonify({
            'success': True,
            'redirect': url_for('project_management.view_project', id=project.id),
        })

    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Task management  (team members + owners)
# ---------------------------------------------------------------------------

@project_management_bp.route('/task/add/<int:milestone_id>', methods=['POST'])
def add_task(milestone_id):
    """Add a task to a milestone.  Project owner (creating PM) / admin only."""
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    if not _valid_csrf():
        return _csrf_json_error()

    db_session = get_db_session()
    try:
        milestone = db_session.query(ProjectMilestone).filter_by(id=milestone_id).first()
        if not milestone:
            return jsonify({'error': 'Milestone not found'}), 404

        project = db_session.query(Project).filter_by(id=milestone.project_id).first()
        if not is_project_owner(project, user):
            return jsonify({'error': 'Only the project manager who created this project can add tasks.'}), 403
        lock = _closed_json_guard(project)
        if lock:
            return lock

        # Parse dates
        try:
            start = datetime.strptime(request.form['start_date'], '%Y-%m-%d').date()
            end   = datetime.strptime(request.form['end_date'],   '%Y-%m-%d').date()
        except (KeyError, ValueError) as exc:
            return jsonify({'error': f'Invalid date: {exc}'}), 400

        # Enforce: task window must fall inside the milestone window
        err = _validate_task_window(start, end, milestone)
        if err:
            return jsonify({'error': err}), 400

        assigned_to_raw = request.form.get('assigned_to', '')
        assigned_to = int(assigned_to_raw) if assigned_to_raw else None

        prio_raw = request.form.get('priority', '')
        task = ProjectTask(
            milestone_id = milestone_id,
            name         = request.form.get('name', '').strip(),
            description  = request.form.get('description', '').strip(),
            category     = request.form.get('category', ''),
            sub_category = request.form.get('sub_category', ''),
            priority     = prio_raw if prio_raw in TASK_PRIORITIES else TASK_PRIORITY_DEFAULT,
            percent_complete = _parse_percent(request.form.get('percent_complete'), 0),
            assigned_to  = assigned_to,
            start_date   = start,
            end_date     = end,
            status       = TaskStatus.NOT_STARTED,
        )
        if not task.name:
            return jsonify({'error': 'Task name is required.'}), 400

        db_session.add(task)
        db_session.flush()                       # so the new task is visible to the status rollups

        # Optional CPM predecessors (owner-only form section; owner is already
        # guaranteed above).
        dep_raw = request.form.get('dependencies')
        if dep_raw is not None:
            dep_err = _save_task_dependencies(db_session, task, dep_raw, project)
            if dep_err:
                db_session.rollback()
                return jsonify({'error': dep_err}), 400

        _ms_prev = milestone.status
        milestone.update_status_based_on_tasks()
        project.update_status_based_on_tasks()
        _log_activity(db_session, project.id, user, 'Task added', f'"{task.name}" - {milestone.name}')
        db_session.commit()
        _maybe_autosend_status(db_session, project, milestone, _ms_prev)

        return jsonify({
            'success': True,
            'redirect': url_for('project_management.view_project', id=project.id),
        })

    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


@project_management_bp.route('/task/<int:task_id>/edit', methods=['POST'])
def edit_task(task_id):
    """Edit a task.  Project owner (creating PM) / admin OR the assignee only."""
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    if not _valid_csrf():
        return _csrf_json_error()

    db_session = get_db_session()
    try:
        task = db_session.query(ProjectTask).options(
            joinedload(ProjectTask.milestone)
        ).filter_by(id=task_id).first()

        if not task:
            return jsonify({'error': 'Task not found'}), 404

        milestone = task.milestone
        project   = db_session.query(Project).filter_by(id=milestone.project_id).first()

        # Requirement 4: only the project manager (owner/admin) or the person
        # the task is assigned to may edit it.
        if not (is_project_owner(project, user) or task.assigned_to == user.id):
            return jsonify({'error': 'Only the project manager or the assigned person can edit this task.'}), 403
        lock = _closed_json_guard(project)
        if lock:
            return lock

        # Parse dates
        try:
            start = datetime.strptime(request.form['start_date'], '%Y-%m-%d').date()
            end   = datetime.strptime(request.form['end_date'],   '%Y-%m-%d').date()
        except (KeyError, ValueError) as exc:
            return jsonify({'error': f'Invalid date: {exc}'}), 400

        err = _validate_task_window(start, end, milestone)
        if err:
            return jsonify({'error': err}), 400

        assigned_to_raw = request.form.get('assigned_to', '')
        task.name         = request.form.get('name', task.name).strip()
        task.description  = request.form.get('description', '').strip()
        task.category     = request.form.get('category', task.category)
        task.sub_category = request.form.get('sub_category', task.sub_category)
        prio_raw = request.form.get('priority', '')
        if prio_raw in TASK_PRIORITIES:
            task.priority = prio_raw
        if 'percent_complete' in request.form:
            task.percent_complete = _parse_percent(
                request.form.get('percent_complete'), task.percent_complete or 0)
        # Keep the stored % consistent with a status set in the same edit.
        if task.status == TaskStatus.COMPLETED:
            task.percent_complete = 100
        elif task.status == TaskStatus.NOT_STARTED:
            task.percent_complete = 0
        task.assigned_to  = int(assigned_to_raw) if assigned_to_raw else None
        task.start_date   = start
        task.end_date     = end
        task.status       = TaskStatus(request.form.get('status', task.status.value))

        # CPM predecessors: only the owner may restructure the schedule
        # network (an assignee's edit form never submits this field).
        dep_raw = request.form.get('dependencies')
        if dep_raw is not None and is_project_owner(project, user):
            dep_err = _save_task_dependencies(db_session, task, dep_raw, project)
            if dep_err:
                db_session.rollback()
                return jsonify({'error': dep_err}), 400

        _ms_prev = milestone.status
        milestone.update_status_based_on_tasks()
        project.update_status_based_on_tasks()
        _log_activity(db_session, project.id, user, 'Task edited', f'"{task.name}"')
        db_session.commit()
        _maybe_autosend_status(db_session, project, milestone, _ms_prev)

        return jsonify({
            'success': True,
            'redirect': url_for('project_management.view_project', id=project.id),
        })

    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


@project_management_bp.route('/task/<int:task_id>/delete', methods=['POST'])
def delete_task(task_id):
    """Delete a task.  Owner only."""
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    if not _valid_csrf():
        return _csrf_json_error()

    db_session = get_db_session()
    try:
        task = db_session.query(ProjectTask).options(
            joinedload(ProjectTask.milestone)
        ).filter_by(id=task_id).first()

        if not task:
            return jsonify({'error': 'Task not found'}), 404

        project = db_session.query(Project).filter_by(
            id=task.milestone.project_id
        ).first()

        if not is_project_owner(project, user):
            return jsonify({'error': 'Only the project owner can delete tasks.'}), 403
        lock = _closed_json_guard(project)
        if lock:
            return lock

        ms = task.milestone
        task_name = task.name
        _ms_prev = ms.status
        db_session.delete(task)
        db_session.flush()                       # so the rollups don't still count the deleted task
        ms.update_status_based_on_tasks()
        project.update_status_based_on_tasks()
        _log_activity(db_session, project.id, user, 'Task deleted', f'"{task_name}"')
        db_session.commit()
        _maybe_autosend_status(db_session, project, ms, _ms_prev)

        return jsonify({
            'success': True,
            'redirect': url_for('project_management.view_project', id=project.id),
        })

    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Task status & notes  (AJAX)
# ---------------------------------------------------------------------------

@project_management_bp.route('/api/task/<int:task_id>/status', methods=['POST'])
def update_task_status(task_id):
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    if not _valid_csrf():
        return _csrf_json_error()

    data       = request.get_json(force=True)
    new_status = data.get('status')
    if new_status not in [s.value for s in TaskStatus]:
        return jsonify({'error': 'Invalid status'}), 400

    db_session = get_db_session()
    try:
        task = db_session.query(ProjectTask).options(
            joinedload(ProjectTask.milestone)
        ).filter_by(id=task_id).first()
        if not task:
            return jsonify({'error': 'Task not found'}), 404

        project = db_session.query(Project).filter_by(
            id=task.milestone.project_id
        ).first()
        if not is_project_member(project, user, db_session):
            return jsonify({'error': 'Permission denied'}), 403
        lock = _closed_json_guard(project)
        if lock:
            return lock

        # Non-owners can only update tasks assigned to them
        if not is_project_owner(project, user) and task.assigned_to != user.id:
            return jsonify({'error': 'You can only update tasks assigned to you.'}), 403

        task.status = TaskStatus(new_status)
        # Pin the stored % to the status ends (matches effective_percent).
        if task.status == TaskStatus.COMPLETED:
            task.percent_complete = 100
        elif task.status == TaskStatus.NOT_STARTED:
            task.percent_complete = 0
        _ms_prev = task.milestone.status
        task.milestone.update_status_based_on_tasks()
        project.update_status_based_on_tasks()
        _log_activity(db_session, project.id, user, 'Task status changed',
                      f'"{task.name}" -> {task.status.value}')
        db_session.commit()

        response = jsonify({
            'success':            True,
            'task_status':        task.status.value,
            'milestone_status':   task.milestone.status.value,
            'project_status':     project.status.value,
            'project_completion': project.get_completion_percentage(),
        })
        _maybe_autosend_status(db_session, project, task.milestone, _ms_prev)
        return response

    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


@project_management_bp.route('/api/task/<int:task_id>/notes', methods=['GET'])
def get_task_notes(task_id):
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401

    db_session = get_db_session()
    try:
        task = db_session.query(ProjectTask).options(
            joinedload(ProjectTask.notes),
            joinedload(ProjectTask.milestone),
        ).filter_by(id=task_id).first()
        if not task:
            return jsonify({'error': 'Task not found'}), 404

        project = db_session.query(Project).filter_by(
            id=task.milestone.project_id
        ).first()
        if not is_project_member(project, user, db_session):
            return jsonify({'error': 'Permission denied'}), 403

        notes_out = []
        for note in sorted(task.notes, key=lambda n: n.created_at):
            u = db_session.query(User).filter_by(id=note.user_id).first()
            uname = _full_name(u) if u else 'Unknown'
            notes_out.append({
                'id':         note.id,
                'note':       note.note,
                'user':       uname,
                'created_at': note.created_at.strftime('%d %b %Y %H:%M'),
            })

        return jsonify({'success': True, 'notes': notes_out})
    finally:
        db_session.close()


@project_management_bp.route('/api/task/<int:task_id>/note', methods=['POST'])
def add_task_note(task_id):
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    if not _valid_csrf():
        return _csrf_json_error()

    data = request.get_json(force=True)
    note_text = (data.get('note') or '').strip()
    if not note_text:
        return jsonify({'error': 'Note text is required'}), 400

    db_session = get_db_session()
    try:
        task = db_session.query(ProjectTask).options(
            joinedload(ProjectTask.milestone)
        ).filter_by(id=task_id).first()
        if not task:
            return jsonify({'error': 'Task not found'}), 404

        project = db_session.query(Project).filter_by(
            id=task.milestone.project_id
        ).first()
        if not is_project_member(project, user, db_session):
            return jsonify({'error': 'Permission denied'}), 403
        lock = _closed_json_guard(project)
        if lock:
            return lock

        note = TaskNote(task_id=task_id, user_id=user.id, note=note_text)
        db_session.add(note)
        db_session.commit()

        uname = _full_name(user)

        return jsonify({
            'success': True,
            'note': {
                'id':         note.id,
                'note':       note.note,
                'user':       uname,
                'created_at': note.created_at.strftime('%d %b %Y %H:%M'),
            },
        })

    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Risk Log  (add/edit: all members; delete: owner only)
# ---------------------------------------------------------------------------

def _parse_scale_1_5(raw):
    """A 1-5 matrix scale value, or None for blank/invalid input."""
    try:
        v = int(raw)
        return v if 1 <= v <= 5 else None
    except (TypeError, ValueError):
        return None


def _apply_risk_matrix_fields(risk, form):
    """
    Read the probabilityximpact fields off the form onto the risk. When both
    scales are set, severity is derived from the score band so the matrix and
    the severity pill can never disagree; otherwise the submitted severity
    stands (legacy simple mode).
    """
    risk.probability = _parse_scale_1_5(form.get('probability'))
    risk.impact      = _parse_scale_1_5(form.get('impact'))
    risk.owner       = (form.get('owner') or '').strip() or None
    risk.mitigation  = (form.get('mitigation') or '').strip() or None
    risk.due_date    = _parse_optional_date(form.get('due_date'))
    if risk.probability and risk.impact:
        risk.severity = RiskSeverity(risk_band(risk.probability * risk.impact))


@project_management_bp.route('/risk/add/<int:project_id>', methods=['POST'])
def add_risk(project_id):
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    if not _valid_csrf():
        return _csrf_json_error()

    db_session = get_db_session()
    try:
        project = db_session.query(Project).filter_by(id=project_id).first()
        if not project:
            return jsonify({'error': 'Project not found'}), 404
        if not is_project_member(project, user, db_session):
            return jsonify({'error': 'Permission denied'}), 403
        lock = _closed_json_guard(project)
        if lock:
            return lock

        name     = (request.form.get('name') or '').strip()
        summary  = (request.form.get('summary') or '').strip()
        severity = request.form.get('severity', 'Low')
        status   = request.form.get('status', 'Open')

        if not name or not summary:
            return jsonify({'error': 'Name and summary are required.'}), 400

        try:
            sev = RiskSeverity(severity)
            sta = RiskStatus(status)
        except ValueError as exc:
            return jsonify({'error': str(exc)}), 400

        risk = ProjectRiskLog(
            project_id=project_id, name=name, summary=summary,
            severity=sev, status=sta,
        )
        _apply_risk_matrix_fields(risk, request.form)
        db_session.add(risk)
        _log_activity(db_session, project_id, user, 'Risk added', f'"{name}" ({sev.value})')
        db_session.commit()

        return jsonify({
            'success': True,
            'redirect': url_for('project_management.view_project', id=project_id),
        })
    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


@project_management_bp.route('/risk/<int:risk_id>/edit', methods=['POST'])
def edit_risk(risk_id):
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    if not _valid_csrf():
        return _csrf_json_error()

    db_session = get_db_session()
    try:
        risk = db_session.query(ProjectRiskLog).filter_by(id=risk_id).first()
        if not risk:
            return jsonify({'error': 'Risk not found'}), 404

        project = db_session.query(Project).filter_by(id=risk.project_id).first()
        if not is_project_member(project, user, db_session):
            return jsonify({'error': 'Permission denied'}), 403
        lock = _closed_json_guard(project)
        if lock:
            return lock

        risk.name    = (request.form.get('name')    or risk.name).strip()
        risk.summary = (request.form.get('summary') or risk.summary).strip()
        try:
            risk.severity = RiskSeverity(request.form.get('severity', risk.severity.value))
            risk.status   = RiskStatus(request.form.get('status',   risk.status.value))
        except ValueError as exc:
            return jsonify({'error': str(exc)}), 400
        _apply_risk_matrix_fields(risk, request.form)

        db_session.commit()
        return jsonify({
            'success': True,
            'redirect': url_for('project_management.view_project', id=project.id),
        })
    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


@project_management_bp.route('/risk/<int:risk_id>/delete', methods=['POST'])
def delete_risk(risk_id):
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    if not _valid_csrf():
        return _csrf_json_error()

    db_session = get_db_session()
    try:
        risk    = db_session.query(ProjectRiskLog).filter_by(id=risk_id).first()
        if not risk:
            return jsonify({'error': 'Risk not found'}), 404
        project = db_session.query(Project).filter_by(id=risk.project_id).first()

        if not is_project_owner(project, user):
            return jsonify({'error': 'Only the project owner can delete risks.'}), 403
        lock = _closed_json_guard(project)
        if lock:
            return lock

        db_session.delete(risk)
        db_session.commit()
        return jsonify({
            'success': True,
            'redirect': url_for('project_management.view_project', id=project.id),
        })
    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Documents  (upload: all members; download: all members; delete: owner only)
# ---------------------------------------------------------------------------

@project_management_bp.route('/upload/<int:project_id>', methods=['POST'])
def upload_document(project_id):
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))

    if not _valid_csrf():
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('project_management.view_project', id=project_id))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).filter_by(id=project_id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))

        if not is_project_member(project, user, db_session):
            flash('Permission denied.', 'error')
            return redirect(url_for('project_management.view_project', id=project_id))

        locked = _closed_redirect_guard(project)
        if locked:
            return locked

        if 'file' not in request.files or request.files['file'].filename == '':
            flash('No file selected.', 'error')
            return redirect(url_for('project_management.view_project', id=project_id))

        file = request.files['file']
        if not allowed_file(file.filename):
            flash(f'File type not allowed. Allowed: {", ".join(sorted(ALLOWED_EXTENSIONS))}', 'error')
            return redirect(url_for('project_management.view_project', id=project_id))

        # Grouping is mandatory: the document must be filed under a phase group.
        doc_cat = request.form.get('document_category', '').strip()
        if doc_cat not in DOCUMENT_CATEGORIES:
            flash('Please select a document group before uploading.', 'error')
            return redirect(url_for('project_management.view_project',
                                    id=project_id, tab='docs'))

        filename, orig_name = _store_upload(file)

        doc_name = (request.form.get('document_name') or orig_name).strip()
        doc_summ = request.form.get('document_summary',  '').strip()
        sensitive = request.form.get('is_sensitive') in ('1', 'on', 'true', 'True')

        # Only the project owner may flag a document sensitive (since only the
        # owner will be able to read it back).
        if sensitive and not is_project_owner(project, user):
            sensitive = False

        document = ProjectDocument(
            project_id   = project_id,
            category     = doc_cat,
            name         = doc_name,
            summary      = doc_summ,
            filename     = filename,
            is_sensitive = sensitive,
            uploaded_by  = user.id,
        )
        db_session.add(document)
        db_session.flush()          # need document.id to key the version row
        file_versions.record_version(
            db_session, DOC_ENTITY, document.id, UPLOAD_FOLDER,
            filename, original_filename=orig_name, uploaded_by=user.id,
            note='Initial upload',
        )
        _log_activity(db_session, project_id, user, 'Document uploaded', doc_name)
        db_session.commit()
        flash('Document uploaded successfully!', 'success')

    except Exception as exc:
        db_session.rollback()
        flash(f'Error uploading document: {exc}', 'error')
    finally:
        db_session.close()

    return redirect(url_for('project_management.view_project', id=project_id))


@project_management_bp.route('/document/<int:doc_id>/download')
def download_document(doc_id):
    # Public projects are read-only viewable, so a NON-sensitive document is
    # downloadable by anyone. A sensitive document stays restricted to the
    # project manager who created the project (requirement 6).
    user = get_current_user()   # may be None

    db_session = get_db_session()
    try:
        doc     = db_session.query(ProjectDocument).filter_by(id=doc_id).first()
        if not doc:
            abort(404)
        project = db_session.query(Project).filter_by(id=doc.project_id).first()

        if doc.is_sensitive and not (user and is_project_owner(project, user)):
            abort(403)

        upload_dir = os.path.abspath(UPLOAD_FOLDER)
        return send_from_directory(
            upload_dir, doc.filename,
            as_attachment=True,
            download_name=doc.name,
        )
    finally:
        db_session.close()


def _document_guard(db_session, doc_id, user):
    """Load a document + project and apply the full access rule set.

    Returns (doc, project, None) when `user` may act on it, else
    (None, None, 'not_found' | 'denied').

    The sensitive rule is enforced HERE, once, for every route that reaches a
    document's file or its history: a sensitive document is owner-only, so an
    OLD VERSION of one must never be reachable by a plain member. Route your
    version code through this helper - hand-rolling the check is how that hole
    gets reopened.
    """
    doc = db_session.query(ProjectDocument).filter_by(id=doc_id).first()
    if not doc:
        return None, None, 'not_found'
    project = db_session.query(Project).filter_by(id=doc.project_id).first()
    if not project:
        return None, None, 'not_found'

    owner = is_project_owner(project, user)
    if not owner and not is_project_member(project, user, db_session):
        return None, None, 'denied'
    if doc.is_sensitive and not owner:
        return None, None, 'denied'
    return doc, project, None


@project_management_bp.route('/document/<int:doc_id>/edit', methods=['POST'])
def edit_document(doc_id):
    """Update a document's details and, optionally, upload a new version of the file.

    Replaces the delete-and-re-create workaround: the row keeps its identity,
    its uploaded_by/uploaded_at and its place in the SDLC doc groups, while the
    previous file drops into the version trail instead of being destroyed.
    """
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))

    if not _valid_csrf():
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('project_management.dashboard'))

    db_session = get_db_session()
    stale_paths = []
    committed = False
    try:
        doc, project, err = _document_guard(db_session, doc_id, user)
        if err == 'not_found':
            flash('Document not found.', 'error')
            return redirect(url_for('project_management.dashboard'))
        if err:
            flash('You do not have permission to edit this document.', 'error')
            return redirect(url_for('project_management.dashboard'))

        locked = _closed_redirect_guard(project)
        if locked:
            return locked

        docs_url = url_for('project_management.view_project',
                           id=project.id, tab='docs')

        doc_name = (request.form.get('document_name') or '').strip()
        if not doc_name:
            flash('Document name is required.', 'error')
            return redirect(docs_url)

        doc_cat = (request.form.get('document_category') or '').strip()
        if doc_cat not in DOCUMENT_CATEGORIES:
            flash('Please select a document group.', 'error')
            return redirect(docs_url)

        file = request.files.get('file')
        replacing = bool(file and file.filename)
        if replacing and not allowed_file(file.filename):
            flash(f'File type not allowed. Allowed: {", ".join(sorted(ALLOWED_EXTENSIONS))}',
                  'error')
            return redirect(docs_url)

        doc.name     = doc_name
        doc.category = doc_cat
        doc.summary  = (request.form.get('document_summary') or '').strip()

        # Only the owner can read a sensitive document back, so only the owner
        # may set the flag. A member's edit leaves it exactly as it was.
        if is_project_owner(project, user):
            doc.is_sensitive = request.form.get('is_sensitive') in ('1', 'on', 'true', 'True')

        if replacing:
            # A document uploaded before versioning existed has no trail yet.
            # Seed its current file as v1 first, or replacing it would erase it.
            file_versions.backfill_initial(
                db_session, DOC_ENTITY, doc.id, UPLOAD_FOLDER, doc.filename,
                original_filename=doc.filename, uploaded_by=doc.uploaded_by,
                uploaded_at=doc.uploaded_at,
            )
            stored, orig = _store_upload(file)
            file_versions.record_version(
                db_session, DOC_ENTITY, doc.id, UPLOAD_FOLDER, stored,
                original_filename=orig, uploaded_by=user.id,
                note=(request.form.get('version_note') or '').strip() or None,
            )
            doc.filename = stored
            # Keep the newest N (the live file among them); the rest are dropped.
            # N is deeper for the SDLC phase groups - display_group is used, not
            # the raw category, so a legacy name that maps onto a group still
            # earns it. protect= is a belt-and-braces guard so a bookkeeping slip
            # can never unlink the file the document is actually serving.
            keep = file_versions.retention_for(DOC_ENTITY, doc.display_group)
            stale_paths = file_versions.prune(
                db_session, DOC_ENTITY, doc.id, UPLOAD_FOLDER,
                keep=keep, protect=(stored,))

        _log_activity(
            db_session, project.id, user,
            'Document version uploaded' if replacing else 'Document updated',
            doc.name,
        )
        db_session.commit()
        committed = True

        if stale_paths:
            logger.info('Pruned %d old version(s) of document %s (%s, keeping %d)',
                        len(stale_paths), doc_id, doc.display_group,
                        file_versions.retention_for(DOC_ENTITY, doc.display_group))
        flash('New version uploaded.' if replacing else 'Document updated.',
              'success')
        return redirect(docs_url)

    except Exception as exc:
        db_session.rollback()
        logger.exception('Error editing document %s', doc_id)
        flash(f'Error updating document: {exc}', 'error')
        return redirect(url_for('project_management.dashboard'))
    finally:
        db_session.close()
        # Unlink ONLY after a successful commit. Doing it earlier - or at all on
        # a failed transaction - would destroy the file while the version rows
        # that point at it survive the rollback.
        if committed:
            file_versions.remove_files(stale_paths)


@project_management_bp.route('/document/<int:doc_id>/versions')
def document_versions(doc_id):
    """The document's version history (newest first) for the Versions panel."""
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401

    db_session = get_db_session()
    try:
        doc, project, err = _document_guard(db_session, doc_id, user)
        if err == 'not_found':
            return jsonify({'error': 'Document not found'}), 404
        if err:
            return jsonify({'error': 'Permission denied'}), 403

        versions = file_versions.list_versions(db_session, DOC_ENTITY, doc.id)
        names = _user_name_map(
            db_session,
            [v.uploaded_by for v in versions] + [doc.uploaded_by],
        )

        payload = [{
            'id':        v.id,
            'version':   v.version_no,
            'filename':  v.original_filename or v.stored_filename,
            'size':      v.size_bytes,
            'note':      v.note or '',
            'uploaded_at': v.uploaded_at.strftime('%d %b %Y, %H:%M') if v.uploaded_at else '',
            'uploaded_by': names.get(v.uploaded_by, 'Unknown'),
            'is_current': v.stored_filename == doc.filename,
            'url': url_for('project_management.download_document_version',
                           doc_id=doc.id, version_id=v.id),
        } for v in versions]

        # A legacy document (uploaded before versioning) has no trail: its file
        # genuinely IS its only version. Show it as v1 via the plain download
        # route rather than writing a row from a GET.
        if not payload and doc.filename:
            payload = [{
                'id': None,
                'version': 1,
                'filename': doc.filename,
                'size': None,
                'note': '',
                'uploaded_at': doc.uploaded_at.strftime('%d %b %Y, %H:%M') if doc.uploaded_at else '',
                'uploaded_by': names.get(doc.uploaded_by, 'Unknown'),
                'is_current': True,
                'url': url_for('project_management.download_document', doc_id=doc.id),
            }]

        return jsonify({
            'success': True,
            'name': doc.name,
            'group': doc.display_group,
            'max_versions': file_versions.retention_for(DOC_ENTITY, doc.display_group),
            'versions': payload,
        })
    finally:
        db_session.close()


@project_management_bp.route('/document/<int:doc_id>/version/<int:version_id>/download')
def download_document_version(doc_id, version_id):
    """Download one historical version.

    Unlike download_document (public for a non-sensitive doc on a public
    project), history is edit-gated: _document_guard requires membership, and
    re-applies the sensitive owner-only rule to the old file too.
    """
    user = get_current_user()
    if not user:
        abort(403)

    db_session = get_db_session()
    try:
        doc, project, err = _document_guard(db_session, doc_id, user)
        if err == 'not_found':
            abort(404)
        if err:
            abort(403)

        # Scoped to this document, so a version id belonging to another one 404s.
        version = file_versions.get_version(db_session, DOC_ENTITY, doc.id, version_id)
        if not version:
            abort(404)

        upload_dir = os.path.abspath(UPLOAD_FOLDER)
        download_name = version.original_filename or version.stored_filename
        return send_from_directory(
            upload_dir, version.stored_filename,
            as_attachment=True,
            download_name=f'v{version.version_no}_{download_name}',
        )
    finally:
        db_session.close()


@project_management_bp.route('/document/<int:doc_id>/delete', methods=['POST'])
def delete_document(doc_id):
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    if not _valid_csrf():
        return _csrf_json_error()

    db_session = get_db_session()
    stale_paths = []
    try:
        doc     = db_session.query(ProjectDocument).filter_by(id=doc_id).first()
        if not doc:
            return jsonify({'error': 'Document not found'}), 404
        project = db_session.query(Project).filter_by(id=doc.project_id).first()

        if not is_project_owner(project, user):
            return jsonify({'error': 'Only the project owner or admin can delete documents.'}), 403
        lock = _closed_json_guard(project)
        if lock:
            return lock

        # The version trail has no FK to the document (one shared table serves
        # every module), so the database will not cascade it away - this route
        # owns the cleanup. Files are unlinked after the commit, in `finally`.
        stale_paths = file_versions.delete_all(
            db_session, DOC_ENTITY, doc.id, UPLOAD_FOLDER)

        current = _upload_file_path(doc.filename)
        if current:
            stale_paths.append(current)

        db_session.delete(doc)
        db_session.commit()
        return jsonify({
            'success': True,
            'redirect': url_for('project_management.view_project', id=project.id),
        })
    except Exception as exc:
        db_session.rollback()
        stale_paths = []        # nothing was committed - leave the files alone
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()
        file_versions.remove_files(stale_paths)


# ---------------------------------------------------------------------------
# Backward compat redirect
# ---------------------------------------------------------------------------

@project_management_bp.route('/index')
def index():
    return redirect(url_for('project_management.dashboard'))


# ---------------------------------------------------------------------------
# My Work  - every task assigned to the current user, across all projects
# ---------------------------------------------------------------------------

@project_management_bp.route('/my-tasks')
def my_tasks():
    user = get_current_user()
    if not user:
        flash('Please sign in to see your tasks.', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        # Optional priority filter (?priority=High); anything else = all.
        priority_filter = request.args.get('priority', '')
        if priority_filter not in TASK_PRIORITIES:
            priority_filter = ''

        tasks = db_session.query(ProjectTask).options(
            joinedload(ProjectTask.milestone).joinedload(ProjectMilestone.project)
        ).filter(ProjectTask.assigned_to == user.id).all()

        work_view = request.args.get('view', 'all')
        if work_view not in ('all', 'open', 'overdue', 'completed'):
            work_view = 'all'
        work_q = (request.args.get('q') or '').strip()

        rows = []
        for t in tasks:
            ms      = t.milestone
            project = ms.project if ms else None
            if not project:
                continue
            rows.append({
                'read_only':   project.is_closed,
                'task_id':     t.id,
                'name':        t.name,
                'project_id':  project.id,
                'project':     project.name,
                'milestone':   ms.name,
                'start':       t.start_date,
                'end':         t.end_date,
                'status':      t.status.value,
                'priority':    _task_priority(t),
                'percent':     t.effective_percent(),
                'overdue':     t.is_overdue(),
                'due_soon':    t.is_nearing_deadline(),
            })

        # KPI tiles always reflect everything assigned; only the list filters.
        open_count    = sum(1 for r in rows if r['status'] != 'Completed')
        overdue_count = sum(1 for r in rows if r['overdue'])
        total_count   = len(rows)

        if priority_filter:
            rows = [r for r in rows if r['priority'] == priority_filter]

        if work_view == 'open':
            rows = [r for r in rows if r['status'] != 'Completed']
        elif work_view == 'completed':
            rows = [r for r in rows if r['status'] == 'Completed']
        elif work_view == 'overdue':
            rows = [r for r in rows if r['overdue']]
        if work_q:
            term = work_q.casefold()
            rows = [r for r in rows if any(term in r[key].casefold()
                    for key in ('name', 'project', 'milestone'))]

        # Overdue first, then priority (Critical first), then soonest deadline.
        rows.sort(key=lambda r: (not r['overdue'],
                                 PRIORITY_ORDER[r['priority']], r['end'] or date.max, r['task_id']))

        return render_template(
            'project_management/my_tasks.html',
            user=user,
            rows=rows,
            open_count=open_count,
            overdue_count=overdue_count,
            total_count=total_count,
            task_statuses=[s.value for s in TaskStatus],
            task_priorities=TASK_PRIORITIES,
            priority_filter=priority_filter,
            work_view=work_view, work_q=work_q,
        )
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Excel export - milestones & tasks  (project members / owner only)
# ---------------------------------------------------------------------------

@project_management_bp.route('/project/<int:id>/export.xlsx')
def export_project_xlsx(id):
    user = get_current_user()
    if not user:
        flash('Please sign in to export.', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            selectinload(Project.milestones).selectinload(ProjectMilestone.tasks)
                .selectinload(ProjectTask.notes),
            selectinload(Project.team_members),
            selectinload(Project.risk_logs),   # Risk Register sheet
        ).filter_by(id=id).first()

        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))

        if not is_project_member(project, user, db_session):
            flash('You do not have access to this project.', 'error')
            return redirect(url_for('project_management.view_project', id=id))

        # Resolve assignee AND note-author names once (the Milestone Notes sheet
        # needs the authors, who aren't necessarily task assignees).
        name_map = {}
        assignee_ids = {t.assigned_to for m in project.milestones for t in m.tasks if t.assigned_to}
        note_user_ids = {n.user_id for m in project.milestones for t in m.tasks for n in t.notes}
        for uid in assignee_ids | note_user_ids:
            u = db_session.query(User).filter_by(id=uid).first()
            if u:
                name_map[uid] = _full_name(u)

        # CPM / baseline context per task, carried into the Task Detail sheet.
        all_tasks = project.get_all_tasks()
        deps = _load_project_dependencies(db_session, [t.id for t in all_tasks])
        cpm_res = None
        if deps:
            cpm_res = compute_cpm(
                [{'id': t.id, 'name': t.name, 'start': t.start_date,
                  'end': t.end_date} for t in all_tasks],
                [{'predecessor_id': d.predecessor_id, 'successor_id': d.successor_id,
                  'type': d.dep_type, 'lag': d.lag_days} for d in deps])
            if not cpm_res.get('ok'):
                cpm_res = None
        preds_by_task = {}
        task_names = {t.id: t.name for t in all_tasks}
        for d in deps:
            label = task_names.get(d.predecessor_id, f'#{d.predecessor_id}')
            if d.dep_type != 'FS' or d.lag_days:
                lag = f'{d.lag_days:+d}d' if d.lag_days else ''
                label += f' ({d.dep_type}{lag})'
            preds_by_task.setdefault(d.successor_id, []).append(label)

        baseline = (db_session.query(ProjectBaseline)
                    .filter_by(project_id=project.id)
                    .order_by(ProjectBaseline.created_at.desc(),
                              ProjectBaseline.id.desc())
                    .first())
        baseline_ends = ({bt.task_id: bt.end_date for bt in baseline.tasks
                          if bt.task_id} if baseline else {})

        task_extras = {}
        for t in all_tasks:
            info = (cpm_res or {}).get('tasks', {}).get(t.id)
            b_end = baseline_ends.get(t.id)
            task_extras[t.id] = {
                'priority':     _task_priority(t),
                'percent':      t.effective_percent(),
                'predecessors': ', '.join(preds_by_task.get(t.id, [])),
                'critical':     bool(info and info['is_critical']),
                'baseline_end': b_end,
                'slip':         (t.end_date - b_end).days if b_end else None,
            }

        # SDLC Process sheet rows (None for legacy ungoverned projects).
        state_labels = {'passed': 'Gate passed', 'ready': 'Ready for sign-off',
                        'active': 'In progress', 'pending': 'Not started',
                        'unplanned': 'Not assigned'}
        sctx = _sdlc_context(project)
        sdlc_rows = []
        if sctx:
            for st in sctx['states']:
                ph = st['phase']
                sdlc_rows.append({
                    'name': st['name'],
                    'state': state_labels.get(st['state'], st['state']),
                    'milestones': ', '.join(m.name for m in st['milestones_obj']),
                    'tasks': (f"{st['milestone']['tasks_done']}/"
                              f"{st['milestone']['tasks_total']}"
                              if st['milestone'] else '-'),
                    'docs': ', '.join(st['doc_categories']),
                    'missing': ', '.join(st['docs_missing']),
                    'signed_by': (name_map.get(ph.signed_off_by, '')
                                  if ph.signed_off_by else ''),
                    'signed_on': (ph.signed_off_at.strftime('%d %b %Y')
                                  if ph.signed_off_at else ''),
                    'flags': ' | '.join(st['flags']),
                })
        workbook_bytes = build_project_workbook(project, name_map, task_extras,
                                                sdlc_rows=sdlc_rows)
        safe_name = secure_filename(project.name) or f'project_{project.id}'
        return Response(
            workbook_bytes,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            headers={'Content-Disposition': f'attachment; filename="{safe_name}_project_report.xlsx"'},
        )
    finally:
        db_session.close()


@project_management_bp.route('/project/<int:id>/export.csv')
def export_project_csv(id):
    """Legacy CSV path - kept so old links/bookmarks still work; now serves the
    professional Excel workbook."""
    return redirect(url_for('project_management.export_project_xlsx', id=id))


# ---------------------------------------------------------------------------
# Go-Live plan  (create / edit: any project member; one plan per project)
# ---------------------------------------------------------------------------

def _parse_optional_datetime(value):
    """Parse an <input type="datetime-local"> value ('YYYY-MM-DDTHH:MM')."""
    if not value:
        return None
    for fmt in ('%Y-%m-%dT%H:%M', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M'):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None


def _clean_choice(value, allowed):
    """Return value if it is one of `allowed`, else ''. Guards forged input."""
    return value if value in allowed else ''


def _golive_children_for(plan, section_key):
    """The plan's existing child rows belonging to one section."""
    if section_key == 'external_connectivity':
        return list(plan.connectivities)
    if section_key == 'contact_point':
        return list(plan.contacts)
    return [t for t in plan.tasks if t.section == section_key]


def _save_golive_children(plan, form, db_session, only=None):
    """
    (Re)build a plan's child rows from the submitted form. Callers delete the
    existing children first (on edit) so this always writes a clean set.

    `only` restricts the rebuild to a single section key - used by the focused
    ("edit one section") editor, whose form carries no fields for the other
    sections and must therefore leave their rows untouched.

    Field naming, per task-style section `<key>`:
        <key>_task[],  <key>_desc[],  <key>_server[],  <key>_dept[],
        <key>_team[],  <key>_start[], <key>_end[],     <key>_status[]
    External connectivity:
        conn_source[], conn_dest[], conn_port[], conn_dir[], conn_desc[]
    Contact point:
        contact_dept[], contact_team[], contact_email[], contact_number[]
    """
    # Task-style sections
    for key in GOLIVE_TASK_SECTION_KEYS:
        if only and key != only:
            continue
        if not plan.is_section_enabled(key):
            continue
        tasks    = form.getlist(f'{key}_task[]')
        descs    = form.getlist(f'{key}_desc[]')
        servers  = form.getlist(f'{key}_server[]')
        depts    = form.getlist(f'{key}_dept[]')
        teams    = form.getlist(f'{key}_team[]')
        starts   = form.getlist(f'{key}_start[]')
        ends     = form.getlist(f'{key}_end[]')
        statuses = form.getlist(f'{key}_status[]')

        for i, task_name in enumerate(tasks):
            if not (task_name or '').strip():
                continue
            status = _clean_choice(statuses[i] if i < len(statuses) else '',
                                   GOLIVE_TASK_STATUSES) or 'Not Started'
            db_session.add(GoLiveTask(
                plan_id        = plan.id,
                section        = key,
                task           = task_name.strip(),
                description    = (descs[i]   if i < len(descs)   else '').strip(),
                server_host    = (servers[i] if i < len(servers) else '').strip(),
                department     = _clean_choice(depts[i] if i < len(depts) else '',
                                               GOLIVE_DEPARTMENTS),
                team           = (teams[i]   if i < len(teams)   else '').strip(),
                start_datetime = _parse_optional_datetime(starts[i] if i < len(starts) else ''),
                end_datetime   = _parse_optional_datetime(ends[i]   if i < len(ends)   else ''),
                status         = status,
                sort_order     = i,
            ))

    # External connectivity
    if ((not only or only == 'external_connectivity')
            and plan.is_section_enabled('external_connectivity')):
        srcs  = form.getlist('conn_source[]')
        dests = form.getlist('conn_dest[]')
        ports = form.getlist('conn_port[]')
        dirs  = form.getlist('conn_dir[]')
        cdesc = form.getlist('conn_desc[]')
        for i in range(len(srcs)):
            src  = (srcs[i]  if i < len(srcs)  else '').strip()
            dest = (dests[i] if i < len(dests) else '').strip()
            port = (ports[i] if i < len(ports) else '').strip()
            desc = (cdesc[i] if i < len(cdesc) else '').strip()
            if not (src or dest or port or desc):
                continue
            db_session.add(GoLiveConnectivity(
                plan_id          = plan.id,
                source_host      = src,
                destination_host = dest,
                port             = port,
                direction        = _clean_choice(dirs[i] if i < len(dirs) else '',
                                                  GOLIVE_CONNECTION_DIRECTIONS),
                description      = desc,
                sort_order       = i,
            ))

    # Contact point
    if ((not only or only == 'contact_point')
            and plan.is_section_enabled('contact_point')):
        depts   = form.getlist('contact_dept[]')
        teams   = form.getlist('contact_team[]')
        emails  = form.getlist('contact_email[]')
        numbers = form.getlist('contact_number[]')
        for i in range(len(depts) if depts else len(teams)):
            dept   = (depts[i]   if i < len(depts)   else '').strip()
            team   = (teams[i]   if i < len(teams)   else '').strip()
            email  = (emails[i]  if i < len(emails)  else '').strip()
            number = (numbers[i] if i < len(numbers) else '').strip()
            if not (dept or team or email or number):
                continue
            db_session.add(GoLiveContact(
                plan_id        = plan.id,
                department     = _clean_choice(dept, GOLIVE_DEPARTMENTS),
                team           = team,
                email          = email,
                contact_number = number,
                sort_order     = i,
            ))


def _apply_section_toggles(plan, form):
    """Read the six enable_<section> checkboxes from the form onto the plan."""
    plan.enable_prerequisite          = form.get('enable_prerequisite') in ('1', 'on', 'true')
    plan.enable_production            = form.get('enable_production') in ('1', 'on', 'true')
    plan.enable_post_golive           = form.get('enable_post_golive') in ('1', 'on', 'true')
    plan.enable_failover_dr           = form.get('enable_failover_dr') in ('1', 'on', 'true')
    plan.enable_external_connectivity = form.get('enable_external_connectivity') in ('1', 'on', 'true')
    plan.enable_contact_point         = form.get('enable_contact_point') in ('1', 'on', 'true')


def _golive_form_context(user, project, plan=None, scope_section=None):
    """
    Shared template context for the create/edit Go-Live forms.

    `scope_section` is the focused editor's section key (None = the full
    plan form, which is what create and "Edit all sections" use).
    """
    enabled_sections = []
    if plan:
        for key in GOLIVE_ALL_SECTIONS:
            if plan.is_section_enabled(key):
                enabled_sections.append((key, GOLIVE_SECTION_LABELS[key]))
    return dict(
        user=user,
        project=project,
        plan=plan,
        task_sections=GOLIVE_TASK_SECTIONS,
        section_labels=GOLIVE_SECTION_LABELS,
        departments=GOLIVE_DEPARTMENTS,
        statuses=GOLIVE_TASK_STATUSES,
        directions=GOLIVE_CONNECTION_DIRECTIONS,
        scope_section=scope_section,
        enabled_sections=enabled_sections,
    )


def _requested_golive_scope(plan, raw):
    """
    Validate a requested focused-editor section key against the plan.

    Returns the key, or '' for the full form - an unknown key, or one whose
    section is switched off, falls back to the full form rather than showing
    an editor for something that is not part of the plan.
    """
    key = (raw or '').strip()
    if key in GOLIVE_ALL_SECTIONS and plan is not None and plan.is_section_enabled(key):
        return key
    return ''


@project_management_bp.route('/project/<int:project_id>/golive/create', methods=['GET', 'POST'])
def create_golive(project_id):
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            joinedload(Project.golive_plan)
        ).filter_by(id=project_id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))

        if not is_project_member(project, user, db_session):
            flash('Only members of this project can create a Go-Live plan.', 'error')
            return redirect(url_for('project_management.view_project', id=project_id))

        locked = _closed_redirect_guard(project)
        if locked:
            return locked

        # One plan per project - redirect to edit if it already exists.
        if project.golive_plan:
            return redirect(url_for('project_management.edit_golive', project_id=project_id))

        if request.method == 'POST':
            if not _valid_csrf():
                flash('Invalid security token. Please try again.', 'error')
                return redirect(url_for('project_management.create_golive', project_id=project_id))
            try:
                plan = GoLivePlan(project_id=project.id, created_by=user.id)
                _apply_section_toggles(plan, request.form)
                db_session.add(plan)
                db_session.flush()
                _save_golive_children(plan, request.form, db_session)
                _log_activity(db_session, project.id, user, 'Go-Live plan created')
                db_session.commit()
                flash('Go-Live plan created successfully!', 'success')
                return redirect(url_for('project_management.view_project', id=project_id))
            except Exception as exc:
                db_session.rollback()
                flash(f'Error creating Go-Live plan: {exc}', 'error')

        return render_template('project_management/create_golive.html',
                               **_golive_form_context(user, project))
    finally:
        db_session.close()


@project_management_bp.route('/project/<int:project_id>/golive/edit', methods=['GET', 'POST'])
def edit_golive(project_id):
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            joinedload(Project.golive_plan).selectinload(GoLivePlan.tasks),
            joinedload(Project.golive_plan).selectinload(GoLivePlan.connectivities),
            joinedload(Project.golive_plan).selectinload(GoLivePlan.contacts),
        ).filter_by(id=project_id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))

        if not is_project_member(project, user, db_session):
            flash('Only members of this project can edit the Go-Live plan.', 'error')
            return redirect(url_for('project_management.view_project', id=project_id))

        locked = _closed_redirect_guard(project)
        if locked:
            return locked

        plan = project.golive_plan
        if not plan:
            return redirect(url_for('project_management.create_golive', project_id=project_id))

        if request.method == 'POST':
            # The focused editor posts its own section key so the save only
            # touches that section - its form carries no fields (and no
            # section toggles) for anything else.
            scope = _requested_golive_scope(plan, request.form.get('scope'))
            if not _valid_csrf():
                flash('Invalid security token. Please try again.', 'error')
                return redirect(url_for('project_management.edit_golive',
                                        project_id=project_id, section=scope or None))
            try:
                if scope:
                    for child in _golive_children_for(plan, scope):
                        db_session.delete(child)
                    db_session.flush()
                    _save_golive_children(plan, request.form, db_session, only=scope)
                    label = GOLIVE_SECTION_LABELS[scope]
                    _log_activity(db_session, project.id, user,
                                  f'Go-Live plan updated ({label})')
                    db_session.commit()
                    flash(f'{label} updated successfully!', 'success')
                    return redirect(url_for('project_management.view_project',
                                            id=project_id, tab='delivery', glsec=scope))

                _apply_section_toggles(plan, request.form)
                # Replace all children with the freshly submitted set.
                for child in list(plan.tasks) + list(plan.connectivities) + list(plan.contacts):
                    db_session.delete(child)
                db_session.flush()
                _save_golive_children(plan, request.form, db_session)
                _log_activity(db_session, project.id, user, 'Go-Live plan updated')
                db_session.commit()
                flash('Go-Live plan updated successfully!', 'success')
                return redirect(url_for('project_management.view_project',
                                        id=project_id, tab='delivery'))
            except Exception as exc:
                db_session.rollback()
                flash(f'Error updating Go-Live plan: {exc}', 'error')

        # On a failed POST stay in the editor the user was actually using.
        scope = _requested_golive_scope(
            plan, request.form.get('scope') if request.method == 'POST'
            else request.args.get('section'))
        return render_template('project_management/edit_golive.html',
                               **_golive_form_context(user, project, plan, scope))
    finally:
        db_session.close()


@project_management_bp.route('/project/<int:project_id>/golive/export.xlsx')
def export_golive_xlsx(project_id):
    # Mirrors the project page's read-only access: anyone who can see the
    # project can download its Go-Live plan workbook.
    user = get_current_user()

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            joinedload(Project.golive_plan).selectinload(GoLivePlan.tasks),
            joinedload(Project.golive_plan).selectinload(GoLivePlan.connectivities),
            joinedload(Project.golive_plan).selectinload(GoLivePlan.contacts),
        ).filter_by(id=project_id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))

        plan = project.golive_plan
        if not plan:
            flash('This project has no Go-Live plan yet.', 'error')
            return redirect(url_for('project_management.view_project', id=project_id))

        workbook_bytes = build_golive_workbook(project, plan)
        safe_name = secure_filename(project.name) or f'project_{project.id}'
        return Response(
            workbook_bytes,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            headers={'Content-Disposition': f'attachment; filename="{safe_name}_golive_plan.xlsx"'},
        )
    finally:
        db_session.close()


@project_management_bp.route('/golive/task/<int:task_id>/status', methods=['POST'])
def update_golive_task_status(task_id):
    """Inline status update for a single Go-Live task. Any project member may
    update it (mirrors the create/update permission on the plan itself)."""
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    if not _valid_csrf():
        return _csrf_json_error()

    data = request.get_json(force=True)
    new_status = data.get('status')
    if new_status not in GOLIVE_TASK_STATUSES:
        return jsonify({'error': 'Invalid status'}), 400

    db_session = get_db_session()
    try:
        task = db_session.query(GoLiveTask).options(
            joinedload(GoLiveTask.plan)
        ).filter_by(id=task_id).first()
        if not task:
            return jsonify({'error': 'Task not found'}), 404

        project = db_session.query(Project).filter_by(id=task.plan.project_id).first()
        if not is_project_member(project, user, db_session):
            return jsonify({'error': 'Permission denied'}), 403
        lock = _closed_json_guard(project)
        if lock:
            return lock

        task.status = new_status
        _log_activity(db_session, project.id, user, 'Go-Live task status changed',
                      f'"{task.task}" -> {new_status}')
        db_session.commit()
        return jsonify({'success': True, 'status': new_status})
    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Private helpers  (form-parsing utilities)
# ---------------------------------------------------------------------------

def _save_stakeholders(project_id, form, db_session):
    names        = form.getlist('stakeholder_names[]')
    roles        = form.getlist('stakeholder_roles[]')
    emails       = form.getlist('stakeholder_emails[]')
    designations = form.getlist('stakeholder_designations[]')
    for i, name in enumerate(names):
        if name.strip():
            db_session.add(ProjectStakeholder(
                project_id  = project_id,
                name        = name,
                role        = roles[i]        if i < len(roles)        else '',
                email       = emails[i]       if i < len(emails)       else '',
                designation = designations[i] if i < len(designations) else '',
            ))


def _save_team_members(project_id, form, db_session):
    ids    = form.getlist('team_member_ids[]')
    roles  = form.getlist('team_member_roles[]')
    groups = form.getlist('team_member_groups[]')
    for i, member_id in enumerate(ids):
        if member_id:
            # Group is mandatory: the forms enforce it client-side; a direct
            # POST without one is rejected so no member lands ungrouped.
            group = groups[i].strip() if i < len(groups) else ''
            if group not in TEAM_MEMBER_GROUPS:
                raise ValueError(
                    'Please select a group (Lead or Engineer) for every team member.')
            db_session.add(ProjectTeamMember(
                project_id   = project_id,
                user_id      = int(member_id),
                role         = roles[i] if i < len(roles) else 'Team Member',
                member_group = group,
            ))


def _save_documents(project_id, form, files, user_id, db_session):
    doc_names   = form.getlist('document_names[]')
    doc_cats    = form.getlist('document_categories[]')
    doc_summs   = form.getlist('document_summaries[]')
    doc_sens    = form.getlist('document_sensitive[]')   # parallel "0"/"1" flags
    doc_files   = files.getlist('document_files[]')
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)

    for i, doc_name in enumerate(doc_names):
        file = doc_files[i] if i < len(doc_files) else None
        if not doc_name.strip() and (not file or not file.filename):
            continue

        # Grouping is mandatory: every saved document must carry one of the
        # phase groups (enforced client-side too; direct POSTs are rejected).
        category = doc_cats[i].strip() if i < len(doc_cats) else ''
        if category not in DOCUMENT_CATEGORIES:
            raise ValueError('Please select a document group for every document.')

        filename = None
        orig = None
        if file and file.filename:
            if not allowed_file(file.filename):
                continue
            filename, orig = _store_upload(file)

        sensitive = (doc_sens[i] in ('1', 'on', 'true', 'True')) if i < len(doc_sens) else False

        document = ProjectDocument(
            project_id   = project_id,
            category     = category,
            name         = doc_name.strip() or (filename or ''),
            summary      = doc_summs[i] if i < len(doc_summs) else '',
            filename     = filename or '',
            is_sensitive = sensitive,
            uploaded_by  = user_id,
        )
        db_session.add(document)

        # A document row can be created without a file (name + summary only);
        # only a real file starts a version trail.
        if filename:
            db_session.flush()      # need document.id to key the version row
            file_versions.record_version(
                db_session, DOC_ENTITY, document.id, UPLOAD_FOLDER,
                filename, original_filename=orig, uploaded_by=user_id,
                note='Initial upload',
            )


# ---------------------------------------------------------------------------
# About  (public - explains the module to end users and the support team)
# ---------------------------------------------------------------------------

@project_management_bp.route('/about')
def about():
    user = get_current_user()
    return render_template('project_management/about.html', user=user)


# ---------------------------------------------------------------------------
# Architect Diagram  (public - in-browser, stateless architecture canvas)
#
# A drag-and-drop diagramming workspace for solution / infrastructure design.
# It is deliberately STATELESS on the server: nothing is written to the
# database and there is no server-side persistence at all. A working draft
# auto-saves to the visitor's browser localStorage (offered for restore on the
# next visit); durable copies are kept by exporting .json (re-openable) or
# PNG / SVG. The accompanying JavaScript (static/js/pm_architect_diagram.js)
# renders the palette, canvas, grouping zones, typed connectors, align /
# distribute tools, an industry template gallery (3-tier, microservices,
# serverless cloud, Kubernetes, event-driven, CI/CD, DR, API-led integration,
# GenAI/RAG, DMZ, zero-trust, ...) and the full-canvas image export entirely
# client-side, so this route only needs to serve the page shell.
# ---------------------------------------------------------------------------

@project_management_bp.route('/architect-diagram')
def architect_diagram():
    user = get_current_user()   # may be None (anonymous visitor); open to all
    return render_template('project_management/architect_diagram.html', user=user)


# ===========================================================================
# Document builders (HLD + BRD + SSIA) - Template administration + guest
# authoring. Every document kind shares the HLDTemplateSection engine,
# discriminated by doc_type; the per-project authoring flow below remains
# HLD-only.
# ===========================================================================

# Labels and seeders per document kind, consumed by the shared admin and
# guest-builder routes/templates.
DOC_BUILDER_KINDS = {
    'hld': {
        'code': 'hld', 'abbr': 'HLD', 'article': 'an',
        'noun': 'High-Level Design',
        'ensure': ensure_hld_template_seeded,
    },
    'brd': {
        'code': 'brd', 'abbr': 'BRD', 'article': 'a',
        'noun': 'Business Requirements Document',
        'ensure': ensure_brd_template_seeded,
    },
    'ssia': {
        'code': 'ssia', 'abbr': 'SSIA', 'article': 'an',
        'noun': 'System Security Impact Assessment',
        'ensure': ensure_ssia_template_seeded,
    },
}


def _load_template_sections(db_session, doc_type='hld'):
    """Current master template for one document kind, ordered, with columns."""
    return (db_session.query(HLDTemplateSection)
            .options(joinedload(HLDTemplateSection.columns))
            .filter(HLDTemplateSection.doc_type == doc_type)
            .order_by(HLDTemplateSection.position, HLDTemplateSection.id)
            .all())


# --------------------------------------------------------------------------
# Admin: master template management
# --------------------------------------------------------------------------

def _template_admin_page(doc_type):
    """Shared admin-only template manager for one document kind."""
    kind = DOC_BUILDER_KINDS[doc_type]
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))
    if user.role != 'admin':
        flash(f'Only administrators can manage the {kind["abbr"]} template.', 'error')
        return redirect(url_for('project_management.dashboard'))

    db_session = get_db_session()
    try:
        kind['ensure'](db_session)
        sections = _load_template_sections(db_session, doc_type)
        tree = flatten_hld_tree(sections)   # [{section, number, depth}, ...]
        return render_template('project_management/hld_admin.html',
                               user=user, tree=tree, total=len(sections),
                               doc_kind=kind)
    finally:
        db_session.close()


@project_management_bp.route('/hld-template')
def hld_template_admin():
    """Admin-only HLD template manager."""
    return _template_admin_page('hld')


@project_management_bp.route('/brd-template')
def brd_template_admin():
    """Admin-only BRD template manager."""
    return _template_admin_page('brd')


@project_management_bp.route('/ssia-template')
def ssia_template_admin():
    """Admin-only SSIA template manager."""
    return _template_admin_page('ssia')


@project_management_bp.route('/hld-template/section/add', methods=['POST'])
def hld_template_add_section():
    user = get_current_user()
    if not user or user.role != 'admin':
        return jsonify({'error': 'Administrator access required.'}), 403
    if not _valid_csrf():
        return _csrf_json_error()

    data = request.get_json(silent=True) or {}
    title = (data.get('title') or '').strip()
    if not title:
        return jsonify({'error': 'Section title is required.'}), 400
    doc_type = data.get('doc_type') if data.get('doc_type') in DOC_BUILDER_KINDS else 'hld'
    description = (data.get('description') or '').strip()
    has_table = bool(data.get('has_table'))
    columns = [str(c).strip() for c in (data.get('columns') or []) if str(c).strip()]
    # Parent (None = top level) and desired 1-based position among its siblings.
    parent_id = data.get('parent_id')
    try:
        parent_id = int(parent_id) if parent_id not in (None, '', '0', 0) else None
    except (TypeError, ValueError):
        parent_id = None
    try:
        requested_no = int(data.get('section_number') or 0)
    except (TypeError, ValueError):
        requested_no = 0

    db_session = get_db_session()
    try:
        DOC_BUILDER_KINDS[doc_type]['ensure'](db_session)
        if parent_id is not None:
            parent = db_session.query(HLDTemplateSection).filter_by(
                id=parent_id, doc_type=doc_type).first()
            if not parent:
                return jsonify({'error': 'Parent section not found.'}), 400
        siblings = (db_session.query(HLDTemplateSection)
                    .filter_by(parent_id=parent_id, doc_type=doc_type)
                    .order_by(HLDTemplateSection.position).all())
        count = len(siblings)
        insert_idx = (requested_no - 1) if 1 <= requested_no <= count + 1 else count
        # Shift siblings at/after the insert point down by one.
        for s in siblings:
            if s.position >= insert_idx:
                s.position += 1
        section = HLDTemplateSection(
            doc_type=doc_type, parent_id=parent_id, position=insert_idx,
            title=title, description=description, has_table=has_table,
        )
        db_session.add(section)
        db_session.flush()
        if has_table:
            for ci, name in enumerate(columns):
                db_session.add(HLDTemplateColumn(section_id=section.id, name=name, sort_order=ci))
        resequence_hld_template(db_session, doc_type)
        db_session.commit()
        return jsonify({'success': True, 'id': section.id})
    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


@project_management_bp.route('/hld-template/section/<int:section_id>/update', methods=['POST'])
def hld_template_update_section(section_id):
    user = get_current_user()
    if not user or user.role != 'admin':
        return jsonify({'error': 'Administrator access required.'}), 403
    if not _valid_csrf():
        return _csrf_json_error()

    data = request.get_json(silent=True) or {}
    title = (data.get('title') or '').strip()
    if not title:
        return jsonify({'error': 'Section title is required.'}), 400

    db_session = get_db_session()
    try:
        section = db_session.query(HLDTemplateSection).filter_by(id=section_id).first()
        if not section:
            return jsonify({'error': 'Section not found.'}), 404

        section.title = title
        section.description = (data.get('description') or '').strip()
        section.has_table = bool(data.get('has_table'))

        # Rebuild columns from the submitted set (only meaningful for tables).
        for col in list(section.columns):
            db_session.delete(col)
        db_session.flush()
        if section.has_table:
            columns = [str(c).strip() for c in (data.get('columns') or []) if str(c).strip()]
            for ci, name in enumerate(columns):
                db_session.add(HLDTemplateColumn(section_id=section.id, name=name, sort_order=ci))
        db_session.commit()
        return jsonify({'success': True})
    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


@project_management_bp.route('/hld-template/section/<int:section_id>/delete', methods=['POST'])
def hld_template_delete_section(section_id):
    user = get_current_user()
    if not user or user.role != 'admin':
        return jsonify({'error': 'Administrator access required.'}), 403
    if not _valid_csrf():
        return _csrf_json_error()

    db_session = get_db_session()
    try:
        section = db_session.query(HLDTemplateSection).filter_by(id=section_id).first()
        if not section:
            return jsonify({'error': 'Section not found.'}), 404
        doc_type = section.doc_type

        # Collect this section + all descendants (the ORM cascade removes the
        # descendant rows, but we must clear project content for every one).
        all_sections = db_session.query(HLDTemplateSection).filter_by(doc_type=doc_type).all()
        children_of = {}
        for s in all_sections:
            children_of.setdefault(s.parent_id, []).append(s.id)
        doomed = []
        stack = [section_id]
        while stack:
            sid = stack.pop()
            doomed.append(sid)
            stack.extend(children_of.get(sid, []))

        db_session.query(ProjectHLDSection).filter(
            ProjectHLDSection.template_section_id.in_(doomed)
        ).delete(synchronize_session=False)

        db_session.delete(section)   # cascade removes descendant template rows + columns
        db_session.flush()
        resequence_hld_template(db_session, doc_type)   # auto-rearrange the sequence
        db_session.commit()
        return jsonify({'success': True})
    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


# --------------------------------------------------------------------------
# User: per-project HLD authoring
# --------------------------------------------------------------------------

def _hld_section_view(template_sections, hld):
    """
    Merge the current master template TREE with any saved project content into a
    single document-ordered list (with dotted numbers + depth) the editor and
    preview templates can iterate.
    """
    by_tmpl = {ps.template_section_id: ps for ps in hld.sections} if hld else {}
    view = []
    for node in flatten_hld_tree(template_sections):
        ts = node['section']
        ps = by_tmpl.get(ts.id)
        cols = ts.ordered_columns()
        rows = []
        if ps:
            for r in ps.ordered_rows():
                rows.append({'id': r.id, 'cells': r.cell_map()})
        view.append({
            'number': node['number'],
            'depth': node['depth'],
            'tmpl': ts,
            'columns': cols,
            'is_required': bool(ps.is_required) if ps else True,
            'short_description': (ps.short_description if ps else '') or '',
            'content': (ps.content if ps else '') or '',
            'rows': rows,
            'default_intro': hld_default_intro(ts.title),
        })
    return view


@project_management_bp.route('/project/<int:project_id>/hld/create', methods=['POST'])
def create_hld(project_id):
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            joinedload(Project.hld)
        ).filter_by(id=project_id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))
        if not is_project_member(project, user, db_session):
            flash('Only members of this project can create its HLD.', 'error')
            return redirect(url_for('project_management.view_project', id=project_id))
        locked = _closed_redirect_guard(project)
        if locked:
            return locked
        if not _valid_csrf():
            flash('Invalid security token. Please try again.', 'error')
            return redirect(url_for('project_management.view_project', id=project_id))

        if project.hld:
            return redirect(url_for('project_management.edit_hld', project_id=project_id))

        ensure_hld_template_seeded(db_session)
        hld = ProjectHLD(project_id=project.id, created_by=user.id)
        db_session.add(hld)
        db_session.flush()
        seed_hld_default_content(db_session, hld)   # pre-fill service-level tiers
        _log_activity(db_session, project.id, user, 'HLD created')
        db_session.commit()
        flash('HLD created. You can now fill in each section - changes save automatically.', 'success')
        return redirect(url_for('project_management.edit_hld', project_id=project_id))
    except Exception as exc:
        db_session.rollback()
        flash(f'Error creating HLD: {exc}', 'error')
        return redirect(url_for('project_management.view_project', id=project_id))
    finally:
        db_session.close()


@project_management_bp.route('/project/<int:project_id>/hld/edit')
def edit_hld(project_id):
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            joinedload(Project.hld).joinedload(ProjectHLD.sections)
                .joinedload(ProjectHLDSection.rows),
        ).filter_by(id=project_id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))
        if not is_project_member(project, user, db_session):
            flash('Only members of this project can edit its HLD.', 'error')
            return redirect(url_for('project_management.view_project', id=project_id))
        if not project.hld:
            return redirect(url_for('project_management.view_project', id=project_id))

        locked = project.is_closed
        ensure_hld_template_seeded(db_session)
        template_sections = _load_template_sections(db_session)
        sections_view = _hld_section_view(template_sections, project.hld)
        return render_template('project_management/hld_edit.html',
                               user=user, project=project, hld=project.hld,
                               sections=sections_view, locked=locked)
    finally:
        db_session.close()


@project_management_bp.route('/project/<int:project_id>/hld/section/save', methods=['POST'])
def save_hld_section(project_id):
    """Autosave a single HLD section (toggle, intro, content and table rows)."""
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    if not _valid_csrf():
        return _csrf_json_error()

    data = request.get_json(silent=True) or {}
    try:
        tmpl_id = int(data.get('template_section_id'))
    except (TypeError, ValueError):
        return jsonify({'error': 'Invalid section.'}), 400

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            joinedload(Project.hld)
        ).filter_by(id=project_id).first()
        if not project:
            return jsonify({'error': 'Project not found'}), 404
        if not is_project_member(project, user, db_session):
            return jsonify({'error': 'Permission denied'}), 403
        lock = _closed_json_guard(project)
        if lock:
            return lock
        if not project.hld:
            return jsonify({'error': 'No HLD for this project.'}), 404

        tmpl = db_session.query(HLDTemplateSection).filter_by(id=tmpl_id).first()
        if not tmpl:
            return jsonify({'error': 'Template section no longer exists.'}), 404

        # Find or create the project section bound to this template section.
        ps = db_session.query(ProjectHLDSection).filter_by(
            hld_id=project.hld.id, template_section_id=tmpl_id).first()
        if not ps:
            ps = ProjectHLDSection(hld_id=project.hld.id, template_section_id=tmpl_id)
            db_session.add(ps)
            db_session.flush()

        ps.is_required = bool(data.get('is_required', True))
        ps.short_description = (data.get('short_description') or '').strip()
        ps.content = (data.get('content') or '').strip()

        # Replace table rows with the submitted set (valid column ids only).
        valid_col_ids = {str(c.id) for c in tmpl.columns}
        for row in list(ps.rows):
            db_session.delete(row)
        db_session.flush()
        if tmpl.has_table:
            for i, raw in enumerate(data.get('rows') or []):
                if not isinstance(raw, dict):
                    continue
                cells = {k: (str(v) if v is not None else '')
                         for k, v in raw.items() if str(k) in valid_col_ids}
                if not any((v or '').strip() for v in cells.values()):
                    continue
                db_session.add(ProjectHLDRow(
                    section_id=ps.id, cells=json.dumps(cells), sort_order=i))

        db_session.commit()
        return jsonify({'success': True,
                        'saved_at': datetime.now().strftime('%H:%M:%S')})
    except Exception as exc:
        db_session.rollback()
        return jsonify({'error': str(exc)}), 500
    finally:
        db_session.close()


@project_management_bp.route('/project/<int:project_id>/hld/delete', methods=['POST'])
def delete_hld(project_id):
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            joinedload(Project.hld)
        ).filter_by(id=project_id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))
        if not is_project_member(project, user, db_session):
            flash('Only members of this project can delete its HLD.', 'error')
            return redirect(url_for('project_management.view_project', id=project_id))
        locked = _closed_redirect_guard(project)
        if locked:
            return locked
        if not _valid_csrf():
            flash('Invalid security token. Please try again.', 'error')
            return redirect(url_for('project_management.view_project', id=project_id))

        if project.hld:
            db_session.delete(project.hld)
            _log_activity(db_session, project.id, user, 'HLD deleted')
            db_session.commit()
            flash('HLD deleted.', 'success')
        return redirect(url_for('project_management.view_project', id=project_id))
    except Exception as exc:
        db_session.rollback()
        flash(f'Error deleting HLD: {exc}', 'error')
        return redirect(url_for('project_management.view_project', id=project_id))
    finally:
        db_session.close()


@project_management_bp.route('/project/<int:project_id>/hld/export.docx')
def export_hld_docx(project_id):
    # Mirrors the project page's read-only access: anyone who can see the
    # project can download its HLD document.
    user = get_current_user()

    db_session = get_db_session()
    try:
        project = db_session.query(Project).options(
            joinedload(Project.hld).joinedload(ProjectHLD.sections)
                .joinedload(ProjectHLDSection.rows),
        ).filter_by(id=project_id).first()
        if not project:
            flash('Project not found.', 'error')
            return redirect(url_for('project_management.dashboard'))
        if not project.hld:
            flash('This project has no HLD yet.', 'error')
            return redirect(url_for('project_management.view_project', id=project_id))

        ensure_hld_template_seeded(db_session)
        template_sections = _load_template_sections(db_session)
        doc_bytes = build_hld_document(project, project.hld, template_sections)
        safe_name = secure_filename(project.name) or f'project_{project.id}'
        return Response(
            doc_bytes,
            mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            headers={'Content-Disposition': f'attachment; filename="{safe_name}_HLD.docx"'},
        )
    finally:
        db_session.close()


# ===========================================================================
# Guest HLD - ephemeral, no database, no login
#
# A guest (not logged in) can build an HLD against the same master template and
# download it. NOTHING is persisted server-side: the page keeps the user's input
# in the browser only, and the export endpoint is stateless - it builds the .docx
# purely from the posted data. Logged-in members are redirected to their normal
# project HLD flow (this area is for guests only).
# ===========================================================================

def _prefilled_rows(template_sections, doc_type):
    """
    Table rows the guest editor starts with, keyed by section id.

    Reference content that would otherwise be retyped verbatim - the HLD's
    standard service tiers, the SSIA's screening questionnaire, and the fixed
    first-column labels of the SSIA's field/value tables - is declared once in
    GUEST_PREFILL_ROWS and bound POSITIONALLY to whatever columns the section
    carries now. A prefill row longer than the live column list is clipped and
    a shorter one leaves the remaining columns blank, so an admin editing the
    master template can never break the builder.
    """
    qa_parents = {ts.id for ts in template_sections if ts.layout() == 'qa'}

    by_section = {}
    for ts in template_sections:
        if not ts.has_table:
            continue
        cols = ts.ordered_columns()
        if not cols:
            continue
        prefill = GUEST_PREFILL_ROWS.get((doc_type, ts.title))
        if not prefill and ts.parent_id in qa_parents:
            # A questionnaire entry always takes exactly one answer, so give
            # the author the row rather than making them add it.
            prefill = [[]]
        if not prefill:
            continue
        by_section[ts.id] = [
            {'cells': {str(col.id): (str(raw[i]) if i < len(raw) else '')
                       for i, col in enumerate(cols)}}
            for raw in prefill
        ]
    return by_section


def _hld_guest_view(template_sections, doc_type='hld'):
    """
    Blank section view for the guest editor: the master template tree with
    sensible defaults (all Required, empty content), plus any reference table
    rows this document kind starts with.
    """
    sl_rows_by_section = _prefilled_rows(template_sections, doc_type)

    view = []
    for node in flatten_hld_tree(template_sections):
        ts = node['section']
        parent = node.get('parent')
        # Questionnaire entry: the question is its own heading and takes
        # exactly one answer, so the editor hides the section intro and the
        # add-row control that would otherwise imply a free-form table.
        is_qa = bool(parent is not None and parent.layout() == 'qa')
        view.append({
            'number': node['number'],
            'qa': is_qa,
            'q_number': node['number'].rsplit('.', 1)[-1],
            'depth': node['depth'],
            'tmpl': ts,
            'columns': ts.ordered_columns(),
            'block': ts.block_conf(),
            'is_required': True,
            'short_description': '',
            'content': '',
            'rows': sl_rows_by_section.get(ts.id, []),
            'default_intro': hld_default_intro(ts.title),
        })
    return view


def _guest_builder_page(doc_type, export_endpoint, sample_endpoint):
    """Shared standalone builder page - open to everyone, stateless."""
    kind = DOC_BUILDER_KINDS[doc_type]
    user = get_current_user()   # may be None (guest) - both are welcome

    db_session = get_db_session()
    try:
        kind['ensure'](db_session)
        template_sections = _load_template_sections(db_session, doc_type)
        sections_view = _hld_guest_view(template_sections, doc_type)
        return render_template('project_management/hld_guest.html',
                               user=user, sections=sections_view,
                               doc_kind=kind,
                               export_url=url_for(export_endpoint),
                               sample_url=url_for(sample_endpoint))
    finally:
        db_session.close()


def _guest_builder_export(doc_type):
    """Shared stateless export - builds the .docx from posted data only."""
    kind = DOC_BUILDER_KINDS[doc_type]
    if not _valid_csrf():
        return _csrf_json_error()

    data = request.get_json(silent=True) or {}
    project_name = (data.get('project_name') or '').strip()
    if not project_name:
        return jsonify({'error': 'Please enter a project name before downloading.'}), 400
    sections = data.get('sections') or {}
    if not isinstance(sections, dict):
        return jsonify({'error': 'Malformed request.'}), 400

    db_session = get_db_session()
    try:
        kind['ensure'](db_session)
        template_sections = _load_template_sections(db_session, doc_type)
        doc_bytes = build_hld_document_from_payload(project_name, sections,
                                                    template_sections, doc_type)
        safe_name = secure_filename(project_name) or 'guest'
        return Response(
            doc_bytes,
            mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            headers={'Content-Disposition':
                     f'attachment; filename="{safe_name}_{kind["abbr"]}.docx"'},
        )
    finally:
        db_session.close()


def _guest_builder_sample(doc_type):
    """
    Download the built-in reference sample for one document kind.

    A fully worked example so a first-time author can see the finished article
    before writing their own. The subject is App Assist itself, so the content
    is real rather than invented. It renders through exactly the same builder
    and renderer as a user-authored document - only the content is canned - so
    the sample can never drift from the live master template: sections an admin
    adds appear (empty), sections they remove disappear, and re-ordered columns
    follow the template.
    """
    kind = DOC_BUILDER_KINDS[doc_type]
    db_session = get_db_session()
    try:
        kind['ensure'](db_session)
        template_sections = _load_template_sections(db_session, doc_type)
        payload = build_sample_payload(template_sections, doc_type)
        doc_bytes = build_hld_document_from_payload(
            SAMPLE_PROJECT_NAME, payload, template_sections, doc_type)
        safe_name = secure_filename(SAMPLE_PROJECT_NAME) or 'sample'
        return Response(
            doc_bytes,
            mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            headers={'Content-Disposition':
                     f'attachment; filename="Sample_{kind["abbr"]}_{safe_name}.docx"'},
        )
    finally:
        db_session.close()


@project_management_bp.route('/guest/hld')
def guest_hld():
    """Standalone HLD builder - open to everyone, stateless (no storage).

    This replaced the per-project 'Create HLD' action: HLD creation now lives
    in the left nav for guests and logged-in users alike.
    """
    return _guest_builder_page('hld', 'project_management.guest_hld_export',
                               'project_management.guest_hld_sample')


@project_management_bp.route('/guest/hld/export.docx', methods=['POST'])
def guest_hld_export():
    return _guest_builder_export('hld')


@project_management_bp.route('/guest/hld/sample.docx')
def guest_hld_sample():
    """Download the reference sample HLD (App Assist)."""
    return _guest_builder_sample('hld')


@project_management_bp.route('/guest/brd')
def guest_brd():
    """Standalone BRD builder - same theme and behaviour as the HLD builder."""
    return _guest_builder_page('brd', 'project_management.guest_brd_export',
                               'project_management.guest_brd_sample')


@project_management_bp.route('/guest/brd/export.docx', methods=['POST'])
def guest_brd_export():
    return _guest_builder_export('brd')


@project_management_bp.route('/guest/brd/sample.docx')
def guest_brd_sample():
    """Download the reference sample BRD (App Assist)."""
    return _guest_builder_sample('brd')


@project_management_bp.route('/guest/ssia')
def guest_ssia():
    """Standalone SSIA builder - same theme and behaviour as the HLD builder."""
    return _guest_builder_page('ssia', 'project_management.guest_ssia_export',
                               'project_management.guest_ssia_sample')


@project_management_bp.route('/guest/ssia/export.docx', methods=['POST'])
def guest_ssia_export():
    return _guest_builder_export('ssia')


@project_management_bp.route('/guest/ssia/sample.docx')
def guest_ssia_sample():
    """Download the reference sample SSIA (App Assist)."""
    return _guest_builder_sample('ssia')

# ===========================================================================
# Proposal-deck builder  (guest AND logged-in; stateless, no DB)
#
# Anyone can build an IT proposal presentation from a form and download it
# as a single, self-contained HTML deck (present full-screen, or Print -> Save
# as PDF for a one-slide-per-page PDF). NOTHING is persisted server-side -- the
# page keeps the user's input in the browser only, and the export endpoint
# builds the HTML purely from the posted data.
# ===========================================================================

@project_management_bp.route('/proposal')
def proposal_builder():
    """Proposal-deck builder page -- available to guests and members alike."""
    user = get_current_user()
    # The form renders the full slide library; the page shows/hides slides to
    # match the selected template using this template -> slide-keys map.
    theme_slides = {tid: [s['key'] for s in slides_for(tid)] for tid in TEMPLATE_IDS}
    return render_template(
        'project_management/proposal_builder.html',
        user=user,
        templates=TEMPLATES,
        meta_fields=META_FIELDS,
        slides=SLIDES,
        theme_slides=theme_slides,
        data=default_data(TEMPLATE_IDS[0], include_all=True),
    )


@project_management_bp.route('/proposal/export.html', methods=['POST'])
def proposal_export():
    """Stateless export -- builds the self-contained HTML deck from posted data."""
    if not _valid_csrf():
        return _csrf_json_error()

    payload = request.get_json(silent=True) or {}
    if not isinstance(payload, dict):
        return jsonify({'error': 'Malformed request.'}), 400

    template_id = str(payload.get('template') or TEMPLATE_IDS[0])
    if template_id not in TEMPLATE_IDS:
        template_id = TEMPLATE_IDS[0]

    try:
        html_doc = build_deck_html(template_id, payload)
    except Exception:
        logger.exception('Proposal deck render failed (template=%s)', template_id)
        return jsonify({'error': 'Could not generate the deck. Please try again.'}), 500

    meta = payload.get('meta') if isinstance(payload.get('meta'), dict) else {}
    base = secure_filename(str(meta.get('client_name') or '').strip()) or 'proposal'
    filename = '%s_%s_proposal.html' % (base, template_id)
    return Response(
        html_doc,
        content_type='text/html; charset=utf-8',
        headers={'Content-Disposition': 'attachment; filename="%s"' % filename},
    )


# ===========================================================================
# Effort Estimate
# ===========================================================================
#
# A spreadsheet-style estimator. The admin-managed predefined resource list and
# its per-person-day rates are the master "core" dataset (the only thing stored
# in the DB). A user's estimate - weeks, per-week effort cells, rate overrides
# and the task plan - is a working copy that lives ONLY in the browser tab and
# is never written back, so user edits can never mutate the core defaults.
# "Reset to defaults" simply rebuilds the grid client-side from that core list,
# and export streams the posted working copy through openpyxl.
# ---------------------------------------------------------------------------

@project_management_bp.route('/effort-estimate')
def effort_estimate():
    """User assessment screen - open to all (working copy only)."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        defaults = load_effort_defaults(db_session)
    finally:
        db_session.close()
    return render_template(
        'project_management/effort_estimate.html',
        user=user,
        defaults=defaults,
        locations=list(EFFORT_LOCATIONS),
    )


@project_management_bp.route('/effort-estimate/export.xlsx', methods=['POST'])
def effort_estimate_export():
    """Stateless export - builds the .xlsx from the posted working copy."""
    if not _valid_csrf():
        return _csrf_json_error()

    payload = request.get_json(silent=True) or {}
    if not isinstance(payload, dict):
        return jsonify({'error': 'Malformed request.'}), 400

    try:
        buf = build_effort_workbook(payload)
    except Exception:
        logger.exception('Effort estimate export failed')
        return jsonify({'error': 'Could not generate the workbook. Please try again.'}), 500

    filename = export_filename(payload.get('project_name'))
    return Response(
        buf.getvalue(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        headers={'Content-Disposition': 'attachment; filename="%s"' % filename},
    )


@project_management_bp.route('/effort-estimate/plan/export.xlsx', methods=['POST'])
def project_plan_export():
    """Stateless export - builds the project-plan .xlsx from the posted working
    copy. Nothing about the plan is persisted server-side."""
    if not _valid_csrf():
        return _csrf_json_error()

    payload = request.get_json(silent=True) or {}
    if not isinstance(payload, dict):
        return jsonify({'error': 'Malformed request.'}), 400

    try:
        buf = build_plan_workbook(payload)
    except Exception:
        logger.exception('Project plan export failed')
        return jsonify({'error': 'Could not generate the workbook. Please try again.'}), 500

    filename = plan_export_filename(payload.get('project_name'))
    return Response(
        buf.getvalue(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        headers={'Content-Disposition': 'attachment; filename="%s"' % filename},
    )


# --------------------------------------------------------------------------
# Admin: core resource-defaults management
# --------------------------------------------------------------------------

@project_management_bp.route('/effort-estimate/admin')
def effort_admin():
    """Admin-only management of the predefined resource list and default rates."""
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return redirect(url_for('login'))
    if user.role != 'admin':
        flash('Only administrators can manage effort-estimate defaults.', 'error')
        return redirect(url_for('project_management.effort_estimate'))

    db_session = get_db_session()
    try:
        ensure_effort_defaults_seeded(db_session)
        rows = (db_session.query(EffortResourceDefault)
                .order_by(EffortResourceDefault.lifecycle_order,
                          EffortResourceDefault.location,
                          EffortResourceDefault.id)
                .all())
        # Group by location for the two-column admin layout.
        grouped = {loc: [] for loc in EFFORT_LOCATIONS}
        for r in rows:
            grouped.setdefault(r.location, []).append(r)
        return render_template(
            'project_management/effort_admin.html',
            user=user,
            grouped=grouped,
            locations=list(EFFORT_LOCATIONS),
            total=len(rows),
        )
    finally:
        db_session.close()


@project_management_bp.route('/effort-estimate/admin/resource/add', methods=['POST'])
def effort_admin_add():
    user = get_current_user()
    if not user or user.role != 'admin':
        return jsonify({'error': 'Administrator access required.'}), 403
    if not _valid_csrf():
        return _csrf_json_error()

    data = request.get_json(silent=True) or {}
    location = str(data.get('location') or '').strip()
    role = str(data.get('role') or '').strip()
    if location not in EFFORT_LOCATIONS:
        return jsonify({'error': 'Location must be Onshore or Offshore.'}), 400
    if not role:
        return jsonify({'error': 'Role name is required.'}), 400
    try:
        rate = max(0, int(float(data.get('rate') or 0)))
    except (TypeError, ValueError):
        return jsonify({'error': 'Rate must be a number.'}), 400

    db_session = get_db_session()
    try:
        ensure_effort_defaults_seeded(db_session)
        exists = (db_session.query(EffortResourceDefault)
                  .filter(EffortResourceDefault.location == location,
                          func.lower(EffortResourceDefault.role) == role.lower())
                  .first())
        if exists:
            return jsonify({'error': 'That role already exists for %s.' % location}), 400
        # New roles sort after everything else in the lifecycle.
        max_order = db_session.query(func.max(EffortResourceDefault.lifecycle_order)).scalar() or 0
        row = EffortResourceDefault(
            location=location, role=role, default_rate=rate,
            lifecycle_order=max_order + 1)
        db_session.add(row)
        db_session.commit()
        return jsonify({'success': True, 'resource': row.to_dict()})
    except Exception:
        db_session.rollback()
        logger.exception('Effort default add failed')
        return jsonify({'error': 'Could not add the resource.'}), 500
    finally:
        db_session.close()


@project_management_bp.route('/effort-estimate/admin/resource/<int:res_id>/update', methods=['POST'])
def effort_admin_update(res_id):
    user = get_current_user()
    if not user or user.role != 'admin':
        return jsonify({'error': 'Administrator access required.'}), 403
    if not _valid_csrf():
        return _csrf_json_error()

    data = request.get_json(silent=True) or {}
    db_session = get_db_session()
    try:
        row = db_session.query(EffortResourceDefault).get(res_id)
        if not row:
            return jsonify({'error': 'Resource not found.'}), 404
        if 'role' in data:
            role = str(data.get('role') or '').strip()
            if not role:
                return jsonify({'error': 'Role name cannot be empty.'}), 400
            row.role = role
        if 'rate' in data:
            try:
                row.default_rate = max(0, int(float(data.get('rate') or 0)))
            except (TypeError, ValueError):
                return jsonify({'error': 'Rate must be a number.'}), 400
        db_session.commit()
        return jsonify({'success': True, 'resource': row.to_dict()})
    except Exception:
        db_session.rollback()
        logger.exception('Effort default update failed')
        return jsonify({'error': 'Could not update the resource.'}), 500
    finally:
        db_session.close()


@project_management_bp.route('/effort-estimate/admin/resource/<int:res_id>/delete', methods=['POST'])
def effort_admin_delete(res_id):
    user = get_current_user()
    if not user or user.role != 'admin':
        return jsonify({'error': 'Administrator access required.'}), 403
    if not _valid_csrf():
        return _csrf_json_error()

    db_session = get_db_session()
    try:
        row = db_session.query(EffortResourceDefault).get(res_id)
        if not row:
            return jsonify({'error': 'Resource not found.'}), 404
        db_session.delete(row)
        db_session.commit()
        return jsonify({'success': True})
    except Exception:
        db_session.rollback()
        logger.exception('Effort default delete failed')
        return jsonify({'error': 'Could not remove the resource.'}), 500
    finally:
        db_session.close()


# --------------------------------------------------------------------------
# Admin: SDLC process definition
#
# The master phase list per methodology. Edits here shape FUTURE projects
# only - a project's phases are snapshotted at creation, so a running
# project's governed process never changes under it.
# --------------------------------------------------------------------------

def _require_admin_redirect():
    """Admin gate for the SDLC template pages. Returns a redirect or None."""
    user = get_current_user()
    if not user:
        flash('Please login.', 'error')
        return None, redirect(url_for('login'))
    if user.role != 'admin':
        flash('Only administrators can manage the SDLC process definition.', 'error')
        return None, redirect(url_for('project_management.dashboard'))
    return user, None


def _parse_default_tasks(raw: str) -> str:
    """
    Parse the admin textarea ('Task name | Category | Sub-category' per line)
    into the JSON stored on the template. Blank lines are skipped; missing
    category/sub-category parts are allowed.
    """
    tasks = []
    for line in (raw or '').splitlines():
        parts = [p.strip() for p in line.split('|')]
        if not parts or not parts[0]:
            continue
        name = parts[0]
        cat  = parts[1] if len(parts) > 1 else ''
        sub  = parts[2] if len(parts) > 2 else ''
        tasks.append([name, cat, sub])
    return json.dumps(tasks)


@project_management_bp.route('/sdlc-process')
def sdlc_admin():
    """Admin page: the ordered phase definition for each methodology."""
    user, deny = _require_admin_redirect()
    if deny:
        return deny

    db_session = get_db_session()
    try:
        ensure_sdlc_templates_seeded(db_session)
        rows = (db_session.query(SDLCPhaseTemplate)
                .order_by(SDLCPhaseTemplate.position, SDLCPhaseTemplate.id)
                .all())
        grouped = {m: [] for m in METHODOLOGIES}
        for r in rows:
            grouped.setdefault(r.methodology, []).append(r)
        return render_template(
            'project_management/sdlc_admin.html',
            user=user,
            grouped=grouped,
            methodologies=METHODOLOGIES,
            methodology_labels=METHODOLOGY_LABELS,
            document_categories=DOCUMENT_CATEGORIES,
        )
    finally:
        db_session.close()


@project_management_bp.route('/sdlc-process/phase/add', methods=['POST'])
def sdlc_admin_add_phase():
    user, deny = _require_admin_redirect()
    if deny:
        return deny
    if not _valid_csrf():
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('project_management.sdlc_admin'))

    methodology = (request.form.get('methodology') or '').strip().lower()
    name = (request.form.get('name') or '').strip()
    if methodology not in METHODOLOGIES or not name:
        flash('A methodology and a phase name are required.', 'error')
        return redirect(url_for('project_management.sdlc_admin'))

    db_session = get_db_session()
    try:
        max_pos = (db_session.query(func.max(SDLCPhaseTemplate.position))
                   .filter_by(methodology=methodology).scalar())
        db_session.add(SDLCPhaseTemplate(
            methodology=methodology,
            position=(max_pos + 1) if max_pos is not None else 0,
            name=name,
            doc_categories='[]', default_tasks='[]', weight=1,
        ))
        db_session.commit()
        flash(f"Phase '{name}' added to the "
              f"{METHODOLOGY_LABELS[methodology]} process.", 'success')
    except Exception as exc:
        db_session.rollback()
        flash(f'Error adding phase: {exc}', 'error')
    finally:
        db_session.close()
    return redirect(url_for('project_management.sdlc_admin'))


@project_management_bp.route('/sdlc-process/phase/<int:phase_id>/update', methods=['POST'])
def sdlc_admin_update_phase(phase_id):
    user, deny = _require_admin_redirect()
    if deny:
        return deny
    if not _valid_csrf():
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('project_management.sdlc_admin'))

    db_session = get_db_session()
    try:
        row = db_session.query(SDLCPhaseTemplate).get(phase_id)
        if not row:
            flash('Phase not found.', 'error')
            return redirect(url_for('project_management.sdlc_admin'))

        name = (request.form.get('name') or '').strip()
        if not name:
            flash('The phase name cannot be empty.', 'error')
            return redirect(url_for('project_management.sdlc_admin'))
        row.name          = name
        row.description   = (request.form.get('description') or '').strip()
        row.exit_criteria = (request.form.get('exit_criteria') or '').strip()
        try:
            row.weight = max(1, int(request.form.get('weight') or 1))
        except (TypeError, ValueError):
            row.weight = 1
        # Only known document categories are accepted (checkbox list).
        cats = [c for c in request.form.getlist('doc_categories')
                if c in DOCUMENT_CATEGORIES]
        row.doc_categories = json.dumps(cats)
        row.default_tasks  = _parse_default_tasks(request.form.get('default_tasks'))
        row.repeatable     = request.form.get('repeatable') == '1'

        db_session.commit()
        flash(f"Phase '{row.name}' updated.", 'success')
    except Exception as exc:
        db_session.rollback()
        flash(f'Error updating phase: {exc}', 'error')
    finally:
        db_session.close()
    return redirect(url_for('project_management.sdlc_admin'))


@project_management_bp.route('/sdlc-process/phase/<int:phase_id>/delete', methods=['POST'])
def sdlc_admin_delete_phase(phase_id):
    user, deny = _require_admin_redirect()
    if deny:
        return deny
    if not _valid_csrf():
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('project_management.sdlc_admin'))

    db_session = get_db_session()
    try:
        row = db_session.query(SDLCPhaseTemplate).get(phase_id)
        if not row:
            flash('Phase not found.', 'error')
            return redirect(url_for('project_management.sdlc_admin'))
        name, methodology = row.name, row.methodology
        db_session.delete(row)
        # Keep sibling positions contiguous.
        siblings = (db_session.query(SDLCPhaseTemplate)
                    .filter_by(methodology=methodology)
                    .order_by(SDLCPhaseTemplate.position, SDLCPhaseTemplate.id)
                    .all())
        for idx, s in enumerate(s for s in siblings if s.id != phase_id):
            s.position = idx
        db_session.commit()
        flash(f"Phase '{name}' removed from the "
              f"{METHODOLOGY_LABELS[methodology]} process.", 'success')
    except Exception as exc:
        db_session.rollback()
        flash(f'Error deleting phase: {exc}', 'error')
    finally:
        db_session.close()
    return redirect(url_for('project_management.sdlc_admin'))


@project_management_bp.route('/sdlc-process/phase/<int:phase_id>/move', methods=['POST'])
def sdlc_admin_move_phase(phase_id):
    user, deny = _require_admin_redirect()
    if deny:
        return deny
    if not _valid_csrf():
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('project_management.sdlc_admin'))

    direction = request.form.get('dir')
    db_session = get_db_session()
    try:
        row = db_session.query(SDLCPhaseTemplate).get(phase_id)
        if not row or direction not in ('up', 'down'):
            flash('Phase not found.', 'error')
            return redirect(url_for('project_management.sdlc_admin'))
        siblings = (db_session.query(SDLCPhaseTemplate)
                    .filter_by(methodology=row.methodology)
                    .order_by(SDLCPhaseTemplate.position, SDLCPhaseTemplate.id)
                    .all())
        idx = next((i for i, s in enumerate(siblings) if s.id == row.id), None)
        swap = idx - 1 if direction == 'up' else idx + 1
        if idx is not None and 0 <= swap < len(siblings):
            siblings[idx], siblings[swap] = siblings[swap], siblings[idx]
            for i, s in enumerate(siblings):
                s.position = i
            db_session.commit()
    except Exception as exc:
        db_session.rollback()
        flash(f'Error reordering phases: {exc}', 'error')
    finally:
        db_session.close()
    return redirect(url_for('project_management.sdlc_admin'))

@project_management_bp.route('/project/<int:id>/sdlc/phase/<int:phase_id>/governance', methods=['POST'])
def update_sdlc_governance(id, phase_id):
    user = get_current_user()
    if not user:
        return redirect(url_for('login'))
    if not _valid_csrf():
        abort(400)
    db_session = get_db_session()
    target = url_for('project_management.view_project', id=id, tab='process', _anchor=f'sdlc-stage-{phase_id}')
    try:
        project = db_session.query(Project).filter_by(id=id).first()
        if not project or not is_project_member(project, user, db_session):
            abort(403)
        if project.is_closed:
            flash('Closed projects cannot be changed.', 'error')
            return redirect(target)
        phase = db_session.query(ProjectSDLCPhase).filter_by(id=phase_id, project_id=id).first()
        if not phase:
            abort(404)
        revision = int(request.form.get('revision', '-1'))
        if revision != (phase.governance_revision or 0):
            raise ValueError('This stage changed in another session. Reload before saving.')
        gate = load_gate(phase)
        action = request.form.get('action', '')
        owner = is_project_owner(project, user)
        eligible = {m.user_id for m in project.team_members if m.user_id} | {project.created_by}
        reviewers = {m.user_id for m in project.team_members if m.member_group == 'Lead' and m.user_id} | {project.created_by}
        documents = {d.id: d for d in project.documents if not d.is_sensitive}
        note = (request.form.get('note') or '').strip()[:2000]
        if action == 'configure':
            if not owner:
                abort(403)
            owner_id = int(request.form.get('owner_id') or '0')
            reviewer_id = int(request.form.get('reviewer_id') or '0')
            if owner_id not in eligible or reviewer_id not in reviewers:
                raise ValueError('Select a current project member as owner and a lead or project manager as reviewer.')
            due = date.fromisoformat(request.form.get('due', '')).isoformat()
            labels = [line.strip() for line in request.form.get('criteria', '').splitlines() if line.strip()]
            if not 1 <= len(labels) <= 30 or any(len(label) > 300 for label in labels) or len(set(labels)) != len(labels):
                raise ValueError('Enter 1 to 30 unique criteria, at most 300 characters each, one per line.')
            existing = {item['label']: item for item in gate.get('items', [])}
            gate.update(owner_id=owner_id, reviewer_id=reviewer_id, due=due,
                        items=[existing.get(label, {'id': secrets.token_hex(8), 'label': label, 'done': False}) for label in labels],
                        status='draft')
        elif action == 'checklist':
            if not gate or not (owner or user.id == gate.get('owner_id')):
                abort(403)
            for item in gate['items']:
                doc_id = int(request.form.get('evidence_' + item['id']) or '0')
                done = request.form.get('done_' + item['id']) == '1'
                if doc_id and doc_id not in documents:
                    raise ValueError('Choose an available, non-sensitive document from this project.')
                if done and not doc_id:
                    raise ValueError('Each completed criterion needs linked evidence.')
                doc = documents.get(doc_id)
                item.update(done=done, document_id=doc_id or None,
                            stamp=evidence_stamp(doc) if doc else None,
                            evidence_name=doc.name if doc else None,
                            evidence_uploaded_at=str(doc.uploaded_at) if doc else None)
            gate['status'] = 'draft'
        elif action in ('submit', 'approve', 'changes', 'revoke'):
            if not gate:
                raise ValueError('Configure this stage first.')
            if action == 'submit':
                if not (owner or user.id == gate.get('owner_id')):
                    abort(403)
            elif not (can_signoff_sdlc(project, user, db_session) and (owner or user.id == gate.get('reviewer_id'))):
                abort(403)
            state = next(s for s in _sdlc_context(project)['states'] if s['phase'].id == phase.id)
            view = state['governance']
            if action in ('submit', 'approve'):
                if view['blockers'] and not (action == 'submit' and view.get('stale') and len(view['blockers']) == 1):
                    raise ValueError('Resolve these items first: ' + ' '.join(view['blockers']))
                if action == 'approve' and view['status'] != 'review':
                    raise ValueError('The stage must be submitted for review before approval.')
                gate['fingerprint'] = view['fingerprint_now']
                gate['status'] = 'review' if action == 'submit' else 'approved'
            else:
                if not note:
                    raise ValueError('Provide a reason for requesting changes or revoking approval.')
                gate['status'] = 'changes'
        else:
            abort(400)
        gate['last_note'] = note
        gate['updated_by'] = user.id
        gate['updated_at'] = datetime.now().isoformat(timespec='seconds')
        values = {ProjectSDLCPhase.governance: json.dumps(gate, ensure_ascii=True),
                  ProjectSDLCPhase.governance_revision: revision + 1,
                  ProjectSDLCPhase.signed_off_by: user.id if gate['status'] == 'approved' else None,
                  ProjectSDLCPhase.signed_off_at: datetime.now() if gate['status'] == 'approved' else None,
                  ProjectSDLCPhase.signoff_note: note if gate['status'] == 'approved' else None}
        changed = db_session.query(ProjectSDLCPhase).filter(
            ProjectSDLCPhase.id == phase_id, ProjectSDLCPhase.project_id == id,
            func.coalesce(ProjectSDLCPhase.governance_revision, 0) == revision).update(values, synchronize_session=False)
        if changed != 1:
            raise ValueError('This stage changed in another session. Reload before saving.')
        _log_activity(db_session, id, user, 'SDLC ' + action,
                      f"Stage '{phase.name}', revision {revision + 1}: " + json.dumps(gate, ensure_ascii=True))
        db_session.commit()
        flash('Stage updated. ' + {'configure': 'Ownership and exit criteria saved.', 'checklist': 'Evidence saved; submit for review when ready.', 'submit': 'Awaiting reviewer decision.', 'approve': 'Gate approved.', 'changes': 'Changes requested.', 'revoke': 'Approval revoked.'}[action], 'success')
    except (ValueError, TypeError) as exc:
        db_session.rollback()
        flash(str(exc), 'error')
    finally:
        db_session.close()
    return redirect(target)
