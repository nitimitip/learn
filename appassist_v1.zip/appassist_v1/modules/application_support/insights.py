"""
insights.py - architecture analytics over the estate graph.

The Architecture View and the Enterprise Architect view both draw the SAME
estate (architecture.build_estate_graph); they only differ in how they group
it - by delivery tower, or by business area. Everything an architect wants to
READ off those diagrams differs in exactly the same way, so it is computed
once here and parameterised by the grouping rather than written twice:

    build_insights(graph, 'tower')   -> the Architecture View's reading
    build_insights(graph, 'domain')  -> the Enterprise Architect's reading

Nothing in this module touches the database. It takes the graph document the
views already fetch and returns a JSON-serialisable analytics pack, which
means the same numbers appear on screen, in the CSV a reader copies out, and
in the PDF that leaves the building - and that they can be tested without a
session.

WHAT IS ACTUALLY COMPUTED

  matrix       A DIRECTIONAL group-to-group integration matrix. The screen
               used to show a symmetric "how many interfaces run between
               these two" count, which cannot answer the question an
               architect actually asks - who serves whom. Rows are sources,
               columns are targets, the diagonal is traffic that stays
               inside the group (its cohesion), and the margins are the
               fan-out / fan-in of each group.
  coupling     Per group: cohesion, fan-in, fan-out, how many peers it
               touches, an autonomy index, and the role that implies
               (Hub / Provider / Consumer / Balanced / Isolated, or
               No applications for a group that holds nothing).
  hubs         Applications ranked by how much of the estate's traffic runs
               through them - concentration risk, named.
  continuity   Business-continuity exposure: criticality inversion (a BC1
               application fed by something less critical than itself),
               BC1 applications with thin or missing support cover, and BC1
               applications depending on third parties.
  protocols    The integration-style mix, with the styles that carry a
               modernisation argument (file drops, direct database links,
               email) separated out.
  externals    Third-party exposure ranked by reach, flagging any external
               system that more than one group depends on.
  technology   Standardisation: what the estate runs on, and which
               technologies exactly one application uses.
  ownership    The cross-tab of the two groupings - a business area split
               across many towers (or a tower spanning many business areas)
               is a real organisational finding, not a drawing artefact.
  coverage     How much of the map is evidence-backed rather than guessed,
               and where the record is thin.
  findings     The above, read as a severity-ranked list of statements with
               a recommendation attached. This is the part that goes at the
               front of the PDF: the numbers are the evidence, the findings
               are the argument.

Deliberately pure, deliberately boring: every function takes data and returns
data, so a wrong number is a failing test rather than a screenshot argument.
"""

from datetime import datetime, timezone


# ---------------------------------------------------------------------------
# Groupings
#
# The two readings of the estate. Everything below is written against this
# table rather than against "tower" or "category", so a third grouping (by
# vendor, by location) would be a row here and no new analytics.
# ---------------------------------------------------------------------------

GROUPING_TOWER = 'tower'
GROUPING_DOMAIN = 'domain'

GROUPINGS = {
    GROUPING_TOWER: {
        'key': 'tower_id',
        'source': 'towers',
        'label': 'Support tower',
        'plural': 'Support towers',
        'view': 'Architecture View',
        'noun': 'tower',
        'counterpart': GROUPING_DOMAIN,
        # Towers name a lead; business domains do not. Analytics that would
        # report "no lead recorded" have to know the difference, or they
        # report every domain in the estate for a field the domain has no
        # room to hold.
        'has_lead': True,
    },
    GROUPING_DOMAIN: {
        'key': 'category_id',
        'source': 'categories',
        'label': 'Business domain',
        'plural': 'Business domains',
        'view': 'Enterprise Architect',
        'noun': 'domain',
        'counterpart': GROUPING_TOWER,
        'has_lead': False,
    },
}


# ---------------------------------------------------------------------------
# Integration styles
#
# `connectivity_type` is free text on the application record - "SFTP",
# "REST API over HTTPS", "Oracle DB link", "Control-M batch". It is the only
# statement the estate makes about HOW two systems are joined, so it is worth
# reading, but it has to be read defensively: match on keywords, first family
# wins, and anything unrecognised stays "Other" rather than being forced into
# a bucket it does not belong in.
#
# The order matters and is the order an architect would read a label in:
# "API to Oracle" is an API, not a database link.
# ---------------------------------------------------------------------------

PROTOCOL_FAMILIES = (
    ('API / web service',
     ('api', 'rest', 'soap', 'http', 'https', 'webservice', 'web service',
      'graphql', 'odata', 'wcf', 'rpc', 'json')),
    ('Messaging / queue',
     ('mq', 'kafka', 'jms', 'queue', 'topic', 'rabbit', 'solace', 'pubsub',
      'pub/sub', 'mqtt', 'service bus', 'event hub', 'streaming')),
    ('Database link',
     ('db link', 'dblink', 'db-link', 'database', 'jdbc', 'odbc', 'oracle',
      'sql', 'linked server', 'replication', 'golden gate', 'goldengate')),
    ('File transfer',
     ('sftp', 'ftps', 'ftp', 'scp', 'file', 'csv', 'flat', 'share', 'nfs',
      'smb', 'cifs', 'folder', 'edi', 'drop')),
    ('Email',
     ('email', 'smtp', 'mail', 'outlook', 'exchange')),
    ('Batch / scheduled job',
     ('batch', 'job', 'etl', 'informatica', 'ssis', 'scheduler', 'control-m',
      'controlm', 'autosys', 'cron')),
)

#: Integration styles that carry a modernisation argument. Nothing here is
#: "wrong" - a nightly file drop can be the right answer - but each one
#: couples two systems in a way that is brittle, unobservable or both, so an
#: estate that leans on them is worth a conversation.
MODERNISATION_STYLES = ('File transfer', 'Database link', 'Email')

PROTOCOL_OTHER = 'Other / unspecified'

#: Roles a group's traffic profile puts it in. Read off fan-in vs fan-out
#: once a group has any cross-group traffic at all.
ROLE_EMPTY = 'No applications'
ROLE_ISOLATED = 'Isolated'
ROLE_PROVIDER = 'Provider'
ROLE_CONSUMER = 'Consumer'
ROLE_HUB = 'Hub'
ROLE_BALANCED = 'Balanced'

#: A group is a Hub when it touches at least this many peers AND carries at
#: least this share of all cross-group traffic. Both, because "talks to
#: everyone a little" and "carries everything to one peer" are different
#: shapes and only the first is a hub.
HUB_PEER_FLOOR = 3
HUB_SHARE_FLOOR = 0.25

#: Fan-in / fan-out ratio past which a group reads as a net Provider or a net
#: Consumer rather than as balanced.
DIRECTION_SKEW = 2.0

#: An application carrying at least this share of every cross-group link is
#: reported as a concentration risk in its own right.
CONCENTRATION_SHARE = 0.20

#: Share of interfaces in the brittle styles past which the estate is said to
#: lean on point-to-point coupling, and share of blank connectivity types past
#: which the record itself is the finding.
LEGACY_ALERT_PCT = 25.0
UNSPECIFIED_ALERT_PCT = 20.0

#: Share of applications missing a field past which the gap is a finding
#: rather than a rounding error.
GAP_ALERT_PCT = 25.0

#: Share of links resolved by NAME rather than by hostname past which the
#: diagram is reporting inference at a level worth stating out loud.
INFERENCE_ALERT_PCT = 30.0

#: Severities, most serious first. Used to sort findings and to colour them.
SEV_HIGH = 'high'
SEV_MEDIUM = 'medium'
SEV_LOW = 'low'
SEV_ORDER = {SEV_HIGH: 0, SEV_MEDIUM: 1, SEV_LOW: 2}


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

def _pct(part, whole):
    """Percentage, rounded to one place; 0.0 rather than a divide-by-zero."""
    if not whole:
        return 0.0
    return round(100.0 * float(part) / float(whole), 1)


def _norm(text):
    return ' '.join(str(text or '').lower().split())


def classify_protocol(connectivity):
    """The integration style a free-text connectivity label describes.

    First matching family wins (see PROTOCOL_FAMILIES); an empty or
    unrecognised label is Other rather than a guess.
    """
    label = _norm(connectivity)
    if not label:
        return PROTOCOL_OTHER
    for family, keywords in PROTOCOL_FAMILIES:
        for word in keywords:
            if word in label:
                return family
    return PROTOCOL_OTHER


# ---------------------------------------------------------------------------
# Grouping the estate
# ---------------------------------------------------------------------------

def group_index(graph, grouping):
    """(groups, group_of_app) for one reading of the estate.

    `groups` are taken from the graph's own grouping payload - `towers` or
    `categories` - so this never re-derives a membership the graph has
    already decided. An application the grouping payload does not mention
    (a graph built before the grouping existed) is left unassigned rather
    than invented into a group.

    Returns:
      groups       : [{id, name, app_ids, lead, description, uncategorised}]
      group_of_app : {app_id: group_id}
    """
    meta = GROUPINGS[grouping]
    groups = []
    group_of_app = {}
    for entry in graph.get(meta['source']) or []:
        gid = entry.get('id')
        app_ids = list(entry.get('app_ids') or [])
        groups.append({
            'id': gid,
            'name': (entry.get('name') or '').strip() or 'Group {0}'.format(gid),
            'app_ids': app_ids,
            'lead': entry.get('lead', ''),
            'description': entry.get('description', ''),
            'uncategorised': bool(entry.get('uncategorised')),
        })
        for app_id in app_ids:
            group_of_app[app_id] = gid
    return groups, group_of_app


def _directed_pairs(links):
    """Each link as one or two (src_app, dst_app, link) flows.

    A bi-directional interface is one edge in the graph - collapsing the two
    opposed records is what stops the diagram drawing a line twice - but it
    is genuinely traffic in both directions, so for a directional matrix it
    counts once each way.
    """
    for link in links:
        yield link['src_app'], link['dst_app'], link
        if link.get('bidir'):
            yield link['dst_app'], link['src_app'], link


# ---------------------------------------------------------------------------
# The integration matrix
# ---------------------------------------------------------------------------

def build_matrix(graph, grouping):
    """The directional group-to-group integration matrix.

    Rows are sources and columns are targets, so cell (i, j) reads "j is fed
    by i". The DIAGONAL is not blanked out: traffic that stays inside a group
    is that group's cohesion, and an architect comparing a domain that talks
    mostly to itself with one that talks mostly outward is comparing exactly
    those two numbers.

    Only groups that actually hold applications appear - an empty business
    area is a real finding, but it is reported by the coupling table, not by
    a row and column of zeroes that make the matrix harder to read.

    Returns:
      groups   : [{id, name, apps}] in display order (rows and columns alike)
      cells    : [[{count, app_pairs, styles}]] indexed [row][col]
      rows     : per-group margins {id, name, apps, out, inb, intra, total,
                 peers}
      pairs    : the populated off-diagonal cells, flattened and ranked
      totals   : {cross, intra, max_cell, pairs}
    """
    all_groups, group_of_app = group_index(graph, grouping)
    groups = [g for g in all_groups if g['app_ids']]
    order = [g['id'] for g in groups]
    pos = dict((gid, i) for i, gid in enumerate(order))
    n = len(order)

    cells = [[{'count': 0, 'app_pairs': set(), 'styles': {}}
              for _ in range(n)] for _ in range(n)]

    for src, dst, link in _directed_pairs(graph.get('links') or []):
        gs, gd = group_of_app.get(src), group_of_app.get(dst)
        if gs is None or gd is None or gs not in pos or gd not in pos:
            continue
        cell = cells[pos[gs]][pos[gd]]
        cell['count'] += 1
        cell['app_pairs'].add((src, dst))
        style = classify_protocol(link.get('connectivity'))
        cell['styles'][style] = cell['styles'].get(style, 0) + 1

    max_cell = 0
    cross_total = 0
    intra_total = 0
    for i in range(n):
        for j in range(n):
            cell = cells[i][j]
            cell['app_pairs'] = len(cell['app_pairs'])
            cell['styles'] = sorted(cell['styles'].items(),
                                    key=lambda kv: (-kv[1], kv[0]))
            if i == j:
                intra_total += cell['count']
            else:
                cross_total += cell['count']
                if cell['count'] > max_cell:
                    max_cell = cell['count']

    rows = []
    for i, group in enumerate(groups):
        out = sum(cells[i][j]['count'] for j in range(n) if j != i)
        inb = sum(cells[j][i]['count'] for j in range(n) if j != i)
        peers = 0
        for j in range(n):
            if j != i and (cells[i][j]['count'] or cells[j][i]['count']):
                peers += 1
        rows.append({
            'id': group['id'], 'name': group['name'],
            'apps': len(group['app_ids']),
            'out': out, 'inb': inb, 'intra': cells[i][i]['count'],
            'total': out + inb, 'peers': peers,
        })

    pairs = []
    for i in range(n):
        for j in range(n):
            if i == j or not cells[i][j]['count']:
                continue
            pairs.append({
                'src_id': groups[i]['id'], 'src': groups[i]['name'],
                'dst_id': groups[j]['id'], 'dst': groups[j]['name'],
                'count': cells[i][j]['count'],
                'app_pairs': cells[i][j]['app_pairs'],
                'styles': cells[i][j]['styles'],
            })
    pairs.sort(key=lambda p: (-p['count'], p['src'].lower(), p['dst'].lower()))

    return {
        'groups': [{'id': g['id'], 'name': g['name'],
                    'apps': len(g['app_ids'])} for g in groups],
        'cells': cells,
        'rows': rows,
        'pairs': pairs,
        'totals': {'cross': cross_total, 'intra': intra_total,
                   'max_cell': max_cell, 'pairs': len(pairs)},
    }


# ---------------------------------------------------------------------------
# Coupling and autonomy
# ---------------------------------------------------------------------------

def _role(row, cross_total, apps=1):
    """The role a group's traffic profile puts it in (see the ROLE_* notes).

    A group holding nothing is not "isolated" - it is empty, which is a
    different finding and reads as one.
    """
    if not apps:
        return ROLE_EMPTY
    if not row['total']:
        return ROLE_ISOLATED
    share = (float(row['total']) / float(cross_total)) if cross_total else 0.0
    if row['peers'] >= HUB_PEER_FLOOR and share >= HUB_SHARE_FLOOR:
        return ROLE_HUB
    if row['out'] > row['inb'] * DIRECTION_SKEW:
        return ROLE_PROVIDER
    if row['inb'] > row['out'] * DIRECTION_SKEW:
        return ROLE_CONSUMER
    return ROLE_BALANCED


def build_coupling(graph, grouping, matrix):
    """Per-group coupling, autonomy and role.

    Autonomy is intra / (intra + cross): the share of a group's interfaces
    that never leave it. A group at 100% is self-contained and can be changed
    on its own schedule; a group near 0% cannot be touched without a
    conversation with everyone else, whatever the org chart says. A group
    with no interfaces at all has no autonomy figure rather than a
    flattering 0 or 100.

    `share` is the group's END of the estate's cross-group traffic. Every
    such interface has two ends, so these do not sum to 100 and are not meant
    to: the question being answered is "how much of what crosses a boundary
    touches this group", not "whose interface is it", which would be
    apportionment nobody asked for.

    Counted alongside it, because they are the questions asked next: how many
    of the group's applications are business critical, how many third-party
    systems it touches, and how many of the OTHER grouping's units its
    applications are spread across.
    """
    meta = GROUPINGS[grouping]
    other = GROUPINGS[meta['counterpart']]
    all_groups, group_of_app = group_index(graph, grouping)
    apps_by_id = dict((a['id'], a) for a in graph.get('apps') or [])
    margins = dict((r['id'], r) for r in matrix['rows'])
    cross_total = matrix['totals']['cross']

    # Third-party reach, per group.
    ext_by_group = {}
    for ext in graph.get('externals') or []:
        for edge in ext.get('links') or []:
            gid = group_of_app.get(edge.get('app'))
            if gid is None:
                continue
            ext_by_group.setdefault(gid, set()).add(
                ext.get('key') or ext.get('name'))

    rows = []
    for group in all_groups:
        margin = margins.get(group['id'], {'out': 0, 'inb': 0, 'intra': 0,
                                           'total': 0, 'peers': 0})
        bc_mix = {'BC1': 0, 'BC2': 0, 'BC3': 0}
        spread = set()
        for app_id in group['app_ids']:
            app = apps_by_id.get(app_id)
            if not app:
                continue
            if app.get('bc') in bc_mix:
                bc_mix[app['bc']] += 1
            counterpart = app.get(other['key'])
            if counterpart is not None:
                spread.add(counterpart)
        interfaces = margin['intra'] + margin['total']
        rows.append({
            'id': group['id'],
            'name': group['name'],
            'lead': group.get('lead', ''),
            'apps': len(group['app_ids']),
            'bc_mix': bc_mix,
            'intra': margin['intra'],
            'out': margin['out'],
            'inb': margin['inb'],
            'cross': margin['total'],
            'peers': margin['peers'],
            'externals': len(ext_by_group.get(group['id'], ())),
            'autonomy': _pct(margin['intra'], interfaces) if interfaces else None,
            'share': _pct(margin['total'], cross_total),
            'role': _role(margin, cross_total, len(group['app_ids'])),
            'spread': len(spread),
        })
    rows.sort(key=lambda r: (-r['cross'], -r['apps'], r['name'].lower()))
    return {
        'label': meta['label'],
        'counterpart_label': other['label'],
        'rows': rows,
    }


# ---------------------------------------------------------------------------
# Applications: hubs, orphans, degree
# ---------------------------------------------------------------------------

def build_app_degrees(graph, grouping):
    """Every application's connectivity profile, and the shapes worth naming.

    `degree` counts interfaces, not partners: two feeds to the same peer are
    two things that break. `cross` counts only the ones that leave the
    application's own group - the traffic that turns a local change into an
    estate-wide conversation, and therefore the number a hub is ranked on.
    """
    groups, group_of_app = group_index(graph, grouping)
    group_name = dict((g['id'], g['name']) for g in groups)

    profile = {}
    for app in graph.get('apps') or []:
        gid = group_of_app.get(app['id'])
        profile[app['id']] = {
            'id': app['id'], 'name': app.get('name') or '',
            'bc': app.get('bc') or '',
            'group_id': gid,
            'group': group_name.get(gid, ''),
            'inb': 0, 'out': 0, 'cross': 0, 'ext': 0, 'degree': 0,
            'peers': set(),
        }

    for src, dst, _link in _directed_pairs(graph.get('links') or []):
        gs, gd = group_of_app.get(src), group_of_app.get(dst)
        if src in profile:
            profile[src]['out'] += 1
            profile[src]['degree'] += 1
            profile[src]['peers'].add(dst)
            if gs != gd:
                profile[src]['cross'] += 1
        if dst in profile:
            profile[dst]['inb'] += 1
            profile[dst]['degree'] += 1
            profile[dst]['peers'].add(src)
            if gs != gd:
                profile[dst]['cross'] += 1

    for ext in graph.get('externals') or []:
        for edge in ext.get('links') or []:
            entry = profile.get(edge.get('app'))
            if entry is None:
                continue
            entry['ext'] += 1
            entry['degree'] += 1

    rows = []
    for entry in profile.values():
        entry['peers'] = len(entry['peers'])
        rows.append(entry)

    total_cross = sum(r['cross'] for r in rows)
    for row in rows:
        row['share'] = _pct(row['cross'], total_cross)

    isolated = sorted([r for r in rows if r['degree'] == 0],
                      key=lambda r: r['name'].lower())
    ranked = sorted(rows, key=lambda r: (-r['degree'], -r['cross'],
                                         r['name'].lower()))
    return {
        'rows': rows,
        'hubs': [r for r in ranked if r['degree'] > 0][:12],
        'isolated': isolated,
        'total_cross': total_cross,
    }


# ---------------------------------------------------------------------------
# Business-continuity exposure
# ---------------------------------------------------------------------------

BC_RANK = {'BC1': 1, 'BC2': 2, 'BC3': 3}


def build_continuity(graph, grouping, degrees):
    """Where the estate's criticality rating and its wiring disagree.

    Three readings, all of them about a BC1 application:

      inversions   A BC1 application FED BY something rated lower than
                   itself. The feed inherits the consumer's criticality
                   whatever the record says, so either the upstream rating is
                   wrong or the dependency is.
      third_party  A BC1 application fed by a system outside the estate -
                   a dependency nobody in the estate can be paged for.
      thin_cover   A BC1 application with no named support contact, or only
                   one. One name is a person, not a rota.
    """
    apps_by_id = dict((a['id'], a) for a in graph.get('apps') or [])
    groups, group_of_app = group_index(graph, grouping)
    group_name = dict((g['id'], g['name']) for g in groups)

    def _where(app_id):
        return group_name.get(group_of_app.get(app_id), '')

    inversions = []
    for src, dst, link in _directed_pairs(graph.get('links') or []):
        consumer, producer = apps_by_id.get(dst), apps_by_id.get(src)
        if not consumer or not producer:
            continue
        c_rank = BC_RANK.get(consumer.get('bc'))
        p_rank = BC_RANK.get(producer.get('bc'))
        if c_rank is None or p_rank is None or p_rank <= c_rank:
            continue
        inversions.append({
            'app_id': consumer['id'], 'app': consumer.get('name') or '',
            'bc': consumer.get('bc'), 'group': _where(consumer['id']),
            'source_id': producer['id'], 'source': producer.get('name') or '',
            'source_bc': producer.get('bc'),
            'source_group': _where(producer['id']),
            'connectivity': link.get('connectivity') or '',
            'style': classify_protocol(link.get('connectivity')),
        })
    inversions.sort(key=lambda r: (BC_RANK.get(r['bc'], 9),
                                   -BC_RANK.get(r['source_bc'], 0),
                                   r['app'].lower()))

    third_party = []
    for ext in graph.get('externals') or []:
        for edge in ext.get('links') or []:
            app = apps_by_id.get(edge.get('app'))
            if not app or app.get('bc') != 'BC1':
                continue
            if edge.get('direction') == 'Outbound':
                continue        # we feed them; they do not hold us up
            third_party.append({
                'app_id': app['id'], 'app': app.get('name') or '',
                'group': _where(app['id']),
                'system': ext.get('name') or '',
                'connectivity': edge.get('connectivity') or '',
                'style': classify_protocol(edge.get('connectivity')),
                'direction': edge.get('direction') or '',
            })
    third_party.sort(key=lambda r: (r['app'].lower(), r['system'].lower()))

    thin_cover = []
    for app in graph.get('apps') or []:
        if app.get('bc') != 'BC1':
            continue
        named = [m for m in (app.get('support') or [])
                 if (m.get('name') or '').strip()]
        if len(named) > 1:
            continue
        thin_cover.append({
            'app_id': app['id'], 'app': app.get('name') or '',
            'group': _where(app['id']),
            'contacts': len(named),
            'contact': (named[0].get('name') if named else ''),
        })
    thin_cover.sort(key=lambda r: (r['contacts'], r['app'].lower()))

    by_app = dict((r['id'], r) for r in degrees['rows'])
    bc1_exposed = []
    for app in graph.get('apps') or []:
        if app.get('bc') != 'BC1':
            continue
        entry = by_app.get(app['id'])
        if not entry or not entry['degree']:
            continue
        bc1_exposed.append({
            'app_id': app['id'], 'app': app.get('name') or '',
            'group': _where(app['id']),
            'degree': entry['degree'], 'cross': entry['cross'],
            'ext': entry['ext'],
        })
    bc1_exposed.sort(key=lambda r: (-r['degree'], r['app'].lower()))

    return {
        'inversions': inversions,
        'third_party': third_party,
        'thin_cover': thin_cover,
        'bc1_exposed': bc1_exposed[:12],
    }


# ---------------------------------------------------------------------------
# Integration styles
# ---------------------------------------------------------------------------

def build_protocols(graph, grouping):
    """The estate's integration-style mix.

    Counted over INTERFACES rather than over resolved links so an application
    that exposes the same data three ways counts three times: each one is a
    thing that has to keep working, whether or not it resolved to something
    inside the estate.
    """
    groups, group_of_app = group_index(graph, grouping)
    counts = {}
    by_group = {}
    total = 0
    for app in graph.get('apps') or []:
        gid = group_of_app.get(app['id'])
        for itf in app.get('interfaces') or []:
            style = classify_protocol(itf.get('connectivity'))
            counts[style] = counts.get(style, 0) + 1
            total += 1
            if gid is not None:
                bucket = by_group.setdefault(gid, {})
                bucket[style] = bucket.get(style, 0) + 1

    rows = []
    for style, count in counts.items():
        rows.append({
            'style': style, 'count': count, 'pct': _pct(count, total),
            'modernise': style in MODERNISATION_STYLES,
        })
    rows.sort(key=lambda r: (-r['count'], r['style']))

    legacy = sum(r['count'] for r in rows if r['modernise'])
    unspecified = counts.get(PROTOCOL_OTHER, 0)
    return {
        'rows': rows,
        'total': total,
        'legacy': legacy,
        'legacy_pct': _pct(legacy, total),
        'unspecified': unspecified,
        'unspecified_pct': _pct(unspecified, total),
        'by_group': by_group,
    }


# ---------------------------------------------------------------------------
# Third-party exposure
# ---------------------------------------------------------------------------

def build_externals(graph, grouping):
    """Third-party systems ranked by reach across the estate.

    An external system touching one application is a supplier. One touching
    applications in three different groups is an enterprise dependency that
    no single group owns, which is a different conversation and a different
    contract.
    """
    groups, group_of_app = group_index(graph, grouping)
    group_name = dict((g['id'], g['name']) for g in groups)
    apps_by_id = dict((a['id'], a) for a in graph.get('apps') or [])

    rows = []
    for ext in graph.get('externals') or []:
        touched = set()
        styles = {}
        bc1 = 0
        app_names = []
        for edge in ext.get('links') or []:
            app = apps_by_id.get(edge.get('app'))
            if not app:
                continue
            app_names.append(app.get('name') or '')
            gid = group_of_app.get(app['id'])
            if gid is not None:
                touched.add(gid)
            if app.get('bc') == 'BC1':
                bc1 += 1
            style = classify_protocol(edge.get('connectivity'))
            styles[style] = styles.get(style, 0) + 1
        rows.append({
            'name': ext.get('name') or '',
            'apps': len(app_names),
            'app_names': sorted(set(app_names), key=lambda s: s.lower()),
            'groups': len(touched),
            'group_names': sorted((group_name.get(g, '') for g in touched),
                                  key=lambda s: s.lower()),
            'bc1': bc1,
            'styles': sorted(styles.items(), key=lambda kv: (-kv[1], kv[0])),
        })
    rows.sort(key=lambda r: (-r['groups'], -r['apps'], r['name'].lower()))
    shared = [r for r in rows if r['groups'] > 1]
    return {'rows': rows, 'shared': shared, 'count': len(rows)}


# ---------------------------------------------------------------------------
# Technology standardisation
# ---------------------------------------------------------------------------

TECH_LABELS = {
    'language': 'Languages and frameworks',
    'database': 'Databases',
    'os': 'Operating systems',
    'tool': 'Tools and middleware',
}

#: The order an architect reads a stack in, mirrored from architecture.py.
TECH_ORDER = ('language', 'database', 'os', 'tool')


def build_technology(graph, grouping):
    """What the estate runs on, and where it runs on one of a kind.

    A technology used by exactly ONE application is not automatically wrong -
    somebody had a reason - but it is the estate carrying a skill, a licence
    and a patching obligation for a single system, and it is the cheapest
    rationalisation question there is. Counted per category so "one database
    nobody else uses" does not hide behind forty libraries.
    """
    groups, group_of_app = group_index(graph, grouping)
    group_name = dict((g['id'], g['name']) for g in groups)

    usage = {}
    documented = 0
    for app in graph.get('apps') or []:
        stack = app.get('tech') or []
        if stack:
            documented += 1
        for item in stack:
            key = ((item.get('category') or '').strip().lower(),
                   (item.get('name') or '').strip())
            if not key[1]:
                continue
            entry = usage.setdefault(key, {'category': key[0], 'name': key[1],
                                           'apps': [], 'groups': set()})
            entry['apps'].append({'id': app['id'],
                                  'name': app.get('name') or ''})
            gid = group_of_app.get(app['id'])
            if gid is not None:
                entry['groups'].add(gid)

    categories = {}
    singletons = []
    for entry in usage.values():
        entry['groups'] = sorted(
            (group_name.get(g, '') for g in entry['groups']),
            key=lambda s: s.lower())
        entry['count'] = len(entry['apps'])
        categories.setdefault(entry['category'], []).append(entry)
        if entry['count'] == 1:
            singletons.append(entry)

    def _bucket(category, items):
        items.sort(key=lambda e: (-e['count'], e['name'].lower()))
        return {
            'category': category,
            'label': TECH_LABELS.get(category, (category or 'Other').title()),
            'distinct': len(items),
            'singletons': len([e for e in items if e['count'] == 1]),
            'top': items[:8],
        }

    summary = [_bucket(c, categories[c]) for c in TECH_ORDER if categories.get(c)]
    # Anything recorded under a category this view does not name still counts.
    summary += [_bucket(c, categories[c]) for c in sorted(categories)
                if c not in TECH_ORDER]

    singletons.sort(key=lambda e: (e['category'], e['name'].lower()))
    total_apps = len(graph.get('apps') or [])
    return {
        'summary': summary,
        'singletons': singletons,
        'documented': documented,
        'documented_pct': _pct(documented, total_apps),
        'undocumented': total_apps - documented,
    }


# ---------------------------------------------------------------------------
# Ownership alignment - the cross-tab of the two groupings
# ---------------------------------------------------------------------------

def build_ownership(graph, grouping):
    """How the two readings of the estate line up against each other.

    A business area whose applications sit in five different towers has five
    escalation paths for one business conversation; a tower spanning eight
    business areas has eight sets of stakeholders for one change window.
    Neither is wrong, both are worth knowing, and neither is visible on
    either diagram on its own - which is exactly why it is computed here.
    """
    meta = GROUPINGS[grouping]
    other = GROUPINGS[meta['counterpart']]
    groups, _group_of_app = group_index(graph, grouping)
    others, other_of_app = group_index(graph, meta['counterpart'])
    other_name = dict((g['id'], g['name']) for g in others)

    rows = []
    for group in groups:
        if not group['app_ids']:
            continue
        spread = {}
        for app_id in group['app_ids']:
            oid = other_of_app.get(app_id)
            if oid is None:
                continue
            spread[oid] = spread.get(oid, 0) + 1
        parts = sorted(
            ({'id': oid, 'name': other_name.get(oid, ''), 'apps': count}
             for oid, count in spread.items()),
            key=lambda p: (-p['apps'], p['name'].lower()))
        rows.append({
            'id': group['id'], 'name': group['name'],
            'apps': len(group['app_ids']),
            'spread': len(parts),
            'parts': parts,
            'concentration': (_pct(parts[0]['apps'], len(group['app_ids']))
                              if parts else 0.0),
        })
    rows.sort(key=lambda r: (-r['spread'], -r['apps'], r['name'].lower()))
    return {
        'label': meta['label'],
        'counterpart_label': other['label'],
        'rows': rows,
        'fragmented': [r for r in rows if r['spread'] > 1],
    }


# ---------------------------------------------------------------------------
# Coverage - how much of this map is evidence, and how much is inference
# ---------------------------------------------------------------------------

def build_coverage(graph, grouping):
    """How far the diagram can be trusted, stated rather than implied.

    Every connection on both views is either backed by a HOSTNAME recorded on
    both sides - evidence - or inferred because two names happened to match.
    The second kind is usually right and occasionally embarrassing, so the
    ratio is reported rather than buried, next to the record gaps that
    produce it.
    """
    links = graph.get('links') or []
    by_host = len([l for l in links if l.get('match') == 'host'])
    by_name = len(links) - by_host

    apps = graph.get('apps') or []
    total = len(apps)
    _groups, group_of_app = group_index(graph, grouping)
    meta = GROUPINGS[grouping]

    gaps = []

    def _gap(label, predicate, why):
        rows = [a for a in apps if predicate(a)]
        gaps.append({
            'label': label, 'count': len(rows), 'pct': _pct(len(rows), total),
            'why': why,
            'apps': sorted((a.get('name') or '' for a in rows),
                           key=lambda s: s.lower())[:40],
        })

    _gap('No business area recorded',
         lambda a: not a.get('category_id'),
         'lands in Uncategorised on the Enterprise Architect view')
    _gap('No summary',
         lambda a: not (a.get('summary') or '').strip(),
         'the application record cannot say what the system is for')
    _gap('No infrastructure listed',
         lambda a: not (a.get('servers') or []),
         'there is no hostname for other applications interfaces to resolve '
         'against')
    _gap('No interfaces listed',
         lambda a: not (a.get('interfaces') or []),
         'it appears unconnected, which is rarely true')
    _gap('No support contact',
         lambda a: not [m for m in (a.get('support') or [])
                        if (m.get('name') or '').strip()],
         'there is nobody named to page')
    _gap('No technology recorded',
         lambda a: not (a.get('tech') or []),
         'it is invisible to any technology or lifecycle question')

    return {
        'links': len(links),
        'by_host': by_host,
        'by_host_pct': _pct(by_host, len(links)),
        'by_name': by_name,
        'by_name_pct': _pct(by_name, len(links)),
        'duplicate_hosts': len(graph.get('warnings') or []),
        'unassigned': len([a for a in apps
                           if group_of_app.get(a['id']) is None]),
        'grouping_label': meta['label'],
        'apps': total,
        'gaps': gaps,
    }


# ---------------------------------------------------------------------------
# The executive layer
#
# Everything above this line MEASURES the estate. Everything below it READS
# those measurements the way a business architect has to present them: as a
# graded position on a small number of things the business actually cares
# about, a plain-English account of what that position is, and an agenda of
# work with an owner and a horizon against each item.
#
# The split is deliberate. The measurements are facts and must not move; the
# reading is a judgement and is allowed to be argued with. Building the
# second entirely out of the first means the argument is always about the
# weighting and never about whether the number is real - every deduction
# below records the driver that caused it, so a grade can be taken apart in
# front of a steering group without anyone opening the database.
# ---------------------------------------------------------------------------

#: The seven things a business architect is actually asked about. These are
#: the headings of the scorecard, the themes the action agenda groups by, and
#: the vocabulary the narrative is written in - one set of words used
#: everywhere, so the report never renames its own subject twice a page.
DIM_RESILIENCE = 'Service resilience'
DIM_AGILITY = 'Change agility'
DIM_SUPPLIER = 'Supplier dependency'
DIM_OWNERSHIP = 'Ownership and accountability'
DIM_INTEGRATION = 'Integration modernisation'
DIM_TECHNOLOGY = 'Technology portfolio'
DIM_INFORMATION = 'Information quality'

#: Weight each dimension carries in the composite index, and the business
#: question it exists to answer. Resilience is weighted highest because it is
#: the only one here whose failure mode is measured in lost service rather
#: than in lost time. Information quality is weighted lowest because it is a
#: statement about the RECORD rather than about the estate - it still
#: appears, because a report that hides how much of itself is inferred is not
#: worth putting in front of anyone.
DIMENSIONS = (
    (DIM_RESILIENCE, 25,
     'If a critical business service failed tonight, could we restore it?'),
    (DIM_AGILITY, 15,
     'Can one part of the business change without moving the rest?'),
    (DIM_SUPPLIER, 15,
     'How much of the business runs on somebody else\'s system?'),
    (DIM_OWNERSHIP, 15,
     'Is there one accountable owner behind each business capability?'),
    (DIM_INTEGRATION, 15,
     'Are our systems joined together in a way we can safely change?'),
    (DIM_TECHNOLOGY, 10,
     'Do we know what we run on, and is it worth what it costs to keep?'),
    (DIM_INFORMATION, 5,
     'How much of this picture is evidence rather than inference?'),
)

#: Grade bands, best-first, read top-down. The labels are the words that go
#: in front of an executive audience; the letters are what fits in the cell
#: next to them.
GRADE_BANDS = (
    (85, 'A', 'Strong', 'no material exposure found in this area'),
    (70, 'B', 'Sound', 'working as intended, with known gaps'),
    (55, 'C', 'Watch', 'holding, but the trend matters'),
    (40, 'D', 'Exposed', 'a live weakness with a business consequence'),
    (0, 'E', 'Critical', 'needs a named owner and a date now'),
)

#: A dimension nothing in the estate can speak to. Reported as such rather
#: than scored 100 (which would flatter) or 0 (which would libel), and left
#: out of the composite index entirely.
GRADE_UNRATED = 'n/a'
BAND_UNRATED = 'Not rated'

#: How soon the estate is hurt by leaving a finding alone. Derived from
#: severity rather than set per finding, so the two can never disagree.
HORIZON_BY_SEVERITY = {SEV_HIGH: 'Now', SEV_MEDIUM: 'Next', SEV_LOW: 'Later'}
HORIZON_ORDER = {'Now': 0, 'Next': 1, 'Later': 2}

#: Which of the seven themes each finding area belongs to. The areas are the
#: analyst's filing; the themes are the audience's.
AREA_THEMES = {
    'Business continuity': DIM_RESILIENCE,
    'Concentration risk': DIM_AGILITY,
    'Integration shape': DIM_AGILITY,
    'Integration style': DIM_INTEGRATION,
    'Third-party exposure': DIM_SUPPLIER,
    'Ownership alignment': DIM_OWNERSHIP,
    'Landscape coverage': DIM_OWNERSHIP,
    'Map confidence': DIM_INFORMATION,
    'Record completeness': DIM_INFORMATION,
    'Technology standardisation': DIM_TECHNOLOGY,
}

#: The role that can actually close an item in each theme. Named as a role
#: and never as a person: an agenda that names individuals goes stale the
#: first time somebody moves desk.
THEME_OWNERS = {
    DIM_RESILIENCE: 'Service owner / continuity lead',
    DIM_AGILITY: 'Enterprise architect',
    DIM_SUPPLIER: 'Vendor management',
    DIM_OWNERSHIP: 'Business domain owner',
    DIM_INTEGRATION: 'Integration architect',
    DIM_TECHNOLOGY: 'Technology strategy',
    DIM_INFORMATION: 'Application owner',
}

#: How self-contained a group is, in words. Read off the same autonomy figure
#: the coupling table prints, so the card and the table cannot disagree.
POSTURE_CONTAINED = 'Self-contained'
POSTURE_INTERLINKED = 'Interlinked'
POSTURE_DEPENDENT = 'Highly coupled'
POSTURE_SILENT = 'No integration recorded'
AUTONOMY_CONTAINED = 70.0
AUTONOMY_DEPENDENT = 30.0

#: Risk rating on a group profile card.
RISK_LOW = 'Low'
RISK_MODERATE = 'Moderate'
RISK_HIGH = 'High'


def _band(score):
    """(grade, band, gloss) for a 0-100 score, or the unrated triple."""
    if score is None:
        return GRADE_UNRATED, BAND_UNRATED, 'nothing in the estate records this'
    for floor, grade, band, gloss in GRADE_BANDS:
        if score >= floor:
            return grade, band, gloss
    last = GRADE_BANDS[-1]
    return last[1], last[2], last[3]


def _cap(value, ceiling):
    """A penalty: never negative, never past the ceiling set for it."""
    return max(0.0, min(float(ceiling), float(value)))


def _count_bc1(graph):
    return len([a for a in (graph.get('apps') or []) if a.get('bc') == 'BC1'])


class _Dimension(object):
    """One scorecard dimension, built by subtraction with the reasons kept.

    Starts at 100 and comes down. Every deduction has to name itself, which
    is the entire point: the panel prints the drivers beside the grade, so
    "why is resilience a D" is answered on the page rather than in a meeting.
    A dimension the estate holds no evidence for is marked unrated rather
    than scored, and drops out of the composite index.
    """

    def __init__(self, name):
        self.name = name
        self.value = 100.0
        self.drivers = []
        self.rated = True

    def deduct(self, label, measure, penalty, ceiling, note):
        penalty = _cap(penalty, ceiling)
        if penalty <= 0:
            return
        self.value -= penalty
        self.drivers.append({'label': label, 'measure': measure,
                             'impact': round(penalty, 1), 'note': note})

    def credit(self, label, measure, note):
        """A driver that costs nothing - what is going right, said out loud."""
        self.drivers.append({'label': label, 'measure': measure,
                             'impact': 0.0, 'note': note})

    def unrated(self, reason):
        self.rated = False
        self.drivers = [{'label': 'Not rated', 'measure': '-', 'impact': 0.0,
                         'note': reason}]

    def finish(self, question, weight):
        score = int(round(_cap(self.value, 100))) if self.rated else None
        grade, band, gloss = _band(score)
        self.drivers.sort(key=lambda d: -d['impact'])
        worst = None
        for driver in self.drivers:
            if driver['impact'] > 0:
                worst = driver
                break
        if score is None:
            verdict = self.drivers[0]['note'] if self.drivers else gloss
        elif worst is None:
            verdict = 'Nothing in this area crossed a reporting threshold.'
        else:
            verdict = worst['note'].rstrip('.') + '.'
            if len([d for d in self.drivers if d['impact'] > 0]) > 1:
                verdict += ' It is the largest single drag on this score.'
        return {'dimension': self.name, 'question': question, 'weight': weight,
                'score': score, 'grade': grade, 'band': band, 'gloss': gloss,
                'verdict': verdict, 'drivers': self.drivers}


# ---------------------------------------------------------------------------
# The scorecard
#
# Seven dimensions, each scored by subtraction from 100 against the figures
# already computed above. The penalties are proportional wherever the
# underlying measure is a share, because "three of four business-critical
# systems have no rota" and "three of four hundred" are not the same
# sentence; they are capped wherever the underlying measure is a count, so
# one very bad number cannot silently swallow every other signal in the
# dimension.
#
# Every threshold and every ceiling is a judgement written down as a number
# in one place. That is the only defensible way to publish a grade.
# ---------------------------------------------------------------------------

def _score_resilience(graph, parts, noun):
    dim = _Dimension(DIM_RESILIENCE)
    continuity = parts['continuity']
    bc1 = _count_bc1(graph)
    if not bc1:
        dim.unrated('No application is rated BC1, so the estate makes no '
                    'statement about which services are business critical. '
                    'Rate the critical applications and this becomes '
                    'measurable.')
        return dim

    thin = continuity['thin_cover']
    uncovered = [r for r in thin if not r['contacts']]
    if thin:
        dim.deduct(
            'Support cover on critical services',
            '{0} of {1} BC1'.format(len(thin), bc1),
            35.0 * (float(len(thin)) / bc1) + (12.0 if uncovered else 0.0), 40,
            '{0} of {1} business-critical applications can be escalated to '
            'one person or nobody'.format(len(thin), bc1))
    else:
        dim.credit('Support cover on critical services',
                   'all {0} BC1'.format(bc1),
                   'every business-critical application names a second '
                   'contact')

    inverted = set(r['app_id'] for r in continuity['inversions'])
    if inverted:
        dim.deduct(
            'Critical services fed by lower-rated systems',
            '{0} of {1} BC1'.format(len(inverted), bc1),
            30.0 * (float(len(inverted)) / bc1), 30,
            '{0} business-critical applications depend on systems the estate '
            'itself rates as less important'.format(len(inverted)))

    exposed = set(r['app_id'] for r in continuity['third_party'])
    if exposed:
        dim.deduct(
            'Critical services fed from outside the estate',
            '{0} of {1} BC1'.format(len(exposed), bc1),
            20.0 * (float(len(exposed)) / bc1), 20,
            '{0} business-critical applications wait on a third party nobody '
            'here can page'.format(len(exposed)))

    return dim


def _score_agility(graph, parts, noun):
    dim = _Dimension(DIM_AGILITY)
    matrix, coupling, degrees = parts['matrix'], parts['coupling'], parts['degrees']
    totals = matrix['totals']
    interfaces = totals['cross'] + totals['intra']
    if not interfaces:
        dim.unrated('No interfaces are recorded anywhere in the estate, so '
                    'there is nothing yet to say how far a change would '
                    'travel.')
        return dim

    autonomy = _pct(totals['intra'], interfaces)
    if autonomy >= 60:
        dim.credit('Change contained within a {0}'.format(noun),
                   '{0}%'.format(autonomy),
                   '{0}% of interfaces never leave their own {1}, so most '
                   'changes can be planned locally'.format(autonomy, noun))
    else:
        dim.deduct(
            'Change contained within a {0}'.format(noun),
            '{0}%'.format(autonomy), (100.0 - autonomy) * 0.35, 35,
            'only {0}% of interfaces stay inside one {1} - most changes pull '
            'in another team'.format(autonomy, noun))

    floor = CONCENTRATION_SHARE * degrees['total_cross']
    concentrated = [r for r in degrees['rows'] if r['cross'] and r['cross'] >= floor]
    if concentrated:
        top = max(concentrated, key=lambda r: r['cross'])
        dim.deduct(
            'Traffic concentrated on single applications',
            '{0} at {1}%'.format(top['name'], top['share']),
            10.0 * len(concentrated) + 10.0, 25,
            '{0} carries {1}% of everything crossing a {2} boundary, so a '
            'freeze on it is an estate-wide freeze'.format(
                top['name'], top['share'], noun))

    hubs = [r for r in coupling['rows'] if r['role'] == ROLE_HUB]
    if hubs:
        dim.deduct(
            'Single {0} acting as an integration hub'.format(noun),
            ', '.join(r['name'] for r in hubs[:3]),
            12.0 * len(hubs), 20,
            '{0} sits between most of the estate, so its release calendar '
            'sets everyone else\'s'.format(hubs[0]['name']))

    single_peer = [r for r in coupling['rows'] if r['cross'] and r['peers'] == 1]
    if single_peer:
        dim.deduct(
            'Groups reachable through one peer only',
            '{0} {1}(s)'.format(len(single_peer), noun),
            5.0 * len(single_peer), 12,
            '{0} {1}(s) send and receive everything through a single peer, '
            'which is an undeclared single point of failure'.format(
                len(single_peer), noun))

    return dim


def _score_supplier(graph, parts, noun):
    dim = _Dimension(DIM_SUPPLIER)
    externals, continuity = parts['externals'], parts['continuity']
    apps = len(graph.get('apps') or [])
    if not apps:
        dim.unrated('The estate holds no application records yet.')
        return dim
    if not externals['count']:
        dim.credit('Third-party systems', 'none',
                   'every recorded interface resolves to an application '
                   'inside the estate')
        return dim

    shared = externals['shared']
    if shared:
        dim.deduct(
            'Suppliers nobody owns',
            '{0} of {1}'.format(len(shared), externals['count']),
            8.0 * len(shared), 30,
            '{0} third-party systems are used by more than one {1}, so no '
            'single {1} owns the contract or the outage'.format(
                len(shared), noun))

    bc1 = _count_bc1(graph)
    exposed = set(r['app_id'] for r in continuity['third_party'])
    if bc1 and exposed:
        dim.deduct(
            'Critical services depending on a supplier',
            '{0} of {1} BC1'.format(len(exposed), bc1),
            30.0 * (float(len(exposed)) / bc1), 30,
            '{0} of {1} business-critical applications cannot run without an '
            'inbound third-party feed'.format(len(exposed), bc1))

    if apps:
        reach = _pct(externals['count'], apps)
        if reach >= 50:
            dim.deduct(
                'Breadth of the supplier estate',
                '{0} suppliers to {1} applications'.format(
                    externals['count'], apps),
                (reach - 50.0) * 0.3, 20,
                'the estate touches {0} third-party systems for {1} '
                'applications, which is a wide contractual surface'.format(
                    externals['count'], apps))

    top = externals['rows'][0] if externals['rows'] else None
    if top and top['apps'] > 1 and not shared:
        dim.credit('Widest supplier relationship',
                   '{0} ({1} applications)'.format(top['name'], top['apps']),
                   'the widest supplier stays inside one {0}'.format(noun))
    return dim


def _score_ownership(graph, parts, noun, counter_noun, has_lead):
    dim = _Dimension(DIM_OWNERSHIP)
    coverage, ownership, coupling = (parts['coverage'], parts['ownership'],
                                     parts['coupling'])
    apps = coverage['apps']
    if not apps:
        dim.unrated('The estate holds no application records yet.')
        return dim

    if coverage['unassigned']:
        pct = _pct(coverage['unassigned'], apps)
        dim.deduct(
            'Applications with no owning {0}'.format(noun),
            '{0} of {1}'.format(coverage['unassigned'], apps),
            pct * 0.5, 35,
            '{0}% of applications sit outside every {1}, so nobody is '
            'accountable for them by name'.format(pct, noun))
    else:
        dim.credit('Applications with no owning {0}'.format(noun), 'none',
                   'every application sits inside a named {0}'.format(noun))

    fragmented = [r for r in ownership['fragmented'] if r['spread'] >= 3]
    if fragmented:
        dim.deduct(
            'Capabilities split across delivery lines',
            '{0} {1}(s)'.format(len(fragmented), noun),
            6.0 * len(fragmented), 25,
            '{0} {1}(s) have their applications spread across three or more '
            '{2}s - one business conversation with several escalation paths '
            'behind it'.format(len(fragmented), noun, counter_noun))

    empty = [r for r in coupling['rows'] if not r['apps']]
    if empty:
        dim.deduct(
            'Declared {0}s holding nothing'.format(noun),
            '{0} {1}(s)'.format(len(empty), noun),
            4.0 * len(empty), 12,
            '{0} {1}(s) are declared but hold no applications, so the '
            'structure claims coverage the estate does not have'.format(
                len(empty), noun))

    populated = [r for r in coupling['rows'] if r['apps']]
    unled = [r for r in populated if not (r.get('lead') or '').strip()]
    if has_lead and populated and unled:
        pct = _pct(len(unled), len(populated))
        dim.deduct(
            '{0}s with no named lead'.format(noun.title()),
            '{0} of {1}'.format(len(unled), len(populated)),
            pct * 0.2, 18,
            '{0} of {1} populated {2}s name no lead, so escalation has no '
            'first stop'.format(len(unled), len(populated), noun))
    return dim


def _score_integration(graph, parts, noun):
    dim = _Dimension(DIM_INTEGRATION)
    protocols = parts['protocols']
    if not protocols['total']:
        dim.unrated('No interfaces are recorded, so the estate makes no '
                    'statement about how its systems are joined together.')
        return dim

    legacy_pct = protocols['legacy_pct']
    if legacy_pct:
        styles = ', '.join('{0} ({1})'.format(r['style'], r['count'])
                           for r in protocols['rows'] if r['modernise'])
        dim.deduct(
            'Brittle point-to-point coupling',
            '{0}%'.format(legacy_pct), legacy_pct * 0.55, 45,
            '{0}% of interfaces are file drops, direct database links or '
            'email - {1}'.format(legacy_pct, styles or 'all hard to observe '
                                 'and hard to version'))
    else:
        dim.credit('Brittle point-to-point coupling', '0%',
                   'no interface relies on a file drop, a database link or '
                   'email')

    unspecified_pct = protocols['unspecified_pct']
    if unspecified_pct:
        dim.deduct(
            'Integration method not recorded',
            '{0}%'.format(unspecified_pct), unspecified_pct * 0.4, 30,
            '{0}% of interfaces do not say how the two systems are joined, so '
            'they cannot be reasoned about for security or '
            'throughput'.format(unspecified_pct))

    modern = [r for r in protocols['rows']
              if r['style'] in ('API / web service', 'Messaging / queue')]
    modern_pct = sum(r['pct'] for r in modern)
    if modern_pct >= 50:
        dim.credit('Interfaces on a managed style',
                   '{0}%'.format(round(modern_pct, 1)),
                   'the majority of interfaces run over APIs or messaging, '
                   'which can be versioned and observed')
    return dim


def _score_technology(graph, parts, noun):
    dim = _Dimension(DIM_TECHNOLOGY)
    technology = parts['technology']
    apps = len(graph.get('apps') or [])
    if not apps:
        dim.unrated('The estate holds no application records yet.')
        return dim

    documented = technology['documented_pct']
    if documented < 100:
        dim.deduct(
            'Applications with a recorded stack',
            '{0}%'.format(documented), (100.0 - documented) * 0.45, 45,
            'only {0}% of applications record what they run on, so any '
            'question about a version, a licence or an end-of-life date can '
            'only be answered for part of the estate'.format(documented))
    else:
        dim.credit('Applications with a recorded stack', '100%',
                   'every application records what it runs on')

    distinct = sum(b['distinct'] for b in technology['summary'])
    singletons = len(technology['singletons'])
    if distinct and singletons:
        share = _pct(singletons, distinct)
        dim.deduct(
            'Technologies used by one application only',
            '{0} of {1}'.format(singletons, distinct), share * 0.3, 30,
            '{0} of {1} recorded technologies are carried for a single '
            'application - each one a skill, a licence and a patching '
            'obligation'.format(singletons, distinct))
    return dim


def _score_information(graph, parts, noun):
    dim = _Dimension(DIM_INFORMATION)
    coverage = parts['coverage']
    if not coverage['apps']:
        dim.unrated('The estate holds no application records yet.')
        return dim

    if coverage['links']:
        by_name_pct = coverage['by_name_pct']
        if by_name_pct:
            dim.deduct(
                'Connections inferred rather than evidenced',
                '{0}%'.format(by_name_pct), by_name_pct * 0.4, 35,
                '{0}% of the connections drawn on this map were matched by '
                'name rather than by a hostname recorded on both sides, so '
                'they are inference'.format(by_name_pct))
        else:
            dim.credit('Connections inferred rather than evidenced', '0%',
                       'every connection is backed by a hostname recorded on '
                       'both sides')

    if coverage['duplicate_hosts']:
        dim.deduct(
            'Hostnames claimed by more than one application',
            '{0}'.format(coverage['duplicate_hosts']),
            8.0 * coverage['duplicate_hosts'], 25,
            '{0} hostnames appear under more than one application, so every '
            'interface pointing at them resolves to whichever record was '
            'read first'.format(coverage['duplicate_hosts']))

    gaps = [g for g in coverage['gaps'] if g['count']]
    if gaps:
        worst = max(gaps, key=lambda g: g['pct'])
        average = sum(g['pct'] for g in gaps) / float(len(coverage['gaps']))
        dim.deduct(
            'Blank fields on the application record',
            '{0} at {1}%'.format(worst['label'].lower(), worst['pct']),
            average * 0.35, 30,
            'the widest gap is "{0}" at {1}% of applications, which means '
            '{2}'.format(worst['label'].lower(), worst['pct'], worst['why']))
    return dim


def build_scorecard(graph, grouping, parts):
    """The estate graded against the seven questions a board asks.

    Returns the seven dimensions plus a weighted composite index. Dimensions
    the estate holds no evidence for are marked NOT RATED and left out of the
    index entirely rather than being scored zero - a missing measurement is
    not a bad result, and pretending otherwise would make the index move when
    somebody fills in a field.
    """
    meta = GROUPINGS[grouping]
    noun = meta['noun']
    counter_noun = GROUPINGS[meta['counterpart']]['noun']

    built = {
        DIM_RESILIENCE: _score_resilience(graph, parts, noun),
        DIM_AGILITY: _score_agility(graph, parts, noun),
        DIM_SUPPLIER: _score_supplier(graph, parts, noun),
        DIM_OWNERSHIP: _score_ownership(graph, parts, noun, counter_noun,
                                        bool(meta.get('has_lead'))),
        DIM_INTEGRATION: _score_integration(graph, parts, noun),
        DIM_TECHNOLOGY: _score_technology(graph, parts, noun),
        DIM_INFORMATION: _score_information(graph, parts, noun),
    }

    rows = []
    weighted = 0.0
    weight_total = 0
    for name, weight, question in DIMENSIONS:
        row = built[name].finish(question, weight)
        rows.append(row)
        if row['score'] is not None:
            weighted += row['score'] * weight
            weight_total += weight

    # Nothing recorded is not a good result: an estate with no applications
    # leaves every dimension unrated, so weight_total is 0 and the index is
    # None rather than a grade awarded for an empty database.
    index = int(round(weighted / weight_total)) if weight_total else None
    grade, band, gloss = _band(index)
    rated = [r for r in rows if r['score'] is not None]
    weakest = min(rated, key=lambda r: r['score']) if rated else None
    strongest = max(rated, key=lambda r: r['score']) if rated else None

    return {
        'index': index,
        'grade': grade,
        'band': band,
        'gloss': gloss,
        'rated': len(rated),
        'unrated': len(rows) - len(rated),
        'rows': rows,
        'weakest': weakest['dimension'] if weakest else '',
        'strongest': strongest['dimension'] if strongest else '',
    }


# ---------------------------------------------------------------------------
# Domain profiles - one card per business area
#
# The coupling table answers eleven questions at once and is the right thing
# to have when a specific one of them is being chased. It is the wrong thing
# to open a conversation with, because reading it requires knowing what
# fan-in, autonomy and role mean before the first number lands.
#
# A profile says the same thing in a sentence: what this domain holds, who it
# depends on, what would hurt it, and whether that is a problem. The numbers
# behind every phrase are the ones in the table, so the two cannot disagree.
# ---------------------------------------------------------------------------

def _posture(row):
    """How self-contained a group is, in words rather than a percentage."""
    if row['autonomy'] is None:
        return POSTURE_SILENT
    if row['autonomy'] >= AUTONOMY_CONTAINED:
        return POSTURE_CONTAINED
    if row['autonomy'] <= AUTONOMY_DEPENDENT:
        return POSTURE_DEPENDENT
    return POSTURE_INTERLINKED


def _role_sentence(row, noun):
    """The traffic role, said the way it would be said out loud."""
    peers = row['peers']
    if row['role'] == ROLE_EMPTY:
        return 'Holds no applications.'
    if row['role'] == ROLE_ISOLATED:
        return ('Records no interfaces at all - it neither feeds nor is fed '
                'by the rest of the estate.')
    if row['role'] == ROLE_HUB:
        return ('Acts as the estate\'s integration hub: it exchanges data '
                'with {0} and sits at one end of {1}% of everything that '
                'crosses a boundary.'.format(
                    _n(peers, 'other ' + noun), row['share']))
    if row['role'] == ROLE_PROVIDER:
        return ('Mainly a supplier of information: it sends {0} out and takes '
                '{1} in, across {2}.'.format(
                    _n(row['out'], 'interface'), row['inb'],
                    _n(peers, 'other ' + noun)))
    if row['role'] == ROLE_CONSUMER:
        return ('Mainly a consumer of information: it takes {0} in and sends '
                '{1} out, across {2}.'.format(
                    _n(row['inb'], 'interface'), row['out'],
                    _n(peers, 'other ' + noun)))
    return ('Exchanges data evenly with {0} - {1} out, {2} in.'.format(
        _n(peers, 'other ' + noun), row['out'], row['inb']))


def build_profiles(graph, grouping, parts):
    """One plain-language card per group, with the risks that belong to it.

    Ordered by risk and then by size, because the first card a reader sees
    should be the one that needs them - not whichever happens to sort first
    alphabetically or to carry the most traffic.
    """
    meta = GROUPINGS[grouping]
    noun = meta['noun']
    coupling = parts['coupling']
    continuity = parts['continuity']
    externals = parts['externals']
    ownership = parts['ownership']

    spread_by_id = dict((r['id'], r) for r in ownership['rows'])
    counter_noun = GROUPINGS[meta['counterpart']]['noun']
    has_lead = bool(meta.get('has_lead'))

    # The continuity findings, filed by the group they land in, so a card can
    # name its own exposure rather than pointing at a table further down.
    thin_by_group = {}
    for entry in continuity['thin_cover']:
        thin_by_group.setdefault(entry['group'], []).append(entry['app'])
    inverted_by_group = {}
    for entry in continuity['inversions']:
        inverted_by_group.setdefault(entry['group'], set()).add(entry['app'])
    supplier_by_group = {}
    for entry in continuity['third_party']:
        supplier_by_group.setdefault(entry['group'], set()).add(entry['app'])
    shared_ext_names = set(r['name'] for r in externals['shared'])
    shared_by_group = {}
    for entry in externals['shared']:
        for name in entry['group_names']:
            shared_by_group.setdefault(name, set()).add(entry['name'])

    rows = []
    for row in coupling['rows']:
        watch = []
        risk_points = 0

        thin = thin_by_group.get(row['name']) or []
        if thin:
            risk_points += 3
            watch.append({
                'kind': 'Support cover',
                'text': '{0} here can be escalated to one person or '
                        'nobody'.format(
                            _n(len(thin), 'business-critical application')),
                'items': sorted(thin)[:6],
            })

        inverted = inverted_by_group.get(row['name']) or set()
        if inverted:
            risk_points += 2
            watch.append({
                'kind': 'Dependency mismatch',
                'text': '{0} here depend on systems rated lower than '
                        'themselves'.format(_n(
                            len(inverted),
                            'business-critical application')),
                'items': sorted(inverted)[:6],
            })

        suppliers = supplier_by_group.get(row['name']) or set()
        if suppliers:
            risk_points += 2
            watch.append({
                'kind': 'Supplier dependency',
                'text': '{0} here wait on an inbound third-party '
                        'feed'.format(_n(
                            len(suppliers),
                            'business-critical application')),
                'items': sorted(suppliers)[:6],
            })

        shared = shared_by_group.get(row['name']) or set()
        if shared:
            risk_points += 1
            watch.append({
                'kind': 'Shared supplier',
                'text': '{0} here {1} also used by another {2}, so the '
                        'relationship has no single owner'.format(
                            _n(len(shared), 'third-party system'),
                            _verb(len(shared), 'is', 'are'), noun),
                'items': sorted(shared)[:6],
            })

        if row['role'] == ROLE_HUB:
            risk_points += 2
            watch.append({
                'kind': 'Change bottleneck',
                'text': 'this {0} sits at one end of {1}% of everything that '
                        'crosses a boundary, so its release calendar '
                        'constrains the estate'.format(noun, row['share']),
                'items': [],
            })

        if row['apps'] and row['cross'] and row['peers'] == 1:
            risk_points += 1
            watch.append({
                'kind': 'Single peer',
                'text': 'everything this {0} sends and receives goes through '
                        'one peer'.format(noun),
                'items': [],
            })

        if has_lead and row['apps'] and not (row.get('lead') or '').strip():
            risk_points += 1
            watch.append({
                'kind': 'No named lead',
                'text': 'no lead is recorded, so escalation has no first '
                        'stop',
                'items': [],
            })

        spread = spread_by_id.get(row['id'])
        if spread and spread['spread'] >= 3:
            risk_points += 1
            watch.append({
                'kind': 'Split ownership',
                'text': 'these applications sit across {0} different {1}s, '
                        'so one business conversation has {0} escalation '
                        'paths'.format(spread['spread'], counter_noun),
                'items': [p['name'] for p in spread['parts'][:6]],
            })

        if risk_points >= 4:
            risk = RISK_HIGH
        elif risk_points >= 2:
            risk = RISK_MODERATE
        else:
            risk = RISK_LOW

        posture = _posture(row)
        bc1 = (row['bc_mix'] or {}).get('BC1', 0)
        if not row['apps']:
            headline = ('Declared but empty - either the area is unserved or '
                        'its applications are filed elsewhere.')
        elif risk == RISK_LOW and not watch:
            headline = ('{0}, {1} business critical. Nothing here crossed a '
                        'reporting threshold.'.format(
                            _n(row['apps'], 'application'), bc1))
        else:
            headline = ('{0}, {1} business critical. {2} below.'.format(
                _n(row['apps'], 'application'), bc1,
                _n(len(watch), 'attention point')))

        rows.append({
            'id': row['id'],
            'name': row['name'],
            'lead': row.get('lead', ''),
            'apps': row['apps'],
            'bc1': bc1,
            'bc_mix': row['bc_mix'],
            'posture': posture,
            'autonomy': row['autonomy'],
            'role': row['role'],
            'role_sentence': _role_sentence(row, noun),
            'peers': row['peers'],
            'externals': row['externals'],
            'intra': row['intra'],
            'out': row['out'],
            'inb': row['inb'],
            'cross': row['cross'],
            'share': row['share'],
            'risk': risk,
            'headline': headline,
            'watch': watch,
        })

    order = {RISK_HIGH: 0, RISK_MODERATE: 1, RISK_LOW: 2}
    rows.sort(key=lambda r: (order.get(r['risk'], 9), -r['apps'],
                             r['name'].lower()))
    return {
        'label': meta['label'],
        'plural': meta['plural'],
        'rows': rows,
        'high': len([r for r in rows if r['risk'] == RISK_HIGH]),
        'moderate': len([r for r in rows if r['risk'] == RISK_MODERATE]),
    }


# ---------------------------------------------------------------------------
# Findings - the numbers above, read as an argument
#
# A finding now carries five things a technical observation does not:
#
#   impact   what it costs the BUSINESS, in a sentence that never mentions an
#            interface. This is the line that survives the walk to the
#            meeting room.
#   theme    which of the seven scorecard dimensions it belongs to, so the
#            agenda groups by consequence rather than by which analysis
#            happened to produce it.
#   horizon  Now / Next / Later, derived from severity so the two can never
#            drift apart.
#   effort   what closing it plausibly costs. A high-severity item that is
#            cheap to fix and a high-severity item that is a programme are
#            not the same conversation.
#   owner    the ROLE that can close it. Never a person.
#
# detail and action are unchanged: the evidence, and the instruction.
# ---------------------------------------------------------------------------

EFFORT_LOW = 'Low'
EFFORT_MEDIUM = 'Medium'
EFFORT_HIGH = 'High'


def _finding(severity, area, title, detail, action, metric='', items=None,
             impact='', effort=EFFORT_MEDIUM):
    """One finding, filed for both the analyst and the audience.

    `theme`, `horizon` and `owner` are derived rather than passed: they are
    functions of `area` and `severity`, and deriving them here is what stops
    a new finding being filed under a theme that does not match its severity
    or an owner that does not match its theme.
    """
    theme = AREA_THEMES.get(area, DIM_INFORMATION)
    return {'severity': severity, 'area': area, 'title': title,
            'detail': detail, 'action': action, 'metric': metric,
            'items': items or [],
            'impact': impact, 'theme': theme, 'effort': effort,
            'horizon': HORIZON_BY_SEVERITY.get(severity, 'Later'),
            'owner': THEME_OWNERS.get(theme, 'Application owner')}


def build_findings(graph, grouping, parts):
    """Severity-ranked statements about the estate, each with an action.

    Every finding here is derived from a number computed above; nothing is
    asserted that the reader cannot go and check in the table it came from.
    An estate with nothing to report gets an explicit "nothing to report"
    row rather than an empty panel, because a blank section reads as a bug.
    """
    meta = GROUPINGS[grouping]
    noun = meta['noun']
    findings = []

    coupling = parts['coupling']
    degrees = parts['degrees']
    continuity = parts['continuity']
    protocols = parts['protocols']
    externals = parts['externals']
    ownership = parts['ownership']
    coverage = parts['coverage']
    technology = parts['technology']

    # --- wiring vs criticality ------------------------------------------
    if continuity['inversions']:
        affected = len(set(r['app_id'] for r in continuity['inversions']))
        findings.append(_finding(
            SEV_HIGH, 'Business continuity', 'Criticality inversion',
            '{0} business-critical application(s) are fed by systems rated '
            'lower than themselves. A feed inherits the criticality of what '
            'it serves, so either the upstream rating or the dependency is '
            'wrong.'.format(affected),
            'Re-rate the upstream systems, or break the dependency.',
            '{0} inverted dependency path(s)'.format(
                len(continuity['inversions'])),
            ['{0} ({1}) fed by {2} ({3})'.format(r['app'], r['bc'],
                                                 r['source'], r['source_bc'])
             for r in continuity['inversions'][:12]],
            impact='A business-critical service can be taken down by a system '
                   'the organisation has decided it can afford to lose. The '
                   'recovery plan for the first does not cover the second.',
            effort=EFFORT_LOW))

    if continuity['thin_cover']:
        no_contact = [r for r in continuity['thin_cover'] if not r['contacts']]
        findings.append(_finding(
            SEV_HIGH if no_contact else SEV_MEDIUM, 'Business continuity',
            'BC1 applications without a support rota',
            '{0} business-critical application(s) name one contact or none. '
            'One name is a person, not a rota.'.format(
                len(continuity['thin_cover'])),
            'Name a second contact on each application record.',
            '{0} with no contact at all'.format(len(no_contact)),
            ['{0} ({1})'.format(r['app'], 'no contact' if not r['contacts']
                                else 'single contact')
             for r in continuity['thin_cover'][:12]],
            impact='Restoring a critical service out of hours depends on one '
                   'person answering the phone. Leave, illness or a '
                   'resignation turns a one-hour incident into an all-night '
                   'one.',
            effort=EFFORT_LOW))

    if continuity['third_party']:
        affected = len(set(r['app_id'] for r in continuity['third_party']))
        findings.append(_finding(
            SEV_MEDIUM, 'Business continuity',
            'Business-critical dependency on third parties',
            '{0} business-critical application(s) are fed by systems outside '
            'the estate - dependencies nobody here can be paged '
            'for.'.format(affected),
            'Confirm each has a contract, a named contact and a fallback.',
            '{0} inbound third-party feed(s)'.format(
                len(continuity['third_party'])),
            ['{0} from {1}'.format(r['app'], r['system'])
             for r in continuity['third_party'][:12]],
            impact='Part of the recovery time for a critical service is held '
                   'by a supplier. Unless the contract says otherwise, their '
                   'priority is not the same as ours.',
            effort=EFFORT_MEDIUM))

    # --- concentration ---------------------------------------------------
    floor = CONCENTRATION_SHARE * degrees['total_cross']
    concentrated = sorted([r for r in degrees['rows']
                           if r['cross'] and r['cross'] >= floor],
                          key=lambda r: -r['cross'])
    if concentrated:
        findings.append(_finding(
            SEV_HIGH if len(concentrated) == 1 else SEV_MEDIUM,
            'Concentration risk', 'Traffic concentrated on a few applications',
            '{0} application(s) each carry at least {1:.0f}% of every '
            'interface that crosses a {2} boundary. An outage or a change '
            'freeze on any of them is an estate-wide event.'.format(
                len(concentrated), CONCENTRATION_SHARE * 100, noun),
            'Treat these as estate-level change-control and DR scope.',
            'top application carries {0}% of cross-{1} traffic'.format(
                concentrated[0]['share'], noun),
            ['{0} ({1}) - {2} cross-{3} interface(s), {4}%'.format(
                r['name'], r['group'] or 'unassigned', r['cross'], noun,
                r['share']) for r in concentrated[:8]],
            impact='A single system failing stops work in several parts of '
                   'the business at once, and every change to it needs an '
                   'estate-wide window.',
            effort=EFFORT_HIGH))

    hubs = [r for r in coupling['rows'] if r['role'] == ROLE_HUB]
    if hubs:
        many = len(hubs) > 1
        findings.append(_finding(
            SEV_MEDIUM, 'Integration shape',
            '{0} acting as an integration hub'.format(
                meta['plural'] if many else meta['label']),
            '{0} {1} a disproportionate share of the traffic and {2} most of '
            'the estate. That is a legitimate pattern when it is deliberate '
            'and a bottleneck when it is not.'.format(
                ', '.join(r['name'] for r in hubs),
                'carry' if many else 'carries',
                'touch' if many else 'touches'),
            'Confirm the hub is an intended integration layer, not an '
            'accident of history.',
            # Shares are per-END and so do not sum (see build_coupling); the
            # busiest hub's own figure is the honest headline.
            'busiest sits at one end of {0}% of cross-{1} traffic'.format(
                max(r['share'] for r in hubs), noun),
            ['{0} - {1} peer(s), at one end of {2}% of cross-{3} '
             'traffic'.format(r['name'], r['peers'], r['share'], noun)
             for r in hubs],
            impact='One team\'s release calendar sets the pace for everyone '
                   'else. Business changes queue behind a dependency the '
                   'business never chose.',
            effort=EFFORT_HIGH))

    single_peer = [r for r in coupling['rows']
                   if r['cross'] and r['peers'] == 1]
    if single_peer:
        findings.append(_finding(
            SEV_LOW, 'Integration shape', 'Single-peer dependency',
            '{0} {1}(s) send and receive everything through exactly one peer. '
            'That peer is an undeclared single point of failure for '
            'them.'.format(len(single_peer), noun),
            'Record the dependency in the continuity plan for both sides.',
            '', ['{0} - {1} interface(s) to one peer'.format(r['name'],
                                                             r['cross'])
                 for r in single_peer[:10]],
            impact='A whole area of the business goes quiet when one '
                   'neighbouring system does, and no continuity plan '
                   'currently says so.',
            effort=EFFORT_LOW))

    silent = [r for r in coupling['rows']
              if r['apps'] and not r['cross'] and not r['intra']]
    if silent:
        findings.append(_finding(
            SEV_LOW, 'Integration shape', 'No integration recorded',
            '{0} {1}(s) hold applications but record no interfaces at all. '
            'Genuinely standalone systems exist; a whole {1} of them is '
            'usually a gap in the record.'.format(len(silent), noun),
            'Check the External Interfaces section on those applications.',
            '', [r['name'] for r in silent[:10]],
            impact='Impact assessment for any change in this area is running '
                   'blind - the estate cannot say who would notice.',
            effort=EFFORT_LOW))

    empty_groups = [r for r in coupling['rows'] if not r['apps']]
    if empty_groups:
        findings.append(_finding(
            SEV_LOW, 'Landscape coverage',
            'Declared {0} with no applications'.format(noun),
            '{0} {1}(s) are defined but hold nothing. Either the area is '
            'unserved, or its applications are misfiled.'.format(
                len(empty_groups), noun),
            'Retire the empty {0}, or classify the applications that belong '
            'to it.'.format(noun),
            '', [r['name'] for r in empty_groups[:10]],
            impact='The structure claims coverage of a business area that '
                   'nothing in the estate actually serves.',
            effort=EFFORT_LOW))

    # --- integration style ----------------------------------------------
    if protocols['legacy'] and protocols['legacy_pct'] >= LEGACY_ALERT_PCT:
        styles = ', '.join('{0} ({1})'.format(r['style'], r['count'])
                           for r in protocols['rows'] if r['modernise'])
        findings.append(_finding(
            SEV_MEDIUM, 'Integration style',
            'Estate leans on point-to-point coupling',
            '{0}% of recorded interfaces are file drops, direct database '
            'links or email - styles that are brittle, hard to observe and '
            'hard to version.'.format(protocols['legacy_pct']),
            'Target the highest-volume of these for an API or event '
            'replacement first.',
            styles, [],
            impact='Failures surface as missing data hours later rather than '
                   'as an alert, and every change to either end risks the '
                   'other. Cost of change stays high across the estate.',
            effort=EFFORT_HIGH))

    if (protocols['unspecified']
            and protocols['unspecified_pct'] >= UNSPECIFIED_ALERT_PCT):
        findings.append(_finding(
            SEV_LOW, 'Integration style', 'Connectivity type not recorded',
            '{0}% of interfaces do not say how the two systems are joined, so '
            'they cannot be reasoned about for security, throughput or '
            'modernisation.'.format(protocols['unspecified_pct']),
            'Fill in Connectivity Type on those interface rows.',
            '{0} interface(s)'.format(protocols['unspecified']), [],
            impact='Security review and modernisation planning both have to '
                   'guess at this part of the estate.',
            effort=EFFORT_LOW))

    # --- third parties ---------------------------------------------------
    if externals['shared']:
        findings.append(_finding(
            SEV_MEDIUM, 'Third-party exposure',
            'External systems shared across the estate',
            '{0} third-party system(s) are depended on by more than one {1}, '
            'so no single {1} owns the relationship, the contract or the '
            'outage.'.format(len(externals['shared']), noun),
            'Assign an enterprise owner to each shared third party.',
            '', ['{0} - {1} {2}(s), {3} application(s)'.format(
                r['name'], r['groups'], noun, r['apps'])
                for r in externals['shared'][:10]],
            impact='Nobody is negotiating these contracts on behalf of the '
                   'whole business, and when one fails the incident has no '
                   'obvious owner.',
            effort=EFFORT_MEDIUM))

    # --- ownership -------------------------------------------------------
    fragmented = [r for r in ownership['fragmented'] if r['spread'] >= 3]
    if fragmented:
        counter = ownership['counterpart_label'].lower()
        findings.append(_finding(
            SEV_MEDIUM, 'Ownership alignment',
            '{0}s split across many {1}s'.format(ownership['label'], counter),
            '{0} {1}(s) have their applications spread across three or more '
            '{2}(s) - one business conversation with several escalation paths '
            'behind it.'.format(len(fragmented), noun, counter),
            'Agree a single accountable owner per {0}.'.format(noun),
            '', ['{0} - {1} {2}(s), largest holds {3}%'.format(
                r['name'], r['spread'], counter, r['concentration'])
                for r in fragmented[:10]],
            impact='A business sponsor asking for one change has to convene '
                   'three delivery groups to get it, which is where the '
                   'elapsed time in the change actually goes.',
            effort=EFFORT_MEDIUM))

    # --- map confidence ---------------------------------------------------
    if coverage['duplicate_hosts']:
        findings.append(_finding(
            SEV_HIGH, 'Map confidence', 'Hostnames claimed twice',
            '{0} hostname(s) appear under more than one application, so every '
            'interface pointing at them resolves to whichever application was '
            'read first.'.format(coverage['duplicate_hosts']),
            'Correct the Infrastructure section on the affected records.',
            '', [],
            impact='Some of the dependencies on this map point at the wrong '
                   'system, so an impact assessment built on it can be '
                   'confidently wrong.',
            effort=EFFORT_LOW))

    if coverage['by_name'] and coverage['by_name_pct'] >= INFERENCE_ALERT_PCT:
        findings.append(_finding(
            SEV_MEDIUM, 'Map confidence', 'Connections inferred from names',
            '{0}% of connections on this diagram were matched by application '
            'NAME rather than by a hostname recorded on both sides. Those are '
            'inferences, not evidence.'.format(coverage['by_name_pct']),
            'Record the peer hostname on the interface, and the host under '
            'the owning application Infrastructure.',
            '{0} of {1} link(s)'.format(coverage['by_name'],
                                        coverage['links']), [],
            impact='A material share of this landscape is an educated guess. '
                   'Decisions taken from it carry that uncertainty whether '
                   'or not anybody says so.',
            effort=EFFORT_MEDIUM))

    for gap in coverage['gaps']:
        if gap['count'] and gap['pct'] >= GAP_ALERT_PCT:
            findings.append(_finding(
                SEV_LOW, 'Record completeness', gap['label'],
                '{0} application(s) - {1}% of the estate - have no value '
                'here, so {2}.'.format(gap['count'], gap['pct'], gap['why']),
                'Complete the field on those application records.',
                '', gap['apps'][:10],
                impact='Any question that turns on this field can only be '
                       'answered for part of the estate, so the answer is '
                       'always a partial one.',
                effort=EFFORT_LOW))

    if degrees['isolated']:
        findings.append(_finding(
            SEV_LOW, 'Record completeness', 'Applications with no connections',
            '{0} application(s) record no interface in either direction. Some '
            'are genuinely standalone; the rest are undocumented.'.format(
                len(degrees['isolated'])),
            'Confirm each is standalone, or record its interfaces.',
            '', ['{0} ({1})'.format(r['name'], r['group'] or 'unassigned')
                 for r in degrees['isolated'][:12]],
            impact='These systems are invisible to every impact assessment '
                   'the estate produces.',
            effort=EFFORT_LOW))

    if technology['undocumented'] and technology['documented_pct'] < 75:
        findings.append(_finding(
            SEV_LOW, 'Technology standardisation',
            'Technology stack not recorded',
            'Only {0}% of applications record a technology stack, so any '
            'question about a version, a language or an end-of-life date can '
            'only be answered for part of the estate.'.format(
                technology['documented_pct']),
            'Complete the Technical Details tab on the remaining records.',
            '{0} application(s) blank'.format(technology['undocumented']), [],
            impact='The estate cannot answer an audit, a licence review or an '
                   'end-of-life question without a manual survey first.',
            effort=EFFORT_MEDIUM))

    if technology['singletons']:
        findings.append(_finding(
            SEV_LOW, 'Technology standardisation',
            'Technologies used by a single application',
            '{0} recorded technologies are used by exactly one application. '
            'Each is a skill, a licence and a patching obligation the estate '
            'carries for one system.'.format(len(technology['singletons'])),
            'Review for rationalisation at the next architecture board.',
            '', ['{0} ({1}) - {2}'.format(e['name'], e['category'],
                                          e['apps'][0]['name'])
                 for e in technology['singletons'][:12]],
            impact='Running cost and key-person risk the business is carrying '
                   'for one system each, usually without having chosen to.',
            effort=EFFORT_MEDIUM))

    findings.sort(key=lambda f: (SEV_ORDER.get(f['severity'], 9),
                                 f['area'], f['title']))
    counts = {SEV_HIGH: 0, SEV_MEDIUM: 0, SEV_LOW: 0}
    for entry in findings:
        counts[entry['severity']] = counts.get(entry['severity'], 0) + 1
    return {'rows': findings, 'counts': counts, 'total': len(findings)}


# ---------------------------------------------------------------------------
# The action agenda - the findings, filed the way work is actually commissioned
#
# A flat severity list is the right output for an analyst and the wrong one
# for a governance forum, which does not take decisions one finding at a
# time. It takes them by theme, against an owner, in a horizon. So the same
# rows are regrouped: seven themes at most, each with the role that can close
# them, ordered by how soon the estate is hurt by doing nothing.
# ---------------------------------------------------------------------------

def build_agenda(findings):
    """Findings regrouped by theme, owner and horizon.

    `priorities` are the items that would go on one slide: the highest
    severity, cheapest-first within that, capped at three. Cheapest-first
    because between two items that hurt equally, the one that can be closed
    this month is the one to commission first.
    """
    rows = findings.get('rows') or []
    effort_rank = {EFFORT_LOW: 0, EFFORT_MEDIUM: 1, EFFORT_HIGH: 2}

    themes = {}
    for entry in rows:
        bucket = themes.setdefault(entry['theme'], {
            'theme': entry['theme'],
            'owner': entry['owner'],
            'rows': [],
            'counts': {SEV_HIGH: 0, SEV_MEDIUM: 0, SEV_LOW: 0},
        })
        bucket['rows'].append(entry)
        bucket['counts'][entry['severity']] = (
            bucket['counts'].get(entry['severity'], 0) + 1)

    rank = dict((name, i) for i, (name, _w, _q) in enumerate(DIMENSIONS))

    ordered = []
    for name, _weight, _question in DIMENSIONS:
        bucket = themes.get(name)
        if not bucket:
            continue
        bucket['rank'] = rank[name]
        bucket['rows'].sort(key=lambda f: (SEV_ORDER.get(f['severity'], 9),
                                           effort_rank.get(f['effort'], 1),
                                           f['title']))
        worst = bucket['rows'][0]['severity']
        bucket['severity'] = worst
        bucket['horizon'] = HORIZON_BY_SEVERITY.get(worst, 'Later')
        bucket['total'] = len(bucket['rows'])
        ordered.append(bucket)
    ordered.sort(key=lambda b: (SEV_ORDER.get(b['severity'], 9), b['rank']))

    priorities = sorted(rows, key=lambda f: (SEV_ORDER.get(f['severity'], 9),
                                             effort_rank.get(f['effort'], 1),
                                             f['title']))[:3]

    horizons = {'Now': 0, 'Next': 0, 'Later': 0}
    for entry in rows:
        horizons[entry['horizon']] = horizons.get(entry['horizon'], 0) + 1

    return {
        'themes': ordered,
        'priorities': priorities,
        'horizons': horizons,
        'total': len(rows),
    }


# ---------------------------------------------------------------------------
# The executive summary
#
# Written, not templated round a number. Every sentence below is assembled
# from figures already computed and every one of them is a complete thought
# that survives being read aloud - which is the test, because this is the
# paragraph that gets pasted into a pack and read out by somebody who was not
# in the room when the analysis ran.
#
# Nothing here introduces a fact the panels do not already carry. If a
# sentence cannot be supported it is not written: an estate that has recorded
# nothing gets a short honest paragraph rather than a long confident one.
# ---------------------------------------------------------------------------

def _n(count, singular, plural=None):
    """"3 applications" / "1 application" - for prose, not for table cells."""
    word = singular if count == 1 else (plural or singular + 's')
    return '{0} {1}'.format(count, word)


def _verb(count, singular, plural):
    return singular if count == 1 else plural


def _sentence_shape(headline, noun, plural_label):
    """What the estate IS, before any judgement about it."""
    apps = headline['apps']
    groups = headline['groups']
    if not apps:
        return ('The estate holds no active application records yet, so there '
                'is nothing to report on.')
    if not groups:
        return ('The estate holds {0}, none of which is assigned to a '
                '{1}.'.format(_n(apps, 'active application'), noun))
    parts = ['The estate holds {0} across {1}'.format(
        _n(apps, 'active application'),
        _n(groups, plural_label.lower().rstrip('s'),
           plural_label.lower()))]
    interfaces = headline['cross'] + headline['intra']
    if interfaces:
        parts.append(
            'joined by {0}, {1} of which cross a {2} boundary'.format(
                _n(interfaces, 'recorded interface'), headline['cross'],
                noun))
    if headline['externals']:
        parts.append('and {0} outside it'.format(
            _n(headline['externals'], 'third-party system')))
    return ', '.join(parts) + '.'


def _sentence_position(scorecard, noun):
    """The judgement, in one sentence, with the grade attached."""
    if scorecard['index'] is None:
        return ('Nothing in the estate record supports a scored position yet - '
                'complete the application records and this becomes '
                'measurable.')
    text = ('Overall the estate scores {0} out of 100 - {1}: {2}.'.format(
        scorecard['index'], scorecard['band'].lower(), scorecard['gloss']))
    if scorecard['weakest'] and scorecard['strongest']:
        rated = [r for r in scorecard['rows'] if r['score'] is not None]
        weakest = min(rated, key=lambda r: r['score'])
        strongest = max(rated, key=lambda r: r['score'])
        if weakest['dimension'] != strongest['dimension']:
            text += (' The strongest position is {0} at {1}; the weakest is '
                     '{2} at {3}.'.format(
                         strongest['dimension'].lower(), strongest['score'],
                         weakest['dimension'].lower(), weakest['score']))
    if scorecard['unrated']:
        text += (' {0} of the seven dimensions could not be scored because the '
                 'estate records nothing that speaks to them.'.format(
                     scorecard['unrated']))
    return text


def _sentence_continuity(graph, parts, noun):
    """The resilience position, in the language a service owner uses."""
    bc1 = _count_bc1(graph)
    if not bc1:
        return ('No application is yet rated BC1, so the estate cannot say '
                'which services the business could not run without.')
    continuity = parts['continuity']
    thin = len(continuity['thin_cover'])
    inverted = len(set(r['app_id'] for r in continuity['inversions']))
    supplied = len(set(r['app_id'] for r in continuity['third_party']))
    clauses = []
    if thin:
        clauses.append('{0} can be escalated to one person or nobody'.format(
            thin))
    if inverted:
        clauses.append('{0} depend on systems rated less important than '
                       'themselves'.format(inverted))
    if supplied:
        clauses.append('{0} wait on an inbound third-party feed'.format(
            supplied))
    if not clauses:
        return ('All {0} have a named rota, depend only on systems rated at '
                'least as highly as themselves, and take no inbound '
                'third-party feed.'.format(
                    _n(bc1, 'business-critical application')))
    if len(clauses) > 1:
        clauses[-1] = 'and ' + clauses[-1]
    return ('Of {0}, {1}.'.format(_n(bc1, 'business-critical application'),
                                  ', '.join(clauses)))


def _sentence_change(headline, parts, noun):
    """How far a change travels, said without the word autonomy."""
    interfaces = headline['cross'] + headline['intra']
    if not interfaces:
        return ('No interfaces are recorded, so the estate cannot yet say how '
                'far a change in one system would travel.')
    autonomy = headline['autonomy']
    text = ('{0}% of interfaces stay inside their own {1}, so {2} change '
            'planned in one place {3}.'.format(
                autonomy, noun,
                'most' if autonomy >= 60 else 'a',
                'usually stays there' if autonomy >= 60
                else 'more often than not pulls in another team'))
    hubs = [r for r in parts['coupling']['rows'] if r['role'] == ROLE_HUB]
    if hubs:
        text += (' {0} sits between most of the estate and effectively sets '
                 'the release calendar for it.'.format(hubs[0]['name']))
    return text


def _sentence_confidence(coverage):
    """How much of this can be relied on - stated, never implied."""
    if not coverage['links']:
        return ('No connection between two applications has been resolved '
                'yet, so this landscape shows systems without their '
                'dependencies.')
    text = ('{0}% of the connections drawn here are backed by a hostname '
            'recorded on both sides; the remaining {1}% were matched by name '
            'and are inference.'.format(coverage['by_host_pct'],
                                        coverage['by_name_pct']))
    if coverage['duplicate_hosts']:
        text += (' {0} {1} claimed by more than one application, so some of '
                 'those dependencies point at the wrong system.'.format(
                     _n(coverage['duplicate_hosts'], 'hostname'),
                     _verb(coverage['duplicate_hosts'], 'is', 'are')))
    return text


def build_narrative(graph, grouping, parts, headline, scorecard, agenda):
    """The estate in plain business English - the paragraph that travels.

    Returns the summary paragraph as an ordered list of sentences, plus the
    two lists any executive read ends on: what is working, and what needs a
    decision. Both are drawn from the scorecard rather than written by hand,
    so an estate that improves stops being criticised for it.
    """
    meta = GROUPINGS[grouping]
    noun = meta['noun']
    matrix = parts['matrix']

    summary = [
        _sentence_shape(headline, noun, meta['plural']),
        _sentence_position(scorecard, noun),
        _sentence_continuity(graph, parts, noun),
        _sentence_change(headline, parts, noun),
        _sentence_confidence(parts['coverage']),
    ]

    working = []
    attention = []
    for row in scorecard['rows']:
        if row['score'] is None:
            continue
        entry = {'dimension': row['dimension'], 'score': row['score'],
                 'band': row['band'], 'note': row['verdict']}
        if row['score'] >= 70:
            working.append(entry)
        elif row['score'] < 55:
            attention.append(entry)
    working.sort(key=lambda r: -r['score'])
    attention.sort(key=lambda r: r['score'])

    decisions = []
    for entry in agenda['priorities']:
        decisions.append({
            'title': entry['title'],
            'theme': entry['theme'],
            'owner': entry['owner'],
            'horizon': entry['horizon'],
            'effort': entry['effort'],
            'impact': entry['impact'],
            'action': entry['action'],
        })

    return {
        'summary': summary,
        'working': working,
        'attention': attention,
        'decisions': decisions,
        'as_at': datetime.now(timezone.utc).strftime('%d %b %Y'),
    }


# ---------------------------------------------------------------------------
# The pack
# ---------------------------------------------------------------------------

def build_insights(graph, grouping=GROUPING_DOMAIN):
    """Every analysis above, as one JSON-serialisable document.

    `graph` is architecture.build_estate_graph()'s output; `grouping` is
    'domain' (Enterprise Architect) or 'tower' (Architecture View). An
    unknown grouping falls back to the domain reading rather than raising:
    this feeds a read-only view, and a diagram with no insights beside it is
    better than a 500.

    The document has two halves and they are ordered on purpose. The
    EXECUTIVE half - scorecard, narrative, agenda, profiles - is what a
    business architect reads and presents. The ANALYTICAL half - matrix,
    coupling, degrees and the rest - is the evidence underneath it, and every
    figure in the first half is computed from the second, never separately.
    """
    if grouping not in GROUPINGS:
        grouping = GROUPING_DOMAIN
    meta = GROUPINGS[grouping]

    matrix = build_matrix(graph, grouping)
    coupling = build_coupling(graph, grouping, matrix)
    degrees = build_app_degrees(graph, grouping)
    continuity = build_continuity(graph, grouping, degrees)
    protocols = build_protocols(graph, grouping)
    externals = build_externals(graph, grouping)
    technology = build_technology(graph, grouping)
    ownership = build_ownership(graph, grouping)
    coverage = build_coverage(graph, grouping)

    parts = {'matrix': matrix, 'coupling': coupling, 'degrees': degrees,
             'continuity': continuity, 'protocols': protocols,
             'externals': externals, 'technology': technology,
             'ownership': ownership, 'coverage': coverage}
    findings = build_findings(graph, grouping, parts)

    counts = graph.get('counts') or {}
    totals = matrix['totals']
    headline = {
        'apps': counts.get('apps', len(graph.get('apps') or [])),
        'groups': len(matrix['groups']),
        'cross': totals['cross'],
        'intra': totals['intra'],
        'pairs': totals['pairs'],
        'externals': externals['count'],
        'bc1': _count_bc1(graph),
        'autonomy': _pct(totals['intra'], totals['intra'] + totals['cross']),
        'evidence': coverage['by_host_pct'],
        'high': findings['counts'].get(SEV_HIGH, 0),
    }

    scorecard = build_scorecard(graph, grouping, parts)
    agenda = build_agenda(findings)
    profiles = build_profiles(graph, grouping, parts)
    narrative = build_narrative(graph, grouping, parts, headline, scorecard,
                                agenda)
    headline['index'] = scorecard['index']
    headline['grade'] = scorecard['grade']
    headline['band'] = scorecard['band']

    return {
        'generated_at': datetime.now(timezone.utc)
                                .strftime('%Y-%m-%dT%H:%M:%SZ'),
        'graph_generated_at': graph.get('generated_at', ''),
        'grouping': grouping,
        'label': meta['label'],
        'plural': meta['plural'],
        'noun': meta['noun'],
        'view': meta['view'],
        'headline': headline,
        # ---- the executive reading ----
        'scorecard': scorecard,
        'narrative': narrative,
        'agenda': agenda,
        'profiles': profiles,
        # ---- the evidence underneath it ----
        'findings': findings,
        'matrix': matrix,
        'coupling': coupling,
        'applications': degrees,
        'continuity': continuity,
        'protocols': protocols,
        'externals': externals,
        'technology': technology,
        'ownership': ownership,
        'coverage': coverage,
    }
