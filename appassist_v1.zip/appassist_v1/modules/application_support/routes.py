from flask import render_template, redirect, url_for, flash, request, jsonify, session, send_file, abort, Response
from sqlalchemy import func
from werkzeug.utils import secure_filename
from auth import get_current_user, require_auth
import base64
import binascii
import os
import secrets
import mimetypes
from datetime import datetime
from auth import get_current_user
from database import get_db_session
from models import User
from . import application_support_bp
from .models import (
    AppSupportTower, TowerMember, ApplicationDetails, ServerDetails,
    SupportTeam, BusinessUsers, VendorDetails, ExternalInterfaces,
    IndividualJobs, SuiteJobs, FileInventory, ApplicationTask, CriticalIssue,
    BusinessCriticality, FlowDirection, TeamRole, UserRole, AuditLog,
    SecretVaultEntry, EnvironmentType, CredentialType,
    TechCatalog, ApplicationTechStack, StandardChecklistItem,
    ApplicationStandardCompliance, TECH_CATEGORIES, CHECKLIST_SCOPES,
    ApplicationCategory, ApplicationAssignment
)
from sqlalchemy import or_
from sqlalchemy.orm import joinedload
from modules.utility.servers_models import ServerData
from crypto_utils import encrypt_data, decrypt_data, CredentialDecryptionError
from .architecture import build_estate_graph
from . import insights
from . import (tech_details, quality, categories,
               server_sync, bulk_import, team_summary)
import file_versions

# Key this module's rows in the shared document_versions table.
FILE_ENTITY = file_versions.ENTITY_APP_SUPPORT_FILE

# The per-application upload dirs all live under this root. Version rows store a
# path RELATIVE to it (e.g. "Payments Hub/20260713_a1b2c3_runbook.pdf") rather
# than a bare filename, so a version keeps pointing at the right file even after
# the application is renamed and new uploads start landing in a new sub-folder.
FILE_UPLOAD_ROOT = os.path.join('secure_uploads', 'application_support')

# CSRF Protection Functions
def generate_csrf_token():
    """Generate a CSRF token for the current session"""
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_hex(16)
    return session['csrf_token']

def validate_csrf_token(token):
    """Validate the provided CSRF token against the session token"""
    if not token or 'csrf_token' not in session:
        return False
    return secrets.compare_digest(session['csrf_token'], token)

# Make CSRF token available to all templates in this blueprint
@application_support_bp.context_processor
def inject_csrf_token():
    return {'csrf_token': generate_csrf_token()}

# File Security Functions
# Define allowed file extensions (whitelist approach)
ALLOWED_EXTENSIONS = {
    'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 
    'xls', 'xlsx', 'ppt', 'pptx', 'csv', 'zip', 'rar', '7z',
    'sql', 'json', 'xml', 'log', 'md', 'yml', 'yaml', 'ini', 'cfg'
}

# Define allowed MIME types for additional validation
ALLOWED_MIME_TYPES = {
    'text/plain', 'application/pdf', 'image/png', 'image/jpeg', 'image/gif',
    'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'text/csv', 'application/zip', 'application/x-rar-compressed', 'application/x-7z-compressed',
    'application/sql', 'application/json', 'application/xml', 'text/x-log', 'text/markdown',
    'application/x-yaml', 'text/yaml','application/x-zip-compressed'
}

def allowed_file(filename):
    """Check if file has an allowed extension"""
    if not filename:
        return False
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def validate_file_content(file):
    """Validate file content type and size"""
    if not file:
        return False, "No file provided"
    
    # Check if file has content
    if not file.filename:
        return False, "Empty filename"
    
    # Check file extension
    if not allowed_file(file.filename):
        return False, f"File type not allowed. Allowed types: {', '.join(sorted(ALLOWED_EXTENSIONS))}"
    
    # Check MIME type
    try:
        file.seek(0)  # Reset file pointer
        mimetype = mimetypes.guess_type(file.filename)[0]
        if mimetype and mimetype not in ALLOWED_MIME_TYPES:
            return False, f"File content type '{mimetype}' not allowed"
    except Exception:
        return False, "Could not determine file type"
    finally:
        file.seek(0)  # Reset file pointer for saving
    
    return True, "File validation passed"

def get_secure_upload_path(app_name):
    """Get secure upload directory outside of static files"""
    # Store files outside the static directory to prevent direct web access
    upload_dir = os.path.join('secure_uploads', 'application_support',app_name)
    os.makedirs(upload_dir, exist_ok=True)
    return upload_dir

def _version_ref(file_path):
    """A FileInventory.file_path expressed relative to FILE_UPLOAD_ROOT.

    That relative form is what the version trail stores. Returns None when the
    path sits outside the upload root - a legacy or hand-edited row we must not
    follow, since the trail's prune would later unlink whatever it points at.
    """
    if not file_path:
        return None
    root = os.path.abspath(FILE_UPLOAD_ROOT)
    full = os.path.abspath(file_path)
    try:
        if os.path.commonpath([root, full]) != root:
            return None
    except ValueError:      # different drive on Windows
        return None
    return os.path.relpath(full, root)


def _store_app_upload(uploaded_file, app_name):
    """Save an uploaded file under a unique name. Returns (file_path, ref, original).

    The random suffix is what makes versioning safe: a timestamp alone collides
    when the same document is re-uploaded twice inside one second, and two
    version rows pointing at one file on disk would let a prune of the older row
    delete the file the newer one is still serving.
    """
    filename = secure_filename(uploaded_file.filename) or 'document'
    upload_dir = get_secure_upload_path(app_name)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    unique = f'{stamp}_{secrets.token_hex(3)}_{filename}'
    file_path = os.path.join(upload_dir, unique)
    uploaded_file.save(file_path)
    return file_path, _version_ref(file_path), uploaded_file.filename


def is_admin(user):
    """Check if user is an admin"""
    if not user:
        return False
    # Ensure we get the actual value, not a SQLAlchemy ColumnElement
    role = getattr(user, 'role', None)
    return role == 'admin'

def is_tower_member(user, tower_id):
    """Check if user is a member of the tower"""
    if not user:
        return False
    if is_admin(user):
        return True
    
    db_session = get_db_session()
    try:
        # Ensure we get the actual value, not a SQLAlchemy ColumnElement
        user_id = getattr(user, 'id', None)
        if not user_id:
            return False
        member = db_session.query(TowerMember).filter_by(
            tower_id=tower_id, user_id=user_id
        ).first()
        return member is not None
    finally:
        db_session.close()

def is_strict_tower_member(user, tower_id):
    """Tower membership WITHOUT the admin bypass.

    The Secret Vault is visible and accessible to tower members only -
    not even admins. Admins only manage who is a member (and who among
    the members may add/update/delete passwords).
    """
    if not user:
        return False
    user_id = getattr(user, 'id', None)
    if not user_id:
        return False
    db_session = get_db_session()
    try:
        member = db_session.query(TowerMember).filter_by(
            tower_id=tower_id, user_id=user_id
        ).first()
        return member is not None
    finally:
        db_session.close()

def can_manage_vault(user, tower_id):
    """True when the user is a tower member that an admin has granted
    password add/update/delete rights to. All other members are view-only."""
    if not user:
        return False
    user_id = getattr(user, 'id', None)
    if not user_id:
        return False
    db_session = get_db_session()
    try:
        member = db_session.query(TowerMember).filter_by(
            tower_id=tower_id, user_id=user_id
        ).first()
        return bool(member and member.can_manage_secrets)
    finally:
        db_session.close()

def is_tower_lead(user, tower_id):
    """True when the user is a member of this tower flagged as a lead.

    Deliberately strict - no admin bypass. This answers "is this person a
    lead OF this tower", which is not the same question as "may this person
    manage its membership"; that one is can_manage_members below.
    """
    if not user:
        return False
    user_id = getattr(user, 'id', None)
    if not user_id:
        return False
    db_session = get_db_session()
    try:
        member = db_session.query(TowerMember).filter_by(
            tower_id=tower_id, user_id=user_id
        ).first()
        return bool(member and member.is_lead)
    finally:
        db_session.close()

def can_manage_members(user, tower_id):
    """Who may add or remove members of a tower: an admin, or one of the
    tower's own leads. Naming the leads themselves stays admin-only, so a
    lead cannot quietly promote themselves a majority or unseat a peer."""
    if not user:
        return False
    return is_admin(user) or is_tower_lead(user, tower_id)

def display_name(user_obj):
    """A person's full name, falling back to the username."""
    if not user_obj:
        return ''
    full = f"{getattr(user_obj, 'firstname', '') or ''} {getattr(user_obj, 'lastname', '') or ''}".strip()
    return full or (getattr(user_obj, 'username', '') or '')

def _sync_tower_lead(db_session, tower_id):
    """Recompute the tower's cached tower_lead text from its lead members.

    tower_lead stays a plain string because a dozen read sites - the Excel and
    PDF exports, quality scoring, both architecture views, the People
    directory and the tower search's ilike - read it directly. The is_lead
    flags on tower_members are the truth; this keeps the display copy in step
    with them. The caller commits.
    """
    rows = (db_session.query(TowerMember, User)
            .join(User, User.id == TowerMember.user_id)
            .filter(TowerMember.tower_id == tower_id,
                    TowerMember.is_lead.is_(True))
            .order_by(User.firstname, User.lastname, User.username)
            .all())
    names = [display_name(u) for _, u in rows]
    tower = db_session.query(AppSupportTower).filter_by(id=tower_id).first()
    if tower is not None:
        tower.tower_lead = ', '.join(n for n in names if n)
    return names

def get_user_name(user_id):
    """Get user name by ID"""
    if not user_id:
        return "System"
    from models import User
    db_session = get_db_session()
    try:
        user = db_session.query(User).filter_by(id=user_id).first()
        return  f"{user.firstname} {user.lastname}" if user else "Unknown User"
    finally:
        db_session.close()

def log_audit(user, tower_name, module, operation, details=None):
    """Log audit entry for user operations"""
    if not user:
        return
    
    db_session = get_db_session()
    try:
        audit_entry = AuditLog(
            user_name=getattr(user, 'username', 'Unknown'),
            email=getattr(user, 'email', 'Unknown'),
            tower_name=tower_name,
            module=module,
            operation=operation,
            details=details
        )
        db_session.add(audit_entry)
        db_session.commit()
    except Exception as e:
        db_session.rollback()
        print(f"Error logging audit: {str(e)}")
    finally:
        db_session.close()

@application_support_bp.route('/')
def index():
    """Application Support module homepage - Tower Cards view"""
    user = get_current_user()
    
    
    db_session = get_db_session()
    try:
        # Get all active towers
        towers = db_session.query(AppSupportTower).filter_by(is_active=True).all()
        
        # Tower statistics via two grouped queries instead of five count
        # queries per tower (the homepage is hit on every module visit).
        app_counts = db_session.query(
            ApplicationDetails.tower_id,
            ApplicationDetails.business_criticality,
            func.count(ApplicationDetails.id),
        ).filter_by(is_active=True).group_by(
            ApplicationDetails.tower_id,
            ApplicationDetails.business_criticality,
        ).all()
        member_counts = dict(db_session.query(
            TowerMember.tower_id, func.count(TowerMember.id),
        ).group_by(TowerMember.tower_id).all())

        tower_stats = {
            tower.id: {
                'total_apps': 0,
                'total_users': member_counts.get(tower.id, 0),
                'bc1_count': 0,
                'bc2_count': 0,
                'bc3_count': 0,
            }
            for tower in towers
        }
        bc_keys = {
            BusinessCriticality.BC1: 'bc1_count',
            BusinessCriticality.BC2: 'bc2_count',
            BusinessCriticality.BC3: 'bc3_count',
        }
        for tower_id, criticality, count in app_counts:
            stats = tower_stats.get(tower_id)
            if stats is None:
                continue
            stats['total_apps'] += count
            if criticality in bc_keys:
                stats[bc_keys[criticality]] += count

        # Documentation quality per tower, plus one estate headline. Scored
        # in bulk (a handful of queries for the whole estate) rather than
        # per tower, because this page is hit on every module visit.
        apps_by_tower = quality.tower_applications(
            db_session, [tower.id for tower in towers])
        all_apps = [app for rows in apps_by_tower.values() for app in rows]
        app_cards = quality.score_applications(db_session, all_apps)
        tower_quality = {}
        for tower in towers:
            cards = [app_cards[app.id] for app in apps_by_tower.get(tower.id, [])
                     if app.id in app_cards]
            profile = quality.score_tower(
                tower, member_counts.get(tower.id, 0), len(cards))
            records = quality.rollup(cards)
            tower_quality[tower.id] = {
                'profile': profile,
                'records': records,
                # One call over the two halves, decided in quality.py so the
                # dashboard and the tower page can never disagree.
                'verdict': quality.tower_verdict(profile, records),
            }
        estate_quality = quality.rollup(list(app_cards.values()))

        return render_template('application_support/index.html',
                             user=user, towers=towers, tower_stats=tower_stats,
                             tower_quality=tower_quality,
                             estate_quality=estate_quality,
                             grade_scale=quality.grade_scale(),
                             quality_target=quality.DEFAULT_TARGET,
                             is_admin=is_admin(user))
    finally:
        db_session.close()

# Tower Management Routes (Admin Only)
@application_support_bp.route('/manage-towers')
@require_auth('admin')
def manage_towers():
    """Tower management page (admin only)"""
    user = get_current_user()
    
    
    
    
    db_session = get_db_session()
    try:
        towers = db_session.query(AppSupportTower).filter_by(is_active=True).all()
        return render_template('application_support/manage_towers.html', 
                             user=user, towers=towers)
    finally:
        db_session.close()

@application_support_bp.route('/tower/<int:tower_id>/manage-members')
@require_auth()
def manage_tower_members(tower_id):
    """Manage tower members (admins and the tower's own leads)."""
    user = get_current_user()

    if not can_manage_members(user, tower_id):
        flash('Access denied. Only an administrator or a lead of this tower '
              'can manage its members.', 'error')
        return redirect(url_for('application_support.tower_applications', tower_id=tower_id))

    db_session = get_db_session()
    try:
        tower = db_session.query(AppSupportTower).filter_by(id=tower_id, is_active=True).first()
        if not tower:
            flash('Tower not found', 'error')
            return redirect(url_for('application_support.index'))
        
        # Get current tower members
        
        current_members = db_session.query(TowerMember).filter_by(tower_id=tower_id).all()
        member_ids = [m.user_id for m in current_members]
        users_by_id = {
            u.id: u for u in db_session.query(User)
            .filter(User.id.in_(member_ids)).all()
        } if member_ids else {}
        member_users = []
        for member in current_members:
            user_obj = users_by_id.get(member.user_id)
            if user_obj:
                member_users.append({
                    'member_id': member.id,
                    'user_id': user_obj.id,
                    'username': user_obj.username,
                    'full_name': display_name(user_obj),
                    'email': user_obj.email,
                    'added_at': member.added_at,
                    'can_manage_secrets': bool(member.can_manage_secrets),
                    'is_lead': bool(member.is_lead)
                })
        # Leads first, then everyone else, each alphabetically - the page is
        # read top-down to answer "who runs this tower".
        member_users.sort(key=lambda m: (not m['is_lead'],
                                         (m['full_name'] or m['username']).lower()))
        
        # Get users for adding new members. Only ACTIVE accounts are offered -
        # a disabled (off-boarded) user keeps their name on existing records
        # but is never available for new assignments.
        all_users = db_session.query(User).filter_by(is_active=True).all()
        current_member_ids = [member['user_id'] for member in member_users]
        available_users = [u for u in all_users if u.id not in current_member_ids]
        
        return render_template('application_support/manage_tower_members.html', 
                             user=user, tower=tower, member_users=member_users,
                             available_users=available_users,
                             is_admin_user=is_admin(user),
                             lead_count=sum(1 for m in member_users if m['is_lead']))
    finally:
        db_session.close()

@application_support_bp.route('/tower/<int:tower_id>/add-member', methods=['POST'])
@require_auth()
def add_tower_member(tower_id):
    """Add user to tower (admins and the tower's own leads)."""
    user = get_current_user()

    if not can_manage_members(user, tower_id):
        flash('Access denied. Only an administrator or a lead of this tower '
              'can add members.', 'error')
        return redirect(url_for('application_support.tower_applications', tower_id=tower_id))

    # CSRF Protection
    csrf_token = request.form.get('csrf_token')
    if not validate_csrf_token(csrf_token):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_tower_members', tower_id=tower_id))
    
    user_id = request.form.get('user_id')
    if not user_id:
        flash('Please select a user to add', 'error')
        return redirect(url_for('application_support.manage_tower_members', tower_id=tower_id))
    
    db_session = get_db_session()
    try:
        # Check if user is already a member
        existing_member = db_session.query(TowerMember).filter_by(
            tower_id=tower_id, user_id=user_id
        ).first()
        
        if existing_member:
            flash('User is already a member of this tower', 'error')
        else:
            # Add new member
            new_member = TowerMember(
                tower_id=tower_id,
                user_id=user_id,
                added_by=getattr(user, 'id', None)
            )
            db_session.add(new_member)
            db_session.commit()
            tower_obj = db_session.query(AppSupportTower).filter_by(id=tower_id).first()
            added_user = db_session.query(User).filter_by(id=user_id).first()
            log_audit(user, tower_obj.tower_name if tower_obj else 'Unknown', 'Tower Member', 'INSERT', f'Added user {added_user.username if added_user else user_id} to tower')
            
            flash('User added to tower successfully', 'success')
            
    except Exception as e:
        db_session.rollback()
        flash(f'Error adding user to tower: {str(e)}', 'error')
    finally:
        db_session.close()
    
    return redirect(url_for('application_support.manage_tower_members', tower_id=tower_id))

@application_support_bp.route('/tower/<int:tower_id>/remove-member/<int:member_id>', methods=['POST'])
@require_auth()
def remove_tower_member(tower_id, member_id):
    """Remove user from tower (admins and the tower's own leads)."""
    user = get_current_user()

    if not can_manage_members(user, tower_id):
        flash('Access denied. Only an administrator or a lead of this tower '
              'can remove members.', 'error')
        return redirect(url_for('application_support.tower_applications', tower_id=tower_id))

    # CSRF Protection
    csrf_token = request.form.get('csrf_token')
    if not validate_csrf_token(csrf_token):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_tower_members', tower_id=tower_id))
    
    db_session = get_db_session()
    try:
        member = db_session.query(TowerMember).filter_by(
            id=member_id, tower_id=tower_id
        ).first()
        
        if member:
            # A lead may manage the tower's ordinary members, but unseating a
            # lead - themselves included - is an admin decision, so a tower can
            # never be left leaderless by the people who lead it.
            if not is_admin(user) and member.is_lead:
                flash('Only an administrator can remove a tower lead.', 'error')
                return redirect(url_for('application_support.manage_tower_members', tower_id=tower_id))

            was_lead = bool(member.is_lead)
            removed_user = db_session.query(User).filter_by(id=member.user_id).first()
            removed_name = removed_user.username if removed_user else member.user_id
            # Free whatever the Tower Summary grid had allocated to them, and
            # with it the support-team rows the grid wrote onto this tower's
            # applications. Leaving those behind would keep a person who no
            # longer has access listed as an application's primary owner.
            freed_cells, freed_rows = team_summary.release_member(
                db_session, tower_id, member.user_id,
                display_name(removed_user), getattr(removed_user, 'email', ''))
            db_session.delete(member)
            db_session.flush()
            if was_lead:
                _sync_tower_lead(db_session, tower_id)
            db_session.commit()
            tower_obj = db_session.query(AppSupportTower).filter_by(id=tower_id).first()
            log_audit(user, tower_obj.tower_name if tower_obj else 'Unknown',
                      'Tower Member', 'DELETE',
                      f'Removed user {removed_name} from tower '
                      f'({freed_cells} assignment(s) released, '
                      f'{freed_rows} support-team row(s) withdrawn)')
            if freed_cells:
                flash('User removed. {0} application assignment{1} released '
                      'and withdrawn from the application record{2}.'.format(
                          freed_cells, '' if freed_cells == 1 else 's',
                          '' if freed_rows == 1 else 's'), 'warning')
            else:
                flash('User removed from tower successfully', 'success')
        else:
            flash('Member not found', 'error')
            
    except Exception as e:
        db_session.rollback()
        flash(f'Error removing user from tower: {str(e)}', 'error')
    finally:
        db_session.close()
    
    return redirect(url_for('application_support.manage_tower_members', tower_id=tower_id))

@application_support_bp.route('/tower/<int:tower_id>/toggle-lead/<int:member_id>', methods=['POST'])
@require_auth('admin')
def toggle_tower_lead(tower_id, member_id):
    """Promote a tower member to lead, or stand them down (admin only).

    Leads are picked from the tower's own members and a tower may have
    several. Keeping this admin-only is what stops a lead from unseating a
    peer or promoting a majority of their own.
    """
    user = get_current_user()

    csrf_token = request.form.get('csrf_token')
    if not validate_csrf_token(csrf_token):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_tower_members', tower_id=tower_id))

    db_session = get_db_session()
    try:
        member = db_session.query(TowerMember).filter_by(id=member_id, tower_id=tower_id).first()
        if not member:
            flash('Member not found', 'error')
            return redirect(url_for('application_support.manage_tower_members', tower_id=tower_id))

        member.is_lead = not bool(member.is_lead)
        db_session.flush()
        _sync_tower_lead(db_session, tower_id)
        db_session.commit()

        tower_obj = db_session.query(AppSupportTower).filter_by(id=tower_id).first()
        target = db_session.query(User).filter_by(id=member.user_id).first()
        name = display_name(target) or (target.username if target else member.user_id)
        action = 'Made' if member.is_lead else 'Removed'
        log_audit(user, tower_obj.tower_name if tower_obj else 'Unknown', 'Tower Member',
                  'UPDATE', f'{action} {name} {"a" if member.is_lead else "as"} tower lead')
        flash(f'{name} is now a tower lead.' if member.is_lead
              else f'{name} is no longer a tower lead.', 'success')
    except Exception as e:
        db_session.rollback()
        flash(f'Error updating tower lead: {str(e)}', 'error')
    finally:
        db_session.close()

    return redirect(url_for('application_support.manage_tower_members', tower_id=tower_id))

@application_support_bp.route('/create-tower', methods=['GET', 'POST'])
@require_auth('admin')
def create_tower():
    """Create new tower (admin only)"""
    user = get_current_user()
    
    
    def _selectable_users():
        """Active accounts a lead can be chosen from. A disabled (off-boarded)
        user keeps their name on existing records but is never offered for a
        new assignment.

        Returned in the SAME shape as edit_tower's _member_choices() so both
        forms can render the one lead picker - see
        templates/application_support/_lead_picker.html. Two near-identical
        blocks of markup is how the two pages drifted apart in the first
        place.
        """
        db_session = get_db_session()
        try:
            users = db_session.query(User).filter_by(is_active=True).order_by(
                User.firstname, User.lastname, User.username).all()
            return [{'user_id': u.id,
                     'name': display_name(u) or u.username,
                     'username': u.username,
                     'email': u.email,
                     # Nothing is pre-selected on a tower that does not exist
                     # yet; the picker takes its initial state from this.
                     'is_lead': False} for u in users]
        finally:
            db_session.close()

    if request.method == 'POST':
        # CSRF Protection
        csrf_token = request.form.get('csrf_token')
        if not validate_csrf_token(csrf_token):
            flash('Invalid security token. Please try again.', 'error')
            return render_template('application_support/create_tower.html', user=user,
                                   lead_choices=_selectable_users())
        
        tower_name = request.form.get('tower_name')
        short_summary = request.form.get('short_summary')
        # Leads are people, not free text: one or more user accounts, each of
        # whom is enrolled as a member of the tower at the same time, because
        # a lead is always a member.
        lead_ids = [int(v) for v in request.form.getlist('lead_user_ids') if str(v).isdigit()]
        tower_group_names = request.form.get('tower_group_names')
        
        if not tower_name:
            flash('Tower name is required', 'error')
            return render_template('application_support/create_tower.html', user=user,
                                   lead_choices=_selectable_users())
        if not lead_ids:
            flash('Select at least one tower lead', 'error')
            return render_template('application_support/create_tower.html', user=user,
                                   lead_choices=_selectable_users())
        
        db_session = get_db_session()
        try:
            tower = AppSupportTower(
                tower_name=tower_name,
                short_summary=short_summary or '',
                tower_lead='',
                tower_group_names=(tower_group_names or '').strip(),
                created_by=getattr(user, 'id', None),
                updated_by=getattr(user, 'id', None)
            )
            db_session.add(tower)
            db_session.flush()

            valid_ids = {u.id for u in db_session.query(User)
                         .filter(User.id.in_(lead_ids), User.is_active.is_(True)).all()}
            for lead_id in lead_ids:
                if lead_id not in valid_ids:
                    continue
                db_session.add(TowerMember(
                    tower_id=tower.id, user_id=lead_id, is_lead=True,
                    added_by=getattr(user, 'id', None)))
            db_session.flush()
            _sync_tower_lead(db_session, tower.id)
            db_session.commit()
            log_audit(user, tower_name, 'Tower', 'INSERT',
                      f'Created tower with lead(s): {tower.tower_lead or "none"}')
            
            flash(f'Tower "{tower_name}" created successfully!', 'success')
            return redirect(url_for('application_support.index'))
        except Exception as e:
            db_session.rollback()
            flash(f'Error creating tower: {str(e)}', 'error')
            return render_template('application_support/create_tower.html', user=user,
                                   lead_choices=_selectable_users())
        finally:
            db_session.close()
    
    return render_template('application_support/create_tower.html', user=user,
                           lead_choices=_selectable_users())

@application_support_bp.route('/edit-tower/<int:tower_id>', methods=['GET', 'POST'])
@require_auth('admin')
def edit_tower(tower_id):
    """Edit tower (admin only)"""
    user = get_current_user()
    
    
    db_session = get_db_session()
    try:
        tower = db_session.query(AppSupportTower).filter_by(id=tower_id, is_active=True).first()
        if not tower:
            flash('Tower not found', 'error')
            return redirect(url_for('application_support.manage_towers'))

        def _member_choices():
            """The tower's own members - the only people a lead can be."""
            rows = (db_session.query(TowerMember, User)
                    .join(User, User.id == TowerMember.user_id)
                    .filter(TowerMember.tower_id == tower_id)
                    .order_by(User.firstname, User.lastname, User.username).all())
            return [{'user_id': u.id, 'name': display_name(u) or u.username,
                     'username': u.username, 'email': u.email,
                     'is_lead': bool(m.is_lead)} for m, u in rows]

        def _lead_context(choices):
            return {'member_choices': choices,
                    'unmatched_lead': _unmatched_lead(choices)}

        def _unmatched_lead(choices):
            """A legacy tower_lead name that belongs to nobody in the member
            list. The start-up backfill leaves these as text; saying so here is
            what stops this page from quietly dropping the name on save."""
            if any(c['is_lead'] for c in choices):
                return ''
            return (tower.tower_lead or '').strip()

        if request.method == 'POST':
            # CSRF Protection
            csrf_token = request.form.get('csrf_token')
            if not validate_csrf_token(csrf_token):
                flash('Invalid security token. Please try again.', 'error')
                return render_template('application_support/edit_tower.html', user=user,
                                       tower=tower, **_lead_context(_member_choices()))
            
            # Get form data with proper validation
            tower_name = request.form.get('tower_name')
            short_summary = request.form.get('short_summary')
            # Leads are chosen from the tower's members; anything else posted
            # is ignored rather than trusted.
            lead_ids = {int(v) for v in request.form.getlist('lead_user_ids') if str(v).isdigit()}
            tower_group_names = request.form.get('tower_group_names')
            
            if not tower_name:
                flash('Tower name is required', 'error')
                return render_template('application_support/edit_tower.html', user=user,
                                       tower=tower, **_lead_context(_member_choices()))
            
            # Update tower attributes
            tower.tower_name = tower_name
            tower.short_summary = short_summary or ''
            tower.tower_group_names = (tower_group_names or '').strip()
            tower.updated_by = getattr(user, 'id', None)

            members = db_session.query(TowerMember).filter_by(tower_id=tower_id).all()
            for member in members:
                member.is_lead = member.user_id in lead_ids
            db_session.flush()
            _sync_tower_lead(db_session, tower_id)
            
            db_session.commit()
            log_audit(user, tower.tower_name, 'Tower', 'UPDATE',
                      f'Updated tower: {tower.tower_name}; lead(s): {tower.tower_lead or "none"}')
            flash(f'Tower "{tower.tower_name}" updated successfully!', 'success')
            return redirect(url_for('application_support.manage_towers'))
        
        return render_template('application_support/edit_tower.html', user=user,
                               tower=tower, **_lead_context(_member_choices()))
    except Exception as e:
        db_session.rollback()
        flash(f'Error updating tower: {str(e)}', 'error')
        return redirect(url_for('application_support.manage_towers'))
    finally:
        db_session.close()

@application_support_bp.route('/delete-tower/<int:tower_id>', methods=['POST'])
@require_auth('admin')
def delete_tower(tower_id):
    """Delete tower (admin only)"""
    user = get_current_user()
    
    
    # CSRF Protection
    csrf_token = request.form.get('csrf_token') or request.json.get('csrf_token') if request.json else None
    if not validate_csrf_token(csrf_token):
        return jsonify({'error': 'Invalid security token'}), 403
    
    db_session = get_db_session()
    try:
        tower = db_session.query(AppSupportTower).filter_by(id=tower_id).first()
        if not tower:
            return jsonify({'error': 'Tower not found'}), 404
        
        # Check if tower has applications
        app_count = db_session.query(ApplicationDetails).filter_by(tower_id=tower_id, is_active=True).count()
        if app_count > 0:
            return jsonify({'error': f'Cannot delete tower. It contains {app_count} active applications.'}), 400
        
        tower.is_active = False
        tower.updated_by = getattr(user, 'id', None)
        db_session.commit()
        
        return jsonify({'success': True, 'message': f'Tower "{tower.tower_name}" deleted successfully'})
    except Exception as e:
        db_session.rollback()
        return jsonify({'error': f'Error deleting tower: {str(e)}'}), 500
    finally:
        db_session.close()

# Tower Application List
@application_support_bp.route('/tower/<int:tower_id>/applications')
def tower_applications(tower_id):
    """View applications in a tower grouped by business criticality"""
    user = get_current_user()
    
    db_session = get_db_session()
    try:
        tower = db_session.query(AppSupportTower).filter_by(id=tower_id, is_active=True).first()
        if not tower:
            flash('Tower not found', 'error')
            return redirect(url_for('application_support.index'))
        
        # Check if user can view this tower (admin or tower member)
        can_edit = user and (is_admin(user) or is_tower_member(user, tower_id))
        
        # Get applications grouped by business criticality. joinedload keeps
        # the category chip on each card from costing a query per card.
        def _apps_of(bc):
            return (db_session.query(ApplicationDetails)
                    .options(joinedload(ApplicationDetails.category))
                    .filter_by(tower_id=tower_id, is_active=True,
                               business_criticality=bc)
                    .all())

        bc1_apps = _apps_of(BusinessCriticality.BC1)
        bc2_apps = _apps_of(BusinessCriticality.BC2)
        bc3_apps = _apps_of(BusinessCriticality.BC3)
        
        # Add created/updated by names
        for app_list in [bc1_apps, bc2_apps, bc3_apps]:
            for app in app_list:
                app.created_by_name = get_user_name(app.created_by)
                app.updated_by_name = get_user_name(app.updated_by)
        
        # Secret Vault is for tower members only - admins do NOT get access
        is_vault_member = is_strict_tower_member(user, tower_id)

        # Documentation quality: the tower's own profile card, and a
        # scorecard per application so each card can show where it stands.
        all_apps = bc1_apps + bc2_apps + bc3_apps
        app_quality = quality.score_applications(db_session, all_apps)
        member_count = (db_session.query(func.count(TowerMember.id))
                        .filter_by(tower_id=tower_id).scalar() or 0)
        tower_profile = quality.score_tower(tower, member_count, len(all_apps))
        records_quality = quality.rollup(list(app_quality.values()))
        verdict = quality.tower_verdict(tower_profile, records_quality)

        # Distinct categories present in this tower, for the filter strip.
        tower_categories = categories.group_by_category(all_apps)

        # Tower Summary - the team, the application count and who supports
        # what. Built from the SAME report the full Tower Summary page
        # renders, so the headline card can never disagree with the page it
        # links to.
        summary = team_summary.build(db_session, tower, all_apps)

        return render_template('application_support/tower_detail.html',
                             user=user, tower=tower, can_edit=can_edit,
                             can_manage_members=can_manage_members(user, tower_id),
                             tower_categories=tower_categories,
                             is_vault_member=is_vault_member,
                             app_quality=app_quality,
                             tower_profile=tower_profile,
                             records_quality=records_quality,
                             tower_verdict=verdict,
                             grade_scale=quality.grade_scale(),
                             summary=summary,
                             bc1_apps=bc1_apps, bc2_apps=bc2_apps, bc3_apps=bc3_apps)
    finally:
        db_session.close()

# Application Management Routes
@application_support_bp.route('/tower/<int:tower_id>/add-application', methods=['GET', 'POST'])
def add_application(tower_id):
    """Add new application to tower"""
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))
    
    # Check if user can add applications to this tower
    if not (is_admin(user) or is_tower_member(user, tower_id)):
        flash('Access denied. You are not a member of this tower.', 'error')
        return redirect(url_for('application_support.tower_applications', tower_id=tower_id))
    
    db_session = get_db_session()
    try:
        tower = db_session.query(AppSupportTower).filter_by(id=tower_id, is_active=True).first()
        if not tower:
            flash('Tower not found', 'error')
            return redirect(url_for('application_support.index'))
        
        if request.method == 'POST':
            # CSRF Protection
            csrf_token = request.form.get('csrf_token')
            if not validate_csrf_token(csrf_token):
                flash('Invalid security token. Please try again.', 'error')
                return render_template('application_support/add_application.html',
                                     user=user, tower=tower,
                                     business_criticalities=BusinessCriticality,
                                     flow_directions=FlowDirection,
                                     team_roles=TeamRole, user_roles=UserRole,
                                     category_options=_category_options(db_session),
                                     selected_category_id=_posted_category_id(request),
                             app_group_users=_application_group_users(db_session, tower_id))
            
            # Basic application details
            application_name = request.form.get('application_name')
            business_criticality = request.form.get('business_criticality')
            application_summary = request.form.get('application_summary')
            accessibility = request.form.get('accessibility')

            # Optional by design - see categories.resolve_selection(). Only a
            # value the browser made up is rejected.
            category_id, category_error = categories.resolve_selection(
                db_session, request.form.get('category_id'))
            if category_error:
                flash(category_error, 'error')
                return render_template('application_support/add_application.html',
                                     user=user, tower=tower,
                                     business_criticalities=BusinessCriticality,
                                     flow_directions=FlowDirection,
                                     team_roles=TeamRole, user_roles=UserRole,
                                     category_options=_category_options(db_session),
                                     selected_category_id=None,
                             app_group_users=_application_group_users(db_session, tower_id))

            if not application_name or not business_criticality:
                flash('Application name and business criticality are required', 'error')
                return render_template('application_support/add_application.html',
                                     user=user, tower=tower,
                                     business_criticalities=BusinessCriticality,
                                     flow_directions=FlowDirection,
                                     team_roles=TeamRole, user_roles=UserRole,
                                     category_options=_category_options(db_session),
                                     selected_category_id=_posted_category_id(request),
                             app_group_users=_application_group_users(db_session, tower_id))
            
            try:
                # Create application
                app = ApplicationDetails(
                    tower_id=tower_id,
                    application_name=application_name,
                    business_criticality=BusinessCriticality(business_criticality),
                    category_id=category_id,
                    application_summary=application_summary or '',
                    accessibility=accessibility or '',
                    created_by=getattr(user, 'id', None),
                    updated_by=getattr(user, 'id', None)
                )
                db_session.add(app)
                db_session.flush()  # Get the ID
                
                # Add related data (server details, support team, etc.)
                _add_application_related_data(request, app.id, db_session,
                                              tower_id)
                
                db_session.commit()
                tower_obj = db_session.query(AppSupportTower).filter_by(id=tower_id).first()
                log_audit(user, tower_obj.tower_name if tower_obj else 'Unknown', 'Application', 'INSERT', f'Created application: {application_name}')
                
                flash(f'Application "{application_name}" added successfully!', 'success')
                _flash_quality_nudge(db_session, app)
                return redirect(url_for('application_support.tower_applications', tower_id=tower_id))
                
            except Exception as e:
                db_session.rollback()
                flash(f'Error adding application: {str(e)}', 'error')
        
        return render_template('application_support/add_application.html',
                             user=user, tower=tower,
                             business_criticalities=BusinessCriticality,
                             flow_directions=FlowDirection,
                             team_roles=TeamRole, user_roles=UserRole,
                             category_options=_category_options(db_session),
                             selected_category_id=_posted_category_id(request),
                             app_group_users=_application_group_users(db_session, tower_id))
    finally:
        db_session.close()

def _category_options(db_session, include_id=None):
    """
    The values for the application form's Category dropdown.

    Seeds on the way past so the very first "Add Application" already offers
    the starter list, rather than an empty dropdown until an administrator
    happens to open the admin screen.

    ``include_id`` keeps an application's own category in the list even after
    it has been retired - see categories.list_categories().
    """
    categories.ensure_seeded(db_session)
    return categories.list_categories(db_session, include_id=include_id)


def _posted_category_id(req):
    """
    The category the user had picked, so a re-rendered form keeps it.

    Returns None on a GET or when nothing was chosen; the value is only ever
    used to pre-select an <option>, never to write, so an unparseable one is
    simply dropped.
    """
    if req.method != 'POST':
        return None
    try:
        return int((req.form.get('category_id') or '').strip())
    except (TypeError, ValueError):
        return None


def _application_scorecard(db_session, app):
    """Documentation quality for one saved application (see quality.py)."""
    related = quality.load_related(db_session, [app.id]).get(app.id)
    return quality.score_application(app, related)


def _flash_quality_nudge(db_session, app):
    """
    Tell the team what is still thin in the record they just saved.

    Deliberately a warning and not a validation error: the form is long, it
    is filled in over days, and blocking the save would only teach people to
    type "NA" into every box. It names the top gaps rather than a bare
    percentage, because a number on its own tells nobody what to go and fix.
    """
    try:
        card = _application_scorecard(db_session, app)
    except Exception as error:            # never fail a save over the metric
        print('Error scoring application quality: {0}'.format(error))
        return
    if card['meets_target'] and not card['gaps']:
        return
    shown = card['gaps'][:2]
    remaining = len(card['gaps']) - len(shown)
    message = ('Record quality {0}% ({1}, target {2}% for {3}). Still to '
               'complete: {4}'.format(card['percent'], card['grade'],
                                      card['target'],
                                      card['criticality'] or 'this application',
                                      ' '.join(shown)))
    if remaining > 0:
        message += ' (+{0} more on the Quality tab)'.format(remaining)
    flash(message, 'warning' if not card['meets_target'] else 'info')


def _application_group_users(db_session, tower_id):
    """
    Active users offered as Support Team member suggestions for one
    application. Each entry carries the display name stored on the
    SupportTeam row and the account email used to auto-fill the email field
    (and to match support membership in Resource Utilization's BAU load).

    Scoped to the MEMBERS OF THE APPLICATION'S TOWER, not to every account
    in the application. An application is supported by the tower that owns
    it, so offering the whole user base invited names from towers with no
    stake in it - and a mis-picked name then travels into the tower's
    allocation grid and Resource Utilization's BAU load.

    Membership is the tower_members table, which is the same list the
    Manage Members page maintains and the same one is_tower_member() gates
    access on - so the suggestions and the access rules cannot disagree.

    The member field itself stays free text. This narrows what is OFFERED,
    it does not reject what is typed: a contractor or a cross-tower
    specialist who has no account here still has to be recordable, and the
    forms have always allowed that (the email is then entered by hand).
    A tower with no members yet therefore yields an empty list rather than
    a blocked form; the templates say so under the field.
    """
    users = (db_session.query(User)
             .join(TowerMember, TowerMember.user_id == User.id)
             .filter(TowerMember.tower_id == tower_id,
                     User.is_active.is_(True))
             .order_by(User.firstname, User.lastname).all())
    return [{
        'name': (f"{(u.firstname or '').capitalize()} "
                 f"{(u.lastname or '').capitalize()}".strip() or u.username),
        'email': u.email or '',
    } for u in users]


def _norm_hostname(name):
    """Lower-cased, trimmed, FQDN-stripped hostname - the same join rule as
    tools/export_infrastructure_report.py uses against server_data."""
    return server_sync.norm_hostname(name)


@application_support_bp.route('/api/server-suggestions')
def server_suggestions():
    """Type-ahead source for server-name fields on the add / edit
    application forms (Server Details + External Interfaces).

    Searches the Utility module's Server Search estate list (server_data)
    by hostname substring and returns [{name, location, os, environment}] so
    the form can auto-fill Location / OS / Environment when the user picks a
    known server. The three values are built by server_sync, so the form
    fills exactly what the post-import re-sync would later write.
    Deduplicated on the normalised hostname, capped at 15 entries.
    """
    user = get_current_user()
    if not user:
        return jsonify([]), 401
    q = (request.args.get('q') or '').strip()
    if len(q) < 2:
        return jsonify([])
    like = '%{}%'.format(q.replace('!', '!!').replace('%', '!%')
                          .replace('_', '!_'))
    db_session = get_db_session()
    try:
        rows = (db_session.query(ServerData)
                .filter(ServerData.server_name.isnot(None),
                        ServerData.server_name.ilike(like, escape='!'))
                .order_by(ServerData.server_name)
                .limit(60).all())
        seen, out = set(), []
        for srv in rows:
            key = _norm_hostname(srv.server_name)
            if not key or key in seen:
                continue
            seen.add(key)
            out.append(server_sync.estate_entry(srv))
            if len(out) >= 15:
                break
        return jsonify(out)
    finally:
        db_session.close()


def _add_application_related_data(request, application_id, db_session,
                                  tower_id):
    """Helper function to add all related application data.

    `tower_id` scopes the Support Team email fallback below to the same
    people the form offered - see _application_group_users()."""
    
    # Server Details
    server_names = request.form.getlist('server_name[]')
    server_locations = request.form.getlist('server_location[]')
    server_os = request.form.getlist('server_os[]')
    server_env_descriptions = request.form.getlist('server_env_description[]')
    
    for i, name in enumerate(server_names):
        if name.strip():
            server = ServerDetails(
                application_id=application_id,
                server_name=name,
                location=server_locations[i] if i < len(server_locations) else '',
                operating_system=server_os[i] if i < len(server_os) else '',
                environment_description=server_env_descriptions[i] if i < len(server_env_descriptions) else ''
            )
            db_session.add(server)
    
    # Support Team
    support_names = request.form.getlist('support_member_name[]')
    support_roles = request.form.getlist('support_role[]')
    support_emails = request.form.getlist('support_email[]')

    # Members are usually picked from the user-account suggestions and the
    # form auto-fills their account email. Server-side fallback (e.g. JS
    # off): resolve a blank email from the matching user account so
    # Resource Utilization's support-membership match keeps working.
    name_to_email = {u['name'].lower(): u['email']
                     for u in _application_group_users(db_session, tower_id)
                     if u['email']}

    for i, name in enumerate(support_names):
        if name.strip():
            email = support_emails[i] if i < len(support_emails) else ''
            if not (email or '').strip():
                email = name_to_email.get(name.strip().lower(), '')
            team_member = SupportTeam(
                application_id=application_id,
                member_name=name,
                role=TeamRole(support_roles[i]) if i < len(support_roles) else TeamRole.TEAM_MEMBER,
                email=email
            )
            db_session.add(team_member)
    
    # Business Users
    business_names = request.form.getlist('business_user_name[]')
    business_roles = request.form.getlist('business_user_role[]')
    business_emails = request.form.getlist('business_user_email[]')
    
    for i, name in enumerate(business_names):
        if name.strip():
            business_user = BusinessUsers(
                application_id=application_id,
                user_name=name,
                role=UserRole(business_roles[i]) if i < len(business_roles) else UserRole.TEAM_MEMBER,
                email=business_emails[i] if i < len(business_emails) else ''
            )
            db_session.add(business_user)
    
    # Vendor Details
    vendor_names = request.form.getlist('vendor_name[]')
    vendor_emails = request.form.getlist('vendor_email[]')
    vendor_bespoke = request.form.getlist('vendor_is_bespoke[]')
    
    for i, name in enumerate(vendor_names):
        if name.strip():
            vendor = VendorDetails(
                application_id=application_id,
                vendor_name=name,
                email=vendor_emails[i] if i < len(vendor_emails) else '',
                is_bespoke=(str(i) in vendor_bespoke or vendor_bespoke[i]=='1') if i < len(vendor_bespoke) else False
            )
            db_session.add(vendor)
    
    # External Interfaces
    interface_names = request.form.getlist('interface_name[]')
    interface_directions = request.form.getlist('interface_flow_direction[]')
    interface_connectivity = request.form.getlist('interface_connectivity_type[]')
    interface_servers = request.form.getlist('interface_external_server[]')
    interface_descriptions = request.form.getlist('interface_description[]')
    interface_contacts = request.form.getlist('interface_contact[]')
    
    for i, name in enumerate(interface_names):
        if name.strip():
            interface = ExternalInterfaces(
                application_id=application_id,
                interface_name=name,
                flow_direction=FlowDirection(interface_directions[i]) if i < len(interface_directions) else FlowDirection.INBOUND,
                connectivity_type=interface_connectivity[i] if i < len(interface_connectivity) else '',
                external_server=interface_servers[i] if i < len(interface_servers) else '',
                description=interface_descriptions[i] if i < len(interface_descriptions) else '',
                contact=interface_contacts[i] if i < len(interface_contacts) else ''
            )
            db_session.add(interface)
    
    # Individual Jobs
    _add_individual_jobs(request, application_id, db_session)
    
    # Suite Jobs
    _add_suite_jobs(request, application_id, db_session)

def _add_individual_jobs(request, application_id, db_session):
    """Add individual jobs"""
    job_names = request.form.getlist('individual_job_name[]')
    job_frequencies = request.form.getlist('individual_job_frequency[]')
    job_short_descriptions = request.form.getlist('individual_job_short_desc[]')
    job_full_descriptions = request.form.getlist('individual_job_full_desc[]')
    job_user_profiles = request.form.getlist('individual_job_user_profile[]')
    job_prerequisites = request.form.getlist('individual_job_prerequisites[]')
    job_scripts = request.form.getlist('individual_job_script[]')
    job_failure_checks = request.form.getlist('individual_job_failure_checks[]')
    job_manual_steps = request.form.getlist('individual_job_manual_steps[]')
    
    for i, name in enumerate(job_names):
        if name.strip():
            job = IndividualJobs(
                application_id=application_id,
                job_name=name,
                frequency=job_frequencies[i] if i < len(job_frequencies) else '',
                short_description=job_short_descriptions[i] if i < len(job_short_descriptions) else '',
                full_description=job_full_descriptions[i] if i < len(job_full_descriptions) else '',
                user_profile=job_user_profiles[i] if i < len(job_user_profiles) else '',
                prerequisites=job_prerequisites[i] if i < len(job_prerequisites) else '',
                script=job_scripts[i] if i < len(job_scripts) else '',
                failure_checks=job_failure_checks[i] if i < len(job_failure_checks) else '',
                manual_execution_steps=job_manual_steps[i] if i < len(job_manual_steps) else ''
            )
            db_session.add(job)

def _add_suite_jobs(request, application_id, db_session):
    """Add suite jobs"""
    suite_names = request.form.getlist('suite_name[]')
    suite_job_names = request.form.getlist('suite_job_name[]')
    suite_job_frequencies = request.form.getlist('suite_job_frequency[]')
    suite_job_short_descriptions = request.form.getlist('suite_job_short_desc[]')
    suite_job_full_descriptions = request.form.getlist('suite_job_full_desc[]')
    suite_job_user_profiles = request.form.getlist('suite_job_user_profile[]')
    suite_job_prerequisites = request.form.getlist('suite_job_prerequisites[]')
    suite_job_scripts = request.form.getlist('suite_job_script[]')
    suite_job_failure_checks = request.form.getlist('suite_job_failure_checks[]')
    suite_job_manual_steps = request.form.getlist('suite_job_manual_steps[]')
    
    for i, suite_name in enumerate(suite_names):
        if suite_name.strip():
            job = SuiteJobs(
                application_id=application_id,
                suite_name=suite_name,
                job_name=suite_job_names[i] if i < len(suite_job_names) else '',
                frequency=suite_job_frequencies[i] if i < len(suite_job_frequencies) else '',
                short_description=suite_job_short_descriptions[i] if i < len(suite_job_short_descriptions) else '',
                full_description=suite_job_full_descriptions[i] if i < len(suite_job_full_descriptions) else '',
                user_profile=suite_job_user_profiles[i] if i < len(suite_job_user_profiles) else '',
                prerequisites=suite_job_prerequisites[i] if i < len(suite_job_prerequisites) else '',
                script=suite_job_scripts[i] if i < len(suite_job_scripts) else '',
                failure_checks=suite_job_failure_checks[i] if i < len(suite_job_failure_checks) else '',
                manual_execution_steps=suite_job_manual_steps[i] if i < len(suite_job_manual_steps) else ''
            )
            db_session.add(job)

# Application Details and Management Routes
@application_support_bp.route('/application/<int:app_id>')
def view_application(app_id):
    """View application details with all sections"""
    user = get_current_user()
    
    db_session = get_db_session()
    try:
        app = db_session.query(ApplicationDetails).filter_by(id=app_id, is_active=True).first()
        if not app:
            flash('Application not found', 'error')
            return redirect(url_for('application_support.index'))
        
        # Check if user can view this application
        can_edit = user and (is_admin(user) or is_tower_member(user, app.tower_id))
        
        # Get all related data
        server_details = db_session.query(ServerDetails).filter_by(application_id=app_id).all()
        support_team = db_session.query(SupportTeam).filter_by(application_id=app_id).all()
        business_users = db_session.query(BusinessUsers).filter_by(application_id=app_id).all()
        vendor_details = db_session.query(VendorDetails).filter_by(application_id=app_id).all()
        external_interfaces = db_session.query(ExternalInterfaces).filter_by(application_id=app_id).all()
        individual_jobs = db_session.query(IndividualJobs).filter_by(application_id=app_id).all()
        suite_jobs = db_session.query(SuiteJobs).filter_by(application_id=app_id).all()
        file_inventory = db_session.query(FileInventory).filter_by(application_id=app_id).all()
        tasks = db_session.query(ApplicationTask).filter_by(application_id=app_id).order_by(ApplicationTask.created_at.desc()).all()
        critical_issues = db_session.query(CriticalIssue).filter_by(application_id=app_id).order_by(CriticalIssue.created_at.desc()).all()
        
        # Add creator names
        app.created_by_name = get_user_name(app.created_by)
        app.updated_by_name = get_user_name(app.updated_by)
        #created_by_name = f"{app.created_user.firstname} {app.created_user.lastname}"
        #updated_by_name = f"{app.updated_user.firstname} {app.updated_user.lastname}"

        # Version-trail size per file, for the badge on the Files tab.
        file_version_counts = file_versions.version_counts(
            db_session, FILE_ENTITY, [f.id for f in file_inventory])

        # Technical Details tab: the recorded stack plus the standards
        # checklist sections its selections make relevant.
        tech_stack = tech_details.load_stack(db_session, app_id)
        stack_flat = tech_details.stack_rows(db_session, app_id)
        std_sections = tech_details.build_sections(
            db_session, stack_flat,
            tech_details.load_compliance(db_session, app_id))
        std_summary = tech_details.overall_summary(std_sections)
        tech_count = len(stack_flat)

        # Documentation quality. Every row it grades is already loaded above,
        # so the scorecard costs no extra queries here.
        app_quality = quality.score_application(app, {
            'servers': server_details,
            'support_team': support_team,
            'business_users': business_users,
            'vendors': vendor_details,
            'tech_stack': stack_flat,
        }, {
            'jobs': len(individual_jobs) + len(suite_jobs),
            'interfaces': len(external_interfaces),
            'tasks': len(tasks),
            'issues': len(critical_issues),
            'files': len(file_inventory),
        })

        # The Support Team card shows both halves together but says which is
        # which: typed on this record, or allocated by the tower lead.
        typed_team, assigned_team = team_summary.split_support_team(
            support_team)

        return render_template('application_support/view_application_v1.html',
                             user=user, app=app, can_edit=can_edit,
                             typed_team=typed_team, assigned_team=assigned_team,
                             assignment_source=team_summary.SOURCE_ASSIGNMENT,
                             server_details=server_details, support_team=support_team,
                             business_users=business_users, vendor_details=vendor_details,
                             external_interfaces=external_interfaces, individual_jobs=individual_jobs,
                             suite_jobs=suite_jobs, file_inventory=file_inventory,
                             file_version_counts=file_version_counts,
                             tasks=tasks, critical_issues=critical_issues,
                             tech_stack=tech_stack, tech_count=tech_count,
                             app_quality=app_quality,
                             quality_rules=quality,
                             std_sections=std_sections, std_summary=std_summary,
                             category_meta=tech_details.CATEGORY_META,
                             status_badge=tech_details.STATUS_BADGE,
                             get_user_name=get_user_name)
    finally:
        db_session.close()

# Application Edit Route
@application_support_bp.route('/application/<int:app_id>/edit', methods=['GET', 'POST'])
def edit_application(app_id):
    """Edit application details"""
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))
    
    db_session = get_db_session()
    try:
        app = db_session.query(ApplicationDetails).filter_by(id=app_id, is_active=True).first()
        if not app:
            flash('Application not found', 'error')
            return redirect(url_for('application_support.index'))
        
        # Check if user can edit this application
        if not (is_admin(user) or is_tower_member(user, app.tower_id)):
            flash('Access denied. You are not a member of this tower.', 'error')
            return redirect(url_for('application_support.view_application', app_id=app_id))
        
        tower = db_session.query(AppSupportTower).filter_by(id=app.tower_id).first()
        
        if request.method == 'POST':
            # CSRF Protection
            csrf_token = request.form.get('csrf_token')
            if not validate_csrf_token(csrf_token):
                flash('Invalid security token. Please try again.', 'error')
                return redirect(request.url)
            
            # Update basic application details
            application_name = request.form.get('application_name')
            business_criticality = request.form.get('business_criticality')
            application_summary = request.form.get('application_summary')
            accessibility = request.form.get('accessibility')

            # The application's CURRENT category is passed as current_id so a
            # record classified under a since-retired category can still be
            # saved without being silently re-classified.
            category_id, category_error = categories.resolve_selection(
                db_session, request.form.get('category_id'),
                current_id=app.category_id)
            if category_error:
                flash(category_error, 'error')
                return redirect(request.url)

            if not application_name or not business_criticality:
                flash('Application name and business criticality are required', 'error')
                return redirect(request.url)
            
            try:
                # Update application details
                app.application_name = application_name
                app.business_criticality = BusinessCriticality(business_criticality)
                app.category_id = category_id
                app.application_summary = application_summary
                app.accessibility = accessibility
                app.updated_by = user.id
                app.updated_at = datetime.now()
                
                # Delete existing related data and add updated data
                _delete_application_related_data(app_id, db_session)
                _add_application_related_data(request, app_id, db_session,
                                              app.tower_id)
                
                db_session.commit()
                log_audit(user, tower.tower_name, 'Application', 'UPDATE', f'Updated application: {application_name}')
                flash('Application updated successfully!', 'success')
                _flash_quality_nudge(db_session, app)
                return redirect(url_for('application_support.view_application', app_id=app_id))
                
            except Exception as e:
                db_session.rollback()
                flash(f'Error updating application: {str(e)}', 'error')
        
        # Get all related data for editing
        server_details = db_session.query(ServerDetails).filter_by(application_id=app_id).all()
        support_team = db_session.query(SupportTeam).filter_by(application_id=app_id).all()
        business_users = db_session.query(BusinessUsers).filter_by(application_id=app_id).all()
        vendor_details = db_session.query(VendorDetails).filter_by(application_id=app_id).all()
        external_interfaces = db_session.query(ExternalInterfaces).filter_by(application_id=app_id).all()
        individual_jobs = db_session.query(IndividualJobs).filter_by(application_id=app_id).all()
        suite_jobs = db_session.query(SuiteJobs).filter_by(application_id=app_id).all()
        
        # The gaps banner at the top of the form: the same scorecard the
        # view page shows, so the team edits with the shortfall in sight.
        app_quality = _application_scorecard(db_session, app)

        # The form edits the TYPED rows only. The tower lead's allocation is
        # rebuilt from the Tower Summary grid, so rendering it as inputs here
        # would let this page fork it - it is shown read-only instead.
        support_team, assigned_team = team_summary.split_support_team(
            support_team)

        return render_template('application_support/edit_application.html',
                             user=user, app=app, tower=tower,
                             app_quality=app_quality,
                             assigned_team=assigned_team,
                             server_details=server_details, support_team=support_team,
                             business_users=business_users, vendor_details=vendor_details,
                             external_interfaces=external_interfaces, individual_jobs=individual_jobs,
                             suite_jobs=suite_jobs,
                             business_criticalities=BusinessCriticality,
                             flow_directions=FlowDirection,
                             team_roles=TeamRole, user_roles=UserRole,
                             category_options=_category_options(
                                 db_session, include_id=app.category_id),
                             selected_category_id=app.category_id,
                             app_group_users=_application_group_users(
                                 db_session, app.tower_id))
    finally:
        db_session.close()

# Modified delete_application function to ensure cascade deletion
@application_support_bp.route('/applications/<int:app_id>/delete', methods=['POST'])
def delete_application(app_id):
    """Delete application and all related data - admin only"""
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))

    # CSRF Protection
    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.view_application', app_id=app_id))

    db_session = get_db_session()
    try:
        application = db_session.query(ApplicationDetails).filter_by(id=app_id).first()
        if not application:
            flash('Application not found', 'error')
            return redirect(url_for('application_support.index'))

        application_name = application.application_name
        tower_id = application.tower_id
        tower = db_session.query(AppSupportTower).filter_by(id=tower_id).first()


        # Delete all related data manually to ensure cleanup
        # Delete files from filesystem and database
        db_session.query(ServerDetails).filter_by(application_id=application.id).delete()
        db_session.query(SupportTeam).filter_by(application_id=application.id).delete()
        # The tower lead's allocation of this application goes with it,
        # otherwise the grid keeps a cell pointing at a deleted row.
        db_session.query(ApplicationAssignment).filter_by(
            application_id=application.id).delete()
        db_session.query(BusinessUsers).filter_by(application_id=application.id).delete()
        db_session.query(VendorDetails).filter_by(application_id=application.id).delete()
        db_session.query(ExternalInterfaces).filter_by(application_id=application.id).delete()
        db_session.query(IndividualJobs).filter_by(application_id=application.id).delete()
        db_session.query(SuiteJobs).filter_by(application_id=application.id).delete()
        db_session.query(CriticalIssue).filter_by(application_id=application.id).delete()
        db_session.query(ApplicationTask).filter_by(application_id=application.id).delete()
        db_session.query(FileInventory).filter_by(application_id=application.id).delete()
        # Technical Details: stack rows and standards answers
        tech_details.delete_for_application(db_session, application.id)

        # Finally delete the application
        db_session.delete(application)
        db_session.commit()
        log_audit(user, tower.tower_name if tower else 'Unknown', 'Application', 'DELETE', f'Deleted application: {application_name}')
        flash('Application and all related data deleted successfully', 'success')
        return redirect(url_for('application_support.tower_applications', tower_id=tower_id))
    except Exception as e:
        db_session.rollback()
        flash(f'Error deleting application: {str(e)}', 'error')
        return redirect(url_for('application_support.view_application', app_id=app_id))
    finally:
        db_session.close()

def _delete_application_related_data(application_id, db_session):
    """Helper function to delete existing related data before updating"""
    db_session.query(ServerDetails).filter_by(application_id=application_id).delete()
    # Support team: only the rows this form can edit. The tower lead's
    # allocation (source='assignment') is rebuilt from the Tower Summary grid
    # and is not on the form, so deleting it here would drop it on every save.
    # `source IS NULL` has to be spelled out: in SQL `source != 'assignment'`
    # is UNKNOWN for a NULL, so it would match none of the typed rows.
    (db_session.query(SupportTeam)
     .filter(SupportTeam.application_id == application_id,
             or_(SupportTeam.source.is_(None),
                 SupportTeam.source != team_summary.SOURCE_ASSIGNMENT))
     .delete(synchronize_session=False))
    db_session.query(BusinessUsers).filter_by(application_id=application_id).delete()
    db_session.query(VendorDetails).filter_by(application_id=application_id).delete()
    db_session.query(ExternalInterfaces).filter_by(application_id=application_id).delete()
    db_session.query(IndividualJobs).filter_by(application_id=application_id).delete()
    db_session.query(SuiteJobs).filter_by(application_id=application_id).delete()

# Individual Jobs Management Routes
@application_support_bp.route('/application/<int:app_id>/add-individual-job', methods=['GET', 'POST'])
def add_individual_job(app_id):
    """Add individual job to application"""
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))
    
    db_session = get_db_session()
    try:
        app = db_session.query(ApplicationDetails).filter_by(id=app_id, is_active=True).first()
        if not app:
            flash('Application not found', 'error')
            return redirect(url_for('application_support.index'))
        
        # Check if user can edit this application
        if not (is_admin(user) or is_tower_member(user, app.tower_id)):
            flash('Access denied. You are not a member of this tower.', 'error')
            return redirect(url_for('application_support.view_application', app_id=app_id))
        
        if request.method == 'POST':
            if not validate_csrf_token(request.form.get('csrf_token')):
                flash('Invalid security token. Please try again.', 'error')
                return redirect(url_for('application_support.view_application', app_id=app_id))
            
            job = IndividualJobs(
                application_id=app_id,
                job_name=request.form.get('job_name', ''),
                frequency=request.form.get('frequency', ''),
                short_description=request.form.get('short_description', ''),
                full_description=request.form.get('full_description', ''),
                user_profile=request.form.get('user_profile', ''),
                prerequisites=request.form.get('prerequisites', ''),
                script=request.form.get('script', ''),
                failure_checks=request.form.get('failure_checks', ''),
                manual_execution_steps=request.form.get('manual_execution_steps', '')
            )
            db_session.add(job)
            db_session.commit()
            
            flash('Individual job added successfully!', 'success')
            return redirect(url_for('application_support.view_application', app_id=app_id))
        
        return render_template('application_support/add_individual_job.html', user=user, app=app)
    finally:
        db_session.close()

# Suite Jobs Management Routes
@application_support_bp.route('/application/<int:app_id>/add-suite-job', methods=['GET', 'POST'])
def add_suite_job(app_id):
    """Add suite job to application"""
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))
    
    db_session = get_db_session()
    try:
        app = db_session.query(ApplicationDetails).filter_by(id=app_id, is_active=True).first()
        if not app:
            flash('Application not found', 'error')
            return redirect(url_for('application_support.index'))
        
        # Check if user can edit this application
        if not (is_admin(user) or is_tower_member(user, app.tower_id)):
            flash('Access denied. You are not a member of this tower.', 'error')
            return redirect(url_for('application_support.view_application', app_id=app_id))
        
        if request.method == 'POST':
            if not validate_csrf_token(request.form.get('csrf_token')):
                flash('Invalid security token. Please try again.', 'error')
                return redirect(url_for('application_support.view_application', app_id=app_id))
            
            job = SuiteJobs(
                application_id=app_id,
                suite_name=request.form.get('suite_name', ''),
                job_name=request.form.get('job_name', ''),
                frequency=request.form.get('frequency', ''),
                short_description=request.form.get('short_description', ''),
                full_description=request.form.get('full_description', ''),
                user_profile=request.form.get('user_profile', ''),
                prerequisites=request.form.get('prerequisites', ''),
                script=request.form.get('script', ''),
                failure_checks=request.form.get('failure_checks', ''),
                manual_execution_steps=request.form.get('manual_execution_steps', '')
            )
            db_session.add(job)
            db_session.commit()
            
            flash('Suite job added successfully!', 'success')
            return redirect(url_for('application_support.view_application', app_id=app_id))
        
        return render_template('application_support/add_suite_job.html', user=user, app=app)
    finally:
        db_session.close()

@application_support_bp.route('/individual-job/<int:job_id>')
def view_individual_job(job_id):
    """View details of a single individual job."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        job = db_session.query(IndividualJobs).filter_by(id=job_id).first()
        app = db_session.query(ApplicationDetails).filter_by(id=job.application_id).first()
        if not job:
            flash('Individual job not found.', 'error')
            return redirect(url_for('application_support.view_application', app_id=job.application_id))
        

        
        if not app:
            flash('Associated application not found.', 'error')
            return redirect(url_for('application_support.index'))

        can_edit = user and (is_admin(user) or is_tower_member(user, app.tower_id))

        return render_template('application_support/view_individual_job.html', user=user, job=job, app=app, can_edit=can_edit)
    finally:
        db_session.close()


@application_support_bp.route('/individual-job/<int:job_id>/edit', methods=['GET', 'POST'])
def edit_individual_job(job_id):
    """Edit an individual job."""
    user = get_current_user()
    if not user:
        flash('Please login to access this page.', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        job = db_session.query(IndividualJobs).filter_by(id=job_id).first()
        if not job:
            flash('Individual job not found.', 'error')
            return redirect(url_for('application_support.index'))

        app = db_session.query(ApplicationDetails).filter_by(id=job.application_id).first()
        if not app:
            flash('Associated application not found.', 'error')
            return redirect(url_for('application_support.index'))

        if not (is_admin(user) or is_tower_member(user, app.tower_id)):
            flash('You do not have permission to edit this job.', 'error')
            return redirect(url_for('application_support.view_application', app_id=app.id))

        if request.method == 'POST':
            if not validate_csrf_token(request.form.get('csrf_token')):
                flash('Invalid security token. Please try again.', 'error')
                return redirect(url_for('application_support.edit_individual_job', job_id=job.id))

            job.job_name = request.form.get('job_name', '')
            job.frequency = request.form.get('frequency', '')
            job.short_description = request.form.get('short_description', '')
            job.full_description = request.form.get('full_description', '')
            job.user_profile = request.form.get('user_profile', '')
            job.prerequisites = request.form.get('prerequisites', '')
            job.script = request.form.get('script', '')
            job.failure_checks = request.form.get('failure_checks', '')
            job.manual_execution_steps = request.form.get('manual_execution_steps', '')
            
            db_session.commit()
            flash('Individual job updated successfully!', 'success')
            return redirect(url_for('application_support.view_application', app_id=app.id))

        return render_template('application_support/edit_individual_job.html', user=user, job=job, app=app)
    except Exception as e:
        db_session.rollback()
        flash(f'An error occurred: {str(e)}', 'error')
        return redirect(url_for('application_support.view_application', app_id=app.id if 'app' in locals() else ''))
    finally:
        db_session.close()


@application_support_bp.route('/individual-job/<int:job_id>/delete', methods=['POST'])
def delete_individual_job(job_id):
    """Delete an individual job (admin only)."""
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required to delete.', 'error')
        return redirect(url_for('application_support.index'))

    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(request.referrer or url_for('application_support.index'))

    db_session = get_db_session()
    try:
        job = db_session.query(IndividualJobs).filter_by(id=job_id).first()
        if not job:
            flash('Individual job not found.', 'error')
            return redirect(url_for('application_support.index'))

        app_id = job.application_id
        db_session.delete(job)
        db_session.commit()
        flash('Individual job deleted successfully.', 'success')
        return redirect(url_for('application_support.view_application', app_id=app_id))
    except Exception as e:
        db_session.rollback()
        flash(f'An error occurred: {str(e)}', 'error')
        return redirect(request.referrer or url_for('application_support.index'))
    finally:
        db_session.close()


# --- Suite Job View, Edit, Delete ---

@application_support_bp.route('/suite-job/<int:job_id>')
def view_suite_job(job_id):
    """View details of a single suite job."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        job = db_session.query(SuiteJobs).filter_by(id=job_id).first()
        if not job:
            flash('Suite job not found.', 'error')
            return redirect(url_for('application_support.index'))

        app = db_session.query(ApplicationDetails).filter_by(id=job.application_id).first()
        if not app:
            flash('Associated application not found.', 'error')
            return redirect(url_for('application_support.index'))

        can_edit = user and (is_admin(user) or is_tower_member(user, app.tower_id))

        return render_template('application_support/view_suite_job.html', user=user, job=job, app=app, can_edit=can_edit)
    finally:
        db_session.close()


@application_support_bp.route('/suite-job/<int:job_id>/edit', methods=['GET', 'POST'])
def edit_suite_job(job_id):
    """Edit a suite job."""
    user = get_current_user()
    if not user:
        flash('Please login to access this page.', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        job = db_session.query(SuiteJobs).filter_by(id=job_id).first()
        if not job:
            flash('Suite job not found.', 'error')
            return redirect(url_for('application_support.index'))

        app = db_session.query(ApplicationDetails).filter_by(id=job.application_id).first()
        if not app:
            flash('Associated application not found.', 'error')
            return redirect(url_for('application_support.index'))

        if not (is_admin(user) or is_tower_member(user, app.tower_id)):
            flash('You do not have permission to edit this job.', 'error')
            return redirect(url_for('application_support.view_application', app_id=app.id))

        if request.method == 'POST':
            if not validate_csrf_token(request.form.get('csrf_token')):
                flash('Invalid security token. Please try again.', 'error')
                return redirect(url_for('application_support.edit_suite_job', job_id=job.id))

            job.suite_name = request.form.get('suite_name', '')
            job.job_name = request.form.get('job_name', '')
            job.frequency = request.form.get('frequency', '')
            job.short_description = request.form.get('short_description', '')
            job.full_description = request.form.get('full_description', '')
            job.user_profile = request.form.get('user_profile', '')
            job.prerequisites = request.form.get('prerequisites', '')
            job.script = request.form.get('script', '')
            job.failure_checks = request.form.get('failure_checks', '')
            job.manual_execution_steps = request.form.get('manual_execution_steps', '')
            
            db_session.commit()
            flash('Suite job updated successfully!', 'success')
            return redirect(url_for('application_support.view_application', app_id=app.id))

        return render_template('application_support/edit_suite_job.html', user=user, job=job, app=app)
    except Exception as e:
        db_session.rollback()
        flash(f'An error occurred: {str(e)}', 'error')
        return redirect(url_for('application_support.view_application', app_id=app.id if 'app' in locals() else ''))
    finally:
        db_session.close()


@application_support_bp.route('/suite-job/<int:job_id>/delete', methods=['POST'])
def delete_suite_job(job_id):
    """Delete a suite job (admin only)."""
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required to delete.', 'error')
        return redirect(url_for('application_support.index'))

    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(request.referrer or url_for('application_support.index'))

    db_session = get_db_session()
    try:
        job = db_session.query(SuiteJobs).filter_by(id=job_id).first()
        if not job:
            flash('Suite job not found.', 'error')
            return redirect(url_for('application_support.index'))

        app_id = job.application_id
        db_session.delete(job)
        db_session.commit()
        flash('Suite job deleted successfully.', 'success')
        return redirect(url_for('application_support.view_application', app_id=app_id))
    except Exception as e:
        db_session.rollback()
        flash(f'An error occurred: {str(e)}', 'error')
        return redirect(request.referrer or url_for('application_support.index'))
    finally:
        db_session.close()


# File Management Routes
@application_support_bp.route('/application/<int:app_id>/upload-file', methods=['GET', 'POST'])
def upload_file(app_id):
    """Upload file for application"""
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))
    
    db_session = get_db_session()
    try:
        app = db_session.query(ApplicationDetails).filter_by(id=app_id, is_active=True).first()
        if not app:
            flash('Application not found', 'error')
            return redirect(url_for('application_support.index'))
        
        # Check if user can edit this application
        if not (is_admin(user) or is_tower_member(user, app.tower_id)):
            flash('Access denied. You are not a member of this tower.', 'error')
            return redirect(url_for('application_support.view_application', app_id=app_id))
        
        if request.method == 'POST':
            if not validate_csrf_token(request.form.get('csrf_token')):
                flash('Invalid security token. Please try again.', 'error')
                return redirect(url_for('application_support.view_application', app_id=app_id))
            
            file_name = request.form.get('file_name', '')
            description = request.form.get('description', '')
            
            # Handle file upload
            uploaded_file = request.files.get('file')
            file_path = ''
            
            if uploaded_file and uploaded_file.filename:
                # Validate file security
                is_valid, validation_message = validate_file_content(uploaded_file)
                if not is_valid:
                    flash(f'File upload failed: {validation_message}', 'error')
                    return render_template('application_support/upload_file.html', user=user, app=app)
                
                # Secure filename processing
                if not secure_filename(uploaded_file.filename):
                    flash('Invalid filename. Please choose a different file.', 'error')
                    return render_template('application_support/upload_file.html', user=user, app=app)

                try:
                    file_path, version_ref, original_name = _store_app_upload(
                        uploaded_file, app.application_name)
                except Exception as e:
                    flash(f'Failed to save file: {str(e)}', 'error')
                    return render_template('application_support/upload_file.html', user=user, app=app)
            else:
                flash('Please select a file to upload.', 'error')
                return render_template('application_support/upload_file.html', user=user, app=app)

            file_inventory = FileInventory(
                application_id=app_id,
                file_name=file_name or uploaded_file.filename if uploaded_file else '',
                description=description,
                file_path=file_path,
                uploaded_by=getattr(user, 'id', None)
            )
            db_session.add(file_inventory)
            db_session.flush()          # need the id to key the version row
            if version_ref:
                file_versions.record_version(
                    db_session, FILE_ENTITY, file_inventory.id, FILE_UPLOAD_ROOT,
                    version_ref, original_filename=original_name,
                    uploaded_by=getattr(user, 'id', None), note='Initial upload',
                )
            db_session.commit()
            log_audit(user, app.tower.tower_name if app.tower else 'Unknown', 'File', 'INSERT', f'Uploaded file: {file_name or uploaded_file.filename} to application: {app.application_name}')

            
            flash('File uploaded successfully!', 'success')
            return redirect(url_for('application_support.view_application', app_id=app_id))
        
        return render_template('application_support/upload_file.html', user=user, app=app)
    finally:
        db_session.close()

# New route: Download document
@application_support_bp.route('/files/<int:file_id>/download')
def download_file(file_id):
    """Download a file's CURRENT version.

    Gated exactly like the version history below it: an admin, or a member of
    the application's tower. This route used to have no check at all - any
    anonymous visitor who guessed an id could pull an application's runbooks and
    configs straight out of the inventory.
    """
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        app_file, app, err = _file_guard(db_session, file_id, user)
        if err == 'not_found':
            flash('File not found', 'error')
            return redirect(url_for('application_support.index'))
        if err:
            flash('Access denied. You are not a member of this tower.', 'error')
            return redirect(url_for('application_support.index'))

        if not app_file.file_path or not os.path.exists(app_file.file_path):
            flash('File not found on disk', 'error')
            return redirect(url_for('application_support.view_application',
                                    app_id=app_file.application_id))

        return send_file(app_file.file_path, as_attachment=True)
    finally:
        db_session.close()
        

def _file_guard(db_session, file_id, user):
    """Load a file row + its application and apply this module's edit rule.

    Returns (app_file, app, None) when `user` may act on it, else
    (None, None, 'not_found' | 'denied').

    Edit rights here are exactly the upload rights: an admin, or a member of the
    application's tower. Every route that reaches a file's history or an old
    version goes through this - hand-rolling the check is how a hole gets opened.
    """
    app_file = db_session.query(FileInventory).filter_by(id=file_id).first()
    if not app_file:
        return None, None, 'not_found'
    app = db_session.query(ApplicationDetails).filter_by(
        id=app_file.application_id).first()
    if not app:
        return None, None, 'not_found'
    if not (is_admin(user) or is_tower_member(user, app.tower_id)):
        return None, None, 'denied'
    return app_file, app, None


@application_support_bp.route('/files/<int:file_id>/edit', methods=['GET', 'POST'])
def edit_file(file_id):
    """Edit a file's details and, optionally, upload a new version of it.

    Replaces the delete-and-re-upload workaround: the inventory row keeps its
    identity, its uploader and its date, and the previous file drops into the
    version trail instead of being destroyed. The page doubles as the version
    history - the retained versions are listed with a download link each.
    """
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    stale_paths = []
    committed = False
    try:
        app_file, app, err = _file_guard(db_session, file_id, user)
        if err == 'not_found':
            flash('File not found', 'error')
            return redirect(url_for('application_support.index'))
        if err:
            flash('Access denied. You are not a member of this tower.', 'error')
            return redirect(url_for('application_support.index'))

        if request.method == 'POST':
            if not validate_csrf_token(request.form.get('csrf_token')):
                flash('Invalid security token. Please try again.', 'error')
                return redirect(url_for('application_support.edit_file', file_id=file_id))

            file_name = (request.form.get('file_name') or '').strip()
            if not file_name:
                flash('File name is required.', 'error')
                return redirect(url_for('application_support.edit_file', file_id=file_id))

            uploaded_file = request.files.get('file')
            replacing = bool(uploaded_file and uploaded_file.filename)
            if replacing:
                is_valid, message = validate_file_content(uploaded_file)
                if not is_valid:
                    flash(f'File upload failed: {message}', 'error')
                    return redirect(url_for('application_support.edit_file', file_id=file_id))
                if not secure_filename(uploaded_file.filename):
                    flash('Invalid filename. Please choose a different file.', 'error')
                    return redirect(url_for('application_support.edit_file', file_id=file_id))

            app_file.file_name = file_name
            app_file.description = (request.form.get('description') or '').strip()

            if replacing:
                # A file uploaded before versioning existed has no trail yet.
                # Seed its current file as v1 first, or replacing it would erase it.
                file_versions.backfill_initial(
                    db_session, FILE_ENTITY, app_file.id, FILE_UPLOAD_ROOT,
                    _version_ref(app_file.file_path),
                    original_filename=app_file.file_name,
                    uploaded_by=app_file.uploaded_by,
                    uploaded_at=app_file.uploaded_at,
                )
                try:
                    new_path, new_ref, original_name = _store_app_upload(
                        uploaded_file, app.application_name)
                except Exception as e:
                    db_session.rollback()
                    flash(f'Failed to save file: {str(e)}', 'error')
                    return redirect(url_for('application_support.edit_file', file_id=file_id))

                file_versions.record_version(
                    db_session, FILE_ENTITY, app_file.id, FILE_UPLOAD_ROOT, new_ref,
                    original_filename=original_name,
                    uploaded_by=getattr(user, 'id', None),
                    note=(request.form.get('version_note') or '').strip() or None,
                )
                app_file.file_path = new_path
                # Keep the newest MAX_VERSIONS (the live file among them). protect=
                # is a belt-and-braces guard so a bookkeeping slip can never unlink
                # the file the inventory row is actually serving.
                stale_paths = file_versions.prune(
                    db_session, FILE_ENTITY, app_file.id, FILE_UPLOAD_ROOT,
                    protect=(new_ref,))

            db_session.commit()
            committed = True
            log_audit(user, app.tower.tower_name if app.tower else 'Unknown', 'File',
                      'UPDATE',
                      f'{"Uploaded new version of" if replacing else "Updated"} '
                      f'file: {file_name} on application: {app.application_name}')
            flash('New version uploaded.' if replacing else 'File details updated.',
                  'success')
            return redirect(url_for('application_support.view_application',
                                    app_id=app.id))

        versions = file_versions.list_versions(db_session, FILE_ENTITY, app_file.id)
        current_ref = _version_ref(app_file.file_path)
        return render_template(
            'application_support/edit_file.html',
            user=user, app=app, app_file=app_file,
            versions=versions, current_ref=current_ref,
            max_versions=file_versions.MAX_VERSIONS,
            get_user_name=get_user_name,
        )
    finally:
        db_session.close()
        # Unlink ONLY after a successful commit. Doing it earlier - or at all on
        # a failed transaction - would destroy the file while the rows that point
        # at it survive the rollback.
        if committed:
            file_versions.remove_files(stale_paths)


@application_support_bp.route('/files/<int:file_id>/version/<int:version_id>/download')
def download_file_version(file_id, version_id):
    """Download one historical version. Edit-gated, via the same guard."""
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        app_file, app, err = _file_guard(db_session, file_id, user)
        if err == 'not_found':
            abort(404)
        if err:
            abort(403)

        # Scoped to this file, so a version id belonging to another one 404s.
        version = file_versions.get_version(
            db_session, FILE_ENTITY, app_file.id, version_id)
        if not version:
            abort(404)

        path = file_versions.resolve_path(FILE_UPLOAD_ROOT, version.stored_filename)
        if not path or not os.path.exists(path):
            flash('That version is no longer on disk', 'error')
            return redirect(url_for('application_support.edit_file', file_id=file_id))

        name = version.original_filename or os.path.basename(version.stored_filename)
        return send_file(path, as_attachment=True,
                         download_name=f'v{version.version_no}_{name}')
    finally:
        db_session.close()


# New route: Delete document
@application_support_bp.route('/files/<int:file_id>/delete', methods=['POST'])
def delete_file(file_id):
    """Delete application file - admin only"""
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required to delete.', 'error')
        return redirect(url_for('application_support.index'))

    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(request.referrer or url_for('application_support.index'))

    db_session = get_db_session()
    stale_paths = []
    committed = False
    try:
        app_file = db_session.query(FileInventory).filter_by(id=file_id).first()
        if not app_file:
            flash('File not found', 'error')
            return redirect(url_for('application_support.index'))

        application_id = app_file.application_id
        filename = app_file.file_name
        app = db_session.query(ApplicationDetails).filter_by(id=application_id).first()

        # The version trail is keyed by file id, not an FK (one shared table
        # serves every module), so nothing cascades it away - this route owns the
        # cleanup. Files are unlinked after the commit, in `finally`.
        stale_paths = file_versions.delete_all(
            db_session, FILE_ENTITY, app_file.id, FILE_UPLOAD_ROOT)
        if app_file.file_path:
            stale_paths.append(os.path.abspath(app_file.file_path))

        # Delete from database
        db_session.delete(app_file)
        db_session.commit()
        committed = True
        log_audit(user, app.tower.tower_name if app and app.tower else 'Unknown', 'File', 'DELETE', f'Deleted file: {filename} from application: {app.application_name if app else application_id}')


        flash('File deleted successfully', 'success')
        return redirect(url_for('application_support.view_application', app_id=application_id))
    finally:
        db_session.close()
        # Unlink ONLY on a committed delete. Doing it unconditionally would
        # destroy the files even when the transaction failed and the rows that
        # point at them survived.
        if committed:
            file_versions.remove_files(stale_paths)

# Task Management Routes
@application_support_bp.route('/application/<int:app_id>/add-task', methods=['GET', 'POST'])
def add_task(app_id):
    """Add task to application"""
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))
    
    db_session = get_db_session()
    try:
        app = db_session.query(ApplicationDetails).filter_by(id=app_id, is_active=True).first()
        if not app:
            flash('Application not found', 'error')
            return redirect(url_for('application_support.index'))
        
        # Check if user can edit this application
        if not (is_admin(user) or is_tower_member(user, app.tower_id)):
            flash('Access denied. You are not a member of this tower.', 'error')
            return redirect(url_for('application_support.view_application', app_id=app_id))
        
        if request.method == 'POST':
            if not validate_csrf_token(request.form.get('csrf_token')):
                flash('Invalid security token. Please try again.', 'error')
                return redirect(url_for('application_support.view_application', app_id=app_id))
            
            task = ApplicationTask(
                application_id=app_id,
                task_name=request.form.get('task_name', ''),
                description=request.form.get('description', ''),
                steps=request.form.get('steps', ''),
                created_by=getattr(user, 'id', None)
            )
            db_session.add(task)
            db_session.commit()
            
            flash('Task added successfully!', 'success')
            return redirect(url_for('application_support.view_application', app_id=app_id))
        
        return render_template('application_support/add_task.html', user=user, app=app)
    finally:
        db_session.close()
        
        
@application_support_bp.route('/task/<int:task_id>/view')
def view_task(task_id):
    """View an application task (public)."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        task = db_session.query(ApplicationTask).filter_by(id=task_id).first()
        if not task:
            flash('Task not found', 'error')
            return redirect(url_for('application_support.index'))

        app = db_session.query(ApplicationDetails).filter_by(id=task.application_id).first()
        can_edit = bool(user and app and (is_admin(user) or is_tower_member(user, app.tower_id)))
        return render_template('application_support/view_task.html', task=task, user=user, can_edit=can_edit)
    finally:
        db_session.close()
        
@application_support_bp.route('/task/<int:task_id>/edit', methods=['GET', 'POST'])
def edit_task(task_id):
    """Edit application issue - logged in users only"""
    user = get_current_user()
    if not user:
        flash('Login required', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        task = db_session.query(ApplicationTask).filter_by(id=task_id).first()
        app = db_session.query(ApplicationDetails).filter_by(id=task.application_id, is_active=True).first()
        if not (is_admin(user) or is_tower_member(user, app.tower_id)):
            flash('Access denied. You are not a member of this tower.', 'error')
            return redirect(url_for('application_support.view_application', app_id=task.application_id))
        
        
        if not task:
            flash('Task not found', 'error')
            return redirect(url_for('application_support.index'))

        if request.method == 'POST':
            
                
            task_name = request.form.get('task_name')
            description = request.form.get('description')
            steps = request.form.get('steps')
            updated_by=getattr(user, 'id', None)

            if not task_name:
                flash('Task name is required', 'error')
                return redirect(url_for('application_support.view_task', task_id=task.id))
            
            task.task_name=task_name
            task.description=description
            task.steps=steps
            task.updated_by=updated_by
            db_session.commit()
            flash('task updated successfully', 'success')
            return redirect(url_for('application_support.view_task', task_id=task.id))

        return render_template('application_support/edit_task.html', task=task, user=user,app=app)
    finally:
        db_session.close()



@application_support_bp.route('/task/<int:task_id>/delete', methods=['POST'])
def delete_task(task_id):
    """Delete application task - admin only"""
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required to delete.', 'error')
        return redirect(url_for('application_support.index'))

    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(request.referrer or url_for('application_support.index'))

    db_session = get_db_session()
    try:
        task = db_session.query(ApplicationTask).filter_by(id=task_id).first()
        if not task:
            flash('Task not found', 'error')
            return redirect(url_for('application_support.index'))

        application_id = task.application_id
        db_session.delete(task)
        db_session.commit()

        flash('Task deleted successfully', 'success')
        return redirect(url_for('application_support.view_application', app_id=application_id))
    finally:
        db_session.close()




# Critical Issue Management Routes
@application_support_bp.route('/application/<int:app_id>/add-critical-issue', methods=['GET', 'POST'])
def add_critical_issue(app_id):
    """Add critical issue to application"""
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))
    
    db_session = get_db_session()
    try:
        app = db_session.query(ApplicationDetails).filter_by(id=app_id, is_active=True).first()
        if not app:
            flash('Application not found', 'error')
            return redirect(url_for('application_support.index'))
        
        # Check if user can edit this application
        if not (is_admin(user) or is_tower_member(user, app.tower_id)):
            flash('Access denied. You are not a member of this tower.', 'error')
            return redirect(url_for('application_support.view_application', app_id=app_id))
        
        if request.method == 'POST':
            if not validate_csrf_token(request.form.get('csrf_token')):
                flash('Invalid security token. Please try again.', 'error')
                return redirect(url_for('application_support.view_application', app_id=app_id))
            
            issue = CriticalIssue(
                application_id=app_id,
                issue_name=request.form.get('issue_name', ''),
                problem_description=request.form.get('problem_description', ''),
                solution_steps=request.form.get('solution_steps', ''),
                created_by=getattr(user, 'id', None)
            )
            db_session.add(issue)
            db_session.commit()
            
            flash('Critical issue added successfully!', 'success')
            return redirect(url_for('application_support.view_application', app_id=app_id))
        
        return render_template('application_support/add_critical_issue.html', user=user, app=app)
    finally:
        db_session.close()

@application_support_bp.route('/issues/<int:issue_id>/view')
def view_issue(issue_id):
    """View a critical issue (public)."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        issue = db_session.query(CriticalIssue).filter_by(id=issue_id).first()
        if not issue:
            flash('Issue not found', 'error')
            return redirect(url_for('application_support.index'))

        app = db_session.query(ApplicationDetails).filter_by(id=issue.application_id).first()
        can_edit = bool(user and app and (is_admin(user) or is_tower_member(user, app.tower_id)))
        return render_template('application_support/view_critical_issue.html', issue=issue, user=user, can_edit=can_edit)
    finally:
        db_session.close()
        
@application_support_bp.route('/issues/<int:issue_id>/edit', methods=['GET', 'POST'])
def edit_issue(issue_id):
    """Edit application issue - tower members and admin only"""
    user = get_current_user()
    if not user:
        flash('Login required', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        issue = db_session.query(CriticalIssue).filter_by(id=issue_id).first()
        if not issue:
            flash('Issue not found', 'error')
            return redirect(url_for('application_support.index'))

        app = db_session.query(ApplicationDetails).filter_by(id=issue.application_id).first()
        if not app:
            flash('Associated application not found.', 'error')
            return redirect(url_for('application_support.index'))

        if not (is_admin(user) or is_tower_member(user, app.tower_id)):
            flash('Access denied. You are not a member of this tower.', 'error')
            return redirect(url_for('application_support.view_issue', issue_id=issue.id))

        if request.method == 'POST':
            if not validate_csrf_token(request.form.get('csrf_token')):
                flash('Invalid security token. Please try again.', 'error')
                return redirect(url_for('application_support.edit_issue', issue_id=issue.id))

            issue.issue_name = request.form.get('issue_name')
            issue.problem_description = request.form.get('problem_description')
            issue.solution_steps = request.form.get('solution_steps')
            issue.updated_by = getattr(user, 'id', None)

            if not issue.issue_name:
                flash('Issue name is required', 'error')
                return render_template('application_support/edit_critical_issue.html', issue=issue, user=user, app=app)

            db_session.commit()
            flash('Issue updated successfully', 'success')
            return redirect(url_for('application_support.view_issue', issue_id=issue.id))

        return render_template('application_support/edit_critical_issue.html', issue=issue, user=user,app=app)
    finally:
        db_session.close()


# New route: Delete application issue
@application_support_bp.route('/issues/<int:issue_id>/delete', methods=['POST'])
def delete_issue(issue_id):
    """Delete application issue - admin only"""
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required to delete.', 'error')
        return redirect(url_for('application_support.index'))

    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(request.referrer or url_for('application_support.index'))

    db_session = get_db_session()
    try:
        issue = db_session.query(CriticalIssue).filter_by(id=issue_id).first()
        if not issue:
            flash('Issue not found', 'error')
            return redirect(url_for('application_support.index'))

        application_id = issue.application_id
        db_session.delete(issue)
        db_session.commit()

        flash('Issue deleted successfully', 'success')
        return redirect(url_for('application_support.view_application', app_id=application_id))
    finally:
        db_session.close()


@application_support_bp.route('/audit-logs')
def view_audit_logs():
    
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))
    
    #if not is_admin(user):
    #    flash('Access denied. Admin privileges required.', 'error')
    #    return redirect(url_for('application_support.index'))
    
    db_session = get_db_session()
    try:
        from .models import AuditLog
        
        # Get filter parameter
        tower_filter = request.args.get('tower_name', '')
        
        # Base query - sorted by timestamp descending
        query = db_session.query(AuditLog).order_by(AuditLog.timestamp.desc())
        
        # Apply tower filter if provided
        if tower_filter:
            query = query.filter(AuditLog.tower_name == tower_filter)
        
        audit_logs = query.all()
        
        # Get unique tower names for filter dropdown
        tower_names = db_session.query(AuditLog.tower_name).distinct().order_by(AuditLog.tower_name).all()
        tower_names = [name[0] for name in tower_names]
        
        return render_template('application_support/audit_logs.html',
                             user=user, audit_logs=audit_logs,
                             tower_names=tower_names, selected_tower=tower_filter)
    finally:
        db_session.close()


# ===========================================================================
# Secret Vault - tower-scoped credential store
#
# Access model (per requirement):
#   * Visible and accessible to TOWER MEMBERS ONLY - not even admins.
#   * Admins only manage membership and grant/revoke the "can manage
#     passwords" flag per member (see toggle_vault_access below).
#   * Members WITH the flag can add / update / delete credentials.
#   * All other members are view-only (list + reveal).
#   * Passwords are stored encrypted (Fernet via crypto_utils) and only
#     decrypted on an explicit reveal request.
# ===========================================================================

_VAULT_TYPE_FILTERS = {
    'server':   CredentialType.SERVER,
    'database': CredentialType.DATABASE,
    'url':      CredentialType.URL,
}

def _vault_wildcard_pattern(term):
    """Turn a user search term into a SQL LIKE pattern.

    Supports wildcard characters: * (any sequence) and ? (single char).
    A term without wildcards becomes a contains-search. Literal % and _
    in the term are escaped so they match themselves.
    """
    pattern = (term.replace('\\', '\\\\')
                   .replace('%', '\\%')
                   .replace('_', '\\_')
                   .replace('*', '%')
                   .replace('?', '_'))
    if '%' not in pattern and '_' not in pattern:
        pattern = f'%{pattern}%'
    return pattern


@application_support_bp.route('/tower/<int:tower_id>/secret-vault')
def secret_vault(tower_id):
    """Secret Vault listing with wildcard search and type filter buttons."""
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))

    if not is_strict_tower_member(user, tower_id):
        flash('Access denied. The Secret Vault is available to tower members only.', 'error')
        return redirect(url_for('application_support.tower_applications', tower_id=tower_id))

    search = request.args.get('q', '').strip()
    type_filter = request.args.get('type', 'all').lower()

    db_session = get_db_session()
    try:
        tower = db_session.query(AppSupportTower).filter_by(id=tower_id, is_active=True).first()
        if not tower:
            flash('Tower not found', 'error')
            return redirect(url_for('application_support.index'))

        query = db_session.query(SecretVaultEntry).filter_by(tower_id=tower_id)

        if type_filter in _VAULT_TYPE_FILTERS:
            query = query.filter(SecretVaultEntry.credential_type == _VAULT_TYPE_FILTERS[type_filter])
        else:
            type_filter = 'all'

        if search:
            pattern = _vault_wildcard_pattern(search)
            query = query.filter(or_(
                SecretVaultEntry.application_name.ilike(pattern, escape='\\'),
                SecretVaultEntry.resource.ilike(pattern, escape='\\'),
                SecretVaultEntry.username.ilike(pattern, escape='\\'),
            ))

        entries = query.order_by(
            SecretVaultEntry.environment,
            SecretVaultEntry.application_name,
        ).all()

        # Counts for the filter buttons (All credentials / Server / Database / URLs)
        base = db_session.query(SecretVaultEntry).filter_by(tower_id=tower_id)
        type_counts = {
            'all':      base.count(),
            'server':   base.filter(SecretVaultEntry.credential_type == CredentialType.SERVER).count(),
            'database': base.filter(SecretVaultEntry.credential_type == CredentialType.DATABASE).count(),
            'url':      base.filter(SecretVaultEntry.credential_type == CredentialType.URL).count(),
        }

        for entry in entries:
            entry.created_by_name = get_user_name(entry.created_by)
            entry.updated_by_name = get_user_name(entry.updated_by)

        return render_template('application_support/secret_vault.html',
                             user=user, tower=tower, entries=entries,
                             can_write=can_manage_vault(user, tower_id),
                             search=search, type_filter=type_filter,
                             type_counts=type_counts,
                             environments=EnvironmentType,
                             credential_types=CredentialType)
    finally:
        db_session.close()


@application_support_bp.route('/tower/<int:tower_id>/secret-vault/add', methods=['POST'])
def add_vault_entry(tower_id):
    """Add a credential (members with vault write access only)."""
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))

    if not is_strict_tower_member(user, tower_id) or not can_manage_vault(user, tower_id):
        flash('Access denied. Only members granted password management rights can add credentials.', 'error')
        return redirect(url_for('application_support.secret_vault', tower_id=tower_id))

    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.secret_vault', tower_id=tower_id))

    environment = request.form.get('environment')
    application_name = (request.form.get('application_name') or '').strip()
    credential_type = request.form.get('credential_type')
    resource = (request.form.get('resource') or '').strip()
    username = (request.form.get('username') or '').strip()
    password = request.form.get('password') or ''

    if not all([environment, application_name, credential_type, resource, username, password]):
        flash('All fields are required: environment, application, type, URL/server/database, user name and password.', 'error')
        return redirect(url_for('application_support.secret_vault', tower_id=tower_id))

    db_session = get_db_session()
    try:
        tower = db_session.query(AppSupportTower).filter_by(id=tower_id, is_active=True).first()
        if not tower:
            flash('Tower not found', 'error')
            return redirect(url_for('application_support.index'))

        entry = SecretVaultEntry(
            tower_id=tower_id,
            environment=EnvironmentType[environment],
            application_name=application_name,
            credential_type=CredentialType[credential_type],
            resource=resource,
            username=username,
            password_encrypted=encrypt_data(password),
            created_by=getattr(user, 'id', None),
            updated_by=getattr(user, 'id', None),
        )
        db_session.add(entry)
        db_session.commit()
        log_audit(user, tower.tower_name, 'Secret Vault', 'INSERT',
                  f'Added {entry.credential_type.value} credential for {application_name} ({resource})')
        flash(f'Credential for "{application_name}" added to the vault.', 'success')
    except KeyError:
        db_session.rollback()
        flash('Invalid environment or credential type.', 'error')
    except Exception as e:
        db_session.rollback()
        flash(f'Error adding credential: {str(e)}', 'error')
    finally:
        db_session.close()

    return redirect(url_for('application_support.secret_vault', tower_id=tower_id))


@application_support_bp.route('/secret-vault/<int:entry_id>/edit', methods=['POST'])
def edit_vault_entry(entry_id):
    """Update a credential (members with vault write access only).

    An empty password field keeps the existing encrypted password.
    """
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        entry = db_session.query(SecretVaultEntry).filter_by(id=entry_id).first()
        if not entry:
            flash('Credential not found', 'error')
            return redirect(url_for('application_support.index'))
        tower_id = entry.tower_id

        if not is_strict_tower_member(user, tower_id) or not can_manage_vault(user, tower_id):
            flash('Access denied. Only members granted password management rights can update credentials.', 'error')
            return redirect(url_for('application_support.secret_vault', tower_id=tower_id))

        if not validate_csrf_token(request.form.get('csrf_token')):
            flash('Invalid security token. Please try again.', 'error')
            return redirect(url_for('application_support.secret_vault', tower_id=tower_id))

        environment = request.form.get('environment')
        application_name = (request.form.get('application_name') or '').strip()
        credential_type = request.form.get('credential_type')
        resource = (request.form.get('resource') or '').strip()
        username = (request.form.get('username') or '').strip()
        password = request.form.get('password') or ''

        if not all([environment, application_name, credential_type, resource, username]):
            flash('Environment, application, type, URL/server/database and user name are required.', 'error')
            return redirect(url_for('application_support.secret_vault', tower_id=tower_id))

        try:
            entry.environment = EnvironmentType[environment]
            entry.credential_type = CredentialType[credential_type]
            entry.application_name = application_name
            entry.resource = resource
            entry.username = username
            if password:  # blank = keep current password
                entry.password_encrypted = encrypt_data(password)
            entry.updated_by = getattr(user, 'id', None)
            db_session.commit()
            tower = db_session.query(AppSupportTower).filter_by(id=tower_id).first()
            log_audit(user, tower.tower_name if tower else 'Unknown', 'Secret Vault', 'UPDATE',
                      f'Updated {entry.credential_type.value} credential for {application_name} ({resource})')
            flash(f'Credential for "{application_name}" updated.', 'success')
        except KeyError:
            db_session.rollback()
            flash('Invalid environment or credential type.', 'error')
        except Exception as e:
            db_session.rollback()
            flash(f'Error updating credential: {str(e)}', 'error')

        return redirect(url_for('application_support.secret_vault', tower_id=tower_id))
    finally:
        db_session.close()


@application_support_bp.route('/secret-vault/<int:entry_id>/delete', methods=['POST'])
def delete_vault_entry(entry_id):
    """Delete a credential (members with vault write access only)."""
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        entry = db_session.query(SecretVaultEntry).filter_by(id=entry_id).first()
        if not entry:
            flash('Credential not found', 'error')
            return redirect(url_for('application_support.index'))
        tower_id = entry.tower_id

        if not is_strict_tower_member(user, tower_id) or not can_manage_vault(user, tower_id):
            flash('Access denied. Only members granted password management rights can delete credentials.', 'error')
            return redirect(url_for('application_support.secret_vault', tower_id=tower_id))

        if not validate_csrf_token(request.form.get('csrf_token')):
            flash('Invalid security token. Please try again.', 'error')
            return redirect(url_for('application_support.secret_vault', tower_id=tower_id))

        app_name, resource = entry.application_name, entry.resource
        cred_type = entry.credential_type.value
        try:
            db_session.delete(entry)
            db_session.commit()
            tower = db_session.query(AppSupportTower).filter_by(id=tower_id).first()
            log_audit(user, tower.tower_name if tower else 'Unknown', 'Secret Vault', 'DELETE',
                      f'Deleted {cred_type} credential for {app_name} ({resource})')
            flash(f'Credential for "{app_name}" deleted from the vault.', 'success')
        except Exception as e:
            db_session.rollback()
            flash(f'Error deleting credential: {str(e)}', 'error')

        return redirect(url_for('application_support.secret_vault', tower_id=tower_id))
    finally:
        db_session.close()


@application_support_bp.route('/secret-vault/<int:entry_id>/reveal', methods=['POST'])
def reveal_vault_entry(entry_id):
    """Return the decrypted password (AJAX, tower members only).

    POST (not GET) so the password is never written to URL/access logs.
    Every reveal is recorded in the audit log - without the password.
    """
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401

    if not validate_csrf_token(request.form.get('csrf_token')):
        return jsonify({'error': 'Invalid security token'}), 403

    db_session = get_db_session()
    try:
        entry = db_session.query(SecretVaultEntry).filter_by(id=entry_id).first()
        if not entry:
            return jsonify({'error': 'Credential not found'}), 404

        if not is_strict_tower_member(user, entry.tower_id):
            return jsonify({'error': 'Access denied. Tower members only.'}), 403

        try:
            password = decrypt_data(entry.password_encrypted)
        except CredentialDecryptionError:
            return jsonify({'error': 'Stored password could not be decrypted. '
                                     'Contact a vault manager to re-save this credential.'}), 500

        tower = db_session.query(AppSupportTower).filter_by(id=entry.tower_id).first()
        log_audit(user, tower.tower_name if tower else 'Unknown', 'Secret Vault', 'REVEAL',
                  f'Revealed password for {entry.application_name} ({entry.resource})')
        return jsonify({'password': password})
    finally:
        db_session.close()


@application_support_bp.route('/tower/<int:tower_id>/member/<int:member_id>/toggle-vault-access', methods=['POST'])
@require_auth('admin')
def toggle_vault_access(tower_id, member_id):
    """Grant/revoke a member's right to add/update/delete vault passwords.

    This is the ONLY Secret Vault power an admin has - admins cannot see
    or open the vault itself.
    """
    user = get_current_user()

    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_tower_members', tower_id=tower_id))

    db_session = get_db_session()
    try:
        member = db_session.query(TowerMember).filter_by(id=member_id, tower_id=tower_id).first()
        if not member:
            flash('Tower member not found', 'error')
            return redirect(url_for('application_support.manage_tower_members', tower_id=tower_id))

        member.can_manage_secrets = not bool(member.can_manage_secrets)
        db_session.commit()

        member_name = get_user_name(member.user_id)
        tower = db_session.query(AppSupportTower).filter_by(id=tower_id).first()
        action = 'granted' if member.can_manage_secrets else 'revoked'
        log_audit(user, tower.tower_name if tower else 'Unknown', 'Secret Vault', 'UPDATE',
                  f'{action.capitalize()} vault password management for {member_name}')
        flash(f'Vault password management {action} for {member_name}.', 'success')
    except Exception as e:
        db_session.rollback()
        flash(f'Error updating vault access: {str(e)}', 'error')
    finally:
        db_session.close()

    return redirect(url_for('application_support.manage_tower_members', tower_id=tower_id))


# ---------------------------------------------------------------------------
# Team Members analytics  (org-wide: who supports what, and how thinly)
# ---------------------------------------------------------------------------

def _resource_identity(member_name, email):
    """
    Stable key for one support resource across applications. Email (the
    account address auto-filled from the member dropdown) is the reliable
    identity; fall back to the name when a legacy row has no email.
    """
    email = (email or '').strip().lower()
    if email:
        return email
    return 'name:' + (member_name or '').strip().lower()


def _team_member_analytics(db_session, tower_id=None, application_id=None):
    """
    Two cross-cutting views over the SupportTeam assignments of every ACTIVE
    application:

      resources - each support resource and how many applications they are
                  on (workload / key-person concentration)
      apps      - each application and how many resources support it
                  (coverage; a count of 1 is a single point of failure)

    Optional filters (both default to None = org-wide, i.e. the existing
    behaviour is unchanged when no filter is supplied):

      tower_id       - restrict everything to one tower
      application_id - restrict everything to one application

    Returns dict(resources=[...], apps=[...], kpis={...}) with rows already
    sorted worst/most first, ready for both the charts and the tables.
    """
    base_q = (db_session.query(SupportTeam, ApplicationDetails, AppSupportTower)
              .join(ApplicationDetails,
                    SupportTeam.application_id == ApplicationDetails.id)
              .join(AppSupportTower,
                    ApplicationDetails.tower_id == AppSupportTower.id)
              .filter(ApplicationDetails.is_active.is_(True)))
    if tower_id:
        base_q = base_q.filter(ApplicationDetails.tower_id == tower_id)
    if application_id:
        base_q = base_q.filter(ApplicationDetails.id == application_id)
    rows = base_q.all()

    resources = {}   # identity -> aggregate
    apps = {}        # application_id -> aggregate

    for st, app, tower in rows:
        ident = _resource_identity(st.member_name, st.email)
        r = resources.get(ident)
        if r is None:
            r = resources[ident] = {
                'name': (st.member_name or '').strip() or (st.email or ident),
                'email': (st.email or '').strip(),
                'app_ids': set(), 'app_names': set(),
                'towers': set(), 'roles': set(),
            }
        # Prefer a non-empty display name / email if a later row has one.
        if (st.member_name or '').strip():
            r['name'] = st.member_name.strip()
        if not r['email'] and (st.email or '').strip():
            r['email'] = st.email.strip()
        r['app_ids'].add(app.id)
        r['app_names'].add(app.application_name)
        r['towers'].add(tower.tower_name)
        if st.role is not None:
            r['roles'].add(st.role.value)

        a = apps.get(app.id)
        if a is None:
            a = apps[app.id] = {
                'id': app.id,
                'name': app.application_name,
                'tower': tower.tower_name,
                'criticality': (app.business_criticality.value
                                if app.business_criticality else '-'),
                'members': {},   # identity -> display name
            }
        a['members'][ident] = (st.member_name or '').strip() or ident

    # Applications that have NO support team row at all still deserve to show
    # as zero-coverage (the biggest risk of all).
    uncovered_q = (db_session.query(ApplicationDetails, AppSupportTower)
                   .join(AppSupportTower,
                         ApplicationDetails.tower_id == AppSupportTower.id)
                   .filter(ApplicationDetails.is_active.is_(True),
                           ~ApplicationDetails.id.in_(list(apps) or [-1])))
    if tower_id:
        uncovered_q = uncovered_q.filter(ApplicationDetails.tower_id == tower_id)
    if application_id:
        uncovered_q = uncovered_q.filter(ApplicationDetails.id == application_id)
    uncovered = uncovered_q.all()
    for app, tower in uncovered:
        apps[app.id] = {
            'id': app.id, 'name': app.application_name,
            'tower': tower.tower_name,
            'criticality': (app.business_criticality.value
                            if app.business_criticality else '-'),
            'members': {},
        }

    resource_rows = [{
        'name': r['name'], 'email': r['email'],
        'app_count': len(r['app_ids']),
        'apps': sorted(r['app_names']),
        'towers': sorted(r['towers']),
        'roles': sorted(r['roles']),
    } for r in resources.values()]
    resource_rows.sort(key=lambda x: (-x['app_count'], x['name'].lower()))

    app_rows = [{
        'name': a['name'], 'tower': a['tower'],
        'criticality': a['criticality'],
        'resource_count': len(a['members']),
        'members': sorted(a['members'].values()),
    } for a in apps.values()]
    app_rows.sort(key=lambda x: (x['resource_count'], x['name'].lower()))

    total_apps = len(app_rows)
    total_resources = len(resource_rows)
    single_support = sum(1 for a in app_rows if a['resource_count'] == 1)
    uncovered_apps = sum(1 for a in app_rows if a['resource_count'] == 0)
    avg_res = (round(sum(a['resource_count'] for a in app_rows) / total_apps, 1)
               if total_apps else 0)

    kpis = {
        'total_apps': total_apps,
        'total_resources': total_resources,
        'avg_resources_per_app': avg_res,
        'single_support': single_support,
        'uncovered_apps': uncovered_apps,
        'busiest': resource_rows[0] if resource_rows else None,
    }
    return {'resources': resource_rows, 'apps': app_rows, 'kpis': kpis}


# Coverage-chart bar colours by business criticality (echo the BC badges in
# the table). Dark enough to carry the white value labels; BC1 critical red
# -> BC3 normal green.
BC_CHART_COLORS = {'BC1': '#B91C1C', 'BC2': '#B45309', 'BC3': '#15803D'}
BC_CHART_LABELS = {'BC1': 'BC1 - Critical', 'BC2': 'BC2 - High',
                   'BC3': 'BC3 - Normal'}
BC_FALLBACK_COLOR = '#64748B'


@application_support_bp.route('/team-members')
def team_members():
    """Org-wide Team Members analytics: applications per resource and
    resources per application, each as a chart + table.

    Optional query-string filters (?tower=<id>&app=<id>). With no
    parameters the page behaves exactly as before (org-wide view)."""
    user = get_current_user()

    # --- Filters (both optional; invalid values fall back to None) ---------
    filter_tower_id = request.args.get('tower', type=int)
    filter_app_id = request.args.get('app', type=int)

    db_session = get_db_session()
    try:
        # Dropdown options. The application list narrows to the selected
        # tower so the two filters stay consistent with each other.
        filter_towers = [
            {'id': t.id, 'name': t.tower_name}
            for t in (db_session.query(AppSupportTower)
                      .filter(AppSupportTower.is_active.is_(True))
                      .order_by(AppSupportTower.tower_name)
                      .all())
        ]
        # Application options CASCADE from the tower selection: the dropdown
        # only exists once a tower is chosen, and it lists that tower's
        # active applications only. Default (no app chosen) = all
        # applications of the selected tower.
        filter_applications = []
        if filter_tower_id:
            filter_applications = [
                {'id': a.id, 'name': a.application_name}
                for a in (db_session.query(ApplicationDetails)
                          .filter(ApplicationDetails.is_active.is_(True),
                                  ApplicationDetails.tower_id == filter_tower_id)
                          .order_by(ApplicationDetails.application_name)
                          .all())
            ]

        # An application filter is only meaningful within a selected tower;
        # drop it if there is no tower or it doesn't belong to that tower.
        if filter_app_id and (not filter_tower_id or filter_app_id not in {
                a['id'] for a in filter_applications}):
            filter_app_id = None

        data = _team_member_analytics(
            db_session,
            tower_id=filter_tower_id,
            application_id=filter_app_id,
        )
    finally:
        db_session.close()

    # Chart payloads: horizontal bars, biggest on top. Cap to keep the plot
    # readable; the tables below always carry the complete list.
    CHART_CAP = 12
    top_resources = data['resources'][:CHART_CAP]
    res_chart = {
        'labels': [r['name'] for r in reversed(top_resources)],
        'values': [r['app_count'] for r in reversed(top_resources)],
        'color': '#2A78D6',
        'unit': ' apps',
    }
    # apps list is sorted least-covered first; show the most-supported in the
    # chart (tail), biggest on top.
    top_apps = data['apps'][-CHART_CAP:]
    app_chart = {
        'labels': [a['name'] for a in top_apps],
        'values': [a['resource_count'] for a in top_apps],
        'colors': [BC_CHART_COLORS.get(a['criticality'], BC_FALLBACK_COLOR)
                   for a in top_apps],
        'unit': ' people',
    }
    # Legend for the coverage chart: BC colour key with the count of
    # applications at each criticality (within the current filter).
    bc_legend = [{
        'code': code, 'label': BC_CHART_LABELS[code],
        'color': BC_CHART_COLORS[code],
        'count': sum(1 for a in data['apps'] if a['criticality'] == code),
    } for code in ('BC1', 'BC2', 'BC3')]

    filters_active = bool(filter_tower_id or filter_app_id)

    return render_template(
        'application_support/team_members.html',
        user=user, is_admin=is_admin(user),
        resources=data['resources'], apps=data['apps'], kpis=data['kpis'],
        res_chart=res_chart, app_chart=app_chart, bc_legend=bc_legend,
        chart_cap=CHART_CAP,
        filter_towers=filter_towers,
        filter_applications=filter_applications,
        selected_tower=filter_tower_id,
        selected_app=filter_app_id,
        filters_active=filters_active,
    )


# About page - explains the module to end users and the support team.
@application_support_bp.route('/about')
def about():
    user = get_current_user()
    return render_template('application_support/about.html', user=user)


# ---------------------------------------------------------------------------
# Professional downloads (Excel / PDF) - tower profile & application profile
# ---------------------------------------------------------------------------

from io import BytesIO
from . import export_docs

EXPORT_FORMATS = {
    'excel': ('.xlsx',
              'application/vnd.openxmlformats-officedocument.'
              'spreadsheetml.sheet'),
    'pdf':   ('.pdf', 'application/pdf'),
}


def _send_export(payload: bytes, stem: str, fmt: str):
    ext, mimetype = EXPORT_FORMATS[fmt]
    stamp = datetime.now().strftime('%Y%m%d')
    return send_file(BytesIO(payload), as_attachment=True,
                     download_name=f'{stem}_{stamp}{ext}', mimetype=mimetype)


@application_support_bp.route('/tower/<int:tower_id>/download/<fmt>')
def download_tower(tower_id, fmt):
    """Tower profile document: summary (tower info, lead) + applications
    grouped by business criticality. `fmt` is 'excel' or 'pdf'."""
    user = get_current_user()
    if not user:
        flash('Please login to download tower documents', 'error')
        return redirect(url_for('login'))
    if fmt not in EXPORT_FORMATS:
        abort(404)

    db_session = get_db_session()
    try:
        tower = db_session.query(AppSupportTower).filter_by(
            id=tower_id, is_active=True).first()
        if not tower:
            flash('Tower not found', 'error')
            return redirect(url_for('application_support.index'))

        apps_by_bc = {}
        for bc in BusinessCriticality:
            apps_by_bc[bc.value] = (
                db_session.query(ApplicationDetails)
                .filter_by(tower_id=tower_id, is_active=True,
                           business_criticality=bc)
                .order_by(ApplicationDetails.application_name)
                .all())
        member_count = db_session.query(TowerMember).filter_by(
            tower_id=tower_id).count()

        generated_by = get_user_name(getattr(user, 'id', None))
        if fmt == 'excel':
            payload = export_docs.build_tower_workbook(
                tower, apps_by_bc, member_count, generated_by)
        else:
            payload = export_docs.build_tower_pdf(
                tower, apps_by_bc, member_count, generated_by)

        log_audit(user, tower.tower_name, 'Tower', 'EXPORT',
                  f'Downloaded tower profile ({fmt})')
        stem = f'Tower_Profile_{export_docs.safe_filename(tower.tower_name)}'
        return _send_export(payload, stem, fmt)
    finally:
        db_session.close()


@application_support_bp.route('/application/<int:app_id>/download/<fmt>')
def download_application(app_id, fmt):
    """Application profile document: every piece of information held about
    the application. `fmt` is 'excel' or 'pdf'."""
    user = get_current_user()
    if not user:
        flash('Please login to download application documents', 'error')
        return redirect(url_for('login'))
    if fmt not in EXPORT_FORMATS:
        abort(404)

    db_session = get_db_session()
    try:
        app = db_session.query(ApplicationDetails).filter_by(
            id=app_id, is_active=True).first()
        if not app:
            flash('Application not found', 'error')
            return redirect(url_for('application_support.index'))

        data = {
            'servers': db_session.query(ServerDetails)
                       .filter_by(application_id=app_id).all(),
            'support_team': db_session.query(SupportTeam)
                            .filter_by(application_id=app_id).all(),
            'business_users': db_session.query(BusinessUsers)
                              .filter_by(application_id=app_id).all(),
            'vendors': db_session.query(VendorDetails)
                       .filter_by(application_id=app_id).all(),
            'interfaces': db_session.query(ExternalInterfaces)
                          .filter_by(application_id=app_id).all(),
            'individual_jobs': db_session.query(IndividualJobs)
                               .filter_by(application_id=app_id).all(),
            'suite_jobs': db_session.query(SuiteJobs)
                          .filter_by(application_id=app_id).all(),
            'files': db_session.query(FileInventory)
                     .filter_by(application_id=app_id).all(),
            'tasks': db_session.query(ApplicationTask)
                     .filter_by(application_id=app_id)
                     .order_by(ApplicationTask.created_at.desc()).all(),
            'critical_issues': db_session.query(CriticalIssue)
                               .filter_by(application_id=app_id)
                               .order_by(CriticalIssue.created_at.desc()).all(),
            'created_by_name': get_user_name(app.created_by),
            'updated_by_name': get_user_name(app.updated_by),
        }

        # Technical Details tab: the recorded stack plus the standards
        # sections its selections make relevant. Only ACTIVE sections are
        # exported, so the document matches the page it came from.
        stack_flat = tech_details.stack_rows(db_session, app_id)
        std_sections = tech_details.build_sections(
            db_session, stack_flat,
            tech_details.load_compliance(db_session, app_id))
        data['tech_stack'] = tech_details.load_stack(db_session, app_id)
        data['std_sections'] = std_sections
        data['std_summary'] = tech_details.overall_summary(std_sections)

        generated_by = get_user_name(getattr(user, 'id', None))
        if fmt == 'excel':
            payload = export_docs.build_application_workbook(
                app, data, generated_by)
        else:
            payload = export_docs.build_application_pdf(
                app, data, generated_by)

        log_audit(user, app.tower.tower_name if app.tower else 'Unknown',
                  'Application', 'EXPORT',
                  f'Downloaded application profile: {app.application_name} '
                  f'({fmt})')
        stem = ('Application_Profile_'
                + export_docs.safe_filename(app.application_name))
        return _send_export(payload, stem, fmt)
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Estate architecture view - the whole estate (towers, applications and
# their interface connectivity) as one dynamic diagram. Rebuilt live from
# the database on every request, so new towers / applications / interfaces
# appear automatically.
# ---------------------------------------------------------------------------

@application_support_bp.route('/architecture')
def estate_architecture():
    """Interactive layered ("semantic zoom") architecture view.

    Drills L1 estate -> L2 tower -> L3 application. The page is a shell: it
    fetches the whole estate once from /architecture/graph.json and does all
    drill-down client-side, so moving between altitudes costs no round-trip."""
    user = get_current_user()
    if not user:
        flash('Please login to view the architecture', 'error')
        return redirect(url_for('login'))
    return render_template('application_support/architecture.html',
                           user=user, is_admin=is_admin(user))


@application_support_bp.route('/architecture/graph.json')
def estate_architecture_graph():
    """The whole estate as one JSON graph - the layered view's data source.

    Every interface arrives already resolved (by hostname where possible,
    by application name otherwise), so the client renders rather than
    reasons. Not audit-logged: this fires on every page load of a view that
    is itself read-only, and logging it would bury the real events."""
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    db_session = get_db_session()
    try:
        return jsonify(build_estate_graph(db_session))
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Enterprise Architect view - the same estate read as a business landscape:
# every application grouped into its Application Category (business area)
# rather than into the tower that supports it.
# ---------------------------------------------------------------------------

@application_support_bp.route('/enterprise-architecture')
def enterprise_architecture():
    """Interactive enterprise landscape, drilling L1 domain -> L2 -> L3.

    Deliberately served from the SAME graph document as the tower view
    (/architecture/graph.json), which already carries the category grouping.
    A second endpoint would be a second source of truth about what is
    connected to what, and the two would drift."""
    user = get_current_user()
    if not user:
        flash('Please login to view the enterprise architecture', 'error')
        return redirect(url_for('login'))
    return render_template('application_support/enterprise_architecture.html',
                           user=user, is_admin=is_admin(user))


# ---------------------------------------------------------------------------
# Architecture insights - the analytics both views read off the same graph.
#
# One endpoint, two readings: ?grouping=tower is the Architecture View's,
# ?grouping=domain the Enterprise Architect's. Served separately from
# graph.json rather than folded into it, because the graph is fetched on
# every page load of a diagram whose reader may never open a fold, and the
# analysis is worth about as much CPU as the graph itself.
# ---------------------------------------------------------------------------

#: Query values callers may ask for, mapped to the analysis grouping. Anything
#: else is a 400 rather than a silent fallback: a caller that asked for the
#: wrong reading should be told, not quietly given the other one.
_INSIGHT_GROUPINGS = (insights.GROUPING_TOWER, insights.GROUPING_DOMAIN)

#: Hard ceiling on the diagram image a page may post up for the PDF. A
#: full-estate PNG at export resolution runs to a few hundred KB; anything
#: past this is not a diagram, and MAX_CONTENT_LENGTH (16 MB) is too blunt an
#: instrument to say so politely.
MAX_DIAGRAM_BYTES = 8 * 1024 * 1024


@application_support_bp.route('/architecture/insights.json')
def estate_architecture_insights():
    """The analytics pack for one reading of the estate.

    Rebuilt from the database on every call, exactly as the graph is: an
    insight that disagrees with the diagram beside it is worse than no
    insight. Not audit-logged, for the same reason graph.json is not."""
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401
    grouping = (request.args.get('grouping')
                or insights.GROUPING_DOMAIN).strip().lower()
    if grouping not in _INSIGHT_GROUPINGS:
        return jsonify({'error': 'Unknown grouping'}), 400
    db_session = get_db_session()
    try:
        graph = build_estate_graph(db_session)
        return jsonify(insights.build_insights(graph, grouping))
    finally:
        db_session.close()


def _decode_diagram(data_url):
    """The posted diagram as PNG bytes, or None.

    The page sends a `data:image/png;base64,...` URL - the same string the
    PNG download is built from. Anything malformed, oversized or not a PNG
    yields None so the report still prints without the picture, which is a
    far better outcome than a 500 on a download button.
    """
    if not data_url or not isinstance(data_url, str):
        return None
    marker = ';base64,'
    head, sep, payload = data_url.partition(marker)
    if not sep or not head.startswith('data:image/png'):
        return None
    if len(payload) > MAX_DIAGRAM_BYTES:
        return None
    try:
        raw = base64.b64decode(payload, validate=True)
    except (ValueError, binascii.Error):
        return None
    # PNG magic. A file that is not a PNG cannot be trusted to the image
    # reader, and the only thing this route does with it is embed it.
    if not raw.startswith(b'\x89PNG\r\n\x1a\n'):
        return None
    return raw


@application_support_bp.route('/architecture/export.pdf', methods=['POST'])
def estate_architecture_pdf():
    """The current diagram AND its analysis, as one branded PDF.

    POST rather than GET because the diagram travels with the request: both
    views draw HTML cards over an SVG wire layer and only the page that laid
    them out knows where everything ended up, so the page serialises the same
    model it drew and posts it up. Everything AROUND the picture is rebuilt
    here from the database, so the numbers in the report are the estate's,
    not the browser's - a page left open overnight cannot print stale
    figures under a fresh date.
    """
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Authentication required'}), 401

    payload = request.get_json(silent=True) or {}
    grouping = str(payload.get('grouping')
                   or insights.GROUPING_DOMAIN).strip().lower()
    if grouping not in _INSIGHT_GROUPINGS:
        return jsonify({'error': 'Unknown grouping'}), 400

    image_bytes = _decode_diagram(payload.get('image'))
    context = {
        'view': _clean_text(payload.get('view'), 80),
        'title': _clean_text(payload.get('title'), 160),
        'subtitle': _clean_text(payload.get('subtitle'), 300),
        'caption': _clean_text(payload.get('caption'), 400),
        'filters': _clean_text(payload.get('filters'), 200),
    }

    db_session = get_db_session()
    try:
        graph = build_estate_graph(db_session)
        pack = insights.build_insights(graph, grouping)
        report = export_docs.build_architecture_pdf(
            context, pack, image_bytes,
            get_user_name(getattr(user, 'id', None)))

        scope = context['title'] or pack['view']
        log_audit(user, scope, 'Architecture', 'EXPORT',
                  'Downloaded architecture report ({0} view, {1} '
                  'finding(s))'.format(grouping, pack['findings']['total']))
        stem = 'Architecture_Report_' + export_docs.safe_filename(
            scope or grouping)
        return _send_export(report, stem, 'pdf')
    finally:
        db_session.close()


def _clean_text(value, limit):
    """A caller-supplied caption, made safe to print.

    These strings are written by the page, but they arrive over the wire and
    end up in a document, so they are treated as untrusted: collapse
    whitespace (a newline would break a table cell), drop control characters,
    and cut to a length that cannot push a heading off the page. Escaping is
    the PDF builder's job; this is about shape, not markup.
    """
    if not isinstance(value, str):
        return ''
    printable = ''.join(ch if ch >= ' ' else ' ' for ch in value)
    return ' '.join(printable.split())[:limit]




# ---------------------------------------------------------------------------
# Search - find a tower or application by (partial) name
# ---------------------------------------------------------------------------

def _search_pattern(q: str) -> str:
    """SQL LIKE pattern for a user query. A plain term becomes a substring
    match; the user may also use * (any run) and ? (single char) wildcards."""
    if '*' in q or '?' in q:
        pattern = (q.replace('\\', '\\\\').replace('%', r'\%')
                    .replace('_', r'\_').replace('*', '%').replace('?', '_'))
        return pattern
    escaped = (q.replace('\\', '\\\\').replace('%', r'\%')
                .replace('_', r'\_'))
    return f'%{escaped}%'


@application_support_bp.route('/search')
def search():
    """Search towers and applications by name (wildcard-friendly) so users
    who know an application but not its tower can jump straight to it."""
    user = get_current_user()
    q = (request.args.get('q') or '').strip()

    towers, apps = [], []
    if q:
        pattern = _search_pattern(q)
        db_session = get_db_session()
        try:
            towers = (db_session.query(AppSupportTower)
                      .filter(AppSupportTower.is_active.is_(True))
                      .filter(or_(
                          AppSupportTower.tower_name.ilike(pattern, escape='\\'),
                          AppSupportTower.tower_lead.ilike(pattern, escape='\\')))
                      .order_by(AppSupportTower.tower_name)
                      .all())
            # outerjoin, not join: an uncategorised application must still
            # be findable by name. The category name is searchable too, so
            # "finance" surfaces the whole business area.
            app_rows = (db_session.query(ApplicationDetails, AppSupportTower,
                                         ApplicationCategory)
                        .join(AppSupportTower,
                              ApplicationDetails.tower_id == AppSupportTower.id)
                        .outerjoin(ApplicationCategory,
                                   ApplicationDetails.category_id ==
                                   ApplicationCategory.id)
                        .filter(ApplicationDetails.is_active.is_(True),
                                AppSupportTower.is_active.is_(True))
                        .filter(or_(
                            ApplicationDetails.application_name.ilike(
                                pattern, escape='\\'),
                            ApplicationDetails.application_summary.ilike(
                                pattern, escape='\\'),
                            ApplicationCategory.name.ilike(
                                pattern, escape='\\')))
                        .order_by(ApplicationDetails.application_name)
                        .all())
            apps = [{
                'id': a.id,
                'name': a.application_name,
                'summary': a.application_summary or '',
                'criticality': a.business_criticality.value,
                'category': c.name if c else '',
                'tower_id': t.id,
                'tower_name': t.tower_name,
                # Name matches rank above description-only matches.
                'name_match': q.replace('*', '').replace('?', '').lower()
                              in (a.application_name or '').lower(),
            } for a, t, c in app_rows]
            apps.sort(key=lambda r: (not r['name_match'], r['name'].lower()))
        finally:
            db_session.close()

    return render_template('application_support/search.html',
                           user=user, q=q, towers=towers, apps=apps)




# ===========================================================================
# Technical Details
#
# Two screens for tower members:
#   /application/<id>/technical      edit the stack AND answer the standards
#                                    checklist in one submit
# and two for admins:
#   /admin/technical-catalog         the dropdown values behind that form
#   /admin/standards-checklist       the checklist master itself
#
# The checklist sections the form shows follow the stack the user picks, so
# the page carries every section up front and reveals them client-side; the
# POST re-derives the active sections from the SAVED stack and ignores
# anything outside them.
# ===========================================================================

@application_support_bp.route('/application/<int:app_id>/technical',
                              methods=['GET', 'POST'])
def edit_technical_details(app_id):
    """Edit an application's technology stack and standards compliance."""
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        app = db_session.query(ApplicationDetails).filter_by(
            id=app_id, is_active=True).first()
        if not app:
            flash('Application not found', 'error')
            return redirect(url_for('application_support.index'))

        if not (is_admin(user) or is_tower_member(user, app.tower_id)):
            flash('Access denied. You are not a member of this tower.', 'error')
            return redirect(url_for('application_support.view_application',
                                    app_id=app_id))

        tower = db_session.query(AppSupportTower).filter_by(
            id=app.tower_id).first()

        if request.method == 'POST':
            if not validate_csrf_token(request.form.get('csrf_token')):
                flash('Invalid security token. Please try again.', 'error')
                return redirect(request.url)

            try:
                catalog_lookup = dict(
                    (row.id, row) for row in db_session.query(TechCatalog).all())
                rows = tech_details.parse_stack(request.form, catalog_lookup)
                tech_details.save_stack(db_session, app_id, rows)
                # Flush so the checklist scope is derived from what was just
                # saved rather than from the pre-edit stack.
                db_session.flush()

                sections = tech_details.build_sections(
                    db_session, tech_details.stack_rows(db_session, app_id),
                    tech_details.load_compliance(db_session, app_id))
                saved, errors = tech_details.save_compliance(
                    db_session, app_id, request.form, sections, user.id)

                app.updated_by = user.id
                app.updated_at = datetime.now()
                db_session.commit()

                log_audit(user, tower.tower_name if tower else 'Unknown',
                          'Technical Details', 'UPDATE',
                          'Updated technical details for {0}: {1} stack item(s), '
                          '{2} standards answer(s)'.format(
                              app.application_name, len(rows), saved))
                if errors:
                    flash('Saved, but {0} answer(s) were skipped: {1}'.format(
                        len(errors), '; '.join(errors[:3])), 'warning')
                else:
                    flash('Technical details updated successfully!', 'success')
                return redirect(url_for('application_support.view_application',
                                        app_id=app_id) + '#technical')
            except Exception as e:
                db_session.rollback()
                flash('Error saving technical details: {0}'.format(e), 'error')

        stack = tech_details.load_stack(db_session, app_id)
        # include_all: every section ships with the page so picking a
        # technology reveals its checklist without a reload.
        sections = tech_details.build_sections(
            db_session, tech_details.stack_rows(db_session, app_id),
            tech_details.load_compliance(db_session, app_id),
            include_all=True)

        return render_template(
            'application_support/technical_details.html',
            user=user, app=app, tower=tower, stack=stack,
            catalog=tech_details.catalog_options(db_session),
            categories=TECH_CATEGORIES,
            category_meta=tech_details.CATEGORY_META,
            category_field=tech_details.CATEGORY_FIELD,
            sections=sections,
            statuses=tech_details.STATUSES,
            date_statuses=tech_details.DATE_STATUSES,
            vendor_status=tech_details.STATUS_VENDOR,
            vendor_comment=tech_details.VENDOR_COMMENT)
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Admin - dropdown catalog
# ---------------------------------------------------------------------------

@application_support_bp.route('/admin/technical-catalog')
def manage_tech_catalog(import_errors=None):
    """Admin: maintain the OS / database / tool / language dropdown values.

    ``import_errors`` is passed by the bulk-upload route, which renders this
    page directly rather than redirecting: a per-row report is the whole
    point of a rejected file and would not survive a flash message.
    """
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))

    db_session = get_db_session()
    try:
        catalog = tech_details.catalog_options(db_session, include_inactive=True)
        usage = {}
        for rows in catalog.values():
            for row in rows:
                usage[row.id] = tech_details.catalog_in_use(db_session, row.id)
        return render_template(
            'application_support/admin_tech_catalog.html',
            user=user, catalog=catalog, usage=usage,
            categories=TECH_CATEGORIES,
            category_meta=tech_details.CATEGORY_META,
            import_errors=import_errors or [])
    finally:
        db_session.close()


# --- Bulk load ------------------------------------------------------------
# Both reference screens share one workbook and one pair of routes' worth of
# behaviour; see bulk_import for the upsert-only, all-or-nothing rules.

BULK_TARGETS = {
    'catalog': ('application_support.manage_tech_catalog',
                'Technical Catalog'),
    'checklist': ('application_support.manage_standards_checklist',
                  'Standards Checklist'),
}


def _bulk_guard(target):
    """(user, redirect) - the redirect is None when the request may proceed."""
    endpoint = BULK_TARGETS[target][0]
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return None, redirect(url_for('application_support.index'))
    if request.method == 'POST' and not validate_csrf_token(
            request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return None, redirect(url_for(endpoint))
    return user, None


@application_support_bp.route('/admin/reference-data/template')
def download_reference_template():
    """The bulk-load workbook, pre-filled with everything recorded today.

    One file carries both sheets, so it is the same download from either
    screen - edit it in Excel and upload it back.

    On a brand new installation both lists are empty, so this is an empty
    template with its headers and its How To Use tab. The starting content
    for a first load ships as sample_data/application_support_reference_data
    .xlsx - see tools/build_reference_workbook.py.
    """
    user, bounce = _bulk_guard('catalog')
    if bounce is not None:
        return bounce

    db_session = get_db_session()
    try:
        payload = bulk_import.build_workbook(db_session)
    finally:
        db_session.close()
    stamp = datetime.now().strftime('%Y%m%d')
    return send_file(
        BytesIO(payload), as_attachment=True,
        download_name='reference_data_{0}.xlsx'.format(stamp),
        mimetype='application/vnd.openxmlformats-officedocument.'
                 'spreadsheetml.sheet')


def _bulk_upload(target):
    """
    Validate the posted workbook and apply it, or report why it was rejected.

    Returns the list of per-row errors; an empty list means it was applied
    and the outcome has already been flashed. Nothing is written unless
    every row is valid - see bulk_import.
    """
    endpoint, label = BULK_TARGETS[target]
    upload = request.files.get('file')
    if upload is None or not upload.filename:
        flash('Choose an Excel file to upload.', 'error')
        return []
    if os.path.splitext(upload.filename)[1].lower() not in ('.xlsx', '.xlsm'):
        flash('Upload an Excel workbook (.xlsx).', 'error')
        return []

    user = get_current_user()
    db_session = get_db_session()
    try:
        payload = BytesIO(upload.read())
        try:
            if target == 'catalog':
                rows, errors = bulk_import.parse_catalog(payload)
            else:
                rows, errors = bulk_import.parse_checklist(payload, db_session)
        except bulk_import.ImportError_ as exc:
            flash(str(exc), 'error')
            return []

        if errors:
            flash('{0} row problem{1} found - nothing was saved. Fix the file '
                  'and upload it again.'.format(
                      len(errors), '' if len(errors) == 1 else 's'), 'error')
            return errors[:bulk_import.MAX_REPORTED_ERRORS]

        if not rows:
            flash('That sheet has no rows to load.', 'warning')
            return []

        if target == 'catalog':
            result = bulk_import.apply_catalog(db_session, rows, user.id)
        else:
            result = bulk_import.apply_checklist(db_session, rows, user.id)

        log_audit(user, 'Administration', label, 'INSERT',
                  'Bulk load: {0} added, {1} updated'.format(
                      result['created'], result['updated']))
        message = ('Loaded {0} row{1}: {2} added, {3} updated, {4} already '
                   'up to date.'.format(
                       len(rows), '' if len(rows) == 1 else 's',
                       result['created'], result['updated'],
                       result['unchanged']))
        if result.get('recarried'):
            message += (' {0} application row{1} carried a re-worded '
                        'description.'.format(
                            result['recarried'],
                            '' if result['recarried'] == 1 else 's'))
        flash(message, 'success')
        return []
    except Exception as e:
        db_session.rollback()
        flash('Could not load the file: {0}'.format(e), 'error')
        return []
    finally:
        db_session.close()


@application_support_bp.route('/admin/technical-catalog/upload',
                              methods=['POST'])
def upload_tech_catalog():
    """Admin: bulk load the Technology Catalog sheet of the workbook."""
    _user, bounce = _bulk_guard('catalog')
    if bounce is not None:
        return bounce
    errors = _bulk_upload('catalog')
    return manage_tech_catalog(import_errors=errors)


@application_support_bp.route('/admin/standards-checklist/upload',
                              methods=['POST'])
def upload_standards_checklist():
    """Admin: bulk load the Standards Checklist sheet of the workbook."""
    _user, bounce = _bulk_guard('checklist')
    if bounce is not None:
        return bounce
    errors = _bulk_upload('checklist')
    return manage_standards_checklist(import_errors=errors)


@application_support_bp.route('/admin/technical-catalog/add', methods=['POST'])
def add_tech_catalog_entry():
    """Admin: add one dropdown value."""
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))
    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_tech_catalog'))

    category = (request.form.get('category') or '').strip()
    name = (request.form.get('name') or '').strip()
    description = (request.form.get('description') or '').strip()

    if category not in TECH_CATEGORIES:
        flash('Unknown category.', 'error')
        return redirect(url_for('application_support.manage_tech_catalog'))
    if not name:
        flash('A name is required.', 'error')
        return redirect(url_for('application_support.manage_tech_catalog'))

    db_session = get_db_session()
    try:
        # Same fold the bulk load uses, so typing a name that differs only
        # in capitals or spacing lands on the entry that is already there
        # instead of adding a near-twin beside it.
        clash = tech_details.find_catalog_entry(db_session, category, name)
        if clash:
            if not clash.is_active:
                clash.is_active = True
                db_session.commit()
                flash('"{0}" already existed and has been re-activated.'.format(
                    clash.name), 'info')
            else:
                flash('"{0}" already exists in this category.'.format(
                    clash.name), 'warning')
            return redirect(url_for('application_support.manage_tech_catalog'))

        db_session.add(TechCatalog(category=category, name=name,
                                   description=description or None,
                                   sort_order=500, is_active=True,
                                   created_by=user.id))
        db_session.commit()
        log_audit(user, 'Administration', 'Technical Catalog', 'INSERT',
                  'Added {0} option: {1}'.format(category, name))
        flash('Added "{0}".'.format(name), 'success')
    except Exception as e:
        db_session.rollback()
        flash('Could not add the option: {0}'.format(e), 'error')
    finally:
        db_session.close()
    return redirect(url_for('application_support.manage_tech_catalog'))


@application_support_bp.route(
    '/admin/technical-catalog/<int:entry_id>/edit', methods=['POST'])
def edit_tech_catalog_entry(entry_id):
    """
    Admin: reword one dropdown value's description.

    That description is the house wording the Technical Details form
    pre-fills into an application's technology row, so a reword also moves
    every application row that still carries the PREVIOUS wording verbatim -
    those provably never diverged from the catalog. A row somebody has
    written over keeps exactly what they typed.

    The NAME is deliberately not editable here: an application row stores
    item_name as it stood when it was saved and is displayed by that name,
    so a rename would leave the estate half-renamed. Retire the entry and
    add the replacement instead.
    """
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))
    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_tech_catalog'))

    description = (request.form.get('description') or '').strip()

    db_session = get_db_session()
    try:
        entry = db_session.query(TechCatalog).filter_by(id=entry_id).first()
        if not entry:
            flash('Option not found.', 'error')
            return redirect(url_for('application_support.manage_tech_catalog'))

        previous = (entry.description or '').strip()
        if previous == description:
            flash('No change to "{0}".'.format(entry.name), 'info')
            return redirect(url_for('application_support.manage_tech_catalog'))

        entry.description = description or None

        carried = tech_details.recarry_stack_descriptions(
            db_session, entry.id, previous, description)
        # A row saved before this entry had any wording is blank, so there is
        # nothing for the carry above to match - fill it instead.
        carried += tech_details.fill_blank_stack_descriptions(
            db_session, entry.id, description)
        db_session.commit()
        log_audit(user, 'Administration', 'Technical Catalog', 'UPDATE',
                  'Reworded {0} option: {1}'.format(entry.category, entry.name))
        if carried:
            flash('Updated "{0}". {1} application row{2} carried the same '
                  'wording and moved with it.'.format(
                      entry.name, carried, '' if carried == 1 else 's'),
                  'success')
        else:
            flash('Updated "{0}".'.format(entry.name), 'success')
    except Exception as e:
        db_session.rollback()
        flash('Could not update the option: {0}'.format(e), 'error')
    finally:
        db_session.close()
    return redirect(url_for('application_support.manage_tech_catalog'))


@application_support_bp.route(
    '/admin/technical-catalog/<int:entry_id>/toggle', methods=['POST'])
def toggle_tech_catalog_entry(entry_id):
    """Admin: retire or restore a dropdown value without losing history."""
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))
    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_tech_catalog'))

    db_session = get_db_session()
    try:
        entry = db_session.query(TechCatalog).filter_by(id=entry_id).first()
        if not entry:
            flash('Option not found.', 'error')
            return redirect(url_for('application_support.manage_tech_catalog'))
        entry.is_active = not bool(entry.is_active)
        db_session.commit()
        log_audit(user, 'Administration', 'Technical Catalog', 'UPDATE',
                  '{0} {1} option: {2}'.format(
                      'Activated' if entry.is_active else 'Retired',
                      entry.category, entry.name))
        flash('"{0}" is now {1}.'.format(
            entry.name, 'active' if entry.is_active else 'retired'), 'success')
    except Exception as e:
        db_session.rollback()
        flash('Could not update the option: {0}'.format(e), 'error')
    finally:
        db_session.close()
    return redirect(url_for('application_support.manage_tech_catalog'))


@application_support_bp.route(
    '/admin/technical-catalog/<int:entry_id>/delete', methods=['POST'])
def delete_tech_catalog_entry(entry_id):
    """
    Admin: delete a dropdown value.

    A value an application has already recorded is RETIRED instead of
    deleted - deleting it would silently strip the technology from those
    applications and orphan their checklist answers.
    """
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))
    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_tech_catalog'))

    db_session = get_db_session()
    try:
        entry = db_session.query(TechCatalog).filter_by(id=entry_id).first()
        if not entry:
            flash('Option not found.', 'error')
            return redirect(url_for('application_support.manage_tech_catalog'))

        name, category = entry.name, entry.category
        in_use, item_count = tech_details.catalog_in_use(db_session, entry_id)
        if in_use:
            entry.is_active = False
            db_session.commit()
            log_audit(user, 'Administration', 'Technical Catalog', 'UPDATE',
                      'Retired in-use {0} option: {1}'.format(category, name))
            flash('"{0}" is used by {1} application record(s), so it has been '
                  'retired rather than deleted. It no longer appears in the '
                  'dropdown.'.format(name, in_use), 'warning')
            return redirect(url_for('application_support.manage_tech_catalog'))

        # Unused: its checklist items go with it.
        (db_session.query(StandardChecklistItem)
         .filter_by(catalog_id=entry_id).delete())
        db_session.delete(entry)
        db_session.commit()
        log_audit(user, 'Administration', 'Technical Catalog', 'DELETE',
                  'Deleted {0} option: {1} (and {2} checklist item(s))'.format(
                      category, name, item_count))
        flash('Deleted "{0}" and its {1} checklist item(s).'.format(
            name, item_count), 'success')
    except Exception as e:
        db_session.rollback()
        flash('Could not delete the option: {0}'.format(e), 'error')
    finally:
        db_session.close()
    return redirect(url_for('application_support.manage_tech_catalog'))


# ---------------------------------------------------------------------------
# Admin - application categories
#
# The business-area dropdown behind every application (Finance, Registration,
# CRM, ...). Same shape as the technical catalog above and for the same
# reason: the list belongs to the organisation, so it has to be editable
# without a release.
#
# Deleting a category that applications record is downgraded to a RETIRE -
# see delete_application_category().
# ---------------------------------------------------------------------------

@application_support_bp.route('/admin/application-categories')
def manage_application_categories():
    """Admin: maintain the application category dropdown values."""
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))

    db_session = get_db_session()
    try:
        categories.ensure_seeded(db_session)
        rows = categories.list_categories(db_session, include_inactive=True)
        usage = categories.usage_counts(db_session)
        unassigned = (db_session.query(func.count(ApplicationDetails.id))
                      .filter(ApplicationDetails.is_active.is_(True),
                              ApplicationDetails.category_id.is_(None))
                      .scalar() or 0)
        return render_template(
            'application_support/admin_categories.html',
            user=user, categories=rows, usage=usage, unassigned=unassigned)
    finally:
        db_session.close()


@application_support_bp.route('/admin/application-categories/add',
                              methods=['POST'])
def add_application_category():
    """Admin: add one category to the dropdown."""
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))
    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_application_categories'))

    name, error = categories.validate_name(request.form.get('name'))
    if error:
        flash(error, 'error')
        return redirect(url_for('application_support.manage_application_categories'))
    description = categories.clean_description(request.form.get('description'))

    db_session = get_db_session()
    try:
        clash = categories.find_by_name(db_session, name)
        if clash:
            # Re-adding a retired category is what an admin means by "add it
            # back", so do that instead of reporting a duplicate.
            if not clash.is_active:
                clash.is_active = True
                clash.updated_by = user.id
                db_session.commit()
                log_audit(user, 'Administration', 'Application Category',
                          'UPDATE', 'Re-activated category: {0}'.format(clash.name))
                flash('"{0}" already existed and has been re-activated.'.format(
                    clash.name), 'info')
            else:
                flash('"{0}" already exists.'.format(clash.name), 'warning')
            return redirect(url_for('application_support.manage_application_categories'))

        db_session.add(ApplicationCategory(
            name=name, description=description,
            sort_order=categories.DEFAULT_SORT_ORDER,
            is_active=True, created_by=user.id, updated_by=user.id))
        db_session.commit()
        log_audit(user, 'Administration', 'Application Category', 'INSERT',
                  'Added category: {0}'.format(name))
        flash('Added category "{0}".'.format(name), 'success')
    except Exception as e:
        db_session.rollback()
        flash('Could not add the category: {0}'.format(e), 'error')
    finally:
        db_session.close()
    return redirect(url_for('application_support.manage_application_categories'))


@application_support_bp.route(
    '/admin/application-categories/<int:category_id>/edit', methods=['POST'])
def edit_application_category(category_id):
    """
    Admin: rename a category or re-word its description.

    A rename flows straight through to every application that references it -
    that is the point of holding the name in one row rather than copying it
    onto each application.
    """
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))
    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_application_categories'))

    name, error = categories.validate_name(request.form.get('name'))
    if error:
        flash(error, 'error')
        return redirect(url_for('application_support.manage_application_categories'))
    description = categories.clean_description(request.form.get('description'))

    db_session = get_db_session()
    try:
        entry = categories.get_category(db_session, category_id)
        if not entry:
            flash('Category not found.', 'error')
            return redirect(url_for('application_support.manage_application_categories'))

        clash = categories.find_by_name(db_session, name, exclude_id=category_id)
        if clash:
            flash('"{0}" already exists.'.format(clash.name), 'warning')
            return redirect(url_for('application_support.manage_application_categories'))

        was = entry.name
        entry.name = name
        entry.description = description
        entry.updated_by = user.id
        entry.updated_at = datetime.now()
        db_session.commit()
        log_audit(user, 'Administration', 'Application Category', 'UPDATE',
                  'Renamed category: {0} -> {1}'.format(was, name)
                  if was != name else 'Updated category: {0}'.format(name))
        flash('Updated "{0}".'.format(name), 'success')
    except Exception as e:
        db_session.rollback()
        flash('Could not update the category: {0}'.format(e), 'error')
    finally:
        db_session.close()
    return redirect(url_for('application_support.manage_application_categories'))


@application_support_bp.route(
    '/admin/application-categories/<int:category_id>/toggle', methods=['POST'])
def toggle_application_category(category_id):
    """Admin: retire or restore a category without losing history."""
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))
    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_application_categories'))

    db_session = get_db_session()
    try:
        entry = categories.get_category(db_session, category_id)
        if not entry:
            flash('Category not found.', 'error')
            return redirect(url_for('application_support.manage_application_categories'))

        entry.is_active = not bool(entry.is_active)
        entry.updated_by = user.id
        entry.updated_at = datetime.now()
        in_use = categories.category_in_use(db_session, category_id)
        db_session.commit()
        log_audit(user, 'Administration', 'Application Category', 'UPDATE',
                  '{0} category: {1}'.format(
                      'Activated' if entry.is_active else 'Retired', entry.name))
        if entry.is_active:
            flash('"{0}" is active again.'.format(entry.name), 'success')
        else:
            flash('"{0}" is retired. It no longer appears in the dropdown; the '
                  '{1} application(s) already classified under it keep '
                  'it.'.format(entry.name, in_use), 'success')
    except Exception as e:
        db_session.rollback()
        flash('Could not update the category: {0}'.format(e), 'error')
    finally:
        db_session.close()
    return redirect(url_for('application_support.manage_application_categories'))


@application_support_bp.route(
    '/admin/application-categories/<int:category_id>/delete', methods=['POST'])
def delete_application_category(category_id):
    """
    Admin: delete a category.

    A category applications already record is RETIRED instead of deleted -
    deleting it would silently un-classify those applications. Pass
    ``force=1`` to go through with it anyway; the applications are then
    explicitly un-classified and the count is written to the audit log.
    """
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))
    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_application_categories'))

    force = (request.form.get('force') or '').strip() == '1'

    db_session = get_db_session()
    try:
        entry = categories.get_category(db_session, category_id)
        if not entry:
            flash('Category not found.', 'error')
            return redirect(url_for('application_support.manage_application_categories'))

        name = entry.name
        in_use = categories.category_in_use(db_session, category_id)

        if in_use and not force:
            entry.is_active = False
            entry.updated_by = user.id
            entry.updated_at = datetime.now()
            db_session.commit()
            log_audit(user, 'Administration', 'Application Category', 'UPDATE',
                      'Retired in-use category: {0}'.format(name))
            flash('"{0}" is used by {1} application(s), so it has been retired '
                  'rather than deleted. It no longer appears in the '
                  'dropdown.'.format(name, in_use), 'warning')
            return redirect(url_for('application_support.manage_application_categories'))

        if in_use:
            categories.clear_category(db_session, category_id)
        db_session.delete(entry)
        db_session.commit()
        log_audit(user, 'Administration', 'Application Category', 'DELETE',
                  'Deleted category: {0} ({1} application(s) un-classified)'
                  .format(name, in_use))
        if in_use:
            flash('Deleted "{0}". {1} application(s) are now '
                  'uncategorised.'.format(name, in_use), 'success')
        else:
            flash('Deleted "{0}".'.format(name), 'success')
    except Exception as e:
        db_session.rollback()
        flash('Could not delete the category: {0}'.format(e), 'error')
    finally:
        db_session.close()
    return redirect(url_for('application_support.manage_application_categories'))


# ---------------------------------------------------------------------------
# Admin - standards checklist master
# ---------------------------------------------------------------------------

@application_support_bp.route('/admin/standards-checklist')
def manage_standards_checklist(import_errors=None):
    """Admin: maintain the general and technology-specific checklist items.

    ``import_errors`` is passed by the bulk-upload route - see
    manage_tech_catalog for why that renders instead of redirecting.
    """
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))

    db_session = get_db_session()
    try:
        catalog = dict((row.id, row)
                       for row in db_session.query(TechCatalog).all())
        items = (db_session.query(StandardChecklistItem)
                 .order_by(StandardChecklistItem.scope,
                           StandardChecklistItem.sort_order,
                           StandardChecklistItem.id).all())

        # scope key -> {title, subtitle, scope, catalog_id, items, usage}
        groups = []
        index = {}
        for item in items:
            key = tech_details.scope_key(item.scope, item.catalog_id)
            if key not in index:
                if item.scope == 'general':
                    title, subtitle = 'General', 'Applies to every application'
                else:
                    entry = catalog.get(item.catalog_id)
                    if entry is None:
                        continue
                    title = entry.name
                    subtitle = tech_details.CATEGORY_META.get(
                        item.scope, ('', '', ''))[0]
                index[key] = {'key': key, 'scope': item.scope,
                              'catalog_id': item.catalog_id,
                              'title': title, 'subtitle': subtitle,
                              'items': []}
                groups.append(index[key])
            index[key]['items'].append({
                'item': item,
                'answers': tech_details.checklist_in_use(db_session, item.id),
            })

        rank = dict((c, i + 1) for i, c in enumerate(TECH_CATEGORIES))
        groups.sort(key=lambda g: (0 if g['scope'] == 'general'
                                   else rank.get(g['scope'], 99),
                                   g['title'].lower()))

        return render_template(
            'application_support/admin_standards_checklist.html',
            user=user, groups=groups,
            catalog=tech_details.catalog_options(db_session,
                                                 include_inactive=True),
            categories=TECH_CATEGORIES,
            category_meta=tech_details.CATEGORY_META,
            import_errors=import_errors or [])
    finally:
        db_session.close()


@application_support_bp.route('/admin/standards-checklist/add', methods=['POST'])
def add_standards_checklist_item():
    """Admin: add one checklist item, general or attached to a technology."""
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))
    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_standards_checklist'))

    scope = (request.form.get('scope') or '').strip()
    name = (request.form.get('name') or '').strip()
    description = (request.form.get('description') or '').strip()
    raw_catalog_id = (request.form.get('catalog_id') or '').strip()

    if scope not in CHECKLIST_SCOPES:
        flash('Unknown checklist scope.', 'error')
        return redirect(url_for('application_support.manage_standards_checklist'))
    if not name:
        flash('A checklist item name is required.', 'error')
        return redirect(url_for('application_support.manage_standards_checklist'))

    db_session = get_db_session()
    try:
        catalog_id = None
        if scope != 'general':
            try:
                catalog_id = int(raw_catalog_id)
            except (TypeError, ValueError):
                flash('Pick the technology this item belongs to.', 'error')
                return redirect(url_for(
                    'application_support.manage_standards_checklist'))
            entry = db_session.query(TechCatalog).filter_by(
                id=catalog_id, category=scope).first()
            if entry is None:
                flash('That technology does not exist in this category.', 'error')
                return redirect(url_for(
                    'application_support.manage_standards_checklist'))

        # As with the catalog, a practice already recorded in this section is
        # re-activated rather than written a second time - two rows asking
        # the same question would each collect their own answers.
        clash = tech_details.checklist_index(db_session).get(
            (scope, catalog_id, tech_details.match_key(name)))
        if clash is not None:
            if not clash.is_active:
                clash.is_active = True
                clash.updated_by = user.id
                clash.updated_at = datetime.now()
                db_session.commit()
                flash('"{0}" already existed here and has been '
                      're-activated.'.format(clash.name), 'info')
            else:
                flash('"{0}" is already on this checklist.'.format(clash.name),
                      'warning')
            return redirect(url_for(
                'application_support.manage_standards_checklist'))

        next_order = (db_session.query(func.max(StandardChecklistItem.sort_order))
                      .filter_by(scope=scope, catalog_id=catalog_id)
                      .scalar() or 0) + 10

        db_session.add(StandardChecklistItem(
            scope=scope, catalog_id=catalog_id, name=name,
            description=description or None, sort_order=next_order,
            is_active=True, is_seeded=False,
            created_by=user.id, updated_by=user.id))
        db_session.commit()
        log_audit(user, 'Administration', 'Standards Checklist', 'INSERT',
                  'Added {0} checklist item: {1}'.format(scope, name))
        flash('Added checklist item "{0}".'.format(name), 'success')
    except Exception as e:
        db_session.rollback()
        flash('Could not add the checklist item: {0}'.format(e), 'error')
    finally:
        db_session.close()
    return redirect(url_for('application_support.manage_standards_checklist'))


@application_support_bp.route(
    '/admin/standards-checklist/<int:item_id>/edit', methods=['POST'])
def edit_standards_checklist_item(item_id):
    """Admin: reword one checklist item."""
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))
    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_standards_checklist'))

    name = (request.form.get('name') or '').strip()
    description = (request.form.get('description') or '').strip()
    if not name:
        flash('A checklist item name is required.', 'error')
        return redirect(url_for('application_support.manage_standards_checklist'))

    db_session = get_db_session()
    try:
        item = db_session.query(StandardChecklistItem).filter_by(
            id=item_id).first()
        if not item:
            flash('Checklist item not found.', 'error')
            return redirect(url_for(
                'application_support.manage_standards_checklist'))
        item.name = name
        item.description = description or None
        item.updated_by = user.id
        item.updated_at = datetime.now()
        db_session.commit()
        log_audit(user, 'Administration', 'Standards Checklist', 'UPDATE',
                  'Edited checklist item: {0}'.format(name))
        flash('Checklist item updated.', 'success')
    except Exception as e:
        db_session.rollback()
        flash('Could not update the checklist item: {0}'.format(e), 'error')
    finally:
        db_session.close()
    return redirect(url_for('application_support.manage_standards_checklist'))


@application_support_bp.route(
    '/admin/standards-checklist/<int:item_id>/toggle', methods=['POST'])
def toggle_standards_checklist_item(item_id):
    """Admin: take a checklist item out of use, or bring it back."""
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))
    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_standards_checklist'))

    db_session = get_db_session()
    try:
        item = db_session.query(StandardChecklistItem).filter_by(
            id=item_id).first()
        if not item:
            flash('Checklist item not found.', 'error')
            return redirect(url_for(
                'application_support.manage_standards_checklist'))
        item.is_active = not bool(item.is_active)
        item.updated_by = user.id
        item.updated_at = datetime.now()
        db_session.commit()
        log_audit(user, 'Administration', 'Standards Checklist', 'UPDATE',
                  '{0} checklist item: {1}'.format(
                      'Activated' if item.is_active else 'Retired', item.name))
        flash('"{0}" is now {1}.'.format(
            item.name, 'active' if item.is_active else 'retired'), 'success')
    except Exception as e:
        db_session.rollback()
        flash('Could not update the checklist item: {0}'.format(e), 'error')
    finally:
        db_session.close()
    return redirect(url_for('application_support.manage_standards_checklist'))


@application_support_bp.route(
    '/admin/standards-checklist/<int:item_id>/delete', methods=['POST'])
def delete_standards_checklist_item(item_id):
    """
    Admin: delete a checklist item.

    An item applications have already answered is RETIRED instead, so the
    assessment history stays intact. A seeded item is retired too - deleting
    it would only invite the next seed run to put it straight back.
    """
    user = get_current_user()
    if not is_admin(user):
        flash('Admin access required', 'error')
        return redirect(url_for('application_support.index'))
    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.manage_standards_checklist'))

    db_session = get_db_session()
    try:
        item = db_session.query(StandardChecklistItem).filter_by(
            id=item_id).first()
        if not item:
            flash('Checklist item not found.', 'error')
            return redirect(url_for(
                'application_support.manage_standards_checklist'))

        name = item.name
        answers = tech_details.checklist_in_use(db_session, item_id)
        if answers or item.is_seeded:
            item.is_active = False
            item.updated_by = user.id
            item.updated_at = datetime.now()
            db_session.commit()
            reason = ('{0} application(s) have answered it'.format(answers)
                      if answers else 'it ships with the coding standard')
            log_audit(user, 'Administration', 'Standards Checklist', 'UPDATE',
                      'Retired checklist item: {0}'.format(name))
            flash('"{0}" has been retired rather than deleted because {1}. It '
                  'no longer appears on any application.'.format(name, reason),
                  'warning')
            return redirect(url_for(
                'application_support.manage_standards_checklist'))

        db_session.delete(item)
        db_session.commit()
        log_audit(user, 'Administration', 'Standards Checklist', 'DELETE',
                  'Deleted checklist item: {0}'.format(name))
        flash('Deleted checklist item "{0}".'.format(name), 'success')
    except Exception as e:
        db_session.rollback()
        flash('Could not delete the checklist item: {0}'.format(e), 'error')
    finally:
        db_session.close()
    return redirect(url_for('application_support.manage_standards_checklist'))


# ===========================================================================
# Documentation Quality
#
# One estate-wide screen answering the question the tower leads actually
# ask: which records are thin, and what exactly is missing from them?
#
#   /quality              the dashboard (optional ?tower=<id> filter)
#   /quality/export.csv   the same rows as a spreadsheet, for a drive
#
# The rules live in quality.py; nothing here decides what "filled in" means.
# ===========================================================================

def _quality_report(db_session, tower_id=None):
    """
    Score the estate - or one tower - once, in the order the screens use.

    The dashboard and the workbook both go through here, so a downloaded
    report can never disagree with the page it was downloaded from. Rows
    come back weakest documented first, which is the working order for a
    documentation drive.
    """
    towers = (db_session.query(AppSupportTower)
              .filter_by(is_active=True)
              .order_by(AppSupportTower.tower_name).all())
    tower_by_id = dict((tower.id, tower) for tower in towers)
    selected = tower_by_id.get(tower_id)
    scope_ids = [selected.id] if selected else list(tower_by_id.keys())

    member_counts = dict(db_session.query(
        TowerMember.tower_id, func.count(TowerMember.id),
    ).group_by(TowerMember.tower_id).all())

    apps_by_tower = quality.tower_applications(db_session, scope_ids)
    all_apps = [app for rows in apps_by_tower.values() for app in rows]
    cards = quality.score_applications(db_session, all_apps)

    tower_rows = []
    for scope_id in scope_ids:
        tower = tower_by_id[scope_id]
        tower_apps = apps_by_tower.get(scope_id, [])
        tower_cards = [cards[app.id] for app in tower_apps if app.id in cards]
        tower_rows.append({
            'tower': tower,
            'profile': quality.score_tower(
                tower, member_counts.get(scope_id, 0), len(tower_apps)),
            'records': quality.rollup(tower_cards),
        })
    tower_rows.sort(key=lambda row: (row['records']['percent'],
                                     row['profile']['percent'],
                                     row['tower'].tower_name.lower()))

    app_rows = [{'app': app, 'tower': tower_by_id.get(app.tower_id),
                 'card': cards[app.id]}
                for app in all_apps if app.id in cards]
    app_rows.sort(key=lambda row: (row['card']['percent'],
                                   row['app'].application_name.lower()))

    return {
        'towers': towers,
        'selected': selected,
        'scope': selected.tower_name if selected else 'All Towers',
        'estate': quality.rollup(list(cards.values())),
        'tower_rows': tower_rows,
        'app_rows': app_rows,
        'gap_rows': quality.worst_checks(list(cards.values())),
        'grade_scale': quality.grade_scale(),
    }


@application_support_bp.route('/quality')
def quality_dashboard():
    """Documentation quality across every tower and application."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        report = _quality_report(db_session,
                                 request.args.get('tower', type=int))
        return render_template('application_support/quality.html',
                               user=user, rules=quality,
                               is_admin=is_admin(user), **report)
    finally:
        db_session.close()


@application_support_bp.route('/quality/download/<fmt>')
def quality_export(fmt):
    """
    The dashboard as a workbook, in the same house style as the Application
    Profile download - so a tower lead can circulate the priority list
    rather than a screenshot.

    Only 'excel' is built today; the URL keeps the /download/<fmt> shape the
    tower and application downloads use so a PDF can slot in beside it.
    """
    user = get_current_user()
    if not user:
        flash('Please login to download the quality report', 'error')
        return redirect(url_for('login'))
    if fmt != 'excel':
        abort(404)

    db_session = get_db_session()
    try:
        report = _quality_report(db_session,
                                 request.args.get('tower', type=int))
        scope = report['scope']

        payload = export_docs.build_quality_workbook(
            scope, report['estate'], report['tower_rows'],
            report['app_rows'], report['gap_rows'],
            get_user_name(getattr(user, 'id', None)))

        log_audit(user, scope, 'Data Quality', 'EXPORT',
                  'Downloaded documentation quality report ({0} '
                  'application(s))'.format(report['estate']['count']))
        stem = 'Documentation_Quality_' + export_docs.safe_filename(scope)
        return _send_export(payload, stem, fmt)
    finally:
        db_session.close()


# ===========================================================================
# Tower Summary
#
#   /tower/<id>/summary                  the team, the application count and
#                                        who supports what
#   /tower/<id>/summary/assign  (POST)   the tower lead saves the grid
#   /tower/<id>/summary/download/excel   the same report as a workbook
#
# Everything the page shows comes from ONE call to team_summary.build(), so
# the page, the grid it posts back and the workbook can never disagree. The
# rules live in team_summary.py; this file only decides who may look and who
# may write.
# ===========================================================================

def can_assign_applications(user, tower_id):
    """Who may fill in the assignment grid: an admin, or one of the tower's
    own leads. Allocating work is a lead's job; everyone who can reach the
    tower can READ the allocation, because knowing who to call is the whole
    point of the page."""
    if not user:
        return False
    return is_admin(user) or is_tower_lead(user, tower_id)


def _summary_tower(db_session, tower_id):
    """The tower, or None when it does not exist / is retired."""
    return (db_session.query(AppSupportTower)
            .filter_by(id=tower_id, is_active=True).first())


@application_support_bp.route('/tower/<int:tower_id>/summary')
def tower_summary(tower_id):
    """Tower Summary - team detail, application count and the assignment
    grid the tower lead allocates applications in."""
    user = get_current_user()
    if not user:
        flash('Please login to access this module', 'error')
        return redirect(url_for('login'))

    db_session = get_db_session()
    try:
        tower = _summary_tower(db_session, tower_id)
        if not tower:
            flash('Tower not found', 'error')
            return redirect(url_for('application_support.index'))

        # `report` already carries `tower`, so it is not passed twice.
        report = team_summary.build(db_session, tower)
        return render_template('application_support/tower_summary.html',
                               user=user,
                               can_assign=can_assign_applications(user,
                                                                  tower_id),
                               can_manage_members=can_manage_members(user,
                                                                     tower_id),
                               **report)
    finally:
        db_session.close()


@application_support_bp.route('/tower/<int:tower_id>/summary/assign',
                              methods=['POST'])
def tower_summary_assign(tower_id):
    """Save the assignment grid.

    The grid posts every cell it rendered, so what comes back IS the
    allocation - a cell the lead cleared on screen arrives empty and the
    assignment goes with it. Rows for people who are no longer members of the
    tower are never read, so removing somebody from the tower frees their
    applications the moment the grid is next saved.
    """
    user = get_current_user()
    if not can_assign_applications(user, tower_id):
        flash('Access denied. Only an administrator or a lead of this tower '
              'can assign its applications.', 'error')
        return redirect(url_for('application_support.tower_summary',
                                tower_id=tower_id))

    if not validate_csrf_token(request.form.get('csrf_token')):
        flash('Invalid security token. Please try again.', 'error')
        return redirect(url_for('application_support.tower_summary',
                                tower_id=tower_id))

    db_session = get_db_session()
    try:
        tower = _summary_tower(db_session, tower_id)
        if not tower:
            flash('Tower not found', 'error')
            return redirect(url_for('application_support.index'))

        members = team_summary.load_members(db_session, tower_id)
        applications = team_summary.load_applications(db_session, tower_id)
        # Read back the same number of columns the page rendered, plus any
        # the lead grew it by client-side - bounded in team_summary so a
        # hand-edited field cannot ask for thousands of columns.
        slots = {}
        for kind in team_summary.TYPES:
            try:
                posted = int(request.form.get('slots-' + kind) or 0)
            except (TypeError, ValueError):
                posted = 0
            slots[kind] = max(team_summary.MIN_SLOTS,
                              min(team_summary.MAX_SLOTS, posted))

        cells, errors = team_summary.parse_form(
            request.form, members, [a.id for a in applications], slots)

        try:
            saved = team_summary.save(db_session, tower_id, cells, user.id)
            # Write the allocation through to the application records, so the
            # Support Team section on each application detail page says the
            # same thing the grid does.
            written, promoted = team_summary.sync_support_team(
                db_session, [a.id for a in applications], cells, members,
                user.id)
            db_session.commit()
        except Exception as exc:
            db_session.rollback()
            flash('Error saving assignments: {0}'.format(exc), 'error')
            return redirect(url_for('application_support.tower_summary',
                                    tower_id=tower_id))

        log_audit(user, tower.tower_name, 'Tower Summary', 'UPDATE',
                  'Saved application assignments ({0} assignment(s) across '
                  '{1} member(s)); support teams updated ({2} added, {3} '
                  'role(s) corrected)'.format(saved, len(members), written,
                                              promoted))
        for message in errors[:5]:
            flash(message, 'warning')
        flash('Assignments saved - {0} application assignment{1} recorded, '
              'and the support team on each application detail page has been '
              'updated to match.'.format(saved, '' if saved == 1 else 's'),
              'success')
        if promoted:
            flash('{0} support-team entr{1} already named on an application '
                  'record had its role corrected to match the '
                  'allocation.'.format(promoted,
                                       'y' if promoted == 1 else 'ies'),
                  'info')
        return redirect(url_for('application_support.tower_summary',
                                tower_id=tower_id))
    finally:
        db_session.close()


@application_support_bp.route('/tower/<int:tower_id>/summary/download/<fmt>')
def tower_summary_export(tower_id, fmt):
    """The Tower Summary as a workbook, in the module's house style."""
    user = get_current_user()
    if not user:
        flash('Please login to download the tower summary', 'error')
        return redirect(url_for('login'))
    if fmt != 'excel':
        abort(404)

    db_session = get_db_session()
    try:
        tower = _summary_tower(db_session, tower_id)
        if not tower:
            flash('Tower not found', 'error')
            return redirect(url_for('application_support.index'))

        report = team_summary.build(db_session, tower)
        payload = export_docs.build_tower_summary_workbook(
            report, get_user_name(getattr(user, 'id', None)))
        log_audit(user, tower.tower_name, 'Tower Summary', 'EXPORT',
                  'Downloaded tower summary ({0} application(s), {1} '
                  'assignment(s))'.format(report['counts']['total'],
                                          report['coverage']['assignments']))
        stem = ('Tower_Summary_'
                + export_docs.safe_filename(tower.tower_name))
        return _send_export(payload, stem, fmt)
    finally:
        db_session.close()
