"""
routes.py - Flask blueprint routes for Application Health Check.

Key production changes
----------------------
* All write operations have try/except/rollback/finally blocks.
* Flash messages accurately describe the action in context.
* Spurious and debug log statements removed.
* Manual health check has a 60-second per-report cooldown.
* URL targets are validated against private/loopback IP ranges (SSRF guard).
* check_duration is validated against the allowed set before saving.
* Index route uses joinedload to avoid N+1 queries.
"""

import logging
from datetime import datetime, timedelta

from flask import render_template, request, redirect, url_for, flash, jsonify, session
from sqlalchemy.orm import joinedload

from auth import get_current_user, require_auth
from database import get_db_session
from .security_config import encrypt_credential as encrypt_data
from .observability import apply_freshness
from . import application_health_check_bp
from .models import (
    ApplicationTower, HealthCheckReport,
    URLMonitor, ServerMonitor, DatabaseMonitor,
    EmailNotificationConfig, HealthCheckExecution,
    HealthCheckHistory, AppTowerMember,
)
from .health_monitor import schedule_health_check
from . import manual_run
from .utils import generate_health_chart, is_safe_url
from models import User

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

VALID_DURATIONS = frozenset({'30min', '1hr', '2hr', '3hr', '4hr'})
MANUAL_RUN_COOLDOWN_SECONDS = 60


# ---------------------------------------------------------------------------
# Authorisation helpers
# ---------------------------------------------------------------------------

def is_admin(user) -> bool:
    if not user:
        return False
    return getattr(user, 'role', None) == 'admin'


def is_tower_member(user, tower_id: int, db_session) -> bool:
    if not user:
        return False
    if is_admin(user):
        return True
    user_id = getattr(user, 'id', None)
    if not user_id:
        return False
    member = db_session.query(AppTowerMember).filter_by(
        tower_id=tower_id, user_id=user_id
    ).first()
    return member is not None


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------

@application_health_check_bp.route('/')
@require_auth()
def index():
    """Application Health Check Dashboard."""
    user = get_current_user()
    user_member_of_towers: set = set()

    db_session = get_db_session()
    try:
        # Use joinedload to avoid N+1 queries when iterating tower.reports
        towers = (
            db_session.query(ApplicationTower)
            .options(joinedload(ApplicationTower.reports))
        )
        if not is_admin(user):
            towers = towers.filter(ApplicationTower.id.in_(
                db_session.query(AppTowerMember.tower_id).filter_by(user_id=user.id)))
        towers = towers.all()
        for tower in towers:
            for report in tower.reports:
                apply_freshness(report)

        if user and not is_admin(user):
            memberships = db_session.query(AppTowerMember).filter_by(user_id=user.id)
            user_member_of_towers = {m.tower_id for m in memberships}

        total_towers  = len(towers)
        total_reports = sum(len(t.reports) for t in towers)
        healthy_reports = warning_reports = failed_reports = 0

        for tower in towers:
            for report in tower.reports:
                if report.last_run_status == 'healthy':
                    healthy_reports += 1
                elif report.last_run_status == 'warning':
                    warning_reports += 1
                elif report.last_run_status == 'failed':
                    failed_reports += 1

        return render_template(
            'application_health_check/index.html',
            user=user,
            towers=towers,
            total_towers=total_towers,
            total_reports=total_reports,
            healthy_reports=healthy_reports,
            warning_reports=warning_reports,
            failed_reports=failed_reports,
            user_member_of_towers=user_member_of_towers,
        )
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Tower management
# ---------------------------------------------------------------------------

@application_health_check_bp.route('/create-tower', methods=['GET', 'POST'])
@require_auth('admin')
def create_tower():
    user = get_current_user()

    if request.method == 'POST':
        tower_name    = request.form.get('tower_name', '').strip()
        description   = request.form.get('description', '').strip()
        email_addresses = request.form.get('email_addresses', '').strip()

        if not tower_name:
            flash('Tower name is required.', 'error')
            return render_template('application_health_check/create_tower.html', user=user)

        db_session = get_db_session()
        try:
            tower = ApplicationTower(
                name=tower_name,
                description=description,
                email_addresses=email_addresses,
                created_by=user.id,
            )
            db_session.add(tower)
            db_session.commit()
            flash('Application Tower created successfully.', 'success')
            return redirect(url_for('application_health_check.tower_detail', tower_id=tower.id))
        except Exception as exc:
            db_session.rollback()
            logging.exception("Error creating tower.")
            flash(f'Error creating tower: {exc}', 'error')
            return render_template('application_health_check/create_tower.html', user=user)
        finally:
            db_session.close()

    return render_template('application_health_check/create_tower.html', user=user)


@application_health_check_bp.route('/tower/<int:tower_id>')
@require_auth()
def tower_detail(tower_id: int):
    user = get_current_user()
    db_session = get_db_session()
    try:
        tower = db_session.query(ApplicationTower).filter_by(id=tower_id).first()
        if not tower:
            flash('Tower not found.', 'error')
            return redirect(url_for('application_health_check.index'))

        for report in tower.reports:
            apply_freshness(report)
        can_edit = is_tower_member(user, tower.id, db_session)
        if not can_edit:
            return 'Access denied', 403
        return render_template(
            'application_health_check/tower_detail_v1.html',
            user=user, tower=tower, can_edit=can_edit,
        )
    finally:
        db_session.close()


@application_health_check_bp.route('/tower/<int:tower_id>/edit', methods=['GET', 'POST'])
@require_auth('admin')
def edit_tower(tower_id: int):
    user = get_current_user()
    db_session = get_db_session()
    try:
        tower = db_session.query(ApplicationTower).filter_by(id=tower_id).first()
        if not tower:
            flash('Tower not found.', 'error')
            return redirect(url_for('application_health_check.index'))

        if request.method == 'POST':
            name = request.form.get('tower_name_e', '').strip()
            if not name:
                flash('Tower name is required.', 'error')
                return redirect(request.url)

            tower.name            = name
            tower.description     = request.form.get('description', '').strip()
            tower.email_addresses = request.form.get('email_addresses', '').strip()
            try:
                db_session.commit()
                flash('Tower updated successfully.', 'success')
                return redirect(url_for('application_health_check.tower_detail', tower_id=tower.id))
            except Exception as exc:
                db_session.rollback()
                logging.exception(f"Error updating tower {tower_id}.")
                flash(f'Error updating tower: {exc}', 'error')
                return redirect(request.url)

        return render_template('application_health_check/edit_tower.html', user=user, tower=tower)
    finally:
        db_session.close()


@application_health_check_bp.route('/tower/<int:tower_id>/delete', methods=['POST'])
@require_auth('admin')
def delete_tower(tower_id: int):
    user = get_current_user()
    db_session = get_db_session()
    try:
        tower = db_session.query(ApplicationTower).filter_by(id=tower_id).first()
        if not tower:
            flash('Tower not found.', 'error')
            return redirect(url_for('application_health_check.index'))

        tower_name   = tower.name
        report_count = len(tower.reports)

        report_ids = [r.id for r in tower.reports]
        if report_ids:
            for model in (URLMonitor, ServerMonitor, DatabaseMonitor,
                          EmailNotificationConfig, HealthCheckExecution,
                          HealthCheckHistory):
                db_session.query(model).filter(
                    model.report_id.in_(report_ids)
                ).delete(synchronize_session=False)
        for report in tower.reports:
            db_session.delete(report)

        db_session.delete(tower)
        db_session.commit()
        flash(
            f'Tower "{tower_name}" and {report_count} report(s) deleted successfully.',
            'success',
        )
    except Exception as exc:
        db_session.rollback()
        logging.exception(f"Error deleting tower {tower_id}.")
        flash(f'Error deleting tower: {exc}', 'error')
    finally:
        db_session.close()

    return redirect(url_for('application_health_check.index'))


# ---------------------------------------------------------------------------
# Tower member management
# ---------------------------------------------------------------------------

@application_health_check_bp.route('/tower/<int:tower_id>/manage-members')
def manage_tower_members(tower_id: int):
    user = get_current_user()
    db_session = get_db_session()
    try:
        if not is_tower_member(user, tower_id, db_session):
            flash('Access denied: you are not a member of this tower.', 'error')
            return redirect(url_for('application_health_check.index'))

        tower = db_session.query(ApplicationTower).filter_by(id=tower_id).first()
        if not tower:
            flash('Tower not found.', 'error')
            return redirect(url_for('application_health_check.index'))

        current_members = db_session.query(AppTowerMember).filter_by(tower_id=tower_id).all()
        member_user_ids = [m.user_id for m in current_members]
        users_by_id = {
            u.id: u for u in db_session.query(User)
            .filter(User.id.in_(member_user_ids)).all()
        } if member_user_ids else {}
        member_users = [
            {'member_id': m.id, 'user': users_by_id[m.user_id]}
            for m in current_members if m.user_id in users_by_id
        ]

        current_member_ids = {m.user_id for m in current_members}
        # Only ACTIVE accounts are offered for new membership - a disabled
        # (off-boarded) user keeps their name on existing records but is
        # never available for new assignments.
        available_users    = [u for u in db_session.query(User).filter_by(is_active=True).all()
                              if u.id not in current_member_ids]

        return render_template(
            'application_health_check/manage_tower_members.html',
            user=user, tower=tower,
            member_users=member_users,
            available_users=available_users,
        )
    finally:
        db_session.close()


@application_health_check_bp.route('/tower/<int:tower_id>/add-member', methods=['POST'])
def add_tower_member(tower_id: int):
    user             = get_current_user()
    user_id_to_add   = request.form.get('user_id')
    db_session       = get_db_session()

    try:
        if not is_tower_member(user, tower_id, db_session):
            flash('Access denied: you do not have permission to manage this tower.', 'error')
            return redirect(url_for('application_health_check.index'))

        if not user_id_to_add:
            flash('Please select a user to add.', 'error')
            return redirect(url_for('application_health_check.manage_tower_members', tower_id=tower_id))

        existing = db_session.query(AppTowerMember).filter_by(
            tower_id=tower_id, user_id=user_id_to_add
        ).first()
        if existing:
            flash('User is already a member of this tower.', 'warning')
        else:
            db_session.add(AppTowerMember(tower_id=tower_id, user_id=user_id_to_add, added_by=user.id))
            db_session.commit()
            flash('User added to tower successfully.', 'success')
    except Exception as exc:
        db_session.rollback()
        logging.exception(f"Error adding member to tower {tower_id}.")
        flash(f'Error adding user: {exc}', 'error')
    finally:
        db_session.close()

    return redirect(url_for('application_health_check.manage_tower_members', tower_id=tower_id))


@application_health_check_bp.route('/tower/<int:tower_id>/remove-member/<int:member_id>', methods=['POST'])
def remove_tower_member(tower_id: int, member_id: int):
    user = get_current_user()
    db_session = get_db_session()
    try:
        if not is_tower_member(user, tower_id, db_session):
            flash('Access denied: you do not have permission to manage this tower.', 'error')
            return redirect(url_for('application_health_check.index'))

        member = db_session.query(AppTowerMember).filter_by(id=member_id, tower_id=tower_id).first()
        if member:
            db_session.delete(member)
            db_session.commit()
            flash('User removed from tower successfully.', 'success')
        else:
            flash('Member not found.', 'error')
    except Exception as exc:
        db_session.rollback()
        logging.exception(f"Error removing member {member_id} from tower {tower_id}.")
        flash(f'Error removing user: {exc}', 'error')
    finally:
        db_session.close()

    return redirect(url_for('application_health_check.manage_tower_members', tower_id=tower_id))


# ---------------------------------------------------------------------------
# Report management
# ---------------------------------------------------------------------------

@application_health_check_bp.route('/tower/<int:tower_id>/create-report', methods=['GET', 'POST'])
def create_report(tower_id: int):
    user = get_current_user()
    db_session = get_db_session()
    try:
        if not is_tower_member(user, tower_id, db_session):
            flash('Access denied: you are not a member of this tower.', 'error')
            return redirect(url_for('application_health_check.tower_detail', tower_id=tower_id))

        tower = db_session.query(ApplicationTower).filter_by(id=tower_id).first()
        if not tower:
            flash('Tower not found.', 'error')
            return redirect(url_for('application_health_check.index'))

        if request.method == 'POST':
            app_name       = request.form.get('app_name', '').strip()
            description    = request.form.get('description', '').strip()
            check_duration = request.form.get('check_duration', '').strip()

            # Input validation
            if not app_name:
                flash('Application name is required.', 'error')
                return render_template('application_health_check/create_report.html', user=user, tower=tower)

            if check_duration not in VALID_DURATIONS:
                flash(f'Invalid check duration. Choose from: {", ".join(sorted(VALID_DURATIONS))}.', 'error')
                return render_template('application_health_check/create_report.html', user=user, tower=tower)

            enable_url_monitoring      = 'url_monitoring'      in request.form
            enable_server_monitoring   = 'server_monitoring'   in request.form
            enable_database_monitoring = 'database_monitoring' in request.form
            enable_email_alerts        = 'email_alerts'        in request.form

            report = HealthCheckReport(
                tower_id=tower.id,
                application_name=app_name,
                description=description,
                check_duration=check_duration,
                url_monitoring_enabled=enable_url_monitoring,
                server_monitoring_enabled=enable_server_monitoring,
                database_monitoring_enabled=enable_database_monitoring,
                email_alerts_enabled=enable_email_alerts,
                created_by=user.id,
            )
            db_session.add(report)
            db_session.flush()   # obtain report.id before adding children

            # URL monitors
            if enable_url_monitoring:
                url_count = 0
                while f'url_name_{url_count}' in request.form:
                    url_name    = request.form.get(f'url_name_{url_count}', '').strip()
                    url_address = request.form.get(f'url_address_{url_count}', '').strip()
                    if url_name and url_address:
                        safe, reason = is_safe_url(url_address)
                        if not safe:
                            flash(f'URL "{url_name}" rejected: {reason}', 'error')
                            db_session.rollback()
                            return render_template(
                                'application_health_check/create_report.html', user=user, tower=tower
                            )
                        db_session.add(URLMonitor(report_id=report.id, name=url_name, url=url_address))
                    url_count += 1

            # Server monitors
            if enable_server_monitoring:
                server_count = 0
                while f'server_type_{server_count}' in request.form:
                    hostname = request.form.get(f'server_hostname_{server_count}', '').strip()
                    port_str = request.form.get(f'server_port_{server_count}', '').strip()
                    if hostname:
                        db_session.add(ServerMonitor(
                            report_id=report.id,
                            server_type=request.form.get(f'server_type_{server_count}'),
                            hostname=hostname,
                            username=request.form.get(f'server_username_{server_count}'),
                            password=encrypt_data(request.form.get(f'server_password_{server_count}', '')),
                            port=int(port_str) if port_str.isdigit() else 22,
                            processes_to_monitor=request.form.get(f'server_processes_{server_count}'),
                        ))
                    server_count += 1

            # Database monitors
            if enable_database_monitoring:
                db_count = 0
                while f'db_type_{db_count}' in request.form:
                    db_host = request.form.get(f'db_host_{db_count}', '').strip()
                    db_port_str = request.form.get(f'db_port_{db_count}', '').strip()
                    if db_host:
                        db_session.add(DatabaseMonitor(
                            report_id=report.id,
                            database_type=request.form.get(f'db_type_{db_count}'),
                            host=db_host,
                            port=int(db_port_str) if db_port_str.isdigit() else None,
                            database_name=request.form.get(f'db_name_{db_count}'),
                            username=request.form.get(f'db_username_{db_count}'),
                            password=encrypt_data(request.form.get(f'db_password_{db_count}', '')),
                        ))
                    db_count += 1

            # Email config
            if enable_email_alerts:
                email_recipients = request.form.get('email_recipients', '').strip()
                if not email_recipients:
                    flash('Email recipients are required when email alerts are enabled.', 'error')
                    db_session.rollback()
                    return render_template('application_health_check/create_report.html', user=user, tower=tower)
                db_session.add(EmailNotificationConfig(
                    report_id=report.id,
                    recipients=email_recipients,
                    send_summary_reports='send_summary_reports' in request.form,
                    send_failure_alerts='send_failure_alerts'   in request.form,
                ))

            db_session.flush()
            for kind in ('url', 'server', 'database'):
                if getattr(report, kind + '_monitoring_enabled') and not getattr(report, kind + '_monitors'):
                    raise ValueError('An enabled monitoring section must contain at least one target.')
            if not any((report.url_monitoring_enabled, report.server_monitoring_enabled,
                        report.database_monitoring_enabled)):
                raise ValueError('Configure at least one monitoring target.')
            if not report.schedule_paused:
                schedule_health_check(report)
            db_session.commit()
            flash('Health Check Report created successfully.', 'success')
            return redirect(url_for('application_health_check.report_detail', report_id=report.id))

        return render_template('application_health_check/create_report.html', user=user, tower=tower)

    except Exception as exc:
        db_session.rollback()
        logging.exception(f"Error creating report for tower {tower_id}.")
        flash(f'Error creating report: {exc}', 'error')
        return redirect(url_for('application_health_check.tower_detail', tower_id=tower_id))
    finally:
        db_session.close()


@application_health_check_bp.route('/report/<int:report_id>')
@require_auth()
def report_detail(report_id: int):
    user = get_current_user()
    db_session = get_db_session()
    try:
        report = db_session.query(HealthCheckReport).filter_by(id=report_id).first()
        if not report:
            flash('Report not found.', 'error')
            return redirect(url_for('application_health_check.index'))

        if not is_tower_member(user, report.tower_id, db_session):
            return 'Access denied', 403
        apply_freshness(report)
        url_monitors      = db_session.query(URLMonitor).filter_by(report_id=report.id).all()
        server_monitors   = db_session.query(ServerMonitor).filter_by(report_id=report.id).all()
        database_monitors = db_session.query(DatabaseMonitor).filter_by(report_id=report.id).all()

        def _section_status(results) -> str:
            if not results:
                return 'success'
            result_list = results if isinstance(results, list) else []
            if any(r.get('status') == 'failed'  for r in result_list): return 'failed'
            if any(r.get('status') == 'warning' for r in result_list): return 'warning'
            return 'success'

        return render_template(
            'application_health_check/report_detail.html',
            user=user,
            report=report,
            # Tower members (and admins) may manage this report - e.g. pause /
            # resume its scheduled checks.
            can_manage=is_tower_member(user, report.tower_id, db_session),
            url_monitors=url_monitors,
            server_monitors=server_monitors,
            database_monitors=database_monitors,
            url_status=_section_status(report.latest_url_results),
            server_status=_section_status(report.latest_server_results),
            database_status=_section_status(report.latest_database_results),
        )
    finally:
        db_session.close()


@application_health_check_bp.route('/report/<int:report_id>/edit', methods=['GET', 'POST'])
def edit_report(report_id: int):
    user = get_current_user()
    db_session = get_db_session()
    try:
        report = db_session.query(HealthCheckReport).filter_by(id=report_id).first()
        if not report:
            flash('Report not found.', 'error')
            return redirect(url_for('application_health_check.index'))

        if not is_tower_member(user, report.tower_id, db_session):
            flash('Access denied: you do not have permission to edit this report.', 'error')
            return redirect(url_for('application_health_check.report_detail', report_id=report_id))

        if request.method == 'POST':
            app_name       = request.form.get('app_name', '').strip()
            check_duration = request.form.get('check_duration', '').strip()

            if not app_name:
                flash('Application name is required.', 'error')
                return render_template('application_health_check/edit_report.html', user=user, report=report)

            if check_duration not in VALID_DURATIONS:
                flash(f'Invalid check duration. Choose from: {", ".join(sorted(VALID_DURATIONS))}.', 'error')
                return render_template('application_health_check/edit_report.html', user=user, report=report)

            report.application_name         = app_name
            report.description              = request.form.get('description', '').strip()
            report.check_duration           = check_duration
            report.url_monitoring_enabled   = 'url_monitoring'      in request.form
            report.server_monitoring_enabled  = 'server_monitoring' in request.form
            report.database_monitoring_enabled = 'database_monitoring' in request.form
            report.email_alerts_enabled     = 'email_alerts'        in request.form

            # Snapshot existing (already-encrypted) credentials BEFORE clearing
            # the monitors. The edit form intentionally renders password fields
            # blank (see edit_report.html), so a blank submission means "keep
            # the stored password" rather than "set the password to empty".
            # Without this, editing any part of a report - even just the email
            # recipients - re-saved every monitor with an empty password and
            # silently wiped the stored server/database credentials.
            #
            # Keyed by the monitor's natural identity (hostname for servers,
            # host+database for DBs) so preservation survives row reordering.
            existing_server_pw = {
                (m.hostname or '').strip().lower(): m.password
                for m in report.server_monitors
            }
            existing_db_pw = {
                ((m.host or '').strip().lower(),
                 (m.database_name or '').strip().lower()): m.password
                for m in report.database_monitors
            }

            # Replace all child monitors
            report.url_monitors.clear()
            report.server_monitors.clear()
            report.database_monitors.clear()
            if report.email_config:
                db_session.delete(report.email_config)

            if report.url_monitoring_enabled:
                url_count = 0
                while f'url_name_{url_count}' in request.form:
                    url_name    = request.form.get(f'url_name_{url_count}', '').strip()
                    url_address = request.form.get(f'url_address_{url_count}', '').strip()
                    if url_name and url_address:
                        safe, reason = is_safe_url(url_address)
                        if not safe:
                            flash(f'URL "{url_name}" rejected: {reason}', 'error')
                            db_session.rollback()
                            return render_template(
                                'application_health_check/edit_report.html', user=user, report=report
                            )
                        report.url_monitors.append(URLMonitor(name=url_name, url=url_address))
                    url_count += 1

            if report.server_monitoring_enabled:
                server_count = 0
                while f'server_hostname_{server_count}' in request.form:
                    hostname = request.form.get(f'server_hostname_{server_count}', '').strip()
                    port_str = request.form.get(f'server_port_{server_count}', '').strip()
                    if hostname:
                        submitted_pw = request.form.get(f'server_password_{server_count}', '').strip()
                        if submitted_pw:
                            server_password = encrypt_data(submitted_pw)
                        else:
                            # Blank field = keep the existing stored credential.
                            server_password = existing_server_pw.get(hostname.lower(), '')
                        report.server_monitors.append(ServerMonitor(
                            server_type=request.form.get(f'server_type_{server_count}'),
                            hostname=hostname,
                            port=int(port_str) if port_str.isdigit() else 22,
                            username=request.form.get(f'server_username_{server_count}'),
                            password=server_password,
                            processes_to_monitor=request.form.get(f'server_processes_{server_count}'),
                        ))
                    server_count += 1

            if report.database_monitoring_enabled:
                db_count = 0
                while f'db_host_{db_count}' in request.form:
                    db_host     = request.form.get(f'db_host_{db_count}', '').strip()
                    db_port_str = request.form.get(f'db_port_{db_count}', '').strip()
                    db_name     = request.form.get(f'db_name_{db_count}')
                    if db_host:
                        submitted_pw = request.form.get(f'db_password_{db_count}', '').strip()
                        if submitted_pw:
                            db_password = encrypt_data(submitted_pw)
                        else:
                            # Blank field = keep the existing stored credential.
                            db_key = (db_host.lower(), (db_name or '').strip().lower())
                            db_password = existing_db_pw.get(db_key, '')
                        report.database_monitors.append(DatabaseMonitor(
                            database_type=request.form.get(f'db_type_{db_count}'),
                            host=db_host,
                            port=int(db_port_str) if db_port_str.isdigit() else None,
                            database_name=db_name,
                            username=request.form.get(f'db_username_{db_count}'),
                            password=db_password,
                        ))
                    db_count += 1

            if report.email_alerts_enabled:
                report.email_config = EmailNotificationConfig(
                    recipients=request.form.get('email_recipients', '').strip(),
                    send_summary_reports='send_summary_reports' in request.form,
                    send_failure_alerts='send_failure_alerts'   in request.form,
                )

            db_session.flush()
            for kind in ('url', 'server', 'database'):
                if getattr(report, kind + '_monitoring_enabled') and not getattr(report, kind + '_monitors'):
                    raise ValueError('An enabled monitoring section must contain at least one target.')
            if not any((report.url_monitoring_enabled, report.server_monitoring_enabled,
                        report.database_monitoring_enabled)):
                raise ValueError('Configure at least one monitoring target.')
            if not report.schedule_paused:
                schedule_health_check(report)
            report.config_version = HealthCheckReport.config_version + 1
            db_session.commit()
            flash('Report updated successfully.', 'success')
            return redirect(url_for('application_health_check.report_detail', report_id=report_id))

        return render_template('application_health_check/edit_report.html', user=user, report=report)

    except Exception as exc:
        db_session.rollback()
        logging.exception(f"Error editing report {report_id}.")
        flash(f'Error updating report: {exc}', 'error')
        return redirect(url_for('application_health_check.report_detail', report_id=report_id))
    finally:
        db_session.close()


@application_health_check_bp.route('/report/<int:report_id>/delete', methods=['POST'])
def delete_report(report_id: int):
    user = get_current_user()
    db_session = get_db_session()
    try:
        report = db_session.query(HealthCheckReport).filter_by(id=report_id).first()
        if not report:
            flash('Report not found.', 'error')
            return redirect(url_for('application_health_check.index'))

        if not is_tower_member(user, report.tower_id, db_session):
            flash('Access denied: you do not have permission to delete this report.', 'error')
            return redirect(url_for('application_health_check.report_detail', report_id=report_id))

        tower_id = report.tower_id
        db_session.delete(report)
        db_session.commit()
        flash('Report deleted successfully.', 'success')
        return redirect(url_for('application_health_check.tower_detail', tower_id=tower_id))

    except Exception as exc:
        db_session.rollback()
        logging.exception(f"Error deleting report {report_id}.")
        flash(f'Error deleting report: {exc}', 'error')
        return redirect(url_for('application_health_check.report_detail', report_id=report_id))
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Manual health check run
# ---------------------------------------------------------------------------

@application_health_check_bp.route('/report/<int:report_id>/run', methods=['POST'])
@require_auth('admin')
def run_manual_check(report_id: int):
    """Hand a manual health check to a detached process and return at once.

    This used to run the checks inline. A report with a few URLs, servers and
    databases can take minutes (see manual_run.py for the timeout arithmetic),
    which held one of the eight IIS workers for the duration and could exceed
    web.config's requestTimeout=600. The run now goes to its own process and
    the page polls run_status below.
    """
    user = get_current_user()

    db_session = get_db_session()
    try:
        report = db_session.query(HealthCheckReport).filter_by(id=report_id).first()
        if not report:
            flash('Report not found.', 'error')
            return redirect(url_for('application_health_check.index'))

        # Cooldown guard - prevent resource exhaustion from repeated manual runs
        if report.last_run_time:
            elapsed = (datetime.now() - report.last_run_time).total_seconds()
            if elapsed < MANUAL_RUN_COOLDOWN_SECONDS:
                remaining = int(MANUAL_RUN_COOLDOWN_SECONDS - elapsed)
                flash(
                    f'Please wait {remaining} second(s) before running again.',
                    'warning',
                )
                return redirect(url_for('application_health_check.report_detail', report_id=report_id))
    finally:
        db_session.close()

    started, message = manual_run.enqueue(report_id, user.id)
    flash(message, 'success' if started else 'warning')
    return redirect(url_for('application_health_check.report_detail', report_id=report_id))


@application_health_check_bp.route('/report/<int:report_id>/run-status')
@require_auth('admin')
def run_status(report_id: int):
    """Progress of the detached manual run, for the report page to poll.

    Also reaps a run whose process died, so leaving the page open is enough to
    clear a stuck job - there is no separate sweeper to configure.
    """
    user = get_current_user()

    db_session = get_db_session()
    try:
        report = db_session.query(HealthCheckReport).filter_by(id=report_id).first()
        if not report:
            return jsonify({'error': 'Report not found'}), 404
        if not (is_admin(user) or is_tower_member(user, report.tower_id, db_session)):
            return jsonify({'error': 'Access denied'}), 403
    finally:
        db_session.close()

    state = manual_run.status(report_id)
    if state is None:
        return jsonify({'error': 'Report not found'}), 404
    return jsonify(state)


# ---------------------------------------------------------------------------
# Pause / resume the scheduled checks for a single report
# ---------------------------------------------------------------------------

@application_health_check_bp.route('/report/<int:report_id>/toggle-schedule', methods=['POST'])
def toggle_schedule(report_id: int):
    """Temporarily stop (or resume) the automatic scheduled checks for a report.

    Pausing only suspends the scheduler sweep - the report stays active, keeps
    its history, and can still be run on demand with "Run Check". Resuming
    re-arms the schedule from now so the next automatic run is a fresh interval
    away rather than an immediate backlog of missed slots."""
    user = get_current_user()
    db_session = get_db_session()
    try:
        report = db_session.query(HealthCheckReport).filter_by(id=report_id).first()
        if not report:
            flash('Report not found.', 'error')
            return redirect(url_for('application_health_check.index'))

        if not is_tower_member(user, report.tower_id, db_session):
            flash('Access denied: you do not have permission to change this report\'s schedule.', 'error')
            return redirect(url_for('application_health_check.report_detail', report_id=report_id))

        report.schedule_paused = not report.schedule_paused
        if report.schedule_paused:
            # Stop future automatic runs; clear the pending slot so a resume
            # always recomputes a clean next_run_time.
            report.next_run_time = None
            message = f'Scheduled checks paused for "{report.application_name}". You can still run checks manually.'
        else:
            # Re-arm the schedule from now.
            schedule_health_check(report)
            message = f'Scheduled checks resumed for "{report.application_name}".'

        report.config_version = HealthCheckReport.config_version + 1

        db_session.commit()
        flash(message, 'success')
        return redirect(url_for('application_health_check.report_detail', report_id=report_id))

    except Exception as exc:
        db_session.rollback()
        logging.exception(f"Error toggling schedule for report {report_id}.")
        flash(f'Error updating schedule: {exc}', 'error')
        return redirect(url_for('application_health_check.report_detail', report_id=report_id))
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# Reports overview
# ---------------------------------------------------------------------------

@application_health_check_bp.route('/manage-reports')
@require_auth('admin')
def manage_reports():
    user = get_current_user()
    db_session = get_db_session()
    try:
        towers = db_session.query(ApplicationTower).options(
            joinedload(ApplicationTower.reports)
        ).all()
        return render_template(
            'application_health_check/manage_reports.html',
            user=user, towers=towers,
        )
    finally:
        db_session.close()


# ---------------------------------------------------------------------------
# About  (public - explains the module to end users and the support team)
# ---------------------------------------------------------------------------

@application_health_check_bp.route('/about')
def about():
    user = get_current_user()
    return render_template('application_health_check/about.html', user=user)


@application_health_check_bp.route('/monitoring-readiness')
@require_auth('admin')
def monitoring_readiness():
    """Authenticated machine-readable health of the monitoring pipeline."""
    from .observability import monitoring_readiness as inspect_monitor
    try:
        result = inspect_monitor()
        return jsonify(result), 200 if result['status'] == 'ok' else 503
    except Exception:
        logging.exception('Monitoring readiness lookup failed.')
        return jsonify(status='unavailable', reason='Monitoring storage unavailable'), 503
