"""Recursive source-file discovery with noise pruning."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from ..domain.models import FileAnalysis
from .languages import LanguageRegistry

#: Directories pruned during recursive scans - VCS metadata, build artefacts,
#: virtual environments, and vendored dependencies.
IGNORED_DIRS: frozenset[str] = frozenset({
    ".git", ".svn", ".hg",
    "__pycache__", ".mypy_cache", ".pytest_cache", ".ruff_cache", ".tox",
    ".venv", "venv", "env",
    "node_modules", "bower_components",
    "bin", "obj", "dist", "build", "target", "out",
    ".idea", ".vs", ".vscode",
})

#: Files above this size are treated as generated/vendored and skipped.
MAX_FILE_BYTES = 2 * 1024 * 1024


@dataclass
class DiscoveryResult:
    """Outcome of a discovery walk."""

    files: list[Path]
    truncated: bool
    skipped_large: int
    #: (path, size in bytes, language id) of files over MAX_FILE_BYTES.
    oversized: list[tuple[Path, int, str]] = field(default_factory=list)
    #: (path, reason, language id) for paths the walk could not read;
    #: directories carry the language id "unknown".
    unreadable: list[tuple[Path, str, str]] = field(default_factory=list)
    max_files: int = 0

    @property
    def complete(self) -> bool:
        return not (self.truncated or self.oversized or self.unreadable)

    def omission_analyses(self, root: Path) -> list[FileAnalysis]:
        """
        Every omission as a failed FileAnalysis, so it travels with the scan
        result as evidence: the quality gate's analysis-error check, the
        coverage table, stored results and every report see it without any
        extra plumbing. A scan that silently skipped code must never read as
        a clean one.
        """
        omissions = [
            FileAnalysis(path=path, language_id=language, tool_errors=[
                f"File not analysed: {size:,} bytes exceeds the "
                f"{MAX_FILE_BYTES // (1024 * 1024)} MB per-file limit."])
            for path, size, language in self.oversized
        ]
        omissions.extend(
            FileAnalysis(path=path, language_id=language, tool_errors=[
                f"Not analysed - discovery could not read this path: {reason}"])
            for path, reason, language in self.unreadable)
        if self.truncated:
            omissions.append(FileAnalysis(
                path=root, language_id="unknown", tool_errors=[
                    f"Discovery stopped at the {self.max_files:,}-file limit; "
                    f"remaining files were NOT analysed."]))
        return omissions


class FileScanner:
    """Walks a tree collecting every file the language registry claims."""

    def __init__(
        self,
        registry: LanguageRegistry,
        ignored_dirs: frozenset[str] = IGNORED_DIRS,
        max_files: int = 100_000,
    ) -> None:
        self._registry = registry
        self._ignored = ignored_dirs
        self._max_files = max_files

    def discover(self, root: Path) -> DiscoveryResult:
        """
        Walk `root` and return every analysable file.

        A single file input is returned as-is when the registry claims it.
        `truncated` is True when `max_files` was reached, letting the caller
        warn the user rather than silently analysing an arbitrary subset.
        """
        if root.is_file():
            claimed = self._registry.detect(root) is not None
            return DiscoveryResult([root] if claimed else [], False, 0,
                                   max_files=self._max_files)

        matches: list[Path] = []
        oversized: list[tuple[Path, int, str]] = []
        unreadable: list[tuple[Path, str, str]] = []

        def result(truncated: bool) -> DiscoveryResult:
            return DiscoveryResult(matches, truncated, len(oversized),
                                   oversized=oversized, unreadable=unreadable,
                                   max_files=self._max_files)

        def walk_error(exc: OSError) -> None:
            # A directory os.walk cannot list would otherwise vanish from
            # the scan without a trace.
            unreadable.append((Path(exc.filename or root),
                               exc.strerror or type(exc).__name__, "unknown"))

        for dirpath, dirnames, filenames in os.walk(root, onerror=walk_error):
            # Mutating dirnames in place prunes the walk before descent.
            dirnames[:] = [
                d for d in dirnames
                if d not in self._ignored and
                (not d.startswith(".") or d in {'.github', '.gitlab', '.circleci'})
                and not (Path(dirpath) / d).is_symlink()
            ]

            for filename in sorted(filenames):
                candidate = Path(dirpath) / filename
                if candidate.is_symlink():
                    continue
                spec = self._registry.detect(candidate)
                if spec is None:
                    continue
                try:
                    size = candidate.stat().st_size
                except OSError as exc:
                    unreadable.append((candidate, exc.strerror or type(exc).__name__,
                                       spec.id))
                    continue
                if size == 0:
                    continue
                if size > MAX_FILE_BYTES:
                    oversized.append((candidate, size, spec.id))
                    continue

                matches.append(candidate)
                if len(matches) >= self._max_files:
                    return result(True)

        return result(False)
