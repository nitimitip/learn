# Similar Incident and Create Change Request history

## 2026-09-29: service requests, accuracy fixes, redesign

* **Service request history** is a third kind (`sr`) beside `incident` and
  `cr`: `python -m modules.service_now_analysis.ml.knowledge --kind sr --input
  ritm_delta.csv`, or Import history on the Similar tickets / template pages.
  Closed Complete / Fulfilled requests are searchable; Closed Incomplete,
  Skipped, Cancelled and Withdrawn are kept but never offered. Excel exports
  with display headers ("Number", "Updated") are accepted for every kind.
* **Re-import once after deploying.** Snapshots built before this change
  carry mode-filled group / category / CI / environment values on records
  whose fields were blank, include cancelled and duplicate incidents, and
  have no failed-change index. Importing the retained full export (or any
  export, for the failed-change index) rebuilds them with the new rules.
  Older snapshots keep working in the meantime.
* Retrieval adds title-only, exact error-code / host-name and CI-preference
  signals; wording scores are discounted for query words the corpus has never
  seen, and a query of 3+ words must share 2+ with a record. Repeats of the
  same issue are grouped with a recurrence count.
* The incident / request template votes fields from similar tickets (so it
  works without trained models), feeds the priority model the predicted
  group instead of "Service Desk", uses the subcategory model, and derives
  priority from the impact x urgency matrix.
* The CR template blends classifiers with a vote of similar changes, matches
  environments by canonical name (blank environments ranked last), prefers a
  plan source with complete plans, marks each step with how many similar CRs
  share it, warns about similar failed changes and checks the schedule.
* Regression cover: `tests/test_snow_assist_accuracy.py`.

### Wording differences without downloading a model

Production cannot download a sentence-embedding model, and everything here
uses only libraries the module already had (pandas, numpy, scipy,
scikit-learn). Built into every snapshot at import time:

* **IT vocabulary normalisation** (`ml/textnorm.py`): "sign in / log on" ->
  login, "can't / unable to" -> cannot, "pwd" -> password, etc. Applied to the
  lexical indexes and to every query; never to displayed text.
* **Character n-grams** ("Spelling" signal): typos and word variants.
* **Rare shared terms** ("Specific term"): one shared word counts when it is
  rare in history (product / host / application names), weighted by rarity.
  Only on histories of 200+ records.
* **Possible matches**: when there are fewer confident matches than asked
  for, one-shared-word candidates are listed after them, labelled and capped
  at 35%. They never feed suggested fixes, insights or the templates.
* A locally trained topic model (LSA) was tried and **removed** - it lowered
  accuracy in the benchmark.

`python tests/bench_snow_paraphrase.py -v` compares the old appassist engine
with this one on paraphrased queries. Snapshots built before this change
keep working without the new signals until the next import.

Both screens can now use a versioned retrieval history independently of the
supervised incident and CR field-prediction models. ServiceNow group members
and application admins can use **Import records** on either screen.

## Export and import

Export new or changed records using `sys_updated_on` since the last complete
successful extraction, with an overlap window. Include updates to older tickets,
not just records opened this year. Use one ServiceNow instance per application
data root: the existing ticket number is the merge key.

Required raw field-name headers are `number`, `short_description`, `state`, and
`sys_updated_on`. Prefer complete records including description, priority,
category, assignment group, dates and close notes. For changes include type,
environment, implementation_plan, backout_plan, test_plan and close code. Export
display values for choice fields such as state, matching the existing pipeline.
Dates should be unambiguous ISO timestamps; `sys_updated_on` is interpreted as UTC.
Malformed CSV rows are rejected rather than silently dropped.

For large exports, run outside the web request timeout:

```powershell
python -m modules.service_now_analysis.ml.knowledge --kind incident --input incidents_delta.csv
python -m modules.service_now_analysis.ml.knowledge --kind cr --input changes_delta.csv
```

The updater retains historical records, replaces a ticket only with an equal or
newer timestamp, preserves fields absent from a reduced export, and keeps the
raw imported batch in the version directory. An explicit blank field in an
export clears that field. Reopened incidents and failed/cancelled changes remain
in history but leave the eligible search corpus. Missing rows are not deletions.

## First import

Incidents bootstrap from `master_training.csv`, or the old retrieval dataframe
when the master is unavailable. Changes bootstrap from the old CR retrieval
dataframe. These are not necessarily complete training datasets: the old CR
corpus discarded state and description. Those records remain stored, but their
plans become searchable only after an export supplies a successful closed state.
Import the retained original export once to restore missing historical coverage.
No source records can be recovered from classifier weights alone.

## Runtime and publication

Unchanged sentence embeddings are reused by text hash and encoder revision
(local model path, file sizes and modification times). TF-IDF and BM25 are rebuilt
locally to include new vocabulary and current corpus statistics. This is retrieval
indexing, not classifier retraining. New CR field suggestions use the matched
record where no classifier prediction is available. Similarity percentages are
similarity measures, not probabilities of success.

Each import builds a separate immutable directory under
`data/service_now_analysis/knowledge/{incident|cr}/`. Only after all artifacts
are written is `CURRENT` atomically replaced. Readers use one snapshot per query;
failed imports leave the previous pointer intact. Snapshots are retained for
recovery and are not automatically pruned. Apply your normal data backup and
retention controls to this directory. Legacy model artifacts are not changed.

The per-kind `UPDATE.lock` rejects concurrent writers across IIS workers. If a
process is forcibly terminated, an administrator must confirm no updater is
running before removing its stale lock. The web import waits for completion;
if the browser or proxy times out, check history status before retrying.

Keep the embedding model immutable while queries are running. After replacing
it, import again to rebuild compatible vectors. Versioned retrieval falls back
to text/keyword search when the encoder revision differs from the snapshot.
Existing supervised training commands still retrain classifiers separately.

## Verification

`python -m pytest tests/test_snow_knowledge.py` exercises history preservation,
stale exports, reopening, failed publication, embedding reuse and invalidation,
filtered semantic retrieval, legacy migration, writer locking and CR generation.
