"""
Inference module for the CR Template Generator.

Changes vs previous version
----------------------------
* **Hybrid retrieval** - the corpus search now combines TF-IDF cosine,
  sentence-embedding cosine, and BM25 via Reciprocal Rank Fusion, exactly
  mirroring the approach in similarity.py.  When semantic vectors or BM25
  are unavailable (libraries not installed, or first run before change_train
  builds them) it falls back transparently to TF-IDF alone.

* **Persisted null fills** - ``cr_null_fills.json`` is loaded at startup so
  any preprocessing done inside the template generation path uses stable
  training-time fill values rather than computing them from a single record.

Public entry point is unchanged::

    generate_cr_template(title, description, planned_start, planned_end,
                         environment=None, server_list=None, requested_by=None)
"""

from __future__ import annotations

import json
import logging
import re
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

from . import config
from .ml.knowledge import load_snapshot, history_status, compatible_semantic
from .ml.retrieval import cached_title_vectors, rank_detailed
from .ml.textnorm import TEXT_NORM_VERSION, normalise
from .ml.assist import clean_value, ensemble, step_key, step_overlap, weighted_vote
from .server_lookup import lookup_servers
from .section_quality import score_template, score_cr_description
from .ml.embedding_utils import (
    get_encoder,
    encode_texts,
    load_sem_vectors,
    load_bm25_index,
    bm25_scores,
    reciprocal_rank_fusion,
    load_null_fills,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Tuning knobs
# ---------------------------------------------------------------------------
TOP_K_SIMILAR_CRS    = 8
MIN_COMMONALITY_PCT  = 0.40
MAX_STEPS_PER_PLAN   = 12
PLAN_STEP_MIN_WORDS  = 2
PLAN_STEP_MAX_WORDS  = 50
MIN_MATCH_PCT_FOR_LIFT = 20.0
RECENCY_TIE_PCT        = 5.0
HIGH_CONFIDENCE_PCT    = 70.0

PLAN_DISCLAIMER = (
    "These steps are taken verbatim from a historical CR for reference "
    "only - please cross-validate every step against your environment, "
    "change scope, and current standards before submitting the CR."
)


# ---------------------------------------------------------------------------
# Artifact loading
# ---------------------------------------------------------------------------
def _load(path: Path):
    try:
        return joblib.load(path)
    except FileNotFoundError:
        return None
    except Exception as exc:
        logger.warning("Failed to load %s: %s", path, exc)
        return None


def _get_cr_null_fills() -> Optional[dict]:
    """Load persisted training-time null fills for CR preprocessing."""
    return load_null_fills(config.MODELS_DIR / "cr_null_fills.json")


def _get_embedding_model():
    """Lazy-load the sentence encoder from config.EMBEDDING_MODEL_PATH."""
    model_path = getattr(config, "EMBEDDING_MODEL_PATH", None)
    if not model_path:
        return None
    return get_encoder(str(model_path))


def cr_models_status() -> Dict[str, Any]:
    """Compact status object used by routes / templates."""
    artifacts = {
        "vectorizer": "cr_vectorizer_latest.pkl",
        "corpus":     "cr_corpus_vectors_latest.pkl",
        "corpus_df":  "cr_corpus_dataframe_latest.pkl",
    }
    status = {k: (config.MODELS_DIR / v).exists() for k, v in artifacts.items()}
    field_models = sorted(p.name for p in config.MODELS_DIR.glob("cr_field_*_latest.pkl"))

    meta_file = config.MODELS_DIR / "cr_metadata.json"
    trained_at = n_changes = None
    if meta_file.exists():
        try:
            with open(meta_file) as f:
                m = json.load(f)
                trained_at = m.get("trained_at")
                n_changes  = m.get("n_changes")
        except Exception:
            pass

    return {
        "artifacts":    status,
        "field_models": field_models,
        "all_loaded":   all(status.values()) or history_status("cr")["version"] is not None,
        "trained_at":   trained_at,
        "n_changes":    n_changes,
        "history":      history_status("cr"),
    }


# ---------------------------------------------------------------------------
# Hybrid CR retrieval
# ---------------------------------------------------------------------------
def _cr_hybrid_scores(
    combined_query: str,
    tfidf_vec,
    tfidf_corpus_vecs,
    n_docs: int,
) -> np.ndarray:
    """
    Combine TF-IDF, semantic, and BM25 signals for CR corpus retrieval.

    Falls back to TF-IDF alone when semantic vectors / BM25 index are not
    available.  RRF with k=60 is used to merge the ranked lists.
    """
    ranked_lists: List[List[int]] = []

    # 1. TF-IDF cosine
    Xq = tfidf_vec.transform([combined_query])
    tfidf_raw = cosine_similarity(Xq, tfidf_corpus_vecs).flatten()
    above_floor = np.where(tfidf_raw >= 0.05)[0]
    if len(above_floor):
        ranked_lists.append(
            above_floor[tfidf_raw[above_floor].argsort()[::-1]].tolist()
        )

    # 2. Semantic cosine (optional)
    sem_vecs = load_sem_vectors("cr", config.MODELS_DIR)
    if sem_vecs is not None:
        enc = _get_embedding_model()
        if enc is not None:
            q_sem = encode_texts([combined_query], enc)
            if q_sem is not None:
                sem_raw = sem_vecs.dot(q_sem[0])
                ranked_lists.append(sem_raw.argsort()[::-1].tolist())

    # 3. BM25 (optional)
    bm25_idx = load_bm25_index("cr", config.MODELS_DIR)
    if bm25_idx is not None:
        bm25_raw = bm25_scores(bm25_idx, combined_query, n_docs)
        if bm25_raw is not None:
            ranked_lists.append(bm25_raw.argsort()[::-1].tolist())

    if not ranked_lists:
        return np.zeros(n_docs, dtype=np.float32)

    return reciprocal_rank_fusion(ranked_lists, n_docs)


# ---------------------------------------------------------------------------
# Step extraction & commonality logic (unchanged)
# ---------------------------------------------------------------------------
_STEP_SPLIT_RE = re.compile(
    r"(?:"
        r"[\r\n]+"
        r"|(?:^|\s)\d+\s*[\.\ )]\s+"
        r"|(?:^|[\r\n])[\-\*]\s+"
        r"|\s*\N{BULLET}\s*"
    r")",
    re.M,
)
_NORMALISE_RE = re.compile(r"[^a-z0-9 ]+")
_FILLER_WORDS = frozenset({
    "the", "a", "an", "to", "and", "or", "of", "in", "on", "at", "by",
    "it", "is", "are", "be", "this", "that", "these", "those", "we",
    "will", "shall", "should", "must", "do", "for", "with", "from",
    "into", "onto", "as", "via", "using", "use", "step", "all", "any",
    "please", "now", "next", "first", "then", "finally",
})
_GENERIC_OBJECTS = frozenset({
    "server", "servers", "box", "boxes", "machine", "machines", "host", "hosts",
    "node", "nodes", "instance", "instances", "vm", "vms", "system", "systems",
    "device", "devices",
})


def _split_into_steps(text: str) -> List[str]:
    if not text:
        return []
    pieces = _STEP_SPLIT_RE.split(text)
    out: List[str] = []
    for p in pieces:
        p = p.strip(" -**\t.")
        if not p:
            continue
        n_words = len(p.split())
        if n_words < PLAN_STEP_MIN_WORDS or n_words > PLAN_STEP_MAX_WORDS:
            continue
        out.append(p)
    return out


def _normalise_step(step: str) -> str:
    s = step.lower().strip()
    s = _NORMALISE_RE.sub(" ", s)
    s = re.sub(r"\b\w*\d+\w*\b", " ", s)
    tokens = [w for w in s.split()
              if w not in _FILLER_WORDS and w not in _GENERIC_OBJECTS and len(w) > 1]
    return " ".join(tokens[:6])


def _plan_from_single_cr(corpus_df, cr_idx: int, plan_field: str,
                          max_steps: int = 25) -> List[str]:
    if corpus_df is None or plan_field not in corpus_df.columns:
        return []
    if cr_idx is None or cr_idx < 0 or cr_idx >= len(corpus_df):
        return []
    text = str(corpus_df.iloc[int(cr_idx)].get(plan_field) or "").strip()
    return _split_into_steps(text)[:max_steps]


def _common_steps_from_corpus(corpus_df, top_idx: List[int], plan_field: str,
                               min_commonality: float = MIN_COMMONALITY_PCT,
                               max_steps: int = MAX_STEPS_PER_PLAN) -> List[str]:
    if plan_field not in corpus_df.columns or len(top_idx) == 0:
        return []
    k = len(top_idx)
    clusters: Dict[str, List[Tuple[int, str, float]]] = defaultdict(list)
    for ci in top_idx:
        text = str(corpus_df.iloc[int(ci)][plan_field] or "")
        steps = _split_into_steps(text)
        for position, step in enumerate(steps):
            key = _normalise_step(step)
            if not key or len(key) < 5:
                continue
            # Relative position (0 = first step, 1 = last) so plans of
            # different lengths can be merged into one sequence.
            clusters[key].append((int(ci), step, position / max(len(steps) - 1, 1)))
    common: List[Tuple[int, str, int, float]] = []
    for key, items in clusters.items():
        cr_count = len({ci for ci, _, _ in items})
        if cr_count / k < min_commonality:
            continue
        best = max((s for _, s, _ in items), key=len)
        order = sum(p for _, _, p in items) / len(items)
        common.append((cr_count, best, len(items), order))
    # Keep the most widely shared steps, then restore their written order:
    # a plan is a sequence, and "restart" must not jump ahead of "restore".
    common.sort(key=lambda t: (-t[0], -t[2], t[1].lower()))
    chosen = sorted(common[:max_steps], key=lambda t: t[3])
    return [c[1] for c in chosen]


# ---------------------------------------------------------------------------
# Risk-impact analysis composer (unchanged)
# ---------------------------------------------------------------------------
def _compose_risk_impact_analysis(
    type_pred: str, risk_pred: str, environment: str,
    server_count: int, has_external_interfaces: bool,
    business_service: str, similar_count: int,
) -> str:
    parts: List[str] = []
    if environment:
        parts.append(f"Change targets the {environment} environment.")
    if server_count > 0:
        parts.append(f"{server_count} server{'s' if server_count != 1 else ''} in scope.")
    if business_service and business_service.lower() != "unknown":
        parts.append(f"Affects business service: {business_service}.")
    if has_external_interfaces:
        parts.append(
            "External interfaces are connected to the affected applications - "
            "downstream impact must be assessed and communicated.")
    if risk_pred == "High":
        parts.append("Predicted risk is HIGH; CAB review and a tested rollback are essential.")
    elif risk_pred == "Moderate":
        parts.append("Predicted risk is MODERATE; standard pre-implementation review applies.")
    else:
        parts.append("Predicted risk is LOW based on similar past changes.")
    if type_pred == "Emergency":
        parts.append(
            "This is an Emergency change - out-of-hours support and accelerated review will apply.")
    elif type_pred == "Standard":
        parts.append("This change matches a Standard pattern previously approved by CAB.")
    if similar_count == 0:
        parts.append(
            "No close matches were found in the historical CR corpus - treat "
            "as a novel change and rehearse in non-prod.")
    elif similar_count >= 5:
        parts.append(
            f"{similar_count} similar successful changes were found in history "
            f"and used to draft the implementation and backout plans.")
    return " ".join(parts)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
_PER_FIELD_MODELS = ["type", "category", "subcategory", "risk", "priority",
                     "impact", "urgency", "assignment_group", "business_service"]

# Environment vocabularies differ between instances ("Prod", "PRD",
# "Production"); compare on a canonical label so a filter never silently
# returns nothing because of spelling.
_ENV_CANON = [
    ("Production", re.compile(r"^(prod|production|prd|live|p)$|\bprod(uction)?\b", re.I)),
    ("DR", re.compile(r"\b(dr|disaster[\s_-]*recovery|bcp)\b", re.I)),
    ("UAT", re.compile(r"\b(uat|pre[\s_-]*prod|preprod|staging|stage|acceptance)\b", re.I)),
    ("Test", re.compile(r"\b(test|tst|sit|qa|qat|integration)\b", re.I)),
    ("Development", re.compile(r"\b(dev|development|sandbox|sbx)\b", re.I)),
]
_DISPLAY_SCALES = {
    "priority": {"1": "1 - Critical", "2": "2 - High", "3": "3 - Moderate", "4": "4 - Low", "5": "5 - Planning"},
    "impact": {"1": "1 - High", "2": "2 - Medium", "3": "3 - Low"},
    "urgency": {"1": "1 - High", "2": "2 - Medium", "3": "3 - Low"},
}
_RISK_ORDER = {"Low": 1, "Moderate": 2, "High": 3, "Very High": 4}
SIMILAR_VOTE_FLOOR = 20.0       # similar CRs below this % do not vote on fields
FAILURE_WARN_PCT = 30.0         # failed CRs at or above this % are surfaced
PLAN_SOURCE_WINDOW = 10.0       # candidates within this many points of the best


def canonical_environment(value) -> str:
    text = clean_value(value)
    if not text:
        return ""
    for label, pattern in _ENV_CANON:
        if pattern.search(text):
            return label
    return text.title()


def _display_scale(field: str, value: str) -> str:
    value = clean_value(value)
    return _DISPLAY_SCALES.get(field, {}).get(value, value)


def _parse_local(value) -> Optional[pd.Timestamp]:
    ts = pd.to_datetime(value, errors="coerce")
    if ts is None or pd.isna(ts):
        return None
    if ts.tzinfo is not None:
        ts = ts.tz_convert(None)
    return ts


def _schedule_checks(start: pd.Timestamp, end: pd.Timestamp, environment: str,
                     similar_durations: List[float], now: Optional[datetime] = None) -> Dict[str, Any]:
    """Lead time, duration and timing checks on the planned window."""
    now = pd.Timestamp(now or datetime.now())
    checks: List[Dict[str, str]] = []
    lead_hours = (start - now).total_seconds() / 3600.0
    duration_hours = (end - start).total_seconds() / 3600.0

    if lead_hours < 0:
        checks.append({"level": "stop", "message": "Planned start is in the past."})
    elif lead_hours < 24:
        checks.append({"level": "warn", "message":
                       f"Lead time is {lead_hours:.0f}h. Under 24h normally needs an Emergency "
                       "or Expedited change and extra approval."})
    elif lead_hours < 72:
        checks.append({"level": "info", "message":
                       f"Lead time is {lead_hours / 24:.1f} days. Confirm it meets the CAB "
                       "submission deadline for a Normal change."})

    typical = None
    if similar_durations:
        typical = float(np.median(similar_durations))
        if typical > 0 and duration_hours < 0.5 * typical:
            checks.append({"level": "warn", "message":
                           f"Window is {duration_hours:.1f}h; similar past changes planned a "
                           f"median of {typical:.1f}h. Allow time for backout."})
        elif typical > 0 and duration_hours > 3 * typical:
            checks.append({"level": "info", "message":
                           f"Window is {duration_hours:.1f}h, well above the {typical:.1f}h "
                           "median for similar changes."})
    if duration_hours > 72:
        checks.append({"level": "info", "message": "Window is longer than 3 days; consider splitting the change."})

    if environment == "Production":
        weekday = start.dayofweek < 5
        business = weekday and 8 <= start.hour < 18
        if business:
            checks.append({"level": "warn", "message":
                           "Starts during business hours (Mon-Fri 08:00-18:00) in Production. "
                           "Confirm user impact is acceptable or move outside core hours."})
    if not checks:
        checks.append({"level": "ok", "message": "Lead time, duration and timing look reasonable."})
    return {"checks": checks, "lead_time_hours": round(lead_hours, 1),
            "duration_hours": round(duration_hours, 2),
            "typical_duration_hours": round(typical, 2) if typical is not None else None}


def _duration_hours(row) -> Optional[float]:
    start = _parse_local(row.get("start_timestamp"))
    end = _parse_local(row.get("end_timestamp"))
    if start is None or end is None or end <= start:
        return None
    return (end - start).total_seconds() / 3600.0


def _plan_completeness(row) -> float:
    have = 0.0
    for field, weight in (("implementation_plan", 0.45), ("backout_plan", 0.35), ("test_plan", 0.20)):
        if len(_split_into_steps(str(row.get(field) or ""))) >= 2:
            have += weight
        elif clean_value(row.get(field)):
            have += weight / 2
    return have


def _recency(row, date_col: Optional[str]) -> float:
    if not date_col:
        return 0.0
    ts = _parse_local(row.get(date_col))
    if ts is None:
        return 0.0
    age_days = max((pd.Timestamp.now() - ts).days, 0)
    return float(max(0.0, 1.0 - age_days / 730.0))      # linear over two years


def _step_consensus(corpus_df, chosen_idx: int, others: List[int], field: str,
                    steps: List[str]) -> List[Dict[str, Any]]:
    """How many of the other similar CRs contain each lifted step."""
    other_keys = []
    for idx in others:
        text = str(corpus_df.iloc[idx].get(field) or "")
        other_keys.append([step_key(s) for s in _split_into_steps(text)])
    out = []
    for step in steps:
        key = step_key(step)
        support = sum(1 for keys in other_keys
                      if key and any(step_overlap(key, k) >= 0.7 for k in keys if k))
        out.append({"step": step, "support": support})
    return out


def _past_failures(snapshot, query: str) -> Tuple[List[Dict[str, Any]], int]:
    if not snapshot or not snapshot.get("failures"):
        return [], 0
    failures = snapshot["failures"]
    frame = failures["dataframe"]
    if not len(frame):
        return [], 0
    if snapshot.get("text_norm") == TEXT_NORM_VERSION:
        query = normalise(query)
    scores = cosine_similarity(snapshot["vectorizer"].transform([query]), failures["vectors"]).ravel()
    order = [int(i) for i in np.argsort(-scores) if scores[i] * 100 >= FAILURE_WARN_PCT]
    out = []
    for i in order[:5]:
        row = frame.iloc[i]
        out.append({"change_id": clean_value(row.get("change_id")), "title": clean_value(row.get("title")),
                    "state": clean_value(row.get("state")), "close_code": clean_value(row.get("close_code")),
                    "close_notes": clean_value(row.get("close_notes"))[:400],
                    "closed_date": clean_value(row.get("closed_timestamp"))[:10],
                    "similarity_score": round(float(scores[i]) * 100, 1)})
    return out, len(order)


def generate_cr_template(*,
                         title: str,
                         description: str,
                         planned_start: str,
                         planned_end: str,
                         environment: Optional[str] = None,
                         server_list: Optional[str] = None,
                         requested_by: Optional[str] = None,
                         now: Optional[datetime] = None,
                         ) -> Dict[str, Any]:
    """
    Generate a full CR template from similar successful past changes.

    Fields are a blend of the trained per-field classifiers (when present)
    and a similarity-weighted vote of the matched CRs. Plans are lifted from
    ONE source CR - chosen for relevance, completeness of its plans and
    recency - and every lifted step is annotated with how many of the other
    similar CRs contain it. Similar changes that failed or were backed out
    are reported separately as a risk signal.
    """
    title = (title or "").strip()
    description = (description or "").strip()
    environment = (environment or "").strip() or None
    env_canon = canonical_environment(environment) if environment else ""

    if not title or len(title) < 5:
        return {"status": "error", "message": "Title must be at least 5 characters."}
    if not description or len(description) < 10:
        return {"status": "error", "message": "Description must be at least 10 characters."}
    if not planned_start or not planned_end:
        return {"status": "error", "message": "Planned start and end dates are required."}
    start = _parse_local(planned_start)
    end = _parse_local(planned_end)
    if start is None or end is None or end <= start:
        return {"status": "error", "message": "Planned end must be later than planned start."}

    status = cr_models_status()
    if not status["all_loaded"]:
        return {
            "status": "no_models",
            "message": "No change history is available. A ServiceNow group member can import records above.",
            "model_status": status,
        }

    # Server validation
    server_info = lookup_servers(server_list or "") if server_list else {
        "status": "no_input", "servers_input": [], "servers_found": [],
        "servers_unknown": [], "applications": [], "external_interfaces": [],
        "warnings": [],
    }

    vec = _load(config.MODELS_DIR / "cr_vectorizer_latest.pkl")
    snapshot = load_snapshot("cr")
    if vec is None and snapshot is None:
        return {"status": "no_models", "message": "Vectorizer not loaded."}

    combined_query = f"{title} {description}".strip()

    # ---- Classifier probabilities per field ------------------------------
    Xq_tfidf = vec.transform([combined_query]) if vec is not None else None
    model_probs: Dict[str, Dict[str, float]] = {}
    for fld in _PER_FIELD_MODELS:
        if Xq_tfidf is None:
            break
        mdl = _load(config.MODELS_DIR / f"cr_field_{fld}_latest.pkl")
        if mdl is None:
            continue
        try:
            if hasattr(mdl, "predict_proba") and hasattr(mdl, "classes_"):
                proba = mdl.predict_proba(Xq_tfidf)[0]
                model_probs[fld] = {str(c): float(p) for c, p in zip(mdl.classes_, proba)}
            else:
                model_probs[fld] = {str(mdl.predict(Xq_tfidf)[0]): 0.6}
        except Exception as exc:
            logger.warning("Field %s prediction failed: %s", fld, exc)

    # ---- Retrieval --------------------------------------------------------
    if snapshot is not None:
        retrieval_vec = snapshot["vectorizer"]
        corpus_vecs, corpus_df = snapshot["vectors"], snapshot["dataframe"]
        semantic, bm25 = compatible_semantic(snapshot), snapshot["bm25"]
        cache = snapshot
    else:
        retrieval_vec = vec
        corpus_vecs = _load(config.MODELS_DIR / "cr_corpus_vectors_latest.pkl")
        corpus_df = _load(config.MODELS_DIR / "cr_corpus_dataframe_latest.pkl")
        semantic = load_sem_vectors("cr", config.MODELS_DIR)
        bm25 = load_bm25_index("cr", config.MODELS_DIR)
        cache = {}

    similar_changes: List[Dict[str, Any]] = []
    top_idx: List[int] = []
    top_scores: List[float] = []
    env_note = ""

    if corpus_vecs is not None and corpus_df is not None and len(corpus_df) > 0:
        n_docs = len(corpus_df)
        allowed = np.ones(n_docs, dtype=bool)
        boost = None
        if env_canon and "environment" in corpus_df:
            row_env = corpus_df["environment"].map(canonical_environment)
            same = row_env.eq(env_canon).to_numpy()
            blank = row_env.eq("").to_numpy()
            # Same environment, or no environment recorded (common when the
            # custom field is optional) - the latter ranked below the former.
            allowed = same | blank
            boost = same
            if blank.any():
                env_note = (f"{int(blank.sum())} historical change(s) have no environment recorded "
                            f"and are included, ranked after {env_canon} matches.")
        titles = corpus_df["title"].fillna("").astype(str).tolist() if "title" in corpus_df else None
        title_vectors = snapshot.get("title_vectors") if snapshot is not None else None
        if title_vectors is None or title_vectors.shape[0] != n_docs:
            title_vectors = cached_title_vectors(cache, retrieval_vec, titles)
        texts = corpus_df["text"].fillna("").astype(str).tolist() if "text" in corpus_df else titles
        ranked = rank_detailed(
            combined_query, retrieval_vec, corpus_vecs, semantic=semantic, bm25=bm25,
            encoder=_get_embedding_model() if semantic is not None else None,
            allowed=allowed, lexical_floor=0.05, title_vectors=title_vectors, texts=texts,
            boost=boost, title_query=title,
            char=snapshot.get("char") if snapshot is not None else None,
            normalised=bool(snapshot is not None and snapshot.get("text_norm") == TEXT_NORM_VERSION))
        hybrid, strength = ranked["fused"], ranked["strength"]
        order = [int(i) for i in np.argsort(-hybrid, kind="stable")[:TOP_K_SIMILAR_CRS] if hybrid[i] > 0]

        for i in order:
            sim = float(strength[i])
            if sim < 0.05:
                continue
            top_idx.append(i)
            top_scores.append(round(sim * 100, 1))
            row = corpus_df.iloc[i]
            similar_changes.append({
                "change_id":          clean_value(row.get("change_id")),
                "title":              clean_value(row.get("title")),
                "type":               clean_value(row.get("type")),
                "risk":               clean_value(row.get("risk")),
                "category":           clean_value(row.get("category")),
                "assignment_group":   clean_value(row.get("assignment_group")),
                "configuration_item": clean_value(row.get("configuration_item")),
                "similarity_score":   round(sim * 100, 1),
                "match_signals":      ranked["signals"][i],
                "environment":        clean_value(row.get("environment")),
                "closed_date":        clean_value(row.get("closed_timestamp")),
                "close_code":         clean_value(row.get("close_code")),
                "duration_hours":     (round(_duration_hours(row), 2)
                                       if _duration_hours(row) is not None else None),
                "plan_completeness":  round(_plan_completeness(row) * 100),
            })

    # ---- Field vote over the similar CRs ------------------------------------
    voters = [(i, s) for i, s in zip(top_idx, top_scores) if s >= SIMILAR_VOTE_FLOOR]
    vote_weights = [(s / 100.0) ** 2 for _, s in voters]
    history_strength = float(min(1.0, sum(s / 100.0 for _, s in voters) / 1.5)) if voters else 0.0
    fields: Dict[str, Any] = {}
    confidences: Dict[str, float] = {}
    field_detail: Dict[str, Dict[str, Any]] = {}
    for fld in _PER_FIELD_MODELS:
        history = []
        if voters and fld in corpus_df:
            history = weighted_vote((corpus_df.iloc[i].get(fld), w)
                                    for (i, _), w in zip(voters, vote_weights))
        ranked_values, source = ensemble(model_probs.get(fld), history, history_strength)
        if ranked_values:
            fields[fld] = ranked_values[0][0]
            confidences[fld] = round(float(ranked_values[0][1]), 3)
            field_detail[fld] = {"source": source,
                                 "alternatives": [{"value": k, "confidence": round(float(v), 3)}
                                                  for k, v in ranked_values[1:4]]}

    # ---- Type / risk rules --------------------------------------------------
    rationale: List[str] = []
    lead_hours = (start - pd.Timestamp(now or datetime.now())).total_seconds() / 3600.0
    predicted_type = fields.get("type", "Normal")
    if 0 <= lead_hours < 24 and predicted_type not in ("Emergency", "Expedited"):
        rationale.append(f"History suggests {predicted_type}, but the {lead_hours:.0f}h lead time "
                         "means it will need Emergency or Expedited handling.")
    if predicted_type == "Standard":
        standard_share = next((v for k, v in (weighted_vote(
            (corpus_df.iloc[i].get("type"), w) for (i, _), w in zip(voters, vote_weights))
            if voters and "type" in corpus_df else []) if k == "Standard"), 0.0)
        if standard_share:
            rationale.append(f"{standard_share * 100:.0f}% of the similar changes were raised as "
                             "Standard - check a pre-approved Standard template exists.")
    risk = fields.get("risk", "Moderate")
    ext = len(server_info.get("external_interfaces") or [])
    n_servers = len(server_info.get("servers_found") or [])
    if env_canon == "Production" and _RISK_ORDER.get(risk, 2) < 2 and (ext or n_servers > 5):
        rationale.append(f"Risk raised from {risk} to Moderate: Production change with "
                         f"{'external interfaces' if ext else str(n_servers) + ' servers'} in scope.")
        risk = fields["risk"] = "Moderate"
        confidences["risk"] = max(confidences.get("risk", 0.0), 0.7)

    # ---- Past failures --------------------------------------------------------
    past_failures, failure_count = _past_failures(snapshot, combined_query)
    successes = sum(1 for s in top_scores if s >= FAILURE_WARN_PCT)
    if failure_count:
        rationale.append(f"{failure_count} similar past change(s) failed or were backed out - "
                         "review their close notes before finalising the plans.")
        if _RISK_ORDER.get(risk, 2) < 2:
            risk = fields["risk"] = "Moderate"

    # ---- Pick the plan source ---------------------------------------------------
    plan_source: Dict[str, Any] = {
        "mode": "none", "best_match_id": None, "best_match_score": None,
        "disclaimer": PLAN_DISCLAIMER, "risk_impact_source": "none",
    }
    impl_steps: List[str] = []
    backout_steps: List[str] = []
    test_steps: List[str] = []
    risk_impact = ""
    chosen_idx: Optional[int] = None
    chosen_score = 0.0

    date_col = next((c for c in ("closed_timestamp", "end_timestamp", "opened_timestamp")
                     if corpus_df is not None and c in corpus_df.columns), None)
    if corpus_df is not None and top_idx:
        top_score = max(top_scores)
        if top_score >= MIN_MATCH_PCT_FOR_LIFT:
            voted_group = fields.get("assignment_group", "")
            candidates = []
            for idx, sc in zip(top_idx, top_scores):
                if sc < top_score - PLAN_SOURCE_WINDOW:
                    continue
                row = corpus_df.iloc[idx]
                completeness = _plan_completeness(row)
                recency = _recency(row, date_col)
                same_group = 1.0 if voted_group and clean_value(row.get("assignment_group")) == voted_group else 0.0
                composite = sc + 8 * completeness + 4 * recency + 3 * same_group
                candidates.append((composite, sc, idx, completeness, recency, same_group))
            candidates.sort(key=lambda c: -c[0])
            _, chosen_score, chosen_idx, completeness, recency, same_group = candidates[0]
            reasons = [f"{chosen_score:.0f}% match"]
            if completeness >= 0.99:
                reasons.append("complete implementation, backout and test plans")
            elif completeness > 0:
                reasons.append(f"plans {completeness * 100:.0f}% complete")
            if recency > 0.5:
                reasons.append("recent")
            if same_group:
                reasons.append("same assignment group")
            if chosen_idx != top_idx[0]:
                reasons.append(f"preferred over the top text match ({top_scores[0]:.0f}%) "
                               "for its plan quality")
            plan_source["reason"] = "; ".join(reasons) + "."

    others: List[int] = []
    consensus: Dict[str, List[Dict[str, Any]]] = {}
    if chosen_idx is not None:
        others = [i for i, s in zip(top_idx, top_scores) if i != chosen_idx and s >= SIMILAR_VOTE_FLOOR]
        impl_steps = _plan_from_single_cr(corpus_df, chosen_idx, "implementation_plan")
        backout_steps = _plan_from_single_cr(corpus_df, chosen_idx, "backout_plan")
        test_steps = _plan_from_single_cr(corpus_df, chosen_idx, "test_plan")
        # A source with a blank section borrows the steps most similar CRs share.
        borrowed = []
        for name, steps in (("backout_plan", backout_steps), ("test_plan", test_steps)):
            if not steps and others:
                common = _common_steps_from_corpus(corpus_df, [chosen_idx] + others, name)
                if common:
                    if name == "backout_plan":
                        backout_steps = common
                    else:
                        test_steps = common
                    borrowed.append(name.replace("_", " "))
        if borrowed:
            plan_source["borrowed_sections"] = borrowed
        for name, steps in (("implementation_plan", impl_steps), ("backout_plan", backout_steps),
                            ("test_plan", test_steps)):
            consensus[name] = _step_consensus(corpus_df, chosen_idx, others, name, steps)

        if "risk_impact_analysis" in corpus_df.columns:
            candidate_ria = str(corpus_df.iloc[chosen_idx].get("risk_impact_analysis") or "").strip()
            if len(candidate_ria.split()) >= 8:
                risk_impact = candidate_ria
                plan_source["risk_impact_source"] = "lifted_from_best_match"

        chosen_row = corpus_df.iloc[chosen_idx]
        plan_source.update({
            "mode": ("high_confidence_match" if chosen_score >= HIGH_CONFIDENCE_PCT
                     else "best_available_match"),
            "best_match_id": clean_value(chosen_row.get("change_id")),
            "best_match_title": clean_value(chosen_row.get("title")),
            "best_match_score": chosen_score,
            "compared_with": len(others),
        })
    else:
        plan_source.update({
            "mode": "no_corpus_match",
            "fallback_reason": "No similar past CRs were found - please draft "
                               "the implementation, backout and test plans manually.",
        })

    if not risk_impact:
        risk_impact = _compose_risk_impact_analysis(
            type_pred=fields.get("type", "Normal"),
            risk_pred=fields.get("risk", "Moderate"),
            environment=env_canon or "the target",
            server_count=n_servers,
            has_external_interfaces=bool(ext),
            business_service=fields.get("business_service", ""),
            similar_count=len(similar_changes),
        )
        if failure_count:
            risk_impact += (f" {failure_count} similar past change(s) failed or were backed out; "
                            "their lessons should be reflected in the backout plan.")
        plan_source["risk_impact_source"] = "rule_composer"

    durations = [c["duration_hours"] for c, s in zip(similar_changes, top_scores)
                 if c["duration_hours"] and s >= SIMILAR_VOTE_FLOOR]
    schedule = _schedule_checks(start, end, env_canon, durations, now=now)

    description_quality = score_cr_description(description)

    template: Dict[str, Any] = {
        "title":               title,
        "description":         description,
        "type":                fields.get("type", "Normal"),
        "category":            fields.get("category", "Unknown"),
        "subcategory":         fields.get("subcategory", "Unknown"),
        "business_service":    fields.get("business_service", "Unknown"),
        "risk":                fields.get("risk", "Moderate"),
        "priority":            _display_scale("priority", fields.get("priority", "3")),
        "impact":              _display_scale("impact", fields.get("impact", "2")),
        "urgency":             _display_scale("urgency", fields.get("urgency", "2")),
        "assignment_group":    fields.get("assignment_group", "Unknown"),
        "environment":         env_canon or "",
        "planned_start":       planned_start,
        "planned_end":         planned_end,
        "implementation_plan": impl_steps,
        "backout_plan":        backout_steps,
        "test_plan":           test_steps,
        "risk_impact_analysis": risk_impact,
        "confidences":         confidences,
        "requested_by":        requested_by or "",
    }

    quality = score_template(template)

    if server_info.get("warnings"):
        rendered_warnings = "\n".join(server_info["warnings"])
        template["risk_impact_analysis_with_warnings"] = (
            f"{risk_impact}\n\n{rendered_warnings}"
        )

    return {
        "status":              "ok",
        "template":            template,
        "quality":             quality,
        "similar_changes":     similar_changes,
        "server_lookup":       server_info,
        "description_quality": description_quality,
        "plan_source":         plan_source,
        "plan_consensus":      consensus,
        "field_detail":        field_detail,
        "rationale":           rationale,
        "schedule":            schedule,
        "outcomes":            {"similar_successful": successes, "similar_failed": failure_count,
                                "failures": past_failures},
        "environment_note":    env_note,
        "evidence":            {"voters": len(voters), "strength": round(history_strength, 2),
                                "models_used": sorted(model_probs)},
        "model_status":        status,
    }
