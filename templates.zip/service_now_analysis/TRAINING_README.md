# ServiceNow Analysis - training and history guide

How to load ServiceNow data into the **Incident template**, **Similar tickets**
and **CR template** pages: the first full load, and every update after it.

Everything here runs offline with the libraries the module already uses
(pandas, numpy, scipy, scikit-learn). Nothing is downloaded.

---

## 1. Two things to load (and why)

| | **Searchable history** | **Trained models** |
|---|---|---|
| Command | `ml.knowledge` (or the **Import history** button) | `ml.train`, `change_train`, `problem_train` |
| Used by | Similar tickets, template evidence and suggested fixes, CR plans, failed-change warnings | Field predictions: category, subcategory, group, priority (incidents); CR fields; Problem search |
| New data | **Incremental** - import only what changed | **Not incremental** - always retrains from scratch on exactly the files you give it |
| Service Requests | Yes (`--kind sr`) | No model; SR templates use history only |

> **Never train a model on a delta file alone.** The model would be rebuilt
> from only the new rows. Training always needs the complete history - keep
> every export and train on the folder (section 4).

---

## 2. One-time setup

Run every command from the **application root** - the folder that contains
`main_app.py` - with the same Python the application runs with.

```powershell
cd <application root>
mkdir data\training\incident, data\training\sr, data\training\cr, data\training\problem
```

Keep **every** export you ever take in its folder and never delete old ones;
model training reads the whole folder. Only `.csv`, `.xlsx` and `.xls` files
are read. File names are free, but a date in the name keeps them ordered, e.g.
`incidents_2026-09-full.csv`, `incidents_2026-10-delta.csv`.

---

## 3. Exporting from ServiceNow

CSV exports use field names (`number`, `short_description`); Excel exports use
display headers (`Number`, `Short description`). Both are accepted.

| Type | Table | Required | Strongly recommended |
|---|---|---|---|
| Incident | `incident` | `number`, `short_description`, `state`, `opened_at`, `sys_updated_on` | `description`, `category`/`u_tenant_category`, `subcategory`, `priority`, `assignment_group`, `cmdb_ci`, `resolved_at`, `closed_at`, `close_code`, `close_notes`, `u_cause_notes`, `caller_id` |
| Service Request | `sc_req_item` (RITM) | `number`, `short_description`, `state`, `sys_updated_on` | `description`, `cat_item`, `assignment_group`, `opened_at`, `closed_at`, `close_notes`, `priority` |
| Change | `change_request` | `number`, `short_description`, `type`, `state`, `sys_updated_on` | `description`, `u_environment`, `risk`, `priority`, `impact`, `urgency`, `category`, `assignment_group`, `cmdb_ci`, `business_service`, `start_date`, `end_date`, `closed_at`, `u_tenant_close_code`, `close_notes`, `implementation_plan`, `backout_plan`, `test_plan`, `risk_impact_analysis` |
| Problem | `problem` | `number`, `short_description`, `state` | `description`, `u_tenant_category`, `priority`, `assignment_group`, `cmdb_ci`, `workaround`, `cause_notes`, `known_error` |

- Export **display values** for choice fields (state, priority, type).
- **First load:** export everything (or as many years as you want searchable).
- **Delta:** filter on **Updated (`sys_updated_on`) since the last export**,
  with one day of overlap. Filter on *updated*, not *opened* - that also
  picks up older tickets that were reopened, re-closed or edited.
- Minimum volumes: incident models need 50 usable rows per field; the CR
  models need 100 valid changes. History imports have no minimum.

---

## 4. First time (from scratch)

Put the full exports in their folders, then run the steps in order.

### Step 1 - Searchable history
```powershell
python -m modules.service_now_analysis.ml.knowledge --kind incident --input data\training\incident\incidents_2026-09-full.csv
python -m modules.service_now_analysis.ml.knowledge --kind sr       --input data\training\sr\requests_2026-09-full.csv
python -m modules.service_now_analysis.ml.knowledge --kind cr       --input data\training\cr\changes_2026-09-full.csv
```
Each prints a JSON summary: `records` (kept), `searchable` (offered as
precedents - resolved / fulfilled / successful only), `failures_indexed`
(CRs; failed or backed-out changes used for warnings).

### Step 2 - Incident models
```powershell
python -m modules.service_now_analysis.ml.merge_exports --input-dir data\training\incident --output data\training\incidents_all.csv
python -m modules.service_now_analysis.ml.train --input data\training\incidents_all.csv --evaluate
```
With one file in the folder the merge just copies it; running it anyway
keeps the first-time and incremental commands identical.

### Step 3 - CR models
```powershell
python -m modules.service_now_analysis.change_train --change-input-dir data\training\cr
```

### Step 4 - Problem records (optional - "Related Problem records" panel)
```powershell
python -m modules.service_now_analysis.problem_train --problem-input-dir data\training\problem
```
Only open / known-error Problems are searchable by default; add
`--include-resolved` to include resolved ones.

### Step 5 - Check
Open **Similar tickets**, **Incident template** and **CR template**. The
header chips should show green dots with the record counts, e.g.
"Incidents 12,480 - 2026-09-29".

---

## 5. Incremental (each new batch)

Export the deltas (section 3) and save them **next to** the older files in
their folders.

### Step 1 - Searchable history (every delta; weekly or monthly is typical)
Import **only the new files**:
```powershell
python -m modules.service_now_analysis.ml.knowledge --kind incident --input data\training\incident\incidents_2026-10-delta.csv
python -m modules.service_now_analysis.ml.knowledge --kind sr       --input data\training\sr\requests_2026-10-delta.csv
python -m modules.service_now_analysis.ml.knowledge --kind cr       --input data\training\cr\changes_2026-10-delta.csv
```
What the import does:
- adds new tickets and replaces a ticket only with an equal or **newer**
  `sys_updated_on` - re-importing an old file is harmless;
- keeps fields a smaller export leaves out (e.g. plans missing from a
  reduced CR export are not erased);
- a reopened incident or a failed CR stays in history but stops being
  offered as a precedent;
- missing rows are **not** deletions.

### Step 2 - Retrain models (monthly or quarterly is enough)
Always on the **whole folder**, never the delta alone:
```powershell
python -m modules.service_now_analysis.ml.merge_exports --input-dir data\training\incident --output data\training\incidents_all.csv
python -m modules.service_now_analysis.ml.train --input data\training\incidents_all.csv --evaluate

python -m modules.service_now_analysis.change_train --change-input-dir data\training\cr
python -m modules.service_now_analysis.problem_train --problem-input-dir data\training\problem
```
`merge_exports` and `change_train` keep the newest version of each ticket
across files, so overlapping exports are fine.

Incident models are **replaced only if the new ones score better** (the
report printed by `--evaluate` shows each decision). To replace them
regardless, add `--force-replace`. To train and report without saving, use
`--dry-run`.

---

## 6. The "Import history" button

The **Import history** button on each page (panel title "Import ServiceNow
records") is the same as `ml.knowledge` in section 5 step 1: it merges one
export into that page's searchable history. It does **not** train models.

- On Similar tickets and Incident template, choose the **Record type**
  (Incidents or Service requests); on CR template it imports changes.
- Only ServiceNow group members see it.
- Fine for small monthly deltas. Use the command line for first loads and
  large files - a big import can outlast the browser / IIS request timeout.
  If the page times out, check the header chip before retrying: the import
  may still have finished.

---

## 7. After upgrading the application

After deploying a new version of this module, **import each type's full
history once** (section 4 step 1, or the whole folder file by file). Older
history snapshots keep working, but only a new import rebuilds them with the
current rules:
- blank group / category / CI / environment left blank instead of filled
  with the most common value;
- cancelled and duplicate incidents removed from search;
- IT vocabulary, spelling and specific-term matching;
- the failed-change index used for CR warnings.

---

## 8. Quick reference

| Task | Command |
|---|---|
| Import history (incident / sr / cr) | `python -m modules.service_now_analysis.ml.knowledge --kind <incident\|sr\|cr> --input <file>` |
| Merge incident exports | `python -m modules.service_now_analysis.ml.merge_exports --input-dir data\training\incident --output data\training\incidents_all.csv` |
| Train incident models | `python -m modules.service_now_analysis.ml.train --input data\training\incidents_all.csv --evaluate` |
| Train CR models | `python -m modules.service_now_analysis.change_train --change-input-dir data\training\cr` |
| Train Problem search | `python -m modules.service_now_analysis.problem_train --problem-input-dir data\training\problem` |
| Compare search engines | `python tests\bench_snow_paraphrase.py -v` |

---

## 9. Troubleshooting

| Message / symptom | Cause and fix |
|---|---|
| `An update is already running` | Another import of the same type is in progress (lock file `data\service_now_analysis\knowledge\<kind>\UPDATE.lock`). Wait. Delete the lock **only** after confirming no import is running (e.g. one killed mid-way). |
| `Export is missing fields: ...` | Add the listed columns to the export (section 3). |
| `Every record needs a ticket number, description and valid sys_updated_on` | Some rows have a blank number / short description or an unreadable Updated date. Fix or drop them and re-export. |
| `Need at least 100 valid CRs to train` | Add more history to `data\training\cr`. The CR template still works from history alone. |
| Incident models "not replaced" | The new models did not beat the current ones. Check `--evaluate` output; use `--force-replace` if intended. |
| Header chip red / "no history" | No import has been done for that type yet (section 4 step 1). |
| Header chip amber / "legacy corpus" | Search runs from the old training corpus. Import the full export to switch to the managed history. |
| Search finds nothing for a very differently worded ticket | Wording with no shared words cannot be matched offline. Add your organisation's terms to `ml\textnorm.py`, then re-import history. |

A failed import never changes the active history - the previous version
stays in use.
