"""Single-ticket detail lookup for the Summary report drawer.

The summary payload only carries the handful of fields each chart needs.
When a user clicks a ticket number in a section table, the drawer wants the
ticket as it appeared in the uploaded export: description, resolution
notes, who it sat with. This module re-reads the session's uploaded file
with the SAME loader and header normaliser the upload used (so an Excel
display-header export and a CSV field-name export both resolve), indexes it
by ticket number and returns only the fields worth reading.

Read-only by design: column_mapper / preprocess / service_request are
called, never changed. Values come from the RAW file, not the preprocessed
frame - preprocessing mode-fills blank categories and priorities, which is
right for aggregates and wrong on a single ticket.
"""
from __future__ import annotations

import logging
import threading
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from .ml.preprocess import load_export
from .service_request import apply_sr_fallbacks, normalise_display_export

logger = logging.getLogger(__name__)

# Long free-text fields (work notes journals) can run to tens of KB per
# ticket; the drawer is a summary, not the journal.
_NOTE_LIMIT = 4000

# Strings pandas / the export use for "nothing here".
_BLANKS = {"", "nan", "none", "nat", "null", "<na>"}

# (label, candidate snake_case columns - first non-blank wins).
# Candidates cover the CSV field name AND the snake-cased Excel display
# header, for incidents and service requests alike; a column absent from
# the file simply yields nothing and the row is dropped.
_OVERVIEW: List[Tuple[str, List[str]]] = [
    ("State",             ["state", "incident_state"]),
    ("Priority",          ["priority"]),
    ("Impact",            ["impact"]),
    ("Urgency",           ["urgency"]),
    ("Category",          ["category"]),
    ("Subcategory",       ["subcategory"]),
    ("Tenant category",   ["u_tenant_category"]),
    ("Item",              ["item", "cat_item"]),
    ("Request",           ["request"]),
    ("Stage",             ["stage"]),
    ("Approval",          ["approval"]),
    ("Caller",            ["caller_id"]),
    ("Requested for",     ["requested_for"]),
    ("Opened by",         ["opened_by"]),
    ("Channel",           ["contact_type", "channel"]),
    ("Configuration item", ["cmdb_ci"]),
    ("Business service",  ["business_service", "service"]),
    ("Assignment group",  ["assignment_group"]),
    ("Assigned to",       ["assigned_to"]),
]

_TIMELINE: List[Tuple[str, List[str]]] = [
    ("Opened",            ["opened_at", "sys_created_on"]),
    ("Resolved",          ["resolved_at"]),
    ("Closed",            ["closed_at"]),
    ("Last updated",      ["sys_updated_on"]),
    ("Off hold date",     ["due_date"]),
    ("SLA met",           ["made_sla", "x_caukp_slc_sla_met", "sla_met"]),
    ("Reassignments",     ["reassignment_count"]),
    ("Reopens",           ["reopen_count"]),
]

_RESOLUTION: List[Tuple[str, List[str]]] = [
    ("Resolution code",     ["u_tenant_resolution_code", "close_code",
                             "resolution_code"]),
    ("Resolution category", ["u_tenant_resolution_category"]),
    ("Root cause code",     ["u_cause_code", "cause_code"]),
    ("Resolved by",         ["resolved_by", "closed_by"]),
]

# Free text, rendered as paragraphs rather than label/value rows.
_TEXT: List[Tuple[str, str, List[str]]] = [
    # (key, label, candidates)
    ("description", "Description",      ["description"]),
    ("resolution",  "Resolution notes", ["close_notes", "resolution_notes"]),
    ("root_cause",  "Root cause notes", ["u_cause_notes", "cause_notes"]),
    ("comments",    "Additional comments", ["comments", "additional_comments"]),
    ("work_notes",  "Work notes",       ["work_notes",
                                         "comments_and_work_notes"]),
]

# (path, mtime, kind) -> (frame, {NUMBER: row position}). Small: a user
# clicks through tickets of ONE report, and the upload files are large.
_CACHE: "OrderedDict[Tuple[str, float, str], Tuple[pd.DataFrame, Dict[str, int]]]" = OrderedDict()
_CACHE_MAX = 4
_LOCK = threading.Lock()


class TicketFileMissing(Exception):
    """The session's uploaded file is gone (cleanup ran or it was deleted)."""


def _clean(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    return "" if text.lower() in _BLANKS else text


def _load_indexed(filepath: str, kind: str) -> Tuple[pd.DataFrame, Dict[str, int]]:
    path = Path(filepath)
    if not path.is_file():
        raise TicketFileMissing(filepath)
    key = (str(path), path.stat().st_mtime, kind)
    with _LOCK:
        hit = _CACHE.get(key)
        if hit is not None:
            _CACHE.move_to_end(key)
            return hit

    df = load_export(path)
    if path.suffix.lower() in (".xlsx", ".xls"):
        df = normalise_display_export(df)
    if kind == "sr":
        df = apply_sr_fallbacks(df)
    df = df.reset_index(drop=True)

    index: Dict[str, int] = {}
    if "number" in df.columns:
        for pos, raw in enumerate(df["number"].tolist()):
            num = _clean(raw).upper()
            # First occurrence wins, matching how the summary counts it.
            if num and num not in index:
                index[num] = pos

    with _LOCK:
        _CACHE[key] = (df, index)
        _CACHE.move_to_end(key)
        while len(_CACHE) > _CACHE_MAX:
            _CACHE.popitem(last=False)
    return df, index


def _first(row: Dict[str, Any], candidates: List[str]) -> str:
    for col in candidates:
        if col in row:
            text = _clean(row[col])
            if text:
                return text
    return ""


def _pairs(row: Dict[str, Any], spec: List[Tuple[str, List[str]]]) -> List[Dict[str, str]]:
    out = []
    for label, candidates in spec:
        value = _first(row, candidates)
        if value:
            out.append({"label": label, "value": value})
    return out


def lookup_ticket(filepath: str, kind: str, number: str) -> Optional[Dict[str, Any]]:
    """Return the drawer payload for one ticket, or None when the number is
    not in the file. Raises TicketFileMissing when the upload is gone."""
    df, index = _load_indexed(filepath, kind)
    pos = index.get(_clean(number).upper())
    if pos is None:
        return None
    row = df.iloc[pos].to_dict()

    text = []
    for key, label, candidates in _TEXT:
        value = _first(row, candidates)
        if not value:
            continue
        truncated = len(value) > _NOTE_LIMIT
        text.append({
            "key": key,
            "label": label,
            "value": value[:_NOTE_LIMIT],
            "truncated": truncated,
        })

    # apply_sr_fallbacks copies the catalog Item into u_tenant_category;
    # don't show the same value twice under two labels.
    overview = _pairs(row, _OVERVIEW)
    item = next((p["value"] for p in overview if p["label"] == "Item"), None)
    if item is not None:
        overview = [p for p in overview
                    if not (p["label"] == "Tenant category" and p["value"] == item)]

    return {
        "number": _clean(row.get("number")),
        "short_description": _first(row, ["short_description"]),
        "state": _first(row, ["state", "incident_state"]),
        "priority": _first(row, ["priority"]),
        "assignment_group": _first(row, ["assignment_group"]),
        "overview": overview,
        "timeline": _pairs(row, _TIMELINE),
        "resolution": _pairs(row, _RESOLUTION),
        "text": text,
    }
