"""Merge every ServiceNow export in a folder into one file, newest version wins.

Incident model training (ml/train.py) takes ONE input file and retrains from
scratch on exactly that file. When exports are collected over time (a full
history plus monthly deltas), merge them first so training sees everything:

    python -m modules.service_now_analysis.ml.merge_exports ^
        --input-dir data\\training\\incident --output data\\training\\incidents_all.csv

A ticket that appears in several files is kept once: the row with the latest
sys_updated_on (or, without that column, the one from the file sorted last).
CSV and Excel files are read; field-name (CSV) and display-header (Excel)
exports can be mixed.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

from .preprocess import load_export
from .dates import parse_dates
from ..service_request import normalise_display_export


def merge_folder(input_dir: Path) -> pd.DataFrame:
    files = sorted(p for p in Path(input_dir).iterdir()
                   if p.suffix.lower() in (".csv", ".xlsx", ".xls"))
    if not files:
        raise FileNotFoundError(f"No CSV or Excel exports in {input_dir}")
    frames = []
    for order, path in enumerate(files):
        frame = load_export(path)
        if path.suffix.lower() in (".xlsx", ".xls"):
            frame = normalise_display_export(frame)
        frame["_file_order"] = order
        frames.append(frame)
        print(f"  {path.name}: {len(frame):,} rows")
    merged = pd.concat(frames, ignore_index=True, sort=False)
    if "number" not in merged:
        raise ValueError("Exports need a 'number' (Number) column")
    sort_cols = ["_file_order"]
    if "sys_updated_on" in merged:
        merged["_updated"] = parse_dates(merged["sys_updated_on"], name="sys_updated_on")
        sort_cols = ["_updated", "_file_order"]
    merged = (merged.sort_values(sort_cols, kind="stable", na_position="first")
                    .drop_duplicates("number", keep="last")
                    .drop(columns=[c for c in ("_updated", "_file_order") if c in merged]))
    return merged.reset_index(drop=True)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Merge ServiceNow exports, newest version of each ticket wins")
    parser.add_argument("--input-dir", required=True, help="Folder with CSV / Excel exports")
    parser.add_argument("--output", required=True, help="Merged CSV to write")
    args = parser.parse_args(argv)
    merged = merge_folder(Path(args.input_dir))
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(args.output, index=False)
    print(f"Merged {len(merged):,} unique tickets -> {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
