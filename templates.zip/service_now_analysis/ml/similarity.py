"""
Similar-ticket search over resolved incidents and fulfilled service requests,
plus related Problem tickets.

How a search works
------------------
1. The chosen corpora (incident, service request, or both) are loaded from
   their versioned knowledge snapshots (legacy model artefacts are the
   incident fallback).
2. Hard filters (category, priority, group, resolved-since) remove rows.
3. retrieval.rank_detailed scores every remaining row with up to six
   signals - text, title, semantic, BM25 keywords, exact error-code /
   host-name hits and an optional configuration-item preference - and fuses
   their ranks. Rows only become candidates on meaningful evidence.
4. Candidates describing the SAME recurring problem (same title fingerprint)
   are collapsed into one card that says how often it recurred, with the
   member that has the most useful resolution note as the representative.
   This replaces the old MMR step, which re-ordered results by the
   sentence-embedding score alone and could push an exact error-code match
   off the list; recurrence is evidence a support engineer wants to see,
   not noise to diversify away.
5. Insights are computed from the strongest evidence: the group that
   usually resolves this, typical resolution time, how many matches carry a
   usable fix, and whether the issue recurs often enough to warrant a
   Problem record.

Match score (%) is an evidence strength - the best of text, title and
calibrated semantic similarity, plus small bonuses when independent signals
agree or an exact identifier matched. It is not a probability that the
matched fix will work.
"""

from __future__ import annotations

import html
import logging
import re
from collections import Counter
from typing import Any, Dict, List, Optional, Sequence

import joblib
import numpy as np
import pandas as pd

from .. import config
from .assist import (
    assess_resolution, clean_value, consensus_steps, title_key, weighted_percentile,
    weighted_vote,
)
from .embedding_utils import get_encoder, load_bm25_index, load_sem_vectors
from .knowledge import compatible_semantic, load_snapshot
from .textnorm import TEXT_NORM_VERSION
from .retrieval import cached_title_vectors, rank, rank_detailed

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Thresholds
# ---------------------------------------------------------------------------
_INCIDENT_SIM_FLOOR = 0.10    # min TF-IDF cosine for the Text / Title signals
_PROBLEM_SIM_FLOOR = 0.12     # slightly stricter to reduce false positives

# Display bands on the match score. Calibrated for the evidence-strength
# scale above (TF-IDF cosine of a genuinely similar IT ticket is typically
# 0.35-0.6; an identical one approaches 1).
BAND_HIGH = 65.0
BAND_MEDIUM = 45.0
# Evidence used for insights / voting must be at least this strong.
EVIDENCE_FLOOR = 0.30
RECURRING_THRESHOLD = 3
# The category classifier must be at least this sure before it re-ranks.
MODEL_HINT_MIN_CONFIDENCE = 0.6
# Matches weaker than this are not shown at all - below it the list is noise.
DISPLAY_FLOOR = 20.0

SOURCES = {
    "incident": {"label": "Incident", "plural": "resolved incidents"},
    "sr": {"label": "Service Request", "plural": "fulfilled service requests"},
}

# Kept for backwards compatibility with callers that imported them.
_MMR_LAMBDA = 0.7
_MMR_CANDIDATE_MULTIPLIER = 3


# ---------------------------------------------------------------------------
# Artifact loaders
# ---------------------------------------------------------------------------
def _load_incident_artefacts():
    vec_path = config.MODELS_DIR / "vectorizer_latest.pkl"
    corpus_path = config.MODELS_DIR / "corpus_vectors_latest.pkl"
    df_path = config.MODELS_DIR / "corpus_dataframe_latest.pkl"

    if not (vec_path.exists() and corpus_path.exists() and df_path.exists()):
        return None, None, None

    try:
        return (joblib.load(vec_path),
                joblib.load(corpus_path),
                joblib.load(df_path))
    except Exception as exc:
        logger.error("Failed to load incident artefacts: %s", exc)
        return None, None, None


def _load_problem_artefacts():
    vec_path = config.MODELS_DIR / "problem_vectorizer_latest.pkl"
    corpus_path = config.MODELS_DIR / "problem_corpus_vectors_latest.pkl"
    df_path = config.MODELS_DIR / "problem_corpus_dataframe_latest.pkl"

    if not (vec_path.exists() and corpus_path.exists() and df_path.exists()):
        return None, None, None

    try:
        return (joblib.load(vec_path),
                joblib.load(corpus_path),
                joblib.load(df_path))
    except Exception as exc:
        logger.error("Failed to load Problem artefacts: %s", exc)
        return None, None, None


def _get_embedding_model():
    """Lazy-load the sentence encoder from config.EMBEDDING_MODEL_PATH."""
    model_path = getattr(config, "EMBEDDING_MODEL_PATH", None)
    if not model_path:
        return None
    return get_encoder(str(model_path))


# Legacy (non-snapshot) corpora have nowhere to cache derived matrices.
_LEGACY_CACHE: Dict[int, dict] = {}


def load_corpus(source: str) -> Optional[Dict[str, Any]]:
    """Everything needed to search one source, or None when it has no history."""
    snapshot = load_snapshot(source)
    if snapshot is not None:
        return {"vectorizer": snapshot["vectorizer"], "vectors": snapshot["vectors"],
                "dataframe": snapshot["dataframe"], "semantic": compatible_semantic(snapshot),
                "bm25": snapshot["bm25"], "cache": snapshot,
                "title_vectors": snapshot.get("title_vectors"),
                "char": snapshot.get("char"),
                "normalised": snapshot.get("text_norm") == TEXT_NORM_VERSION}
    if source != "incident":
        return None
    vec, vectors, df = _load_incident_artefacts()
    if vec is None:
        return None
    cache = _LEGACY_CACHE.setdefault(id(df), {})
    return {"vectorizer": vec, "vectors": vectors, "dataframe": df,
            "semantic": load_sem_vectors("incident", config.MODELS_DIR),
            "bm25": load_bm25_index("incident", config.MODELS_DIR), "cache": cache,
            "title_vectors": None, "char": None, "normalised": False}


def _model_hint(description: str, df) -> Optional[np.ndarray]:
    """Rows in the category the trained incident classifier predicts.

    The classifier learned from thousands of labelled tickets which wordings
    belong to which category, so it recognises "can't reach the portal" and
    "site unavailable" as the same kind of ticket even with no shared words.
    Used only to re-rank candidates, and only when it is confident.
    """
    if "category" not in df or not config.models_available():
        return None
    try:
        from .predict import ModelStore
        store = ModelStore()
        vec, model = store.vectorizer(), store.cat_model()
        if vec is None or model is None or not hasattr(model, "classes_"):
            return None
        proba = model.predict_proba(vec.transform([description]))[0]
        best = int(np.argmax(proba))
        label = str(model.classes_[best])
        if proba[best] < MODEL_HINT_MIN_CONFIDENCE or label in ("Other", "Unknown"):
            return None
        mask = df["category"].fillna("").astype(str).str.casefold().eq(label.casefold()).to_numpy()
        return mask if mask.any() else None
    except Exception as exc:
        logger.warning("Category hint unavailable: %s", exc)
        return None


def _title_keys(corpus: Dict[str, Any]):
    cache = corpus["cache"]
    if "_title_keys" not in cache:
        keys = [title_key(str(t)) for t in corpus["dataframe"].get("title", pd.Series(dtype=str)).fillna("")]
        cache["_title_keys"] = keys
        cache["_title_key_counts"] = Counter(k for k in keys if k)
    return cache["_title_keys"], cache["_title_key_counts"]


# ---------------------------------------------------------------------------
# Keyword highlighting helper
# ---------------------------------------------------------------------------
_HIGHLIGHT_SKIP = frozenset("""the and for with from that this was are has have not but you your our
its via all any can per via into onto out off new get got been will would could should""".split())


def _highlight_keywords(text: str, query_terms: List[str], max_len: int = 200) -> str:
    if not text:
        return ""
    snippet = text[:max_len] + ("..." if len(text) > max_len else "")
    # Escape BEFORE adding <mark> tags: the result is rendered as raw HTML in
    # the browser, so corpus text (uploaded ServiceNow exports) must never be
    # able to carry live markup. Terms are escaped the same way so they still
    # match inside the escaped snippet.
    snippet = html.escape(snippet)
    for term in sorted(set(query_terms), key=len, reverse=True):
        if len(term) < 3 or term.lower() in _HIGHLIGHT_SKIP:
            continue
        pattern = re.compile(rf"\b({re.escape(html.escape(term))})\b", re.I)
        snippet = pattern.sub(r"<mark>\1</mark>", snippet)
    return snippet


def _band(pct: float) -> str:
    return "high" if pct >= BAND_HIGH else "medium" if pct >= BAND_MEDIUM else "low"


# ===========================================================================
# Core search over one source
# ===========================================================================
def _search_source(source: str, description: str, *, category_filter=None, priority_filter=None,
                   group_filter=None, resolved_since=None, ci_hint=None,
                   top_n: int = config.TOP_N_SIMILAR, collapse: bool = True) -> Dict[str, Any]:
    corpus = load_corpus(source)
    label = SOURCES[source]["plural"]
    if corpus is None:
        return {"matches": [], "evidence": [], "status": "no_models", "source": source,
                "message": f"No {label} history is available. A ServiceNow group member "
                           f"can import records above."}

    df = corpus["dataframe"]
    allowed = np.ones(len(df), dtype=bool)
    for column, value in (("category", category_filter), ("priority", priority_filter),
                          ("assignment_group", group_filter)):
        if value and value.strip():
            if column not in df:
                allowed[:] = False
                break
            allowed &= df[column].fillna("").astype(str).str.casefold().eq(value.strip().casefold()).to_numpy()
    if resolved_since:
        cutoff = pd.to_datetime(resolved_since, errors="coerce", utc=True)
        if pd.isna(cutoff):
            return {"matches": [], "evidence": [], "status": "no_results", "source": source,
                    "message": "Invalid resolved-since date."}
        stamps = pd.to_datetime(df.get("resolved_timestamp"), errors="coerce", utc=True)
        allowed &= pd.Series(stamps, index=df.index).ge(cutoff).fillna(False).to_numpy()
    if not allowed.any():
        return {"matches": [], "evidence": [], "status": "no_results", "source": source,
                "message": f"No {label} match the chosen filters."}

    boost = None
    if ci_hint and ci_hint.strip() and "configuration_item" in df:
        boost = df["configuration_item"].fillna("").astype(str).str.casefold() \
                  .str.contains(ci_hint.strip().casefold(), regex=False).to_numpy()

    vec = corpus["vectorizer"]
    titles = df["title"].fillna("").astype(str).tolist() if "title" in df else None
    title_vectors = corpus["title_vectors"]
    if title_vectors is None or title_vectors.shape[0] != len(df):
        title_vectors = cached_title_vectors(corpus["cache"], vec, titles)
    # Exact-code search runs on the raw (not vocabulary-normalised) text.
    texts = df["text"].fillna("").astype(str).tolist() if "text" in df else titles

    result = rank_detailed(
        description, vec, corpus["vectors"], semantic=corpus["semantic"], bm25=corpus["bm25"],
        encoder=_get_embedding_model() if corpus["semantic"] is not None else None,
        allowed=allowed, lexical_floor=_INCIDENT_SIM_FLOOR, title_vectors=title_vectors,
        texts=texts, boost=boost, char=corpus.get("char"),
        normalised=corpus.get("normalised", False),
        hint=_model_hint(description, df) if source == "incident" else None)

    fused, strength = result["fused"], result["strength"]
    order = [int(i) for i in np.argsort(-fused, kind="stable") if fused[i] > 0]
    tentative = result.get("tentative") or []
    if not order and not tentative:
        return {"matches": [], "evidence": [], "status": "no_results", "source": source,
                "total_searched": int(allowed.sum()),
                "message": f"No sufficiently similar {label} found."}

    keys, key_counts = _title_keys(corpus)
    query_terms = re.findall(r"\w{3,}", description.lower())

    def build(i: int) -> Dict[str, Any]:
        row = df.iloc[i]

        def value(column):
            return clean_value(row.get(column)) if column in df else ""

        notes = value("close_notes") or value("root_cause_notes")
        quality, steps = assess_resolution(notes)
        possible = strength[i] <= 0
        pct = round(float(result["tentative_score"][i] if possible else strength[i]) * 100, 1)
        hours = row.get("resolution_hours") if "resolution_hours" in df else None
        breakdown = {
            "text": round(float(result["lexical"][i]) * 100, 1),
            "title": round(float(result["title"][i]) * 100, 1),
            "keywords": round(float(result["keywords"][i]) * 100, 1),
            "exact_code": bool(result["code_hits"][i]),
        }
        if result["semantic"] is not None:
            breakdown["semantic"] = round(float(result["semantic"][i]) * 100, 1)
        if result["fuzzy"] is not None:
            breakdown["spelling"] = round(float(result["fuzzy"][i]) * 100, 1)
        return {
            "incident_id": value("incident_id"),
            "record_type": SOURCES[source]["label"],
            "source": source,
            "title": value("title"),
            "title_highlighted": _highlight_keywords(value("title"), query_terms, 300),
            "description_snippet": _highlight_keywords(value("description_full"), query_terms, 400),
            "category": value("category"),
            "subcategory": value("subcategory"),
            "catalog_item": value("catalog_item"),
            "priority": value("priority"),
            "assignment_group": value("assignment_group"),
            "configuration_item": value("configuration_item"),
            "resolved_date": value("resolved_timestamp")[:19],
            "resolution_hours": (round(float(hours), 1)
                                 if hours is not None and pd.notna(hours) else None),
            "root_cause": value("root_cause_notes") or value("root_cause_code"),
            "close_code": value("close_code"),
            "resolution_notes": notes[:1500],
            "resolution_steps": steps,
            "resolution_quality": quality,
            "similarity_score": pct,
            "match_score": pct,
            "text_similarity": breakdown["text"],
            "match_breakdown": breakdown,
            "match_signals": result["signals"][i],
            "similarity_band": _band(pct),
            "occurrences": int(key_counts.get(keys[i], 1)) if keys[i] else 1,
            "related": [],
            "work_notes": value("work_notes")[:1000],
            "tentative": bool(possible),
            "_weight": float(strength[i]),
        }

    # Evidence: the strongest uncollapsed candidates, for voting / insights.
    evidence = [build(i) for i in order[:12] if strength[i] >= EVIDENCE_FLOOR]

    matches: List[Dict[str, Any]] = []
    if collapse:
        groups: Dict[str, List[int]] = {}
        ordered_keys: List[str] = []
        for i in order[: max(top_n * 6, 30)]:
            key = keys[i] or f"__row{i}"
            if key not in groups:
                groups[key] = []
                ordered_keys.append(key)
            groups[key].append(i)
        for key in ordered_keys[:top_n]:
            members = groups[key]
            cards = [build(i) for i in members[:6]]
            lead = cards[0]
            # Prefer the member whose note actually explains the fix, as long
            # as it is nearly as relevant as the best-ranked one.
            rank_q = {"useful": 2, "thin": 1, "none": 0}
            better = max(cards, key=lambda c: (rank_q[c["resolution_quality"]], c["match_score"]))
            if (rank_q[better["resolution_quality"]] > rank_q[lead["resolution_quality"]]
                    and better["match_score"] >= lead["match_score"] - 10):
                better = dict(better, match_score=lead["match_score"], similarity_score=lead["similarity_score"],
                              similarity_band=lead["similarity_band"])
                lead = better
            lead["related"] = [{"id": c["incident_id"], "resolved_date": c["resolved_date"]}
                               for c in cards if c["incident_id"] != lead["incident_id"]]
            matches.append(lead)
    else:
        matches = [build(i) for i in order[:top_n]]

    # Fewer confident matches than asked for: offer tickets that share at
    # least one word as POSSIBLE matches, after the confident ones. They are
    # labelled, capped at a weak score and never used as evidence.
    for i in tentative[: max(0, top_n - len(matches))]:
        card = build(int(i))
        card["match_signals"] = ["Possible"]
        card["similarity_band"] = "low"
        matches.append(card)

    return {"matches": matches, "evidence": evidence, "status": "ok", "source": source,
            "total_searched": int(allowed.sum()), "codes": result["codes"]}


def compute_insights(evidence: Sequence[Dict[str, Any]], matches: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    """Support-facing summary of what the similar tickets say."""
    if not evidence:
        return {"available": False}
    weights = [m["_weight"] ** 2 for m in evidence]
    groups = weighted_vote((m["assignment_group"], w) for m, w in zip(evidence, weights))
    categories = weighted_vote((m["category"], w) for m, w in zip(evidence, weights))
    hours = [m["resolution_hours"] for m in evidence]
    p50 = weighted_percentile(hours, weights, 0.5)
    p80 = weighted_percentile(hours, weights, 0.8)
    top = matches[0] if matches else evidence[0]
    useful = sum(1 for m in evidence if m["resolution_quality"] == "useful")
    return {
        "available": True,
        "evidence_count": len(evidence),
        "suggested_group": ({"name": groups[0][0], "share": round(groups[0][1] * 100)}
                            if groups else None),
        "groups": [{"name": k, "share": round(v * 100)} for k, v in groups[:4]],
        "top_category": categories[0][0] if categories else "",
        "median_resolution_hours": round(p50, 1) if p50 is not None else None,
        "p80_resolution_hours": round(p80, 1) if p80 is not None else None,
        "useful_resolutions": useful,
        "recurring": top["occurrences"] >= RECURRING_THRESHOLD,
        "occurrences": top["occurrences"],
        "recurring_title": top["title"],
        "sources": sorted({m["record_type"] for m in evidence}),
    }


def _strip_private(items):
    for m in items:
        m.pop("_weight", None)
    return items


# ===========================================================================
# Public entry points
# ===========================================================================
def find_similar(description: str,
                 category_filter: Optional[str] = None,
                 priority_filter: Optional[str] = None,
                 top_n: int = config.TOP_N_SIMILAR,
                 group_filter: Optional[str] = None,
                 resolved_since: Optional[str] = None,
                 source: str = "incident",
                 ci_hint: Optional[str] = None,
                 collapse: bool = True,
                 keep_evidence: bool = False) -> Dict[str, Any]:
    """Top-N similar resolved tickets from one source or both.

    source: "incident", "sr" or "all". The original positional signature is
    unchanged, so existing callers keep working.
    """
    if not description or not description.strip():
        return {"matches": [], "status": "no_query"}
    top_n = max(1, min(int(top_n), 20))
    sources = ["incident", "sr"] if source == "all" else [source if source in SOURCES else "incident"]

    runs = [_search_source(s, description, category_filter=category_filter,
                           priority_filter=priority_filter, group_filter=group_filter,
                           resolved_since=resolved_since, ci_hint=ci_hint, top_n=top_n,
                           collapse=collapse) for s in sources]
    ok = [r for r in runs if r["status"] == "ok"]
    if not ok:
        # Prefer a "no results" explanation over "no history" when both ran.
        pick = next((r for r in runs if r["status"] == "no_results"), runs[0])
        return {"matches": [], "status": pick["status"], "message": pick.get("message", ""),
                "source": source, "sources_available": [], "insights": {"available": False}}

    # Exact identifier matches first (see retrieval), then by strength.
    # Confident before possible; exact identifier matches first; then strength.
    matches = sorted((m for r in ok for m in r["matches"]
                      if m["tentative"] or m["match_score"] >= DISPLAY_FLOOR),
                     key=lambda m: (m["tentative"], not m["match_breakdown"]["exact_code"],
                                    -m["match_score"]))[:top_n]
    if not matches:
        return {"matches": [], "status": "no_results", "source": source,
                "message": "Only weak matches were found. Add the error text, application or CI, "
                           "or search both record types.",
                "sources_available": [r["source"] for r in ok], "insights": {"available": False}}
    evidence = sorted((m for r in ok for m in r["evidence"]), key=lambda m: -m["match_score"])[:12]
    insights = compute_insights(evidence, matches)
    out = {
        "matches": matches, "status": "ok", "source": source,
        "total_searched": sum(r.get("total_searched", 0) for r in runs),
        "searched_by_source": {r["source"]: r.get("total_searched", 0) for r in runs},
        "sources_available": [r["source"] for r in ok],
        "sources_missing": [r["source"] for r in runs if r["status"] == "no_models"],
        "codes": sorted({c for r in ok for c in r.get("codes", [])}),
        "confident_count": sum(1 for m in matches if not m["tentative"]),
        "insights": insights,
    }
    if keep_evidence:
        out["evidence"] = evidence
    else:
        _strip_private(evidence)
    _strip_private(matches)
    return out


# ===========================================================================
# Problem search
# ===========================================================================
_PROBLEM_SIMILARITY_LIKELY = 50.0
_PROBLEM_SIMILARITY_NOTABLE = 25.0


def find_related_problems(description: str,
                          category_filter: Optional[str] = None,
                          ci_filter: Optional[str] = None,
                          top_n: int = 3) -> Dict[str, Any]:
    """Search the Problem corpus for tickets related to the query."""
    if not description or not description.strip():
        return {"matches": [], "status": "no_query"}

    vec, corpus_vectors, df = _load_problem_artefacts()
    if vec is None:
        return {"matches": [], "status": "no_models",
                "message": "Problem corpus not trained yet - "
                           "run problem_train.py to enable this section."}

    allowed = np.ones(len(df), dtype=bool)
    if category_filter and category_filter.strip() and "category" in df:
        allowed &= df["category"].astype(str).str.casefold().eq(category_filter.strip().casefold()).to_numpy()
    if ci_filter and ci_filter.strip() and "configuration_item" in df:
        allowed &= df["configuration_item"].astype(str).str.casefold().str.contains(ci_filter.strip().casefold(), regex=False, na=False).to_numpy()
    if not allowed.any():
        return {"matches": [], "status": "no_results",
                "message": "No problems match the chosen filters."}

    n_docs = len(df)
    semantic = load_sem_vectors("problem", config.MODELS_DIR)
    hybrid, strength, _, _ = rank(description, vec, corpus_vectors,
        semantic=semantic, bm25=load_bm25_index("problem", config.MODELS_DIR),
        encoder=_get_embedding_model() if semantic is not None else None,
        allowed=allowed, lexical_floor=_PROBLEM_SIM_FLOOR)
    candidate_idx = [int(i) for i in hybrid.argsort()[::-1][:min(n_docs, top_n * 3)] if hybrid[i] > 0]
    final_idx = candidate_idx[:top_n]

    query_terms = re.findall(r"\w{3,}", description.lower())
    matches: List[Dict[str, Any]] = []
    best_band: Optional[str] = None

    for i in final_idx:
        row = df.iloc[int(i)]
        sim_pct = round(float(strength[int(i)]) * 100, 1)
        if sim_pct >= _PROBLEM_SIMILARITY_LIKELY:
            band = "likely"
        elif sim_pct >= _PROBLEM_SIMILARITY_NOTABLE:
            band = "possible"
        else:
            band = "weak"
        if best_band is None or _band_rank(band) > _band_rank(best_band):
            best_band = band

        matches.append({
            "problem_id": str(row.get("problem_id", "")),
            "title": str(row.get("title", "")),
            "title_highlighted": _highlight_keywords(str(row.get("title", "")), query_terms, 300),
            "description_snippet": _highlight_keywords(
                str(row.get("description_full", "")), query_terms, 350),
            "state": str(row.get("state", "")),
            "category": str(row.get("category", "Unknown")),
            "priority": str(row.get("priority", "")),
            "assignment_group": str(row.get("assignment_group", "")),
            "configuration_item": str(row.get("configuration_item", "")),
            "business_service": str(row.get("business_service", "")),
            "workaround": clean_value(row.get("workaround", "")),
            "cause_notes": clean_value(row.get("cause_notes", "")),
            "is_known_error": bool(row.get("known_error", False)),
            "is_major_problem": bool(row.get("major_problem", False)),
            "rfc": str(row.get("rfc", "")),
            "opened_at": str(row.get("opened_timestamp", "")),
            "similarity_score": sim_pct,
            "similarity_band": band,
        })

    if not matches:
        return {"matches": [], "status": "no_results",
                "message": "No related problems found.", "best_band": None}

    return {"matches": matches, "status": "ok",
            "total_searched": n_docs, "best_band": best_band}


def _band_rank(band: str) -> int:
    return {"likely": 3, "possible": 2, "weak": 1}.get(band, 0)


def find_similar_with_problems(description: str,
                               category_filter: Optional[str] = None,
                               priority_filter: Optional[str] = None,
                               top_n: int = config.TOP_N_SIMILAR,
                               problem_top_n: int = 3) -> Dict[str, Any]:
    incidents = find_similar(description=description, category_filter=category_filter,
                             priority_filter=priority_filter, top_n=top_n)
    problems = find_related_problems(description=description, category_filter=category_filter,
                                     top_n=problem_top_n)
    return {"incidents": incidents, "problems": problems}


# ===========================================================================
# Recommendation synthesiser
# ===========================================================================
def synthesize_recommendation(matches: List[Dict]) -> Dict[str, Any]:
    """Merge the fixes of the matched tickets into one ranked set of steps.

    Steps are weighted by match score and ranked by how many DIFFERENT
    tickets contain them, so a step three similar tickets agree on outranks a
    long list from a single ticket. Confidence reflects both the strength of
    the best match and that agreement - not the average score, which a long
    tail of weak matches used to drag down (or a single strong one inflate).
    """
    if not matches:
        return {"recommended_steps": [], "steps": [], "likely_root_cause": "",
                "confidence": "low", "based_on": 0, "average_similarity": 0.0,
                "confidence_reason": "No matches to learn from."}

    def score(m):
        return float(m.get("match_score", m.get("similarity_score", 0)) or 0)

    sources = []
    for m in matches:
        steps = m.get("resolution_steps") or []
        if steps:
            sources.append((m.get("incident_id") or m.get("id") or str(len(sources)),
                            max(score(m), 1.0) / 100.0, steps))
    steps = consensus_steps(sources, limit=8)

    causes = weighted_vote((m.get("root_cause", ""), score(m)) for m in matches)
    likely_cause = causes[0][0] if causes else ""

    best = max(score(m) for m in matches)
    agreed = steps[0]["support"] if steps else 0
    with_fix = len(sources)
    if best >= BAND_HIGH and (agreed >= 2 or with_fix >= 1):
        confidence = "high" if agreed >= 2 or best >= 80 else "medium"
    elif best >= BAND_MEDIUM and with_fix:
        confidence = "medium"
    else:
        confidence = "low"
    reason = (f"Best match {best:.0f}%; "
              + (f"top step confirmed by {agreed} tickets" if agreed >= 2
                 else "steps come from a single ticket" if with_fix else "no usable resolution notes")
              + f"; {with_fix} of {len(matches)} matches record a fix.")

    return {
        "recommended_steps": [s["text"] for s in steps],
        "steps": steps,
        "likely_root_cause": likely_cause,
        "confidence": confidence,
        "confidence_reason": reason,
        "average_similarity": round(sum(score(m) for m in matches) / len(matches), 1),
        "best_similarity": round(best, 1),
        "based_on": len(matches),
        "with_resolution": with_fix,
    }
