"""Versioned retrieval snapshots, independent of supervised prediction models.

Each export is a set of complete records from one ServiceNow instance. Ticket
numbers are the legacy-compatible key; sys_updated_on prevents stale replays.
Only the small CURRENT file is replaced after all snapshot files are written.

Three kinds of history are kept, each with its own snapshot chain:

    incident  resolved incidents            (Similar search, Incident template)
    sr        fulfilled service requests    (Similar search, Request template)
    cr        successful change requests    (CR template), plus an index of
              FAILED / backed-out changes so the CR page can warn when a
              similar change has gone wrong before.

Accuracy rules applied when a snapshot is built:

  * Blank categorical fields stay "Unknown". The shared preprocess() fills a
    blank group / category / CI with the column MODE, which suits aggregate
    reporting but fabricates metadata on an individual record - and those
    fields are shown to engineers, used as filters and voted on by the
    template generators.
  * A blank priority stays blank instead of becoming P3.
  * Cancelled, duplicate, withdrawn and "not solved" incidents are kept in
    history but never searchable: they hold no fix to reuse. (preprocess()
    maps "Cancelled" to "Closed", so the raw state and close code are kept
    alongside as state_detail / close_code for this test.)
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from contextlib import contextmanager
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from uuid import uuid4

import joblib
import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer

from .. import config
from .dates import parse_dates
from .embedding_utils import build_bm25, encode_texts, get_encoder, encoder_revision
from .retrieval import build_char_index
from .textnorm import TEXT_NORM_VERSION, normalise_all


KINDS = ("incident", "sr", "cr")
KEYS = {"incident": "incident_id", "sr": "incident_id", "cr": "change_id"}

# Raw fields carried through untouched (the column mappers do not map them).
_EXTRA_FIELDS = {"state_detail": ("state",), "close_code": ("close_code", "u_tenant_close_code"),
                 "catalog_item": ("cat_item", "item")}
_NOT_A_FIX_RE = re.compile(r"cancel|duplicate|not\s+solved|withdrawn|rejected|invalid|"
                           r"no\s+longer\s+required|raised\s+in\s+error", re.I)
_SR_DONE_RE = re.compile(r"^(?:closed\s*complete|complete|completed|closed|resolved|fulfilled|delivered)\b", re.I)
_SR_NOT_DONE_RE = re.compile(r"incomplete|skipped|cancel|reject|withdrawn", re.I)


def _root(kind):
    if kind not in KINDS:
        raise ValueError("Unknown history type")
    return config.DATA_DIR / "knowledge" / kind


def snapshot_dir(kind):
    root = _root(kind)
    pointer = root / "CURRENT"
    if not pointer.exists():
        return None
    version = pointer.read_text(encoding="ascii").strip()
    if len(version) != 32 or any(c not in "0123456789abcdef" for c in version):
        raise ValueError("Invalid history version")
    return root / version


@lru_cache(maxsize=4)
def _read_snapshot(path):
    return joblib.load(Path(path) / "retrieval.pkl")


def load_snapshot(kind):
    path = snapshot_dir(kind)
    return _read_snapshot(str(path)) if path else None


def history_status(kind):
    path = snapshot_dir(kind)
    if path:
        return json.loads((path / "metadata.json").read_text(encoding="utf-8"))
    legacy_name = {"incident": "corpus_dataframe_latest.pkl",
                   "cr": "cr_corpus_dataframe_latest.pkl"}.get(kind)
    source = ("Legacy model corpus" if legacy_name and (config.MODELS_DIR / legacy_name).exists()
              else "No records available")
    return {"records": None, "searchable": None, "updated_at": None,
            "source": source, "version": None}


@contextmanager
def _writer(kind):
    root = _root(kind)
    root.mkdir(parents=True, exist_ok=True)
    lock = root / "UPDATE.lock"
    try:
        fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        raise ValueError("An update is already running. Try again after it finishes.")
    os.close(fd)
    try:
        yield root
    finally:
        lock.unlink()


def _legacy_history(kind):
    if kind == "sr":
        return pd.DataFrame(), "Imported exports"
    if kind == "incident" and config.MASTER_TRAINING_CSV.exists():
        frame = pd.read_csv(config.MASTER_TRAINING_CSV, low_memory=False)
        return frame, "Migrated incident master"
    name = "corpus_dataframe_latest.pkl" if kind == "incident" else "cr_corpus_dataframe_latest.pkl"
    path = config.MODELS_DIR / name
    if path.exists():
        frame = joblib.load(path).copy()
        # Old CR corpora discarded state and text. Preserve their records but
        # require a current export before using their plans as successful CRs.
        if "text" not in frame:
            frame["text"] = frame["title"].fillna("").astype(str)
        return frame, "Migrated retrieval corpus (partial history)"
    return pd.DataFrame(), "Imported exports"


def _merge(existing, incoming, key):
    frames = [f for f in (existing, incoming) if len(f)]
    merged = pd.concat(frames, ignore_index=True, sort=False)
    if key not in merged or merged[key].isna().any():
        raise ValueError("History contains records without a ticket number")
    merged[key] = merged[key].astype(str).str.strip()
    if merged[key].isin(["", "nan", "None"]).any():
        raise ValueError("History contains blank ticket numbers")
    merged["updated_timestamp"] = pd.to_datetime(merged.get("updated_timestamp"), errors="coerce", utc=True)
    # An old row with an unknown timestamp must not override a dated export.
    merged = merged.sort_values("updated_timestamp", kind="stable", na_position="first")
    return merged.drop_duplicates(key, keep="last").reset_index(drop=True)


def _model_revision(path):
    return encoder_revision(path)


def compatible_semantic(snapshot):
    """A changed encoder requires reindexing, even if vector dimensions match."""
    if snapshot.get("encoder_revision") != _model_revision(getattr(config, "EMBEDDING_MODEL_PATH", None)):
        return None
    return snapshot["semantic"]


def _embeddings(texts, old):
    path = getattr(config, "EMBEDDING_MODEL_PATH", None)
    revision = _model_revision(path)
    keys = [hashlib.sha256(t.encode("utf-8")).hexdigest() for t in texts]
    cache = {}
    if old and revision and old.get("encoder_revision") == revision and old.get("semantic") is not None:
        cache = dict(zip(old["text_hashes"], old["semantic"]))
    missing = dict((key, text) for key, text in zip(keys, texts) if key not in cache)
    if missing:
        encoded = encode_texts(list(missing.values()), get_encoder(path))
        if encoded is None:
            return None, keys, revision, 0, 0
        cache.update(zip(missing, encoded))
    if not texts:
        return None, keys, revision, 0, 0
    return np.asarray([cache[key] for key in keys], dtype=np.float32), keys, revision, len(texts) - sum(key in missing for key in keys), len(missing)


def _no_impute_fills(kind="incident"):
    """Fill values that leave blanks as "Unknown" instead of the column mode."""
    if kind == "cr":
        from .change_preprocess import CATEGORICAL_COLUMNS
    else:
        from .preprocess import CATEGORICAL_COLUMNS
    return {column: "Unknown" for column in CATEGORICAL_COLUMNS}


def _is_fix_record(frame):
    """False for incidents / requests that were closed without a real fix."""
    blank = pd.Series("", index=frame.index)
    detail = (frame["state_detail"] if "state_detail" in frame else blank).fillna("").astype(str)
    code = (frame["close_code"] if "close_code" in frame else blank).fillna("").astype(str)
    return ~(detail.str.contains(_NOT_A_FIX_RE) | code.str.contains(_NOT_A_FIX_RE))


def searchable_records(kind, history):
    """The subset of history that may be offered as a precedent."""
    from .preprocess import filter_system_tickets, get_resolved_tickets
    from .change_preprocess import is_successful_change
    if not len(history):
        return history
    if kind == "cr":
        return history.loc[history.apply(is_successful_change, axis=1)]
    if kind == "sr":
        people = filter_system_tickets(history)
        state = people["state"].fillna("").astype(str)
        detail = (people["state_detail"].fillna(state) if "state_detail" in people else state)
        detail = detail.astype(str).str.strip()
        done = detail.str.contains(_SR_DONE_RE) & ~detail.str.contains(_SR_NOT_DONE_RE)
        return people.loc[done & _is_fix_record(people)]
    resolved = get_resolved_tickets(filter_system_tickets(history))
    return resolved.loc[_is_fix_record(resolved)]


def _failure_index(history, vectorizer):
    """Changes that failed, were backed out or cancelled - for risk warnings."""
    from .change_preprocess import _FAILURE_NOTES_RE, _FAILURE_STATE_RE
    if not len(history):
        return None
    blank = pd.Series("", index=history.index)
    state = (history["state"] if "state" in history else blank).fillna("").astype(str)
    code = (history["close_code"] if "close_code" in history else blank).fillna("").astype(str)
    notes = (history["close_notes"] if "close_notes" in history else blank).fillna("").astype(str)
    failed = (state.str.contains(_FAILURE_STATE_RE) | code.str.contains(_FAILURE_STATE_RE)
              | notes.str.contains(_FAILURE_NOTES_RE))
    frame = history.loc[failed].reset_index(drop=True)
    if frame.empty or "text" not in frame:
        return None
    texts = normalise_all(frame["text"].fillna("").astype(str))
    return {"dataframe": frame, "vectors": vectorizer.transform(texts)}


def _invalid_rows(raw, timestamps):
    """Rows the history cannot key or date, by reason, with readable examples.

    Examples name the spreadsheet row (header = row 1) and the ticket number,
    so the bad rows can be found in the export without a script.
    """
    number = raw["number"].fillna("").astype(str).str.strip()
    title = raw["short_description"].fillna("").astype(str).str.strip()
    checks = {"blank number": number.eq(""),
              "blank short_description": title.eq(""),
              "unreadable sys_updated_on": timestamps.isna()}
    bad = pd.Series(False, index=raw.index)
    details = []
    for reason, mask in checks.items():
        if mask.any():
            bad |= mask
            examples = ", ".join(f"row {i + 2} ({number[i] or 'no number'})"
                                 for i in mask[mask].index[:5])
            details.append(f"{int(mask.sum())} with {reason} (e.g. {examples})")
    return bad, details


def update_history(kind, input_path, skip_invalid=False):
    from .preprocess import load_export, preprocess
    from .change_preprocess import preprocess as preprocess_changes
    from ..service_request import apply_sr_fallbacks, normalise_display_export

    with _writer(kind) as root:
        raw = load_export(input_path, strict=True)
        # Excel exports carry display headers ("Number", "Updated"); map them
        # onto field names exactly as the summary uploads do.
        if Path(str(input_path)).suffix.lower() in (".xlsx", ".xls"):
            raw = normalise_display_export(raw)
        if kind == "sr":
            raw = apply_sr_fallbacks(raw)
        required = {"number", "short_description", "state", "sys_updated_on"}
        missing = required - set(raw.columns)
        if missing:
            raise ValueError("Export is missing fields: " + ", ".join(sorted(missing)))
        if raw.empty:
            raise ValueError("The export contains no records")
        timestamps = parse_dates(raw["sys_updated_on"], required=True,
                                 name="sys_updated_on").dt.tz_localize("UTC")
        bad, problems = _invalid_rows(raw, timestamps)
        skipped = int(bad.sum())
        if skipped and not skip_invalid:
            raise ValueError("Every record needs a ticket number, description and valid "
                             "sys_updated_on: " + "; ".join(problems) +
                             ". Fix the export, or rerun with --skip-invalid to leave these rows out.")
        if skipped:
            raw, timestamps = raw.loc[~bad], timestamps.loc[~bad]
            if raw.empty:
                raise ValueError("No valid records left after skipping: " + "; ".join(problems))
        raw = raw.assign(_updated=timestamps).sort_values("_updated", kind="stable").drop_duplicates("number", keep="last")
        if kind == "cr":
            incoming = preprocess_changes(raw, fill_values=_no_impute_fills("cr"))
        else:
            incoming = preprocess(raw, fill_values=_no_impute_fills())
            if "priority_present" in incoming:
                incoming["priority"] = incoming["priority"].where(incoming["priority_present"], "")
        if len(incoming) != len(raw):
            raise ValueError("Some export records could not be normalized; history was not changed")
        incoming["updated_timestamp"] = pd.to_datetime(incoming["updated_timestamp"], errors="coerce", utc=True)
        # Use the validated raw timestamps: preprocessors may assume local date formats.
        key = KEYS[kind]
        numbers = raw["number"].astype(str)
        stamp_by_id = dict(zip(numbers, raw["_updated"]))
        incoming["updated_timestamp"] = incoming[key].map(stamp_by_id)
        extra_present = {}
        for field, candidates in _EXTRA_FIELDS.items():
            source_column = next((c for c in candidates if c in raw), None)
            extra_present[field] = source_column is not None
            if source_column is not None and field not in incoming:
                incoming[field] = incoming[key].map(dict(zip(numbers, raw[source_column])))
        old_path = snapshot_dir(kind)
        old = load_snapshot(kind)
        if old_path:
            existing = joblib.load(old_path / "history.pkl")
            source = history_status(kind)["source"]
        else:
            existing, source = _legacy_history(kind)
        # A reduced export must not erase plans/notes omitted from its columns.
        if len(existing):
            if key not in existing:
                raise ValueError("Stored history is missing its ticket-number column; restore it before importing")
            from .column_mapper import COLUMN_MAPPING as incident_mapping
            from .change_column_mapper import COLUMN_MAPPING as change_mapping
            mapping = dict(incident_mapping if kind != "cr" else change_mapping)
            mapping.update({field: list(candidates) for field, candidates in _EXTRA_FIELDS.items()
                            if not extra_present.get(field)})
            previous = existing.drop_duplicates(key, keep="last").set_index(key)
            for field, candidates in mapping.items():
                if field in previous and not any(column in raw for column in candidates):
                    known = incoming[key].isin(previous.index)
                    if known.any():
                        if field not in incoming:
                            incoming[field] = None
                        incoming[field] = incoming[field].astype(object)
                        incoming.loc[known, field] = incoming.loc[known, key].map(previous[field])
        history = _merge(existing, incoming, key)
        if "description_full" in history:
            history["text"] = (history["title"].fillna("").astype(str) + " " +
                               history["description_full"].fillna("").astype(str)).str.strip().str.replace(r"\s+", " ", regex=True)
        if kind != "cr":
            opened = pd.to_datetime(history.get("opened_timestamp"), errors="coerce", utc=True)
            resolved = pd.to_datetime(history.get("resolved_timestamp"), errors="coerce", utc=True)
            closed = pd.to_datetime(history.get("closed_timestamp"), errors="coerce", utc=True)
            history["resolution_hours"] = ((resolved.fillna(closed) - opened).dt.total_seconds() / 3600).clip(0, config.RESOLUTION_HOURS_CLIP)
        corpus = searchable_records(kind, history).copy().reset_index(drop=True)
        texts = corpus["text"].fillna("").astype(str).tolist()
        # Lexical indexes are built on vocabulary-normalised text ("sign in",
        # "log on" -> "login"); sentence embeddings keep the raw text.
        norm_texts = normalise_all(texts)
        vec = TfidfVectorizer(max_features=config.TFIDF_MAX_FEATURES,
                              ngram_range=(1, config.TFIDF_NGRAM_MAX), min_df=1,
                              stop_words="english", sublinear_tf=True, dtype=np.float32)
        # Empty eligible corpora are valid after tickets reopen or fail.
        try:
            matrix = vec.fit_transform(norm_texts)
        except ValueError as exc:
            if texts and "empty vocabulary" not in str(exc):
                raise
            vec.fit(["emptycorpusplaceholder"])
            matrix = vec.transform(norm_texts) if texts else csr_matrix((0, 1), dtype=np.float32)
        semantic, hashes, revision, reused, encoded = _embeddings(texts, old)
        snapshot = {"vectorizer": vec, "vectors": matrix, "dataframe": corpus,
                    "semantic": semantic, "bm25": build_bm25(norm_texts),
                    "text_hashes": hashes, "encoder_revision": revision,
                    "text_norm": TEXT_NORM_VERSION,
                    "title_vectors": (vec.transform(normalise_all(corpus["title"].fillna("").astype(str)))
                                      if len(corpus) else None),
                    "char": build_char_index(norm_texts),
                    "failures": _failure_index(history, vec) if kind == "cr" else None}
        version = uuid4().hex
        stage = root / version
        stage.mkdir()
        latest = history["updated_timestamp"].max()
        metadata = {"version": version, "kind": kind, "records": len(history), "searchable": len(corpus),
                    "updated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    "latest_record_update": latest.isoformat() if pd.notna(latest) else None,
                    "imported": len(incoming), "skipped_invalid": skipped,
                    "skipped_detail": problems if skipped else [],
                    "embeddings_reused": reused,
                    "embeddings_encoded": encoded, "source": source,
                    "semantic_available": semantic is not None,
                    "text_norm": TEXT_NORM_VERSION,
                    "failures_indexed": (len(snapshot["failures"]["dataframe"])
                                         if snapshot["failures"] else 0)}
        joblib.dump(history, stage / "history.pkl")
        joblib.dump(raw.drop(columns=["_updated"]), stage / "import.pkl")
        joblib.dump(snapshot, stage / "retrieval.pkl")
        (stage / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
        pointer = root / f"CURRENT.{version}.tmp"
        pointer.write_text(version, encoding="ascii")
        os.replace(pointer, root / "CURRENT")
        return metadata


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Merge a ServiceNow delta export into searchable history")
    parser.add_argument("--kind", choices=KINDS, required=True)
    parser.add_argument("--input", required=True)
    parser.add_argument("--skip-invalid", action="store_true",
                        help="Leave out rows with a blank number / short description or an "
                             "unreadable sys_updated_on instead of rejecting the export")
    args = parser.parse_args()
    print(json.dumps(update_history(args.kind, args.input, skip_invalid=args.skip_invalid), indent=2))
