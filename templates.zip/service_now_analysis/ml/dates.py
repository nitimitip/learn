"""
Auto-detecting date parser for ServiceNow exports.

``pd.to_datetime(col, errors="coerce")`` on its own guesses one format from the
first value; when that guess does not fit the column it falls back to parsing
every cell with dateutil, which is slow and reads slash dates MONTH-first. On a
UK ``dd/mm/yyyy`` export that turns 03/04/2026 into 4 March while 13/04/2026
stays 13 April - silently corrupting resolution times and temporal features.

``parse_dates`` instead scores a list of explicit formats against a sample of
the column and parses with the best one (then the next best for any rows a
mixed export left behind). Day-first and month-first slash formats compete on
the evidence: a single "13/04" rules month-first out. When the column cannot
tell them apart (every day <= 12) ``config.DATES_DAY_FIRST`` decides.

Columns are either required (the caller cannot work without them - a parse
failure is logged as a warning and a last-resort generic parse is tried) or
optional (unparseable values just become NaT, quietly).
"""
from __future__ import annotations

import logging
import warnings
from typing import List, Optional

import pandas as pd

from .. import config

logger = logging.getLogger(__name__)

_SAMPLE_SIZE = 2000

# Date parts, day-first variants listed before their month-first twins so a
# genuine tie resolves to day-first (re-ordered at runtime if the config says
# month-first).
_DAY_FIRST_DATES = ["%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d/%m/%y"]
_MONTH_FIRST_DATES = ["%m/%d/%Y", "%m-%d-%Y", "%m.%d.%Y", "%m/%d/%y"]
_UNAMBIGUOUS_DATES = ["%Y-%m-%d", "%Y/%m/%d", "%d-%b-%Y", "%d %b %Y", "%d-%b-%y",
                      "%d %B %Y", "%b %d, %Y"]
_TIMES = ["", " %H:%M:%S", " %H:%M", " %H:%M:%S.%f", "T%H:%M:%S", "T%H:%M:%S.%f",
          " %I:%M:%S %p", " %I:%M %p"]


def _candidate_formats() -> List[str]:
    if config.DATES_DAY_FIRST:
        dates = _UNAMBIGUOUS_DATES + _DAY_FIRST_DATES + _MONTH_FIRST_DATES
    else:
        dates = _UNAMBIGUOUS_DATES + _MONTH_FIRST_DATES + _DAY_FIRST_DATES
    return [d + t for d in dates for t in _TIMES]


def _clean(series: pd.Series) -> pd.Series:
    s = series.astype("object").where(series.notna(), None)
    s = s.map(lambda v: None if v is None else str(v).strip())
    return s.where(s.fillna("").ne("") & ~s.fillna("").str.lower().isin(["nan", "nat", "none"]), None)


def detect_formats(values: pd.Series) -> List[str]:
    """Formats that parse at least one sampled value, best match rate first.

    Python's sort is stable, so equal rates keep the candidate order - which is
    how the day-first / month-first tie-break works.
    """
    sample = pd.Series(values.dropna().unique()[:_SAMPLE_SIZE], dtype="object")
    if sample.empty:
        return []
    scored = []
    for fmt in _candidate_formats():
        rate = pd.to_datetime(sample, format=fmt, errors="coerce").notna().mean()
        if rate > 0:
            scored.append((fmt, rate))
    scored.sort(key=lambda item: -item[1])
    return [fmt for fmt, _ in scored]


def _generic_parse(values: pd.Series) -> pd.Series:
    """Last resort for required columns: pandas' own inference, quietly."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            out = pd.to_datetime(values, errors="coerce", dayfirst=config.DATES_DAY_FIRST)
        except (ValueError, TypeError):
            out = pd.Series(pd.NaT, index=values.index)
        if not pd.api.types.is_datetime64_any_dtype(out):
            out = pd.to_datetime(values, errors="coerce", utc=True,
                                 dayfirst=config.DATES_DAY_FIRST)
    if getattr(out.dt, "tz", None) is not None:
        out = out.dt.tz_convert(None)
    return out


def parse_dates(series: Optional[pd.Series], *, required: bool = False,
                name: str = "") -> Optional[pd.Series]:
    """Parse a timestamp column with an auto-detected format (naive datetime64).

    ``required=False``: values no detected format can read become NaT, silently.
    ``required=True``: those values get a last-resort generic parse, and any
    that still fail are logged as a warning with examples.
    """
    if series is None:
        return None
    if pd.api.types.is_datetime64_any_dtype(series):
        if getattr(series.dt, "tz", None) is not None:
            return series.dt.tz_convert(None)
        return series

    values = _clean(series)
    out = pd.Series(pd.NaT, index=series.index, dtype="datetime64[ns]")
    pending = values.notna()
    if not pending.any():
        return out

    formats = detect_formats(values[pending])
    for fmt in formats:
        parsed = pd.to_datetime(values[pending], format=fmt, errors="coerce")
        hit = parsed.notna()
        if hit.any():
            out.loc[hit[hit].index] = parsed[hit]
            pending.loc[hit[hit].index] = False
        if not pending.any():
            break
    if formats:
        logger.debug("Date column %s parsed with format %s", name or "?", formats[0])

    if pending.any() and required:
        rescued = _generic_parse(values[pending])
        hit = rescued.notna()
        out.loc[hit[hit].index] = rescued[hit]
        pending.loc[hit[hit].index] = False
        if pending.any():
            examples = values[pending].drop_duplicates().head(3).tolist()
            logger.warning("Date column %s: %d of %d values could not be parsed "
                           "(e.g. %s) - left blank", name or "?", int(pending.sum()),
                           int(values.notna().sum()), examples)
    return out
