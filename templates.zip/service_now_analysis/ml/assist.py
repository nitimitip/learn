"""Shared evidence helpers for the three support-assist features.

Similar Incidents, the Incident / Service Request template and the CR
template all turn a handful of historical tickets into advice. The rules for
doing that live here, once, so the three pages cannot disagree:

  * what counts as a usable resolution note (and what is boilerplate),
  * how a free-text note is broken into steps and how two steps are judged
    to be "the same step",
  * similarity-weighted voting over the fields of the matched tickets,
  * weighted percentiles for "how long did the similar ones take".

Nothing here imports scikit-learn; it is plain Python + numpy.
"""
from __future__ import annotations

import re
from collections import defaultdict
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

# ---------------------------------------------------------------------------
# Resolution notes
# ---------------------------------------------------------------------------
# Notes that record THAT a ticket closed, not HOW. They are the commonest
# close note in most instances and were previously offered as "steps".
_BOILERPLATE_RE = re.compile(
    r"^\W*(issue\s+)?(has\s+been\s+|is\s+)?("
    r"resolved|closed|fixed|done|completed?|working( now| fine)?|sorted|"
    r"no (further )?(response|reply|update)( from (the )?(user|caller))?|"
    r"user (has )?confirmed|confirmed by (the )?(user|caller)|as per (the )?(user|caller)|"
    r"closing( the)?( ticket| incident)?|auto[- ]?closed?|duplicate( of)?|"
    r"see (parent|related|inc|ritm|chg)|resolved by (the )?(caller|user)|"
    r"please (see|refer)|n/?a|na|none|test|ok"
    r")\b[\w\s.,:;'/-]{0,40}$", re.I)
_TICKET_ONLY_RE = re.compile(r"^\W*(inc|ritm|req|sctask|chg|prb|task)\d+\W*$", re.I)
_STEP_SPLIT_RE = re.compile(r"(?:[\r\n]+|(?:^|\s)\d{1,2}\s*[.)]\s+|(?:^|\s)[-*\N{BULLET}]\s+|;\s+)")
_ENUM_PREFIX_RE = re.compile(r"^\s*(?:(?:step\s*)?\d{1,2}\s*[.):-]|[a-z][.)]|[-*])\s+", re.I)
_SENTENCE_RE = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9])")
_NORMALISE_RE = re.compile(r"[^a-z0-9 ]+")
_FILLER = frozenset("""the a an to and or of in on at by it is are be this that these those we i
will shall should must do did done for with from into onto as via using use step all any please
now next first then finally was were has have had been user users issue ticket""".split())


def is_boilerplate(text: str) -> bool:
    text = (text or "").strip()
    return (not text or len(text) < 6 or bool(_BOILERPLATE_RE.match(text))
            or bool(_TICKET_ONLY_RE.match(text)))


def split_steps(text: str, max_steps: int = 10) -> List[str]:
    """Break a resolution / plan note into discrete, non-boilerplate steps.

    Bulleted and numbered notes split on their markers; a single paragraph
    splits into sentences so a one-line close note still yields steps.
    """
    text = (text or "").strip()
    if not text:
        return []
    pieces = [p for p in _STEP_SPLIT_RE.split(text) if p and p.strip()]
    if len(pieces) <= 1:
        pieces = _SENTENCE_RE.split(text)
    steps: List[str] = []
    for piece in pieces:
        # Drop a leading enumerator the split left behind ("2. Restart").
        piece = _ENUM_PREFIX_RE.sub("", piece)
        piece = piece.strip(" \t-*.:;")
        words = piece.split()
        if len(words) < 2 or len(words) > 60 or is_boilerplate(piece):
            continue
        steps.append(piece)
        if len(steps) >= max_steps:
            break
    return steps


def assess_resolution(text: str) -> Tuple[str, List[str]]:
    """('useful' | 'thin' | 'none', steps) for one close note."""
    if not (text or "").strip():
        return "none", []
    steps = split_steps(text)
    if not steps:
        return "thin", []
    words = sum(len(s.split()) for s in steps)
    return ("useful" if words >= 6 else "thin"), steps


def _stem(word: str) -> str:
    for suffix in ("ing", "ed", "es", "s"):
        if len(word) >= 4 + len(suffix) and word.endswith(suffix):
            return word[: -len(suffix)]
    return word


def step_key(step: str) -> str:
    """Order-insensitive fingerprint used to decide two steps are the same.

    Hyphenated prefixes are folded (re-issued == reissued) and a light suffix
    strip makes restart / restarted / restarting one word.
    """
    s = re.sub(r"(?<=[a-z])-(?=[a-z])", "", (step or "").lower())
    s = _NORMALISE_RE.sub(" ", s)
    s = re.sub(r"\b\w*\d+\w*\b", " ", s)
    tokens = sorted({_stem(w) for w in s.split() if w not in _FILLER and len(w) > 2})
    return " ".join(tokens[:8])


def step_overlap(a: str, b: str) -> float:
    ta, tb = set(a.split()), set(b.split())
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / float(min(len(ta), len(tb)))


def consensus_steps(sources: Sequence[Tuple[str, float, List[str]]],
                    limit: int = 8) -> List[Dict[str, object]]:
    """Merge the steps of several tickets, strongest consensus first.

    `sources` is (ticket_id, weight, steps). Steps whose fingerprints overlap
    by >= 70% are one step; its support is the number of DISTINCT tickets
    that contain it and its weight the sum of their similarity weights. The
    wording kept is the most complete variant from the best-weighted ticket.
    """
    clusters: List[Dict[str, object]] = []
    for ticket, weight, steps in sources:
        for position, step in enumerate(steps):
            key = step_key(step)
            if not key:
                continue
            home = next((c for c in clusters if step_overlap(c["key"], key) >= 0.7), None)
            if home is None:
                home = {"key": key, "text": step, "best": -1.0, "tickets": {}, "order": []}
                clusters.append(home)
            if ticket not in home["tickets"]:
                home["tickets"][ticket] = weight
                home["order"].append(position)
            if weight > home["best"] or (weight == home["best"] and len(step) > len(home["text"])):
                home["best"], home["text"] = weight, step
    out = []
    for c in clusters:
        out.append({"text": c["text"], "support": len(c["tickets"]),
                    "weight": round(sum(c["tickets"].values()), 3),
                    "sources": list(c["tickets"].keys()),
                    "position": float(np.mean(c["order"])) if c["order"] else 0.0})
    # Consensus first, then evidence weight; ties keep the natural order in
    # which the steps were written.
    out.sort(key=lambda r: (-r["support"], -r["weight"], r["position"]))
    return out[:limit]


# ---------------------------------------------------------------------------
# Voting / statistics
# ---------------------------------------------------------------------------
_EMPTY = {"", "unknown", "nan", "none", "nat", "null", "-"}


def clean_value(value) -> str:
    if value is None:
        return ""
    try:
        if value != value:          # NaN
            return ""
    except Exception:
        pass
    text = str(value).strip()
    return "" if text.lower() in _EMPTY else text


def weighted_vote(pairs: Iterable[Tuple[object, float]]) -> List[Tuple[str, float]]:
    """[(label, share)] best first; blanks ignored; shares sum to 1."""
    totals: Dict[str, float] = defaultdict(float)
    for value, weight in pairs:
        label = clean_value(value)
        if label and weight > 0:
            totals[label] += float(weight)
    grand = sum(totals.values())
    if grand <= 0:
        return []
    return sorted(((k, v / grand) for k, v in totals.items()), key=lambda kv: -kv[1])


def weighted_percentile(values: Sequence[float], weights: Sequence[float], q: float) -> Optional[float]:
    pairs = [(float(v), float(w)) for v, w in zip(values, weights)
             if v is not None and v == v and w > 0]
    if not pairs:
        return None
    pairs.sort()
    vals = np.array([p[0] for p in pairs])
    cum = np.cumsum([p[1] for p in pairs])
    cutoff = q * cum[-1]
    return float(vals[int(np.searchsorted(cum, cutoff))])


def ensemble(model: Optional[Dict[str, float]], history: List[Tuple[str, float]],
             history_evidence: float) -> Tuple[List[Tuple[str, float]], str]:
    """Blend classifier probabilities with the similar-ticket vote.

    history_evidence (0..1) is how much the vote should be trusted - it grows
    with the number and strength of matched tickets. With no classifier the
    vote stands alone; with no history the classifier does. Returns
    ([(label, confidence)], source) best first.
    """
    model = {k: v for k, v in (model or {}).items() if clean_value(k) and k != "Other"}
    hist = dict(history)
    if not model and not hist:
        return [], "default"
    if not model:
        # Confidence of a pure vote is its share scaled by how much evidence
        # stands behind it - one weak match must not read as 100%.
        return [(k, v * history_evidence) for k, v in history], "history"
    if not hist:
        return sorted(model.items(), key=lambda kv: -kv[1]), "model"
    alpha = 0.5 * history_evidence + 0.2          # 0.2 .. 0.7 weight on history
    labels = set(model) | set(hist)
    blended = {k: (1 - alpha) * model.get(k, 0.0) + alpha * hist.get(k, 0.0) for k in labels}
    ranked = sorted(blended.items(), key=lambda kv: -kv[1])
    top_model = max(model, key=model.get)
    source = "model+history" if history and top_model == history[0][0] else "model|history"
    return ranked, source


def title_key(title: str) -> str:
    """Fingerprint for 'the same problem again' grouping (ids and numbers removed)."""
    s = (title or "").lower()
    s = re.sub(r"\b\w*\d\w*\b", " ", s)
    s = re.sub(r"[^a-z ]+", " ", s)
    return " ".join(s.split())[:80]
