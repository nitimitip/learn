"""
Incident / Service Request template generator.

Given a free-text description, propose the ServiceNow fields a support
engineer would otherwise pick by hand, and say how sure it is about each.

Evidence, in order of trust
---------------------------
1. Similar resolved tickets (incident and/or service-request history). Their
   fields are voted on, weighted by the square of the match score, so two
   strong matches outweigh five weak ones. This works from imported history
   alone - before any classifier has been trained - which the previous
   generator could not do (it returned "General / Service Desk / P3").
2. The trained classifiers (category, subcategory, routing, priority, ETA)
   where present. Their probabilities are blended with the vote
   (assist.ensemble); how much the vote counts grows with the evidence.
3. Rules, for the fields ServiceNow itself derives from rules: impact from
   scope, urgency from the stated business effect, and priority from the
   standard impact x urgency matrix.

Accuracy fixes vs the previous generator
----------------------------------------
* The priority model was trained on (text, ACTUAL assignment group,
  category) but was always fed the constant "Service Desk" at inference - a
  train/serve skew that biased every priority toward whatever Service Desk
  tickets usually were. It now receives the predicted group.
* The trained subcategory model was never called; subcategory was always
  blank.
* Scope "Organisation" (the value the form offers) had no impact mapping and
  fell through to "3 - Low".
* Priority ignored scope entirely: a company-wide outage could come out P4.
  Priority now follows the impact x urgency matrix, and the model/history
  priority is reported alongside so a disagreement is visible.
* ETA was a single regression number. It is now the weighted median and
  80th percentile of how long the similar tickets actually took, with the
  model as fallback.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .assist import clean_value, ensemble, weighted_percentile, weighted_vote

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Ticket type detection
# ---------------------------------------------------------------------------
_REQUEST_RE = re.compile(
    r"\b(request(ing|ed)?|need(s|ed)? (access|a|an|new|to be (added|given|granted))|"
    r"please (provide|grant|create|install|add|set ?up|enable|arrange|order|remove)|"
    r"new (user|laptop|account|starter|joiner|licen[cs]e|mailbox|phone)|access to|"
    r"grant(ed)?|onboard(ing)?|offboard(ing)?|provision(ing)?|order(ing)?|"
    r"install(ation)?|licen[cs]e|add (me|user|him|her|them) to|leaver|starter|"
    r"permission(s)? (for|to)|create (a |an )?(new )?(account|user|mailbox|group))\b", re.I)
_INCIDENT_RE = re.compile(
    r"\b(error|errors|fail(s|ed|ing|ure)?|down|outage|not working|isn'?t working|"
    r"cannot|can'?t|unable|crash(ed|es|ing)?|time[ds]? ?out|slow(ness)?|broken|"
    r"exception|stuck|hung|hang(s|ing)?|freez(e|es|ing)|unavailable|unreachable|"
    r"lost|missing|corrupt(ed)?|degraded|intermittent|disconnect(ed|s)?|denied|"
    r"invalid|expired|locked out)\b", re.I)


def detect_ticket_type(text: str) -> Tuple[str, str]:
    """('incident' | 'request', reason). Break-fix language wins ties."""
    req = len(_REQUEST_RE.findall(text or ""))
    inc = len(_INCIDENT_RE.findall(text or ""))
    if req > inc:
        return "request", "Worded as a request for something new (access, install, provision)."
    if inc:
        return "incident", "Describes something broken or degraded."
    return "incident", "No clear request wording; treated as an incident."


# ---------------------------------------------------------------------------
# Impact x urgency -> priority (ServiceNow default matrix, P5 folded into P4)
# ---------------------------------------------------------------------------
IMPACT_LABELS = {1: "1 - High", 2: "2 - Medium", 3: "3 - Low"}
URGENCY_LABELS = IMPACT_LABELS
_SCOPE_IMPACT = {"individual": 3, "team": 2, "department": 2, "multiple departments": 1,
                 "organisation": 1, "organization": 1, "company-wide": 1, "company wide": 1}
_PRIORITY_MATRIX = {(1, 1): "P1", (1, 2): "P2", (2, 1): "P2", (1, 3): "P3", (2, 2): "P3",
                    (3, 1): "P3", (2, 3): "P4", (3, 2): "P4", (3, 3): "P4"}
_URGENCY_WORDS = {
    1: re.compile(r"\b(outage|down|all users|everyone|entire|whole (site|company|team)|"
                  r"production (is )?(down|stopped)|critical|business stopped|cannot trade|"
                  r"major incident|p1|sev ?1|urgent(ly)?|asap|immediately)\b", re.I),
    2: re.compile(r"\b(cannot|can'?t|unable|fail(s|ed|ing)?|error|blocked|stuck|not working|"
                  r"deadline|degraded|slow|intermittent)\b", re.I),
}
_URGENCY_CHOICE = {"high": 1, "1": 1, "work stopped": 1, "medium": 2, "2": 2, "degraded": 2,
                   "low": 3, "3": 3, "no impact": 3, "minor": 3}
_NON_PROD_RE = re.compile(r"\b(uat|test|dev|development|sit|qa|staging|pre-?prod|sandbox|training)\b", re.I)


def infer_urgency(text: str) -> Tuple[int, str]:
    if _URGENCY_WORDS[1].search(text or ""):
        return 1, "Description indicates an outage or wide business stoppage."
    if _URGENCY_WORDS[2].search(text or ""):
        return 2, "Description indicates work is blocked or degraded."
    return 3, "No blocking or outage language in the description."


def _priority_rank(p: str) -> Optional[int]:
    m = re.match(r"^P([1-5])$", clean_value(p))
    return int(m.group(1)) if m else None


def short_description(text: str, limit: int = 100) -> str:
    """First sentence of the description, trimmed at a word boundary."""
    first = re.split(r"(?<=[.!?])\s+|\n", (text or "").strip(), maxsplit=1)[0].strip()
    first = re.sub(r"\s+", " ", first).rstrip(".")
    if len(first) <= limit:
        return first
    cut = first[:limit].rsplit(" ", 1)[0]
    return cut.rstrip(",;:-") + "..."


# ---------------------------------------------------------------------------
# Classifier helpers
# ---------------------------------------------------------------------------
def _proba_dict(model, X) -> Dict[str, float]:
    try:
        proba = model.predict_proba(X)[0]
        classes = getattr(model, "classes_", None)
        if classes is None:
            return {}
        return {str(c): float(p) for c, p in zip(classes, proba)}
    except Exception as exc:
        logger.warning("predict_proba failed: %s", exc)
        return {}


def _classify(store, name: str, X_text, extra: Dict[str, str], cols: Tuple[str, ...],
              encoders_name: str = "column_encoders") -> Dict[str, float]:
    from .predict import _augment_with_encoders
    model = getattr(store, name)()
    if model is None:
        return {}
    try:
        X = X_text
        if cols:
            encoders = getattr(store, encoders_name)()
            X = _augment_with_encoders(X_text, pd.DataFrame([extra]), encoders, cols)
        return _proba_dict(model, X)
    except Exception as exc:
        logger.warning("%s failed: %s", name, exc)
        return {}


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def _field(value, confidence, source, alternatives=None, note=""):
    return {"value": value, "confidence": round(float(confidence or 0.0), 3),
            "source": source, "alternatives": alternatives or [], "note": note}


def _alts(ranked: List[Tuple[str, float]], skip: str) -> List[Dict[str, Any]]:
    return [{"value": k, "confidence": round(float(v), 3)} for k, v in ranked if k != skip][:3]


def predict_template_fields(description: str, scope: str = "Individual",
                            environment: str = "Production",
                            caller: str = "Unknown",
                            store=None,
                            ticket_type: str = "auto",
                            urgency: Optional[str] = None,
                            ci: Optional[str] = None,
                            with_similar: bool = True) -> Dict[str, Any]:
    """Predict ServiceNow fields for a free-text incident or request."""
    from .predict import ModelStore
    from .similarity import find_similar, synthesize_recommendation

    description = (description or "").strip()
    store = store or ModelStore()
    vec = store.vectorizer()

    detected, type_reason = detect_ticket_type(description)
    chosen_type = ticket_type if ticket_type in ("incident", "request") else detected
    if ticket_type in ("incident", "request") and ticket_type != detected:
        type_reason = "Chosen on the form (the wording reads more like a%s %s)." % (
            "n" if detected == "incident" else "", detected)
    elif ticket_type in ("incident", "request"):
        type_reason = "Chosen on the form."

    # ---- 1. Similar-ticket evidence --------------------------------------
    source = "incident" if chosen_type == "incident" else "sr"
    similar: Dict[str, Any] = {"status": "skipped", "matches": [], "evidence": []}
    if with_similar:
        similar = find_similar(description, top_n=5, source=source, ci_hint=ci,
                               keep_evidence=True)
        if similar.get("status") != "ok" and source == "sr":
            # No request history yet: incident history still says who does
            # this work and how long it takes.
            similar = find_similar(description, top_n=5, source="incident", ci_hint=ci,
                                   keep_evidence=True)
    evidence = similar.get("evidence") or []
    weights = [m.pop("_weight", m.get("match_score", 0) / 100.0) ** 2 for m in evidence]
    # 0..1: how far to trust the vote. Squared weights decide BETWEEN labels;
    # trust in the vote as a whole grows with the plain match scores - e.g.
    # three 50% matches, or two 75% ones, are full trust.
    history_strength = (float(min(1.0, sum(np.sqrt(w) for w in weights) / 1.5))
                        if weights else 0.0)

    def vote(column):
        return weighted_vote((m.get(column, ""), w) for m, w in zip(evidence, weights))

    # ---- 2. Classifiers + ensemble ----------------------------------------
    X_text = vec.transform([description]) if vec is not None else None
    models_used = vec is not None and chosen_type == "incident"

    def model_probs(name, extra=None, cols=(), enc="column_encoders"):
        if not models_used:
            return {}
        return _classify(store, name, X_text, extra or {}, cols, enc)

    cat_ranked, cat_src = ensemble(model_probs("cat_model"), vote("category"), history_strength)
    category = cat_ranked[0][0] if cat_ranked else "General"

    sub_ranked, sub_src = ensemble(
        model_probs("subcat_model", {"category": category}, ("category",)),
        vote("subcategory"), history_strength)
    subcategory = sub_ranked[0][0] if sub_ranked else ""

    hist_priority = vote("priority")
    provisional_priority = hist_priority[0][0] if hist_priority else "P3"
    grp_ranked, grp_src = ensemble(
        model_probs("route_model", {"category": category, "priority": provisional_priority},
                    ("category", "priority")),
        vote("assignment_group"), history_strength)
    group = grp_ranked[0][0] if grp_ranked else "Service Desk"

    # Train/serve parity: priority model sees the PREDICTED group.
    pri_ranked, pri_src = ensemble(
        model_probs("pri_model", {"assignment_group": group, "category": category},
                    ("assignment_group", "category")),
        hist_priority, history_strength)
    learned_priority = pri_ranked[0][0] if pri_ranked else ""

    ci_ranked = vote("configuration_item")
    ci_value = clean_value(ci) or (ci_ranked[0][0] if ci_ranked and ci_ranked[0][1] >= 0.5 else "")

    # ---- 3. Rules: impact, urgency, priority -------------------------------
    impact = _SCOPE_IMPACT.get((scope or "").strip().lower(), 3)
    chosen_urgency = _URGENCY_CHOICE.get((urgency or "").strip().lower())
    if chosen_urgency:
        urg, urg_reason = chosen_urgency, "Chosen on the form."
    else:
        urg, urg_reason = infer_urgency(description)
    if _NON_PROD_RE.search(environment or "") and urg == 1:
        urg, urg_reason = 2, urg_reason + " Capped at Medium for a non-production environment."
    if chosen_type == "request" and not chosen_urgency and urg < 3 and not _URGENCY_WORDS[1].search(description):
        urg, urg_reason = 3, "Requests default to Low urgency unless an outage is described."
    matrix_priority = _PRIORITY_MATRIX[(impact, urg)]

    notes: List[str] = []
    lp, mp = _priority_rank(learned_priority), _priority_rank(matrix_priority)
    if lp and mp and abs(lp - mp) >= 2:
        notes.append(f"Similar tickets were usually {learned_priority}; the impact x urgency "
                     f"matrix gives {matrix_priority}. Check scope and urgency.")

    # ---- 4. ETA -------------------------------------------------------------
    hours = [m.get("resolution_hours") for m in evidence]
    p50 = weighted_percentile(hours, weights, 0.5)
    p80 = weighted_percentile(hours, weights, 0.8)
    eta_source = "history" if p50 is not None else "default"
    if p50 is None and models_used and store.eta_model() is not None:
        try:
            from .predict import _augment_with_encoders
            X = _augment_with_encoders(X_text, pd.DataFrame([{"priority": matrix_priority, "category": category}]),
                                       store.res_column_encoders(), ("priority", "category"))
            p50 = float(np.clip(store.eta_model().predict(X)[0], 0.5, 720))
            eta_source = "model"
        except Exception as exc:
            logger.warning("ETA predict failed: %s", exc)
    if p50 is None:
        p50 = {"P1": 4.0, "P2": 12.0, "P3": 48.0, "P4": 96.0}[matrix_priority]

    # ---- 5. Assemble ------------------------------------------------------
    fields = {
        "category": _field(category, cat_ranked[0][1] if cat_ranked else 0, cat_src, _alts(cat_ranked, category)),
        "subcategory": _field(subcategory, sub_ranked[0][1] if sub_ranked else 0, sub_src, _alts(sub_ranked, subcategory)),
        "assignment_group": _field(group, grp_ranked[0][1] if grp_ranked else 0, grp_src, _alts(grp_ranked, group)),
        "priority": _field(matrix_priority, 1.0, "rule",
                           note=f"Impact {IMPACT_LABELS[impact]} x urgency {URGENCY_LABELS[urg]}."),
        "historical_priority": _field(learned_priority, pri_ranked[0][1] if pri_ranked else 0, pri_src,
                                      _alts(pri_ranked, learned_priority)),
        "impact": _field(IMPACT_LABELS[impact], 1.0, "rule", note=f"From scope: {scope}."),
        "urgency": _field(URGENCY_LABELS[urg], 1.0 if chosen_urgency else 0.7, "rule", note=urg_reason),
        "configuration_item": _field(ci_value, 1.0 if clean_value(ci) else (ci_ranked[0][1] if ci_ranked else 0),
                                     "form" if clean_value(ci) else "history", _alts(ci_ranked, ci_value)),
    }
    review = [name.replace("_", " ") for name in ("category", "subcategory", "assignment_group")
              if fields[name]["value"] and fields[name]["confidence"] < 0.5]

    result: Dict[str, Any] = {
        "ticket_type": chosen_type,
        "ticket_type_label": "Incident" if chosen_type == "incident" else "Service Request",
        "ticket_type_detected": detected,
        "ticket_type_reason": type_reason,
        "short_description": short_description(description),
        "description": description,
        "caller": caller,
        "category": category,
        "subcategory": subcategory,
        "priority": matrix_priority,
        "impact": IMPACT_LABELS[impact],
        "urgency": URGENCY_LABELS[urg],
        "assignment_group": group,
        "configuration_item": ci_value,
        "environment": environment,
        "estimated_resolution_hours": round(p50, 1),
        "estimated_resolution_p80_hours": round(p80, 1) if p80 is not None else None,
        "eta_source": eta_source,
        "confidence": {"category": fields["category"]["confidence"],
                       "priority": fields["historical_priority"]["confidence"],
                       "assignment_group": fields["assignment_group"]["confidence"]},
        "fields": fields,
        "needs_review": review,
        "notes": notes,
        "evidence": {"matches": len(evidence), "strength": round(history_strength, 2),
                     "models_used": bool(models_used),
                     "source": similar.get("source") or source,
                     "searched": similar.get("total_searched", 0)},
        "fallback_mode": vec is None and not evidence,
    }

    # Possible (tentative) matches are for a person to glance at, never
    # evidence for proposed fields or a suggested fix.
    matches = [m for m in (similar.get("matches") or []) if not m.get("tentative")]
    if matches:
        synth = synthesize_recommendation(matches)
        result["suggested_resolution_steps"] = synth["recommended_steps"]
        result["resolution"] = synth
        result["likely_root_cause"] = synth["likely_root_cause"]
    else:
        result["suggested_resolution_steps"] = []
        result["resolution"] = None
        result["likely_root_cause"] = ""
    result["similar_incidents"] = [
        {"id": m["incident_id"], "title": m["title"], "similarity": m["match_score"],
         "record_type": m["record_type"], "assignment_group": m["assignment_group"],
         "resolution_hours": m["resolution_hours"], "resolution_quality": m["resolution_quality"],
         "occurrences": m["occurrences"]}
        for m in matches]
    result["insights"] = similar.get("insights") or {"available": False}
    return result
