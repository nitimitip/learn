"""Keep every retrieval signal aligned to the same corpus row positions.

`rank_detailed` is the engine behind Similar Incidents, the Incident /
Service Request template and the CR template. It scores one query against a
corpus with up to six independent signals, fuses their RANKS (Reciprocal Rank
Fusion) for ordering, and separately computes a 0..1 match strength for
display:

    Text       TF-IDF cosine over title + description
    Title      TF-IDF cosine over the short description only - the field
               support staff write most carefully, so it carries the most
               signal per word and is not diluted by long boilerplate bodies
    Semantic   sentence-embedding cosine (when an encoder is installed)
    Keywords   BM25, gated at a fraction of the best score so that sharing a
               single common word ("user", "issue") no longer counts
    Code       exact identifier match: error codes (ORA-12514, 0x80070005),
               KB / patch ids, host names (web01). TF-IDF splits these into
               fragments; an exact hit is the strongest evidence there is
    Context    a caller-supplied soft preference (same CI, same environment)
               that re-orders candidates without filtering anyone out

A row only becomes a candidate when a MEANINGFUL signal found it (Text,
Title, Semantic or Code). Keywords and Context re-rank candidates but never
admit one on their own. Text and Title are scaled by the share of query words
the corpus vocabulary knows (see vocabulary_coverage).

`rank` keeps the original 4-tuple contract for existing callers.
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional

import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

from .embedding_utils import bm25_scores, encode_texts, reciprocal_rank_fusion

SEMANTIC_FLOOR = 0.40
# Semantic cosine from general-purpose sentence encoders sits around
# 0.3-0.4 for unrelated IT text and rarely exceeds 0.9 for paraphrases, so
# the raw value overstates similarity. It is rescaled onto 0..1 over this
# band before it is shown to anyone.
SEMANTIC_LOW, SEMANTIC_HIGH = 0.30, 0.85
BM25_RELATIVE_FLOOR = 0.25      # enters the Keywords list
TITLE_WEIGHT = 0.90             # title-only cosine is slightly optimistic

# Identifier-like tokens: mixed letters+digits (ORA-12514, KB5031356, web01,
# 0x80070005) or long pure numbers (error numbers, not years or counts).
_CODE_RE = re.compile(
    r"(?<![A-Za-z0-9])("
    r"(?=[A-Za-z0-9._\-]*\d)(?=[A-Za-z0-9._\-]*[A-Za-z])[A-Za-z0-9][A-Za-z0-9._\-]{3,}[A-Za-z0-9]"
    r"|\d{5,}"
    r")(?![A-Za-z0-9])")
# Tokens that look like codes but carry no evidence (dates, sizes, versions
# of ubiquitous software are still allowed - they are specific enough).
_CODE_NOISE_RE = re.compile(r"^(\d{1,2}(am|pm)|\d+(gb|mb|kb|tb|ms|s|h|hrs?|mins?)|q[1-4]|p[1-5]|x64|x86|win\d+|\d{4}-\d{2}(-\d{2})?)$", re.I)


def extract_codes(text: str) -> List[str]:
    """Distinct identifier-like tokens in `text`, lower-cased."""
    seen: List[str] = []
    for match in _CODE_RE.finditer(text or ""):
        token = match.group(1).strip("._-").lower()
        if len(token) < 4 or _CODE_NOISE_RE.match(token) or token in seen:
            continue
        seen.append(token)
    return seen[:8]


def query_words(vectorizer, query: str):
    """(content words of the query, vocabulary column of each known one)."""
    try:
        analyzer = vectorizer.build_analyzer()
        vocabulary = vectorizer.vocabulary_
    except Exception:
        return set(), []
    words = {t for t in analyzer(query or "") if " " not in t}
    return words, [vocabulary[w] for w in words if w in vocabulary]


RARE_WORD_SHARE = 0.01
RARE_WORD_MIN_DOCS = 3
# Rarity is only meaningful on a realistic history; in a small one almost
# every word is "rare", including "request" and "user".
RARE_WORD_MIN_CORPUS = 200


def rare_columns(matrix, columns):
    """Vocabulary columns present in few documents (specific terms)."""
    if not columns or matrix is None or matrix.shape[0] < RARE_WORD_MIN_CORPUS:
        return []
    doc_freq = np.asarray((matrix[:, columns] != 0).sum(axis=0)).ravel()
    limit = max(RARE_WORD_MIN_DOCS, int(RARE_WORD_SHARE * matrix.shape[0]))
    return [c for c, f in zip(columns, doc_freq) if 0 < f <= limit]


def vocabulary_coverage(vectorizer, query: str) -> float:
    """Share of the query's content words present in the fitted vocabulary."""
    words, known = query_words(vectorizer, query)
    return len(known) / float(len(words)) if words else 1.0


def distinct_hits(matrix, columns) -> np.ndarray:
    """Per row: how many of the given vocabulary columns are present."""
    if not columns or matrix is None:
        return np.zeros(matrix.shape[0] if matrix is not None else 0, dtype=np.int64)
    return np.asarray((matrix[:, columns] != 0).sum(axis=1)).ravel()


def calibrate_semantic(scores: np.ndarray) -> np.ndarray:
    return np.clip((scores - SEMANTIC_LOW) / (SEMANTIC_HIGH - SEMANTIC_LOW), 0.0, 1.0)


def cached_title_vectors(cache: Optional[dict], vectorizer, titles) -> Optional[object]:
    """TF-IDF vectors of the titles, computed once per snapshot object.

    Snapshots are held in an lru_cache, so storing the matrix on the dict
    makes this a one-off cost per worker per published version.
    """
    if titles is None:
        return None
    if cache is not None and "_title_vectors" in cache:
        return cache["_title_vectors"]
    matrix = vectorizer.transform([str(t or "") for t in titles])
    if cache is not None:
        cache["_title_vectors"] = matrix
    return matrix


# ---------------------------------------------------------------------------
# Locally trained "meaning" indexes (scikit-learn only - no downloads).
# ---------------------------------------------------------------------------
CHAR_TEXT_CHARS = 200           # title + start of description; bounds memory
# Character-gram cosine is inflated by shared whole words (every shared
# word contributes many 3-4-grams), so it only adds evidence well above the
# level word overlap already explains.
CHAR_FLOOR = 0.55               # character-gram cosine that admits a row
CHAR_LOW, CHAR_HIGH = 0.45, 0.90
CHAR_WEIGHT = 0.75
# Highest score a tentative (possible) match can show.
TENTATIVE_CAP = 0.35


def build_char_index(norm_texts):
    """Character 3-4-gram TF-IDF: catches spelling variants and typos
    ("certficate", "timed-out") that word matching misses."""
    from sklearn.feature_extraction.text import TfidfVectorizer
    texts = [str(t or "")[:CHAR_TEXT_CHARS] for t in norm_texts]
    if not texts or not any(t.strip() for t in texts):
        return None
    vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 4), min_df=1 if len(texts) < 50 else 2,
                          max_features=100000, sublinear_tf=True, dtype=np.float32)
    try:
        return {"vectorizer": vec, "vectors": vec.fit_transform(texts)}
    except ValueError:
        return None


def rank_detailed(query: str, vectorizer, vectors, *, semantic=None, bm25=None,
                  encoder=None, allowed=None, lexical_floor: float = 0.10,
                  title_vectors=None, texts=None, boost=None,
                  title_query: Optional[str] = None, char=None,
                  normalised: bool = False, hint=None) -> Dict[str, object]:
    """Score `query` against the corpus.

    title_query  what the Title signal compares against stored short
                 descriptions (default: the query). The CR page passes its own
                 short description so a near-identical title is not diluted.
    char         the snapshot's character n-gram index (optional).
    normalised   the snapshot's lexical indexes were built on textnorm output,
                 so the query must be normalised the same way.
    hint         rows the trained classifiers point to (predicted category /
                 group). Re-ranks candidates; never admits one.
    """
    count = vectors.shape[0]
    eligible = np.ones(count, dtype=bool) if allowed is None else np.asarray(allowed, dtype=bool)
    zeros = np.zeros(count, dtype=np.float64)
    if count == 0:
        return {"fused": zeros, "strength": zeros, "lexical": zeros, "title": zeros,
                "semantic": None, "keywords": zeros, "fuzzy": None,
                "code_hits": np.zeros(0, dtype=bool), "codes": [], "signals": [],
                "candidate": np.zeros(0, dtype=bool), "tentative": [], "tentative_score": zeros}

    raw_query = query
    if normalised:
        from .textnorm import normalise
        query = normalise(query)
        title_query = normalise(title_query) if title_query else None

    query_vector = vectorizer.transform([query])
    # TF-IDF silently drops query words the corpus has never seen, so a
    # query sharing ONE known word with a document scores as if that word
    # were the whole query. Scale by the share of query words the
    # vocabulary knows (square root: a verbose description must not halve an
    # otherwise strong match).
    words, known = query_words(vectorizer, query)
    coverage = float(np.sqrt(len(known) / float(len(words)))) if words else 1.0
    lexical = cosine_similarity(query_vector, vectors).ravel() * coverage
    has_titles = title_vectors is not None and title_vectors.shape[0] == count
    title_q = title_query.strip() if title_query and title_query.strip() else None
    title_vector = vectorizer.transform([title_q]) if title_q else query_vector
    title_words, title_known = query_words(vectorizer, title_q) if title_q else (words, known)
    title_cov = (float(np.sqrt(len(title_known) / float(len(title_words)))) if title_words else 1.0)
    title = (cosine_similarity(title_vector, title_vectors).ravel() * title_cov
             if has_titles else zeros.copy())
    # Wording evidence needs more than one shared word once the query has
    # three or more content words ("user password reset" must not match a
    # printer ticket because both mention a user).
    word_hits = distinct_hits(vectors, known)
    needed = 1 if len(words) <= 2 else 2
    # ...unless the one shared word is RARE in this history (an application,
    # product or host name: "anyconnect", "kronos"). A word in at most 1% of
    # tickets (min 3) is specific evidence; "request" or "user" is not.
    rare = rare_columns(vectors, known)
    rare_hits = distinct_hits(vectors, rare)
    enough_words = (word_hits >= needed) | (rare_hits >= 1)
    title_needed = 1 if len(title_words) <= 2 else 2
    enough_title_words = (((distinct_hits(title_vectors, title_known) >= title_needed)
                           | (distinct_hits(title_vectors, [c for c in title_known if c in set(rare)]) >= 1))
                          if has_titles else enough_words)

    semantic_scores = None
    if semantic is not None and len(semantic) == count and encoder is not None:
        encoded = encode_texts([raw_query], encoder)
        if encoded is not None and semantic.ndim == 2 and semantic.shape[1] == encoded.shape[1]:
            semantic_scores = semantic.dot(encoded[0]).astype(np.float64)

    fuzzy = None
    if char and char.get("vectors") is not None and char["vectors"].shape[0] == count:
        fuzzy = cosine_similarity(char["vectorizer"].transform([query[:CHAR_TEXT_CHARS]]),
                                  char["vectors"]).ravel().astype(np.float64)

    keywords = zeros.copy()
    if bm25 is not None:
        raw = bm25_scores(bm25, query, count)
        if raw is not None and len(raw) == count:
            raw = np.asarray(raw, dtype=np.float64)
            top = raw[eligible].max() if eligible.any() else 0.0
            if top > 0:
                keywords = np.clip(raw / top, 0.0, 1.0)

    codes = extract_codes(raw_query)
    code_hits = np.zeros(count, dtype=bool)
    if codes and texts is not None and len(texts) == count:
        lowered = [str(t or "").lower() for t in texts]
        for code in codes:
            code_hits |= np.fromiter((code in t for t in lowered), dtype=bool, count=count)

    boost_mask = np.zeros(count, dtype=bool) if boost is None else np.asarray(boost, dtype=bool)
    hint_mask = np.zeros(count, dtype=bool) if hint is None else np.asarray(hint, dtype=bool)

    fuzzy_ok = (fuzzy >= CHAR_FLOOR) if fuzzy is not None else np.zeros(count, dtype=bool)

    admitted = eligible & (
        ((lexical > lexical_floor) & enough_words)
        | ((title > lexical_floor) & enough_title_words) | code_hits | fuzzy_ok
        | ((semantic_scores > SEMANTIC_FLOOR) if semantic_scores is not None else False))

    signals: List[List[str]] = [[] for _ in range(count)]
    ranked: List[List[int]] = []

    def add(scores, mask, label):
        indices = np.flatnonzero(admitted & mask)
        if len(indices):
            ranked.append(indices[np.argsort(-scores[indices], kind="stable")].tolist())
            for index in indices:
                signals[index].append(label)

    add(lexical, (lexical > lexical_floor) & enough_words, "Text")
    add(title, (title > lexical_floor) & enough_title_words, "Title")
    if semantic_scores is not None:
        add(semantic_scores, semantic_scores > SEMANTIC_FLOOR, "Semantic")
    if fuzzy is not None:
        add(fuzzy, fuzzy_ok, "Spelling")
    add(keywords, keywords >= BM25_RELATIVE_FLOOR, "Keywords")
    # A shared RARE term (product / application / host name) is specific
    # evidence; rank rows carrying it on their own list so a common word the
    # normaliser merged ("drops out" -> disconnect) cannot outvote it.
    # Weighted by rarity (IDF): a term in 1 ticket outweighs one in 4.
    rare_weight = zeros.copy()
    if rare:
        idf = getattr(vectorizer, "idf_", None)
        weights = (np.asarray(idf)[rare] if idf is not None else np.ones(len(rare)))
        rare_weight = np.asarray((vectors[:, rare] != 0).astype(np.float64) @ weights).ravel()
    add(rare_weight + lexical, rare_hits >= 1, "Specific term")
    if code_hits.any():
        add(code_hits.astype(np.float64) + lexical, code_hits, "Exact code")
        # An exact identifier hit is decisive evidence - count it twice.
        ranked.append(ranked[-1])
    if boost_mask.any():
        add(lexical + title, boost_mask, "Context")
    if hint_mask.any():
        add(lexical + title, hint_mask, "Model hint")

    fused = reciprocal_rank_fusion(ranked, count).astype(np.float64) if ranked else zeros.copy()
    fused[~admitted] = 0.0
    # An identifier the engineer typed (ORA-12514, web01, KB5031356) is
    # decisive: rows containing it form the top tier, ordered among
    # themselves by everything else. More signals must not outvote it.
    if code_hits.any():
        fused = np.where(code_hits & admitted, fused + fused.max() + 1.0, fused)

    sem_cal = calibrate_semantic(semantic_scores) if semantic_scores is not None else zeros
    fuzzy_cal = (np.clip((fuzzy - CHAR_LOW) / (CHAR_HIGH - CHAR_LOW), 0, 1)
                 if fuzzy is not None else zeros)
    base = np.maximum.reduce([lexical, TITLE_WEIGHT * title, sem_cal, CHAR_WEIGHT * fuzzy_cal])
    def independent(sig):
        # Spelling and Keywords restate word overlap; they only count as an
        # independent opinion when the word signal did not fire.
        own = [s for s in sig if s not in ("Context", "Model hint")]
        if "Text" in own or "Title" in own:
            own = [s for s in own if s not in ("Spelling", "Keywords")]
        return min(max(len(own) - 1, 0), 2)
    agreement = np.array([independent(sig) for sig in signals], dtype=np.float64)
    strength = base + 0.05 * agreement + 0.10 * code_hits
    strength = np.where(admitted, np.clip(strength, 0.0, 1.0), 0.0)

    # Tentative tier: rows sharing at least one word with the query that did
    # not meet the evidence bar ("colleagues can't hear me on teams" vs "Teams
    # calls dropping audio"). Offered only AFTER confident matches, labelled
    # as possible, capped at a weak score and never used as evidence.
    tentative_mask = eligible & ~admitted & (word_hits >= 1) & ((lexical > 0.03) | (keywords >= 0.5))
    tentative_score = np.where(tentative_mask,
                               np.minimum(np.maximum.reduce([lexical, TITLE_WEIGHT * title, 0.3 * keywords]),
                                          TENTATIVE_CAP), 0.0)
    order = np.flatnonzero(tentative_mask)
    tentative = order[np.argsort(-(keywords[order] + lexical[order] + title[order]), kind="stable")].tolist()

    return {"fused": fused, "strength": strength, "lexical": lexical, "title": title,
            "semantic": sem_cal if semantic_scores is not None else None,
            "fuzzy": fuzzy_cal if fuzzy is not None else None,
            "keywords": keywords, "code_hits": code_hits, "codes": codes,
            "signals": signals, "candidate": admitted,
            "tentative": tentative, "tentative_score": tentative_score}


def rank(query, vectorizer, vectors, *, semantic=None, bm25=None, encoder=None,
         allowed=None, lexical_floor=0.10):
    """Original 4-tuple contract: (fused, strength, lexical, signals)."""
    result = rank_detailed(query, vectorizer, vectors, semantic=semantic, bm25=bm25,
                           encoder=encoder, allowed=allowed, lexical_floor=lexical_floor)
    return result["fused"], result["strength"], result["lexical"], result["signals"]
