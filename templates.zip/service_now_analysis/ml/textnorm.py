"""IT-support vocabulary normalisation for retrieval.

Support tickets say the same thing many ways: "can't log on", "unable to
sign in", "login fails". Word-level matching treats those as different words.
This module rewrites common variants onto one canonical token before the
TF-IDF / BM25 / character / topic indexes are built, and applies the SAME
rewrite to every query.

Rules:
  * Only applied to snapshots built with it (snapshot["text_norm"] ==
    TEXT_NORM_VERSION). A query must never be normalised against an index
    that was not, or "log in" -> "login" would stop matching "log in".
  * Never used for display, for the stored ticket text or for sentence
    embeddings - only for the lexical indexes.
  * Plain regular expressions; no downloads, no extra libraries.

Bump TEXT_NORM_VERSION when the table changes: snapshots built with an older
table fall back to un-normalised queries until the next import.
"""
from __future__ import annotations

import re
from typing import List, Tuple

TEXT_NORM_VERSION = 1

# (pattern, replacement). Order matters: multi-word phrases first.
_RULES: List[Tuple[str, str]] = [
    # access / authentication
    (r"\b(log(?:ged|ging)?[\s-]?(?:in|on)|sign(?:ed|ing)?[\s-]?(?:in|on)|logon|signon|signin)\b", "login"),
    (r"\b(log(?:ged|ging)?[\s-]?(?:out|off)|sign(?:ed|ing)?[\s-]?(?:out|off)|logoff|signout)\b", "logout"),
    (r"\b(pwd|passwd|pass[\s-]?word|pword|pw)\b", "password"),
    (r"\b(a/c|acct|accnt)\b", "account"),
    (r"\b(locked[\s-]?out|lock[\s-]?out|lockout)\b", "locked"),
    (r"\b(mfa|2fa|two[\s-]?factor|multi[\s-]?factor|authenticator[\s-]?app)\b", "mfa"),
    (r"\b(sso|single[\s-]?sign[\s-]?on)\b", "sso"),
    (r"\b(perms?|permissions?|privileges?|entitlements?)\b", "permission"),
    # inability / failure
    (r"\b(can\s*not|can'?t|cant|unable\s+to|not\s+able\s+to|couldn'?t|could\s+not|cannot)\b", "cannot"),
    (r"\b(does\s*n'?t|doesnt|is\s*n'?t|isnt|not)\s+work(?:ing|s)?\b", "notworking"),
    (r"\b(time[ds]?[\s-]?out|timing[\s-]?out|timeouts?)\b", "timeout"),
    (r"\b(crash(?:ed|es|ing)?|hang(?:s|ing)?|hung|frozen|freez(?:e|es|ing))\b", "crash"),
    (r"\b(fail(?:s|ed|ing|ure|ures)?)\b", "fail"),
    (r"\b(err(?:or|ors)?|exception)\b", "error"),
    (r"\b(slow(?:ness)?|sluggish|laggy|lagging|performance\s+(?:issue|problem|degradation))\b", "slow"),
    (r"\b(unreachable|unavailable|inaccessible|not\s+accessible|not\s+reachable|down)\b", "unavailable"),
    (r"\b(disconnect(?:s|ed|ing|ion)?|drop(?:s|ped|ping)\s+(?:out|off|connection))\b", "disconnect"),
    # actions
    (r"\b(re[\s-]?boot(?:ed|ing)?|re[\s-]?start(?:ed|ing)?|bounce[ds]?|power[\s-]?cycled?)\b", "restart"),
    (r"\b(re[\s-]?issu(?:e|ed|ing)|re[\s-]?generat(?:e|ed|ing))\b", "reissue"),
    (r"\b(re[\s-]?install(?:ed|ing)?|re[\s-]?deploy(?:ed|ing)?)\b", "reinstall"),
    (r"\b(re[\s-]?set(?:ting)?)\b", "reset"),
    (r"\b(un[\s-]?lock(?:ed|ing)?)\b", "unlock"),
    # systems / places
    (r"\b(o365|office[\s-]?365|m365|microsoft[\s-]?365)\b", "office365"),
    (r"\b(e[\s-]?mails?|mailbox(?:es)?|mails?)\b", "email"),
    (r"\b(db|dbs|databases?)\b", "database"),
    (r"\b(svr|srv|servers?)\b", "server"),
    (r"\b(prd|prod|production)\b", "production"),
    (r"\b(non[\s-]?prod|preprod|pre[\s-]?prod|staging|uat)\b", "nonproduction"),
    (r"\b(pc|laptop|desktop|workstation|machine)\b", "computer"),
    (r"\b(certs?|certificates?|ssl|tls)\b", "certificate"),
    (r"\b(wi[\s-]?fi|wireless|wlan)\b", "wifi"),
    (r"\b(printer|printing|print(?:s|ed)?|print[\s-]?queue)\b", "print"),
    (r"\b(teams|ms[\s-]?teams)\b", "teams"),
    (r"\b(one[\s-]?drive)\b", "onedrive"),
    (r"\b(share[\s-]?point)\b", "sharepoint"),
    (r"\b(shared[\s-]?drive|network[\s-]?drive|mapped[\s-]?drive|file[\s-]?share)\b", "shareddrive"),
    (r"\b(pls|plz|please|kindly)\b", " "),
]
_COMPILED = [(re.compile(p, re.I), r) for p, r in _RULES]


def normalise(text: str) -> str:
    """Canonicalise support vocabulary (lower-cased output)."""
    out = (text or "").lower()
    for pattern, replacement in _COMPILED:
        out = pattern.sub(replacement, out)
    return re.sub(r"\s+", " ", out).strip()


def normalise_all(texts) -> List[str]:
    return [normalise(t) for t in texts]
