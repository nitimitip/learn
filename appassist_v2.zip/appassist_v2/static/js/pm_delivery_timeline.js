/* Accessible delivery timeline. Dates are UTC calendar days, inclusive at both ends. */
(() => {
    'use strict';
    const root = document.getElementById('deliveryTimeline');
    if (!root) return;
    const data = JSON.parse(document.getElementById('pm-plan-data').textContent);
    const DAY = 86400000;
    const day = value => value ? Date.parse(value + 'T00:00:00Z') / DAY : NaN;
    const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const date = value => new Date(value * DAY).toLocaleDateString(undefined, {day:'2-digit', month:'short', year:'numeric', timeZone:'UTC'});
    const compare = new Map(data.rows.map(r => [String(r.id), r]));
    const rows = data.schedule.map(r => ({...r, comparison: compare.get(String(r.id)), startDay:day(r.start), endDay:day(r.end)}));
    const $ = id => document.getElementById(id);
    const collapsed = new Set();
    const tasks = rows.filter(r => r.kind === 'task');
    let rangeStart, rangeEnd, pixels;
    const now = new Date();
    const today = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()) / DAY;
    const variance = r => !r.comparison ? (data.baseline ? 'Not in baseline' : 'No baseline') : r.comparison.variance > 0 ? `+${r.comparison.variance}d later` : r.comparison.variance < 0 ? `${-r.comparison.variance}d earlier` : 'On baseline';
    rows.filter(r => r.kind === 'milestone').forEach(r => {
        const option = document.createElement('option'); option.value = r.milestone_id; option.textContent = r.name; $('timelineMilestone').append(option);
    });
    if (!data.baseline) $('timelineFilter').querySelector('[value="late"]').disabled = true;
    const late = tasks.filter(r => r.comparison?.variance > 0).length;
    $('deliverySummary').innerHTML = [[tasks.length,'Tasks in plan'],[tasks.filter(r => Number(r.progress) >= 100).length,'Completed'],[tasks.filter(r => r.critical).length,'Critical tasks'],[data.baseline ? late : '\u2014','Finishing later than baseline']].map(([v,l]) => `<div><strong>${v}</strong><span>${l}</span></div>`).join('');
    function render() {
        const baseline = $('timelineBaseline').checked;
        const query = $('timelineSearch').value.trim().toLowerCase();
        const milestone = $('timelineMilestone').value;
        const filter = $('timelineFilter').value;
        const matches = r => (!query || `${r.name} ${r.owner || ''}`.toLowerCase().includes(query)) &&
            (filter === 'all' || filter === 'critical' && r.critical || filter === 'late' && r.comparison?.variance > 0 || filter === 'open' && Number(r.progress) < 100);
        const visible = rows.filter(r => (!milestone || String(r.milestone_id) === milestone) &&
            (r.kind === 'milestone' ? ((!query && filter === 'all') || tasks.some(t => t.milestone_id === r.milestone_id && matches(t))) : matches(r) && (!collapsed.has(r.milestone_id) || query || filter !== 'all')));
        const dates = visible.flatMap(r => [r.startDay, r.endDay, ...(baseline && r.comparison ? [day(r.comparison.baseline_start), day(r.comparison.baseline_end)] : [])]).filter(Number.isFinite);
        rangeStart = dates.length ? Math.min(...dates) - 2 : today - 7;
        rangeEnd = dates.length ? Math.max(...dates) + 3 : today + 7;
        const span = rangeEnd - rangeStart;
        const scale = $('timelineZoom').value;
        pixels = scale === 'day' ? 36 : scale === 'week' ? 12 : Math.max(0.05, Math.max(480, $('timelineViewport').clientWidth - 300) / span);
        const width = Math.max(480, span * pixels);
        const step = Math.max(1, Math.ceil(95 / pixels));
        let ticks = '';
        for (let d = rangeStart; d <= rangeEnd; d += step) ticks += `<span style="left:${(d-rangeStart)*pixels}px">${esc(date(d))}</span>`;
        const todayLine = today >= rangeStart && today <= rangeEnd ? `<i class="pm-today-line" style="left:${(today-rangeStart)*pixels}px" title="Today: ${date(today)}"></i>` : '';
        const bar = (start,end,cls,title) => Number.isFinite(start) && Number.isFinite(end) && end >= start ? `<span class="pm-schedule-bar ${cls}" style="left:${(start-rangeStart)*pixels}px;width:${Math.max(3,(end-start+1)*pixels)}px" title="${esc(title)}"></span>` : '';
        $('timelineGrid').style.setProperty('--timeline-width', `${width}px`);
        $('timelineGrid').style.setProperty('--tick-width', `${step * pixels}px`);
        $('timelineGrid').innerHTML = `<div class="pm-timeline-row pm-timeline-axis"><div class="pm-timeline-label">Work item <span>Schedule / finish variance</span></div><div class="pm-timeline-track">${ticks}</div></div>` + visible.map(r => {
            const isMilestone = r.kind === 'milestone';
            const b = baseline && r.comparison;
            const valid = Number.isFinite(r.startDay) && Number.isFinite(r.endDay) && r.endDay >= r.startDay;
            return `<div class="pm-timeline-row ${isMilestone ? 'is-milestone' : ''}"><div class="pm-timeline-label">${isMilestone ? `<button type="button" class="pm-group-toggle" data-group="${r.milestone_id}" aria-expanded="${!collapsed.has(r.milestone_id)}" aria-label="Toggle ${esc(r.name)}">${collapsed.has(r.milestone_id) ? '+' : '\u2212'}</button>` : ''}<button type="button" class="pm-task-select" data-row="${esc(r.id)}" title="${esc(r.name)}">${esc(r.name)}</button><span>${isMilestone ? esc(r.status) : `${r.critical ? 'Critical \u00b7 ' : ''}${Math.round(Number(r.progress) || 0)}% \u00b7 ${esc(variance(r))}`}</span></div><button type="button" class="pm-timeline-track ${b ? 'has-baseline' : ''}" data-row="${esc(r.id)}" aria-label="${esc(r.name + ': ' + (valid ? r.start + ' to ' + r.end : 'Unscheduled') + '. ' + (isMilestone ? r.status : variance(r)))}">${todayLine}${bar(r.startDay,r.endDay,'pm-current ' + (isMilestone ? 'pm-milestone-bar' : r.critical ? 'pm-critical-bar' : ''),`Current: ${r.start} \u2192 ${r.end}`)}${b ? bar(day(b.baseline_start),day(b.baseline_end),'pm-baseline',`Baseline: ${b.baseline_start} \u2192 ${b.baseline_end}`) : ''}${!valid ? '<span class="pm-unscheduled">Dates not scheduled</span>' : ''}</button></div>`;
        }).join('') + (!visible.length ? '<div class="pm-timeline-empty">No work matches these filters. <button type="button" class="btn btn-sm" id="timelineReset">Reset filters</button></div>' : '');
        $('timelineReset')?.addEventListener('click', () => { $('timelineSearch').value = ''; $('timelineMilestone').value = ''; $('timelineFilter').value = 'all'; render(); });
    }
    $('timelineGrid').addEventListener('click', event => {
        const group = event.target.closest('[data-group]');
        if (group) { const id = Number(group.dataset.group); collapsed.has(id) ? collapsed.delete(id) : collapsed.add(id); render(); return; }
        const button = event.target.closest('[data-row]');
        if (!button) return;
        const r = rows.find(r => String(r.id) === button.dataset.row);
        const b = r.comparison;
        $('timelineInspector').innerHTML = `<strong>${esc(r.name)}</strong><span>${esc(r.owner || 'Milestone')} \u00b7 ${esc(r.status)} \u00b7 ${Math.round(Number(r.progress) || 0)}% complete</span><span>Current plan: <b>${esc(r.start || 'Unscheduled')} \u2192 ${esc(r.end || 'Unscheduled')}</b></span>${r.kind === 'task' ? `<span>Baseline: <b>${b ? `${esc(b.baseline_start)} \u2192 ${esc(b.baseline_end)}` : 'Not available'}</b> \u00b7 ${esc(variance(r))}</span>` : ''}`;
    });
    ['timelineMilestone','timelineFilter','timelineZoom','timelineBaseline'].forEach(id => $(id).addEventListener('change', render));
    $('timelineSearch').addEventListener('input', render);
    $('timelineCollapse').addEventListener('click', () => {
        const groups = rows.filter(r => r.kind === 'milestone');
        const collapse = collapsed.size < groups.length;
        collapsed.clear(); if (collapse) groups.forEach(r => collapsed.add(r.milestone_id));
        $('timelineCollapse').textContent = collapse ? 'Expand milestones' : 'Collapse milestones';
        $('timelineCollapse').setAttribute('aria-pressed', String(collapse)); render();
    });
    $('timelineToday').addEventListener('click', () => {
        if (today < rangeStart || today > rangeEnd) { $('timelineInspector').textContent = `Today (${date(today)}) is outside the displayed schedule: ${date(rangeStart + 2)} to ${date(rangeEnd - 3)}.`; return; }
        $('timelineViewport').scrollLeft = Math.max(0,(today-rangeStart)*pixels - ($('timelineViewport').clientWidth-300)/2);
        $('timelineInspector').textContent = `Today: ${date(today)}. The vertical line marks today's date.`;
    });
    if (window.ResizeObserver) { let width; new ResizeObserver(() => { const next = $('timelineViewport').clientWidth; if (next && next !== width) { width = next; render(); } }).observe($('timelineViewport')); }
    render();
})();
