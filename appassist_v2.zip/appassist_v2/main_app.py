"""
main_app.py - Application Dashboard
Production-ready configuration for IIS + wfastcgi.

Key changes from original:
  1. Logging uses RotatingFileHandler with absolute paths (no unbounded growth,
     and works regardless of IIS working directory).
  2. Background schedulers are guarded by the RUN_SCHEDULERS_IN_APP env var
     (default false) so they never start in an IIS/wfastcgi worker (which would
     run jobs N times) - the dedicated Windows service owns the schedule.
  3. Removed the commented-out duplicate `from_json` filter.
  4. Secret key is required in production - fails loudly instead of silently
     using a hardcoded default.
  5. Session cookies hardened (HttpOnly, SameSite, optional Secure).
  6. Added /health endpoint for IIS Application Initialization warm-up.
  7. Global 404/500 error handlers (no raw exception text leaked to users).
  8. Upload + log directories auto-created on startup.
  9. app.run() debug flag now driven by env var, not hardcoded True.
"""

import os
import json
import logging
import uuid
from datetime import datetime, timedelta

# ---------------------------------------------------------------------------
# Load .env FIRST - before importing any project module.
#
# This MUST stay above `from database import ...` and every other project
# import. Those modules read os.environ at IMPORT time (database.py picks its
# engine from DATABASE_URL, sizes its pool, sets the SQLite busy timeout;
# file_versions.py reads its retention caps), and whatever they read then is
# frozen for the life of the process. Loading .env after them would leave the
# values in os.environ but too late to be seen - DATABASE_URL in particular
# would be SILENTLY IGNORED and the app would stay on SQLite while appearing
# to be configured for SQL Server.
#
# The standalone Windows health-monitor service loads .env itself; the Flask
# worker (and its in-process scheduler) needs the same so values like the
# URL_NTLM_USER / URL_NTLM_PASS AD credentials, DB and SMTP settings are
# available here too. override=False so a real OS/IIS environment variable
# always wins over the file. Silently skipped if python-dotenv isn't installed.
# ---------------------------------------------------------------------------
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env'),
                override=False)
except ImportError:
    pass


from flask import (
    Flask, render_template, session, request,
    redirect, url_for, flash, jsonify, send_file,
)

from markupsafe import Markup, escape

from sqlalchemy import func

from database import init_db, get_db_session
from log_utils import DatedFileHandler, has_dated_handler
from auth import create_admin_user, get_current_user
from csrf_utils import generate_csrf_token, csrf_protect, enforce_csrf
from models import User
from password_reset import generate_temp_password, send_password_reset_email


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# APP_LOG_DIR moves the logs off the application directory. Worth setting when
# the app folder is on a synchronised or replicated volume (OneDrive, DFS, a
# backup agent watching the tree): every log line then becomes sync traffic,
# and with several IIS workers writing continuously that is a measurable drag
# on the whole box. Point it at a plain local path such as D:\logs\appassist.
LOG_DIR = os.environ.get('APP_LOG_DIR') or os.path.join(BASE_DIR, 'logs')
UPLOAD_DIR = os.path.join(BASE_DIR, 'uploads')

os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)


# ---------------------------------------------------------------------------
# Logging - dated files, absolute path, level controlled by env var.
#
# MUST NOT be RotatingFileHandler. IIS runs this app in maxInstances="8"
# separate processes; RotatingFileHandler's rollover RENAMES the active file,
# and on Windows that rename fails with WinError 32 while the other seven
# workers hold the file open. The rollover then silently loses records.
#
# DatedFileHandler writes to app_<date>_p<pid>.log and switches file on a date
# change instead of renaming, so nothing is ever contended. See log_utils.py.
# APP_LOG_RETENTION_DAYS (default 30) controls how long dated files are kept.
# ---------------------------------------------------------------------------
_log_level = logging.DEBUG if os.environ.get('APP_DEBUG_LOG') == '1' else logging.INFO
_log_retention = int(os.environ.get('APP_LOG_RETENTION_DAYS', '30'))

_root_logger = logging.getLogger()
_root_logger.setLevel(_log_level)

# Avoid stacking duplicate handlers when this module is imported twice
# (wfastcgi can sometimes do this on reload; the test suite imports it once
# per session).
if not has_dated_handler(_root_logger, 'app'):
    _file_handler = DatedFileHandler(LOG_DIR, 'app', retention_days=_log_retention)
    _file_handler.setFormatter(logging.Formatter(
        '%(asctime)s - %(levelname)s - %(name)s - %(message)s'
    ))
    _file_handler.setLevel(_log_level)
    _root_logger.addHandler(_file_handler)

logger = logging.getLogger(__name__)
logger.info('=== Application starting (PID %s) ===', os.getpid())


# ---------------------------------------------------------------------------
# Flask app
# ---------------------------------------------------------------------------
app = Flask(__name__)

# Secret key: required in production
_secret = os.environ.get('SESSION_SECRET')
if not _secret:
    if os.environ.get('FLASK_ENV') == 'production':
        raise RuntimeError(
            'SESSION_SECRET environment variable must be set in production'
        )
    _secret = 'dev-secret-key-change-in-production'
    logger.warning('Using insecure default SESSION_SECRET (development only)')
app.secret_key = _secret

# Upload config
app.config['UPLOAD_FOLDER'] = UPLOAD_DIR
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB global floor

# ---------------------------------------------------------------------------
# Upload-size policy
#
# Best practice: a small GLOBAL cap (MAX_CONTENT_LENGTH above) protects every
# endpoint, and only the modules that genuinely handle large files raise the
# limit - per-request, scoped to their own blueprint. Crucially, no module
# mutates the shared MAX_CONTENT_LENGTH, because that silently loosens the cap
# for EVERY other endpoint too (login, project forms, ...).
#
# The three large-upload modules are:
#   * file_monitor         - DTN "Web Data Specification" HTML exports (~18 MB+)
#   * service_now_analysis - ML-analysis incident/change CSV & xlsx exports
#   * utility              - file-split source workbooks
#   * software_inventory   - application installers, GB-scale by design
#
# The map is populated AFTER the blueprints are imported (below) so each value
# comes from that module's own config - the module stays the single source of
# truth for its own limit. Werkzeug enforces request.max_content_length while
# parsing the body; setting it in a before_request hook (not the view) is
# required because the csrf_protect decorator reads request.form first.
# ---------------------------------------------------------------------------
_UPLOAD_LIMITS_BY_BLUEPRINT: dict = {}


@app.before_request
def _scope_upload_limit():
    """Raise the per-request body limit for the large-upload blueprints only,
    leaving the small global cap in force everywhere else."""
    if request.method in ('POST', 'PUT', 'PATCH'):
        limit = _UPLOAD_LIMITS_BY_BLUEPRINT.get(request.blueprint)
        if limit:
            request.max_content_length = limit


# ---------------------------------------------------------------------------
# Application-wide CSRF gate.
#
# MUST be registered after _scope_upload_limit: Flask runs before_request hooks
# in registration order, and the gate reads request.form, which is what parses
# (and therefore size-checks) the body. Registering it first would apply the
# small global cap to the large-upload blueprints and 413 their uploads.
#
# Every POST/PUT/PATCH/DELETE now needs a valid token unless its view carries
# @csrf_exempt. See csrf_utils.enforce_csrf for the reasoning.
# ---------------------------------------------------------------------------
enforce_csrf(app)

# Session / cookie hardening
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    # Set SESSION_COOKIE_SECURE=1 in env when serving over HTTPS only
    SESSION_COOKIE_SECURE=os.environ.get('SESSION_COOKIE_SECURE') == '1',
    PERMANENT_SESSION_LIFETIME=60 * 60 * 8,  # 8 hours
)


# ---------------------------------------------------------------------------
# Jinja filters
# ---------------------------------------------------------------------------
@app.template_filter('from_json')
def from_json_filter(value):
    """Convert a JSON string to a Python object. Returns [] on bad input."""
    if value is None:
        return []
    if not isinstance(value, str):
        return value
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return []


@app.template_filter('nl2br')
def nl2br_filter(value):
    """Escape user-entered text, then convert newlines to <br> tags.

    Safe replacement for the `|replace('\\n','<br>')|safe` pattern: any HTML
    in the stored value is escaped, only the inserted <br> tags are markup.
    """
    if value is None:
        return ''
    normalized = str(value).replace('\r\n', '\n')
    return escape(normalized).replace('\n', Markup('<br>'))


# ---------------------------------------------------------------------------
# CSRF token - exposed to every template so forms (and AJAX callers) can
# submit it back. Blueprints with their own context processor share the same
# session key, so the token is identical app-wide.
# ---------------------------------------------------------------------------
@app.context_processor
def _inject_csrf_token():
    return {'csrf_token': generate_csrf_token()}


# ---------------------------------------------------------------------------
# Database init (idempotent - safe to run in every worker)
# ---------------------------------------------------------------------------
init_db()
with app.app_context():
    create_admin_user()
    # Tower leads used to be typed names; they are now the tower's own members.
    # Match the old text to a member once so the first save of a tower on the
    # new Edit Tower page cannot blank a lead nobody asked to remove.
    from modules.application_support.lead_backfill import backfill_tower_leads
    _lead_session = get_db_session()
    try:
        backfill_tower_leads(_lead_session)
    except Exception:
        _lead_session.rollback()
        logger.exception('Tower lead backfill failed - leads stay as free text.')
    finally:
        _lead_session.close()


# ---------------------------------------------------------------------------
# Blueprints
# ---------------------------------------------------------------------------
from modules.project_management import project_management_bp
from modules.application_support import application_support_bp
from modules.mimp_report import mimp_report_bp
from modules.utility import utility_bp
from modules.service_now_analysis import service_now_analysis_bp
from modules.file_monitor import file_monitor_bp
from modules.application_health_check import application_health_check_bp
from modules.security import security_bp
from modules.todo import todo_bp
from modules.user_profile import user_profile_bp
from modules.activity_tracker import activity_tracker_bp
from modules.resource_utilization import resource_utilization_bp
from modules.resource_tracker import resource_tracker_bp
from modules.people import people_bp
from modules.rota import rota_bp
from modules.code_sentinel import code_sentinel_bp
from modules.software_inventory import software_inventory_bp
# from modules.automate_scheduler import automate_scheduler_bp

app.register_blueprint(project_management_bp,        url_prefix='/project-management')
app.register_blueprint(application_support_bp,       url_prefix='/application-support')
app.register_blueprint(mimp_report_bp,               url_prefix='/mimp-report')
app.register_blueprint(utility_bp,                   url_prefix='/utility')
app.register_blueprint(service_now_analysis_bp,      url_prefix='/service-now-analysis')
app.register_blueprint(file_monitor_bp,              url_prefix='/file-monitor')
app.register_blueprint(application_health_check_bp,  url_prefix='/application-health-check')
app.register_blueprint(security_bp,                  url_prefix='/security')
app.register_blueprint(todo_bp,                      url_prefix='/todo')
app.register_blueprint(user_profile_bp,              url_prefix='/profile')
app.register_blueprint(activity_tracker_bp,          url_prefix='/activity-tracker')
app.register_blueprint(resource_utilization_bp,      url_prefix='/resource-utilization')
app.register_blueprint(resource_tracker_bp,          url_prefix='/resource-tracker')
app.register_blueprint(people_bp,                    url_prefix='/people')
app.register_blueprint(rota_bp,                      url_prefix='/rota')
app.register_blueprint(code_sentinel_bp,             url_prefix='/code-sentinel')
app.register_blueprint(software_inventory_bp,        url_prefix='/software-inventory')
# app.register_blueprint(automate_scheduler_bp,      url_prefix='/automate-scheduler')


# ---------------------------------------------------------------------------
# Populate the per-blueprint upload limits (see the upload-size policy note
# above). Each large-upload module keeps its own limit in its own config, so
# the number lives with the module that needs it - this app just wires it to
# the module's blueprint. Any other blueprint stays bounded by the 16 MB
# global cap. To change a module's limit, edit that module's config (or its
# env var), not this file.
# ---------------------------------------------------------------------------
from modules.service_now_analysis import config as _snow_config
from modules.utility import config as _utility_config
from modules.code_sentinel import config as _code_sentinel_config
from modules.software_inventory import config as _software_inventory_config

_UPLOAD_LIMITS_BY_BLUEPRINT.update({
    'file_monitor':         200 * 1024 * 1024,                    # DTN flow-spec HTML exports
    'service_now_analysis': _snow_config.MAX_CONTENT_LENGTH,      # SNOW_ML_MAX_UPLOAD_MB (default 512 MB)
    'utility':              _utility_config.MAX_CONTENT_LENGTH,   # UTILITY_MAX_UPLOAD_BYTES (default 100 MB)
    'code_sentinel':        _code_sentinel_config.MAX_CONTENT_LENGTH,  # CODESENTINEL_MAX_UPLOAD_MB (default 200 MB) + CI JSON ingest
    # Application installers - GB-scale by design. See that module's config
    # for why this is a very large NUMBER rather than None, and for the IIS
    # requestLimits setting that has to agree with it.
    'software_inventory':   _software_inventory_config.MAX_CONTENT_LENGTH,  # SOFTWARE_INVENTORY_MAX_UPLOAD_MB (default 64 GB)
})


# ---------------------------------------------------------------------------
# Background schedulers - SINGLE-OWNER GUARD
#
# The scheduled jobs (health check, MIMP, certificate expiry, to-do digest /
# purge) MUST run in the dedicated Windows service (health_monitor_app_sched.py)
# ONLY - never inside an IIS / wfastcgi worker or the local dev server.
#
# wfastcgi runs several worker processes, so starting the scheduler in-process
# would fire every job once PER WORKER (duplicate work / emails / DB writes).
# The Windows service starts the schedulers itself - it calls the init_*()
# functions directly and does NOT consult the flag below - so it always owns
# the schedule regardless of how the web app is configured.
#
# A single flag, read from .env, decides whether THIS process (the web app)
# also starts them:
#
#   RUN_SCHEDULERS_IN_APP=false   (DEFAULT) - the web app starts NO schedulers.
#                                  Correct for every IIS deployment; the Windows
#                                  service is the sole scheduler owner.
#   RUN_SCHEDULERS_IN_APP=true    - opt in to run the schedulers inside this
#                                  process. Use ONLY for a no-service, single
#                                  dev/test worker; never under multi-worker IIS.
# ---------------------------------------------------------------------------
_run_schedulers_in_app = os.environ.get(
    'RUN_SCHEDULERS_IN_APP', 'false'
).strip().lower() in ('1', 'true', 'yes', 'on')

if _run_schedulers_in_app:
    logger.info('RUN_SCHEDULERS_IN_APP enabled -> starting background schedulers in this process')
    from modules.application_health_check.health_monitor import init_health_monitoring
    from modules.mimp_report.scheduler import init_mimp_monitoring
    from modules.security.cert_monitor import init_certificate_monitoring
    from modules.todo.scheduler import init_todo_monitoring
    from modules.service_now_analysis.scheduler import init_open_incident_monitoring
    from modules.file_monitor.scheduler import init_file_monitor_alerting
    from modules.rota.scheduler import init_rota_monitoring
    init_health_monitoring()
    init_mimp_monitoring(app)
    init_certificate_monitoring()
    init_todo_monitoring()
    init_open_incident_monitoring()
    init_file_monitor_alerting()
    init_rota_monitoring()
else:
    logger.info('RUN_SCHEDULERS_IN_APP disabled -> background schedulers NOT started here; '
                'the Windows service (health_monitor_app_sched.py) owns the schedule')


# ---------------------------------------------------------------------------
# Health / warm-up endpoint
# Used by IIS Application Initialization to warm the worker after a recycle.
# ---------------------------------------------------------------------------
@app.route('/health')
def health():
    return jsonify(status='ok', pid=os.getpid()), 200


# ---------------------------------------------------------------------------
# Global error handlers - users never see a raw traceback or a default
# IIS/Werkzeug error screen.
#
# Every error renders the same branded page (templates/errors/error.html)
# with a short SUPPORT REFERENCE id. The same id prefixes the log entry, so
# "please contact your administrator and quote REF X" leads straight to the
# stack trace. The exception text itself is shown ON the page only when the
# viewer is a logged-in admin - anonymous/regular users get the friendly
# message only (tracebacks to end users are an information-disclosure
# finding, not a debugging aid).
#
# IIS-side errors that never reach Flask (worker crash, request filtering)
# are covered separately by <httpErrors> in web.config, which serves the
# static fallback page static/error_iis.html.
# ---------------------------------------------------------------------------

def _render_error(code, title, message, exc=None):
    ref = uuid.uuid4().hex[:8].upper()
    if code >= 500:
        logger.exception('[REF %s] %s %s -> %s: %s',
                         ref, request.method, request.path, code, exc)
    else:
        logger.warning('[REF %s] %s %s -> %s',
                       ref, request.method, request.path, code)

    # Show the actual error text to logged-in admins only. Resolving the
    # user can itself fail (e.g. the DB is what broke) - then show nothing.
    detail = None
    if exc is not None:
        try:
            user = get_current_user()
            if user is not None and getattr(user, 'role', None) == 'admin':
                original = getattr(exc, 'original_exception', None) or exc
                detail = f'{type(original).__name__}: {original}'
        except Exception:
            detail = None

    try:
        return render_template(
            'errors/error.html', code=code, title=title, message=message,
            ref=ref, detail=detail,
            now=datetime.now().strftime('%d %b %Y %H:%M'),
        ), code
    except Exception:
        # Absolute last resort - even the error template failed.
        logger.exception('[REF %s] error page itself failed to render', ref)
        return f'{title} (support reference {ref})', code


@app.errorhandler(400)
def _bad_request(e):
    return _render_error(
        400, 'Request could not be processed',
        'The request was invalid or its security token expired. Go back, '
        'refresh the page and try again.')


@app.errorhandler(403)
def _forbidden(e):
    return _render_error(
        403, 'Access denied',
        'You do not have permission to view this page. If you believe you '
        'should, please contact your administrator.')


@app.errorhandler(404)
def _not_found(e):
    return _render_error(
        404, 'Page not found',
        'The page you are looking for does not exist or may have been '
        'moved. Check the address, or head back to the dashboard.')


@app.errorhandler(405)
def _method_not_allowed(e):
    return _render_error(
        405, 'Action not allowed',
        'That action is not available on this page. Go back and try again '
        'from the page you started on.')


@app.errorhandler(413)
def _payload_too_large(e):
    return _render_error(
        413, 'File too large',
        'The file you tried to upload exceeds the size limit for this '
        'module. Reduce the file size or contact your administrator if the '
        'limit needs raising.')


@app.errorhandler(500)
def _server_error(e):
    return _render_error(
        500, 'Something went wrong',
        'An unexpected error occurred while processing your request. The '
        'details have been logged. Please try again - and if the problem '
        'persists, contact your administrator with the reference below.',
        exc=e)


# ===========================================================================
# Routes
# ===========================================================================

@app.route('/')
def intro():
    """Root -> dashboard. The standalone welcome/landing page was retired;
    the Home pane of the dashboard launcher now carries the welcome content."""
    return redirect(url_for('index'))


@app.route('/index')
def index():
    """Homepage with module cards"""
    user = get_current_user()
    public_view = 'public' in request.args
    return render_template('index.html', user=user, public_view=public_view)


@app.route('/login', methods=['GET', 'POST'])
@csrf_protect
def login():
    """User login"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if not username or not password:
            flash('Username and password are required', 'error')
            return render_template('login.html')

        db_session = get_db_session()
        try:
            user = db_session.query(User).filter_by(username=username).first()
            if user and user.check_password(password):
                # A disabled (soft-deleted) account keeps all its historical
                # project data intact but can no longer sign in.
                if not user.is_active:
                    flash('This account has been disabled. Please contact an administrator.', 'error')
                    return render_template('login.html')
                session['user_id'] = user.id
                # First login (or any account without a group set) lands on
                # My Profile: the group drives Resource Utilization and the
                # Application Support member dropdown, so it is mandatory.
                if not (user.user_group or '').strip():
                    flash('Welcome! Setting your Group is mandatory - you '
                          'will land on this profile page on every login '
                          'until it is set. All other details are optional.',
                          'warning')
                    return redirect(url_for('user_profile.profile'))
                flash('Login successful', 'success')
                return redirect(url_for('index'))
            flash('Invalid username or password', 'error')
        finally:
            db_session.close()

    return render_template('login.html')


# ---------------------------------------------------------------------------
# Password-reset throttle.
#
# Best effort by design: the window lives in this worker's memory, so with
# several IIS worker processes an attacker gets one attempt per worker rather
# than one overall. That is enough to stop a repeated lock-out of the same
# account, and it needs no schema change. A durable limit belongs with the
# reset-token flow this endpoint should grow into.
# ---------------------------------------------------------------------------
_RESET_COOLDOWN_MINUTES = 15
_reset_attempts: dict = {}


def _reset_allowed(email: str) -> bool:
    """True if this address has not had a reset in the cooldown window."""
    now = datetime.now()
    cutoff = now - timedelta(minutes=_RESET_COOLDOWN_MINUTES)
    for addr, when in list(_reset_attempts.items()):
        if when < cutoff:
            _reset_attempts.pop(addr, None)
    last = _reset_attempts.get(email.lower())
    return last is None or last < cutoff


def _record_reset(email: str) -> None:
    _reset_attempts[email.lower()] = datetime.now()


@app.route('/forgot-password', methods=['GET', 'POST'])
@csrf_protect
def forgot_password():
    """Self-service password reset.

    The user submits the email address on their account. If it matches an
    active account we generate a strong temporary password, store it, and email
    it with advice to change it after signing in. The response is always the
    same generic message so this endpoint never reveals whether an email is
    registered.
    """
    if request.method == 'POST':
        email = (request.form.get('email') or '').strip()

        # Shown regardless of whether the email matched - no account enumeration.
        generic_msg = ('If that email address matches an account, a new '
                       'temporary password has been sent to it.')

        if not email:
            flash('Please enter your email address', 'error')
            return render_template('forgot_password.html')

        db_session = get_db_session()
        try:
            user = db_session.query(User).filter(
                func.lower(User.email) == email.lower()
            ).first()

            if user and user.is_active and _reset_allowed(email):
                temp_password = generate_temp_password()
                user.set_password(temp_password)

                # Send FIRST, commit second. The old order changed the stored
                # password and only then tried to post it, so a mail failure -
                # or anyone who knows a colleague's address - left that account
                # locked out of a password nobody could read.
                sent = send_password_reset_email(
                    user.email, user.firstname, user.username, temp_password
                )
                if sent:
                    db_session.commit()
                    _record_reset(email)
                else:
                    db_session.rollback()
                    logger.error('Password reset for %s abandoned: the email '
                                 'could not be delivered, so the existing '
                                 'password was left in place.', user.username)
            elif user and user.is_active:
                logger.warning('Password reset for %s ignored: another reset '
                               'was requested less than %d minutes ago.',
                               user.username, _RESET_COOLDOWN_MINUTES)
            else:
                # Unknown or disabled account: do no work, but respond the same.
                logger.info('Password reset requested for unrecognised or '
                            'inactive email.')

            flash(generic_msg, 'info')
            return redirect(url_for('login'))
        except Exception as e:
            db_session.rollback()
            logger.exception('Error processing password reset: %s', e)
            # Still generic to the user.
            flash(generic_msg, 'info')
            return redirect(url_for('login'))
        finally:
            db_session.close()

    return render_template('forgot_password.html')


@app.route('/logout')
def logout():
    """User logout"""
    session.pop('user_id', None)
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))


@app.route('/admin/users')
def admin_users():
    """Admin user management"""
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('index'))

    from modules.user_profile.models import USER_GROUP_LABELS

    db_session = get_db_session()
    try:
        users = db_session.query(User).order_by(User.username).all()
        return render_template('admin/users.html', users=users, user=user,
                               user_group_labels=USER_GROUP_LABELS)
    finally:
        db_session.close()


@app.route('/admin/users/report.xlsx')
def admin_users_report():
    """User Access Report - two-sheet Excel download for administrators.

    Sheet 1 is the count metrics plus the written access rules; sheet 2 lists
    every account with its resolved access level per module. Built in
    modules/user_profile/access_report.py.
    """
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('index'))

    from io import BytesIO
    from modules.user_profile import access_report

    db_session = get_db_session()
    try:
        data = access_report.collect_access_data(db_session)
        generated_by = '{0} {1} ({2})'.format(
            user.firstname or '', user.lastname or '', user.username).strip()
        payload = access_report.build_user_access_workbook(data, generated_by)
    except Exception as e:
        logger.exception('Error building the user access report: %s', e)
        flash('Could not build the user access report', 'error')
        return redirect(url_for('admin_users'))
    finally:
        db_session.close()

    stamp = datetime.now().strftime('%Y%m%d')
    return send_file(
        BytesIO(payload), as_attachment=True,
        download_name='User_Access_Report_{0}.xlsx'.format(stamp),
        mimetype='application/vnd.openxmlformats-officedocument.'
                 'spreadsheetml.sheet')


@app.route('/admin/users/<int:user_id>/role', methods=['POST'])
@csrf_protect
def update_user_role(user_id):
    """Update user role"""
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('index'))

    new_role = request.form.get('role')
    if not new_role:
        flash('Invalid request', 'error')
        return redirect(url_for('admin_users'))

    if new_role not in ('admin', 'project_manager', 'team_member'):
        flash('Invalid role', 'error')
        return redirect(url_for('admin_users'))

    db_session = get_db_session()
    try:
        target_user = db_session.query(User).filter_by(id=user_id).first()
        if target_user:
            target_user.role = new_role
            db_session.commit()
            flash(f'User role updated to {new_role}', 'success')
        else:
            flash('User not found', 'error')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error updating role for user_id=%s: %s', user_id, e)
        flash('Error updating user role', 'error')
    finally:
        db_session.close()

    return redirect(url_for('admin_users'))


@app.route('/change-password', methods=['GET', 'POST'])
@csrf_protect
def change_password():
    """Allow logged-in user to change their password"""
    user = get_current_user()
    if not user:
        flash('You must be logged in to change your password', 'error')
        return redirect(url_for('login'))

    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_new_password = request.form.get('confirm_new_password')

        if not all([current_password, new_password, confirm_new_password]):
            flash('All password fields are required', 'error')
            return render_template('change_password.html', user=user)

        if not user.check_password(current_password):
            flash('Incorrect current password', 'error')
            return render_template('change_password.html', user=user)

        if new_password != confirm_new_password:
            flash('New passwords do not match', 'error')
            return render_template('change_password.html', user=user)

        if len(new_password) < 6:
            flash('Password must be at least 6 characters long', 'error')
            return render_template('change_password.html', user=user)

        db_session = get_db_session()
        try:
            db_user = db_session.query(User).filter_by(id=user.id).first()
            db_user.set_password(new_password)
            db_session.commit()
            flash('Password changed successfully', 'success')
            return redirect(url_for('index'))
        except Exception as e:
            db_session.rollback()
            logger.exception('Error changing password for user %s: %s', user.username, e)
            # Don't leak the raw exception to the user
            flash('An error occurred while changing your password', 'error')
        finally:
            db_session.close()

    return render_template('change_password.html', user=user)


@app.route('/admin/users/<int:user_id>/reset-password', methods=['GET', 'POST'])
@csrf_protect
def reset_password(user_id):
    """Admin password reset"""
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('index'))

    db_session = get_db_session()
    try:
        target_user = db_session.query(User).filter_by(id=user_id).first()
        if not target_user:
            flash('User not found', 'error')
            return redirect(url_for('admin_users'))

        if request.method == 'POST':
            new_password = request.form.get('new_password')
            confirm_password = request.form.get('confirm_password')

            if not new_password or not confirm_password:
                flash('Both password fields are required', 'error')
                return render_template('admin/reset_password.html', target_user=target_user, user=user)

            if new_password != confirm_password:
                flash('Passwords do not match', 'error')
                return render_template('admin/reset_password.html', target_user=target_user, user=user)

            if len(new_password) < 6:
                flash('Password must be at least 6 characters long', 'error')
                return render_template('admin/reset_password.html', target_user=target_user, user=user)

            target_user.set_password(new_password)
            db_session.commit()
            flash(f'Password reset for user {target_user.username}', 'success')
            return redirect(url_for('admin_users'))

        return render_template('admin/reset_password.html', target_user=target_user, user=user)
    finally:
        db_session.close()


@app.route('/admin/users/<int:user_id>/toggle-active', methods=['POST'])
@csrf_protect
def toggle_user_active(user_id):
    """
    Soft-delete / restore a user (admin only).

    Disabling sets ``is_active = False`` instead of removing the row. This is
    the recommended way to off-board someone: every project reference to them
    (projects they created, team memberships, task assignments, notes,
    uploaded documents, Go-Live plans, activity log) stays intact, so existing
    project data is never corrupted - the account simply can no longer sign in
    and is no longer offered for new assignments.
    """
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('index'))

    # An admin must not lock themselves out.
    if user.id == user_id:
        flash('You cannot disable your own account', 'error')
        return redirect(url_for('admin_users'))

    db_session = get_db_session()
    try:
        target_user = db_session.query(User).filter_by(id=user_id).first()
        if not target_user:
            flash('User not found', 'error')
            return redirect(url_for('admin_users'))

        target_user.is_active = not bool(target_user.is_active)
        db_session.commit()
        if target_user.is_active:
            flash(f'User {target_user.username} has been re-enabled', 'success')
        else:
            flash(f'User {target_user.username} has been disabled. Their project '
                  f'data is preserved; they can no longer sign in.', 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error toggling active state for user_id=%s: %s', user_id, e)
        flash('Error updating user', 'error')
    finally:
        db_session.close()

    return redirect(url_for('admin_users'))


@app.route('/admin/users/<int:user_id>/delete', methods=['POST'])
@csrf_protect
def delete_user(user_id):
    """
    Permanently delete a user (admin only).

    This is only safe when the account is not referenced by any other record.
    The database enforces those foreign keys, so if the user still owns or
    appears in project (or any other module's) data the delete raises an
    IntegrityError - we catch it, roll back, and steer the admin to *disable*
    the account instead (see toggle_user_active), which never breaks data.
    """
    from sqlalchemy.exc import IntegrityError

    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('index'))

    # Prevent admin from deleting themselves
    if user.id == user_id:
        flash('You cannot delete your own account', 'error')
        return redirect(url_for('admin_users'))

    db_session = get_db_session()
    try:
        target_user = db_session.query(User).filter_by(id=user_id).first()
        if not target_user:
            flash('User not found', 'error')
            return redirect(url_for('admin_users'))

        username = target_user.username
        db_session.delete(target_user)
        db_session.commit()
        flash(f'User {username} has been permanently deleted', 'success')
    except IntegrityError:
        db_session.rollback()
        flash('This user is referenced by existing project (or other) records, '
              'so they cannot be permanently deleted without corrupting that '
              'data. Use "Disable" instead to off-board them safely.', 'error')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error deleting user %s: %s', user_id, e)
        flash('Error deleting user', 'error')
    finally:
        db_session.close()

    return redirect(url_for('admin_users'))


@app.route('/register', methods=['GET', 'POST'])
@csrf_protect
def register():
    """User registration"""
    if request.method == 'POST':
        username = request.form.get('username')
        firstname = request.form.get('firstname')
        lastname = request.form.get('lastname')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        if not all([username, firstname, lastname, email, password, confirm_password]):
            flash('All fields are required', 'error')
            return render_template('register.html')

        if password != confirm_password:
            flash('Passwords do not match', 'error')
            return render_template('register.html')

        if len(password) < 6:
            flash('Password must be at least 6 characters long', 'error')
            return render_template('register.html')

        db_session = get_db_session()
        try:
            existing_user = db_session.query(User).filter(
                (User.username == username) | (User.email == email)
            ).first()

            if existing_user:
                flash('Username or email already exists', 'error')
                return render_template('register.html')

            user = User(
                username=username,
                firstname=firstname,
                lastname=lastname,
                email=email,
                role='team_member',  # default role
            )
            user.set_password(password)
            db_session.add(user)
            db_session.commit()

            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db_session.rollback()
            logger.exception('Error registering user %s: %s', username, e)
            flash('An error occurred during registration', 'error')
        finally:
            db_session.close()

    return render_template('register.html')


# ===========================================================================
# Local development entry point
# (NOT used when running under IIS / wfastcgi - wfastcgi imports `app` directly)
# ===========================================================================
if __name__ == '__main__':
    debug_mode = os.environ.get('FLASK_DEBUG') == '1'
    app.run(host='0.0.0.0', port=5002, debug=True)