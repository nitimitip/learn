"""
health_monitor_app_sched_mssql.py - SQL Server-hard-wired scheduler service.

WHY THIS FILE EXISTS
--------------------
health_monitor_app_sched.py already runs against SQL Server unchanged - set
DATABASE_URL in .env (see mssql.env) and database.py builds a pooled pyodbc
engine that every scheduler's jobstore and every job reuses. That is the
RECOMMENDED way to switch; this file then stays unused.

This file is the service-side counterpart of mssql_database.py, for a
deployment that wants MSSQL hard-wired rather than env-selected. It exists to
close one silent failure mode: when the SCM starts the service with a missing
or typo'd .env, database.py quietly falls back to sqlite:///project_management.db
- the service then runs every sweep against a fresh, EMPTY local file: no
health checks fire, no alerts send, and nothing errors anywhere. This wrapper
makes that impossible:

  * It loads .env, then imports ``mssql_database`` - which REFUSES to start
    (loud RuntimeError, logged to the service log and the Windows event log)
    unless DATABASE_URL is an mssql+pyodbc:// URL.
  * It installs ``mssql_database`` as ``sys.modules['database']`` BEFORE any
    scheduler module is imported, so every ``from database import engine /
    get_db_session / init_db / Base`` in the whole app binds to the MSSQL-only
    module. An SQLite fallback cannot happen in this process, by construction.

Everything else - the service class, logging, sweep cadence, all six
schedulers, heartbeats, clean shutdown - is REUSED from
health_monitor_app_sched.py (imported below), not copied. Keep that file
authoritative; this wrapper should never need to change when a scheduler is
added there.

USAGE
-----
Use ONE of the two service files, never both. Both register the SAME service
name ("ApplicationDashboardScheduler"), so installing this one replaces the
standard registration (run the standard file's ``remove`` first, or just
``install`` this one over it):

    cd /d C:\\Path\\To\\APPASSIST
    python health_monitor_app_sched.py remove        (if previously installed)
    python health_monitor_app_sched_mssql.py install
    net start ApplicationDashboardScheduler

`debug` / `stop` / `remove` work exactly as documented in
health_monitor_app_sched.py. Service account, recovery and startup-type
guidance from that file applies unchanged.

DATABASE_URL comes from .env (preferred) or the SCM environment; if unset
entirely, mssql_database.py's default (local SQLEXPRESS, trusted connection)
applies - matching migrate_sqlite_to_mssql.py's default target.
"""

import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

# Importing the standard service module does the shared bootstrap exactly
# once: seeds the sweep-cadence env vars (BEFORE any scheduler import),
# chdirs to the project root, and configures the dated daily log handler.
import health_monitor_app_sched as _base

import servicemanager
import win32serviceutil

# .env must be loaded BEFORE mssql_database is imported: that module reads
# DATABASE_URL and builds its engine at import time. (SvcDoRun loads .env
# again later; python-dotenv's override=False makes that a no-op.)
_base._load_dotenv_if_present()

try:
    import mssql_database
except RuntimeError as exc:
    # Wrong/non-MSSQL DATABASE_URL. Fail the service start LOUDLY in both the
    # scheduler log and the Windows event log, instead of falling back.
    _msg = ('MSSQL scheduler service refused to start: %s' % exc)
    _base.logger.error(_msg)
    try:
        servicemanager.LogErrorMsg(_msg)
    except Exception:
        pass  # not running under the SCM (e.g. CLI) - the raise still shows
    raise

# THE POINT OF THIS FILE: every later `import database` / `from database
# import ...` anywhere in the app (schedulers, models, jobstores) now binds
# to the MSSQL-only module. Must happen before _start_schedulers() runs.
sys.modules['database'] = mssql_database


class SchedulerServiceMssql(_base.SchedulerService):
    """The standard scheduler service, hard-bound to SQL Server."""

    # Same service NAME as the standard file so exactly one scheduler service
    # can exist per host; the display name/description say which flavour is
    # registered.
    _svc_name_ = _base.SchedulerService._svc_name_
    _svc_display_name_ = "Application Dashboard Scheduler (SQL Server)"
    _svc_description_ = (
        "Runs APScheduler-based background jobs for the Application "
        "Dashboard (health check, MIMP, certificate expiry, to-do digest, "
        "file-monitor alerts, open-incident digest) against SQL Server. "
        "Hard-wired via mssql_database.py: refuses to start on a non-MSSQL "
        "DATABASE_URL instead of falling back to SQLite."
    )


if __name__ == '__main__':
    if len(sys.argv) == 1:
        # Started by the Service Control Manager (no CLI args) - run as service
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(SchedulerServiceMssql)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        # Called from the command line (install / start / stop / debug / remove)
        win32serviceutil.HandleCommandLine(SchedulerServiceMssql)
