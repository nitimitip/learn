"""
health_monitor_app_sched.py - Native Windows service wrapper around the schedulers.

Location
--------
This file lives in the APPASSIST project ROOT (next to main_app.py,
database.py and the modules/ package). That matters: the service must be
able to ``import database`` and ``import modules.application_health_check``
/ ``import modules.mimp_report``. Those packages resolve only when the
project root is on sys.path, so the root is exactly where this script
belongs. (It used to live under modules/application_health_check/, where
BASE_DIR pointed at the sub-folder and those imports could not resolve.)

Uses pywin32 (which ships with Anaconda) to register the schedulers as a
real Windows service - shows up in services.msc, controllable with
`net start` / `net stop`, automatically restarted by the Service Control
Manager on crash.

No third-party tools required. No NSSM, no srvany, nothing to install.

What the service does
---------------------
On start:
  1. Loads .env so the service receives its DB / SMTP configuration.
  2. Applies scheduler defaults before importing scheduler modules: health
     sweep every minute, MIMP every 30 minutes. Explicit settings win.
  3. Calls database.init_db() to ensure the schema and indexes exist.
  4. Calls health_monitor.init_health_monitoring() which starts an
     APScheduler BackgroundScheduler running the probe, email and retention jobs:
        - The sweep job (every minute by default) -- finds reports whose
          next_run_time has elapsed and runs them.
        - The retention purge (daily at 02:00 local) -- deletes
          HealthCheckExecution rows older than 5 days.
  5. Initialises MIMP monitoring under a Flask app-context. Its sweep
     (also every 30 min) finds MIMP reports whose next execution time
     has elapsed and runs them, plus a daily maintenance job at 02:00.
  6. Initialises the remaining best-effort schedulers, each with its own
     jobstore table (a failure in one never blocks the others):
        - certificate expiry alerting (daily, 60/30-day tiers)
        - to-do morning digest + retention purge (daily)
        - file-monitor pending-file alerts (daily, 07:30 local)
        - ServiceNow open-incident afternoon digest (daily, 14:00 local)
  7. Blocks waiting for the SCM stop signal, logging an INFO-level
     heartbeat every minute so the log file shows operational signal.

On stop:
  Calls shutdown_health_monitoring() / shutdown_mimp_monitoring() so
  APScheduler's in-flight job (if any) gets a chance to finish and the
  SQLAlchemy job-stores close cleanly. No half-written DB rows.

Both schedulers run in THIS one process. They use SEPARATE jobstore
tables (apscheduler_jobs vs apscheduler_jobs_mimp) so neither loads or
fires the other's jobs.

INSTALL (run from elevated cmd, from the APPASSIST root):
    cd /d C:\\Path\\To\\APPASSIST
    python health_monitor_app_sched.py install

START:
    net start ApplicationDashboardScheduler
        - or -
    python health_monitor_app_sched.py start

STOP:
    net stop ApplicationDashboardScheduler

REMOVE:
    python health_monitor_app_sched.py remove

DEBUG (run in foreground, see exceptions on the console):
    python health_monitor_app_sched.py debug


After `install`, open services.msc and:
    1. Find "Application Dashboard Scheduler"
    2. Properties -> Log On tab -> set the service account that has DB access
       (or "Local System" if it has sufficient DB credentials via env vars).
    3. Properties -> Recovery tab -> set First / Second / Subsequent failures
       to "Restart the Service" with a 1-minute delay.
    4. Properties -> General tab -> Startup type: Automatic (Delayed Start)
       so the service waits until the OS finishes booting before starting.

Avoiding a duplicate sweeper
----------------------------
The Flask app, when alive under IIS, can ALSO start an APScheduler sweep
(via init_health_monitoring() / init_mimp_monitoring() at app boot). The
atomic claim in _claim_report_for_run (health check) and the per-minute
DB lock (MIMP) prevent double-firing, but it is wasteful to have two
sweepers running. To suppress the Flask-side sweepers and let the service
own the schedule, leave this env var at its default (or set it explicitly):

    RUN_SCHEDULERS_IN_APP=false

main_app.py already honours that var (default false = the web app starts no
schedulers). This service ignores it on purpose -- it is the dedicated
scheduler owner and always starts the jobs.
"""

import os
import re
import sys
import socket
import datetime
import logging


# ---------------------------------------------------------------------------
# Make sure imports work whether run by SCM or interactively.
# BASE_DIR is the APPASSIST project root (this file lives there), so
# `import database` and `import modules.*` resolve.
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

# When started by SCM, current directory is C:\Windows\System32. Fix that.
os.chdir(BASE_DIR)


# ---------------------------------------------------------------------------
# Crash-proof boot breadcrumbs -- written BEFORE the pywin32 imports and the
# real logging setup, because a failure in either of those otherwise leaves
# no trace at all (the SCM just reports the generic Error 1053). If
# service_boot.log is missing after a start attempt, the process never
# launched (ImagePath / file-permission problem, not a Python problem).
# ---------------------------------------------------------------------------
_BOOT_LOG = os.path.join(BASE_DIR, 'logs', 'scheduler_log', 'service_boot.log')


def _boot_trace(msg):
    try:
        os.makedirs(os.path.dirname(_BOOT_LOG), exist_ok=True)
        with open(_BOOT_LOG, 'a', encoding='utf-8') as fh:
            fh.write('%s | pid=%s | %s\n' % (
                datetime.datetime.now().isoformat(' '), os.getpid(), msg))
    except Exception:
        pass  # never let the breadcrumb writer kill the service


_boot_trace('interpreter up: exe=%s | argv=%s | python=%s | user=%s | cwd=%s'
            % (sys.executable, sys.argv, sys.version.split()[0],
               os.environ.get('USERNAME', '?'), os.getcwd()))


# ---------------------------------------------------------------------------
# Conda DLL search-path bootstrap.
#
# The SCM launches bare python.exe under LocalSystem with NO conda
# activation, so <conda>\Library\bin is not on the DLL search path. On
# Python 3.8+ extension modules resolve their dependent DLLs only from the
# executable's directory, the system dirs and directories registered via
# os.add_dll_directory() -- so imports like sqlite3 (_sqlite3.pyd needs
# sqlite3.dll from Library\bin) fail with "DLL load failed while importing
# _sqlite3" even though the same import works in an activated shell.
#
# Register here every directory `conda activate` would prepend, BEFORE the
# pywin32 imports and before any app module (database.py imports sqlite3 at
# module level) can be dragged in. PATH is prepended too for child
# processes and ctypes.LoadLibrary callers.
# ---------------------------------------------------------------------------
def _bootstrap_conda_dll_dirs():
    # sys.base_prefix is the interpreter's install dir (E:\Anaconda3) no
    # matter which exe hosts us; dirname(sys.executable) would point at
    # ...\site-packages\win32 under pythonservice.exe hosting and the
    # bootstrap would silently register nothing. Keep both roots -- they
    # are identical under python.exe hosting and the loop dedupes.
    roots = []
    for root in (sys.base_prefix, sys.prefix, os.path.dirname(sys.executable)):
        if root and root not in roots:
            roots.append(root)
    candidates = []
    for conda_root in roots:
        for d in (
            conda_root,
            os.path.join(conda_root, 'Library', 'mingw-w64', 'bin'),
            os.path.join(conda_root, 'Library', 'usr', 'bin'),
            os.path.join(conda_root, 'Library', 'bin'),
            os.path.join(conda_root, 'Scripts'),
            os.path.join(conda_root, 'DLLs'),
        ):
            if d not in candidates:
                candidates.append(d)
    added = []
    for d in candidates:
        if not os.path.isdir(d):
            continue
        try:
            os.add_dll_directory(d)
            added.append(d)
        except (OSError, AttributeError):
            pass
    path_parts = os.environ.get('PATH', '').split(os.pathsep)
    prepend = [d for d in candidates
               if os.path.isdir(d) and d not in path_parts]
    if prepend:
        os.environ['PATH'] = os.pathsep.join(prepend + path_parts)
    _boot_trace('conda DLL dirs registered: %s' % (added or 'none'))


_bootstrap_conda_dll_dirs()


# ---------------------------------------------------------------------------
# Sweep cadence - 30 minutes for BOTH schedulers.
#
# These env vars MUST be seeded before the scheduler modules are imported
# (health_monitor reads HEALTH_SWEEP_INTERVAL_MIN, and mimp_report.scheduler
# reads MIMP_SWEEP_INTERVAL_SEC, at module-import time). setdefault is used
# so an explicitly pre-set OS env var still wins; the later .env load runs
# with override=False, so it cannot lower these back down.
# ---------------------------------------------------------------------------
SWEEP_INTERVAL_MINUTES = 30
# Defaults are applied by _start_schedulers after loading .env.


try:
    import win32serviceutil
    import win32service
    import win32event
    import servicemanager
except Exception:
    import traceback
    _boot_trace('FATAL: pywin32 import failed:\n' + traceback.format_exc())
    raise
_boot_trace('pywin32 imports OK')


# ---------------------------------------------------------------------------
# Logging - one file per DAY in <BASE_DIR>/logs/scheduler_log/, with files
# older than LOG_RETENTION_DAYS deleted automatically.
#
# Each calendar day is written DIRECTLY to its own dated file,
# scheduler_<YYYY-MM-DD>.log. The handler switches to a fresh dated file the
# first time a record is emitted on a new local date. There is NO single
# rolling scheduler.log, so no one file can grow without bound - and there is
# no midnight file-rename (which TimedRotatingFileHandler does and which, under
# the Windows SCM, can fail on a briefly-held handle and silently leave one log
# growing for days).
#
# _purge_old_logs() deletes dated files older than LOG_RETENTION_DAYS. It runs
# at startup AND each time the handler switches day, so cleanup happens whether
# the service restarts often or runs for weeks.
# ---------------------------------------------------------------------------
LOG_DIR = os.path.join(BASE_DIR, 'logs')
SCHED_LOG_DIR = os.path.join(LOG_DIR, 'scheduler_log')
os.makedirs(SCHED_LOG_DIR, exist_ok=True)

LOG_RETENTION_DAYS = 5
# Dated files look like scheduler_2026-06-01.log
_DATED_LOG_RE = re.compile(r'^scheduler_(\d{4}-\d{2}-\d{2})\.log$')


def _purge_old_logs():
    """Delete scheduler_<date>.log files older than LOG_RETENTION_DAYS.

    Date is taken from the filename (not mtime), so it is robust against
    file-copy timestamp changes. Today's file (scheduler_<today>.log) has a
    date that is never < cutoff, so the active file is never removed.
    Best-effort: any single failure is logged and skipped rather than killing
    the service."""
    cutoff = datetime.date.today() - datetime.timedelta(days=LOG_RETENTION_DAYS)
    try:
        entries = os.listdir(SCHED_LOG_DIR)
    except OSError:
        return
    for name in entries:
        m = _DATED_LOG_RE.match(name)
        if not m:
            continue
        try:
            file_date = datetime.datetime.strptime(m.group(1), '%Y-%m-%d').date()
        except ValueError:
            continue
        if file_date < cutoff:
            try:
                os.remove(os.path.join(SCHED_LOG_DIR, name))
            except OSError:
                # Logger may not be configured yet at first call; ignore.
                pass


class _DatedDailyHandler(logging.FileHandler):
    """Write straight to scheduler_<YYYY-MM-DD>.log, switching to a fresh dated
    file the first time a record is emitted on a new local date.

    This avoids both a single ever-growing scheduler.log and the midnight
    file-rename that TimedRotatingFileHandler performs (which can fail under the
    Windows SCM if the file handle is briefly held, leaving one log to grow
    unbounded). Old dated files are purged on each day switch."""

    @staticmethod
    def _path_for(d):
        return os.path.join(SCHED_LOG_DIR, f'scheduler_{d.isoformat()}.log')

    def __init__(self, encoding='utf-8'):
        self._current_date = datetime.date.today()
        super().__init__(self._path_for(self._current_date),
                         mode='a', encoding=encoding, delay=False)

    def emit(self, record):
        # On the first record of a new day, close today's file and open the
        # next dated one, then purge anything past the retention window. The
        # logging framework holds this handler's lock around emit(), so the
        # stream switch is serialised against concurrent log calls.
        today = datetime.date.today()
        if today != self._current_date:
            self._current_date = today
            try:
                if self.stream:
                    self.stream.close()
            finally:
                self.stream = None
            self.baseFilename = os.path.abspath(self._path_for(today))
            self.stream = self._open()
            _purge_old_logs()
        super().emit(record)


_handler = _DatedDailyHandler(encoding='utf-8')
_handler.setFormatter(logging.Formatter(
    '%(asctime)s - %(levelname)s - %(name)s - %(message)s'
))

_root = logging.getLogger()
_root.setLevel(logging.INFO)
if not any(isinstance(h, _DatedDailyHandler) for h in _root.handlers):
    _root.addHandler(_handler)

# Clean out anything already past the retention window at startup.
_purge_old_logs()

logger = logging.getLogger('scheduler_winservice')


# ---------------------------------------------------------------------------
# .env loader -- SCM does not inherit the user shell environment
# ---------------------------------------------------------------------------
def _load_dotenv_if_present() -> None:
    """Best-effort .env loader so the service sees the same env vars the
    Flask app does. Silently skipped if no .env exists or python-dotenv
    is not installed -- the service will then rely on whatever env vars
    the SCM passes through (typically very few)."""
    dotenv_path = os.path.join(BASE_DIR, '.env')
    if not os.path.isfile(dotenv_path):
        logger.info('.env not found at %s -- relying on SCM-provided env.',
                    dotenv_path)
        return
    try:
        from dotenv import load_dotenv  # type: ignore
        load_dotenv(dotenv_path, override=False)
        logger.info('.env loaded from %s', dotenv_path)
    except ImportError:
        # Manual parse fallback so we don't hard-depend on python-dotenv.
        try:
            with open(dotenv_path, 'r', encoding='utf-8') as fh:
                for line in fh:
                    line = line.strip()
                    if not line or line.startswith('#') or '=' not in line:
                        continue
                    key, _, value = line.partition('=')
                    key = key.strip()
                    value = value.strip().strip('"').strip("'")
                    if key and key not in os.environ:
                        os.environ[key] = value
            logger.info('.env loaded (manual parse) from %s', dotenv_path)
        except Exception:
            logger.exception('Failed to parse .env at %s -- continuing.',
                             dotenv_path)


# ===========================================================================
# Service class
# ===========================================================================
class SchedulerService(win32serviceutil.ServiceFramework):
    # These three attributes register the service with Windows
    _svc_name_         = "ApplicationDashboardScheduler"
    _svc_display_name_ = "Application Dashboard Scheduler"
    _svc_description_  = ("Runs APScheduler-based background jobs for the "
                          "Application Dashboard - both the Application "
                          "Health Check and MIMP Report sweeps (every 30 "
                          "min), independent of IIS.")

    # Host the service under the full python.exe interpreter instead of
    # pywin32's pythonservice.exe stub. pythonservice.exe must locate
    # python3x.dll / pywintypes3x.dll via the SERVICE account's PATH (bare
    # under LocalSystem), which is the classic cause of "Error 1053 /
    # Event 7009: timeout waiting for the service to connect" even though
    # `debug` mode works. python.exe resolves its own DLLs next to itself,
    # so hosting under it removes that whole failure class. The no-args
    # branch in __main__ below (PrepareToHostSingle + dispatcher) is what
    # makes this hosting mode work. Takes effect on the NEXT `install` --
    # run `python health_monitor_app_sched.py remove` then `... install`
    # to rewrite the registered ImagePath.
    _exe_name_ = sys.executable
    _exe_args_ = '"{}"'.format(os.path.abspath(__file__))

    # 60-second heartbeat -- frequent enough to detect a hang, infrequent
    # enough to keep the log readable.
    HEARTBEAT_SECONDS = 60

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        # Event object the SCM will signal when it wants us to stop
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)
        socket.setdefaulttimeout(60)
        self.running = False

    # -----------------------------------------------------------------------
    # SCM callbacks
    # -----------------------------------------------------------------------
    def SvcStop(self):
        """Called by the SCM when the service is being stopped."""
        logger.info('SvcStop received - shutting down')
        # Tell the SCM we acknowledge the stop and need a moment to
        # tidy up. Without this Windows may kill us at the 30 s mark.
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING, waitHint=30000)
        self.running = False
        win32event.SetEvent(self.stop_event)

    def SvcDoRun(self):
        """Called by the SCM when the service is being started."""
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, ''),
        )
        logger.info('===== Scheduler service starting (PID %s) =====',
                    os.getpid())
        _load_dotenv_if_present()
        logger.info('Sweep settings: health=%s minutes, MIMP=%s seconds.',
                    os.environ.get('HEALTH_SWEEP_INTERVAL_MIN', '1'),
                    os.environ.get('MIMP_SWEEP_INTERVAL_SEC', str(SWEEP_INTERVAL_MINUTES * 60)))

        try:
            self._start_schedulers()
            self.running = True
            logger.info('Scheduler service running. Waiting for stop signal...')

            # Block here forever (or until stop_event is signalled).
            # APScheduler runs jobs in its own daemon threads, which keep
            # ticking as long as this main thread is alive.
            heartbeat_ms = self.HEARTBEAT_SECONDS * 1000
            tick = 0
            while self.running:
                rc = win32event.WaitForSingleObject(self.stop_event, heartbeat_ms)
                if rc == win32event.WAIT_OBJECT_0:
                    break  # stop signalled
                tick += 1
                # Cheap, low-volume heartbeat. Once every 5 ticks (~5 min)
                # we also log scheduler.get_jobs() counts so the log file
                # documents that the sweep + retention jobs are still
                # registered.
                if tick % 5 == 0:
                    self._log_job_status()
                else:
                    logger.info(
                        'Heartbeat - scheduler service alive (PID %s, tick %d)',
                        os.getpid(), tick,
                    )

        except Exception as e:
            logger.exception('Fatal error in scheduler service: %s', e)
            servicemanager.LogErrorMsg(
                f"Scheduler service crashed: {e}\n"
                f"See the dated logs in {SCHED_LOG_DIR} for details."
            )
            raise
        finally:
            # Stop APScheduler cleanly. Will let any in-flight job finish
            # (wait=True inside shutdown_health_monitoring is set to
            # False by design so a hung SSH/DB check can't block our stop
            # -- but the SQLAlchemy job-store still flushes).
            self._stop_schedulers()
            logger.info('===== Scheduler service stopped =====')

    # -----------------------------------------------------------------------
    # Actual work
    # -----------------------------------------------------------------------
    def _start_schedulers(self):
        """Initialize the database and start all background schedulers."""
        # Import here, not at module top - so that `install` / `remove` /
        # `debug` commands don't drag in the whole app stack just to register.
        _load_dotenv_if_present()
        os.environ.setdefault('HEALTH_SWEEP_INTERVAL_MIN', '1')
        os.environ.setdefault('MIMP_SWEEP_INTERVAL_SEC', str(SWEEP_INTERVAL_MINUTES * 60))
        from flask import Flask
        from database import init_db

        app = Flask(__name__)
        app.config['SECRET_KEY'] = os.environ.get('SESSION_SECRET',
                                                  'scheduler-internal')

        logger.info('Initializing database...')
        init_db()

        logger.info('Initializing health monitoring (sweep every %d min)...',
                    int(os.environ['HEALTH_SWEEP_INTERVAL_MIN']))
        from modules.application_health_check.health_monitor import (
            init_health_monitoring,
        )
        init_health_monitoring()

        # MIMP monitoring is best-effort -- if its module is missing or
        # raises, we still want the health-check sweep to keep running.
        try:
            logger.info('Initializing MIMP monitoring (sweep every %d min)...',
                        SWEEP_INTERVAL_MINUTES)
            from modules.mimp_report.scheduler import init_mimp_monitoring
            with app.app_context():
                init_mimp_monitoring(app)
        except Exception:
            logger.exception('MIMP monitoring failed to start -- continuing '
                             'without it.')

        # Certificate expiry alerting is best-effort too -- a daily cron job
        # with TWO-TIER thresholds: it warns the owning team + security
        # distribution once a certificate is within 60 days of expiry, and
        # escalates (copying the team's manager[s]) once it is within 30 days.
        # Both tiers are handled by the single daily run -- the 60-day sweep
        # already covers the 30-day window, and the manager escalation is
        # decided per certificate inside run_certificate_expiry_check(). The
        # per-row once-per-day cadence is enforced inside the check itself, so
        # the alert repeats every day until renewal and a daily trigger is
        # correct and idempotent. Thresholds are overridable via
        # CERT_ALERT_WARN_DAYS / CERT_ALERT_MANAGER_DAYS.
        try:
            logger.info('Initializing certificate expiry monitoring...')
            from modules.security.cert_monitor import init_certificate_monitoring
            init_certificate_monitoring()
        except Exception:
            logger.exception('Certificate monitoring failed to start -- '
                             'continuing without it.')

        # To-do monitoring is best-effort too -- a daily morning digest emailing
        # each user their open items (highlighting due-today / overdue) plus a
        # daily retention purge of completed items older than 4 months.
        try:
            logger.info('Initializing to-do monitoring...')
            from modules.todo.scheduler import init_todo_monitoring
            init_todo_monitoring()
        except Exception:
            logger.exception('To-do monitoring failed to start -- '
                             'continuing without it.')

        # File Monitor pending-file alerting is best-effort too -- a daily
        # morning sweep (07:30 local by default) that probes each active,
        # alert-enabled file-monitor report and emails its recipients when
        # files from previous days are still pending or duplicate copies were
        # lost in transit. The per-day alert log makes it idempotent.
        try:
            logger.info('Initializing file-monitor pending-file alerting...')
            from modules.file_monitor.scheduler import init_file_monitor_alerting
            init_file_monitor_alerting()
        except Exception:
            logger.exception('File-monitor alerting failed to start -- '
                             'continuing without it.')

        # ServiceNow open-incident afternoon digest is best-effort too -- a daily
        # cron (14:00 local by default) that emails a professional per-assignment-
        # group open-incident summary for the most recent upload to the groups
        # that have escalation contacts configured. No upload / no contacts is a
        # clean no-op, so a daily trigger is safe.
        try:
            logger.info('Initializing open-incident afternoon digest...')
            from modules.service_now_analysis.scheduler import init_open_incident_monitoring
            init_open_incident_monitoring()
        except Exception:
            logger.exception('Open-incident monitoring failed to start -- '
                             'continuing without it.')

        # Rota is best-effort too -- an INTERVAL job (every 10 minutes by
        # default, not a daily cron) that alerts on a missed sign-in, a missed
        # sign-off and a missed shift. It has to be an interval: a member has
        # 15 minutes from the start of a shift to sign in, so a nightly sweep
        # would report a 07:00 miss the following morning. Each alert is
        # claimed through a UNIQUE row in rota_alerts before it is sent, so
        # running it here and in a web worker cannot duplicate an email.
        try:
            logger.info('Initializing rota monitoring...')
            from modules.rota.scheduler import init_rota_monitoring
            init_rota_monitoring()
        except Exception:
            logger.exception('Rota monitoring failed to start -- '
                             'continuing without it.')

        logger.info('All schedulers started successfully')

    def _stop_schedulers(self):
        """Shut down APScheduler cleanly on service stop.

        Each shutdown hook is called only if its module was actually imported
        during _start_schedulers (checked via sys.modules). Re-importing here
        would drag the whole app stack in during stop -- and if startup itself
        died on an import error, every one of these would crash again with the
        same error, burying the real traceback under six copies of it."""
        hooks = [
            ('modules.application_health_check.health_monitor',
             'shutdown_health_monitoring', 'Health monitoring'),
            ('modules.mimp_report.scheduler',
             'shutdown_mimp_monitoring', 'MIMP monitoring'),
            ('modules.security.cert_monitor',
             'shutdown_certificate_monitoring', 'Certificate monitoring'),
            ('modules.todo.scheduler',
             'shutdown_todo_monitoring', 'To-do monitoring'),
            ('modules.service_now_analysis.scheduler',
             'shutdown_open_incident_monitoring', 'Open-incident monitoring'),
            ('modules.file_monitor.scheduler',
             'shutdown_file_monitor_alerting', 'File-monitor alerting'),
            ('modules.rota.scheduler',
             'shutdown_rota_monitoring', 'Rota monitoring'),
        ]
        for module_path, func_name, label in hooks:
            mod = sys.modules.get(module_path)
            if mod is None:
                logger.info('%s was never started -- nothing to shut down.',
                            label)
                continue
            try:
                shutdown = getattr(mod, func_name, None)
                if shutdown is None:
                    continue
                shutdown()
                logger.info('%s shut down cleanly.', label)
            except Exception:
                logger.exception('Error shutting down %s (suppressed -- '
                                 'service is stopping anyway).', label)

    def _log_job_status(self):
        """Periodic operational snapshot: which jobs are registered and
        when they're next due, for BOTH schedulers. Helps confirm at a
        glance that the sweeps are still alive."""
        self._log_one_scheduler(
            'modules.application_health_check.health_monitor', '_scheduler',
            'health-check',
        )
        self._log_one_scheduler(
            'modules.mimp_report.scheduler', '_scheduler', 'MIMP',
        )
        self._log_one_scheduler(
            'modules.todo.scheduler', '_scheduler', 'to-do',
        )
        self._log_one_scheduler(
            'modules.security.cert_monitor', '_scheduler', 'certificate',
        )
        self._log_one_scheduler(
            'modules.file_monitor.scheduler', '_scheduler', 'file-monitor',
        )
        self._log_one_scheduler(
            'modules.service_now_analysis.scheduler', '_scheduler',
            'open-incident',
        )

    def _log_one_scheduler(self, module_path: str, attr: str, label: str):
        try:
            import importlib
            mod = importlib.import_module(module_path)
            scheduler = getattr(mod, attr, None)
            if scheduler is None or not getattr(scheduler, 'running', False):
                logger.warning('Heartbeat: %s APScheduler is NOT running.', label)
                return
            jobs = scheduler.get_jobs()
            summary = ', '.join(
                f"{j.id}@{j.next_run_time.strftime('%H:%M:%S') if j.next_run_time else 'idle'}"
                for j in jobs
            ) or 'no jobs'
            logger.info('Heartbeat (PID %s) [%s]: %d job(s): %s',
                        os.getpid(), label, len(jobs), summary)
        except Exception:
            logger.exception('Heartbeat job-status check crashed for %s '
                             '(suppressed).', label)


# ===========================================================================
# Entry point - dispatches install / start / stop / remove / debug
# ===========================================================================
if __name__ == '__main__':
    if len(sys.argv) == 1:
        # Started by the Service Control Manager (no CLI args) - run as service
        _boot_trace('connecting to service control dispatcher (SCM launch)')
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(SchedulerService)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        # Called from the command line (install / start / stop / debug / remove)
        win32serviceutil.HandleCommandLine(SchedulerService)
