/* CHHMax Demand - Proof of Concept build.
   ---------------------------------------------------------------------------
   Helpers, reference data and the in-memory store. This file holds everything
   that is not a screen: the role matrix, the reporting-period arithmetic, the
   email template catalogue and the search logic.

   Nothing here talks to a network. Every figure comes from poc-data.js, which
   is generated sample data. */

(function (global) {
  "use strict";

  var POC = global.POC || {};
  global.POC = POC;

  /* =======================================================================
     Small helpers
     ======================================================================= */

  function esc(value) {
    if (value === null || value === undefined) { return ""; }
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  /* Matches the application's `num` Jinja filter: one decimal place, grouped
     thousands, and a dash where there is no value at all. */
  function num(value, places) {
    if (value === null || value === undefined || value === "") { return "-"; }
    var number = Number(value);
    if (isNaN(number)) { return String(value); }
    return number.toLocaleString("en-GB", {
      minimumFractionDigits: places === undefined ? 1 : places,
      maximumFractionDigits: places === undefined ? 1 : places
    });
  }

  var MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  function pad(value) { return (value < 10 ? "0" : "") + value; }

  function parseDate(value) {
    if (!value) { return null; }
    if (value instanceof Date) { return value; }
    var parts = String(value).split(/[-T:]/).map(Number);
    return new Date(parts[0], (parts[1] || 1) - 1, parts[2] || 1,
                    parts[3] || 0, parts[4] || 0, parts[5] || 0);
  }

  /* "31 Aug 2026" */
  function day(value) {
    var date = parseDate(value);
    if (!date) { return ""; }
    return pad(date.getDate()) + " " + MONTHS[date.getMonth()] + " " + date.getFullYear();
  }

  /* "31 Aug 2026, 14:05" - the application's `dt` filter, "Never" and all. */
  function dt(value, withSeconds) {
    var date = parseDate(value);
    if (!date) { return "Never"; }
    var stamp = day(date) + ", " + pad(date.getHours()) + ":" + pad(date.getMinutes());
    return withSeconds ? stamp + ":" + pad(date.getSeconds()) : stamp;
  }

  /* "2026-08" -> "Aug 2026" */
  function monthLabel(key) {
    var parts = String(key).split("-");
    return MONTHS[Number(parts[1]) - 1] + " " + parts[0];
  }

  function filesize(bytes) {
    var size = Number(bytes) || 0;
    if (size < 1024) { return size + " bytes"; }
    if (size < 1048576) { return Math.round(size / 1024) + " KB"; }
    return (size / 1048576).toFixed(1) + " MB";
  }

  function initials(first, last) {
    return ((first || "?").charAt(0) + (last || "").charAt(0)).toUpperCase();
  }

  function plural(count, singular, many) {
    return count === 1 ? singular : (many === undefined ? singular + "s" : many);
  }

  function unique(values) {
    var seen = {};
    var out = [];
    values.forEach(function (value) {
      var key = String(value).toLowerCase();
      if (!seen[key]) { seen[key] = true; out.push(value); }
    });
    return out;
  }

  function nowIso() {
    var date = new Date();
    return date.getFullYear() + "-" + pad(date.getMonth() + 1) + "-" + pad(date.getDate()) +
           "T" + pad(date.getHours()) + ":" + pad(date.getMinutes()) + ":" + pad(date.getSeconds());
  }

  POC.esc = esc;
  POC.num = num;
  POC.day = day;
  POC.dt = dt;
  POC.monthLabel = monthLabel;
  POC.filesize = filesize;
  POC.initials = initials;
  POC.plural = plural;
  POC.unique = unique;
  POC.nowIso = nowIso;
  POC.parseDate = parseDate;

  /* =======================================================================
     Configuration, roles and capabilities

     Mirrors app/models.py and app/config.py so the POC enforces exactly the
     access model the real service does.
     ======================================================================= */

  POC.CONFIG = {
    APP_NAME: "CHHMax Demand",
    APP_VERSION: "2.6.0",
    ORG_NAME: "Northern Powergrid",
    ORG_STRAPLINE: "NETWORK DATA SERVICES",
    MAX_BULK_MPANS: 500,
    MIN_PERIOD_MONTHS: 1,
    MAX_PERIOD_MONTHS: 36,
    MAX_UPLOAD_MB: 2,
    // The live sign-in page only offers single sign-on where it is wired
    // up; the demonstration is run on the username and password form.
    SSO_ENABLED: false,
    PAGE_SIZE: 10,
    AUDIT_PAGE_SIZE: 15,
    DISTRIBUTOR_IDS: ["15", "23"]
  };

  POC.ROLES = ["Admin", "Registration analyst", "View only"];

  POC.ROLE_HINTS = {
    "Admin": "Full access, including user management and email configuration.",
    "View only": "Can search demand data and export results. No administrative access.",
    "Registration analyst": "Can search, export and maintain supply registration reference data."
  };

  POC.ROLE_PERMISSIONS = {
    "Admin": [
      "demand.search", "demand.bulk", "demand.export", "demand.email",
      "demand.supplier_email", "admin.users", "admin.email_config", "admin.audit"
    ],
    "Registration analyst": [
      "demand.search", "demand.bulk", "demand.export", "demand.email",
      "demand.supplier_email"
    ],
    "View only": ["demand.search", "demand.export"]
  };

  POC.STATUSES = ["Active", "Invited", "Suspended"];

  POC.can = function (permission) {
    var user = POC.store.currentUser;
    if (!user) { return false; }
    var held = POC.ROLE_PERMISSIONS[user.role] || [];
    return held.indexOf(permission) !== -1;
  };

  /* =======================================================================
     Reporting periods (app/core/periods.py)
     ======================================================================= */

  POC.PERIOD_PRESETS = [
    ["6", "6 months"],
    ["12", "12 months"],
    ["18", "18 months"],
    ["24", "24 months"],
    ["36", "36 months"],
    ["full", "Full history"],
    ["custom", "Custom..."]
  ];

  /* A window always ends at the "data current to" date and starts on the
     first day of the month `months - 1` whole months earlier, so a 12-month
     search returns twelve billing periods rather than eleven and a fragment. */
  POC.resolveWindow = function (period, customMonths) {
    var end = parseDate(POC.store.dataCurrentTo);
    var endKey = end.getFullYear() + "-" + pad(end.getMonth() + 1);

    if (period === "full") {
      return {
        months: null, startKey: "0000-00", endKey: endKey, isFull: true,
        label: "Full history",
        describe: "Full history to " + day(end)
      };
    }

    var months = period === "custom" ? Number(customMonths) : Number(period);
    if (!months || months < POC.CONFIG.MIN_PERIOD_MONTHS) { months = 12; }
    if (months > POC.CONFIG.MAX_PERIOD_MONTHS) { months = POC.CONFIG.MAX_PERIOD_MONTHS; }

    var start = new Date(end.getFullYear(), end.getMonth() - (months - 1), 1);
    var startKey = start.getFullYear() + "-" + pad(start.getMonth() + 1);
    return {
      months: months, startKey: startKey, endKey: endKey, isFull: false,
      label: months + " months",
      describe: MONTHS[start.getMonth()] + " " + start.getFullYear() + " to " +
                MONTHS[end.getMonth()] + " " + end.getFullYear()
    };
  };

  POC.METHOD_LABELS = {
    mpan: "Single MPAN",
    bulk: "Bulk MPAN upload",
    postcode: "Postcode"
  };

  /* =======================================================================
     MPAN validation (app/core/mpan.py)
     ======================================================================= */

  var CHECK_PRIMES = [3, 5, 7, 13, 17, 19, 23, 29, 31, 37, 41, 43];

  POC.normaliseMpan = function (raw) {
    return String(raw === undefined || raw === null ? "" : raw).replace(/[^0-9]/g, "");
  };

  POC.validateMpan = function (raw) {
    var core = POC.normaliseMpan(raw);
    if (!core) { return { ok: false, core: "", reason: "Enter an MPAN." }; }
    if (core.length !== 13) {
      return { ok: false, core: core, reason: "MPAN must be 13 digits" };
    }
    var total = 0;
    for (var index = 0; index < 12; index += 1) {
      total += Number(core.charAt(index)) * CHECK_PRIMES[index];
    }
    if (total % 11 % 10 !== Number(core.charAt(12))) {
      return { ok: false, core: core, reason: "MPAN check digit is invalid" };
    }
    return { ok: true, core: core, reason: "" };
  };

  var POSTCODE_PATTERN = /^[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}$/i;
  POC.validatePostcode = function (raw) {
    var value = String(raw || "").trim().toUpperCase().replace(/\s+/g, " ");
    if (!value) { return { ok: false, value: "", reason: "Enter a postcode." }; }
    if (!POSTCODE_PATTERN.test(value)) {
      return { ok: false, value: value, reason: "That does not look like a UK postcode." };
    }
    if (value.indexOf(" ") === -1) {
      value = value.slice(0, value.length - 3) + " " + value.slice(-3);
    }
    return { ok: true, value: value, reason: "" };
  };

  POC.validateEmail = function (raw) {
    var value = String(raw || "").trim();
    return /^[^@\s;]+@[^@\s;]+\.[^@\s;]{2,}$/.test(value);
  };

  /* =======================================================================
     Audit vocabulary (app/core/audit.py)
     ======================================================================= */

  POC.ACTION_GROUPS = [
    ["Access", [
      ["login.success", "Signed in"],
      ["login.failed", "Sign-in failed"],
      ["login.locked", "Account locked out"],
      ["logout", "Signed out"],
      ["access.denied", "Access denied"]
    ]],
    ["Passwords", [
      ["password.changed", "Password changed by the user"],
      ["password.reset_requested", "Forgot-password requested"],
      ["password.reset_issued", "Temporary password emailed"]
    ]],
    ["Demand data", [
      ["demand.search", "Demand search run"],
      ["demand.bulk_upload", "Bulk MPAN file uploaded"],
      ["demand.export", "Results exported to Excel"],
      ["demand.supplier_email", "Demand emailed to suppliers"],
      ["demand.supplier_email.manual", "Demand emailed to a typed address"]
    ]],
    ["Supplier email list", [
      ["demand.supplier_email.added", "Supplier address added"],
      ["demand.supplier_email.uploaded", "Supplier address file uploaded"],
      ["demand.supplier_email.deleted", "Supplier address deleted"]
    ]],
    ["User administration", [
      ["admin.user.created", "User created"],
      ["admin.user.updated", "User updated"],
      ["admin.user.status", "User status changed"],
      ["admin.user.password_reset", "Temporary password issued by an admin"],
      ["account.email.sent", "Account email sent"]
    ]],
    ["Scheduled jobs", [
      ["job.account_review", "Dormant account review run"],
      ["account.inactivity.warned", "Dormancy warning emailed"],
      ["account.inactivity.suspended", "Account suspended for inactivity"],
      ["job.retention", "Data retention sweep run"]
    ]],
    ["Email templates", [
      ["admin.email_template.updated", "Email template edited"],
      ["admin.email_template.reset", "Email template restored to default"],
      ["admin.email_template.preview", "Email template previewed"]
    ]]
  ];

  POC.ACTION_LABELS = (function () {
    var labels = {};
    POC.ACTION_GROUPS.forEach(function (group) {
      group[1].forEach(function (pair) { labels[pair[0]] = pair[1]; });
    });
    return labels;
  }());

  POC.describeAction = function (action) {
    return POC.ACTION_LABELS[action] || action;
  };

  /* =======================================================================
     Email templates (app/core/email_templates.py)
     ======================================================================= */

  var DEFAULT_SIGNATURE =
    "Northern Powergrid\n" +
    "Network Data Services\n" +
    "chhmax.support@northernpowergrid.com";

  var USER_COMMON = [
    ["@username", "The user's user ID (their sign-in name)"],
    ["@password", "The temporary password issued with this message"],
    ["@fullname", "The user's full name, for the greeting"],
    ["@signin_url", "Link to the CHHMax Demand sign-in page"]
  ];

  var DORMANCY_COMMON = [
    ["@username", "The user's user ID (their sign-in name)"],
    ["@fullname", "The user's full name, for the greeting"],
    ["@signin_url", "Link to the CHHMax Demand sign-in page"],
    ["@last_login", "When they last signed in, or 'never'"],
    ["@inactive_months", "How many months of no sign-in triggers the review, e.g. 9"],
    ["@admin_contact", "Who to contact about the account"]
  ];

  POC.EMAIL_SPECS = {
    forgot_password: {
      key: "forgot_password",
      name: "Forgot password",
      purpose: "Sent when someone uses Forgot password on the sign-in page and the user ID they gave matches an account.",
      toSource: "The email address held on the matching user record. It is never typed, so a reset can only ever reach the account's own inbox.",
      supportsCc: false,
      values: USER_COMMON,
      tables: []
    },
    welcome: {
      key: "welcome",
      name: "Welcome mail",
      purpose: "Sent when an administrator creates an account, and again whenever an administrator issues a new temporary password.",
      toSource: "The email address held on the new user's record.",
      supportsCc: false,
      values: USER_COMMON.concat([
        ["@role", "The role the account was given"],
        ["@role_details", "A sentence describing that role and the access it carries"]
      ]),
      tables: []
    },
    inactivity_warning: {
      key: "inactivity_warning",
      name: "Dormant account warning",
      purpose: "Sent by the weekend account review to anyone who has not signed in for the dormancy period, warning that the account will be suspended unless they sign in before the deadline.",
      toSource: "The email address held on that user's record.",
      supportsCc: false,
      values: DORMANCY_COMMON.concat([
        ["@deadline", "The date the account is suspended on"],
        ["@grace_days", "Days left to sign in, e.g. 7"]
      ]),
      tables: []
    },
    account_suspended: {
      key: "account_suspended",
      name: "Account suspended",
      purpose: "Sent by the weekend account review when the warning ran out and the account was suspended. It tells the user how to get it back.",
      toSource: "The email address held on that user's record.",
      supportsCc: false,
      values: DORMANCY_COMMON.concat([
        ["@suspended_on", "The date the account was suspended"]
      ]),
      tables: []
    },
    supplier: {
      key: "supplier",
      name: "Supplier email",
      purpose: "Sent from a single-MPAN or bulk MPAN search to the supplier registered against each MPAN. One message per MPAN.",
      toSource: "The supplier addresses returned by SELECT mpan, email FROM supplier_email for that MPAN.",
      supportsCc: true,
      values: [
        ["@MPAN", "The 13-digit MPAN this message reports on"],
        ["@Period", "The reporting window, e.g. Last 12 months"],
        ["@Occupier", "Site occupier held against the supply"],
        ["@Address", "Site address"],
        ["@Postcode", "Site postcode"],
        ["@Agreed capacity (kVA)", "Latest agreed capacity in the window"],
        ["@Max MD (kVA)", "Highest monthly maximum demand in the window"],
        ["@Min MD (kVA)", "Lowest monthly maximum demand in the window"],
        ["@Average MD (kVA)", "Mean monthly maximum demand in the window"]
      ],
      tables: [
        ["@table_Month", "Month", "Billing month", "left", "month"],
        ["@table_Agreed capacity (kVA)", "Agreed capacity (kVA)", "Agreed capacity for that month", "right", "capacity"],
        ["@table_Maximum demand (kVA)", "Maximum demand (kVA)", "Maximum demand for that month", "right", "maxKva"],
        ["@table_MD day", "MD day", "Day the maximum demand fell on", "left", "mdDay"],
        ["@table_MD HH period start", "MD HH period start", "Half hour the peak started in", "left", "hh"],
        ["@table_Peak kW", "Peak kW", "Peak kW for that month", "right", "peakKw"]
      ]
    }
  };

  POC.EMAIL_DEFAULTS = {
    forgot_password: {
      displayName: "Northern Powergrid - CHHMax Demand",
      subject: "Your CHHMax Demand temporary password",
      body:
        "Hello @fullname,\n\n" +
        "We received a request to reset the password on your CHHMax Demand account. " +
        "A temporary password has been issued.\n\n" +
        "Username: @username\n" +
        "Temporary password: @password\n\n" +
        "Sign in at @signin_url and you will be asked to choose a new password before " +
        "you can go any further. The temporary password stops working as soon as it " +
        "has been used.\n\n" +
        "If you did not ask for this, contact the service desk straight away - your " +
        "previous password will no longer work.",
      signature: DEFAULT_SIGNATURE
    },
    welcome: {
      displayName: "Northern Powergrid - CHHMax Demand",
      subject: "Your CHHMax Demand account is ready",
      body:
        "Hello @fullname,\n\n" +
        "An account has been created for you on CHHMax Demand, the Northern Powergrid " +
        "half hourly maximum demand reporting service.\n\n" +
        "Username: @username\n" +
        "Temporary password: @password\n" +
        "Role: @role\n\n" +
        "@role_details\n\n" +
        "Sign in at @signin_url. You will be asked to set your own password the first " +
        "time you sign in, and the temporary password above will stop working at that " +
        "point.\n\n" +
        "Demand data is commercially sensitive. Please keep exports inside the agreed " +
        "reporting channels.",
      signature: DEFAULT_SIGNATURE
    },
    inactivity_warning: {
      displayName: "Northern Powergrid - CHHMax Demand",
      subject: "Action needed: your CHHMax Demand account will be suspended",
      body:
        "Hello @fullname,\n\n" +
        "Your CHHMax Demand account has not been used for @inactive_months months. " +
        "Accounts that stay unused are suspended, because dormant access to " +
        "commercially sensitive demand data is a risk to Northern Powergrid and to " +
        "you.\n\n" +
        "Username: @username\n" +
        "Last signed in: @last_login\n" +
        "Suspended on: @deadline\n\n" +
        "To keep the account, sign in at @signin_url within the next @grace_days days. " +
        "Signing in is all that is needed - there is nothing to reply to and no form " +
        "to fill in.\n\n" +
        "If the account is suspended you will not lose anything: contact " +
        "@admin_contact and an administrator can reactivate it for you.",
      signature: DEFAULT_SIGNATURE
    },
    account_suspended: {
      displayName: "Northern Powergrid - CHHMax Demand",
      subject: "Your CHHMax Demand account has been suspended",
      body:
        "Hello @fullname,\n\n" +
        "Your CHHMax Demand account was suspended on @suspended_on because it had not " +
        "been used for @inactive_months months and the warning sent earlier was not " +
        "acted on.\n\n" +
        "Username: @username\n" +
        "Last signed in: @last_login\n\n" +
        "Nothing has been deleted. If you still need access, contact @admin_contact " +
        "and ask for the account to be reactivated - an administrator can do that in a " +
        "few seconds, and you can sign in again at @signin_url straight away.",
      signature: DEFAULT_SIGNATURE
    },
    supplier: {
      displayName: "Northern Powergrid - CHHMax Demand",
      subject: "Half hourly maximum demand for MPAN @MPAN",
      body:
        "Dear Supplier,\n\n" +
        "Please find below the half hourly maximum demand recorded by Northern " +
        "Powergrid for the supply shown, covering @Period.\n\n" +
        "MPAN: @MPAN\n" +
        "Occupier: @Occupier\n" +
        "Address: @Address\n" +
        "Postcode: @Postcode\n" +
        "Agreed capacity (kVA): @Agreed capacity (kVA)\n" +
        "Max MD (kVA): @Max MD (kVA)\n" +
        "Min MD (kVA): @Min MD (kVA)\n" +
        "Average MD (kVA): @Average MD (kVA)\n\n" +
        "Monthly maximum demand\n\n" +
        "@table_Month\n" +
        "@table_Agreed capacity (kVA)\n" +
        "@table_Maximum demand (kVA)\n" +
        "@table_MD day\n" +
        "@table_MD HH period start\n" +
        "@table_Peak kW\n\n" +
        "If any of the details above look wrong, reply to the service desk quoting the " +
        "MPAN and we will investigate.",
      signature: DEFAULT_SIGNATURE
    }
  };

  POC.CONFIDENTIALITY =
    "Half hourly demand data is commercially sensitive. Do not forward this " +
    "message outside the agreed reporting channels.";

  /* =======================================================================
     Store

     One mutable object. Refreshing the page resets the demonstration, which
     is exactly what is wanted between run-throughs.
     ======================================================================= */

  function buildStore() {
    var raw = global.POC_DATA;

    var supplies = raw.supplies.map(function (item) {
      return {
        mpan: item.mpan,
        occupier: item.occupier,
        addr1: item.addr1,
        addr2: item.addr2,
        address: [item.addr1, item.addr2].filter(Boolean).join(", "),
        postcode: item.postcode,
        duplicates: item.duplicates,
        rows: item.rows.map(function (row) {
          return {
            monthKey: row[0],
            monthLabel: monthLabel(row[0]),
            capacity: row[1],
            peakKva: row[2],
            peakKw: row[3],
            mdDay: row[4] || "No peak recorded",
            hh: row[5] || "",
            overCapacity: row[1] > 0 && row[2] > row[1],
            quality: row[5] ? "Actual" : "Estimated"
          };
        })
      };
    });

    var byMpan = {};
    supplies.forEach(function (supply) { byMpan[supply.mpan] = supply; });

    var templates = {};
    Object.keys(POC.EMAIL_SPECS).forEach(function (key) {
      var defaults = POC.EMAIL_DEFAULTS[key];
      templates[key] = {
        key: key,
        // "Account suspended" deliberately ships without a From address, so
        // the "Needs a From address" state has something to show.
        fromAddress: key === "account_suspended" ? "" : "chhmax.noreply@northernpowergrid.com",
        displayName: defaults.displayName,
        ccAddress: key === "supplier" ? "connections.team@northernpowergrid.com" : "",
        subject: defaults.subject,
        body: defaults.body,
        signature: defaults.signature,
        updatedAt: key === "supplier" ? "2026-09-02T11:24:00" : null,
        updatedBy: key === "supplier" ? "p.nayar" : null
      };
    });

    return {
      dataCurrentTo: raw.dataCurrentTo,
      supplies: supplies,
      suppliesByMpan: byMpan,
      durabillEmails: raw.durabillEmails,
      heldEntries: raw.heldEntries.slice(),
      users: raw.users.slice(),
      history: raw.history.slice(),
      audit: raw.audit.slice(),
      batchFixture: raw.batch,
      supplierUploadFixture: raw.supplierUpload,
      templates: templates,
      currentUser: null,
      nextUserId: raw.users.length + 1,
      nextEntryId: raw.heldEntries.length + 1,
      // Live screen state, kept across navigation the way a server session
      // would keep it.
      search: null,
      supplierUploadResult: null,
      sentPlans: {},
      toasts: []
    };
  }

  POC.resetStore = function () {
    POC.store = buildStore();
    return POC.store;
  };

  POC.store = buildStore();

  /* =======================================================================
     Demand search

     The same shape the Flask service produces: a window, a list of per-supply
     aggregates, and the MPANs that returned nothing.
     ======================================================================= */

  function aggregate(supply, window) {
    var rows = supply.rows.filter(function (row) {
      return window.isFull ||
             (row.monthKey >= window.startKey && row.monthKey <= window.endKey);
    });

    if (!rows.length) {
      return {
        mpan: supply.mpan, occupier: supply.occupier, address: supply.address,
        postcode: supply.postcode, rows: [], hasData: false, quality: "Estimated",
        duplicatesRemoved: 0
      };
    }

    var peaks = rows.map(function (row) { return row.peakKva; });
    var total = peaks.reduce(function (sum, value) { return sum + value; }, 0);
    var peakRow = rows.reduce(function (best, row) {
      return !best || row.peakKva > best.peakKva ? row : best;
    }, null);
    var capacity = null;
    rows.some(function (row) {
      if (row.capacity) { capacity = row.capacity; return true; }
      return false;
    });

    return {
      mpan: supply.mpan,
      occupier: supply.occupier,
      address: supply.address,
      postcode: supply.postcode,
      rows: rows,
      hasData: true,
      maxKva: Math.max.apply(null, peaks),
      minKva: Math.min.apply(null, peaks),
      avgKva: Math.round((total / rows.length) * 10) / 10,
      peakRow: peakRow,
      agreedCapacity: capacity,
      monthsOverCapacity: rows.filter(function (row) { return row.overCapacity; }).length,
      quality: rows.every(function (row) { return row.quality === "Actual"; })
        ? "Actual" : "Estimated",
      duplicatesRemoved: supply.duplicates || 0
    };
  }

  POC.aggregate = aggregate;

  function countLabel(outcome) {
    if (outcome.method === "postcode") {
      var found = outcome.postcodeSupplies.length;
      return found + " suppl" + (found === 1 ? "y" : "ies") + " found";
    }
    var supplies = outcome.supplies.length;
    var rows = outcome.supplies.reduce(function (sum, item) {
      return sum + item.rows.length;
    }, 0);
    return supplies + " suppl" + (supplies === 1 ? "y" : "ies") + " - " +
           rows + " month" + (rows === 1 ? "" : "s") + " of data";
  }

  /* Runs a search over the sample dataset. Returns the same outcome shape for
     every method, so the results section does not care which was used. */
  POC.runSearch = function (criteria) {
    var window = POC.resolveWindow(criteria.period, criteria.months);
    var outcome = {
      method: criteria.method,
      window: window,
      supplies: [],
      postcodeSupplies: [],
      notFound: [],
      failed: [],
      truncated: false,
      durationMs: 0
    };

    var started = Date.now();

    if (criteria.method === "postcode") {
      var wanted = criteria.postcode.toUpperCase();
      outcome.postcodeSupplies = POC.store.supplies.filter(function (supply) {
        return supply.postcode.toUpperCase() === wanted;
      }).map(function (supply) {
        return {
          mpan: supply.mpan,
          occupier: supply.occupier,
          address: supply.address,
          postcode: supply.postcode
        };
      });
    } else {
      var targets = criteria.method === "bulk"
        ? (criteria.batch ? criteria.batch.accepted : [])
        : [criteria.mpan];

      targets.forEach(function (mpan) {
        var supply = POC.store.suppliesByMpan[mpan];
        if (!supply) {
          outcome.notFound.push(mpan);
          return;
        }
        var built = aggregate(supply, window);
        if (built.hasData) {
          outcome.supplies.push(built);
        } else {
          outcome.notFound.push(mpan);
        }
      });
    }

    // A plausible read time, so the busy state is not instantaneous.
    outcome.durationMs = Math.max(
      90,
      Math.round((Date.now() - started) + 60 +
                 (outcome.supplies.length + outcome.postcodeSupplies.length) * 24)
    );
    outcome.countLabel = countLabel(outcome);
    outcome.hasResults = outcome.supplies.length > 0 || outcome.postcodeSupplies.length > 0;
    return outcome;
  };

  /* =======================================================================
     Supplier addresses

     Durabill's supplier_email table and the list this application holds
     itself are ADDED together. An entry held here can give an MPAN a
     recipient, but it never replaces what Durabill holds.
     ======================================================================= */

  POC.heldFor = function (mpan) {
    return POC.store.heldEntries
      .filter(function (entry) { return entry.mpan === mpan; })
      .map(function (entry) { return entry.email; });
  };

  POC.durabillFor = function (mpan) {
    return (POC.store.durabillEmails[mpan] || []).slice();
  };

  POC.recipientsFor = function (mpan) {
    return POC.unique(POC.durabillFor(mpan).concat(POC.heldFor(mpan)));
  };

  POC.BADGE_NO_EMAIL = "No email found";

  /* Builds the per-MPAN send plan behind "Send to suppliers". */
  POC.buildPlan = function (outcome, criteria) {
    var mpans = criteria.method === "bulk"
      ? (criteria.batch ? criteria.batch.accepted.slice() : [])
      : [criteria.mpan];

    var withData = {};
    outcome.supplies.forEach(function (supply) { withData[supply.mpan] = supply; });

    var plan = {
      targets: [], ready: [], manual: [], sent: [], failed: [],
      recipientCount: 0, heldCount: 0, lookupError: ""
    };
    var addresses = {};

    mpans.forEach(function (mpan) {
      var supply = withData[mpan];
      var durabill = POC.durabillFor(mpan);
      var held = POC.heldFor(mpan);
      var recipients = POC.unique(durabill.concat(held));
      var target = {
        mpan: mpan,
        occupier: supply ? supply.occupier : "",
        supply: supply || null,
        recipients: recipients,
        held: held,
        isHeld: held.length > 0 && durabill.length === 0,
        monthCount: supply ? supply.rows.length : 0,
        canSendToTypedAddress: false
      };

      if (!supply) {
        target.badgeClass = "badge-neutral";
        target.badgeLabel = "No data";
        target.detail = "No demand data in this window - there is nothing to report.";
        plan.manual.push(target);
      } else if (recipients.length) {
        target.badgeClass = "badge-ok";
        target.badgeLabel = "Ready to send";
        target.detail = "";
        recipients.forEach(function (address) { addresses[address.toLowerCase()] = true; });
        if (held.length) { plan.heldCount += 1; }
        plan.ready.push(target);
      } else {
        target.badgeClass = "badge-warn";
        target.badgeLabel = POC.BADGE_NO_EMAIL;
        target.detail = "Neither Durabill nor the supplier email list holds an " +
                        "address for this MPAN.";
        target.canSendToTypedAddress = true;
        plan.manual.push(target);
      }
      plan.targets.push(target);
    });

    plan.recipientCount = Object.keys(addresses).length;
    plan.hasSendable = plan.ready.length > 0;
    return plan;
  };

  /* =======================================================================
     Audit and history recording
     ======================================================================= */

  POC.audit = function (action, entity, outcome, detail) {
    POC.store.audit.unshift({
      at: POC.nowIso(),
      username: POC.store.currentUser ? POC.store.currentUser.username : "",
      action: action,
      entity: entity || "",
      outcome: outcome || "success",
      ip: "10.42.18.7",
      detail: detail || {}
    });
  };

  POC.recordSearch = function (criteria, outcome) {
    var described = criteria.method === "postcode" ? criteria.postcode
      : criteria.method === "bulk"
        ? (criteria.batch ? criteria.batch.filename + " (" + criteria.batch.accepted.length + " MPANs)" : "")
        : criteria.mpan;

    POC.store.history.unshift({
      at: POC.nowIso(),
      username: POC.store.currentUser.username,
      method: POC.METHOD_LABELS[criteria.method],
      criteria: described,
      periodLabel: outcome.window.label,
      mpanCount: criteria.method === "postcode" ? 0 : (outcome.supplies.length + outcome.notFound.length),
      rowCount: outcome.supplies.reduce(function (sum, supply) {
        return sum + supply.rows.length;
      }, 0),
      durationMs: outcome.durationMs,
      outcome: "success"
    });

    POC.audit("demand.search", "", "success", {
      method: criteria.method,
      criteria: described,
      rows: String(outcome.supplies.reduce(function (sum, supply) {
        return sum + supply.rows.length;
      }, 0))
    });
  };

  /* =======================================================================
     CSV downloads

     The real service writes a formatted workbook. A self-contained browser
     page cannot, so the POC hands over the same columns as CSV - which Excel
     opens directly.
     ======================================================================= */

  function csvCell(value) {
    var text = value === null || value === undefined ? "" : String(value);
    return /[",\n]/.test(text) ? '"' + text.replace(/"/g, '""') + '"' : text;
  }

  POC.downloadCsv = function (filename, rows) {
    var body = rows.map(function (row) {
      return row.map(csvCell).join(",");
    }).join("\r\n");
    var blob = new Blob(["\uFEFF" + body], { type: "text/csv;charset=utf-8;" });
    var url = URL.createObjectURL(blob);
    var link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  };

  POC.exportRows = function (outcome, criteria) {
    var rows = [
      ["CHHMax Demand - Proof of Concept export"],
      ["Sample data. Not Northern Powergrid demand data."],
      ["Search method", POC.METHOD_LABELS[criteria.method]],
      ["Period", outcome.window.label + " (" + outcome.window.describe + ")"],
      ["Run by", POC.store.currentUser.username],
      ["Run at", POC.dt(POC.nowIso())],
      [],
      ["MPAN", "Occupier", "Address", "Postcode", "Month",
       "Agreed capacity (kVA)", "Maximum demand (kVA)", "MD day",
       "MD HH period start", "Peak kW", "Data quality"]
    ];

    outcome.supplies.forEach(function (supply) {
      supply.rows.forEach(function (row) {
        rows.push([
          supply.mpan, supply.occupier, supply.address, supply.postcode,
          row.monthLabel, row.capacity, row.peakKva, row.mdDay, row.hh,
          row.peakKw, row.quality
        ]);
      });
    });

    if (criteria.method === "postcode") {
      rows.push([]);
      rows.push(["Supplies in " + criteria.postcode]);
      rows.push(["MPAN", "Occupier", "Address", "Postcode"]);
      outcome.postcodeSupplies.forEach(function (supply) {
        rows.push([supply.mpan, supply.occupier, supply.address, supply.postcode]);
      });
    }
    return rows;
  };

  POC.exportFilename = function (criteria) {
    var stem = criteria.method === "postcode"
      ? criteria.postcode.replace(/\s+/g, "-")
      : criteria.method === "bulk" ? "bulk" : criteria.mpan;
    return "chhmax-demand-" + stem + "-POC.csv";
  };

}(window));
