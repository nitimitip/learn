/* CHHMax Demand - Proof of Concept build.
   ---------------------------------------------------------------------------
   Every screen, rendered as HTML. The markup and class names follow the real
   Jinja templates in app/templates so the POC looks and reads like the live
   service; only the data behind them is invented. */

(function (global) {
  "use strict";

  var POC = global.POC;
  var esc = POC.esc;
  var num = POC.num;
  var day = POC.day;
  var dt = POC.dt;

  var views = {};
  POC.views = views;

  /* =======================================================================
     Icons
     ======================================================================= */

  var ICONS = {
    home: '<path d="M2 9 10 2.6 18 9v8.4H2V9Z"></path><path d="M8 17.4v-5h4v5"></path>',
    search: '<circle cx="8.5" cy="8.5" r="5.5"></circle><path d="M12.7 12.7 17.5 17.5"></path>',
    mail: '<rect x="2" y="4.5" width="16" height="11" rx="1.5"></rect><path d="m2.6 5.4 7.4 5.2 7.4-5.2"></path>',
    cog: '<circle cx="10" cy="10" r="2.9"></circle><path d="M10 1.8v2.6M10 15.6v2.6M1.8 10h2.6M15.6 10h2.6M4.2 4.2l1.9 1.9M13.9 13.9l1.9 1.9M15.8 4.2l-1.9 1.9M6.1 13.9l-1.9 1.9"></path>',
    send: '<path d="M2.2 9.6 17.6 3.1l-4.3 14.4-3.2-5.4-5.4-3.2Z"></path>',
    caret: '<path d="M2.5 4.5 6 8l3.5-3.5"></path>',
    eye: '<path d="M1.8 10S4.9 4.5 10 4.5 18.2 10 18.2 10 15.1 15.5 10 15.5 1.8 10 1.8 10Z"></path><circle cx="10" cy="10" r="2.4"></circle>',
    back: '<path d="M10 3 5 8l5 5"></path>',
    burger: '<path d="M1.5 4h13M1.5 8h13M1.5 12h13"></path>',
    sso: '<path d="M12 2.5h4.5v15H12"></path><path d="M2.5 10h9"></path><path d="M8.5 6.5 12 10l-3.5 3.5"></path>'
  };

  function icon(name, size, viewBox) {
    return '<svg width="' + (size || 17) + '" height="' + (size || 17) + '" viewBox="0 0 ' +
      (viewBox || 20) + ' ' + (viewBox || 20) + '" fill="none" stroke="currentColor" ' +
      'stroke-width="1.6" aria-hidden="true">' + ICONS[name] + "</svg>";
  }

  var DOWNLOAD_ICON =
    '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" ' +
    'stroke-width="1.6" aria-hidden="true"><path d="M8 1.5v8.5"></path>' +
    '<path d="M4.5 7 8 10.5 11.5 7"></path><path d="M2 12.5v2h12v-2"></path></svg>';

  POC.icon = icon;

  /* =======================================================================
     Shell
     ======================================================================= */

  function navItem(route, active, label, iconName, extra) {
    return '<a class="nav-item' + (active ? " is-active" : "") + '" href="#' + route +
      '" title="' + esc(label) + '"' + (extra || "") + ">" +
      icon(iconName) + '<span class="nav-text">' + esc(label) + "</span>" +
      (extra ? '<span class="nav-caret">' + icon("caret", 10, 12) + "</span>" : "") +
      "</a>";
  }

  /* The application shell: brand, menu, topbar, content well. */
  POC.layout = function (options) {
    var store = POC.store;
    var user = store.currentUser;
    var nav = options.nav || "";
    var sub = options.sub || "";
    var config = POC.CONFIG;

    var menu = navItem("/home", nav === "home", "Home", "home") +
               navItem("/search", nav === "demand", "CHHMax Demand Data", "search");

    if (POC.can("demand.supplier_email")) {
      menu += navItem("/supplier-emails", nav === "supplier_emails",
                      "Supplier email list", "mail");
    }

    if (POC.can("admin.users")) {
      menu += navItem("/admin/users", nav === "admin", "Administration", "cog",
                      ' data-subnav-toggle aria-expanded="' + (nav === "admin" ? "true" : "false") + '"');
      menu += '<div class="subnav" data-subnav' + (nav === "admin" ? "" : " hidden") + ">" +
        '<a href="#/admin/users" class="' + (sub === "users" ? "is-active" : "") + '">User</a>' +
        '<a href="#/admin/email" class="' + (sub === "email" ? "is-active" : "") + '">Email Templates</a>' +
        '<a href="#/admin/audit" class="' + (sub === "audit" ? "is-active" : "") + '">Audit Trail</a>' +
        '<a href="#/admin/diagnostics" class="' + (sub === "diagnostics" ? "is-active" : "") + '">Diagnostics</a>' +
        "</div>";
    }

    return '' +
'<div class="shell">' +
  '<aside class="sidebar panel-bg">' +
    '<a class="sidebar-brand" href="#/home" title="' + esc(config.ORG_NAME) + ' - ' + esc(config.ORG_STRAPLINE) + '">' +
      '<img class="brand-logo brand-logo-full" src="assets/img/logo.svg" alt="' + esc(config.ORG_NAME) + '" width="250" height="51">' +
      '<img class="brand-logo brand-logo-mark" src="assets/img/logo-mark.svg" alt="' + esc(config.ORG_NAME) + '" width="51" height="51">' +
    "</a>" +
    '<nav class="sidebar-nav" aria-label="Main">' +
      '<div class="nav-label">Menu</div>' + menu +
    "</nav>" +
    '<div class="sidebar-foot">' +
      '<div class="sidebar-status"><span class="dot"></span>Data current to ' + day(store.dataCurrentTo) + "</div>" +
      '<div class="poc-stamp">Proof of concept &middot; sample data</div>' +
      '<div class="sidebar-version">v' + esc(config.APP_VERSION) + " &middot; " + esc(config.APP_NAME) + "</div>" +
    "</div>" +
  "</aside>" +

  '<div class="shell-main">' +
    '<header class="topbar">' +
      '<button type="button" class="icon-button" data-nav-toggle aria-label="Toggle navigation">' +
        icon("burger", 15, 16) + "</button>" +
      '<div style="min-width:0">' +
        '<div class="crumb">' + esc(options.crumb || config.APP_NAME) + "</div>" +
        '<div class="page-title">' + esc(options.title || "") + "</div>" +
      "</div>" +
      '<div class="topbar-spacer"></div>' +
      '<span class="badge badge-warn poc-chip">POC demo</span>' +
      '<div style="position:relative">' +
        '<button type="button" class="user-button" data-user-toggle aria-haspopup="true" aria-expanded="false">' +
          '<span class="avatar">' + esc(POC.initials(user.firstName, user.lastName)) + "</span>" +
          "<span><span class=\"user-name\">" + esc(user.firstName + " " + user.lastName) + "</span>" +
          '<span class="user-role" style="display:block">' + esc(user.role) + "</span></span>" +
        "</button>" +
        '<div class="user-menu" data-user-menu hidden>' +
          '<div class="head"><div class="user-name">' + esc(user.firstName + " " + user.lastName) + "</div>" +
          '<div class="user-role">' + esc(user.email) + "</div></div>" +
          '<a href="#/profile">My profile</a>' +
          '<a href="#/password">Change password</a>' +
          '<button type="button" data-action="switch-user">Switch demo user</button>' +
          '<button type="button" data-action="reset-demo">Reset demo data</button>' +
          '<button type="button" data-action="logout">Sign out</button>' +
        "</div>" +
      "</div>" +
    "</header>" +

    '<main class="content"><div class="content-narrow stack">' + options.body + "</div></main>" +
  "</div>" +
"</div>" +
'<div class="toast-tray" data-toast-tray></div>';
  };

  /* =======================================================================
     Sign in
     ======================================================================= */

  var LOGIN_POINTS = [
    "Search by MPAN, bulk upload or postcode",
    "Export for connection assessment and reporting",
    "Access is logged and audited"
  ];

  function brandPanel(heading, lede, points) {
    var config = POC.CONFIG;
    return '' +
'<div class="login-brand panel-bg-lg">' +
  '<div style="position:relative">' +
    '<img class="brand-logo brand-logo-login" src="assets/img/logo.svg" alt="' +
      esc(config.ORG_NAME) + '" width="250" height="51">' +
  "</div>" +
  '<div style="margin:auto 0;max-width:430px;position:relative">' +
    "<h1>" + esc(heading) + "</h1>" +
    '<p class="login-lede">' + esc(lede) + "</p>" +
    '<div class="login-points">' +
      points.map(function (point) {
        return '<div class="login-point"><span class="dot"></span>' + esc(point) + "</div>";
      }).join("") +
    "</div>" +
  "</div>" +
  '<div class="login-version">v' + esc(config.APP_VERSION) + " &middot; " +
    esc(config.APP_NAME) + " &middot; Proof of concept build</div>" +
"</div>";
  }

  POC.DEMO_ACCOUNTS = [
    { username: "a.whitfield", label: "Alan Whitfield", role: "Admin",
      note: "Everything, including Administration" },
    { username: "s.okafor", label: "Sandra Okafor", role: "Registration analyst",
      note: "Search, bulk, export, email, supplier list" },
    { username: "d.ellison", label: "David Ellison", role: "View only",
      note: "Search and export only" }
  ];

  views.login = function (state) {
    var accounts = POC.DEMO_ACCOUNTS.map(function (account) {
      return '<button type="button" class="demo-account" data-demo-user="' + esc(account.username) + '">' +
        '<span class="demo-account-role">' + esc(account.role) + "</span>" +
        '<span class="demo-account-name">' + esc(account.label) + "</span>" +
        '<span class="mono demo-account-id">' + esc(account.username) + " / demo</span>" +
        '<span class="demo-account-note">' + esc(account.note) + "</span>" +
      "</button>";
    }).join("");

    return '' +
'<div class="login">' +
  brandPanel("Half Hourly Maximum Demand Data",
             "Retrieve validated half hourly maximum demand for metered supplies across " +
             "the Northeast, Yorkshire and North Lincolnshire licence areas.",
             LOGIN_POINTS) +
  '<div class="login-form-panel"><div class="login-form">' +
    "<h2>Sign in</h2>" +
    '<p class="sub">Use your ' + esc(POC.CONFIG.ORG_NAME) + " network account.</p>" +

    (state.error
      ? '<div class="banner banner-error" style="margin-bottom:18px" role="alert"><div>' +
        '<div class="banner-title">Could not sign you in</div>' + esc(state.error) + "</div></div>"
      : "") +
    (state.notice
      ? '<div class="banner banner-info" style="margin-bottom:18px" role="status"><div>' +
        esc(state.notice) + "</div></div>"
      : "") +

    (POC.CONFIG.SSO_ENABLED
      ? '<button type="button" class="btn btn-block" data-action="sso">' + icon("sso", 15) +
        " Continue with single sign-on</button>" +
        '<div class="rule-or">OR</div>'
      : "") +

    '<form data-form="login" novalidate>' +
      '<div class="field">' +
        '<label class="field-label" for="login-username">Username</label>' +
        '<input class="input" id="login-username" name="username" autocomplete="username" value="' +
          esc(state.username || "") + '">' +
      "</div>" +
      '<div class="field">' +
        '<label class="field-label" for="login-password">Password</label>' +
        '<input class="input" id="login-password" name="password" type="password" autocomplete="current-password">' +
      "</div>" +
      '<div class="row" style="justify-content:space-between;margin-bottom:18px">' +
        '<label class="check"><input type="checkbox" name="remember"><span>Keep me signed in</span></label>' +
        '<a href="#/forgot" style="font-size:12.5px">Forgot password?</a>' +
      "</div>" +
      '<button type="submit" class="btn btn-primary btn-block">Sign in</button>' +
    "</form>" +

    '<div class="demo-accounts">' +
      '<div class="demo-accounts-head">Demonstration accounts &middot; password <span class="mono">demo</span></div>' +
      accounts +
    "</div>" +

    '<p class="login-note">Proof of concept build. Every MPAN, name, address and figure ' +
      "in this application is invented for demonstration - nothing here is " +
      esc(POC.CONFIG.ORG_NAME) + " demand data.</p>" +
  "</div></div>" +
"</div>";
  };

  views.forgot = function (state) {
    var panel = brandPanel("Forgotten your password?",
      "Give us the user ID you sign in with and we will email a temporary password to " +
      "the address held on your account.",
      ["The email goes to your account's address, and nowhere else",
       "You choose a new password as soon as you sign in",
       "Every request is logged and audited"]);

    var form = state.submitted
      ? '<div class="banner banner-info" style="margin-bottom:18px" role="status"><div>' +
          '<div class="banner-title">Check your inbox</div>' +
          "If that user ID matches an account, a temporary password is on its way to the " +
          "address we hold for it.</div></div>" +
        '<p class="sub" style="margin-bottom:24px">Nothing arrived? Your previous password ' +
          "still works if no reset was issued. A further request for the same account is " +
          "ignored for 15 minutes, so wait before trying again, then contact the service " +
          "desk if it still does not arrive.</p>" +
        '<a class="btn btn-primary btn-block" href="#/login">Back to sign in</a>'
      : '<form data-form="forgot" novalidate>' +
          '<div class="field">' +
            '<label class="field-label" for="forgot-username">Username</label>' +
            '<input class="input" id="forgot-username" name="username" placeholder="Your user ID">' +
          "</div>" +
          '<button type="submit" class="btn btn-primary btn-block">Email me a temporary password</button>' +
        "</form>" +
        '<p class="login-note"><a href="#/login">Back to sign in</a></p>';

    return '<div class="login">' + panel +
      '<div class="login-form-panel"><div class="login-form">' +
        "<h2>Reset your password</h2>" +
        '<p class="sub">We will not tell you whether a user ID exists, so check it carefully.</p>' +
        form +
      "</div></div></div>";
  };

  /* =======================================================================
     Home
     ======================================================================= */

  views.home = function () {
    var hour = new Date().getHours();
    var greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

    var body =
'<div class="banner banner-warning">' +
  "<div><div class=\"banner-title\">Sample data</div>" +
  "This is a proof of concept build. It runs entirely in your browser against " +
  "generated sample data, with no connection to Durabill and no production " +
  "records. Nothing on screen is " + esc(POC.CONFIG.ORG_NAME) + " demand data.</div>" +
"</div>" +
"<section>" +
  '<div class="eyebrow">' + esc(greeting) + ", " + esc(POC.store.currentUser.firstName) + "</div>" +
  '<h1 class="h-page" style="margin:8px 0 10px">Half Hourly Maximum Demand Data</h1>' +
  '<p class="lede">Use the navigation menu to search, review, and manage Half Hourly ' +
    "Maximum Demand data. Select CHHMax Demand Data to begin searching for demand " +
    "information.</p>" +
  '<div style="margin-top:18px">' +
    '<a class="btn btn-primary" href="#/search">' + icon("search", 15) + " Start a search</a>" +
  "</div>" +
"</section>" +
'<div class="tiles">' +
  "<div class=\"tile\"><h3>Search by MPAN or postcode</h3><p>Look up maximum demand for a " +
    "single supply, or every CHHMax-metered supply in a postcode area.</p></div>" +
  "<div class=\"tile\"><h3>Bulk MPAN upload</h3><p>Upload a CSV or XLSX of up to " +
    POC.CONFIG.MAX_BULK_MPANS + " MPANs and retrieve demand for all of them in one " +
    "search.</p></div>" +
  "<div class=\"tile\"><h3>Export for reporting</h3><p>Download results with peak date, " +
    "half-hour period and data quality flags included.</p></div>" +
"</div>";

    return POC.layout({
      nav: "home", crumb: "Home", title: "Half Hourly Maximum Demand Data", body: body
    });
  };

  /* =======================================================================
     Search
     ======================================================================= */

  function fieldErrors(errors, name) {
    if (!errors || !errors[name]) { return ""; }
    return '<div class="field-error">' + esc(errors[name]) + "</div>";
  }

  function periodOptions(selected) {
    return POC.PERIOD_PRESETS.map(function (preset) {
      return '<option value="' + preset[0] + '"' +
        (preset[0] === selected ? " selected" : "") + ">" + esc(preset[1]) + "</option>";
    }).join("");
  }

  function criteriaCard(search) {
    var criteria = search.criteria;
    var errors = search.errors || {};
    var config = POC.CONFIG;

    var tabs = [["mpan", "Single MPAN", false],
                ["bulk", "Bulk MPAN upload", true],
                ["postcode", "Postcode", false]]
      .filter(function (tab) { return !tab[2] || POC.can("demand.bulk"); })
      .map(function (tab) {
        return '<a class="method-tab' + (criteria.method === tab[0] ? " is-active" : "") +
          '" data-method-tab="' + tab[0] + '" role="tab" aria-selected="' +
          (criteria.method === tab[0] ? "true" : "false") + '" href="#/search">' +
          esc(tab[1]) + "</a>";
      }).join("");

    var bulkPanel = "";
    if (POC.can("demand.bulk")) {
      var batch = criteria.batch;
      var inner;
      if (batch) {
        inner =
'<div class="file-card">' +
  '<div class="file-icon">' + esc(batch.filename.split(".").pop().toUpperCase()) + "</div>" +
  '<div style="min-width:0">' +
    '<div style="font-weight:600">' + esc(batch.filename) + "</div>" +
    '<div class="file-meta">' + batch.totalRows + " rows &middot; " +
      POC.filesize(batch.sizeBytes) + " &middot; uploaded " + dt(batch.uploadedAt).slice(-5) + "</div>" +
  "</div>" +
  '<div class="spacer"></div>' +
  '<span class="badge badge-ok">' + batch.accepted.length + " valid</span>" +
  '<button type="button" class="btn btn-sm" data-action="clear-batch">Remove</button>' +
"</div>" +
(batch.rejected.length
  ? '<div style="margin-top:12px">' +
      '<div class="badge badge-warn">' + batch.rejected.length + " rows will be skipped</div>" +
      '<ul class="reject-list">' + batch.rejected.map(function (row) {
        return "<li>Row " + row.row + ' &mdash; <span class="mono">' + esc(row.value) +
          "</span> &middot; " + esc(row.reason) + "</li>";
      }).join("") + "</ul>" +
      '<button type="button" class="btn-link" style="display:inline-block;margin-top:8px" ' +
        'data-action="download-batch-errors">Download error report</button>' +
    "</div>"
  : "");
      } else {
        inner =
'<div class="dropzone' + (errors.upload ? " has-error" : "") + '" data-dropzone>' +
  "<p>Drag a file here, or <button type=\"button\" class=\"btn-link\" data-browse>browse to upload</button></p>" +
  '<div class="meta">.CSV or .XLSX &middot; one MPAN per row &middot; max ' +
    config.MAX_BULK_MPANS + " rows &middot; " + config.MAX_UPLOAD_MB + " MB</div>" +
  '<div class="meta" data-file-name hidden></div>' +
  '<input type="file" class="visually-hidden" data-file-input accept=".csv,.txt,.xlsx,.xlsm">' +
"</div>" +
fieldErrors(errors, "upload") +
'<div class="field-hint">No file to hand? ' +
  '<button type="button" class="btn-link" data-action="use-sample-batch">Use the sample MPAN list</button>' +
  " (" + POC.store.batchFixture.totalRows + " rows, " +
  POC.store.batchFixture.rejected.length + " deliberately wrong). Or " +
  '<button type="button" class="btn-link" data-action="download-mpan-template">download the MPAN template</button>' +
  ' &mdash; a single <span class="mono">MPAN</span> heading, then one 13-digit MPAN core ' +
  "per row. Spaces and dashes are ignored, and a heading row is optional.</div>";
      }
      bulkPanel = '<div data-method-panel="bulk"' +
        (criteria.method === "bulk" ? "" : " hidden") + '>' +
        '<div class="field-label">Bulk MPAN Upload</div>' + inner + "</div>";
    }

    return '' +
'<section class="card">' +
  '<div class="card-head">' +
    "<div><div class=\"h-section\">Search demand data</div>" +
    '<div class="muted" style="font-size:12px;margin-top:3px">Choose one search method. ' +
      "Period Length applies to all methods.</div></div>" +
    '<div class="spacer"></div>' +
    '<div class="method-tabs" role="tablist" aria-label="Search method">' + tabs + "</div>" +
  "</div>" +

  '<div class="card-body">' +
    '<form data-form="search" novalidate>' +
      '<input type="hidden" name="method" value="' + esc(criteria.method) + '" data-method-input>' +
      '<div class="criteria-row">' +

        '<div class="field field-period">' +
          '<label class="field-label" for="search-period">Period Length ' +
            '<span class="req">*</span> <span class="faint" style="font-weight:400">Required</span></label>' +
          '<select class="select' + (errors.period ? " has-error" : "") +
            '" id="search-period" name="period" data-period-select>' +
            periodOptions(criteria.period) + "</select>" +
          fieldErrors(errors, "period") +
          (errors.period ? "" :
            '<div class="field-hint">The maximum demand is taken from this window, ending ' +
            day(POC.store.dataCurrentTo) + ".</div>") +
        "</div>" +

        '<div class="field field-months" data-custom-months' +
          (criteria.period === "custom" ? "" : " hidden") + ">" +
          '<label class="field-label" for="search-months">Number of months</label>' +
          '<div class="stepper">' +
            '<button type="button" data-step="-1" aria-label="Fewer months">&minus;</button>' +
            '<input class="input mono' + (errors.months ? " has-error" : "") +
              '" id="search-months" name="months" type="number" min="' + config.MIN_PERIOD_MONTHS +
              '" max="' + config.MAX_PERIOD_MONTHS + '" value="' + esc(criteria.months) +
              '" data-months-input>' +
            '<button type="button" data-step="1" aria-label="More months">+</button>' +
          "</div>" +
          fieldErrors(errors, "months") +
          '<div class="field-hint">Between ' + config.MIN_PERIOD_MONTHS + " and " +
            config.MAX_PERIOD_MONTHS + " months.</div>" +
        "</div>" +

        '<div class="field field-term" data-method-panel="mpan"' +
          (criteria.method === "mpan" ? "" : " hidden") + ">" +
          '<label class="field-label" for="search-mpan">MPAN Number</label>' +
          '<input class="input mono' + (errors.mpan ? " has-error" : "") +
            '" id="search-mpan" name="mpan" placeholder="13-digit MPAN core" value="' +
            esc(criteria.mpan) + '">' +
          fieldErrors(errors, "mpan") +
          (errors.mpan ? "" :
            '<div class="field-hint">Enter the 13-digit bottom line of the supply number.</div>') +
        "</div>" +

        '<div class="field field-term" data-method-panel="postcode"' +
          (criteria.method === "postcode" ? "" : " hidden") + ">" +
          '<label class="field-label" for="search-postcode">Postcode</label>' +
          '<input class="input mono' + (errors.postcode ? " has-error" : "") +
            '" id="search-postcode" name="postcode" placeholder="NE8 2BQ" value="' +
            esc(criteria.postcode) + '">' +
          fieldErrors(errors, "postcode") +
          (errors.postcode ? "" :
            '<div class="field-hint">Returns every CHHMax-metered supply in the area.</div>') +
        "</div>" +
      "</div>" +

      bulkPanel +

      '<div class="row" style="margin-top:22px">' +
        '<button type="submit" class="btn btn-primary" data-submit>' + icon("search", 15) + " Search</button>" +
        '<button type="button" class="btn btn-ghost" data-action="clear-search">Clear</button>' +
        '<div class="spacer"></div>' +
        '<span class="field-hint" style="margin:0">Fields marked <span class="req">*</span> are required</span>' +
      "</div>" +
    "</form>" +
  "</div>" +
"</section>" +
'<div class="card" data-busy hidden><div class="loading-row"><span class="spinner"></span>' +
  "Retrieving half hourly maximum demand data...</div></div>";
  }

  /* ---- one supply: identity strip, facts, monthly table ---------------- */

  function sendOneDialog(key, mpan, periodLabel, back) {
    var id = "send-one-" + key;
    return '' +
'<button type="button" class="btn btn-sm btn-primary" data-dialog-open="' + id + '">' +
  icon("send", 13) + " Send email</button>" +
'<dialog id="' + id + '" class="modal" aria-label="Send this supply by email">' +
  '<form data-form="send-one" data-mpan="' + esc(mpan) + '" data-back="' + esc(back || "") + '">' +
    '<div class="modal-head"><div><div class="h-section">Send this supply by email</div>' +
      '<div class="muted mono" style="font-size:12px;margin-top:3px">' + esc(mpan) + "</div></div></div>" +
    '<div class="modal-body">' +
      '<div class="field">' +
        '<label class="field-label" for="' + id + '-address">Send to <span class="req">*</span></label>' +
        '<input class="input" type="email" id="' + id + '-address" name="address" required ' +
          'autocomplete="off" multiple placeholder="name@supplier.co.uk">' +
        '<div class="field-hint">Separate several addresses with a semicolon. The supply\'s ' +
          "monthly maximum demand for " + esc(String(periodLabel).toLowerCase()) +
          " is sent using the Supplier email template.</div>" +
      "</div>" +
      (POC.can("demand.supplier_email")
        ? '<label class="check"><input type="checkbox" name="remember" value="1" checked>' +
          "Add this address to the supplier email list, so the next search finds it</label>"
        : "") +
      '<div class="banner banner-warning" style="margin:12px 0 0"><div>Demand data is ' +
        "commercially sensitive and this address is not the registered supplier. Check it " +
        "before sending.</div></div>" +
    "</div>" +
    '<div class="modal-foot">' +
      '<button type="button" class="btn" data-dialog-close>Cancel</button>' +
      '<div class="spacer"></div>' +
      '<button type="submit" class="btn btn-primary">Send</button>' +
    "</div>" +
  "</form>" +
"</dialog>";
  }

  function supplyCard(supply, options) {
    options = options || {};
    var peak = supply.peakRow;
    var periodLabel = options.periodLabel || "";
    var addressState = options.addresses;   // undefined = never asked

    var badges = '<span class="badge ' +
      (supply.quality === "Actual" ? "badge-ok" : "badge-warn") + '">' +
      esc(supply.quality) + "</span>";

    if (addressState !== undefined) {
      if (addressState.length) {
        badges += '<span class="badge badge-teal" title="' + esc(addressState.join("; ")) +
          '">Supplier email on file</span>';
      } else {
        badges += '<span class="badge badge-warn">' + POC.BADGE_NO_EMAIL + "</span>" +
          sendOneDialog("card-" + supply.mpan, supply.mpan, periodLabel, options.back);
      }
    }

    var facts = [
      ["MPAN", '<span class="mono">' + esc(supply.mpan) + "</span>", "mono"],
      ["Period", esc(periodLabel), ""],
      ["Occupier", esc(supply.occupier || "-"), ""],
      ["Address", esc(supply.address || "-"), ""],
      ["Postcode", esc(supply.postcode || "-"), "mono"],
      ["Agreed capacity (kVA)", num(supply.agreedCapacity), "big"],
      ["Max MD (kVA)", num(supply.maxKva), "big"],
      ["Min MD (kVA)", num(supply.minKva), "big"],
      ["Average MD (kVA)", num(supply.avgKva), "big"],
      ["Months over capacity", supply.monthsOverCapacity + " / " + supply.rows.length, "big"]
    ].map(function (fact) {
      return '<div class="fact"><div class="fact-k">' + esc(fact[0]) + "</div>" +
        '<div class="fact-v' + (fact[2] === "big" ? " big" : fact[2] === "mono" ? " mono" : "") +
        '">' + fact[1] + "</div></div>";
    }).join("");

    var rows = supply.rows.map(function (row) {
      var classes = [];
      if (row.overCapacity) { classes.push("is-over"); }
      if (peak && row === peak) { classes.push("is-peak"); }
      return "<tr" + (classes.length ? ' class="' + classes.join(" ") + '"' : "") + ">" +
        '<td class="strong">' + esc(row.monthLabel) + "</td>" +
        '<td class="num">' + num(row.capacity) + "</td>" +
        '<td class="md-value">' + num(row.peakKva) + "</td>" +
        '<td class="muted" style="white-space:nowrap">' + esc(row.mdDay) + "</td>" +
        '<td class="mono muted">' + esc(row.hh || "-") + "</td>" +
        '<td class="num">' + num(row.peakKw) + "</td>" +
      "</tr>";
    }).join("");

    return '' +
'<section class="card" data-quality="' + esc(supply.quality) + '">' +
  '<div class="card-head">' +
    (options.position ? '<span class="eyebrow">' + esc(options.position) + "</span>" : "") +
    '<span class="mono" style="font-size:14px;font-weight:600">' + esc(supply.mpan) + "</span>" +
    '<span class="muted" style="font-weight:500">' + esc(supply.occupier || "Unknown occupier") + "</span>" +
    '<div class="spacer"></div>' + badges +
  "</div>" +

  '<div style="padding:16px 18px;background:var(--surface-muted);border-bottom:1px solid var(--line-soft)">' +
    '<div class="facts">' + facts + "</div>" +
  "</div>" +

  '<div class="card-head">' +
    '<div class="h-section">Monthly maximum demand</div>' +
    '<span class="muted" style="font-size:11.5px">' + supply.rows.length + " month" +
      (supply.rows.length === 1 ? "" : "s") + "</span>" +
    '<div class="spacer"></div>' +
    '<div class="legend">' +
      '<span><span class="swatch swatch-peak"></span>Highest month</span>' +
      '<span><span class="swatch swatch-over"></span>Over agreed capacity</span>' +
    "</div>" +
  "</div>" +

  '<div class="table-wrap"><table class="data" style="min-width:760px">' +
    "<thead><tr><th>Month</th><th class=\"num\">Agreed capacity (kVA)</th>" +
    "<th class=\"num\">Maximum demand (kVA)</th><th>MD day</th>" +
    "<th>MD HH period start</th><th class=\"num\">Peak kW</th></tr></thead>" +
    "<tbody>" + rows + "</tbody></table></div>" +

  (supply.duplicatesRemoved
    ? '<div class="card-body" style="padding:12px 18px">' +
        '<div class="banner banner-warning"><div>' +
        '<div class="banner-title">' + supply.duplicatesRemoved + " duplicate month" +
          (supply.duplicatesRemoved === 1 ? "" : "s") + " collapsed</div>" +
        "Durabill returned more than one statement for the same billing month. The highest " +
        "maximum demand was kept (preferring the MHHS record), so the average is not " +
        "double-counted. Raise this with the service desk if it persists.</div></div></div>"
    : "") +

  '<div class="card-foot">Data quality: ' + esc(supply.quality) +
    (peak ? " &middot; Highest month " + esc(peak.monthLabel) + " at " + num(peak.peakKva) + " kVA" : "") +
  "</div>" +
"</section>";
  }

  POC.supplyCard = supplyCard;

  function resultsSection(search) {
    var outcome = search.outcome;
    var criteria = search.criteria;

    if (search.state === "idle") {
      return '<section class="card"><div class="empty-state">' +
        "<h3>Results will appear here</h3><p>Select a Period Length and a search method " +
        "above, then choose Search. The criteria stay on screen so you can refine without " +
        "navigating away.</p></div></section>";
    }

    if (search.state === "empty") {
      return '<section class="card"><div class="empty-state">' +
        "<h3>No demand data found</h3><p>No half hourly maximum demand was returned for " +
        '<span class="mono">' + esc(search.describe) + "</span> over " +
        esc(outcome.window.label.toLowerCase()) + " (" + esc(outcome.window.describe) + "). " +
        "The supply may not be CHHMax-metered, or may have no settled data in this window.</p>" +
        '<div class="actions">' +
          '<button type="button" class="btn btn-primary" data-action="widen-full">Widen to full history</button>' +
          '<button type="button" class="btn" data-action="clear-search">Clear search</button>' +
        "</div></div></section>";
    }

    var head =
'<section class="card">' +
  '<div class="card-head">' +
    "<div><div class=\"h-section\">Search results</div>" +
    '<div class="muted" style="font-size:12px;margin-top:3px">' + esc(outcome.countLabel) +
      " &middot; " + esc(outcome.window.describe) + " &middot; read in " + outcome.durationMs + " ms</div></div>" +
    '<div class="spacer"></div>' +
    (POC.can("demand.export")
      ? '<button type="button" class="btn btn-sm" data-action="export">' + DOWNLOAD_ICON + " Export Excel</button>"
      : "") +
    (POC.can("demand.email") && criteria.method !== "postcode"
      ? '<a class="btn btn-sm btn-primary" href="#/email-review">' + icon("send", 14) + " Send email</a>"
      : "") +
  "</div>" +
  (outcome.notFound.length || outcome.truncated
    ? '<div class="card-body" style="padding-top:14px;padding-bottom:14px">' +
      (outcome.notFound.length
        ? '<div class="banner banner-warning" style="margin-bottom:8px"><div>' +
          '<div class="banner-title">' + outcome.notFound.length + " MPAN" +
            (outcome.notFound.length === 1 ? "" : "s") + " returned no data</div>" +
          '<span class="mono" style="font-size:11.5px">' +
            esc(outcome.notFound.slice(0, 12).join(", ")) +
            (outcome.notFound.length > 12 ? " and " + (outcome.notFound.length - 12) + " more" : "") +
          "</span></div></div>"
        : "") +
      (outcome.truncated
        ? '<div class="banner banner-info"><div>Only the first ' + POC.CONFIG.MAX_BULK_MPANS +
          " supplies are shown. Narrow the postcode to see the rest.</div></div>"
        : "") +
      "</div>"
    : "") +
"</section>";

    if (criteria.method === "postcode") {
      var listRows = outcome.postcodeSupplies.map(function (item) {
        return "<tr>" +
          '<td><a class="mono" style="font-weight:600" href="#/supply/' + esc(item.mpan) + '">' +
            esc(item.mpan) + "</a></td>" +
          '<td style="font-weight:500">' + esc(item.occupier) + "</td>" +
          '<td class="muted">' + esc(item.address) + "</td>" +
          '<td class="mono muted">' + esc(item.postcode) + "</td>" +
        "</tr>";
      }).join("");

      return head +
'<section class="card">' +
  '<div class="card-head">' +
    "<div><div class=\"h-section\">Supplies in " + esc(criteria.postcode.toUpperCase()) + "</div>" +
    '<div class="muted" style="font-size:12px;margin-top:3px">Select an MPAN to view its ' +
      "half hourly maximum demand for " + esc(outcome.window.label.toLowerCase()) + ".</div></div>" +
    '<div class="spacer"></div>' +
    '<input type="search" class="input mono" style="width:220px" placeholder="Filter supplies" ' +
      'aria-label="Filter supplies" data-filter-input="pc-table">' +
  "</div>" +
  '<div class="table-wrap"><table class="data" id="pc-table" style="min-width:680px">' +
    "<thead><tr><th>MPAN</th><th>Occupier</th><th>Address</th><th>Postcode</th></tr></thead>" +
    "<tbody>" + listRows + "</tbody></table></div>" +
  '<div class="empty-state" data-filter-empty="pc-table" hidden><h3>No supplies match this filter</h3></div>' +
  '<div class="card-foot">' + outcome.postcodeSupplies.length +
    " supplies listed. Demand is read from Durabill when you open one.</div>" +
"</section>";
    }

    var showAddresses = POC.can("demand.email");
    var total = outcome.supplies.length;
    var cards = outcome.supplies.map(function (supply, index) {
      return supplyCard(supply, {
        periodLabel: outcome.window.label,
        position: total > 1 ? ("0" + (index + 1)).slice(-2) + " / " + ("0" + total).slice(-2) : "",
        addresses: showAddresses ? POC.recipientsFor(supply.mpan) : undefined,
        back: "#/search"
      });
    }).join("");

    return head +
      (total > 1
        ? '<div class="row"><label class="field-label" style="margin:0" for="quality-filter">Data quality</label>' +
          '<select class="select" id="quality-filter" style="width:180px" data-quality-filter="supply-list">' +
          '<option value="all">All data quality</option><option value="Actual">Actual only</option>' +
          '<option value="Estimated">Estimated only</option></select></div>'
        : "") +
      '<div class="stack" id="supply-list">' + cards + "</div>" +
      '<div class="card empty-state" data-quality-empty="supply-list" hidden>' +
        "<h3>No rows match this data quality filter</h3>" +
        "<p>Your results are still here &mdash; reset the filter to see them.</p></div>";
  }

  views.search = function (search) {
    var banner = search.banner
      ? '<div class="banner banner-error" role="alert"><div>' +
        '<div class="banner-title">' + esc(search.banner) + "</div>" +
        '<ul style="margin:6px 0 0;padding-left:18px">' +
        Object.keys(search.errors || {}).map(function (key) {
          return "<li>" + esc(search.errors[key]) + "</li>";
        }).join("") + "</ul></div></div>"
      : "";

    return POC.layout({
      nav: "demand", crumb: "CHHMax Demand Data", title: "Search demand data",
      body: banner + criteriaCard(search) + resultsSection(search)
    });
  };

  views.supply = function (state) {
    var body = '<div class="row">' +
      (state.backPostcode
        ? '<a class="btn btn-sm" href="#/search">' + icon("back", 13, 16) + " Back to " +
          esc(state.backPostcode.toUpperCase()) + " supplies</a>"
        : '<a class="btn btn-sm" href="#/search">Back to search</a>') +
      '<div class="spacer"></div>' +
      (state.supply && POC.can("demand.export")
        ? '<button type="button" class="btn btn-sm" data-action="export-supply" data-mpan="' +
          esc(state.mpan) + '">Export Excel</button>' : "") +
      (state.supply && POC.can("demand.email")
        ? '<a class="btn btn-sm btn-primary" href="#/email-review?mpan=' + esc(state.mpan) + '">Send email</a>'
        : "") +
      "</div>";

    if (state.supply) {
      body += supplyCard(state.supply, {
        periodLabel: state.window.label,
        addresses: POC.can("demand.email") ? POC.recipientsFor(state.mpan) : undefined,
        back: "#/supply/" + state.mpan
      });
    } else {
      body += '<section class="card"><div class="empty-state"><h3>No demand data found</h3>' +
        '<p>No half hourly maximum demand was returned for <span class="mono">' +
        esc(state.mpan) + "</span> over " + esc(state.window.label.toLowerCase()) +
        " (" + esc(state.window.describe) + ").</p>" +
        '<div class="actions"><button type="button" class="btn btn-primary" ' +
        'data-action="widen-supply" data-mpan="' + esc(state.mpan) +
        '">Widen to full history</button></div></div></section>';
    }

    return POC.layout({
      nav: "demand", crumb: "CHHMax Demand Data", title: "Supply " + state.mpan, body: body
    });
  };

  /* =======================================================================
     Send to suppliers
     ======================================================================= */

  views.emailReview = function (state) {
    var plan = state.plan;
    var outcome = state.outcome;
    var criteria = state.criteria;
    var sent = state.sent;
    var template = POC.store.templates.supplier;
    var ccList = template.ccAddress
      ? template.ccAddress.split(";").map(function (part) { return part.trim(); }).filter(Boolean)
      : [];

    var facts = '<div class="fact"><div class="fact-k">MPANs in this search</div>' +
      '<div class="fact-v big">' + plan.targets.length + "</div></div>";
    if (sent) {
      facts += '<div class="fact"><div class="fact-k">Sent</div><div class="fact-v big">' +
        plan.sent.length + "</div></div>" +
        '<div class="fact"><div class="fact-k">Not delivered</div><div class="fact-v big">' +
        plan.failed.length + "</div></div>";
    } else {
      facts += '<div class="fact"><div class="fact-k">Ready to send</div><div class="fact-v big">' +
        plan.ready.length + "</div></div>" +
        '<div class="fact"><div class="fact-k">Supplier addresses</div><div class="fact-v big">' +
        plan.recipientCount + "</div></div>";
    }
    facts += '<div class="fact"><div class="fact-k">Send manually</div><div class="fact-v big">' +
      plan.manual.length + "</div></div>";

    var rows = plan.targets.map(function (target) {
      return "<tr>" +
        '<td class="mono strong">' + esc(target.mpan) + "</td>" +
        "<td>" + esc(target.occupier || "-") + "</td>" +
        '<td class="mono muted wrap-any">' +
          (target.recipients.length ? esc(target.recipients.join("; ")) : "&mdash;") +
          (target.held.length
            ? '<div style="margin-top:4px"><span class="badge badge-neutral" title="' +
              esc(target.held.join("; ")) + '">' +
              (target.isHeld ? "From the supplier email list"
                             : "Includes an address from the supplier email list") +
              "</span></div>"
            : "") +
        "</td>" +
        '<td class="num">' + (target.monthCount || "-") + "</td>" +
        "<td><span class=\"badge " + target.badgeClass + '">' + esc(target.badgeLabel) + "</span>" +
          (target.detail
            ? '<div class="muted" style="font-size:11.5px;margin-top:4px;white-space:normal">' +
              esc(target.detail) + "</div>"
            : "") +
        "</td>" +
        "<td>" +
          (target.canSendToTypedAddress && !sent
            ? sendOneDialog("row-" + target.mpan, target.mpan, outcome.window.label, "#/email-review")
            : "") +
        "</td>" +
      "</tr>";
    }).join("");

    var body =
(!template.fromAddress
  ? '<div class="banner banner-warning"><div><div class="banner-title">The supplier template ' +
    "has no From address</div>Set one in <a href=\"#/admin/email?template=supplier\">" +
    "Administration &rarr; Email</a> before sending, or delivery will be refused.</div></div>"
  : "") +

'<section class="card">' +
  '<div class="card-head">' +
    "<div><div class=\"h-section\">" + (sent ? "What was sent" : "What will be sent") + "</div>" +
    '<div class="muted" style="font-size:12px;margin-top:3px">' +
      esc(POC.METHOD_LABELS[criteria.method]) + ' &middot; <span class="mono">' +
      esc(state.describe) + "</span> &middot; " + esc(outcome.window.label) +
      " (" + esc(outcome.window.describe) + ")</div></div>" +
    '<div class="spacer"></div>' +
    '<a class="btn btn-sm" href="#/search">Back to results</a>' +
  "</div>" +
  '<div class="facts">' + facts + "</div>" +
  '<div class="card-body">' +
    (sent
      ? '<p class="muted" style="margin:0;font-size:12.5px">One message per MPAN went to the ' +
        "supplier registered against it, using the Supplier email template. Delivery was " +
        "recorded in the audit trail.</p>"
      : '<p class="muted" style="margin:0 0 4px;font-size:12.5px">Each MPAN below is sent as ' +
        "its own message to the supplier addresses registered against it in " +
        "<span class=\"mono\">supplier_email</span>, carrying that supply's monthly maximum " +
        "demand. Check the list, then send.</p>" +
        (plan.heldCount
          ? '<p class="muted" style="margin:8px 0 0;font-size:12.5px">' + plan.heldCount +
            " of them also use an address from the " +
            (POC.can("demand.supplier_email")
              ? '<a href="#/supplier-emails">supplier email list</a>'
              : "supplier email list") +
            ", which this service holds itself. Those addresses are added to what Durabill " +
            "holds, never used in place of it.</p>"
          : "") +
        (ccList.length
          ? '<p class="muted" style="margin:8px 0 0;font-size:12.5px">Every message is copied ' +
            'to <span class="mono">' + esc(ccList.join("; ")) + "</span>.</p>"
          : "")) +
  "</div>" +
  (sent ? "" :
    '<div class="card-head" style="border-top:1px solid var(--line-soft);border-bottom:0">' +
      '<div class="banner banner-warning" style="margin:0;flex:1"><div>Demand data is ' +
        "commercially sensitive. These messages go to external suppliers.</div></div>" +
      '<div class="spacer"></div>' +
      '<button type="button" class="btn btn-primary" data-action="send-supplier-emails"' +
        (plan.hasSendable ? "" : " disabled") + ">" + icon("send", 15) + " Send " +
        plan.ready.length + " supplier email" + (plan.ready.length === 1 ? "" : "s") + "</button>" +
    "</div>") +
"</section>" +

'<section class="card">' +
  '<div class="card-head">' +
    "<div><div class=\"h-section\">MPAN report</div>" +
    '<div class="muted" style="font-size:12px;margin-top:3px">Every MPAN in the search, ' +
      "whether or not a supplier could be found.</div></div>" +
    '<div class="spacer"></div>' +
    '<input type="search" class="input mono" style="width:220px" placeholder="Filter MPANs" ' +
      'aria-label="Filter MPANs" data-filter-input="supplier-table">' +
  "</div>" +
  '<div class="table-wrap"><table class="data" id="supplier-table" style="min-width:860px">' +
    "<thead><tr><th>MPAN</th><th>Occupier</th><th>Supplier email</th><th class=\"num\">Months</th>" +
    "<th>Status</th><th><span class=\"visually-hidden\">Actions</span></th></tr></thead>" +
    "<tbody>" + rows + "</tbody></table></div>" +
  '<div class="empty-state" data-filter-empty="supplier-table" hidden><h3>No MPANs match this filter</h3></div>' +
  (plan.manual.length
    ? '<div class="card-body" style="border-top:1px solid var(--line-soft)">' +
      '<div class="banner banner-warning" style="margin:0"><div>' +
      '<div class="banner-title">' + plan.manual.length + " MPAN" +
        (plan.manual.length === 1 ? "" : "s") + " need manual handling</div>" +
      "Either neither <span class=\"mono\">supplier_email</span> nor the supplier email list " +
      "holds an address for the MPAN, or the search returned no demand data for it. Nothing " +
      "was sent for these. Where there is data to send, use <strong>Send email</strong> on " +
      "the row to send it to an address you type; where there is not, the supply has nothing " +
      "to report." +
      '<ul class="reject-list" style="margin-top:10px">' +
        plan.manual.slice(0, 12).map(function (target) {
          return '<li><span class="mono">' + esc(target.mpan) + "</span> &middot; " +
            esc(target.detail) + "</li>";
        }).join("") +
      "</ul></div></div></div>"
    : "") +
  '<div class="card-foot">' +
    (sent
      ? "Sent using the Supplier email template as it stands in " +
        '<a href="#/admin/email?template=supplier">Administration &rarr; Email</a>.'
      : "Wording, columns and CC come from the Supplier email template." +
        (POC.can("admin.email_config")
          ? ' <a href="#/admin/email/supplier/preview">Preview it with sample data</a>.'
          : "")) +
  "</div>" +
"</section>" +

(POC.can("demand.export")
  ? '<div class="row"><button type="button" class="btn" data-action="export">' + DOWNLOAD_ICON +
    " Export the same results to Excel</button><div class=\"spacer\"></div></div>"
  : "");

    return POC.layout({
      nav: "demand", crumb: "CHHMax Demand Data",
      title: sent ? "Supplier email report" : "Send to suppliers",
      body: body
    });
  };

  /* =======================================================================
     Supplier email list
     ======================================================================= */

  views.supplierEmails = function (state) {
    var store = POC.store;
    var query = (state.query || "").trim().toLowerCase();
    var matching = store.heldEntries.filter(function (entry) {
      return !query || entry.mpan.indexOf(query) !== -1 ||
             entry.email.toLowerCase().indexOf(query) !== -1;
    });
    var pageSize = POC.CONFIG.PAGE_SIZE;
    var pages = Math.max(1, Math.ceil(matching.length / pageSize));
    var page = Math.min(Math.max(1, state.page || 1), pages);
    var entries = matching.slice((page - 1) * pageSize, page * pageSize);
    var distinct = POC.unique(store.heldEntries.map(function (entry) { return entry.mpan; })).length;
    var parsed = store.supplierUploadResult;
    var errors = state.errors || {};

    var rows = entries.map(function (entry) {
      return "<tr>" +
        '<td class="mono strong"><a href="#/supply/' + esc(entry.mpan) + '">' + esc(entry.mpan) + "</a></td>" +
        '<td class="mono">' + esc(entry.email) + "</td>" +
        '<td class="muted" style="white-space:nowrap">' + day(entry.createdAt) +
          '<div style="font-size:11.5px">' + esc(entry.source) +
          (entry.createdBy ? " by " + esc(entry.createdBy) : "") + "</div></td>" +
        '<td class="muted">' + esc(entry.note || "-") + "</td>" +
        '<td style="text-align:right">' +
          '<button type="button" class="btn btn-sm btn-danger" data-action="delete-entry" ' +
          'data-id="' + entry.id + '" data-email="' + esc(entry.email) + '" data-mpan="' +
          esc(entry.mpan) + '">Delete</button>' +
        "</td>" +
      "</tr>";
    }).join("");

    var body =
'<section class="card">' +
  '<div class="card-body"><p class="muted" style="margin:0;font-size:12.5px">' +
    "Durabill's <span class=\"mono\">supplier_email</span> table stays the record of who " +
    "supplies each MPAN, and it is read on every send. This list is what fills its gaps: the " +
    "addresses you already hold for supplies Durabill has no row for. The two are " +
    "<strong>added together</strong> at send time &mdash; an entry here can give an MPAN a " +
    "recipient, but it can never replace or remove the one Durabill holds.</p></div>" +
  '<div class="facts">' +
    '<div class="fact"><div class="fact-k">Addresses held</div><div class="fact-v big">' +
      store.heldEntries.length + "</div></div>" +
    '<div class="fact"><div class="fact-k">MPANs covered</div><div class="fact-v big">' +
      distinct + "</div></div>" +
  "</div>" +
"</section>" +

'<div class="stack">' +
  '<section class="card">' +
    '<div class="card-head"><div><div class="h-section">Add an address</div>' +
      '<div class="muted" style="font-size:12px;margin-top:3px">One MPAN, one address. Add ' +
      "the same MPAN again to give it a second recipient.</div></div></div>" +
    '<div class="card-body"><form data-form="add-supplier-email" novalidate>' +
      '<div class="criteria-row">' +
        '<div class="field"><label class="field-label" for="entry-mpan">MPAN <span class="req">*</span></label>' +
          '<input class="input mono' + (errors.mpan ? " has-error" : "") +
            '" id="entry-mpan" name="mpan" placeholder="13-digit MPAN core" value="' +
            esc(state.form && state.form.mpan || "") + '">' +
          fieldErrors(errors, "mpan") + "</div>" +
        '<div class="field" style="flex:2 1 280px">' +
          '<label class="field-label" for="entry-email">Supplier email address <span class="req">*</span></label>' +
          '<input class="input' + (errors.email ? " has-error" : "") +
            '" id="entry-email" name="email" placeholder="settlements@supplier.co.uk" value="' +
            esc(state.form && state.form.email || "") + '">' +
          fieldErrors(errors, "email") + "</div>" +
        '<div class="field" style="flex:1 1 200px">' +
          '<label class="field-label" for="entry-note">Note</label>' +
          '<input class="input" id="entry-note" name="note" placeholder="Where this came from" value="' +
            esc(state.form && state.form.note || "") + '"></div>' +
      "</div>" +
      '<div class="row" style="margin-top:16px">' +
        '<button type="submit" class="btn btn-primary">Add address</button>' +
        '<div class="spacer"></div>' +
        '<span class="field-hint" style="margin:0">Fields marked <span class="req">*</span> are required</span>' +
      "</div>" +
    "</form></div>" +
  "</section>" +

  '<section class="card">' +
    '<div class="card-head"><div><div class="h-section">Upload a spreadsheet</div>' +
      '<div class="muted" style="font-size:12px;margin-top:3px">An MPAN column and an email ' +
      "column. Everything else is ignored.</div></div>" +
      '<div class="spacer"></div>' +
      '<button type="button" class="btn btn-sm" data-action="download-supplier-template">Download the template</button>' +
    "</div>" +
    '<div class="card-body"><form data-form="upload-supplier-emails" novalidate data-supplier-upload>' +
      '<div class="dropzone" data-dropzone>' +
        "<p>Drag a file here, or <button type=\"button\" class=\"btn-link\" data-browse>browse to upload</button></p>" +
        '<div class="meta">.CSV or .XLSX &middot; headings <span class="mono">MPAN</span> and ' +
          '<span class="mono">Email</span> &middot; ' + POC.CONFIG.MAX_UPLOAD_MB + " MB</div>" +
        '<div class="meta" data-file-name hidden></div>' +
        '<input type="file" class="visually-hidden" data-file-input accept=".csv,.txt,.xlsx,.xlsm">' +
      "</div>" +
      '<div class="field-hint">An address already on the list is left alone rather than ' +
        "duplicated, so the same file can be uploaded again after it has been corrected. " +
        "In this demonstration any file you choose loads the same sample spreadsheet.</div>" +
      '<div class="row" style="margin-top:16px">' +
        '<button type="submit" class="btn btn-primary">Upload</button></div>' +
    "</form></div>" +
  "</section>" +
"</div>" +

(parsed && parsed.rejected.length
  ? '<section class="card">' +
    '<div class="card-head"><div><div class="h-section">' + parsed.rejected.length + " row" +
      (parsed.rejected.length === 1 ? "" : "s") + " skipped in " + esc(parsed.filename) + "</div>" +
      '<div class="muted" style="font-size:12px;margin-top:3px">The rest of the file was ' +
      "loaded. Correct these and upload it again.</div></div></div>" +
    '<div class="table-wrap"><table class="data" style="min-width:640px">' +
      "<thead><tr><th class=\"num\">Row</th><th>MPAN</th><th>Email</th><th>Reason</th></tr></thead><tbody>" +
      parsed.rejected.map(function (row) {
        return '<tr><td class="num">' + row.row + '</td><td class="mono">' +
          esc(row.raw_mpan || "-") + '</td><td class="mono muted">' + esc(row.raw_email || "-") +
          "</td><td>" + esc(row.reason) + "</td></tr>";
      }).join("") +
      "</tbody></table></div></section>"
  : "") +

'<section class="card">' +
  '<div class="card-head"><div><div class="h-section">Addresses held</div>' +
    '<div class="muted" style="font-size:12px;margin-top:3px">' + matching.length + " address" +
      (matching.length === 1 ? "" : "es") +
      (state.query ? ' matching "' + esc(state.query) + '"' : "") + ".</div></div>" +
    '<div class="spacer"></div>' +
    '<form data-form="search-supplier-emails" class="row" style="margin:0">' +
      '<input type="search" class="input mono" name="q" value="' + esc(state.query || "") +
        '" style="width:220px" placeholder="MPAN or email" aria-label="Search the supplier email list">' +
      '<button type="submit" class="btn btn-sm">Search</button>' +
      (state.query ? '<button type="button" class="btn btn-sm btn-ghost" data-action="clear-supplier-query">Clear</button>' : "") +
    "</form>" +
  "</div>" +
  (entries.length
    ? '<div class="table-wrap"><table class="data" style="min-width:820px">' +
      "<thead><tr><th>MPAN</th><th>Email</th><th>Added</th><th>Note</th>" +
      "<th><span class=\"visually-hidden\">Actions</span></th></tr></thead><tbody>" + rows +
      "</tbody></table></div>" +
      (pages > 1
        ? '<div class="card-foot row"><span>Page ' + page + " of " + pages + "</span>" +
          '<div class="spacer"></div>' +
          (page > 1 ? '<button type="button" class="btn btn-sm" data-action="supplier-page" data-page="' + (page - 1) + '">Previous</button>' : "") +
          (page < pages ? '<button type="button" class="btn btn-sm" data-action="supplier-page" data-page="' + (page + 1) + '">Next</button>' : "") +
          "</div>"
        : "")
    : '<div class="empty-state"><h3>' +
      (state.query ? 'Nothing matches "' + esc(state.query) + '"' : "No addresses have been added yet") +
      "</h3><p>" +
      (state.query ? "Clear the search to see the whole list."
                   : "Every supplier address currently comes from Durabill. Add one above, or " +
                     "upload a spreadsheet, for the supplies Durabill has no row for.") +
      "</p></div>") +
"</section>";

    return POC.layout({
      nav: "supplier_emails", crumb: "CHHMax Demand Data",
      title: "Supplier email list", body: body
    });
  };

  /* =======================================================================
     Profile and password
     ======================================================================= */

  function historyTable(entries, withUser) {
    if (!entries.length) { return ""; }
    return '<div class="table-wrap"><table class="data" style="min-width:820px">' +
      "<thead><tr><th>When</th>" + (withUser ? "<th>User</th>" : "") +
      "<th>Method</th><th>Criteria</th><th>Period</th><th class=\"num\">MPANs</th>" +
      "<th class=\"num\">Rows</th>" + (withUser ? "<th class=\"num\">Duration</th>" : "") +
      "<th>Outcome</th></tr></thead><tbody>" +
      entries.map(function (entry) {
        return "<tr>" +
          '<td class="mono muted">' + dt(entry.at) + "</td>" +
          (withUser ? '<td class="mono">' + esc(entry.username) + "</td>" : "") +
          "<td>" + esc(entry.method) + "</td>" +
          '<td class="mono muted" style="max-width:240px">' + esc(entry.criteria) + "</td>" +
          "<td>" + esc(entry.periodLabel) + "</td>" +
          '<td class="num">' + entry.mpanCount + "</td>" +
          '<td class="num">' + entry.rowCount + "</td>" +
          (withUser ? '<td class="num">' + entry.durationMs + " ms</td>" : "") +
          '<td><span class="badge ' + (entry.outcome === "success" ? "badge-ok" : "badge-danger") +
            '">' + esc(entry.outcome) + "</span></td>" +
        "</tr>";
      }).join("") + "</tbody></table></div>";
  }

  views.profile = function () {
    var user = POC.store.currentUser;
    var mine = POC.store.history.filter(function (entry) {
      return entry.username === user.username;
    }).slice(0, 15);

    var body =
'<section class="card">' +
  '<div class="card-head"><div class="h-section">Account</div></div>' +
  '<div class="card-body"><div class="facts">' +
    '<div class="fact"><div class="fact-k">Name</div><div class="fact-v">' +
      esc(user.firstName + " " + user.lastName) + "</div></div>" +
    '<div class="fact"><div class="fact-k">Username</div><div class="fact-v mono">' + esc(user.username) + "</div></div>" +
    '<div class="fact"><div class="fact-k">Email</div><div class="fact-v">' + esc(user.email) + "</div></div>" +
    '<div class="fact"><div class="fact-k">Role</div><div class="fact-v">' + esc(user.role) + "</div></div>" +
    '<div class="fact"><div class="fact-k">Status</div><div class="fact-v">' + esc(user.status) + "</div></div>" +
    '<div class="fact"><div class="fact-k">Last sign-in</div><div class="fact-v mono">' +
      dt(user.lastLoginAt) + "</div></div>" +
  "</div>" +
  '<div class="row" style="margin-top:16px"><a class="btn" href="#/password">Change password</a></div>' +
  "</div>" +
"</section>" +
'<section class="card">' +
  '<div class="card-head"><div class="h-section">Your recent searches</div></div>' +
  (mine.length
    ? historyTable(mine, false)
    : '<div class="empty-state"><h3>You have not run a search yet</h3>' +
      '<div class="actions"><a class="btn btn-primary" href="#/search">Start a search</a></div></div>') +
"</section>";

    return POC.layout({ nav: "home", crumb: "Account", title: "My profile", body: body });
  };

  views.password = function (state) {
    var errors = state.errors || {};
    var body =
'<section class="card" style="max-width:520px">' +
  '<div class="card-head"><div class="h-section">Change password</div></div>' +
  '<div class="card-body"><form data-form="change-password" novalidate>' +
    ["current:Current password", "next:New password", "confirm:Confirm new password"]
      .map(function (pair) {
        var parts = pair.split(":");
        return '<div class="field"><label class="field-label" for="pw-' + parts[0] + '">' +
          esc(parts[1]) + "</label>" +
          '<input class="input' + (errors[parts[0]] ? " has-error" : "") +
          '" type="password" id="pw-' + parts[0] + '" name="' + parts[0] + '">' +
          fieldErrors(errors, parts[0]) + "</div>";
      }).join("") +
    '<p class="field-hint" style="margin-bottom:16px">At least 12 characters, with upper ' +
      "and lower case, a digit and a symbol. The last 5 passwords cannot be reused.</p>" +
    '<button type="submit" class="btn btn-primary">Change password</button>' +
  "</form></div>" +
"</section>";

    return POC.layout({ nav: "home", crumb: "Account", title: "Change password", body: body });
  };

  /* =======================================================================
     Administration - users
     ======================================================================= */

  views.adminUsers = function (state) {
    var store = POC.store;
    var query = (state.query || "").trim().toLowerCase();
    // Ordered by username, as the live service orders them.
    var matching = store.users.filter(function (user) {
      if (!query) { return true; }
      return [user.username, user.firstName, user.lastName, user.email, user.role]
        .join(" ").toLowerCase().indexOf(query) !== -1;
    }).sort(function (left, right) {
      return left.username.localeCompare(right.username);
    });
    var pageSize = POC.CONFIG.PAGE_SIZE;
    var pages = Math.max(1, Math.ceil(matching.length / pageSize));
    var page = Math.min(Math.max(1, state.page || 1), pages);
    var rows = matching.slice((page - 1) * pageSize, page * pageSize).map(function (user) {
      return "<tr>" +
        '<td class="mono" style="font-weight:600">' + esc(user.username) + "</td>" +
        "<td>" + esc(user.firstName) + "</td><td>" + esc(user.lastName) + "</td>" +
        "<td>" + esc(user.role) + "</td>" +
        '<td class="mono muted">' + dt(user.lastLoginAt) + "</td>" +
        "<td><span class=\"badge " +
          (user.status === "Active" ? "badge-ok" : user.status === "Invited" ? "badge-warn" : "badge-danger") +
          '">' + esc(user.status) + "</span>" +
          (user.isLocked ? ' <span class="badge badge-danger">Locked</span>' : "") +
          (user.dormantWarnedAt
            ? ' <span class="badge badge-warn" title="Warned for inactivity on ' +
              day(user.dormantWarnedAt) + '">Dormant</span>' : "") +
        "</td>" +
        '<td><a href="#/admin/users/' + user.id + '">Manage</a></td>' +
      "</tr>";
    }).join("");

    var body =
"<section><h1 class=\"h-page\">Administration</h1>" +
  '<p class="lede" style="margin-top:8px">Manage who can access CHHMax demand data and how ' +
  "the service behaves. Only Service Administrators can change these settings.</p></section>" +

'<section class="card">' +
  '<div class="card-head">' +
    '<div class="h-section">Users</div>' +
    '<span class="badge badge-neutral">' + store.users.length + "</span>" +
    '<div class="spacer"></div>' +
    '<form data-form="search-users" class="row" style="gap:8px">' +
      '<input type="search" class="input" name="q" value="' + esc(state.query || "") +
        '" placeholder="Search name, username, email or role" aria-label="Search users" style="width:280px">' +
      '<button type="submit" class="btn btn-sm">Search</button>' +
      (state.query ? '<button type="button" class="btn btn-sm btn-ghost" data-action="clear-user-query">Clear</button>' : "") +
    "</form>" +
    '<a class="btn btn-sm btn-primary" href="#/admin/users/new">Create user</a>' +
  "</div>" +
  '<div class="table-wrap"><table class="data" style="min-width:900px">' +
    "<thead><tr><th>Username</th><th>First name</th><th>Last name</th><th>Role</th>" +
    "<th>Last logon</th><th>Status</th><th></th></tr></thead><tbody>" + rows + "</tbody></table></div>" +
  (rows ? "" : '<div class="empty-state"><h3>No users match this filter</h3>' +
    '<div class="actions"><button type="button" class="btn" data-action="clear-user-query">Clear filter</button></div></div>') +
  (pages > 1
    ? '<div class="pager"><span class="muted" style="margin-right:auto">Page ' + page + " of " + pages + "</span>" +
      (page > 1 ? '<button type="button" class="btn btn-sm" data-action="user-page" data-page="' + (page - 1) + '">Previous</button>' : "") +
      (page < pages ? '<button type="button" class="btn btn-sm" data-action="user-page" data-page="' + (page + 1) + '">Next</button>' : "") +
      "</div>"
    : "") +
"</section>" +

'<section class="card">' +
  '<div class="card-head"><div class="h-section">What each role can do</div></div>' +
  '<div class="card-body stack">' +
    POC.ROLES.map(function (role) {
      return '<div class="row" style="align-items:flex-start;gap:14px">' +
        '<span class="badge badge-teal" style="min-width:150px;justify-content:center">' +
        esc(role) + "</span>" +
        '<span class="muted">' + esc(POC.ROLE_HINTS[role]) + "</span></div>";
    }).join("") +
  "</div>" +
"</section>";

    return POC.layout({
      nav: "admin", sub: "users", crumb: "Administration", title: "Users", body: body
    });
  };

  views.userForm = function (state) {
    var user = state.user;
    var form = state.form;
    var errors = state.errors || {};

    var activity = user
      ? POC.store.audit.filter(function (entry) {
          return entry.username === user.username || entry.entity === user.username;
        }).slice(0, 8)
      : [];

    var body =
'<div class="row"><a class="btn btn-sm" href="#/admin/users">Back to users</a></div>' +
'<section class="card" style="max-width:720px">' +
  '<div class="card-head"><div><div class="h-section">' + (user ? "Edit user" : "Create user") + "</div>" +
    '<div class="muted" style="font-size:12px;margin-top:3px">' +
    (user ? "Username and audit history cannot be changed."
          : "The user receives an email invitation with a temporary password.") +
    "</div></div></div>" +
  '<div class="card-body"><form data-form="user" data-id="' + (user ? user.id : "") + '" novalidate>' +
    '<div class="field-grid">' +
      '<div class="field"><label class="field-label" for="u-username">Username <span class="req">*</span></label>' +
        '<input class="input mono' + (errors.username ? " has-error" : "") +
        '" id="u-username" name="username" value="' + esc(form.username) + '"' +
        (user ? " readonly" : "") + ">" + fieldErrors(errors, "username") + "</div>" +
      '<div class="field"><label class="field-label" for="u-email">Email address <span class="req">*</span></label>' +
        '<input class="input' + (errors.email ? " has-error" : "") +
        '" id="u-email" name="email" value="' + esc(form.email) + '">' +
        fieldErrors(errors, "email") + "</div>" +
      '<div class="field"><label class="field-label" for="u-first">First name <span class="req">*</span></label>' +
        '<input class="input' + (errors.firstName ? " has-error" : "") +
        '" id="u-first" name="firstName" value="' + esc(form.firstName) + '">' +
        fieldErrors(errors, "firstName") + "</div>" +
      '<div class="field"><label class="field-label" for="u-last">Last name <span class="req">*</span></label>' +
        '<input class="input' + (errors.lastName ? " has-error" : "") +
        '" id="u-last" name="lastName" value="' + esc(form.lastName) + '">' +
        fieldErrors(errors, "lastName") + "</div>" +
      '<div class="field"><label class="field-label" for="u-role">Role <span class="req">*</span></label>' +
        '<select class="select" id="u-role" name="role">' +
        POC.ROLES.map(function (role) {
          return '<option value="' + esc(role) + '"' + (form.role === role ? " selected" : "") +
            ">" + esc(role) + "</option>";
        }).join("") + "</select>" +
        '<div class="field-hint">' + esc(POC.ROLE_HINTS[form.role] || "Choose the least access the user needs.") + "</div></div>" +
      '<div class="field"><label class="field-label" for="u-status">Status</label>' +
        '<select class="select" id="u-status" name="status">' +
        POC.STATUSES.map(function (status) {
          return '<option value="' + esc(status) + '"' + (form.status === status ? " selected" : "") +
            ">" + esc(status) + "</option>";
        }).join("") + "</select></div>" +
    "</div>" +
    '<div class="row" style="margin-top:8px">' +
      '<button type="submit" class="btn btn-primary">' + (user ? "Save changes" : "Create user") + "</button>" +
      '<a class="btn btn-ghost" href="#/admin/users">Cancel</a>' +
      '<div class="spacer"></div>' +
      '<span class="field-hint" style="margin:0">Fields marked <span class="req">*</span> are required</span>' +
    "</div>" +
  "</form></div>" +
"</section>" +

(user
  ? '<section class="card" style="max-width:720px">' +
      '<div class="card-head"><div class="h-section">Account actions</div></div>' +
      '<div class="card-body row" style="gap:10px">' +
        '<button type="button" class="btn" data-action="reset-user-password" data-id="' + user.id + '">Reset password</button>' +
        (user.status !== "Suspended"
          ? '<button type="button" class="btn btn-danger" data-action="set-user-status" data-id="' +
            user.id + '" data-status="Suspended">Suspend account</button>'
          : '<button type="button" class="btn" data-action="set-user-status" data-id="' +
            user.id + '" data-status="Active">Reactivate account</button>') +
        '<div class="spacer"></div>' +
        '<span class="muted" style="font-size:12px">Created ' + dt(user.createdAt) +
          (user.createdBy ? " by " + esc(user.createdBy) : "") + "</span>" +
      "</div>" +
    "</section>" +
    (activity.length
      ? '<section class="card" style="max-width:720px">' +
        '<div class="card-head"><div class="h-section">Recent activity</div></div>' +
        '<div class="table-wrap"><table class="data">' +
        "<thead><tr><th>When</th><th>Action</th><th>Detail</th><th>Outcome</th></tr></thead><tbody>" +
        activity.map(function (entry) {
          return '<tr><td class="mono muted">' + dt(entry.at) + '</td><td class="mono">' +
            esc(entry.action) + '</td><td class="muted">' + esc(entry.entity || "-") + "</td>" +
            '<td><span class="badge ' + (entry.outcome === "success" ? "badge-ok" : "badge-warn") +
            '">' + esc(entry.outcome) + "</span></td></tr>";
        }).join("") + "</tbody></table></div></section>"
      : "")
  : "");

    return POC.layout({
      nav: "admin", sub: "users", crumb: "Administration / Users",
      title: user ? user.firstName + " " + user.lastName : "Create user", body: body
    });
  };

  /* =======================================================================
     Administration - email templates
     ======================================================================= */

  views.adminEmail = function (state) {
    var store = POC.store;
    var key = state.key;
    var spec = POC.EMAIL_SPECS[key];
    var template = store.templates[key];

    var tabs = Object.keys(POC.EMAIL_SPECS).map(function (other) {
      return '<a class="method-tab' + (other === key ? " is-active" : "") +
        '" href="#/admin/email?template=' + other + '">' + esc(POC.EMAIL_SPECS[other].name) + "</a>";
    }).join("");

    var pickerRows = Object.keys(POC.EMAIL_SPECS).map(function (other) {
      var row = store.templates[other];
      return "<tr" + (other === key ? ' class="is-peak"' : "") + ">" +
        '<td class="strong"><a href="#/admin/email?template=' + other + '">' +
          esc(POC.EMAIL_SPECS[other].name) + "</a></td>" +
        '<td class="mono muted">' + esc(row.fromAddress || "Not set") + "</td>" +
        '<td class="muted">' + (row.updatedAt
          ? dt(row.updatedAt) + (row.updatedBy ? " by " + esc(row.updatedBy) : "")
          : "Shipped default") + "</td>" +
        "<td>" + (row.fromAddress
          ? '<span class="badge badge-ok">Ready</span>'
          : '<span class="badge badge-warn">Needs a From address</span>') + "</td>" +
      "</tr>";
    }).join("");

    var body =
'<section class="card">' +
  '<div class="card-head"><div><div class="h-section">Email templates</div>' +
    '<div class="muted" style="font-size:12px;margin-top:3px">Five templates, each with its ' +
    "own sender and wording. Recipients are never typed here &mdash; they are looked up when " +
    "the message is sent.</div></div>" +
    '<div class="spacer"></div>' +
    '<div class="method-tabs" aria-label="Email template">' + tabs + "</div>" +
  "</div>" +
  '<div class="card-body"><p class="muted" style="margin:0;font-size:12.5px">' +
    esc(spec.purpose) + "</p></div>" +
  '<div class="table-wrap"><table class="data" style="min-width:640px">' +
    "<thead><tr><th>Template</th><th>From address</th><th>Last saved</th><th>Status</th></tr></thead>" +
    "<tbody>" + pickerRows + "</tbody></table></div>" +
"</section>" +

'<section class="card">' +
  '<form data-form="email-template" data-key="' + key + '" novalidate>' +
    '<div class="card-head"><div><div class="h-section">' + esc(spec.name) + "</div>" +
      '<div class="muted" style="font-size:12px;margin-top:3px">Placeholders are replaced ' +
      "with the real values as the message is sent.</div></div>" +
      '<div class="spacer"></div>' +
      '<a class="btn btn-sm" href="#/admin/email/' + key + '/preview">' + icon("eye", 14) +
        " Preview with sample data</a>" +
    "</div>" +
    '<div class="card-body">' +
      '<div class="field"><div class="field-label">To address</div>' +
        '<div class="file-card" style="align-items:flex-start"><div class="file-icon">TO</div>' +
        '<div style="min-width:0"><div style="font-weight:600">Resolved when the message is sent</div>' +
        '<div class="file-meta" style="white-space:normal">' + esc(spec.toSource) + "</div></div></div></div>" +

      '<div class="field-grid">' +
        '<div class="field"><label class="field-label" for="t-from">From address <span class="req">*</span></label>' +
          '<input class="input mono" id="t-from" name="fromAddress" value="' + esc(template.fromAddress) +
          '" placeholder="chhmax.noreply@northernpowergrid.com"></div>' +
        '<div class="field"><label class="field-label" for="t-display">Display name</label>' +
          '<input class="input" id="t-display" name="displayName" value="' + esc(template.displayName) + '">' +
          '<div class="field-hint">The name a recipient sees instead of the raw address.</div></div>' +
      "</div>" +

      (spec.supportsCc
        ? '<div class="field"><label class="field-label" for="t-cc">CC address</label>' +
          '<input class="input mono" id="t-cc" name="ccAddress" value="' + esc(template.ccAddress) + '">' +
          '<div class="field-hint">Copied on every supplier message. Separate multiple ' +
          "addresses with a semicolon. Leave empty for none.</div></div>"
        : "") +

      '<div class="field"><label class="field-label" for="t-subject">Subject line <span class="req">*</span></label>' +
        '<input class="input" id="t-subject" name="subject" value="' + esc(template.subject) + '">' +
        '<div class="field-hint">Value placeholders work here.' +
        (spec.tables.length ? ' <span class="mono">@table_</span> placeholders do not &mdash; a table cannot render on one line.' : "") +
        "</div></div>" +

      '<div class="field"><label class="field-label" for="t-body">Mail body <span class="req">*</span></label>' +
        '<textarea class="input mono" id="t-body" name="body" rows="18" ' +
        'style="line-height:1.6;resize:vertical">' + esc(template.body) + "</textarea></div>" +

      '<div class="field"><label class="field-label" for="t-signature">Signature</label>' +
        '<textarea class="input mono" id="t-signature" name="signature" rows="4" ' +
        'style="line-height:1.6;resize:vertical">' + esc(template.signature) + "</textarea>" +
        '<div class="field-hint">Sits below the body, above the standard footer.</div></div>' +

      '<div class="row" style="margin-top:20px">' +
        '<button type="submit" class="btn btn-primary">Save template</button>' +
        '<a class="btn btn-ghost" href="#/admin/email?template=' + key + '">Discard changes</a>' +
        '<div class="spacer"></div>' +
        '<span class="muted" style="font-size:12px">' +
          (template.updatedAt
            ? "Last saved " + dt(template.updatedAt) + (template.updatedBy ? " by " + esc(template.updatedBy) : "")
            : "Shipped default, never edited") + "</span>" +
      "</div>" +
    "</div>" +
  "</form>" +
  '<div class="card-head" style="border-top:1px solid var(--line-soft);border-bottom:0">' +
    '<div class="muted" style="font-size:12px">Restoring puts back the wording this release ' +
      "shipped. The From address and CC are left alone.</div>" +
    '<div class="spacer"></div>' +
    '<button type="button" class="btn btn-sm" data-action="reset-template" data-key="' + key +
      '">Restore shipped wording</button>' +
  "</div>" +
"</section>" +

'<section class="card">' +
  '<div class="card-head"><div><div class="h-section">Placeholders for ' +
    esc(spec.name.toLowerCase()) + "</div>" +
    '<div class="muted" style="font-size:12px;margin-top:3px">Type these anywhere in the ' +
    "subject, body or signature. Anything else beginning with <span class=\"mono\">@</span> " +
    "&mdash; an email address, for instance &mdash; is left exactly as typed.</div></div></div>" +
  '<div class="table-wrap"><table class="data" style="min-width:640px">' +
    "<thead><tr><th style=\"width:38%\">Placeholder</th><th>Replaced with</th></tr></thead><tbody>" +
    spec.values.map(function (pair) {
      return '<tr><td class="mono strong">' + esc(pair[0]) + '</td><td class="muted">' +
        esc(pair[1]) + "</td></tr>";
    }).join("") + "</tbody></table></div>" +
  (spec.tables.length
    ? '<div class="card-head" style="border-top:1px solid var(--line-soft)">' +
      "<div><div class=\"h-section\">Table columns</div>" +
      '<div class="muted" style="font-size:12px;margin-top:3px">Write these together &mdash; ' +
      "one per line &mdash; and they render as a single table carrying those columns, in the " +
      "order you wrote them. Leave one out and the column does not appear.</div></div></div>" +
      '<div class="table-wrap"><table class="data" style="min-width:640px">' +
      "<thead><tr><th style=\"width:38%\">Placeholder</th><th>Column</th><th>Holds</th></tr></thead><tbody>" +
      spec.tables.map(function (row) {
        return '<tr><td class="mono strong">' + esc(row[0]) + '</td><td class="strong">' +
          esc(row[1]) + '</td><td class="muted">' + esc(row[2]) + "</td></tr>";
      }).join("") + "</tbody></table></div>"
    : "") +
  '<div class="card-body" style="border-top:1px solid var(--line-soft)">' +
    '<div class="h-section" style="margin-bottom:8px">Formatting</div>' +
    '<ul class="reject-list">' +
      "<li>A blank line starts a new paragraph.</li>" +
      "<li>Two or more consecutive <span class=\"mono\">Label: value</span> lines become a " +
        "highlighted facts panel.</li>" +
      "<li>A placeholder with nothing behind it shows as <span class=\"mono\">-</span> and " +
        "keeps its place in the panel.</li>" +
      "<li>A web address is turned into a link automatically.</li>" +
    "</ul></div>" +
  '<div class="card-foot">Every message is wrapped in the ' + esc(POC.CONFIG.ORG_NAME) +
    " house style with the confidentiality footer. Use " +
    '<a href="#/admin/email/' + key + '/preview">Preview with sample data</a> to see exactly ' +
    "what a recipient gets.</div>" +
"</section>";

    return POC.layout({
      nav: "admin", sub: "email", crumb: "Administration", title: "Email templates", body: body
    });
  };

  views.emailPreview = function (state) {
    var spec = POC.EMAIL_SPECS[state.key];
    var message = state.message;

    var body =
'<div class="banner banner-info"><div><div class="banner-title">Sample data</div>' +
  "Every name, MPAN, password and figure below is invented. This is the template as saved, " +
  "rendered the same way the message itself is built &mdash; so what you approve here is what " +
  "a recipient gets.</div></div>" +

'<section class="card">' +
  '<div class="card-head"><div><div class="h-section">Message headers</div>' +
    '<div class="muted" style="font-size:12px;margin-top:3px">How the message is addressed ' +
    "once the placeholders are resolved.</div></div>" +
    '<div class="spacer"></div>' +
    '<a class="btn btn-sm" href="#/admin/email?template=' + state.key + '">Back to the template</a>' +
  "</div>" +
  '<div class="facts">' +
    '<div class="fact"><div class="fact-k">From</div><div class="fact-v mono">' +
      esc(message.sender || "Not set") + "</div></div>" +
    '<div class="fact"><div class="fact-k">To</div><div class="fact-v mono">' +
      esc(message.to.join("; ") || "-") + "</div></div>" +
    (spec.supportsCc
      ? '<div class="fact"><div class="fact-k">CC</div><div class="fact-v mono">' +
        esc(message.cc.join("; ") || "None") + "</div></div>"
      : "") +
    '<div class="fact"><div class="fact-k">Subject</div><div class="fact-v">' +
      esc(message.subject || "(no subject)") + "</div></div>" +
  "</div>" +
  (message.fromAddress ? "" :
    '<div class="card-body"><div class="banner banner-warning" style="margin:0"><div>' +
    '<div class="banner-title">This template cannot be sent yet</div>It has no From address, ' +
    "so delivery would be refused. Set one on the template before anyone relies on it." +
    "</div></div></div>") +
"</section>" +

'<section class="card">' +
  '<div class="card-head"><div class="h-section">HTML message</div><div class="spacer"></div>' +
    '<span class="badge badge-teal">As the recipient sees it</span></div>' +
  '<div style="background:var(--bg);border-top:1px solid var(--line-soft)">' + message.cardHtml + "</div>" +
"</section>" +

'<section class="card">' +
  '<div class="card-head"><div><div class="h-section">Plain text alternative</div>' +
    '<div class="muted" style="font-size:12px;margin-top:3px">Sent alongside the HTML, and ' +
    "what a text-only mail client shows.</div></div></div>" +
  '<div class="card-body"><pre class="mono" style="margin:0;white-space:pre-wrap;' +
    "word-break:break-word;font-size:12px;line-height:1.6;color:var(--muted)\">" +
    esc(message.text) + "</pre></div>" +
"</section>";

    return POC.layout({
      nav: "admin", sub: "email", crumb: "Administration",
      title: spec.name + " preview", body: body
    });
  };

  /* =======================================================================
     Administration - audit trail
     ======================================================================= */

  views.adminAudit = function (state) {
    var store = POC.store;
    var action = state.action || "";
    var username = (state.username || "").trim().toLowerCase();

    var matching = store.audit.filter(function (entry) {
      if (action && entry.action !== action) { return false; }
      if (username && (entry.username || "").toLowerCase().indexOf(username) === -1) { return false; }
      return true;
    });

    var pageSize = POC.CONFIG.AUDIT_PAGE_SIZE;
    var pages = Math.max(1, Math.ceil(matching.length / pageSize));
    var page = Math.min(Math.max(1, state.page || 1), pages);

    var tones = {
      success: "badge-ok", partial: "badge-warn", ignored: "badge-neutral", denied: "badge-warn"
    };

    var rows = matching.slice((page - 1) * pageSize, page * pageSize).map(function (entry) {
      var detail = Object.keys(entry.detail || {}).map(function (key) {
        return '<span class="mono">' + esc(key) + "</span>=" + esc(entry.detail[key]);
      }).join(" ");
      return "<tr>" +
        '<td class="mono muted">' + dt(entry.at, true) + "</td>" +
        '<td class="mono">' + esc(entry.username || "-") + "</td>" +
        '<td><div class="strong">' + esc(POC.describeAction(entry.action)) + "</div>" +
          '<div class="mono muted" style="font-size:11px">' + esc(entry.action) + "</div></td>" +
        '<td class="muted">' + esc(entry.entity || "-") + "</td>" +
        '<td><span class="badge ' + (tones[entry.outcome] || "badge-danger") + '">' +
          esc(entry.outcome) + "</span></td>" +
        '<td class="mono muted">' + esc(entry.ip || "-") + "</td>" +
        '<td class="muted" style="font-size:11.5px;max-width:340px">' + detail + "</td>" +
      "</tr>";
    }).join("");

    var options = '<option value="">All actions</option>' +
      POC.ACTION_GROUPS.map(function (group) {
        return '<optgroup label="' + esc(group[0]) + '">' +
          group[1].map(function (pair) {
            return '<option value="' + pair[0] + '"' + (pair[0] === action ? " selected" : "") +
              ">" + esc(pair[1]) + "</option>";
          }).join("") + "</optgroup>";
      }).join("");

    var body =
'<section class="card">' +
  '<div class="card-head"><div><div class="h-section">Audit trail</div>' +
    '<div class="muted" style="font-size:12px;margin-top:3px">Append-only record of every ' +
    "sign-in, search, export, email sent and administrative change. Nothing here is ever " +
    "edited or deleted.</div></div>" +
    '<span class="badge badge-neutral">' + matching.length + "</span>" +
    '<div class="spacer"></div>' +
    '<form data-form="audit-filter" class="row" style="gap:8px">' +
      '<select class="select" name="action" style="width:250px" aria-label="Filter by action">' +
        options + "</select>" +
      '<input class="input" name="username" value="' + esc(state.username || "") +
        '" placeholder="Username" aria-label="Filter by username" style="width:170px">' +
      '<button type="submit" class="btn btn-sm">Filter</button>' +
      ((action || username) ? '<button type="button" class="btn btn-sm btn-ghost" data-action="clear-audit">Clear</button>' : "") +
    "</form>" +
  "</div>" +
  '<div class="table-wrap"><table class="data" style="min-width:960px">' +
    "<thead><tr><th>When</th><th>User</th><th>Action</th><th>Entity</th><th>Outcome</th>" +
    "<th>IP</th><th>Detail</th></tr></thead><tbody>" + rows + "</tbody></table></div>" +
  (rows ? "" : '<div class="empty-state"><h3>No audit entries match this filter</h3></div>') +
  (pages > 1
    ? '<div class="pager"><span class="muted" style="margin-right:auto">Page ' + page + " of " + pages + "</span>" +
      (page > 1 ? '<button type="button" class="btn btn-sm" data-action="audit-page" data-page="' + (page - 1) + '">Previous</button>' : "") +
      (page < pages ? '<button type="button" class="btn btn-sm" data-action="audit-page" data-page="' + (page + 1) + '">Next</button>' : "") +
      "</div>"
    : "") +
"</section>";

    return POC.layout({
      nav: "admin", sub: "audit", crumb: "Administration", title: "Audit trail", body: body
    });
  };

  /* =======================================================================
     Administration - diagnostics
     ======================================================================= */

  views.adminDiagnostics = function () {
    var store = POC.store;
    var config = POC.CONFIG;

    var health = {
      backend: "poc sample dataset",
      ok: "True",
      dsn: "no Durabill connection in this build",
      mode: "in-browser",
      bulk_mode: "IN list",
      server_time: dt(POC.nowIso(), true)
    };

    var settings = {
      "Demand source": "POC sample dataset (no Durabill connection)",
      "Driver mode": "n/a - proof of concept build",
      "HHMAXDEM schema": "HHMAXDEM",
      "Period range": config.MIN_PERIOD_MONTHS + " to " + config.MAX_PERIOD_MONTHS + " months",
      "Bulk limit": config.MAX_BULK_MPANS,
      "Distributor IDs": config.DISTRIBUTOR_IDS.join(", "),
      "MPAN check digit enforced": "True",
      "Application database": "In-memory (browser session)",
      "SMTP host": "not configured - nothing is delivered",
      "SMTP port": 25,
      "SMTP transport security": "None",
      "SMTP authentication": "anonymous relay",
      "SMTP password supplied": "False"
    };

    var counts = {
      users: store.users.length,
      active_users: store.users.filter(function (user) { return user.status === "Active"; }).length,
      searches: store.history.length,
      audit_entries: store.audit.length,
      supplier_addresses_held: store.heldEntries.length
    };

    var runs = [
      { started: "2026-09-13T02:15:04", job: "account_review", key: "2026-W37", trigger: "Schedule",
        what: "2 warned, 1 suspended, 13 skipped", duration: 4.2, status: "success" },
      { started: "2026-09-13T02:15:09", job: "retention", key: "2026-W37", trigger: "Schedule",
        what: "0 audit, 0 search and 0 job rows, 4 log files deleted", duration: 1.1, status: "success" },
      { started: "2026-09-06T02:15:03", job: "account_review", key: "2026-W36", trigger: "Schedule",
        what: "1 warned, 0 suspended, 14 skipped", duration: 3.8, status: "success" },
      { started: "2026-09-06T02:15:07", job: "retention", key: "2026-W36", trigger: "Schedule",
        what: "0 audit, 0 search and 0 job rows, 3 log files deleted", duration: 0.9, status: "success" }
    ];

    function factGrid(source, big) {
      return '<div class="facts">' + Object.keys(source).map(function (key) {
        return '<div class="fact"><div class="fact-k">' + esc(key.replace(/_/g, " ")) + "</div>" +
          '<div class="fact-v ' + (big ? "big" : "mono") + '">' + esc(source[key]) + "</div></div>";
      }).join("") + "</div>";
    }

    var body =
'<div class="banner banner-warning"><div><div class="banner-title">Proof of concept build</div>' +
  "This page normally reports the live Durabill connection, the application database and the " +
  "Windows scheduler service. In this build every value is illustrative and nothing is " +
  "connected.</div></div>" +

'<section class="card">' +
  '<div class="card-head"><div class="h-section">Durabill connectivity</div>' +
    '<div class="spacer"></div><span class="badge badge-ok">Connected (sample)</span></div>' +
  '<div class="card-body">' + factGrid(health, false) + "</div>" +
"</section>" +

'<section class="card">' +
  '<div class="card-head"><div class="h-section">Configuration in force</div></div>' +
  '<div class="card-body">' + factGrid(settings, false) + "</div>" +
"</section>" +

'<section class="card">' +
  '<div class="card-head"><div class="h-section">Application database</div></div>' +
  '<div class="card-body">' + factGrid(counts, true) + "</div>" +
"</section>" +

'<section class="card">' +
  '<div class="card-head"><div class="h-section">Scheduled jobs</div>' +
    '<div class="spacer"></div><span class="badge badge-ok">Enabled</span></div>' +
  '<div class="card-body"><div class="facts">' +
    '<div class="fact"><div class="fact-k">Dormant account review</div>' +
      '<div class="fact-v">Warn after 9 months of no sign-in, suspend 7 days later</div></div>' +
    '<div class="fact"><div class="fact-k">Data retention</div>' +
      '<div class="fact-v">Delete audit trail, search history and job history over 365 days ' +
      "old, and log files over 90 days old</div></div>" +
    '<div class="fact"><div class="fact-k">Schedule</div>' +
      '<div class="fact-v">Every Sunday at 02:15 UTC</div></div>' +
    '<div class="fact"><div class="fact-k">Run by</div><div class="fact-v">Windows service ' +
      '(CHHMaxDemandScheduler)<div class="muted" style="font-size:12px;margin-top:2px">No IIS ' +
      "worker runs these jobs. If the service is stopped, nothing runs them.</div></div></div>" +
    '<div class="fact"><div class="fact-k">Next occurrence</div>' +
      '<div class="fact-v mono">20 Sep 2026, 02:15</div></div>' +
  "</div></div>" +
  '<div class="table-wrap"><table class="data" style="min-width:820px">' +
    "<thead><tr><th>Started</th><th>Job</th><th>Occurrence</th><th>Trigger</th>" +
    "<th>What it did</th><th class=\"num\">Duration</th><th>Outcome</th></tr></thead><tbody>" +
    runs.map(function (run) {
      return '<tr><td class="mono muted">' + dt(run.started) + "</td>" +
        "<td>" + (run.job === "retention" ? "Data retention sweep" : "Dormant account review") + "</td>" +
        '<td class="mono">' + esc(run.key) + "</td><td>" + esc(run.trigger) + "</td>" +
        "<td>" + esc(run.what) + '</td><td class="num">' + run.duration.toFixed(1) + " s</td>" +
        '<td><span class="badge badge-ok">' + esc(run.status) + "</span></td></tr>";
    }).join("") + "</tbody></table></div>" +
"</section>" +

'<section class="card">' +
  '<div class="card-head"><div class="h-section">Recent searches (all users)</div></div>' +
  historyTable(store.history.slice(0, 15), true) +
"</section>";

    return POC.layout({
      nav: "admin", sub: "diagnostics", crumb: "Administration", title: "Diagnostics", body: body
    });
  };

  /* =======================================================================
     Errors
     ======================================================================= */

  views.notFound = function (route) {
    return POC.layout({
      nav: "", crumb: "Not found", title: "Page not found",
      body: '<section class="card"><div class="empty-state"><h3>Page not found</h3>' +
        '<p>There is nothing at <span class="mono">' + esc(route) + "</span> in this " +
        "demonstration build.</p>" +
        '<div class="actions"><a class="btn btn-primary" href="#/home">Back to home</a></div>' +
        "</div></section>"
    });
  };

  views.denied = function () {
    return POC.layout({
      nav: "", crumb: "Access denied", title: "Access denied",
      body: '<section class="card"><div class="empty-state"><h3>You do not have access to this page</h3>' +
        "<p>Your role does not carry this permission. Switch to the administrator " +
        "demonstration account to see it.</p>" +
        '<div class="actions"><a class="btn btn-primary" href="#/home">Back to home</a></div>' +
        "</div></section>"
    });
  };

}(window));
