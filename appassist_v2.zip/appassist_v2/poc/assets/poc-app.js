/* CHHMax Demand - Proof of Concept build.
   ---------------------------------------------------------------------------
   Router, screen state and every interaction. One delegated listener set is
   installed at start-up; render() replaces the page and never re-binds. */

(function (global) {
  "use strict";

  var POC = global.POC;
  var esc = POC.esc;
  var num = POC.num;

  var app = document.getElementById("app");

  /* =======================================================================
     Page state

     The Flask service keeps this in the session; the POC keeps it here, so
     criteria survive a trip to a supply and back exactly as they do live.
     ======================================================================= */

  var page = {
    login: { username: "", error: "", notice: "" },
    forgot: { submitted: false },
    search: null,
    supplierEmails: { query: "", page: 1, form: {}, errors: {} },
    users: { query: "", page: 1 },
    userForm: null,
    email: { key: "supplier" },
    audit: { action: "", username: "", page: 1 },
    password: { errors: {} }
  };

  function freshSearch() {
    return {
      criteria: {
        method: "mpan", period: "12", months: 12,
        mpan: "", postcode: "", batch: null
      },
      state: "idle", outcome: null, errors: {}, banner: "", describe: ""
    };
  }

  page.search = freshSearch();
  POC.store.search = page.search;

  function describeCriteria(criteria) {
    if (criteria.method === "postcode") { return criteria.postcode.toUpperCase(); }
    if (criteria.method === "bulk") {
      return criteria.batch
        ? criteria.batch.filename + " (" + criteria.batch.accepted.length + " MPANs)"
        : "no file";
    }
    return criteria.mpan;
  }

  /* =======================================================================
     Toasts
     ======================================================================= */

  var pendingToasts = [];

  function toast(message) {
    pendingToasts.push(message);
    flushToasts();
  }

  function flushToasts() {
    var tray = document.querySelector("[data-toast-tray]");
    if (!tray) { return; }
    while (pendingToasts.length) {
      var message = pendingToasts.shift();
      var node = document.createElement("div");
      node.className = "toast";
      node.setAttribute("role", "status");
      node.innerHTML = "<span>" + esc(message) + "</span>" +
        '<button type="button" class="toast-close" aria-label="Dismiss">&times;</button>';
      tray.appendChild(node);
      (function (element) {
        element.querySelector(".toast-close").addEventListener("click", function () {
          element.remove();
        });
        setTimeout(function () { element.remove(); }, 6000);
      }(node));
    }
  }

  POC.toast = toast;

  /* =======================================================================
     Email rendering (app/core/email_theme.py, in miniature)
     ======================================================================= */

  var THEME = {
    ink: "#1b2733", muted: "#5c6b7a", faint: "#8494a3", line: "#dde3e9",
    lineSoft: "#eef1f4", lineStrong: "#cfd8e0", bg: "#f4f6f8",
    surfaceMuted: "#fbfcfd", surfaceHead: "#f8fafb", panel: "#10262c", teal: "#0b6b74",
    sans: "'IBM Plex Sans',Helvetica,Arial,sans-serif",
    mono: "'IBM Plex Mono','Cascadia Mono',Consolas,monospace"
  };

  function substitute(text, values) {
    var tokens = Object.keys(values).sort(function (a, b) { return b.length - a.length; });
    var output = text;
    tokens.forEach(function (token) {
      var pattern = new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g");
      output = output.replace(pattern, values[token]);
    });
    return output;
  }

  function linkify(text) {
    return esc(text).replace(/(https?:\/\/[^\s<]+)/g, function (url) {
      return '<a href="' + url + '" style="color:' + THEME.teal + '">' + url + "</a>";
    });
  }

  function sampleSupplier() {
    var window = POC.resolveWindow("12");
    return POC.aggregate(POC.store.supplies[0], window);
  }

  function sampleValues(key) {
    if (key === "supplier") {
      var supply = sampleSupplier();
      var window = POC.resolveWindow("12");
      return {
        "@MPAN": supply.mpan,
        "@Period": window.label + " (" + window.describe + ")",
        "@Occupier": supply.occupier,
        "@Address": supply.address,
        "@Postcode": supply.postcode,
        "@Agreed capacity (kVA)": num(supply.agreedCapacity),
        "@Max MD (kVA)": num(supply.maxKva),
        "@Min MD (kVA)": num(supply.minKva),
        "@Average MD (kVA)": num(supply.avgKva)
      };
    }
    return {
      "@username": "s.taylor",
      "@password": "Xk7#pQ2v-demo",
      "@fullname": "Sam Taylor",
      "@signin_url": "https://chhmax.northernpowergrid.com/login",
      "@role": "Registration analyst",
      "@role_details": "As Registration analyst, you can search demand data by MPAN or " +
        "postcode, run bulk MPAN uploads, export results to Excel, send demand reports to " +
        "suppliers by email and maintain the supplier email list.",
      "@last_login": "12 Dec 2025, 09:14",
      "@inactive_months": "9",
      "@admin_contact": "chhmax.support@northernpowergrid.com",
      "@deadline": "25 Sep 2026",
      "@grace_days": "7",
      "@suspended_on": "13 Sep 2026"
    };
  }

  function factsPanel(pairs) {
    return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" ' +
      'style="background:' + THEME.surfaceHead + ";border:1px solid " + THEME.lineSoft +
      ';border-radius:6px;margin:0 0 14px"><tr><td style="padding:14px 16px">' +
      pairs.map(function (pair) {
        return '<div style="margin:0 0 9px">' +
          '<div style="font:400 10px ' + THEME.mono + ";letter-spacing:.07em;color:" +
            THEME.faint + ';text-transform:uppercase">' + esc(pair[0]) + "</div>" +
          '<div style="font:500 13px ' + THEME.sans + ";color:" + THEME.ink +
            ';margin-top:3px">' + esc(pair[1] || "-") + "</div></div>";
      }).join("") +
      "</td></tr></table>";
  }

  function dataTable(columns, rows) {
    var head = columns.map(function (column) {
      return '<th align="' + column.align + '" style="padding:9px 12px;font:600 10.5px ' +
        THEME.sans + ";letter-spacing:.06em;text-transform:uppercase;color:" + THEME.muted +
        ";background:" + THEME.surfaceHead + ";border-bottom:1px solid " + THEME.lineStrong +
        ";text-align:" + column.align + '">' + esc(column.label) + "</th>";
    }).join("");

    var bodyRows = rows.map(function (row, index) {
      return '<tr style="background:' + (index % 2 ? THEME.surfaceMuted : "#ffffff") + '">' +
        columns.map(function (column) {
          var value = row[column.field];
          return '<td align="' + column.align + '" style="padding:9px 12px;font:' +
            (column.align === "right" ? "500 12.5px " + THEME.mono : "400 12.5px " + THEME.sans) +
            ";color:" + THEME.ink + ";border-bottom:1px solid " + THEME.lineSoft +
            ";text-align:" + column.align + '">' + esc(value) + "</td>";
        }).join("") + "</tr>";
    }).join("");

    return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" ' +
      'style="border-collapse:collapse;border:1px solid ' + THEME.line +
      ';border-radius:6px;margin:0 0 14px"><thead><tr>' + head + "</tr></thead><tbody>" +
      bodyRows + "</tbody></table>";
  }

  /* Turns a saved template body into the HTML a recipient sees. Blank lines
     start paragraphs; two or more consecutive "Label: value" lines become a
     facts panel; a run of @table_ tokens becomes the monthly table. */
  function renderBody(spec, template, values) {
    var tableTokens = {};
    spec.tables.forEach(function (row) { tableTokens[row[0]] = row; });

    var blocks = template.body.split(/\n\s*\n/);
    var html = "";
    var text = [];

    blocks.forEach(function (block) {
      var lines = block.split("\n").map(function (line) { return line.trim(); })
                       .filter(function (line) { return line.length; });
      if (!lines.length) { return; }

      var wanted = lines.filter(function (line) { return tableTokens[line]; });
      if (wanted.length && wanted.length === lines.length) {
        var columns = wanted.map(function (line) {
          var row = tableTokens[line];
          return { label: row[1], align: row[3], field: row[4] };
        });
        var supply = sampleSupplier();
        var rows = supply.rows.map(function (row) {
          return {
            month: row.monthLabel,
            capacity: num(row.capacity),
            maxKva: num(row.peakKva),
            mdDay: row.mdDay,
            hh: row.hh || "-",
            peakKw: num(row.peakKw)
          };
        });
        html += dataTable(columns, rows);
        text.push(columns.map(function (column) { return column.label; }).join(" | "));
        rows.forEach(function (row) {
          text.push(columns.map(function (column) { return row[column.field]; }).join(" | "));
        });
        text.push("");
        return;
      }

      var pairs = [];
      var isFacts = lines.length >= 2 && lines.every(function (line) {
        var match = /^([^:]{1,60}):\s*(.*)$/.exec(substitute(line, values));
        if (!match) { return false; }
        pairs.push([match[1], match[2]]);
        return true;
      });

      if (isFacts) {
        html += factsPanel(pairs);
        pairs.forEach(function (pair) { text.push(pair[0] + ": " + (pair[1] || "-")); });
        text.push("");
        return;
      }

      var paragraph = substitute(lines.join(" "), values);
      html += '<p style="margin:0 0 12px;font:400 13.5px/1.65 ' + THEME.sans + ";color:" +
        THEME.ink + '">' + linkify(paragraph) + "</p>";
      text.push(paragraph);
      text.push("");
    });

    return { html: html, text: text.join("\n") };
  }

  function buildMessage(key) {
    var spec = POC.EMAIL_SPECS[key];
    var template = POC.store.templates[key];
    var values = sampleValues(key);
    var rendered = renderBody(spec, template, values);

    var to = key === "supplier"
      ? POC.recipientsFor(POC.store.supplies[0].mpan)
      : ["sam.taylor@example.com"];
    var cc = template.ccAddress
      ? template.ccAddress.split(";").map(function (part) { return part.trim(); }).filter(Boolean)
      : [];

    var signature = substitute(template.signature || "", values);
    var signatureHtml = signature
      ? '<div style="margin:18px 0 0;padding-top:14px;border-top:1px solid ' + THEME.lineSoft +
        ";font:400 12.5px/1.6 " + THEME.sans + ";color:" + THEME.muted + '">' +
        linkify(signature).replace(/\n/g, "<br>") + "</div>"
      : "";

    var cardHtml =
'<div style="padding:24px;background:' + THEME.bg + '">' +
  '<table role="presentation" width="640" cellpadding="0" cellspacing="0" ' +
    'style="margin:0 auto;max-width:100%;background:#ffffff;border:1px solid ' + THEME.line + ';border-radius:8px">' +
    '<tr><td style="background:' + THEME.panel + ';padding:20px 24px;border-radius:8px 8px 0 0">' +
      '<div style="font:600 16px ' + THEME.sans + ';color:#ffffff">' +
        esc(POC.CONFIG.ORG_NAME) + "</div>" +
      '<div style="font:400 10px ' + THEME.mono + ';letter-spacing:.09em;color:rgba(255,255,255,.55);margin-top:4px">' +
        esc(POC.CONFIG.ORG_STRAPLINE) + " &middot; " + esc(POC.CONFIG.APP_NAME).toUpperCase() + "</div>" +
    "</td></tr>" +
    '<tr><td style="padding:24px">' + rendered.html + signatureHtml + "</td></tr>" +
    '<tr><td style="background:' + THEME.surfaceMuted + ";padding:16px 24px;border-top:1px solid " +
      THEME.lineSoft + ';border-radius:0 0 8px 8px;font:400 11px/1.6 ' + THEME.sans + ";color:" +
      THEME.faint + '">' + esc(POC.CONFIDENTIALITY) +
      "<br>" + esc(POC.CONFIG.APP_NAME) + " v" + esc(POC.CONFIG.APP_VERSION) + " &middot; " +
      esc(POC.CONFIG.ORG_NAME) + "</td></tr>" +
  "</table>" +
"</div>";

    return {
      sender: template.fromAddress
        ? (template.displayName ? template.displayName + " <" + template.fromAddress + ">" : template.fromAddress)
        : "",
      fromAddress: template.fromAddress,
      to: to,
      cc: cc,
      subject: substitute(template.subject, values),
      cardHtml: cardHtml,
      text: rendered.text + (signature ? "\n" + signature + "\n" : "") + "\n" + POC.CONFIDENTIALITY
    };
  }

  /* =======================================================================
     Router
     ======================================================================= */

  function parseRoute() {
    var raw = (global.location.hash || "#/login").replace(/^#/, "");
    var parts = raw.split("?");
    var path = parts[0] || "/login";
    var query = {};
    (parts[1] || "").split("&").forEach(function (pair) {
      if (!pair) { return; }
      var bits = pair.split("=");
      query[decodeURIComponent(bits[0])] = decodeURIComponent(bits[1] || "");
    });
    return { path: path, query: query, segments: path.split("/").filter(Boolean) };
  }

  function go(route) {
    if (global.location.hash === "#" + route) { render(); }
    else { global.location.hash = route; }
  }

  POC.go = go;

  function render() {
    var route = parseRoute();
    var user = POC.store.currentUser;
    var segments = route.segments;

    if (!user) {
      if (route.path === "/forgot") {
        app.innerHTML = POC.views.forgot(page.forgot);
      } else {
        app.innerHTML = POC.views.login(page.login);
      }
      flushToasts();
      return;
    }

    var html;
    switch (segments[0]) {
    case undefined:
    case "home":
      html = POC.views.home();
      break;

    case "login":
    case "forgot":
      go("/home");
      return;

    case "search":
      html = POC.views.search(page.search);
      break;

    case "supply":
      html = renderSupply(segments[1], route.query);
      break;

    case "email-review":
      html = renderEmailReview(route.query);
      break;

    case "supplier-emails":
      html = POC.can("demand.supplier_email")
        ? POC.views.supplierEmails(page.supplierEmails)
        : POC.views.denied();
      break;

    case "profile":
      html = POC.views.profile();
      break;

    case "password":
      html = POC.views.password(page.password);
      break;

    case "admin":
      html = renderAdmin(segments, route.query);
      break;

    default:
      html = POC.views.notFound(route.path);
    }

    app.innerHTML = html;
    applyShellState();
    flushToasts();
    global.scrollTo(0, 0);
  }

  POC.render = render;

  function renderSupply(mpan, query) {
    var criteria = page.search.criteria;
    var period = query.period || criteria.period || "12";
    var window = POC.resolveWindow(period, criteria.months);
    var source = POC.store.suppliesByMpan[mpan];
    var supply = source ? POC.aggregate(source, window) : null;

    return POC.views.supply({
      mpan: mpan,
      supply: supply && supply.hasData ? supply : null,
      window: window,
      backPostcode: criteria.method === "postcode" && page.search.state === "results"
        ? criteria.postcode : ""
    });
  }

  function renderEmailReview(query) {
    if (!POC.can("demand.email")) { return POC.views.denied(); }

    var criteria = page.search.criteria;
    var outcome = page.search.outcome;

    // Opened straight from a supply page: run the same single-MPAN search.
    if (query.mpan) {
      criteria = {
        method: "mpan", period: criteria.period, months: criteria.months,
        mpan: query.mpan, postcode: "", batch: null
      };
      outcome = POC.runSearch(criteria);
    }

    if (!outcome || criteria.method === "postcode") {
      return POC.layout({
        nav: "demand", crumb: "CHHMax Demand Data", title: "Send to suppliers",
        body: '<section class="card"><div class="empty-state">' +
          "<h3>Run a search first</h3><p>Supplier emails are sent from the results of a " +
          "single MPAN or bulk MPAN search. A postcode search has no demand to send.</p>" +
          '<div class="actions"><a class="btn btn-primary" href="#/search">Go to search</a></div>' +
          "</div></section>"
      });
    }

    var key = describeCriteria(criteria);
    var plan = POC.store.sentPlans[key] || POC.buildPlan(outcome, criteria);
    page.emailContext = { criteria: criteria, outcome: outcome, plan: plan, key: key };

    return POC.views.emailReview({
      criteria: criteria, outcome: outcome, plan: plan,
      describe: key, sent: !!POC.store.sentPlans[key]
    });
  }

  function renderAdmin(segments, query) {
    if (!POC.can("admin.users")) { return POC.views.denied(); }

    switch (segments[1]) {
    case undefined:
    case "users":
      if (segments[2] === "new") {
        page.userForm = page.userForm && page.userForm.isNew ? page.userForm : {
          isNew: true, user: null, errors: {},
          form: { username: "", email: "", firstName: "", lastName: "",
                  role: "View only", status: "Invited" }
        };
        return POC.views.userForm(page.userForm);
      }
      if (segments[2]) {
        var user = findUser(Number(segments[2]));
        if (!user) { return POC.views.notFound("/admin/users/" + segments[2]); }
        if (!page.userForm || page.userForm.isNew || page.userForm.user.id !== user.id) {
          page.userForm = {
            isNew: false, user: user, errors: {},
            form: {
              username: user.username, email: user.email, firstName: user.firstName,
              lastName: user.lastName, role: user.role, status: user.status
            }
          };
        }
        page.userForm.user = user;
        return POC.views.userForm(page.userForm);
      }
      page.userForm = null;
      return POC.views.adminUsers(page.users);

    case "email":
      if (segments[2] && segments[3] === "preview") {
        if (!POC.EMAIL_SPECS[segments[2]]) { return POC.views.notFound("/admin/email"); }
        POC.audit("admin.email_template.preview", segments[2], "success", {});
        return POC.views.emailPreview({ key: segments[2], message: buildMessage(segments[2]) });
      }
      page.email.key = POC.EMAIL_SPECS[query.template] ? query.template : page.email.key;
      return POC.views.adminEmail(page.email);

    case "audit":
      return POC.views.adminAudit(page.audit);

    case "diagnostics":
      return POC.views.adminDiagnostics();

    default:
      return POC.views.notFound("/admin/" + segments[1]);
    }
  }

  function findUser(id) {
    var found = null;
    POC.store.users.some(function (user) {
      if (user.id === id) { found = user; return true; }
      return false;
    });
    return found;
  }

  /* =======================================================================
     Shell behaviour
     ======================================================================= */

  function applyShellState() {
    var shell = document.querySelector(".shell");
    if (!shell) { return; }
    try {
      if (global.localStorage.getItem("chhmax.poc.nav") === "collapsed") {
        shell.classList.add("nav-collapsed");
      }
    } catch (error) { /* private mode */ }
  }

  /* =======================================================================
     Sign in / out
     ======================================================================= */

  var DEMO_PASSWORD = "demo";

  function signIn(user, method) {
    POC.store.currentUser = user;
    user.lastLoginAt = POC.nowIso();
    user.isLocked = false;
    user.dormantWarnedAt = null;
    POC.audit("login.success", "", "success", { method: method });
    page.login = { username: "", error: "", notice: "" };
    toast("Signed in as " + user.firstName + " " + user.lastName + " (" + user.role + ")");
    go("/home");
    render();
  }

  function attemptLogin(username, password) {
    var wanted = String(username || "").trim().toLowerCase();
    var user = null;
    POC.store.users.some(function (candidate) {
      if (candidate.username.toLowerCase() === wanted) { user = candidate; return true; }
      return false;
    });

    page.login.username = username;

    if (!user || password !== DEMO_PASSWORD) {
      page.login.error = "Your username or password was not recognised. In this " +
        "demonstration build only the accounts listed below can sign in, and the " +
        "password is always \"demo\".";
      POC.store.audit.unshift({
        at: POC.nowIso(), username: wanted, action: "login.failed", entity: "",
        outcome: "failure", ip: "10.42.18.7", detail: { reason: "bad password" }
      });
      render();
      return;
    }

    if (user.status === "Suspended") {
      page.login.error = "This account has been suspended. Contact the service desk.";
      render();
      return;
    }
    if (user.isLocked) {
      page.login.error = "This account is locked after too many failed sign-in attempts. " +
        "An administrator can release it.";
      render();
      return;
    }

    signIn(user, "password");
  }

  function signOut(notice) {
    if (POC.store.currentUser) { POC.audit("logout", "", "success", {}); }
    POC.store.currentUser = null;
    page.login = { username: "", error: "", notice: notice || "" };
    page.search = freshSearch();
    POC.store.search = page.search;
    go("/login");
    render();
  }

  /* =======================================================================
     Search
     ======================================================================= */

  function readSearchForm(form) {
    var data = new FormData(form);
    return {
      method: form.querySelector("[data-method-input]").value,
      period: String(data.get("period") || "12"),
      months: Number(data.get("months") || 12),
      mpan: String(data.get("mpan") || "").trim(),
      postcode: String(data.get("postcode") || "").trim(),
      batch: page.search.criteria.batch
    };
  }

  function runSearchFrom(criteria) {
    var errors = {};

    if (criteria.period === "custom") {
      if (!criteria.months || criteria.months < POC.CONFIG.MIN_PERIOD_MONTHS ||
          criteria.months > POC.CONFIG.MAX_PERIOD_MONTHS) {
        errors.months = "Enter a number of months between " + POC.CONFIG.MIN_PERIOD_MONTHS +
          " and " + POC.CONFIG.MAX_PERIOD_MONTHS + ".";
      }
    }

    if (criteria.method === "mpan") {
      var check = POC.validateMpan(criteria.mpan);
      if (!check.ok) { errors.mpan = check.reason + "."; }
      else { criteria.mpan = check.core; }
    } else if (criteria.method === "postcode") {
      var postcode = POC.validatePostcode(criteria.postcode);
      if (!postcode.ok) { errors.postcode = postcode.reason; }
      else { criteria.postcode = postcode.value; }
    } else if (criteria.method === "bulk") {
      if (!criteria.batch) {
        errors.upload = "Choose a CSV or XLSX of MPANs, or load the sample list.";
      }
    }

    page.search.criteria = criteria;
    page.search.errors = errors;

    if (Object.keys(errors).length) {
      page.search.banner = "We could not run that search";
      page.search.state = page.search.state === "results" ? "results" : "idle";
      render();
      return;
    }

    page.search.banner = "";

    var busy = document.querySelector("[data-busy]");
    var submit = document.querySelector("[data-submit]");
    if (busy) { busy.hidden = false; }
    if (submit) { submit.disabled = true; submit.textContent = "Searching..."; }

    setTimeout(function () {
      var outcome = POC.runSearch(criteria);
      page.search.outcome = outcome;
      page.search.describe = describeCriteria(criteria);
      page.search.state = outcome.hasResults ? "results" : "empty";
      POC.recordSearch(criteria, outcome);
      POC.store.sentPlans = {};
      render();
    }, 550);
  }

  function sampleBatch(filename, sizeBytes) {
    var fixture = POC.store.batchFixture;
    return {
      filename: filename || fixture.filename,
      sizeBytes: sizeBytes || fixture.sizeBytes,
      totalRows: fixture.totalRows,
      accepted: fixture.accepted.slice(),
      rejected: fixture.rejected.slice(),
      uploadedAt: POC.nowIso()
    };
  }

  /* =======================================================================
     Delegated events
     ======================================================================= */

  document.addEventListener("click", function (event) {
    var target = event.target;

    // -- sidebar, sub-nav and user menu ---------------------------------
    var navToggle = target.closest("[data-nav-toggle]");
    if (navToggle) {
      var shell = document.querySelector(".shell");
      shell.classList.toggle("nav-collapsed");
      try {
        global.localStorage.setItem("chhmax.poc.nav",
          shell.classList.contains("nav-collapsed") ? "collapsed" : "open");
      } catch (error) { /* private mode */ }
      return;
    }

    var subnavToggle = target.closest("[data-subnav-toggle]");
    if (subnavToggle) {
      var subnav = document.querySelector("[data-subnav]");
      if (subnav) {
        event.preventDefault();
        var opening = subnav.hidden;
        subnav.hidden = !opening;
        subnavToggle.setAttribute("aria-expanded", opening ? "true" : "false");
        return;
      }
    }

    var userToggle = target.closest("[data-user-toggle]");
    var userMenu = document.querySelector("[data-user-menu]");
    if (userToggle && userMenu) {
      event.stopPropagation();
      userMenu.hidden = !userMenu.hidden;
      userToggle.setAttribute("aria-expanded", userMenu.hidden ? "false" : "true");
      return;
    }
    if (userMenu && !userMenu.hidden && !userMenu.contains(target)) {
      userMenu.hidden = true;
    }

    // -- dialogs --------------------------------------------------------
    var dialogOpen = target.closest("[data-dialog-open]");
    if (dialogOpen) {
      var dialog = document.getElementById(dialogOpen.getAttribute("data-dialog-open"));
      if (dialog) {
        if (dialog.showModal) { dialog.showModal(); } else { dialog.hidden = false; }
        var first = dialog.querySelector("input[type=email]");
        if (first) { first.focus(); }
      }
      return;
    }
    if (target.closest("[data-dialog-close]")) {
      var owner = target.closest("dialog");
      if (owner) { owner.close ? owner.close() : (owner.hidden = true); }
      return;
    }

    // -- search method tabs ---------------------------------------------
    var tab = target.closest("[data-method-tab]");
    if (tab) {
      event.preventDefault();
      var method = tab.getAttribute("data-method-tab");
      document.querySelectorAll("[data-method-panel]").forEach(function (panel) {
        panel.hidden = panel.getAttribute("data-method-panel") !== method;
      });
      document.querySelectorAll("[data-method-tab]").forEach(function (other) {
        var active = other.getAttribute("data-method-tab") === method;
        other.classList.toggle("is-active", active);
        other.setAttribute("aria-selected", active ? "true" : "false");
      });
      var methodInput = document.querySelector("[data-method-input]");
      if (methodInput) { methodInput.value = method; }
      page.search.criteria.method = method;
      return;
    }

    // -- month stepper ---------------------------------------------------
    var step = target.closest("[data-step]");
    if (step) {
      var input = document.querySelector("[data-months-input]");
      if (input) {
        var value = parseInt(input.value, 10);
        if (isNaN(value)) { value = 12; }
        value += parseInt(step.getAttribute("data-step"), 10);
        input.value = Math.min(POC.CONFIG.MAX_PERIOD_MONTHS,
                               Math.max(POC.CONFIG.MIN_PERIOD_MONTHS, value));
      }
      return;
    }

    if (target.closest("[data-browse]")) {
      event.preventDefault();
      var zone = target.closest("[data-dropzone]");
      var picker = zone && zone.querySelector("[data-file-input]");
      if (picker) { picker.click(); }
      return;
    }

    // -- demo account shortcut on the sign-in screen ----------------------
    var demoUser = target.closest("[data-demo-user]");
    if (demoUser) {
      document.getElementById("login-username").value = demoUser.getAttribute("data-demo-user");
      document.getElementById("login-password").value = DEMO_PASSWORD;
      document.getElementById("login-password").focus();
      return;
    }

    var action = target.closest("[data-action]");
    if (action) { handleAction(action.getAttribute("data-action"), action, event); }
  });

  document.addEventListener("change", function (event) {
    var target = event.target;

    if (target.matches("[data-period-select]")) {
      var panel = document.querySelector("[data-custom-months]");
      if (panel) { panel.hidden = target.value !== "custom"; }
      page.search.criteria.period = target.value;
      return;
    }

    if (target.matches("[data-quality-filter]")) {
      var scope = document.getElementById(target.getAttribute("data-quality-filter"));
      var note = document.querySelector('[data-quality-empty="' +
        target.getAttribute("data-quality-filter") + '"]');
      var shown = 0;
      scope.querySelectorAll("[data-quality]").forEach(function (card) {
        var match = target.value === "all" || card.getAttribute("data-quality") === target.value;
        card.hidden = !match;
        if (match) { shown += 1; }
      });
      if (note) { note.hidden = shown !== 0; }
      return;
    }

    if (target.matches("[data-file-input]")) {
      var file = target.files && target.files[0];
      if (!file) { return; }
      var form = target.closest("form");
      if (form && form.getAttribute("data-form") === "upload-supplier-emails") {
        var label = form.querySelector("[data-file-name]");
        if (label) { label.textContent = file.name; label.hidden = false; }
        form.dataset.chosen = file.name;
        return;
      }
      page.search.criteria.method = "bulk";
      page.search.criteria.batch = sampleBatch(file.name, file.size);
      page.search.errors = {};
      POC.audit("demand.bulk_upload", file.name, "success", {
        accepted: String(page.search.criteria.batch.accepted.length),
        rejected: String(page.search.criteria.batch.rejected.length)
      });
      toast("Loaded " + page.search.criteria.batch.accepted.length + " MPANs from " + file.name);
      render();
    }
  });

  document.addEventListener("input", function (event) {
    var target = event.target;
    if (!target.matches("[data-filter-input]")) { return; }
    var tableId = target.getAttribute("data-filter-input");
    var table = document.getElementById(tableId);
    if (!table) { return; }
    var note = document.querySelector('[data-filter-empty="' + tableId + '"]');
    var term = target.value.trim().toLowerCase();
    var shown = 0;
    table.querySelectorAll("tbody tr").forEach(function (row) {
      var match = !term || row.textContent.toLowerCase().indexOf(term) !== -1;
      row.hidden = !match;
      if (match) { shown += 1; }
    });
    if (note) { note.hidden = shown !== 0; }
  });

  ["dragenter", "dragover"].forEach(function (name) {
    document.addEventListener(name, function (event) {
      var zone = event.target.closest && event.target.closest("[data-dropzone]");
      if (!zone) { return; }
      event.preventDefault();
      zone.classList.add("is-dragover");
    });
  });

  ["dragleave", "drop"].forEach(function (name) {
    document.addEventListener(name, function (event) {
      var zone = event.target.closest && event.target.closest("[data-dropzone]");
      if (!zone) { return; }
      event.preventDefault();
      zone.classList.remove("is-dragover");
      if (name === "drop" && event.dataTransfer && event.dataTransfer.files.length) {
        var picker = zone.querySelector("[data-file-input]");
        if (picker) {
          picker.files = event.dataTransfer.files;
          picker.dispatchEvent(new Event("change", { bubbles: true }));
        }
      }
    });
  });

  document.addEventListener("keydown", function (event) {
    if (event.key !== "Escape") { return; }
    var menu = document.querySelector("[data-user-menu]");
    if (menu) { menu.hidden = true; }
  });

  document.addEventListener("submit", function (event) {
    var form = event.target;
    var name = form.getAttribute("data-form");
    if (!name) { return; }
    event.preventDefault();
    handleSubmit(name, form);
  });

  /* =======================================================================
     Form handlers
     ======================================================================= */

  function handleSubmit(name, form) {
    var data = new FormData(form);

    switch (name) {
    case "login":
      attemptLogin(data.get("username"), data.get("password"));
      break;

    case "forgot":
      page.forgot.submitted = true;
      POC.store.audit.unshift({
        at: POC.nowIso(), username: String(data.get("username") || "").toLowerCase(),
        action: "password.reset_requested", entity: "", outcome: "success",
        ip: "10.42.18.7", detail: { channel: "self service" }
      });
      render();
      break;

    case "search":
      runSearchFrom(readSearchForm(form));
      break;

    case "send-one":
      sendOne(form, data);
      break;

    case "add-supplier-email":
      addSupplierEmail(data);
      break;

    case "upload-supplier-emails":
      uploadSupplierEmails(form);
      break;

    case "search-supplier-emails":
      page.supplierEmails.query = String(data.get("q") || "");
      page.supplierEmails.page = 1;
      render();
      break;

    case "search-users":
      page.users.query = String(data.get("q") || "");
      page.users.page = 1;
      render();
      break;

    case "user":
      saveUser(form, data);
      break;

    case "email-template":
      saveTemplate(form, data);
      break;

    case "audit-filter":
      page.audit.action = String(data.get("action") || "");
      page.audit.username = String(data.get("username") || "");
      page.audit.page = 1;
      render();
      break;

    case "change-password":
      changePassword(data);
      break;

    default:
      break;
    }
  }

  function sendOne(form, data) {
    var mpan = form.getAttribute("data-mpan");
    var raw = String(data.get("address") || "");
    var addresses = raw.split(/[;,]/).map(function (part) { return part.trim(); })
                       .filter(Boolean);
    var bad = addresses.filter(function (address) { return !POC.validateEmail(address); });

    if (!addresses.length || bad.length) {
      global.alert(bad.length
        ? "This does not look like an email address: " + bad[0]
        : "Enter at least one email address.");
      return;
    }

    if (data.get("remember") && POC.can("demand.supplier_email")) {
      addresses.forEach(function (address) {
        POC.store.heldEntries.unshift({
          id: POC.store.nextEntryId++,
          mpan: mpan,
          email: address,
          note: "Typed when sending a report",
          source: "Added by hand",
          createdBy: POC.store.currentUser.username,
          createdAt: POC.nowIso()
        });
      });
    }

    POC.audit("demand.supplier_email.manual", mpan, "success", {
      to: addresses.length + " " + POC.plural(addresses.length, "address", "addresses")
    });

    var dialog = form.closest("dialog");
    if (dialog && dialog.close) { dialog.close(); }
    toast("Demand report for " + mpan + " sent to " + addresses.join("; "));
    render();
  }

  function addSupplierEmail(data) {
    var mpanRaw = String(data.get("mpan") || "");
    var email = String(data.get("email") || "").trim();
    var note = String(data.get("note") || "").trim();
    var errors = {};

    var check = POC.validateMpan(mpanRaw);
    if (!check.ok) { errors.mpan = check.reason + "."; }
    if (!POC.validateEmail(email)) { errors.email = "Enter a valid email address."; }

    var duplicate = POC.store.heldEntries.some(function (entry) {
      return entry.mpan === check.core && entry.email.toLowerCase() === email.toLowerCase();
    });
    if (!errors.email && duplicate) {
      errors.email = "That address is already on the list for this MPAN.";
    }

    page.supplierEmails.errors = errors;
    page.supplierEmails.form = { mpan: mpanRaw, email: email, note: note };

    if (Object.keys(errors).length) { render(); return; }

    POC.store.heldEntries.unshift({
      id: POC.store.nextEntryId++,
      mpan: check.core, email: email, note: note,
      source: "Added by hand",
      createdBy: POC.store.currentUser.username,
      createdAt: POC.nowIso()
    });
    POC.audit("demand.supplier_email.added", "one address", "success", { mpan: check.core });

    page.supplierEmails.form = {};
    page.supplierEmails.page = 1;
    toast("Added " + email + " for MPAN " + check.core);
    render();
  }

  function uploadSupplierEmails(form) {
    var fixture = POC.store.supplierUploadFixture;
    var filename = form.dataset.chosen || fixture.filename;
    var added = 0;
    var skipped = 0;

    fixture.rows.forEach(function (row) {
      var exists = POC.store.heldEntries.some(function (entry) {
        return entry.mpan === row.mpan && entry.email.toLowerCase() === row.email.toLowerCase();
      });
      if (exists) { skipped += 1; return; }
      added += 1;
      POC.store.heldEntries.unshift({
        id: POC.store.nextEntryId++,
        mpan: row.mpan, email: row.email, note: row.note,
        source: "Uploaded from a spreadsheet",
        createdBy: POC.store.currentUser.username,
        createdAt: POC.nowIso()
      });
    });

    POC.store.supplierUploadResult = {
      filename: filename, rejected: fixture.rejected.slice()
    };
    POC.audit("demand.supplier_email.uploaded", filename, "success", {
      added: String(added), skipped: String(skipped),
      rejected: String(fixture.rejected.length)
    });

    delete form.dataset.chosen;
    page.supplierEmails.page = 1;
    toast(added + " " + POC.plural(added, "address", "addresses") + " added from " + filename +
          (skipped ? ", " + skipped + " already held" : "") +
          (fixture.rejected.length ? ", " + fixture.rejected.length + " rows skipped" : ""));
    render();
  }

  function saveUser(form, data) {
    var id = form.getAttribute("data-id");
    var values = {
      username: String(data.get("username") || "").trim(),
      email: String(data.get("email") || "").trim(),
      firstName: String(data.get("firstName") || "").trim(),
      lastName: String(data.get("lastName") || "").trim(),
      role: String(data.get("role") || "View only"),
      status: String(data.get("status") || "Invited")
    };
    var errors = {};

    if (!values.username) { errors.username = "Enter a username."; }
    if (!values.firstName) { errors.firstName = "Enter a first name."; }
    if (!values.lastName) { errors.lastName = "Enter a last name."; }
    if (!POC.validateEmail(values.email)) { errors.email = "Enter a valid email address."; }

    var clash = POC.store.users.some(function (user) {
      return String(user.id) !== String(id) &&
        (user.username.toLowerCase() === values.username.toLowerCase() ||
         user.email.toLowerCase() === values.email.toLowerCase());
    });
    if (clash) { errors.username = "That username or email address is already in use."; }

    page.userForm.form = values;
    page.userForm.errors = errors;
    if (Object.keys(errors).length) { render(); return; }

    if (id) {
      var user = findUser(Number(id));
      var wasStatus = user.status;
      Object.keys(values).forEach(function (key) { user[key] = values[key]; });
      if (user.status !== "Suspended") { user.dormantWarnedAt = null; }
      POC.audit("admin.user.updated", user.username, "success", { role: user.role });
      if (wasStatus !== user.status) {
        POC.audit("admin.user.status", user.username, "success",
                  { from: wasStatus, to: user.status });
      }
      toast("Saved " + user.username);
      render();
      return;
    }

    var created = {
      id: POC.store.nextUserId++,
      username: values.username, email: values.email,
      firstName: values.firstName, lastName: values.lastName,
      role: values.role, status: values.status,
      lastLoginAt: null, isLocked: false, dormantWarnedAt: null,
      createdAt: POC.nowIso(), createdBy: POC.store.currentUser.username
    };
    POC.store.users.push(created);
    POC.audit("admin.user.created", created.username, "success", { role: created.role });
    POC.audit("account.email.sent", created.username, "success", { template: "Welcome mail" });
    page.userForm = null;
    toast("Created " + created.username + " - a welcome email with a temporary password " +
          "would be sent to " + created.email);
    go("/admin/users");
    render();
  }

  function saveTemplate(form, data) {
    var key = form.getAttribute("data-key");
    var template = POC.store.templates[key];
    var subject = String(data.get("subject") || "").trim();
    var body = String(data.get("body") || "").trim();

    if (!subject || !body) {
      global.alert("A template needs both a subject line and a body.");
      return;
    }

    template.fromAddress = String(data.get("fromAddress") || "").trim();
    template.displayName = String(data.get("displayName") || "").trim();
    if (POC.EMAIL_SPECS[key].supportsCc) {
      template.ccAddress = String(data.get("ccAddress") || "").trim();
    }
    template.subject = subject;
    template.body = body;
    template.signature = String(data.get("signature") || "");
    template.updatedAt = POC.nowIso();
    template.updatedBy = POC.store.currentUser.username;

    POC.audit("admin.email_template.updated", key, "success", { fields: "subject, body" });
    toast(POC.EMAIL_SPECS[key].name + " saved");
    render();
  }

  function changePassword(data) {
    var errors = {};
    var current = String(data.get("current") || "");
    var next = String(data.get("next") || "");
    var confirm = String(data.get("confirm") || "");

    if (current !== DEMO_PASSWORD) { errors.current = "That is not your current password."; }
    if (next.length < 12) { errors.next = "Use at least 12 characters."; }
    else if (!/[a-z]/.test(next) || !/[A-Z]/.test(next) || !/\d/.test(next) ||
             !/[^A-Za-z0-9]/.test(next)) {
      errors.next = "Use upper and lower case, a digit and a symbol.";
    } else if (next === current) {
      errors.next = "The new password must be different from the current one.";
    }
    if (next !== confirm) { errors.confirm = "The two passwords do not match."; }

    page.password.errors = errors;
    if (Object.keys(errors).length) { render(); return; }

    POC.audit("password.changed", "", "success", {});
    page.password.errors = {};
    toast("Password changed. In the live service you would sign in with it next time.");
    go("/profile");
    render();
  }

  /* =======================================================================
     Button actions
     ======================================================================= */

  function handleAction(action, element, event) {
    if (event) { event.preventDefault(); }

    switch (action) {
    case "sso":
      var admin = POC.store.users[0];
      signIn(admin, "single sign-on");
      break;

    case "logout":
      signOut("");
      break;

    case "switch-user":
      signOut("Signed out of the demonstration. Choose another account to see a different " +
              "level of access.");
      break;

    case "reset-demo":
      POC.resetStore();
      page.search = freshSearch();
      POC.store.search = page.search;
      page.supplierEmails = { query: "", page: 1, form: {}, errors: {} };
      page.users = { query: "", page: 1 };
      page.audit = { action: "", username: "", page: 1 };
      page.userForm = null;
      signOut("Demonstration data has been reset to its starting state.");
      break;

    case "clear-search":
      page.search = freshSearch();
      POC.store.search = page.search;
      POC.store.sentPlans = {};
      render();
      break;

    case "clear-batch":
      page.search.criteria.batch = null;
      render();
      break;

    case "use-sample-batch":
      page.search.criteria.method = "bulk";
      page.search.criteria.batch = sampleBatch();
      POC.audit("demand.bulk_upload", page.search.criteria.batch.filename, "success", {
        accepted: String(page.search.criteria.batch.accepted.length),
        rejected: String(page.search.criteria.batch.rejected.length)
      });
      render();
      break;

    case "widen-full":
      page.search.criteria.period = "full";
      runSearchFrom(page.search.criteria);
      break;

    case "widen-supply":
      go("/supply/" + element.getAttribute("data-mpan") + "?period=full");
      break;

    case "export":
      exportCurrent();
      break;

    case "export-supply":
      exportSupply(element.getAttribute("data-mpan"));
      break;

    case "download-mpan-template":
      POC.downloadCsv("chhmax-mpan-template.csv",
        [["MPAN"]].concat(POC.store.supplies.slice(0, 5).map(function (supply) {
          return [supply.mpan];
        })));
      break;

    case "download-batch-errors":
      POC.downloadCsv("mpan-upload-errors.csv",
        [["Row", "Value", "Reason"]].concat(
          page.search.criteria.batch.rejected.map(function (row) {
            return [row.row, row.value, row.reason];
          })));
      break;

    case "download-supplier-template":
      POC.downloadCsv("supplier-email-template.csv", [
        ["MPAN", "Email", "Note"],
        [POC.store.supplies[0].mpan, "settlements@supplier.example", "Optional note"]
      ]);
      break;

    case "send-supplier-emails":
      sendSupplierEmails();
      break;

    case "delete-entry":
      deleteEntry(element);
      break;

    case "supplier-page":
      page.supplierEmails.page = Number(element.getAttribute("data-page"));
      render();
      break;

    case "clear-supplier-query":
      page.supplierEmails.query = "";
      page.supplierEmails.page = 1;
      render();
      break;

    case "user-page":
      page.users.page = Number(element.getAttribute("data-page"));
      render();
      break;

    case "clear-user-query":
      page.users.query = "";
      page.users.page = 1;
      render();
      break;

    case "audit-page":
      page.audit.page = Number(element.getAttribute("data-page"));
      render();
      break;

    case "clear-audit":
      page.audit = { action: "", username: "", page: 1 };
      render();
      break;

    case "reset-user-password":
      resetUserPassword(Number(element.getAttribute("data-id")));
      break;

    case "set-user-status":
      setUserStatus(Number(element.getAttribute("data-id")),
                    element.getAttribute("data-status"));
      break;

    case "reset-template":
      resetTemplate(element.getAttribute("data-key"));
      break;

    default:
      break;
    }
  }

  function exportCurrent() {
    var context = page.emailContext;
    var outcome = page.search.outcome;
    var criteria = page.search.criteria;
    if (context && context.outcome && !outcome) {
      outcome = context.outcome;
      criteria = context.criteria;
    }
    if (!outcome) { return; }

    POC.downloadCsv(POC.exportFilename(criteria), POC.exportRows(outcome, criteria));
    POC.audit("demand.export", POC.exportFilename(criteria), "success", {
      supplies: String(outcome.supplies.length)
    });
    toast("Export downloaded. The live service writes a formatted Excel workbook; this " +
          "demonstration writes the same columns as CSV.");
  }

  function exportSupply(mpan) {
    var criteria = {
      method: "mpan", period: page.search.criteria.period,
      months: page.search.criteria.months, mpan: mpan, postcode: "", batch: null
    };
    var outcome = POC.runSearch(criteria);
    POC.downloadCsv(POC.exportFilename(criteria), POC.exportRows(outcome, criteria));
    POC.audit("demand.export", POC.exportFilename(criteria), "success", { supplies: "1" });
    toast("Export downloaded for " + mpan + ".");
  }

  function sendSupplierEmails() {
    var context = page.emailContext;
    if (!context) { return; }

    var plan = context.plan;
    if (!global.confirm("Send " + plan.ready.length + " supplier " +
        POC.plural(plan.ready.length, "email") +
        "?\n\nThis is a demonstration - no message leaves your browser.")) {
      return;
    }

    plan.sent = plan.ready.slice();
    plan.failed = [];
    POC.store.sentPlans[context.key] = plan;

    POC.audit("demand.supplier_email", plan.targets.length + " MPANs", "success", {
      sent: String(plan.sent.length),
      recipients: String(plan.recipientCount),
      manual: String(plan.manual.length)
    });

    toast(plan.sent.length + " supplier " + POC.plural(plan.sent.length, "email") +
          " sent (demonstration only - nothing was delivered).");
    render();
  }

  function deleteEntry(element) {
    var id = Number(element.getAttribute("data-id"));
    var email = element.getAttribute("data-email");
    var mpan = element.getAttribute("data-mpan");

    if (!global.confirm("Remove " + email + " from MPAN " + mpan +
        "? Searches will stop finding this address.")) {
      return;
    }

    POC.store.heldEntries = POC.store.heldEntries.filter(function (entry) {
      return entry.id !== id;
    });
    POC.audit("demand.supplier_email.deleted", email, "success", { mpan: mpan });
    toast("Removed " + email + " from MPAN " + mpan);
    render();
  }

  function resetUserPassword(id) {
    var user = findUser(id);
    if (!user) { return; }
    if (!global.confirm("Issue a new temporary password for " + user.username + "?")) { return; }

    user.status = user.status === "Suspended" ? "Suspended" : "Invited";
    POC.audit("admin.user.password_reset", user.username, "success", {});
    POC.audit("account.email.sent", user.username, "success", { template: "Welcome mail" });
    toast("A temporary password would be emailed to " + user.email + ".");
    render();
  }

  function setUserStatus(id, status) {
    var user = findUser(id);
    if (!user) { return; }
    if (status === "Suspended" &&
        !global.confirm("Suspend " + user.username + "? They will not be able to sign in.")) {
      return;
    }

    var was = user.status;
    user.status = status;
    if (status === "Active") { user.dormantWarnedAt = null; user.isLocked = false; }
    POC.audit("admin.user.status", user.username, "success", { from: was, to: status });
    if (page.userForm) { page.userForm.form.status = status; }
    toast(user.username + " is now " + status.toLowerCase() + ".");
    render();
  }

  function resetTemplate(key) {
    if (!global.confirm("Restore the shipped wording for this template? The From address " +
        "and CC are left alone.")) {
      return;
    }
    var defaults = POC.EMAIL_DEFAULTS[key];
    var template = POC.store.templates[key];
    template.subject = defaults.subject;
    template.body = defaults.body;
    template.signature = defaults.signature;
    template.displayName = defaults.displayName;
    template.updatedAt = POC.nowIso();
    template.updatedBy = POC.store.currentUser.username;
    POC.audit("admin.email_template.reset", key, "success", {});
    toast("Shipped wording restored.");
    render();
  }

  /* =======================================================================
     Start
     ======================================================================= */

  global.addEventListener("hashchange", render);

  if (!global.location.hash) { global.location.hash = "#/login"; }
  render();

}(window));
