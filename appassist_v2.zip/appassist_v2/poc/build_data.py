"""Generate the POC dummy dataset as a JavaScript file.

Everything here is invented. No production values are read from anywhere.
"""
from __future__ import annotations

import calendar
import json
import random
from datetime import date, datetime, timedelta

PRIMES = (3, 5, 7, 13, 17, 19, 23, 29, 31, 37, 41, 43)
RNG = random.Random(20260918)

DATA_CURRENT_TO = date(2026, 8, 31)
HISTORY_MONTHS = 36


def check_digit(first12: str) -> int:
    total = sum(int(d) * p for d, p in zip(first12, PRIMES))
    return total % 11 % 10


def make_mpan(distributor: str) -> str:
    body = distributor + "".join(str(RNG.randint(0, 9)) for _ in range(10))
    return body + str(check_digit(body))


def month_seq(count: int) -> list:
    """`count` month starts ending at the month of DATA_CURRENT_TO."""
    out = []
    year, month = DATA_CURRENT_TO.year, DATA_CURRENT_TO.month
    for _ in range(count):
        out.append(date(year, month, 1))
        month -= 1
        if month == 0:
            month, year = 12, year - 1
    return list(reversed(out))


# Seasonal shape: winter peaks, summer troughs. Index 0 = January.
SEASON = [1.00, 0.98, 0.93, 0.86, 0.80, 0.77, 0.78, 0.79, 0.84, 0.90, 0.96, 1.01]

WINTER_SLOTS = ["16:30-17:00", "17:00-17:30", "17:30-18:00", "08:00-08:30"]
SUMMER_SLOTS = ["12:00-12:30", "12:30-13:00", "13:00-13:30", "14:30-15:00"]

# (occupier, addr1, addr2, postcode, distributor, capacity, base kVA, profile)
SITES = [
    ("Tyne Foundry Works Ltd", "Unit 4 Quayside Industrial Estate", "Gateshead", "NE8 2BQ", "15", 1500, 1180, "industrial"),
    ("Baltic Retail Park Landlord", "Baltic Retail Park, South Shore Road", "Gateshead", "NE8 2BQ", "15", 800, 520, "retail"),
    ("Saltwell Cold Storage", "Saltwell Road South", "Gateshead", "NE8 2BQ", "15", 650, 610, "cold_store"),
    ("Gateshead Leisure Trust", "Prince Consort Road", "Gateshead", "NE8 2BQ", "15", 400, 268, "leisure"),
    ("Team Valley Print Services", "Kingsway North, Team Valley", "Gateshead", "NE8 2BQ", "15", 500, 341, "industrial"),
    ("Riverside Data Centre Ltd", "Hawks Road", "Gateshead", "NE8 2BQ", "15", 2000, 1620, "datacentre"),
    ("Ouse Valley Brewing Co", "Clifton Moor Industrial Estate", "York", "YO26 4TR", "23", 900, 742, "industrial"),
    ("Poppleton Garden Centre", "Northfield Lane", "York", "YO26 4TR", "23", 250, 132, "retail"),
    ("York West Business Park Ltd", "Millfield Lane", "York", "YO26 4TR", "23", 750, 498, "office"),
    ("Rawcliffe Care Village", "Manor Lane", "York", "YO26 4TR", "23", 300, 214, "care"),
    ("Humber Seafoods Processing", "Estate Road 5, South Humberside", "Grimsby", "DN31 1PZ", "23", 1750, 1490, "cold_store"),
    ("Alexandra Dock Logistics", "Alexandra Dock", "Grimsby", "DN31 1PZ", "23", 1100, 690, "industrial"),
    ("Freeman Street Market Ltd", "Freeman Street", "Grimsby", "DN31 1PZ", "23", 350, 228, "retail"),
    ("Grimsby Civic Offices", "Town Hall Square", "Grimsby", "DN31 1PZ", "23", 275, 176, "office"),
    ("Kingswood Retail Ltd", "Ennerdale Link Road", "Kingston upon Hull", "HU7 0YE", "23", 600, 414, "retail"),
    ("Sutton Fields Engineering", "Bergen Way, Sutton Fields", "Kingston upon Hull", "HU7 0YE", "23", 950, 878, "industrial"),
    ("Bransholme Health Campus", "Goodhart Road", "Kingston upon Hull", "HU7 0YE", "23", 450, 296, "care"),
    ("Darlington Rail Depot Ltd", "McMullen Road", "Darlington", "DL1 4QR", "15", 1250, 905, "industrial"),
    ("Yarm Road Trade Counter", "Yarm Road", "Darlington", "DL1 4QR", "15", 200, 118, "retail"),
    ("Cleveland Bridge Fabrication", "Yarm Road Industrial Estate", "Darlington", "DL1 4QR", "15", 700, 664, "industrial"),
    ("Lincoln Grain Handling Ltd", "Riseholme Road", "Lincoln", "LN2 1QQ", "23", 850, 560, "agri"),
    ("Cathedral Quarter Hotel Ltd", "Eastgate", "Lincoln", "LN2 1QQ", "23", 320, 203, "leisure"),
    ("Nettleham Fields Poultry", "Nettleham Road", "Lincoln", "LN2 1QQ", "23", 480, 392, "agri"),
    ("Durham Riverside Campus", "Stockton Road", "Durham", "DH1 3LE", "15", 1400, 968, "office"),
    ("Belmont Trading Estate Ltd", "Broomside Lane", "Durham", "DH1 3LE", "15", 550, 372, "industrial"),
    ("Framwellgate Sports Village", "Newton Drive", "Durham", "DH1 3LE", "15", 260, 158, "leisure"),
]

PROFILE_NOISE = {
    "industrial": 0.05,
    "cold_store": 0.035,
    "datacentre": 0.015,
    "retail": 0.06,
    "office": 0.055,
    "leisure": 0.08,
    "care": 0.04,
    "agri": 0.09,
}

# How hard the seasonal shape pulls. Negative is summer-peaking.
PROFILE_SEASON_PULL = {
    "datacentre": 0.15,
    "cold_store": -0.45,
    "agri": 0.35,
    "industrial": 0.7,
    "retail": 0.9,
    "office": 0.85,
    "leisure": 1.0,
    "care": 0.8,
}


# Supply index -> month positions (oldest first) with no settled peak half
# hour. Positions 24..35 are the most recent twelve months, so these are the
# supplies that read "Estimated" on a default 12-month search.
ESTIMATED_MONTHS = {
    7: (9, 28, 31),
    12: (33,),
    16: (2, 3),
    21: (26, 27),
    24: (35,),
}


def slot_for(month: int, profile: str) -> str:
    if profile == "cold_store":
        return RNG.choice(SUMMER_SLOTS if month in (5, 6, 7, 8) else WINTER_SLOTS)
    if profile == "datacentre":
        return RNG.choice(["02:00-02:30", "11:00-11:30", "15:30-16:00", "21:00-21:30"])
    return RNG.choice(WINTER_SLOTS if month in (11, 12, 1, 2, 3) else SUMMER_SLOTS)


def peak_day(month_start: date) -> date:
    """A weekday in the month, biased away from weekends."""
    last = calendar.monthrange(month_start.year, month_start.month)[1]
    for _ in range(12):
        day = RNG.randint(1, last)
        candidate = date(month_start.year, month_start.month, day)
        if candidate.weekday() < 5:
            return candidate
    return date(month_start.year, month_start.month, 15)


def build_supply(index: int, site) -> dict:
    occupier, addr1, addr2, postcode, distributor, capacity, base, profile = site
    mpan = make_mpan(distributor)
    months = month_seq(HISTORY_MONTHS)

    # A capacity uplift part way through history for a couple of sites.
    uplift_from = None
    uplift_to = capacity
    if index in (0, 10):
        uplift_from = months[18]
        uplift_to = round(capacity * 1.35 / 50) * 50

    trend = RNG.uniform(-0.04, 0.09)
    pull = PROFILE_SEASON_PULL[profile]
    noise = PROFILE_NOISE[profile]

    # Shape the whole series first, so the peaks can be scaled against the
    # agreed capacity afterwards. A site that never approaches its capacity
    # and a site that breaches it every month are both unrealistic.
    shaped = []
    for position, month_start in enumerate(months):
        seasonal = 1 + (SEASON[month_start.month - 1] - 1) * pull
        growth = 1 + trend * (position / max(1, HISTORY_MONTHS - 1))
        shaped.append(base * seasonal * growth * (1 + RNG.gauss(0, noise)))

    # Sites running their connection hot: the series is scaled so the busiest
    # month sits just under capacity, then one or two months spike over it.
    if index in (2, 10, 15, 19):
        scale = (capacity * 0.965) / max(shaped)
        shaped = [value * scale for value in shaped]
        # Push the busiest recent months over the line, so the breaches show
        # up in the periods a demonstration actually asks for.
        recent = sorted(
            range(HISTORY_MONTHS - 14, HISTORY_MONTHS),
            key=lambda offset: shaped[offset],
            reverse=True,
        )
        for offset in recent[:3]:
            shaped[offset] *= RNG.uniform(1.03, 1.12)

    rows = []
    for position, month_start in enumerate(months):
        peak_kva = round(max(shaped[position], base * 0.35), 1)

        row_capacity = capacity
        if uplift_from is not None and month_start >= uplift_from:
            row_capacity = uplift_to

        peak_kw = round(peak_kva * RNG.uniform(0.93, 0.985), 1)

        # A handful of supplies have months with no settled peak half hour;
        # those months read as Estimated, and so does the supply as a whole.
        estimated = position in ESTIMATED_MONTHS.get(index, ())
        if estimated:
            md_day, hh = "", ""
        else:
            day = peak_day(month_start)
            md_day = day.strftime("%d %b %Y")
            hh = slot_for(month_start.month, profile)

        rows.append([
            month_start.strftime("%Y-%m"),
            float(row_capacity),
            peak_kva,
            peak_kw,
            md_day,
            hh,
        ])

    rows.reverse()  # newest first, as the application orders them
    return {
        "mpan": mpan,
        "occupier": occupier,
        "addr1": addr1,
        "addr2": addr2,
        "postcode": postcode,
        "profile": profile,
        # One supply demonstrates the "duplicate months collapsed" guard.
        "duplicates": 1 if index == 11 else 0,
        "rows": rows,
    }


supplies = [build_supply(i, site) for i, site in enumerate(SITES)]

# --------------------------------------------------------------------------
# Supplier addresses: what "Durabill" holds, and what the app holds itself
# --------------------------------------------------------------------------
SUPPLIER_DOMAINS = [
    "settlements@northgate-energy.example",
    "halfhourly@penninepower.example",
    "data.services@humber-energy.example",
    "metering@caledonenergy.example",
    "settlements@airevalley-utilities.example",
    "hh.data@sixpennyenergy.example",
]

durabill_emails = {}
for position, supply in enumerate(supplies):
    if position in (5, 13, 18, 22):      # no supplier row held at all
        continue
    primary = SUPPLIER_DOMAINS[position % len(SUPPLIER_DOMAINS)]
    addresses = [primary]
    if position % 7 == 3:
        addresses.append("copy.desk@" + primary.split("@", 1)[1])
    durabill_emails[supply["mpan"]] = addresses

# The application's own list. Two of these cover MPANs Durabill has no row
# for, which is the whole point of the screen; the rest sit alongside.
held_seed = [
    (5, "connections@riverside-dc.example", "Given by the customer, Mar 2026"),
    (13, "energy.team@grimsby-civic.example", "Supplied by the billing team"),
    (0, "second.contact@northgate-energy.example", "Additional settlements contact"),
    (2, "hh.reports@caledonenergy.example", ""),
    (7, "accounts@poppleton-garden.example", "Site contact, not the supplier"),
    (10, "capacity@humber-energy.example", "Capacity review 2026"),
    (16, "estates@bransholme-health.example", ""),
    (20, "grain.ops@lincolngrain.example", "Harvest reporting"),
    (23, "energy@durham-riverside.example", "Campus energy manager"),
    (24, "site.manager@belmont-estate.example", ""),
    (8, "facilities@yorkwestbp.example", "Landlord copy"),
    (11, "logistics.energy@alexandradock.example", ""),
    (18, "trade.counter@yarmroad.example", "Added from the 2026 audit"),
    (4, "print.ops@teamvalleyprint.example", ""),
]
sources = ["Added by hand", "Uploaded from a spreadsheet"]
held_entries = []
for position, (supply_index, email, note) in enumerate(held_seed):
    held_entries.append({
        "id": position + 1,
        "mpan": supplies[supply_index]["mpan"],
        "email": email,
        "note": note,
        "source": sources[position % 2],
        "createdBy": ["a.whitfield", "s.okafor", "r.mcallister"][position % 3],
        "createdAt": (datetime(2026, 3, 4, 9, 12) + timedelta(days=position * 9, hours=position)).strftime("%Y-%m-%dT%H:%M:%S"),
    })

# --------------------------------------------------------------------------
# Users
# --------------------------------------------------------------------------
USERS = [
    ("a.whitfield", "Alan", "Whitfield", "alan.whitfield@example.com", "Admin", "Active", "2026-09-18T08:41:00", False, False),
    ("s.okafor", "Sandra", "Okafor", "sandra.okafor@example.com", "Registration analyst", "Active", "2026-09-18T07:58:00", False, False),
    ("r.mcallister", "Ruth", "McAllister", "ruth.mcallister@example.com", "Registration analyst", "Active", "2026-09-17T16:22:00", False, False),
    ("d.ellison", "David", "Ellison", "david.ellison@example.com", "View only", "Active", "2026-09-17T11:03:00", False, False),
    ("p.nayar", "Priya", "Nayar", "priya.nayar@example.com", "Admin", "Active", "2026-09-16T14:47:00", False, False),
    ("j.kowalski", "Jakub", "Kowalski", "jakub.kowalski@example.com", "Registration analyst", "Active", "2026-09-15T09:30:00", False, False),
    ("m.brennan", "Maeve", "Brennan", "maeve.brennan@example.com", "View only", "Active", "2026-09-12T13:19:00", False, False),
    ("t.ashworth", "Tom", "Ashworth", "tom.ashworth@example.com", "View only", "Invited", None, False, False),
    ("l.fernandes", "Luisa", "Fernandes", "luisa.fernandes@example.com", "Registration analyst", "Active", "2026-08-29T10:05:00", False, False),
    ("c.duffield", "Colin", "Duffield", "colin.duffield@example.com", "View only", "Active", "2025-12-19T15:44:00", False, True),
    ("h.oyelaran", "Hakeem", "Oyelaran", "hakeem.oyelaran@example.com", "Registration analyst", "Suspended", "2025-11-07T08:12:00", False, False),
    ("k.sandhu", "Kiran", "Sandhu", "kiran.sandhu@example.com", "View only", "Active", "2026-09-11T17:36:00", True, False),
    ("g.armstrong", "Gail", "Armstrong", "gail.armstrong@example.com", "Admin", "Active", "2026-09-09T08:55:00", False, False),
    ("n.petrov", "Nikolai", "Petrov", "nikolai.petrov@example.com", "Registration analyst", "Active", "2026-09-04T12:28:00", False, False),
    ("e.hargreaves", "Ellie", "Hargreaves", "ellie.hargreaves@example.com", "View only", "Invited", None, False, False),
    ("b.iqbal", "Bilal", "Iqbal", "bilal.iqbal@example.com", "View only", "Active", "2026-07-23T09:41:00", False, True),
]

users = []
for position, (username, first, last, email, role, status, last_login, locked, dormant) in enumerate(USERS):
    users.append({
        "id": position + 1,
        "username": username,
        "firstName": first,
        "lastName": last,
        "email": email,
        "role": role,
        "status": status,
        "lastLoginAt": last_login,
        "isLocked": locked,
        "dormantWarnedAt": "2026-09-13T02:15:00" if dormant else None,
        "createdAt": (datetime(2025, 4, 2, 10, 0) + timedelta(days=position * 23)).strftime("%Y-%m-%dT%H:%M:%S"),
        "createdBy": "a.whitfield" if position else "bootstrap",
    })

# --------------------------------------------------------------------------
# Seeded search history and audit trail
# --------------------------------------------------------------------------
history = []
METHODS = ["Single MPAN", "Bulk MPAN upload", "Postcode"]
PERIOD_LABELS = ["6 months", "12 months", "24 months", "Full history", "18 months"]

moment = datetime(2026, 9, 18, 8, 12)
for position in range(18):
    supply = supplies[(position * 3) % len(supplies)]
    method = METHODS[position % 3]
    if method == "Postcode":
        criteria = supply["postcode"]
        mpan_count = 0
        rows = 0
    elif method == "Bulk MPAN upload":
        criteria = "mpan-list-sep-2026.xlsx (24 MPANs)"
        mpan_count = 24
        rows = 24 * 12
    else:
        criteria = supply["mpan"]
        mpan_count = 1
        rows = 12
    user = users[(position * 5) % len(users)]
    at = moment - timedelta(hours=position * 7, minutes=position * 11)
    history.append({
        "at": at.strftime("%Y-%m-%dT%H:%M:%S"),
        "username": user["username"],
        "method": method,
        "criteria": criteria,
        "periodLabel": PERIOD_LABELS[position % len(PERIOD_LABELS)],
        "mpanCount": mpan_count,
        "rowCount": rows,
        "durationMs": RNG.randint(120, 1450),
        "outcome": "success" if position != 9 else "error",
    })

SEED_AUDIT = [
    ("login.success", "a.whitfield", "", "success", {"method": "password"}),
    ("demand.search", "s.okafor", "", "success", {"method": "postcode", "criteria": "NE8 2BQ", "rows": "96"}),
    ("demand.export", "s.okafor", "chhmax-demand-NE8-2BQ.xlsx", "success", {"supplies": "6"}),
    ("demand.supplier_email", "r.mcallister", "24 MPANs", "partial", {"sent": "21", "failed": "3"}),
    ("demand.bulk_upload", "r.mcallister", "mpan-list-sep-2026.xlsx", "success", {"accepted": "24", "rejected": "3"}),
    ("admin.user.created", "a.whitfield", "t.ashworth", "success", {"role": "View only"}),
    ("account.email.sent", "a.whitfield", "t.ashworth", "success", {"template": "Welcome mail"}),
    ("login.failed", "c.duffield", "", "failure", {"reason": "bad password", "attempt": "2"}),
    ("login.locked", "k.sandhu", "", "failure", {"attempts": "5"}),
    ("password.reset_requested", "k.sandhu", "", "ignored", {"reason": "account locked"}),
    ("admin.email_template.updated", "p.nayar", "supplier", "success", {"fields": "subject, body"}),
    ("admin.email_template.preview", "p.nayar", "supplier", "success", {}),
    ("demand.supplier_email.added", "s.okafor", "one address", "success", {"mpan": supplies[5]["mpan"]}),
    ("demand.supplier_email.uploaded", "s.okafor", "supplier-addresses.xlsx", "success", {"added": "11", "skipped": "2"}),
    ("demand.supplier_email.manual", "r.mcallister", supplies[13]["mpan"], "success", {"to": "1 address"}),
    ("job.account_review", "", "weekly review", "success", {"warned": "2", "suspended": "1", "skipped": "13"}),
    ("account.inactivity.warned", "", "c.duffield", "success", {"deadline": "20 Sep 2026"}),
    ("account.inactivity.suspended", "", "h.oyelaran", "success", {"last_login": "07 Nov 2025"}),
    ("job.retention", "", "weekly sweep", "success", {"audit_rows": "0", "search_rows": "0", "log_files": "4"}),
    ("admin.user.status", "g.armstrong", "h.oyelaran", "success", {"from": "Active", "to": "Suspended"}),
    ("admin.user.password_reset", "a.whitfield", "b.iqbal", "success", {}),
    ("access.denied", "d.ellison", "/admin/users", "denied", {"role": "View only"}),
    ("password.changed", "j.kowalski", "", "success", {}),
    ("logout", "d.ellison", "", "success", {}),
    ("demand.search", "d.ellison", "", "success", {"method": "mpan", "criteria": supplies[3]["mpan"]}),
    ("password.reset_issued", "a.whitfield", "b.iqbal", "success", {"template": "Forgot password"}),
    ("demand.export", "j.kowalski", "chhmax-demand-bulk.xlsx", "success", {"supplies": "24"}),
    ("admin.email_template.reset", "g.armstrong", "welcome", "success", {}),
    ("demand.search", "m.brennan", "", "success", {"method": "mpan", "criteria": supplies[9]["mpan"]}),
    ("login.success", "p.nayar", "", "success", {"method": "single sign-on"}),
]

IPS = ["10.42.18.7", "10.42.18.23", "10.42.19.104", "10.60.2.88", "10.42.18.51", "10.42.18.7"]
audit = []
moment = datetime(2026, 9, 18, 8, 55)
for position, (action, username, entity, outcome, detail) in enumerate(SEED_AUDIT * 2):
    at = moment - timedelta(hours=position * 3, minutes=(position * 17) % 60)
    audit.append({
        "at": at.strftime("%Y-%m-%dT%H:%M:%S"),
        "username": username,
        "action": action,
        "entity": entity,
        "outcome": outcome,
        "ip": "" if not username else IPS[position % len(IPS)],
        "detail": detail,
    })

# --------------------------------------------------------------------------
# Upload fixtures
# --------------------------------------------------------------------------
batch = {
    "filename": "mpan-list-sep-2026.xlsx",
    "sizeBytes": 18944,
    "totalRows": 26,
    # supplies[22] is deliberately in the list: it has demand but no supplier
    # address anywhere, so the send report has a row to offer "send it to an
    # address I type" on. The last two are valid MPANs nothing holds data for.
    "accepted": [s["mpan"] for s in supplies[:20]] + [supplies[22]["mpan"]] +
                [make_mpan("15"), make_mpan("23")],
    "rejected": [
        {"row": 7, "value": "15 0123 456", "reason": "MPAN must be 13 digits"},
        {"row": 14, "value": "23A456789012B", "reason": "MPAN must contain digits only"},
        {"row": 22, "value": "1500000000001", "reason": "MPAN check digit is invalid"},
    ],
}

supplier_upload = {
    "filename": "supplier-addresses-q3.xlsx",
    "sizeBytes": 11264,
    "added": 6,
    "skipped": 2,
    "rows": [
        {"mpan": supplies[3]["mpan"], "email": "hh.data@sixpennyenergy.example", "note": "Uploaded Q3 2026"},
        {"mpan": supplies[6]["mpan"], "email": "settlements@airevalley-utilities.example", "note": "Uploaded Q3 2026"},
        {"mpan": supplies[9]["mpan"], "email": "care.energy@rawcliffe-village.example", "note": "Uploaded Q3 2026"},
        {"mpan": supplies[14]["mpan"], "email": "estates@kingswood-retail.example", "note": "Uploaded Q3 2026"},
        {"mpan": supplies[21]["mpan"], "email": "duty.manager@cathedralquarter.example", "note": "Uploaded Q3 2026"},
        {"mpan": supplies[25]["mpan"], "email": "energy@framwellgate-sports.example", "note": "Uploaded Q3 2026"},
    ],
    "rejected": [
        {"row": 4, "raw_mpan": "15 8842 991", "raw_email": "data@northgate-energy.example", "reason": "MPAN must be 13 digits"},
        {"row": 9, "raw_mpan": supplies[2]["mpan"], "raw_email": "not-an-address", "reason": "Email address is not valid"},
        {"row": 15, "raw_mpan": "", "raw_email": "hh@penninepower.example", "reason": "No MPAN in this row"},
    ],
}

payload = {
    "dataCurrentTo": DATA_CURRENT_TO.isoformat(),
    "supplies": supplies,
    "durabillEmails": durabill_emails,
    "heldEntries": held_entries,
    "users": users,
    "history": history,
    "audit": audit,
    "batch": batch,
    "supplierUpload": supplier_upload,
}

out = "poc/assets/poc-data.js"
with open(out, "w", encoding="utf-8", newline="\n") as handle:
    handle.write(
        "/* CHHMax Demand POC - generated sample data.\n"
        "   Every MPAN, name, address, email address and figure below is invented\n"
        "   for demonstration. Nothing here comes from Durabill or from any\n"
        "   production system. */\n\n"
        "window.POC_DATA = "
    )
    json.dump(payload, handle, indent=1)
    handle.write(";\n")

print("wrote", out)
print("supplies:", len(supplies), "rows each:", len(supplies[0]["rows"]))
print("sample mpans:", [s["mpan"] for s in supplies[:4]])
print("postcodes:", sorted({s["postcode"] for s in supplies}))
print("no-supplier mpans:", [supplies[i]["mpan"] for i in (5, 13, 18, 22)])
