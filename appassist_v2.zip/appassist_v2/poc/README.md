# CHHMax Demand - Proof of Concept build

A standalone, browser-only demonstration of the CHHMax Demand service. It
reproduces the navigation, screens and behaviour of the real application, but
it runs entirely from these files: no Flask, no Durabill, no Oracle, no SMTP,
no database and no network calls of any kind.

**Every MPAN, name, address, occupier, email address and figure in this build
is invented.** Nothing here comes from Durabill or from any production system,
and nothing typed into it leaves the browser.

---

## Running it

Double-click `index.html`. That is the whole installation.

There is also `chhmax-demand-poc.html` - the same application bundled into one
self-contained file, with the stylesheet, the scripts and the brand artwork
inlined. It is the copy to email or hand over on a memory stick. Rebuild it
after any change with `python poc/build_single.py` (run from the project root);
edit the files under `assets/`, never the bundle.

It works from `file://`, so it can be run from a laptop, a USB stick or a
shared folder with no server and no internet connection. (Without internet the
IBM Plex webfont falls back to Helvetica/Arial; everything else is identical.)

If you would rather serve it over HTTP - for screen sharing from a fixed URL,
say:

```
cd poc
python -m http.server 8080
```

then open <http://localhost:8080/>.

Chrome, Edge and Firefox are all fine. Refreshing the page resets the
demonstration to its starting state, and so does **Reset demo data** in the
user menu.

---

## Signing in

The password for every demonstration account is `demo`. The sign-in screen
lists them; clicking one fills the form in.

| Account | Role | What it can reach |
| --- | --- | --- |
| `a.whitfield` | Admin | Everything, including Administration |
| `s.okafor` | Registration analyst | Search, bulk upload, export, supplier emails, supplier email list |
| `d.ellison` | View only | Search and export only - no bulk tab, no email, no admin |

**Switch demo user** in the user menu returns to the sign-in screen so a
different level of access can be shown without losing the thread.

Single sign-on is not offered in this build: `SSO_ENABLED` in
`assets/poc-core.js` is `false`, which is how the live sign-in page hides the
button too. Set it to `true` if a later demonstration needs it.

The access model is the real one, taken from `app/models.py`: the menu, the
buttons on the results screen and the Administration pages all appear and
disappear with the signed-in role.

---

## A ten-minute demonstration

1. **Sign in** as `a.whitfield`. Point out the sample-data banner on the home
   page - it is the same banner the live application shows when it is pointed
   at anything other than Durabill.
2. **Single MPAN.** CHHMax Demand Data -> paste `1582552748011` (Saltwell Cold
   Storage) -> Search. Twelve months of maximum demand, the peak month in teal,
   the months over agreed capacity in amber, and the aggregate facts across
   the top.
3. **Period length.** Change Period Length to `Custom...` and step the month
   count. Re-run and watch the window, the aggregates and the "months over
   capacity" count all move with it.
4. **Postcode.** Postcode tab -> `NE8 2BQ` -> Search. Six supplies; type "cold"
   in the filter to narrow the list, then open a supply to see its demand.
5. **Bulk upload.** Bulk MPAN upload tab -> drag any file onto the drop zone
   (or use the sample list link). The file card shows 23 accepted and 3 rows
   skipped, with the reasons. Search returns 21 supplies plus a banner naming
   the two MPANs that returned no data.
6. **Data quality filter.** On the bulk results, switch the Data quality
   selector to "Estimated only" - the supplies with a month that has no
   settled peak half hour.
7. **Send to suppliers.** Send email -> the per-MPAN report. Each MPAN is a
   separate message to the supplier registered against it; addresses held by
   this service are *added to* what Durabill holds, never substituted. One
   row has no supplier at all and offers "send it to an address I type".
   Send, and the screen turns into the delivery report.
8. **Supplier email list.** Add an address, upload a spreadsheet, delete a
   row. Watch the "MPANs covered" count move.
9. **Administration -> Users.** Create a user, suspend one, reset a password.
   Note the Dormant and Locked badges on the list.
10. **Administration -> Email Templates.** Pick the Supplier email template,
    change a word, then **Preview with sample data** - the rendered message,
    the facts panel, the monthly table and the plain-text alternative.
11. **Administration -> Audit Trail.** Every step above is in it, with the user,
    the outcome and the detail. This is the point of the screen: the search
    you ran ninety seconds ago is already recorded.
12. **Switch demo user** to `d.ellison` (View only) and repeat step 2. No bulk
    tab, no Send email button, no Administration menu; `#/admin/users` answers
    "Access denied".

---

## What is faithful, and what is simulated

Faithful to the live service:

- the navigation, screen layout, wording and stylesheet (`poc.css` is the
  application's own `app/static/css/app.css`, with a short POC-only section
  appended at the end);
- the role and capability matrix, and every screen it gates;
- MPAN validation, including the check digit and the 13-digit rule;
- reporting-period arithmetic - a "12 months" window is twelve whole billing
  months ending at the data-current-to date, not eleven and a fragment;
- the per-supply aggregates: max, min, average, latest agreed capacity, months
  over capacity, and the Actual/Estimated rule (a supply reads Estimated if
  *any* month in the window has no settled peak half hour);
- the supplier-address rule: Durabill's `supplier_email` and this service's
  own list are added together, never substituted;
- the audit vocabulary and the plain-English action labels.

Simulated, and called out on screen where it matters:

- **Uploads are not parsed.** Any file dropped on a drop zone loads the same
  sample result, so the accepted/rejected behaviour can be shown without
  needing a prepared spreadsheet.
- **Exports are CSV.** The live service writes a formatted Excel workbook; a
  page with no server writes the same columns as CSV, which Excel opens.
- **No email is delivered.** "Send" records the send and shows the report; no
  message leaves the browser.
- **Diagnostics values are illustrative.** That page normally reports the live
  Durabill connection, the application database and the Windows scheduler
  service.
- **Nothing persists.** All state lives in the browser tab. Refresh to reset.

---

## Files

```
poc/
  index.html            the only page; everything renders into it
  chhmax-demand-poc.html  the same build, bundled into one file
  build_single.py       rebuilds that bundle from the files below
  build_data.py         regenerates the sample dataset
  README.md             this file
  assets/
    poc.css             the application stylesheet, plus a POC-only section
    poc-data.js         the generated sample dataset (26 supplies x 36 months)
    poc-core.js         roles, periods, MPAN rules, the store, search logic
    poc-views.js        every screen, as HTML
    poc-app.js          router, events, forms, email rendering
    img/                the brand assets
```

## Changing the sample data

`assets/poc-data.js` is generated, and its header says so. It holds:

- `supplies` - 26 supplies across 7 postcodes, each with 36 monthly rows as
  `[month, agreed capacity, peak kVA, peak kW, MD day, MD half hour]`. A row
  with an empty MD day is an Estimated month.
- `durabillEmails` - the supplier addresses "Durabill" holds, keyed by MPAN.
- `heldEntries` - the supplier email list this service holds itself.
- `users`, `history`, `audit` - the seeded accounts, search history and trail.
- `batch`, `supplierUpload` - what the two upload drop zones produce.

`build_data.py` is what generated it: run `python poc/build_data.py` from the
project root to rebuild the file. It is seeded, so the same run produces the
same MPANs and the same figures every time; change the seed at the top and
every MPAN in the demonstration changes with it (including the ones quoted in
the script above).

Editing the file by hand is fine too; the demand figures only need to stay
plausible. Generated MPANs carry a valid check digit, which the search screen
enforces, so invent new ones with care - an MPAN that fails the check digit
will be rejected by the search box exactly as it would be live.

---

## Please note

This folder is a demonstration artefact. It is not part of the deployable
application, is not covered by the test suite, and should not be published to
a server that the business could mistake for the live service.
