"""Bundle the POC into one self-contained HTML file.

Inlines the stylesheet, the four scripts and the three brand SVGs, so the whole
demonstration can be emailed or carried as a single file.
"""
from __future__ import annotations

import base64
import io
import pathlib

ROOT = pathlib.Path("poc")
ASSETS = ROOT / "assets"
OUT = ROOT / "chhmax-demand-poc.html"


def read(path: pathlib.Path) -> str:
    return io.open(path, encoding="utf-8").read()


def data_uri(path: pathlib.Path) -> str:
    raw = path.read_bytes()
    return "data:image/svg+xml;base64," + base64.b64encode(raw).decode("ascii")


IMAGES = {
    "assets/img/logo.svg": data_uri(ASSETS / "img" / "logo.svg"),
    "assets/img/logo-mark.svg": data_uri(ASSETS / "img" / "logo-mark.svg"),
    "assets/img/favicon.svg": data_uri(ASSETS / "img" / "favicon.svg"),
}


def inline_images(text: str) -> str:
    for path, uri in IMAGES.items():
        text = text.replace(path, uri)
    return text


def script(path: pathlib.Path) -> str:
    # A literal </script> inside a script block would close it early. None of
    # these files contain one today; the guard keeps that true if they change.
    body = inline_images(read(path)).replace("</script>", "<\\/script>")
    return "<script>\n" + body + "\n</script>"


css = inline_images(read(ASSETS / "poc.css"))

html = read(ROOT / "index.html")

# The page shell, with every external reference replaced by its contents.
html = html.replace(
    '  <link rel="stylesheet" href="assets/poc.css">\n',
    "  <style>\n" + css + "\n  </style>\n",
)
html = html.replace(
    '  <link rel="icon" href="assets/img/favicon.svg" type="image/svg+xml">',
    '  <link rel="icon" href="' + IMAGES["assets/img/favicon.svg"] + '" type="image/svg+xml">',
)
html = html.replace("<title>CHHMax Demand - Proof of Concept</title>",
                    "<title>CHHMax Demand - Proof of Concept (single file)</title>")

scripts = "\n".join(
    script(ASSETS / name)
    for name in ("poc-data.js", "poc-core.js", "poc-views.js", "poc-app.js")
)
for name in ("poc-data.js", "poc-core.js", "poc-views.js", "poc-app.js"):
    html = html.replace('  <script src="assets/' + name + '"></script>\n', "")
html = html.replace("</body>", scripts + "\n</body>")

banner = (
    "<!--\n"
    "  CHHMax Demand - Proof of Concept, bundled as a single file.\n"
    "  Generated from poc/index.html and poc/assets/. Edit those and rebuild\n"
    "  rather than editing this file by hand.\n"
    "\n"
    "  All sample data. No Durabill connection, no production records.\n"
    "-->\n"
)
html = html.replace("<!DOCTYPE html>", "<!DOCTYPE html>\n" + banner, 1)

io.open(OUT, "w", encoding="utf-8", newline="\n").write(html)
print("wrote", OUT, f"{OUT.stat().st_size / 1024:.0f} KB")

leftovers = [ref for ref in ("assets/poc", "assets/img") if ref in html]
print("remaining external references:", leftovers or "none")
