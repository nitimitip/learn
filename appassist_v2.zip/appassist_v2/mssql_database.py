"""
mssql_database.py - MSSQL-first copy of database.py.

WHY THIS FILE EXISTS
--------------------
database.py already runs on SQL Server unchanged - set the DATABASE_URL env
var (see .env / mssql.env) and its mssql branch builds a pooled pyodbc engine.
That is the RECOMMENDED way to switch; no code changes anywhere.

This file is the same module with SQL Server as the DEFAULT and the SQLite
code path removed, for a deployment that wants MSSQL hard-wired rather than
env-selected. To use it, either:

    (a) keep importing `database` everywhere and just set DATABASE_URL
        (preferred - this file then stays unused), or
    (b) replace database.py with this file (rename this to database.py)
        so a missing/typo'd DATABASE_URL can never silently fall back
        to a local SQLite file in production.

Differences from database.py:
  * DATABASE_URL defaults to a local SQLEXPRESS trusted connection instead
    of sqlite:///project_management.db.
  * Refuses to start on a non-MSSQL URL (fail loudly, no SQLite fallback).
  * SQLite-only code removed (pragma event hook, busy-timeout plumbing).
  * Everything else (init_db, _ensure_columns, session factory) is identical
    - those were already dialect-aware.

MAINTENANCE: init_db()'s model-import block and _ensure_columns()'s additive
column list are copies of the ones in database.py and MUST be kept in
lock-step whenever a model module or additive column is added there -
otherwise a deployment that renames this file over database.py silently
misses tables/columns. tests/test_mssql_parity.py enforces that lock-step;
run it (or the whole suite) after touching either file.
"""
import os
import logging
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

logger = logging.getLogger(__name__)

# SQL Server connection URL. Override with the DATABASE_URL env var.
# Must match the TARGET_MSSQL_URL used by migrate_sqlite_to_mssql.py.
DATABASE_URL = os.environ.get(
    'DATABASE_URL',
    'mssql+pyodbc://@localhost\\SQLEXPRESS/AppAssist'
    '?driver=ODBC+Driver+17+for+SQL+Server&trusted_connection=yes',
)

if not DATABASE_URL.startswith('mssql'):
    raise RuntimeError(
        f"mssql_database.py requires an mssql+pyodbc:// DATABASE_URL, got "
        f"'{DATABASE_URL.split(':', 1)[0]}:...'. Set DATABASE_URL to your "
        f"SQL Server instance (see mssql.env), or use database.py for other "
        f"backends."
    )

# Connection-pool bounds. With 8 single-request wfastcgi workers plus the
# Windows service, each process holds at most a handful of connections;
# 10 + 20 overflow per process is comfortable headroom without letting a
# burst exhaust the SQL Server instance.
_POOL_SIZE     = int(os.environ.get('DB_POOL_SIZE',     '10'))
_POOL_OVERFLOW = int(os.environ.get('DB_POOL_OVERFLOW', '20'))

# Bounded pool so a burst of concurrent requests / sweeps cannot open an
# unlimited number of server connections. pool_pre_ping discards stale
# connections (e.g. after the DB server restarts); pool_recycle forces a
# refresh before most server-side idle timeouts kick in. fast_executemany
# dramatically speeds up batched INSERTs through pyodbc.
engine = create_engine(
    DATABASE_URL,
    echo=False,
    pool_pre_ping=True,
    pool_recycle=300,
    pool_size=_POOL_SIZE,
    max_overflow=_POOL_OVERFLOW,
    pool_timeout=30,
    fast_executemany=True,
)

# Create session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create base class.
#
# Every model does `from database import Base`, so models register on the
# Base owned by the module NAMED `database`. When this file has replaced
# database.py (recommended use, option (b) in the header) that is this
# module and a fresh Base is correct. When it is imported side-by-side as
# `mssql_database` (e.g. by a one-off script), reuse database.Base so
# init_db()/create_all() here still sees every registered model instead of
# an empty metadata.
if __name__ in ('database', '__main__'):
    Base = declarative_base()
else:
    from database import Base  # share the app's metadata


def init_db() -> None:
    """
    Initialize database - create any missing tables.

    IMPORTANT: This function deliberately does NOT drop existing tables on
    error. If you genuinely need to wipe and recreate (during development),
    call `recreate_all_tables_DESTRUCTIVE()` explicitly.
    """
    # Import models so SQLAlchemy registers them on Base.metadata.
    from models import User
    from modules.project_management.models import (
        Project, ProjectStakeholder, ProjectStatusRecipient,
        ProjectMilestone, ProjectTeamMember,
        ProjectTask, TaskDependency, TaskNote, ProjectActivity,
        ProjectRiskLog, ProjectDocument,
        ProjectBaseline, BaselineMilestone, BaselineTask,
        GoLivePlan, GoLiveTask, GoLiveConnectivity, GoLiveContact,
        HLDTemplateSection, HLDTemplateColumn,
        ProjectHLD, ProjectHLDSection, ProjectHLDRow,
        EffortResourceDefault,
        SDLCPhaseTemplate, ProjectSDLCPhase, SDLCPhaseMilestone,
    )
    from modules.application_support.models import (
        AppSupportTower, TowerMember, ApplicationCategory,
        ApplicationDetails, ServerDetails, ApplicationAssignment,
        SupportTeam, BusinessUsers, VendorDetails, ExternalInterfaces,
        IndividualJobs, SuiteJobs, FileInventory, ApplicationTask, CriticalIssue,
        SecretVaultEntry, AuditLog,
        TechCatalog, ApplicationTechStack, StandardChecklistItem,
        ApplicationStandardCompliance
    )
    from modules.mimp_report.models import (
        MIMPReport, MIMPApplicationTower, MIMPApplication,
        MIMPApplicationStatus, MIMPSchedulerLock,
    )
    from modules.utility.servers_models import (
        FieldMapping, ServerData, ServerImport, DatabaseReport,
    )
    from modules.file_monitor.models import (
        FileMonitorReport, FileMonitorAlertLog,
        FileMonitorTower, FileMonitorTowerMember,
        DtnFlowMessage, DtnFlowDataItem, DtnFlowCatalogueMeta,
    )
    from modules.application_health_check.models import (
        ApplicationTower, AppTowerMember, HealthCheckReport, URLMonitor,
        ServerMonitor, DatabaseMonitor, EmailNotificationConfig,
        HealthCheckExecution, HealthCheckHistory
    )
    from modules.security.models import (
        SecurityGroupMember, CertificateRecord, CertificateConfig,
        CertificateTeamManager,
    )
    from modules.service_now_analysis.models import (
        ServiceNowGroupMember, GuidePage, GuideDocument, AssignmentGroupContact,
        OpenIncidentEmailSettings, SnowTicketWorkload,
    )
    from modules.todo.models import TodoItem, TodoDigestLog
    from modules.user_profile.models import (
        UserSubGroup, SoftSkill, UserSkill,
    )
    from modules.activity_tracker.models import ActivityEntry
    from modules.resource_utilization.models import (WorkforceHoliday,
                                                     WorkforceSettings)
    from modules.rota.models import (
        RotaAdmin, Rota, RotaMember, RotaShift, RotaAssignment,
        RotaHandover, RotaRequest, RotaAlert, RotaAudit,
    )
    from modules.code_sentinel.models import (
        CodeProject, CodeScan, CodeFinding, CodeTriage, CodeApiToken,
    )
    from modules.software_inventory.models import (
        SoftwareGroupMember, SoftwareItem, SoftwareItemTower, SoftwareVersion,
    )
    # Shared version trail for uploaded documents (project docs today; the
    # application-support and ServiceNow-guide files use the same table).
    from file_versions import DocumentVersion

    # Rota: move the previous build's tables aside BEFORE create_all() so the
    # new, smaller ones can be created under the proper names. The rows are
    # carried across by ensure_rota_schema() once the tables exist - the two
    # halves have to straddle create_all(). Idempotent; see
    # modules/rota/schema.py.
    from modules.rota.schema import retire_legacy_rota_tables
    retire_legacy_rota_tables(engine)


    try:
        Base.metadata.create_all(bind=engine)
        logger.info("Database initialized - tables created or already present.")
    except Exception as e:
        # NEVER drop on failure - that destroys production data including
        # APScheduler jobs and MIMP status history. Just log loudly and
        # let the developer fix the model error.
        logger.error(
            "Database create_all() failed: %s. "
            "Tables were NOT dropped. Investigate the model definition error.",
            e,
            exc_info=True,
        )
        raise

    # ------------------------------------------------------------------
    # Apply indexes that were added to already-existing tables.
    # create_all() does not add newly-declared indexes to a table that
    # already exists; CREATE each declared index with checkfirst=True so
    # the step is fully idempotent and never touches data.
    # ------------------------------------------------------------------
    try:
        created = 0
        for table in Base.metadata.sorted_tables:
            for index in table.indexes:
                try:
                    index.create(bind=engine, checkfirst=True)
                    created += 1
                except Exception as idx_err:
                    # One bad index must not abort startup - log and move on.
                    logger.warning(
                        "Could not ensure index %s on %s: %s",
                        index.name, table.name, idx_err,
                    )
        logger.info("Index reconciliation complete - %d index(es) ensured.",
                    created)
    except Exception as e:
        # Index reconciliation is best-effort; never fatal.
        logger.warning("Index reconciliation step failed: %s", e, exc_info=True)

    # ------------------------------------------------------------------
    # Lightweight additive column migrations (ALTER TABLE ... ADD).
    # Idempotent: a column that already exists is detected and skipped.
    # ------------------------------------------------------------------
    _ensure_columns()
    from modules.application_health_check.schema import ensure_health_schema
    ensure_health_schema(engine)
    # Rota: copy the rotas, members, shifts, assignments, handovers and
    # requests from the retired tables into the new ones. Runs once, on the
    # first boot after the rebuild - see modules/rota/schema.py.
    from modules.rota.schema import ensure_rota_schema
    ensure_rota_schema(engine)



def _ensure_columns(target_engine=None) -> None:
    """
    Add columns that were introduced after their table already existed.

    Dialect-aware: SQL Server uses ``ALTER TABLE ... ADD`` (no COLUMN keyword)
    and ``BIT`` instead of ``BOOLEAN``. The dialect branches are kept so the
    SQLite->MSSQL migration script can pass either engine here.
    """
    from sqlalchemy import inspect, text

    engine = target_engine if target_engine is not None else globals()['engine']
    dialect = engine.dialect.name.lower()
    is_mssql = dialect in ('mssql', 'pyodbc')

    # Portable column spec: (table, column, generic_type, not_null, default_literal)
    #   generic_type    - 'DATE' | 'BOOLEAN' | 'INTEGER' | 'VARCHAR(n)'
    #   not_null        - bool
    #   default_literal - None | '0' | '1' | ...  (SQL literal, no quoting applied)
    additive = [
        ('project_milestones',    'start_date',         'DATE',         False, None),
        ('project_tasks',         'priority',           'VARCHAR(20)',  False, "'Medium'"),
        ('project_tasks',         'percent_complete',   'INTEGER',      False, '0'),
        ('project_risk_logs',     'probability',        'INTEGER',      False, None),
        ('project_risk_logs',     'impact',             'INTEGER',      False, None),
        ('project_risk_logs',     'owner',              'VARCHAR(200)', False, None),
        ('project_risk_logs',     'mitigation',         'TEXT',         False, None),
        ('project_risk_logs',     'due_date',           'DATE',         False, None),
        ('project_documents',     'is_sensitive',       'BOOLEAN',      True,  '0'),
        ('project_stakeholders',  'designation',        'VARCHAR(200)', False, None),
        ('project_team_members',  'member_group',       'VARCHAR(20)',  False, None),
        ('users',                 'user_group',         'VARCHAR(30)',  False, None),
        ('users',                 'sub_group',          'VARCHAR(100)', False, None),
        ('users',                 'team',               'VARCHAR(20)',  False, None),
        ('projects',              'start_date',         'DATE',         False, None),
        ('projects',              'target_end_date',    'DATE',         False, None),
        ('projects',              'auto_status_email',  'BOOLEAN',      True,  '1'),
        ('projects',              'project_type',         'VARCHAR(20)', False, "'sdlc'"),
        ('projects',              'methodology',          'VARCHAR(20)', False, None),
        ('projects',              'sdlc_score',           'INTEGER',     False, None),
        ('projects',              'sdlc_recommended',     'VARCHAR(20)', False, None),
        ('projects',              'sdlc_override_reason', 'TEXT',        False, None),
        ('sdlc_phase_templates',  'repeatable',           'BOOLEAN',     True,  '0'),
        ('project_sdlc_phases',   'repeatable',           'BOOLEAN',     False, '0'),
        ('project_sdlc_phases',   'default_tasks',        'TEXT',        False, None),
        ('hld_template_sections', 'parent_id',          'INTEGER',      False, None),
        ('hld_template_sections', 'doc_type',           'VARCHAR(10)',  False, "'hld'"),
        ('hld_template_sections', 'block_config',       'TEXT',         False, None),
        ('app_support_towers',    'tower_group_names',  'TEXT',         False, None),
        ('tower_members',         'can_manage_secrets', 'BOOLEAN',      True,  '0'),
        ('tower_members',         'is_lead',            'BOOLEAN',      True,  '0'),
        ('application_details',   'category_id',        'INTEGER',      False, None),
        ('support_team',          'source',             'VARCHAR(16)',  False, None),
        ('health_check_reports', 'run_token', 'VARCHAR(36)', False, None),
        ('health_check_reports', 'run_lease_until', 'DATETIME', False, None),
        ('health_check_reports', 'config_version', 'INTEGER', True, '0'),
        ('health_check_reports', 'last_notification_status', 'VARCHAR(20)', False, None),
        ('health_check_reports', 'last_notification_at', 'DATETIME', False, None),
        ('health_check_reports',  'schedule_paused',    'BOOLEAN',      True,  '0'),
        ('health_check_reports',  'manual_run_state',      'VARCHAR(20)', False, None),
        ('health_check_reports',  'manual_run_started_at', 'DATETIME',    False, None),
        ('health_check_reports',  'manual_run_by',         'INTEGER',     False, None),
        ('health_check_reports',  'manual_run_message',    'TEXT',        False, None),
        ('health_check_reports',  'manual_run_heartbeat',  'DATETIME',    False, None),
        # Rota - the columns the Workforce Rota Management rebuild added to
        # tables that already shipped. Every one is nullable or defaulted, so
        # an existing row keeps behaving exactly as it did.
        ('file_monitor_reports',  'exclusion_rules',    'TEXT',         False, None),
        ('file_monitor_reports',  'alert_enabled',      'BOOLEAN',      False, '0'),
        ('file_monitor_reports',  'alert_emails',       'VARCHAR(500)', False, None),
        ('file_monitor_reports',  'source_stats_config',            'TEXT', False, None),
        ('file_monitor_reports',  'source_exclusion_config',        'TEXT', False, None),
        ('file_monitor_reports',  'intermediate_stats_config',      'TEXT', False, None),
        ('file_monitor_reports',  'intermediate_exclusion_config',  'TEXT', False, None),
        ('file_monitor_reports',  'target_stats_config',            'TEXT', False, None),
        ('file_monitor_reports',  'target_exclusion_config',        'TEXT', False, None),
        ('file_monitor_reports',  'source_display_config',          'TEXT', False, None),
        ('file_monitor_reports',  'intermediate_display_config',    'TEXT', False, None),
        ('file_monitor_reports',  'target_display_config',          'TEXT', False, None),
        ('file_monitor_reports',  'alert_grace_days',               'INTEGER', False, '1'),
        ('file_monitor_reports',  'exclusion_apply_all',            'BOOLEAN', False, '0'),
        ('file_monitor_reports',  'tower_id',                       'INTEGER', False, None),
        ('activity_entries',      'project_task_id',    'INTEGER',      False, None),
        ('code_projects',         'gate_mode',          'VARCHAR(10)',  False, "'full'"),
        ('code_scans',            'gate_mode',          'VARCHAR(10)',  False, "'full'"),
        ('code_scans',            'baseline_scan_id',   'INTEGER',      False, None),
        ('code_scans',            'new_blocker',        'INTEGER',      False, '0'),
        ('code_scans',            'new_critical',       'INTEGER',      False, '0'),
        ('code_scans',            'new_high',           'INTEGER',      False, '0'),
        ('code_scans',            'new_findings',       'INTEGER',      False, '0'),
        ('code_scans',            'heartbeat_at',       'DATETIME',     False, None),
        ('code_findings',         'is_new',             'BOOLEAN',      False, '1'),
        ('snow_ticket_workload',  'resolved_at',        'DATETIME',     False, None),
        ('snow_ticket_workload',  'priority',           'VARCHAR(10)',  False, None),
        ('snow_ticket_workload',  'category',           'VARCHAR(200)', False, None),
        ('snow_ticket_workload',  'subcategory',        'VARCHAR(200)', False, None),
        ('snow_ticket_workload',  'short_description',  'VARCHAR(500)', False, None),
        ('snow_ticket_workload',  'assignment_group',   'VARCHAR(200)', False, None),
        ('snow_ticket_workload',  'state',              'VARCHAR(60)',  False, None),
        # Software Inventory audience. NOT NULL with a 'general' default so
        # every package published before restricted software existed keeps
        # the behaviour it had - open to every signed-in user - instead of
        # landing on a NULL that the access rule would then have to guess at.
        ('software_items',        'visibility',         'VARCHAR(16)',  True,  "'general'"),
        # MIMP schedule state. Nullable with no default on purpose: NULL
        # means "not seeded yet", and the sweep seeds it once from the last
        # SCHEDULER-written observation so an existing report resumes where
        # it was instead of every report firing at once after the upgrade.
        ('mimp_reports',          'last_run_at',        'DATETIME',     False, None),
        ('mimp_reports',          'next_run_at',        'DATETIME',     False, None),
    ]

    def _render_type(generic_type: str) -> str:
        if generic_type == 'BOOLEAN':
            return 'BIT' if is_mssql else 'BOOLEAN'
        return generic_type

    def _render_add(table: str, column: str, generic_type: str,
                    not_null: bool, default_literal) -> str:
        col_type = _render_type(generic_type)
        # SQL Server: "ALTER TABLE t ADD col TYPE [DEFAULT x] [NOT NULL]"
        # Others:     "ALTER TABLE t ADD COLUMN col TYPE [NOT NULL DEFAULT x]"
        if is_mssql:
            parts = [f'ALTER TABLE {table} ADD {column} {col_type}']
            if default_literal is not None:
                parts.append(f'DEFAULT {default_literal}')
            if not_null:
                parts.append('NOT NULL')
            return ' '.join(parts)
        parts = [f'ALTER TABLE {table} ADD COLUMN {column} {col_type}']
        if not_null:
            parts.append('NOT NULL')
        if default_literal is not None:
            parts.append(f'DEFAULT {default_literal}')
        return ' '.join(parts)

    try:
        inspector = inspect(engine)
        existing_tables = set(inspector.get_table_names())
    except Exception as e:
        logger.warning("Could not inspect schema for column migration: %s", e)
        return

    added = 0
    with engine.begin() as conn:
        for table, column, gtype, not_null, default_literal in additive:
            if table not in existing_tables:
                continue  # create_all() will have built it with the column
            try:
                cols = {c['name'] for c in inspector.get_columns(table)}
            except Exception as e:
                logger.warning("Could not read columns of %s: %s", table, e)
                continue
            if column in cols:
                continue
            try:
                conn.execute(text(_render_add(table, column, gtype,
                                              not_null, default_literal)))
                added += 1
                logger.info("Added missing column %s.%s", table, column)
            except Exception as e:
                logger.warning("Could not add column %s.%s: %s", table, column, e)

    # Backfill milestone.start_date so existing rows satisfy the
    # "task within milestone start/end" rule. SQL Server uses
    # CAST(created_at AS DATE); other backends use date(created_at).
    created_at_as_date = (
        'CAST(created_at AS DATE)' if is_mssql else 'date(created_at)'
    )
    try:
        with engine.begin() as conn:
            conn.execute(text(
                "UPDATE project_milestones "
                "SET start_date = COALESCE("
                "  (SELECT MIN(t.start_date) FROM project_tasks t "
                "     WHERE t.milestone_id = project_milestones.id), "
                f"  {created_at_as_date}, end_date) "
                "WHERE start_date IS NULL"
            ))
    except Exception as e:
        logger.warning("Could not backfill milestone start_date: %s", e)

    # Backfill sdlc_phase_milestones (the stage->milestone mapping) from the
    # two earlier cuts of the SDLC feature. Each legacy column only exists on
    # databases created under that cut, so each statement is allowed to fail
    # silently - the NOT EXISTS guard keeps both idempotent.
    for legacy_sql in (
        "INSERT INTO sdlc_phase_milestones (phase_id, milestone_id) "
        "SELECT p.id, p.milestone_id FROM project_sdlc_phases p "
        "WHERE p.milestone_id IS NOT NULL AND NOT EXISTS "
        "  (SELECT 1 FROM sdlc_phase_milestones l "
        "     WHERE l.phase_id = p.id AND l.milestone_id = p.milestone_id)",
        "INSERT INTO sdlc_phase_milestones (phase_id, milestone_id) "
        "SELECT m.sdlc_phase_id, m.id FROM project_milestones m "
        "WHERE m.sdlc_phase_id IS NOT NULL AND NOT EXISTS "
        "  (SELECT 1 FROM sdlc_phase_milestones l "
        "     WHERE l.phase_id = m.sdlc_phase_id AND l.milestone_id = m.id)",
    ):
        try:
            with engine.begin() as conn:
                conn.execute(text(legacy_sql))
        except Exception:
            pass

    if added:
        logger.info("Column migration complete - %d column(s) added.", added)


def recreate_all_tables_DESTRUCTIVE() -> None:
    """
    Drop and recreate every table. DEVELOPMENT USE ONLY.

    Wipes ALL data including:
        - User accounts and their hashed passwords
        - All projects, applications, towers, support data
        - All MIMP reports and status history
        - All APScheduler persisted jobs
        - All other module data

    Only call this manually from a developer shell, never from app startup.
    """
    logger.warning("DESTRUCTIVE: Dropping and recreating all tables.")
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    logger.warning("DESTRUCTIVE: All tables recreated. ALL DATA LOST.")


def get_db_session():
    """Get database session"""
    return SessionLocal()


def close_db_session(session):
    """Close database session"""
    session.close()
