"""
service.py - To-Do business logic invoked by the scheduler (and the manual
"email me now" route).

Two jobs:

  1. run_morning_digests()      - once every morning, email every active user
                                  who has at least one OPEN to-do their personal
                                  summary (overdue + due-today highlighted).
  2. run_todo_retention_purge() - once daily, permanently delete COMPLETED
                                  to-dos whose completed_at is older than the
                                  retention window (4 months by default).

Both open their own DB session and never raise out of the per-user loop, so one
bad row or recipient cannot abort the whole sweep - the same resilience pattern
the certificate / health-check sweeps use.
"""

import logging
import os
from calendar import monthrange
from datetime import date, datetime, timedelta

from sqlalchemy.exc import IntegrityError

from database import get_db_session
from models import User
from .models import TodoItem, TodoDigestLog, STATUS_OPEN, STATUS_COMPLETED
from .email_utils import send_todo_digest

logger = logging.getLogger(__name__)

# How many days of digest-claim rows to keep. Only the current day's claims
# are needed for dedup; a short tail is kept for safety, the rest are pruned
# by the daily retention purge so the table never grows unbounded.
_DIGEST_LOG_KEEP_DAYS = int(os.environ.get('TODO_DIGEST_LOG_KEEP_DAYS', '7'))


def _claim_digest(db, user_id: int, run_date: date) -> bool:
    """Atomically claim today's digest for *user_id*.

    Returns True if THIS caller won the claim (and should therefore send), or
    False if the digest for (user, run_date) was already claimed by another
    process. Cross-process safe via the UNIQUE (user_id, sent_date) constraint
    on todo_digest_log: a losing caller hits IntegrityError and is told to skip.
    """
    db.add(TodoDigestLog(user_id=user_id, sent_date=run_date))
    try:
        db.commit()
        return True
    except IntegrityError:
        db.rollback()
        return False

# How many months a completed to-do is kept before the purge removes it.
RETENTION_MONTHS = int(os.environ.get('TODO_RETENTION_MONTHS', '4'))


# ---------------------------------------------------------------------------
# Sorting (must match the on-screen order in routes._open_sort_key)
# ---------------------------------------------------------------------------
_PRIORITY_RANK = {'high': 0, 'medium': 1, 'low': 2}


def _open_sort_key(item):
    has_date = item.due_date is not None
    return (
        0 if item.is_overdue else 1,
        0 if item.is_due_today else 1,
        date.max if not has_date else item.due_date,
        _PRIORITY_RANK.get(item.priority, 1),
        -(item.id or 0),
    )


# ---------------------------------------------------------------------------
# Morning digest sweep
# ---------------------------------------------------------------------------
def run_morning_digests(run_date: date = None) -> dict:
    """Email every active user with open to-dos their morning summary.

    Returns a small stats dict for the caller / logs. Never raises.
    """
    run_date = run_date or date.today()
    db = get_db_session()
    sent = skipped = failed = 0
    try:
        # Only users who actually own open items - one grouped query, then a
        # per-user fetch so we keep the digest ordering identical to the UI.
        user_ids = [
            row[0]
            for row in db.query(TodoItem.user_id)
            .filter(TodoItem.status == STATUS_OPEN)
            .distinct()
            .all()
        ]
        if not user_ids:
            logger.info('Morning digest: no users have open to-dos.')
            return {'sent': 0, 'skipped': 0, 'failed': 0}

        users = (
            db.query(User)
            .filter(User.id.in_(user_ids), User.is_active.is_(True))
            .all()
        )

        for user in users:
            try:
                # Cross-process idempotency: atomically claim today's digest.
                # If another runner (e.g. an IIS worker that also started a
                # scheduler) already claimed it, skip - each user gets at most
                # ONE automated digest per day regardless of how many processes
                # run the sweep. (claim-then-send => strict at-most-once; a rare
                # SMTP failure means no digest that day, which is logged, rather
                # than risking a duplicate.)
                if not _claim_digest(db, user.id, run_date):
                    skipped += 1
                    continue

                open_items = (
                    db.query(TodoItem)
                    .filter(
                        TodoItem.user_id == user.id,
                        TodoItem.status == STATUS_OPEN,
                    )
                    .all()
                )
                open_items.sort(key=_open_sort_key)
                if send_todo_digest(user, open_items, run_date):
                    sent += 1
                else:
                    skipped += 1
            except Exception:
                failed += 1
                logger.exception('Morning digest failed for user %s.', user.id)

        logger.info('Morning digest complete: %d sent, %d skipped, %d failed '
                    '(of %d candidate users).', sent, skipped, failed, len(users))
        return {'sent': sent, 'skipped': skipped, 'failed': failed}
    finally:
        db.close()


def send_digest_for_user(user_id: int, run_date: date = None) -> bool:
    """Send (or re-send) the digest to a single user on demand.

    Returns True if an email went out, False if there was nothing to send.
    Used by the "email me my open list now" button.
    """
    run_date = run_date or date.today()
    db = get_db_session()
    try:
        user = db.query(User).filter_by(id=user_id, is_active=True).first()
        if not user:
            return False
        open_items = (
            db.query(TodoItem)
            .filter(TodoItem.user_id == user.id, TodoItem.status == STATUS_OPEN)
            .all()
        )
        open_items.sort(key=_open_sort_key)
        return send_todo_digest(user, open_items, run_date)
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Retention purge
# ---------------------------------------------------------------------------
def _subtract_months(when: datetime, months: int) -> datetime:
    """Return *when* shifted back by *months* calendar months.

    Calendar-accurate (not a 30-day approximation): subtracting 4 months from
    31 May yields 31 Jan; subtracting from 31 Dec to a short month clamps to the
    last valid day. Keeps the time-of-day component.
    """
    month_index = when.month - 1 - months
    year = when.year + month_index // 12
    month = month_index % 12 + 1
    day = min(when.day, monthrange(year, month)[1])
    return when.replace(year=year, month=month, day=day)


def run_todo_retention_purge(months: int = None) -> int:
    """Delete COMPLETED to-dos whose completed_at is older than the retention
    window. Returns the number of rows removed. Never raises."""
    months = RETENTION_MONTHS if months is None else months
    cutoff = _subtract_months(datetime.now(), months)
    db = get_db_session()
    try:
        deleted = (
            db.query(TodoItem)
            .filter(
                TodoItem.status == STATUS_COMPLETED,
                TodoItem.completed_at.isnot(None),
                TodoItem.completed_at < cutoff,
            )
            .delete(synchronize_session=False)
        )
        # Prune stale digest-claim rows - only recent days are needed for the
        # dedup guard, so this keeps todo_digest_log from growing unbounded.
        log_cutoff = date.today() - timedelta(days=_DIGEST_LOG_KEEP_DAYS)
        logs_deleted = (
            db.query(TodoDigestLog)
            .filter(TodoDigestLog.sent_date < log_cutoff)
            .delete(synchronize_session=False)
        )
        db.commit()
        if deleted:
            logger.info('Retention purge: deleted %d completed to-do(s) older '
                        'than %d months (before %s).',
                        deleted, months, cutoff.strftime('%Y-%m-%d'))
        else:
            logger.info('Retention purge: nothing older than %d months.', months)
        if logs_deleted:
            logger.info('Retention purge: pruned %d stale digest-log row(s).',
                        logs_deleted)
        return deleted
    except Exception:
        db.rollback()
        logger.exception('Retention purge failed (suppressed).')
        return 0
    finally:
        db.close()
