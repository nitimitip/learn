"""
Resource Utilization module - routes.

Access model (Resource Tracker):
* every signed-in user     - People Explorer, own utilization detail
* project managers / admin - utilization dashboard, Excel reports, anyone's
                             detail page, and the T&M allocations register

* /resource-utilization/            - drill-down dashboard (PM). Level by level:
      no params                     -> Application vs Infra (user group)
      ?group=<g>                    -> Project vs BAU (team)
      ?group=<g>&team=<t>           -> sub-groups (towers / disciplines)
      ?group=<g>&team=<t>&sub=<s>   -> the individual team members
* /resource-utilization/report      - professional Excel report of the current
                                      scope (offered from the group level down)
* /resource-utilization/people      - filterable people explorer (name, group,
                                      team, sub-group) with per-user numbers
* /resource-utilization/user/<id>   - one user's utilization detail (PM, or
                                      the user viewing themselves)
* /resource-utilization/user/<id>/tickets.xlsx
                                    - that person's ServiceNow ticket list
                                      (incidents + service requests worked
                                      in the workload window) as a
                                      professional Excel workbook. Same
                                      access rule as the detail page.
* /resource-utilization/allocations - T&M allocations register (PM). The T&M
                                      "contract" IS the project-task
                                      allocation from Project Management:
                                      planned working days x 8h vs the hours
                                      logged against that task in the
                                      timesheet, EXTENDED when work continues
                                      past the planned end (or beyond the
                                      allocated volume)

Utilization is TIMESHEET-BASED: hours actually logged in the Activity
Tracker against a capacity of working days x 8h (weekend hours count in
full - overtime shows up above 100%). Everything else is context, not math:
projects / tasks assigned, Application Support membership, and the
incidents / service requests worked in the last year (captured from
ServiceNow Batch Analysis uploads). See service.py for the exact model.
"""

import io
import logging
from datetime import date, datetime, timedelta

from flask import (Blueprint, flash, redirect, render_template, request,
                   send_file, url_for)
from sqlalchemy import func, or_

from auth import get_current_user
from csrf_utils import csrf_protect
from database import get_db_session
from models import User
from modules.activity_tracker.models import (ActivityEntry, LEAVE_CATEGORY,
                                             STANDARD_DAY_HOURS)
from modules.application_support.models import ApplicationDetails, SupportTeam
from modules.project_management.models import (Project, ProjectMilestone,
                                               ProjectTask)
from modules.service_now_analysis.models import SnowTicketWorkload
from modules.service_now_analysis.workload_themes import (
    PRIORITY_COLORS, PRIORITY_LABELS, analyse_themes,
    priority_breakdown)
from modules.user_profile.models import (USER_GROUP_LABELS, USER_GROUPS,
                                         USER_TEAMS, team_includes_bau,
                                         team_includes_project)

from .models import (WorkforceHoliday, WorkforceSettings,
                     billable_category_choices, load_holidays, load_settings,
                     parse_holiday_rows, upsert_holidays)
from .service import (ALLOCATION_BAND_LABELS, BAND_LABELS, PERIOD_PRESETS,
                      aggregate_stats, allocation_consumption,
                      compute_user_stats, group_users, period_label,
                      resolve_period, split_task_hours, task_allocation,
                      working_days)

logger = logging.getLogger(__name__)

resource_utilization_bp = Blueprint(
    'resource_utilization', __name__,
    template_folder='../../templates/resource_utilization',
)

# URL token for users with no group / team / sub-group on their profile.
UNASSIGNED = 'unassigned'
UNASSIGNED_LABEL = 'Unassigned'

# ServiceNow workload window shown as context (independent of the period).
WORKLOAD_WINDOW_DAYS = 365

# Status colours for the utilization bars (band = status, never identity).
BAND_COLORS = {'over': '#DC2626', 'healthy': '#16A34A',
               'low': '#D97706', 'none': '#94A3B8'}
INCIDENT_BAR_COLOR = '#475569'

# Fixed line colours for the incident / service-request monthly trend -
# colour follows the entity (incidents always blue, SRs always orange;
# a CVD-safe warm/cool pair, distinct from the status colours above).
TREND_SERIES_COLORS = {'incident': '#2A78D6', 'service_request': '#EB6834'}
WORKLOAD_TREND_MONTHS = 12


def _is_pm(user) -> bool:
    return bool(user) and user.role in ('admin', 'project_manager')


def _require_pm():
    """Current user if project manager or admin, else None."""
    user = get_current_user()
    if not user:
        flash('Please login to view resource utilization.', 'error')
        return None
    if not _is_pm(user):
        flash('This Resource Tracker view is available to project managers '
              'only.', 'error')
        return None
    return user


def _require_user():
    """Any signed-in user (People Explorer is open to everyone), else None."""
    user = get_current_user()
    if not user:
        flash('Please login to view the Resource Tracker.', 'error')
    return user


def _require_admin():
    """Current user if admin (workforce settings), else None."""
    user = get_current_user()
    if not user or user.role != 'admin':
        flash('Admin access required.', 'error')
        return None
    return user


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def _period_from_request():
    start, end, preset = resolve_period(
        request.args.get('period'),
        request.args.get('start'), request.args.get('end'))
    return {
        'start': start, 'end': end, 'preset': preset,
        'label': period_label(preset, start, end),
        'args': _period_args(preset, start, end),
    }


def _period_args(preset, start, end):
    """Query-string args that re-select the current period on any link."""
    if preset == 'custom':
        return {'period': 'custom',
                'start': start.isoformat(), 'end': end.isoformat()}
    return {'period': preset}


def _workforce(db_session):
    """
    The workforce configuration every calculation needs, as one flat dict:
    band thresholds, day hours, the non-billable category set, and the full
    holiday calendar (all-time - allocations span outside the period).
    """
    wf = load_settings(db_session)
    wf['holidays'] = load_holidays(db_session)
    return wf


def _load_hours(db_session, users, start, end, wf):
    """
    {user_id: {'worked': {date: h}, 'billable': {date: h},
               'leave': {date: h}}} within [start, end].

    Leave-category hours go in 'leave' only (they reduce capacity, never
    count as work). Billable = worked hours whose category is not in the
    configured non-billable set; uncategorised entries count billable.
    """
    ids = [u.id for u in users]
    if not ids:
        return {}
    rows = (db_session.query(ActivityEntry.user_id,
                             ActivityEntry.entry_date,
                             ActivityEntry.category,
                             func.sum(ActivityEntry.hours))
            .filter(ActivityEntry.user_id.in_(ids),
                    ActivityEntry.entry_date >= start,
                    ActivityEntry.entry_date <= end)
            .group_by(ActivityEntry.user_id, ActivityEntry.entry_date,
                      ActivityEntry.category)
            .all())
    non_billable = wf['non_billable']
    out = {}
    for uid, d, category, hours in rows:
        h = float(hours or 0.0)
        buckets = out.setdefault(uid, {'worked': {}, 'billable': {},
                                       'leave': {}})
        cat = (category or '').strip()
        if cat == LEAVE_CATEGORY:
            buckets['leave'][d] = buckets['leave'].get(d, 0.0) + h
            continue
        buckets['worked'][d] = buckets['worked'].get(d, 0.0) + h
        if cat not in non_billable:
            buckets['billable'][d] = buckets['billable'].get(d, 0.0) + h
    return out


_EMPTY_BUCKETS = {'worked': {}, 'billable': {}, 'leave': {}}


def _user_stats(buckets, start, end, wf):
    """compute_user_stats wired to the workforce configuration."""
    b = buckets or _EMPTY_BUCKETS
    return compute_user_stats(
        b['worked'], start, end,
        billable_by_date=b['billable'], leave_by_date=b['leave'],
        day_hours=wf['day_hours'], holidays=wf['holidays'],
        under=wf['under_pct'], over=wf['over_pct'])


def _agg(stats_list, wf):
    """aggregate_stats wired to the configured band thresholds."""
    return aggregate_stats(stats_list, under=wf['under_pct'],
                           over=wf['over_pct'])


def _load_user_stats(db_session, users, start, end, wf):
    """[(user, stats)] for the given users over [start, end]."""
    hours = _load_hours(db_session, users, start, end, wf)
    return [(u, _user_stats(hours.get(u.id), start, end, wf))
            for u in users]


def _full_name(user) -> str:
    return (f"{(user.firstname or '').strip()} "
            f"{(user.lastname or '').strip()}").strip().lower()


# Worst-first ordering used when one person carries several allocations.
_ALLOCATION_BAND_SEVERITY = {'exceeded': 0, 'reached': 1, 'nearing': 2,
                             'ok': 3}


def _assigned_task_rows(db_session, user_ids=None):
    """
    [(task, milestone, project)] for every assigned project task - each one
    IS a T&M allocation (planned working days x 8h for that resource).
    """
    query = (db_session.query(ProjectTask, ProjectMilestone, Project)
             .join(ProjectMilestone,
                   ProjectTask.milestone_id == ProjectMilestone.id)
             .join(Project, ProjectMilestone.project_id == Project.id)
             .filter(ProjectTask.assigned_to.isnot(None)))
    if user_ids is not None:
        if not user_ids:
            return []
        query = query.filter(ProjectTask.assigned_to.in_(list(user_ids)))
    return (query.order_by(ProjectTask.start_date.desc(),
                           ProjectTask.id.desc())
            .all())


def _allocation_stats(db_session, task_rows, wf):
    """
    {task_id: consumption} for [(task, milestone, project)] rows.

    Consumption comes from the timesheet entries LINKED to each task
    (ActivityEntry.project_task_id) - one grouped query for all tasks, then
    pure service math per task. Hours dated after the task's planned end
    flag the allocation as Extended. The planned volume respects the
    holiday calendar and the configured day hours.
    """
    tasks = [t for t, _, _ in task_rows]
    if not tasks:
        return {}
    ids = [t.id for t in tasks]
    rows = (db_session.query(ActivityEntry.project_task_id,
                             ActivityEntry.entry_date,
                             func.sum(ActivityEntry.hours))
            .filter(ActivityEntry.project_task_id.in_(ids))
            .group_by(ActivityEntry.project_task_id,
                      ActivityEntry.entry_date)
            .all())
    hours = {}
    for tid, d, h in rows:
        hours.setdefault(tid, {})[d] = float(h or 0.0)

    out = {}
    for t in tasks:
        _, allocated_hours = task_allocation(t.start_date, t.end_date,
                                             wf['day_hours'],
                                             wf['holidays'])
        consumed, days_logged, after_h, after_d = split_task_hours(
            hours.get(t.id, {}), t.end_date)
        out[t.id] = allocation_consumption(
            allocated_hours, wf['day_hours'], consumed,
            after_end_hours=after_h, days_logged=days_logged,
            after_end_days=after_d)
    return out


def _worst_allocation_by_user(task_rows, stats_by_task):
    """{user_id: (task, stats)} keeping each person's worst-band allocation."""
    worst = {}
    for task, _, _ in task_rows:
        stats = stats_by_task.get(task.id)
        if stats is None:
            continue
        current = worst.get(task.assigned_to)
        if (current is None
                or _ALLOCATION_BAND_SEVERITY[stats['band']]
                < _ALLOCATION_BAND_SEVERITY[current[1]['band']]):
            worst[task.assigned_to] = (task, stats)
    return worst


def _load_context(db_session, users, start, end):
    """
    Per-user CONTEXT metrics (never part of the utilization number):

      support_apps   - active Application Support apps (email match)
      projects/tasks - distinct projects & tasks assigned in the period
      incidents_1y / srs_1y - ServiceNow tickets assigned to the person in
                       the last year (Batch Analysis workload capture,
                       matched by display name)
    """
    ctx = {u.id: {'support_apps': 0, 'projects': 0, 'tasks': 0,
                  'incidents_1y': 0, 'srs_1y': 0} for u in users}
    ids = list(ctx)
    if not ids:
        return ctx

    # Application Support membership (account email <-> support-team email).
    email_to_id = {u.email.strip().lower(): u.id
                   for u in users if u.email}
    if email_to_id:
        rows = (db_session.query(
                    func.lower(SupportTeam.email),
                    func.count(func.distinct(SupportTeam.application_id)))
                .join(ApplicationDetails,
                      SupportTeam.application_id == ApplicationDetails.id)
                .filter(ApplicationDetails.is_active.is_(True),
                        func.lower(SupportTeam.email).in_(list(email_to_id)))
                .group_by(func.lower(SupportTeam.email))
                .all())
        for email, count in rows:
            if email in email_to_id:
                ctx[email_to_id[email]]['support_apps'] = count

    # Projects & tasks assigned in the period (task dates overlap it).
    rows = (db_session.query(ProjectTask.assigned_to,
                             func.count(ProjectTask.id),
                             func.count(func.distinct(
                                 ProjectMilestone.project_id)))
            .join(ProjectMilestone,
                  ProjectTask.milestone_id == ProjectMilestone.id)
            .filter(ProjectTask.assigned_to.in_(ids),
                    ProjectTask.start_date <= end,
                    ProjectTask.end_date >= start)
            .group_by(ProjectTask.assigned_to)
            .all())
    for uid, task_count, project_count in rows:
        ctx[uid]['tasks'] = task_count
        ctx[uid]['projects'] = project_count

    # ServiceNow workload in the last year (display-name match). Tickets
    # with no opened date still count - they were captured, so they exist.
    name_to_id = {}
    for u in users:
        name = _full_name(u)
        if name:
            name_to_id[name] = u.id
    if name_to_id:
        cutoff = datetime.now() - timedelta(days=WORKLOAD_WINDOW_DAYS)
        rows = (db_session.query(
                    func.lower(SnowTicketWorkload.assigned_to),
                    SnowTicketWorkload.ticket_type,
                    func.count(SnowTicketWorkload.id))
                .filter(func.lower(SnowTicketWorkload.assigned_to)
                        .in_(list(name_to_id)),
                        or_(SnowTicketWorkload.opened_at >= cutoff,
                            SnowTicketWorkload.opened_at.is_(None)))
                .group_by(func.lower(SnowTicketWorkload.assigned_to),
                          SnowTicketWorkload.ticket_type)
                .all())
        for name, ticket_type, count in rows:
            uid = name_to_id.get(name)
            if uid is None:
                continue
            if ticket_type == 'incident':
                ctx[uid]['incidents_1y'] = count
            elif ticket_type == 'service_request':
                ctx[uid]['srs_1y'] = count

    return ctx


def _month_starts(today, months):
    """First-of-month dates for the last `months` months, oldest first."""
    year, month = today.year, today.month
    out = []
    for _ in range(months):
        out.append(date(year, month, 1))
        month -= 1
        if month == 0:
            year, month = year - 1, 12
    out.reverse()
    return out


def _workload_trend(db_session, users, months=WORKLOAD_TREND_MONTHS):
    """
    Month-by-month incident / service-request counts for the given users
    (by ticket opened date, from the ServiceNow workload capture) as a
    two-series line-chart payload. None when there is nothing to plot -
    tickets without an opened date count in the 1-year totals but cannot
    be placed on the time axis.
    """
    names = [n for n in (_full_name(u) for u in users) if n]
    if not names:
        return None
    buckets = _month_starts(date.today(), months)
    window_start = datetime.combine(buckets[0], datetime.min.time())
    rows = (db_session.query(SnowTicketWorkload.ticket_type,
                             SnowTicketWorkload.opened_at)
            .filter(func.lower(SnowTicketWorkload.assigned_to).in_(names),
                    SnowTicketWorkload.opened_at.isnot(None),
                    SnowTicketWorkload.opened_at >= window_start)
            .all())
    if not rows:
        return None

    counts = {'incident': {b: 0 for b in buckets},
              'service_request': {b: 0 for b in buckets}}
    for ticket_type, opened in rows:
        by_month = counts.get(ticket_type)
        key = date(opened.year, opened.month, 1)
        if by_month is not None and key in by_month:
            by_month[key] += 1

    return {
        'labels': [b.strftime('%b %y') for b in buckets],
        'series': [
            {'name': 'Incidents',
             'color': TREND_SERIES_COLORS['incident'],
             'values': [counts['incident'][b] for b in buckets]},
            {'name': 'Service requests',
             'color': TREND_SERIES_COLORS['service_request'],
             'values': [counts['service_request'][b] for b in buckets]},
        ],
        'unit': '',
    }


def _workload_tickets(db_session, users):
    """
    The individual ServiceNow tickets captured against `users` inside the
    workload window, newest first, as plain dicts.

    Exactly the rows the counters on this page total up (same window, same
    display-name match, tickets with no opened date included), so the list,
    the charts, the themes and the Excel download can never disagree with
    the headline numbers.
    """
    names = [n for n in (_full_name(u) for u in users) if n]
    if not names:
        return []
    cutoff = datetime.now() - timedelta(days=WORKLOAD_WINDOW_DAYS)
    rows = (db_session.query(SnowTicketWorkload)
            .filter(func.lower(SnowTicketWorkload.assigned_to).in_(names),
                    or_(SnowTicketWorkload.opened_at >= cutoff,
                        SnowTicketWorkload.opened_at.is_(None)))
            .all())
    tickets = [{
        'number': row.ticket_number,
        'type': row.ticket_type,
        'title': row.short_description,
        'priority': row.priority,
        'category': row.category,
        'subcategory': row.subcategory,
        'assignment_group': row.assignment_group,
        'state': row.state,
        'opened_at': row.opened_at,
        'resolved_at': row.resolved_at,
        'assigned_to': row.assigned_to,
    } for row in rows]
    # Newest first; tickets with no opened date sort to the end rather than
    # blowing up the comparison.
    tickets.sort(key=lambda t: (t['opened_at'] is not None, t['opened_at'],
                                t['number'] or ''),
                 reverse=True)
    return tickets


def _priority_payload(tickets):
    """
    Stacked horizontal-bar payload of the ticket mix by priority: one bar
    per priority present, split into incidents and service requests. None
    when there is nothing to plot.

    Priority is the ticket's own, captured only when the export stated one
    - "Priority not set" is its own bar rather than being folded into P3.
    """
    rows = priority_breakdown(tickets)
    if not rows:
        return None
    # Plotly stacks a horizontal bar bottom-up, so reverse the canonical
    # order to put P1 at the top of the chart where a reader expects it.
    rows = list(reversed(rows))
    return {
        'labels': [r['label'] for r in rows],
        'series': [
            {'name': 'Incidents',
             'color': TREND_SERIES_COLORS['incident'],
             'values': [r['incidents'] for r in rows]},
            {'name': 'Service requests',
             'color': TREND_SERIES_COLORS['service_request'],
             'values': [r['service_requests'] for r in rows]},
        ],
        'totals': [r['total'] for r in rows],
        'unit': '',
    }


def _active_users(db_session):
    return (db_session.query(User)
            .filter(User.is_active.is_(True))
            .order_by(User.firstname, User.lastname)
            .all())


def _norm(value):
    return (value or '').strip()


def _matches(profile_value, token):
    """Does a profile field match a drill-down URL token?"""
    if token == UNASSIGNED:
        return not _norm(profile_value)
    return _norm(profile_value) == token


def _scope_filters():
    """(group, team, sub) drill-down tokens from the query string."""
    return (_norm(request.args.get('group')).lower(),
            _norm(request.args.get('team')),
            _norm(request.args.get('sub')))


def _filter_scope_users(users, group, team, sub):
    if group:
        users = [u for u in users
                 if _matches((u.user_group or '').lower(), group)]
    if team:
        users = [u for u in users if _matches(u.team, team)]
    if sub:
        users = [u for u in users if _matches(u.sub_group, sub)]
    return users


def _scope_title(group, team, sub):
    parts = []
    if group:
        parts.append(USER_GROUP_LABELS.get(group, UNASSIGNED_LABEL))
    if team:
        parts.append(team if team != UNASSIGNED else UNASSIGNED_LABEL)
    if sub:
        parts.append(sub if sub != UNASSIGNED else UNASSIGNED_LABEL)
    return ' - '.join(parts) if parts else 'All resources'


# ---------------------------------------------------------------------------
# Drill-down dashboard
# ---------------------------------------------------------------------------

def _drill_url(period, **kwargs):
    args = dict(period['args'])
    args.update({k: v for k, v in kwargs.items() if v})
    return url_for('resource_utilization.dashboard', **args)


def _cards_for(grouped, wf, label_for, url_for_key):
    """Sorted level cards: one per child key, Unassigned last."""
    cards = []
    for key, rows in grouped.items():
        token = key or UNASSIGNED
        cards.append({
            'key': token,
            'label': label_for(key) if key else UNASSIGNED_LABEL,
            'url': url_for_key(token),
            'agg': _agg([s for _, s in rows], wf),
        })
    cards.sort(key=lambda c: (c['key'] == UNASSIGNED, c['label'].lower()))
    return cards


def _bars_payload(items):
    """items: [(label, stats-or-agg)] -> utilization % bar chart data."""
    return {
        'labels': [label for label, _ in items],
        'values': [(s['percent'] or 0) for _, s in items],
        'colors': [BAND_COLORS[s['band']] for _, s in items],
        'unit': '%',
        'refline': 100,
    }


def _weekly_agg(users, hours_by_user, start, end, wf):
    """[(week_start_date, agg)] week-by-week for the scope (clipped)."""
    out = []
    week_start = start - timedelta(days=start.weekday())
    while week_start <= end:
        week_end = week_start + timedelta(days=6)
        lo, hi = max(week_start, start), min(week_end, end)
        agg = _agg([_user_stats(hours_by_user.get(u.id), lo, hi, wf)
                    for u in users], wf)
        out.append((week_start, agg))
        week_start += timedelta(days=7)
    return out


def _trend_payload(users, hours_by_user, start, end, wf):
    """Week-by-week utilization % for the scope (clipped to the period)."""
    weeks = _weekly_agg(users, hours_by_user, start, end, wf)
    return {
        'labels': [w.strftime('%d %b') for w, _ in weeks],
        'values': [(a['percent'] if a['percent'] is not None else 0)
                   for _, a in weeks],
        'unit': '%', 'refline': 100,
    }


@resource_utilization_bp.route('/')
def dashboard():
    user = _require_pm()
    if not user:
        return redirect(url_for('index'))

    period = _period_from_request()
    group, team, sub = _scope_filters()

    if group and group != UNASSIGNED and group not in USER_GROUPS:
        flash('Unknown group.', 'error')
        return redirect(url_for('resource_utilization.dashboard',
                                **period['args']))
    if team and team != UNASSIGNED and team not in USER_TEAMS:
        flash('Unknown team.', 'error')
        return redirect(url_for('resource_utilization.dashboard',
                                group=group, **period['args']))

    members_level = bool(group and team and sub)

    db_session = get_db_session()
    try:
        wf = _workforce(db_session)
        users = _filter_scope_users(_active_users(db_session),
                                    group, team, sub)
        hours_by_user = _load_hours(db_session, users, period['start'],
                                    period['end'], wf)
        ctx = (_load_context(db_session, users, period['start'],
                             period['end'])
               if members_level else {})
        workload_trend = (_workload_trend(db_session, users)
                          if members_level else None)
    finally:
        db_session.close()

    rows = [(u, _user_stats(hours_by_user.get(u.id), period['start'],
                            period['end'], wf))
            for u in users]
    scope_agg = _agg([s for _, s in rows], wf)
    trend_chart = _trend_payload(users, hours_by_user, period['start'],
                                 period['end'], wf)

    # Breadcrumb trail down to the current scope.
    crumbs = [('All resources', _drill_url(period))]
    if group:
        crumbs.append((USER_GROUP_LABELS.get(group, UNASSIGNED_LABEL),
                       _drill_url(period, group=group)))
    if team:
        crumbs.append((team if team != UNASSIGNED else UNASSIGNED_LABEL,
                       _drill_url(period, group=group, team=team)))
    if sub:
        crumbs.append((sub if sub != UNASSIGNED else UNASSIGNED_LABEL,
                       _drill_url(period, group=group, team=team, sub=sub)))

    cards, members, level_name = [], [], ''
    if not group:
        level_name = 'Application vs Infra'
        grouped = group_users(rows, lambda u: (u.user_group or '').lower())
        cards = _cards_for(
            grouped, wf,
            lambda k: USER_GROUP_LABELS.get(k, k.capitalize()),
            lambda token: _drill_url(period, group=token))
    elif not team:
        level_name = 'Project vs BAU'
        grouped = group_users(rows, lambda u: u.team)
        cards = _cards_for(
            grouped, wf, lambda k: k,
            lambda token: _drill_url(period, group=group, team=token))
    elif not sub:
        level_name = 'Teams'
        grouped = group_users(rows, lambda u: u.sub_group)
        cards = _cards_for(
            grouped, wf, lambda k: k,
            lambda token: _drill_url(period, group=group, team=team,
                                     sub=token))
    else:
        level_name = 'Team members'
        members = sorted(rows, key=lambda r: (r[0].firstname or '',
                                              r[0].lastname or ''))

    # One comparison bar chart per level; at member level a second chart
    # compares the incidents assigned (last year) across the team.
    if members:
        names = [(f"{p.firstname or ''} {p.lastname or ''}".strip()
                  or p.username) for p, _ in members]
        util_chart = _bars_payload(list(zip(names,
                                            [s for _, s in members])))
        incident_chart = {
            'labels': names,
            'values': [ctx[p.id]['incidents_1y'] for p, _ in members],
            'colors': [INCIDENT_BAR_COLOR] * len(names),
            'unit': '', 'refline': None,
        }
    else:
        util_chart = _bars_payload([(c['label'], c['agg']) for c in cards])
        incident_chart = None

    report_url = url_for('resource_utilization.report', group=group,
                         team=team, sub=sub, **period['args'])

    return render_template(
        'resource_utilization/dashboard.html',
        user=user, period=period, period_presets=PERIOD_PRESETS,
        crumbs=crumbs, level_name=level_name,
        cards=cards, members=members, ctx=ctx,
        scope_agg=scope_agg, band_labels=BAND_LABELS,
        group=group, team=team, sub=sub,
        util_chart=util_chart, incident_chart=incident_chart,
        trend_chart=trend_chart, workload_trend=workload_trend,
        report_url=report_url, wf=wf,
        scope_title=_scope_title(group, team, sub),
    )


# ---------------------------------------------------------------------------
# Excel report
# ---------------------------------------------------------------------------

@resource_utilization_bp.route('/report')
def report():
    user = _require_pm()
    if not user:
        return redirect(url_for('index'))

    period = _period_from_request()
    group, team, sub = _scope_filters()
    if group and group != UNASSIGNED and group not in USER_GROUPS:
        flash('Unknown group.', 'error')
        return redirect(url_for('resource_utilization.dashboard',
                                **period['args']))

    db_session = get_db_session()
    try:
        wf = _workforce(db_session)
        users = _filter_scope_users(_active_users(db_session),
                                    group, team, sub)
        hours_by_user = _load_hours(db_session, users, period['start'],
                                    period['end'], wf)
        ctx = _load_context(db_session, users, period['start'],
                            period['end'])
        task_rows = _assigned_task_rows(db_session, [u.id for u in users])
        stats_by_task = _allocation_stats(db_session, task_rows, wf)
        users_by_id = {u.id: u for u in users}
        allocation_rows = [
            (t, p, users_by_id.get(t.assigned_to), stats_by_task[t.id])
            for t, m, p in task_rows]
        # Data-freshness stamp for the ServiceNow workload context columns.
        snow_as_of = (db_session.query(func.max(
            SnowTicketWorkload.captured_at)).scalar())
    finally:
        db_session.close()

    rows = [(u, _user_stats(hours_by_user.get(u.id), period['start'],
                            period['end'], wf))
            for u in users]
    weekly = _weekly_agg(users, hours_by_user, period['start'],
                         period['end'], wf)
    holidays_in_period = sorted(d for d in wf['holidays']
                                if period['start'] <= d <= period['end']
                                and d.weekday() < 5)

    from .report_excel import build_utilization_report
    scope_title = _scope_title(group, team, sub)
    stream = io.BytesIO()
    build_utilization_report(
        stream, scope_title=scope_title, period=period, rows=rows, ctx=ctx,
        band_labels=BAND_LABELS, group_labels=USER_GROUP_LABELS,
        unassigned_label=UNASSIGNED_LABEL,
        generated_by=f"{user.firstname or ''} {user.lastname or ''}".strip(),
        allocation_rows=allocation_rows,
        allocation_band_labels=ALLOCATION_BAND_LABELS,
        wf=wf, weekly=weekly, holidays_in_period=holidays_in_period,
        snow_as_of=snow_as_of,
    )
    stream.seek(0)

    safe_scope = scope_title.replace(' - ', '_').replace(' ', '-')
    filename = (f"Resource_Utilization_{safe_scope}_"
                f"{period['start'].isoformat()}_{period['end'].isoformat()}"
                f".xlsx")
    logger.info('Utilization report downloaded by %s for scope %s',
                user.username, scope_title)
    return send_file(
        stream, as_attachment=True, download_name=filename,
        mimetype=('application/vnd.openxmlformats-officedocument'
                  '.spreadsheetml.sheet'))


# ---------------------------------------------------------------------------
# People explorer (filter tab)
# ---------------------------------------------------------------------------

@resource_utilization_bp.route('/people')
def people():
    user = _require_user()
    if not user:
        return redirect(url_for('login'))
    is_pm = _is_pm(user)

    period = _period_from_request()
    f_name = _norm(request.args.get('name'))
    f_group = _norm(request.args.get('group')).lower()
    f_team = _norm(request.args.get('team'))
    f_sub = _norm(request.args.get('sub'))

    db_session = get_db_session()
    try:
        query = db_session.query(User).filter(User.is_active.is_(True))
        if f_name:
            like = f'%{f_name}%'
            query = query.filter(or_(User.firstname.ilike(like),
                                     User.lastname.ilike(like),
                                     User.username.ilike(like)))
        if f_group in USER_GROUPS:
            query = query.filter(func.lower(User.user_group) == f_group)
        if f_team in USER_TEAMS:
            query = query.filter(User.team == f_team)
        if f_sub:
            query = query.filter(User.sub_group == f_sub)
        users = query.order_by(User.firstname, User.lastname).all()

        # Sub-group filter options: every value in use plus the admin list
        # values would be overkill - the ones in use are what can match.
        sub_options = [s for (s,) in
                       db_session.query(User.sub_group)
                       .filter(User.sub_group.isnot(None),
                               User.sub_group != '')
                       .distinct().order_by(User.sub_group).all()]

        wf = _workforce(db_session)
        rows = _load_user_stats(db_session, users, period['start'],
                                period['end'], wf)
        ctx = _load_context(db_session, users, period['start'],
                            period['end'])

        # T&M allocation badge (worst project-task allocation per person -
        # project managers only).
        alloc_by_user = {}
        if is_pm:
            task_rows = _assigned_task_rows(db_session,
                                            [u.id for u in users])
            alloc_by_user = _worst_allocation_by_user(
                task_rows, _allocation_stats(db_session, task_rows, wf))
    finally:
        db_session.close()

    rows.sort(key=lambda r: -(r[1]['percent'] or 0))

    return render_template(
        'resource_utilization/people.html',
        user=user, is_pm=is_pm,
        period=period, period_presets=PERIOD_PRESETS,
        rows=rows, ctx=ctx, band_labels=BAND_LABELS,
        alloc_by_user=alloc_by_user,
        allocation_band_labels=ALLOCATION_BAND_LABELS,
        f_name=f_name, f_group=f_group, f_team=f_team, f_sub=f_sub,
        user_groups=USER_GROUPS, user_group_labels=USER_GROUP_LABELS,
        user_teams=USER_TEAMS, sub_options=sub_options,
    )


# ---------------------------------------------------------------------------
# Individual utilization
# ---------------------------------------------------------------------------

@resource_utilization_bp.route('/user/<int:user_id>')
def user_detail(user_id):
    user = _require_user()
    if not user:
        return redirect(url_for('login'))
    is_pm = _is_pm(user)
    if not is_pm and user.id != user_id:
        flash('You can open your own utilization detail; other people\'s '
              'pages are available to project managers.', 'error')
        return redirect(url_for('resource_utilization.people'))

    period = _period_from_request()
    start, end = period['start'], period['end']

    db_session = get_db_session()
    try:
        person = db_session.query(User).filter_by(id=user_id).first()
        if not person:
            flash('User not found.', 'error')
            return redirect(url_for('resource_utilization.people',
                                    **period['args']))

        wf = _workforce(db_session)
        hours = _load_hours(db_session, [person], start, end, wf)
        person_ctx = _load_context(db_session, [person], start,
                                   end)[person.id]
        workload_trend = _workload_trend(db_session, [person])

        # The individual tickets behind the workload counters, analysed
        # three ways for the tabbed panel: monthly trend (above), the
        # priority profile, and themes of a similar nature.
        workload_tickets = _workload_tickets(db_session, [person])
        snow_as_of = (db_session.query(func.max(
            SnowTicketWorkload.captured_at)).scalar())

        activities = (db_session.query(ActivityEntry)
                      .filter(ActivityEntry.user_id == person.id,
                              ActivityEntry.entry_date >= start,
                              ActivityEntry.entry_date <= end)
                      .order_by(ActivityEntry.entry_date.desc(),
                                ActivityEntry.id.desc())
                      .all())

        # Every assigned task = a T&M allocation: planned days x day hours
        # vs the hours logged against it in the timesheet (all-time, not
        # clipped to the viewing period - an extension must never scroll
        # out of sight).
        tasks = _assigned_task_rows(db_session, [person.id])
        alloc_stats = _allocation_stats(db_session, tasks, wf)

        supported_apps = []
        if person.email:
            supported_apps = (
                db_session.query(ApplicationDetails)
                .join(SupportTeam,
                      SupportTeam.application_id == ApplicationDetails.id)
                .filter(ApplicationDetails.is_active.is_(True),
                        func.lower(SupportTeam.email)
                        == person.email.strip().lower())
                .distinct().order_by(ApplicationDetails.application_name)
                .all())
    finally:
        db_session.close()

    buckets = hours.get(person.id)
    stats = _user_stats(buckets, start, end, wf)

    # Week-by-week breakdown across the period (each row clipped to it).
    weeks = []
    week_start = start - timedelta(days=start.weekday())
    while week_start <= end:
        week_end = week_start + timedelta(days=6)
        lo, hi = max(week_start, start), min(week_end, end)
        weeks.append({
            'start': week_start, 'end': week_end,
            'stats': _user_stats(buckets, lo, hi, wf),
        })
        week_start += timedelta(days=7)

    # 'BAU' shows the support-apps context, 'Project' the projects/tasks
    # context, 'Project & BAU' shows both.
    show_bau_ctx = team_includes_bau(person.team)
    show_project_ctx = team_includes_project(person.team)

    # One row per day in the Timesheet entries panel: a day with several
    # tasks stays a single row carrying every task's detail.
    activity_days = []
    for a in activities:                     # already newest-date first
        if activity_days and activity_days[-1]['date'] == a.entry_date:
            activity_days[-1]['entries'].append(a)
            activity_days[-1]['total'] += a.hours
        else:
            activity_days.append({'date': a.entry_date, 'entries': [a],
                                  'total': a.hours})
    for d in activity_days:
        d['total'] = round(d['total'], 2)

    # Workload analysis (context, never part of the utilization figure).
    # Computed outside the session: plain dicts in, plain dicts out.
    workload_priority = _priority_payload(workload_tickets)
    workload_themes = analyse_themes(workload_tickets)

    return render_template(
        'resource_utilization/user_detail.html',
        user=user, is_pm=is_pm,
        person=person, stats=stats, person_ctx=person_ctx,
        workload_trend=workload_trend,
        workload_tickets=workload_tickets,
        workload_priority=workload_priority,
        workload_themes=workload_themes,
        priority_colors=PRIORITY_COLORS, priority_labels=PRIORITY_LABELS,
        snow_as_of=snow_as_of,
        period=period, period_presets=PERIOD_PRESETS,
        tasks=tasks, activities=activities, activity_days=activity_days,
        weeks=weeks,
        supported_apps=supported_apps,
        show_bau_ctx=show_bau_ctx, show_project_ctx=show_project_ctx,
        band_labels=BAND_LABELS,
        alloc_stats=alloc_stats,
        allocation_band_labels=ALLOCATION_BAND_LABELS,
        user_group_labels=USER_GROUP_LABELS,
        day_hours=wf['day_hours'], wf=wf,
        working_day_count=len(working_days(start, end, wf['holidays'])),
        workload_window_days=WORKLOAD_WINDOW_DAYS,
        today=date.today(),
    )


@resource_utilization_bp.route('/user/<int:user_id>/tickets.xlsx')
def user_tickets_report(user_id):
    """
    One person's ServiceNow ticket list as an Excel workbook.

    Same access rule as the detail page it is offered from: a project
    manager or admin for anyone, everybody else for themselves only. The
    workbook is built from the same helpers that render the page, so the
    file and the screen always agree.
    """
    user = _require_user()
    if not user:
        return redirect(url_for('login'))
    if not _is_pm(user) and user.id != user_id:
        flash('You can download your own ticket list; other people\'s are '
              'available to project managers.', 'error')
        return redirect(url_for('resource_utilization.people'))

    period = _period_from_request()
    db_session = get_db_session()
    try:
        person = db_session.query(User).filter_by(id=user_id).first()
        if not person:
            flash('User not found.', 'error')
            return redirect(url_for('resource_utilization.people',
                                    **period['args']))
        person_name = _full_name(person).title() or person.username
        person_meta = [
            ('Role', (person.role or '').replace('_', ' ').title()),
            ('Group', USER_GROUP_LABELS.get(person.user_group,
                                            person.user_group)),
            ('Team', person.team),
            ('Sub-group', person.sub_group),
            ('ServiceNow assignee name', _full_name(person).title()),
        ]
        tickets = _workload_tickets(db_session, [person])
        snow_as_of = (db_session.query(func.max(
            SnowTicketWorkload.captured_at)).scalar())
    finally:
        db_session.close()

    if not tickets:
        flash('No ServiceNow tickets are captured against '
              f'{person_name} in the last {WORKLOAD_WINDOW_DAYS} days, so '
              'there is nothing to export.', 'error')
        return redirect(url_for('resource_utilization.user_detail',
                                user_id=user_id, **period['args']))

    from .report_excel import build_user_tickets_report
    stream = io.BytesIO()
    build_user_tickets_report(
        stream,
        person_name=person_name,
        person_meta=person_meta,
        tickets=tickets,
        priority_rows=priority_breakdown(tickets),
        themes_analysis=analyse_themes(tickets),
        window_days=WORKLOAD_WINDOW_DAYS,
        generated_by=f"{user.firstname or ''} {user.lastname or ''}".strip(),
        snow_as_of=snow_as_of,
    )
    stream.seek(0)

    safe_name = person_name.replace(' ', '-') or f'user-{user_id}'
    filename = (f"ServiceNow_Tickets_{safe_name}_"
                f"{date.today().isoformat()}.xlsx")
    logger.info('ServiceNow ticket list for user %s downloaded by %s '
                '(%d tickets)', user_id, user.username, len(tickets))
    return send_file(
        stream, as_attachment=True, download_name=filename,
        mimetype=('application/vnd.openxmlformats-officedocument'
                  '.spreadsheetml.sheet'))


# ---------------------------------------------------------------------------
# T&M allocations register (project managers)
# ---------------------------------------------------------------------------

def _allocation_quads(db_session, wf, user_ids=None):
    """
    [(task, project, person, stats)] for every assigned project task, worst
    band first. The people map includes disabled accounts so historical
    allocations keep their names.
    """
    task_rows = _assigned_task_rows(db_session, user_ids)
    stats_by_task = _allocation_stats(db_session, task_rows, wf)
    person_ids = {t.assigned_to for t, _, _ in task_rows}
    people = ({u.id: u for u in db_session.query(User)
               .filter(User.id.in_(person_ids)).all()}
              if person_ids else {})
    quads = [(t, p, people.get(t.assigned_to), stats_by_task[t.id])
             for t, m, p in task_rows]
    quads.sort(key=lambda q: (_ALLOCATION_BAND_SEVERITY[q[3]['band']],
                              -(q[3]['percent'] or 0)))
    return quads


def _filtered_allocations(quads, band, name, only_logged):
    if band in ALLOCATION_BAND_LABELS:
        quads = [q for q in quads if q[3]['band'] == band]
    if name:
        needle = name.lower()
        quads = [q for q in quads
                 if (q[1] and needle in (q[1].name or '').lower())
                 or (q[0] and needle in (q[0].name or '').lower())
                 or (q[2] and (needle in _full_name(q[2])
                               or needle in (q[2].username or '').lower()))]
    if only_logged:
        quads = [q for q in quads if q[3]['consumed_hours'] > 0]
    return quads


@resource_utilization_bp.route('/allocations')
def allocations():
    user = _require_pm()
    if not user:
        return redirect(url_for('index'))

    f_band = (request.args.get('band') or '').strip().lower()
    f_name = _norm(request.args.get('name'))
    f_logged = (request.args.get('logged') or '').strip() == '1'

    db_session = get_db_session()
    try:
        wf = _workforce(db_session)
        quads = _allocation_quads(db_session, wf)
    finally:
        db_session.close()

    kpis = {
        'total': len(quads),
        'nearing': sum(1 for q in quads if q[3]['band'] == 'nearing'),
        'reached': sum(1 for q in quads if q[3]['band'] == 'reached'),
        'extended': sum(1 for q in quads if q[3]['band'] == 'exceeded'),
        'after_end_hours': round(sum(q[3]['after_end_hours']
                                     for q in quads), 2),
        'overrun_hours': round(sum(q[3]['overrun_hours'] for q in quads), 2),
    }

    rows = _filtered_allocations(quads, f_band, f_name, f_logged)

    return render_template(
        'resource_utilization/allocations.html',
        user=user, rows=rows, kpis=kpis,
        allocation_band_labels=ALLOCATION_BAND_LABELS,
        f_band=f_band, f_name=f_name, f_logged=f_logged,
        day_hours=wf['day_hours'], today=date.today(),
    )


@resource_utilization_bp.route('/allocations/report')
def allocations_report():
    user = _require_pm()
    if not user:
        return redirect(url_for('index'))

    db_session = get_db_session()
    try:
        wf = _workforce(db_session)
        rows = _allocation_quads(db_session, wf)
    finally:
        db_session.close()

    from .report_excel import build_allocations_report
    stream = io.BytesIO()
    build_allocations_report(
        stream, rows=rows, allocation_band_labels=ALLOCATION_BAND_LABELS,
        generated_by=f"{user.firstname or ''} {user.lastname or ''}".strip(),
        day_hours=wf['day_hours'],
    )
    stream.seek(0)

    filename = (f"TM_Allocations_{datetime.now().strftime('%Y-%m-%d')}.xlsx")
    logger.info('T&M allocation report downloaded by %s', user.username)
    return send_file(
        stream, as_attachment=True, download_name=filename,
        mimetype=('application/vnd.openxmlformats-officedocument'
                  '.spreadsheetml.sheet'))


# ---------------------------------------------------------------------------
# Workforce settings (admin): holiday calendar, band thresholds, day hours,
# non-billable categories
# ---------------------------------------------------------------------------

@resource_utilization_bp.route('/admin/settings')
def admin_settings():
    user = _require_admin()
    if not user:
        return redirect(url_for('index'))

    db_session = get_db_session()
    try:
        wf = load_settings(db_session)
        holidays = (db_session.query(WorkforceHoliday)
                    .order_by(WorkforceHoliday.holiday_date)
                    .all())
    finally:
        db_session.close()

    return render_template(
        'resource_utilization/settings.html',
        user=user, wf=wf, holidays=holidays,
        category_choices=billable_category_choices(),
        leave_category=LEAVE_CATEGORY,
        default_day_hours=STANDARD_DAY_HOURS,
        today=date.today(),
    )


@resource_utilization_bp.route('/admin/settings/save', methods=['POST'])
@csrf_protect
def save_settings():
    user = _require_admin()
    if not user:
        return redirect(url_for('index'))

    def _num(name):
        try:
            return float((request.form.get(name) or '').strip())
        except (TypeError, ValueError):
            return None

    under = _num('under_pct')
    over = _num('over_pct')
    day_hours = _num('day_hours')
    non_billable = [c for c in request.form.getlist('non_billable')
                    if c in billable_category_choices()]

    if under is None or not (0 < under < 200):
        flash('The under-utilized threshold must be between 0 and 200.',
              'error')
        return redirect(url_for('resource_utilization.admin_settings'))
    if over is None or not (under < over <= 300):
        flash('The over-utilized threshold must be above the under-utilized '
              'one (and at most 300).', 'error')
        return redirect(url_for('resource_utilization.admin_settings'))
    if day_hours is None or not (1.0 <= day_hours <= 24.0):
        flash('The working day must be between 1 and 24 hours.', 'error')
        return redirect(url_for('resource_utilization.admin_settings'))

    db_session = get_db_session()
    try:
        row = db_session.query(WorkforceSettings).first()
        if not row:
            row = WorkforceSettings()
            db_session.add(row)
        row.under_utilized_below = under
        row.over_utilized_above = over
        row.day_hours = day_hours
        row.non_billable_categories = ', '.join(non_billable)
        row.updated_by = user.username
        db_session.commit()
        logger.info('Workforce settings saved by %s (bands %s/%s, day %sh)',
                    user.username, under, over, day_hours)
        flash('Workforce settings saved.', 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error saving workforce settings: %s', e)
        flash('An error occurred while saving the settings.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('resource_utilization.admin_settings'))


@resource_utilization_bp.route('/admin/holidays/add', methods=['POST'])
@csrf_protect
def add_holiday():
    user = _require_admin()
    if not user:
        return redirect(url_for('index'))

    name = (request.form.get('name') or '').strip()
    try:
        holiday_date = date.fromisoformat(
            (request.form.get('holiday_date') or '').strip())
    except (TypeError, ValueError):
        holiday_date = None

    if not holiday_date or not name:
        flash('A date and a holiday name are required.', 'error')
        return redirect(url_for('resource_utilization.admin_settings'))
    if holiday_date.weekday() >= 5:
        flash(f"{holiday_date.strftime('%d %b %Y')} is a weekend - capacity "
              'already excludes it, so it does not need a holiday entry.',
              'error')
        return redirect(url_for('resource_utilization.admin_settings'))

    db_session = get_db_session()
    try:
        exists = (db_session.query(WorkforceHoliday)
                  .filter_by(holiday_date=holiday_date).first())
        if exists:
            flash(f"{holiday_date.strftime('%d %b %Y')} is already in the "
                  f"calendar ({exists.name}).", 'error')
        else:
            db_session.add(WorkforceHoliday(holiday_date=holiday_date,
                                            name=name[:120]))
            db_session.commit()
            logger.info('Holiday %s (%s) added by %s', holiday_date, name,
                        user.username)
            flash(f"Holiday '{name}' added for "
                  f"{holiday_date.strftime('%d %b %Y')}.", 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error adding holiday: %s', e)
        flash('An error occurred while adding the holiday.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('resource_utilization.admin_settings'))


@resource_utilization_bp.route('/admin/holidays/upload', methods=['POST'])
@csrf_protect
def upload_holidays():
    """
    Bulk-load the holiday calendar from an Excel file (.xlsx): first sheet,
    column A = date, column B = holiday name, header row optional. Existing
    dates get their name updated, new dates are added - so re-uploading a
    corrected year simply refreshes it. Weekend / invalid / duplicate rows
    are skipped and reported.
    """
    user = _require_admin()
    if not user:
        return redirect(url_for('index'))

    file = request.files.get('holiday_file')
    if not file or not (file.filename or '').strip():
        flash('Choose an Excel file (.xlsx) to upload.', 'error')
        return redirect(url_for('resource_utilization.admin_settings'))
    if not file.filename.lower().endswith('.xlsx'):
        flash('Please upload a .xlsx Excel file (column A = date, '
              'column B = holiday name).', 'error')
        return redirect(url_for('resource_utilization.admin_settings'))

    try:
        from openpyxl import load_workbook
        wb = load_workbook(file.stream, read_only=True, data_only=True)
        try:
            entries, stats = parse_holiday_rows(
                wb.worksheets[0].iter_rows(values_only=True))
        finally:
            wb.close()
    except Exception as e:
        logger.exception('Could not read holiday upload %s: %s',
                         file.filename, e)
        flash('That file could not be read as an Excel workbook.', 'error')
        return redirect(url_for('resource_utilization.admin_settings'))

    skipped_bits = [f"{count} {reason}" for reason, count in
                    (('weekend', stats['weekend']),
                     ('invalid', stats['invalid']),
                     ('duplicate', stats['duplicate'])) if count]
    skipped_text = (' Skipped: ' + ', '.join(skipped_bits) + '.'
                    if skipped_bits else '')

    if not entries:
        flash('No usable holiday rows found - expected column A = date, '
              'column B = holiday name.' + skipped_text, 'error')
        return redirect(url_for('resource_utilization.admin_settings'))

    db_session = get_db_session()
    try:
        added, updated, unchanged = upsert_holidays(db_session, entries)
        db_session.commit()
        logger.info('Holiday upload %s by %s: %d added, %d updated, '
                    '%d unchanged, skipped %s', file.filename, user.username,
                    added, updated, unchanged, stats)
        summary = [f"{added} holiday(s) added"]
        if updated:
            summary.append(f"{updated} renamed")
        if unchanged:
            summary.append(f"{unchanged} already up to date")
        flash('Holiday calendar updated: ' + ', '.join(summary) + '.'
              + skipped_text, 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error applying holiday upload: %s', e)
        flash('An error occurred while updating the holiday calendar.',
              'error')
    finally:
        db_session.close()

    return redirect(url_for('resource_utilization.admin_settings'))


@resource_utilization_bp.route('/admin/holidays/<int:holiday_id>/delete',
                               methods=['POST'])
@csrf_protect
def delete_holiday(holiday_id):
    user = _require_admin()
    if not user:
        return redirect(url_for('index'))

    db_session = get_db_session()
    try:
        row = (db_session.query(WorkforceHoliday)
               .filter_by(id=holiday_id).first())
        if not row:
            flash('Holiday not found.', 'error')
        else:
            label = f"{row.name} ({row.holiday_date.strftime('%d %b %Y')})"
            db_session.delete(row)
            db_session.commit()
            logger.info('Holiday %s removed by %s', label, user.username)
            flash(f"Holiday {label} removed from the calendar.", 'success')
    except Exception as e:
        db_session.rollback()
        logger.exception('Error deleting holiday %s: %s', holiday_id, e)
        flash('An error occurred while deleting the holiday.', 'error')
    finally:
        db_session.close()

    return redirect(url_for('resource_utilization.admin_settings'))
