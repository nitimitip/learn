"""
arch_brief.py - the Business and Enterprise Architecture brief.

The analytics pack in insights.py measures the estate the way an analyst
takes it apart: seven graded dimensions, a written assessment, an agenda,
support-cover exposure, ownership alignment. That is the right document to
put behind a steering group, and it is the wrong document to put in FRONT of
one - it is long, and a good half of it answers questions a support manager
asks rather than questions an architect asks.

This module is the other document: one screen, no paragraphs, and only the
things an enterprise architect is actually asked about.

    integration     what talks to what, over what, in which pattern
    platform        what the estate runs on - operating systems first
    capability      the BC1 / BC2 / BC3 spread, by domain
    dependency      upstream and downstream, and who sits in the middle
    risk            the architectural and technology concerns, ranked

Everything here is derived from the SAME graph the diagram is drawn from
(architecture.build_estate_graph) and from the SAME classifiers insights.py
uses, so the brief and the analysis underneath it cannot disagree about a
number. Nothing here counts people: headcount is a support question, and a
brief that leads with it is not an architecture brief.

ASCII only, to the module's convention.
"""

from . import insights

# Re-exported so callers and tests have one name for them.
GROUPING_TOWER = insights.GROUPING_TOWER
GROUPING_DOMAIN = insights.GROUPING_DOMAIN


# ---------------------------------------------------------------------------
# Integration patterns
#
# insights.classify_protocol() answers "what is this wire made of" - SFTP,
# Kafka, a DB link. A pattern is the level above that: the architectural
# STYLE the wire implies, which is the thing a target-state conversation is
# actually about. Several protocol families collapse into one pattern on
# purpose; the protocol detail is still reported beside it.
# ---------------------------------------------------------------------------

#: protocol family (as insights.classify_protocol returns it) -> pattern.
PATTERN_OF_PROTOCOL = {
    'API / web service': 'Request / response (API)',
    'Messaging / queue': 'Event driven',
    'Database link': 'Shared data (database)',
    'File transfer': 'Batch file transfer',
    'Batch / scheduled job': 'Batch file transfer',
    'Email': 'Point to point (other)',
    insights.PROTOCOL_OTHER: 'Not recorded',
}

PATTERN_API = 'Request / response (API)'
PATTERN_EVENT = 'Event driven'
PATTERN_DATA = 'Shared data (database)'
PATTERN_BATCH = 'Batch file transfer'
PATTERN_OTHER = 'Point to point (other)'
PATTERN_NONE = 'Not recorded'

#: Display order. Loosely coupled patterns first, because that is the order a
#: target-state slide reads in and the order makes the mix legible at a
#: glance without anyone reading the numbers.
PATTERN_ORDER = (PATTERN_API, PATTERN_EVENT, PATTERN_DATA, PATTERN_BATCH,
                 PATTERN_OTHER, PATTERN_NONE)

#: How each pattern is marked in the UI. "tight" is not a failing grade - a
#: nightly extract can be exactly right - it is a statement about how hard
#: the two ends are to change independently.
PATTERN_COUPLING = {
    PATTERN_API: 'loose',
    PATTERN_EVENT: 'loose',
    PATTERN_DATA: 'tight',
    PATTERN_BATCH: 'tight',
    PATTERN_OTHER: 'tight',
    PATTERN_NONE: 'unknown',
}

#: One line per pattern, for the tooltip. Short enough to sit in a card.
PATTERN_NOTE = {
    PATTERN_API: 'Synchronous call between two systems that both stay up',
    PATTERN_EVENT: 'Published events; the two ends do not have to be up '
                   'together',
    PATTERN_DATA: 'One system reads another\'s data store directly',
    PATTERN_BATCH: 'Scheduled extract and load; latency is the schedule',
    PATTERN_OTHER: 'Direct coupling that is none of the above',
    PATTERN_NONE: 'No connectivity type recorded against the interface',
}


def classify_pattern(connectivity):
    """Free-text connectivity -> integration pattern."""
    family = insights.classify_protocol(connectivity)
    return PATTERN_OF_PROTOCOL.get(family, PATTERN_OTHER)


# ---------------------------------------------------------------------------
# Business criticality
#
# BC1 / BC2 / BC3 is the estate's own capability tiering, recorded on every
# application record. It is the one field on the diagram that a business
# audience reads without translation, so it leads the brief.
# ---------------------------------------------------------------------------

BC_TIERS = (
    ('BC1', 'Tier 1 - business critical',
     'An outage stops a business process the same day'),
    ('BC2', 'Tier 2 - business important',
     'An outage degrades a business process within days'),
    ('BC3', 'Tier 3 - business supporting',
     'An outage is absorbed by the business for a while'),
)

BC_UNRATED = 'Not rated'


# ---------------------------------------------------------------------------
# Risk severities, reused from insights so one vocabulary covers both packs.
# ---------------------------------------------------------------------------

SEV_HIGH = insights.SEV_HIGH
SEV_MEDIUM = insights.SEV_MEDIUM
SEV_LOW = insights.SEV_LOW

#: Risk areas. Architecture and technology only - deliberately no support,
#: ownership or headcount area, because those belong to the analysis pack.
AREA_INTEGRATION = 'Integration'
AREA_DEPENDENCY = 'Dependency'
AREA_PLATFORM = 'Platform'
AREA_RECORD = 'Architecture record'

#: An application on this many connections or more is load-bearing enough
#: that its blast radius is worth naming on the brief.
HUB_DEGREE_FLOOR = 4

#: Share of interfaces in a tightly-coupled pattern past which the estate is
#: said to lean on point-to-point integration.
TIGHT_COUPLING_PCT = 40.0

#: Share of interfaces with no connectivity type past which the RECORD is the
#: finding rather than the estate.
UNRECORDED_PCT = 20.0

#: Share of applications with no technology recorded past which the estate
#: cannot answer a lifecycle question about itself.
STACK_GAP_PCT = 40.0

#: Share of links inferred from a name rather than evidenced by a hostname
#: past which the map is reporting inference at a level worth stating.
INFERRED_PCT = 30.0

#: Operating systems whose name alone is a lifecycle conversation. Matched as
#: substrings of the lower-cased value, so "Windows Server 2012 R2 Standard"
#: is caught by "windows server 2012". Nothing here is asserted to be out of
#: support in a given estate - the finding is "check this", not "this is
#: unsupported", because support dates are contractual and local.
DATED_OS_MARKERS = (
    'windows server 2003', 'windows server 2008', 'windows server 2012',
    'windows 7', 'windows 8', 'windows xp', 'windows nt',
    'rhel 5', 'rhel 6', 'red hat enterprise linux 5',
    'red hat enterprise linux 6', 'centos 6', 'centos 7',
    'ubuntu 14', 'ubuntu 16', 'ubuntu 18',
    'solaris', 'aix 6', 'aix 7.1', 'hp-ux', 'suse 11',
)


def _pct(part, whole):
    return insights._pct(part, whole)


def _clean(value):
    return ' '.join(str(value or '').split())


# ---------------------------------------------------------------------------
# Integration - what talks to what, over what
# ---------------------------------------------------------------------------

def build_integration(graph, grouping):
    """The estate's integration profile: patterns, protocols and reach.

    Patterns and protocols are counted over INTERFACE RECORDS, because each
    one is a thing that has to keep working. Connections are counted over
    resolved LINKS, because two applications joined one way are one
    dependency however many rows describe it. Both numbers are reported, and
    the gap between them is the estate's duplicate-record count.
    """
    groups, group_of_app = insights.group_index(graph, grouping)
    links = graph.get('links') or []
    apps = graph.get('apps') or []

    patterns = {}
    protocols = {}
    directions = {'Inbound': 0, 'Outbound': 0, 'Bi-Directional Flow': 0}
    interfaces = 0
    for app in apps:
        for itf in app.get('interfaces') or []:
            interfaces += 1
            pattern = classify_pattern(itf.get('connectivity'))
            patterns[pattern] = patterns.get(pattern, 0) + 1
            family = insights.classify_protocol(itf.get('connectivity'))
            label = _clean(itf.get('connectivity')) or 'Not recorded'
            entry = protocols.setdefault(
                label, {'name': label, 'family': family,
                        'pattern': pattern, 'count': 0})
            entry['count'] += 1
            direction = itf.get('direction') or ''
            if direction in directions:
                directions[direction] += 1

    pattern_rows = []
    for name in PATTERN_ORDER:
        count = patterns.get(name, 0)
        if not count:
            continue
        pattern_rows.append({
            'pattern': name,
            'count': count,
            'pct': _pct(count, interfaces),
            'coupling': PATTERN_COUPLING.get(name, 'unknown'),
            'note': PATTERN_NOTE.get(name, ''),
        })

    protocol_rows = sorted(protocols.values(),
                           key=lambda r: (-r['count'], r['name'].lower()))
    for row in protocol_rows:
        row['pct'] = _pct(row['count'], interfaces)

    loose = sum(r['count'] for r in pattern_rows if r['coupling'] == 'loose')
    tight = sum(r['count'] for r in pattern_rows if r['coupling'] == 'tight')
    unknown = sum(r['count'] for r in pattern_rows
                  if r['coupling'] == 'unknown')

    # Cross-group reach: how much of the estate's integration crosses a
    # domain or tower boundary, which is the number a target-operating-model
    # conversation turns on.
    cross = 0
    for link in links:
        ga = group_of_app.get(link['src_app'])
        gb = group_of_app.get(link['dst_app'])
        if ga is not None and gb is not None and ga != gb:
            cross += 1

    declarations = sum(len(l.get('interface_ids') or []) or 1 for l in links)
    connected = set()
    for link in links:
        connected.add(link['src_app'])
        connected.add(link['dst_app'])
    for ext in graph.get('externals') or []:
        for edge in ext.get('links') or []:
            connected.add(edge.get('app'))

    return {
        'interfaces': interfaces,
        'connections': len(links),
        'declarations': declarations,
        'duplicate_records': max(0, declarations - len(links)),
        'cross_group': cross,
        'cross_group_pct': _pct(cross, len(links)),
        'internal': len(links) - cross,
        'externals': len(graph.get('externals') or []),
        'connected_apps': len([a for a in apps if a['id'] in connected]),
        'isolated_apps': len([a for a in apps if a['id'] not in connected]),
        'patterns': pattern_rows,
        'protocols': protocol_rows[:12],
        'protocol_count': len(protocol_rows),
        'directions': directions,
        'loose': loose,
        'loose_pct': _pct(loose, interfaces),
        'tight': tight,
        'tight_pct': _pct(tight, interfaces),
        'unknown': unknown,
        'unknown_pct': _pct(unknown, interfaces),
        'groups': len(groups),
    }


# ---------------------------------------------------------------------------
# Platform - operating systems first, then the rest of the stack
#
# Operating systems arrive from two places and BOTH are read: the
# Infrastructure section records an OS against every server, and the
# Technical Details tab records one against the application. The server
# record is the one the estate actually patches, so it leads; an application
# whose stack names an OS no server confirms is still counted, because the
# alternative is a platform view that goes blank for a cloud application with
# no servers listed against it.
# ---------------------------------------------------------------------------

STACK_LABELS = {
    'os': 'Operating systems',
    'database': 'Databases',
    'language': 'Languages and frameworks',
    'tool': 'Tools and middleware',
}

STACK_ORDER = ('os', 'database', 'language', 'tool')


def _os_key(name):
    """Normalise an OS label enough to merge obvious restatements."""
    return ' '.join(str(name or '').replace('_', ' ').lower().split())


def build_platform(graph, grouping):
    """What the estate runs on.

    Returns operating systems as their own block - it is the first question
    an infrastructure or security architect asks - plus the rest of the
    recorded stack, hosting locations, and the technologies carried by a
    single application (the cheapest rationalisation question there is).
    """
    apps = graph.get('apps') or []
    total_apps = len(apps)

    os_usage = {}
    servers = 0
    locations = {}
    for app in apps:
        seen = set()
        for server in app.get('servers') or []:
            servers += 1
            location = _clean(server.get('location'))
            if location:
                locations[location] = locations.get(location, 0) + 1
            name = _clean(server.get('os'))
            if not name:
                continue
            key = _os_key(name)
            entry = os_usage.setdefault(
                key, {'name': name, 'servers': 0, 'app_ids': set(),
                      'source': 'infrastructure'})
            entry['servers'] += 1
            entry['app_ids'].add(app['id'])
            seen.add(key)
        for item in app.get('tech') or []:
            if (item.get('category') or '').strip().lower() != 'os':
                continue
            name = _clean(item.get('name'))
            if not name:
                continue
            key = _os_key(name)
            entry = os_usage.setdefault(
                key, {'name': name, 'servers': 0, 'app_ids': set(),
                      'source': 'technical details'})
            entry['app_ids'].add(app['id'])

    os_rows = []
    for entry in os_usage.values():
        apps_on = len(entry['app_ids'])
        os_rows.append({
            'name': entry['name'],
            'apps': apps_on,
            'servers': entry['servers'],
            'pct': _pct(apps_on, total_apps),
            'dated': _is_dated_os(entry['name']),
            'source': entry['source'],
        })
    os_rows.sort(key=lambda r: (-r['apps'], -r['servers'], r['name'].lower()))

    # The rest of the recorded stack, by category.
    stack = {}
    documented = 0
    for app in apps:
        items = app.get('tech') or []
        if items:
            documented += 1
        for item in items:
            category = (item.get('category') or '').strip().lower()
            if category == 'os':
                continue        # already its own block above
            name = _clean(item.get('name'))
            if not name:
                continue
            entry = stack.setdefault(
                (category, name.lower()),
                {'category': category, 'name': name, 'app_ids': set()})
            entry['app_ids'].add(app['id'])

    by_category = {}
    singletons = []
    for entry in stack.values():
        row = {'name': entry['name'], 'apps': len(entry['app_ids']),
               'category': entry['category']}
        by_category.setdefault(entry['category'], []).append(row)
        if row['apps'] == 1:
            singletons.append(row)

    stack_rows = []
    for category in STACK_ORDER:
        items = by_category.get(category)
        if not items:
            continue
        items.sort(key=lambda r: (-r['apps'], r['name'].lower()))
        stack_rows.append({
            'category': category,
            'label': STACK_LABELS.get(category, (category or 'Other').title()),
            'distinct': len(items),
            'singletons': len([r for r in items if r['apps'] == 1]),
            'top': items[:8],
        })
    for category in sorted(by_category):
        if category in STACK_ORDER:
            continue
        items = by_category[category]
        items.sort(key=lambda r: (-r['apps'], r['name'].lower()))
        stack_rows.append({
            'category': category,
            'label': (category or 'Other').title(),
            'distinct': len(items),
            'singletons': len([r for r in items if r['apps'] == 1]),
            'top': items[:8],
        })

    location_rows = sorted(
        ({'name': name, 'servers': count, 'pct': _pct(count, servers)}
         for name, count in locations.items()),
        key=lambda r: (-r['servers'], r['name'].lower()))

    singletons.sort(key=lambda r: (r['category'], r['name'].lower()))
    dated = [r for r in os_rows if r['dated']]
    return {
        'os': os_rows,
        'os_distinct': len(os_rows),
        'os_dated': dated,
        'servers': servers,
        'no_infrastructure': len([a for a in apps if not (a.get('servers') or [])]),
        'locations': location_rows[:8],
        'location_count': len(location_rows),
        'stack': stack_rows,
        'singletons': singletons[:20],
        'singleton_count': len(singletons),
        'documented': documented,
        'documented_pct': _pct(documented, total_apps),
        'undocumented': total_apps - documented,
    }


def _is_dated_os(name):
    """True when an OS label is one worth a lifecycle check."""
    low = _os_key(name)
    return any(marker in low for marker in DATED_OS_MARKERS)


# ---------------------------------------------------------------------------
# Capability tiering - BC1 / BC2 / BC3
# ---------------------------------------------------------------------------

def build_capability(graph, grouping):
    """The BC1 / BC2 / BC3 spread, for the estate and per group.

    Each tier also carries how connected it is, because "twelve BC1 systems"
    and "twelve BC1 systems carrying half the estate's integration" are
    different statements and only the second one is an architecture finding.
    """
    groups, group_of_app = insights.group_index(graph, grouping)
    group_name = dict((g['id'], g['name']) for g in groups)
    apps = graph.get('apps') or []
    total = len(apps)

    degree = {}
    for link in graph.get('links') or []:
        degree[link['src_app']] = degree.get(link['src_app'], 0) + 1
        degree[link['dst_app']] = degree.get(link['dst_app'], 0) + 1
    external_facing = {}
    for ext in graph.get('externals') or []:
        for edge in ext.get('links') or []:
            app_id = edge.get('app')
            external_facing[app_id] = external_facing.get(app_id, 0) + 1

    tiers = []
    for code, label, note in BC_TIERS:
        members = [a for a in apps if a.get('bc') == code]
        tiers.append({
            'code': code, 'label': label, 'note': note,
            'count': len(members),
            'pct': _pct(len(members), total),
            'connections': sum(degree.get(a['id'], 0) for a in members),
            'external_facing': len([a for a in members
                                    if external_facing.get(a['id'])]),
            'isolated': len([a for a in members if not degree.get(a['id'])]),
        })
    rated = sum(t['count'] for t in tiers)
    if total - rated > 0:
        tiers.append({
            'code': '', 'label': BC_UNRATED,
            'note': 'No business criticality recorded on the application',
            'count': total - rated, 'pct': _pct(total - rated, total),
            'connections': 0, 'external_facing': 0, 'isolated': 0,
        })

    by_group = []
    for group in groups:
        if not group['app_ids']:
            continue
        mix = dict((code, 0) for code, _l, _n in BC_TIERS)
        for app_id in group['app_ids']:
            app = next((a for a in apps if a['id'] == app_id), None)
            if app and app.get('bc') in mix:
                mix[app['bc']] += 1
        by_group.append({
            'id': group['id'],
            'name': group['name'],
            'apps': len(group['app_ids']),
            'mix': mix,
            'bc1': mix.get('BC1', 0),
            'bc1_pct': _pct(mix.get('BC1', 0), len(group['app_ids'])),
        })
    by_group.sort(key=lambda r: (-r['bc1'], -r['apps'], r['name'].lower()))

    return {
        'tiers': tiers,
        'total': total,
        'bc1': next((t['count'] for t in tiers if t['code'] == 'BC1'), 0),
        'by_group': by_group,
        'group_label': insights.GROUPINGS[grouping]['label'],
        'unrated': total - rated,
        'group_name': group_name,
    }


# ---------------------------------------------------------------------------
# Dependencies - upstream, downstream, and who sits in the middle
# ---------------------------------------------------------------------------

def build_dependency(graph, grouping):
    """Which applications the estate leans on, and which way the data runs.

    Upstream and downstream are stated from the application's own point of
    view, the way the L3 diagram states them: an application's UPSTREAM
    systems feed it, its DOWNSTREAM systems consume from it, and a
    bi-directional connection counts on both sides because it genuinely is
    both.
    """
    groups, group_of_app = insights.group_index(graph, grouping)
    group_name = dict((g['id'], g['name']) for g in groups)
    apps = graph.get('apps') or []
    app_by_id = dict((a['id'], a) for a in apps)

    up = {}
    down = {}
    cross = {}
    for link in graph.get('links') or []:
        src, dst = link['src_app'], link['dst_app']
        down.setdefault(src, set()).add(dst)
        up.setdefault(dst, set()).add(src)
        if link.get('bidir'):
            down.setdefault(dst, set()).add(src)
            up.setdefault(src, set()).add(dst)
        ga, gb = group_of_app.get(src), group_of_app.get(dst)
        if ga is not None and gb is not None and ga != gb:
            cross[src] = cross.get(src, 0) + 1
            cross[dst] = cross.get(dst, 0) + 1

    ext_up = {}
    ext_down = {}
    for ext in graph.get('externals') or []:
        for edge in ext.get('links') or []:
            app_id = edge.get('app')
            name = ext.get('name') or ''
            if edge.get('direction') == 'Outbound':
                ext_down.setdefault(app_id, set()).add(name)
            elif edge.get('direction') == 'Inbound':
                ext_up.setdefault(app_id, set()).add(name)
            else:
                ext_up.setdefault(app_id, set()).add(name)
                ext_down.setdefault(app_id, set()).add(name)

    rows = []
    for app in apps:
        upstream = up.get(app['id'], set())
        downstream = down.get(app['id'], set())
        peers = upstream | downstream
        if not peers and not ext_up.get(app['id']) \
                and not ext_down.get(app['id']):
            continue
        rows.append({
            'app_id': app['id'],
            'app': app.get('name') or '',
            'bc': app.get('bc') or '',
            'group': group_name.get(group_of_app.get(app['id']), ''),
            'upstream': len(upstream),
            'downstream': len(downstream),
            'peers': len(peers),
            'cross': cross.get(app['id'], 0),
            'ext_upstream': len(ext_up.get(app['id'], set())),
            'ext_downstream': len(ext_down.get(app['id'], set())),
            'upstream_names': sorted(
                (app_by_id[i].get('name') or '' for i in upstream
                 if i in app_by_id), key=lambda s: s.lower())[:8],
            'downstream_names': sorted(
                (app_by_id[i].get('name') or '' for i in downstream
                 if i in app_by_id), key=lambda s: s.lower())[:8],
        })
    rows.sort(key=lambda r: (-r['peers'], -r['cross'], r['app'].lower()))

    providers = sorted(rows, key=lambda r: (-r['downstream'], r['app'].lower()))
    consumers = sorted(rows, key=lambda r: (-r['upstream'], r['app'].lower()))

    # Third parties, split the way a contract conversation splits them.
    ext_rows = []
    for ext in graph.get('externals') or []:
        inbound = outbound = 0
        bc1 = 0
        touched = set()
        for edge in ext.get('links') or []:
            app = app_by_id.get(edge.get('app'))
            if not app:
                continue
            touched.add(app['id'])
            if app.get('bc') == 'BC1':
                bc1 += 1
            direction = edge.get('direction') or ''
            if direction == 'Outbound':
                outbound += 1
            elif direction == 'Inbound':
                inbound += 1
            else:
                inbound += 1
                outbound += 1
        ext_rows.append({
            'name': ext.get('name') or '',
            'apps': len(touched),
            'inbound': inbound,
            'outbound': outbound,
            'bc1': bc1,
            'role': ('Upstream' if inbound and not outbound
                     else 'Downstream' if outbound and not inbound
                     else 'Both ways'),
        })
    ext_rows.sort(key=lambda r: (-r['apps'], -r['bc1'], r['name'].lower()))

    return {
        'rows': rows[:12],
        'total_connected': len(rows),
        'providers': [r for r in providers if r['downstream']][:6],
        'consumers': [r for r in consumers if r['upstream']][:6],
        'hubs': [r for r in rows if r['peers'] >= HUB_DEGREE_FLOOR],
        'externals': ext_rows[:12],
        'external_count': len(ext_rows),
        'external_upstream': len([r for r in ext_rows
                                  if r['role'] in ('Upstream', 'Both ways')]),
        'external_downstream': len([r for r in ext_rows
                                    if r['role'] in ('Downstream',
                                                     'Both ways')]),
    }


# ---------------------------------------------------------------------------
# Architectural and technology risk
#
# Every risk here is an ARCHITECTURE risk: how the estate is joined together,
# what it runs on, and what the record does not say about either. Support
# cover, headcount and ownership spread are real risks and they are reported
# by insights.build_findings() - they are not reported here, because a brief
# that mixes them dilutes the one thing it exists to say.
# ---------------------------------------------------------------------------

def _risk(severity, area, title, metric, detail, action, items=None):
    return {
        'severity': severity, 'area': area, 'title': title,
        'metric': metric, 'detail': detail, 'action': action,
        'items': items or [],
    }


def build_risks(graph, grouping, integration, platform, capability,
                dependency):
    """The architectural and technology concerns, most serious first."""
    risks = []
    apps = graph.get('apps') or []
    noun = insights.GROUPINGS[grouping]['noun']

    # ---- concentration: one application everything runs through -----------
    for row in dependency['hubs'][:3]:
        severity = SEV_HIGH if row['bc'] == 'BC1' else SEV_MEDIUM
        risks.append(_risk(
            severity, AREA_DEPENDENCY,
            '{0} is load bearing'.format(row['app']),
            '{0} connected systems'.format(row['peers']),
            'It feeds {0} and is fed by {1}; {2} of those cross a {3} '
            'boundary.'.format(row['downstream'], row['upstream'],
                               row['cross'], noun),
            'Confirm the failover and recovery position for this system '
            'before any change that touches it.',
            items=row['downstream_names'][:6]))

    # ---- BC1 systems depending on something outside the estate ------------
    bc1_external = []
    for ext in graph.get('externals') or []:
        for edge in ext.get('links') or []:
            app = next((a for a in apps if a['id'] == edge.get('app')), None)
            if not app or app.get('bc') != 'BC1':
                continue
            if edge.get('direction') == 'Outbound':
                continue        # we feed them; they do not hold us up
            bc1_external.append('{0} <- {1}'.format(app.get('name') or '',
                                                    ext.get('name') or ''))
    if bc1_external:
        risks.append(_risk(
            SEV_HIGH, AREA_DEPENDENCY,
            'Business-critical systems fed from outside the estate',
            '{0} dependencies'.format(len(bc1_external)),
            'A BC1 application cannot be recovered faster than the third '
            'party it reads from.',
            'Check the contracted availability of each supplier against the '
            'recovery target of the application that depends on it.',
            items=sorted(set(bc1_external))[:8]))

    # ---- integration pattern mix ------------------------------------------
    if integration['tight_pct'] >= TIGHT_COUPLING_PCT:
        tight_names = [r['pattern'] for r in integration['patterns']
                       if r['coupling'] == 'tight']
        risks.append(_risk(
            SEV_MEDIUM, AREA_INTEGRATION,
            'The estate leans on tightly coupled integration',
            '{0}% of interfaces'.format(integration['tight_pct']),
            'File drops, direct database reads and point-to-point links '
            'make both ends hard to change independently.',
            'Target the highest-volume of these for an API or event '
            'interface at the next change on either side.',
            items=tight_names))

    if integration['unknown_pct'] >= UNRECORDED_PCT:
        risks.append(_risk(
            SEV_MEDIUM, AREA_RECORD,
            'Integration method not recorded on many interfaces',
            '{0}% of interfaces'.format(integration['unknown_pct']),
            'An interface with no connectivity type cannot be assessed for '
            'coupling, security or recovery.',
            'Set a connectivity type on every External Interface record.'))

    if integration['duplicate_records']:
        risks.append(_risk(
            SEV_LOW, AREA_RECORD,
            'Connections recorded more than once',
            '{0} surplus records'.format(integration['duplicate_records']),
            'Both application owners have recorded their own side of the '
            'same integration. The diagram draws each connection once; the '
            'interface counts still see every record.',
            'Remove the surplus External Interface rows listed under Data '
            'quality.'))

    # ---- platform ---------------------------------------------------------
    if platform['os_dated']:
        risks.append(_risk(
            SEV_HIGH, AREA_PLATFORM,
            'Operating systems that need a lifecycle check',
            '{0} of {1} recorded'.format(len(platform['os_dated']),
                                         platform['os_distinct']),
            'These platforms are at or beyond the point where vendor '
            'support has to be confirmed rather than assumed.',
            'Confirm the support position for each, and put the ones '
            'without cover on the remediation plan.',
            items=['{0} ({1} application{2})'.format(
                r['name'], r['apps'], '' if r['apps'] == 1 else 's')
                for r in platform['os_dated'][:8]]))

    if platform['os_distinct'] > 6:
        risks.append(_risk(
            SEV_LOW, AREA_PLATFORM,
            'Operating system estate is fragmented',
            '{0} distinct platforms'.format(platform['os_distinct']),
            'Every additional platform is a separate patching, hardening '
            'and skills obligation.',
            'Agree a target platform set and map each outlier to it.',
            items=[r['name'] for r in platform['os'][:8]]))

    if platform['singleton_count']:
        risks.append(_risk(
            SEV_LOW, AREA_PLATFORM,
            'Technologies carried for a single application',
            '{0} technologies'.format(platform['singleton_count']),
            'Each one is a licence, a skill and a patching obligation held '
            'for one system.',
            'Review each against the estate standard at that system\'s next '
            'major change.',
            items=['{0} ({1})'.format(r['name'], r['category'] or 'other')
                   for r in platform['singletons'][:8]]))

    if platform['documented_pct'] < (100.0 - STACK_GAP_PCT):
        risks.append(_risk(
            SEV_MEDIUM, AREA_RECORD,
            'Technology stack not recorded for much of the estate',
            '{0} of {1} applications'.format(platform['undocumented'],
                                             capability['total']),
            'An application with no recorded stack is invisible to any '
            'vulnerability, lifecycle or rationalisation question.',
            'Complete the Technical Details tab, BC1 applications first.'))

    # ---- what the map itself is standing on -------------------------------
    links = graph.get('links') or []
    inferred = len([l for l in links if l.get('match') != 'host'])
    inferred_pct = _pct(inferred, len(links))
    if inferred_pct >= INFERRED_PCT and links:
        risks.append(_risk(
            SEV_MEDIUM, AREA_RECORD,
            'Part of this map is inferred rather than evidenced',
            '{0}% of connections'.format(inferred_pct),
            'These connections were matched because two names happened to '
            'agree, not because a hostname was recorded on both sides.',
            'Record the peer hostname on the External Interface, and the '
            'server under the peer\'s Infrastructure.'))

    isolated = integration['isolated_apps']
    if isolated:
        risks.append(_risk(
            SEV_LOW, AREA_RECORD,
            'Applications showing no connections at all',
            '{0} applications'.format(isolated),
            'A system with no interfaces recorded appears unconnected on '
            'every view, which is rarely true of a live application.',
            'Record the External Interfaces for each, or retire the record.'))

    risks.sort(key=lambda r: (insights.SEV_ORDER.get(r['severity'], 9),
                              r['area'], r['title'].lower()))
    counts = {SEV_HIGH: 0, SEV_MEDIUM: 0, SEV_LOW: 0}
    for risk in risks:
        counts[risk['severity']] = counts.get(risk['severity'], 0) + 1
    return {'rows': risks, 'counts': counts, 'total': len(risks)}


# ---------------------------------------------------------------------------
# The brief
# ---------------------------------------------------------------------------

def build_brief(graph, grouping=GROUPING_DOMAIN):
    """The whole Business and Enterprise Architecture brief, as one dict.

    `graph` is architecture.build_estate_graph()'s output. An unknown
    grouping falls back to the domain reading rather than raising, matching
    insights.build_insights(): this feeds a read-only view, and a panel with
    no brief beside the diagram is better than a 500.
    """
    if grouping not in insights.GROUPINGS:
        grouping = GROUPING_DOMAIN
    meta = insights.GROUPINGS[grouping]

    integration = build_integration(graph, grouping)
    platform = build_platform(graph, grouping)
    capability = build_capability(graph, grouping)
    dependency = build_dependency(graph, grouping)
    risks = build_risks(graph, grouping, integration, platform, capability,
                        dependency)

    groups, _group_of_app = insights.group_index(graph, grouping)
    populated = len([g for g in groups if g['app_ids']])

    # The metric rail. Eight numbers, every one of them an architecture
    # question, and not one of them a headcount.
    rail = [
        {'key': 'apps', 'label': 'Applications',
         'value': capability['total'],
         'note': '{0} {1}'.format(populated, meta['plural'].lower())},
        {'key': 'bc1', 'label': 'Business critical',
         'value': capability['bc1'],
         'note': 'BC1, of {0} rated'.format(
             capability['total'] - capability['unrated']),
         'tone': 'critical' if capability['bc1'] else ''},
        {'key': 'connections', 'label': 'Integrations',
         'value': integration['connections'],
         'note': '{0} interface records'.format(integration['interfaces'])},
        {'key': 'cross', 'label': 'Cross-{0}'.format(meta['noun']),
         'value': integration['cross_group'],
         'note': '{0}% of all connections'.format(
             integration['cross_group_pct'])},
        {'key': 'externals', 'label': 'Third-party systems',
         'value': dependency['external_count'],
         # Not a partition: a system the estate both reads from and feeds
         # is counted on both sides, so these two can exceed the total.
         'note': '{0} feed in, {1} consume out'.format(
             dependency['external_upstream'],
             dependency['external_downstream'])},
        {'key': 'loose', 'label': 'Loosely coupled',
         'value': '{0}%'.format(integration['loose_pct']),
         'note': 'API and event interfaces',
         'tone': 'good' if integration['loose_pct'] >= 50 else ''},
        {'key': 'platforms', 'label': 'Operating systems',
         'value': platform['os_distinct'],
         'note': '{0} server{1} recorded'.format(
             platform['servers'], '' if platform['servers'] == 1 else 's'),
         'tone': 'warn' if platform['os_dated'] else ''},
        {'key': 'risks', 'label': 'Architecture risks',
         'value': risks['total'],
         'note': '{0} high, {1} medium'.format(
             risks['counts'].get(SEV_HIGH, 0),
             risks['counts'].get(SEV_MEDIUM, 0)),
         'tone': 'critical' if risks['counts'].get(SEV_HIGH) else ''},
    ]

    return {
        'grouping': grouping,
        'label': meta['label'],
        'plural': meta['plural'],
        'noun': meta['noun'],
        'view': meta['view'],
        'rail': rail,
        'integration': integration,
        'platform': platform,
        'capability': capability,
        'dependency': dependency,
        'risks': risks,
    }
