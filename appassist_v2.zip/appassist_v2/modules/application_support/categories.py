"""
Application Category - persistence helpers and rules.

A category is the business area an application serves (Finance, Registration,
CRM, ...). It is admin-managed data, not an Enum, because the list belongs to
the organisation and changes without a release.

Everything that touches the database lives here so routes.py stays thin, and
the pure rules (name normalisation, clash detection, selection validation)
are importable without a session for the unit tests.

Two rules are worth knowing before changing anything:

  * RETIRE, DO NOT DELETE. A category any application records is
    de-activated instead of removed, so those applications keep reading
    correctly while the value disappears from the dropdown.
  * A RETIRED category an application already carries stays selectable ON
    THAT APPLICATION. Editing an unrelated field must never silently
    re-classify the record, and must never be blocked by a change an admin
    made elsewhere.

Python 3.9 compatible on purpose - production runs 3.9.
"""

from sqlalchemy import func

from .models import ApplicationCategory, ApplicationDetails

# Longest name the column can hold; the form and the parser agree here
# rather than discovering it as a database error on save.
NAME_MAX = 150

# Sort order given to an admin-added category, so hand-added values fall
# after the seeded ones but stay alphabetical among themselves.
DEFAULT_SORT_ORDER = 500

# Starter list. Additive seeding only - see seed_categories().
SEED_CATEGORIES = (
    ('Finance', 'Accounting, treasury, billing and financial reporting', 10),
    ('Registration', 'Customer, member or asset registration and onboarding', 20),
    ('CRM', 'Customer relationship, service and contact management', 30),
    ('HR & Payroll', 'People, payroll, recruitment and time management', 40),
    ('Supply Chain', 'Procurement, inventory, logistics and warehousing', 50),
    ('Sales & Marketing', 'Campaigns, pricing, quotations and order capture', 60),
    ('Operations', 'Core business operations and production systems', 70),
    ('Data & Analytics', 'Reporting, data warehouse, BI and analytics', 80),
    ('Infrastructure', 'Platform, middleware and infrastructure services', 90),
    ('Security & Compliance', 'Identity, access, audit and regulatory systems', 100),
)


# ---------------------------------------------------------------------------
# Rules (no session needed)
# ---------------------------------------------------------------------------

def clean_name(value):
    """Trim a posted name down to what actually gets stored."""
    if value is None:
        return ''
    return ' '.join(str(value).split())[:NAME_MAX]


def clean_description(value):
    """Trim a posted description; empty becomes None, not the empty string."""
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def validate_name(value):
    """(name, error) for a posted category name."""
    name = clean_name(value)
    if not name:
        return '', 'A category name is required.'
    return name, None


# ---------------------------------------------------------------------------
# Seeding
# ---------------------------------------------------------------------------

def seed_categories(db_session):
    """
    Insert any missing starter category.

    Additive only: a category an administrator renamed, re-worded or retired
    is left exactly as it is. A seeded category deleted outright IS
    re-created - retire rather than delete when the intent is "we never use
    this".

    Returns the number of rows inserted (0 on the common no-op path).
    """
    existing = set()
    for (name,) in db_session.query(ApplicationCategory.name).all():
        existing.add((name or '').strip().lower())

    inserted = 0
    for name, description, sort_order in SEED_CATEGORIES:
        if name.lower() in existing:
            continue
        db_session.add(ApplicationCategory(
            name=name, description=description, sort_order=sort_order,
            is_active=True))
        inserted += 1

    if inserted:
        db_session.commit()
    return inserted


def ensure_seeded(db_session):
    """Seed once, cheaply: a single COUNT on the already-seeded path."""
    if db_session.query(func.count(ApplicationCategory.id)).scalar():
        return 0
    return seed_categories(db_session)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------

def list_categories(db_session, include_inactive=False, include_id=None):
    """
    Categories ordered by sort_order then name.

    ``include_id`` keeps one specific category in the list even when it has
    been retired - that is how an application that already carries a retired
    category can be re-saved without being re-classified.
    """
    query = db_session.query(ApplicationCategory)
    if not include_inactive:
        if include_id:
            query = query.filter((ApplicationCategory.is_active.is_(True)) |
                                 (ApplicationCategory.id == include_id))
        else:
            query = query.filter(ApplicationCategory.is_active.is_(True))
    return query.order_by(ApplicationCategory.sort_order,
                          ApplicationCategory.name).all()


def get_category(db_session, category_id):
    """One category by id, or None."""
    if not category_id:
        return None
    return (db_session.query(ApplicationCategory)
            .filter_by(id=category_id).first())


def find_by_name(db_session, name, exclude_id=None):
    """Case-insensitive lookup, used to stop duplicate categories."""
    name = clean_name(name)
    if not name:
        return None
    query = (db_session.query(ApplicationCategory)
             .filter(func.lower(ApplicationCategory.name) == name.lower()))
    if exclude_id:
        query = query.filter(ApplicationCategory.id != exclude_id)
    return query.first()


def category_in_use(db_session, category_id):
    """
    How many application rows REFERENCE a category.

    Deliberately counts soft-deleted applications too: they still hold the
    foreign key, so they are what makes deleting the category unsafe. The
    admin screen's headline numbers use usage_counts() instead, which counts
    only the records a user can actually see.
    """
    return (db_session.query(func.count(ApplicationDetails.id))
            .filter(ApplicationDetails.category_id == category_id)
            .scalar() or 0)


def usage_counts(db_session):
    """{category_id: live_application_count} for every category, one query."""
    rows = (db_session.query(ApplicationDetails.category_id,
                             func.count(ApplicationDetails.id))
            .filter(ApplicationDetails.category_id.isnot(None),
                    ApplicationDetails.is_active.is_(True))
            .group_by(ApplicationDetails.category_id).all())
    return dict((category_id, count) for category_id, count in rows)


def category_name(app):
    """
    The label to show for an application's category.

    Reads through the relationship and falls back to the empty string -
    templates and exporters both need this to be total, because the column is
    nullable and a category may have been retired.
    """
    category = getattr(app, 'category', None)
    if category is None:
        return ''
    return (getattr(category, 'name', '') or '').strip()


def group_by_category(apps):
    """
    [(label, [app, ...]), ...] ordered by category sort order.

    Applications with no category collect under "Uncategorised", always last,
    so a gap in the data is visible rather than hidden.
    """
    buckets = {}
    for app in apps:
        category = getattr(app, 'category', None)
        if category is None:
            key = (1, 0, 'uncategorised')
            label = 'Uncategorised'
        else:
            key = (0, category.sort_order or 0, (category.name or '').lower())
            label = category.name
        buckets.setdefault(key, (label, []))[1].append(app)
    return [buckets[key] for key in sorted(buckets)]


# ---------------------------------------------------------------------------
# Writes
# ---------------------------------------------------------------------------

def resolve_selection(db_session, raw_value, current_id=None):
    """
    Turn the posted dropdown value into (category_id, error).

    Blank means "not classified" and is accepted - the field is optional by
    design, so a long form can be saved before the business area is known.

    An id the browser sends is never trusted: it must exist, and it must
    either be active or be the category this application already carries.
    """
    text = (raw_value or '').strip()
    if not text:
        return None, None
    try:
        category_id = int(text)
    except (TypeError, ValueError):
        return None, 'Unknown category selected.'

    category = get_category(db_session, category_id)
    if category is None:
        return None, 'Unknown category selected.'
    if not category.is_active and category_id != current_id:
        return None, ('"{0}" has been retired and can no longer be '
                      'assigned.'.format(category.name))
    return category_id, None


def clear_category(db_session, category_id):
    """Un-classify every application under a category. Caller commits."""
    (db_session.query(ApplicationDetails)
     .filter(ApplicationDetails.category_id == category_id)
     .update({ApplicationDetails.category_id: None},
             synchronize_session=False))
