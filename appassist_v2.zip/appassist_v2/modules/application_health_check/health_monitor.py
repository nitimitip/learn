"""Application health runner with durable scheduling and notification delivery.

Production owner: the dedicated Windows service. IIS scheduling remains off
by default. A standalone CLI is also supported; do not share an APScheduler
job store among independent scheduler processes.

next_run_time defines the local-time schedule; a separate renewable UTC lease
serializes scheduled/manual runs. Token and configuration-version checks
fence result writes. Results and email outbox events commit atomically.
The scheduler independently drains the outbox every 30 seconds.

Existing local schedule/history times are retained for UI compatibility.
Lease, notification and monitoring-heartbeat timestamps use UTC.
"""

import logging
import os
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import timezone
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional
from tzlocal import get_localzone
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval     import IntervalTrigger
from apscheduler.triggers.cron         import CronTrigger
from apscheduler.jobstores.sqlalchemy  import SQLAlchemyJobStore
from apscheduler.events                import EVENT_JOB_ERROR, EVENT_JOB_EXECUTED
from apscheduler.jobstores.base        import JobLookupError

from database import engine, get_db_session
from .models import (
    HealthCheckReport,
    HealthCheckExecution,
)
from .utils import (
    check_url_health,
    check_server_health,
    check_database_health,
)

from .notifications import enqueue_health_email, deliver_pending_notifications

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DURATION_MINUTES: dict = {
    '30min': 30,
    '1hr':   60,
    '2hr':  120,
    '3hr':  180,
    '4hr':  240,
}

PENALTY = {
    'url_failed':       20, 'url_warning':       10,
    'server_failed':    25, 'server_warning':    15,
    'database_failed':  30, 'database_warning':  20,
}

STATUS_RANK = {'healthy': 0, 'warning': 1, 'failed': 2}

RETENTION_DAYS  = 5
RETENTION_BATCH = 1000

# How often the in-process APScheduler sweeps the reports table for
# due runs. The Windows Task Scheduler CLI provides the same sweep on
# its own cadence (~15 min), so this can stay short without doubling
# load - `max_instances=1` prevents overlapping sweeps and the DB-level
# next_run_time check prevents double-execution.
_SWEEP_INTERVAL_MIN: int = int(os.environ.get('HEALTH_SWEEP_INTERVAL_MIN', '1'))

_JOB_PREFIX     = 'health_check_'             # kept for orphan cleanup of legacy jobs
_SWEEP_JOB      = 'health_check_sweep'
_RETENTION_JOB  = 'retention_purge'
_JOBSTORE_TABLE = os.environ.get('APSCHEDULER_TABLE', 'apscheduler_jobs')


# ---------------------------------------------------------------------------
# Lightweight value object passed to the email sender
# ---------------------------------------------------------------------------

@dataclass
class ExecutionResult:
    """Returned by run_health_check.

    Note: this is NOT the SQLAlchemy HealthCheckExecution row - that row
    is persisted separately. This object carries the same data in a form
    convenient for email rendering and for callers that don't keep a
    session open.
    """
    report_id: int
    executed_by: Optional[int]
    overall_status: str
    overall_score: float
    url_results: list = field(default_factory=list)
    server_results: list = field(default_factory=list)
    database_results: list = field(default_factory=list)
    execution_time_seconds: float = 0.0
    executed_at: datetime = field(default_factory=datetime.now)


# ---------------------------------------------------------------------------
# APScheduler lifecycle
# ---------------------------------------------------------------------------

_init_lock          = threading.Lock()
_scheduler:          Optional[BackgroundScheduler] = None


def _build_scheduler() -> BackgroundScheduler:
    """Create the BackgroundScheduler with sensible production defaults."""
    jobstore = SQLAlchemyJobStore(
        engine=engine,
        tablename=_JOBSTORE_TABLE,
    )
    return BackgroundScheduler(
        jobstores={'default': jobstore},
        job_defaults={
            'coalesce':           True,   # Merge missed runs into a single execution
            'max_instances':      1,      # Never run the same report concurrently
            'misfire_grace_time': 60,     # Tolerate up to 60s of lateness
        },
        #timezone=str(datetime.now().astimezone().tzinfo) or 'UTC',
        timezone=get_localzone(),
    )


def init_health_monitoring() -> None:
    """Start the in-process APScheduler. Safe to call multiple times.

    Schedules the probe sweep, notification delivery and retention jobs:
      * health_check_sweep   - every minute, calls run_due_checks()
      * retention_purge      - daily at 02:00, prunes execution history

    On Windows IIS the worker may be recycled - APScheduler with
    SQLAlchemyJobStore preserves these two jobs across recycles, but
    the Windows Task Scheduler running run_health_checks.py is still
    the durable trigger because IIS may sleep entirely.
    """
    global _scheduler

    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            logging.info("Health monitoring already running - skipping re-init.")
            return

        from .schema import ensure_health_schema
        ensure_health_schema(engine)
        _scheduler = _build_scheduler()
        _scheduler.add_listener(_job_event_listener,
                                EVENT_JOB_ERROR | EVENT_JOB_EXECUTED)

        _sync_jobs_with_reports()
        _schedule_sweep_job()
        _schedule_retention_job()
        _scheduler.add_job(deliver_pending_notifications, 'interval', seconds=30,
                           id='health_notification_delivery', replace_existing=True,
                           max_instances=1, coalesce=True)

        _scheduler.start()
        logging.info("APScheduler health monitoring started.")


def shutdown_health_monitoring() -> None:
    """Cleanly stop the scheduler. Call from app teardown / atexit."""
    global _scheduler
    with _init_lock:
        if _scheduler is not None and _scheduler.running:
            _scheduler.shutdown(wait=False)
            logging.info("APScheduler health monitoring stopped.")
        _scheduler = None


def _job_event_listener(event) -> None:
    """Log job outcomes for observability. Does NOT keep history rows.

    APScheduler does not persist job-execution history by default - only
    job DEFINITIONS are stored in the jobstore. Each successful run
    updates the next-run-time in place; we don't need to manually purge.
    Failed runs are surfaced to the application log here.
    """
    if event.exception:
        logging.error(
            "APScheduler job %s raised an exception: %s",
            event.job_id, event.exception,
        )
    else:
        logging.debug("APScheduler job %s completed.", event.job_id)


# ---------------------------------------------------------------------------
# Job registration
# ---------------------------------------------------------------------------
# Under the next_run_time-driven model the in-process scheduler only owns
# TWO jobs: the periodic sweep (runs run_due_checks) and the nightly
# retention purge. Per-report scheduling is done by setting next_run_time
# on the HealthCheckReport row - no APScheduler job is created per report.
# ---------------------------------------------------------------------------

def _job_id(report_id: int) -> str:
    return f"{_JOB_PREFIX}{report_id}"


def _sync_jobs_with_reports() -> None:
    """At startup: ensure every active report has a sane next_run_time,
    and clean up any legacy per-report jobs left over from the old model.
    """
    if _scheduler is None:
        return

    db_session = get_db_session()
    try:
        active_reports = (
            db_session.query(HealthCheckReport)
                      .filter_by(is_active=True, schedule_paused=False).all()
        )
        now = datetime.now()
        for r in active_reports:
            # Seed next_run_time for reports created before this model
            # change, or whose next_run_time was wiped by a manual run.
            if r.next_run_time is None:
                interval = DURATION_MINUTES.get(r.check_duration, 60)
                r.next_run_time = now + timedelta(minutes=interval)
        db_session.commit()
        logging.info(
            "Schedule reconciled - %d active report(s); next_run_time seeded "
            "where missing.",
            len(active_reports),
        )
    except Exception:
        logging.exception("Failed to reconcile next_run_time on startup.")
        try:
            db_session.rollback()
        except Exception:
            pass
    finally:
        db_session.close()

    # Remove any leftover per-report APScheduler jobs from the old model
    # (these would otherwise keep triggering on their own intervals).
    try:
        for job in list(_scheduler.get_jobs()):
            if job.id.startswith(_JOB_PREFIX):
                try:
                    _scheduler.remove_job(job.id)
                    logging.info("Removed legacy per-report job %s.", job.id)
                except JobLookupError:
                    pass
    except Exception:
        logging.exception("Failed to clean up legacy per-report jobs.")


def schedule_health_check(report) -> None:
    """Register / re-register the schedule for a single report.

    Under the next_run_time-driven model this only sets the DB column;
    the in-process sweep job and the Windows Task Scheduler CLI will
    both pick the report up the next time it sweeps.

    Called by routes.py whenever a report is created, edited, or
    re-activated so the new interval takes effect immediately.
    """
    interval = DURATION_MINUTES.get(report.check_duration, 60)
    target   = datetime.now() + timedelta(minutes=interval)

    # If the caller's session is still attached, just stamp the model.
    # Otherwise, open a short-lived session to persist the change.
    try:
        from sqlalchemy.orm import object_session
        sess = object_session(report)
    except Exception:
        sess = None

    if sess is not None:
        # Caller is responsible for committing - common when called inside
        # a create/edit route that's about to commit anyway.
        report.next_run_time = target
        logging.debug(
            "Scheduled health check for report %s ('%s') - next run at %s "
            "(interval %d min).",
            report.id, report.application_name,
            target.isoformat(timespec='seconds'), interval,
        )
        return

    # Detached object - open our own session to update.
    db_session = get_db_session()
    try:
        live = db_session.query(HealthCheckReport).filter_by(id=report.id).first()
        if live is None:
            return
        live.next_run_time = target
        db_session.commit()
        logging.debug(
            "Scheduled health check for report %s ('%s') - next run at %s "
            "(interval %d min).",
            live.id, live.application_name,
            target.isoformat(timespec='seconds'), interval,
        )
    except Exception:
        logging.exception("Failed to set next_run_time for report %s.", report.id)
        try:
            db_session.rollback()
        except Exception:
            pass
    finally:
        db_session.close()


def unschedule_health_check(report_id: int) -> None:
    """Remove the schedule entry for a deactivated/deleted report.

    Under the next_run_time-driven model this clears the DB column so
    the sweep ignores the report. Also removes any legacy APScheduler
    job left over from the old per-report model.
    """
    db_session = get_db_session()
    try:
        live = db_session.query(HealthCheckReport).filter_by(id=report_id).first()
        if live is not None:
            live.next_run_time = None
            db_session.commit()
    except Exception:
        logging.exception("Failed to clear next_run_time for report %s.", report_id)
        try:
            db_session.rollback()
        except Exception:
            pass
    finally:
        db_session.close()

    if _scheduler is None:
        return
    try:
        _scheduler.remove_job(_job_id(report_id))
        logging.debug("Removed legacy per-report job for %s.", report_id)
    except JobLookupError:
        pass


# ---------------------------------------------------------------------------
# The sweep job - runs every minute (configurable) and triggers any
# reports whose next_run_time has elapsed.
# ---------------------------------------------------------------------------

def _schedule_sweep_job() -> None:
    if _scheduler is None:
        return
    _scheduler.add_job(
        func=_sweep_safe,
        trigger=IntervalTrigger(minutes=_SWEEP_INTERVAL_MIN),
        id=_SWEEP_JOB,
        name=f'Health-check sweep (every {_SWEEP_INTERVAL_MIN} min)',
        replace_existing=True,
        coalesce=True,
        max_instances=1,
        misfire_grace_time=60,
    )
    logging.info(
        "Sweep job scheduled - runs every %d minute(s).",
        _SWEEP_INTERVAL_MIN,
    )


def _sweep_safe() -> None:
    """Sweep entry point used by APScheduler - swallows everything so a
    transient failure on one report cannot kill the scheduler thread."""
    try:
        stats = run_due_checks(force=False)
        if stats['ran'] or stats['failed']:
            logging.info("Sweep complete: %s", stats)
        else:
            logging.debug("Sweep complete: %s", stats)
    except Exception:
        logging.exception("Health-check sweep crashed (suppressed).")


# ---------------------------------------------------------------------------
# Retention - runs once a day at 02:00 local
# ---------------------------------------------------------------------------

def _schedule_retention_job() -> None:
    if _scheduler is None:
        return
    _scheduler.add_job(
        func=_run_retention_safe,
        trigger=CronTrigger(hour=2, minute=0),
        id=_RETENTION_JOB,
        name='5-day execution-history purge',
        replace_existing=True,
    )
    logging.info("Retention purge scheduled daily at 02:00.")


def _run_retention_safe() -> None:
    try:
        deleted = purge_old_executions()
        logging.info("Retention purge complete - removed %d row(s).", deleted)
    except Exception:
        logging.exception("Retention purge failed.")


def purge_old_executions(retention_days: int = RETENTION_DAYS) -> int:
    """Delete HealthCheckExecution rows older than `retention_days`."""
    if retention_days < 1:
        raise ValueError('retention_days must be positive.')
    cutoff = datetime.now() - timedelta(days=retention_days)
    total_deleted = 0

    db_session = get_db_session()
    try:
        while True:
            ids = [
                row[0] for row in db_session.query(HealthCheckExecution.id)
                                            .filter(HealthCheckExecution.executed_at < cutoff)
                                            .limit(RETENTION_BATCH)
                                            .all()
            ]
            if not ids:
                break
            db_session.query(HealthCheckExecution) \
                      .filter(HealthCheckExecution.id.in_(ids)) \
                      .delete(synchronize_session=False)
            db_session.commit()
            total_deleted += len(ids)
            if len(ids) < RETENTION_BATCH:
                break
    except Exception:
        logging.exception("Retention purge crashed mid-batch - rolling back.")
        try:
            db_session.rollback()
        except Exception:
            pass
        raise
    finally:
        db_session.close()

    logging.info(
        "Purged %d execution rows older than %d day(s) (cutoff %s).",
        total_deleted, retention_days, cutoff.isoformat(timespec='seconds'),
    )
    # Sent payloads contain operational details: retain them no longer than
    # execution history. Pending/failed deliveries remain for operator action.
    from .models import HealthNotification
    with get_db_session() as db:
        while True:
            ids = [row[0] for row in db.query(HealthNotification.id).filter(
                HealthNotification.state.in_(('sent', 'superseded')),
                HealthNotification.sent_at < _utcnow() - timedelta(days=retention_days),
            ).limit(RETENTION_BATCH).all()]
            if not ids:
                break
            db.query(HealthNotification).filter(HealthNotification.id.in_(ids)).delete(synchronize_session=False)
            db.commit()
    return total_deleted


# ---------------------------------------------------------------------------
# Core execution - used by APScheduler, manual UI runs, and the CLI
# ---------------------------------------------------------------------------

def _merge_status(current: str, incoming: str) -> str:
    """Combine two overall statuses, taking the worst."""
    if STATUS_RANK.get(incoming, 0) > STATUS_RANK.get(current, 0):
        return incoming
    return current


def _utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _claim_report_for_run(report_id: int, force: bool = False) -> tuple:
    """Claim due work atomically; manual runs share the same renewable lease."""
    db_session = get_db_session()
    token = str(uuid.uuid4())
    try:
        query = db_session.query(HealthCheckReport).filter(
            HealthCheckReport.id == report_id,
            HealthCheckReport.is_active.is_(True),
            (HealthCheckReport.run_token.is_(None)) |
            (HealthCheckReport.run_lease_until < _utcnow()),
        )
        if not force:
            query = query.filter(
                HealthCheckReport.schedule_paused.is_(False),
                (HealthCheckReport.next_run_time.is_(None)) |
                (HealthCheckReport.next_run_time <= datetime.now()),
            )
        rows = query.update({
            'run_token': token,
            'run_lease_until': _utcnow() + timedelta(seconds=120),
        }, synchronize_session=False)
        if not rows:
            db_session.rollback()
            return None, 'lost_race'
        # Read configuration under the row lock, before committing the claim.
        report = db_session.query(HealthCheckReport).filter_by(id=report_id).one()
        snapshot = {key: getattr(report, key) for key in (
            'id', 'application_name', 'tower_id', 'check_duration',
            'url_monitoring_enabled', 'server_monitoring_enabled',
            'database_monitoring_enabled', 'email_alerts_enabled', 'config_version')}
        snapshot.update(token=token, previous_next_run=report.next_run_time, force=force)
        for kind in ('url', 'server', 'database'):
            key = kind + '_monitors'
            snapshot[key] = list(getattr(report, key)) if snapshot[kind + '_monitoring_enabled'] else []
            for obj in snapshot[key]:
                db_session.expunge(obj)
        db_session.commit()
        return snapshot, 'claimed'
    except Exception:
        db_session.rollback()
        logging.exception('Failed to claim report %s.', report_id)
        return None, 'error'
    finally:
        db_session.close()


def _renew_lease(snapshot):
    with get_db_session() as db:
        rows = db.query(HealthCheckReport).filter(
            HealthCheckReport.id == snapshot['id'],
            HealthCheckReport.run_token == snapshot['token'],
            HealthCheckReport.run_lease_until > _utcnow(),
            HealthCheckReport.config_version == snapshot['config_version'],
        ).update({'run_lease_until': _utcnow() + timedelta(seconds=120)}, synchronize_session=False)
        db.commit()
        return bool(rows)


def _release_lease(snapshot):
    try:
        with get_db_session() as db:
            db.query(HealthCheckReport).filter_by(
                id=snapshot['id'], run_token=snapshot['token'],
            ).update({'run_token': None, 'run_lease_until': None}, synchronize_session=False)
            db.commit()
    except Exception:
        logging.exception('Lease release failed for report %s; it will expire.', snapshot['id'])


def _run_health_check_with_outcome(report_id: int, executed_by: Optional[int] = None,
                                   bypass_due_check: bool = False) -> tuple:
    snapshot, reason = _claim_report_for_run(report_id, force=bypass_due_check)
    if snapshot is None:
        return None, reason
    stop = threading.Event()
    lost = threading.Event()
    budget = max(60, int(os.environ.get('HEALTH_REPORT_BUDGET_SECONDS', '900')))
    snapshot['deadline'] = time.monotonic() + budget
    snapshot['lease_lost'] = lost

    def renew():
        while not stop.wait(30):
            try:
                if time.monotonic() >= snapshot['deadline'] or not _renew_lease(snapshot):
                    lost.set()
                    return
            except Exception:
                logging.exception('Cannot renew report %s lease.', report_id)
                lost.set()
                return

    beater = threading.Thread(target=renew, name='health-lease-' + str(report_id), daemon=True)
    beater.start()
    try:
        return _run_claimed_report(snapshot, executed_by)
    finally:
        stop.set()
        beater.join(timeout=5)
        _release_lease(snapshot)


def _probe_with_budget(snapshot, probe, monitor):
    if snapshot['lease_lost'].is_set():
        raise RuntimeError('Execution lease was lost; result cannot be committed.')
    if time.monotonic() >= snapshot['deadline']:
        raise TimeoutError('Report execution budget exhausted; target was not checked.')
    return probe(monitor)


def _run_claimed_report(snapshot, executed_by):
    start_time     = time.monotonic()
    overall_status = 'healthy'
    overall_score  = 100.0

    url_results:      list = []
    server_results:   list = []
    database_results: list = []

    # ---- 2. Run the checks with NO db session held -------------------
    if snapshot['url_monitoring_enabled']:
        for url_monitor in snapshot['url_monitors']:
            try:
                result = _probe_with_budget(snapshot, check_url_health, url_monitor)
                url_results.append(result)
                if result.get('status') == 'failed':
                    overall_status = _merge_status(overall_status, 'failed')
                    overall_score -= PENALTY['url_failed']
                elif result.get('status') not in ('success', 'healthy'):
                    overall_status = _merge_status(overall_status, 'warning')
                    overall_score -= PENALTY['url_warning']
            except Exception as exc:
                logging.exception(
                    "URL check crashed for monitor id=%s",
                    getattr(url_monitor, 'id', '?'),
                )
                url_results.append({
                    'name':          getattr(url_monitor, 'name', 'unknown'),
                    'url':           getattr(url_monitor, 'url',  'unknown'),
                    'status':        'failed',
                    'error_message': f"{type(exc).__name__}: {exc}" if str(exc) else type(exc).__name__,
                })
                overall_status = _merge_status(overall_status, 'failed')
                overall_score -= PENALTY['url_failed']

    if snapshot['server_monitoring_enabled']:
        for server_monitor in snapshot['server_monitors']:
            try:
                result = _probe_with_budget(snapshot, check_server_health, server_monitor)
                server_results.append(result)
                if result.get('status') == 'failed':
                    overall_status = _merge_status(overall_status, 'failed')
                    overall_score -= PENALTY['server_failed']
                elif result.get('status') not in ('success', 'healthy'):
                    overall_status = _merge_status(overall_status, 'warning')
                    overall_score -= PENALTY['server_warning']
            except Exception as exc:
                logging.exception(
                    "Server check crashed for monitor id=%s",
                    getattr(server_monitor, 'id', '?'),
                )
                server_results.append({
                    'hostname':      getattr(server_monitor, 'hostname',    'unknown'),
                    'server_type':   getattr(server_monitor, 'server_type', 'unknown'),
                    'status':        'failed',
                    'error_message': f"{type(exc).__name__}: {exc}" if str(exc) else type(exc).__name__,
                })
                overall_status = _merge_status(overall_status, 'failed')
                overall_score -= PENALTY['server_failed']

    if snapshot['database_monitoring_enabled']:
        for db_monitor in snapshot['database_monitors']:
            try:
                result = _probe_with_budget(snapshot, check_database_health, db_monitor)
                database_results.append(result)
                if result.get('status') == 'failed':
                    overall_status = _merge_status(overall_status, 'failed')
                    overall_score -= PENALTY['database_failed']
                elif result.get('status') not in ('success', 'healthy'):
                    overall_status = _merge_status(overall_status, 'warning')
                    overall_score -= PENALTY['database_warning']
            except Exception as exc:
                logging.exception(
                    "Database check crashed for monitor id=%s",
                    getattr(db_monitor, 'id', '?'),
                )
                database_results.append({
                    'host':          getattr(db_monitor, 'host',          'unknown'),
                    'database_type': getattr(db_monitor, 'database_type', 'unknown'),
                    'database_name': getattr(db_monitor, 'database_name', 'unknown'),
                    'status':        'failed',
                    'error_message': f"{type(exc).__name__}: {exc}" if str(exc) else type(exc).__name__,
                })
                overall_status = _merge_status(overall_status, 'failed')
                overall_score -= PENALTY['database_failed']

    if not (url_results or server_results or database_results):
        overall_status, overall_score = 'warning', 0.0
        url_results.append({'name': 'Monitoring configuration', 'url': '', 'status': 'warning',
                            'warning_reason': 'No enabled targets were checked.'})
    for kind, results in (('url', url_results), ('server', server_results), ('database', database_results)):
        if snapshot[kind + '_monitoring_enabled'] and not snapshot[kind + '_monitors']:
            overall_status = _merge_status(overall_status, 'warning')
            results.append({'name': 'Monitoring configuration', 'hostname': '', 'host': '',
                            'status': 'warning', 'warning_reason': 'Enabled section has no targets.'})
    overall_score  = max(0.0, overall_score)
    execution_time = time.monotonic() - start_time
    now            = datetime.now()
    interval       = DURATION_MINUTES.get(snapshot['check_duration'], 60)

    # Anchor the next run on the SCHEDULED slot (the next_run_time that
    # made this report due), not on completion time. Anchoring on
    # "now + interval" pushes next_run past the following sweep by the
    # execution duration, so with a coarse sweep (e.g. 30 min) a 30-min
    # report would effectively run only every 60 min. Stepping forward
    # from the previous slot keeps the period exact, and the catch-up
    # loop advances a report that fell behind to the next future slot.
    prev_slot = snapshot.get('previous_next_run')
    if snapshot['force'] and prev_slot is not None and prev_slot > now:
        next_run = prev_slot
    elif prev_slot is None:
        # First-ever run.
        next_run = now + timedelta(minutes=interval)
    else:
        next_run = prev_slot + timedelta(minutes=interval)
        steps = 0
        while next_run <= now and steps < 100_000:
            next_run += timedelta(minutes=interval)
            steps += 1

    # ---- 3. Persist results (short-lived session) --------------------
    db_session = get_db_session()
    try:
        # Conditional write obtains the row lock and fences stale workers/config.
        rows = db_session.query(HealthCheckReport).filter(
            HealthCheckReport.id == snapshot['id'],
            HealthCheckReport.run_token == snapshot['token'],
            HealthCheckReport.run_lease_until > _utcnow(),
            HealthCheckReport.config_version == snapshot['config_version'],
            HealthCheckReport.is_active.is_(True),
        ).update({'run_token': None, 'run_lease_until': None}, synchronize_session=False)
        if not rows or snapshot['lease_lost'].is_set():
            db_session.rollback()
            return None, 'lost_race'
        persisted_report = db_session.query(HealthCheckReport).filter_by(id=snapshot['id']).one()

        execution_row = HealthCheckExecution(
            report_id=persisted_report.id,
            executed_by=executed_by,
            executed_at=now,
            overall_status=overall_status,
            overall_score=overall_score,
            url_results=url_results,
            server_results=server_results,
            database_results=database_results,
            execution_time_seconds=execution_time,
        )
        db_session.add(execution_row)

        persisted_report.last_run_time           = now
        persisted_report.last_run_status         = overall_status
        persisted_report.last_run_score          = overall_score
        persisted_report.latest_url_results      = url_results
        persisted_report.latest_server_results   = server_results
        persisted_report.latest_database_results = database_results
        # Advance the scheduled slot only after the result is persisted.
        persisted_report.next_run_time           = None if persisted_report.schedule_paused else next_run

        db_session.flush()

        logging.info(
            "Health check for report %s ('%s'): %s (%.1f%%) in %.2fs.",
            persisted_report.id, persisted_report.application_name,
            overall_status, overall_score, execution_time,
        )

        result_obj = ExecutionResult(
            report_id=persisted_report.id,
            executed_by=executed_by,
            overall_status=overall_status,
            overall_score=overall_score,
            url_results=url_results,
            server_results=server_results,
            database_results=database_results,
            execution_time_seconds=execution_time,
            executed_at=now,
        )

        # Persist the email event atomically with the health result. No SMTP
        # calls occur while holding this transaction or the report lease.
        if snapshot['email_alerts_enabled']:
            enqueue_health_email(persisted_report, result_obj, db_session)
        db_session.commit()

        return (result_obj, 'ran')

    except Exception:
        logging.exception(
            "Unexpected error persisting health check for report %s.",
            snapshot['id'],
        )
        try:
            db_session.rollback()
        except Exception:
            pass
        return (None, 'error')
    finally:
        db_session.close()


def run_health_check(report_id: int,
                     executed_by: Optional[int] = None) -> Optional[ExecutionResult]:
    """Run all enabled checks for a report and persist the results.

    Public facade - preserves the existing ``Optional[ExecutionResult]``
    contract so callers (routes.py, run_health_checks.py) don't need to
    change. Bucket-level outcome info is available via the internal
    ``_run_health_check_with_outcome`` helper.

    Resource hygiene
    ----------------
    * The DB session that loads the report config is opened, used, and
      CLOSED before any URL / SSH / Oracle / MSSQL check runs. Long-
      running checks therefore never pin a connection from the pool.
    * Each individual check (URL, server, database) opens and closes
      its own remote connection in its `finally` block (see utils.py).
    * After all checks finish, a fresh short-lived DB session is opened
      to write the HealthCheckExecution row and update the report
      snapshot, then closed.
    """
    result, _outcome = _run_health_check_with_outcome(report_id, executed_by)
    return result


def run_health_check_force(report_id: int,
                           executed_by: Optional[int] = None) -> Optional[ExecutionResult]:
    """Run a single report NOW regardless of its next_run_time.

    Used by the CLI's ``--report N --force`` combo and by any caller
    that wants to bypass the due-time check (e.g. the Flask manual-run
    button if it prefers immediate execution over respecting the
    schedule).
    """
    result, _outcome = _run_health_check_with_outcome(
        report_id, executed_by, bypass_due_check=True,
    )
    return result


# NOTE: run_health_check_manual(report, executed_by) used to live here and was
# called straight from the Flask "Run Check" view, which meant the whole run
# happened inside the HTTP request. That is gone: routes.run_manual_check now
# calls manual_run.enqueue(), which spawns run_health_checks.py --job in a
# detached process, and the page polls for progress. Use run_health_check_force
# (by report_id) if you need to run one report from code.
#
# The old signature took a REPORT OBJECT that the view had already released
# from its session; it happened to work only because .id was already loaded.
# Passing an id avoids that trap entirely.


# ---------------------------------------------------------------------------
# CLI entry point - used by run_health_checks.py / Windows Task Scheduler
# ---------------------------------------------------------------------------

def run_due_checks(force: bool = False) -> dict:
    """Run every report whose next_run_time has elapsed.

    Single source of truth for the schedule is HealthCheckReport.next_run_time.
    The query filters at the database level so we don't pull every active
    report into memory just to skip it. Per-sweep limit (env var
    HEALTH_SWEEP_BATCH, default 50) keeps a backlog from saturating the
    monitoring host if many reports become due simultaneously.

    Called by:
      * the in-process APScheduler sweep (_sweep_safe)
      * run_health_checks.py (Windows Task Scheduler)
    """
    stats = {'total': 0, 'ran': 0, 'skipped': 0, 'failed': 0}
    now    = datetime.now()
    batch  = max(1, min(1000, int(os.environ.get('HEALTH_SWEEP_BATCH', '50'))))

    db_session = get_db_session()
    try:
        if force:
            due_ids = [
                row[0] for row in (
                    db_session.query(HealthCheckReport.id)
                              .filter(
                                  HealthCheckReport.is_active.is_(True),
                                  HealthCheckReport.schedule_paused.is_(False),
                                  (HealthCheckReport.run_token.is_(None)) |
                                  (HealthCheckReport.run_lease_until < _utcnow()),
                              )
                              .limit(batch)
                              .all()
                )
            ]
            stats['total'] = (
                db_session.query(HealthCheckReport)
                          .filter(
                              HealthCheckReport.is_active.is_(True),
                              HealthCheckReport.schedule_paused.is_(False),
                          )
                          .count()
            )
        else:
            due_ids = [
                row[0] for row in (
                    db_session.query(HealthCheckReport.id)
                              .filter(
                                  HealthCheckReport.is_active.is_(True),
                                  HealthCheckReport.schedule_paused.is_(False),
                                  (HealthCheckReport.next_run_time.is_(None)) |
                                  (HealthCheckReport.next_run_time <= now),
                                  (HealthCheckReport.run_token.is_(None)) |
                                  (HealthCheckReport.run_lease_until < _utcnow()),
                              )
                              .order_by(HealthCheckReport.next_run_time.asc())
                              .limit(batch)
                              .all()
                )
            ]
            stats['total'] = len(due_ids)
        stats['skipped'] = max(stats['total'] - len(due_ids), 0)
    except Exception:
        logging.exception("run_due_checks: failed to enumerate due reports.")
        raise
    finally:
        db_session.close()

    workers = max(1, min(16, int(os.environ.get('HEALTH_WORKERS', '4'))))
    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix='health-report') as pool:
        pending = {pool.submit(_run_health_check_with_outcome, report_id,
                               bypass_due_check=force): report_id for report_id in due_ids}
        for future in as_completed(pending):
            try:
                _result, outcome = future.result()
                if outcome == 'ran':
                    stats['ran'] += 1
                elif outcome in ('lost_race', 'inactive'):
                    stats['skipped'] += 1
                else:
                    stats['failed'] += 1
            except Exception:
                logging.exception('run_due_checks: report %s crashed.', pending[future])
                stats['failed'] += 1

    from .observability import record_sweep
    record_sweep(stats)
    return stats
