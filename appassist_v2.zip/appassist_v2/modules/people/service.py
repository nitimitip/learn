"""
People Directory - data assembly.

The directory owns no tables of its own. Every fact on a person's page is
READ from the module that already owns it, so the CV can never drift from
the record:

* identity, group / sub-group / team  - the shared ``users`` row (My Profile)
* technical & soft skills             - ``user_skills`` (My Profile)
* tower, applications, primary owner  - Application Support
* incidents / service requests worked - ServiceNow Analysis workload capture
* projects and the role held on them  - Project Management

Nothing here writes. The two entry points are :func:`directory_rows` (the
search results) and :func:`build_profile` (one person's dossier).

Tower attribution
-----------------
Application Support records a person's tower two ways and the directory
honours both:

* ``member``  - an explicit Tower Member row (the authoritative statement),
* ``support`` - derived: the person is on the support team of an application
  that belongs to the tower.

A person can therefore carry several towers, and the same tower can arrive
from both sources - 'member' wins for display because it was stated rather
than inferred.
"""

import logging
from collections import OrderedDict, defaultdict
from datetime import datetime, timedelta

from sqlalchemy import func, or_

from models import User
from modules.application_support.models import (ApplicationCategory,
                                                ApplicationDetails,
                                                AppSupportTower, SupportTeam,
                                                TeamRole, TowerMember)
from modules.application_support.tech_details import CATEGORY_META
from modules.project_management.models import (Project, ProjectMilestone,
                                               ProjectTask, ProjectTeamMember,
                                               TaskStatus)
from modules.service_now_analysis.models import SnowTicketWorkload
from modules.service_now_analysis.workload_themes import priority_breakdown
from modules.user_profile.models import (SKILL_SOFT, SKILL_TECHNICAL,
                                         UserSkill)

logger = logging.getLogger(__name__)

# ServiceNow contribution window, matched to the Resource Utilization
# workload panel so the two never quote different numbers for one person.
WORKLOAD_WINDOW_DAYS = 365

# How much of each long list the profile shows before it stops being a CV
# and starts being a report.
RECENT_TICKETS = 12
TOP_GROUPS = 6

TOWER_SOURCE_LABELS = {
    'member': 'Tower member',
    'support': 'Application support',
}


# ---------------------------------------------------------------------------
# Small shared helpers
# ---------------------------------------------------------------------------

def full_name(person):
    """'Firstname Lastname', trimmed - the display name used everywhere."""
    first = (person.firstname or '').strip()
    last = (person.lastname or '').strip()
    return (first + ' ' + last).strip()


def initials(person):
    """Up to two letters for the avatar chip, falling back to the username."""
    first = (person.firstname or '').strip()
    last = (person.lastname or '').strip()
    letters = (first[:1] + last[:1]).strip()
    if not letters:
        letters = (person.username or '?')[:2]
    return letters.upper()


def _email_key(value):
    return (value or '').strip().lower()


def _name_key(person):
    return full_name(person).lower()


def _enum_value(value):
    """Display text for a value that may be an Enum, a string or None."""
    if value is None:
        return None
    return getattr(value, 'value', value)


# ---------------------------------------------------------------------------
# Filter options
# ---------------------------------------------------------------------------

def tower_options(db_session):
    """[(id, name)] for every active Application Support tower."""
    rows = (db_session.query(AppSupportTower.id, AppSupportTower.tower_name)
            .filter(AppSupportTower.is_active.is_(True))
            .order_by(AppSupportTower.tower_name).all())
    return [(row_id, name) for row_id, name in rows]


def sub_group_options(db_session):
    """Every sub-group value actually carried by a person, alphabetically.

    The values IN USE rather than the admin list: a sub-group nobody sits in
    would only ever return an empty result page.
    """
    rows = (db_session.query(User.sub_group)
            .filter(User.is_active.is_(True),
                    User.sub_group.isnot(None), User.sub_group != '')
            .distinct().order_by(User.sub_group).all())
    return [value for (value,) in rows]


# ---------------------------------------------------------------------------
# Tower attribution
# ---------------------------------------------------------------------------

def towers_by_user(db_session, users):
    """
    {user_id: [{'id', 'name', 'lead', 'source'}]} for the given users.

    Explicit Tower Member rows first, then the towers reached through the
    applications the person supports; a tower already claimed by membership
    is not repeated.
    """
    towers = dict((u.id, []) for u in users)
    if not towers:
        return towers
    ids = list(towers)
    seen = defaultdict(set)

    tower_rows = (db_session.query(AppSupportTower)
                  .filter(AppSupportTower.is_active.is_(True)).all())
    by_id = dict((t.id, t) for t in tower_rows)

    member_rows = (db_session.query(TowerMember.tower_id, TowerMember.user_id)
                   .filter(TowerMember.user_id.in_(ids)).all())
    for tower_id, user_id in member_rows:
        tower = by_id.get(tower_id)
        if tower is None or tower_id in seen[user_id]:
            continue
        seen[user_id].add(tower_id)
        towers[user_id].append({'id': tower.id, 'name': tower.tower_name,
                                'lead': tower.tower_lead,
                                'source': 'member'})

    email_to_id = {}
    for u in users:
        key = _email_key(u.email)
        if key:
            email_to_id[key] = u.id
    if email_to_id:
        rows = (db_session.query(func.lower(SupportTeam.email),
                                 ApplicationDetails.tower_id)
                .join(ApplicationDetails,
                      SupportTeam.application_id == ApplicationDetails.id)
                .filter(ApplicationDetails.is_active.is_(True),
                        func.lower(SupportTeam.email).in_(list(email_to_id)))
                .distinct().all())
        for email, tower_id in rows:
            user_id = email_to_id.get(email)
            tower = by_id.get(tower_id)
            if user_id is None or tower is None or tower_id in seen[user_id]:
                continue
            seen[user_id].add(tower_id)
            towers[user_id].append({'id': tower.id, 'name': tower.tower_name,
                                    'lead': tower.tower_lead,
                                    'source': 'support'})

    for rows in towers.values():
        rows.sort(key=lambda t: (t['source'] != 'member', t['name'].lower()))
    return towers


def user_ids_in_tower(db_session, tower_id):
    """
    The set of user ids attributed to one tower, by either route.

    Resolved in SQL and applied as a filter on the people query, so the
    tower search stays a database question rather than a scan of everybody's
    tower map.
    """
    ids = set(user_id for (user_id,) in
              db_session.query(TowerMember.user_id)
              .filter(TowerMember.tower_id == tower_id).all())

    emails = [email for (email,) in
              db_session.query(func.lower(SupportTeam.email))
              .join(ApplicationDetails,
                    SupportTeam.application_id == ApplicationDetails.id)
              .filter(ApplicationDetails.tower_id == tower_id,
                      ApplicationDetails.is_active.is_(True),
                      SupportTeam.email.isnot(None),
                      SupportTeam.email != '')
              .distinct().all()]
    if emails:
        ids.update(user_id for (user_id,) in
                   db_session.query(User.id)
                   .filter(func.lower(User.email).in_(emails)).all())
    return ids


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

def search_users(db_session, name=None, team=None, sub_group=None,
                 tower_id=None):
    """
    Active users matching the directory search, ordered by name.

    ``name`` matches first name, last name, the two joined, username or
    email; the other three are exact filters. A tower filter that resolves
    to nobody returns an empty list rather than everybody.
    """
    query = db_session.query(User).filter(User.is_active.is_(True))

    term = ' '.join((name or '').split())
    if term:
        like = '%' + term + '%'
        joined = func.lower(User.firstname + ' ' + User.lastname)
        query = query.filter(or_(User.firstname.ilike(like),
                                 User.lastname.ilike(like),
                                 joined.like('%' + term.lower() + '%'),
                                 User.username.ilike(like),
                                 User.email.ilike(like)))
    if team:
        query = query.filter(User.team == team)
    if sub_group:
        query = query.filter(User.sub_group == sub_group)
    if tower_id:
        ids = user_ids_in_tower(db_session, tower_id)
        if not ids:
            return []
        query = query.filter(User.id.in_(list(ids)))

    return query.order_by(User.firstname, User.lastname).all()


# ---------------------------------------------------------------------------
# Directory rows
# ---------------------------------------------------------------------------

def _application_counts(db_session, users):
    """{user_id: (supported, primary_owned)} from the support-team roster."""
    counts = dict((u.id, [0, 0]) for u in users)
    email_to_id = {}
    for u in users:
        key = _email_key(u.email)
        if key:
            email_to_id[key] = u.id
    if not email_to_id:
        return dict((uid, (0, 0)) for uid in counts)

    rows = (db_session.query(func.lower(SupportTeam.email), SupportTeam.role,
                             func.count(func.distinct(
                                 SupportTeam.application_id)))
            .join(ApplicationDetails,
                  SupportTeam.application_id == ApplicationDetails.id)
            .filter(ApplicationDetails.is_active.is_(True),
                    func.lower(SupportTeam.email).in_(list(email_to_id)))
            .group_by(func.lower(SupportTeam.email), SupportTeam.role).all())
    for email, role, count in rows:
        user_id = email_to_id.get(email)
        if user_id is None:
            continue
        counts[user_id][0] += count
        if _enum_value(role) == TeamRole.PRIMARY_OWNER.value:
            counts[user_id][1] += count
    return dict((uid, tuple(pair)) for uid, pair in counts.items())


def _project_counts(db_session, users):
    """{user_id: open_project_count} across roster seats and task work."""
    counts = dict((u.id, set()) for u in users)
    ids = list(counts)
    if not ids:
        return {}

    seat_rows = (db_session.query(ProjectTeamMember.user_id,
                                  ProjectTeamMember.project_id)
                 .join(Project, ProjectTeamMember.project_id == Project.id)
                 .filter(ProjectTeamMember.user_id.in_(ids),
                         Project.is_closed.is_(False)).all())
    for user_id, project_id in seat_rows:
        counts[user_id].add(project_id)

    task_rows = (db_session.query(ProjectTask.assigned_to,
                                  ProjectMilestone.project_id)
                 .join(ProjectMilestone,
                       ProjectTask.milestone_id == ProjectMilestone.id)
                 .join(Project, ProjectMilestone.project_id == Project.id)
                 .filter(ProjectTask.assigned_to.in_(ids),
                         Project.is_closed.is_(False)).all())
    for user_id, project_id in task_rows:
        counts[user_id].add(project_id)

    return dict((user_id, len(seen)) for user_id, seen in counts.items())


def _ticket_counts(db_session, users):
    """
    {user_id: {'incidents', 'service_requests', 'total'}} in the window.

    Matched on the assignee display name exactly as ServiceNow exported it -
    the workload table deliberately keeps a name rather than a user id.
    """
    counts = dict((u.id, {'incidents': 0, 'service_requests': 0, 'total': 0})
                  for u in users)
    name_to_id = {}
    for u in users:
        key = _name_key(u)
        if key:
            name_to_id[key] = u.id
    if not name_to_id:
        return counts

    cutoff = datetime.now() - timedelta(days=WORKLOAD_WINDOW_DAYS)
    rows = (db_session.query(func.lower(SnowTicketWorkload.assigned_to),
                             SnowTicketWorkload.ticket_type,
                             func.count(SnowTicketWorkload.id))
            .filter(func.lower(SnowTicketWorkload.assigned_to)
                    .in_(list(name_to_id)),
                    or_(SnowTicketWorkload.opened_at >= cutoff,
                        SnowTicketWorkload.opened_at.is_(None)))
            .group_by(func.lower(SnowTicketWorkload.assigned_to),
                      SnowTicketWorkload.ticket_type).all())
    for name, ticket_type, count in rows:
        user_id = name_to_id.get(name)
        if user_id is None:
            continue
        if ticket_type == 'incident':
            counts[user_id]['incidents'] += count
        elif ticket_type == 'service_request':
            counts[user_id]['service_requests'] += count
        counts[user_id]['total'] += count
    return counts


def _skill_names(db_session, users, skill_type, limit=None):
    """{user_id: [skill name, ...]} of one type, alphabetically."""
    out = dict((u.id, []) for u in users)
    ids = list(out)
    if not ids:
        return out
    rows = (db_session.query(UserSkill.user_id, UserSkill.item_name)
            .filter(UserSkill.user_id.in_(ids),
                    UserSkill.skill_type == skill_type)
            .order_by(UserSkill.item_name).all())
    for user_id, item_name in rows:
        out[user_id].append(item_name)
    if limit is not None:
        return dict((user_id, names[:limit])
                    for user_id, names in out.items())
    return out


def directory_rows(db_session, users, skill_preview=4):
    """
    One card's worth of facts per person, in the order `users` arrived.

    Everything is loaded in grouped queries up front - the directory would
    otherwise fire five queries per person listed.
    """
    if not users:
        return []
    towers = towers_by_user(db_session, users)
    apps = _application_counts(db_session, users)
    projects = _project_counts(db_session, users)
    tickets = _ticket_counts(db_session, users)
    all_skills = _skill_names(db_session, users, SKILL_TECHNICAL)

    rows = []
    for person in users:
        supported, primary = apps.get(person.id, (0, 0))
        skills = all_skills.get(person.id, [])
        shown = skills[:skill_preview]
        rows.append({
            'person': person,
            'name': full_name(person) or person.username,
            'initials': initials(person),
            'towers': towers.get(person.id, []),
            'applications': supported,
            'primary_applications': primary,
            'projects': projects.get(person.id, 0),
            'tickets': tickets.get(person.id, {'incidents': 0,
                                               'service_requests': 0,
                                               'total': 0}),
            'skills': shown,
            'more_skills': len(skills) - len(shown),
        })
    return rows


# ---------------------------------------------------------------------------
# One person's dossier
# ---------------------------------------------------------------------------

def _applications_for(db_session, person):
    """
    {'primary': [...], 'supporting': [...], 'total': n} for one person.

    A row carries the application, its tower, criticality and business
    category - the context that makes "supports 9 applications" mean
    something on a CV.
    """
    empty = {'primary': [], 'supporting': [], 'total': 0}
    email = _email_key(person.email)
    if not email:
        return empty

    rows = (db_session.query(ApplicationDetails, SupportTeam.role,
                             AppSupportTower.tower_name,
                             ApplicationCategory.name)
            .join(SupportTeam,
                  SupportTeam.application_id == ApplicationDetails.id)
            .join(AppSupportTower,
                  ApplicationDetails.tower_id == AppSupportTower.id)
            .outerjoin(ApplicationCategory,
                       ApplicationDetails.category_id
                       == ApplicationCategory.id)
            .filter(ApplicationDetails.is_active.is_(True),
                    func.lower(SupportTeam.email) == email)
            .order_by(ApplicationDetails.application_name).all())

    # One application can appear twice if the roster lists the person more
    # than once; keep the strongest role stated.
    merged = OrderedDict()
    for app, role, tower_name, category_name in rows:
        role_value = _enum_value(role)
        entry = merged.get(app.id)
        if entry is None:
            merged[app.id] = {
                'id': app.id,
                'name': app.application_name,
                'tower': tower_name,
                'category': category_name,
                'criticality': _enum_value(app.business_criticality),
                'summary': app.application_summary,
                'role': role_value,
            }
        elif role_value == TeamRole.PRIMARY_OWNER.value:
            entry['role'] = role_value

    primary, supporting = [], []
    for entry in merged.values():
        if entry['role'] == TeamRole.PRIMARY_OWNER.value:
            primary.append(entry)
        else:
            supporting.append(entry)
    return {'primary': primary, 'supporting': supporting,
            'total': len(merged)}


def _skills_for(db_session, person):
    """
    {'technical': [{label, icon, names}], 'soft': [names], ...}.

    Technical skills are grouped by their Technology Catalog category, in
    the catalog's own category order, so the CV reads OS / Databases /
    Tools / Languages rather than one long alphabetical list.
    """
    rows = (db_session.query(UserSkill)
            .filter(UserSkill.user_id == person.id)
            .order_by(UserSkill.item_name).all())

    by_category = defaultdict(list)
    soft = []
    for row in rows:
        if row.skill_type == SKILL_SOFT:
            soft.append(row.item_name)
        elif row.skill_type == SKILL_TECHNICAL:
            by_category[row.category or ''].append(row.item_name)

    technical = []
    for category in CATEGORY_META:
        names = by_category.pop(category, [])
        if names:
            _, plural, icon = CATEGORY_META[category]
            technical.append({'label': plural, 'icon': icon, 'names': names})
    # A skill recorded against a category the catalog no longer defines must
    # still show up rather than vanish from the person's CV.
    for category, names in sorted(by_category.items()):
        technical.append({'label': category.title() if category else 'Other',
                          'icon': 'fa-microchip', 'names': names})

    return {'technical': technical, 'soft': soft,
            'technical_total': sum(len(g['names']) for g in technical)}


def _service_now_for(db_session, person):
    """
    The ServiceNow contribution: what this person worked and what closed.

    'Worked on' is every captured ticket assigned to them in the window;
    'resolved' is the subset carrying a resolved timestamp. The two are
    reported separately because the export does not always state a
    resolution - counting a blank as unresolved is honest, counting it as
    resolved would not be.
    """
    as_of = db_session.query(func.max(SnowTicketWorkload.captured_at)).scalar()
    blank = {'incidents': 0, 'service_requests': 0, 'other': 0, 'total': 0,
             'resolved': 0, 'resolution_rate': None, 'priority': [],
             'groups': [], 'recent': [], 'window_days': WORKLOAD_WINDOW_DAYS,
             'as_of': as_of}
    name = _name_key(person)
    if not name:
        return blank

    cutoff = datetime.now() - timedelta(days=WORKLOAD_WINDOW_DAYS)
    rows = (db_session.query(SnowTicketWorkload)
            .filter(func.lower(SnowTicketWorkload.assigned_to) == name,
                    or_(SnowTicketWorkload.opened_at >= cutoff,
                        SnowTicketWorkload.opened_at.is_(None))).all())
    if not rows:
        return blank

    tickets = [{
        'number': row.ticket_number,
        'type': row.ticket_type,
        'title': row.short_description,
        'priority': row.priority,
        'category': row.category,
        'assignment_group': row.assignment_group,
        'state': row.state,
        'opened_at': row.opened_at,
        'resolved_at': row.resolved_at,
    } for row in rows]
    # Newest first; a ticket with no opened date sorts to the end rather
    # than blowing up the comparison.
    tickets.sort(key=lambda t: (t['opened_at'] is not None, t['opened_at'],
                                t['number'] or ''),
                 reverse=True)

    counts = {'incident': 0, 'service_request': 0, 'other': 0}
    groups = defaultdict(int)
    resolved = 0
    for ticket in tickets:
        key = ticket['type'] if ticket['type'] in counts else 'other'
        counts[key] += 1
        if ticket['resolved_at'] is not None:
            resolved += 1
        if ticket['assignment_group']:
            groups[ticket['assignment_group']] += 1

    total = len(tickets)
    top_groups = sorted(groups.items(), key=lambda kv: (-kv[1], kv[0]))
    return {
        'incidents': counts['incident'],
        'service_requests': counts['service_request'],
        'other': counts['other'],
        'total': total,
        'resolved': resolved,
        'resolution_rate': round(resolved * 100.0 / total, 1),
        'priority': priority_breakdown(tickets),
        'groups': top_groups[:TOP_GROUPS],
        'recent': tickets[:RECENT_TICKETS],
        'window_days': WORKLOAD_WINDOW_DAYS,
        'as_of': as_of,
    }


def _projects_for(db_session, person):
    """
    Every project the person is on, open ones first, with the role held.

    Two ways onto a project and both count: a seat on the project roster
    (which states the role) and tasks assigned from the plan (which does
    not, so the role reads 'Task assignee'). A person on the roster who also
    carries tasks gets one entry showing both.
    """
    seats = (db_session.query(ProjectTeamMember, Project)
             .join(Project, ProjectTeamMember.project_id == Project.id)
             .filter(ProjectTeamMember.user_id == person.id).all())

    task_rows = (db_session.query(ProjectTask, Project)
                 .join(ProjectMilestone,
                       ProjectTask.milestone_id == ProjectMilestone.id)
                 .join(Project, ProjectMilestone.project_id == Project.id)
                 .filter(ProjectTask.assigned_to == person.id).all())

    entries = OrderedDict()

    def _entry(project):
        if project.id not in entries:
            entries[project.id] = {
                'id': project.id,
                'name': project.name,
                'status': _enum_value(project.status),
                'is_closed': bool(project.is_closed),
                'project_type': project.project_type,
                'methodology': project.methodology,
                'start_date': project.start_date,
                'target_end_date': project.target_end_date,
                'role': None,
                'member_group': None,
                'on_roster': False,
                'tasks': 0,
                'tasks_completed': 0,
                'tasks_open': 0,
                'tasks_overdue': 0,
                'first_task': None,
                'last_task': None,
            }
        return entries[project.id]

    for seat, project in seats:
        entry = _entry(project)
        entry['role'] = seat.role
        entry['member_group'] = seat.member_group
        entry['on_roster'] = True

    for task, project in task_rows:
        entry = _entry(project)
        entry['tasks'] += 1
        if task.status == TaskStatus.COMPLETED:
            entry['tasks_completed'] += 1
        else:
            entry['tasks_open'] += 1
            if task.is_overdue():
                entry['tasks_overdue'] += 1
        if (entry['first_task'] is None
                or task.start_date < entry['first_task']):
            entry['first_task'] = task.start_date
        if entry['last_task'] is None or task.end_date > entry['last_task']:
            entry['last_task'] = task.end_date

    for entry in entries.values():
        if not entry['role']:
            entry['role'] = 'Task assignee'
        entry['completion'] = (round(entry['tasks_completed'] * 100.0
                                     / entry['tasks'])
                               if entry['tasks'] else None)

    def _recency(entry):
        """Sort key: most recent involvement first, undated last."""
        latest = entry['last_task'] or entry['target_end_date']
        return -latest.toordinal() if latest else 0

    return sorted(entries.values(),
                  key=lambda e: (e['is_closed'], _recency(e),
                                 e['name'].lower()))


def build_profile(db_session, person):
    """The complete dossier behind one person's CV page."""
    towers = towers_by_user(db_session, [person]).get(person.id, [])
    applications = _applications_for(db_session, person)
    skills = _skills_for(db_session, person)
    service_now = _service_now_for(db_session, person)
    projects = _projects_for(db_session, person)

    active_projects = [p for p in projects if not p['is_closed']]
    return {
        'person': person,
        'name': full_name(person) or person.username,
        'initials': initials(person),
        'towers': towers,
        'applications': applications,
        'skills': skills,
        'service_now': service_now,
        'projects': projects,
        'summary': {
            'applications': applications['total'],
            'primary_applications': len(applications['primary']),
            'towers': len(towers),
            'projects': len(projects),
            'active_projects': len(active_projects),
            'open_tasks': sum(p['tasks_open'] for p in projects),
            'tickets': service_now['total'],
            'incidents': service_now['incidents'],
            'service_requests': service_now['service_requests'],
            'resolved': service_now['resolved'],
            'skills': skills['technical_total'] + len(skills['soft']),
        },
    }
