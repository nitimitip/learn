"""The run worker for an IIS install: executes queued test runs, one at a time.

Under IIS the web pages come from wsgi.py inside the IIS worker processes, and this
script runs as ONE separate, long-lived process, normally the "QA Portal Run Worker"
scheduled task (deploy/install_run_worker_task.ps1). It:

* takes the worker lock (instance/run_worker.lock), so a second copy, or python app.py
  started on the same data folder, refuses to start instead of aborting this one's runs;
* upgrades the database if needed, marks runs a previous worker left half done as
  interrupted, and prunes old runs;
* then claims Queued runs, starts the browser, writes results, and between runs does
  the WAL checkpoint and the daily backup.

It logs to logs/portal.log (the "Run worker" log on Users & System).

Run by hand for a check:  <venv>\\Scripts\\python.exe run_worker.py
Stop it with Ctrl+C, or Stop on the scheduled task.
"""
import logging
import os
import signal
import sys

import app as portal

log = logging.getLogger("run_worker")


def main():
    try:
        started = portal.bootstrap(start_worker=True)
    except portal.WorkerAlreadyRunning as exc:
        log.error("%s", exc)
        return 2
    thread, stop_event = started
    log.info("QA Automation Portal run worker started, pid %s, data folder %s",
             os.getpid(), portal.config.DATA_DIR)

    def request_stop(signum, _frame):
        log.info("Run worker stopping (signal %s) once the run in progress, if any, ends", signum)
        stop_event.set()

    for name in ("SIGINT", "SIGTERM", "SIGBREAK"):
        if hasattr(signal, name):
            signal.signal(getattr(signal, name), request_stop)
    while thread.is_alive():
        thread.join(1.0)
    log.info("Run worker stopped")
    return 0


if __name__ == "__main__":
    sys.exit(main())
