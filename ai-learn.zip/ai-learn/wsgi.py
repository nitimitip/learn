"""IIS (wfastcgi) entry point: web.config sets WSGI_HANDLER=wsgi.app.

Why not app.app: importing app.py only builds the Flask object. The database setup and
the run worker live in app.main(), which wfastcgi never calls, so a site pointed at
app.app starts with no tables and its runs stay Queued for ever.

IIS starts several of these processes and recycles them whenever it likes, so they only
serve pages. Test runs are executed by run_worker.py, ONE separate process started by
the "QA Portal Run Worker" scheduled task (deploy/install_run_worker_task.ps1). The two
only talk through the database: a run is queued, aborted and read back as table rows.
"""
import app as portal

portal.bootstrap_web()

app = portal.app
