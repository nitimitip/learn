"""Locks shared between processes, kept on a file.

Under IIS the portal runs as several processes: the FastCGI web workers and one run
worker. Two things must never happen twice at the same moment:

* the database upgrade in init_db (two processes adding the same column fail), and
* the run worker itself (a second one would mark the first one's running run as
  "interrupted by a restart" and open a second browser).

The operating system drops the lock when the process ends, even if it crashes, so a
stale lock file never blocks a restart. Standard library only.
"""
import os
import time
from pathlib import Path

if os.name == "nt":
    import msvcrt

    def _try_lock(handle):
        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)

    def _unlock(handle):
        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
else:
    import fcntl

    def _try_lock(handle):
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)

    def _unlock(handle):
        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


class ProcessLock:
    """An exclusive lock on a file, held until release() or the end of the process."""

    def __init__(self, path):
        self.path = Path(path)
        self._handle = None

    @property
    def held(self):
        return self._handle is not None

    def acquire(self, timeout=0.0):
        """True once the lock is held; False if another process still holds it after
        timeout seconds (0 = try once)."""
        if self._handle is not None:
            return True
        self.path.parent.mkdir(parents=True, exist_ok=True)
        handle = open(self.path, "a+b")
        deadline = time.monotonic() + timeout
        while True:
            try:
                _try_lock(handle)
            except OSError:
                if time.monotonic() >= deadline:
                    handle.close()
                    return False
                time.sleep(0.2)
                continue
            self._handle = handle
            return True

    def release(self):
        handle, self._handle = self._handle, None
        if handle is None:
            return
        try:
            _unlock(handle)
        except OSError:
            pass
        handle.close()

    def __enter__(self):
        if not self.acquire(timeout=120):
            raise TimeoutError(f"Another process held {self.path} for two minutes.")
        return self

    def __exit__(self, *exc):
        self.release()
