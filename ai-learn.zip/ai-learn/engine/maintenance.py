"""Database upkeep the run worker does while it is idle.

SQLite in WAL mode writes to a side file (qa_platform.db-wal) and moves the changes
into the database only when no reader is in the way. On a portal that is always being
polled that can be never, so the side file grows and a copy of the .db file alone is
missing most of the data. The worker therefore asks for a full checkpoint now and
then, and once a day makes a consistent copy with SQLite's own backup, which is safe
while the portal is in use.

Standard library only, on its own connection, so it never holds the ORM's session.
"""
import logging
import sqlite3
import time
from datetime import datetime

import config

log = logging.getLogger(__name__)

CHECKPOINT_EVERY_SEC = 300
_BACKUP_PREFIX = "qa_platform_"
_last_checkpoint = 0.0


def checkpoint():
    """Move everything from the -wal file into the database and empty it. Returns True
    when it was done; False when a reader was in the way, which is tried again later."""
    connection = sqlite3.connect(config.DB_PATH, timeout=5)
    try:
        busy, _frames, _moved = connection.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
        return not busy
    finally:
        connection.close()


def backup_path(day=None):
    return config.BACKUP_DIR / f"{_BACKUP_PREFIX}{(day or datetime.now()):%Y%m%d}.db"


def backup(target=None):
    """A consistent copy of the database, taken page by page while it stays in use."""
    target = target or backup_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    partial = target.with_suffix(".partial")
    source = sqlite3.connect(config.DB_PATH, timeout=30)
    try:
        copy = sqlite3.connect(partial)
        try:
            source.backup(copy)
        finally:
            copy.close()
    finally:
        source.close()
    partial.replace(target)  # a half-written copy never has the final name
    return target


def prune_backups():
    """Keep the newest BACKUP_KEEP daily copies."""
    copies = sorted(config.BACKUP_DIR.glob(f"{_BACKUP_PREFIX}*.db"))
    for old in copies[:-config.BACKUP_KEEP]:
        try:
            old.unlink()
        except OSError as exc:
            log.warning("Old backup %s could not be removed: %s", old.name, exc)


def run_idle_tasks(now=None):
    """Called by the run worker between runs. Cheap when nothing is due, and never
    raises: upkeep must not stop test runs."""
    global _last_checkpoint
    now = time.monotonic() if now is None else now
    if now - _last_checkpoint < CHECKPOINT_EVERY_SEC:
        return
    _last_checkpoint = now
    try:
        if not checkpoint():
            log.info("Database checkpoint skipped: the database was being read. It is tried again.")
    except Exception as exc:
        log.warning("Database checkpoint failed: %s", exc)
    try:
        if not backup_path().exists():
            log.info("Database backup written: %s", backup())
            prune_backups()
    except Exception as exc:
        log.warning("Database backup failed: %s", exc)
